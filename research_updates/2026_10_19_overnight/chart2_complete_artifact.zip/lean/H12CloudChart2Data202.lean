import H12CloudChart2Data201

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env50820 : List Nat := [2,4,8,10,32,11,128,256,512,266,674,292,269,0,293,262,1,390,267,292,292,396,11,40,388,10,292,1,293,903,256,303,256,33,0,512]

theorem envBound50820 : H12AffineFastState.Bounded env50820 := by
  intro p hp
  have h : env50820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50819_50820 : H12AffineEnvironment.transform 11 292 env50819 = env50820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env50819 == env50820) = true)

theorem identity50820 : scanCanonicalize (H12AffineFastState.compose env50820 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound50820 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50821 : List Nat := [2,4,8,10,32,11,128,256,390,266,292,292,269,0,293,262,1,390,267,292,292,396,11,40,388,10,292,1,293,1,256,303,256,33,0,390]

theorem envBound50821 : H12AffineFastState.Bounded env50821 := by
  intro p hp
  have h : env50821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50820_50821 : H12AffineEnvironment.transform 8 390 env50820 = env50821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env50820 == env50821) = true)

def env50822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,17,69649,70887,78895,77841,1297,74814,81227,8204,74798,256,65830,1345,79470]

theorem envBound50822 : H12AffineFastState.Bounded env50822 := by
  intro p hp
  have h : env50822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50799_50822 : H12AffineEnvironment.transform 17 65665 env50799 = env50822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50799 == env50822) = true)

theorem identity50822 : scanCanonicalize (H12AffineFastState.compose env50822 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound50822 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,65536,1344,65665,73839,9245,0,477,17,65553,66791,74799,73745,1297,74814,77131,8204,74798,256,65830,1345,75374]

theorem envBound50823 : H12AffineFastState.Bounded env50823 := by
  intro p hp
  have h : env50823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50822_50823 : H12AffineEnvironment.transform 11 0 env50822 = env50823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50822 == env50823) = true)

def env50824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9244,65536,1296,65665,73791,9245,0,397,17,65553,66743,74799,73745,1297,74814,77083,8204,74798,256,65830,1297,75326]

theorem envBound50824 : H12AffineFastState.Bounded env50824 := by
  intro p hp
  have h : env50824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50823_50824 : H12AffineEnvironment.transform 5 16 env50823 = env50824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50823 == env50824) = true)

theorem identity50824 : scanCanonicalize (H12AffineFastState.compose env50824 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50824 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,269,1296,1297,65536,1296,65665,65842,1296,0,397,17,65553,66743,66850,65820,1297,66867,68630,257,66851,256,65830,1297,67379]

theorem envBound50825 : H12AffineFastState.Bounded env50825 := by
  intro p hp
  have h : env50825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50824_50825 : H12AffineEnvironment.transform 12 269 env50824 = env50825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50824 == env50825) = true)

def env50826 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9244,65536,1297,65665,73790,9245,0,396,17,65553,66742,74799,73745,1297,74814,77082,8204,74798,256,65830,1296,75327]

theorem envBound50826 : H12AffineFastState.Bounded env50826 := by
  intro p hp
  have h : env50826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50823_50826 : H12AffineEnvironment.transform 5 17 env50823 = env50826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50823 == env50826) = true)

theorem identity50826 : scanCanonicalize (H12AffineFastState.compose env50826 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound50826 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50827 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9244,1331,1297,1458,9485,9245,0,396,17,1314,389,8476,9506,1297,8461,10281,8204,8477,256,1045,1296,8972]

theorem envBound50827 : H12AffineFastState.Bounded env50827 := by
  intro p hp
  have h : env50827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50826_50827 : H12AffineEnvironment.transform 15 1331 env50826 = env50827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env50826 == env50827) = true)

theorem identity50827 : scanCanonicalize (H12AffineFastState.compose env50827 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound50827 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env50828 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,0,8192,1296,9244,1331,1297,1458,9485,9245,0,396,17,1314,389,8476,9506,1297,8461,10281,8204,8477,256,1045,1296,8580]

theorem envBound50828 : H12AffineFastState.Bounded env50828 := by
  intro p hp
  have h : env50828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50827_50828 : H12AffineEnvironment.transform 8 136 env50827 = env50828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env50827 == env50828) = true)

theorem identity50828 : scanCanonicalize (H12AffineFastState.compose env50828 (packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound50828 : packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env50829 : List Nat := [2,4,8,16,32,17,56,256,48,1024,2048,0,8192,1296,9244,1331,1297,1290,9485,9245,0,308,17,1314,317,8476,9506,1297,8461,10281,8204,8477,256,1045,1296,8508]

theorem envBound50829 : H12AffineFastState.Bounded env50829 := by
  intro p hp
  have h : env50829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50828_50829 : H12AffineEnvironment.transform 6 56 env50828 = env50829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env50828 == env50829) = true)

theorem identity50829 : scanCanonicalize (H12AffineFastState.compose env50829 (packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound50829 : packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50830 : List Nat := [2,4,8,16,32,17,56,256,48,1024,43,0,8192,1296,9244,1331,1297,1290,9485,9245,0,308,17,1314,317,8476,9506,1297,8461,8194,8204,8477,256,1045,1296,8508]

theorem envBound50830 : H12AffineFastState.Bounded env50830 := by
  intro p hp
  have h : env50830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50829_50830 : H12AffineEnvironment.transform 10 43 env50829 = env50830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env50829 == env50830) = true)

theorem identity50830 : scanCanonicalize (H12AffineFastState.compose env50830 (packedSelected [0,3,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound50830 : packedSelected [0,3,8,9,12] rootPS < 2^1333 := by decide +kernel

def env50831 : List Nat := [2,4,8,16,32,17,56,256,48,1024,43,0,51,1296,1071,1331,1297,1290,1342,1070,0,308,17,1314,317,303,1297,1297,318,49,63,302,256,1045,1296,271]

theorem envBound50831 : H12AffineFastState.Bounded env50831 := by
  intro p hp
  have h : env50831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50830_50831 : H12AffineEnvironment.transform 12 51 env50830 = env50831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env50830 == env50831) = true)

theorem identity50831 : scanCanonicalize (H12AffineFastState.compose env50831 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50831 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50832 : List Nat := [2,4,8,11,32,10,35,256,43,1024,43,0,40,1291,1071,1320,1290,1290,1317,1070,0,303,10,1314,294,303,1290,1290,293,42,36,302,256,1038,1291,271]

theorem envBound50832 : H12AffineFastState.Bounded env50832 := by
  intro p hp
  have h : env50832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50831_50832 : H12AffineEnvironment.transform 3 11 env50831 = env50832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50831 == env50832) = true)

theorem identity50832 : scanCanonicalize (H12AffineFastState.compose env50832 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound50832 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env50833 : List Nat := [2,4,8,11,32,10,35,256,43,46,43,0,40,293,1,262,292,292,267,0,0,303,10,268,294,303,292,292,293,42,36,302,256,32,293,271]

theorem envBound50833 : H12AffineFastState.Bounded env50833 := by
  intro p hp
  have h : env50833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50832_50833 : H12AffineEnvironment.transform 9 46 env50832 = env50833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env50832 == env50833) = true)

theorem identity50833 : scanCanonicalize (H12AffineFastState.compose env50833 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound50833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50834 : List Nat := [2,4,8,11,32,10,35,15,43,46,43,0,40,42,1,9,43,43,4,0,0,32,10,3,41,32,43,43,42,42,36,33,15,32,42,0]

theorem envBound50834 : H12AffineFastState.Bounded env50834 := by
  intro p hp
  have h : env50834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50833_50834 : H12AffineEnvironment.transform 7 15 env50833 = env50834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env50833 == env50834) = true)

theorem identity50834 : scanCanonicalize (H12AffineFastState.compose env50834 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50835 : List Nat := [2,2,8,11,32,10,35,9,43,40,43,0,40,42,1,9,43,43,2,0,0,32,10,3,41,32,43,43,42,42,34,33,9,32,42,0]

theorem envBound50835 : H12AffineFastState.Bounded env50835 := by
  intro p hp
  have h : env50835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50834_50835 : H12AffineEnvironment.transform 1 2 env50834 = env50835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50834 == env50835) = true)

theorem identity50835 : scanCanonicalize (H12AffineFastState.compose env50835 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50835 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50836 : List Nat := [2,2,8,11,10,10,9,9,1,2,1,0,2,0,1,9,1,1,2,0,0,10,10,3,3,10,1,1,0,0,8,11,9,10,0,0]

theorem envBound50836 : H12AffineFastState.Bounded env50836 := by
  intro p hp
  have h : env50836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50835_50836 : H12AffineEnvironment.transform 4 10 env50835 = env50836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50835 == env50836) = true)

theorem identity50836 : scanCanonicalize (H12AffineFastState.compose env50836 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound50836 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50837 : List Nat := [2,2,1,2,3,3,0,0,1,2,1,0,2,0,1,0,1,1,2,0,0,3,3,3,3,3,1,1,0,0,1,2,0,3,0,0]

theorem envBound50837 : H12AffineFastState.Bounded env50837 := by
  intro p hp
  have h : env50837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50836_50837 : H12AffineEnvironment.transform 2 1 env50836 = env50837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env50836 == env50837) = true)

theorem identity50837 : scanCanonicalize (H12AffineFastState.compose env50837 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50837 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50838 : List Nat := [0,0,1,0,1,1,0,0,1,0,1,0,0,0,1,0,1,1,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,0,0]

theorem envBound50838 : H12AffineFastState.Bounded env50838 := by
  intro p hp
  have h : env50838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50837_50838 : H12AffineEnvironment.transform 0 0 env50837 = env50838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50837 == env50838) = true)

def env50839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70886,78894,77841,1297,74814,81226,365712,74798,256,308666,1345,79471]

theorem envBound50839 : H12AffineFastState.Bounded env50839 := by
  intro p hp
  have h : env50839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50797_50839 : H12AffineEnvironment.transform 13 1297 env50797 = env50839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50797 == env50839) = true)

theorem identity50839 : scanCanonicalize (H12AffineFastState.compose env50839 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound50839 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,17,266385,38036,46172,45155,1297,42060,48440,267490,42076,256,308666,1345,46621]

theorem envBound50840 : H12AffineFastState.Bounded env50840 := by
  intro p hp
  have h : env50840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50839_50840 : H12AffineEnvironment.transform 15 32882 env50839 = env50840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env50839 == env50840) = true)

def env50841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263633,33236,41244,42275,1297,42060,43128,262562,42076,256,303354,1345,41821]

theorem envBound50841 : H12AffineFastState.Bounded env50841 := by
  intro p hp
  have h : env50841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50840_50841 : H12AffineEnvironment.transform 11 1344 env50840 = env50841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env50840 == env50841) = true)

theorem identity50841 : scanCanonicalize (H12AffineFastState.compose env50841 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound50841 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,277,359,1345,262144,9289,276,1344,8597,17,263633,193,8201,9270,1297,9561,10605,262562,9545,256,270831,1345,8776]

theorem envBound50842 : H12AffineFastState.Bounded env50842 := by
  intro p hp
  have h : env50842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50841_50842 : H12AffineEnvironment.transform 14 277 env50841 = env50842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env50841 == env50842) = true)

theorem identity50842 : scanCanonicalize (H12AffineFastState.compose env50842 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 9783) := by decide +kernel

theorem selectedBound50842 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env50843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,277,359,1345,9783,9289,276,1344,8597,17,9190,193,8201,9270,1297,9561,10605,10133,9545,256,2008,1345,8776]

theorem envBound50843 : H12AffineFastState.Bounded env50843 := by
  intro p hp
  have h : env50843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50842_50843 : H12AffineEnvironment.transform 17 9783 env50842 = env50843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9783 env50842 == env50843) = true)

def env50844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263632,33237,41245,42274,1297,42060,43129,262563,42076,256,303355,1345,41820]

theorem envBound50844 : H12AffineFastState.Bounded env50844 := by
  intro p hp
  have h : env50844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50840_50844 : H12AffineEnvironment.transform 11 1345 env50840 = env50844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env50840 == env50844) = true)

theorem identity50844 : scanCanonicalize (H12AffineFastState.compose env50844 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound50844 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,487,42333,32769,1345,41089,17,1079,33237,41245,42274,1297,42060,43129,68,42076,256,41244,1345,41820]

theorem envBound50845 : H12AffineFastState.Bounded env50845 := by
  intro p hp
  have h : env50845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50844_50845 : H12AffineEnvironment.transform 17 487 env50844 = env50845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env50844 == env50845) = true)

theorem identity50845 : scanCanonicalize (H12AffineFastState.compose env50845 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50845 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1345,487,1025,8541,1345,477,17,1079,8329,65,1150,1297,1296,2341,68,1280,256,64,1345,512]

theorem envBound50846 : H12AffineFastState.Bounded env50846 := by
  intro p hp
  have h : env50846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50845_50846 : H12AffineEnvironment.transform 14 8540 env50845 = env50846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50845 == env50846) = true)

theorem identity50846 : scanCanonicalize (H12AffineFastState.compose env50846 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50846 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50847 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,8192,1029,8264,8250,1109,243,1025,8265,1109,201,17,1079,8329,65,1150,1029,1028,2097,68,1044,20,64,1109,512]

theorem envBound50847 : H12AffineFastState.Bounded env50847 := by
  intro p hp
  have h : env50847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50846_50847 : H12AffineEnvironment.transform 7 20 env50846 = env50847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50846 == env50847) = true)

theorem identity50847 : scanCanonicalize (H12AffineFastState.compose env50847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound50847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50848 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,1684,1029,1756,1710,1109,243,1025,1757,1109,201,17,1079,1565,65,1150,1029,1028,2097,68,1044,20,64,1109,512]

theorem envBound50848 : H12AffineFastState.Bounded env50848 := by
  intro p hp
  have h : env50848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50847_50848 : H12AffineEnvironment.transform 12 1684 env50847 = env50848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env50847 == env50848) = true)

theorem identity50848 : scanCanonicalize (H12AffineFastState.compose env50848 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50848 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50849 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1028,1684,1029,1677,1710,1028,162,1025,1676,1028,152,17,1079,1565,16,1071,1029,1028,2097,21,1044,20,17,1028,512]

theorem envBound50849 : H12AffineFastState.Bounded env50849 := by
  intro p hp
  have h : env50849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50848_50849 : H12AffineEnvironment.transform 5 17 env50848 = env50849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50848 == env50849) = true)

theorem identity50849 : scanCanonicalize (H12AffineFastState.compose env50849 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound50849 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50850 : List Nat := [2,4,8,16,32,17,128,20,512,140,2048,136,536,137,513,546,136,162,141,512,136,152,17,187,657,16,163,137,136,2097,21,152,20,17,136,512]

theorem envBound50850 : H12AffineFastState.Bounded env50850 := by
  intro p hp
  have h : env50850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50849_50850 : H12AffineEnvironment.transform 9 140 env50849 = env50850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env50849 == env50850) = true)

def env50851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86519,94526,77840,1296,74814,96347,381313,74798,256,323755,1345,95102]

theorem envBound50851 : H12AffineFastState.Bounded env50851 := by
  intro p hp
  have h : env50851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50796_50851 : H12AffineEnvironment.transform 16 16465 env50796 = env50851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env50796 == env50851) = true)

def env50852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70887,78894,77840,1296,74814,81227,365713,74798,256,308667,1345,79470]

theorem envBound50852 : H12AffineFastState.Bounded env50852 := by
  intro p hp
  have h : env50852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50851_50852 : H12AffineEnvironment.transform 13 1296 env50851 = env50852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50851 == env50852) = true)

theorem identity50852 : scanCanonicalize (H12AffineFastState.compose env50852 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound50852 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,16,266384,38036,46173,45155,1296,42061,48440,267490,42077,256,308667,1345,46621]

theorem envBound50853 : H12AffineFastState.Bounded env50853 := by
  intro p hp
  have h : env50853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50852_50853 : H12AffineEnvironment.transform 15 32883 env50852 = env50853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env50852 == env50853) = true)

def env50854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263632,33236,41245,42275,1296,42061,43128,262562,42077,256,303355,1345,41821]

theorem envBound50854 : H12AffineFastState.Bounded env50854 := by
  intro p hp
  have h : env50854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50853_50854 : H12AffineEnvironment.transform 11 1344 env50853 = env50854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env50853 == env50854) = true)

theorem identity50854 : scanCanonicalize (H12AffineFastState.compose env50854 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound50854 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50855 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,32768,32883,0,262144,40989,32769,1,41089,16,262289,33236,41245,41058,81,41228,43128,262562,41244,256,303355,0,41821]

theorem envBound50855 : H12AffineFastState.Bounded env50855 := by
  intro p hp
  have h : env50855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50854_50855 : H12AffineEnvironment.transform 9 321 env50854 = env50855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50854 == env50855) = true)

theorem identity50855 : scanCanonicalize (H12AffineFastState.compose env50855 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50855 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50856 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8494,0,262144,320,8540,1,476,16,262289,8329,64,319,81,81,2341,262562,65,256,262566,0,512]

theorem envBound50856 : H12AffineFastState.Bounded env50856 := by
  intro p hp
  have h : env50856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50855_50856 : H12AffineEnvironment.transform 14 8541 env50855 = env50856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50855 == env50856) = true)

theorem identity50856 : scanCanonicalize (H12AffineFastState.compose env50856 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound50856 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50857 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8494,0,242,320,8540,1,476,16,99,8329,64,319,81,81,2341,336,65,256,340,0,512]

theorem envBound50857 : H12AffineFastState.Bounded env50857 := by
  intro p hp
  have h : env50857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50856_50857 : H12AffineEnvironment.transform 17 242 env50856 = env50857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env50856 == env50857) = true)

theorem identity50857 : scanCanonicalize (H12AffineFastState.compose env50857 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound50857 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50858 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,705,81,924,1007,0,242,320,925,1,476,16,99,584,64,319,81,81,2341,336,65,256,340,0,512]

theorem envBound50858 : H12AffineFastState.Bounded env50858 := by
  intro p hp
  have h : env50858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50857_50858 : H12AffineEnvironment.transform 12 705 env50857 = env50858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env50857 == env50858) = true)

theorem identity50858 : scanCanonicalize (H12AffineFastState.compose env50858 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50858 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50859 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,656,0,924,958,0,163,273,925,1,397,16,50,537,17,319,0,0,2341,257,16,256,261,0,512]

theorem envBound50859 : H12AffineFastState.Bounded env50859 := by
  intro p hp
  have h : env50859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50858_50859 : H12AffineEnvironment.transform 5 17 env50858 = env50859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50858 == env50859) = true)

theorem identity50859 : scanCanonicalize (H12AffineFastState.compose env50859 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound50859 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50860 : List Nat := [2,4,8,16,32,17,56,256,512,272,2048,1,552,0,804,774,0,27,273,805,1,309,16,50,537,17,319,0,0,2341,257,16,256,261,0,512]

theorem envBound50860 : H12AffineFastState.Bounded env50860 := by
  intro p hp
  have h : env50860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50859_50860 : H12AffineEnvironment.transform 6 56 env50859 = env50860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env50859 == env50860) = true)

theorem identity50860 : scanCanonicalize (H12AffineFastState.compose env50860 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound50860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50861 : List Nat := [2,4,8,16,32,17,56,256,512,272,293,1,552,0,804,774,0,27,273,805,1,309,16,50,537,17,319,0,0,0,257,16,256,261,0,512]

theorem envBound50861 : H12AffineFastState.Bounded env50861 := by
  intro p hp
  have h : env50861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50860_50861 : H12AffineEnvironment.transform 10 293 env50860 = env50861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env50860 == env50861) = true)

theorem identity50861 : scanCanonicalize (H12AffineFastState.compose env50861 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50861 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env50862 : List Nat := [2,4,8,16,10,17,18,256,512,272,271,1,514,0,782,774,0,27,273,783,1,287,16,24,537,17,277,0,0,0,257,16,256,261,0,512]

theorem envBound50862 : H12AffineFastState.Bounded env50862 := by
  intro p hp
  have h : env50862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50861_50862 : H12AffineEnvironment.transform 4 10 env50861 = env50862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50861 == env50862) = true)

theorem identity50862 : scanCanonicalize (H12AffineFastState.compose env50862 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50862 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50863 : List Nat := [2,4,8,16,10,17,18,256,0,272,271,1,2,0,270,262,0,27,273,271,1,287,16,24,25,17,277,0,0,0,257,16,256,261,0,0]

theorem envBound50863 : H12AffineFastState.Bounded env50863 := by
  intro p hp
  have h : env50863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50862_50863 : H12AffineEnvironment.transform 8 0 env50862 = env50863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50862 == env50863) = true)

theorem identity50863 : scanCanonicalize (H12AffineFastState.compose env50863 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50863 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50864 : List Nat := [2,4,8,16,10,17,18,20,0,4,27,1,2,0,26,18,0,27,5,27,1,11,16,24,25,17,1,0,0,0,21,16,20,17,0,0]

theorem envBound50864 : H12AffineFastState.Bounded env50864 := by
  intro p hp
  have h : env50864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50863_50864 : H12AffineEnvironment.transform 7 20 env50863 = env50864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50863 == env50864) = true)

theorem identity50864 : scanCanonicalize (H12AffineFastState.compose env50864 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50865 : List Nat := [2,4,8,6,10,7,4,2,0,4,13,1,2,0,12,4,0,13,5,13,1,11,6,14,15,7,1,0,0,0,3,6,2,7,0,0]

theorem envBound50865 : H12AffineFastState.Bounded env50865 := by
  intro p hp
  have h : env50865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50864_50865 : H12AffineEnvironment.transform 3 6 env50864 = env50865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50864 == env50865) = true)

theorem identity50865 : scanCanonicalize (H12AffineFastState.compose env50865 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50866 : List Nat := [2,4,4,6,6,7,4,2,0,4,1,1,2,0,0,4,0,1,5,1,1,7,6,2,3,7,1,0,0,0,3,6,2,7,0,0]

theorem envBound50866 : H12AffineFastState.Bounded env50866 := by
  intro p hp
  have h : env50866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50865_50866 : H12AffineEnvironment.transform 2 4 env50865 = env50866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50865 == env50866) = true)

def env50867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263633,33237,41244,42274,1296,42061,43129,262563,42077,256,303354,1345,41820]

theorem envBound50867 : H12AffineFastState.Bounded env50867 := by
  intro p hp
  have h : env50867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50853_50867 : H12AffineEnvironment.transform 11 1345 env50853 = env50867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env50853 == env50867) = true)

theorem identity50867 : scanCanonicalize (H12AffineFastState.compose env50867 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound50867 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,34226,42333,32769,1345,41088,16,32867,33237,41244,42274,1296,42061,43129,33809,42077,256,9544,1345,41820]

theorem envBound50868 : H12AffineFastState.Bounded env50868 := by
  intro p hp
  have h : env50868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50867_50868 : H12AffineEnvironment.transform 17 34226 env50867 = env50868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env50867 == env50868) = true)

theorem identity50868 : scanCanonicalize (H12AffineFastState.compose env50868 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound50868 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env50869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,657,1296,32768,32883,1345,34226,34764,32769,1345,33297,16,32867,33237,33677,34739,1296,34524,35560,33809,34508,256,2009,1345,33229]

theorem envBound50869 : H12AffineFastState.Bounded env50869 := by
  intro p hp
  have h : env50869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50868_50869 : H12AffineEnvironment.transform 12 657 env50868 = env50869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env50868 == env50869) = true)

def env50870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70886,78895,77840,1296,74814,81226,365712,74798,256,308666,1345,79471]

theorem envBound50870 : H12AffineFastState.Bounded env50870 := by
  intro p hp
  have h : env50870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50851_50870 : H12AffineEnvironment.transform 13 1297 env50851 = env50870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50851 == env50870) = true)

theorem identity50870 : scanCanonicalize (H12AffineFastState.compose env50870 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50870 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,16,266385,70886,78895,77840,1296,74814,81226,336012,74798,256,262566,1345,79471]

theorem envBound50871 : H12AffineFastState.Bounded env50871 := by
  intro p hp
  have h : env50871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50870_50871 : H12AffineEnvironment.transform 14 13340 env50870 = env50871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50870 == env50871) = true)

def env50872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,16,69649,70886,78895,77840,1296,74814,81226,8204,74798,256,65830,1345,79471]

theorem envBound50872 : H12AffineFastState.Bounded env50872 := by
  intro p hp
  have h : env50872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50871_50872 : H12AffineEnvironment.transform 17 65664 env50871 = env50872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50871 == env50872) = true)

theorem identity50872 : scanCanonicalize (H12AffineFastState.compose env50872 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound50872 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,65536,1344,65664,66919,276,4096,476,16,69649,70886,65830,66841,1296,69943,67651,5381,69927,256,65830,1345,66406]

theorem envBound50873 : H12AffineFastState.Bounded env50873 := by
  intro p hp
  have h : env50873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50872_50873 : H12AffineEnvironment.transform 12 5385 env50872 = env50873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env50872 == env50873) = true)

def env50874 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,65536,1296,65664,66871,276,4096,396,16,69649,70838,65830,66841,1296,69943,67603,5381,69927,256,65830,1297,66358]

theorem envBound50874 : H12AffineFastState.Bounded env50874 := by
  intro p hp
  have h : env50874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50873_50874 : H12AffineEnvironment.transform 5 16 env50873 = env50874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50873 == env50874) = true)

theorem identity50874 : scanCanonicalize (H12AffineFastState.compose env50874 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound50874 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50875 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,5426,1296,5554,4101,276,4096,396,16,1315,388,5140,4139,1296,1029,7457,5381,1045,256,5140,1297,5636]

theorem envBound50875 : H12AffineFastState.Bounded env50875 := by
  intro p hp
  have h : env50875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50874_50875 : H12AffineEnvironment.transform 15 5426 env50874 = env50875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env50874 == env50875) = true)

def env50876 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65664,66870,276,4096,397,16,69649,70839,65830,66841,1296,69943,67602,5381,69927,256,65830,1296,66359]

theorem envBound50876 : H12AffineFastState.Bounded env50876 := by
  intro p hp
  have h : env50876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50873_50876 : H12AffineEnvironment.transform 5 17 env50873 = env50876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50873 == env50876) = true)

theorem identity50876 : scanCanonicalize (H12AffineFastState.compose env50876 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound50876 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50877 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,268,1297,277,65536,1297,65664,66870,276,1029,397,16,66580,65714,65830,66841,1296,66866,67602,256,66850,256,65830,1296,66359]

theorem envBound50877 : H12AffineFastState.Bounded env50877 := by
  intro p hp
  have h : env50877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50876_50877 : H12AffineEnvironment.transform 11 1029 env50876 = env50877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env50876 == env50877) = true)

theorem identity50877 : scanCanonicalize (H12AffineFastState.compose env50877 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 958) := by decide +kernel

theorem selectedBound50877 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env50878 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,268,1297,277,958,1297,830,1672,276,1029,397,16,1962,780,664,1703,1296,1676,2988,256,1692,256,664,1296,137]

theorem envBound50878 : H12AffineFastState.Bounded env50878 := by
  intro p hp
  have h : env50878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50877_50878 : H12AffineEnvironment.transform 15 958 env50877 = env50878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 958 env50877 == env50878) = true)

theorem identity50878 : scanCanonicalize (H12AffineFastState.compose env50878 (packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound50878 : packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env50879 : List Nat := [2,4,8,16,32,17,128,256,512,564,2048,561,268,805,277,958,805,830,188,276,561,397,16,414,780,664,147,804,184,2988,256,168,256,664,804,137]

theorem envBound50879 : H12AffineFastState.Bounded env50879 := by
  intro p hp
  have h : env50879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50878_50879 : H12AffineEnvironment.transform 9 564 env50878 = env50879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env50878 == env50879) = true)

theorem identity50879 : scanCanonicalize (H12AffineFastState.compose env50879 (packedSelected [0,1,2,4,7,8,9,11,17,18,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound50879 : packedSelected [0,1,2,4,7,8,9,11,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env50880 : List Nat := [2,4,8,16,32,17,128,256,512,564,318,561,268,805,277,958,805,830,188,276,561,397,16,414,780,664,147,804,184,658,256,168,256,664,804,137]

theorem envBound50880 : H12AffineFastState.Bounded env50880 := by
  intro p hp
  have h : env50880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50879_50880 : H12AffineEnvironment.transform 10 318 env50879 = env50880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env50879 == env50880) = true)

theorem identity50880 : scanCanonicalize (H12AffineFastState.compose env50880 (packedSelected [1,3,5,7,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50880 : packedSelected [1,3,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50881 : List Nat := [2,4,8,16,32,17,8,256,512,564,318,561,268,805,277,822,805,830,52,276,561,261,16,278,780,528,27,804,48,538,256,32,256,528,804,1]

theorem envBound50881 : H12AffineFastState.Bounded env50881 := by
  intro p hp
  have h : env50881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50880_50881 : H12AffineEnvironment.transform 6 8 env50880 = env50881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50880 == env50881) = true)

theorem identity50881 : scanCanonicalize (H12AffineFastState.compose env50881 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50881 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env50882 : List Nat := [2,4,8,11,32,10,8,256,512,559,293,554,268,805,270,813,805,805,47,271,554,261,11,269,780,523,0,804,43,513,256,32,256,523,804,1]

theorem envBound50882 : H12AffineFastState.Bounded env50882 := by
  intro p hp
  have h : env50882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50881_50882 : H12AffineEnvironment.transform 3 11 env50881 = env50882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50881 == env50882) = true)

theorem identity50882 : scanCanonicalize (H12AffineFastState.compose env50882 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound50882 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50883 : List Nat := [2,4,8,11,32,10,8,256,293,266,293,271,268,0,270,8,0,0,47,271,271,261,11,269,41,302,0,1,43,292,256,32,256,302,1,1]

theorem envBound50883 : H12AffineFastState.Bounded env50883 := by
  intro p hp
  have h : env50883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50882_50883 : H12AffineEnvironment.transform 8 293 env50882 = env50883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env50882 == env50883) = true)

theorem identity50883 : scanCanonicalize (H12AffineFastState.compose env50883 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound50883 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50884 : List Nat := [2,4,8,11,32,10,8,15,42,5,42,0,3,0,1,8,0,0,47,0,0,10,11,2,41,33,0,1,43,43,15,32,15,33,1,1]

theorem envBound50884 : H12AffineFastState.Bounded env50884 := by
  intro p hp
  have h : env50884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50883_50884 : H12AffineEnvironment.transform 7 15 env50883 = env50884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env50883 == env50884) = true)

theorem identity50884 : scanCanonicalize (H12AffineFastState.compose env50884 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50885 : List Nat := [2,2,8,11,32,10,8,9,42,3,42,0,3,0,1,8,0,0,41,0,0,10,11,2,41,33,0,1,43,43,9,32,9,33,1,1]

theorem envBound50885 : H12AffineFastState.Bounded env50885 := by
  intro p hp
  have h : env50885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50884_50885 : H12AffineEnvironment.transform 1 2 env50884 = env50885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50884 == env50885) = true)

def env50886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,16,69648,70886,78895,77840,1296,74814,81226,8205,74798,256,65831,1345,79471]

theorem envBound50886 : H12AffineFastState.Bounded env50886 := by
  intro p hp
  have h : env50886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50871_50886 : H12AffineEnvironment.transform 17 65665 env50871 = env50886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50871 == env50886) = true)

theorem identity50886 : scanCanonicalize (H12AffineFastState.compose env50886 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound50886 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,65536,1344,65665,69670,5205,4096,476,16,69648,70886,70759,69720,1296,66678,72962,69,66662,256,65831,1345,71207]

theorem envBound50887 : H12AffineFastState.Bounded env50887 := by
  intro p hp
  have h : env50887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50886_50887 : H12AffineEnvironment.transform 12 72 env50886 = env50887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env50886 == env50887) = true)

def env50888 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,65536,1296,65665,69670,5125,4096,396,16,69648,70838,70711,69640,1296,66598,72962,21,66614,256,65831,1297,71207]

theorem envBound50888 : H12AffineFastState.Bounded env50888 := by
  intro p hp
  have h : env50888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50887_50888 : H12AffineEnvironment.transform 5 16 env50887 = env50888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50887 == env50888) = true)

theorem identity50888 : scanCanonicalize (H12AffineFastState.compose env50888 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound50888 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50889 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,5427,1296,5554,1301,5125,4096,396,16,1315,389,260,1339,1296,4373,2097,21,4357,256,5140,1297,788]

theorem envBound50889 : H12AffineFastState.Bounded env50889 := by
  intro p hp
  have h : env50889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50888_50889 : H12AffineEnvironment.transform 15 5427 env50888 = env50889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env50888 == env50889) = true)

theorem identity50889 : scanCanonicalize (H12AffineFastState.compose env50889 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50889 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50890 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,24,1028,5124,5158,1029,5287,1024,5125,4096,153,16,1078,144,17,1070,1029,4096,2097,21,4112,21,5140,1028,513]

theorem envBound50890 : H12AffineFastState.Bounded env50890 := by
  intro p hp
  have h : env50890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50889_50890 : H12AffineEnvironment.transform 7 21 env50889 = env50890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50889 == env50890) = true)

theorem identity50890 : scanCanonicalize (H12AffineFastState.compose env50890 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2722) := by decide +kernel

theorem selectedBound50890 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50891 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,2722,24,1028,3750,3716,1029,3589,1024,3751,2722,153,16,1078,144,17,1070,1029,2722,2097,21,2738,21,3766,1028,513]

theorem envBound50891 : H12AffineFastState.Bounded env50891 := by
  intro p hp
  have h : env50891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50890_50891 : H12AffineEnvironment.transform 11 2722 env50890 = env50891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2722 env50890 == env50891) = true)

theorem identity50891 : scanCanonicalize (H12AffineFastState.compose env50891 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50891 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50892 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,2722,24,0,2722,2688,1,2561,4,2723,2722,153,16,50,144,17,42,1,2722,2097,21,2738,21,2738,0,513]

theorem envBound50892 : H12AffineFastState.Bounded env50892 := by
  intro p hp
  have h : env50892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50891_50892 : H12AffineEnvironment.transform 9 4 env50891 = env50892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50891 == env50892) = true)

theorem identity50892 : scanCanonicalize (H12AffineFastState.compose env50892 (packedSelected [1,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 693) := by decide +kernel

theorem selectedBound50892 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env50893 : List Nat := [2,4,8,16,32,16,128,21,512,4,693,23,24,0,23,53,1,180,4,22,23,153,16,50,144,17,42,1,23,644,21,7,21,7,0,513]

theorem envBound50893 : H12AffineFastState.Bounded env50893 := by
  intro p hp
  have h : env50893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50892_50893 : H12AffineEnvironment.transform 10 693 env50892 = env50893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 693 env50892 == env50893) = true)

theorem identity50893 : scanCanonicalize (H12AffineFastState.compose env50893 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50893 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50894 : List Nat := [2,4,8,1,32,1,128,4,512,4,676,6,9,0,6,36,1,165,4,7,6,136,1,35,129,0,42,1,6,644,4,7,4,7,0,513]

theorem envBound50894 : H12AffineFastState.Bounded env50894 := by
  intro p hp
  have h : env50894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50893_50894 : H12AffineEnvironment.transform 3 1 env50893 = env50894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50893 == env50894) = true)

def env50895 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,65536,1297,65665,69670,5124,4096,397,16,69648,70839,70710,69641,1296,66599,72962,20,66615,256,65831,1296,71207]

theorem envBound50895 : H12AffineFastState.Bounded env50895 := by
  intro p hp
  have h : env50895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50887_50895 : H12AffineEnvironment.transform 5 17 env50887 = env50895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50887 == env50895) = true)

theorem identity50895 : scanCanonicalize (H12AffineFastState.compose env50895 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50895 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50896 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1029,5125,65536,1029,65665,69670,5124,4096,153,16,69648,70839,70710,69641,1028,66599,72726,20,66615,20,65587,1028,71207]

theorem envBound50896 : H12AffineFastState.Bounded env50896 := by
  intro p hp
  have h : env50896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50895_50896 : H12AffineEnvironment.transform 7 20 env50895 = env50896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50895 == env50896) = true)

theorem identity50896 : scanCanonicalize (H12AffineFastState.compose env50896 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound50896 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env50897 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1029,5125,5159,1029,5286,1025,5124,4096,153,16,1079,144,17,1070,1028,4096,2097,20,4112,20,5140,1028,512]

theorem envBound50897 : H12AffineFastState.Bounded env50897 := by
  intro p hp
  have h : env50897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50896_50897 : H12AffineEnvironment.transform 15 5159 env50896 = env50897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env50896 == env50897) = true)

theorem identity50897 : scanCanonicalize (H12AffineFastState.compose env50897 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2696) := by decide +kernel

theorem selectedBound50897 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50898 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,2696,25,1029,3725,3759,1029,3630,1025,3724,2696,153,16,1079,144,17,1070,1028,2696,2097,20,2712,20,3740,1028,512]

theorem envBound50898 : H12AffineFastState.Bounded env50898 := by
  intro p hp
  have h : env50898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50897_50898 : H12AffineEnvironment.transform 11 2696 env50897 = env50898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2696 env50897 == env50898) = true)

theorem identity50898 : scanCanonicalize (H12AffineFastState.compose env50898 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound50898 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env50899 : List Nat := [2,4,8,16,32,17,128,20,26,1024,2048,2194,25,1029,3223,3253,1029,3124,1025,3222,2194,153,16,1079,144,17,1070,1028,2194,2097,20,2178,20,3206,1028,26]

theorem envBound50899 : H12AffineFastState.Bounded env50899 := by
  intro p hp
  have h : env50899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50898_50899 : H12AffineEnvironment.transform 8 26 env50898 = env50899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env50898 == env50899) = true)

theorem identity50899 : scanCanonicalize (H12AffineFastState.compose env50899 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50899 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env50900 : List Nat := [2,4,8,16,32,17,9,20,26,1024,2048,2075,25,1029,3102,3132,1029,3124,1025,3103,2075,16,16,1079,25,17,1070,1028,2075,2097,20,2059,20,3087,1028,26]

theorem envBound50900 : H12AffineFastState.Bounded env50900 := by
  intro p hp
  have h : env50900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50899_50900 : H12AffineEnvironment.transform 6 9 env50899 = env50900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50899 == env50900) = true)

def env50901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86519,209263,225344,148801,74814,96347,381312,74798,256,323754,1345,95102]

theorem envBound50901 : H12AffineFastState.Bounded env50901 := by
  intro p hp
  have h : env50901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50795_50901 : H12AffineEnvironment.transform 23 284033 env50795 = env50901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env50795 == env50901) = true)

def env50902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86519,94527,77840,1297,74814,96347,381312,74798,256,323754,1345,95102]

theorem envBound50902 : H12AffineFastState.Bounded env50902 := by
  intro p hp
  have h : env50902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50901_50902 : H12AffineEnvironment.transform 16 16464 env50901 = env50902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env50901 == env50902) = true)

def env50903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70887,78895,77840,1297,74814,81227,365712,74798,256,308666,1345,79470]

theorem envBound50903 : H12AffineFastState.Bounded env50903 := by
  intro p hp
  have h : env50903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50902_50903 : H12AffineEnvironment.transform 13 1296 env50902 = env50903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50902 == env50903) = true)

theorem identity50903 : scanCanonicalize (H12AffineFastState.compose env50903 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50903 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,17,266385,70887,78895,77840,1297,74814,81227,336012,74798,256,262566,1345,79470]

theorem envBound50904 : H12AffineFastState.Bounded env50904 := by
  intro p hp
  have h : env50904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50903_50904 : H12AffineEnvironment.transform 14 13340 env50903 = env50904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50903 == env50904) = true)

def env50905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,17,69649,70887,78895,77840,1297,74814,81227,8204,74798,256,65830,1345,79470]

theorem envBound50905 : H12AffineFastState.Bounded env50905 := by
  intro p hp
  have h : env50905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50904_50905 : H12AffineEnvironment.transform 17 65664 env50904 = env50905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50904 == env50905) = true)

theorem identity50905 : scanCanonicalize (H12AffineFastState.compose env50905 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound50905 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9327,1344,9455,5120,13341,4096,477,17,13438,12424,4160,5247,1297,81,6436,8204,65,256,9545,1345,4609]

theorem envBound50906 : H12AffineFastState.Bounded env50906 := by
  intro p hp
  have h : env50906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50905_50906 : H12AffineEnvironment.transform 15 9327 env50905 = env50906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env50905 == env50906) = true)

def env50907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9327,1344,9455,1024,9245,0,477,17,9342,8328,64,1151,1297,81,2340,8204,65,256,9545,1345,513]

theorem envBound50907 : H12AffineFastState.Bounded env50907 := by
  intro p hp
  have h : env50907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50906_50907 : H12AffineEnvironment.transform 11 0 env50906 = env50907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50906 == env50907) = true)

theorem identity50907 : scanCanonicalize (H12AffineFastState.compose env50907 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50907 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,269,1296,1297,1378,1344,1506,1024,1296,0,477,17,1395,389,64,1151,1297,81,2340,257,65,256,1092,1345,513]

theorem envBound50908 : H12AffineFastState.Bounded env50908 := by
  intro p hp
  have h : env50908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50907_50908 : H12AffineEnvironment.transform 12 269 env50907 = env50908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50907 == env50908) = true)

theorem identity50908 : scanCanonicalize (H12AffineFastState.compose env50908 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound50908 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50909 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,0,269,324,325,310,276,438,84,324,0,477,17,295,389,64,43,325,81,2340,257,65,256,16,277,513]

theorem envBound50909 : H12AffineFastState.Bounded env50909 := by
  intro p hp
  have h : env50909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50908_50909 : H12AffineEnvironment.transform 9 84 env50908 = env50909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env50908 == env50909) = true)

theorem identity50909 : scanCanonicalize (H12AffineFastState.compose env50909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50910 : List Nat := [2,4,8,16,32,64,128,5,512,84,2048,0,8,65,64,51,17,179,84,65,0,216,17,34,128,64,43,64,81,2081,4,65,5,16,16,513]

theorem envBound50910 : H12AffineFastState.Bounded env50910 := by
  intro p hp
  have h : env50910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50909_50910 : H12AffineEnvironment.transform 7 5 env50909 = env50910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50909 == env50910) = true)

theorem identity50910 : scanCanonicalize (H12AffineFastState.compose env50910 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound50910 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env50911 : List Nat := [2,4,8,16,32,64,128,5,137,84,2048,0,8,65,64,51,17,179,84,65,0,216,17,34,128,64,43,64,81,2081,4,65,5,16,16,136]

theorem envBound50911 : H12AffineFastState.Bounded env50911 := by
  intro p hp
  have h : env50911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50910_50911 : H12AffineEnvironment.transform 8 137 env50910 = env50911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env50910 == env50911) = true)

theorem identity50911 : scanCanonicalize (H12AffineFastState.compose env50911 (packedSelected [5,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound50911 : packedSelected [5,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50912 : List Nat := [2,4,8,16,32,64,63,5,54,84,2048,0,8,65,64,51,17,12,84,65,0,103,17,34,63,64,43,64,81,2081,4,65,5,16,16,55]

theorem envBound50912 : H12AffineFastState.Bounded env50912 := by
  intro p hp
  have h : env50912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50911_50912 : H12AffineEnvironment.transform 6 63 env50911 = env50912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env50911 == env50912) = true)

theorem identity50912 : scanCanonicalize (H12AffineFastState.compose env50912 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50912 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50913 : List Nat := [2,4,8,16,32,17,63,5,54,5,2048,0,8,16,17,51,17,12,5,16,0,54,17,34,63,17,43,17,0,2081,4,16,5,16,16,55]

theorem envBound50913 : H12AffineFastState.Bounded env50913 := by
  intro p hp
  have h : env50913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50912_50913 : H12AffineEnvironment.transform 5 17 env50912 = env50913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50912 == env50913) = true)

theorem identity50913 : scanCanonicalize (H12AffineFastState.compose env50913 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound50913 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env50914 : List Nat := [2,4,8,16,32,17,63,5,54,5,44,0,8,16,17,51,17,12,5,16,0,54,17,34,63,17,43,17,0,13,4,16,5,16,16,55]

theorem envBound50914 : H12AffineFastState.Bounded env50914 := by
  intro p hp
  have h : env50914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50913_50914 : H12AffineEnvironment.transform 10 44 env50913 = env50914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env50913 == env50914) = true)

theorem identity50914 : scanCanonicalize (H12AffineFastState.compose env50914 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50914 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50915 : List Nat := [2,4,8,0,32,1,47,5,38,5,44,0,8,0,1,35,1,12,5,0,0,38,1,34,47,1,43,1,0,13,4,0,5,0,0,39]

theorem envBound50915 : H12AffineFastState.Bounded env50915 := by
  intro p hp
  have h : env50915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50914_50915 : H12AffineEnvironment.transform 3 0 env50914 = env50915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50914 == env50915) = true)

theorem identity50915 : scanCanonicalize (H12AffineFastState.compose env50915 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50916 : List Nat := [2,4,8,0,10,1,5,5,12,5,6,0,8,0,1,9,1,12,5,0,0,12,1,8,5,1,1,1,0,13,4,0,5,0,0,13]

theorem envBound50916 : H12AffineFastState.Bounded env50916 := by
  intro p hp
  have h : env50916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50915_50916 : H12AffineEnvironment.transform 4 10 env50915 = env50916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50915 == env50916) = true)

theorem identity50916 : scanCanonicalize (H12AffineFastState.compose env50916 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50917 : List Nat := [2,3,8,0,10,1,2,2,11,2,1,0,8,0,1,9,1,11,2,0,0,11,1,8,2,1,1,1,0,10,3,0,2,0,0,10]

theorem envBound50917 : H12AffineFastState.Bounded env50917 := by
  intro p hp
  have h : env50917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50916_50917 : H12AffineEnvironment.transform 1 3 env50916 = env50917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50916 == env50917) = true)

theorem identity50917 : scanCanonicalize (H12AffineFastState.compose env50917 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50918 : List Nat := [1,0,8,0,9,1,1,1,8,1,1,0,8,0,1,9,1,8,1,0,0,8,1,8,1,1,1,1,0,9,0,0,1,0,0,9]

theorem envBound50918 : H12AffineFastState.Bounded env50918 := by
  intro p hp
  have h : env50918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50917_50918 : H12AffineEnvironment.transform 0 1 env50917 = env50918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50917 == env50918) = true)

theorem identity50918 : scanCanonicalize (H12AffineFastState.compose env50918 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50918 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50919 : List Nat := [1,0,0,0,1,1,1,1,0,1,1,0,0,0,1,1,1,0,1,0,0,0,1,0,1,1,1,1,0,1,0,0,1,0,0,1]

theorem envBound50919 : H12AffineFastState.Bounded env50919 := by
  intro p hp
  have h : env50919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50918_50919 : H12AffineEnvironment.transform 2 0 env50918 = env50919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50918 == env50919) = true)

def env50920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9327,1344,9455,1025,9244,1,477,17,9343,8329,65,1150,1297,81,2341,8204,65,256,9545,1345,512]

theorem envBound50920 : H12AffineFastState.Bounded env50920 := by
  intro p hp
  have h : env50920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50906_50920 : H12AffineEnvironment.transform 11 1 env50906 = env50920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50906 == env50920) = true)

theorem identity50920 : scanCanonicalize (H12AffineFastState.compose env50920 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50920 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,349,1296,1344,1330,1344,1458,1025,1345,1,477,17,1314,468,65,1150,1297,81,2341,337,65,256,1044,1345,512]

theorem envBound50921 : H12AffineFastState.Bounded env50921 := by
  intro p hp
  have h : env50921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50920_50921 : H12AffineEnvironment.transform 12 349 env50920 = env50921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50920 == env50921) = true)

theorem identity50921 : scanCanonicalize (H12AffineFastState.compose env50921 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50921 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50922 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,268,1296,1297,1330,1297,1458,1025,1296,1,396,17,1314,389,16,1071,1297,0,2341,256,16,256,1044,1296,512]

theorem envBound50922 : H12AffineFastState.Bounded env50922 := by
  intro p hp
  have h : env50922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50921_50922 : H12AffineEnvironment.transform 5 17 env50921 = env50922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50921 == env50922) = true)

theorem identity50922 : scanCanonicalize (H12AffineFastState.compose env50922 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound50922 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50923 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1,268,1296,1297,1330,1297,1458,1025,1296,1,396,17,1314,389,16,1071,1297,0,805,256,16,256,1044,1296,512]

theorem envBound50923 : H12AffineFastState.Bounded env50923 := by
  intro p hp
  have h : env50923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50922_50923 : H12AffineEnvironment.transform 10 512 env50922 = env50923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env50922 == env50923) = true)

theorem identity50923 : scanCanonicalize (H12AffineFastState.compose env50923 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound50923 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50924 : List Nat := [2,4,8,16,32,17,128,256,512,564,512,1,268,804,805,774,805,902,565,804,1,396,17,790,389,16,539,805,0,805,256,16,256,544,804,512]

theorem envBound50924 : H12AffineFastState.Bounded env50924 := by
  intro p hp
  have h : env50924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50923_50924 : H12AffineEnvironment.transform 9 564 env50923 = env50924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env50923 == env50924) = true)

theorem identity50924 : scanCanonicalize (H12AffineFastState.compose env50924 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50924 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50925 : List Nat := [2,4,8,16,32,17,9,256,512,564,512,1,268,804,805,774,805,783,565,804,1,261,17,790,268,16,539,805,0,805,256,16,256,544,804,512]

theorem envBound50925 : H12AffineFastState.Bounded env50925 := by
  intro p hp
  have h : env50925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50924_50925 : H12AffineEnvironment.transform 6 9 env50924 = env50925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50924 == env50925) = true)

theorem identity50925 : scanCanonicalize (H12AffineFastState.compose env50925 (packedSelected [0,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound50925 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env50926 : List Nat := [2,4,8,16,32,17,9,256,277,289,277,1,268,49,48,19,48,26,288,49,1,261,17,3,268,16,270,48,0,48,256,16,256,309,49,277]

theorem envBound50926 : H12AffineFastState.Bounded env50926 := by
  intro p hp
  have h : env50926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50925_50926 : H12AffineEnvironment.transform 8 277 env50925 = env50926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50925 == env50926) = true)

theorem identity50926 : scanCanonicalize (H12AffineFastState.compose env50926 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound50926 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env50927 : List Nat := [2,4,8,16,32,17,9,15,26,46,26,1,3,49,48,19,48,26,47,49,1,10,17,3,3,16,1,48,0,48,15,16,15,58,49,26]

theorem envBound50927 : H12AffineFastState.Bounded env50927 := by
  intro p hp
  have h : env50927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50926_50927 : H12AffineEnvironment.transform 7 15 env50926 = env50927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env50926 == env50927) = true)

theorem identity50927 : scanCanonicalize (H12AffineFastState.compose env50927 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50927 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env50928 : List Nat := [2,4,8,16,11,17,9,15,26,5,26,1,3,26,27,19,27,26,4,26,1,10,17,3,3,16,1,27,0,27,15,16,15,17,26,26]

theorem envBound50928 : H12AffineFastState.Bounded env50928 := by
  intro p hp
  have h : env50928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50927_50928 : H12AffineEnvironment.transform 4 11 env50927 = env50928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50927 == env50928) = true)

theorem identity50928 : scanCanonicalize (H12AffineFastState.compose env50928 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound50928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50929 : List Nat := [2,4,8,13,11,12,9,15,7,5,7,1,3,7,6,14,6,7,4,7,1,10,12,3,3,13,1,6,0,6,15,13,15,12,7,7]

theorem envBound50929 : H12AffineFastState.Bounded env50929 := by
  intro p hp
  have h : env50929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50928_50929 : H12AffineEnvironment.transform 3 13 env50928 = env50929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env50928 == env50929) = true)

def env50930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,17,69648,70887,78895,77840,1297,74814,81227,8205,74798,256,65831,1345,79470]

theorem envBound50930 : H12AffineFastState.Bounded env50930 := by
  intro p hp
  have h : env50930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50904_50930 : H12AffineEnvironment.transform 17 65665 env50904 = env50930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50904 == env50930) = true)

theorem identity50930 : scanCanonicalize (H12AffineFastState.compose env50930 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound50930 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12590,1344,12719,321,13341,4096,477,17,8510,9673,1281,318,1297,5392,3173,8205,5376,256,12297,1345,1856]

theorem envBound50931 : H12AffineFastState.Bounded env50931 := by
  intro p hp
  have h : env50931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50930_50931 : H12AffineEnvironment.transform 15 12590 env50930 = env50931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env50930 == env50931) = true)

def env50932 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12590,0,12719,321,12637,4096,477,17,8510,8329,65,318,81,4176,2341,8205,4160,256,12297,1,512]

theorem envBound50932 : H12AffineFastState.Bounded env50932 := by
  intro p hp
  have h : env50932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50931_50932 : H12AffineEnvironment.transform 9 320 env50931 = env50932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50931 == env50932) = true)

theorem identity50932 : scanCanonicalize (H12AffineFastState.compose env50932 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50932 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50933 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,348,80,4096,4210,0,4339,321,4097,4096,477,17,98,469,65,318,81,4176,2341,337,4160,256,4437,1,512]

theorem envBound50933 : H12AffineFastState.Bounded env50933 := by
  intro p hp
  have h : env50933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50932_50933 : H12AffineEnvironment.transform 12 348 env50932 = env50933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50932 == env50933) = true)

theorem identity50933 : scanCanonicalize (H12AffineFastState.compose env50933 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50933 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50934 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,269,1,4096,4131,0,4258,272,4097,4096,396,17,51,388,16,318,0,4097,2341,256,4113,256,4356,1,512]

theorem envBound50934 : H12AffineFastState.Bounded env50934 := by
  intro p hp
  have h : env50934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50933_50934 : H12AffineEnvironment.transform 5 17 env50933 = env50934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50933 == env50934) = true)

theorem identity50934 : scanCanonicalize (H12AffineFastState.compose env50934 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound50934 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50935 : List Nat := [2,4,8,16,32,17,128,256,512,273,696,4096,269,1,4096,4131,0,4258,272,4097,4096,396,17,51,388,16,318,0,4097,925,256,4113,256,4356,1,512]

theorem envBound50935 : H12AffineFastState.Bounded env50935 := by
  intro p hp
  have h : env50935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50934_50935 : H12AffineEnvironment.transform 10 696 env50934 = env50935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env50934 == env50935) = true)

theorem identity50935 : scanCanonicalize (H12AffineFastState.compose env50935 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound50935 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env50936 : List Nat := [2,4,8,16,32,17,128,256,512,273,696,27,269,1,27,56,0,185,272,26,27,396,17,51,388,16,318,0,26,925,256,10,256,287,1,512]

theorem envBound50936 : H12AffineFastState.Bounded env50936 := by
  intro p hp
  have h : env50936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50935_50936 : H12AffineEnvironment.transform 11 27 env50935 = env50936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env50935 == env50936) = true)

theorem identity50936 : scanCanonicalize (H12AffineFastState.compose env50936 (packedSelected [1,3,5,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound50936 : packedSelected [1,3,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50937 : List Nat := [2,4,8,16,32,17,128,256,438,273,270,27,269,1,27,56,0,185,272,26,27,396,17,51,388,16,318,0,26,43,256,10,256,287,1,438]

theorem envBound50937 : H12AffineFastState.Bounded env50937 := by
  intro p hp
  have h : env50937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50936_50937 : H12AffineEnvironment.transform 8 438 env50936 = env50937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env50936 == env50937) = true)

theorem identity50937 : scanCanonicalize (H12AffineFastState.compose env50937 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50937 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env50938 : List Nat := [2,4,8,16,17,17,128,256,391,273,270,27,269,1,27,9,0,136,272,26,27,396,17,2,388,16,271,0,26,26,256,10,256,287,1,391]

theorem envBound50938 : H12AffineFastState.Bounded env50938 := by
  intro p hp
  have h : env50938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50937_50938 : H12AffineEnvironment.transform 4 17 env50937 = env50938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50937 == env50938) = true)

theorem identity50938 : scanCanonicalize (H12AffineFastState.compose env50938 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound50938 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50939 : List Nat := [2,4,8,16,17,17,18,256,277,273,270,27,269,1,27,9,0,26,272,26,27,286,17,2,278,16,271,0,26,26,256,10,256,287,1,277]

theorem envBound50939 : H12AffineFastState.Bounded env50939 := by
  intro p hp
  have h : env50939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50938_50939 : H12AffineEnvironment.transform 6 18 env50938 = env50939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env50938 == env50939) = true)

theorem identity50939 : scanCanonicalize (H12AffineFastState.compose env50939 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50939 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50940 : List Nat := [2,4,8,11,10,10,9,256,270,266,270,0,269,1,0,9,0,1,267,1,0,261,10,2,269,11,271,0,1,1,256,10,256,260,1,270]

theorem envBound50940 : H12AffineFastState.Bounded env50940 := by
  intro p hp
  have h : env50940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50939_50940 : H12AffineEnvironment.transform 3 11 env50939 = env50940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50939 == env50940) = true)

theorem identity50940 : scanCanonicalize (H12AffineFastState.compose env50940 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound50940 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50941 : List Nat := [2,4,8,11,10,10,9,14,0,4,0,0,3,1,0,9,0,1,5,1,0,11,10,2,3,11,1,0,1,1,14,10,14,10,1,0]

theorem envBound50941 : H12AffineFastState.Bounded env50941 := by
  intro p hp
  have h : env50941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50940_50941 : H12AffineEnvironment.transform 7 14 env50940 = env50941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env50940 == env50941) = true)

theorem identity50941 : scanCanonicalize (H12AffineFastState.compose env50941 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50942 : List Nat := [2,4,4,7,6,6,5,2,0,4,0,0,3,1,0,5,0,1,5,1,0,7,6,2,3,7,1,0,1,1,2,6,2,6,1,0]

theorem envBound50942 : H12AffineFastState.Bounded env50942 := by
  intro p hp
  have h : env50942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50941_50942 : H12AffineEnvironment.transform 2 4 env50941 = env50942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50941 == env50942) = true)

def env50943 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12590,1,12719,321,12636,4096,477,17,8510,8328,64,318,80,4177,2340,8205,4161,256,12297,0,513]

theorem envBound50943 : H12AffineFastState.Bounded env50943 := by
  intro p hp
  have h : env50943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50931_50943 : H12AffineEnvironment.transform 9 321 env50931 = env50943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50931 == env50943) = true)

theorem identity50943 : scanCanonicalize (H12AffineFastState.compose env50943 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50943 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50944 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,81,4177,4130,1,4259,321,4176,4096,477,17,50,388,64,318,80,4177,2340,257,4161,256,4357,0,513]

theorem envBound50944 : H12AffineFastState.Bounded env50944 := by
  intro p hp
  have h : env50944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50943_50944 : H12AffineEnvironment.transform 12 268 env50943 = env50944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50943 == env50944) = true)

theorem identity50944 : scanCanonicalize (H12AffineFastState.compose env50944 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50944 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50945 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,4096,25,81,4177,4130,1,4259,84,4176,4096,200,17,50,145,64,43,80,4177,2097,20,4161,21,4112,0,513]

theorem envBound50945 : H12AffineFastState.Bounded env50945 := by
  intro p hp
  have h : env50945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50944_50945 : H12AffineEnvironment.transform 7 21 env50944 = env50945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50944 == env50945) = true)

theorem identity50945 : scanCanonicalize (H12AffineFastState.compose env50945 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50945 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50946 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,17,25,81,64,51,1,178,84,65,17,200,17,50,145,64,43,80,64,2097,20,80,21,1,0,513]

theorem envBound50946 : H12AffineFastState.Bounded env50946 := by
  intro p hp
  have h : env50946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50945_50946 : H12AffineEnvironment.transform 11 17 env50945 = env50946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50945 == env50946) = true)

theorem identity50946 : scanCanonicalize (H12AffineFastState.compose env50946 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound50946 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env50947 : List Nat := [2,4,8,16,32,64,128,21,152,84,2048,17,25,81,64,51,1,178,84,65,17,200,17,50,145,64,43,80,64,2097,20,80,21,1,0,153]

theorem envBound50947 : H12AffineFastState.Bounded env50947 := by
  intro p hp
  have h : env50947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50946_50947 : H12AffineEnvironment.transform 8 152 env50946 = env50947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env50946 == env50947) = true)

theorem identity50947 : scanCanonicalize (H12AffineFastState.compose env50947 (packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound50947 : packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env50948 : List Nat := [2,4,8,16,32,6,128,21,152,18,2048,17,25,23,6,51,1,178,18,7,17,142,17,50,145,6,43,22,6,2097,20,22,21,1,0,153]

theorem envBound50948 : H12AffineFastState.Bounded env50948 := by
  intro p hp
  have h : env50948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50947_50948 : H12AffineEnvironment.transform 5 6 env50947 = env50948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env50947 == env50948) = true)

theorem identity50948 : scanCanonicalize (H12AffineFastState.compose env50948 (packedSelected [0,7,20] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50948 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50949 : List Nat := [2,4,8,6,32,6,128,3,142,4,2048,7,15,1,6,37,1,164,4,7,7,142,7,36,135,6,43,0,6,2087,2,0,3,1,0,143]

theorem envBound50949 : H12AffineFastState.Bounded env50949 := by
  intro p hp
  have h : env50949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50948_50949 : H12AffineEnvironment.transform 3 6 env50948 = env50949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50948 == env50949) = true)

theorem identity50949 : scanCanonicalize (H12AffineFastState.compose env50949 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50949 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env50950 : List Nat := [2,4,8,6,7,6,128,3,142,4,2048,7,15,1,6,2,1,131,4,7,7,142,7,3,135,6,12,0,6,2048,2,0,3,1,0,143]

theorem envBound50950 : H12AffineFastState.Bounded env50950 := by
  intro p hp
  have h : env50950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50949_50950 : H12AffineEnvironment.transform 4 7 env50949 = env50950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50949 == env50950) = true)

theorem identity50950 : scanCanonicalize (H12AffineFastState.compose env50950 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 138) := by decide +kernel

theorem selectedBound50950 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50951 : List Nat := [2,4,8,6,7,6,128,3,142,4,138,7,15,1,6,2,1,131,4,7,7,142,7,3,135,6,12,0,6,138,2,0,3,1,0,143]

theorem envBound50951 : H12AffineFastState.Bounded env50951 := by
  intro p hp
  have h : env50951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50950_50951 : H12AffineEnvironment.transform 10 138 env50950 = env50951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 138 env50950 == env50951) = true)

theorem identity50951 : scanCanonicalize (H12AffineFastState.compose env50951 (packedSelected [0,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50951 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env50952 : List Nat := [2,4,8,6,7,6,15,3,1,4,5,7,15,1,6,2,1,12,4,7,7,1,7,3,8,6,12,0,6,5,2,0,3,1,0,0]

theorem envBound50952 : H12AffineFastState.Bounded env50952 := by
  intro p hp
  have h : env50952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50951_50952 : H12AffineEnvironment.transform 6 15 env50951 = env50952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50951 == env50952) = true)

theorem identity50952 : scanCanonicalize (H12AffineFastState.compose env50952 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50953 : List Nat := [2,2,8,0,1,0,9,3,1,2,3,1,9,1,0,2,1,10,2,1,1,1,1,3,8,0,10,0,0,3,2,0,3,1,0,0]

theorem envBound50953 : H12AffineFastState.Bounded env50953 := by
  intro p hp
  have h : env50953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50952_50953 : H12AffineEnvironment.transform 1 2 env50952 = env50953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50952 == env50953) = true)

theorem identity50953 : scanCanonicalize (H12AffineFastState.compose env50953 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50954 : List Nat := [1,1,8,0,1,0,9,0,1,1,0,1,9,1,0,1,1,9,1,1,1,1,1,0,8,0,9,0,0,0,1,0,0,1,0,0]

theorem envBound50954 : H12AffineFastState.Bounded env50954 := by
  intro p hp
  have h : env50954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50953_50954 : H12AffineEnvironment.transform 0 1 env50953 = env50954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50953 == env50954) = true)

theorem identity50954 : scanCanonicalize (H12AffineFastState.compose env50954 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50954 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50955 : List Nat := [1,1,0,0,1,0,1,0,1,1,0,1,1,1,0,1,1,1,1,1,1,1,1,0,0,0,1,0,0,0,1,0,0,1,0,0]

theorem envBound50955 : H12AffineFastState.Bounded env50955 := by
  intro p hp
  have h : env50955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50954_50955 : H12AffineEnvironment.transform 2 0 env50954 = env50955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50954 == env50955) = true)

def env50956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70886,78894,77840,1297,74814,81226,365713,74798,256,308667,1345,79471]

theorem envBound50956 : H12AffineFastState.Bounded env50956 := by
  intro p hp
  have h : env50956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50902_50956 : H12AffineEnvironment.transform 13 1297 env50902 = env50956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50902 == env50956) = true)

theorem identity50956 : scanCanonicalize (H12AffineFastState.compose env50956 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound50956 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,17,266384,38036,46172,45154,1297,42060,48440,267491,42076,256,308667,1345,46621]

theorem envBound50957 : H12AffineFastState.Bounded env50957 := by
  intro p hp
  have h : env50957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50956_50957 : H12AffineEnvironment.transform 15 32882 env50956 = env50957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env50956 == env50957) = true)

def env50958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263632,33236,41244,42274,1297,42060,43128,262563,42076,256,303355,1345,41821]

theorem envBound50958 : H12AffineFastState.Bounded env50958 := by
  intro p hp
  have h : env50958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50957_50958 : H12AffineEnvironment.transform 11 1344 env50957 = env50958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env50957 == env50958) = true)

theorem identity50958 : scanCanonicalize (H12AffineFastState.compose env50958 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound50958 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,73,1297,32768,32882,1345,262144,34069,32769,1344,32969,17,263632,33236,33109,34155,1297,33797,34865,262563,33813,256,295090,1345,33556]

theorem envBound50959 : H12AffineFastState.Bounded env50959 := by
  intro p hp
  have h : env50959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50958_50959 : H12AffineEnvironment.transform 12 73 env50958 = env50959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50958 == env50959) = true)

theorem identity50959 : scanCanonicalize (H12AffineFastState.compose env50959 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 34667) := by decide +kernel

theorem selectedBound50959 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env50960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,73,1297,32768,32882,1345,34667,34069,32769,1344,32969,17,33467,33236,33109,34155,1297,33797,34865,34504,33813,256,2009,1345,33556]

theorem envBound50960 : H12AffineFastState.Bounded env50960 := by
  intro p hp
  have h : env50960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50959_50960 : H12AffineEnvironment.transform 17 34667 env50959 = env50960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34667 env50959 == env50960) = true)

def env50961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263633,33237,41245,42275,1297,42060,43129,262562,42076,256,303354,1345,41820]

theorem envBound50961 : H12AffineFastState.Bounded env50961 := by
  intro p hp
  have h : env50961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50957_50961 : H12AffineEnvironment.transform 11 1345 env50957 = env50961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env50957 == env50961) = true)

theorem identity50961 : scanCanonicalize (H12AffineFastState.compose env50961 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound50961 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,41147,42333,32769,1345,41089,17,42346,33237,41245,42275,1297,42060,43129,41241,42076,256,65,1345,41820]

theorem envBound50962 : H12AffineFastState.Bounded env50962 := by
  intro p hp
  have h : env50962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50961_50962 : H12AffineEnvironment.transform 17 41147 env50961 = env50962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env50961 == env50962) = true)

theorem identity50962 : scanCanonicalize (H12AffineFastState.compose env50962 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50962 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1345,487,1025,8541,1345,477,17,1078,8329,65,1151,1297,1296,2341,69,1280,256,65,1345,512]

theorem envBound50963 : H12AffineFastState.Bounded env50963 := by
  intro p hp
  have h : env50963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50962_50963 : H12AffineEnvironment.transform 14 8540 env50962 = env50963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50962 == env50963) = true)

theorem identity50963 : scanCanonicalize (H12AffineFastState.compose env50963 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50963 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50964 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,8192,1028,8265,8251,1108,242,1025,8264,1108,200,17,1078,8329,65,1151,1028,1029,2096,69,1045,21,65,1108,512]

theorem envBound50964 : H12AffineFastState.Bounded env50964 := by
  intro p hp
  have h : env50964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50963_50964 : H12AffineEnvironment.transform 7 21 env50963 = env50964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50963 == env50964) = true)

theorem identity50964 : scanCanonicalize (H12AffineFastState.compose env50964 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound50964 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50965 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,1684,1028,1757,1711,1108,242,1025,1756,1108,200,17,1078,1565,65,1151,1028,1029,2096,69,1045,21,65,1108,512]

theorem envBound50965 : H12AffineFastState.Bounded env50965 := by
  intro p hp
  have h : env50965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50964_50965 : H12AffineEnvironment.transform 12 1684 env50964 = env50965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env50964 == env50965) = true)

theorem identity50965 : scanCanonicalize (H12AffineFastState.compose env50965 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50965 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50966 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,1684,1028,1676,1711,1029,163,1025,1677,1029,153,17,1078,1565,16,1070,1028,1029,2096,20,1045,21,16,1029,512]

theorem envBound50966 : H12AffineFastState.Bounded env50966 := by
  intro p hp
  have h : env50966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50965_50966 : H12AffineEnvironment.transform 5 17 env50965 = env50966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50965 == env50966) = true)

theorem identity50966 : scanCanonicalize (H12AffineFastState.compose env50966 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50966 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50967 : List Nat := [2,4,8,16,16,17,128,21,512,1024,2048,1029,1684,1028,1676,1695,1029,147,1025,1677,1029,153,17,1030,1565,16,1054,1028,1029,2048,20,1045,21,16,1029,512]

theorem envBound50967 : H12AffineFastState.Bounded env50967 := by
  intro p hp
  have h : env50967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50966_50967 : H12AffineEnvironment.transform 4 16 env50966 = env50967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50966 == env50967) = true)

theorem identity50967 : scanCanonicalize (H12AffineFastState.compose env50967 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50967 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env50968 : List Nat := [2,4,8,16,16,17,128,21,512,4,2048,1,656,0,648,667,1,147,5,649,1,153,17,2,537,16,26,0,1,2048,20,17,21,16,1,512]

theorem envBound50968 : H12AffineFastState.Bounded env50968 := by
  intro p hp
  have h : env50968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50967_50968 : H12AffineEnvironment.transform 9 4 env50967 = env50968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50967 == env50968) = true)

theorem identity50968 : scanCanonicalize (H12AffineFastState.compose env50968 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound50968 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50969 : List Nat := [2,4,8,16,16,17,128,21,512,4,133,1,656,0,648,667,1,147,5,649,1,153,17,2,537,16,26,0,1,133,20,17,21,16,1,512]

theorem envBound50969 : H12AffineFastState.Bounded env50969 := by
  intro p hp
  have h : env50969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50968_50969 : H12AffineEnvironment.transform 10 133 env50968 = env50969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env50968 == env50969) = true)

theorem identity50969 : scanCanonicalize (H12AffineFastState.compose env50969 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound50969 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50970 : List Nat := [2,4,8,16,16,17,5,21,512,4,0,1,533,0,525,542,1,22,5,524,1,28,17,2,537,16,26,0,1,0,20,17,21,16,1,512]

theorem envBound50970 : H12AffineFastState.Bounded env50970 := by
  intro p hp
  have h : env50970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50969_50970 : H12AffineEnvironment.transform 6 5 env50969 = env50970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env50969 == env50970) = true)

theorem identity50970 : scanCanonicalize (H12AffineFastState.compose env50970 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50970 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50971 : List Nat := [2,4,5,16,16,17,5,21,512,4,0,1,533,0,512,531,1,22,5,513,1,17,17,2,532,16,23,0,1,0,20,17,21,16,1,512]

theorem envBound50971 : H12AffineFastState.Bounded env50971 := by
  intro p hp
  have h : env50971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50970_50971 : H12AffineEnvironment.transform 2 5 env50970 = env50971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50970 == env50971) = true)

def env50972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86519,94526,77841,1296,74814,96347,381312,74798,256,323754,1345,95102]

theorem envBound50972 : H12AffineFastState.Bounded env50972 := by
  intro p hp
  have h : env50972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50901_50972 : H12AffineEnvironment.transform 16 16465 env50901 = env50972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env50901 == env50972) = true)

def env50973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70887,78894,77841,1296,74814,81227,365712,74798,256,308666,1345,79470]

theorem envBound50973 : H12AffineFastState.Bounded env50973 := by
  intro p hp
  have h : env50973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50972_50973 : H12AffineEnvironment.transform 13 1296 env50972 = env50973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50972 == env50973) = true)

theorem identity50973 : scanCanonicalize (H12AffineFastState.compose env50973 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound50973 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,16,266385,38036,46173,45154,1296,42061,48440,267491,42077,256,308666,1345,46621]

theorem envBound50974 : H12AffineFastState.Bounded env50974 := by
  intro p hp
  have h : env50974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50973_50974 : H12AffineEnvironment.transform 15 32883 env50973 = env50974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env50973 == env50974) = true)

def env50975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263633,33236,41245,42274,1296,42061,43128,262563,42077,256,303354,1345,41821]

theorem envBound50975 : H12AffineFastState.Bounded env50975 := by
  intro p hp
  have h : env50975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50974_50975 : H12AffineEnvironment.transform 11 1344 env50974 = env50975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env50974 == env50975) = true)

theorem identity50975 : scanCanonicalize (H12AffineFastState.compose env50975 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound50975 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9245,9326,1345,262144,321,9244,1344,1180,16,263633,9673,1280,319,1296,80,3173,262563,64,256,263399,1345,1856]

theorem envBound50976 : H12AffineFastState.Bounded env50976 := by
  intro p hp
  have h : env50976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50975_50976 : H12AffineEnvironment.transform 14 9245 env50975 = env50976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env50975 == env50976) = true)

theorem identity50976 : scanCanonicalize (H12AffineFastState.compose env50976 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50976 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50977 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8494,1,262144,321,8540,0,476,16,262289,8329,64,319,80,80,2341,262563,64,256,262567,1,512]

theorem envBound50977 : H12AffineFastState.Bounded env50977 := by
  intro p hp
  have h : env50977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50976_50977 : H12AffineEnvironment.transform 9 320 env50976 = env50977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50976 == env50977) = true)

theorem identity50977 : scanCanonicalize (H12AffineFastState.compose env50977 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound50977 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50978 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8494,1,243,321,8540,0,476,16,98,8329,64,319,80,80,2341,336,64,256,340,1,512]

theorem envBound50978 : H12AffineFastState.Bounded env50978 := by
  intro p hp
  have h : env50978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50977_50978 : H12AffineEnvironment.transform 17 243 env50977 = env50978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env50977 == env50978) = true)

theorem identity50978 : scanCanonicalize (H12AffineFastState.compose env50978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound50978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50979 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,705,80,924,1007,1,243,321,925,0,476,16,98,584,64,319,80,80,2341,336,64,256,340,1,512]

theorem envBound50979 : H12AffineFastState.Bounded env50979 := by
  intro p hp
  have h : env50979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50978_50979 : H12AffineEnvironment.transform 12 705 env50978 = env50979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env50978 == env50979) = true)

theorem identity50979 : scanCanonicalize (H12AffineFastState.compose env50979 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50979 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50980 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,656,1,924,958,1,162,272,925,0,397,16,51,537,17,319,1,1,2341,257,17,256,261,1,512]

theorem envBound50980 : H12AffineFastState.Bounded env50980 := by
  intro p hp
  have h : env50980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50979_50980 : H12AffineEnvironment.transform 5 17 env50979 = env50980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50979 == env50980) = true)

theorem identity50980 : scanCanonicalize (H12AffineFastState.compose env50980 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound50980 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50981 : List Nat := [2,4,8,16,32,17,57,256,512,273,2048,0,553,1,805,775,1,27,272,804,0,308,16,51,537,17,319,1,1,2341,257,17,256,261,1,512]

theorem envBound50981 : H12AffineFastState.Bounded env50981 := by
  intro p hp
  have h : env50981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50980_50981 : H12AffineEnvironment.transform 6 57 env50980 = env50981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env50980 == env50981) = true)

theorem identity50981 : scanCanonicalize (H12AffineFastState.compose env50981 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound50981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50982 : List Nat := [2,4,8,16,32,17,57,256,512,273,293,0,553,1,805,775,1,27,272,804,0,308,16,51,537,17,319,1,1,0,257,17,256,261,1,512]

theorem envBound50982 : H12AffineFastState.Bounded env50982 := by
  intro p hp
  have h : env50982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50981_50982 : H12AffineEnvironment.transform 10 293 env50981 = env50982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env50981 == env50982) = true)

theorem identity50982 : scanCanonicalize (H12AffineFastState.compose env50982 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound50982 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env50983 : List Nat := [2,4,8,16,32,17,57,62,512,47,27,0,553,1,539,569,1,27,46,538,0,10,16,51,537,17,1,1,1,0,63,17,62,59,1,512]

theorem envBound50983 : H12AffineFastState.Bounded env50983 := by
  intro p hp
  have h : env50983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50982_50983 : H12AffineEnvironment.transform 7 62 env50982 = env50983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env50982 == env50983) = true)

theorem identity50983 : scanCanonicalize (H12AffineFastState.compose env50983 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50984 : List Nat := [2,4,8,16,32,17,57,62,48,47,27,0,25,1,43,9,1,27,46,42,0,10,16,51,41,17,1,1,1,0,63,17,62,59,1,48]

theorem envBound50984 : H12AffineFastState.Bounded env50984 := by
  intro p hp
  have h : env50984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50983_50984 : H12AffineEnvironment.transform 8 48 env50983 = env50984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50983 == env50984) = true)

def env50985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263632,33237,41244,42275,1296,42061,43129,262562,42077,256,303355,1345,41820]

theorem envBound50985 : H12AffineFastState.Bounded env50985 := by
  intro p hp
  have h : env50985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50974_50985 : H12AffineEnvironment.transform 11 1345 env50974 = env50985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env50974 == env50985) = true)

theorem identity50985 : scanCanonicalize (H12AffineFastState.compose env50985 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound50985 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,9454,42333,32769,1345,41088,16,8510,33237,41244,42275,1296,42061,43129,9548,42077,256,33813,1345,41820]

theorem envBound50986 : H12AffineFastState.Bounded env50986 := by
  intro p hp
  have h : env50986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50985_50986 : H12AffineEnvironment.transform 17 9454 env50985 = env50986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env50985 == env50986) = true)

theorem identity50986 : scanCanonicalize (H12AffineFastState.compose env50986 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 973) := by decide +kernel

theorem selectedBound50986 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env50987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,973,958,1345,9454,9872,972,1345,9037,16,8510,536,8913,9966,1296,10112,11188,9548,10128,256,2008,1345,8337]

theorem envBound50987 : H12AffineFastState.Bounded env50987 := by
  intro p hp
  have h : env50987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50986_50987 : H12AffineEnvironment.transform 14 973 env50986 = env50987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 973 env50986 == env50987) = true)

def env50988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70886,78895,77841,1296,74814,81226,365713,74798,256,308667,1345,79471]

theorem envBound50988 : H12AffineFastState.Bounded env50988 := by
  intro p hp
  have h : env50988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50972_50988 : H12AffineEnvironment.transform 13 1297 env50972 = env50988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50972 == env50988) = true)

theorem identity50988 : scanCanonicalize (H12AffineFastState.compose env50988 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50988 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,16,266384,70886,78895,77841,1296,74814,81226,336013,74798,256,262567,1345,79471]

theorem envBound50989 : H12AffineFastState.Bounded env50989 := by
  intro p hp
  have h : env50989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50988_50989 : H12AffineEnvironment.transform 14 13340 env50988 = env50989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50988 == env50989) = true)

def env50990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,16,69648,70886,78895,77841,1296,74814,81226,8205,74798,256,65831,1345,79471]

theorem envBound50990 : H12AffineFastState.Bounded env50990 := by
  intro p hp
  have h : env50990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50989_50990 : H12AffineEnvironment.transform 17 65664 env50989 = env50990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50989 == env50990) = true)

theorem identity50990 : scanCanonicalize (H12AffineFastState.compose env50990 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound50990 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5158,1344,5286,9288,13341,4096,476,16,1078,192,8201,9271,1296,12312,10604,8205,12296,256,5377,1345,8777]

theorem envBound50991 : H12AffineFastState.Bounded env50991 := by
  intro p hp
  have h : env50991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50990_50991 : H12AffineEnvironment.transform 15 5158 env50990 = env50991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env50990 == env50991) = true)

def env50992 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5286,9240,13341,4096,396,16,1078,144,8201,9271,1296,12312,10556,8205,12296,256,5377,1297,8729]

theorem envBound50992 : H12AffineFastState.Bounded env50992 := by
  intro p hp
  have h : env50992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50991_50992 : H12AffineEnvironment.transform 5 16 env50991 = env50992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50991 == env50992) = true)

theorem identity50992 : scanCanonicalize (H12AffineFastState.compose env50992 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50992 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50993 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,8192,1028,13340,5158,1029,5286,9240,13341,4096,153,16,1078,144,8201,9271,1029,12312,10281,8205,12296,21,5140,1028,8729]

theorem envBound50993 : H12AffineFastState.Bounded env50993 := by
  intro p hp
  have h : env50993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50992_50993 : H12AffineEnvironment.transform 7 21 env50992 = env50993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50992 == env50993) = true)

theorem identity50993 : scanCanonicalize (H12AffineFastState.compose env50993 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound50993 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50994 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,24,1028,5124,5158,1029,5286,1024,5125,4096,153,16,1078,144,17,1071,1029,4096,2097,21,4112,21,5140,1028,513]

theorem envBound50994 : H12AffineFastState.Bounded env50994 := by
  intro p hp
  have h : env50994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50993_50994 : H12AffineEnvironment.transform 12 24 env50993 = env50994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env50993 == env50994) = true)

theorem identity50994 : scanCanonicalize (H12AffineFastState.compose env50994 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound50994 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50995 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,2723,24,1028,3751,3717,1029,3589,1024,3750,2723,153,16,1078,144,17,1071,1029,2723,2097,21,2739,21,3767,1028,513]

theorem envBound50995 : H12AffineFastState.Bounded env50995 := by
  intro p hp
  have h : env50995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50994_50995 : H12AffineEnvironment.transform 11 2723 env50994 = env50995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env50994 == env50995) = true)

theorem identity50995 : scanCanonicalize (H12AffineFastState.compose env50995 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound50995 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50996 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,2723,24,1,2722,2688,0,2560,5,2723,2723,153,16,51,144,17,42,0,2723,2097,21,2739,21,2738,1,513]

theorem envBound50996 : H12AffineFastState.Bounded env50996 := by
  intro p hp
  have h : env50996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50995_50996 : H12AffineEnvironment.transform 9 5 env50995 = env50996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env50995 == env50996) = true)

theorem identity50996 : scanCanonicalize (H12AffineFastState.compose env50996 (packedSelected [1,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound50996 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env50997 : List Nat := [2,4,8,16,32,16,128,21,512,5,45,654,24,1,655,685,0,557,5,654,654,153,16,51,144,17,42,0,654,28,21,670,21,671,1,513]

theorem envBound50997 : H12AffineFastState.Bounded env50997 := by
  intro p hp
  have h : env50997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50996_50997 : H12AffineEnvironment.transform 10 45 env50996 = env50997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env50996 == env50997) = true)

theorem identity50997 : scanCanonicalize (H12AffineFastState.compose env50997 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 158) := by decide +kernel

theorem selectedBound50997 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50998 : List Nat := [2,4,8,16,32,16,128,21,158,5,45,16,24,1,17,51,0,179,5,16,16,153,16,51,144,17,42,0,16,28,21,0,21,1,1,159]

theorem envBound50998 : H12AffineFastState.Bounded env50998 := by
  intro p hp
  have h : env50998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50997_50998 : H12AffineEnvironment.transform 8 158 env50997 = env50998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 158 env50997 == env50998) = true)

theorem identity50998 : scanCanonicalize (H12AffineFastState.compose env50998 (packedSelected [0,2,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound50998 : packedSelected [0,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env50999 : List Nat := [2,4,8,16,32,16,24,21,6,5,45,16,24,1,17,51,0,43,5,16,16,1,16,51,8,17,42,0,16,28,21,0,21,1,1,7]

theorem envBound50999 : H12AffineFastState.Bounded env50999 := by
  intro p hp
  have h : env50999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50998_50999 : H12AffineEnvironment.transform 6 24 env50998 = env50999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env50998 == env50999) = true)

theorem identity50999 : scanCanonicalize (H12AffineFastState.compose env50999 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50999 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51000 : List Nat := [2,4,2,16,32,16,18,21,6,5,39,16,18,1,17,51,0,33,5,16,16,1,16,51,2,17,32,0,16,22,21,0,21,1,1,7]

theorem envBound51000 : H12AffineFastState.Bounded env51000 := by
  intro p hp
  have h : env51000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50999_51000 : H12AffineEnvironment.transform 2 2 env50999 = env51000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50999 == env51000) = true)

theorem identity51000 : scanCanonicalize (H12AffineFastState.compose env51000 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51000 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51001 : List Nat := [2,4,2,7,32,7,5,2,6,5,39,7,5,1,6,36,0,33,5,7,7,1,7,36,2,6,32,0,7,1,2,0,2,1,1,7]

theorem envBound51001 : H12AffineFastState.Bounded env51001 := by
  intro p hp
  have h : env51001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51000_51001 : H12AffineEnvironment.transform 3 7 env51000 = env51001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51000 == env51001) = true)

theorem identity51001 : scanCanonicalize (H12AffineFastState.compose env51001 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound51001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51002 : List Nat := [2,4,2,7,3,7,5,2,6,5,4,7,5,1,6,7,0,2,5,7,7,1,7,7,2,6,3,0,7,1,2,0,2,1,1,7]

theorem envBound51002 : H12AffineFastState.Bounded env51002 := by
  intro p hp
  have h : env51002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51001_51002 : H12AffineEnvironment.transform 4 3 env51001 = env51002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env51001 == env51002) = true)

theorem identity51002 : scanCanonicalize (H12AffineFastState.compose env51002 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51002 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51003 : List Nat := [2,3,2,0,3,0,2,2,1,2,3,0,2,1,1,0,0,2,2,0,0,1,0,0,2,1,3,0,0,1,2,0,2,1,1,0]

theorem envBound51003 : H12AffineFastState.Bounded env51003 := by
  intro p hp
  have h : env51003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51002_51003 : H12AffineEnvironment.transform 1 3 env51002 = env51003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51002 == env51003) = true)

def env51004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5286,9241,13341,4096,397,16,1078,145,8201,9271,1296,12312,10557,8205,12296,256,5377,1296,8728]

theorem envBound51004 : H12AffineFastState.Bounded env51004 := by
  intro p hp
  have h : env51004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50991_51004 : H12AffineEnvironment.transform 5 17 env50991 = env51004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50991 == env51004) = true)

theorem identity51004 : scanCanonicalize (H12AffineFastState.compose env51004 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51004 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,1297,5393,5158,1297,5286,1300,5392,4096,397,16,1078,145,260,1338,1296,4373,2096,256,4357,256,5377,1296,789]

theorem envBound51005 : H12AffineFastState.Bounded env51005 := by
  intro p hp
  have h : env51005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51004_51005 : H12AffineEnvironment.transform 12 269 env51004 = env51005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51004 == env51005) = true)

theorem identity51005 : scanCanonicalize (H12AffineFastState.compose env51005 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51005 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env51006 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,24,1028,5124,5158,1028,5286,1025,5125,4096,152,16,1078,145,17,1071,1029,4096,2096,21,4112,21,5140,1029,512]

theorem envBound51006 : H12AffineFastState.Bounded env51006 := by
  intro p hp
  have h : env51006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51005_51006 : H12AffineEnvironment.transform 7 21 env51005 = env51006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51005 == env51006) = true)

theorem identity51006 : scanCanonicalize (H12AffineFastState.compose env51006 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2696) := by decide +kernel

theorem selectedBound51006 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env51007 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,2696,24,1028,3724,3758,1028,3630,1025,3725,2696,152,16,1078,145,17,1071,1029,2696,2096,21,2712,21,3740,1029,512]

theorem envBound51007 : H12AffineFastState.Bounded env51007 := by
  intro p hp
  have h : env51007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51006_51007 : H12AffineEnvironment.transform 11 2696 env51006 = env51007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2696 env51006 == env51007) = true)

theorem identity51007 : scanCanonicalize (H12AffineFastState.compose env51007 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound51007 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env51008 : List Nat := [2,4,8,16,32,17,128,21,512,1024,1175,1567,24,1028,539,569,1028,697,1025,538,1567,152,16,1078,145,17,1071,1029,1567,1191,21,1551,21,523,1029,512]

theorem envBound51008 : H12AffineFastState.Bounded env51008 := by
  intro p hp
  have h : env51008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51007_51008 : H12AffineEnvironment.transform 10 1175 env51007 = env51008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env51007 == env51008) = true)

theorem identity51008 : scanCanonicalize (H12AffineFastState.compose env51008 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound51008 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51009 : List Nat := [2,4,8,16,32,17,128,21,512,678,561,185,24,674,539,569,674,697,679,538,185,152,16,656,145,17,649,675,185,513,21,169,21,523,675,512]

theorem envBound51009 : H12AffineFastState.Bounded env51009 := by
  intro p hp
  have h : env51009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51008_51009 : H12AffineEnvironment.transform 9 678 env51008 = env51009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env51008 == env51009) = true)

def env51010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,16,69649,70886,78895,77841,1296,74814,81226,8204,74798,256,65830,1345,79471]

theorem envBound51010 : H12AffineFastState.Bounded env51010 := by
  intro p hp
  have h : env51010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50989_51010 : H12AffineEnvironment.transform 17 65665 env50989 = env51010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50989 == env51010) = true)

theorem identity51010 : scanCanonicalize (H12AffineFastState.compose env51010 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound51010 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,1344,486,12553,13341,4096,476,16,4470,5505,13640,12662,1296,9561,15405,8204,9545,256,65,1345,14088]

theorem envBound51011 : H12AffineFastState.Bounded env51011 := by
  intro p hp
  have h : env51011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51010_51011 : H12AffineEnvironment.transform 15 359 env51010 = env51011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env51010 == env51011) = true)

def env51012 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,311,1296,438,12553,13341,4096,396,16,4390,5505,13592,12582,1296,9481,15405,8204,9497,256,17,1297,14088]

theorem envBound51012 : H12AffineFastState.Bounded env51012 := by
  intro p hp
  have h : env51012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51011_51012 : H12AffineEnvironment.transform 5 16 env51011 = env51012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51011 == env51012) = true)

theorem identity51012 : scanCanonicalize (H12AffineFastState.compose env51012 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51012 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,8192,1297,8217,311,1296,438,9484,8216,1029,396,16,1315,388,8477,9507,1296,9481,10280,8204,9497,256,17,1297,8973]

theorem envBound51013 : H12AffineFastState.Bounded env51013 := by
  intro p hp
  have h : env51013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51012_51013 : H12AffineEnvironment.transform 11 1029 env51012 = env51013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env51012 == env51013) = true)

def env51014 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,310,1297,439,12553,13341,4096,397,16,4391,5505,13593,12583,1296,9480,15405,8204,9496,256,16,1296,14088]

theorem envBound51014 : H12AffineFastState.Bounded env51014 := by
  intro p hp
  have h : env51014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51011_51014 : H12AffineEnvironment.transform 5 17 env51011 = env51014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51011 == env51014) = true)

theorem identity51014 : scanCanonicalize (H12AffineFastState.compose env51014 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51014 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51015 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,1297,5392,310,1297,439,4101,5393,4096,397,16,4391,5505,5141,4139,1296,1028,7457,256,1044,256,16,1296,5636]

theorem envBound51015 : H12AffineFastState.Bounded env51015 := by
  intro p hp
  have h : env51015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51014_51015 : H12AffineEnvironment.transform 12 268 env51014 = env51015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51014 == env51015) = true)

theorem identity51015 : scanCanonicalize (H12AffineFastState.compose env51015 (packedSelected [1,2,5,8,19,23,24,26,32] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound51015 : packedSelected [1,2,5,8,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env51016 : List Nat := [2,4,8,16,32,17,128,256,413,1024,2048,4096,268,1297,5392,310,1297,439,4101,5393,4096,397,16,4391,5505,5141,4139,1296,1028,7457,256,1044,256,16,1296,5529]

theorem envBound51016 : H12AffineFastState.Bounded env51016 := by
  intro p hp
  have h : env51016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51015_51016 : H12AffineEnvironment.transform 8 413 env51015 = env51016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env51015 == env51016) = true)

theorem identity51016 : scanCanonicalize (H12AffineFastState.compose env51016 (packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound51016 : packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env51017 : List Nat := [2,4,8,16,32,17,128,256,413,1024,2048,429,268,1297,1213,310,1297,439,424,1212,429,397,16,138,1068,1464,390,1296,1028,3212,256,1044,256,16,1296,1076]

theorem envBound51017 : H12AffineFastState.Bounded env51017 := by
  intro p hp
  have h : env51017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51016_51017 : H12AffineEnvironment.transform 11 429 env51016 = env51017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env51016 == env51017) = true)

theorem identity51017 : scanCanonicalize (H12AffineFastState.compose env51017 (packedSelected [0,2,3,4,5,7,9,10,11,17,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound51017 : packedSelected [0,2,3,4,5,7,9,10,11,17,21,23] rootPS < 2^1333 := by decide +kernel

def env51018 : List Nat := [2,4,8,16,32,17,128,256,413,425,2048,429,268,184,276,310,184,439,424,277,429,397,16,138,389,17,390,185,429,2341,256,445,256,16,185,413]

theorem envBound51018 : H12AffineFastState.Bounded env51018 := by
  intro p hp
  have h : env51018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51017_51018 : H12AffineEnvironment.transform 9 425 env51017 = env51018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env51017 == env51018) = true)

theorem identity51018 : scanCanonicalize (H12AffineFastState.compose env51018 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound51018 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env51019 : List Nat := [2,4,8,16,32,17,128,256,413,425,428,429,268,184,276,310,184,439,424,277,429,397,16,138,389,17,390,185,429,137,256,445,256,16,185,413]

theorem envBound51019 : H12AffineFastState.Bounded env51019 := by
  intro p hp
  have h : env51019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51018_51019 : H12AffineEnvironment.transform 10 428 env51018 = env51019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env51018 == env51019) = true)

theorem identity51019 : scanCanonicalize (H12AffineFastState.compose env51019 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound51019 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env51020 : List Nat := [2,4,8,16,32,17,128,157,0,52,49,48,145,184,137,171,184,42,53,136,48,16,16,138,24,17,27,185,48,137,157,32,157,16,185,0]

theorem envBound51020 : H12AffineFastState.Bounded env51020 := by
  intro p hp
  have h : env51020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51019_51020 : H12AffineEnvironment.transform 7 157 env51019 = env51020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env51019 == env51020) = true)

theorem identity51020 : scanCanonicalize (H12AffineFastState.compose env51020 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound51020 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env51021 : List Nat := [2,4,8,16,32,17,34,63,0,52,49,48,51,26,43,9,26,42,53,42,48,16,16,40,24,17,27,27,48,43,63,32,63,16,27,0]

theorem envBound51021 : H12AffineFastState.Bounded env51021 := by
  intro p hp
  have h : env51021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51020_51021 : H12AffineEnvironment.transform 6 34 env51020 = env51021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env51020 == env51021) = true)

theorem identity51021 : scanCanonicalize (H12AffineFastState.compose env51021 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51021 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51022 : List Nat := [2,4,8,16,10,17,8,21,0,30,27,26,25,26,1,9,26,0,31,0,26,16,16,2,24,17,27,27,26,1,21,10,21,16,27,0]

theorem envBound51022 : H12AffineFastState.Bounded env51022 := by
  intro p hp
  have h : env51022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51021_51022 : H12AffineEnvironment.transform 4 10 env51021 = env51022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51021 == env51022) = true)

theorem identity51022 : scanCanonicalize (H12AffineFastState.compose env51022 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51022 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51023 : List Nat := [2,4,8,10,10,11,8,15,0,4,1,0,3,0,1,9,0,0,5,0,0,10,10,2,2,11,1,1,0,1,15,10,15,10,1,0]

theorem envBound51023 : H12AffineFastState.Bounded env51023 := by
  intro p hp
  have h : env51023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51022_51023 : H12AffineEnvironment.transform 3 10 env51022 = env51023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51022 == env51023) = true)

theorem identity51023 : scanCanonicalize (H12AffineFastState.compose env51023 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51024 : List Nat := [2,4,5,7,7,6,5,2,0,4,1,0,3,0,1,4,0,0,5,0,0,7,7,2,2,6,1,1,0,1,2,7,2,7,1,0]

theorem envBound51024 : H12AffineFastState.Bounded env51024 := by
  intro p hp
  have h : env51024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51023_51024 : H12AffineEnvironment.transform 2 5 env51023 = env51024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51023 == env51024) = true)

def env51025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,134217728,148801,545088,96347,16876544,74799,257,17420372,151462016,525824]

theorem envBound51025 : H12AffineFastState.Bounded env51025 := by
  intro p hp
  have h : env51025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50122_51025 : H12AffineEnvironment.transform 24 533641 env50122 = env51025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env50122 == env51025) = true)

def env51026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245632,148801,545088,96347,16876544,74799,257,17420372,1344,525824]

theorem envBound51026 : H12AffineFastState.Bounded env51026 := by
  intro p hp
  have h : env51026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51025_51026 : H12AffineEnvironment.transform 26 17245632 env51025 = env51026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env51025 == env51026) = true)

theorem identity51026 : scanCanonicalize (H12AffineFastState.compose env51026 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound51026 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41003,533641,672784,493035,148801,545088,96347,74795,74799,257,618623,1344,525824]

theorem envBound51027 : H12AffineFastState.Bounded env51027 := by
  intro p hp
  have h : env51027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51026_51027 : H12AffineEnvironment.transform 23 41003 env51026 = env51027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env51026 == env51027) = true)

def env51028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,493035,148801,148800,96347,74795,74799,257,222335,1344,135680]

theorem envBound51028 : H12AffineFastState.Bounded env51028 := by
  intro p hp
  have h : env51028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51027_51028 : H12AffineEnvironment.transform 18 136192 env51027 = env51028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env51027 == env51028) = true)

def env51029 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,492615,148717,148716,96347,74795,74799,173,222335,1260,135680]

theorem envBound51029 : H12AffineFastState.Bounded env51029 := by
  intro p hp
  have h : env51029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51028_51029 : H12AffineEnvironment.transform 7 172 env51028 = env51029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51028 == env51029) = true)

def env51030 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143497,20496,492567,148669,148668,96267,74795,74799,173,222255,1212,135680]

theorem envBound51030 : H12AffineFastState.Bounded env51030 := by
  intro p hp
  have h : env51030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51029_51030 : H12AffineEnvironment.transform 5 16 env51029 = env51030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51029 == env51030) = true)

theorem identity51030 : scanCanonicalize (H12AffineFastState.compose env51030 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound51030 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51031 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,41003,32809,20496,341175,62493,62492,96267,74795,74799,173,119951,1212,41632]

theorem envBound51031 : H12AffineFastState.Bounded env51031 := by
  intro p hp
  have h : env51031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51030_51031 : H12AffineEnvironment.transform 16 45216 env51030 = env51031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env51030 == env51031) = true)

theorem identity51031 : scanCanonicalize (H12AffineFastState.compose env51031 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound51031 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env51032 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4096,46140,46092,41003,32809,5293,341175,45216,45217,81078,74795,74799,173,102450,1212,41632]

theorem envBound51032 : H12AffineFastState.Bounded env51032 := by
  intro p hp
  have h : env51032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51031_51032 : H12AffineEnvironment.transform 13 1213 env51031 = env51032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env51031 == env51032) = true)

theorem identity51032 : scanCanonicalize (H12AffineFastState.compose env51032 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound51032 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51033 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,32768,65536,45216,262144,41124,32769,4096,45112,45064,41003,32809,4265,340147,45216,45217,80050,73775,73771,173,102450,184,41632]

theorem envBound51033 : H12AffineFastState.Bounded env51033 := by
  intro p hp
  have h : env51033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51032_51033 : H12AffineEnvironment.transform 9 4 env51032 = env51033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env51032 == env51033) = true)

theorem identity51033 : scanCanonicalize (H12AffineFastState.compose env51033 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound51033 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env51034 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,32768,37019,45216,262144,41124,32769,4096,45112,45064,41003,32809,4265,303144,45216,45217,43049,45236,45232,173,169,184,41632]

theorem envBound51034 : H12AffineFastState.Bounded env51034 := by
  intro p hp
  have h : env51034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51033_51034 : H12AffineEnvironment.transform 15 37019 env51033 = env51034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env51033 == env51034) = true)

theorem identity51034 : scanCanonicalize (H12AffineFastState.compose env51034 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound51034 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env51035 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,32768,37019,45216,43049,41124,32769,4096,45112,45064,41003,32809,4265,2049,45216,45217,43049,45236,45232,173,169,184,41632]

theorem envBound51035 : H12AffineFastState.Bounded env51035 := by
  intro p hp
  have h : env51035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51034_51035 : H12AffineEnvironment.transform 17 43049 env51034 = env51035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env51034 == env51035) = true)

theorem identity51035 : scanCanonicalize (H12AffineFastState.compose env51035 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound51035 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env51036 : List Nat := [2,4,8,16,32,16,128,172,147,4,2048,4096,8192,185,32768,37019,45216,43049,41124,32769,4096,45112,45064,41003,32809,4265,2049,45216,45217,43049,45236,45232,173,169,184,41011]

theorem envBound51036 : H12AffineFastState.Bounded env51036 := by
  intro p hp
  have h : env51036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51035_51036 : H12AffineEnvironment.transform 8 147 env51035 = env51036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env51035 == env51036) = true)

theorem identity51036 : scanCanonicalize (H12AffineFastState.compose env51036 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 14522) := by decide +kernel

theorem selectedBound51036 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env51037 : List Nat := [2,4,8,16,32,16,128,172,147,4,2048,4096,8192,185,14522,10273,2074,4243,6174,14523,4096,2178,2226,6289,14483,4265,2049,2074,2075,4243,2062,2058,173,169,184,6281]

theorem envBound51037 : H12AffineFastState.Bounded env51037 := by
  intro p hp
  have h : env51037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51036_51037 : H12AffineEnvironment.transform 14 14522 env51036 = env51037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14522 env51036 == env51037) = true)

theorem identity51037 : scanCanonicalize (H12AffineFastState.compose env51037 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound51037 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env51038 : List Nat := [2,4,8,16,32,16,128,172,147,4,2048,4096,25,185,6307,2104,2074,4243,6174,6306,4096,2178,2226,6289,6282,4265,2049,2074,2075,4243,2062,2058,173,169,184,6281]

theorem envBound51038 : H12AffineFastState.Bounded env51038 := by
  intro p hp
  have h : env51038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51037_51038 : H12AffineEnvironment.transform 12 25 env51037 = env51038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env51037 == env51038) = true)

theorem identity51038 : scanCanonicalize (H12AffineFastState.compose env51038 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51038 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env51039 : List Nat := [2,4,8,11,32,11,128,172,136,4,2048,4096,2,162,6307,2083,2049,4232,6149,6306,4096,2178,2217,6282,6282,4265,2049,2049,2048,4232,2062,2058,173,169,163,6281]

theorem envBound51039 : H12AffineFastState.Bounded env51039 := by
  intro p hp
  have h : env51039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51038_51039 : H12AffineEnvironment.transform 3 11 env51038 = env51039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51038 == env51039) = true)

theorem identity51039 : scanCanonicalize (H12AffineFastState.compose env51039 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound51039 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env51040 : List Nat := [2,4,8,11,32,11,128,172,136,4,163,4096,2,162,4096,128,162,4232,4262,4097,4096,33,10,4137,4137,4265,162,162,163,4232,173,169,173,169,163,4138]

theorem envBound51040 : H12AffineFastState.Bounded env51040 := by
  intro p hp
  have h : env51040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51039_51040 : H12AffineEnvironment.transform 10 163 env51039 = env51040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env51039 == env51040) = true)

theorem identity51040 : scanCanonicalize (H12AffineFastState.compose env51040 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound51040 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51041 : List Nat := [2,4,8,11,32,11,47,3,39,4,12,4096,2,13,4096,47,13,4135,4105,4097,4096,33,10,4137,4137,4102,13,13,12,4135,2,6,2,6,12,4138]

theorem envBound51041 : H12AffineFastState.Bounded env51041 := by
  intro p hp
  have h : env51041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51040_51041 : H12AffineEnvironment.transform 6 47 env51040 = env51041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env51040 == env51041) = true)

theorem identity51041 : scanCanonicalize (H12AffineFastState.compose env51041 (packedSelected [1,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound51041 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env51042 : List Nat := [2,4,8,11,32,11,47,3,39,4,12,42,2,13,42,47,13,13,35,43,42,33,10,3,3,44,13,13,12,13,2,6,2,6,12,0]

theorem envBound51042 : H12AffineFastState.Bounded env51042 := by
  intro p hp
  have h : env51042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51041_51042 : H12AffineEnvironment.transform 11 42 env51041 = env51042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env51041 == env51042) = true)

theorem identity51042 : scanCanonicalize (H12AffineFastState.compose env51042 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51043 : List Nat := [2,4,8,11,6,11,9,3,1,4,12,12,2,13,12,9,13,13,5,13,12,7,10,3,3,10,13,13,12,13,2,6,2,6,12,0]

theorem envBound51043 : H12AffineFastState.Bounded env51043 := by
  intro p hp
  have h : env51043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51042_51043 : H12AffineEnvironment.transform 4 6 env51042 = env51043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51042 == env51043) = true)

theorem identity51043 : scanCanonicalize (H12AffineFastState.compose env51043 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound51043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51044 : List Nat := [2,4,0,3,6,3,1,3,1,4,4,4,2,5,4,1,5,5,5,5,4,7,2,3,3,2,5,5,4,5,2,6,2,6,4,0]

theorem envBound51044 : H12AffineFastState.Bounded env51044 := by
  intro p hp
  have h : env51044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51043_51044 : H12AffineEnvironment.transform 2 0 env51043 = env51044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env51043 == env51044) = true)

theorem identity51044 : scanCanonicalize (H12AffineFastState.compose env51044 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51044 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51045 : List Nat := [2,0,0,3,2,3,1,3,1,0,0,0,2,1,0,1,1,1,1,1,0,3,2,3,3,2,1,1,0,1,2,2,2,2,0,0]

theorem envBound51045 : H12AffineFastState.Bounded env51045 := by
  intro p hp
  have h : env51045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51044_51045 : H12AffineEnvironment.transform 1 0 env51044 = env51045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51044 == env51045) = true)

theorem identity51045 : scanCanonicalize (H12AffineFastState.compose env51045 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51045 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51046 : List Nat := [1,0,0,0,1,0,1,0,1,0,0,0,1,1,0,1,1,1,1,1,0,0,1,0,0,1,1,1,0,1,1,1,1,1,0,0]

theorem envBound51046 : H12AffineFastState.Bounded env51046 := by
  intro p hp
  have h : env51046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51045_51046 : H12AffineEnvironment.transform 0 1 env51045 = env51046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51045 == env51046) = true)

def env51047 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143497,20496,492566,148668,148669,96266,74795,74799,173,222254,1213,135680]

theorem envBound51047 : H12AffineFastState.Bounded env51047 := by
  intro p hp
  have h : env51047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51029_51047 : H12AffineEnvironment.transform 5 17 env51029 = env51047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51029 == env51047) = true)

theorem identity51047 : scanCanonicalize (H12AffineFastState.compose env51047 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound51047 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51048 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,41003,143497,20496,105630,148668,148669,96266,74795,74799,173,222254,1213,135680]

theorem envBound51048 : H12AffineFastState.Bounded env51048 := by
  intro p hp
  have h : env51048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51047_51048 : H12AffineEnvironment.transform 17 137352 env51047 = env51048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env51047 == env51048) = true)

theorem identity51048 : scanCanonicalize (H12AffineFastState.compose env51048 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound51048 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51049 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4096,61568,147472,41003,143497,20496,43169,148668,148669,19509,4116,4112,173,151569,1213,135680]

theorem envBound51049 : H12AffineFastState.Bounded env51049 := by
  intro p hp
  have h : env51049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51048_51049 : H12AffineEnvironment.transform 15 13375 env51048 = env51049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env51048 == env51049) = true)

theorem identity51049 : scanCanonicalize (H12AffineFastState.compose env51049 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound51049 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51050 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136192,32769,4096,46141,132269,41003,143497,5293,43169,131073,131072,2184,4116,4112,173,136364,1213,135680]

theorem envBound51050 : H12AffineFastState.Bounded env51050 := by
  intro p hp
  have h : env51050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51049_51050 : H12AffineEnvironment.transform 13 1213 env51049 = env51050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env51049 == env51050) = true)

theorem identity51050 : scanCanonicalize (H12AffineFastState.compose env51050 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound51050 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env51051 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,40985,47249,46105,32769,4096,46141,42164,41003,37008,5293,43169,40984,40985,2184,4116,4112,173,46261,1213,45593]

theorem envBound51051 : H12AffineFastState.Bounded env51051 := by
  intro p hp
  have h : env51051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51050_51051 : H12AffineEnvironment.transform 16 40985 env51050 = env51051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env51050 == env51051) = true)

theorem identity51051 : scanCanonicalize (H12AffineFastState.compose env51051 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 15551) := by decide +kernel

theorem selectedBound51051 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env51052 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,15551,13375,7334,1070,2214,15550,4096,2178,6155,7316,11311,5293,5150,7335,7334,2184,4116,4112,173,2058,1213,3750]

theorem envBound51052 : H12AffineFastState.Bounded env51052 := by
  intro p hp
  have h : env51052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51051_51052 : H12AffineEnvironment.transform 14 15551 env51051 = env51052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15551 env51051 == env51052) = true)

theorem identity51052 : scanCanonicalize (H12AffineFastState.compose env51052 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound51052 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51053 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,11270,9350,3103,1070,2214,11271,185,2178,2226,3117,11311,1044,1191,3102,3103,2184,173,169,173,2058,1213,3750]

theorem envBound51053 : H12AffineFastState.Bounded env51053 := by
  intro p hp
  have h : env51053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51052_51053 : H12AffineEnvironment.transform 11 185 env51052 = env51053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env51052 == env51053) = true)

theorem identity51053 : scanCanonicalize (H12AffineFastState.compose env51053 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound51053 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51054 : List Nat := [2,4,8,16,32,17,128,172,512,1024,560,185,8192,1213,9782,9350,1583,1070,662,9783,185,690,642,1565,9759,1044,1191,1582,1583,696,173,169,173,570,1213,1174]

theorem envBound51054 : H12AffineFastState.Bounded env51054 := by
  intro p hp
  have h : env51054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51053_51054 : H12AffineEnvironment.transform 10 560 env51053 = env51054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env51053 == env51054) = true)

theorem identity51054 : scanCanonicalize (H12AffineFastState.compose env51054 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound51054 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env51055 : List Nat := [2,4,8,16,32,17,128,172,512,1024,560,185,1172,1213,674,18,1583,1070,662,675,185,690,642,1565,651,1044,1191,1582,1583,696,173,169,173,570,1213,1174]

theorem envBound51055 : H12AffineFastState.Bounded env51055 := by
  intro p hp
  have h : env51055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51054_51055 : H12AffineEnvironment.transform 12 1172 env51054 = env51055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env51054 == env51055) = true)

theorem identity51055 : scanCanonicalize (H12AffineFastState.compose env51055 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound51055 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env51056 : List Nat := [2,4,8,16,32,17,128,172,147,1024,163,185,1172,1213,49,18,1212,1070,5,48,185,33,17,1166,24,1044,1191,1213,1212,43,173,169,173,169,1213,1174]

theorem envBound51056 : H12AffineFastState.Bounded env51056 := by
  intro p hp
  have h : env51056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51055_51056 : H12AffineEnvironment.transform 8 147 env51055 = env51056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env51055 == env51056) = true)

theorem identity51056 : scanCanonicalize (H12AffineFastState.compose env51056 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound51056 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env51057 : List Nat := [2,4,8,16,32,17,63,19,44,1024,28,6,1067,1026,49,18,1027,1070,5,48,6,33,17,1073,24,1044,1048,1026,1027,43,18,22,18,22,1026,1065]

theorem envBound51057 : H12AffineFastState.Bounded env51057 := by
  intro p hp
  have h : env51057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51056_51057 : H12AffineEnvironment.transform 6 63 env51056 = env51057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env51056 == env51057) = true)

theorem identity51057 : scanCanonicalize (H12AffineFastState.compose env51057 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound51057 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51058 : List Nat := [2,4,8,16,22,17,9,19,26,1024,28,6,1053,1026,7,18,1027,1048,5,6,6,23,17,1031,24,1044,1048,1026,1027,29,18,22,18,22,1026,1055]

theorem envBound51058 : H12AffineFastState.Bounded env51058 := by
  intro p hp
  have h : env51058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51057_51058 : H12AffineEnvironment.transform 4 22 env51057 = env51058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env51057 == env51058) = true)

theorem identity51058 : scanCanonicalize (H12AffineFastState.compose env51058 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound51058 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env51059 : List Nat := [2,4,8,16,22,17,9,19,26,30,28,6,3,28,7,18,29,6,5,6,6,23,17,25,24,10,6,28,29,29,18,22,18,22,28,1]

theorem envBound51059 : H12AffineFastState.Bounded env51059 := by
  intro p hp
  have h : env51059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51058_51059 : H12AffineEnvironment.transform 9 30 env51058 = env51059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env51058 == env51059) = true)

theorem identity51059 : scanCanonicalize (H12AffineFastState.compose env51059 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51059 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51060 : List Nat := [2,4,8,10,12,11,9,9,0,4,6,6,3,6,7,8,7,6,5,6,6,13,11,3,2,10,6,6,7,7,8,12,8,12,6,1]

theorem envBound51060 : H12AffineFastState.Bounded env51060 := by
  intro p hp
  have h : env51060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51059_51060 : H12AffineEnvironment.transform 3 10 env51059 = env51060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51059 == env51060) = true)

theorem identity51060 : scanCanonicalize (H12AffineFastState.compose env51060 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51061 : List Nat := [0,4,8,8,12,9,9,9,0,4,4,4,1,4,5,8,5,4,5,4,4,13,9,1,0,8,4,4,5,5,8,12,8,12,4,1]

theorem envBound51061 : H12AffineFastState.Bounded env51061 := by
  intro p hp
  have h : env51061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51060_51061 : H12AffineEnvironment.transform 0 0 env51060 = env51061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51060 == env51061) = true)

theorem identity51061 : scanCanonicalize (H12AffineFastState.compose env51061 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51062 : List Nat := [0,4,5,5,1,4,4,4,0,4,4,4,1,4,5,5,5,4,5,4,4,0,4,1,0,5,4,4,5,5,5,1,5,1,4,1]

theorem envBound51062 : H12AffineFastState.Bounded env51062 := by
  intro p hp
  have h : env51062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51061_51062 : H12AffineEnvironment.transform 2 5 env51061 = env51062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51061 == env51062) = true)

theorem identity51062 : scanCanonicalize (H12AffineFastState.compose env51062 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51062 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51063 : List Nat := [0,0,1,1,1,0,0,0,0,0,0,0,1,0,1,1,1,0,1,0,0,0,0,1,0,1,0,0,1,1,1,1,1,1,0,1]

theorem envBound51063 : H12AffineFastState.Bounded env51063 := by
  intro p hp
  have h : env51063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51062_51063 : H12AffineEnvironment.transform 1 0 env51062 = env51063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51062 == env51063) = true)

def env51064 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,492614,148716,148717,96347,74795,74799,172,222335,1261,135680]

theorem envBound51064 : H12AffineFastState.Bounded env51064 := by
  intro p hp
  have h : env51064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51028_51064 : H12AffineEnvironment.transform 7 173 env51028 = env51064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51028 == env51064) = true)

def env51065 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143497,20496,492566,148668,148669,96267,74795,74799,172,222255,1213,135680]

theorem envBound51065 : H12AffineFastState.Bounded env51065 := by
  intro p hp
  have h : env51065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51064_51065 : H12AffineEnvironment.transform 5 16 env51064 = env51065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51064 == env51065) = true)

theorem identity51065 : scanCanonicalize (H12AffineFastState.compose env51065 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound51065 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51066 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61569,98355,41003,127147,20496,279604,99486,99487,96267,74795,74799,172,41997,1213,119330]

theorem envBound51066 : H12AffineFastState.Bounded env51066 := by
  intro p hp
  have h : env51066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51065_51066 : H12AffineEnvironment.transform 16 114722 env51065 = env51066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env51065 == env51066) = true)

theorem identity51066 : scanCanonicalize (H12AffineFastState.compose env51066 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 122031) := by decide +kernel

theorem selectedBound51066 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51067 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,122031,119842,32769,4096,61569,98355,41003,127147,20496,104603,99486,99487,96267,74795,74799,172,41997,1213,119330]

theorem envBound51067 : H12AffineFastState.Bounded env51067 := by
  intro p hp
  have h : env51067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51066_51067 : H12AffineEnvironment.transform 17 122031 env51066 = env51067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122031 env51066 == env51067) = true)

theorem identity51067 : scanCanonicalize (H12AffineFastState.compose env51067 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound51067 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env51068 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,3213,1024,32769,4096,61569,20497,41003,8329,20496,18617,21692,21693,43049,62473,62477,172,41997,1213,512]

theorem envBound51068 : H12AffineFastState.Bounded env51068 := by
  intro p hp
  have h : env51068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51067_51068 : H12AffineEnvironment.transform 15 53282 env51067 = env51068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env51067 == env51068) = true)

theorem identity51068 : scanCanonicalize (H12AffineFastState.compose env51068 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound51068 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51069 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,12347,4096,3213,1024,24600,4096,4248,20497,16434,8329,20496,18617,21692,21693,18480,5136,5140,172,17428,1213,512]

theorem envBound51069 : H12AffineFastState.Bounded env51069 := by
  intro p hp
  have h : env51069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51068_51069 : H12AffineEnvironment.transform 14 24601 env51068 = env51069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env51068 == env51069) = true)

theorem identity51069 : scanCanonicalize (H12AffineFastState.compose env51069 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound51069 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51070 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8745,560,12347,4096,3213,1024,561,4096,4248,12856,8731,8329,12857,10896,13973,13972,10777,5136,5140,172,9789,1213,512]

theorem envBound51070 : H12AffineFastState.Bounded env51070 := by
  intro p hp
  have h : env51070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51069_51070 : H12AffineEnvironment.transform 13 8745 env51069 = env51070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env51069 == env51070) = true)

theorem identity51070 : scanCanonicalize (H12AffineFastState.compose env51070 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound51070 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51071 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1167,1702,560,5300,4096,3213,1024,561,4096,4248,5815,1684,1030,5814,3615,4634,4635,3734,5136,5140,172,690,1213,512]

theorem envBound51071 : H12AffineFastState.Bounded env51071 := by
  intro p hp
  have h : env51071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51070_51071 : H12AffineEnvironment.transform 12 1167 env51070 = env51071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env51070 == env51071) = true)

theorem identity51071 : scanCanonicalize (H12AffineFastState.compose env51071 (packedSelected [0,2,3,5,9,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound51071 : packedSelected [0,2,3,5,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env51072 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3076,1167,1702,560,2224,3076,3213,1024,561,3076,3228,2739,1684,1030,2738,3615,3614,3615,3734,2068,2064,172,690,1213,512]

theorem envBound51072 : H12AffineFastState.Bounded env51072 := by
  intro p hp
  have h : env51072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51071_51072 : H12AffineEnvironment.transform 11 3076 env51071 = env51072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env51071 == env51072) = true)

theorem identity51072 : scanCanonicalize (H12AffineFastState.compose env51072 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound51072 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51073 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,1703,1167,1702,560,531,1703,1582,1024,561,1703,1599,16,1684,1030,17,1212,1213,1212,1077,695,691,172,690,1213,512]

theorem envBound51073 : H12AffineFastState.Bounded env51073 := by
  intro p hp
  have h : env51073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51072_51073 : H12AffineEnvironment.transform 10 675 env51072 = env51073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env51072 == env51073) = true)

theorem identity51073 : scanCanonicalize (H12AffineFastState.compose env51073 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound51073 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env51074 : List Nat := [2,4,8,16,32,16,128,173,136,1024,43,1071,1167,1070,184,155,1071,1190,1024,185,1071,1207,16,1052,1030,17,1212,1213,1212,1077,63,59,172,58,1213,136]

theorem envBound51074 : H12AffineFastState.Bounded env51074 := by
  intro p hp
  have h : env51074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51073_51074 : H12AffineEnvironment.transform 8 136 env51073 = env51074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env51073 == env51074) = true)

theorem identity51074 : scanCanonicalize (H12AffineFastState.compose env51074 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound51074 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env51075 : List Nat := [2,4,8,16,32,16,19,62,27,1024,43,1071,1052,1070,43,8,1071,1077,1024,42,1071,1060,16,1052,1030,17,1071,1070,1071,1077,63,59,63,58,1070,27]

theorem envBound51075 : H12AffineFastState.Bounded env51075 := by
  intro p hp
  have h : env51075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51074_51075 : H12AffineEnvironment.transform 6 19 env51074 = env51075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env51074 == env51075) = true)

theorem identity51075 : scanCanonicalize (H12AffineFastState.compose env51075 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51075 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env51076 : List Nat := [2,4,8,16,17,16,19,15,27,1024,26,1054,1052,1055,26,8,1054,1028,1024,27,1054,1045,16,1052,1030,17,1054,1055,1054,1028,14,10,14,11,1055,27]

theorem envBound51076 : H12AffineFastState.Bounded env51076 := by
  intro p hp
  have h : env51076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51075_51076 : H12AffineEnvironment.transform 4 17 env51075 = env51076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51075 == env51076) = true)

theorem identity51076 : scanCanonicalize (H12AffineFastState.compose env51076 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51076 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env51077 : List Nat := [2,4,8,10,11,10,9,15,1,1024,0,1028,1030,1029,0,8,1028,1028,1024,1,1028,1039,10,1030,1030,11,1028,1029,1028,1028,14,10,14,11,1029,1]

theorem envBound51077 : H12AffineFastState.Bounded env51077 := by
  intro p hp
  have h : env51077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51076_51077 : H12AffineEnvironment.transform 3 10 env51076 = env51077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51076 == env51077) = true)

theorem identity51077 : scanCanonicalize (H12AffineFastState.compose env51077 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound51077 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51078 : List Nat := [2,4,8,10,11,10,9,15,1,4,0,0,2,1,0,8,0,0,4,1,0,11,10,2,2,11,0,1,0,0,14,10,14,11,1,1]

theorem envBound51078 : H12AffineFastState.Bounded env51078 := by
  intro p hp
  have h : env51078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51077_51078 : H12AffineEnvironment.transform 9 4 env51077 = env51078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env51077 == env51078) = true)

theorem identity51078 : scanCanonicalize (H12AffineFastState.compose env51078 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51078 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51079 : List Nat := [2,4,5,7,6,7,4,2,1,4,0,0,2,1,0,5,0,0,4,1,0,6,7,2,2,6,0,1,0,0,3,7,3,6,1,1]

end H12CloudChart2