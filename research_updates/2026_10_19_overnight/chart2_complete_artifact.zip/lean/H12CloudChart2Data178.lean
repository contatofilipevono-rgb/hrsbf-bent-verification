import H12CloudChart2Data177

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env44612 : List Nat := [2,4,8,11,32,3,9,15,1,13,34,1,2,8,9,35,0,43,12,8,0,3,10,40,3,3,42,9,8,8,14,11,14,2,0,0]

theorem envBound44612 : H12AffineFastState.Bounded env44612 := by
  intro p hp
  have h : env44612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44611_44612 : H12AffineEnvironment.transform 5 3 env44611 = env44612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env44611 == env44612) = true)

theorem identity44612 : scanCanonicalize (H12AffineFastState.compose env44612 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44612 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44613 : List Nat := [2,4,8,11,10,3,9,15,1,13,8,1,2,8,9,9,0,1,12,8,0,3,10,2,3,3,0,9,8,8,14,11,14,2,0,0]

theorem envBound44613 : H12AffineFastState.Bounded env44613 := by
  intro p hp
  have h : env44613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44612_44613 : H12AffineEnvironment.transform 4 10 env44612 = env44613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44612 == env44613) = true)

theorem identity44613 : scanCanonicalize (H12AffineFastState.compose env44613 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound44613 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44614 : List Nat := [2,4,0,3,2,3,1,7,1,5,0,1,2,0,1,1,0,1,4,0,0,3,2,2,3,3,0,1,0,0,6,3,6,2,0,0]

theorem envBound44614 : H12AffineFastState.Bounded env44614 := by
  intro p hp
  have h : env44614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44613_44614 : H12AffineEnvironment.transform 2 0 env44613 = env44614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env44613 == env44614) = true)

theorem identity44614 : scanCanonicalize (H12AffineFastState.compose env44614 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44615 : List Nat := [2,2,0,3,2,3,1,1,1,3,0,1,2,0,1,1,0,1,2,0,0,3,2,2,3,3,0,1,0,0,0,3,0,2,0,0]

theorem envBound44615 : H12AffineFastState.Bounded env44615 := by
  intro p hp
  have h : env44615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44614_44615 : H12AffineEnvironment.transform 1 2 env44614 = env44615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44614 == env44615) = true)

theorem identity44615 : scanCanonicalize (H12AffineFastState.compose env44615 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44615 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44616 : List Nat := [1,1,0,0,1,0,1,1,1,0,0,1,1,0,1,1,0,1,1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,1,0,0]

theorem envBound44616 : H12AffineFastState.Bounded env44616 := by
  intro p hp
  have h : env44616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44615_44616 : H12AffineEnvironment.transform 0 1 env44615 = env44616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44615 == env44616) = true)

def env44617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123164,28888,78895,385203,90415,1296,96346,25885,82998,257,1281,1345,21073]

theorem envBound44617 : H12AffineFastState.Bounded env44617 := by
  intro p hp
  have h : env44617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44515_44617 : H12AffineEnvironment.transform 18 21585 env44515 = env44617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env44515 == env44617) = true)

theorem identity44617 : scanCanonicalize (H12AffineFastState.compose env44617 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound44617 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4097,17612,91182,87296,28888,78895,349359,90415,1296,96346,25885,82998,257,1281,1345,21073]

theorem envBound44618 : H12AffineFastState.Bounded env44618 := by
  intro p hp
  have h : env44618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44617_44618 : H12AffineEnvironment.transform 14 13340 env44617 = env44618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env44617 == env44618) = true)

def env44619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4097,476,74046,69648,13768,78895,332223,74815,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound44619 : H12AffineFastState.Bounded env44619 := by
  intro p hp
  have h : env44619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44618_44619 : H12AffineEnvironment.transform 13 1296 env44618 = env44619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44618 == env44619) = true)

def env44620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4097,476,74046,69648,13768,78895,4415,74815,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound44620 : H12AffineFastState.Bounded env44620 := by
  intro p hp
  have h : env44620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_44620 : H12AffineEnvironment.transform 17 65664 env44619 = env44620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44619 == env44620) = true)

theorem identity44620 : scanCanonicalize (H12AffineFastState.compose env44620 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound44620 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5159,12360,5287,4417,13341,4097,476,13593,1079,13768,8200,4415,12312,1296,10605,8205,5377,257,1281,1345,5953]

theorem envBound44621 : H12AffineFastState.Bounded env44621 := by
  intro p hp
  have h : env44621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44620_44621 : H12AffineEnvironment.transform 15 5159 env44620 = env44621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env44620 == env44621) = true)

def env44622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,5159,1344,5287,4417,277,4097,476,17,1079,192,5376,4415,1296,1296,7269,5381,5377,257,1281,1345,5953]

theorem envBound44622 : H12AffineFastState.Bounded env44622 := by
  intro p hp
  have h : env44622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_44622 : H12AffineEnvironment.transform 12 5384 env44621 = env44622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env44621 == env44622) = true)

theorem identity44622 : scanCanonicalize (H12AffineFastState.compose env44622 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44622 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44623 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,0,276,4407,80,4535,4417,277,4097,476,17,295,192,4112,4415,0,0,6517,4117,4113,257,17,81,4689]

theorem envBound44623 : H12AffineFastState.Bounded env44623 := by
  intro p hp
  have h : env44623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44622_44623 : H12AffineEnvironment.transform 9 272 env44622 = env44623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44622 == env44623) = true)

theorem identity44623 : scanCanonicalize (H12AffineFastState.compose env44623 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound44623 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44624 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,4096,4120,0,185,4250,80,4122,4332,184,4097,113,17,138,192,4112,4242,0,0,6360,4117,4113,172,17,81,4689]

theorem envBound44624 : H12AffineFastState.Bounded env44624 := by
  intro p hp
  have h : env44624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44623_44624 : H12AffineEnvironment.transform 7 173 env44623 = env44624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44623 == env44624) = true)

theorem identity44624 : scanCanonicalize (H12AffineFastState.compose env44624 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound44624 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44625 : List Nat := [2,4,8,16,32,64,128,173,512,189,538,4096,4120,0,185,4250,80,4122,4332,184,4097,113,17,138,192,4112,4242,0,0,4802,4117,4113,172,17,81,4689]

theorem envBound44625 : H12AffineFastState.Bounded env44625 := by
  intro p hp
  have h : env44625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44624_44625 : H12AffineEnvironment.transform 10 538 env44624 = env44625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env44624 == env44625) = true)

theorem identity44625 : scanCanonicalize (H12AffineFastState.compose env44625 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44625 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env44626 : List Nat := [2,4,8,16,32,64,18,63,512,47,538,4096,4120,0,43,4104,80,4122,4222,42,4097,113,17,24,82,4112,4096,0,0,4688,4117,4113,62,17,81,4689]

theorem envBound44626 : H12AffineFastState.Bounded env44626 := by
  intro p hp
  have h : env44626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44625_44626 : H12AffineEnvironment.transform 6 18 env44625 = env44626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44625 == env44626) = true)

theorem identity44626 : scanCanonicalize (H12AffineFastState.compose env44626 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 74) := by decide +kernel

theorem selectedBound44626 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44627 : List Nat := [2,4,8,16,32,64,18,63,512,47,538,74,82,0,43,66,80,80,52,42,75,113,17,24,82,90,74,0,0,538,95,91,62,17,81,539]

theorem envBound44627 : H12AffineFastState.Bounded env44627 := by
  intro p hp
  have h : env44627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44626_44627 : H12AffineEnvironment.transform 11 74 env44626 = env44627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 74 env44626 == env44627) = true)

theorem identity44627 : scanCanonicalize (H12AffineFastState.compose env44627 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound44627 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env44628 : List Nat := [2,4,8,16,32,64,18,63,123,47,97,74,82,0,43,66,80,80,52,42,75,113,17,24,82,90,74,0,0,97,95,91,62,17,81,96]

theorem envBound44628 : H12AffineFastState.Bounded env44628 := by
  intro p hp
  have h : env44628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44627_44628 : H12AffineEnvironment.transform 8 123 env44627 = env44628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env44627 == env44628) = true)

theorem identity44628 : scanCanonicalize (H12AffineFastState.compose env44628 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44628 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44629 : List Nat := [2,4,8,11,32,64,9,36,96,47,97,74,73,0,43,66,75,75,47,42,75,106,10,3,73,65,74,0,0,97,68,64,37,10,74,96]

theorem envBound44629 : H12AffineFastState.Bounded env44629 := by
  intro p hp
  have h : env44629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44628_44629 : H12AffineEnvironment.transform 3 11 env44628 = env44629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44628 == env44629) = true)

theorem identity44629 : scanCanonicalize (H12AffineFastState.compose env44629 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound44629 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44630 : List Nat := [2,4,8,11,32,33,9,36,1,47,0,43,40,0,43,35,42,42,47,42,42,11,10,3,40,32,43,0,0,0,37,33,37,10,43,1]

theorem envBound44630 : H12AffineFastState.Bounded env44630 := by
  intro p hp
  have h : env44630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44629_44630 : H12AffineEnvironment.transform 5 33 env44629 = env44630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env44629 == env44630) = true)

def env44631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,5159,1345,5287,4417,276,4097,476,16,1079,193,5377,4415,1297,1296,7268,5380,5377,257,1281,1345,5953]

theorem envBound44631 : H12AffineFastState.Bounded env44631 := by
  intro p hp
  have h : env44631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_44631 : H12AffineEnvironment.transform 12 5385 env44621 = env44631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env44621 == env44631) = true)

theorem identity44631 : scanCanonicalize (H12AffineFastState.compose env44631 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44631 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44632 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4365,276,277,4131,325,4259,4417,276,4097,476,16,51,193,4357,4415,277,276,6240,4352,4357,257,261,325,4933]

theorem envBound44632 : H12AffineFastState.Bounded env44632 := by
  intro p hp
  have h : env44632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44631_44632 : H12AffineEnvironment.transform 9 4 env44631 = env44632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44631 == env44632) = true)

theorem identity44632 : scanCanonicalize (H12AffineFastState.compose env44632 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 998) := by decide +kernel

theorem selectedBound44632 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44633 : List Nat := [2,4,8,16,32,64,128,256,512,4,998,4096,4365,276,277,4131,325,4259,4417,276,4097,476,16,51,193,4357,4415,277,276,4998,4352,4357,257,261,325,4933]

theorem envBound44633 : H12AffineFastState.Bounded env44633 := by
  intro p hp
  have h : env44633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44632_44633 : H12AffineEnvironment.transform 10 998 env44632 = env44633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 998 env44632 == env44633) = true)

theorem identity44633 : scanCanonicalize (H12AffineFastState.compose env44633 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound44633 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env44634 : List Nat := [2,4,8,16,32,64,128,256,512,4,998,508,241,276,277,479,325,351,189,276,509,476,16,51,193,249,195,277,276,634,252,249,257,261,325,697]

theorem envBound44634 : H12AffineFastState.Bounded env44634 := by
  intro p hp
  have h : env44634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44633_44634 : H12AffineEnvironment.transform 11 508 env44633 = env44634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env44633 == env44634) = true)

theorem identity44634 : scanCanonicalize (H12AffineFastState.compose env44634 (packedSelected [2,4,5,8,9,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound44634 : packedSelected [2,4,5,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env44635 : List Nat := [2,4,8,16,32,64,128,256,97,4,391,508,241,276,277,479,325,351,189,276,509,476,16,51,193,249,195,277,276,27,252,249,257,261,325,216]

theorem envBound44635 : H12AffineFastState.Bounded env44635 := by
  intro p hp
  have h : env44635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44634_44635 : H12AffineEnvironment.transform 8 97 env44634 = env44635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env44634 == env44635) = true)

theorem identity44635 : scanCanonicalize (H12AffineFastState.compose env44635 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound44635 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env44636 : List Nat := [2,4,8,16,32,59,128,256,26,4,391,391,138,276,277,420,318,292,189,276,390,423,16,51,186,130,184,277,276,27,135,130,257,261,318,163]

theorem envBound44636 : H12AffineFastState.Bounded env44636 := by
  intro p hp
  have h : env44636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44635_44636 : H12AffineEnvironment.transform 5 59 env44635 = env44636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env44635 == env44636) = true)

theorem identity44636 : scanCanonicalize (H12AffineFastState.compose env44636 (packedSelected [1,3,4,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44636 : packedSelected [1,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44637 : List Nat := [2,4,8,16,32,59,18,256,26,4,277,277,24,276,277,310,318,292,47,276,276,309,16,51,40,16,42,277,276,27,21,16,257,261,318,49]

theorem envBound44637 : H12AffineFastState.Bounded env44637 := by
  intro p hp
  have h : env44637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44636_44637 : H12AffineEnvironment.transform 6 18 env44636 = env44637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44636 == env44637) = true)

theorem identity44637 : scanCanonicalize (H12AffineFastState.compose env44637 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44637 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env44638 : List Nat := [2,4,8,16,32,59,18,20,26,4,1,1,24,0,1,34,42,48,47,0,0,33,16,51,40,16,42,1,0,27,21,16,21,17,42,49]

theorem envBound44638 : H12AffineFastState.Bounded env44638 := by
  intro p hp
  have h : env44638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44637_44638 : H12AffineEnvironment.transform 7 20 env44637 = env44638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44637 == env44638) = true)

theorem identity44638 : scanCanonicalize (H12AffineFastState.compose env44638 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44639 : List Nat := [2,4,8,10,32,33,8,14,0,4,1,1,2,0,1,34,42,42,47,0,0,33,10,41,40,10,42,1,0,1,15,10,15,11,42,43]

theorem envBound44639 : H12AffineFastState.Bounded env44639 := by
  intro p hp
  have h : env44639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44638_44639 : H12AffineEnvironment.transform 3 10 env44638 = env44639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44638 == env44639) = true)

theorem identity44639 : scanCanonicalize (H12AffineFastState.compose env44639 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound44639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44640 : List Nat := [2,4,8,10,6,7,8,14,0,4,1,1,2,0,1,4,12,12,9,0,0,7,10,15,14,10,12,1,0,1,15,10,15,11,12,13]

theorem envBound44640 : H12AffineFastState.Bounded env44640 := by
  intro p hp
  have h : env44640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44639_44640 : H12AffineEnvironment.transform 4 6 env44639 = env44640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env44639 == env44640) = true)

theorem identity44640 : scanCanonicalize (H12AffineFastState.compose env44640 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44640 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44641 : List Nat := [2,4,4,6,6,7,4,2,0,4,1,1,2,0,1,4,0,0,5,0,0,7,6,3,2,6,0,1,0,1,3,6,3,7,0,1]

theorem envBound44641 : H12AffineFastState.Bounded env44641 := by
  intro p hp
  have h : env44641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44640_44641 : H12AffineEnvironment.transform 2 4 env44640 = env44641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44640 == env44641) = true)

theorem identity44641 : scanCanonicalize (H12AffineFastState.compose env44641 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44642 : List Nat := [2,1,1,3,3,2,1,2,0,1,1,1,2,0,1,1,0,0,0,0,0,2,3,3,2,3,0,1,0,1,3,3,3,2,0,1]

theorem envBound44642 : H12AffineFastState.Bounded env44642 := by
  intro p hp
  have h : env44642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44641_44642 : H12AffineEnvironment.transform 1 1 env44641 = env44642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44641 == env44642) = true)

theorem identity44642 : scanCanonicalize (H12AffineFastState.compose env44642 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44642 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44643 : List Nat := [1,1,1,0,0,1,1,1,0,1,1,1,1,0,1,1,0,0,0,0,0,1,0,0,1,0,0,1,0,1,0,0,0,1,0,1]

theorem envBound44643 : H12AffineFastState.Bounded env44643 := by
  intro p hp
  have h : env44643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44642_44643 : H12AffineEnvironment.transform 0 1 env44642 = env44643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44642 == env44643) = true)

def env44644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4097,476,74046,69648,13768,78895,4414,74815,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound44644 : H12AffineFastState.Bounded env44644 := by
  intro p hp
  have h : env44644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_44644 : H12AffineEnvironment.transform 17 65665 env44619 = env44644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44619 == env44644) = true)

theorem identity44644 : scanCanonicalize (H12AffineFastState.compose env44644 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound44644 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,359,9480,486,4417,13341,4097,476,8281,4471,13768,13640,4414,9560,1296,15405,8205,65,257,1281,1345,5953]

theorem envBound44645 : H12AffineFastState.Bounded env44645 := by
  intro p hp
  have h : env44645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44644_44645 : H12AffineEnvironment.transform 15 359 env44644 = env44645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env44644 == env44645) = true)

def env44646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,359,1344,486,4417,5205,4097,476,17,4471,5504,5376,4414,1296,1296,7269,69,65,257,1281,1345,5953]

theorem envBound44646 : H12AffineFastState.Bounded env44646 := by
  intro p hp
  have h : env44646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44645_44646 : H12AffineEnvironment.transform 12 72 env44645 = env44646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44645 == env44646) = true)

theorem identity44646 : scanCanonicalize (H12AffineFastState.compose env44646 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound44646 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1296,1028,359,1344,486,273,1029,81,476,17,295,1488,1360,366,1296,1296,3125,69,65,257,1281,1345,1809]

theorem envBound44647 : H12AffineFastState.Bounded env44647 := by
  intro p hp
  have h : env44647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44646_44647 : H12AffineEnvironment.transform 11 80 env44646 = env44647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env44646 == env44647) = true)

theorem identity44647 : scanCanonicalize (H12AffineFastState.compose env44647 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound44647 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44648 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,72,1213,1028,202,1261,75,188,1029,81,113,17,138,1149,1277,195,1213,1213,3125,69,65,172,1196,1260,1724]

theorem envBound44648 : H12AffineFastState.Bounded env44648 := by
  intro p hp
  have h : env44648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44647_44648 : H12AffineEnvironment.transform 7 173 env44647 = env44648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44647 == env44648) = true)

theorem identity44648 : scanCanonicalize (H12AffineFastState.compose env44648 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound44648 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44649 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1702,80,72,1213,1028,202,1261,75,188,1029,81,113,17,138,1149,1277,195,1213,1213,659,69,65,172,1196,1260,1724]

theorem envBound44649 : H12AffineFastState.Bounded env44649 := by
  intro p hp
  have h : env44649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44648_44649 : H12AffineEnvironment.transform 10 1702 env44648 = env44649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env44648 == env44649) = true)

theorem identity44649 : scanCanonicalize (H12AffineFastState.compose env44649 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound44649 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env44650 : List Nat := [2,4,8,16,32,64,128,173,512,47,649,80,72,146,43,202,194,75,188,42,81,113,17,138,82,210,195,146,146,659,69,65,172,131,195,659]

theorem envBound44650 : H12AffineFastState.Bounded env44650 := by
  intro p hp
  have h : env44650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44649_44650 : H12AffineEnvironment.transform 9 47 env44649 = env44650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env44649 == env44650) = true)

theorem identity44650 : scanCanonicalize (H12AffineFastState.compose env44650 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44650 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44651 : List Nat := [2,4,8,11,32,64,128,173,512,47,649,75,72,137,43,202,194,75,167,42,74,106,10,138,73,201,195,137,137,648,69,65,172,131,195,648]

theorem envBound44651 : H12AffineFastState.Bounded env44651 := by
  intro p hp
  have h : env44651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44650_44651 : H12AffineEnvironment.transform 3 11 env44650 = env44651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44650 == env44651) = true)

theorem identity44651 : scanCanonicalize (H12AffineFastState.compose env44651 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound44651 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44652 : List Nat := [2,4,8,11,32,64,128,173,137,47,0,75,72,137,43,202,194,75,167,42,74,106,10,138,73,201,195,137,137,1,69,65,172,131,195,1]

theorem envBound44652 : H12AffineFastState.Bounded env44652 := by
  intro p hp
  have h : env44652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44651_44652 : H12AffineEnvironment.transform 8 137 env44651 = env44652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env44651 == env44652) = true)

theorem identity44652 : scanCanonicalize (H12AffineFastState.compose env44652 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound44652 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44653 : List Nat := [2,4,8,11,32,11,128,173,137,47,0,0,3,137,43,129,137,0,167,42,1,33,10,138,2,130,136,137,137,1,14,10,172,131,136,1]

theorem envBound44653 : H12AffineFastState.Bounded env44653 := by
  intro p hp
  have h : env44653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44652_44653 : H12AffineEnvironment.transform 5 11 env44652 = env44653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env44652 == env44653) = true)

theorem identity44653 : scanCanonicalize (H12AffineFastState.compose env44653 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44653 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44654 : List Nat := [2,4,8,11,32,11,8,37,1,47,0,0,3,1,43,9,1,0,47,42,1,33,10,2,2,10,0,1,1,1,14,10,36,11,0,1]

theorem envBound44654 : H12AffineFastState.Bounded env44654 := by
  intro p hp
  have h : env44654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44653_44654 : H12AffineEnvironment.transform 6 8 env44653 = env44654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44653 == env44654) = true)

theorem identity44654 : scanCanonicalize (H12AffineFastState.compose env44654 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44655 : List Nat := [2,4,8,11,7,11,8,2,1,8,0,0,3,1,12,9,1,0,8,13,1,6,10,2,2,10,0,1,1,1,14,10,3,11,0,1]

theorem envBound44655 : H12AffineFastState.Bounded env44655 := by
  intro p hp
  have h : env44655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44654_44655 : H12AffineEnvironment.transform 4 7 env44654 = env44655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44654 == env44655) = true)

theorem identity44655 : scanCanonicalize (H12AffineFastState.compose env44655 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44656 : List Nat := [2,4,4,7,7,7,4,2,1,4,0,0,3,1,0,5,1,0,4,1,1,6,6,2,2,6,0,1,1,1,2,6,3,7,0,1]

theorem envBound44656 : H12AffineFastState.Bounded env44656 := by
  intro p hp
  have h : env44656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44655_44656 : H12AffineEnvironment.transform 2 4 env44655 = env44656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44655 == env44656) = true)

def env44657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,359,1345,486,4417,5204,4097,476,16,4471,5505,5377,4414,1297,1296,7268,68,65,257,1281,1345,5953]

theorem envBound44657 : H12AffineFastState.Bounded env44657 := by
  intro p hp
  have h : env44657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44645_44657 : H12AffineEnvironment.transform 12 73 env44645 = env44657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env44645 == env44657) = true)

theorem identity44657 : scanCanonicalize (H12AffineFastState.compose env44657 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44657 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44658 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,73,276,4177,359,325,486,4417,4176,4097,476,16,4471,4485,4357,4414,277,276,6240,68,65,257,261,325,4933]

theorem envBound44658 : H12AffineFastState.Bounded env44658 := by
  intro p hp
  have h : env44658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44657_44658 : H12AffineEnvironment.transform 9 4 env44657 = env44658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44657 == env44658) = true)

theorem identity44658 : scanCanonicalize (H12AffineFastState.compose env44658 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound44658 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44659 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,325,73,276,276,359,325,486,4,277,324,476,16,50,192,64,123,277,276,2341,68,65,257,261,325,512]

theorem envBound44659 : H12AffineFastState.Bounded env44659 := by
  intro p hp
  have h : env44659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44658_44659 : H12AffineEnvironment.transform 11 325 env44658 = env44659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env44658 == env44659) = true)

theorem identity44659 : scanCanonicalize (H12AffineFastState.compose env44659 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44659 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44660 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,25,276,276,311,277,438,4,277,276,396,16,50,144,16,43,277,276,2341,20,17,257,261,277,512]

theorem envBound44660 : H12AffineFastState.Bounded env44660 := by
  intro p hp
  have h : env44660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44659_44660 : H12AffineEnvironment.transform 5 16 env44659 = env44660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44659 == env44660) = true)

theorem identity44660 : scanCanonicalize (H12AffineFastState.compose env44660 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound44660 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44661 : List Nat := [2,4,8,16,32,16,128,256,512,4,512,277,25,276,276,311,277,438,4,277,276,396,16,50,144,16,43,277,276,805,20,17,257,261,277,512]

theorem envBound44661 : H12AffineFastState.Bounded env44661 := by
  intro p hp
  have h : env44661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44660_44661 : H12AffineEnvironment.transform 10 512 env44660 = env44661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env44660 == env44661) = true)

theorem identity44661 : scanCanonicalize (H12AffineFastState.compose env44661 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44661 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44662 : List Nat := [2,4,8,10,32,10,128,256,512,4,512,271,3,270,270,301,271,428,4,271,270,396,10,40,138,10,43,271,270,805,14,11,257,261,271,512]

theorem envBound44662 : H12AffineFastState.Bounded env44662 := by
  intro p hp
  have h : env44662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44661_44662 : H12AffineEnvironment.transform 3 10 env44661 = env44662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44661 == env44662) = true)

theorem identity44662 : scanCanonicalize (H12AffineFastState.compose env44662 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound44662 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env44663 : List Nat := [2,4,8,10,32,10,128,256,390,4,390,271,3,270,270,301,271,428,4,271,270,396,10,40,138,10,43,271,270,163,14,11,257,261,271,390]

theorem envBound44663 : H12AffineFastState.Bounded env44663 := by
  intro p hp
  have h : env44663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44662_44663 : H12AffineEnvironment.transform 8 390 env44662 = env44663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env44662 == env44663) = true)

theorem identity44663 : scanCanonicalize (H12AffineFastState.compose env44663 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound44663 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44664 : List Nat := [2,4,8,10,32,10,128,135,1,4,1,136,3,137,137,170,136,43,4,136,137,11,10,40,138,10,43,136,137,163,14,11,134,130,136,1]

theorem envBound44664 : H12AffineFastState.Bounded env44664 := by
  intro p hp
  have h : env44664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44663_44664 : H12AffineEnvironment.transform 7 135 env44663 = env44664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env44663 == env44664) = true)

theorem identity44664 : scanCanonicalize (H12AffineFastState.compose env44664 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound44664 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44665 : List Nat := [2,4,8,10,32,10,34,37,1,4,1,42,3,43,43,8,42,43,4,42,43,11,10,40,40,10,43,42,43,1,14,11,36,32,42,1]

theorem envBound44665 : H12AffineFastState.Bounded env44665 := by
  intro p hp
  have h : env44665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44664_44665 : H12AffineEnvironment.transform 6 34 env44664 = env44665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env44664 == env44665) = true)

theorem identity44665 : scanCanonicalize (H12AffineFastState.compose env44665 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44665 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44666 : List Nat := [2,4,8,10,10,10,8,15,1,4,1,0,3,1,1,8,0,1,4,0,1,11,10,2,2,10,1,0,1,1,14,11,14,10,0,1]

theorem envBound44666 : H12AffineFastState.Bounded env44666 := by
  intro p hp
  have h : env44666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44665_44666 : H12AffineEnvironment.transform 4 10 env44665 = env44666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44665 == env44666) = true)

theorem identity44666 : scanCanonicalize (H12AffineFastState.compose env44666 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44667 : List Nat := [2,4,5,7,7,7,5,2,1,4,1,0,3,1,1,5,0,1,4,0,1,6,7,2,2,7,1,0,1,1,3,6,3,7,0,1]

theorem envBound44667 : H12AffineFastState.Bounded env44667 := by
  intro p hp
  have h : env44667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44666_44667 : H12AffineEnvironment.transform 2 5 env44666 = env44667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44666 == env44667) = true)

def env44668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4097,477,74047,69649,13769,78895,332222,74814,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound44668 : H12AffineFastState.Bounded env44668 := by
  intro p hp
  have h : env44668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44618_44668 : H12AffineEnvironment.transform 13 1297 env44618 = env44668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44618 == env44668) = true)

def env44669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4097,477,74047,69649,13769,78895,4414,74814,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound44669 : H12AffineFastState.Bounded env44669 := by
  intro p hp
  have h : env44669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44668_44669 : H12AffineEnvironment.transform 17 65664 env44668 = env44669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44668 == env44669) = true)

theorem identity44669 : scanCanonicalize (H12AffineFastState.compose env44669 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound44669 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9327,0,9455,4416,13341,4097,477,1360,13438,13769,4160,4414,81,1296,6436,8204,9544,257,1281,1345,5952]

theorem envBound44670 : H12AffineFastState.Bounded env44670 := by
  intro p hp
  have h : env44670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44669_44670 : H12AffineEnvironment.transform 15 9327 env44669 = env44670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env44669 == env44670) = true)

def env44671 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,8495,0,8623,4416,12637,4097,477,16,12606,12425,4160,4414,81,80,6436,8204,8200,257,65,1,4608]

theorem envBound44671 : H12AffineFastState.Bounded env44671 := by
  intro p hp
  have h : env44671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44670_44671 : H12AffineEnvironment.transform 9 320 env44670 = env44671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44670 == env44671) = true)

theorem identity44671 : scanCanonicalize (H12AffineFastState.compose env44671 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound44671 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44672 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,81,4420,311,0,439,4416,4421,4097,477,16,4390,4241,4160,4414,81,80,6436,20,16,257,65,1,4608]

theorem envBound44672 : H12AffineFastState.Bounded env44672 := by
  intro p hp
  have h : env44672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44671_44672 : H12AffineEnvironment.transform 12 24 env44671 = env44672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env44671 == env44672) = true)

theorem identity44672 : scanCanonicalize (H12AffineFastState.compose env44672 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound44672 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44673 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,428,24,81,232,311,0,439,236,233,429,477,16,138,317,492,146,81,80,2184,20,16,257,65,1,940]

theorem envBound44673 : H12AffineFastState.Bounded env44673 := by
  intro p hp
  have h : env44673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44672_44673 : H12AffineEnvironment.transform 11 428 env44672 = env44673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env44672 == env44673) = true)

theorem identity44673 : scanCanonicalize (H12AffineFastState.compose env44673 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound44673 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44674 : List Nat := [2,4,8,16,32,64,128,256,96,320,2048,428,24,81,232,311,0,439,236,233,429,477,16,138,317,492,146,81,80,2184,20,16,257,65,1,460]

theorem envBound44674 : H12AffineFastState.Bounded env44674 := by
  intro p hp
  have h : env44674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44673_44674 : H12AffineEnvironment.transform 8 96 env44673 = env44674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env44673 == env44674) = true)

theorem identity44674 : scanCanonicalize (H12AffineFastState.compose env44674 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound44674 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44675 : List Nat := [2,4,8,16,32,64,128,256,96,320,81,428,24,81,232,311,0,439,236,233,429,477,16,138,317,492,146,81,80,217,20,16,257,65,1,460]

theorem envBound44675 : H12AffineFastState.Bounded env44675 := by
  intro p hp
  have h : env44675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44674_44675 : H12AffineEnvironment.transform 10 81 env44674 = env44675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env44674 == env44675) = true)

theorem identity44675 : scanCanonicalize (H12AffineFastState.compose env44675 (packedSelected [0,1,2,4,8,10,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44675 : packedSelected [0,1,2,4,8,10,13] rootPS < 2^1333 := by decide +kernel

def env44676 : List Nat := [2,4,8,16,16,64,128,256,80,320,81,412,24,81,216,263,0,391,220,217,413,477,16,138,269,476,146,81,80,217,20,16,257,65,1,460]

theorem envBound44676 : H12AffineFastState.Bounded env44676 := by
  intro p hp
  have h : env44676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44675_44676 : H12AffineEnvironment.transform 4 16 env44675 = env44676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44675 == env44676) = true)

theorem identity44676 : scanCanonicalize (H12AffineFastState.compose env44676 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound44676 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env44677 : List Nat := [2,4,8,16,16,64,128,94,80,30,81,194,24,81,216,89,0,217,220,217,195,131,16,138,83,130,146,81,80,217,20,16,95,65,1,146]

theorem envBound44677 : H12AffineFastState.Bounded env44677 := by
  intro p hp
  have h : env44677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44676_44677 : H12AffineEnvironment.transform 7 94 env44676 = env44677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env44676 == env44677) = true)

theorem identity44677 : scanCanonicalize (H12AffineFastState.compose env44677 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44677 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44678 : List Nat := [2,4,8,16,16,64,8,94,80,30,81,74,24,81,80,89,0,81,84,81,75,11,16,2,83,10,26,81,80,81,20,16,95,65,1,26]

theorem envBound44678 : H12AffineFastState.Bounded env44678 := by
  intro p hp
  have h : env44678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44677_44678 : H12AffineEnvironment.transform 6 8 env44677 = env44678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44677 == env44678) = true)

theorem identity44678 : scanCanonicalize (H12AffineFastState.compose env44678 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound44678 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44679 : List Nat := [2,4,8,16,16,10,8,20,26,30,27,0,24,27,26,19,0,27,30,27,1,11,16,2,25,10,26,27,26,27,20,16,21,11,1,26]

theorem envBound44679 : H12AffineFastState.Bounded env44679 := by
  intro p hp
  have h : env44679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44678_44679 : H12AffineEnvironment.transform 5 10 env44678 = env44679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env44678 == env44679) = true)

def env44680 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,8494,0,8622,4416,12636,4097,477,17,12607,12424,4160,4414,81,81,6436,8204,8201,257,64,0,4609]

theorem envBound44680 : H12AffineFastState.Bounded env44680 := by
  intro p hp
  have h : env44680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44670_44680 : H12AffineEnvironment.transform 9 321 env44670 = env44680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44670 == env44680) = true)

theorem identity44680 : scanCanonicalize (H12AffineFastState.compose env44680 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound44680 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44681 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,324,8192,80,8217,8494,0,8622,4,8216,325,477,17,8315,8652,260,122,81,81,2144,8204,8201,257,64,0,837]

theorem envBound44681 : H12AffineFastState.Bounded env44681 := by
  intro p hp
  have h : env44681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44680_44681 : H12AffineEnvironment.transform 11 324 env44680 = env44681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env44680 == env44681) = true)

theorem identity44681 : scanCanonicalize (H12AffineFastState.compose env44681 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound44681 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env44682 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,324,2990,80,2999,2688,0,2560,4,2998,325,477,17,3029,2658,260,122,81,81,2144,2978,2983,257,64,0,837]

theorem envBound44682 : H12AffineFastState.Bounded env44682 := by
  intro p hp
  have h : env44682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44681_44682 : H12AffineEnvironment.transform 12 2990 env44681 = env44682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env44681 == env44682) = true)

theorem identity44682 : scanCanonicalize (H12AffineFastState.compose env44682 (packedSelected [1,2,3,4,9,10,13,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound44682 : packedSelected [1,2,3,4,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env44683 : List Nat := [2,4,8,16,32,64,128,256,512,321,42,324,900,80,925,682,0,554,4,924,325,477,17,1023,584,260,122,81,81,74,904,909,257,64,0,837]

theorem envBound44683 : H12AffineFastState.Bounded env44683 := by
  intro p hp
  have h : env44683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44682_44683 : H12AffineEnvironment.transform 10 42 env44682 = env44683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env44682 == env44683) = true)

theorem identity44683 : scanCanonicalize (H12AffineFastState.compose env44683 (packedSelected [1,2,3,4,5,8,9,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound44683 : packedSelected [1,2,3,4,5,8,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env44684 : List Nat := [2,4,8,16,32,64,128,256,217,321,42,324,349,80,324,115,0,243,4,325,325,477,17,294,145,260,122,81,81,74,337,340,257,64,0,412]

theorem envBound44684 : H12AffineFastState.Bounded env44684 := by
  intro p hp
  have h : env44684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44683_44684 : H12AffineEnvironment.transform 8 217 env44683 = env44684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env44683 == env44684) = true)

theorem identity44684 : scanCanonicalize (H12AffineFastState.compose env44684 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound44684 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44685 : List Nat := [2,4,8,16,32,64,104,256,49,321,42,324,349,80,324,115,0,27,4,325,325,309,17,294,121,260,122,81,81,74,337,340,257,64,0,372]

theorem envBound44685 : H12AffineFastState.Bounded env44685 := by
  intro p hp
  have h : env44685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44684_44685 : H12AffineEnvironment.transform 6 104 env44684 = env44685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env44684 == env44685) = true)

theorem identity44685 : scanCanonicalize (H12AffineFastState.compose env44685 (packedSelected [0,2,3,4,5,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44685 : packedSelected [0,2,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env44686 : List Nat := [2,4,8,16,32,64,104,68,49,5,42,0,25,80,0,115,0,27,4,1,1,113,17,98,121,64,122,81,81,74,21,16,69,64,0,48]

theorem envBound44686 : H12AffineFastState.Bounded env44686 := by
  intro p hp
  have h : env44686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44685_44686 : H12AffineEnvironment.transform 7 68 env44685 = env44686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44685 == env44686) = true)

theorem identity44686 : scanCanonicalize (H12AffineFastState.compose env44686 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound44686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44687 : List Nat := [2,4,8,16,32,11,35,15,49,5,42,0,25,27,0,56,0,27,4,1,1,58,17,41,50,11,49,26,26,1,21,16,14,11,0,48]

theorem envBound44687 : H12AffineFastState.Bounded env44687 := by
  intro p hp
  have h : env44687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44686_44687 : H12AffineEnvironment.transform 5 11 env44686 = env44687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env44686 == env44687) = true)

theorem identity44687 : scanCanonicalize (H12AffineFastState.compose env44687 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound44687 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env44688 : List Nat := [2,4,8,16,25,11,26,15,8,5,19,0,25,27,0,1,0,27,4,1,1,3,17,16,11,11,8,26,26,1,21,16,14,11,0,9]

theorem envBound44688 : H12AffineFastState.Bounded env44688 := by
  intro p hp
  have h : env44688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44687_44688 : H12AffineEnvironment.transform 4 25 env44687 = env44688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env44687 == env44688) = true)

theorem identity44688 : scanCanonicalize (H12AffineFastState.compose env44688 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound44688 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env44689 : List Nat := [2,4,8,8,1,11,2,15,8,5,11,0,1,3,0,1,0,3,4,1,1,3,9,8,11,11,8,2,2,1,13,8,14,11,0,9]

theorem envBound44689 : H12AffineFastState.Bounded env44689 := by
  intro p hp
  have h : env44689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44688_44689 : H12AffineEnvironment.transform 3 8 env44688 = env44689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env44688 == env44689) = true)

theorem identity44689 : scanCanonicalize (H12AffineFastState.compose env44689 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44690 : List Nat := [2,3,8,8,1,11,2,8,8,2,11,0,1,3,0,1,0,3,3,1,1,3,9,8,11,11,8,2,2,1,10,8,9,11,0,9]

theorem envBound44690 : H12AffineFastState.Bounded env44690 := by
  intro p hp
  have h : env44690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44689_44690 : H12AffineEnvironment.transform 1 3 env44689 = env44690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44689 == env44690) = true)

theorem identity44690 : scanCanonicalize (H12AffineFastState.compose env44690 (packedSelected [0,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44690 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env44691 : List Nat := [0,1,8,8,1,9,0,8,8,0,9,0,1,1,0,1,0,1,1,1,1,1,9,8,9,9,8,0,0,1,8,8,9,9,0,9]

theorem envBound44691 : H12AffineFastState.Bounded env44691 := by
  intro p hp
  have h : env44691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44690_44691 : H12AffineEnvironment.transform 0 0 env44690 = env44691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44690 == env44691) = true)

def env44692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4097,477,74047,69649,13769,78895,4415,74814,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound44692 : H12AffineFastState.Bounded env44692 := by
  intro p hp
  have h : env44692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44668_44692 : H12AffineEnvironment.transform 17 65665 env44668 = env44692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44668 == env44692) = true)

theorem identity44692 : scanCanonicalize (H12AffineFastState.compose env44692 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound44692 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12590,5441,12719,4416,13341,4097,477,4113,8511,13769,1281,4415,5392,1296,3173,8204,12297,257,1281,1345,5952]

theorem envBound44693 : H12AffineFastState.Bounded env44693 := by
  intro p hp
  have h : env44693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44692_44693 : H12AffineEnvironment.transform 15 12590 env44692 = env44693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env44692 == env44693) = true)

def env44694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,8494,1345,8623,320,9245,1,477,17,8511,9673,1281,319,1296,1296,3173,8204,8201,257,1281,1345,1856]

theorem envBound44694 : H12AffineFastState.Bounded env44694 := by
  intro p hp
  have h : env44694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44693_44694 : H12AffineEnvironment.transform 11 0 env44693 = env44694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44693 == env44694) = true)

theorem identity44694 : scanCanonicalize (H12AffineFastState.compose env44694 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44694 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44695 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,0,8192,1109,9244,8298,1029,8427,4,9245,1,153,17,8315,9357,1093,123,1108,1108,3173,8204,8201,69,1093,1029,1540]

theorem envBound44695 : H12AffineFastState.Bounded env44695 := by
  intro p hp
  have h : env44695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44694_44695 : H12AffineEnvironment.transform 7 68 env44694 = env44695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44694 == env44695) = true)

theorem identity44695 : scanCanonicalize (H12AffineFastState.compose env44695 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44695 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44696 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8192,81,8216,8298,1,8427,4,8217,1,153,17,8315,8329,65,123,80,80,2145,8204,8201,69,65,1,512]

theorem envBound44696 : H12AffineFastState.Bounded env44696 := by
  intro p hp
  have h : env44696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44695_44696 : H12AffineEnvironment.transform 9 4 env44695 = env44696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44695 == env44696) = true)

theorem identity44696 : scanCanonicalize (H12AffineFastState.compose env44696 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound44696 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44697 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,240,81,232,154,1,27,4,233,1,153,17,139,121,65,123,80,80,2145,252,249,69,65,1,512]

theorem envBound44697 : H12AffineFastState.Bounded env44697 := by
  intro p hp
  have h : env44697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44696_44697 : H12AffineEnvironment.transform 12 240 env44696 = env44697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env44696 == env44697) = true)

theorem identity44697 : scanCanonicalize (H12AffineFastState.compose env44697 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound44697 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44698 : List Nat := [2,4,8,16,32,64,128,68,49,4,2048,0,240,81,232,154,1,27,4,233,1,153,17,139,121,65,123,80,80,2145,252,249,69,65,1,49]

theorem envBound44698 : H12AffineFastState.Bounded env44698 := by
  intro p hp
  have h : env44698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44697_44698 : H12AffineEnvironment.transform 8 49 env44697 = env44698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env44697 == env44698) = true)

theorem identity44698 : scanCanonicalize (H12AffineFastState.compose env44698 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound44698 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env44699 : List Nat := [2,4,8,16,32,64,104,68,49,4,2048,0,24,81,0,114,1,27,4,1,1,113,17,99,121,65,123,80,80,2145,20,17,69,65,1,49]

theorem envBound44699 : H12AffineFastState.Bounded env44699 := by
  intro p hp
  have h : env44699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44698_44699 : H12AffineEnvironment.transform 6 104 env44698 = env44699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env44698 == env44699) = true)

def env44700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,8495,1344,8622,321,9244,0,477,16,8511,9672,1281,318,1297,1296,3173,8204,8200,257,1281,1345,1857]

theorem envBound44700 : H12AffineFastState.Bounded env44700 := by
  intro p hp
  have h : env44700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44693_44700 : H12AffineEnvironment.transform 11 1 env44693 = env44700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env44693 == env44700) = true)

theorem identity44700 : scanCanonicalize (H12AffineFastState.compose env44700 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound44700 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1297,325,1143,1344,1270,321,324,0,477,16,1127,144,1281,318,1297,1296,3173,1364,1360,257,1281,1345,1857]

theorem envBound44701 : H12AffineFastState.Bounded env44701 := by
  intro p hp
  have h : env44701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44700_44701 : H12AffineEnvironment.transform 12 1368 env44700 = env44701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env44700 == env44701) = true)

theorem identity44701 : scanCanonicalize (H12AffineFastState.compose env44701 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound44701 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44702 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,1,437,508,325,154,429,27,321,324,0,477,16,138,144,492,318,508,509,2184,441,445,257,492,428,940]

theorem envBound44702 : H12AffineFastState.Bounded env44702 := by
  intro p hp
  have h : env44702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44701_44702 : H12AffineEnvironment.transform 9 237 env44701 = env44702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env44701 == env44702) = true)

theorem identity44702 : scanCanonicalize (H12AffineFastState.compose env44702 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound44702 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44703 : List Nat := [2,4,8,16,32,64,128,256,461,237,2048,1,437,508,325,154,429,27,321,324,0,477,16,138,144,492,318,508,509,2184,441,445,257,492,428,97]

theorem envBound44703 : H12AffineFastState.Bounded env44703 := by
  intro p hp
  have h : env44703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44702_44703 : H12AffineEnvironment.transform 8 461 env44702 = env44703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env44702 == env44703) = true)

theorem identity44703 : scanCanonicalize (H12AffineFastState.compose env44703 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound44703 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44704 : List Nat := [2,4,8,16,32,64,128,256,461,237,509,1,437,508,325,154,429,27,321,324,0,477,16,138,144,492,318,508,509,373,441,445,257,492,428,97]

theorem envBound44704 : H12AffineFastState.Bounded env44704 := by
  intro p hp
  have h : env44704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44703_44704 : H12AffineEnvironment.transform 10 509 env44703 = env44704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env44703 == env44704) = true)

theorem identity44704 : scanCanonicalize (H12AffineFastState.compose env44704 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44704 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env44705 : List Nat := [2,4,8,16,32,64,128,117,184,237,136,1,192,137,48,154,216,27,52,49,0,168,16,138,144,153,75,137,136,0,204,200,116,153,217,97]

theorem envBound44705 : H12AffineFastState.Bounded env44705 := by
  intro p hp
  have h : env44705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44704_44705 : H12AffineEnvironment.transform 7 117 env44704 = env44705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44704 == env44705) = true)

theorem identity44705 : scanCanonicalize (H12AffineFastState.compose env44705 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound44705 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env44706 : List Nat := [2,4,8,16,32,59,128,14,184,150,136,1,187,137,48,154,163,27,52,49,0,168,16,138,144,153,48,137,136,0,183,179,15,153,162,26]

theorem envBound44706 : H12AffineFastState.Bounded env44706 := by
  intro p hp
  have h : env44706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44705_44706 : H12AffineEnvironment.transform 5 59 env44705 = env44706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env44705 == env44706) = true)

theorem identity44706 : scanCanonicalize (H12AffineFastState.compose env44706 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44706 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env44707 : List Nat := [2,4,8,16,32,59,9,14,49,31,1,1,50,0,48,19,42,27,52,49,0,33,16,3,25,16,48,0,1,0,62,58,15,16,43,26]

theorem envBound44707 : H12AffineFastState.Bounded env44707 := by
  intro p hp
  have h : env44707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44706_44707 : H12AffineEnvironment.transform 6 9 env44706 = env44707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44706 == env44707) = true)

theorem identity44707 : scanCanonicalize (H12AffineFastState.compose env44707 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44708 : List Nat := [2,4,8,16,10,17,9,14,27,31,1,1,24,0,26,19,0,27,30,27,0,11,16,3,25,16,26,0,1,0,20,16,15,16,1,26]

theorem envBound44708 : H12AffineFastState.Bounded env44708 := by
  intro p hp
  have h : env44708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44707_44708 : H12AffineEnvironment.transform 4 10 env44707 = env44708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44707 == env44708) = true)

theorem identity44708 : scanCanonicalize (H12AffineFastState.compose env44708 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound44708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44709 : List Nat := [2,4,8,5,10,4,9,14,14,10,1,1,13,0,15,6,0,14,11,14,0,11,5,3,12,5,15,0,1,0,1,5,15,5,1,15]

theorem envBound44709 : H12AffineFastState.Bounded env44709 := by
  intro p hp
  have h : env44709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44708_44709 : H12AffineEnvironment.transform 3 5 env44708 = env44709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env44708 == env44709) = true)

theorem identity44709 : scanCanonicalize (H12AffineFastState.compose env44709 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44710 : List Nat := [2,4,1,5,3,4,0,7,7,3,1,1,4,0,6,6,0,7,2,7,0,2,5,3,5,5,6,0,1,0,1,5,6,5,1,6]

theorem envBound44710 : H12AffineFastState.Bounded env44710 := by
  intro p hp
  have h : env44710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44709_44710 : H12AffineEnvironment.transform 2 1 env44709 = env44710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44709 == env44710) = true)

theorem identity44710 : scanCanonicalize (H12AffineFastState.compose env44710 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44710 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44711 : List Nat := [2,2,1,3,3,2,0,1,1,3,1,1,2,0,0,0,0,1,2,1,0,2,3,3,3,3,0,0,1,0,1,3,0,3,1,0]

theorem envBound44711 : H12AffineFastState.Bounded env44711 := by
  intro p hp
  have h : env44711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44710_44711 : H12AffineEnvironment.transform 1 2 env44710 = env44711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44710 == env44711) = true)

theorem identity44711 : scanCanonicalize (H12AffineFastState.compose env44711 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44711 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44712 : List Nat := [1,1,1,0,0,1,0,1,1,0,1,1,1,0,0,0,0,1,1,1,0,1,0,0,0,0,0,0,1,0,1,0,0,0,1,0]

theorem envBound44712 : H12AffineFastState.Bounded env44712 := by
  intro p hp
  have h : env44712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44711_44712 : H12AffineEnvironment.transform 0 1 env44711 = env44712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44711 == env44712) = true)

def env44713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123165,533641,614526,385202,90415,545089,96346,25884,82999,257,545104,1345,525824]

theorem envBound44713 : H12AffineFastState.Bounded env44713 := by
  intro p hp
  have h : env44713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44514_44713 : H12AffineEnvironment.transform 23 123165 env44514 = env44713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env44514 == env44713) = true)

def env44714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123165,28889,78894,385202,90415,1297,96346,25884,82999,257,1280,1345,21072]

theorem envBound44714 : H12AffineFastState.Bounded env44714 := by
  intro p hp
  have h : env44714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44713_44714 : H12AffineEnvironment.transform 18 21584 env44713 = env44714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env44713 == env44714) = true)

theorem identity44714 : scanCanonicalize (H12AffineFastState.compose env44714 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound44714 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4097,5277,91182,66896,28889,78894,328959,90415,1297,96346,25884,82999,257,1280,1345,21072]

theorem envBound44715 : H12AffineFastState.Bounded env44715 := by
  intro p hp
  have h : env44715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44714_44715 : H12AffineEnvironment.transform 14 25677 env44714 = env44715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env44714 == env44715) = true)

def env44716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4097,5277,74046,66896,13769,78894,328959,74815,1297,81226,8204,65831,257,1280,1345,5952]

theorem envBound44716 : H12AffineFastState.Bounded env44716 := by
  intro p hp
  have h : env44716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44715_44716 : H12AffineEnvironment.transform 13 1296 env44715 = env44716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44715 == env44716) = true)

def env44717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4097,5277,74046,66896,13769,78894,1151,74815,1297,81226,8204,65831,257,1280,1345,5952]

theorem envBound44717 : H12AffineFastState.Bounded env44717 := by
  intro p hp
  have h : env44717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44716_44717 : H12AffineEnvironment.transform 17 65664 env44716 = env44717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44716 == env44717) = true)

theorem identity44717 : scanCanonicalize (H12AffineFastState.compose env44717 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound44717 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,65536,69990,65664,4416,5205,4097,5277,70711,66896,192,65831,1151,69942,1297,67651,5381,65831,257,1280,1345,5952]

theorem envBound44718 : H12AffineFastState.Bounded env44718 := by
  intro p hp
  have h : env44718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44717_44718 : H12AffineEnvironment.transform 12 5385 env44717 = env44718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env44717 == env44718) = true)

def env44719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1296,576,65536,67442,65664,1876,577,1557,649,66083,66896,192,65831,1151,67362,1297,67651,785,65831,257,1280,1345,340]

theorem envBound44719 : H12AffineFastState.Bounded env44719 := by
  intro p hp
  have h : env44719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44718_44719 : H12AffineEnvironment.transform 11 1556 env44718 = env44719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env44718 == env44719) = true)

def env44720 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,65536,66082,65664,516,577,837,649,66083,65536,192,65831,303,66162,65,67651,785,65831,257,80,17,340]

theorem envBound44720 : H12AffineFastState.Bounded env44720 := by
  intro p hp
  have h : env44720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44719_44720 : H12AffineEnvironment.transform 9 336 env44719 = env44720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env44719 == env44720) = true)

theorem identity44720 : scanCanonicalize (H12AffineFastState.compose env44720 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 435) := by decide +kernel

theorem selectedBound44720 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44721 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,435,913,307,516,577,837,649,912,435,192,148,303,961,65,2544,785,148,257,80,17,340]

theorem envBound44721 : H12AffineFastState.Bounded env44721 := by
  intro p hp
  have h : env44721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44720_44721 : H12AffineEnvironment.transform 15 435 env44720 = env44721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 435 env44720 == env44721) = true)

def env44722 : List Nat := [2,4,8,16,32,64,128,256,328,336,2048,12,85,64,264,435,217,307,332,265,13,449,216,435,192,148,303,137,65,2544,89,148,257,80,17,340]

theorem envBound44722 : H12AffineFastState.Bounded env44722 := by
  intro p hp
  have h : env44722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44721_44722 : H12AffineEnvironment.transform 8 328 env44721 = env44722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env44721 == env44722) = true)

theorem identity44722 : scanCanonicalize (H12AffineFastState.compose env44722 (packedSelected [0,4,7,9,12,16,20,21,38] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44722 : packedSelected [0,4,7,9,12,16,20,21,38] rootPS < 2^1333 := by decide +kernel

def env44723 : List Nat := [2,4,4,16,32,64,128,256,324,336,2048,0,85,64,260,435,213,307,320,261,1,449,212,435,192,148,291,133,65,2544,85,148,257,80,17,340]

theorem envBound44723 : H12AffineFastState.Bounded env44723 := by
  intro p hp
  have h : env44723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44722_44723 : H12AffineEnvironment.transform 2 4 env44722 = env44723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44722 == env44723) = true)

theorem identity44723 : scanCanonicalize (H12AffineFastState.compose env44723 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 208) := by decide +kernel

theorem selectedBound44723 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44724 : List Nat := [2,4,4,16,32,64,128,208,148,128,2048,0,85,64,212,99,213,227,144,213,1,17,212,99,192,148,243,133,65,2080,85,148,209,80,17,132]

theorem envBound44724 : H12AffineFastState.Bounded env44724 := by
  intro p hp
  have h : env44724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44723_44724 : H12AffineEnvironment.transform 7 208 env44723 = env44724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 208 env44723 == env44724) = true)

theorem identity44724 : scanCanonicalize (H12AffineFastState.compose env44724 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 229) := by decide +kernel

theorem selectedBound44724 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env44725 : List Nat := [2,4,4,16,32,64,128,208,148,128,229,0,85,64,212,99,213,227,144,213,1,17,212,99,192,148,243,133,65,197,85,148,209,80,17,132]

theorem envBound44725 : H12AffineFastState.Bounded env44725 := by
  intro p hp
  have h : env44725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44724_44725 : H12AffineEnvironment.transform 10 229 env44724 = env44725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 229 env44724 == env44725) = true)

theorem identity44725 : scanCanonicalize (H12AffineFastState.compose env44725 (packedSelected [0,1,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound44725 : packedSelected [0,1,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44726 : List Nat := [2,4,4,16,32,64,67,19,87,67,38,0,85,64,23,99,22,32,83,22,1,17,23,99,3,87,48,70,65,6,85,87,18,80,17,71]

theorem envBound44726 : H12AffineFastState.Bounded env44726 := by
  intro p hp
  have h : env44726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44725_44726 : H12AffineEnvironment.transform 6 67 env44725 = env44726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env44725 == env44726) = true)

theorem identity44726 : scanCanonicalize (H12AffineFastState.compose env44726 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound44726 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env44727 : List Nat := [2,4,4,16,22,64,67,19,87,67,16,0,85,64,23,85,22,22,83,22,1,17,23,85,3,87,6,70,65,6,85,87,18,80,17,71]

theorem envBound44727 : H12AffineFastState.Bounded env44727 := by
  intro p hp
  have h : env44727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44726_44727 : H12AffineEnvironment.transform 4 22 env44726 = env44727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env44726 == env44727) = true)

theorem identity44727 : scanCanonicalize (H12AffineFastState.compose env44727 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44727 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44728 : List Nat := [2,4,4,6,0,64,67,5,65,67,6,0,67,64,1,67,0,0,69,0,1,7,1,67,3,65,6,70,65,6,67,65,4,70,7,71]

theorem envBound44728 : H12AffineFastState.Bounded env44728 := by
  intro p hp
  have h : env44728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44727_44728 : H12AffineEnvironment.transform 3 6 env44727 = env44728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44727 == env44728) = true)

theorem identity44728 : scanCanonicalize (H12AffineFastState.compose env44728 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound44728 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44729 : List Nat := [2,4,4,6,0,6,5,5,7,5,6,0,5,6,1,5,0,0,3,0,1,7,1,5,3,7,6,0,7,6,5,7,4,0,7,1]

theorem envBound44729 : H12AffineFastState.Bounded env44729 := by
  intro p hp
  have h : env44729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44728_44729 : H12AffineEnvironment.transform 5 6 env44728 = env44729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env44728 == env44729) = true)

theorem identity44729 : scanCanonicalize (H12AffineFastState.compose env44729 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44729 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44730 : List Nat := [2,3,3,1,0,1,2,2,0,2,1,0,2,1,1,2,0,0,3,0,1,0,1,2,3,0,1,0,0,1,2,0,3,0,0,1]

theorem envBound44730 : H12AffineFastState.Bounded env44730 := by
  intro p hp
  have h : env44730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44729_44730 : H12AffineEnvironment.transform 1 3 env44729 = env44730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44729 == env44730) = true)

theorem identity44730 : scanCanonicalize (H12AffineFastState.compose env44730 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44731 : List Nat := [1,0,0,1,0,1,1,1,0,1,1,0,1,1,1,1,0,0,0,0,1,0,1,1,0,0,1,0,0,1,1,0,0,0,0,1]

theorem envBound44731 : H12AffineFastState.Bounded env44731 := by
  intro p hp
  have h : env44731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44730_44731 : H12AffineEnvironment.transform 0 1 env44730 = env44731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44730 == env44731) = true)

def env44732 : List Nat := [2,4,8,16,32,64,128,256,329,336,2048,13,84,64,265,435,216,307,333,264,12,448,217,435,192,148,303,136,65,2544,88,148,257,80,17,340]

theorem envBound44732 : H12AffineFastState.Bounded env44732 := by
  intro p hp
  have h : env44732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44721_44732 : H12AffineEnvironment.transform 8 329 env44721 = env44732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env44721 == env44732) = true)

theorem identity44732 : scanCanonicalize (H12AffineFastState.compose env44732 (packedSelected [0,4,7,9,12,16,20,21,38] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44732 : packedSelected [0,4,7,9,12,16,20,21,38] rootPS < 2^1333 := by decide +kernel

def env44733 : List Nat := [2,4,8,1,32,64,128,256,329,321,2048,13,69,64,265,418,201,290,333,264,12,448,200,418,192,133,303,136,65,2529,73,133,257,65,0,325]

theorem envBound44733 : H12AffineFastState.Bounded env44733 := by
  intro p hp
  have h : env44733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44732_44733 : H12AffineEnvironment.transform 3 1 env44732 = env44733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44732 == env44733) = true)

theorem identity44733 : scanCanonicalize (H12AffineFastState.compose env44733 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 335) := by decide +kernel

theorem selectedBound44733 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env44734 : List Nat := [2,4,8,1,32,64,128,256,329,321,335,13,69,64,265,418,201,290,333,264,12,448,200,418,192,133,303,136,65,174,73,133,257,65,0,325]

theorem envBound44734 : H12AffineFastState.Bounded env44734 := by
  intro p hp
  have h : env44734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44733_44734 : H12AffineEnvironment.transform 10 335 env44733 = env44734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 335 env44733 == env44734) = true)

theorem identity44734 : scanCanonicalize (H12AffineFastState.compose env44734 (packedSelected [3,4,5,9,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound44734 : packedSelected [3,4,5,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env44735 : List Nat := [2,4,8,1,32,64,128,3,74,66,76,13,69,64,10,161,201,33,78,11,12,195,200,161,192,133,44,136,65,174,73,133,2,65,0,70]

theorem envBound44735 : H12AffineFastState.Bounded env44735 := by
  intro p hp
  have h : env44735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44734_44735 : H12AffineEnvironment.transform 7 3 env44734 = env44735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env44734 == env44735) = true)

theorem identity44735 : scanCanonicalize (H12AffineFastState.compose env44735 (packedSelected [1,2,3,4,5,7,8,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44735 : packedSelected [1,2,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env44736 : List Nat := [2,3,8,1,32,64,128,3,74,66,75,10,66,64,10,161,201,33,73,11,11,195,200,161,192,130,43,136,65,169,73,130,2,65,0,65]

theorem envBound44736 : H12AffineFastState.Bounded env44736 := by
  intro p hp
  have h : env44736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44735_44736 : H12AffineEnvironment.transform 1 3 env44735 = env44736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44735 == env44736) = true)

theorem identity44736 : scanCanonicalize (H12AffineFastState.compose env44736 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44736 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44737 : List Nat := [2,3,8,1,32,64,8,3,74,66,75,10,66,64,10,41,65,33,73,11,11,75,64,41,72,10,43,0,65,33,73,10,2,65,0,65]

theorem envBound44737 : H12AffineFastState.Bounded env44737 := by
  intro p hp
  have h : env44737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44736_44737 : H12AffineEnvironment.transform 6 8 env44736 = env44737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44736 == env44737) = true)

theorem identity44737 : scanCanonicalize (H12AffineFastState.compose env44737 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound44737 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44738 : List Nat := [2,3,8,1,32,11,8,3,1,9,0,10,9,11,10,41,10,33,2,11,11,0,11,41,3,10,43,0,10,33,2,10,2,10,0,10]

theorem envBound44738 : H12AffineFastState.Bounded env44738 := by
  intro p hp
  have h : env44738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44737_44738 : H12AffineEnvironment.transform 5 11 env44737 = env44738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env44737 == env44738) = true)

theorem identity44738 : scanCanonicalize (H12AffineFastState.compose env44738 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44738 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44739 : List Nat := [2,3,8,1,0,11,8,3,1,9,0,10,9,11,10,9,10,1,2,11,11,0,11,9,3,10,11,0,10,1,2,10,2,10,0,10]

theorem envBound44739 : H12AffineFastState.Bounded env44739 := by
  intro p hp
  have h : env44739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44738_44739 : H12AffineEnvironment.transform 4 0 env44738 = env44739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44738 == env44739) = true)

theorem identity44739 : scanCanonicalize (H12AffineFastState.compose env44739 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44739 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44740 : List Nat := [2,3,2,1,0,1,2,3,1,3,0,0,3,1,0,3,0,1,2,1,1,0,1,3,3,0,1,0,0,1,2,0,2,0,0,0]

theorem envBound44740 : H12AffineFastState.Bounded env44740 := by
  intro p hp
  have h : env44740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44739_44740 : H12AffineEnvironment.transform 2 2 env44739 = env44740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44739 == env44740) = true)

theorem identity44740 : scanCanonicalize (H12AffineFastState.compose env44740 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44741 : List Nat := [0,1,0,1,0,1,0,1,1,1,0,0,1,1,0,1,0,1,0,1,1,0,1,1,1,0,1,0,0,1,0,0,0,0,0,0]

theorem envBound44741 : H12AffineFastState.Bounded env44741 := by
  intro p hp
  have h : env44741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44740_44741 : H12AffineEnvironment.transform 0 0 env44740 = env44741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44740 == env44741) = true)

def env44742 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,65536,66083,65664,517,577,836,649,66083,65537,192,65831,302,66163,64,67651,785,65831,257,81,16,340]

theorem envBound44742 : H12AffineFastState.Bounded env44742 := by
  intro p hp
  have h : env44742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44719_44742 : H12AffineEnvironment.transform 9 337 env44719 = env44742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env44719 == env44742) = true)

theorem identity44742 : scanCanonicalize (H12AffineFastState.compose env44742 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 759) := by decide +kernel

theorem selectedBound44742 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44743 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,759,212,631,517,577,836,649,212,758,192,976,302,132,64,2740,785,976,257,81,16,340]

theorem envBound44743 : H12AffineFastState.Bounded env44743 := by
  intro p hp
  have h : env44743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44742_44743 : H12AffineEnvironment.transform 15 759 env44742 = env44743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 759 env44742 == env44743) = true)

def env44744 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,781,65,576,743,196,615,517,577,836,649,196,742,192,960,302,132,64,2724,769,960,257,65,0,324]

theorem envBound44744 : H12AffineFastState.Bounded env44744 := by
  intro p hp
  have h : env44744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44743_44744 : H12AffineEnvironment.transform 3 0 env44743 = env44744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44743 == env44744) = true)

theorem identity44744 : scanCanonicalize (H12AffineFastState.compose env44744 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound44744 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44745 : List Nat := [2,4,8,0,32,64,128,256,133,321,2048,448,392,65,197,98,196,226,128,196,449,12,196,99,192,325,302,132,64,2081,388,325,257,65,0,324]

theorem envBound44745 : H12AffineFastState.Bounded env44745 := by
  intro p hp
  have h : env44745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44744_44745 : H12AffineEnvironment.transform 8 133 env44744 = env44745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env44744 == env44745) = true)

theorem identity44745 : scanCanonicalize (H12AffineFastState.compose env44745 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound44745 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env44746 : List Nat := [2,4,8,0,32,64,128,256,133,321,162,448,392,65,197,98,196,226,128,196,449,12,196,99,192,325,302,132,64,131,388,325,257,65,0,324]

theorem envBound44746 : H12AffineFastState.Bounded env44746 := by
  intro p hp
  have h : env44746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44745_44746 : H12AffineEnvironment.transform 10 162 env44745 = env44746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env44745 == env44746) = true)

theorem identity44746 : scanCanonicalize (H12AffineFastState.compose env44746 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound44746 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44747 : List Nat := [2,4,8,0,32,45,128,256,133,300,162,429,392,44,168,15,169,143,128,169,428,12,169,14,173,296,302,132,45,131,388,296,257,44,0,297]

theorem envBound44747 : H12AffineFastState.Bounded env44747 := by
  intro p hp
  have h : env44747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44746_44747 : H12AffineEnvironment.transform 5 45 env44746 = env44747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env44746 == env44747) = true)

theorem identity44747 : scanCanonicalize (H12AffineFastState.compose env44747 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound44747 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env44748 : List Nat := [2,4,8,0,32,45,128,47,133,3,162,130,167,44,168,15,169,143,128,169,131,12,169,14,173,7,1,132,45,131,171,7,46,44,0,6]

theorem envBound44748 : H12AffineFastState.Bounded env44748 := by
  intro p hp
  have h : env44748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44747_44748 : H12AffineEnvironment.transform 7 47 env44747 = env44748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env44747 == env44748) = true)

theorem identity44748 : scanCanonicalize (H12AffineFastState.compose env44748 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44748 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env44749 : List Nat := [2,4,5,0,32,32,128,34,133,3,162,130,167,33,165,2,164,130,128,164,131,1,164,3,160,7,1,132,32,131,166,7,35,33,0,6]

theorem envBound44749 : H12AffineFastState.Bounded env44749 := by
  intro p hp
  have h : env44749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44748_44749 : H12AffineEnvironment.transform 2 5 env44748 = env44749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44748 == env44749) = true)

theorem identity44749 : scanCanonicalize (H12AffineFastState.compose env44749 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound44749 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44750 : List Nat := [2,4,5,0,32,32,37,34,32,3,7,39,2,33,0,2,1,39,37,1,38,1,1,3,5,7,1,33,32,38,3,7,35,33,0,6]

theorem envBound44750 : H12AffineFastState.Bounded env44750 := by
  intro p hp
  have h : env44750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44749_44750 : H12AffineEnvironment.transform 6 37 env44749 = env44750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env44749 == env44750) = true)

theorem identity44750 : scanCanonicalize (H12AffineFastState.compose env44750 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44751 : List Nat := [2,3,2,0,32,32,34,34,32,3,0,32,2,33,0,2,1,32,34,1,33,1,1,3,2,0,1,33,32,33,3,0,35,33,0,1]

theorem envBound44751 : H12AffineFastState.Bounded env44751 := by
  intro p hp
  have h : env44751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44750_44751 : H12AffineEnvironment.transform 1 3 env44750 = env44751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44750 == env44751) = true)

theorem identity44751 : scanCanonicalize (H12AffineFastState.compose env44751 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44752 : List Nat := [2,3,2,0,0,0,2,2,0,3,0,0,2,1,0,2,1,0,2,1,1,1,1,3,2,0,1,1,0,1,3,0,3,1,0,1]

theorem envBound44752 : H12AffineFastState.Bounded env44752 := by
  intro p hp
  have h : env44752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44751_44752 : H12AffineEnvironment.transform 4 0 env44751 = env44752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44751 == env44752) = true)

theorem identity44752 : scanCanonicalize (H12AffineFastState.compose env44752 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44753 : List Nat := [1,0,1,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,1,1,1,1,0,1,0,1,1,0,1,0,0,0,1,0,1]

theorem envBound44753 : H12AffineFastState.Bounded env44753 := by
  intro p hp
  have h : env44753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44752_44753 : H12AffineEnvironment.transform 0 1 env44752 = env44753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44752 == env44753) = true)

def env44754 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,780,65,576,742,197,614,517,577,836,649,197,743,192,961,302,132,64,2725,768,961,257,64,1,325]

theorem envBound44754 : H12AffineFastState.Bounded env44754 := by
  intro p hp
  have h : env44754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44743_44754 : H12AffineEnvironment.transform 3 1 env44743 = env44754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44743 == env44754) = true)

theorem identity44754 : scanCanonicalize (H12AffineFastState.compose env44754 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound44754 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44755 : List Nat := [2,4,8,1,32,64,128,193,512,129,2048,644,717,65,576,742,197,614,517,577,645,649,197,743,192,512,239,132,64,2725,705,512,192,64,1,132]

theorem envBound44755 : H12AffineFastState.Bounded env44755 := by
  intro p hp
  have h : env44755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44754_44755 : H12AffineEnvironment.transform 7 193 env44754 = env44755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env44754 == env44755) = true)

theorem identity44755 : scanCanonicalize (H12AffineFastState.compose env44755 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 196) := by decide +kernel

theorem selectedBound44755 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44756 : List Nat := [2,4,8,1,32,64,128,193,196,129,2048,64,9,65,132,34,197,162,193,133,65,77,197,35,192,196,239,132,64,2145,5,196,192,64,1,132]

theorem envBound44756 : H12AffineFastState.Bounded env44756 := by
  intro p hp
  have h : env44756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44755_44756 : H12AffineEnvironment.transform 8 196 env44755 = env44756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 196 env44755 == env44756) = true)

theorem identity44756 : scanCanonicalize (H12AffineFastState.compose env44756 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 238) := by decide +kernel

theorem selectedBound44756 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44757 : List Nat := [2,4,8,1,32,64,128,193,196,129,238,64,9,65,132,34,197,162,193,133,65,77,197,35,192,196,239,132,64,143,5,196,192,64,1,132]

theorem envBound44757 : H12AffineFastState.Bounded env44757 := by
  intro p hp
  have h : env44757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44756_44757 : H12AffineEnvironment.transform 10 238 env44756 = env44757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 238 env44756 == env44757) = true)

theorem identity44757 : scanCanonicalize (H12AffineFastState.compose env44757 (packedSelected [0,3,4,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound44757 : packedSelected [0,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env44758 : List Nat := [2,4,8,1,12,64,128,193,196,129,194,64,9,65,132,14,197,142,193,133,65,77,197,15,192,196,195,132,64,143,5,196,192,64,1,132]

theorem envBound44758 : H12AffineFastState.Bounded env44758 := by
  intro p hp
  have h : env44758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44757_44758 : H12AffineEnvironment.transform 4 12 env44757 = env44758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env44757 == env44758) = true)

theorem identity44758 : scanCanonicalize (H12AffineFastState.compose env44758 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44758 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env44759 : List Nat := [2,4,8,1,12,64,9,72,77,8,75,64,9,65,13,14,76,7,72,12,65,77,76,15,73,77,74,13,64,6,5,77,73,64,1,13]

theorem envBound44759 : H12AffineFastState.Bounded env44759 := by
  intro p hp
  have h : env44759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44758_44759 : H12AffineEnvironment.transform 6 9 env44758 = env44759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44758 == env44759) = true)

theorem identity44759 : scanCanonicalize (H12AffineFastState.compose env44759 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44759 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44760 : List Nat := [2,4,3,1,7,64,2,67,70,3,64,64,2,65,6,5,71,7,67,7,65,70,71,4,66,70,65,6,64,6,5,70,66,64,1,6]

theorem envBound44760 : H12AffineFastState.Bounded env44760 := by
  intro p hp
  have h : env44760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44759_44760 : H12AffineEnvironment.transform 2 3 env44759 = env44760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44759 == env44760) = true)

theorem identity44760 : scanCanonicalize (H12AffineFastState.compose env44760 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44761 : List Nat := [2,4,3,1,7,1,2,2,7,3,1,1,2,0,6,5,6,7,2,7,0,7,6,4,3,7,0,6,1,6,5,7,3,1,1,6]

theorem envBound44761 : H12AffineFastState.Bounded env44761 := by
  intro p hp
  have h : env44761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44760_44761 : H12AffineEnvironment.transform 5 1 env44760 = env44761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44760 == env44761) = true)

theorem identity44761 : scanCanonicalize (H12AffineFastState.compose env44761 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44762 : List Nat := [1,4,0,1,4,1,1,1,4,0,1,1,1,0,5,5,5,4,1,4,0,4,5,4,0,4,0,5,1,5,5,4,0,1,1,5]

theorem envBound44762 : H12AffineFastState.Bounded env44762 := by
  intro p hp
  have h : env44762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44761_44762 : H12AffineEnvironment.transform 0 1 env44761 = env44762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44761 == env44762) = true)

theorem identity44762 : scanCanonicalize (H12AffineFastState.compose env44762 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44762 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44763 : List Nat := [1,0,0,1,0,1,1,1,0,0,1,1,1,0,1,1,1,0,1,0,0,0,1,0,0,0,0,1,1,1,1,0,0,1,1,1]

theorem envBound44763 : H12AffineFastState.Bounded env44763 := by
  intro p hp
  have h : env44763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44762_44763 : H12AffineEnvironment.transform 1 0 env44762 = env44763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44762 == env44763) = true)

def env44764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1296,577,65536,67443,65664,1877,576,1556,648,66082,66896,192,65831,1151,67363,1297,67651,784,65831,257,1280,1345,341]

theorem envBound44764 : H12AffineFastState.Bounded env44764 := by
  intro p hp
  have h : env44764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44718_44764 : H12AffineEnvironment.transform 11 1557 env44718 = env44764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env44718 == env44764) = true)

def env44765 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,65536,66083,65664,517,576,836,648,66082,65536,192,65831,303,66163,65,67651,784,65831,257,80,17,341]

theorem envBound44765 : H12AffineFastState.Bounded env44765 := by
  intro p hp
  have h : env44765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44764_44765 : H12AffineEnvironment.transform 9 336 env44764 = env44765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env44764 == env44765) = true)

theorem identity44765 : scanCanonicalize (H12AffineFastState.compose env44765 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 384) := by decide +kernel

theorem selectedBound44765 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44766 : List Nat := [2,4,8,16,32,64,128,256,384,336,2048,197,156,64,449,65536,65955,65664,389,448,196,264,65954,65536,192,65831,303,66035,65,67651,144,65831,257,80,17,341]

theorem envBound44766 : H12AffineFastState.Bounded env44766 := by
  intro p hp
  have h : env44766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44765_44766 : H12AffineEnvironment.transform 8 384 env44765 = env44766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 384 env44765 == env44766) = true)

def env44767 : List Nat := [2,4,8,0,32,64,128,256,384,320,2048,197,140,64,449,65536,65955,65664,389,448,196,264,65954,65536,192,65831,303,66019,65,67651,128,65831,257,64,1,325]

theorem envBound44767 : H12AffineFastState.Bounded env44767 := by
  intro p hp
  have h : env44767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44766_44767 : H12AffineEnvironment.transform 3 0 env44766 = env44767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44766 == env44767) = true)

theorem identity44767 : scanCanonicalize (H12AffineFastState.compose env44767 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 166) := by decide +kernel

theorem selectedBound44767 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44768 : List Nat := [2,4,8,0,32,64,128,256,384,320,2048,197,140,64,449,166,261,38,389,448,196,264,260,166,192,385,303,325,65,2277,128,385,257,64,1,325]

theorem envBound44768 : H12AffineFastState.Bounded env44768 := by
  intro p hp
  have h : env44768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44767_44768 : H12AffineEnvironment.transform 15 166 env44767 = env44768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 166 env44767 == env44768) = true)

theorem identity44768 : scanCanonicalize (H12AffineFastState.compose env44768 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound44768 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44769 : List Nat := [2,4,8,0,32,64,4,256,260,320,2048,65,8,64,325,34,261,38,257,324,64,264,260,34,68,261,303,325,65,2145,4,261,257,64,1,325]

theorem envBound44769 : H12AffineFastState.Bounded env44769 := by
  intro p hp
  have h : env44769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44768_44769 : H12AffineEnvironment.transform 6 4 env44768 = env44769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env44768 == env44769) = true)

theorem identity44769 : scanCanonicalize (H12AffineFastState.compose env44769 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound44769 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44770 : List Nat := [2,4,8,0,32,64,4,256,260,320,367,65,8,64,325,34,261,38,257,324,64,264,260,34,68,261,303,325,65,270,4,261,257,64,1,325]

theorem envBound44770 : H12AffineFastState.Bounded env44770 := by
  intro p hp
  have h : env44770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44769_44770 : H12AffineEnvironment.transform 10 367 env44769 = env44770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env44769 == env44770) = true)

theorem identity44770 : scanCanonicalize (H12AffineFastState.compose env44770 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound44770 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env44771 : List Nat := [2,4,8,0,32,64,4,66,70,2,45,65,8,64,7,34,71,38,67,6,64,74,70,34,68,71,109,7,65,76,4,71,67,64,1,7]

theorem envBound44771 : H12AffineFastState.Bounded env44771 := by
  intro p hp
  have h : env44771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44770_44771 : H12AffineEnvironment.transform 7 66 env44770 = env44771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env44770 == env44771) = true)

theorem identity44771 : scanCanonicalize (H12AffineFastState.compose env44771 (packedSelected [0,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound44771 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env44772 : List Nat := [2,4,8,0,32,42,4,40,44,2,45,43,8,42,7,34,45,38,41,6,42,32,44,34,46,45,7,7,43,38,4,45,41,42,1,7]

theorem envBound44772 : H12AffineFastState.Bounded env44772 := by
  intro p hp
  have h : env44772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44771_44772 : H12AffineEnvironment.transform 5 42 env44771 = env44772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env44771 == env44772) = true)

def env44773 : List Nat := [2,4,8,1,32,64,128,256,384,321,2048,197,141,64,449,65536,65955,65664,389,448,196,264,65954,65536,192,65831,303,66018,65,67651,129,65831,257,65,0,324]

theorem envBound44773 : H12AffineFastState.Bounded env44773 := by
  intro p hp
  have h : env44773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44766_44773 : H12AffineEnvironment.transform 3 1 env44766 = env44773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44766 == env44773) = true)

theorem identity44773 : scanCanonicalize (H12AffineFastState.compose env44773 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound44773 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44774 : List Nat := [2,4,8,1,32,64,128,256,384,321,2048,197,141,64,449,99,448,227,389,448,196,264,449,99,192,324,303,385,65,2080,129,324,257,65,0,324]

theorem envBound44774 : H12AffineFastState.Bounded env44774 := by
  intro p hp
  have h : env44774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44773_44774 : H12AffineEnvironment.transform 15 99 env44773 = env44774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env44773 == env44774) = true)

theorem identity44774 : scanCanonicalize (H12AffineFastState.compose env44774 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound44774 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env44775 : List Nat := [2,4,8,1,32,64,128,256,384,321,162,197,141,64,449,99,448,227,389,448,196,264,449,99,192,324,303,385,65,130,129,324,257,65,0,324]

theorem envBound44775 : H12AffineFastState.Bounded env44775 := by
  intro p hp
  have h : env44775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44774_44775 : H12AffineEnvironment.transform 10 162 env44774 = env44775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env44774 == env44775) = true)

theorem identity44775 : scanCanonicalize (H12AffineFastState.compose env44775 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound44775 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44776 : List Nat := [2,4,8,1,32,64,128,104,232,41,162,197,141,64,169,99,168,227,237,168,196,96,169,99,192,44,71,233,65,130,129,44,105,65,0,44]

theorem envBound44776 : H12AffineFastState.Bounded env44776 := by
  intro p hp
  have h : env44776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44775_44776 : H12AffineEnvironment.transform 7 104 env44775 = env44776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env44775 == env44776) = true)

theorem identity44776 : scanCanonicalize (H12AffineFastState.compose env44776 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound44776 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env44777 : List Nat := [2,4,8,1,32,6,128,46,174,41,162,131,141,6,169,37,168,165,171,168,130,38,169,37,134,44,1,175,7,130,129,44,47,7,0,44]

theorem envBound44777 : H12AffineFastState.Bounded env44777 := by
  intro p hp
  have h : env44777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44776_44777 : H12AffineEnvironment.transform 5 6 env44776 = env44777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env44776 == env44777) = true)

theorem identity44777 : scanCanonicalize (H12AffineFastState.compose env44777 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound44777 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env44778 : List Nat := [2,4,8,1,32,6,36,46,10,41,6,39,41,6,13,37,12,1,15,12,38,38,13,37,34,44,1,11,7,38,37,44,47,7,0,44]

theorem envBound44778 : H12AffineFastState.Bounded env44778 := by
  intro p hp
  have h : env44778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44777_44778 : H12AffineEnvironment.transform 6 36 env44777 = env44778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env44777 == env44778) = true)

theorem identity44778 : scanCanonicalize (H12AffineFastState.compose env44778 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44779 : List Nat := [2,4,8,1,10,6,14,4,10,3,6,13,3,6,13,15,12,1,15,12,12,12,13,15,8,6,1,11,7,12,15,6,5,7,0,6]

theorem envBound44779 : H12AffineFastState.Bounded env44779 := by
  intro p hp
  have h : env44779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44778_44779 : H12AffineEnvironment.transform 4 10 env44778 = env44779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44778 == env44779) = true)

theorem identity44779 : scanCanonicalize (H12AffineFastState.compose env44779 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44779 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44780 : List Nat := [2,4,5,1,7,6,3,4,7,3,6,0,3,6,0,2,1,1,2,1,1,1,0,2,5,6,1,6,7,1,2,6,5,7,0,6]

theorem envBound44780 : H12AffineFastState.Bounded env44780 := by
  intro p hp
  have h : env44780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44779_44780 : H12AffineEnvironment.transform 2 5 env44779 = env44780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44779 == env44780) = true)

theorem identity44780 : scanCanonicalize (H12AffineFastState.compose env44780 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44781 : List Nat := [2,1,0,1,2,3,3,1,2,3,3,0,3,3,0,2,1,1,2,1,1,1,0,2,0,3,1,3,2,1,2,3,0,2,0,3]

theorem envBound44781 : H12AffineFastState.Bounded env44781 := by
  intro p hp
  have h : env44781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44780_44781 : H12AffineEnvironment.transform 1 1 env44780 = env44781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44780 == env44781) = true)

theorem identity44781 : scanCanonicalize (H12AffineFastState.compose env44781 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44781 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44782 : List Nat := [1,1,0,1,1,0,0,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,1,1,0,0,1,0,0]

theorem envBound44782 : H12AffineFastState.Bounded env44782 := by
  intro p hp
  have h : env44782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44781_44782 : H12AffineEnvironment.transform 0 1 env44781 = env44782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44781 == env44782) = true)

def env44783 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,65536,66082,65664,516,576,837,648,66082,65537,192,65831,302,66162,64,67651,784,65831,257,81,16,341]

theorem envBound44783 : H12AffineFastState.Bounded env44783 := by
  intro p hp
  have h : env44783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44764_44783 : H12AffineEnvironment.transform 9 337 env44764 = env44783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env44764 == env44783) = true)

theorem identity44783 : scanCanonicalize (H12AffineFastState.compose env44783 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound44783 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44784 : List Nat := [2,4,8,16,32,64,69,256,512,337,2048,836,796,65,577,65536,66082,65605,516,576,837,589,66082,65537,5,65831,302,66162,64,67651,784,65831,257,81,16,341]

theorem envBound44784 : H12AffineFastState.Bounded env44784 := by
  intro p hp
  have h : env44784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44783_44784 : H12AffineEnvironment.transform 6 69 env44783 = env44784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env44783 == env44784) = true)

def env44785 : List Nat := [2,4,8,0,32,64,69,256,512,321,2048,836,780,65,577,65536,66082,65605,516,576,837,589,66082,65537,5,65831,302,66146,64,67651,768,65831,257,65,0,325]

theorem envBound44785 : H12AffineFastState.Bounded env44785 := by
  intro p hp
  have h : env44785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44784_44785 : H12AffineEnvironment.transform 3 0 env44784 = env44785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44784 == env44785) = true)

theorem identity44785 : scanCanonicalize (H12AffineFastState.compose env44785 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound44785 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44786 : List Nat := [2,4,8,0,32,64,69,256,512,321,2048,836,780,65,577,98,576,39,516,576,837,589,576,99,5,325,302,512,64,2081,768,325,257,65,0,325]

theorem envBound44786 : H12AffineFastState.Bounded env44786 := by
  intro p hp
  have h : env44786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44785_44786 : H12AffineEnvironment.transform 15 98 env44785 = env44786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env44785 == env44786) = true)

theorem identity44786 : scanCanonicalize (H12AffineFastState.compose env44786 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound44786 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env44787 : List Nat := [2,4,8,0,32,64,69,256,512,321,103,836,780,65,577,98,576,39,516,576,837,589,576,99,5,325,302,512,64,70,768,325,257,65,0,325]

theorem envBound44787 : H12AffineFastState.Bounded env44787 := by
  intro p hp
  have h : env44787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44786_44787 : H12AffineEnvironment.transform 10 103 env44786 = env44787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env44786 == env44787) = true)

theorem identity44787 : scanCanonicalize (H12AffineFastState.compose env44787 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound44787 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44788 : List Nat := [2,4,8,0,32,64,69,256,45,321,103,361,289,65,108,98,109,39,41,109,360,96,109,99,5,325,302,45,64,70,301,325,257,65,0,325]

theorem envBound44788 : H12AffineFastState.Bounded env44788 := by
  intro p hp
  have h : env44788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44787_44788 : H12AffineEnvironment.transform 8 45 env44787 = env44788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env44787 == env44788) = true)

theorem identity44788 : scanCanonicalize (H12AffineFastState.compose env44788 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44788 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env44789 : List Nat := [2,4,8,0,32,64,69,68,45,5,103,45,101,65,108,98,109,39,41,109,44,96,109,99,5,1,106,45,64,70,105,1,69,65,0,1]

theorem envBound44789 : H12AffineFastState.Bounded env44789 := by
  intro p hp
  have h : env44789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44788_44789 : H12AffineEnvironment.transform 7 68 env44788 = env44789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44788 == env44789) = true)

theorem identity44789 : scanCanonicalize (H12AffineFastState.compose env44789 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound44789 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44790 : List Nat := [2,4,8,0,32,11,14,15,45,5,44,45,46,10,39,41,38,39,41,38,44,43,38,40,5,1,33,45,11,13,34,1,14,10,0,1]

theorem envBound44790 : H12AffineFastState.Bounded env44790 := by
  intro p hp
  have h : env44790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44789_44790 : H12AffineEnvironment.transform 5 11 env44789 = env44790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env44789 == env44790) = true)

theorem identity44790 : scanCanonicalize (H12AffineFastState.compose env44790 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44790 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44791 : List Nat := [2,4,2,0,32,1,4,5,39,5,38,39,36,0,39,35,38,39,35,38,38,33,38,34,5,1,33,39,1,7,34,1,4,0,0,1]

theorem envBound44791 : H12AffineFastState.Bounded env44791 := by
  intro p hp
  have h : env44791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44790_44791 : H12AffineEnvironment.transform 2 2 env44790 = env44791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44790 == env44791) = true)

theorem identity44791 : scanCanonicalize (H12AffineFastState.compose env44791 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44792 : List Nat := [2,2,2,0,32,1,2,3,33,3,32,33,34,0,33,35,32,33,35,32,32,33,32,34,3,1,33,33,1,1,34,1,2,0,0,1]

theorem envBound44792 : H12AffineFastState.Bounded env44792 := by
  intro p hp
  have h : env44792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44791_44792 : H12AffineEnvironment.transform 1 2 env44791 = env44792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44791 == env44792) = true)

theorem identity44792 : scanCanonicalize (H12AffineFastState.compose env44792 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44792 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44793 : List Nat := [2,2,2,0,0,1,2,3,1,3,0,1,2,0,1,3,0,1,3,0,0,1,0,2,3,1,1,1,1,1,2,1,2,0,0,1]

theorem envBound44793 : H12AffineFastState.Bounded env44793 := by
  intro p hp
  have h : env44793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44792_44793 : H12AffineEnvironment.transform 4 0 env44792 = env44793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44792 == env44793) = true)

def env44794 : List Nat := [2,4,8,1,32,64,69,256,512,320,2048,836,781,65,577,65536,66082,65605,516,576,837,589,66082,65537,5,65831,302,66147,64,67651,769,65831,257,64,1,324]

theorem envBound44794 : H12AffineFastState.Bounded env44794 := by
  intro p hp
  have h : env44794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44784_44794 : H12AffineEnvironment.transform 3 1 env44784 = env44794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44784 == env44794) = true)

theorem identity44794 : scanCanonicalize (H12AffineFastState.compose env44794 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound44794 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44795 : List Nat := [2,4,8,1,32,64,69,256,512,320,2048,836,781,65,577,806,260,867,516,576,837,589,260,807,5,513,302,325,64,2917,769,513,257,64,1,324]

theorem envBound44795 : H12AffineFastState.Bounded env44795 := by
  intro p hp
  have h : env44795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44794_44795 : H12AffineEnvironment.transform 15 806 env44794 = env44795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env44794 == env44795) = true)

theorem identity44795 : scanCanonicalize (H12AffineFastState.compose env44795 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound44795 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44796 : List Nat := [2,4,8,1,32,64,69,256,260,320,2048,64,9,65,325,34,260,103,256,324,65,329,260,35,5,261,302,325,64,2145,5,261,257,64,1,324]

theorem envBound44796 : H12AffineFastState.Bounded env44796 := by
  intro p hp
  have h : env44796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44795_44796 : H12AffineEnvironment.transform 8 260 env44795 = env44796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env44795 == env44796) = true)

theorem identity44796 : scanCanonicalize (H12AffineFastState.compose env44796 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound44796 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44797 : List Nat := [2,4,8,1,32,64,69,256,260,320,107,64,9,65,325,34,260,103,256,324,65,329,260,35,5,261,302,325,64,10,5,261,257,64,1,324]

theorem envBound44797 : H12AffineFastState.Bounded env44797 := by
  intro p hp
  have h : env44797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44796_44797 : H12AffineEnvironment.transform 10 107 env44796 = env44797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env44796 == env44797) = true)

theorem identity44797 : scanCanonicalize (H12AffineFastState.compose env44797 (packedSelected [0,1,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound44797 : packedSelected [0,1,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env44798 : List Nat := [2,4,8,1,32,64,69,40,44,104,107,64,9,65,109,34,44,103,40,108,65,97,44,35,5,45,6,109,64,10,5,45,41,64,1,108]

theorem envBound44798 : H12AffineFastState.Bounded env44798 := by
  intro p hp
  have h : env44798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44797_44798 : H12AffineEnvironment.transform 7 40 env44797 = env44798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env44797 == env44798) = true)

theorem identity44798 : scanCanonicalize (H12AffineFastState.compose env44798 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound44798 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44799 : List Nat := [2,4,8,1,32,43,46,40,44,3,0,43,9,42,6,34,44,12,40,7,42,10,44,35,5,45,6,6,43,10,5,45,41,43,1,7]

theorem envBound44799 : H12AffineFastState.Bounded env44799 := by
  intro p hp
  have h : env44799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44798_44799 : H12AffineEnvironment.transform 5 43 env44798 = env44799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env44798 == env44799) = true)

theorem identity44799 : scanCanonicalize (H12AffineFastState.compose env44799 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound44799 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44800 : List Nat := [2,4,8,1,13,6,3,5,1,3,0,6,9,7,6,15,1,12,5,7,7,10,1,14,5,0,6,6,6,10,5,0,4,6,1,7]

theorem envBound44800 : H12AffineFastState.Bounded env44800 := by
  intro p hp
  have h : env44800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44799_44800 : H12AffineEnvironment.transform 4 13 env44799 = env44800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env44799 == env44800) = true)

theorem identity44800 : scanCanonicalize (H12AffineFastState.compose env44800 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44800 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44801 : List Nat := [2,2,8,1,11,0,3,3,1,3,0,0,9,1,0,9,1,10,3,1,1,10,1,8,3,0,0,0,0,10,3,0,2,0,1,1]

theorem envBound44801 : H12AffineFastState.Bounded env44801 := by
  intro p hp
  have h : env44801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44800_44801 : H12AffineEnvironment.transform 1 2 env44800 = env44801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44800 == env44801) = true)

def env44802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4097,5277,74046,66896,13769,78894,1150,74815,1297,81226,8204,65831,257,1280,1345,5952]

theorem envBound44802 : H12AffineFastState.Bounded env44802 := by
  intro p hp
  have h : env44802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44716_44802 : H12AffineEnvironment.transform 17 65665 env44716 = env44802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44716 == env44802) = true)

theorem identity44802 : scanCanonicalize (H12AffineFastState.compose env44802 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound44802 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,65536,66599,65665,4416,276,4097,5277,65910,66896,5505,70758,1150,66679,1297,72962,68,65831,257,1280,1345,5952]

theorem envBound44803 : H12AffineFastState.Bounded env44803 := by
  intro p hp
  have h : env44803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44802_44803 : H12AffineEnvironment.transform 12 72 env44802 = env44803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44802 == env44803) = true)

def env44804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1296,277,65536,66599,65665,1876,276,1557,649,65910,66896,917,66162,1150,66679,1297,68374,68,65831,257,1280,1345,340]

theorem envBound44804 : H12AffineFastState.Bounded env44804 := by
  intro p hp
  have h : env44804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44803_44804 : H12AffineEnvironment.transform 11 1556 env44803 = env44804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env44803 == env44804) = true)

def env44805 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,65536,65895,65665,532,276,853,649,65910,65552,917,66162,318,65847,81,68374,68,65831,257,64,1,340]

theorem envBound44805 : H12AffineFastState.Bounded env44805 := by
  intro p hp
  have h : env44805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44804_44805 : H12AffineEnvironment.transform 9 320 env44804 = env44805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44804 == env44805) = true)

theorem identity44805 : scanCanonicalize (H12AffineFastState.compose env44805 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44805 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44806 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,114,277,243,532,276,853,649,260,98,917,512,318,325,81,2916,68,341,257,64,1,340]

theorem envBound44806 : H12AffineFastState.Bounded env44806 := by
  intro p hp
  have h : env44806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44805_44806 : H12AffineEnvironment.transform 15 114 env44805 = env44806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44805 == env44806) = true)

theorem identity44806 : scanCanonicalize (H12AffineFastState.compose env44806 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound44806 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44807 : List Nat := [2,4,8,16,32,64,128,256,261,320,2048,81,72,80,277,114,277,243,273,276,80,396,260,98,144,261,318,325,81,2145,68,341,257,64,1,340]

theorem envBound44807 : H12AffineFastState.Bounded env44807 := by
  intro p hp
  have h : env44807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44806_44807 : H12AffineEnvironment.transform 8 261 env44806 = env44807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env44806 == env44807) = true)

theorem identity44807 : scanCanonicalize (H12AffineFastState.compose env44807 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound44807 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44808 : List Nat := [2,4,8,16,32,42,128,256,261,298,2048,59,34,58,277,24,277,153,273,276,58,396,260,8,144,261,318,303,59,2059,46,319,257,42,1,318]

theorem envBound44808 : H12AffineFastState.Bounded env44808 := by
  intro p hp
  have h : env44808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44807_44808 : H12AffineEnvironment.transform 5 42 env44807 = env44808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env44807 == env44808) = true)

theorem identity44808 : scanCanonicalize (H12AffineFastState.compose env44808 (packedSelected [1,3,4,9,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound44808 : packedSelected [1,3,4,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env44809 : List Nat := [2,4,8,16,32,42,128,256,261,298,270,59,34,58,277,24,277,153,273,276,58,396,260,8,144,261,318,303,59,261,46,319,257,42,1,318]

theorem envBound44809 : H12AffineFastState.Bounded env44809 := by
  intro p hp
  have h : env44809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44808_44809 : H12AffineEnvironment.transform 10 270 env44808 = env44809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env44808 == env44809) = true)

theorem identity44809 : scanCanonicalize (H12AffineFastState.compose env44809 (packedSelected [1,5,8,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound44809 : packedSelected [1,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env44810 : List Nat := [2,4,8,16,32,42,128,9,12,35,7,59,34,58,28,24,28,153,24,29,58,133,13,8,144,12,55,38,59,12,46,54,8,42,1,55]

theorem envBound44810 : H12AffineFastState.Bounded env44810 := by
  intro p hp
  have h : env44810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44809_44810 : H12AffineEnvironment.transform 7 9 env44809 = env44810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env44809 == env44810) = true)

theorem identity44810 : scanCanonicalize (H12AffineFastState.compose env44810 (packedSelected [5,8,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44810 : packedSelected [5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env44811 : List Nat := [2,4,8,16,16,26,128,9,12,19,7,11,18,10,28,24,28,153,24,29,10,133,13,8,144,12,7,22,11,12,30,6,8,26,1,7]

theorem envBound44811 : H12AffineFastState.Bounded env44811 := by
  intro p hp
  have h : env44811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44810_44811 : H12AffineEnvironment.transform 4 16 env44810 = env44811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44810 == env44811) = true)

theorem identity44811 : scanCanonicalize (H12AffineFastState.compose env44811 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44811 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44812 : List Nat := [2,4,8,6,6,12,128,9,12,5,7,11,4,10,10,14,10,143,14,11,10,133,13,8,134,12,7,0,11,12,8,6,8,12,1,7]

theorem envBound44812 : H12AffineFastState.Bounded env44812 := by
  intro p hp
  have h : env44812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44811_44812 : H12AffineEnvironment.transform 3 6 env44811 = env44812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44811 == env44812) = true)

theorem identity44812 : scanCanonicalize (H12AffineFastState.compose env44812 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44812 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44813 : List Nat := [2,3,8,1,1,11,128,9,11,2,0,11,3,10,10,9,10,136,9,11,10,130,10,8,129,11,0,0,11,11,8,1,8,11,1,0]

theorem envBound44813 : H12AffineFastState.Bounded env44813 := by
  intro p hp
  have h : env44813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44812_44813 : H12AffineEnvironment.transform 1 3 env44812 = env44813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44812 == env44813) = true)

theorem identity44813 : scanCanonicalize (H12AffineFastState.compose env44813 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44813 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44814 : List Nat := [2,3,8,1,1,11,8,9,11,2,0,11,3,10,10,9,10,0,9,11,10,10,10,8,9,11,0,0,11,11,8,1,8,11,1,0]

theorem envBound44814 : H12AffineFastState.Bounded env44814 := by
  intro p hp
  have h : env44814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44813_44814 : H12AffineEnvironment.transform 6 8 env44813 = env44814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44813 == env44814) = true)

def env44815 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,65536,65894,65665,533,276,852,649,65910,65553,917,66162,319,65846,80,68374,68,65831,257,65,0,340]

theorem envBound44815 : H12AffineFastState.Bounded env44815 := by
  intro p hp
  have h : env44815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44804_44815 : H12AffineEnvironment.transform 9 321 env44804 = env44815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44804 == env44815) = true)

theorem identity44815 : scanCanonicalize (H12AffineFastState.compose env44815 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound44815 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44816 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,807,577,934,533,276,852,649,593,822,917,341,319,529,80,2097,68,512,257,65,0,340]

theorem envBound44816 : H12AffineFastState.Bounded env44816 := by
  intro p hp
  have h : env44816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44815_44816 : H12AffineEnvironment.transform 15 807 env44815 = env44816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env44815 == env44816) = true)

theorem identity44816 : scanCanonicalize (H12AffineFastState.compose env44816 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound44816 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44817 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,72,81,277,359,1,486,85,276,276,201,17,374,469,341,319,81,80,2097,68,64,257,65,0,340]

theorem envBound44817 : H12AffineFastState.Bounded env44817 := by
  intro p hp
  have h : env44817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44816_44817 : H12AffineEnvironment.transform 8 64 env44816 = env44817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env44816 == env44817) = true)

theorem identity44817 : scanCanonicalize (H12AffineFastState.compose env44817 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound44817 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env44818 : List Nat := [2,4,8,16,32,64,128,18,64,83,2048,7,72,81,7,117,1,244,85,6,6,201,17,100,199,71,45,81,80,2097,68,64,19,65,0,70]

theorem envBound44818 : H12AffineFastState.Bounded env44818 := by
  intro p hp
  have h : env44818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44817_44818 : H12AffineEnvironment.transform 7 18 env44817 = env44818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env44817 == env44818) = true)

theorem identity44818 : scanCanonicalize (H12AffineFastState.compose env44818 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound44818 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env44819 : List Nat := [2,4,8,16,32,61,128,18,61,46,2048,7,53,44,7,8,1,137,40,6,6,180,17,25,186,58,45,44,45,2097,57,61,19,60,0,59]

theorem envBound44819 : H12AffineFastState.Bounded env44819 := by
  intro p hp
  have h : env44819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44818_44819 : H12AffineEnvironment.transform 5 61 env44818 = env44819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env44818 == env44819) = true)

theorem identity44819 : scanCanonicalize (H12AffineFastState.compose env44819 (packedSelected [0,1,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound44819 : packedSelected [0,1,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44820 : List Nat := [2,4,8,16,32,61,128,18,61,46,32,7,53,44,7,8,1,137,40,6,6,180,17,25,186,58,45,44,45,17,57,61,19,60,0,59]

theorem envBound44820 : H12AffineFastState.Bounded env44820 := by
  intro p hp
  have h : env44820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44819_44820 : H12AffineEnvironment.transform 10 32 env44819 = env44820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env44819 == env44820) = true)

theorem identity44820 : scanCanonicalize (H12AffineFastState.compose env44820 (packedSelected [0,1,2,3,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44820 : packedSelected [0,1,2,3,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env44821 : List Nat := [2,4,8,11,32,38,128,9,38,46,32,7,46,44,7,8,1,137,40,6,6,175,10,2,161,33,45,44,45,10,34,38,8,39,0,32]

theorem envBound44821 : H12AffineFastState.Bounded env44821 := by
  intro p hp
  have h : env44821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44820_44821 : H12AffineEnvironment.transform 3 11 env44820 = env44821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44820 == env44821) = true)

theorem identity44821 : scanCanonicalize (H12AffineFastState.compose env44821 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound44821 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44822 : List Nat := [2,4,8,11,32,38,35,9,38,46,32,7,46,44,7,8,1,42,40,6,6,12,10,2,2,33,45,44,45,10,34,38,8,39,0,32]

theorem envBound44822 : H12AffineFastState.Bounded env44822 := by
  intro p hp
  have h : env44822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44821_44822 : H12AffineEnvironment.transform 6 35 env44821 = env44822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env44821 == env44822) = true)

theorem identity44822 : scanCanonicalize (H12AffineFastState.compose env44822 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44822 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44823 : List Nat := [2,4,8,11,0,6,3,9,6,14,0,7,14,12,7,8,1,10,8,6,6,12,10,2,2,1,13,12,13,10,2,6,8,7,0,0]

theorem envBound44823 : H12AffineFastState.Bounded env44823 := by
  intro p hp
  have h : env44823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44822_44823 : H12AffineEnvironment.transform 4 0 env44822 = env44823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44822 == env44823) = true)

theorem identity44823 : scanCanonicalize (H12AffineFastState.compose env44823 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44824 : List Nat := [2,4,3,0,0,6,3,2,6,5,0,7,5,7,7,3,1,1,3,6,6,7,1,2,2,1,6,7,6,1,2,6,3,7,0,0]

theorem envBound44824 : H12AffineFastState.Bounded env44824 := by
  intro p hp
  have h : env44824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44823_44824 : H12AffineEnvironment.transform 2 3 env44823 = env44824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44823 == env44824) = true)

def env44825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1296,277,65536,66599,65665,1877,276,1556,648,65910,66896,916,66163,1150,66679,1297,68375,68,65831,257,1280,1345,341]

theorem envBound44825 : H12AffineFastState.Bounded env44825 := by
  intro p hp
  have h : env44825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44803_44825 : H12AffineEnvironment.transform 11 1557 env44803 = env44825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env44803 == env44825) = true)

def env44826 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,65536,65895,65665,533,276,852,648,65910,65552,916,66163,318,65847,81,68375,68,65831,257,64,1,341]

theorem envBound44826 : H12AffineFastState.Bounded env44826 := by
  intro p hp
  have h : env44826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44825_44826 : H12AffineEnvironment.transform 9 320 env44825 = env44826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44825 == env44826) = true)

theorem identity44826 : scanCanonicalize (H12AffineFastState.compose env44826 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44826 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44827 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,114,277,243,533,276,852,648,260,98,916,513,318,325,81,2917,68,341,257,64,1,341]

theorem envBound44827 : H12AffineFastState.Bounded env44827 := by
  intro p hp
  have h : env44827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44826_44827 : H12AffineEnvironment.transform 15 114 env44826 = env44827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44826 == env44827) = true)

theorem identity44827 : scanCanonicalize (H12AffineFastState.compose env44827 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound44827 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44828 : List Nat := [2,4,8,16,32,64,128,256,260,320,2048,81,72,80,277,114,277,243,273,276,80,396,260,98,144,261,318,325,81,2145,68,341,257,64,1,341]

theorem envBound44828 : H12AffineFastState.Bounded env44828 := by
  intro p hp
  have h : env44828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44827_44828 : H12AffineEnvironment.transform 8 260 env44827 = env44828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env44827 == env44828) = true)

theorem identity44828 : scanCanonicalize (H12AffineFastState.compose env44828 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound44828 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44829 : List Nat := [2,4,8,16,26,64,128,256,260,320,2048,81,72,80,277,72,277,201,273,276,80,396,260,88,144,261,260,325,81,2139,68,341,257,64,1,341]

theorem envBound44829 : H12AffineFastState.Bounded env44829 := by
  intro p hp
  have h : env44829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44828_44829 : H12AffineEnvironment.transform 4 26 env44828 = env44829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env44828 == env44829) = true)

theorem identity44829 : scanCanonicalize (H12AffineFastState.compose env44829 (packedSelected [1,3,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound44829 : packedSelected [1,3,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44830 : List Nat := [2,4,8,16,26,64,128,256,260,320,270,81,72,80,277,72,277,201,273,276,80,396,260,88,144,261,260,325,81,341,68,341,257,64,1,341]

theorem envBound44830 : H12AffineFastState.Bounded env44830 := by
  intro p hp
  have h : env44830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44829_44830 : H12AffineEnvironment.transform 10 270 env44829 = env44830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env44829 == env44830) = true)

theorem identity44830 : scanCanonicalize (H12AffineFastState.compose env44830 (packedSelected [3,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound44830 : packedSelected [3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env44831 : List Nat := [2,4,8,16,26,6,128,256,260,262,270,23,14,22,277,14,277,143,273,276,22,396,260,30,144,261,260,259,23,275,2,275,257,6,1,275]

theorem envBound44831 : H12AffineFastState.Bounded env44831 := by
  intro p hp
  have h : env44831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44830_44831 : H12AffineEnvironment.transform 5 6 env44830 = env44831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env44830 == env44831) = true)

theorem identity44831 : scanCanonicalize (H12AffineFastState.compose env44831 (packedSelected [1,3,4,5,8,9,10,16] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44831 : packedSelected [1,3,4,5,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env44832 : List Nat := [2,4,2,16,16,6,128,256,260,262,260,23,4,22,277,4,277,133,273,276,22,390,260,20,144,261,260,259,23,275,2,275,257,6,1,275]

theorem envBound44832 : H12AffineFastState.Bounded env44832 := by
  intro p hp
  have h : env44832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44831_44832 : H12AffineEnvironment.transform 2 2 env44831 = env44832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44831 == env44832) = true)

theorem identity44832 : scanCanonicalize (H12AffineFastState.compose env44832 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44832 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44833 : List Nat := [2,4,2,16,16,6,128,5,1,3,1,23,4,22,16,4,16,133,20,17,22,131,1,20,144,0,1,6,23,22,2,22,4,6,1,22]

theorem envBound44833 : H12AffineFastState.Bounded env44833 := by
  intro p hp
  have h : env44833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44832_44833 : H12AffineEnvironment.transform 7 5 env44832 = env44833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44832 == env44833) = true)

theorem identity44833 : scanCanonicalize (H12AffineFastState.compose env44833 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound44833 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44834 : List Nat := [2,4,2,16,16,6,2,5,1,3,1,23,4,22,16,4,16,7,20,17,22,1,1,20,18,0,1,6,23,22,2,22,4,6,1,22]

theorem envBound44834 : H12AffineFastState.Bounded env44834 := by
  intro p hp
  have h : env44834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44833_44834 : H12AffineEnvironment.transform 6 2 env44833 = env44834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env44833 == env44834) = true)

def env44835 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,65536,65894,65665,532,276,853,648,65910,65553,916,66163,319,65846,80,68375,68,65831,257,65,0,341]

theorem envBound44835 : H12AffineFastState.Bounded env44835 := by
  intro p hp
  have h : env44835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44825_44835 : H12AffineEnvironment.transform 9 321 env44825 = env44835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44825 == env44835) = true)

theorem identity44835 : scanCanonicalize (H12AffineFastState.compose env44835 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound44835 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44836 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,806,576,935,532,276,853,648,592,823,916,341,319,528,80,2097,68,513,257,65,0,341]

theorem envBound44836 : H12AffineFastState.Bounded env44836 := by
  intro p hp
  have h : env44836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44835_44836 : H12AffineEnvironment.transform 15 806 env44835 = env44836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env44835 == env44836) = true)

theorem identity44836 : scanCanonicalize (H12AffineFastState.compose env44836 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound44836 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44837 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,72,81,277,359,1,486,85,276,276,201,17,374,469,341,319,81,80,2097,68,64,257,65,0,341]

theorem envBound44837 : H12AffineFastState.Bounded env44837 := by
  intro p hp
  have h : env44837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44836_44837 : H12AffineEnvironment.transform 8 65 env44836 = env44837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env44836 == env44837) = true)

theorem identity44837 : scanCanonicalize (H12AffineFastState.compose env44837 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound44837 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env44838 : List Nat := [2,4,8,16,32,64,128,18,65,83,2048,7,72,81,7,117,1,244,85,6,6,201,17,100,199,71,45,81,80,2097,68,64,19,65,0,71]

theorem envBound44838 : H12AffineFastState.Bounded env44838 := by
  intro p hp
  have h : env44838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44837_44838 : H12AffineEnvironment.transform 7 18 env44837 = env44838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env44837 == env44838) = true)

theorem identity44838 : scanCanonicalize (H12AffineFastState.compose env44838 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound44838 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env44839 : List Nat := [2,4,8,16,32,61,128,18,60,46,2048,7,53,44,7,8,1,137,40,6,6,180,17,25,186,58,45,44,45,2097,57,61,19,60,0,58]

theorem envBound44839 : H12AffineFastState.Bounded env44839 := by
  intro p hp
  have h : env44839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44838_44839 : H12AffineEnvironment.transform 5 61 env44838 = env44839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env44838 == env44839) = true)

theorem identity44839 : scanCanonicalize (H12AffineFastState.compose env44839 (packedSelected [0,1,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound44839 : packedSelected [0,1,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44840 : List Nat := [2,4,8,16,32,61,128,18,60,46,33,7,53,44,7,8,1,137,40,6,6,180,17,25,186,58,45,44,45,16,57,61,19,60,0,58]

theorem envBound44840 : H12AffineFastState.Bounded env44840 := by
  intro p hp
  have h : env44840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44839_44840 : H12AffineEnvironment.transform 10 33 env44839 = env44840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env44839 == env44840) = true)

theorem identity44840 : scanCanonicalize (H12AffineFastState.compose env44840 (packedSelected [0,1,2,3,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound44840 : packedSelected [0,1,2,3,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env44841 : List Nat := [2,4,8,13,32,32,128,15,33,46,33,7,40,44,7,8,1,137,40,6,6,169,12,4,167,39,45,44,45,13,36,32,14,33,0,39]

theorem envBound44841 : H12AffineFastState.Bounded env44841 := by
  intro p hp
  have h : env44841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44840_44841 : H12AffineEnvironment.transform 3 13 env44840 = env44841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env44840 == env44841) = true)

theorem identity44841 : scanCanonicalize (H12AffineFastState.compose env44841 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound44841 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44842 : List Nat := [2,4,8,13,32,32,35,15,33,46,33,7,40,44,7,8,1,42,40,6,6,10,12,4,4,39,45,44,45,13,36,32,14,33,0,39]

theorem envBound44842 : H12AffineFastState.Bounded env44842 := by
  intro p hp
  have h : env44842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44841_44842 : H12AffineEnvironment.transform 6 35 env44841 = env44842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env44841 == env44842) = true)

theorem identity44842 : scanCanonicalize (H12AffineFastState.compose env44842 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44842 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44843 : List Nat := [2,4,8,13,7,7,4,15,6,9,6,7,15,11,7,8,1,13,15,6,6,10,12,4,4,0,10,11,10,13,3,7,14,6,0,0]

theorem envBound44843 : H12AffineFastState.Bounded env44843 := by
  intro p hp
  have h : env44843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44842_44843 : H12AffineEnvironment.transform 4 7 env44842 = env44843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44842 == env44843) = true)

theorem identity44843 : scanCanonicalize (H12AffineFastState.compose env44843 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44844 : List Nat := [2,4,2,7,7,7,4,5,6,3,6,7,5,1,7,2,1,7,5,6,6,0,6,4,4,0,0,1,0,7,3,7,4,6,0,0]

theorem envBound44844 : H12AffineFastState.Bounded env44844 := by
  intro p hp
  have h : env44844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44843_44844 : H12AffineEnvironment.transform 2 2 env44843 = env44844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44843 == env44844) = true)

theorem identity44844 : scanCanonicalize (H12AffineFastState.compose env44844 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44844 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44845 : List Nat := [2,2,2,1,1,1,2,3,0,3,0,1,3,1,1,2,1,1,3,0,0,0,0,2,2,0,0,1,0,1,3,1,2,0,0,0]

theorem envBound44845 : H12AffineFastState.Bounded env44845 := by
  intro p hp
  have h : env44845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44844_44845 : H12AffineEnvironment.transform 1 2 env44844 = env44845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44844 == env44845) = true)

def env44846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4097,5277,74047,66896,13768,78894,328959,74814,1297,81227,8205,65830,257,1280,1345,5953]

theorem envBound44846 : H12AffineFastState.Bounded env44846 := by
  intro p hp
  have h : env44846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44715_44846 : H12AffineEnvironment.transform 13 1297 env44715 = env44846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44715 == env44846) = true)

def env44847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4097,5277,74047,66896,13768,78894,1151,74814,1297,81227,8205,65830,257,1280,1345,5953]

theorem envBound44847 : H12AffineFastState.Bounded env44847 := by
  intro p hp
  have h : env44847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44846_44847 : H12AffineEnvironment.transform 17 65664 env44846 = env44847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44846 == env44847) = true)

theorem identity44847 : scanCanonicalize (H12AffineFastState.compose env44847 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound44847 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44848 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,65536,74031,65664,4417,8541,4097,4573,74047,65552,12424,78190,319,74110,81,79883,8205,65830,257,64,1,4609]

theorem envBound44848 : H12AffineFastState.Bounded env44848 := by
  intro p hp
  have h : env44848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44847_44848 : H12AffineEnvironment.transform 9 320 env44847 = env44848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44847 == env44848) = true)

def env44849 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,81,8540,65536,74031,65664,533,8541,853,649,74047,65552,9180,74298,319,74110,81,76639,8205,65830,257,64,1,341]

theorem envBound44849 : H12AffineFastState.Bounded env44849 := by
  intro p hp
  have h : env44849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44848_44849 : H12AffineEnvironment.transform 11 852 env44848 = env44849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env44848 == env44849) = true)

def env44850 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,65536,74031,65664,517,8525,837,649,74031,65536,9164,74282,303,74094,65,76623,8205,65830,257,64,1,325]

theorem envBound44850 : H12AffineFastState.Bounded env44850 := by
  intro p hp
  have h : env44850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44849_44850 : H12AffineEnvironment.transform 3 0 env44849 = env44850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44849 == env44850) = true)

theorem identity44850 : scanCanonicalize (H12AffineFastState.compose env44850 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 517) := by decide +kernel

theorem selectedBound44850 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44851 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,517,65,841,65536,66346,65664,517,840,837,649,66346,65536,457,65583,303,66411,65,67914,520,65830,257,64,1,325]

theorem envBound44851 : H12AffineFastState.Bounded env44851 := by
  intro p hp
  have h : env44851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44850_44851 : H12AffineEnvironment.transform 12 517 env44850 = env44851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 517 env44850 == env44851) = true)

def env44852 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,260,69,65,265,65536,65898,65664,69,264,261,201,65898,65536,457,65583,303,65835,65,67914,72,65830,257,64,1,325]

theorem envBound44852 : H12AffineFastState.Bounded env44852 := by
  intro p hp
  have h : env44852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44851_44852 : H12AffineEnvironment.transform 8 64 env44851 = env44852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env44851 == env44852) = true)

theorem identity44852 : scanCanonicalize (H12AffineFastState.compose env44852 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 362) := by decide +kernel

theorem selectedBound44852 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env44853 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,260,69,65,265,362,0,490,69,264,261,201,0,362,457,325,303,65,65,2080,72,76,257,64,1,325]

theorem envBound44853 : H12AffineFastState.Bounded env44853 := by
  intro p hp
  have h : env44853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44852_44853 : H12AffineEnvironment.transform 15 362 env44852 = env44853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 362 env44852 == env44853) = true)

theorem identity44853 : scanCanonicalize (H12AffineFastState.compose env44853 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound44853 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env44854 : List Nat := [2,4,8,0,32,64,128,256,64,320,390,260,69,65,265,362,0,490,69,264,261,201,0,362,457,325,303,65,65,422,72,76,257,64,1,325]

theorem envBound44854 : H12AffineFastState.Bounded env44854 := by
  intro p hp
  have h : env44854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44853_44854 : H12AffineEnvironment.transform 10 390 env44853 = env44854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env44853 == env44854) = true)

theorem identity44854 : scanCanonicalize (H12AffineFastState.compose env44854 (packedSelected [1,3,4,5,9,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 224) := by decide +kernel

theorem selectedBound44854 : packedSelected [1,3,4,5,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env44855 : List Nat := [2,4,8,0,32,64,128,224,64,160,102,228,69,65,233,138,0,10,69,232,229,201,0,138,41,165,207,65,65,70,72,76,225,64,1,165]

theorem envBound44855 : H12AffineFastState.Bounded env44855 := by
  intro p hp
  have h : env44855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44854_44855 : H12AffineEnvironment.transform 7 224 env44854 = env44855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env44854 == env44855) = true)

theorem identity44855 : scanCanonicalize (H12AffineFastState.compose env44855 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound44855 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44856 : List Nat := [2,4,8,0,32,64,41,73,64,9,102,77,69,65,64,35,0,10,69,65,76,96,0,35,41,12,102,65,65,70,72,76,72,64,1,12]

theorem envBound44856 : H12AffineFastState.Bounded env44856 := by
  intro p hp
  have h : env44856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44855_44856 : H12AffineEnvironment.transform 6 41 env44855 = env44856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env44855 == env44856) = true)

theorem identity44856 : scanCanonicalize (H12AffineFastState.compose env44856 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44856 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env44857 : List Nat := [2,4,4,0,32,64,37,69,64,5,102,65,69,65,64,35,0,6,69,65,64,96,0,35,37,0,102,65,65,70,68,64,68,64,1,0]

theorem envBound44857 : H12AffineFastState.Bounded env44857 := by
  intro p hp
  have h : env44857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44856_44857 : H12AffineEnvironment.transform 2 4 env44856 = env44857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44856 == env44857) = true)

theorem identity44857 : scanCanonicalize (H12AffineFastState.compose env44857 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44857 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44858 : List Nat := [2,2,2,0,32,64,35,67,64,3,96,65,67,65,64,35,0,0,67,65,64,96,0,35,35,0,96,65,65,64,66,64,66,64,1,0]

theorem envBound44858 : H12AffineFastState.Bounded env44858 := by
  intro p hp
  have h : env44858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44857_44858 : H12AffineEnvironment.transform 1 2 env44857 = env44858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44857 == env44858) = true)

theorem identity44858 : scanCanonicalize (H12AffineFastState.compose env44858 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44859 : List Nat := [2,2,2,0,32,1,35,2,1,3,33,0,2,0,1,35,0,0,2,0,1,33,0,35,35,0,33,0,0,1,3,1,3,1,1,0]

theorem envBound44859 : H12AffineFastState.Bounded env44859 := by
  intro p hp
  have h : env44859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44858_44859 : H12AffineEnvironment.transform 5 1 env44858 = env44859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44858 == env44859) = true)

theorem identity44859 : scanCanonicalize (H12AffineFastState.compose env44859 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound44859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44860 : List Nat := [2,2,2,0,2,1,1,2,1,3,3,0,2,0,1,1,0,0,2,0,1,3,0,1,1,0,3,0,0,1,3,1,3,1,1,0]

theorem envBound44860 : H12AffineFastState.Bounded env44860 := by
  intro p hp
  have h : env44860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44859_44860 : H12AffineEnvironment.transform 4 2 env44859 = env44860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env44859 == env44860) = true)

theorem identity44860 : scanCanonicalize (H12AffineFastState.compose env44860 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44860 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44861 : List Nat := [0,0,0,0,0,1,1,0,1,1,1,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1,0,0,1,1,1,1,1,1,0]

theorem envBound44861 : H12AffineFastState.Bounded env44861 := by
  intro p hp
  have h : env44861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44860_44861 : H12AffineEnvironment.transform 0 0 env44860 = env44861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44860 == env44861) = true)

def env44862 : List Nat := [2,4,8,0,32,64,128,256,65,320,2048,261,68,65,264,65536,65899,65664,68,265,260,200,65899,65536,457,65583,303,65834,65,67914,73,65830,257,64,1,325]

theorem envBound44862 : H12AffineFastState.Bounded env44862 := by
  intro p hp
  have h : env44862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44851_44862 : H12AffineEnvironment.transform 8 65 env44851 = env44862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env44851 == env44862) = true)

theorem identity44862 : scanCanonicalize (H12AffineFastState.compose env44862 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound44862 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env44863 : List Nat := [2,4,8,0,32,64,128,256,65,320,2048,261,68,65,264,359,12,487,68,265,260,200,12,359,457,328,303,77,65,2093,73,65,257,64,1,325]

theorem envBound44863 : H12AffineFastState.Bounded env44863 := by
  intro p hp
  have h : env44863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44862_44863 : H12AffineEnvironment.transform 15 359 env44862 = env44863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env44862 == env44863) = true)

theorem identity44863 : scanCanonicalize (H12AffineFastState.compose env44863 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44863 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44864 : List Nat := [2,4,8,0,32,1,128,256,0,257,2048,261,5,0,264,294,12,422,5,265,260,137,12,294,392,265,303,12,0,2093,8,0,257,1,1,260]

theorem envBound44864 : H12AffineFastState.Bounded env44864 := by
  intro p hp
  have h : env44864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44863_44864 : H12AffineEnvironment.transform 5 1 env44863 = env44864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44863 == env44864) = true)

theorem identity44864 : scanCanonicalize (H12AffineFastState.compose env44864 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound44864 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44865 : List Nat := [2,4,8,0,32,1,128,35,0,34,2048,38,5,0,43,5,12,133,5,42,39,137,12,5,171,42,12,12,0,2093,8,0,34,1,1,39]

theorem envBound44865 : H12AffineFastState.Bounded env44865 := by
  intro p hp
  have h : env44865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44864_44865 : H12AffineEnvironment.transform 7 35 env44864 = env44865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env44864 == env44865) = true)

theorem identity44865 : scanCanonicalize (H12AffineFastState.compose env44865 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound44865 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env44866 : List Nat := [2,4,8,0,32,1,128,35,0,34,6,38,5,0,43,5,12,133,5,42,39,137,12,5,171,42,12,12,0,43,8,0,34,1,1,39]

theorem envBound44866 : H12AffineFastState.Bounded env44866 := by
  intro p hp
  have h : env44866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44865_44866 : H12AffineEnvironment.transform 10 6 env44865 = env44866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env44865 == env44866) = true)

theorem identity44866 : scanCanonicalize (H12AffineFastState.compose env44866 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound44866 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44867 : List Nat := [2,4,8,0,32,1,5,35,0,34,6,38,5,0,43,5,12,0,5,42,39,12,12,5,46,42,12,12,0,43,8,0,34,1,1,39]

theorem envBound44867 : H12AffineFastState.Bounded env44867 := by
  intro p hp
  have h : env44867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44866_44867 : H12AffineEnvironment.transform 6 5 env44866 = env44867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env44866 == env44867) = true)

def env44868 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,65536,74031,65664,516,8524,836,649,74030,65537,9165,74283,302,74095,64,76622,8205,65830,257,64,1,324]

theorem envBound44868 : H12AffineFastState.Bounded env44868 := by
  intro p hp
  have h : env44868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44849_44868 : H12AffineEnvironment.transform 3 1 env44849 = env44868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44849 == env44868) = true)

theorem identity44868 : scanCanonicalize (H12AffineFastState.compose env44868 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound44868 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44869 : List Nat := [2,4,8,1,32,64,128,256,77,320,2048,264,8192,64,8525,65536,74031,65664,73,8524,265,196,74030,65537,8576,73830,302,74095,64,76035,8205,65830,257,64,1,324]

theorem envBound44869 : H12AffineFastState.Bounded env44869 := by
  intro p hp
  have h : env44869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44868_44869 : H12AffineEnvironment.transform 8 77 env44868 = env44869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env44868 == env44869) = true)

def env44870 : List Nat := [2,4,8,1,32,64,128,256,77,320,2048,264,72,64,261,65536,65895,65664,73,260,265,196,65894,65537,456,65582,302,65831,64,67915,69,65830,257,64,1,324]

theorem envBound44870 : H12AffineFastState.Bounded env44870 := by
  intro p hp
  have h : env44870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44869_44870 : H12AffineEnvironment.transform 12 72 env44869 = env44870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44869 == env44870) = true)

theorem identity44870 : scanCanonicalize (H12AffineFastState.compose env44870 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 362) := by decide +kernel

theorem selectedBound44870 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44871 : List Nat := [2,4,8,1,32,64,128,256,77,320,2048,264,72,64,261,362,13,490,73,260,265,196,12,363,456,324,302,77,64,2081,69,76,257,64,1,324]

end H12CloudChart2