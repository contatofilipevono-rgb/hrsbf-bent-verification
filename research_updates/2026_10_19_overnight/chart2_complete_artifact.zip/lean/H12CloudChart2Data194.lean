import H12CloudChart2Data193

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans48752_48756 : H12AffineEnvironment.transform 11 1345 env48752 = env48756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env48752 == env48756) = true)

theorem identity48756 : scanCanonicalize (H12AffineFastState.compose env48756 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48757 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,32768,32883,80,262144,41037,32769,80,41089,16,262336,33236,41245,41011,1,41309,43128,262563,17,256,262567,81,41821]

theorem envBound48757 : H12AffineFastState.Bounded env48757 := by
  intro p hp
  have h : env48757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48756_48757 : H12AffineEnvironment.transform 9 273 env48756 = env48757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48756 == env48757) = true)

theorem identity48757 : scanCanonicalize (H12AffineFastState.compose env48757 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48757 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48758 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,8541,8494,80,262144,272,8540,80,476,16,262336,8329,64,366,1,0,2341,262563,17,256,262567,81,512]

theorem envBound48758 : H12AffineFastState.Bounded env48758 := by
  intro p hp
  have h : env48758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48757_48758 : H12AffineEnvironment.transform 14 8541 env48757 = env48758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48757 == env48758) = true)

theorem identity48758 : scanCanonicalize (H12AffineFastState.compose env48758 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound48758 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48759 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,8541,8494,80,242,272,8540,80,476,16,50,8329,64,366,1,0,2341,337,17,256,341,81,512]

theorem envBound48759 : H12AffineFastState.Bounded env48759 := by
  intro p hp
  have h : env48759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48758_48759 : H12AffineEnvironment.transform 17 242 env48758 = env48759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env48758 == env48759) = true)

theorem identity48759 : scanCanonicalize (H12AffineFastState.compose env48759 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound48759 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48760 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,980,0,649,762,80,242,272,648,80,476,16,50,861,64,366,1,0,2341,337,17,256,341,81,512]

theorem envBound48760 : H12AffineFastState.Bounded env48760 := by
  intro p hp
  have h : env48760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48759_48760 : H12AffineEnvironment.transform 12 980 env48759 = env48760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env48759 == env48760) = true)

theorem identity48760 : scanCanonicalize (H12AffineFastState.compose env48760 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48760 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48761 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,900,0,649,682,0,162,272,648,0,396,16,50,781,16,318,1,0,2341,257,17,256,261,1,512]

theorem envBound48761 : H12AffineFastState.Bounded env48761 := by
  intro p hp
  have h : env48761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48760_48761 : H12AffineEnvironment.transform 5 16 env48760 = env48761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48760 == env48761) = true)

theorem identity48761 : scanCanonicalize (H12AffineFastState.compose env48761 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound48761 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env48762 : List Nat := [2,4,8,16,32,16,128,256,512,273,390,0,900,0,649,682,0,162,272,648,0,396,16,50,781,16,318,1,0,163,257,17,256,261,1,512]

theorem envBound48762 : H12AffineFastState.Bounded env48762 := by
  intro p hp
  have h : env48762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48761_48762 : H12AffineEnvironment.transform 10 390 env48761 = env48762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env48761 == env48762) = true)

theorem identity48762 : scanCanonicalize (H12AffineFastState.compose env48762 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48762 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48763 : List Nat := [2,4,8,16,32,16,128,20,512,5,146,0,656,0,649,682,0,162,4,648,0,152,16,50,537,16,42,1,0,163,21,17,20,17,1,512]

theorem envBound48763 : H12AffineFastState.Bounded env48763 := by
  intro p hp
  have h : env48763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48762_48763 : H12AffineEnvironment.transform 7 20 env48762 = env48763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48762 == env48763) = true)

theorem identity48763 : scanCanonicalize (H12AffineFastState.compose env48763 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound48763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48764 : List Nat := [2,4,8,16,32,16,14,20,512,5,28,0,542,0,519,548,0,44,4,518,0,22,16,50,537,16,42,1,0,45,21,17,20,17,1,512]

theorem envBound48764 : H12AffineFastState.Bounded env48764 := by
  intro p hp
  have h : env48764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48763_48764 : H12AffineEnvironment.transform 6 14 env48763 = env48764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env48763 == env48764) = true)

theorem identity48764 : scanCanonicalize (H12AffineFastState.compose env48764 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48764 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48765 : List Nat := [2,2,8,16,32,16,8,18,512,3,26,0,536,0,513,546,0,42,2,512,0,16,16,50,537,16,42,1,0,43,19,17,18,17,1,512]

theorem envBound48765 : H12AffineFastState.Bounded env48765 := by
  intro p hp
  have h : env48765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48764_48765 : H12AffineEnvironment.transform 1 2 env48764 = env48765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48764 == env48765) = true)

theorem identity48765 : scanCanonicalize (H12AffineFastState.compose env48765 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48765 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48766 : List Nat := [2,2,8,16,11,16,8,18,512,3,26,0,536,0,513,521,0,1,2,512,0,16,16,25,537,16,1,1,0,0,19,17,18,17,1,512]

theorem envBound48766 : H12AffineFastState.Bounded env48766 := by
  intro p hp
  have h : env48766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48765_48766 : H12AffineEnvironment.transform 4 11 env48765 = env48766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48765 == env48766) = true)

theorem identity48766 : scanCanonicalize (H12AffineFastState.compose env48766 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48767 : List Nat := [2,2,8,10,11,10,8,8,512,3,0,0,514,0,513,521,0,1,2,512,0,10,10,3,515,10,1,1,0,0,9,11,8,11,1,512]

theorem envBound48767 : H12AffineFastState.Bounded env48767 := by
  intro p hp
  have h : env48767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48766_48767 : H12AffineEnvironment.transform 3 10 env48766 = env48767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48766 == env48767) = true)

theorem identity48767 : scanCanonicalize (H12AffineFastState.compose env48767 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48768 : List Nat := [2,2,8,10,11,10,8,8,1,3,0,0,3,0,0,8,0,1,2,1,0,10,10,3,2,10,1,1,0,0,9,11,8,11,1,1]

theorem envBound48768 : H12AffineFastState.Bounded env48768 := by
  intro p hp
  have h : env48768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48767_48768 : H12AffineEnvironment.transform 8 1 env48767 = env48768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48767 == env48768) = true)

def env48769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86519,94527,77841,1297,74815,96347,381312,1280,256,381316,1344,95102]

theorem envBound48769 : H12AffineFastState.Bounded env48769 := by
  intro p hp
  have h : env48769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48700_48769 : H12AffineEnvironment.transform 16 16465 env48700 = env48769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env48700 == env48769) = true)

def env48770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70887,78895,77841,1297,74815,81227,365712,1280,256,365716,1344,79470]

theorem envBound48770 : H12AffineFastState.Bounded env48770 := by
  intro p hp
  have h : env48770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48769_48770 : H12AffineEnvironment.transform 13 1296 env48769 = env48770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env48769 == env48770) = true)

theorem identity48770 : scanCanonicalize (H12AffineFastState.compose env48770 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound48770 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,17,266385,38037,46173,45155,1297,42061,48441,267490,1280,256,267494,1344,46620]

theorem envBound48771 : H12AffineFastState.Bounded env48771 := by
  intro p hp
  have h : env48771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48770_48771 : H12AffineEnvironment.transform 15 32882 env48770 = env48771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env48770 == env48771) = true)

def env48772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263633,33237,41245,42275,1297,42061,43129,262562,1280,256,262566,1344,41820]

theorem envBound48772 : H12AffineFastState.Bounded env48772 := by
  intro p hp
  have h : env48772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48771_48772 : H12AffineEnvironment.transform 11 1344 env48771 = env48772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env48771 == env48772) = true)

theorem identity48772 : scanCanonicalize (H12AffineFastState.compose env48772 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound48772 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,439,42333,32769,1344,41089,17,1126,33237,41245,42275,1297,42061,43129,21,1280,256,17,1344,41820]

theorem envBound48773 : H12AffineFastState.Bounded env48773 := by
  intro p hp
  have h : env48773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48772_48773 : H12AffineEnvironment.transform 17 439 env48772 = env48773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env48772 == env48773) = true)

theorem identity48773 : scanCanonicalize (H12AffineFastState.compose env48773 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48773 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1345,439,1025,8541,1344,477,17,1126,8329,65,1151,1297,1297,2341,21,1280,256,17,1344,512]

theorem envBound48774 : H12AffineFastState.Bounded env48774 := by
  intro p hp
  have h : env48774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48773_48774 : H12AffineEnvironment.transform 14 8540 env48773 = env48774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48773 == env48774) = true)

theorem identity48774 : scanCanonicalize (H12AffineFastState.compose env48774 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound48774 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48775 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,8192,1108,8216,8298,1029,243,1025,8217,1028,153,17,1126,8329,65,1151,1109,1109,2145,21,1092,68,17,1028,512]

theorem envBound48775 : H12AffineFastState.Bounded env48775 := by
  intro p hp
  have h : env48775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48774_48775 : H12AffineEnvironment.transform 7 68 env48774 = env48775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env48774 == env48775) = true)

theorem identity48775 : scanCanonicalize (H12AffineFastState.compose env48775 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound48775 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48776 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,656,1108,648,762,1029,243,1025,649,1028,153,17,1126,537,65,1151,1109,1109,2145,21,1092,68,17,1028,512]

theorem envBound48776 : H12AffineFastState.Bounded env48776 := by
  intro p hp
  have h : env48776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48775_48776 : H12AffineEnvironment.transform 12 656 env48775 = env48776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env48775 == env48776) = true)

theorem identity48776 : scanCanonicalize (H12AffineFastState.compose env48776 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48776 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48777 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,656,1028,648,682,1029,163,1025,649,1028,153,17,1078,537,17,1071,1029,1029,2097,21,1044,20,17,1028,512]

theorem envBound48777 : H12AffineFastState.Bounded env48777 := by
  intro p hp
  have h : env48777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48776_48777 : H12AffineEnvironment.transform 5 16 env48776 = env48777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48776 == env48777) = true)

theorem identity48777 : scanCanonicalize (H12AffineFastState.compose env48777 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound48777 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48778 : List Nat := [2,4,8,16,32,16,128,20,512,1024,43,1028,656,1028,648,682,1029,163,1025,649,1028,153,17,1078,537,17,1071,1029,1029,26,21,1044,20,17,1028,512]

theorem envBound48778 : H12AffineFastState.Bounded env48778 := by
  intro p hp
  have h : env48778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48777_48778 : H12AffineEnvironment.transform 10 43 env48777 = env48778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env48777 == env48778) = true)

theorem identity48778 : scanCanonicalize (H12AffineFastState.compose env48778 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound48778 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env48779 : List Nat := [2,4,8,16,32,16,128,20,512,517,43,513,656,513,648,682,512,163,516,649,513,153,17,563,537,17,554,512,512,26,21,529,20,17,513,512]

theorem envBound48779 : H12AffineFastState.Bounded env48779 := by
  intro p hp
  have h : env48779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48778_48779 : H12AffineEnvironment.transform 9 517 env48778 = env48779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env48778 == env48779) = true)

theorem identity48779 : scanCanonicalize (H12AffineFastState.compose env48779 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound48779 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48780 : List Nat := [2,4,8,16,32,16,128,20,185,188,43,184,41,184,49,19,185,163,189,48,184,153,17,138,160,17,147,185,185,26,21,168,20,17,184,185]

theorem envBound48780 : H12AffineFastState.Bounded env48780 := by
  intro p hp
  have h : env48780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48779_48780 : H12AffineEnvironment.transform 8 185 env48779 = env48780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env48779 == env48780) = true)

theorem identity48780 : scanCanonicalize (H12AffineFastState.compose env48780 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound48780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48781 : List Nat := [2,4,8,16,32,16,34,20,27,30,43,26,41,26,49,19,27,1,31,48,26,59,17,40,2,17,49,27,27,26,21,10,20,17,26,27]

theorem envBound48781 : H12AffineFastState.Bounded env48781 := by
  intro p hp
  have h : env48781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48780_48781 : H12AffineEnvironment.transform 6 34 env48780 = env48781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env48780 == env48781) = true)

def env48782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263632,33236,41244,42274,1297,42061,43128,262563,1280,256,262567,1344,41821]

theorem envBound48782 : H12AffineFastState.Bounded env48782 := by
  intro p hp
  have h : env48782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48771_48782 : H12AffineEnvironment.transform 11 1345 env48771 = env48782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env48771 == env48782) = true)

theorem identity48782 : scanCanonicalize (H12AffineFastState.compose env48782 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound48782 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,325,311,1345,262144,9241,324,1345,8645,17,263632,145,8281,9319,1297,9480,10557,262563,1280,256,262567,1344,8728]

theorem envBound48783 : H12AffineFastState.Bounded env48783 := by
  intro p hp
  have h : env48783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48782_48783 : H12AffineEnvironment.transform 14 325 env48782 = env48783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env48782 == env48783) = true)

theorem identity48783 : scanCanonicalize (H12AffineFastState.compose env48783 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound48783 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env48784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,656,1296,325,311,1345,262144,1673,324,1345,853,17,263632,145,713,1783,1297,1944,2989,262563,1280,256,262567,1344,136]

theorem envBound48784 : H12AffineFastState.Bounded env48784 := by
  intro p hp
  have h : env48784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48783_48784 : H12AffineEnvironment.transform 12 656 env48783 = env48784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env48783 == env48784) = true)

def env48785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70886,78894,77841,1297,74815,81226,365713,1280,256,365717,1344,79471]

theorem envBound48785 : H12AffineFastState.Bounded env48785 := by
  intro p hp
  have h : env48785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48769_48785 : H12AffineEnvironment.transform 13 1297 env48769 = env48785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env48769 == env48785) = true)

theorem identity48785 : scanCanonicalize (H12AffineFastState.compose env48785 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48785 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,17,266384,70886,78894,77841,1297,74815,81226,336012,1280,256,336008,1344,79471]

theorem envBound48786 : H12AffineFastState.Bounded env48786 := by
  intro p hp
  have h : env48786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48785_48786 : H12AffineEnvironment.transform 14 13341 env48785 = env48786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env48785 == env48786) = true)

def env48787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,17,69648,70886,78894,77841,1297,74815,81226,8204,1280,256,8200,1344,79471]

theorem envBound48787 : H12AffineFastState.Bounded env48787 := by
  intro p hp
  have h : env48787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48786_48787 : H12AffineEnvironment.transform 17 65664 env48786 = env48787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48786 == env48787) = true)

theorem identity48787 : scanCanonicalize (H12AffineFastState.compose env48787 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48787 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48788 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,65536,80,65664,77934,12556,4096,477,17,69648,70134,78142,77841,1,74031,79962,8204,16,256,8200,80,78719]

theorem envBound48788 : H12AffineFastState.Bounded env48788 := by
  intro p hp
  have h : env48788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48787_48788 : H12AffineEnvironment.transform 9 272 env48787 = env48788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48787 == env48788) = true)

def env48789 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,65536,0,65664,77886,12556,4096,397,17,69648,70054,78142,77841,1,74031,79882,8204,16,256,8200,0,78639]

theorem envBound48789 : H12AffineFastState.Bounded env48789 := by
  intro p hp
  have h : env48789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48788_48789 : H12AffineEnvironment.transform 5 16 env48788 = env48789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48788 == env48789) = true)

theorem identity48789 : scanCanonicalize (H12AffineFastState.compose env48789 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound48789 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48790 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,34,0,162,12316,12556,4096,397,17,4146,4484,12572,12339,1,8461,14376,8204,16,256,8200,0,13069]

theorem envBound48790 : H12AffineFastState.Bounded env48790 := by
  intro p hp
  have h : env48790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48789_48790 : H12AffineEnvironment.transform 15 34 env48789 = env48790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env48789 == env48790) = true)

theorem identity48790 : scanCanonicalize (H12AffineFastState.compose env48790 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound48790 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48791 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,8461,34,0,162,8220,8460,0,397,17,50,388,8476,8243,1,8461,10280,8204,16,256,8200,0,8973]

theorem envBound48791 : H12AffineFastState.Bounded env48791 := by
  intro p hp
  have h : env48791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48790_48791 : H12AffineEnvironment.transform 11 0 env48790 = env48791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env48790 == env48791) = true)

theorem identity48791 : scanCanonicalize (H12AffineFastState.compose env48791 (packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound48791 : packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env48792 : List Nat := [2,4,8,16,32,16,128,256,438,272,2048,0,8192,1,8461,34,0,162,8220,8460,0,397,17,50,388,8476,8243,1,8461,10280,8204,16,256,8200,0,8379]

theorem envBound48792 : H12AffineFastState.Bounded env48792 := by
  intro p hp
  have h : env48792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48791_48792 : H12AffineEnvironment.transform 8 438 env48791 = env48792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env48791 == env48792) = true)

theorem identity48792 : scanCanonicalize (H12AffineFastState.compose env48792 (packedSelected [0,3,5,7,10,11,12,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 414) := by decide +kernel

theorem selectedBound48792 : packedSelected [0,3,5,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env48793 : List Nat := [2,4,8,16,32,16,128,256,438,272,2048,0,414,1,147,34,0,162,386,146,0,397,17,50,388,130,429,1,147,2486,402,16,256,406,0,293]

theorem envBound48793 : H12AffineFastState.Bounded env48793 := by
  intro p hp
  have h : env48793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48792_48793 : H12AffineEnvironment.transform 12 414 env48792 = env48793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 414 env48792 == env48793) = true)

theorem identity48793 : scanCanonicalize (H12AffineFastState.compose env48793 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound48793 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48794 : List Nat := [2,4,8,16,32,16,128,256,438,272,439,0,414,1,147,34,0,162,386,146,0,397,17,50,388,130,429,1,147,1,402,16,256,406,0,293]

theorem envBound48794 : H12AffineFastState.Bounded env48794 := by
  intro p hp
  have h : env48794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48793_48794 : H12AffineEnvironment.transform 10 439 env48793 = env48794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env48793 == env48794) = true)

theorem identity48794 : scanCanonicalize (H12AffineFastState.compose env48794 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound48794 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48795 : List Nat := [2,4,8,16,32,16,128,183,1,167,0,0,41,1,147,34,0,162,53,146,0,58,17,50,51,130,26,1,147,1,37,16,183,33,0,146]

theorem envBound48795 : H12AffineFastState.Bounded env48795 := by
  intro p hp
  have h : env48795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48794_48795 : H12AffineEnvironment.transform 7 183 env48794 = env48795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env48794 == env48795) = true)

theorem identity48795 : scanCanonicalize (H12AffineFastState.compose env48795 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound48795 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48796 : List Nat := [2,4,8,16,32,16,19,36,1,52,0,0,41,1,0,34,0,49,53,1,0,58,17,50,51,17,26,1,0,1,37,16,36,33,0,1]

theorem envBound48796 : H12AffineFastState.Bounded env48796 := by
  intro p hp
  have h : env48796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48795_48796 : H12AffineEnvironment.transform 6 19 env48795 = env48796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env48795 == env48796) = true)

theorem identity48796 : scanCanonicalize (H12AffineFastState.compose env48796 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48796 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48797 : List Nat := [2,4,8,11,32,11,8,36,1,47,0,0,41,1,0,34,0,42,46,1,0,33,10,41,40,10,1,1,0,1,37,11,36,33,0,1]

theorem envBound48797 : H12AffineFastState.Bounded env48797 := by
  intro p hp
  have h : env48797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48796_48797 : H12AffineEnvironment.transform 3 11 env48796 = env48797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48796 == env48797) = true)

theorem identity48797 : scanCanonicalize (H12AffineFastState.compose env48797 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48798 : List Nat := [2,4,8,11,10,11,8,14,1,5,0,0,3,1,0,8,0,0,4,1,0,11,10,3,2,10,1,1,0,1,15,11,14,11,0,1]

theorem envBound48798 : H12AffineFastState.Bounded env48798 := by
  intro p hp
  have h : env48798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48797_48798 : H12AffineEnvironment.transform 4 10 env48797 = env48798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48797 == env48798) = true)

theorem identity48798 : scanCanonicalize (H12AffineFastState.compose env48798 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48799 : List Nat := [2,4,4,7,6,7,4,2,1,5,0,0,3,1,0,4,0,0,4,1,0,7,6,3,2,6,1,1,0,1,3,7,2,7,0,1]

theorem envBound48799 : H12AffineFastState.Bounded env48799 := by
  intro p hp
  have h : env48799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48798_48799 : H12AffineEnvironment.transform 2 4 env48798 = env48799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48798 == env48799) = true)

def env48800 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,65536,1,65664,77887,12556,4096,396,17,69648,70055,78142,77841,1,74031,79883,8204,16,256,8200,1,78638]

theorem envBound48800 : H12AffineFastState.Bounded env48800 := by
  intro p hp
  have h : env48800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48788_48800 : H12AffineEnvironment.transform 5 17 env48788 = env48800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48788 == env48800) = true)

theorem identity48800 : scanCanonicalize (H12AffineFastState.compose env48800 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound48800 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48801 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,4365,1,0,65536,1,65664,65842,1,4096,396,17,69648,70055,65587,65820,1,69666,67846,4353,16,256,4357,1,66083]

theorem envBound48801 : H12AffineFastState.Bounded env48801 := by
  intro p hp
  have h : env48801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48800_48801 : H12AffineEnvironment.transform 12 4365 env48800 = env48801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env48800 == env48801) = true)

theorem identity48801 : scanCanonicalize (H12AffineFastState.compose env48801 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound48801 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48802 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,269,1,0,65536,1,65664,65842,1,0,396,17,65552,65959,65587,65820,1,65570,67846,257,16,256,261,1,66083]

theorem envBound48802 : H12AffineFastState.Bounded env48802 := by
  intro p hp
  have h : env48802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48801_48802 : H12AffineEnvironment.transform 11 0 env48801 = env48802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env48801 == env48802) = true)

theorem identity48802 : scanCanonicalize (H12AffineFastState.compose env48802 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound48802 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env48803 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,269,1,0,2310,1,2438,2100,1,0,396,17,2326,2209,2357,2074,1,2340,0,257,16,256,261,1,2853]

theorem envBound48803 : H12AffineFastState.Bounded env48803 := by
  intro p hp
  have h : env48803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48802_48803 : H12AffineEnvironment.transform 15 2310 env48802 = env48803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env48802 == env48803) = true)

theorem identity48803 : scanCanonicalize (H12AffineFastState.compose env48803 (packedSelected [0,2,3,7,8,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound48803 : packedSelected [0,2,3,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env48804 : List Nat := [2,4,8,16,32,17,128,256,512,272,276,0,269,1,0,18,1,146,288,1,0,396,17,2,437,33,270,1,48,0,257,16,256,261,1,561]

theorem envBound48804 : H12AffineFastState.Bounded env48804 := by
  intro p hp
  have h : env48804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48803_48804 : H12AffineEnvironment.transform 10 276 env48803 = env48804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env48803 == env48804) = true)

theorem identity48804 : scanCanonicalize (H12AffineFastState.compose env48804 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound48804 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48805 : List Nat := [2,4,8,16,32,17,128,256,390,272,276,0,269,1,0,18,1,146,288,1,0,396,17,2,437,33,270,1,48,0,257,16,256,261,1,439]

theorem envBound48805 : H12AffineFastState.Bounded env48805 := by
  intro p hp
  have h : env48805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48804_48805 : H12AffineEnvironment.transform 8 390 env48804 = env48805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env48804 == env48805) = true)

theorem identity48805 : scanCanonicalize (H12AffineFastState.compose env48805 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48805 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env48806 : List Nat := [2,4,8,16,32,17,8,256,270,272,276,0,269,1,0,18,1,26,288,1,0,260,17,2,317,33,270,1,48,0,257,16,256,261,1,319]

theorem envBound48806 : H12AffineFastState.Bounded env48806 := by
  intro p hp
  have h : env48806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48805_48806 : H12AffineEnvironment.transform 6 8 env48805 = env48806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48805 == env48806) = true)

theorem identity48806 : scanCanonicalize (H12AffineFastState.compose env48806 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48806 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48807 : List Nat := [2,4,8,16,16,17,8,256,270,272,276,0,269,1,0,18,1,26,272,1,0,260,17,2,269,17,270,1,0,0,257,16,256,261,1,271]

theorem envBound48807 : H12AffineFastState.Bounded env48807 := by
  intro p hp
  have h : env48807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48806_48807 : H12AffineEnvironment.transform 4 16 env48806 = env48807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48806 == env48807) = true)

theorem identity48807 : scanCanonicalize (H12AffineFastState.compose env48807 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48808 : List Nat := [2,4,8,10,10,11,8,256,270,266,270,0,269,1,0,8,1,0,266,1,0,260,11,2,269,11,270,1,0,0,257,10,256,261,1,271]

theorem envBound48808 : H12AffineFastState.Bounded env48808 := by
  intro p hp
  have h : env48808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48807_48808 : H12AffineEnvironment.transform 3 10 env48807 = env48808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48807 == env48808) = true)

theorem identity48808 : scanCanonicalize (H12AffineFastState.compose env48808 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound48808 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48809 : List Nat := [2,4,8,10,10,11,8,6,8,12,8,0,11,1,0,8,1,0,12,1,0,2,11,2,11,11,8,1,0,0,7,10,6,3,1,9]

theorem envBound48809 : H12AffineFastState.Bounded env48809 := by
  intro p hp
  have h : env48809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48808_48809 : H12AffineEnvironment.transform 7 6 env48808 = env48809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env48808 == env48809) = true)

theorem identity48809 : scanCanonicalize (H12AffineFastState.compose env48809 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48809 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48810 : List Nat := [1,4,8,9,9,8,8,5,8,12,8,0,8,1,0,8,1,0,12,1,0,1,8,1,8,8,8,1,0,0,4,9,5,0,1,9]

theorem envBound48810 : H12AffineFastState.Bounded env48810 := by
  intro p hp
  have h : env48810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48809_48810 : H12AffineEnvironment.transform 0 1 env48809 = env48810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48809 == env48810) = true)

theorem identity48810 : scanCanonicalize (H12AffineFastState.compose env48810 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48810 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48811 : List Nat := [1,4,4,5,5,4,4,5,4,0,4,0,4,1,0,4,1,0,0,1,0,1,4,1,4,4,4,1,0,0,4,5,5,0,1,5]

theorem envBound48811 : H12AffineFastState.Bounded env48811 := by
  intro p hp
  have h : env48811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48810_48811 : H12AffineEnvironment.transform 2 4 env48810 = env48811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48810 == env48811) = true)

def env48812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,17,69649,70886,78894,77841,1297,74815,81226,8205,1280,256,8201,1344,79471]

theorem envBound48812 : H12AffineFastState.Bounded env48812 := by
  intro p hp
  have h : env48812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48786_48812 : H12AffineEnvironment.transform 17 65665 env48786 = env48812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48786 == env48812) = true)

theorem identity48812 : scanCanonicalize (H12AffineFastState.compose env48812 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound48812 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,65536,1344,65665,73790,9292,80,477,17,65601,66742,74878,73793,1297,74815,77082,8205,1280,256,8201,1344,75327]

theorem envBound48813 : H12AffineFastState.Bounded env48813 := by
  intro p hp
  have h : env48813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48812_48813 : H12AffineEnvironment.transform 11 80 env48812 = env48813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env48812 == env48813) = true)

def env48814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1220,1297,137,65536,1344,65665,66810,136,80,477,17,65601,66742,65722,66693,1297,65787,68062,1225,1280,256,1229,1344,66299]

theorem envBound48814 : H12AffineFastState.Bounded env48814 := by
  intro p hp
  have h : env48814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48813_48814 : H12AffineEnvironment.transform 12 1220 env48813 = env48814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env48813 == env48814) = true)

def env48815 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1297,137,65536,1280,65665,66746,136,16,413,17,65537,66742,65722,66693,1297,65723,67998,1161,1280,256,1165,1280,66235]

theorem envBound48815 : H12AffineFastState.Bounded env48815 := by
  intro p hp
  have h : env48815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48814_48815 : H12AffineEnvironment.transform 5 0 env48814 = env48815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48814 == env48815) = true)

theorem identity48815 : scanCanonicalize (H12AffineFastState.compose env48815 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 299) := by decide +kernel

theorem selectedBound48815 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48816 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1297,137,299,1280,426,1425,136,16,413,17,298,1437,401,1454,1297,400,2229,1161,1280,256,1165,1280,912]

theorem envBound48816 : H12AffineFastState.Bounded env48816 := by
  intro p hp
  have h : env48816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48815_48816 : H12AffineEnvironment.transform 15 299 env48815 = env48816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 299 env48815 == env48816) = true)

def env48817 : List Nat := [2,4,8,16,32,0,128,144,512,1024,2048,16,1156,1153,137,187,1168,58,1025,136,16,13,17,186,1037,1,1086,1153,0,2229,1161,1168,144,1165,1168,512]

theorem envBound48817 : H12AffineFastState.Bounded env48817 := by
  intro p hp
  have h : env48817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48816_48817 : H12AffineEnvironment.transform 7 144 env48816 = env48817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env48816 == env48817) = true)

theorem identity48817 : scanCanonicalize (H12AffineFastState.compose env48817 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48817 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48818 : List Nat := [2,4,8,16,32,0,8,24,512,1024,2048,16,1036,1033,1,51,1048,58,1025,0,16,13,17,50,1037,1,1086,1033,0,2109,1025,1048,24,1029,1048,512]

theorem envBound48818 : H12AffineFastState.Bounded env48818 := by
  intro p hp
  have h : env48818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48817_48818 : H12AffineEnvironment.transform 6 8 env48817 = env48818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48817 == env48818) = true)

theorem identity48818 : scanCanonicalize (H12AffineFastState.compose env48818 (packedSelected [2,3,5,10,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48818 : packedSelected [2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env48819 : List Nat := [2,3,8,16,32,0,8,24,512,1024,2048,16,1035,1033,1,51,1048,58,1025,0,16,10,17,50,1034,1,1081,1033,0,2106,1025,1048,24,1026,1048,512]

theorem envBound48819 : H12AffineFastState.Bounded env48819 := by
  intro p hp
  have h : env48819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48818_48819 : H12AffineEnvironment.transform 1 3 env48818 = env48819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48818 == env48819) = true)

theorem identity48819 : scanCanonicalize (H12AffineFastState.compose env48819 (packedSelected [0,1,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1577) := by decide +kernel

theorem selectedBound48819 : packedSelected [0,1,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48820 : List Nat := [2,3,8,16,32,0,8,24,512,1024,1577,16,1035,1033,1,51,1048,58,1025,0,16,10,17,50,1034,1,1081,1033,0,1555,1025,1048,24,1026,1048,512]

theorem envBound48820 : H12AffineFastState.Bounded env48820 := by
  intro p hp
  have h : env48820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48819_48820 : H12AffineEnvironment.transform 10 1577 env48819 = env48820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1577 env48819 == env48820) = true)

theorem identity48820 : scanCanonicalize (H12AffineFastState.compose env48820 (packedSelected [0,2,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound48820 : packedSelected [0,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48821 : List Nat := [2,3,8,16,32,0,8,24,58,1024,1043,16,1035,1033,1,51,1048,58,1025,0,16,10,17,50,1034,1,1081,1033,0,1065,1025,1048,24,1026,1048,58]

theorem envBound48821 : H12AffineFastState.Bounded env48821 := by
  intro p hp
  have h : env48821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48820_48821 : H12AffineEnvironment.transform 8 58 env48820 = env48821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env48820 == env48821) = true)

theorem identity48821 : scanCanonicalize (H12AffineFastState.compose env48821 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 40) := by decide +kernel

theorem selectedBound48821 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env48822 : List Nat := [2,3,8,16,32,0,8,24,58,40,59,16,35,33,1,51,48,58,41,0,16,10,17,50,34,1,17,33,0,1,41,48,24,42,48,58]

theorem envBound48822 : H12AffineFastState.Bounded env48822 := by
  intro p hp
  have h : env48822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48821_48822 : H12AffineEnvironment.transform 9 40 env48821 = env48822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 40 env48821 == env48822) = true)

theorem identity48822 : scanCanonicalize (H12AffineFastState.compose env48822 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48822 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48823 : List Nat := [2,3,8,10,32,0,8,2,32,40,33,10,35,33,1,41,42,32,41,0,10,10,11,40,34,1,11,33,0,1,41,42,2,42,42,32]

theorem envBound48823 : H12AffineFastState.Bounded env48823 := by
  intro p hp
  have h : env48823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48822_48823 : H12AffineEnvironment.transform 3 10 env48822 = env48823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48822 == env48823) = true)

theorem identity48823 : scanCanonicalize (H12AffineFastState.compose env48823 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48824 : List Nat := [2,3,2,0,32,0,2,2,32,34,33,0,35,33,1,35,32,32,35,0,0,0,1,34,34,1,1,33,0,1,35,32,2,32,32,32]

theorem envBound48824 : H12AffineFastState.Bounded env48824 := by
  intro p hp
  have h : env48824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48823_48824 : H12AffineEnvironment.transform 2 2 env48823 = env48824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48823 == env48824) = true)

theorem identity48824 : scanCanonicalize (H12AffineFastState.compose env48824 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48824 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48825 : List Nat := [2,3,2,0,0,0,2,2,0,2,1,0,3,1,1,3,0,0,3,0,0,0,1,2,2,1,1,1,0,1,3,0,2,0,0,0]

theorem envBound48825 : H12AffineFastState.Bounded env48825 := by
  intro p hp
  have h : env48825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48824_48825 : H12AffineEnvironment.transform 4 0 env48824 = env48825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48824 == env48825) = true)

def env48826 : List Nat := [2,4,8,16,32,0,128,145,512,1024,2048,16,1156,1152,137,186,1169,59,1024,136,16,12,17,187,1036,0,1087,1152,1,2229,1161,1169,145,1165,1169,513]

theorem envBound48826 : H12AffineFastState.Bounded env48826 := by
  intro p hp
  have h : env48826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48816_48826 : H12AffineEnvironment.transform 7 145 env48816 = env48826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env48816 == env48826) = true)

theorem identity48826 : scanCanonicalize (H12AffineFastState.compose env48826 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound48826 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48827 : List Nat := [2,4,8,16,32,0,25,8,512,1024,2048,16,1053,1049,16,35,1032,59,1024,17,16,12,17,34,1036,0,1087,1049,1,2092,1040,1032,8,1044,1032,513]

theorem envBound48827 : H12AffineFastState.Bounded env48827 := by
  intro p hp
  have h : env48827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48826_48827 : H12AffineEnvironment.transform 6 25 env48826 = env48827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env48826 == env48827) = true)

theorem identity48827 : scanCanonicalize (H12AffineFastState.compose env48827 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48827 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48828 : List Nat := [2,4,5,16,32,0,20,5,512,1024,2048,16,1040,1044,16,35,1029,54,1024,17,16,1,17,34,1025,0,1074,1044,1,2081,1040,1029,5,1044,1029,513]

theorem envBound48828 : H12AffineFastState.Bounded env48828 := by
  intro p hp
  have h : env48828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48827_48828 : H12AffineEnvironment.transform 2 5 env48827 = env48828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48827 == env48828) = true)

theorem identity48828 : scanCanonicalize (H12AffineFastState.compose env48828 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48828 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48829 : List Nat := [2,4,5,0,32,0,4,5,512,1024,2048,0,1024,1028,0,35,1029,38,1024,1,0,1,1,34,1025,0,1058,1028,1,2081,1024,1029,5,1028,1029,513]

theorem envBound48829 : H12AffineFastState.Bounded env48829 := by
  intro p hp
  have h : env48829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48828_48829 : H12AffineEnvironment.transform 3 0 env48828 = env48829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48828 == env48829) = true)

theorem identity48829 : scanCanonicalize (H12AffineFastState.compose env48829 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound48829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48830 : List Nat := [2,4,5,0,32,0,4,5,512,516,2048,0,516,512,0,35,513,38,516,1,0,1,1,34,517,0,550,512,1,2081,516,513,5,512,513,513]

theorem envBound48830 : H12AffineFastState.Bounded env48830 := by
  intro p hp
  have h : env48830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48829_48830 : H12AffineEnvironment.transform 9 516 env48829 = env48830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env48829 == env48830) = true)

theorem identity48830 : scanCanonicalize (H12AffineFastState.compose env48830 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound48830 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48831 : List Nat := [2,4,5,0,32,0,4,5,39,35,2048,0,35,39,0,35,38,38,35,1,0,1,1,34,34,0,1,39,1,2081,35,38,5,39,38,38]

theorem envBound48831 : H12AffineFastState.Bounded env48831 := by
  intro p hp
  have h : env48831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48830_48831 : H12AffineEnvironment.transform 8 39 env48830 = env48831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env48830 == env48831) = true)

theorem identity48831 : scanCanonicalize (H12AffineFastState.compose env48831 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound48831 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env48832 : List Nat := [2,4,5,0,32,0,4,5,39,35,5,0,35,39,0,35,38,38,35,1,0,1,1,34,34,0,1,39,1,36,35,38,5,39,38,38]

theorem envBound48832 : H12AffineFastState.Bounded env48832 := by
  intro p hp
  have h : env48832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48831_48832 : H12AffineEnvironment.transform 10 5 env48831 = env48832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env48831 == env48832) = true)

theorem identity48832 : scanCanonicalize (H12AffineFastState.compose env48832 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound48832 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env48833 : List Nat := [2,4,5,0,3,0,4,5,4,0,5,0,0,4,0,0,5,5,0,1,0,1,1,1,1,0,1,4,1,7,0,5,5,4,5,5]

theorem envBound48833 : H12AffineFastState.Bounded env48833 := by
  intro p hp
  have h : env48833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48832_48833 : H12AffineEnvironment.transform 4 3 env48832 = env48833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env48832 == env48833) = true)

theorem identity48833 : scanCanonicalize (H12AffineFastState.compose env48833 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48833 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48834 : List Nat := [2,2,3,0,3,0,2,3,2,0,3,0,0,2,0,0,3,3,0,1,0,1,1,1,1,0,1,2,1,1,0,3,3,2,3,3]

theorem envBound48834 : H12AffineFastState.Bounded env48834 := by
  intro p hp
  have h : env48834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48833_48834 : H12AffineEnvironment.transform 1 2 env48833 = env48834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48833 == env48834) = true)

theorem identity48834 : scanCanonicalize (H12AffineFastState.compose env48834 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48834 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48835 : List Nat := [1,1,0,0,0,0,1,0,1,0,0,0,0,1,0,0,0,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,1,0,0]

theorem envBound48835 : H12AffineFastState.Bounded env48835 := by
  intro p hp
  have h : env48835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48834_48835 : H12AffineEnvironment.transform 0 1 env48834 = env48835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48834 == env48835) = true)

def env48836 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1297,137,65536,1281,65665,66747,136,17,412,17,65536,66742,65722,66693,1297,65722,67999,1160,1280,256,1164,1281,66234]

theorem envBound48836 : H12AffineFastState.Bounded env48836 := by
  intro p hp
  have h : env48836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48814_48836 : H12AffineEnvironment.transform 5 1 env48814 = env48836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48814 == env48836) = true)

theorem identity48836 : scanCanonicalize (H12AffineFastState.compose env48836 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 166) := by decide +kernel

theorem selectedBound48836 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48837 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1297,137,166,1281,39,1053,136,17,412,17,166,1040,28,1059,1297,28,2361,1160,1280,256,1164,1281,540]

theorem envBound48837 : H12AffineFastState.Bounded env48837 := by
  intro p hp
  have h : env48837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48836_48837 : H12AffineEnvironment.transform 15 166 env48836 = env48837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 166 env48836 == env48837) = true)

def env48838 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1,1157,1281,137,166,1281,39,1037,136,1,396,1,166,1024,12,1059,1281,12,2345,1160,1280,256,1164,1281,524]

theorem envBound48838 : H12AffineFastState.Bounded env48838 := by
  intro p hp
  have h : env48838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48837_48838 : H12AffineEnvironment.transform 3 0 env48837 = env48838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48837 == env48838) = true)

theorem identity48838 : scanCanonicalize (H12AffineFastState.compose env48838 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48838 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48839 : List Nat := [2,4,8,0,32,1,8,256,512,1024,2048,1,1037,1281,1,46,1281,39,1037,0,1,260,1,46,1024,12,1059,1281,12,2345,1024,1280,256,1028,1281,524]

theorem envBound48839 : H12AffineFastState.Bounded env48839 := by
  intro p hp
  have h : env48839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48838_48839 : H12AffineEnvironment.transform 6 8 env48838 = env48839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48838 == env48839) = true)

theorem identity48839 : scanCanonicalize (H12AffineFastState.compose env48839 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 269) := by decide +kernel

theorem selectedBound48839 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48840 : List Nat := [2,4,8,0,32,1,8,256,512,269,2048,1,256,12,1,46,12,39,256,0,1,260,1,46,269,12,302,12,12,2345,269,13,256,265,12,524]

theorem envBound48840 : H12AffineFastState.Bounded env48840 := by
  intro p hp
  have h : env48840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48839_48840 : H12AffineEnvironment.transform 9 269 env48839 = env48840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 269 env48839 == env48840) = true)

theorem identity48840 : scanCanonicalize (H12AffineFastState.compose env48840 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 802) := by decide +kernel

theorem selectedBound48840 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env48841 : List Nat := [2,4,8,0,32,1,8,256,512,269,802,1,256,12,1,46,12,39,256,0,1,260,1,46,269,12,302,12,12,523,269,13,256,265,12,524]

theorem envBound48841 : H12AffineFastState.Bounded env48841 := by
  intro p hp
  have h : env48841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48840_48841 : H12AffineEnvironment.transform 10 802 env48840 = env48841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 802 env48840 == env48841) = true)

theorem identity48841 : scanCanonicalize (H12AffineFastState.compose env48841 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48841 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48842 : List Nat := [2,4,8,0,32,1,8,256,43,269,265,1,256,12,1,46,12,39,256,0,1,260,1,46,269,12,302,12,12,32,269,13,256,265,12,39]

theorem envBound48842 : H12AffineFastState.Bounded env48842 := by
  intro p hp
  have h : env48842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48841_48842 : H12AffineEnvironment.transform 8 43 env48841 = env48842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48841 == env48842) = true)

theorem identity48842 : scanCanonicalize (H12AffineFastState.compose env48842 (packedSelected [4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound48842 : packedSelected [4,7,8] rootPS < 2^1333 := by decide +kernel

def env48843 : List Nat := [2,4,8,0,32,1,8,35,43,46,42,1,35,12,1,46,12,39,35,0,1,39,1,46,46,12,13,12,12,32,46,13,35,42,12,39]

theorem envBound48843 : H12AffineFastState.Bounded env48843 := by
  intro p hp
  have h : env48843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48842_48843 : H12AffineEnvironment.transform 7 35 env48842 = env48843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env48842 == env48843) = true)

def env48844 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,0,1157,1280,137,166,1281,39,1036,136,0,397,0,166,1025,13,1059,1280,13,2344,1160,1280,256,1164,1281,525]

theorem envBound48844 : H12AffineFastState.Bounded env48844 := by
  intro p hp
  have h : env48844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48837_48844 : H12AffineEnvironment.transform 3 1 env48837 = env48844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48837 == env48844) = true)

theorem identity48844 : scanCanonicalize (H12AffineFastState.compose env48844 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound48844 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48845 : List Nat := [2,4,8,1,32,1,5,256,512,1024,2048,0,1024,1280,12,35,1281,39,1036,13,0,264,0,35,1025,13,1059,1280,13,2344,1037,1280,256,1033,1281,525]

theorem envBound48845 : H12AffineFastState.Bounded env48845 := by
  intro p hp
  have h : env48845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48844_48845 : H12AffineEnvironment.transform 6 5 env48844 = env48845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48844 == env48845) = true)

theorem identity48845 : scanCanonicalize (H12AffineFastState.compose env48845 (packedSelected [0,1,2,3,5,7,8,10,11,12,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 810) := by decide +kernel

theorem selectedBound48845 : packedSelected [0,1,2,3,5,7,8,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48846 : List Nat := [2,4,8,1,32,1,5,256,512,810,2048,0,810,554,12,35,555,39,806,13,0,264,0,35,811,13,777,554,13,2344,807,554,256,803,555,525]

theorem envBound48846 : H12AffineFastState.Bounded env48846 := by
  intro p hp
  have h : env48846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48845_48846 : H12AffineEnvironment.transform 9 810 env48845 = env48846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 810 env48845 == env48846) = true)

theorem identity48846 : scanCanonicalize (H12AffineFastState.compose env48846 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound48846 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48847 : List Nat := [2,4,8,1,32,1,5,256,38,268,2048,0,268,12,12,35,13,39,256,13,0,264,0,35,269,13,303,12,13,2344,257,12,256,261,13,43]

theorem envBound48847 : H12AffineFastState.Bounded env48847 := by
  intro p hp
  have h : env48847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48846_48847 : H12AffineEnvironment.transform 8 38 env48846 = env48847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env48846 == env48847) = true)

theorem identity48847 : scanCanonicalize (H12AffineFastState.compose env48847 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 265) := by decide +kernel

theorem selectedBound48847 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env48848 : List Nat := [2,4,8,1,32,1,5,256,38,268,265,0,268,12,12,35,13,39,256,13,0,264,0,35,269,13,303,12,13,33,257,12,256,261,13,43]

theorem envBound48848 : H12AffineFastState.Bounded env48848 := by
  intro p hp
  have h : env48848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48847_48848 : H12AffineEnvironment.transform 10 265 env48847 = env48848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 265 env48847 == env48848) = true)

theorem identity48848 : scanCanonicalize (H12AffineFastState.compose env48848 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound48848 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env48849 : List Nat := [2,4,8,1,32,1,5,40,38,36,33,0,36,12,12,35,13,39,40,13,0,32,0,35,37,13,7,12,13,33,41,12,40,45,13,43]

theorem envBound48849 : H12AffineFastState.Bounded env48849 := by
  intro p hp
  have h : env48849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48848_48849 : H12AffineEnvironment.transform 7 40 env48848 = env48849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env48848 == env48849) = true)

theorem identity48849 : scanCanonicalize (H12AffineFastState.compose env48849 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48849 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48850 : List Nat := [2,4,8,1,1,1,5,9,7,5,0,0,5,12,12,2,13,6,9,13,0,1,0,2,4,13,7,12,13,0,8,12,9,12,13,10]

theorem envBound48850 : H12AffineFastState.Bounded env48850 := by
  intro p hp
  have h : env48850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48849_48850 : H12AffineEnvironment.transform 4 1 env48849 = env48850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48849 == env48850) = true)

theorem identity48850 : scanCanonicalize (H12AffineFastState.compose env48850 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48851 : List Nat := [2,2,8,1,1,1,3,9,1,3,0,0,3,10,10,2,11,0,9,11,0,1,0,2,2,11,1,10,11,0,8,10,9,10,11,10]

theorem envBound48851 : H12AffineFastState.Bounded env48851 := by
  intro p hp
  have h : env48851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48850_48851 : H12AffineEnvironment.transform 1 2 env48850 = env48851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48850 == env48851) = true)

def env48852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1221,1297,136,65536,1344,65665,66811,137,80,477,17,65601,66742,65723,66692,1297,65786,68063,1224,1280,256,1228,1344,66298]

theorem envBound48852 : H12AffineFastState.Bounded env48852 := by
  intro p hp
  have h : env48852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48813_48852 : H12AffineEnvironment.transform 12 1221 env48813 = env48852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env48813 == env48852) = true)

def env48853 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1157,1297,136,65536,1280,65665,66747,137,16,413,17,65537,66742,65723,66692,1297,65722,67999,1160,1280,256,1164,1280,66234]

theorem envBound48853 : H12AffineFastState.Bounded env48853 := by
  intro p hp
  have h : env48853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48852_48853 : H12AffineEnvironment.transform 5 0 env48852 = env48853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48852 == env48853) = true)

theorem identity48853 : scanCanonicalize (H12AffineFastState.compose env48853 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 128) := by decide +kernel

theorem selectedBound48853 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48854 : List Nat := [2,4,8,16,32,0,128,256,512,128,2048,16,5,401,136,65536,384,65665,65595,137,16,413,17,65537,65590,65723,65540,401,65722,67999,8,384,256,12,384,66234]

theorem envBound48854 : H12AffineFastState.Bounded env48854 := by
  intro p hp
  have h : env48854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48853_48854 : H12AffineEnvironment.transform 9 128 env48853 = env48854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env48853 == env48854) = true)

def env48855 : List Nat := [2,4,8,0,32,0,128,256,512,128,2048,0,5,385,136,65536,384,65665,65579,137,0,397,1,65537,65574,65707,65540,385,65706,67983,8,384,256,12,384,66218]

theorem envBound48855 : H12AffineFastState.Bounded env48855 := by
  intro p hp
  have h : env48855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48854_48855 : H12AffineEnvironment.transform 3 0 env48854 = env48855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48854 == env48855) = true)

theorem identity48855 : scanCanonicalize (H12AffineFastState.compose env48855 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound48855 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48856 : List Nat := [2,4,8,0,32,0,128,256,512,128,2048,0,5,385,136,35,384,162,8,137,0,397,1,34,5,136,39,385,137,2476,8,384,256,12,384,649]

theorem envBound48856 : H12AffineFastState.Bounded env48856 := by
  intro p hp
  have h : env48856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48855_48856 : H12AffineEnvironment.transform 15 35 env48855 = env48856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env48855 == env48856) = true)

theorem identity48856 : scanCanonicalize (H12AffineFastState.compose env48856 (packedSelected [0,1,2,3,5,7,8,10,11,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48856 : packedSelected [0,1,2,3,5,7,8,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48857 : List Nat := [2,4,8,0,32,0,128,256,42,128,2048,0,5,385,136,35,384,162,8,137,0,397,1,34,5,136,39,385,137,2476,8,384,256,12,384,163]

theorem envBound48857 : H12AffineFastState.Bounded env48857 := by
  intro p hp
  have h : env48857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48856_48857 : H12AffineEnvironment.transform 8 42 env48856 = env48857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48856 == env48857) = true)

theorem identity48857 : scanCanonicalize (H12AffineFastState.compose env48857 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound48857 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48858 : List Nat := [2,4,8,0,32,0,128,9,42,128,2048,0,5,136,136,35,137,162,8,137,0,132,1,34,5,136,39,136,137,2213,8,137,9,12,137,163]

theorem envBound48858 : H12AffineFastState.Bounded env48858 := by
  intro p hp
  have h : env48858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48857_48858 : H12AffineEnvironment.transform 7 9 env48857 = env48858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env48857 == env48858) = true)

theorem identity48858 : scanCanonicalize (H12AffineFastState.compose env48858 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound48858 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env48859 : List Nat := [2,4,8,0,32,0,128,9,42,128,12,0,5,136,136,35,137,162,8,137,0,132,1,34,5,136,39,136,137,169,8,137,9,12,137,163]

theorem envBound48859 : H12AffineFastState.Bounded env48859 := by
  intro p hp
  have h : env48859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48858_48859 : H12AffineEnvironment.transform 10 12 env48858 = env48859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env48858 == env48859) = true)

theorem identity48859 : scanCanonicalize (H12AffineFastState.compose env48859 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48859 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env48860 : List Nat := [2,3,8,0,32,0,128,9,42,128,11,0,2,136,136,35,137,162,8,137,0,131,1,34,2,136,32,136,137,169,8,137,9,11,137,163]

theorem envBound48860 : H12AffineFastState.Bounded env48860 := by
  intro p hp
  have h : env48860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48859_48860 : H12AffineEnvironment.transform 1 3 env48859 = env48860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48859 == env48860) = true)

def env48861 : List Nat := [2,4,8,1,32,0,128,256,512,128,2048,1,5,384,136,65536,384,65665,65578,137,1,396,0,65537,65575,65706,65540,384,65707,67982,8,384,256,12,384,66219]

theorem envBound48861 : H12AffineFastState.Bounded env48861 := by
  intro p hp
  have h : env48861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48854_48861 : H12AffineEnvironment.transform 3 1 env48854 = env48861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48854 == env48861) = true)

theorem identity48861 : scanCanonicalize (H12AffineFastState.compose env48861 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48861 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48862 : List Nat := [2,4,8,1,32,0,9,256,512,9,2048,1,5,265,1,65536,265,65544,65578,0,1,261,0,65537,65575,65571,65540,265,65570,67847,8,265,256,12,265,66082]

theorem envBound48862 : H12AffineFastState.Bounded env48862 := by
  intro p hp
  have h : env48862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48861_48862 : H12AffineEnvironment.transform 6 9 env48861 = env48862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48861 == env48862) = true)

theorem identity48862 : scanCanonicalize (H12AffineFastState.compose env48862 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 299) := by decide +kernel

theorem selectedBound48862 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48863 : List Nat := [2,4,8,1,32,0,9,256,512,9,2048,1,5,265,1,299,265,291,257,0,1,261,0,298,268,264,303,265,265,2092,8,265,256,12,265,777]

theorem envBound48863 : H12AffineFastState.Bounded env48863 := by
  intro p hp
  have h : env48863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48862_48863 : H12AffineEnvironment.transform 15 299 env48862 = env48863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 299 env48862 == env48863) = true)

theorem identity48863 : scanCanonicalize (H12AffineFastState.compose env48863 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 802) := by decide +kernel

theorem selectedBound48863 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env48864 : List Nat := [2,4,8,1,32,0,9,256,512,9,802,1,5,265,1,299,265,291,257,0,1,261,0,298,268,264,303,265,265,782,8,265,256,12,265,777]

theorem envBound48864 : H12AffineFastState.Bounded env48864 := by
  intro p hp
  have h : env48864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48863_48864 : H12AffineEnvironment.transform 10 802 env48863 = env48864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 802 env48863 == env48864) = true)

theorem identity48864 : scanCanonicalize (H12AffineFastState.compose env48864 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound48864 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48865 : List Nat := [2,4,8,1,32,0,9,15,512,9,557,1,5,6,1,36,6,44,14,0,1,10,0,37,3,7,32,6,6,513,8,6,15,12,6,518]

theorem envBound48865 : H12AffineFastState.Bounded env48865 := by
  intro p hp
  have h : env48865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48864_48865 : H12AffineEnvironment.transform 7 15 env48864 = env48865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env48864 == env48865) = true)

theorem identity48865 : scanCanonicalize (H12AffineFastState.compose env48865 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48865 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48866 : List Nat := [2,4,3,1,32,0,2,4,512,2,550,1,5,6,1,36,6,39,5,0,1,1,0,37,3,7,32,6,6,513,3,6,4,7,6,518]

theorem envBound48866 : H12AffineFastState.Bounded env48866 := by
  intro p hp
  have h : env48866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48865_48866 : H12AffineEnvironment.transform 2 3 env48865 = env48866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48865 == env48866) = true)

theorem identity48866 : scanCanonicalize (H12AffineFastState.compose env48866 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound48866 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48867 : List Nat := [2,4,3,1,32,0,2,4,38,2,0,1,5,6,1,36,6,39,5,0,1,1,0,37,3,7,32,6,6,39,3,6,4,7,6,32]

theorem envBound48867 : H12AffineFastState.Bounded env48867 := by
  intro p hp
  have h : env48867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48866_48867 : H12AffineEnvironment.transform 8 38 env48866 = env48867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env48866 == env48867) = true)

theorem identity48867 : scanCanonicalize (H12AffineFastState.compose env48867 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48867 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48868 : List Nat := [2,4,3,1,7,0,2,4,1,2,0,1,5,6,1,3,6,0,5,0,1,1,0,2,3,7,7,6,6,0,3,6,4,7,6,7]

theorem envBound48868 : H12AffineFastState.Bounded env48868 := by
  intro p hp
  have h : env48868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48867_48868 : H12AffineEnvironment.transform 4 7 env48867 = env48868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48867 == env48868) = true)

theorem identity48868 : scanCanonicalize (H12AffineFastState.compose env48868 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48868 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48869 : List Nat := [2,3,3,1,0,0,2,3,1,2,0,1,2,1,1,3,1,0,2,0,1,1,0,2,3,0,0,1,1,0,3,1,3,0,1,0]

theorem envBound48869 : H12AffineFastState.Bounded env48869 := by
  intro p hp
  have h : env48869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48868_48869 : H12AffineEnvironment.transform 1 3 env48868 = env48869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48868 == env48869) = true)

theorem identity48869 : scanCanonicalize (H12AffineFastState.compose env48869 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48870 : List Nat := [0,1,1,1,0,0,0,1,1,0,0,1,0,1,1,1,1,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,1,0,1,0]

theorem envBound48870 : H12AffineFastState.Bounded env48870 := by
  intro p hp
  have h : env48870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48869_48870 : H12AffineEnvironment.transform 0 0 env48869 = env48870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48869 == env48870) = true)

def env48871 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1156,1297,136,65536,1281,65665,66746,137,17,412,17,65536,66742,65723,66692,1297,65723,67998,1161,1280,256,1165,1281,66235]

theorem envBound48871 : H12AffineFastState.Bounded env48871 := by
  intro p hp
  have h : env48871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48852_48871 : H12AffineEnvironment.transform 5 1 env48852 = env48871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48852 == env48871) = true)

theorem identity48871 : scanCanonicalize (H12AffineFastState.compose env48871 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 269) := by decide +kernel

theorem selectedBound48871 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48872 : List Nat := [2,4,8,16,32,1,128,256,512,269,2048,17,393,28,136,65536,12,65665,65975,137,17,412,17,65536,65979,65723,65929,28,65723,67998,388,13,256,384,12,66235]

theorem envBound48872 : H12AffineFastState.Bounded env48872 := by
  intro p hp
  have h : env48872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48871_48872 : H12AffineEnvironment.transform 9 269 env48871 = env48872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 269 env48871 == env48872) = true)

def env48873 : List Nat := [2,4,8,16,32,1,128,140,512,129,2048,17,5,28,136,65536,12,65665,65595,137,17,16,17,65536,65591,65723,65541,28,65723,67602,8,13,140,12,12,66235]

theorem envBound48873 : H12AffineFastState.Bounded env48873 := by
  intro p hp
  have h : env48873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48872_48873 : H12AffineEnvironment.transform 7 140 env48872 = env48873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env48872 == env48873) = true)

theorem identity48873 : scanCanonicalize (H12AffineFastState.compose env48873 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound48873 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48874 : List Nat := [2,4,8,16,32,1,128,140,512,129,2048,17,5,28,136,50,12,179,9,137,17,16,17,50,5,137,55,28,137,2080,8,13,140,12,12,649]

theorem envBound48874 : H12AffineFastState.Bounded env48874 := by
  intro p hp
  have h : env48874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48873_48874 : H12AffineEnvironment.transform 15 50 env48873 = env48874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env48873 == env48874) = true)

theorem identity48874 : scanCanonicalize (H12AffineFastState.compose env48874 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound48874 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env48875 : List Nat := [2,4,8,16,32,1,40,36,512,41,2048,17,5,28,32,50,12,27,9,33,17,16,17,50,5,33,55,28,33,2080,8,13,36,12,12,545]

theorem envBound48875 : H12AffineFastState.Bounded env48875 := by
  intro p hp
  have h : env48875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48874_48875 : H12AffineEnvironment.transform 6 40 env48874 = env48875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env48874 == env48875) = true)

theorem identity48875 : scanCanonicalize (H12AffineFastState.compose env48875 (packedSelected [2,4,9,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound48875 : packedSelected [2,4,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env48876 : List Nat := [2,4,8,16,32,1,40,36,512,41,513,17,5,28,32,50,12,27,9,33,17,16,17,50,5,33,55,28,33,545,8,13,36,12,12,545]

theorem envBound48876 : H12AffineFastState.Bounded env48876 := by
  intro p hp
  have h : env48876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48875_48876 : H12AffineEnvironment.transform 10 513 env48875 = env48876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env48875 == env48876) = true)

theorem identity48876 : scanCanonicalize (H12AffineFastState.compose env48876 (packedSelected [1,4,5,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48876 : packedSelected [1,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env48877 : List Nat := [2,4,4,16,32,1,36,36,512,37,513,17,5,16,32,50,0,23,5,33,17,16,17,50,5,33,55,16,33,545,4,1,36,0,0,545]

theorem envBound48877 : H12AffineFastState.Bounded env48877 := by
  intro p hp
  have h : env48877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48876_48877 : H12AffineEnvironment.transform 2 4 env48876 = env48877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48876 == env48877) = true)

theorem identity48877 : scanCanonicalize (H12AffineFastState.compose env48877 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48877 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env48878 : List Nat := [2,4,4,16,32,1,36,36,49,37,48,17,5,16,32,50,0,23,5,33,17,16,17,50,5,33,55,16,33,16,4,1,36,0,0,16]

theorem envBound48878 : H12AffineFastState.Bounded env48878 := by
  intro p hp
  have h : env48878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48877_48878 : H12AffineEnvironment.transform 8 49 env48877 = env48878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48877 == env48878) = true)

theorem identity48878 : scanCanonicalize (H12AffineFastState.compose env48878 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48879 : List Nat := [2,4,4,16,6,1,2,2,23,3,22,17,5,16,6,20,0,23,5,7,17,16,17,20,5,7,17,16,7,16,4,1,2,0,0,16]

theorem envBound48879 : H12AffineFastState.Bounded env48879 := by
  intro p hp
  have h : env48879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48878_48879 : H12AffineEnvironment.transform 4 6 env48878 = env48879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48878 == env48879) = true)

theorem identity48879 : scanCanonicalize (H12AffineFastState.compose env48879 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48879 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48880 : List Nat := [2,4,4,6,6,1,2,2,1,3,0,7,5,6,6,2,0,1,5,7,7,6,7,2,5,7,7,6,7,6,4,1,2,0,0,6]

theorem envBound48880 : H12AffineFastState.Bounded env48880 := by
  intro p hp
  have h : env48880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48879_48880 : H12AffineEnvironment.transform 3 6 env48879 = env48880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48879 == env48880) = true)

theorem identity48880 : scanCanonicalize (H12AffineFastState.compose env48880 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48880 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48881 : List Nat := [2,3,3,1,1,1,2,2,1,3,0,0,2,1,1,2,0,1,2,0,0,1,0,2,2,0,0,1,0,1,3,1,2,0,0,1]

theorem envBound48881 : H12AffineFastState.Bounded env48881 := by
  intro p hp
  have h : env48881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48880_48881 : H12AffineEnvironment.transform 1 3 env48880 = env48881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48880 == env48881) = true)

def env48882 : List Nat := [2,4,8,16,32,1,128,141,512,128,2048,17,4,28,136,65536,12,65665,65594,137,17,17,17,65536,65590,65723,65540,28,65723,67603,9,13,141,13,12,66235]

theorem envBound48882 : H12AffineFastState.Bounded env48882 := by
  intro p hp
  have h : env48882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48872_48882 : H12AffineEnvironment.transform 7 141 env48872 = env48882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env48872 == env48882) = true)

theorem identity48882 : scanCanonicalize (H12AffineFastState.compose env48882 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48882 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48883 : List Nat := [2,4,8,16,32,1,9,4,512,9,2048,17,4,28,1,65536,12,65544,65594,0,17,17,17,65536,65590,65586,65540,28,65586,67603,9,13,4,13,12,66098]

theorem envBound48883 : H12AffineFastState.Bounded env48883 := by
  intro p hp
  have h : env48883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48882_48883 : H12AffineEnvironment.transform 6 9 env48882 = env48883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48882 == env48883) = true)

theorem identity48883 : scanCanonicalize (H12AffineFastState.compose env48883 (packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2607) := by decide +kernel

theorem selectedBound48883 : packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env48884 : List Nat := [2,4,8,16,32,1,9,4,512,9,2048,17,4,28,1,2607,12,2599,2581,0,17,17,17,2607,2585,2589,2603,28,2589,572,9,13,4,13,12,2077]

theorem envBound48884 : H12AffineFastState.Bounded env48884 := by
  intro p hp
  have h : env48884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48883_48884 : H12AffineEnvironment.transform 15 2607 env48883 = env48884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2607 env48883 == env48884) = true)

theorem identity48884 : scanCanonicalize (H12AffineFastState.compose env48884 (packedSelected [0,1,2,3,5,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound48884 : packedSelected [0,1,2,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48885 : List Nat := [2,4,8,16,32,1,9,4,512,9,59,17,4,28,1,532,12,540,558,0,17,17,17,532,546,550,528,28,550,572,9,13,4,13,12,38]

theorem envBound48885 : H12AffineFastState.Bounded env48885 := by
  intro p hp
  have h : env48885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48884_48885 : H12AffineEnvironment.transform 10 59 env48884 = env48885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env48884 == env48885) = true)

theorem identity48885 : scanCanonicalize (H12AffineFastState.compose env48885 (packedSelected [2,3,4,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound48885 : packedSelected [2,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env48886 : List Nat := [2,4,8,16,32,1,9,4,7,9,59,17,4,28,1,19,12,27,41,0,17,17,17,19,37,33,23,28,33,59,9,13,4,13,12,38]

theorem envBound48886 : H12AffineFastState.Bounded env48886 := by
  intro p hp
  have h : env48886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48885_48886 : H12AffineEnvironment.transform 8 7 env48885 = env48886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env48885 == env48886) = true)

theorem identity48886 : scanCanonicalize (H12AffineFastState.compose env48886 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound48886 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env48887 : List Nat := [2,4,8,16,29,1,9,4,7,9,6,17,4,28,1,19,12,27,20,0,17,17,17,19,24,28,23,28,28,6,9,13,4,13,12,27]

theorem envBound48887 : H12AffineFastState.Bounded env48887 := by
  intro p hp
  have h : env48887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48886_48887 : H12AffineEnvironment.transform 4 29 env48886 = env48887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env48886 == env48887) = true)

theorem identity48887 : scanCanonicalize (H12AffineFastState.compose env48887 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48887 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48888 : List Nat := [2,4,8,7,10,1,9,4,7,9,6,6,4,11,1,4,12,12,3,0,6,6,6,4,15,11,0,11,11,6,9,13,4,13,12,12]

theorem envBound48888 : H12AffineFastState.Bounded env48888 := by
  intro p hp
  have h : env48888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48887_48888 : H12AffineEnvironment.transform 3 7 env48887 = env48888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48887 == env48888) = true)

def env48889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,134217728,148800,545089,96347,16876544,618622,257,16876549,151462017,525824]

theorem envBound48889 : H12AffineFastState.Bounded env48889 := by
  intro p hp
  have h : env48889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47784_48889 : H12AffineEnvironment.transform 24 533641 env47784 = env48889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env47784 == env48889) = true)

def env48890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245632,148800,545089,96347,16876544,618622,257,16876549,1345,525824]

theorem envBound48890 : H12AffineFastState.Bounded env48890 := by
  intro p hp
  have h : env48890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48889_48890 : H12AffineEnvironment.transform 26 17245632 env48889 = env48890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env48889 == env48890) = true)

theorem identity48890 : scanCanonicalize (H12AffineFastState.compose env48890 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound48890 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env48891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41003,533641,672785,493035,148800,545089,96347,74795,618622,257,74798,1345,525824]

theorem envBound48891 : H12AffineFastState.Bounded env48891 := by
  intro p hp
  have h : env48891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48890_48891 : H12AffineEnvironment.transform 23 41003 env48890 = env48891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env48890 == env48891) = true)

def env48892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,493035,148800,148801,96347,74795,222334,257,74798,1345,135680]

theorem envBound48892 : H12AffineFastState.Bounded env48892 := by
  intro p hp
  have h : env48892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48891_48892 : H12AffineEnvironment.transform 18 136192 env48891 = env48892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env48891 == env48892) = true)

def env48893 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,492615,148716,148717,96347,74795,222334,173,74798,1261,135680]

theorem envBound48893 : H12AffineFastState.Bounded env48893 := by
  intro p hp
  have h : env48893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48892_48893 : H12AffineEnvironment.transform 7 172 env48892 = env48893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48892 == env48893) = true)

def env48894 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143497,20497,492567,148668,148669,96267,74795,222254,173,74798,1213,135680]

theorem envBound48894 : H12AffineFastState.Bounded env48894 := by
  intro p hp
  have h : env48894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48893_48894 : H12AffineEnvironment.transform 5 16 env48893 = env48894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48893 == env48894) = true)

theorem identity48894 : scanCanonicalize (H12AffineFastState.compose env48894 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound48894 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48895 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,41003,143497,20497,105631,148668,148669,96267,74795,222254,173,74798,1213,135680]

theorem envBound48895 : H12AffineFastState.Bounded env48895 := by
  intro p hp
  have h : env48895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48894_48895 : H12AffineEnvironment.transform 17 137352 env48894 = env48895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env48894 == env48895) = true)

theorem identity48895 : scanCanonicalize (H12AffineFastState.compose env48895 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound48895 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48896 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4096,61569,147472,41003,143497,20497,43169,148668,148669,19509,4117,151568,173,4112,1213,135680]

theorem envBound48896 : H12AffineFastState.Bounded env48896 := by
  intro p hp
  have h : env48896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48895_48896 : H12AffineEnvironment.transform 15 13374 env48895 = env48896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env48895 == env48896) = true)

theorem identity48896 : scanCanonicalize (H12AffineFastState.compose env48896 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound48896 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env48897 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136192,32769,4096,46140,132269,41003,143497,5292,43169,131073,131072,2184,4117,136365,173,4112,1213,135680]

theorem envBound48897 : H12AffineFastState.Bounded env48897 := by
  intro p hp
  have h : env48897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48896_48897 : H12AffineEnvironment.transform 13 1213 env48896 = env48897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env48896 == env48897) = true)

theorem identity48897 : scanCanonicalize (H12AffineFastState.compose env48897 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound48897 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env48898 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,13374,131072,137352,136192,9380,4096,4249,132269,1166,143497,5292,3076,131073,131072,2184,4117,136365,173,4112,1213,135680]

theorem envBound48898 : H12AffineFastState.Bounded env48898 := by
  intro p hp
  have h : env48898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48897_48898 : H12AffineEnvironment.transform 14 9381 env48897 = env48898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env48897 == env48898) = true)

theorem identity48898 : scanCanonicalize (H12AffineFastState.compose env48898 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 2074) := by decide +kernel

theorem selectedBound48898 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48899 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,13374,2074,4242,7194,9380,4096,4249,3255,1166,14483,5292,3076,2075,2074,2184,4117,7351,173,4112,1213,6682]

theorem envBound48899 : H12AffineFastState.Bounded env48899 := by
  intro p hp
  have h : env48899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48898_48899 : H12AffineEnvironment.transform 16 2074 env48898 = env48899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2074 env48898 == env48899) = true)

theorem identity48899 : scanCanonicalize (H12AffineFastState.compose env48899 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound48899 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48900 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4257,1213,5124,1183,2074,4242,7194,5125,4096,4249,3255,1166,2098,5292,3076,2075,2074,2184,4117,7351,173,4112,1213,6682]

theorem envBound48900 : H12AffineFastState.Bounded env48900 := by
  intro p hp
  have h : env48900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48899_48900 : H12AffineEnvironment.transform 12 4257 env48899 = env48900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env48899 == env48900) = true)

theorem identity48900 : scanCanonicalize (H12AffineFastState.compose env48900 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 3734) := by decide +kernel

theorem selectedBound48900 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env48901 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3734,3639,1213,2706,1183,2074,3588,652,2707,3734,3599,3255,1166,2098,2618,3076,2075,2074,2184,3715,545,173,3718,1213,1164]

theorem envBound48901 : H12AffineFastState.Bounded env48901 := by
  intro p hp
  have h : env48901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48900_48901 : H12AffineEnvironment.transform 11 3734 env48900 = env48901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3734 env48900 == env48901) = true)

theorem identity48901 : scanCanonicalize (H12AffineFastState.compose env48901 (packedSelected [0,2,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound48901 : packedSelected [0,2,9,10,16] rootPS < 2^1333 := by decide +kernel

def env48902 : List Nat := [2,4,8,16,32,16,128,172,512,1024,554,1212,1053,1213,184,1183,560,1070,652,185,1212,1061,1693,1166,536,16,1582,561,560,674,1193,545,173,1196,1213,1164]

theorem envBound48902 : H12AffineFastState.Bounded env48902 := by
  intro p hp
  have h : env48902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48901_48902 : H12AffineEnvironment.transform 10 554 env48901 = env48902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env48901 == env48902) = true)

theorem identity48902 : scanCanonicalize (H12AffineFastState.compose env48902 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound48902 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48903 : List Nat := [2,4,8,16,32,16,128,172,512,516,554,696,537,697,184,667,560,554,652,185,696,545,153,650,536,16,42,561,560,674,685,545,173,680,697,648]

theorem envBound48903 : H12AffineFastState.Bounded env48903 := by
  intro p hp
  have h : env48903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48902_48903 : H12AffineEnvironment.transform 9 516 env48902 = env48903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env48902 == env48903) = true)

theorem identity48903 : scanCanonicalize (H12AffineFastState.compose env48903 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound48903 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env48904 : List Nat := [2,4,8,16,13,16,128,129,512,516,519,661,537,660,149,667,541,519,652,148,661,524,153,650,536,16,7,540,541,655,640,524,128,645,660,648]

theorem envBound48904 : H12AffineFastState.Bounded env48904 := by
  intro p hp
  have h : env48904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48903_48904 : H12AffineEnvironment.transform 4 13 env48903 = env48904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env48903 == env48904) = true)

theorem identity48904 : scanCanonicalize (H12AffineFastState.compose env48904 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound48904 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env48905 : List Nat := [2,4,8,16,13,16,128,129,27,31,28,142,2,143,149,128,6,28,151,148,142,23,153,145,3,16,7,7,6,148,155,23,128,158,143,147]

theorem envBound48905 : H12AffineFastState.Bounded env48905 := by
  intro p hp
  have h : env48905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48904_48905 : H12AffineEnvironment.transform 8 27 env48904 = env48905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env48904 == env48905) = true)

theorem identity48905 : scanCanonicalize (H12AffineFastState.compose env48905 (packedSelected [0,1,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound48905 : packedSelected [0,1,6,7] rootPS < 2^1333 := by decide +kernel

def env48906 : List Nat := [2,4,8,16,13,16,19,18,27,31,28,29,2,28,6,19,6,28,4,7,29,23,10,2,3,16,7,7,6,7,8,23,19,13,28,0]

theorem envBound48906 : H12AffineFastState.Bounded env48906 := by
  intro p hp
  have h : env48906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48905_48906 : H12AffineEnvironment.transform 6 19 env48905 = env48906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env48905 == env48906) = true)

theorem identity48906 : scanCanonicalize (H12AffineFastState.compose env48906 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48907 : List Nat := [2,2,8,16,11,16,19,18,27,25,26,27,2,26,0,19,0,26,2,1,27,17,10,2,3,16,1,1,0,1,8,17,19,11,26,0]

theorem envBound48907 : H12AffineFastState.Bounded env48907 := by
  intro p hp
  have h : env48907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48906_48907 : H12AffineEnvironment.transform 1 2 env48906 = env48907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48906 == env48907) = true)

def env48908 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143497,20497,492566,148669,148668,96266,74795,222255,173,74798,1212,135680]

theorem envBound48908 : H12AffineFastState.Bounded env48908 := by
  intro p hp
  have h : env48908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48893_48908 : H12AffineEnvironment.transform 5 17 env48893 = env48908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48893 == env48908) = true)

theorem identity48908 : scanCanonicalize (H12AffineFastState.compose env48908 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound48908 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48909 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,41003,32809,20497,341174,62493,62492,96266,74795,119951,173,74798,1212,41632]

theorem envBound48909 : H12AffineFastState.Bounded env48909 := by
  intro p hp
  have h : env48909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48908_48909 : H12AffineEnvironment.transform 16 45216 env48908 = env48909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env48908 == env48909) = true)

theorem identity48909 : scanCanonicalize (H12AffineFastState.compose env48909 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound48909 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env48910 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4096,46141,46092,41003,32809,5292,341174,45216,45217,81079,74795,102450,173,74798,1212,41632]

theorem envBound48910 : H12AffineFastState.Bounded env48910 := by
  intro p hp
  have h : env48910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48909_48910 : H12AffineEnvironment.transform 13 1213 env48909 = env48910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env48909 == env48910) = true)

theorem identity48910 : scanCanonicalize (H12AffineFastState.compose env48910 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound48910 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48911 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,12313,65536,185,262144,5305,12312,4096,1060,1045,4146,12336,5292,341174,185,184,81079,74795,73771,173,74798,1212,4793]

theorem envBound48911 : H12AffineFastState.Bounded env48911 := by
  intro p hp
  have h : env48911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48910_48911 : H12AffineEnvironment.transform 14 12313 env48910 = env48911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env48910 == env48911) = true)

theorem identity48911 : scanCanonicalize (H12AffineFastState.compose env48911 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound48911 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env48912 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,12313,9351,185,262144,5305,12312,4096,1060,1045,4146,12336,5292,266289,185,184,6192,172,1196,173,169,1212,4793]

theorem envBound48912 : H12AffineFastState.Bounded env48912 := by
  intro p hp
  have h : env48912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48911_48912 : H12AffineEnvironment.transform 15 9351 env48911 = env48912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env48911 == env48912) = true)

theorem identity48912 : scanCanonicalize (H12AffineFastState.compose env48912 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound48912 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env48913 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,12313,9351,185,6192,5305,12312,4096,1060,1045,4146,12336,5292,2049,185,184,6192,172,1196,173,169,1212,4793]

theorem envBound48913 : H12AffineFastState.Bounded env48913 := by
  intro p hp
  have h : env48913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48912_48913 : H12AffineEnvironment.transform 17 6192 env48912 = env48913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env48912 == env48913) = true)

theorem identity48913 : scanCanonicalize (H12AffineFastState.compose env48913 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound48913 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env48914 : List Nat := [2,4,8,16,32,17,128,172,147,1024,2048,4096,8192,1213,12313,9351,185,6192,5305,12312,4096,1060,1045,4146,12336,5292,2049,185,184,6192,172,1196,173,169,1212,4138]

theorem envBound48914 : H12AffineFastState.Bounded env48914 := by
  intro p hp
  have h : env48914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48913_48914 : H12AffineEnvironment.transform 8 147 env48913 = env48914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env48913 == env48914) = true)

theorem identity48914 : scanCanonicalize (H12AffineFastState.compose env48914 (packedSelected [1,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound48914 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env48915 : List Nat := [2,4,8,16,32,17,128,172,147,1024,2048,4096,1166,1213,5271,9,185,6192,5305,5270,4096,1060,1045,4146,5310,5292,2049,185,184,6192,172,1196,173,169,1212,4138]

theorem envBound48915 : H12AffineFastState.Bounded env48915 := by
  intro p hp
  have h : env48915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48914_48915 : H12AffineEnvironment.transform 12 1166 env48914 = env48915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env48914 == env48915) = true)

theorem identity48915 : scanCanonicalize (H12AffineFastState.compose env48915 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48915 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env48916 : List Nat := [2,4,8,11,32,10,128,172,136,1024,2048,4096,1166,1190,5260,9,162,6187,5282,5261,4096,1060,1038,4137,5285,5292,2049,162,163,6187,172,1196,173,169,1191,4138]

theorem envBound48916 : H12AffineFastState.Bounded env48916 := by
  intro p hp
  have h : env48916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48915_48916 : H12AffineEnvironment.transform 3 11 env48915 = env48916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48915 == env48916) = true)

theorem identity48916 : scanCanonicalize (H12AffineFastState.compose env48916 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound48916 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48917 : List Nat := [2,4,8,11,32,10,128,172,136,140,2048,4096,2,42,4096,9,162,6187,4142,4097,4096,168,130,4137,4137,4128,2049,162,163,6187,172,32,173,169,43,4138]

theorem envBound48917 : H12AffineFastState.Bounded env48917 := by
  intro p hp
  have h : env48917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48916_48917 : H12AffineEnvironment.transform 9 140 env48916 = env48917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env48916 == env48917) = true)

theorem identity48917 : scanCanonicalize (H12AffineFastState.compose env48917 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound48917 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48918 : List Nat := [2,4,8,11,32,10,128,172,136,140,2048,43,2,42,43,9,162,2048,5,42,43,168,130,2,2,11,2049,162,163,2048,172,32,173,169,43,1]

theorem envBound48918 : H12AffineFastState.Bounded env48918 := by
  intro p hp
  have h : env48918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48917_48918 : H12AffineEnvironment.transform 11 43 env48917 = env48918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env48917 == env48918) = true)

theorem identity48918 : scanCanonicalize (H12AffineFastState.compose env48918 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48918 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48919 : List Nat := [2,4,5,6,32,7,128,161,133,129,2048,38,2,39,38,4,162,2048,5,39,38,165,130,2,2,6,2049,162,163,2048,161,32,160,164,38,1]

theorem envBound48919 : H12AffineFastState.Bounded env48919 := by
  intro p hp
  have h : env48919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48918_48919 : H12AffineEnvironment.transform 2 5 env48918 = env48919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48918 == env48919) = true)

theorem identity48919 : scanCanonicalize (H12AffineFastState.compose env48919 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound48919 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48920 : List Nat := [2,4,5,6,32,7,128,161,133,129,38,38,2,39,38,4,162,38,5,39,38,165,130,2,2,6,39,162,163,38,161,32,160,164,38,1]

theorem envBound48920 : H12AffineFastState.Bounded env48920 := by
  intro p hp
  have h : env48920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48919_48920 : H12AffineEnvironment.transform 10 38 env48919 = env48920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env48919 == env48920) = true)

theorem identity48920 : scanCanonicalize (H12AffineFastState.compose env48920 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound48920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48921 : List Nat := [2,4,5,6,32,7,5,36,0,4,38,38,2,39,38,4,39,38,5,39,38,32,7,2,2,6,39,39,38,38,36,32,37,33,38,1]

theorem envBound48921 : H12AffineFastState.Bounded env48921 := by
  intro p hp
  have h : env48921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48920_48921 : H12AffineEnvironment.transform 6 5 env48920 = env48921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48920 == env48921) = true)

theorem identity48921 : scanCanonicalize (H12AffineFastState.compose env48921 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound48921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48922 : List Nat := [2,4,5,6,3,7,5,7,0,4,5,5,2,4,5,4,4,5,5,4,5,3,7,2,2,6,4,4,5,5,7,3,6,2,5,1]

theorem envBound48922 : H12AffineFastState.Bounded env48922 := by
  intro p hp
  have h : env48922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48921_48922 : H12AffineEnvironment.transform 4 3 env48921 = env48922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env48921 == env48922) = true)

theorem identity48922 : scanCanonicalize (H12AffineFastState.compose env48922 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48923 : List Nat := [2,0,1,2,3,3,1,3,0,0,1,1,2,0,1,0,0,1,1,0,1,3,3,2,2,2,0,0,1,1,3,3,2,2,1,1]

theorem envBound48923 : H12AffineFastState.Bounded env48923 := by
  intro p hp
  have h : env48923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48922_48923 : H12AffineEnvironment.transform 1 0 env48922 = env48923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48922 == env48923) = true)

theorem identity48923 : scanCanonicalize (H12AffineFastState.compose env48923 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48923 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48924 : List Nat := [1,0,1,1,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1,0,1,0,0,1,1,1,0,0,1,1,0,0,1,1,1,1]

theorem envBound48924 : H12AffineFastState.Bounded env48924 := by
  intro p hp
  have h : env48924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48923_48924 : H12AffineEnvironment.transform 0 1 env48923 = env48924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48923 == env48924) = true)

def env48925 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,492614,148717,148716,96347,74795,222334,172,74798,1260,135680]

theorem envBound48925 : H12AffineFastState.Bounded env48925 := by
  intro p hp
  have h : env48925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48892_48925 : H12AffineEnvironment.transform 7 173 env48892 = env48925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env48892 == env48925) = true)

def env48926 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143497,20497,492566,148669,148668,96267,74795,222254,172,74798,1212,135680]

theorem envBound48926 : H12AffineFastState.Bounded env48926 := by
  intro p hp
  have h : env48926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48925_48926 : H12AffineEnvironment.transform 5 16 env48925 = env48926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48925 == env48926) = true)

theorem identity48926 : scanCanonicalize (H12AffineFastState.compose env48926 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound48926 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48927 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61569,147472,41003,143497,20497,60444,148669,148668,96267,74795,222254,172,74798,1212,135680]

theorem envBound48927 : H12AffineFastState.Bounded env48927 := by
  intro p hp
  have h : env48927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48926_48927 : H12AffineEnvironment.transform 17 223242 env48926 = env48927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env48926 == env48927) = true)

theorem identity48927 : scanCanonicalize (H12AffineFastState.compose env48927 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound48927 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48928 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4096,61569,147472,41003,143497,20497,60444,148669,148668,2184,21672,136365,172,21677,1212,135680]

theorem envBound48928 : H12AffineFastState.Bounded env48928 := by
  intro p hp
  have h : env48928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48927_48928 : H12AffineEnvironment.transform 15 28803 env48927 = env48928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env48927 == env48928) = true)

theorem identity48928 : scanCanonicalize (H12AffineFastState.compose env48928 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound48928 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env48929 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,28803,131072,137353,136192,29861,4096,1061,147472,21647,143497,20497,6328,148669,148668,2184,21672,136365,172,21677,1212,135680]

theorem envBound48929 : H12AffineFastState.Bounded env48929 := by
  intro p hp
  have h : env48929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48928_48929 : H12AffineEnvironment.transform 14 29860 env48928 = env48929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env48928 == env48929) = true)

theorem identity48929 : scanCanonicalize (H12AffineFastState.compose env48929 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound48929 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env48930 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,13375,131072,137353,136192,12313,4096,1061,132268,4147,143497,5293,6328,131073,131072,2184,4116,136365,172,4113,1212,135680]

theorem envBound48930 : H12AffineFastState.Bounded env48930 := by
  intro p hp
  have h : env48930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48929_48930 : H12AffineEnvironment.transform 13 1212 env48929 = env48930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env48929 == env48930) = true)

theorem identity48930 : scanCanonicalize (H12AffineFastState.compose env48930 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound48930 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env48931 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2098,1212,6186,7181,131072,137353,136192,6187,4096,1061,132268,4147,137403,5293,6328,131073,131072,2184,4116,136365,172,4113,1212,135680]

theorem envBound48931 : H12AffineFastState.Bounded env48931 := by
  intro p hp
  have h : env48931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48930_48931 : H12AffineEnvironment.transform 12 2098 env48930 = env48931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env48930 == env48931) = true)

theorem identity48931 : scanCanonicalize (H12AffineFastState.compose env48931 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 5124) := by decide +kernel

theorem selectedBound48931 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env48932 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2098,1212,6186,7181,5124,3213,4,6187,4096,1061,4264,4147,3263,5293,6328,5125,5124,2184,4116,169,172,4113,1212,1540]

theorem envBound48932 : H12AffineFastState.Bounded env48932 := by
  intro p hp
  have h : env48932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48931_48932 : H12AffineEnvironment.transform 16 5124 env48931 = env48932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5124 env48931 == env48932) = true)

theorem identity48932 : scanCanonicalize (H12AffineFastState.compose env48932 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound48932 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48933 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,696,2098,1212,2706,3765,1724,3213,4,2707,696,1061,528,651,3263,1557,2560,1725,1724,2184,684,169,172,681,1212,1540]

theorem envBound48933 : H12AffineFastState.Bounded env48933 := by
  intro p hp
  have h : env48933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48932_48933 : H12AffineEnvironment.transform 11 696 env48932 = env48933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env48932 == env48933) = true)

theorem identity48933 : scanCanonicalize (H12AffineFastState.compose env48933 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound48933 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48934 : List Nat := [2,4,8,16,32,16,128,173,512,1024,163,696,145,1212,561,1558,1724,1070,4,560,696,1061,528,651,1052,1557,675,1725,1724,43,684,169,172,681,1212,1540]

theorem envBound48934 : H12AffineFastState.Bounded env48934 := by
  intro p hp
  have h : env48934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48933_48934 : H12AffineEnvironment.transform 10 163 env48933 = env48934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env48933 == env48934) = true)

theorem identity48934 : scanCanonicalize (H12AffineFastState.compose env48934 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound48934 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env48935 : List Nat := [2,4,8,16,32,16,128,173,146,1024,163,42,145,1212,163,1156,1070,1070,4,162,42,1061,130,25,1052,1159,49,1071,1070,43,62,169,172,59,1212,1174]

theorem envBound48935 : H12AffineFastState.Bounded env48935 := by
  intro p hp
  have h : env48935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48934_48935 : H12AffineEnvironment.transform 8 146 env48934 = env48935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env48934 == env48935) = true)

theorem identity48935 : scanCanonicalize (H12AffineFastState.compose env48935 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound48935 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env48936 : List Nat := [2,4,8,16,32,16,128,173,146,30,163,42,145,162,163,154,48,48,4,162,42,59,130,25,2,153,49,49,48,43,62,169,172,59,162,136]

theorem envBound48936 : H12AffineFastState.Bounded env48936 := by
  intro p hp
  have h : env48936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48935_48936 : H12AffineEnvironment.transform 9 30 env48935 = env48936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env48935 == env48936) = true)

theorem identity48936 : scanCanonicalize (H12AffineFastState.compose env48936 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48936 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48937 : List Nat := [2,4,8,7,32,7,128,173,133,9,163,42,134,162,163,141,39,39,4,162,42,44,130,14,2,142,38,38,39,43,41,169,172,44,162,136]

theorem envBound48937 : H12AffineFastState.Bounded env48937 := by
  intro p hp
  have h : env48937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48936_48937 : H12AffineEnvironment.transform 3 7 env48936 = env48937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48936 == env48937) = true)

def env48938 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143497,20497,492567,148668,148669,96266,74795,222255,172,74798,1213,135680]

theorem envBound48938 : H12AffineFastState.Bounded env48938 := by
  intro p hp
  have h : env48938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48925_48938 : H12AffineEnvironment.transform 5 17 env48925 = env48938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48925 == env48938) = true)

theorem identity48938 : scanCanonicalize (H12AffineFastState.compose env48938 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound48938 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48939 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61568,98354,41003,127146,20497,279604,99487,99486,96266,74795,41996,172,74798,1213,119331]

theorem envBound48939 : H12AffineFastState.Bounded env48939 := by
  intro p hp
  have h : env48939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48938_48939 : H12AffineEnvironment.transform 16 114723 env48938 = env48939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env48938 == env48939) = true)

theorem identity48939 : scanCanonicalize (H12AffineFastState.compose env48939 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 23693) := by decide +kernel

theorem selectedBound48939 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48940 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,23693,119843,32769,4096,61568,98354,41003,127146,20497,6329,99487,99486,96266,74795,41996,172,74798,1213,119331]

theorem envBound48940 : H12AffineFastState.Bounded env48940 := by
  intro p hp
  have h : env48940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48939_48940 : H12AffineEnvironment.transform 17 23693 env48939 = env48940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23693 env48939 == env48940) = true)

theorem identity48940 : scanCanonicalize (H12AffineFastState.compose env48940 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound48940 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env48941 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,23693,1024,32769,4096,61568,20497,41003,8329,20497,6329,21692,21693,43049,62472,41996,172,62477,1213,512]

theorem envBound48941 : H12AffineFastState.Bounded env48941 := by
  intro p hp
  have h : env48941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48940_48941 : H12AffineEnvironment.transform 15 53283 env48940 = env48941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env48940 == env48941) = true)

theorem identity48941 : scanCanonicalize (H12AffineFastState.compose env48941 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound48941 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48942 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,24634,4096,23693,1024,12312,4096,16537,20497,4146,8329,20497,6329,21692,21693,6192,17425,5141,172,17428,1213,512]

theorem envBound48942 : H12AffineFastState.Bounded env48942 := by
  intro p hp
  have h : env48942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48941_48942 : H12AffineEnvironment.transform 14 12313 env48941 = env48942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env48941 == env48942) = true)

theorem identity48942 : scanCanonicalize (H12AffineFastState.compose env48942 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound48942 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48943 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,8745,12313,531,4096,16036,1024,12312,4096,8880,12856,4146,8329,12856,6329,13973,13972,6192,9784,5141,172,9789,1213,512]

theorem envBound48943 : H12AffineFastState.Bounded env48943 := by
  intro p hp
  have h : env48943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48942_48943 : H12AffineEnvironment.transform 13 8745 env48942 = env48943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env48942 == env48943) = true)

theorem identity48943 : scanCanonicalize (H12AffineFastState.compose env48943 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound48943 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env48944 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,674,8192,8745,8891,531,674,11270,1024,8890,674,8880,8346,656,8329,8346,2587,9271,9270,2706,9784,1719,172,9789,1213,512]

theorem envBound48944 : H12AffineFastState.Bounded env48944 := by
  intro p hp
  have h : env48944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48943_48944 : H12AffineEnvironment.transform 11 674 env48943 = env48944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env48943 == env48944) = true)

theorem identity48944 : scanCanonicalize (H12AffineFastState.compose env48944 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound48944 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48945 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1212,674,8192,8745,8891,531,674,8378,1024,8890,674,8880,8346,656,8329,8346,1703,9271,9270,1582,9784,1719,172,9789,1213,512]

theorem envBound48945 : H12AffineFastState.Bounded env48945 := by
  intro p hp
  have h : env48945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48944_48945 : H12AffineEnvironment.transform 10 1212 env48944 = env48945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env48944 == env48945) = true)

theorem identity48945 : scanCanonicalize (H12AffineFastState.compose env48945 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound48945 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env48946 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1212,674,25,560,674,531,674,163,1024,675,674,681,131,656,144,131,1703,1070,1071,1582,1569,1719,172,1572,1213,512]

theorem envBound48946 : H12AffineFastState.Bounded env48946 := by
  intro p hp
  have h : env48946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48945_48946 : H12AffineEnvironment.transform 12 25 env48945 = env48946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48945 == env48946) = true)

theorem identity48946 : scanCanonicalize (H12AffineFastState.compose env48946 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48946 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env48947 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1212,162,25,48,162,19,162,163,1024,163,162,169,131,144,144,131,1191,1070,1071,1070,1057,1207,172,1060,1213,0]

theorem envBound48947 : H12AffineFastState.Bounded env48947 := by
  intro p hp
  have h : env48947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48946_48947 : H12AffineEnvironment.transform 8 0 env48946 = env48947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48946 == env48947) = true)

theorem identity48947 : scanCanonicalize (H12AffineFastState.compose env48947 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48947 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env48948 : List Nat := [2,4,8,16,32,17,128,173,0,4,184,162,25,48,162,19,162,163,4,163,162,169,131,144,144,131,163,42,43,42,37,179,172,32,185,0]

theorem envBound48948 : H12AffineFastState.Bounded env48948 := by
  intro p hp
  have h : env48948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48947_48948 : H12AffineEnvironment.transform 9 4 env48947 = env48948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48947 == env48948) = true)

theorem identity48948 : scanCanonicalize (H12AffineFastState.compose env48948 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48948 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48949 : List Nat := [2,4,8,16,32,17,8,37,0,4,48,42,25,48,42,19,42,43,4,43,42,33,11,24,24,11,43,42,43,42,37,59,36,32,49,0]

theorem envBound48949 : H12AffineFastState.Bounded env48949 := by
  intro p hp
  have h : env48949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48948_48949 : H12AffineEnvironment.transform 6 8 env48948 = env48949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48948 == env48949) = true)

theorem identity48949 : scanCanonicalize (H12AffineFastState.compose env48949 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48949 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48950 : List Nat := [2,4,8,10,32,11,8,37,0,4,42,42,3,42,42,9,42,43,4,43,42,33,11,2,2,11,43,42,43,42,37,33,36,32,43,0]

theorem envBound48950 : H12AffineFastState.Bounded env48950 := by
  intro p hp
  have h : env48950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48949_48950 : H12AffineEnvironment.transform 3 10 env48949 = env48950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48949 == env48950) = true)

theorem identity48950 : scanCanonicalize (H12AffineFastState.compose env48950 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48951 : List Nat := [2,4,4,6,32,7,4,37,0,4,38,38,3,38,38,5,38,39,4,39,38,33,7,2,2,7,39,38,39,38,37,33,36,32,39,0]

theorem envBound48951 : H12AffineFastState.Bounded env48951 := by
  intro p hp
  have h : env48951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48950_48951 : H12AffineEnvironment.transform 2 4 env48950 = env48951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48950 == env48951) = true)

theorem identity48951 : scanCanonicalize (H12AffineFastState.compose env48951 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48951 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48952 : List Nat := [2,4,4,6,7,7,4,2,0,4,1,1,3,1,1,5,1,0,4,0,1,6,7,2,2,7,0,1,0,1,2,6,3,7,0,0]

theorem envBound48952 : H12AffineFastState.Bounded env48952 := by
  intro p hp
  have h : env48952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48951_48952 : H12AffineEnvironment.transform 4 7 env48951 = env48952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48951 == env48952) = true)

def env48953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,493035,148800,148800,96347,74795,222335,257,74798,1345,135681]

theorem envBound48953 : H12AffineFastState.Bounded env48953 := by
  intro p hp
  have h : env48953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48891_48953 : H12AffineEnvironment.transform 18 136193 env48891 = env48953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env48891 == env48953) = true)

def env48954 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,492615,148716,148716,96347,74795,222335,173,74798,1261,135681]

theorem envBound48954 : H12AffineFastState.Bounded env48954 := by
  intro p hp
  have h : env48954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48953_48954 : H12AffineEnvironment.transform 7 172 env48953 = env48954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48953 == env48954) = true)

def env48955 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143496,20496,492567,148668,148668,96267,74795,222255,173,74798,1213,135681]

theorem envBound48955 : H12AffineFastState.Bounded env48955 := by
  intro p hp
  have h : env48955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48954_48955 : H12AffineEnvironment.transform 5 16 env48954 = env48955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48954 == env48955) = true)

theorem identity48955 : scanCanonicalize (H12AffineFastState.compose env48955 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound48955 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48956 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,41003,32809,20496,341174,62493,62493,96267,74795,119950,173,74798,1213,41632]

theorem envBound48956 : H12AffineFastState.Bounded env48956 := by
  intro p hp
  have h : env48956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48955_48956 : H12AffineEnvironment.transform 16 45217 env48955 = env48956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env48955 == env48956) = true)

theorem identity48956 : scanCanonicalize (H12AffineFastState.compose env48956 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound48956 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env48957 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4096,46141,46093,41003,32809,5292,341174,45217,45217,81079,74795,102450,173,74798,1213,41632]

theorem envBound48957 : H12AffineFastState.Bounded env48957 := by
  intro p hp
  have h : env48957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48956_48957 : H12AffineEnvironment.transform 13 1212 env48956 = env48957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env48956 == env48957) = true)

theorem identity48957 : scanCanonicalize (H12AffineFastState.compose env48957 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound48957 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48958 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12312,65536,185,262144,5304,12313,4096,1061,1045,4147,12337,5292,341174,185,185,81079,74795,73770,173,74798,1213,4792]

theorem envBound48958 : H12AffineFastState.Bounded env48958 := by
  intro p hp
  have h : env48958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48957_48958 : H12AffineEnvironment.transform 14 12312 env48957 = env48958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env48957 == env48958) = true)

theorem identity48958 : scanCanonicalize (H12AffineFastState.compose env48958 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound48958 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env48959 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12312,9350,185,262144,5304,12313,4096,1061,1045,4147,12337,5292,266288,185,185,6193,173,1196,173,168,1213,4792]

theorem envBound48959 : H12AffineFastState.Bounded env48959 := by
  intro p hp
  have h : env48959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48958_48959 : H12AffineEnvironment.transform 15 9350 env48958 = env48959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env48958 == env48959) = true)

theorem identity48959 : scanCanonicalize (H12AffineFastState.compose env48959 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound48959 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env48960 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12312,9350,185,2185,5304,12313,4096,1061,1045,4147,12337,5292,6329,185,185,6193,173,1196,173,168,1213,4792]

theorem envBound48960 : H12AffineFastState.Bounded env48960 := by
  intro p hp
  have h : env48960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48959_48960 : H12AffineEnvironment.transform 17 2185 env48959 = env48960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env48959 == env48960) = true)

theorem identity48960 : scanCanonicalize (H12AffineFastState.compose env48960 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48960 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env48961 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,4096,8192,1212,12312,9350,185,2185,5304,12313,4096,1061,1045,4147,12337,5292,6329,185,185,6193,173,1196,173,168,1213,4281]

theorem envBound48961 : H12AffineFastState.Bounded env48961 := by
  intro p hp
  have h : env48961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48960_48961 : H12AffineEnvironment.transform 8 1 env48960 = env48961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48960 == env48961) = true)

theorem identity48961 : scanCanonicalize (H12AffineFastState.compose env48961 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound48961 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48962 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2185,8192,1212,10385,9350,185,2185,3121,10384,2185,1061,1045,2234,10424,3109,48,185,185,184,173,1196,173,168,1213,2096]

theorem envBound48962 : H12AffineFastState.Bounded env48962 := by
  intro p hp
  have h : env48962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48961_48962 : H12AffineEnvironment.transform 11 2185 env48961 = env48962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env48961 == env48962) = true)

theorem identity48962 : scanCanonicalize (H12AffineFastState.compose env48962 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound48962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48963 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2185,2089,1212,184,3247,185,2185,3121,185,2185,1061,1045,2234,145,3109,48,185,185,184,173,1196,173,168,1213,2096]

theorem envBound48963 : H12AffineFastState.Bounded env48963 := by
  intro p hp
  have h : env48963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48962_48963 : H12AffineEnvironment.transform 12 2089 env48962 = env48963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env48962 == env48963) = true)

theorem identity48963 : scanCanonicalize (H12AffineFastState.compose env48963 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound48963 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env48964 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1213,1076,1172,1212,184,18,185,1076,140,185,1076,1061,1045,1031,145,152,48,185,185,184,173,1196,173,168,1213,1165]

theorem envBound48964 : H12AffineFastState.Bounded env48964 := by
  intro p hp
  have h : env48964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48963_48964 : H12AffineEnvironment.transform 10 1213 env48963 = env48964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env48963 == env48964) = true)

theorem identity48964 : scanCanonicalize (H12AffineFastState.compose env48964 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48964 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env48965 : List Nat := [2,4,8,10,32,10,128,172,1,1024,1191,1070,1166,1190,162,8,163,1070,140,163,1070,1061,1039,1031,139,130,42,163,163,162,173,1196,173,168,1191,1165]

theorem envBound48965 : H12AffineFastState.Bounded env48965 := by
  intro p hp
  have h : env48965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48964_48965 : H12AffineEnvironment.transform 3 10 env48964 = env48965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48964 == env48965) = true)

theorem identity48965 : scanCanonicalize (H12AffineFastState.compose env48965 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48965 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48966 : List Nat := [2,4,8,10,32,10,9,37,1,1024,1070,1070,1031,1071,43,8,42,1070,5,42,1070,1061,1039,1031,2,11,42,42,42,43,36,1061,36,33,1070,1028]

theorem envBound48966 : H12AffineFastState.Bounded env48966 := by
  intro p hp
  have h : env48966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48965_48966 : H12AffineEnvironment.transform 6 9 env48965 = env48966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48965 == env48966) = true)

theorem identity48966 : scanCanonicalize (H12AffineFastState.compose env48966 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48967 : List Nat := [2,4,8,10,7,10,9,2,1,1024,1033,1033,1031,1032,12,8,13,1033,5,13,1033,1026,1039,1031,2,11,13,13,13,12,3,1026,3,6,1033,1028]

theorem envBound48967 : H12AffineFastState.Bounded env48967 := by
  intro p hp
  have h : env48967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48966_48967 : H12AffineEnvironment.transform 4 7 env48966 = env48967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48966 == env48967) = true)

def env48968 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143496,20496,492566,148669,148669,96266,74795,222254,173,74798,1212,135681]

theorem envBound48968 : H12AffineFastState.Bounded env48968 := by
  intro p hp
  have h : env48968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48954_48968 : H12AffineEnvironment.transform 5 17 env48954 = env48968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48954 == env48968) = true)

theorem identity48968 : scanCanonicalize (H12AffineFastState.compose env48968 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound48968 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48969 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,41003,143496,20496,105631,148669,148669,96266,74795,222254,173,74798,1212,135681]

theorem envBound48969 : H12AffineFastState.Bounded env48969 := by
  intro p hp
  have h : env48969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48968_48969 : H12AffineEnvironment.transform 17 137353 env48968 = env48969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env48968 == env48969) = true)

theorem identity48969 : scanCanonicalize (H12AffineFastState.compose env48969 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound48969 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48970 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4096,61568,147473,41003,143496,20496,43169,148669,148669,19508,4117,151568,173,4112,1212,135681]

theorem envBound48970 : H12AffineFastState.Bounded env48970 := by
  intro p hp
  have h : env48970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48969_48970 : H12AffineEnvironment.transform 15 13374 env48969 = env48970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env48969 == env48970) = true)

theorem identity48970 : scanCanonicalize (H12AffineFastState.compose env48970 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound48970 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env48971 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136193,32769,4096,46140,132269,41003,143496,5292,43169,131073,131073,2184,4117,136364,173,4112,1212,135681]

theorem envBound48971 : H12AffineFastState.Bounded env48971 := by
  intro p hp
  have h : env48971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48970_48971 : H12AffineEnvironment.transform 13 1212 env48970 = env48971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env48970 == env48971) = true)

theorem identity48971 : scanCanonicalize (H12AffineFastState.compose env48971 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound48971 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env48972 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,46244,44077,41125,32769,4096,46140,45065,41003,33836,5292,43169,46245,46245,2184,4117,40968,173,4112,1212,42661]

theorem envBound48972 : H12AffineFastState.Bounded env48972 := by
  intro p hp
  have h : env48972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48971_48972 : H12AffineEnvironment.transform 16 46244 env48971 = env48972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env48971 == env48972) = true)

theorem identity48972 : scanCanonicalize (H12AffineFastState.compose env48972 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48972 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env48973 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,32768,12346,45216,43049,41125,32769,4096,45112,45065,41003,32808,4264,43169,45217,45217,2184,4117,40968,173,4112,184,41633]

theorem envBound48973 : H12AffineFastState.Bounded env48973 := by
  intro p hp
  have h : env48973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48972_48973 : H12AffineEnvironment.transform 9 4 env48972 = env48973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48972 == env48973) = true)

theorem identity48973 : scanCanonicalize (H12AffineFastState.compose env48973 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound48973 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48974 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,2194,8192,184,32768,10408,43058,43049,41125,32769,2194,43178,43163,41003,32808,2106,43169,43059,43059,2184,2183,40968,173,2178,184,41633]

theorem envBound48974 : H12AffineFastState.Bounded env48974 := by
  intro p hp
  have h : env48974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48973_48974 : H12AffineEnvironment.transform 11 2194 env48973 = env48974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env48973 == env48974) = true)

theorem identity48974 : scanCanonicalize (H12AffineFastState.compose env48974 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 10426) := by decide +kernel

theorem selectedBound48974 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48975 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,2194,8192,184,10426,10408,136,147,2079,10427,2194,16,33,2193,10386,2106,27,137,137,2184,2183,2226,173,2178,184,2587]

theorem envBound48975 : H12AffineFastState.Bounded env48975 := by
  intro p hp
  have h : env48975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48974_48975 : H12AffineEnvironment.transform 14 10426 env48974 = env48975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10426 env48974 == env48975) = true)

theorem identity48975 : scanCanonicalize (H12AffineFastState.compose env48975 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48975 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env48976 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,2194,40,184,2194,2176,136,147,2079,2195,2194,16,33,2193,2234,2106,27,137,137,2184,2183,2226,173,2178,184,2587]

theorem envBound48976 : H12AffineFastState.Bounded env48976 := by
  intro p hp
  have h : env48976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48975_48976 : H12AffineEnvironment.transform 12 40 env48975 = env48976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48975 == env48976) = true)

theorem identity48976 : scanCanonicalize (H12AffineFastState.compose env48976 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48976 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48977 : List Nat := [2,4,8,16,32,17,128,172,42,4,2048,2194,40,184,2194,2176,136,147,2079,2195,2194,16,33,2193,2234,2106,27,137,137,2184,2183,2226,173,2178,184,2097]

theorem envBound48977 : H12AffineFastState.Bounded env48977 := by
  intro p hp
  have h : env48977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48976_48977 : H12AffineEnvironment.transform 8 42 env48976 = env48977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48976 == env48977) = true)

theorem identity48977 : scanCanonicalize (H12AffineFastState.compose env48977 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound48977 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env48978 : List Nat := [2,4,8,16,32,17,128,172,42,4,185,43,40,184,43,57,136,147,166,42,43,16,33,40,3,131,27,137,137,49,62,11,173,59,184,136]

theorem envBound48978 : H12AffineFastState.Bounded env48978 := by
  intro p hp
  have h : env48978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48977_48978 : H12AffineEnvironment.transform 10 185 env48977 = env48978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env48977 == env48978) = true)

theorem identity48978 : scanCanonicalize (H12AffineFastState.compose env48978 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48978 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48979 : List Nat := [2,4,8,16,10,17,128,134,0,4,147,1,2,146,1,19,136,147,140,0,1,16,11,2,3,131,27,137,137,27,20,11,135,17,146,136]

theorem envBound48979 : H12AffineFastState.Bounded env48979 := by
  intro p hp
  have h : env48979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48978_48979 : H12AffineEnvironment.transform 4 10 env48978 = env48979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48978 == env48979) = true)

theorem identity48979 : scanCanonicalize (H12AffineFastState.compose env48979 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound48979 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48980 : List Nat := [2,4,8,16,10,17,19,21,0,4,0,1,2,1,1,19,27,0,31,0,1,16,11,2,3,16,27,26,26,27,20,11,20,17,1,27]

theorem envBound48980 : H12AffineFastState.Bounded env48980 := by
  intro p hp
  have h : env48980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48979_48980 : H12AffineEnvironment.transform 6 19 env48979 = env48980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env48979 == env48980) = true)

theorem identity48980 : scanCanonicalize (H12AffineFastState.compose env48980 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48980 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48981 : List Nat := [2,4,8,10,10,11,9,15,0,4,0,1,2,1,1,9,1,0,5,0,1,10,11,2,3,10,1,0,0,1,14,11,14,11,1,1]

theorem envBound48981 : H12AffineFastState.Bounded env48981 := by
  intro p hp
  have h : env48981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48980_48981 : H12AffineEnvironment.transform 3 10 env48980 = env48981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48980 == env48981) = true)

theorem identity48981 : scanCanonicalize (H12AffineFastState.compose env48981 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48981 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48982 : List Nat := [2,1,8,10,10,11,9,10,0,1,0,1,2,1,1,9,1,0,0,0,1,10,11,2,3,10,1,0,0,1,11,11,11,11,1,1]

theorem envBound48982 : H12AffineFastState.Bounded env48982 := by
  intro p hp
  have h : env48982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48981_48982 : H12AffineEnvironment.transform 1 1 env48981 = env48982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48981 == env48982) = true)

theorem identity48982 : scanCanonicalize (H12AffineFastState.compose env48982 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48983 : List Nat := [2,1,1,3,3,2,0,3,0,1,0,1,2,1,1,0,1,0,0,0,1,3,2,2,3,3,1,0,0,1,2,2,2,2,1,1]

theorem envBound48983 : H12AffineFastState.Bounded env48983 := by
  intro p hp
  have h : env48983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48982_48983 : H12AffineEnvironment.transform 2 1 env48982 = env48983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48982 == env48983) = true)

theorem identity48983 : scanCanonicalize (H12AffineFastState.compose env48983 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48983 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48984 : List Nat := [1,1,1,0,0,1,0,0,0,1,0,1,1,1,1,0,1,0,0,0,1,0,1,1,0,0,1,0,0,1,1,1,1,1,1,1]

theorem envBound48984 : H12AffineFastState.Bounded env48984 := by
  intro p hp
  have h : env48984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48983_48984 : H12AffineEnvironment.transform 0 1 env48983 = env48984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48983 == env48984) = true)

def env48985 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,492614,148717,148717,96347,74795,222335,172,74798,1260,135681]

theorem envBound48985 : H12AffineFastState.Bounded env48985 := by
  intro p hp
  have h : env48985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48953_48985 : H12AffineEnvironment.transform 7 173 env48953 = env48985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env48953 == env48985) = true)

def env48986 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143496,20496,492566,148669,148669,96267,74795,222255,172,74798,1212,135681]

theorem envBound48986 : H12AffineFastState.Bounded env48986 := by
  intro p hp
  have h : env48986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48985_48986 : H12AffineEnvironment.transform 5 16 env48985 = env48986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48985 == env48986) = true)

theorem identity48986 : scanCanonicalize (H12AffineFastState.compose env48986 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound48986 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48987 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61569,98355,41003,127147,20496,279605,99486,99486,96267,74795,41996,172,74798,1212,119330]

theorem envBound48987 : H12AffineFastState.Bounded env48987 := by
  intro p hp
  have h : env48987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48986_48987 : H12AffineEnvironment.transform 16 114723 env48986 = env48987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env48986 == env48987) = true)

theorem identity48987 : scanCanonicalize (H12AffineFastState.compose env48987 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 23693) := by decide +kernel

theorem selectedBound48987 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48988 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,23693,119842,32769,4096,61569,98355,41003,127147,20496,6328,99486,99486,96267,74795,41996,172,74798,1212,119330]

theorem envBound48988 : H12AffineFastState.Bounded env48988 := by
  intro p hp
  have h : env48988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48987_48988 : H12AffineEnvironment.transform 17 23693 env48987 = env48988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23693 env48987 == env48988) = true)

theorem identity48988 : scanCanonicalize (H12AffineFastState.compose env48988 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound48988 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env48989 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,23693,1024,32769,4096,61569,20497,41003,8329,20496,6328,21692,21692,43049,62473,41996,172,62476,1212,512]

theorem envBound48989 : H12AffineFastState.Bounded env48989 := by
  intro p hp
  have h : env48989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48988_48989 : H12AffineEnvironment.transform 15 53282 env48988 = env48989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env48988 == env48989) = true)

theorem identity48989 : scanCanonicalize (H12AffineFastState.compose env48989 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound48989 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48990 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,24634,4097,23693,1024,12313,4096,16537,20497,4147,8329,20496,6328,21692,21692,6193,17425,5140,172,17428,1212,512]

theorem envBound48990 : H12AffineFastState.Bounded env48990 := by
  intro p hp
  have h : env48990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48989_48990 : H12AffineEnvironment.transform 14 12312 env48989 = env48990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env48989 == env48990) = true)

theorem identity48990 : scanCanonicalize (H12AffineFastState.compose env48990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12944) := by decide +kernel

theorem selectedBound48990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48991 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,12944,12312,4778,4097,11805,1024,12313,4096,12809,8833,4147,8329,8832,6328,9772,9772,6193,13953,5140,172,13956,1212,512]

theorem envBound48991 : H12AffineFastState.Bounded env48991 := by
  intro p hp
  have h : env48991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48990_48991 : H12AffineEnvironment.transform 13 12944 env48990 = env48991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12944 env48990 == env48991) = true)

theorem identity48991 : scanCanonicalize (H12AffineFastState.compose env48991 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound48991 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env48992 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,675,8192,8243,8891,9,674,11805,1024,8890,675,8362,8833,656,8329,8832,2587,9772,9772,2706,9250,1719,172,9255,1212,512]

theorem envBound48992 : H12AffineFastState.Bounded env48992 := by
  intro p hp
  have h : env48992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48991_48992 : H12AffineEnvironment.transform 11 675 env48991 = env48992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env48991 == env48992) = true)

theorem identity48992 : scanCanonicalize (H12AffineFastState.compose env48992 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound48992 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48993 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1212,675,8192,8243,8891,9,674,8865,1024,8890,675,8362,8833,656,8329,8832,1703,9772,9772,1582,9250,1719,172,9255,1212,512]

theorem envBound48993 : H12AffineFastState.Bounded env48993 := by
  intro p hp
  have h : env48993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48992_48993 : H12AffineEnvironment.transform 10 1212 env48992 = env48993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env48992 == env48993) = true)

theorem identity48993 : scanCanonicalize (H12AffineFastState.compose env48993 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound48993 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env48994 : List Nat := [2,4,8,16,32,16,128,173,512,150,42,675,8192,8243,8891,9,674,8865,150,8890,675,8362,8833,656,8329,8832,561,8890,8890,696,8372,545,172,8369,42,512]

theorem envBound48994 : H12AffineFastState.Bounded env48994 := by
  intro p hp
  have h : env48994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48993_48994 : H12AffineEnvironment.transform 9 150 env48993 = env48994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env48993 == env48994) = true)

theorem identity48994 : scanCanonicalize (H12AffineFastState.compose env48994 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound48994 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48995 : List Nat := [2,4,8,16,32,16,128,173,512,150,42,675,2,49,697,9,674,675,150,696,675,168,643,656,139,642,561,696,696,696,182,545,172,179,42,512]

theorem envBound48995 : H12AffineFastState.Bounded env48995 := by
  intro p hp
  have h : env48995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48994_48995 : H12AffineEnvironment.transform 12 2 env48994 = env48995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env48994 == env48995) = true)

theorem identity48995 : scanCanonicalize (H12AffineFastState.compose env48995 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48995 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env48996 : List Nat := [2,4,8,10,32,10,128,173,512,140,42,675,2,43,675,9,674,675,140,674,675,168,643,650,139,642,555,674,674,674,172,545,172,169,42,512]

theorem envBound48996 : H12AffineFastState.Bounded env48996 := by
  intro p hp
  have h : env48996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48995_48996 : H12AffineEnvironment.transform 3 10 env48995 = env48996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48995 == env48996) = true)

theorem identity48996 : scanCanonicalize (H12AffineFastState.compose env48996 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48996 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env48997 : List Nat := [2,4,8,10,32,10,128,173,0,140,42,163,2,43,163,9,162,163,140,162,163,168,131,138,139,130,43,162,162,162,172,33,172,169,42,0]

theorem envBound48997 : H12AffineFastState.Bounded env48997 := by
  intro p hp
  have h : env48997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48996_48997 : H12AffineEnvironment.transform 8 0 env48996 = env48997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48996 == env48997) = true)

theorem identity48997 : scanCanonicalize (H12AffineFastState.compose env48997 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48998 : List Nat := [2,4,8,10,11,10,128,134,0,140,1,136,2,0,136,9,137,136,140,137,136,131,131,138,139,130,0,137,137,137,135,10,135,130,1,0]

theorem envBound48998 : H12AffineFastState.Bounded env48998 := by
  intro p hp
  have h : env48998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48997_48998 : H12AffineEnvironment.transform 4 11 env48997 = env48998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48997 == env48998) = true)

theorem identity48998 : scanCanonicalize (H12AffineFastState.compose env48998 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48999 : List Nat := [2,4,5,7,6,7,128,134,0,129,1,133,2,0,133,4,132,133,129,132,133,131,131,135,134,130,0,132,132,132,135,7,135,130,1,0]

theorem envBound48999 : H12AffineFastState.Bounded env48999 := by
  intro p hp
  have h : env48999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48998_48999 : H12AffineEnvironment.transform 2 5 env48998 = env48999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48998 == env48999) = true)

theorem identity48999 : scanCanonicalize (H12AffineFastState.compose env48999 (packedSelected [9] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48999 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env49000 : List Nat := [2,4,5,7,6,7,4,2,0,5,1,1,2,0,1,4,0,1,5,0,1,7,7,3,2,6,0,0,0,0,3,7,3,6,1,0]

theorem envBound49000 : H12AffineFastState.Bounded env49000 := by
  intro p hp
  have h : env49000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48999_49000 : H12AffineEnvironment.transform 6 4 env48999 = env49000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48999 == env49000) = true)

def env49001 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143496,20496,492567,148668,148668,96266,74795,222254,172,74798,1213,135681]

theorem envBound49001 : H12AffineFastState.Bounded env49001 := by
  intro p hp
  have h : env49001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48985_49001 : H12AffineEnvironment.transform 5 17 env48985 = env49001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48985 == env49001) = true)

theorem identity49001 : scanCanonicalize (H12AffineFastState.compose env49001 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound49001 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49002 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61568,147473,41003,143496,20496,60445,148668,148668,96266,74795,222254,172,74798,1213,135681]

theorem envBound49002 : H12AffineFastState.Bounded env49002 := by
  intro p hp
  have h : env49002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49001_49002 : H12AffineEnvironment.transform 17 223242 env49001 = env49002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env49001 == env49002) = true)

theorem identity49002 : scanCanonicalize (H12AffineFastState.compose env49002 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound49002 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49003 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4096,61568,147473,41003,143496,20496,60445,148668,148668,2184,21673,136364,172,21676,1213,135681]

theorem envBound49003 : H12AffineFastState.Bounded env49003 := by
  intro p hp
  have h : env49003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49002_49003 : H12AffineEnvironment.transform 15 28802 env49002 = env49003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env49002 == env49003) = true)

theorem identity49003 : scanCanonicalize (H12AffineFastState.compose env49003 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound49003 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49004 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,28802,131072,137352,136193,29861,4096,1060,147473,21647,143496,20496,6329,148668,148668,2184,21673,136364,172,21676,1213,135681]

theorem envBound49004 : H12AffineFastState.Bounded env49004 := by
  intro p hp
  have h : env49004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49003_49004 : H12AffineEnvironment.transform 14 29860 env49003 = env49004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env49003 == env49004) = true)

theorem identity49004 : scanCanonicalize (H12AffineFastState.compose env49004 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49004 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env49005 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12313,13375,131072,137352,136193,12312,4096,1060,132268,4146,143496,5293,6329,131073,131073,2184,4116,136364,172,4113,1213,135681]

theorem envBound49005 : H12AffineFastState.Bounded env49005 := by
  intro p hp
  have h : env49005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49004_49005 : H12AffineEnvironment.transform 13 1213 env49004 = env49005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env49004 == env49005) = true)

theorem identity49005 : scanCanonicalize (H12AffineFastState.compose env49005 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound49005 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env49006 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6282,1213,2195,3253,131072,137352,136193,2194,4096,1060,132268,4146,133122,5293,6329,131073,131073,2184,4116,136364,172,4113,1213,135681]

theorem envBound49006 : H12AffineFastState.Bounded env49006 := by
  intro p hp
  have h : env49006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49005_49006 : H12AffineEnvironment.transform 12 6282 env49005 = env49006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env49005 == env49006) = true)

theorem identity49006 : scanCanonicalize (H12AffineFastState.compose env49006 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound49006 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env49007 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,6282,185,2195,2225,131072,137352,135173,2194,4096,32,131240,4146,133122,4265,6329,131073,131073,2184,4116,135336,172,4113,185,135681]

theorem envBound49007 : H12AffineFastState.Bounded env49007 := by
  intro p hp
  have h : env49007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49006_49007 : H12AffineEnvironment.transform 9 4 env49006 = env49007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env49006 == env49007) = true)

theorem identity49007 : scanCanonicalize (H12AffineFastState.compose env49007 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49007 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env49008 : List Nat := [2,4,8,16,32,17,128,173,1,4,2048,4096,6282,185,2195,2225,131072,137352,135173,2194,4096,32,131240,4146,133122,4265,6329,131073,131073,2184,4116,135336,172,4113,185,135168]

theorem envBound49008 : H12AffineFastState.Bounded env49008 := by
  intro p hp
  have h : env49008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49007_49008 : H12AffineEnvironment.transform 8 1 env49007 = env49008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49007 == env49008) = true)

theorem identity49008 : scanCanonicalize (H12AffineFastState.compose env49008 (packedSelected [5,8] rootPS)) = affineNative (2^(16+1) ^^^ 6306) := by decide +kernel

theorem selectedBound49008 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49009 : List Nat := [2,4,8,16,32,17,128,173,1,4,2048,4096,6282,185,2195,2225,6306,42,2215,2194,4096,32,6154,4146,4256,4265,6329,6307,6307,2184,4116,2058,172,4113,185,2210]

theorem envBound49009 : H12AffineFastState.Bounded env49009 := by
  intro p hp
  have h : env49009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49008_49009 : H12AffineEnvironment.transform 16 6306 env49008 = env49009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6306 env49008 == env49009) = true)

theorem identity49009 : scanCanonicalize (H12AffineFastState.compose env49009 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound49009 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49010 : List Nat := [2,4,8,16,32,17,128,173,1,4,2048,43,2209,185,2195,2225,2185,42,2215,2194,43,32,2081,25,139,130,2194,2184,2184,2184,63,2058,172,58,185,2210]

theorem envBound49010 : H12AffineFastState.Bounded env49010 := by
  intro p hp
  have h : env49010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49009_49010 : H12AffineEnvironment.transform 11 43 env49009 = env49010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env49009 == env49010) = true)

theorem identity49010 : scanCanonicalize (H12AffineFastState.compose env49010 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound49010 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49011 : List Nat := [2,4,8,16,32,17,128,173,1,4,13,43,172,185,158,188,132,42,170,159,43,32,44,25,139,130,159,133,133,133,63,7,172,58,185,175]

theorem envBound49011 : H12AffineFastState.Bounded env49011 := by
  intro p hp
  have h : env49011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49010_49011 : H12AffineEnvironment.transform 10 13 env49010 = env49011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env49010 == env49011) = true)

theorem identity49011 : scanCanonicalize (H12AffineFastState.compose env49011 (packedSelected [0,1,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49011 : packedSelected [0,1,2,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2