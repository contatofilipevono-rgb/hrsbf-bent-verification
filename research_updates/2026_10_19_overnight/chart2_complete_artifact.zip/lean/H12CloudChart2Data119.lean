import H12CloudChart2Data118

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29360 : List Nat := [2,4,8,0,32,64,111,256,512,320,2048,836,781,65,577,99,577,13,517,576,836,615,576,99,46,325,302,512,65,2080,768,324,257,64,1,325]

theorem envBound29360 : H12AffineFastState.Bounded env29360 := by
  intro p hp
  have h : env29360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29359_29360 : H12AffineEnvironment.transform 15 99 env29359 = env29360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env29359 == env29360) = true)

theorem identity29360 : scanCanonicalize (H12AffineFastState.compose env29360 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound29360 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29361 : List Nat := [2,4,8,0,32,64,111,9,512,73,2048,589,516,65,577,99,577,13,517,576,589,615,576,99,46,76,39,512,65,2080,521,77,8,64,1,76]

theorem envBound29361 : H12AffineFastState.Bounded env29361 := by
  intro p hp
  have h : env29361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29360_29361 : H12AffineEnvironment.transform 7 9 env29360 = env29361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env29360 == env29361) = true)

theorem identity29361 : scanCanonicalize (H12AffineFastState.compose env29361 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 589) := by decide +kernel

theorem selectedBound29361 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29362 : List Nat := [2,4,8,0,32,64,111,9,512,73,589,589,516,65,577,99,577,13,517,576,589,615,576,99,46,76,39,512,65,621,521,77,8,64,1,76]

theorem envBound29362 : H12AffineFastState.Bounded env29362 := by
  intro p hp
  have h : env29362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29361_29362 : H12AffineEnvironment.transform 10 589 env29361 = env29362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 589 env29361 == env29362) = true)

theorem identity29362 : scanCanonicalize (H12AffineFastState.compose env29362 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29362 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29363 : List Nat := [2,4,8,0,10,64,69,9,512,73,589,589,516,65,577,73,577,13,517,576,589,589,576,73,4,76,13,512,65,583,521,77,8,64,1,76]

theorem envBound29363 : H12AffineFastState.Bounded env29363 := by
  intro p hp
  have h : env29363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29362_29363 : H12AffineEnvironment.transform 4 10 env29362 = env29363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29362 == env29363) = true)

theorem identity29363 : scanCanonicalize (H12AffineFastState.compose env29363 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 76) := by decide +kernel

theorem selectedBound29363 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29364 : List Nat := [2,4,8,0,10,64,69,9,76,73,1,1,72,65,13,73,13,13,73,12,1,1,12,73,4,76,13,76,65,11,69,77,8,64,1,76]

theorem envBound29364 : H12AffineFastState.Bounded env29364 := by
  intro p hp
  have h : env29364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29363_29364 : H12AffineEnvironment.transform 8 76 env29363 = env29364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 76 env29363 == env29364) = true)

theorem identity29364 : scanCanonicalize (H12AffineFastState.compose env29364 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29365 : List Nat := [2,3,8,0,10,64,66,9,75,73,1,1,72,65,10,73,10,10,73,11,1,1,11,73,3,75,10,75,65,11,66,74,8,64,1,75]

theorem envBound29365 : H12AffineFastState.Bounded env29365 := by
  intro p hp
  have h : env29365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29364_29365 : H12AffineEnvironment.transform 1 3 env29364 = env29365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29364 == env29365) = true)

def env29366 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,65536,74031,65665,516,8524,837,648,74031,65537,9165,74282,303,74095,64,76623,8205,65831,257,64,1,324]

theorem envBound29366 : H12AffineFastState.Bounded env29366 := by
  intro p hp
  have h : env29366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29347_29366 : H12AffineEnvironment.transform 3 1 env29347 = env29366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29347 == env29366) = true)

theorem identity29366 : scanCanonicalize (H12AffineFastState.compose env29366 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound29366 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29367 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,167,64,490,65536,65928,65665,516,491,837,648,65928,65537,874,66189,303,65992,64,68584,170,65831,257,64,1,324]

theorem envBound29367 : H12AffineFastState.Bounded env29367 := by
  intro p hp
  have h : env29367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29366_29367 : H12AffineEnvironment.transform 12 167 env29366 = env29367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env29366 == env29367) = true)

def env29368 : List Nat := [2,4,8,1,32,64,128,256,428,320,2048,233,167,64,490,65536,65928,65665,424,491,233,292,65928,65537,198,65825,303,65992,64,67652,170,65831,257,64,1,324]

theorem envBound29368 : H12AffineFastState.Bounded env29368 := by
  intro p hp
  have h : env29368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29367_29368 : H12AffineEnvironment.transform 8 428 env29367 = env29368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env29367 == env29368) = true)

theorem identity29368 : scanCanonicalize (H12AffineFastState.compose env29368 (packedSelected [0,1,8,11,12,13,17,18,19,21,23,27,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 454) := by decide +kernel

theorem selectedBound29368 : packedSelected [0,1,8,11,12,13,17,18,19,21,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env29369 : List Nat := [2,4,8,1,32,64,128,256,428,320,454,233,167,64,490,65536,65928,65665,424,491,233,292,65928,65537,198,65825,303,65992,64,65922,170,65831,257,64,1,324]

theorem envBound29369 : H12AffineFastState.Bounded env29369 := by
  intro p hp
  have h : env29369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29368_29369 : H12AffineEnvironment.transform 10 454 env29368 = env29369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 454 env29368 == env29369) = true)

theorem identity29369 : scanCanonicalize (H12AffineFastState.compose env29369 (packedSelected [0,1,2,7,8,11,13,16,19,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound29369 : packedSelected [0,1,2,7,8,11,13,16,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29370 : List Nat := [2,4,8,1,32,64,128,138,38,202,76,233,167,64,96,65536,65538,65665,34,97,233,174,65538,65537,198,65707,165,65602,64,65544,170,65709,139,64,1,206]

theorem envBound29370 : H12AffineFastState.Bounded env29370 := by
  intro p hp
  have h : env29370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29369_29370 : H12AffineEnvironment.transform 7 138 env29369 = env29370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env29369 == env29370) = true)

theorem identity29370 : scanCanonicalize (H12AffineFastState.compose env29370 (packedSelected [1,3,8,10,11,12,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound29370 : packedSelected [1,3,8,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env29371 : List Nat := [2,4,8,1,32,43,128,138,38,161,39,130,167,43,11,65536,65538,65665,34,10,130,174,65538,65537,173,65707,165,65577,43,65544,170,65709,139,43,1,165]

theorem envBound29371 : H12AffineFastState.Bounded env29371 := by
  intro p hp
  have h : env29371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29370_29371 : H12AffineEnvironment.transform 5 43 env29370 = env29371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env29370 == env29371) = true)

theorem identity29371 : scanCanonicalize (H12AffineFastState.compose env29371 (packedSelected [2,5,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound29371 : packedSelected [2,5,10,11] rootPS < 2^1333 := by decide +kernel

def env29372 : List Nat := [2,4,8,1,32,43,14,4,38,47,39,12,41,43,11,65536,65538,65551,34,10,12,32,65538,65537,35,65573,43,65577,43,65544,36,65571,5,43,1,43]

theorem envBound29372 : H12AffineFastState.Bounded env29372 := by
  intro p hp
  have h : env29372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29371_29372 : H12AffineEnvironment.transform 6 14 env29371 = env29372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env29371 == env29372) = true)

theorem identity29372 : scanCanonicalize (H12AffineFastState.compose env29372 (packedSelected [2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 14) := by decide +kernel

theorem selectedBound29372 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env29373 : List Nat := [2,4,8,1,32,43,14,4,38,47,39,12,41,43,11,14,12,1,34,10,12,32,12,15,35,43,43,39,43,6,36,45,5,43,1,43]

theorem envBound29373 : H12AffineFastState.Bounded env29373 := by
  intro p hp
  have h : env29373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29372_29373 : H12AffineEnvironment.transform 15 14 env29372 = env29373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14 env29372 == env29373) = true)

theorem identity29373 : scanCanonicalize (H12AffineFastState.compose env29373 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29373 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29374 : List Nat := [2,4,8,1,0,11,14,4,6,15,7,12,9,11,11,14,12,1,2,10,12,0,12,15,3,11,11,7,11,6,4,13,5,11,1,11]

theorem envBound29374 : H12AffineFastState.Bounded env29374 := by
  intro p hp
  have h : env29374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29373_29374 : H12AffineEnvironment.transform 4 0 env29373 = env29374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29373 == env29374) = true)

def env29375 : List Nat := [2,4,8,1,32,64,128,256,429,320,2048,232,167,64,490,65536,65928,65665,425,491,232,293,65928,65537,199,65824,303,65992,64,67653,170,65831,257,64,1,324]

theorem envBound29375 : H12AffineFastState.Bounded env29375 := by
  intro p hp
  have h : env29375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29367_29375 : H12AffineEnvironment.transform 8 429 env29367 = env29375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env29367 == env29375) = true)

theorem identity29375 : scanCanonicalize (H12AffineFastState.compose env29375 (packedSelected [0,1,8,11,12,13,17,18,19,21,23,27,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 449) := by decide +kernel

theorem selectedBound29375 : packedSelected [0,1,8,11,12,13,17,18,19,21,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env29376 : List Nat := [2,4,8,1,32,64,128,256,429,320,449,232,167,64,490,65536,65928,65665,425,491,232,293,65928,65537,199,65824,303,65992,64,65924,170,65831,257,64,1,324]

theorem envBound29376 : H12AffineFastState.Bounded env29376 := by
  intro p hp
  have h : env29376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29375_29376 : H12AffineEnvironment.transform 10 449 env29375 = env29376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 449 env29375 == env29376) = true)

theorem identity29376 : scanCanonicalize (H12AffineFastState.compose env29376 (packedSelected [1,2,3,5,8,10,11,12,15,16,18,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 425) := by decide +kernel

theorem selectedBound29376 : packedSelected [1,2,3,5,8,10,11,12,15,16,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env29377 : List Nat := [2,4,8,1,32,64,128,256,429,320,449,232,167,64,490,425,33,296,425,491,232,293,33,424,199,137,303,97,64,45,170,142,257,64,1,324]

theorem envBound29377 : H12AffineFastState.Bounded env29377 := by
  intro p hp
  have h : env29377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29376_29377 : H12AffineEnvironment.transform 15 425 env29376 = env29377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 425 env29376 == env29377) = true)

theorem identity29377 : scanCanonicalize (H12AffineFastState.compose env29377 (packedSelected [4,8,9,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29377 : packedSelected [4,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env29378 : List Nat := [2,4,8,1,11,64,128,256,390,320,449,195,140,64,449,386,10,259,386,448,195,270,10,387,199,137,260,74,64,6,129,142,257,64,1,324]

theorem envBound29378 : H12AffineFastState.Bounded env29378 := by
  intro p hp
  have h : env29378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29377_29378 : H12AffineEnvironment.transform 4 11 env29377 = env29378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29377 == env29378) = true)

theorem identity29378 : scanCanonicalize (H12AffineFastState.compose env29378 (packedSelected [0,1,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29378 : packedSelected [0,1,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env29379 : List Nat := [2,4,8,1,11,64,128,69,195,5,132,195,140,64,132,199,10,70,199,133,195,75,10,198,199,137,65,74,64,6,129,142,68,64,1,1]

theorem envBound29379 : H12AffineFastState.Bounded env29379 := by
  intro p hp
  have h : env29379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29378_29379 : H12AffineEnvironment.transform 7 69 env29378 = env29379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29378 == env29379) = true)

theorem identity29379 : scanCanonicalize (H12AffineFastState.compose env29379 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound29379 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env29380 : List Nat := [2,4,8,1,11,64,68,69,7,5,64,7,72,64,64,3,10,70,3,65,7,75,10,2,3,77,65,74,64,6,69,74,68,64,1,1]

theorem envBound29380 : H12AffineFastState.Bounded env29380 := by
  intro p hp
  have h : env29380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29379_29380 : H12AffineEnvironment.transform 6 68 env29379 = env29380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env29379 == env29380) = true)

theorem identity29380 : scanCanonicalize (H12AffineFastState.compose env29380 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29380 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29381 : List Nat := [2,4,3,1,0,64,68,69,7,5,64,7,67,64,64,3,1,70,3,65,7,64,1,2,3,70,65,65,64,6,69,65,68,64,1,1]

theorem envBound29381 : H12AffineFastState.Bounded env29381 := by
  intro p hp
  have h : env29381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29380_29381 : H12AffineEnvironment.transform 2 3 env29380 = env29381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29380 == env29381) = true)

theorem identity29381 : scanCanonicalize (H12AffineFastState.compose env29381 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29381 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29382 : List Nat := [2,3,3,1,0,64,67,66,0,2,64,0,67,64,64,3,1,65,3,65,0,64,1,2,3,65,65,65,64,1,66,65,67,64,1,1]

theorem envBound29382 : H12AffineFastState.Bounded env29382 := by
  intro p hp
  have h : env29382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29381_29382 : H12AffineEnvironment.transform 1 3 env29381 = env29382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29381 == env29382) = true)

theorem identity29382 : scanCanonicalize (H12AffineFastState.compose env29382 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound29382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29383 : List Nat := [2,3,3,1,0,2,1,0,0,2,2,0,1,2,2,3,1,3,3,3,0,2,1,2,3,3,3,3,2,1,0,3,1,2,1,1]

theorem envBound29383 : H12AffineFastState.Bounded env29383 := by
  intro p hp
  have h : env29383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29382_29383 : H12AffineEnvironment.transform 5 2 env29382 = env29383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env29382 == env29383) = true)

def env29384 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,81,8540,65536,74031,65665,532,8541,853,649,74046,65552,9181,74298,318,74110,81,76639,8205,65831,257,64,1,340]

theorem envBound29384 : H12AffineFastState.Bounded env29384 := by
  intro p hp
  have h : env29384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29346_29384 : H12AffineEnvironment.transform 11 853 env29346 = env29384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env29346 == env29384) = true)

def env29385 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,65536,74031,65665,516,8525,837,649,74030,65536,9165,74282,302,74094,65,76623,8205,65831,257,64,1,324]

theorem envBound29385 : H12AffineFastState.Bounded env29385 := by
  intro p hp
  have h : env29385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29384_29385 : H12AffineEnvironment.transform 3 0 env29384 = env29385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29384 == env29385) = true)

theorem identity29385 : scanCanonicalize (H12AffineFastState.compose env29385 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8641) := by decide +kernel

theorem selectedBound29385 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29386 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,8641,238,8512,516,8525,837,649,239,8641,9165,1003,302,175,65,2702,8205,8422,257,64,1,324]

theorem envBound29386 : H12AffineFastState.Bounded env29386 := by
  intro p hp
  have h : env29386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29385_29386 : H12AffineEnvironment.transform 15 8641 env29385 = env29386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8641 env29385 == env29386) = true)

def env29387 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,780,65,576,717,238,588,516,577,837,649,239,717,193,1003,302,175,65,2702,769,1002,257,64,1,324]

theorem envBound29387 : H12AffineFastState.Bounded env29387 := by
  intro p hp
  have h : env29387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29386_29387 : H12AffineEnvironment.transform 12 780 env29386 = env29387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env29386 == env29387) = true)

theorem identity29387 : scanCanonicalize (H12AffineFastState.compose env29387 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 174) := by decide +kernel

theorem selectedBound29387 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29388 : List Nat := [2,4,8,0,32,64,128,256,174,320,2048,491,418,65,238,99,238,226,170,239,491,39,239,99,193,325,302,175,65,2080,431,324,257,64,1,324]

theorem envBound29388 : H12AffineFastState.Bounded env29388 := by
  intro p hp
  have h : env29388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29387_29388 : H12AffineEnvironment.transform 8 174 env29387 = env29388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 174 env29387 == env29388) = true)

theorem identity29388 : scanCanonicalize (H12AffineFastState.compose env29388 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 230) := by decide +kernel

theorem selectedBound29388 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29389 : List Nat := [2,4,8,0,32,64,128,230,174,166,2048,13,68,65,238,99,238,226,170,239,13,39,239,99,193,163,200,175,65,2080,73,162,231,64,1,162]

theorem envBound29389 : H12AffineFastState.Bounded env29389 := by
  intro p hp
  have h : env29389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29388_29389 : H12AffineEnvironment.transform 7 230 env29388 = env29389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 230 env29388 == env29389) = true)

theorem identity29389 : scanCanonicalize (H12AffineFastState.compose env29389 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound29389 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29390 : List Nat := [2,4,8,0,32,64,128,230,174,166,12,13,68,65,238,99,238,226,170,239,13,39,239,99,193,163,200,175,65,44,73,162,231,64,1,162]

theorem envBound29390 : H12AffineFastState.Bounded env29390 := by
  intro p hp
  have h : env29390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29389_29390 : H12AffineEnvironment.transform 10 12 env29389 = env29390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env29389 == env29390) = true)

theorem identity29390 : scanCanonicalize (H12AffineFastState.compose env29390 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound29390 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29391 : List Nat := [2,4,8,0,32,64,15,105,33,41,12,13,68,65,97,99,97,109,37,96,13,39,96,99,78,44,71,32,65,44,73,45,104,64,1,45]

theorem envBound29391 : H12AffineFastState.Bounded env29391 := by
  intro p hp
  have h : env29391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29390_29391 : H12AffineEnvironment.transform 6 15 env29390 = env29391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env29390 == env29391) = true)

theorem identity29391 : scanCanonicalize (H12AffineFastState.compose env29391 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29391 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29392 : List Nat := [2,4,3,0,32,64,4,98,33,34,7,6,68,65,97,99,97,102,37,96,6,39,96,99,69,39,71,32,65,39,66,38,99,64,1,38]

theorem envBound29392 : H12AffineFastState.Bounded env29392 := by
  intro p hp
  have h : env29392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29391_29392 : H12AffineEnvironment.transform 2 3 env29391 = env29392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29391 == env29392) = true)

def env29393 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,781,65,577,716,238,589,516,576,837,649,239,716,192,1003,302,175,65,2702,768,1003,257,64,1,324]

theorem envBound29393 : H12AffineFastState.Bounded env29393 := by
  intro p hp
  have h : env29393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29386_29393 : H12AffineEnvironment.transform 12 781 env29386 = env29393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env29386 == env29393) = true)

theorem identity29393 : scanCanonicalize (H12AffineFastState.compose env29393 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound29393 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29394 : List Nat := [2,4,8,0,32,64,128,234,512,170,2048,687,743,65,577,716,238,589,516,576,687,649,239,716,192,513,196,175,65,2702,746,513,235,64,1,174]

theorem envBound29394 : H12AffineFastState.Bounded env29394 := by
  intro p hp
  have h : env29394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29393_29394 : H12AffineEnvironment.transform 7 234 env29393 = env29394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env29393 == env29394) = true)

theorem identity29394 : scanCanonicalize (H12AffineFastState.compose env29394 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound29394 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29395 : List Nat := [2,4,8,0,32,64,46,68,512,4,2048,513,585,65,577,610,64,589,516,576,513,551,65,610,110,513,106,1,65,2592,580,513,69,64,1,0]

theorem envBound29395 : H12AffineFastState.Bounded env29395 := by
  intro p hp
  have h : env29395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29394_29395 : H12AffineEnvironment.transform 6 46 env29394 = env29395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env29394 == env29395) = true)

theorem identity29395 : scanCanonicalize (H12AffineFastState.compose env29395 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound29395 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env29396 : List Nat := [2,4,8,0,32,64,46,68,512,4,43,513,585,65,577,610,64,589,516,576,513,551,65,610,110,513,106,1,65,523,580,513,69,64,1,0]

theorem envBound29396 : H12AffineFastState.Bounded env29396 := by
  intro p hp
  have h : env29396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29395_29396 : H12AffineEnvironment.transform 10 43 env29395 = env29396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env29395 == env29396) = true)

theorem identity29396 : scanCanonicalize (H12AffineFastState.compose env29396 (packedSelected [0,3,4,5,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound29396 : packedSelected [0,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env29397 : List Nat := [2,4,8,0,32,64,46,68,77,4,43,76,4,65,12,47,64,0,73,13,76,106,65,47,110,76,106,1,65,70,9,76,69,64,1,0]

theorem envBound29397 : H12AffineFastState.Bounded env29397 := by
  intro p hp
  have h : env29397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29396_29397 : H12AffineEnvironment.transform 8 77 env29396 = env29397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env29396 == env29397) = true)

theorem identity29397 : scanCanonicalize (H12AffineFastState.compose env29397 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29397 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env29398 : List Nat := [2,4,5,0,32,64,35,68,64,4,38,65,4,65,1,34,64,0,68,0,65,103,65,34,99,65,103,1,65,70,4,65,69,64,1,0]

theorem envBound29398 : H12AffineFastState.Bounded env29398 := by
  intro p hp
  have h : env29398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29397_29398 : H12AffineEnvironment.transform 2 5 env29397 = env29398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29397 == env29398) = true)

theorem identity29398 : scanCanonicalize (H12AffineFastState.compose env29398 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29399 : List Nat := [2,3,2,0,32,64,35,67,64,3,33,65,3,65,1,34,64,0,67,0,65,96,65,34,99,65,96,1,65,65,3,65,66,64,1,0]

theorem envBound29399 : H12AffineFastState.Bounded env29399 := by
  intro p hp
  have h : env29399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29398_29399 : H12AffineEnvironment.transform 1 3 env29398 = env29399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29398 == env29399) = true)

theorem identity29399 : scanCanonicalize (H12AffineFastState.compose env29399 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29399 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29400 : List Nat := [2,3,2,0,0,64,3,67,64,3,1,65,3,65,1,2,64,0,67,0,65,64,65,2,67,65,64,1,65,65,3,65,66,64,1,0]

theorem envBound29400 : H12AffineFastState.Bounded env29400 := by
  intro p hp
  have h : env29400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29399_29400 : H12AffineEnvironment.transform 4 0 env29399 = env29400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29399 == env29400) = true)

def env29401 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,65536,74031,65665,517,8524,836,649,74031,65537,9164,74283,303,74095,64,76622,8205,65831,257,64,1,325]

theorem envBound29401 : H12AffineFastState.Bounded env29401 := by
  intro p hp
  have h : env29401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29384_29401 : H12AffineEnvironment.transform 3 1 env29384 = env29401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29384 == env29401) = true)

theorem identity29401 : scanCanonicalize (H12AffineFastState.compose env29401 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 393) := by decide +kernel

theorem selectedBound29401 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29402 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,393,8358,264,517,8524,836,649,8358,392,9164,9122,303,8422,64,10951,8205,174,257,64,1,325]

theorem envBound29402 : H12AffineFastState.Bounded env29402 := by
  intro p hp
  have h : env29402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29401_29402 : H12AffineEnvironment.transform 15 393 env29401 = env29402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env29401 == env29402) = true)

def env29403 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,780,64,577,393,938,264,517,576,836,649,938,392,192,174,303,1002,64,2507,769,174,257,64,1,325]

theorem envBound29403 : H12AffineFastState.Bounded env29403 := by
  intro p hp
  have h : env29403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29402_29403 : H12AffineEnvironment.transform 12 780 env29402 = env29403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env29402 == env29403) = true)

theorem identity29403 : scanCanonicalize (H12AffineFastState.compose env29403 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound29403 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29404 : List Nat := [2,4,8,1,32,64,128,256,175,320,2048,491,419,64,238,393,261,264,170,239,491,38,261,392,192,174,303,325,64,2507,430,174,257,64,1,325]

theorem envBound29404 : H12AffineFastState.Bounded env29404 := by
  intro p hp
  have h : env29404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29403_29404 : H12AffineEnvironment.transform 8 175 env29403 = env29404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env29403 == env29404) = true)

theorem identity29404 : scanCanonicalize (H12AffineFastState.compose env29404 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29404 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29405 : List Nat := [2,4,8,1,32,64,128,68,175,4,2048,175,231,64,238,205,65,76,170,239,175,38,65,204,192,174,107,1,64,2191,234,174,69,64,1,1]

theorem envBound29405 : H12AffineFastState.Bounded env29405 := by
  intro p hp
  have h : env29405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29404_29405 : H12AffineEnvironment.transform 7 68 env29404 = env29405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29404 == env29405) = true)

theorem identity29405 : scanCanonicalize (H12AffineFastState.compose env29405 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound29405 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env29406 : List Nat := [2,4,8,1,32,64,128,68,175,4,106,175,231,64,238,205,65,76,170,239,175,38,65,204,192,174,107,1,64,229,234,174,69,64,1,1]

theorem envBound29406 : H12AffineFastState.Bounded env29406 := by
  intro p hp
  have h : env29406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29405_29406 : H12AffineEnvironment.transform 10 106 env29405 = env29406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env29405 == env29406) = true)

def env29407 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,781,64,576,393,939,264,517,577,836,649,939,392,193,175,303,1003,64,2506,768,174,257,64,1,325]

theorem envBound29407 : H12AffineFastState.Bounded env29407 := by
  intro p hp
  have h : env29407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29402_29407 : H12AffineEnvironment.transform 12 781 env29402 = env29407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env29402 == env29407) = true)

theorem identity29407 : scanCanonicalize (H12AffineFastState.compose env29407 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound29407 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29408 : List Nat := [2,4,8,1,32,64,128,235,512,171,2048,687,742,64,576,98,576,227,517,577,687,649,576,99,193,175,196,512,64,2081,747,174,234,64,1,174]

theorem envBound29408 : H12AffineFastState.Bounded env29408 := by
  intro p hp
  have h : env29408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29407_29408 : H12AffineEnvironment.transform 7 235 env29407 = env29408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env29407 == env29408) = true)

theorem identity29408 : scanCanonicalize (H12AffineFastState.compose env29408 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29408 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29409 : List Nat := [2,4,5,1,32,64,128,230,512,166,2048,674,742,64,576,98,576,227,517,577,674,644,576,99,193,162,196,512,64,2081,742,163,231,64,1,163]

theorem envBound29409 : H12AffineFastState.Bounded env29409 := by
  intro p hp
  have h : env29409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29408_29409 : H12AffineEnvironment.transform 2 5 env29408 = env29409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29408 == env29409) = true)

theorem identity29409 : scanCanonicalize (H12AffineFastState.compose env29409 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound29409 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29410 : List Nat := [2,4,5,1,32,64,128,230,512,166,674,674,742,64,576,98,576,227,517,577,674,644,576,99,193,162,196,512,64,643,742,163,231,64,1,163]

theorem envBound29410 : H12AffineFastState.Bounded env29410 := by
  intro p hp
  have h : env29410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29409_29410 : H12AffineEnvironment.transform 10 674 env29409 = env29410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env29409 == env29410) = true)

theorem identity29410 : scanCanonicalize (H12AffineFastState.compose env29410 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound29410 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29411 : List Nat := [2,4,5,1,32,64,128,230,132,166,38,38,98,64,196,98,196,227,129,197,38,0,196,99,193,162,196,132,64,7,98,163,231,64,1,163]

theorem envBound29411 : H12AffineFastState.Bounded env29411 := by
  intro p hp
  have h : env29411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29410_29411 : H12AffineEnvironment.transform 8 132 env29410 = env29411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env29410 == env29411) = true)

theorem identity29411 : scanCanonicalize (H12AffineFastState.compose env29411 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound29411 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env29412 : List Nat := [2,4,5,1,32,64,67,37,71,101,38,38,98,64,7,98,7,32,66,6,38,0,7,99,2,97,7,71,64,7,98,96,36,64,1,96]

theorem envBound29412 : H12AffineFastState.Bounded env29412 := by
  intro p hp
  have h : env29412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29411_29412 : H12AffineEnvironment.transform 6 67 env29411 = env29412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env29411 == env29412) = true)

theorem identity29412 : scanCanonicalize (H12AffineFastState.compose env29412 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound29412 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env29413 : List Nat := [2,4,5,1,32,39,36,37,32,2,38,38,5,39,7,5,7,32,37,6,38,0,7,4,2,6,7,32,39,7,5,7,36,39,1,7]

theorem envBound29413 : H12AffineFastState.Bounded env29413 := by
  intro p hp
  have h : env29413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29412_29413 : H12AffineEnvironment.transform 5 39 env29412 = env29413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env29412 == env29413) = true)

def env29414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123165,28888,78894,385202,90415,1296,96347,25884,82999,257,1280,1345,21073]

theorem envBound29414 : H12AffineFastState.Bounded env29414 := by
  intro p hp
  have h : env29414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29200_29414 : H12AffineEnvironment.transform 18 21585 env29200 = env29414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env29200 == env29414) = true)

theorem identity29414 : scanCanonicalize (H12AffineFastState.compose env29414 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29414 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4096,17613,91183,87297,28888,78894,349358,90415,1296,96347,25884,82999,257,1280,1345,21073]

theorem envBound29415 : H12AffineFastState.Bounded env29415 := by
  intro p hp
  have h : env29415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29414_29415 : H12AffineEnvironment.transform 14 13340 env29414 = env29415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29414 == env29415) = true)

def env29416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4096,477,74047,69649,13768,78894,332222,74815,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound29416 : H12AffineFastState.Bounded env29416 := by
  intro p hp
  have h : env29416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29415_29416 : H12AffineEnvironment.transform 13 1296 env29415 = env29416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29415 == env29416) = true)

def env29417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4096,477,74047,69649,13768,78894,4414,74815,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound29417 : H12AffineFastState.Bounded env29417 := by
  intro p hp
  have h : env29417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29416_29417 : H12AffineEnvironment.transform 17 65664 env29416 = env29417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29416 == env29417) = true)

theorem identity29417 : scanCanonicalize (H12AffineFastState.compose env29417 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound29417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4096,477,70711,69649,192,65830,4414,69943,1296,67651,5380,65831,257,1280,1345,5953]

theorem envBound29418 : H12AffineFastState.Bounded env29418 := by
  intro p hp
  have h : env29418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29417_29418 : H12AffineEnvironment.transform 12 5384 env29417 = env29418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env29417 == env29418) = true)

def env29419 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4096,477,70711,69649,192,65830,4414,69943,1296,67651,5380,65831,257,1280,1345,5141]

theorem envBound29419 : H12AffineFastState.Bounded env29419 := by
  intro p hp
  have h : env29419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29418_29419 : H12AffineEnvironment.transform 8 340 env29418 = env29419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env29418 == env29419) = true)

def env29420 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,276,65536,65895,65664,321,277,0,477,66615,65553,192,65830,318,65847,1296,67651,1284,65831,257,1280,1345,1045]

theorem envBound29420 : H12AffineFastState.Bounded env29420 := by
  intro p hp
  have h : env29420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29419_29420 : H12AffineEnvironment.transform 11 0 env29419 = env29420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29419 == env29420) = true)

theorem identity29420 : scanCanonicalize (H12AffineFastState.compose env29420 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound29420 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29421 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,276,1331,1108,1459,321,277,0,477,260,1314,192,1045,318,1028,1296,3440,1284,1044,257,1280,1345,1045]

theorem envBound29421 : H12AffineFastState.Bounded env29421 := by
  intro p hp
  have h : env29421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29420_29421 : H12AffineEnvironment.transform 15 1331 env29420 = env29421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env29420 == env29421) = true)

theorem identity29421 : scanCanonicalize (H12AffineFastState.compose env29421 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1443) := by decide +kernel

theorem selectedBound29421 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env29422 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1443,0,1288,1296,276,1331,1108,1459,321,277,0,477,260,1314,192,1045,318,1028,1296,211,1284,1044,257,1280,1345,1045]

theorem envBound29422 : H12AffineFastState.Bounded env29422 := by
  intro p hp
  have h : env29422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29421_29422 : H12AffineEnvironment.transform 10 1443 env29421 = env29422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1443 env29421 == env29422) = true)

theorem identity29422 : scanCanonicalize (H12AffineFastState.compose env29422 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29422 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29423 : List Nat := [2,4,8,16,32,16,128,256,260,1024,1443,0,1288,1296,276,1331,1028,1459,273,277,0,397,260,1314,144,1045,318,1028,1296,131,1284,1044,257,1280,1297,1045]

theorem envBound29423 : H12AffineFastState.Bounded env29423 := by
  intro p hp
  have h : env29423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29422_29423 : H12AffineEnvironment.transform 5 16 env29422 = env29423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29422 == env29423) = true)

theorem identity29423 : scanCanonicalize (H12AffineFastState.compose env29423 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound29423 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29424 : List Nat := [2,4,8,16,32,16,21,256,260,1024,1334,0,1288,1296,276,1331,1028,1318,273,277,0,280,260,1314,5,1045,318,1028,1296,22,1284,1044,257,1280,1297,1045]

theorem envBound29424 : H12AffineFastState.Bounded env29424 := by
  intro p hp
  have h : env29424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29423_29424 : H12AffineEnvironment.transform 6 21 env29423 = env29424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env29423 == env29424) = true)

theorem identity29424 : scanCanonicalize (H12AffineFastState.compose env29424 (packedSelected [1,2,3,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound29424 : packedSelected [1,2,3,8,15] rootPS < 2^1333 := by decide +kernel

def env29425 : List Nat := [2,4,8,16,32,16,21,256,260,34,276,0,298,306,276,273,38,260,273,277,0,280,260,256,5,55,318,38,306,22,294,54,257,290,307,55]

theorem envBound29425 : H12AffineFastState.Bounded env29425 := by
  intro p hp
  have h : env29425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29424_29425 : H12AffineEnvironment.transform 9 34 env29424 = env29425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env29424 == env29425) = true)

theorem identity29425 : scanCanonicalize (H12AffineFastState.compose env29425 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound29425 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29426 : List Nat := [2,4,8,13,32,13,8,256,260,34,265,0,298,303,265,268,38,260,268,264,0,261,260,256,5,42,291,38,303,11,294,43,257,290,302,42]

theorem envBound29426 : H12AffineFastState.Bounded env29426 := by
  intro p hp
  have h : env29426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29425_29426 : H12AffineEnvironment.transform 3 13 env29425 = env29426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env29425 == env29426) = true)

theorem identity29426 : scanCanonicalize (H12AffineFastState.compose env29426 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound29426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29427 : List Nat := [2,4,8,13,32,13,8,35,39,34,42,0,9,12,42,47,38,39,47,43,0,38,39,35,5,42,0,38,12,11,5,43,34,1,13,42]

theorem envBound29427 : H12AffineFastState.Bounded env29427 := by
  intro p hp
  have h : env29427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29426_29427 : H12AffineEnvironment.transform 7 35 env29426 = env29427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env29426 == env29427) = true)

theorem identity29427 : scanCanonicalize (H12AffineFastState.compose env29427 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29427 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29428 : List Nat := [2,4,8,13,10,13,8,9,13,8,0,0,9,12,0,5,12,13,5,1,0,12,13,9,5,0,0,12,12,11,5,1,8,1,13,0]

theorem envBound29428 : H12AffineFastState.Bounded env29428 := by
  intro p hp
  have h : env29428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29427_29428 : H12AffineEnvironment.transform 4 10 env29427 = env29428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29427 == env29428) = true)

theorem identity29428 : scanCanonicalize (H12AffineFastState.compose env29428 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29429 : List Nat := [2,3,8,10,10,10,8,9,10,8,0,0,9,11,0,2,11,10,2,1,0,11,10,9,2,0,0,11,11,11,2,1,8,1,10,0]

theorem envBound29429 : H12AffineFastState.Bounded env29429 := by
  intro p hp
  have h : env29429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29428_29429 : H12AffineEnvironment.transform 1 3 env29428 = env29429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29428 == env29429) = true)

def env29430 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,276,65536,65894,65664,320,277,1,477,66614,65552,192,65830,319,65846,1296,67651,1285,65831,257,1280,1345,1044]

theorem envBound29430 : H12AffineFastState.Bounded env29430 := by
  intro p hp
  have h : env29430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29419_29430 : H12AffineEnvironment.transform 11 1 env29419 = env29430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29419 == env29430) = true)

theorem identity29430 : scanCanonicalize (H12AffineFastState.compose env29430 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound29430 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29431 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,276,115,277,243,320,277,1,477,1093,99,192,341,319,325,1296,2096,1285,340,257,1280,1345,1044]

theorem envBound29431 : H12AffineFastState.Bounded env29431 := by
  intro p hp
  have h : env29431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29430_29431 : H12AffineEnvironment.transform 15 115 env29430 = env29431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env29430 == env29431) = true)

theorem identity29431 : scanCanonicalize (H12AffineFastState.compose env29431 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1354) := by decide +kernel

theorem selectedBound29431 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29432 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1354,1,1289,1296,276,115,277,243,320,277,1,477,1093,99,192,341,319,325,1296,1402,1285,340,257,1280,1345,1044]

theorem envBound29432 : H12AffineFastState.Bounded env29432 := by
  intro p hp
  have h : env29432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29431_29432 : H12AffineEnvironment.transform 10 1354 env29431 = env29432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1354 env29431 == env29432) = true)

theorem identity29432 : scanCanonicalize (H12AffineFastState.compose env29432 (packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 415) := by decide +kernel

theorem selectedBound29432 : packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29433 : List Nat := [2,4,8,16,32,64,128,256,340,415,213,1,150,143,276,115,277,243,320,277,1,477,474,99,192,341,319,325,143,229,154,340,257,159,222,395]

theorem envBound29433 : H12AffineFastState.Bounded env29433 := by
  intro p hp
  have h : env29433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29432_29433 : H12AffineEnvironment.transform 9 415 env29432 = env29433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 415 env29432 == env29433) = true)

theorem identity29433 : scanCanonicalize (H12AffineFastState.compose env29433 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29433 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29434 : List Nat := [2,4,8,16,32,16,128,256,260,415,133,1,150,143,276,35,277,163,272,277,1,397,394,51,144,261,319,277,143,181,154,260,257,159,142,395]

theorem envBound29434 : H12AffineFastState.Bounded env29434 := by
  intro p hp
  have h : env29434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29433_29434 : H12AffineEnvironment.transform 5 16 env29433 = env29434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29433 == env29434) = true)

theorem identity29434 : scanCanonicalize (H12AffineFastState.compose env29434 (packedSelected [2,5,8,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound29434 : packedSelected [2,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env29435 : List Nat := [2,4,8,16,32,16,53,256,260,298,48,1,35,58,276,35,277,22,272,277,1,312,319,51,37,261,319,277,58,0,47,260,257,42,59,318]

theorem envBound29435 : H12AffineFastState.Bounded env29435 := by
  intro p hp
  have h : env29435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29434_29435 : H12AffineEnvironment.transform 6 53 env29434 = env29435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env29434 == env29435) = true)

theorem identity29435 : scanCanonicalize (H12AffineFastState.compose env29435 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29436 : List Nat := [2,4,8,16,0,16,21,256,260,266,16,1,3,26,276,3,277,22,272,277,1,280,287,19,5,261,287,277,26,0,15,260,257,10,27,286]

theorem envBound29436 : H12AffineFastState.Bounded env29436 := by
  intro p hp
  have h : env29436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29435_29436 : H12AffineEnvironment.transform 4 0 env29435 = env29436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29435 == env29436) = true)

theorem identity29436 : scanCanonicalize (H12AffineFastState.compose env29436 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29436 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env29437 : List Nat := [2,4,8,10,0,10,15,256,260,266,10,1,3,0,270,3,271,12,266,271,1,258,261,9,5,261,261,271,0,0,15,260,257,10,1,260]

theorem envBound29437 : H12AffineFastState.Bounded env29437 := by
  intro p hp
  have h : env29437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29436_29437 : H12AffineEnvironment.transform 3 10 env29436 = env29437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29436 == env29437) = true)

theorem identity29437 : scanCanonicalize (H12AffineFastState.compose env29437 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29438 : List Nat := [2,2,8,10,0,10,9,256,258,266,10,1,3,0,264,3,265,10,266,265,1,258,259,9,3,259,259,265,0,0,9,258,257,10,1,258]

theorem envBound29438 : H12AffineFastState.Bounded env29438 := by
  intro p hp
  have h : env29438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29437_29438 : H12AffineEnvironment.transform 1 2 env29437 = env29438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29437 == env29438) = true)

theorem identity29438 : scanCanonicalize (H12AffineFastState.compose env29438 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound29438 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29439 : List Nat := [2,2,8,10,0,10,9,8,10,2,10,1,3,0,0,3,1,10,2,1,1,10,11,9,3,11,11,1,0,0,9,10,9,10,1,10]

theorem envBound29439 : H12AffineFastState.Bounded env29439 := by
  intro p hp
  have h : env29439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29438_29439 : H12AffineEnvironment.transform 7 8 env29438 = env29439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env29438 == env29439) = true)

def env29440 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4096,477,70711,69649,192,65830,4414,69943,1296,67651,5380,65831,257,1280,1345,5140]

theorem envBound29440 : H12AffineFastState.Bounded env29440 := by
  intro p hp
  have h : env29440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29418_29440 : H12AffineEnvironment.transform 8 341 env29418 = env29440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env29418 == env29440) = true)

def env29441 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,276,65536,65895,65664,321,277,0,477,66615,65553,192,65830,318,65847,1296,67651,1284,65831,257,1280,1345,1044]

theorem envBound29441 : H12AffineFastState.Bounded env29441 := by
  intro p hp
  have h : env29441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29440_29441 : H12AffineEnvironment.transform 11 0 env29440 = env29441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29440 == env29441) = true)

theorem identity29441 : scanCanonicalize (H12AffineFastState.compose env29441 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound29441 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29442 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,276,1331,1108,1459,321,277,0,477,260,1314,192,1045,318,1028,1296,3440,1284,1044,257,1280,1345,1044]

theorem envBound29442 : H12AffineFastState.Bounded env29442 := by
  intro p hp
  have h : env29442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29441_29442 : H12AffineEnvironment.transform 15 1331 env29441 = env29442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env29441 == env29442) = true)

theorem identity29442 : scanCanonicalize (H12AffineFastState.compose env29442 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound29442 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env29443 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1442,0,1288,1296,276,1331,1108,1459,321,277,0,477,260,1314,192,1045,318,1028,1296,210,1284,1044,257,1280,1345,1044]

theorem envBound29443 : H12AffineFastState.Bounded env29443 := by
  intro p hp
  have h : env29443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29442_29443 : H12AffineEnvironment.transform 10 1442 env29442 = env29443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env29442 == env29443) = true)

theorem identity29443 : scanCanonicalize (H12AffineFastState.compose env29443 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29443 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29444 : List Nat := [2,4,8,16,32,16,128,256,261,1024,1442,0,1288,1296,276,1331,1028,1459,273,277,0,397,260,1314,144,1045,318,1028,1296,130,1284,1044,257,1280,1297,1044]

theorem envBound29444 : H12AffineFastState.Bounded env29444 := by
  intro p hp
  have h : env29444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29443_29444 : H12AffineEnvironment.transform 5 16 env29443 = env29444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29443 == env29444) = true)

theorem identity29444 : scanCanonicalize (H12AffineFastState.compose env29444 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound29444 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29445 : List Nat := [2,4,8,16,32,16,128,129,132,1024,1059,0,1161,1169,149,1202,1028,1074,144,148,0,12,133,1187,144,1045,191,1028,1169,130,1157,1044,128,1153,1168,1044]

theorem envBound29445 : H12AffineFastState.Bounded env29445 := by
  intro p hp
  have h : env29445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29444_29445 : H12AffineEnvironment.transform 7 129 env29444 = env29445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env29444 == env29445) = true)

theorem identity29445 : scanCanonicalize (H12AffineFastState.compose env29445 (packedSelected [1,2,3,8,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29445 : packedSelected [1,2,3,8,15] rootPS < 2^1333 := by decide +kernel

def env29446 : List Nat := [2,4,8,16,6,16,128,129,132,1024,1029,0,1161,1169,149,1172,1028,1044,144,148,0,12,133,1157,144,1045,153,1028,1169,130,1157,1044,128,1153,1168,1044]

theorem envBound29446 : H12AffineFastState.Bounded env29446 := by
  intro p hp
  have h : env29446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29445_29446 : H12AffineEnvironment.transform 4 6 env29445 = env29446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29445 == env29446) = true)

theorem identity29446 : scanCanonicalize (H12AffineFastState.compose env29446 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 24) := by decide +kernel

theorem selectedBound29446 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29447 : List Nat := [2,4,8,16,6,16,128,129,132,24,29,0,145,137,149,140,28,12,144,148,0,12,133,157,144,13,153,28,137,130,157,12,128,153,136,12]

theorem envBound29447 : H12AffineFastState.Bounded env29447 := by
  intro p hp
  have h : env29447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29446_29447 : H12AffineEnvironment.transform 9 24 env29446 = env29447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env29446 == env29447) = true)

theorem identity29447 : scanCanonicalize (H12AffineFastState.compose env29447 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29448 : List Nat := [2,4,8,1,6,1,128,129,132,9,12,0,128,137,132,140,13,12,129,133,0,12,133,140,129,13,136,13,137,130,140,12,128,136,136,12]

theorem envBound29448 : H12AffineFastState.Bounded env29448 := by
  intro p hp
  have h : env29448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29447_29448 : H12AffineEnvironment.transform 3 1 env29447 = env29448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29447 == env29448) = true)

theorem identity29448 : scanCanonicalize (H12AffineFastState.compose env29448 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29448 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29449 : List Nat := [2,4,4,1,6,1,128,129,132,5,0,0,128,133,132,128,1,0,129,133,0,0,133,128,129,1,132,1,133,130,128,0,128,132,132,0]

theorem envBound29449 : H12AffineFastState.Bounded env29449 := by
  intro p hp
  have h : env29449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29448_29449 : H12AffineEnvironment.transform 2 4 env29448 = env29449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29448 == env29449) = true)

theorem identity29449 : scanCanonicalize (H12AffineFastState.compose env29449 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29449 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29450 : List Nat := [2,4,4,1,6,1,2,3,6,5,0,0,2,7,6,2,1,0,3,7,0,0,7,2,3,1,6,1,7,0,2,0,2,6,6,0]

theorem envBound29450 : H12AffineFastState.Bounded env29450 := by
  intro p hp
  have h : env29450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29449_29450 : H12AffineEnvironment.transform 6 2 env29449 = env29450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29449 == env29450) = true)

def env29451 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,276,65536,65894,65664,320,277,1,477,66614,65552,192,65830,319,65846,1296,67651,1285,65831,257,1280,1345,1045]

theorem envBound29451 : H12AffineFastState.Bounded env29451 := by
  intro p hp
  have h : env29451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29440_29451 : H12AffineEnvironment.transform 11 1 env29440 = env29451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29440 == env29451) = true)

theorem identity29451 : scanCanonicalize (H12AffineFastState.compose env29451 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound29451 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29452 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,276,115,277,243,320,277,1,477,1093,99,192,341,319,325,1296,2096,1285,340,257,1280,1345,1045]

theorem envBound29452 : H12AffineFastState.Bounded env29452 := by
  intro p hp
  have h : env29452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29451_29452 : H12AffineEnvironment.transform 15 115 env29451 = env29452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env29451 == env29452) = true)

theorem identity29452 : scanCanonicalize (H12AffineFastState.compose env29452 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1355) := by decide +kernel

theorem selectedBound29452 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29453 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1355,1,1289,1296,276,115,277,243,320,277,1,477,1093,99,192,341,319,325,1296,1403,1285,340,257,1280,1345,1045]

theorem envBound29453 : H12AffineFastState.Bounded env29453 := by
  intro p hp
  have h : env29453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29452_29453 : H12AffineEnvironment.transform 10 1355 env29452 = env29453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1355 env29452 == env29453) = true)

theorem identity29453 : scanCanonicalize (H12AffineFastState.compose env29453 (packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 203) := by decide +kernel

theorem selectedBound29453 : packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29454 : List Nat := [2,4,8,16,32,64,128,203,158,1024,1152,1,1218,1243,223,115,222,243,139,222,1,22,1093,99,192,158,244,142,1243,1200,1230,159,202,1227,1162,1045]

theorem envBound29454 : H12AffineFastState.Bounded env29454 := by
  intro p hp
  have h : env29454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29453_29454 : H12AffineEnvironment.transform 7 203 env29453 = env29454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 203 env29453 == env29454) = true)

theorem identity29454 : scanCanonicalize (H12AffineFastState.compose env29454 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29454 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29455 : List Nat := [2,4,8,16,32,16,128,155,158,1024,1152,1,1170,1163,143,35,142,163,139,142,1,22,1045,51,144,158,164,142,1163,1200,1182,159,154,1179,1162,1045]

theorem envBound29455 : H12AffineFastState.Bounded env29455 := by
  intro p hp
  have h : env29455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29454_29455 : H12AffineEnvironment.transform 5 16 env29454 = env29455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29454 == env29455) = true)

theorem identity29455 : scanCanonicalize (H12AffineFastState.compose env29455 (packedSelected [2,5,8,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound29455 : packedSelected [2,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env29456 : List Nat := [2,4,8,16,27,16,128,155,158,1024,1152,1,1170,1163,143,24,142,152,139,142,1,22,1045,8,144,158,159,142,1163,1163,1182,159,154,1179,1162,1045]

theorem envBound29456 : H12AffineFastState.Bounded env29456 := by
  intro p hp
  have h : env29456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29455_29456 : H12AffineEnvironment.transform 4 27 env29455 = env29456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env29455 == env29456) = true)

theorem identity29456 : scanCanonicalize (H12AffineFastState.compose env29456 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29457 : List Nat := [2,4,8,10,1,10,128,129,132,1024,1152,1,1160,1163,143,2,142,130,139,142,1,12,1039,8,138,132,133,142,1163,1163,1156,133,128,1153,1162,1039]

theorem envBound29457 : H12AffineFastState.Bounded env29457 := by
  intro p hp
  have h : env29457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29456_29457 : H12AffineEnvironment.transform 3 10 env29456 = env29457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29456 == env29457) = true)

theorem identity29457 : scanCanonicalize (H12AffineFastState.compose env29457 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29457 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env29458 : List Nat := [2,4,8,10,1,10,9,8,13,1024,1033,1,1025,1026,6,2,7,11,2,7,1,12,1039,8,3,13,12,7,1026,1026,1037,12,9,1032,1027,1039]

theorem envBound29458 : H12AffineFastState.Bounded env29458 := by
  intro p hp
  have h : env29458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29457_29458 : H12AffineEnvironment.transform 6 9 env29457 = env29458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29457 == env29458) = true)

theorem identity29458 : scanCanonicalize (H12AffineFastState.compose env29458 (packedSelected [4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound29458 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env29459 : List Nat := [2,4,8,10,1,10,9,8,13,4,13,1,5,6,6,2,7,11,2,7,1,12,11,8,3,13,12,7,6,6,9,12,9,12,7,11]

theorem envBound29459 : H12AffineFastState.Bounded env29459 := by
  intro p hp
  have h : env29459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29458_29459 : H12AffineEnvironment.transform 9 4 env29458 = env29459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env29458 == env29459) = true)

theorem identity29459 : scanCanonicalize (H12AffineFastState.compose env29459 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29459 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29460 : List Nat := [2,2,8,10,1,10,9,8,11,2,11,1,3,0,0,2,1,11,2,1,1,10,11,8,3,11,10,1,0,0,9,10,9,10,1,11]

theorem envBound29460 : H12AffineFastState.Bounded env29460 := by
  intro p hp
  have h : env29460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29459_29460 : H12AffineEnvironment.transform 1 2 env29459 = env29460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29459 == env29460) = true)

def env29461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4096,477,74047,69649,13768,78894,4415,74815,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound29461 : H12AffineFastState.Bounded env29461 := by
  intro p hp
  have h : env29461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29416_29461 : H12AffineEnvironment.transform 17 65665 env29416 = env29461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29416 == env29461) = true)

theorem identity29461 : scanCanonicalize (H12AffineFastState.compose env29461 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound29461 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4096,477,65911,69649,5504,70758,4415,66679,1296,72963,68,65831,257,1280,1345,5953]

theorem envBound29462 : H12AffineFastState.Bounded env29462 := by
  intro p hp
  have h : env29462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29461_29462 : H12AffineEnvironment.transform 12 72 env29461 = env29462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29461 == env29462) = true)

def env29463 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4096,477,65911,69649,5504,70758,4415,66679,1296,72963,68,65831,257,1280,1345,5141]

theorem envBound29463 : H12AffineFastState.Bounded env29463 := by
  intro p hp
  have h : env29463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29462_29463 : H12AffineEnvironment.transform 8 340 env29462 = env29463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env29462 == env29463) = true)

def env29464 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4372,65536,65895,65665,4417,4373,4096,477,65911,69649,4288,69926,4415,65847,80,71747,68,65831,257,64,1,4437]

theorem envBound29464 : H12AffineFastState.Bounded env29464 := by
  intro p hp
  have h : env29464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29463_29464 : H12AffineEnvironment.transform 9 320 env29463 = env29464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29463 == env29464) = true)

theorem identity29464 : scanCanonicalize (H12AffineFastState.compose env29464 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound29464 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29465 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4372,4211,4372,4338,4417,4373,4096,477,4356,98,4288,341,4415,4420,80,2096,68,4436,257,64,1,4437]

theorem envBound29465 : H12AffineFastState.Bounded env29465 := by
  intro p hp
  have h : env29465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29464_29465 : H12AffineEnvironment.transform 15 4211 env29464 = env29465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env29464 == env29465) = true)

theorem identity29465 : scanCanonicalize (H12AffineFastState.compose env29465 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29465 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29466 : List Nat := [2,4,8,16,32,16,128,256,260,272,2048,4096,24,0,4372,4131,4372,4258,4369,4373,4096,397,4356,50,4240,261,4415,4372,0,2096,20,4356,257,16,1,4357]

theorem envBound29466 : H12AffineFastState.Bounded env29466 := by
  intro p hp
  have h : env29466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29465_29466 : H12AffineEnvironment.transform 5 16 env29465 = env29466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29465 == env29466) = true)

theorem identity29466 : scanCanonicalize (H12AffineFastState.compose env29466 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound29466 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env29467 : List Nat := [2,4,8,16,32,16,128,256,260,272,2048,17,24,0,261,50,261,179,256,260,17,397,277,50,129,261,302,261,0,2096,20,277,257,16,1,276]

theorem envBound29467 : H12AffineFastState.Bounded env29467 := by
  intro p hp
  have h : env29467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29466_29467 : H12AffineEnvironment.transform 11 17 env29466 = env29467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29466 == env29467) = true)

theorem identity29467 : scanCanonicalize (H12AffineFastState.compose env29467 (packedSelected [1,3,8,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound29467 : packedSelected [1,3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29468 : List Nat := [2,4,8,16,32,16,128,256,260,272,174,17,24,0,261,50,261,179,256,260,17,397,277,50,129,261,302,261,0,158,20,277,257,16,1,276]

theorem envBound29468 : H12AffineFastState.Bounded env29468 := by
  intro p hp
  have h : env29468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29467_29468 : H12AffineEnvironment.transform 10 174 env29467 = env29468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env29467 == env29468) = true)

theorem identity29468 : scanCanonicalize (H12AffineFastState.compose env29468 (packedSelected [0,1,2,5,7,11,12,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29468 : packedSelected [0,1,2,5,7,11,12,17] rootPS < 2^1333 := by decide +kernel

def env29469 : List Nat := [2,2,8,16,32,16,128,256,258,272,168,17,24,0,259,50,259,179,256,258,17,395,275,50,129,259,296,259,0,152,18,275,257,16,1,274]

theorem envBound29469 : H12AffineFastState.Bounded env29469 := by
  intro p hp
  have h : env29469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29468_29469 : H12AffineEnvironment.transform 1 2 env29468 = env29469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29468 == env29469) = true)

theorem identity29469 : scanCanonicalize (H12AffineFastState.compose env29469 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound29469 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env29470 : List Nat := [2,2,8,16,32,16,40,256,258,272,0,17,24,0,259,50,259,27,256,258,17,291,275,50,41,259,296,259,0,48,18,275,257,16,1,274]

theorem envBound29470 : H12AffineFastState.Bounded env29470 := by
  intro p hp
  have h : env29470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29469_29470 : H12AffineEnvironment.transform 6 40 env29469 = env29470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env29469 == env29470) = true)

theorem identity29470 : scanCanonicalize (H12AffineFastState.compose env29470 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound29470 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env29471 : List Nat := [2,2,8,16,32,16,40,35,33,51,0,17,24,0,32,50,32,27,35,33,17,0,48,50,41,32,11,32,0,48,18,48,34,16,1,49]

theorem envBound29471 : H12AffineFastState.Bounded env29471 := by
  intro p hp
  have h : env29471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29470_29471 : H12AffineEnvironment.transform 7 35 env29470 = env29471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env29470 == env29471) = true)

theorem identity29471 : scanCanonicalize (H12AffineFastState.compose env29471 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29472 : List Nat := [2,2,8,16,0,16,8,3,1,19,0,17,24,0,0,18,0,27,3,1,17,0,16,18,9,0,11,0,0,16,18,16,2,16,1,17]

theorem envBound29472 : H12AffineFastState.Bounded env29472 := by
  intro p hp
  have h : env29472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29471_29472 : H12AffineEnvironment.transform 4 0 env29471 = env29472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29471 == env29472) = true)

theorem identity29472 : scanCanonicalize (H12AffineFastState.compose env29472 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29472 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29473 : List Nat := [2,2,3,16,0,16,3,3,1,19,0,17,19,0,0,18,0,16,3,1,17,0,16,18,2,0,0,0,0,16,18,16,2,16,1,17]

theorem envBound29473 : H12AffineFastState.Bounded env29473 := by
  intro p hp
  have h : env29473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29472_29473 : H12AffineEnvironment.transform 2 3 env29472 = env29473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29472 == env29473) = true)

theorem identity29473 : scanCanonicalize (H12AffineFastState.compose env29473 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29473 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29474 : List Nat := [2,2,3,0,0,0,3,3,1,3,0,1,3,0,0,2,0,0,3,1,1,0,0,2,2,0,0,0,0,0,2,0,2,0,1,1]

theorem envBound29474 : H12AffineFastState.Bounded env29474 := by
  intro p hp
  have h : env29474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29473_29474 : H12AffineEnvironment.transform 3 0 env29473 = env29474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29473 == env29474) = true)

def env29475 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4373,65536,65894,65665,4417,4372,4096,477,65911,69649,4289,69927,4415,65846,81,71746,68,65831,257,65,0,4436]

theorem envBound29475 : H12AffineFastState.Bounded env29475 := by
  intro p hp
  have h : env29475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29463_29475 : H12AffineEnvironment.transform 9 321 env29463 = env29475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29463 == env29475) = true)

theorem identity29475 : scanCanonicalize (H12AffineFastState.compose env29475 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound29475 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29476 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4373,115,277,242,4417,4372,4096,477,260,4194,4289,4436,4415,325,81,6193,68,340,257,65,0,4436]

theorem envBound29476 : H12AffineFastState.Bounded env29476 := by
  intro p hp
  have h : env29476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29475_29476 : H12AffineEnvironment.transform 15 115 env29475 = env29476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env29475 == env29476) = true)

theorem identity29476 : scanCanonicalize (H12AffineFastState.compose env29476 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 335) := by decide +kernel

theorem selectedBound29476 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env29477 : List Nat := [2,4,8,16,32,64,128,256,340,321,335,4096,72,81,4373,115,277,242,4417,4372,4096,477,260,4194,4289,4436,4415,325,81,4478,68,340,257,65,0,4436]

theorem envBound29477 : H12AffineFastState.Bounded env29477 := by
  intro p hp
  have h : env29477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29476_29477 : H12AffineEnvironment.transform 10 335 env29476 = env29477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 335 env29476 == env29477) = true)

theorem identity29477 : scanCanonicalize (H12AffineFastState.compose env29477 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound29477 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29478 : List Nat := [2,4,8,16,32,64,95,256,340,321,335,4096,72,81,4373,115,277,45,4417,4372,4096,258,260,4194,4126,4436,4415,325,81,4478,68,340,257,65,0,4436]

theorem envBound29478 : H12AffineFastState.Bounded env29478 := by
  intro p hp
  have h : env29478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29477_29478 : H12AffineEnvironment.transform 6 95 env29477 = env29478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env29477 == env29478) = true)

theorem identity29478 : scanCanonicalize (H12AffineFastState.compose env29478 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29478 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29479 : List Nat := [2,4,8,16,32,16,15,256,260,273,287,4096,24,1,4373,35,277,45,4369,4372,4096,258,260,4146,4126,4356,4415,277,1,4398,20,260,257,17,0,4356]

theorem envBound29479 : H12AffineFastState.Bounded env29479 := by
  intro p hp
  have h : env29479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29478_29479 : H12AffineEnvironment.transform 5 16 env29478 = env29479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29478 == env29479) = true)

theorem identity29479 : scanCanonicalize (H12AffineFastState.compose env29479 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound29479 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29480 : List Nat := [2,4,8,16,32,16,15,47,43,62,48,4096,24,1,4154,35,58,45,4158,4155,4096,45,43,4146,4126,4139,4112,58,1,4097,20,43,46,17,0,4139]

theorem envBound29480 : H12AffineFastState.Bounded env29480 := by
  intro p hp
  have h : env29480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29479_29480 : H12AffineEnvironment.transform 7 47 env29479 = env29480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env29479 == env29480) = true)

theorem identity29480 : scanCanonicalize (H12AffineFastState.compose env29480 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29481 : List Nat := [2,4,8,16,0,16,15,15,11,30,16,4096,24,1,4122,3,26,13,4126,4123,4096,13,11,4114,4126,4107,4112,26,1,4097,20,11,14,17,0,4107]

theorem envBound29481 : H12AffineFastState.Bounded env29481 := by
  intro p hp
  have h : env29481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29480_29481 : H12AffineEnvironment.transform 4 0 env29480 = env29481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29480 == env29481) = true)

theorem identity29481 : scanCanonicalize (H12AffineFastState.compose env29481 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29481 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29482 : List Nat := [2,4,2,16,0,16,5,5,1,20,16,4096,18,1,4112,3,16,7,4116,4113,4096,7,1,4114,4116,4097,4112,16,1,4097,20,1,4,17,0,4097]

theorem envBound29482 : H12AffineFastState.Bounded env29482 := by
  intro p hp
  have h : env29482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29481_29482 : H12AffineEnvironment.transform 2 2 env29481 = env29482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29481 == env29482) = true)

theorem identity29482 : scanCanonicalize (H12AffineFastState.compose env29482 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound29482 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29483 : List Nat := [2,4,2,16,0,16,5,5,1,20,16,17,18,1,1,3,16,7,5,0,17,7,1,3,5,16,1,16,1,16,20,1,4,17,0,16]

theorem envBound29483 : H12AffineFastState.Bounded env29483 := by
  intro p hp
  have h : env29483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29482_29483 : H12AffineEnvironment.transform 11 17 env29482 = env29483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29482 == env29483) = true)

theorem identity29483 : scanCanonicalize (H12AffineFastState.compose env29483 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29483 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29484 : List Nat := [2,4,2,0,0,0,5,5,1,4,0,1,2,1,1,3,0,7,5,0,1,7,1,3,5,0,1,0,1,0,4,1,4,1,0,0]

theorem envBound29484 : H12AffineFastState.Bounded env29484 := by
  intro p hp
  have h : env29484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29483_29484 : H12AffineEnvironment.transform 3 0 env29483 = env29484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29483 == env29484) = true)

theorem identity29484 : scanCanonicalize (H12AffineFastState.compose env29484 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29484 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29485 : List Nat := [2,0,2,0,0,0,1,1,1,0,0,1,2,1,1,3,0,3,1,0,1,3,1,3,1,0,1,0,1,0,0,1,0,1,0,0]

theorem envBound29485 : H12AffineFastState.Bounded env29485 := by
  intro p hp
  have h : env29485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29484_29485 : H12AffineEnvironment.transform 1 0 env29484 = env29485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29484 == env29485) = true)

def env29486 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4096,477,65911,69649,5504,70758,4415,66679,1296,72963,68,65831,257,1280,1345,5140]

theorem envBound29486 : H12AffineFastState.Bounded env29486 := by
  intro p hp
  have h : env29486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29462_29486 : H12AffineEnvironment.transform 8 341 env29462 = env29486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env29462 == env29486) = true)

def env29487 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4372,65536,65895,65665,4417,4373,4096,477,65911,69649,4288,69926,4415,65847,80,71747,68,65831,257,64,1,4436]

theorem envBound29487 : H12AffineFastState.Bounded env29487 := by
  intro p hp
  have h : env29487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29486_29487 : H12AffineEnvironment.transform 9 320 env29486 = env29487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29486 == env29487) = true)

theorem identity29487 : scanCanonicalize (H12AffineFastState.compose env29487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound29487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29488 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4372,4211,4372,4338,4417,4373,4096,477,4356,98,4288,341,4415,4420,80,2096,68,4436,257,64,1,4436]

theorem envBound29488 : H12AffineFastState.Bounded env29488 := by
  intro p hp
  have h : env29488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29487_29488 : H12AffineEnvironment.transform 15 4211 env29487 = env29488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env29487 == env29488) = true)

theorem identity29488 : scanCanonicalize (H12AffineFastState.compose env29488 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29488 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29489 : List Nat := [2,4,8,16,32,16,128,256,261,272,2048,4096,24,0,4372,4131,4372,4258,4369,4373,4096,397,4356,50,4240,261,4415,4372,0,2096,20,4356,257,16,1,4356]

theorem envBound29489 : H12AffineFastState.Bounded env29489 := by
  intro p hp
  have h : env29489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29488_29489 : H12AffineEnvironment.transform 5 16 env29488 = env29489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29488 == env29489) = true)

theorem identity29489 : scanCanonicalize (H12AffineFastState.compose env29489 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29489 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env29490 : List Nat := [2,4,8,1,32,1,128,256,261,257,2048,4096,9,0,4357,4131,4357,4258,4352,4356,4096,397,4356,35,4225,261,4398,4357,0,2081,5,4356,257,1,1,4356]

theorem envBound29490 : H12AffineFastState.Bounded env29490 := by
  intro p hp
  have h : env29490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29489_29490 : H12AffineEnvironment.transform 3 1 env29489 = env29490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29489 == env29490) = true)

theorem identity29490 : scanCanonicalize (H12AffineFastState.compose env29490 (packedSelected [0,1,5,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 427) := by decide +kernel

theorem selectedBound29490 : packedSelected [0,1,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29491 : List Nat := [2,4,8,1,32,1,128,256,261,257,427,4096,9,0,4357,4131,4357,4258,4352,4356,4096,397,4356,35,4225,261,4398,4357,0,394,5,4356,257,1,1,4356]

theorem envBound29491 : H12AffineFastState.Bounded env29491 := by
  intro p hp
  have h : env29491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29490_29491 : H12AffineEnvironment.transform 10 427 env29490 = env29491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 427 env29490 == env29491) = true)

theorem identity29491 : scanCanonicalize (H12AffineFastState.compose env29491 (packedSelected [1,2,3,10,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound29491 : packedSelected [1,2,3,10,12,17] rootPS < 2^1333 := by decide +kernel

def env29492 : List Nat := [2,4,8,1,32,1,128,2,7,3,169,4096,9,0,4103,4131,4103,4258,4098,4102,4096,143,4102,35,4225,7,4140,4103,0,136,5,4102,3,1,1,4102]

theorem envBound29492 : H12AffineFastState.Bounded env29492 := by
  intro p hp
  have h : env29492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29491_29492 : H12AffineEnvironment.transform 7 2 env29491 = env29492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env29491 == env29492) = true)

theorem identity29492 : scanCanonicalize (H12AffineFastState.compose env29492 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 168) := by decide +kernel

theorem selectedBound29492 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env29493 : List Nat := [2,4,8,1,32,1,128,2,7,3,169,168,9,0,175,139,175,10,170,174,168,143,174,35,41,7,132,175,0,136,5,174,3,1,1,174]

theorem envBound29493 : H12AffineFastState.Bounded env29493 := by
  intro p hp
  have h : env29493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29492_29493 : H12AffineEnvironment.transform 11 168 env29492 = env29493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 168 env29492 == env29493) = true)

theorem identity29493 : scanCanonicalize (H12AffineFastState.compose env29493 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29493 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env29494 : List Nat := [2,4,8,1,7,1,128,2,7,3,142,143,9,0,136,139,136,10,141,137,143,143,137,4,14,7,132,136,0,136,5,137,3,1,1,137]

theorem envBound29494 : H12AffineFastState.Bounded env29494 := by
  intro p hp
  have h : env29494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29493_29494 : H12AffineEnvironment.transform 4 7 env29493 = env29494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29493 == env29494) = true)

theorem identity29494 : scanCanonicalize (H12AffineFastState.compose env29494 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29495 : List Nat := [2,2,8,1,1,1,128,2,1,3,136,137,9,0,136,139,136,10,139,137,137,137,137,2,8,1,130,136,0,136,3,137,3,1,1,137]

theorem envBound29495 : H12AffineFastState.Bounded env29495 := by
  intro p hp
  have h : env29495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29494_29495 : H12AffineEnvironment.transform 1 2 env29494 = env29495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29494 == env29495) = true)

theorem identity29495 : scanCanonicalize (H12AffineFastState.compose env29495 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29495 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29496 : List Nat := [2,2,8,1,1,1,2,2,1,3,10,11,9,0,10,9,10,10,9,11,11,11,11,2,8,1,0,10,0,10,3,11,3,1,1,11]

theorem envBound29496 : H12AffineFastState.Bounded env29496 := by
  intro p hp
  have h : env29496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29495_29496 : H12AffineEnvironment.transform 6 2 env29495 = env29496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29495 == env29496) = true)

theorem identity29496 : scanCanonicalize (H12AffineFastState.compose env29496 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29497 : List Nat := [2,2,2,1,1,1,2,2,1,3,0,1,3,0,0,3,0,0,3,1,1,1,1,2,2,1,0,0,0,0,3,1,3,1,1,1]

theorem envBound29497 : H12AffineFastState.Bounded env29497 := by
  intro p hp
  have h : env29497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29496_29497 : H12AffineEnvironment.transform 2 2 env29496 = env29497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29496 == env29497) = true)

def env29498 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4373,65536,65894,65665,4417,4372,4096,477,65911,69649,4289,69927,4415,65846,81,71746,68,65831,257,65,0,4437]

theorem envBound29498 : H12AffineFastState.Bounded env29498 := by
  intro p hp
  have h : env29498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29486_29498 : H12AffineEnvironment.transform 9 321 env29486 = env29498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29486 == env29498) = true)

theorem identity29498 : scanCanonicalize (H12AffineFastState.compose env29498 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound29498 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29499 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4373,115,277,242,4417,4372,4096,477,260,4194,4289,4436,4415,325,81,6193,68,340,257,65,0,4437]

theorem envBound29499 : H12AffineFastState.Bounded env29499 := by
  intro p hp
  have h : env29499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29498_29499 : H12AffineEnvironment.transform 15 115 env29498 = env29499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env29498 == env29499) = true)

theorem identity29499 : scanCanonicalize (H12AffineFastState.compose env29499 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 334) := by decide +kernel

theorem selectedBound29499 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env29500 : List Nat := [2,4,8,16,32,64,128,256,341,321,334,4096,72,81,4373,115,277,242,4417,4372,4096,477,260,4194,4289,4436,4415,325,81,4479,68,340,257,65,0,4437]

theorem envBound29500 : H12AffineFastState.Bounded env29500 := by
  intro p hp
  have h : env29500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29499_29500 : H12AffineEnvironment.transform 10 334 env29499 = env29500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 334 env29499 == env29500) = true)

theorem identity29500 : scanCanonicalize (H12AffineFastState.compose env29500 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 202) := by decide +kernel

theorem selectedBound29500 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29501 : List Nat := [2,4,8,16,32,64,128,202,159,139,132,4096,72,81,4319,115,223,242,4235,4318,4096,23,206,4194,4289,4254,4341,143,81,4277,68,158,203,65,0,4255]

theorem envBound29501 : H12AffineFastState.Bounded env29501 := by
  intro p hp
  have h : env29501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29500_29501 : H12AffineEnvironment.transform 7 202 env29500 = env29501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 202 env29500 == env29501) = true)

theorem identity29501 : scanCanonicalize (H12AffineFastState.compose env29501 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29501 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29502 : List Nat := [2,4,8,16,32,16,128,154,159,139,132,4096,24,1,4239,35,143,162,4235,4238,4096,23,158,4146,4241,4254,4261,143,1,4277,20,158,155,17,0,4255]

theorem envBound29502 : H12AffineFastState.Bounded env29502 := by
  intro p hp
  have h : env29502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29501_29502 : H12AffineEnvironment.transform 5 16 env29501 = env29502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29501 == env29502) = true)

theorem identity29502 : scanCanonicalize (H12AffineFastState.compose env29502 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound29502 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29503 : List Nat := [2,4,8,16,32,16,52,46,43,63,48,4096,24,1,4155,35,59,22,4159,4154,4096,23,42,4146,4133,4138,4113,59,1,4097,20,42,47,17,0,4139]

theorem envBound29503 : H12AffineFastState.Bounded env29503 := by
  intro p hp
  have h : env29503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29502_29503 : H12AffineEnvironment.transform 6 52 env29502 = env29503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env29502 == env29503) = true)

theorem identity29503 : scanCanonicalize (H12AffineFastState.compose env29503 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29504 : List Nat := [2,4,8,16,1,16,21,15,10,30,17,4096,24,1,4122,2,26,22,4126,4123,4096,23,11,4115,4100,4107,4113,26,1,4097,20,11,14,17,0,4106]

theorem envBound29504 : H12AffineFastState.Bounded env29504 := by
  intro p hp
  have h : env29504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29503_29504 : H12AffineEnvironment.transform 4 1 env29503 = env29504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29503 == env29504) = true)

theorem identity29504 : scanCanonicalize (H12AffineFastState.compose env29504 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound29504 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29505 : List Nat := [2,4,8,16,1,16,21,15,10,30,17,11,24,1,17,2,26,22,21,16,11,23,11,24,15,0,26,26,1,10,20,11,14,17,0,1]

theorem envBound29505 : H12AffineFastState.Bounded env29505 := by
  intro p hp
  have h : env29505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29504_29505 : H12AffineEnvironment.transform 11 11 env29504 = env29505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env29504 == env29505) = true)

theorem identity29505 : scanCanonicalize (H12AffineFastState.compose env29505 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29505 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29506 : List Nat := [2,4,8,11,1,11,14,15,10,5,10,11,3,1,10,2,1,13,14,11,11,12,11,3,15,0,1,1,1,10,15,11,14,10,0,1]

theorem envBound29506 : H12AffineFastState.Bounded env29506 := by
  intro p hp
  have h : env29506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29505_29506 : H12AffineEnvironment.transform 3 11 env29505 = env29506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29505 == env29506) = true)

theorem identity29506 : scanCanonicalize (H12AffineFastState.compose env29506 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29507 : List Nat := [2,4,3,0,1,0,5,4,1,5,1,0,3,1,1,2,1,6,5,0,0,7,0,3,4,0,1,1,1,1,4,0,5,1,0,1]

theorem envBound29507 : H12AffineFastState.Bounded env29507 := by
  intro p hp
  have h : env29507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29506_29507 : H12AffineEnvironment.transform 2 3 env29506 = env29507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29506 == env29507) = true)

theorem identity29507 : scanCanonicalize (H12AffineFastState.compose env29507 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29507 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29508 : List Nat := [2,2,3,0,1,0,3,2,1,3,1,0,3,1,1,2,1,0,3,0,0,1,0,3,2,0,1,1,1,1,2,0,3,1,0,1]

theorem envBound29508 : H12AffineFastState.Bounded env29508 := by
  intro p hp
  have h : env29508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29507_29508 : H12AffineEnvironment.transform 1 2 env29507 = env29508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29507 == env29508) = true)

def env29509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4096,476,74046,69648,13769,78894,332223,74814,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound29509 : H12AffineFastState.Bounded env29509 := by
  intro p hp
  have h : env29509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29415_29509 : H12AffineEnvironment.transform 13 1297 env29415 = env29509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29415 == env29509) = true)

def env29510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4096,476,74046,69648,13769,78894,4415,74814,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound29510 : H12AffineFastState.Bounded env29510 := by
  intro p hp
  have h : env29510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29509_29510 : H12AffineEnvironment.transform 17 65664 env29509 = env29510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29509 == env29510) = true)

theorem identity29510 : scanCanonicalize (H12AffineFastState.compose env29510 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound29510 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29511 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4096,476,74046,69648,12424,78191,4415,74111,81,79883,8205,65830,257,65,0,4609]

theorem envBound29511 : H12AffineFastState.Bounded env29511 := by
  intro p hp
  have h : env29511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29510_29511 : H12AffineEnvironment.transform 9 321 env29510 = env29511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29510 == env29511) = true)

def env29512 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4096,476,74046,69648,12424,78191,4415,74111,81,79883,8205,65830,257,65,0,4437]

theorem envBound29512 : H12AffineFastState.Bounded env29512 := by
  intro p hp
  have h : env29512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29511_29512 : H12AffineEnvironment.transform 8 340 env29511 = env29512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env29511 == env29512) = true)

def env29513 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,80,8525,65536,74030,65664,336,8524,16,476,74046,65536,8344,74111,303,74111,81,75803,8205,65830,257,65,0,325]

theorem envBound29513 : H12AffineFastState.Bounded env29513 := by
  intro p hp
  have h : env29513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29512_29513 : H12AffineEnvironment.transform 11 16 env29512 = env29513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env29512 == env29513) = true)

theorem identity29513 : scanCanonicalize (H12AffineFastState.compose env29513 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 314) := by decide +kernel

theorem selectedBound29513 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29514 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,314,80,119,65536,65556,65664,336,118,16,476,65540,65536,418,65605,303,65605,81,67873,311,65830,257,65,0,325]

theorem envBound29514 : H12AffineFastState.Bounded env29514 := by
  intro p hp
  have h : env29514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29513_29514 : H12AffineEnvironment.transform 12 314 env29513 = env29514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 314 env29513 == env29514) = true)

def env29515 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,298,64,103,65536,65540,65664,320,102,0,460,65540,65536,418,65605,303,65605,65,67873,295,65830,257,65,0,325]

theorem envBound29515 : H12AffineFastState.Bounded env29515 := by
  intro p hp
  have h : env29515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29514_29515 : H12AffineEnvironment.transform 3 0 env29514 = env29515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29514 == env29515) = true)

theorem identity29515 : scanCanonicalize (H12AffineFastState.compose env29515 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29515 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29516 : List Nat := [2,4,8,0,32,64,128,68,0,5,2048,0,110,64,103,65536,65540,65664,4,102,0,136,65540,65536,230,65605,107,65605,65,67685,99,65634,69,65,0,1]

theorem envBound29516 : H12AffineFastState.Bounded env29516 := by
  intro p hp
  have h : env29516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29515_29516 : H12AffineEnvironment.transform 7 68 env29515 = env29516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29515 == env29516) = true)

theorem identity29516 : scanCanonicalize (H12AffineFastState.compose env29516 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound29516 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29517 : List Nat := [2,4,8,0,32,64,128,68,0,5,2048,0,110,64,103,98,102,226,4,102,0,136,102,98,230,39,107,39,65,2055,99,0,69,65,0,1]

theorem envBound29517 : H12AffineFastState.Bounded env29517 := by
  intro p hp
  have h : env29517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29516_29517 : H12AffineEnvironment.transform 15 98 env29516 = env29517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env29516 == env29517) = true)

theorem identity29517 : scanCanonicalize (H12AffineFastState.compose env29517 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29517 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29518 : List Nat := [2,4,8,0,7,64,128,68,0,5,2048,0,73,64,64,69,65,197,4,65,0,136,65,69,193,0,76,0,65,2055,68,0,69,65,0,1]

theorem envBound29518 : H12AffineFastState.Bounded env29518 := by
  intro p hp
  have h : env29518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29517_29518 : H12AffineEnvironment.transform 4 7 env29517 = env29518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29517 == env29518) = true)

theorem identity29518 : scanCanonicalize (H12AffineFastState.compose env29518 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 206) := by decide +kernel

theorem selectedBound29518 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29519 : List Nat := [2,4,8,0,7,64,128,68,0,5,206,0,73,64,64,69,65,197,4,65,0,136,65,69,193,0,76,0,65,201,68,0,69,65,0,1]

theorem envBound29519 : H12AffineFastState.Bounded env29519 := by
  intro p hp
  have h : env29519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29518_29519 : H12AffineEnvironment.transform 10 206 env29518 = env29519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 206 env29518 == env29519) = true)

theorem identity29519 : scanCanonicalize (H12AffineFastState.compose env29519 (packedSelected [0,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 76) := by decide +kernel

theorem selectedBound29519 : packedSelected [0,7,8,9] rootPS < 2^1333 := by decide +kernel

def env29520 : List Nat := [2,4,8,0,7,64,76,68,0,5,2,0,73,64,64,69,65,9,4,65,0,68,65,69,13,0,76,0,65,5,68,0,69,65,0,1]

theorem envBound29520 : H12AffineFastState.Bounded env29520 := by
  intro p hp
  have h : env29520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29519_29520 : H12AffineEnvironment.transform 6 76 env29519 = env29520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 76 env29519 == env29520) = true)

theorem identity29520 : scanCanonicalize (H12AffineFastState.compose env29520 (packedSelected [0,1,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29520 : packedSelected [0,1,7,11] rootPS < 2^1333 := by decide +kernel

def env29521 : List Nat := [2,4,5,0,7,64,65,68,0,5,2,0,68,64,64,69,65,4,4,65,0,68,65,69,0,0,65,0,65,5,68,0,69,65,0,1]

theorem envBound29521 : H12AffineFastState.Bounded env29521 := by
  intro p hp
  have h : env29521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29520_29521 : H12AffineEnvironment.transform 2 5 env29520 = env29521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29520 == env29521) = true)

theorem identity29521 : scanCanonicalize (H12AffineFastState.compose env29521 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound29521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29522 : List Nat := [2,4,5,0,7,3,2,7,0,5,2,0,7,3,3,6,2,4,4,2,0,7,2,6,0,0,2,0,2,5,7,0,6,2,0,1]

theorem envBound29522 : H12AffineFastState.Bounded env29522 := by
  intro p hp
  have h : env29522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29521_29522 : H12AffineEnvironment.transform 5 3 env29521 = env29522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env29521 == env29522) = true)

theorem identity29522 : scanCanonicalize (H12AffineFastState.compose env29522 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29523 : List Nat := [2,2,3,0,1,3,2,1,0,3,2,0,1,3,3,0,2,2,2,2,0,1,2,0,0,0,2,0,2,3,1,0,0,2,0,1]

theorem envBound29523 : H12AffineFastState.Bounded env29523 := by
  intro p hp
  have h : env29523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29522_29523 : H12AffineEnvironment.transform 1 2 env29522 = env29523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29522 == env29523) = true)

def env29524 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,299,65,102,65536,65541,65664,321,103,1,461,65540,65536,418,65605,303,65605,64,67873,294,65830,257,65,0,325]

theorem envBound29524 : H12AffineFastState.Bounded env29524 := by
  intro p hp
  have h : env29524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29514_29524 : H12AffineEnvironment.transform 3 1 env29514 = env29524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29514 == env29524) = true)

theorem identity29524 : scanCanonicalize (H12AffineFastState.compose env29524 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 257) := by decide +kernel

theorem selectedBound29524 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29525 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,299,65,102,257,260,385,321,103,1,461,261,257,418,324,303,324,64,2080,294,39,257,65,0,325]

theorem envBound29525 : H12AffineFastState.Bounded env29525 := by
  intro p hp
  have h : env29525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29524_29525 : H12AffineEnvironment.transform 15 257 env29524 = env29525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env29524 == env29525) = true)

theorem identity29525 : scanCanonicalize (H12AffineFastState.compose env29525 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29525 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29526 : List Nat := [2,4,8,1,32,1,128,256,260,256,2048,1,299,0,39,257,260,385,256,38,1,396,261,257,418,261,303,261,1,2080,294,39,257,0,0,260]

theorem envBound29526 : H12AffineFastState.Bounded env29526 := by
  intro p hp
  have h : env29526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29525_29526 : H12AffineEnvironment.transform 5 1 env29525 = env29526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29525 == env29526) = true)

theorem identity29526 : scanCanonicalize (H12AffineFastState.compose env29526 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound29526 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29527 : List Nat := [2,4,8,1,32,1,128,256,260,256,428,1,299,0,39,257,260,385,256,38,1,396,261,257,418,261,303,261,1,396,294,39,257,0,0,260]

theorem envBound29527 : H12AffineFastState.Bounded env29527 := by
  intro p hp
  have h : env29527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29526_29527 : H12AffineEnvironment.transform 10 428 env29526 = env29527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env29526 == env29527) = true)

theorem identity29527 : scanCanonicalize (H12AffineFastState.compose env29527 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound29527 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29528 : List Nat := [2,4,8,1,32,1,128,166,162,166,10,1,141,0,39,167,162,39,166,38,1,42,163,167,4,163,137,163,1,42,128,39,167,0,0,162]

theorem envBound29528 : H12AffineFastState.Bounded env29528 := by
  intro p hp
  have h : env29528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29527_29528 : H12AffineEnvironment.transform 7 166 env29527 = env29528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env29527 == env29528) = true)

theorem identity29528 : scanCanonicalize (H12AffineFastState.compose env29528 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29528 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29529 : List Nat := [2,4,8,1,6,1,128,128,132,128,10,1,141,0,1,129,132,1,128,0,1,12,133,129,4,133,137,133,1,12,128,1,129,0,0,132]

theorem envBound29529 : H12AffineFastState.Bounded env29529 := by
  intro p hp
  have h : env29529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29528_29529 : H12AffineEnvironment.transform 4 6 env29528 = env29529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29528 == env29529) = true)

theorem identity29529 : scanCanonicalize (H12AffineFastState.compose env29529 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29530 : List Nat := [2,4,5,1,6,1,128,128,132,128,7,1,128,0,1,129,132,1,128,0,1,1,133,129,4,133,132,133,1,1,128,1,129,0,0,132]

theorem envBound29530 : H12AffineFastState.Bounded env29530 := by
  intro p hp
  have h : env29530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29529_29530 : H12AffineEnvironment.transform 2 5 env29529 = env29530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29529 == env29530) = true)

theorem identity29530 : scanCanonicalize (H12AffineFastState.compose env29530 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound29530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29531 : List Nat := [2,4,5,1,6,1,3,3,7,3,7,1,3,0,1,2,7,1,3,0,1,1,6,2,4,6,7,6,1,1,3,1,2,0,0,7]

theorem envBound29531 : H12AffineFastState.Bounded env29531 := by
  intro p hp
  have h : env29531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29530_29531 : H12AffineEnvironment.transform 6 3 env29530 = env29531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env29530 == env29531) = true)

theorem identity29531 : scanCanonicalize (H12AffineFastState.compose env29531 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29532 : List Nat := [2,2,3,1,0,1,3,3,1,3,1,1,3,0,1,2,1,1,3,0,1,1,0,2,2,0,1,0,1,1,3,1,2,0,0,1]

theorem envBound29532 : H12AffineFastState.Bounded env29532 := by
  intro p hp
  have h : env29532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29531_29532 : H12AffineEnvironment.transform 1 2 env29531 = env29532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29531 == env29532) = true)

def env29533 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,80,8524,65536,74030,65664,337,8525,17,476,74046,65537,8345,74110,302,74111,81,75802,8205,65830,257,65,0,324]

theorem envBound29533 : H12AffineFastState.Bounded env29533 := by
  intro p hp
  have h : env29533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29512_29533 : H12AffineEnvironment.transform 11 17 env29512 = env29533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29512 == env29533) = true)

theorem identity29533 : scanCanonicalize (H12AffineFastState.compose env29533 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound29533 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29534 : List Nat := [2,4,8,16,32,64,128,115,39,50,2048,17,8192,80,8255,65536,73821,65664,34,8254,17,175,73805,65537,8345,73741,93,73740,81,75802,8205,65621,114,65,0,55]

theorem envBound29534 : H12AffineFastState.Bounded env29534 := by
  intro p hp
  have h : env29534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29533_29534 : H12AffineEnvironment.transform 7 115 env29533 = env29534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env29533 == env29534) = true)

def env29535 : List Nat := [2,4,8,0,32,64,128,99,39,34,2048,1,8192,64,8239,65536,73805,65664,34,8238,1,175,73805,65537,8329,73741,77,73740,65,75786,8205,65605,98,65,0,39]

theorem envBound29535 : H12AffineFastState.Bounded env29535 := by
  intro p hp
  have h : env29535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29534_29535 : H12AffineEnvironment.transform 3 0 env29534 = env29535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29534 == env29535) = true)

theorem identity29535 : scanCanonicalize (H12AffineFastState.compose env29535 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound29535 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29536 : List Nat := [2,4,8,0,32,64,128,99,39,34,2048,1,8192,64,8239,8235,102,8363,34,8238,1,175,102,8234,8329,38,77,39,65,2081,8205,8302,98,65,0,39]

theorem envBound29536 : H12AffineFastState.Bounded env29536 := by
  intro p hp
  have h : env29536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29535_29536 : H12AffineEnvironment.transform 15 8235 env29535 = env29536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env29535 == env29536) = true)

theorem identity29536 : scanCanonicalize (H12AffineFastState.compose env29536 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound29536 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29537 : List Nat := [2,4,8,0,32,0,128,35,39,34,2048,1,8192,0,8239,8235,38,8363,34,8238,1,175,38,8234,8329,38,13,39,1,2081,8205,8238,34,1,0,39]

theorem envBound29537 : H12AffineFastState.Bounded env29537 := by
  intro p hp
  have h : env29537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29536_29537 : H12AffineEnvironment.transform 5 0 env29536 = env29537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env29536 == env29537) = true)

theorem identity29537 : scanCanonicalize (H12AffineFastState.compose env29537 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound29537 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29538 : List Nat := [2,4,8,0,32,0,128,35,39,34,143,1,8192,0,8239,8235,38,8363,34,8238,1,175,38,8234,8329,38,13,39,1,174,8205,8238,34,1,0,39]

theorem envBound29538 : H12AffineFastState.Bounded env29538 := by
  intro p hp
  have h : env29538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29537_29538 : H12AffineEnvironment.transform 10 143 env29537 = env29538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env29537 == env29538) = true)

theorem identity29538 : scanCanonicalize (H12AffineFastState.compose env29538 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound29538 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29539 : List Nat := [2,4,8,0,32,0,4,35,39,34,11,1,8192,0,8239,8235,38,8239,34,8238,1,43,38,8234,8205,38,13,39,1,42,8205,8238,34,1,0,39]

theorem envBound29539 : H12AffineFastState.Bounded env29539 := by
  intro p hp
  have h : env29539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29538_29539 : H12AffineEnvironment.transform 6 4 env29538 = env29539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env29538 == env29539) = true)

theorem identity29539 : scanCanonicalize (H12AffineFastState.compose env29539 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29539 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29540 : List Nat := [2,4,8,0,7,0,4,4,0,5,11,1,8192,0,8200,8204,1,8200,5,8201,1,12,1,8205,8205,1,13,0,1,13,8205,8201,5,1,0,0]

theorem envBound29540 : H12AffineFastState.Bounded env29540 := by
  intro p hp
  have h : env29540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29539_29540 : H12AffineEnvironment.transform 4 7 env29539 = env29540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29539 == env29540) = true)

theorem identity29540 : scanCanonicalize (H12AffineFastState.compose env29540 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound29540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29541 : List Nat := [2,4,8,0,7,0,4,4,0,5,11,1,4,0,12,8,1,12,5,13,1,12,1,9,9,1,13,0,1,13,9,13,5,1,0,0]

theorem envBound29541 : H12AffineFastState.Bounded env29541 := by
  intro p hp
  have h : env29541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29540_29541 : H12AffineEnvironment.transform 12 4 env29540 = env29541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env29540 == env29541) = true)

theorem identity29541 : scanCanonicalize (H12AffineFastState.compose env29541 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29541 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29542 : List Nat := [2,4,4,0,7,0,4,4,0,5,7,1,4,0,0,4,1,0,5,1,1,0,1,5,5,1,1,0,1,1,5,1,5,1,0,0]

theorem envBound29542 : H12AffineFastState.Bounded env29542 := by
  intro p hp
  have h : env29542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29541_29542 : H12AffineEnvironment.transform 2 4 env29541 = env29542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29541 == env29542) = true)

theorem identity29542 : scanCanonicalize (H12AffineFastState.compose env29542 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29543 : List Nat := [2,2,2,0,1,0,2,2,0,3,1,1,2,0,0,2,1,0,3,1,1,0,1,3,3,1,1,0,1,1,3,1,3,1,0,0]

theorem envBound29543 : H12AffineFastState.Bounded env29543 := by
  intro p hp
  have h : env29543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29542_29543 : H12AffineEnvironment.transform 1 2 env29542 = env29543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29542 == env29543) = true)

def env29544 : List Nat := [2,4,8,1,32,64,128,98,39,35,2048,0,8192,65,8238,65536,73804,65664,34,8239,0,175,73805,65537,8328,73741,76,73740,64,75787,8205,65604,99,65,0,38]

theorem envBound29544 : H12AffineFastState.Bounded env29544 := by
  intro p hp
  have h : env29544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29534_29544 : H12AffineEnvironment.transform 3 1 env29534 = env29544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29534 == env29544) = true)

theorem identity29544 : scanCanonicalize (H12AffineFastState.compose env29544 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29544 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29545 : List Nat := [2,4,8,1,6,64,128,68,1,5,2048,0,8192,65,8200,65536,73804,65664,4,8201,0,137,73805,65537,8328,73741,76,73740,64,75787,8205,65604,69,65,0,0]

theorem envBound29545 : H12AffineFastState.Bounded env29545 := by
  intro p hp
  have h : env29545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29544_29545 : H12AffineEnvironment.transform 4 6 env29544 = env29545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29544 == env29545) = true)

theorem identity29545 : scanCanonicalize (H12AffineFastState.compose env29545 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound29545 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29546 : List Nat := [2,4,8,1,6,64,128,68,1,5,2048,0,8192,65,8200,69,8201,197,4,8201,0,137,8200,68,8328,8264,76,8265,64,10318,8205,1,69,65,0,0]

theorem envBound29546 : H12AffineFastState.Bounded env29546 := by
  intro p hp
  have h : env29546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29545_29546 : H12AffineEnvironment.transform 15 69 env29545 = env29546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env29545 == env29546) = true)

theorem identity29546 : scanCanonicalize (H12AffineFastState.compose env29546 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound29546 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29547 : List Nat := [2,4,8,1,6,64,128,68,1,5,2048,0,72,65,64,69,65,197,4,65,0,137,64,68,192,0,76,1,64,2054,69,1,69,65,0,0]

theorem envBound29547 : H12AffineFastState.Bounded env29547 := by
  intro p hp
  have h : env29547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29546_29547 : H12AffineEnvironment.transform 12 72 env29546 = env29547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29546 == env29547) = true)

theorem identity29547 : scanCanonicalize (H12AffineFastState.compose env29547 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound29547 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29548 : List Nat := [2,4,8,1,6,64,15,68,1,5,2048,0,72,65,64,69,65,74,4,65,0,6,64,68,79,0,76,1,64,2054,69,1,69,65,0,0]

theorem envBound29548 : H12AffineFastState.Bounded env29548 := by
  intro p hp
  have h : env29548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29547_29548 : H12AffineEnvironment.transform 6 15 env29547 = env29548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env29547 == env29548) = true)

theorem identity29548 : scanCanonicalize (H12AffineFastState.compose env29548 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound29548 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29549 : List Nat := [2,4,8,1,6,64,15,68,1,5,12,0,72,65,64,69,65,74,4,65,0,6,64,68,79,0,76,1,64,10,69,1,69,65,0,0]

theorem envBound29549 : H12AffineFastState.Bounded env29549 := by
  intro p hp
  have h : env29549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29548_29549 : H12AffineEnvironment.transform 10 12 env29548 = env29549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env29548 == env29549) = true)

theorem identity29549 : scanCanonicalize (H12AffineFastState.compose env29549 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound29549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29550 : List Nat := [2,4,8,1,6,12,15,8,1,5,12,0,4,13,12,9,13,6,4,13,0,6,12,8,3,0,0,1,12,10,9,1,9,13,0,0]

theorem envBound29550 : H12AffineFastState.Bounded env29550 := by
  intro p hp
  have h : env29550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29549_29550 : H12AffineEnvironment.transform 5 12 env29549 = env29550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env29549 == env29550) = true)

theorem identity29550 : scanCanonicalize (H12AffineFastState.compose env29550 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound29550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29551 : List Nat := [2,4,6,1,6,2,1,6,1,5,2,0,4,3,2,7,3,6,4,3,0,6,2,6,3,0,0,1,2,4,7,1,7,3,0,0]

theorem envBound29551 : H12AffineFastState.Bounded env29551 := by
  intro p hp
  have h : env29551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29550_29551 : H12AffineEnvironment.transform 2 6 env29550 = env29551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env29550 == env29551) = true)

theorem identity29551 : scanCanonicalize (H12AffineFastState.compose env29551 (packedSelected [2,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29551 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env29552 : List Nat := [2,3,1,1,1,2,1,1,1,2,2,0,3,3,2,0,3,1,3,3,0,1,2,1,3,0,0,1,2,3,0,1,0,3,0,0]

theorem envBound29552 : H12AffineFastState.Bounded env29552 := by
  intro p hp
  have h : env29552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29551_29552 : H12AffineEnvironment.transform 1 3 env29551 = env29552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29551 == env29552) = true)

def env29553 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4096,476,74046,69648,12424,78191,4415,74111,81,79883,8205,65830,257,65,0,4436]

theorem envBound29553 : H12AffineFastState.Bounded env29553 := by
  intro p hp
  have h : env29553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29511_29553 : H12AffineEnvironment.transform 8 341 env29511 = env29553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env29511 == env29553) = true)

def env29554 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8525,65536,74030,65664,336,8524,16,476,74046,65536,8344,74111,303,74111,81,75803,8205,65830,257,65,0,324]

theorem envBound29554 : H12AffineFastState.Bounded env29554 := by
  intro p hp
  have h : env29554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29553_29554 : H12AffineEnvironment.transform 11 16 env29553 = env29554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env29553 == env29554) = true)

theorem identity29554 : scanCanonicalize (H12AffineFastState.compose env29554 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 20) := by decide +kernel

theorem selectedBound29554 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29555 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8525,20,8506,148,336,8524,16,476,8490,20,8344,8555,303,8555,81,10255,8205,306,257,65,0,324]

theorem envBound29555 : H12AffineFastState.Bounded env29555 := by
  intro p hp
  have h : env29555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29554_29555 : H12AffineEnvironment.transform 15 20 env29554 = env29555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env29554 == env29555) = true)

def env29556 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,8192,64,8525,4,8490,132,320,8524,0,460,8490,4,8328,8555,303,8555,65,10255,8205,290,257,65,0,324]

theorem envBound29556 : H12AffineFastState.Bounded env29556 := by
  intro p hp
  have h : env29556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29555_29556 : H12AffineEnvironment.transform 3 0 env29555 = env29556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29555 == env29556) = true)

theorem identity29556 : scanCanonicalize (H12AffineFastState.compose env29556 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29556 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29557 : List Nat := [2,4,8,0,32,64,128,68,1,5,2048,0,8192,64,8201,4,8302,132,4,8200,0,136,8302,4,8328,8239,107,8239,65,10255,8205,102,69,65,0,0]

theorem envBound29557 : H12AffineFastState.Bounded env29557 := by
  intro p hp
  have h : env29557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29556_29557 : H12AffineEnvironment.transform 7 68 env29556 = env29557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29556 == env29557) = true)

theorem identity29557 : scanCanonicalize (H12AffineFastState.compose env29557 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound29557 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29558 : List Nat := [2,4,8,0,32,38,128,34,1,5,2048,0,8192,38,8201,4,8200,132,4,8200,0,136,8200,4,8328,8239,13,8239,39,10255,8205,0,35,39,0,0]

theorem envBound29558 : H12AffineFastState.Bounded env29558 := by
  intro p hp
  have h : env29558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29557_29558 : H12AffineEnvironment.transform 5 38 env29557 = env29558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env29557 == env29558) = true)

theorem identity29558 : scanCanonicalize (H12AffineFastState.compose env29558 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound29558 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29559 : List Nat := [2,4,8,0,32,38,128,34,1,5,2048,0,47,38,38,4,39,132,4,39,0,136,39,4,167,0,13,0,39,2080,34,0,35,39,0,0]

theorem envBound29559 : H12AffineFastState.Bounded env29559 := by
  intro p hp
  have h : env29559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29558_29559 : H12AffineEnvironment.transform 12 47 env29558 = env29559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env29558 == env29559) = true)

theorem identity29559 : scanCanonicalize (H12AffineFastState.compose env29559 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound29559 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29560 : List Nat := [2,4,8,0,32,38,128,34,1,5,169,0,47,38,38,4,39,132,4,39,0,136,39,4,167,0,13,0,39,137,34,0,35,39,0,0]

theorem envBound29560 : H12AffineFastState.Bounded env29560 := by
  intro p hp
  have h : env29560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29559_29560 : H12AffineEnvironment.transform 10 169 env29559 = env29560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env29559 == env29560) = true)

theorem identity29560 : scanCanonicalize (H12AffineFastState.compose env29560 (packedSelected [0,1,2,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound29560 : packedSelected [0,1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env29561 : List Nat := [2,4,8,0,8,14,128,10,1,5,129,0,7,14,14,4,15,132,4,15,0,136,15,4,143,0,13,0,15,137,10,0,11,15,0,0]

theorem envBound29561 : H12AffineFastState.Bounded env29561 := by
  intro p hp
  have h : env29561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29560_29561 : H12AffineEnvironment.transform 4 8 env29560 = env29561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env29560 == env29561) = true)

theorem identity29561 : scanCanonicalize (H12AffineFastState.compose env29561 (packedSelected [0,1,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29561 : packedSelected [0,1,7,11] rootPS < 2^1333 := by decide +kernel

def env29562 : List Nat := [2,4,4,0,4,2,128,6,1,5,129,0,7,2,2,4,3,132,4,3,0,132,3,4,131,0,1,0,3,133,6,0,7,3,0,0]

theorem envBound29562 : H12AffineFastState.Bounded env29562 := by
  intro p hp
  have h : env29562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29561_29562 : H12AffineEnvironment.transform 2 4 env29561 = env29562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29561 == env29562) = true)

theorem identity29562 : scanCanonicalize (H12AffineFastState.compose env29562 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound29562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29563 : List Nat := [2,4,4,0,4,2,0,6,1,5,1,0,7,2,2,4,3,4,4,3,0,4,3,4,3,0,1,0,3,5,6,0,7,3,0,0]

theorem envBound29563 : H12AffineFastState.Bounded env29563 := by
  intro p hp
  have h : env29563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29562_29563 : H12AffineEnvironment.transform 6 0 env29562 = env29563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env29562 == env29563) = true)

theorem identity29563 : scanCanonicalize (H12AffineFastState.compose env29563 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29563 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29564 : List Nat := [2,2,2,0,2,2,0,0,1,3,1,0,1,2,2,2,3,2,2,3,0,2,3,2,3,0,1,0,3,3,0,0,1,3,0,0]

theorem envBound29564 : H12AffineFastState.Bounded env29564 := by
  intro p hp
  have h : env29564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29563_29564 : H12AffineEnvironment.transform 1 2 env29563 = env29564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29563 == env29564) = true)

theorem identity29564 : scanCanonicalize (H12AffineFastState.compose env29564 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29564 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29565 : List Nat := [1,1,1,0,1,1,0,0,1,0,1,0,1,1,1,1,0,1,1,0,0,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0]

theorem envBound29565 : H12AffineFastState.Bounded env29565 := by
  intro p hp
  have h : env29565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29564_29565 : H12AffineEnvironment.transform 0 1 env29564 = env29565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29564 == env29565) = true)

def env29566 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,8192,65,8525,5,8491,133,321,8524,1,461,8490,5,8329,8555,303,8555,64,10255,8205,291,257,65,0,324]

theorem envBound29566 : H12AffineFastState.Bounded env29566 := by
  intro p hp
  have h : env29566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29555_29566 : H12AffineEnvironment.transform 3 1 env29555 = env29566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29555 == env29566) = true)

theorem identity29566 : scanCanonicalize (H12AffineFastState.compose env29566 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound29566 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29567 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,47,65,354,5,260,133,321,355,1,461,261,5,166,324,303,324,64,2080,34,291,257,65,0,324]

theorem envBound29567 : H12AffineFastState.Bounded env29567 := by
  intro p hp
  have h : env29567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29566_29567 : H12AffineEnvironment.transform 12 47 env29566 = env29567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env29566 == env29567) = true)

theorem identity29567 : scanCanonicalize (H12AffineFastState.compose env29567 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29567 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29568 : List Nat := [2,4,8,1,32,1,128,256,261,256,2048,1,47,0,291,5,260,133,256,290,1,396,261,5,166,261,303,261,1,2080,34,291,257,0,0,261]

theorem envBound29568 : H12AffineFastState.Bounded env29568 := by
  intro p hp
  have h : env29568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29567_29568 : H12AffineEnvironment.transform 5 1 env29567 = env29568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29567 == env29568) = true)

theorem identity29568 : scanCanonicalize (H12AffineFastState.compose env29568 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound29568 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29569 : List Nat := [2,4,8,1,32,1,128,256,261,256,428,1,47,0,291,5,260,133,256,290,1,396,261,5,166,261,303,261,1,396,34,291,257,0,0,261]

theorem envBound29569 : H12AffineFastState.Bounded env29569 := by
  intro p hp
  have h : env29569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29568_29569 : H12AffineEnvironment.transform 10 428 env29568 = env29569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env29568 == env29569) = true)

theorem identity29569 : scanCanonicalize (H12AffineFastState.compose env29569 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound29569 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29570 : List Nat := [2,4,8,1,32,1,128,166,163,166,10,1,47,0,133,5,162,133,166,132,1,42,163,5,166,163,137,163,1,42,34,133,167,0,0,163]

theorem envBound29570 : H12AffineFastState.Bounded env29570 := by
  intro p hp
  have h : env29570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29569_29570 : H12AffineEnvironment.transform 7 166 env29569 = env29570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env29569 == env29570) = true)

theorem identity29570 : scanCanonicalize (H12AffineFastState.compose env29570 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound29570 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29571 : List Nat := [2,4,8,1,32,1,35,5,0,5,10,1,47,0,38,5,1,38,5,39,1,42,0,5,5,0,42,0,1,42,34,38,4,0,0,0]

theorem envBound29571 : H12AffineFastState.Bounded env29571 := by
  intro p hp
  have h : env29571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29570_29571 : H12AffineEnvironment.transform 6 35 env29570 = env29571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env29570 == env29571) = true)

theorem identity29571 : scanCanonicalize (H12AffineFastState.compose env29571 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29572 : List Nat := [2,4,5,1,32,1,35,5,0,5,7,1,34,0,38,5,1,38,5,39,1,39,0,5,5,0,39,0,1,39,34,38,4,0,0,0]

theorem envBound29572 : H12AffineFastState.Bounded env29572 := by
  intro p hp
  have h : env29572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29571_29572 : H12AffineEnvironment.transform 2 5 env29571 = env29572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29571 == env29572) = true)

theorem identity29572 : scanCanonicalize (H12AffineFastState.compose env29572 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29572 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29573 : List Nat := [2,4,5,1,6,1,5,5,0,5,7,1,4,0,0,5,1,0,5,1,1,1,0,5,5,0,1,0,1,1,4,0,4,0,0,0]

theorem envBound29573 : H12AffineFastState.Bounded env29573 := by
  intro p hp
  have h : env29573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29572_29573 : H12AffineEnvironment.transform 4 6 env29572 = env29573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29572 == env29573) = true)

theorem identity29573 : scanCanonicalize (H12AffineFastState.compose env29573 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29574 : List Nat := [2,2,3,1,0,1,3,3,0,3,1,1,2,0,0,3,1,0,3,1,1,1,0,3,3,0,1,0,1,1,2,0,2,0,0,0]

theorem envBound29574 : H12AffineFastState.Bounded env29574 := by
  intro p hp
  have h : env29574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29573_29574 : H12AffineEnvironment.transform 1 2 env29573 = env29574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29573 == env29574) = true)

def env29575 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8524,65536,74030,65664,337,8525,17,476,74046,65537,8345,74110,302,74111,81,75802,8205,65830,257,65,0,325]

theorem envBound29575 : H12AffineFastState.Bounded env29575 := by
  intro p hp
  have h : env29575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29553_29575 : H12AffineEnvironment.transform 11 17 env29553 = env29575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29553 == env29575) = true)

theorem identity29575 : scanCanonicalize (H12AffineFastState.compose env29575 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8285) := by decide +kernel

theorem selectedBound29575 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29576 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8524,8285,371,8413,337,8525,17,476,355,8284,8345,291,302,290,81,2119,8205,8571,257,65,0,325]

theorem envBound29576 : H12AffineFastState.Bounded env29576 := by
  intro p hp
  have h : env29576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29575_29576 : H12AffineEnvironment.transform 15 8285 env29575 = env29576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8285 env29575 == env29576) = true)

def env29577 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,8192,64,8524,8269,355,8397,321,8525,1,460,355,8268,8329,291,302,290,65,2119,8205,8555,257,65,0,325]

theorem envBound29577 : H12AffineFastState.Bounded env29577 := by
  intro p hp
  have h : env29577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29576_29577 : H12AffineEnvironment.transform 3 0 env29576 = env29577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29576 == env29577) = true)

theorem identity29577 : scanCanonicalize (H12AffineFastState.compose env29577 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound29577 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29578 : List Nat := [2,4,8,0,32,38,128,256,291,295,2048,1,8192,38,8490,8235,261,8363,295,8491,1,426,261,8234,8329,291,302,290,39,2081,8205,8461,257,39,0,291]

theorem envBound29578 : H12AffineFastState.Bounded env29578 := by
  intro p hp
  have h : env29578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29577_29578 : H12AffineEnvironment.transform 5 38 env29577 = env29578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env29577 == env29578) = true)

theorem identity29578 : scanCanonicalize (H12AffineFastState.compose env29578 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29578 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29579 : List Nat := [2,4,8,0,6,0,128,256,261,257,2048,1,8192,0,8460,8205,261,8333,257,8461,1,396,261,8204,8329,261,264,260,1,2055,8205,8461,257,1,0,261]

theorem envBound29579 : H12AffineFastState.Bounded env29579 := by
  intro p hp
  have h : env29579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29578_29579 : H12AffineEnvironment.transform 4 6 env29578 = env29579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29578 == env29579) = true)

theorem identity29579 : scanCanonicalize (H12AffineFastState.compose env29579 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 394) := by decide +kernel

theorem selectedBound29579 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29580 : List Nat := [2,4,8,0,6,0,128,256,261,257,394,1,8192,0,8460,8205,261,8333,257,8461,1,396,261,8204,8329,261,264,260,1,397,8205,8461,257,1,0,261]

theorem envBound29580 : H12AffineFastState.Bounded env29580 := by
  intro p hp
  have h : env29580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29579_29580 : H12AffineEnvironment.transform 10 394 env29579 = env29580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 394 env29579 == env29580) = true)

theorem identity29580 : scanCanonicalize (H12AffineFastState.compose env29580 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound29580 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29581 : List Nat := [2,4,8,0,6,0,128,129,132,128,11,1,8192,0,8333,8205,132,8333,128,8332,1,13,132,8204,8329,132,137,133,1,12,8205,8332,128,1,0,132]

theorem envBound29581 : H12AffineFastState.Bounded env29581 := by
  intro p hp
  have h : env29581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29580_29581 : H12AffineEnvironment.transform 7 129 env29580 = env29581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env29580 == env29581) = true)

theorem identity29581 : scanCanonicalize (H12AffineFastState.compose env29581 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound29581 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29582 : List Nat := [2,4,8,0,6,0,128,129,132,128,11,1,140,0,1,129,132,1,128,0,1,13,132,128,5,132,137,133,1,12,129,0,128,1,0,132]

theorem envBound29582 : H12AffineFastState.Bounded env29582 := by
  intro p hp
  have h : env29582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29581_29582 : H12AffineEnvironment.transform 12 140 env29581 = env29582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env29581 == env29582) = true)

theorem identity29582 : scanCanonicalize (H12AffineFastState.compose env29582 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29583 : List Nat := [2,4,5,0,6,0,128,129,132,128,6,1,129,0,1,129,132,1,128,0,1,0,132,128,5,132,132,133,1,1,129,0,128,1,0,132]

theorem envBound29583 : H12AffineFastState.Bounded env29583 := by
  intro p hp
  have h : env29583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29582_29583 : H12AffineEnvironment.transform 2 5 env29582 = env29583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29582 == env29583) = true)

theorem identity29583 : scanCanonicalize (H12AffineFastState.compose env29583 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29584 : List Nat := [2,4,5,0,6,0,2,3,6,2,6,1,3,0,1,3,6,1,2,0,1,0,6,2,5,6,6,7,1,1,3,0,2,1,0,6]

theorem envBound29584 : H12AffineFastState.Bounded env29584 := by
  intro p hp
  have h : env29584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29583_29584 : H12AffineEnvironment.transform 6 2 env29583 = env29584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29583 == env29584) = true)

theorem identity29584 : scanCanonicalize (H12AffineFastState.compose env29584 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29585 : List Nat := [2,3,2,0,1,0,2,3,1,2,1,1,3,0,1,3,1,1,2,0,1,0,1,2,2,1,1,0,1,1,3,0,2,1,0,1]

theorem envBound29585 : H12AffineFastState.Bounded env29585 := by
  intro p hp
  have h : env29585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29584_29585 : H12AffineEnvironment.transform 1 3 env29584 = env29585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29584 == env29585) = true)

def env29586 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,8192,65,8524,8268,354,8396,320,8525,0,461,355,8269,8328,291,302,290,64,2119,8205,8554,257,65,0,325]

theorem envBound29586 : H12AffineFastState.Bounded env29586 := by
  intro p hp
  have h : env29586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29576_29586 : H12AffineEnvironment.transform 3 1 env29576 = env29586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29576 == env29586) = true)

theorem identity29586 : scanCanonicalize (H12AffineFastState.compose env29586 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29586 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29587 : List Nat := [2,4,8,1,32,64,128,68,0,5,2048,0,8192,65,8200,8268,38,8396,4,8201,0,137,39,8269,8328,103,106,102,64,2119,8205,8238,69,65,0,1]

theorem envBound29587 : H12AffineFastState.Bounded env29587 := by
  intro p hp
  have h : env29587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29586_29587 : H12AffineEnvironment.transform 7 68 env29586 = env29587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29586 == env29587) = true)

theorem identity29587 : scanCanonicalize (H12AffineFastState.compose env29587 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound29587 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29588 : List Nat := [2,4,8,1,32,64,128,68,0,5,2048,0,47,65,39,99,38,227,4,38,0,137,39,98,167,103,106,102,64,2119,34,1,69,65,0,1]

theorem envBound29588 : H12AffineFastState.Bounded env29588 := by
  intro p hp
  have h : env29588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29587_29588 : H12AffineEnvironment.transform 12 47 env29587 = env29588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env29587 == env29588) = true)

theorem identity29588 : scanCanonicalize (H12AffineFastState.compose env29588 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound29588 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29589 : List Nat := [2,4,8,1,32,39,128,35,0,5,2048,0,47,38,39,4,38,132,4,38,0,137,39,5,167,0,13,1,39,2080,34,1,34,38,0,1]

theorem envBound29589 : H12AffineFastState.Bounded env29589 := by
  intro p hp
  have h : env29589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29588_29589 : H12AffineEnvironment.transform 5 39 env29588 = env29589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env29588 == env29589) = true)

theorem identity29589 : scanCanonicalize (H12AffineFastState.compose env29589 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound29589 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29590 : List Nat := [2,4,8,1,32,39,14,35,0,5,2048,0,47,38,39,4,38,10,4,38,0,7,39,5,41,0,13,1,39,2080,34,1,34,38,0,1]

theorem envBound29590 : H12AffineFastState.Bounded env29590 := by
  intro p hp
  have h : env29590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29589_29590 : H12AffineEnvironment.transform 6 14 env29589 = env29590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env29589 == env29590) = true)

theorem identity29590 : scanCanonicalize (H12AffineFastState.compose env29590 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound29590 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29591 : List Nat := [2,4,8,1,32,39,14,35,0,5,42,0,47,38,39,4,38,10,4,38,0,7,39,5,41,0,13,1,39,10,34,1,34,38,0,1]

theorem envBound29591 : H12AffineFastState.Bounded env29591 := by
  intro p hp
  have h : env29591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29590_29591 : H12AffineEnvironment.transform 10 42 env29590 = env29591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env29590 == env29591) = true)

theorem identity29591 : scanCanonicalize (H12AffineFastState.compose env29591 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29592 : List Nat := [2,4,5,1,32,39,3,35,0,5,39,0,34,38,39,4,38,7,4,38,0,7,39,5,36,0,0,1,39,7,34,1,34,38,0,1]

theorem envBound29592 : H12AffineFastState.Bounded env29592 := by
  intro p hp
  have h : env29592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29591_29592 : H12AffineEnvironment.transform 2 5 env29591 = env29592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29591 == env29592) = true)

theorem identity29592 : scanCanonicalize (H12AffineFastState.compose env29592 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29592 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29593 : List Nat := [0,4,5,1,32,37,1,33,0,5,37,0,32,36,37,4,36,5,4,36,0,5,37,5,36,0,0,1,37,5,32,1,32,36,0,1]

theorem envBound29593 : H12AffineFastState.Bounded env29593 := by
  intro p hp
  have h : env29593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29592_29593 : H12AffineEnvironment.transform 0 0 env29592 = env29593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29592 == env29593) = true)

theorem identity29593 : scanCanonicalize (H12AffineFastState.compose env29593 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29593 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29594 : List Nat := [0,0,1,1,32,33,1,33,0,1,33,0,32,32,33,0,32,1,0,32,0,1,33,1,32,0,0,1,33,1,32,1,32,32,0,1]

theorem envBound29594 : H12AffineFastState.Bounded env29594 := by
  intro p hp
  have h : env29594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29593_29594 : H12AffineEnvironment.transform 1 0 env29593 = env29594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29593 == env29594) = true)

theorem identity29594 : scanCanonicalize (H12AffineFastState.compose env29594 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29595 : List Nat := [0,0,1,1,1,0,1,0,0,1,0,0,1,1,0,0,1,1,0,1,0,1,0,1,1,0,0,1,0,1,1,1,1,1,0,1]

theorem envBound29595 : H12AffineFastState.Bounded env29595 := by
  intro p hp
  have h : env29595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29594_29595 : H12AffineEnvironment.transform 4 1 env29594 = env29595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29594 == env29595) = true)

def env29596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4096,476,74046,69648,13769,78894,4414,74814,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound29596 : H12AffineFastState.Bounded env29596 := by
  intro p hp
  have h : env29596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29509_29596 : H12AffineEnvironment.transform 17 65665 env29509 = env29596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29509 == env29596) = true)

theorem identity29596 : scanCanonicalize (H12AffineFastState.compose env29596 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29596 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,0,476,74046,65552,9673,74798,318,74814,1296,77130,8205,65830,257,1280,1345,1856]

theorem envBound29597 : H12AffineFastState.Bounded env29597 := by
  intro p hp
  have h : env29597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29596_29597 : H12AffineEnvironment.transform 11 0 env29596 = env29597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29596 == env29597) = true)

def env29598 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,0,476,74046,65552,9673,74798,318,74814,1296,77130,8205,65830,257,1280,1345,1044]

theorem envBound29598 : H12AffineFastState.Bounded env29598 := by
  intro p hp
  have h : env29598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29597_29598 : H12AffineEnvironment.transform 8 340 env29597 = env29598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env29597 == env29598) = true)

def env29599 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9228,65536,74863,65665,320,9229,0,460,74030,65536,9673,74798,302,74798,1280,77130,8205,65830,257,1280,1345,1028]

theorem envBound29599 : H12AffineFastState.Bounded env29599 := by
  intro p hp
  have h : env29599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29598_29599 : H12AffineEnvironment.transform 3 0 env29598 = env29599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29598 == env29599) = true)

theorem identity29599 : scanCanonicalize (H12AffineFastState.compose env29599 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 299) := by decide +kernel

theorem selectedBound29599 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29600 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,299,1281,1319,65536,66884,65665,320,1318,0,460,65541,65536,1250,66821,302,66821,1280,68705,294,65830,257,1280,1345,1028]

theorem envBound29600 : H12AffineFastState.Bounded env29600 := by
  intro p hp
  have h : env29600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29599_29600 : H12AffineEnvironment.transform 12 299 env29599 = env29600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 299 env29599 == env29600) = true)

def env29601 : List Nat := [2,4,8,0,32,64,36,256,324,1024,2048,0,299,1281,1319,65536,66884,65573,320,1318,0,360,65541,65536,1094,66821,302,66821,1280,68705,294,65830,257,1280,1345,1028]

theorem envBound29601 : H12AffineFastState.Bounded env29601 := by
  intro p hp
  have h : env29601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29600_29601 : H12AffineEnvironment.transform 6 36 env29600 = env29601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env29600 == env29601) = true)

def env29602 : List Nat := [2,4,8,0,32,64,36,256,324,1024,2048,0,299,1281,1319,40,1388,13,320,1318,0,360,45,40,1094,1325,302,1325,1280,3145,294,270,257,1280,1345,1028]

theorem envBound29602 : H12AffineFastState.Bounded env29602 := by
  intro p hp
  have h : env29602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29601_29602 : H12AffineEnvironment.transform 15 40 env29601 = env29602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40 env29601 == env29602) = true)

theorem identity29602 : scanCanonicalize (H12AffineFastState.compose env29602 (packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 1324) := by decide +kernel

theorem selectedBound29602 : packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29603 : List Nat := [2,4,8,0,32,64,36,256,324,1024,1324,0,299,1281,1319,40,1388,13,320,1318,0,360,45,40,1094,1325,302,1325,1280,357,294,270,257,1280,1345,1028]

theorem envBound29603 : H12AffineFastState.Bounded env29603 := by
  intro p hp
  have h : env29603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29602_29603 : H12AffineEnvironment.transform 10 1324 env29602 = env29603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1324 env29602 == env29603) = true)

theorem identity29603 : scanCanonicalize (H12AffineFastState.compose env29603 (packedSelected [1,3,5,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound29603 : packedSelected [1,3,5,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env29604 : List Nat := [2,4,8,0,32,45,36,256,297,1024,1324,0,299,1281,1319,40,1281,13,301,1318,0,261,45,40,1067,1325,302,1325,1280,264,294,270,257,1280,1324,1028]

theorem envBound29604 : H12AffineFastState.Bounded env29604 := by
  intro p hp
  have h : env29604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29603_29604 : H12AffineEnvironment.transform 5 45 env29603 = env29604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env29603 == env29604) = true)

theorem identity29604 : scanCanonicalize (H12AffineFastState.compose env29604 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound29604 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env29605 : List Nat := [2,4,8,0,13,0,9,256,260,1024,1281,0,262,1281,1290,5,1281,13,256,1291,0,261,0,5,1030,1280,259,1280,1280,264,267,270,257,1280,1281,1028]

theorem envBound29605 : H12AffineFastState.Bounded env29605 := by
  intro p hp
  have h : env29605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29604_29605 : H12AffineEnvironment.transform 4 13 env29604 = env29605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env29604 == env29605) = true)

theorem identity29605 : scanCanonicalize (H12AffineFastState.compose env29605 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound29605 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env29606 : List Nat := [2,4,8,0,13,0,9,256,260,9,264,0,262,264,259,5,264,13,256,258,0,261,0,5,15,265,259,265,265,264,267,270,257,265,264,13]

theorem envBound29606 : H12AffineFastState.Bounded env29606 := by
  intro p hp
  have h : env29606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29605_29606 : H12AffineEnvironment.transform 9 9 env29605 = env29606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env29605 == env29606) = true)

theorem identity29606 : scanCanonicalize (H12AffineFastState.compose env29606 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29606 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29607 : List Nat := [2,4,4,0,1,0,5,256,260,5,260,0,262,260,259,5,260,1,256,258,0,261,0,5,3,261,259,261,261,260,263,258,257,261,260,1]

theorem envBound29607 : H12AffineFastState.Bounded env29607 := by
  intro p hp
  have h : env29607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29606_29607 : H12AffineEnvironment.transform 2 4 env29606 = env29607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29606 == env29607) = true)

theorem identity29607 : scanCanonicalize (H12AffineFastState.compose env29607 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29607 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29608 : List Nat := [2,4,4,0,1,0,5,5,1,5,1,0,3,1,6,5,1,1,5,7,0,0,0,5,3,0,6,0,0,1,2,7,4,0,1,1]

theorem envBound29608 : H12AffineFastState.Bounded env29608 := by
  intro p hp
  have h : env29608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29607_29608 : H12AffineEnvironment.transform 7 5 env29607 = env29608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29607 == env29608) = true)

theorem identity29608 : scanCanonicalize (H12AffineFastState.compose env29608 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29609 : List Nat := [2,2,2,0,1,0,3,3,1,3,1,0,3,1,0,3,1,1,3,1,0,0,0,3,3,0,0,0,0,1,2,1,2,0,1,1]

theorem envBound29609 : H12AffineFastState.Bounded env29609 := by
  intro p hp
  have h : env29609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29608_29609 : H12AffineEnvironment.transform 1 2 env29608 = env29609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29608 == env29609) = true)

def env29610 : List Nat := [2,4,8,0,32,64,36,256,324,1024,2048,0,299,1281,1319,41,1389,12,320,1318,0,360,44,41,1094,1324,302,1324,1280,3144,294,271,257,1280,1345,1028]

theorem envBound29610 : H12AffineFastState.Bounded env29610 := by
  intro p hp
  have h : env29610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29601_29610 : H12AffineEnvironment.transform 15 41 env29601 = env29610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env29601 == env29610) = true)

theorem identity29610 : scanCanonicalize (H12AffineFastState.compose env29610 (packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound29610 : packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29611 : List Nat := [2,4,8,0,32,64,36,256,324,1024,1323,0,299,1281,1319,41,1389,12,320,1318,0,360,44,41,1094,1324,302,1324,1280,355,294,271,257,1280,1345,1028]

theorem envBound29611 : H12AffineFastState.Bounded env29611 := by
  intro p hp
  have h : env29611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29610_29611 : H12AffineEnvironment.transform 10 1323 env29610 = env29611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env29610 == env29611) = true)

theorem identity29611 : scanCanonicalize (H12AffineFastState.compose env29611 (packedSelected [3,4,5,7,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound29611 : packedSelected [3,4,5,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29612 : List Nat := [2,4,8,0,32,64,36,256,324,111,324,0,299,366,328,41,258,12,320,329,0,360,44,41,41,323,302,323,367,355,294,271,257,367,302,107]

theorem envBound29612 : H12AffineFastState.Bounded env29612 := by
  intro p hp
  have h : env29612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29611_29612 : H12AffineEnvironment.transform 9 111 env29611 = env29612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env29611 == env29612) = true)

theorem identity29612 : scanCanonicalize (H12AffineFastState.compose env29612 (packedSelected [0,1,2,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound29612 : packedSelected [0,1,2,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29613 : List Nat := [2,4,8,0,32,64,36,35,103,111,103,0,8,77,107,41,33,12,99,106,0,75,44,41,41,96,13,96,76,64,5,44,34,76,13,107]

theorem envBound29613 : H12AffineFastState.Bounded env29613 := by
  intro p hp
  have h : env29613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29612_29613 : H12AffineEnvironment.transform 7 35 env29612 = env29613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env29612 == env29613) = true)

theorem identity29613 : scanCanonicalize (H12AffineFastState.compose env29613 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29613 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29614 : List Nat := [2,3,8,0,32,64,35,35,96,104,96,0,8,74,107,41,33,11,99,106,0,75,43,41,41,96,10,96,75,64,2,43,34,75,10,107]

theorem envBound29614 : H12AffineFastState.Bounded env29614 := by
  intro p hp
  have h : env29614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29613_29614 : H12AffineEnvironment.transform 1 3 env29613 = env29614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29613 == env29614) = true)

theorem identity29614 : scanCanonicalize (H12AffineFastState.compose env29614 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29614 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29615 : List Nat := [2,3,8,0,32,1,35,35,33,41,33,0,8,11,42,41,33,11,34,43,0,10,43,41,41,33,10,33,10,1,2,43,34,10,10,42]

theorem envBound29615 : H12AffineFastState.Bounded env29615 := by
  intro p hp
  have h : env29615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29614_29615 : H12AffineEnvironment.transform 5 1 env29614 = env29615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29614 == env29615) = true)

theorem identity29615 : scanCanonicalize (H12AffineFastState.compose env29615 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29615 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29616 : List Nat := [2,3,3,0,32,1,35,35,33,34,33,0,3,0,33,34,33,0,34,32,0,1,32,34,34,33,1,33,1,1,2,32,34,1,1,33]

theorem envBound29616 : H12AffineFastState.Bounded env29616 := by
  intro p hp
  have h : env29616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29615_29616 : H12AffineEnvironment.transform 2 3 env29615 = env29616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29615 == env29616) = true)

theorem identity29616 : scanCanonicalize (H12AffineFastState.compose env29616 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29616 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29617 : List Nat := [2,3,3,0,1,1,2,2,0,3,0,0,3,0,0,3,0,0,3,1,0,1,1,3,3,0,1,0,1,1,2,1,3,1,1,0]

theorem envBound29617 : H12AffineFastState.Bounded env29617 := by
  intro p hp
  have h : env29617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29616_29617 : H12AffineEnvironment.transform 4 1 env29616 = env29617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29616 == env29617) = true)

def env29618 : List Nat := [2,4,8,0,32,64,37,256,324,1024,2048,0,299,1281,1319,65536,66884,65572,320,1318,0,361,65541,65536,1095,66821,302,66821,1280,68705,294,65830,257,1280,1345,1028]

theorem envBound29618 : H12AffineFastState.Bounded env29618 := by
  intro p hp
  have h : env29618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29600_29618 : H12AffineEnvironment.transform 6 37 env29600 = env29618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env29600 == env29618) = true)

def env29619 : List Nat := [2,4,8,0,32,64,37,256,324,1024,2048,0,299,1281,1319,40,1388,12,320,1318,0,361,45,40,1095,1325,302,1325,1280,3145,294,270,257,1280,1345,1028]

theorem envBound29619 : H12AffineFastState.Bounded env29619 := by
  intro p hp
  have h : env29619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29618_29619 : H12AffineEnvironment.transform 15 40 env29618 = env29619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40 env29618 == env29619) = true)

theorem identity29619 : scanCanonicalize (H12AffineFastState.compose env29619 (packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29619 : packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2