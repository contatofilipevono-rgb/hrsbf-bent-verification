import H12CloudChart2Data168

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity42285 : scanCanonicalize (H12AffineFastState.compose env42285 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound42285 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env42286 : List Nat := [2,4,8,16,32,16,128,256,163,4,2048,2232,2485,277,276,310,277,439,4,277,2233,396,17,2462,2364,17,43,276,2232,2340,2489,17,257,2217,276,163]

theorem envBound42286 : H12AffineFastState.Bounded env42286 := by
  intro p hp
  have h : env42286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42285_42286 : H12AffineEnvironment.transform 8 163 env42285 = env42286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env42285 == env42286) = true)

theorem identity42286 : scanCanonicalize (H12AffineFastState.compose env42286 (packedSelected [1,2,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42286 : packedSelected [1,2,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env42287 : List Nat := [2,4,8,16,32,16,128,20,163,4,2048,2232,2209,1,0,34,1,163,4,1,2233,152,17,2186,2088,17,43,0,2232,2096,2221,17,21,2217,0,163]

theorem envBound42287 : H12AffineFastState.Bounded env42287 := by
  intro p hp
  have h : env42287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42286_42287 : H12AffineEnvironment.transform 7 20 env42286 = env42287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42286 == env42287) = true)

theorem identity42287 : scanCanonicalize (H12AffineFastState.compose env42287 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound42287 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42288 : List Nat := [2,4,8,16,32,16,128,20,163,4,163,27,2,1,0,34,1,163,4,1,26,152,17,41,139,17,43,0,27,147,14,17,21,10,0,163]

theorem envBound42288 : H12AffineFastState.Bounded env42288 := by
  intro p hp
  have h : env42288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42287_42288 : H12AffineEnvironment.transform 10 163 env42287 = env42288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env42287 == env42288) = true)

theorem identity42288 : scanCanonicalize (H12AffineFastState.compose env42288 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42288 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42289 : List Nat := [2,4,8,10,32,10,128,14,163,4,163,1,2,1,0,34,1,163,4,1,0,130,11,41,139,11,43,0,1,137,14,11,15,10,0,163]

theorem envBound42289 : H12AffineFastState.Bounded env42289 := by
  intro p hp
  have h : env42289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42288_42289 : H12AffineEnvironment.transform 3 10 env42288 = env42289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42288 == env42289) = true)

theorem identity42289 : scanCanonicalize (H12AffineFastState.compose env42289 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound42289 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42290 : List Nat := [2,4,8,10,32,10,37,14,6,4,6,1,2,1,0,34,1,6,4,1,0,39,11,41,46,11,43,0,1,44,14,11,15,10,0,6]

theorem envBound42290 : H12AffineFastState.Bounded env42290 := by
  intro p hp
  have h : env42290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42289_42290 : H12AffineEnvironment.transform 6 37 env42289 = env42290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env42289 == env42290) = true)

theorem identity42290 : scanCanonicalize (H12AffineFastState.compose env42290 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound42290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42291 : List Nat := [2,4,8,10,12,10,9,14,6,4,6,1,2,1,0,14,1,6,4,1,0,11,11,5,2,11,7,0,1,0,14,11,15,10,0,6]

theorem envBound42291 : H12AffineFastState.Bounded env42291 := by
  intro p hp
  have h : env42291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42290_42291 : H12AffineEnvironment.transform 4 12 env42290 = env42291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env42290 == env42291) = true)

theorem identity42291 : scanCanonicalize (H12AffineFastState.compose env42291 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42292 : List Nat := [2,3,8,10,11,10,9,9,1,3,1,1,2,1,0,9,1,1,3,1,0,11,11,2,2,11,0,0,1,0,9,11,8,10,0,1]

theorem envBound42292 : H12AffineFastState.Bounded env42292 := by
  intro p hp
  have h : env42292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42291_42292 : H12AffineEnvironment.transform 1 3 env42291 = env42292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42291 == env42292) = true)

def env42293 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,65536,1296,65665,66871,277,4097,397,17,69648,70839,65831,66841,1296,69942,67603,5381,65831,257,69927,1297,66359]

theorem envBound42293 : H12AffineFastState.Bounded env42293 := by
  intro p hp
  have h : env42293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42281_42293 : H12AffineEnvironment.transform 5 17 env42281 = env42293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42281 == env42293) = true)

theorem identity42293 : scanCanonicalize (H12AffineFastState.compose env42293 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound42293 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42294 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,1330,1296,1459,5,277,4097,397,17,5410,4485,1045,43,1296,5124,3361,5381,1045,257,5141,1297,1541]

theorem envBound42294 : H12AffineFastState.Bounded env42294 := by
  intro p hp
  have h : env42294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42293_42294 : H12AffineEnvironment.transform 15 1330 env42293 = env42294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env42293 == env42294) = true)

theorem identity42294 : scanCanonicalize (H12AffineFastState.compose env42294 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42294 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42295 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4365,277,276,310,276,439,5,277,4097,397,17,4390,4485,17,43,276,4096,2341,4353,17,257,4113,277,513]

theorem envBound42295 : H12AffineFastState.Bounded env42295 := by
  intro p hp
  have h : env42295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42294_42295 : H12AffineEnvironment.transform 9 4 env42294 = env42295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42294 == env42295) = true)

theorem identity42295 : scanCanonicalize (H12AffineFastState.compose env42295 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound42295 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env42296 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,649,900,277,276,310,276,439,5,277,648,397,17,943,780,17,43,276,649,2341,904,17,257,664,277,513]

theorem envBound42296 : H12AffineFastState.Bounded env42296 := by
  intro p hp
  have h : env42296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42295_42296 : H12AffineEnvironment.transform 11 649 env42295 = env42296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env42295 == env42296) = true)

theorem identity42296 : scanCanonicalize (H12AffineFastState.compose env42296 (packedSelected [0,1,5,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound42296 : packedSelected [0,1,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env42297 : List Nat := [2,4,8,16,32,17,128,256,512,4,691,649,900,277,276,310,276,439,5,277,648,397,17,943,780,17,43,276,649,918,904,17,257,664,277,513]

theorem envBound42297 : H12AffineFastState.Bounded env42297 := by
  intro p hp
  have h : env42297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42296_42297 : H12AffineEnvironment.transform 10 691 env42296 = env42297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env42296 == env42297) = true)

theorem identity42297 : scanCanonicalize (H12AffineFastState.compose env42297 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 416) := by decide +kernel

theorem selectedBound42297 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env42298 : List Nat := [2,4,8,16,32,17,128,256,416,4,275,297,36,277,276,310,276,439,5,277,296,397,17,15,172,17,43,276,297,54,40,17,257,312,277,417]

theorem envBound42298 : H12AffineFastState.Bounded env42298 := by
  intro p hp
  have h : env42298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42297_42298 : H12AffineEnvironment.transform 8 416 env42297 = env42298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 416 env42297 == env42298) = true)

theorem identity42298 : scanCanonicalize (H12AffineFastState.compose env42298 (packedSelected [2,5,19] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound42298 : packedSelected [2,5,19] rootPS < 2^1333 := by decide +kernel

def env42299 : List Nat := [2,4,8,16,32,17,128,41,137,4,58,0,36,60,61,31,61,158,5,60,1,164,17,15,172,17,43,61,0,54,40,17,40,17,60,136]

theorem envBound42299 : H12AffineFastState.Bounded env42299 := by
  intro p hp
  have h : env42299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42298_42299 : H12AffineEnvironment.transform 7 41 env42298 = env42299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env42298 == env42299) = true)

def env42300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86519,94526,77841,1297,74815,96346,381313,308666,257,90430,1344,95102]

theorem envBound42300 : H12AffineFastState.Bounded env42300 := by
  intro p hp
  have h : env42300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42248_42300 : H12AffineEnvironment.transform 16 16465 env42248 = env42300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env42248 == env42300) = true)

def env42301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70887,78894,77841,1297,74815,81226,365713,308666,257,74798,1344,79470]

theorem envBound42301 : H12AffineFastState.Bounded env42301 := by
  intro p hp
  have h : env42301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42300_42301 : H12AffineEnvironment.transform 13 1296 env42300 = env42301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42300 == env42301) = true)

theorem identity42301 : scanCanonicalize (H12AffineFastState.compose env42301 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42301 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77934,13340,4097,477,16,266384,70887,78894,77841,1297,74815,81226,336012,262567,257,74798,1344,79470]

theorem envBound42302 : H12AffineFastState.Bounded env42302 := by
  intro p hp
  have h : env42302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42301_42302 : H12AffineEnvironment.transform 14 13341 env42301 = env42302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42301 == env42302) = true)

def env42303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77934,13340,4097,477,16,69648,70887,78894,77841,1297,74815,81226,8204,65831,257,74798,1344,79470]

theorem envBound42303 : H12AffineFastState.Bounded env42303 := by
  intro p hp
  have h : env42303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42302_42303 : H12AffineEnvironment.transform 17 65664 env42302 = env42303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42302 == env42303) = true)

theorem identity42303 : scanCanonicalize (H12AffineFastState.compose env42303 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound42303 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,65536,1345,65664,73839,9245,0,477,16,65553,66790,74799,73744,1297,74815,77131,8204,65831,257,74798,1344,75375]

theorem envBound42304 : H12AffineFastState.Bounded env42304 := by
  intro p hp
  have h : env42304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42303_42304 : H12AffineEnvironment.transform 11 1 env42303 = env42304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42303 == env42304) = true)

def env42305 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9244,65536,1297,65664,73791,9245,0,397,16,65553,66742,74799,73744,1297,74815,77083,8204,65831,257,74798,1296,75327]

theorem envBound42305 : H12AffineFastState.Bounded env42305 := by
  intro p hp
  have h : env42305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42304_42305 : H12AffineEnvironment.transform 5 16 env42304 = env42305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42304 == env42305) = true)

theorem identity42305 : scanCanonicalize (H12AffineFastState.compose env42305 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound42305 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9244,8251,1297,8379,4,9245,0,397,16,8234,9357,1044,43,1297,1028,3360,8204,8476,257,1045,1296,1540]

theorem envBound42306 : H12AffineFastState.Bounded env42306 := by
  intro p hp
  have h : env42306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42305_42306 : H12AffineEnvironment.transform 15 8251 env42305 = env42306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env42305 == env42306) = true)

theorem identity42306 : scanCanonicalize (H12AffineFastState.compose env42306 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42306 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42307 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,1,8192,276,8216,8251,277,8379,4,8217,0,397,16,8234,8329,16,43,277,0,2340,8204,8476,257,17,276,512]

theorem envBound42307 : H12AffineFastState.Bounded env42307 := by
  intro p hp
  have h : env42307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42306_42307 : H12AffineEnvironment.transform 9 4 env42306 = env42307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42306 == env42307) = true)

theorem identity42307 : scanCanonicalize (H12AffineFastState.compose env42307 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound42307 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env42308 : List Nat := [2,4,8,16,32,16,128,256,512,4,318,1,8192,276,8216,8251,277,8379,4,8217,0,397,16,8234,8329,16,43,277,0,26,8204,8476,257,17,276,512]

theorem envBound42308 : H12AffineFastState.Bounded env42308 := by
  intro p hp
  have h : env42308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42307_42308 : H12AffineEnvironment.transform 10 318 env42307 = env42308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env42307 == env42308) = true)

theorem identity42308 : scanCanonicalize (H12AffineFastState.compose env42308 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42308 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42309 : List Nat := [2,4,8,11,32,11,128,256,512,4,293,1,8192,271,8195,8224,270,8352,4,8194,0,397,11,8234,8329,11,43,270,0,1,8204,8455,257,10,271,512]

theorem envBound42309 : H12AffineFastState.Bounded env42309 := by
  intro p hp
  have h : env42309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42308_42309 : H12AffineEnvironment.transform 3 11 env42308 = env42309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42308 == env42309) = true)

theorem identity42309 : scanCanonicalize (H12AffineFastState.compose env42309 (packedSelected [0,2,4,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 295) := by decide +kernel

theorem selectedBound42309 : packedSelected [0,2,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env42310 : List Nat := [2,4,8,11,32,11,128,256,512,4,293,1,295,271,292,263,270,391,4,293,0,397,11,269,430,11,43,270,0,1,299,32,257,10,271,512]

theorem envBound42310 : H12AffineFastState.Bounded env42310 := by
  intro p hp
  have h : env42310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42309_42310 : H12AffineEnvironment.transform 12 295 env42309 = env42310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 295 env42309 == env42310) = true)

theorem identity42310 : scanCanonicalize (H12AffineFastState.compose env42310 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42310 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42311 : List Nat := [2,4,8,11,32,11,128,256,0,4,293,1,295,271,292,263,270,391,4,293,0,397,11,269,430,11,43,270,0,1,299,32,257,10,271,0]

theorem envBound42311 : H12AffineFastState.Bounded env42311 := by
  intro p hp
  have h : env42311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42310_42311 : H12AffineEnvironment.transform 8 0 env42310 = env42311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42310 == env42311) = true)

theorem identity42311 : scanCanonicalize (H12AffineFastState.compose env42311 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound42311 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env42312 : List Nat := [2,4,8,11,32,11,128,14,0,4,43,1,41,1,42,9,0,137,4,43,0,131,11,3,160,11,43,0,0,1,37,32,15,10,1,0]

theorem envBound42312 : H12AffineFastState.Bounded env42312 := by
  intro p hp
  have h : env42312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42311_42312 : H12AffineEnvironment.transform 7 14 env42311 = env42312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env42311 == env42312) = true)

theorem identity42312 : scanCanonicalize (H12AffineFastState.compose env42312 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42313 : List Nat := [2,4,8,11,11,11,128,14,0,4,0,1,2,1,1,9,0,137,4,0,0,131,11,3,139,11,0,0,0,1,14,11,15,10,1,0]

theorem envBound42313 : H12AffineFastState.Bounded env42313 := by
  intro p hp
  have h : env42313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42312_42313 : H12AffineEnvironment.transform 4 11 env42312 = env42313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42312 == env42313) = true)

theorem identity42313 : scanCanonicalize (H12AffineFastState.compose env42313 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42314 : List Nat := [2,3,8,11,11,11,128,9,0,3,0,1,2,1,1,9,0,137,3,0,0,131,11,3,139,11,0,0,0,1,9,11,8,10,1,0]

theorem envBound42314 : H12AffineFastState.Bounded env42314 := by
  intro p hp
  have h : env42314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42313_42314 : H12AffineEnvironment.transform 1 3 env42313 = env42314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42313 == env42314) = true)

theorem identity42314 : scanCanonicalize (H12AffineFastState.compose env42314 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42315 : List Nat := [2,3,8,11,11,11,8,9,0,3,0,1,2,1,1,9,0,1,3,0,0,11,11,3,3,11,0,0,0,1,9,11,8,10,1,0]

theorem envBound42315 : H12AffineFastState.Bounded env42315 := by
  intro p hp
  have h : env42315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42314_42315 : H12AffineEnvironment.transform 6 8 env42314 = env42315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42314 == env42315) = true)

def env42316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9244,65536,1296,65664,73790,9245,0,396,16,65553,66743,74799,73744,1297,74815,77082,8204,65831,257,74798,1297,75326]

theorem envBound42316 : H12AffineFastState.Bounded env42316 := by
  intro p hp
  have h : env42316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42304_42316 : H12AffineEnvironment.transform 5 17 env42304 = env42316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42304 == env42316) = true)

theorem identity42316 : scanCanonicalize (H12AffineFastState.compose env42316 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42316 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42317 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,1,8192,277,8217,65536,277,65664,73790,8216,0,396,16,65553,65714,73770,73744,276,73786,76063,8204,65831,257,73771,276,74299]

theorem envBound42317 : H12AffineFastState.Bounded env42317 := by
  intro p hp
  have h : env42317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42316_42317 : H12AffineEnvironment.transform 9 5 env42316 = env42317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42316 == env42317) = true)

theorem identity42317 : scanCanonicalize (H12AffineFastState.compose env42317 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound42317 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env42318 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,1,8192,277,8217,8250,277,8378,4,8216,0,396,16,8235,8328,16,42,276,0,2341,8204,8477,257,17,276,513]

theorem envBound42318 : H12AffineFastState.Bounded env42318 := by
  intro p hp
  have h : env42318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42317_42318 : H12AffineEnvironment.transform 15 8250 env42317 = env42318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env42317 == env42318) = true)

theorem identity42318 : scanCanonicalize (H12AffineFastState.compose env42318 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42318 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env42319 : List Nat := [2,4,8,16,32,17,128,256,33,5,2048,1,8192,277,8217,8250,277,8378,4,8216,0,396,16,8235,8328,16,42,276,0,2341,8204,8477,257,17,276,32]

theorem envBound42319 : H12AffineFastState.Bounded env42319 := by
  intro p hp
  have h : env42319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42318_42319 : H12AffineEnvironment.transform 8 33 env42318 = env42319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42318 == env42319) = true)

theorem identity42319 : scanCanonicalize (H12AffineFastState.compose env42319 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42319 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42320 : List Nat := [2,4,8,16,32,17,128,256,33,5,2048,1,269,277,276,311,277,439,4,277,0,396,16,294,389,16,42,276,0,2341,257,16,257,17,276,32]

theorem envBound42320 : H12AffineFastState.Bounded env42320 := by
  intro p hp
  have h : env42320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42319_42320 : H12AffineEnvironment.transform 12 269 env42319 = env42320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42319 == env42320) = true)

theorem identity42320 : scanCanonicalize (H12AffineFastState.compose env42320 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound42320 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env42321 : List Nat := [2,4,8,16,32,17,128,47,33,5,2048,1,34,58,59,24,58,152,4,58,0,163,16,9,170,16,42,59,0,2058,46,16,46,17,59,32]

theorem envBound42321 : H12AffineFastState.Bounded env42321 := by
  intro p hp
  have h : env42321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42320_42321 : H12AffineEnvironment.transform 7 47 env42320 = env42321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env42320 == env42321) = true)

theorem identity42321 : scanCanonicalize (H12AffineFastState.compose env42321 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 159) := by decide +kernel

theorem selectedBound42321 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42322 : List Nat := [2,4,8,16,32,17,128,47,33,5,159,1,34,58,59,24,58,152,4,58,0,163,16,9,170,16,42,59,0,149,46,16,46,17,59,32]

theorem envBound42322 : H12AffineFastState.Bounded env42322 := by
  intro p hp
  have h : env42322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42321_42322 : H12AffineEnvironment.transform 10 159 env42321 = env42322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 159 env42321 == env42322) = true)

theorem identity42322 : scanCanonicalize (H12AffineFastState.compose env42322 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42322 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env42323 : List Nat := [2,4,8,16,10,17,128,5,11,5,159,1,8,16,17,24,16,152,4,16,0,137,16,9,128,16,0,17,0,149,4,16,4,17,17,10]

theorem envBound42323 : H12AffineFastState.Bounded env42323 := by
  intro p hp
  have h : env42323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42322_42323 : H12AffineEnvironment.transform 4 10 env42322 = env42323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42322 == env42323) = true)

theorem identity42323 : scanCanonicalize (H12AffineFastState.compose env42323 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42323 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42324 : List Nat := [2,4,8,16,10,17,18,5,11,5,13,1,8,16,17,24,16,10,4,16,0,27,16,9,18,16,0,17,0,7,4,16,4,17,17,10]

theorem envBound42324 : H12AffineFastState.Bounded env42324 := by
  intro p hp
  have h : env42324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42323_42324 : H12AffineEnvironment.transform 6 18 env42323 = env42324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42323 == env42324) = true)

theorem identity42324 : scanCanonicalize (H12AffineFastState.compose env42324 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42325 : List Nat := [2,4,8,10,10,11,8,5,11,5,13,1,8,10,11,2,10,10,4,10,0,1,10,9,8,10,0,11,0,7,4,10,4,11,11,10]

theorem envBound42325 : H12AffineFastState.Bounded env42325 := by
  intro p hp
  have h : env42325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42324_42325 : H12AffineEnvironment.transform 3 10 env42324 = env42325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42324 == env42325) = true)

theorem identity42325 : scanCanonicalize (H12AffineFastState.compose env42325 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound42325 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42326 : List Nat := [2,4,1,3,3,2,1,5,2,5,4,1,1,3,2,2,3,3,4,3,0,1,3,0,1,3,0,2,0,7,4,3,4,2,2,3]

theorem envBound42326 : H12AffineFastState.Bounded env42326 := by
  intro p hp
  have h : env42326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42325_42326 : H12AffineEnvironment.transform 2 1 env42325 = env42326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env42325 == env42326) = true)

def env42327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77934,13340,4097,477,16,69649,70887,78894,77841,1297,74815,81226,8205,65830,257,74798,1344,79470]

theorem envBound42327 : H12AffineFastState.Bounded env42327 := by
  intro p hp
  have h : env42327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42302_42327 : H12AffineEnvironment.transform 17 65665 env42302 = env42327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42302 == env42327) = true)

theorem identity42327 : scanCanonicalize (H12AffineFastState.compose env42327 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound42327 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42328 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,65536,0,65665,77934,12637,4097,477,16,69649,70054,78191,77841,80,74110,79883,8205,65830,257,74095,1,78639]

theorem envBound42328 : H12AffineFastState.Bounded env42328 := by
  intro p hp
  have h : env42328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42327_42328 : H12AffineEnvironment.transform 9 321 env42327 = env42328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42327 == env42328) = true)

def env42329 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12556,65536,0,65665,77886,12557,4097,397,16,69649,70054,78143,77841,0,74030,79883,8205,65830,257,74047,1,78639]

theorem envBound42329 : H12AffineFastState.Bounded env42329 := by
  intro p hp
  have h : env42329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42328_42329 : H12AffineEnvironment.transform 5 16 env42328 = env42329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42328 == env42329) = true)

theorem identity42329 : scanCanonicalize (H12AffineFastState.compose env42329 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound42329 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42330 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12556,12346,0,12475,4,12557,4097,397,16,8235,8604,261,43,0,4372,2097,8205,12572,257,4357,1,789]

theorem envBound42330 : H12AffineFastState.Bounded env42330 := by
  intro p hp
  have h : env42330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42329_42330 : H12AffineEnvironment.transform 15 12346 env42329 = env42330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env42329 == env42330) = true)

theorem identity42330 : scanCanonicalize (H12AffineFastState.compose env42330 (packedSelected [2,3,10,23,24,26,32] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound42330 : packedSelected [2,3,10,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env42331 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,648,8192,1,9092,8882,0,8755,4,9093,649,397,16,8235,8604,261,43,0,924,2097,8205,9108,257,909,1,789]

theorem envBound42331 : H12AffineFastState.Bounded env42331 := by
  intro p hp
  have h : env42331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42330_42331 : H12AffineEnvironment.transform 11 648 env42330 = env42331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env42330 == env42331) = true)

theorem identity42331 : scanCanonicalize (H12AffineFastState.compose env42331 (packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound42331 : packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42332 : List Nat := [2,4,8,16,32,16,128,256,512,273,147,648,8192,1,9092,8882,0,8755,4,9093,649,397,16,8235,8604,261,43,0,924,162,8205,9108,257,909,1,789]

theorem envBound42332 : H12AffineFastState.Bounded env42332 := by
  intro p hp
  have h : env42332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42331_42332 : H12AffineEnvironment.transform 10 147 env42331 = env42332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env42331 == env42332) = true)

theorem identity42332 : scanCanonicalize (H12AffineFastState.compose env42332 (packedSelected [0,3,4,7,8,9,12,15,19] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound42332 : packedSelected [0,3,4,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env42333 : List Nat := [2,4,8,16,32,16,128,256,48,273,147,184,8192,1,8628,8322,0,8195,4,8629,185,397,16,8235,8604,261,43,0,428,162,8205,8612,257,445,1,293]

theorem envBound42333 : H12AffineFastState.Bounded env42333 := by
  intro p hp
  have h : env42333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42332_42333 : H12AffineEnvironment.transform 8 48 env42332 = env42333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env42332 == env42333) = true)

theorem identity42333 : scanCanonicalize (H12AffineFastState.compose env42333 (packedSelected [0,3,7,8,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound42333 : packedSelected [0,3,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env42334 : List Nat := [2,4,8,16,32,16,128,256,48,273,147,184,50,1,390,176,0,49,4,391,185,397,16,25,430,261,43,0,428,162,63,406,257,445,1,293]

theorem envBound42334 : H12AffineFastState.Bounded env42334 := by
  intro p hp
  have h : env42334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42333_42334 : H12AffineEnvironment.transform 12 50 env42333 = env42334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env42333 == env42334) = true)

theorem identity42334 : scanCanonicalize (H12AffineFastState.compose env42334 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound42334 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env42335 : List Nat := [2,4,8,16,32,16,128,183,48,166,147,184,50,1,49,176,0,49,4,48,185,58,16,25,25,178,43,0,27,162,63,33,182,10,1,146]

theorem envBound42335 : H12AffineFastState.Bounded env42335 := by
  intro p hp
  have h : env42335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42334_42335 : H12AffineEnvironment.transform 7 183 env42334 = env42335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env42334 == env42335) = true)

theorem identity42335 : scanCanonicalize (H12AffineFastState.compose env42335 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42335 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42336 : List Nat := [2,4,8,16,16,16,128,135,0,150,147,136,2,1,1,128,0,1,4,0,137,10,16,25,25,130,27,0,27,146,15,17,134,10,1,146]

theorem envBound42336 : H12AffineFastState.Bounded env42336 := by
  intro p hp
  have h : env42336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42335_42336 : H12AffineEnvironment.transform 4 16 env42335 = env42336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42335 == env42336) = true)

def env42337 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,65536,0,65665,77887,12556,4097,396,16,69649,70054,78142,77841,1,74031,79883,8205,65830,257,74046,1,78639]

theorem envBound42337 : H12AffineFastState.Bounded env42337 := by
  intro p hp
  have h : env42337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42328_42337 : H12AffineEnvironment.transform 5 17 env42328 = env42337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42328 == env42337) = true)

theorem identity42337 : scanCanonicalize (H12AffineFastState.compose env42337 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42337 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42338 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,4096,8192,0,12312,65536,0,65665,77887,12313,4097,153,16,69649,69811,77867,77841,1,73786,79883,8205,65587,20,73771,1,78394]

theorem envBound42338 : H12AffineFastState.Bounded env42338 := by
  intro p hp
  have h : env42338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42337_42338 : H12AffineEnvironment.transform 7 21 env42337 = env42338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42337 == env42338) = true)

def env42339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70886,78895,77841,1297,74815,81227,365712,308666,257,74799,1344,79471]

theorem envBound42339 : H12AffineFastState.Bounded env42339 := by
  intro p hp
  have h : env42339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42300_42339 : H12AffineEnvironment.transform 13 1297 env42300 = env42339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42300 == env42339) = true)

theorem identity42339 : scanCanonicalize (H12AffineFastState.compose env42339 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound42339 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,16,266385,38037,46172,45154,1297,42060,48440,267491,308666,257,42076,1344,46620]

theorem envBound42340 : H12AffineFastState.Bounded env42340 := by
  intro p hp
  have h : env42340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42339_42340 : H12AffineEnvironment.transform 15 32883 env42339 = env42340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env42339 == env42340) = true)

def env42341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263633,33237,41244,42274,1297,42060,43128,262563,303354,257,42076,1344,41820]

theorem envBound42341 : H12AffineFastState.Bounded env42341 := by
  intro p hp
  have h : env42341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42340_42341 : H12AffineEnvironment.transform 11 1344 env42340 = env42341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env42340 == env42341) = true)

theorem identity42341 : scanCanonicalize (H12AffineFastState.compose env42341 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound42341 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,486,42332,32769,1345,41089,16,1079,33237,41244,42274,1297,42060,43128,69,41244,257,42076,1344,41820]

theorem envBound42342 : H12AffineFastState.Bounded env42342 := by
  intro p hp
  have h : env42342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42341_42342 : H12AffineEnvironment.transform 17 486 env42341 = env42342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env42341 == env42342) = true)

theorem identity42342 : scanCanonicalize (H12AffineFastState.compose env42342 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42342 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1344,486,1024,8541,1345,477,16,1079,8329,64,1150,1297,1296,2340,69,64,257,1280,1344,512]

theorem envBound42343 : H12AffineFastState.Bounded env42343 := by
  intro p hp
  have h : env42343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42342_42343 : H12AffineEnvironment.transform 14 8540 env42342 = env42343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42342 == env42343) = true)

theorem identity42343 : scanCanonicalize (H12AffineFastState.compose env42343 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42343 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42344 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,325,8540,8495,276,486,84,8541,277,477,16,99,8329,64,42,325,324,2340,69,64,257,340,276,512]

theorem envBound42344 : H12AffineFastState.Bounded env42344 := by
  intro p hp
  have h : env42344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42343_42344 : H12AffineEnvironment.transform 9 84 env42343 = env42344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42343 == env42344) = true)

theorem identity42344 : scanCanonicalize (H12AffineFastState.compose env42344 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound42344 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42345 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,705,325,925,1006,276,486,84,924,277,477,16,99,584,64,42,325,324,2340,69,64,257,340,276,512]

theorem envBound42345 : H12AffineFastState.Bounded env42345 := by
  intro p hp
  have h : env42345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42344_42345 : H12AffineEnvironment.transform 12 705 env42344 = env42345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env42344 == env42345) = true)

theorem identity42345 : scanCanonicalize (H12AffineFastState.compose env42345 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42345 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42346 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,657,277,925,958,276,438,4,924,277,397,16,51,536,16,42,277,276,2340,21,16,257,260,276,512]

theorem envBound42346 : H12AffineFastState.Bounded env42346 := by
  intro p hp
  have h : env42346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42345_42346 : H12AffineEnvironment.transform 5 16 env42345 = env42346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42345 == env42346) = true)

theorem identity42346 : scanCanonicalize (H12AffineFastState.compose env42346 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound42346 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42347 : List Nat := [2,4,8,16,32,16,128,256,512,4,270,276,657,277,925,958,276,438,4,924,277,397,16,51,536,16,42,277,276,42,21,16,257,260,276,512]

theorem envBound42347 : H12AffineFastState.Bounded env42347 := by
  intro p hp
  have h : env42347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42346_42347 : H12AffineEnvironment.transform 10 270 env42346 = env42347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env42346 == env42347) = true)

theorem identity42347 : scanCanonicalize (H12AffineFastState.compose env42347 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42347 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42348 : List Nat := [2,4,8,16,32,16,56,256,512,4,270,276,553,277,805,774,276,270,4,804,277,309,16,51,536,16,42,277,276,42,21,16,257,260,276,512]

theorem envBound42348 : H12AffineFastState.Bounded env42348 := by
  intro p hp
  have h : env42348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42347_42348 : H12AffineEnvironment.transform 6 56 env42347 = env42348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42347 == env42348) = true)

theorem identity42348 : scanCanonicalize (H12AffineFastState.compose env42348 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound42348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42349 : List Nat := [2,4,8,16,32,16,56,256,318,4,270,276,279,277,27,56,276,270,4,26,277,309,16,51,294,16,42,277,276,42,21,16,257,260,276,318]

theorem envBound42349 : H12AffineFastState.Bounded env42349 := by
  intro p hp
  have h : env42349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42348_42349 : H12AffineEnvironment.transform 8 318 env42348 = env42349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env42348 == env42349) = true)

theorem identity42349 : scanCanonicalize (H12AffineFastState.compose env42349 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42349 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env42350 : List Nat := [2,4,8,16,32,16,56,36,26,4,42,48,51,49,27,56,48,42,4,26,49,17,16,51,2,16,42,49,48,42,21,16,37,32,48,26]

theorem envBound42350 : H12AffineFastState.Bounded env42350 := by
  intro p hp
  have h : env42350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42349_42350 : H12AffineEnvironment.transform 7 36 env42349 = env42350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42349 == env42350) = true)

def env42351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263632,33236,41245,42275,1297,42060,43129,262562,303355,257,42076,1344,41821]

theorem envBound42351 : H12AffineFastState.Bounded env42351 := by
  intro p hp
  have h : env42351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42340_42351 : H12AffineEnvironment.transform 11 1345 env42340 = env42351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env42340 == env42351) = true)

theorem identity42351 : scanCanonicalize (H12AffineFastState.compose env42351 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound42351 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,276,359,1344,262144,9289,277,1344,8596,16,263632,192,8201,9271,1297,9560,10605,262562,270831,257,9544,1344,8777]

theorem envBound42352 : H12AffineFastState.Bounded env42352 := by
  intro p hp
  have h : env42352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42351_42352 : H12AffineEnvironment.transform 14 276 env42351 = env42352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env42351 == env42352) = true)

theorem identity42352 : scanCanonicalize (H12AffineFastState.compose env42352 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound42352 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env42353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1345,8192,1297,276,359,1344,262144,9289,277,1344,8596,16,263632,192,8201,9271,1297,9560,10139,262562,270831,257,9544,1344,8777]

theorem envBound42353 : H12AffineFastState.Bounded env42353 := by
  intro p hp
  have h : env42353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42352_42353 : H12AffineEnvironment.transform 10 1782 env42352 = env42353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env42352 == env42353) = true)

def env42354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86519,209263,225345,148800,74815,96346,381312,456170,257,205167,1344,95102]

theorem envBound42354 : H12AffineFastState.Bounded env42354 := by
  intro p hp
  have h : env42354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42247_42354 : H12AffineEnvironment.transform 23 284033 env42247 = env42354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env42247 == env42354) = true)

def env42355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86519,94527,77841,1296,74815,96346,381312,308666,257,90431,1344,95102]

theorem envBound42355 : H12AffineFastState.Bounded env42355 := by
  intro p hp
  have h : env42355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42354_42355 : H12AffineEnvironment.transform 16 16464 env42354 = env42355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env42354 == env42355) = true)

def env42356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70887,78895,77841,1296,74815,81226,365712,308666,257,74799,1344,79470]

theorem envBound42356 : H12AffineFastState.Bounded env42356 := by
  intro p hp
  have h : env42356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42355_42356 : H12AffineEnvironment.transform 13 1296 env42355 = env42356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42355 == env42356) = true)

theorem identity42356 : scanCanonicalize (H12AffineFastState.compose env42356 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound42356 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,17,266385,38037,46173,45155,1296,42061,48440,267490,308666,257,42077,1344,46620]

theorem envBound42357 : H12AffineFastState.Bounded env42357 := by
  intro p hp
  have h : env42357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42356_42357 : H12AffineEnvironment.transform 15 32882 env42356 = env42357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env42356 == env42357) = true)

def env42358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263633,33237,41245,42275,1296,42061,43128,262562,303354,257,42077,1344,41820]

theorem envBound42358 : H12AffineFastState.Bounded env42358 := by
  intro p hp
  have h : env42358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42357_42358 : H12AffineEnvironment.transform 11 1344 env42357 = env42358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env42357 == env42358) = true)

theorem identity42358 : scanCanonicalize (H12AffineFastState.compose env42358 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound42358 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,9454,42332,32769,1345,41088,17,8511,33237,41245,42275,1296,42061,43128,9548,33812,257,42077,1344,41820]

theorem envBound42359 : H12AffineFastState.Bounded env42359 := by
  intro p hp
  have h : env42359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42358_42359 : H12AffineEnvironment.transform 17 9454 env42358 = env42359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env42358 == env42359) = true)

theorem identity42359 : scanCanonicalize (H12AffineFastState.compose env42359 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound42359 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env42360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1344,8192,1296,32768,32882,1344,9454,42332,32769,1345,41088,17,8511,33237,41245,42275,1296,42061,42638,9548,33812,257,42077,1344,41820]

theorem envBound42360 : H12AffineFastState.Bounded env42360 := by
  intro p hp
  have h : env42360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42359_42360 : H12AffineEnvironment.transform 10 1782 env42359 = env42360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env42359 == env42360) = true)

def env42361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263632,33236,41244,42274,1296,42061,43129,262563,303355,257,42077,1344,41821]

theorem envBound42361 : H12AffineFastState.Bounded env42361 := by
  intro p hp
  have h : env42361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42357_42361 : H12AffineEnvironment.transform 11 1345 env42357 = env42361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env42357 == env42361) = true)

theorem identity42361 : scanCanonicalize (H12AffineFastState.compose env42361 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound42361 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9245,9327,1344,262144,320,9244,1344,1180,17,263632,9673,1281,319,1296,80,3172,262563,263398,257,64,1344,1856]

theorem envBound42362 : H12AffineFastState.Bounded env42362 := by
  intro p hp
  have h : env42362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42361_42362 : H12AffineEnvironment.transform 14 9245 env42361 = env42362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env42361 == env42362) = true)

theorem identity42362 : scanCanonicalize (H12AffineFastState.compose env42362 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound42362 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42363 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8541,8495,0,262144,320,8540,0,476,17,262288,8329,65,319,80,80,2340,262563,262566,257,64,0,512]

theorem envBound42363 : H12AffineFastState.Bounded env42363 := by
  intro p hp
  have h : env42363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42362_42363 : H12AffineEnvironment.transform 9 320 env42362 = env42363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42362 == env42363) = true)

theorem identity42363 : scanCanonicalize (H12AffineFastState.compose env42363 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42363 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42364 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,8192,80,8265,8251,0,262144,84,8264,0,200,17,262288,8329,65,43,80,80,2096,262327,262322,21,64,0,512]

theorem envBound42364 : H12AffineFastState.Bounded env42364 := by
  intro p hp
  have h : env42364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42363_42364 : H12AffineEnvironment.transform 7 20 env42363 = env42364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42363 == env42364) = true)

theorem identity42364 : scanCanonicalize (H12AffineFastState.compose env42364 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound42364 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42365 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,8192,80,8265,8251,0,8754,84,8264,0,200,17,8866,8329,65,43,80,80,2096,8837,8832,21,64,0,512]

theorem envBound42365 : H12AffineFastState.Bounded env42365 := by
  intro p hp
  have h : env42365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42364_42365 : H12AffineEnvironment.transform 17 8754 env42364 = env42365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env42364 == env42365) = true)

theorem identity42365 : scanCanonicalize (H12AffineFastState.compose env42365 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42365 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42366 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,0,8217,8251,0,8754,4,8216,0,152,17,8866,8329,17,43,0,0,2096,8837,8832,21,16,0,512]

theorem envBound42366 : H12AffineFastState.Bounded env42366 := by
  intro p hp
  have h : env42366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42365_42366 : H12AffineEnvironment.transform 5 16 env42365 = env42366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42365 == env42366) = true)

theorem identity42366 : scanCanonicalize (H12AffineFastState.compose env42366 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound42366 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42367 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,2563,0,2586,2616,0,2097,4,2587,0,152,17,2209,2698,17,43,0,0,2096,2182,2179,21,16,0,512]

theorem envBound42367 : H12AffineFastState.Bounded env42367 := by
  intro p hp
  have h : env42367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42366_42367 : H12AffineEnvironment.transform 12 2563 env42366 = env42367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env42366 == env42367) = true)

theorem identity42367 : scanCanonicalize (H12AffineFastState.compose env42367 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound42367 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42368 : List Nat := [2,4,8,16,32,16,128,20,512,4,147,1,656,0,649,683,0,162,4,648,0,152,17,50,537,17,43,0,0,163,21,16,21,16,0,512]

theorem envBound42368 : H12AffineFastState.Bounded env42368 := by
  intro p hp
  have h : env42368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42367_42368 : H12AffineEnvironment.transform 10 147 env42367 = env42368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env42367 == env42368) = true)

theorem identity42368 : scanCanonicalize (H12AffineFastState.compose env42368 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound42368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42369 : List Nat := [2,4,8,16,32,16,128,20,143,4,147,1,31,0,6,36,0,162,4,7,0,152,17,50,150,17,43,0,0,163,21,16,21,16,0,143]

theorem envBound42369 : H12AffineFastState.Bounded env42369 := by
  intro p hp
  have h : env42369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42368_42369 : H12AffineEnvironment.transform 8 143 env42368 = env42369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env42368 == env42369) = true)

theorem identity42369 : scanCanonicalize (H12AffineFastState.compose env42369 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42369 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42370 : List Nat := [2,4,8,16,32,16,56,20,55,4,43,1,31,0,6,36,0,26,4,7,0,32,17,50,46,17,43,0,0,27,21,16,21,16,0,55]

theorem envBound42370 : H12AffineFastState.Bounded env42370 := by
  intro p hp
  have h : env42370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42369_42370 : H12AffineEnvironment.transform 6 56 env42369 = env42370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42369 == env42370) = true)

theorem identity42370 : scanCanonicalize (H12AffineFastState.compose env42370 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42371 : List Nat := [2,4,8,11,32,11,35,15,44,4,43,1,4,0,6,36,0,1,4,7,0,32,10,41,46,10,43,0,0,0,14,11,14,11,0,44]

theorem envBound42371 : H12AffineFastState.Bounded env42371 := by
  intro p hp
  have h : env42371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42370_42371 : H12AffineEnvironment.transform 3 11 env42370 = env42371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42370 == env42371) = true)

theorem identity42371 : scanCanonicalize (H12AffineFastState.compose env42371 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42372 : List Nat := [2,4,8,11,13,11,14,15,1,4,6,1,4,0,6,9,0,1,4,7,0,13,10,4,3,10,6,0,0,0,14,11,14,11,0,1]

theorem envBound42372 : H12AffineFastState.Bounded env42372 := by
  intro p hp
  have h : env42372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42371_42372 : H12AffineEnvironment.transform 4 13 env42371 = env42372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42371 == env42372) = true)

theorem identity42372 : scanCanonicalize (H12AffineFastState.compose env42372 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42373 : List Nat := [2,3,8,11,10,11,9,8,1,3,1,1,3,0,1,9,0,1,3,0,0,10,10,3,3,10,1,0,0,0,9,11,9,11,0,1]

theorem envBound42373 : H12AffineFastState.Bounded env42373 := by
  intro p hp
  have h : env42373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42372_42373 : H12AffineEnvironment.transform 1 3 env42372 = env42373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42372 == env42373) = true)

def env42374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70886,78894,77841,1296,74815,81227,365713,308666,257,74798,1344,79471]

theorem envBound42374 : H12AffineFastState.Bounded env42374 := by
  intro p hp
  have h : env42374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42355_42374 : H12AffineEnvironment.transform 13 1297 env42355 = env42374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42355 == env42374) = true)

theorem identity42374 : scanCanonicalize (H12AffineFastState.compose env42374 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42374 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77935,13340,4097,476,17,266384,70886,78894,77841,1296,74815,81227,336012,262567,257,74798,1344,79471]

theorem envBound42375 : H12AffineFastState.Bounded env42375 := by
  intro p hp
  have h : env42375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42374_42375 : H12AffineEnvironment.transform 14 13341 env42374 = env42375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42374 == env42375) = true)

def env42376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77935,13340,4097,476,17,69648,70886,78894,77841,1296,74815,81227,8204,65831,257,74798,1344,79471]

theorem envBound42376 : H12AffineFastState.Bounded env42376 := by
  intro p hp
  have h : env42376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42375_42376 : H12AffineEnvironment.transform 17 65664 env42375 = env42376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42375 == env42376) = true)

theorem identity42376 : scanCanonicalize (H12AffineFastState.compose env42376 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound42376 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,359,1345,487,12552,13340,4097,476,17,4471,5505,13641,12662,1296,9560,15404,8204,64,257,9545,1344,14088]

theorem envBound42377 : H12AffineFastState.Bounded env42377 := by
  intro p hp
  have h : env42377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42376_42377 : H12AffineEnvironment.transform 15 359 env42376 = env42377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env42376 == env42377) = true)

def env42378 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,311,1297,439,12552,13340,4097,396,17,4391,5505,13593,12582,1296,9480,15404,8204,16,257,9497,1296,14088]

theorem envBound42378 : H12AffineFastState.Bounded env42378 := by
  intro p hp
  have h : env42378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42377_42378 : H12AffineEnvironment.transform 5 16 env42377 = env42378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42377 == env42378) = true)

theorem identity42378 : scanCanonicalize (H12AffineFastState.compose env42378 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42378 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42379 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,8192,277,12313,311,277,439,12552,12312,4097,396,17,4391,4485,12573,12582,276,8460,14376,8204,16,257,8477,276,13068]

theorem envBound42379 : H12AffineFastState.Bounded env42379 := by
  intro p hp
  have h : env42379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42378_42379 : H12AffineEnvironment.transform 9 4 env42378 = env42379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42378 == env42379) = true)

theorem identity42379 : scanCanonicalize (H12AffineFastState.compose env42379 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound42379 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env42380 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4364,277,277,311,277,439,4,276,4097,396,17,4391,4485,17,42,276,4096,2340,4352,16,257,4113,276,512]

theorem envBound42380 : H12AffineFastState.Bounded env42380 := by
  intro p hp
  have h : env42380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42379_42380 : H12AffineEnvironment.transform 12 4364 env42379 = env42380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env42379 == env42380) = true)

theorem identity42380 : scanCanonicalize (H12AffineFastState.compose env42380 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound42380 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env42381 : List Nat := [2,4,8,16,32,16,128,256,512,4,782,4096,4364,277,277,311,277,439,4,276,4097,396,17,4391,4485,17,42,276,4096,554,4352,16,257,4113,276,512]

theorem envBound42381 : H12AffineFastState.Bounded env42381 := by
  intro p hp
  have h : env42381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42380_42381 : H12AffineEnvironment.transform 10 782 env42380 = env42381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env42380 == env42381) = true)

theorem identity42381 : scanCanonicalize (H12AffineFastState.compose env42381 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound42381 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env42382 : List Nat := [2,4,8,16,32,16,128,256,163,4,429,4096,4364,277,277,311,277,439,4,276,4097,396,17,4391,4485,17,42,276,4096,137,4352,16,257,4113,276,163]

theorem envBound42382 : H12AffineFastState.Bounded env42382 := by
  intro p hp
  have h : env42382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42381_42382 : H12AffineEnvironment.transform 8 163 env42381 = env42382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env42381 == env42382) = true)

theorem identity42382 : scanCanonicalize (H12AffineFastState.compose env42382 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound42382 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env42383 : List Nat := [2,4,8,16,32,16,128,256,163,4,429,146,414,277,277,311,277,439,4,276,147,396,17,437,279,17,42,276,146,137,402,16,257,131,276,163]

theorem envBound42383 : H12AffineFastState.Bounded env42383 := by
  intro p hp
  have h : env42383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42382_42383 : H12AffineEnvironment.transform 11 146 env42382 = env42383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env42382 == env42383) = true)

theorem identity42383 : scanCanonicalize (H12AffineFastState.compose env42383 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound42383 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env42384 : List Nat := [2,4,8,16,32,16,19,256,48,4,318,1,269,277,277,311,277,292,4,276,0,287,17,294,279,17,42,276,1,26,257,16,257,16,276,48]

theorem envBound42384 : H12AffineFastState.Bounded env42384 := by
  intro p hp
  have h : env42384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42383_42384 : H12AffineEnvironment.transform 6 19 env42383 = env42384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env42383 == env42384) = true)

theorem identity42384 : scanCanonicalize (H12AffineFastState.compose env42384 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound42384 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env42385 : List Nat := [2,4,8,16,28,16,19,256,12,4,258,1,269,277,277,267,277,280,4,276,0,287,17,282,279,17,22,276,1,26,257,16,257,16,276,12]

theorem envBound42385 : H12AffineFastState.Bounded env42385 := by
  intro p hp
  have h : env42385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42384_42385 : H12AffineEnvironment.transform 4 28 env42384 = env42385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env42384 == env42385) = true)

theorem identity42385 : scanCanonicalize (H12AffineFastState.compose env42385 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound42385 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42386 : List Nat := [2,4,8,16,28,16,19,3,12,4,1,1,14,22,22,8,22,27,4,23,0,28,17,25,20,17,22,23,1,26,2,16,2,16,23,12]

theorem envBound42386 : H12AffineFastState.Bounded env42386 := by
  intro p hp
  have h : env42386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42385_42386 : H12AffineEnvironment.transform 7 3 env42385 = env42386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env42385 == env42386) = true)

theorem identity42386 : scanCanonicalize (H12AffineFastState.compose env42386 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42386 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42387 : List Nat := [2,4,8,10,6,10,9,3,12,4,1,1,14,12,12,8,12,1,4,13,0,6,11,3,14,11,12,13,1,0,2,10,2,10,13,12]

theorem envBound42387 : H12AffineFastState.Bounded env42387 := by
  intro p hp
  have h : env42387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42386_42387 : H12AffineEnvironment.transform 3 10 env42386 = env42387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42386 == env42387) = true)

theorem identity42387 : scanCanonicalize (H12AffineFastState.compose env42387 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42387 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42388 : List Nat := [2,4,4,6,6,6,5,3,0,4,1,1,2,0,0,4,0,1,4,1,0,6,7,3,2,7,0,1,1,0,2,6,2,6,1,0]

theorem envBound42388 : H12AffineFastState.Bounded env42388 := by
  intro p hp
  have h : env42388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42387_42388 : H12AffineEnvironment.transform 2 4 env42387 = env42388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42387 == env42388) = true)

def env42389 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,310,1296,438,12552,13340,4097,397,17,4390,5505,13592,12583,1296,9481,15404,8204,17,257,9496,1297,14088]

theorem envBound42389 : H12AffineFastState.Bounded env42389 := by
  intro p hp
  have h : env42389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42377_42389 : H12AffineEnvironment.transform 5 17 env42377 = env42389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42377 == env42389) = true)

theorem identity42389 : scanCanonicalize (H12AffineFastState.compose env42389 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound42389 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42390 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4365,1297,1296,310,1296,438,5,1297,4097,397,17,4390,5505,1045,42,1296,5124,3361,4353,17,257,5141,1297,1541]

theorem envBound42390 : H12AffineFastState.Bounded env42390 := by
  intro p hp
  have h : env42390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42389_42390 : H12AffineEnvironment.transform 12 4365 env42389 = env42390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env42389 == env42390) = true)

theorem identity42390 : scanCanonicalize (H12AffineFastState.compose env42390 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42390 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42391 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4365,277,276,310,276,438,5,277,4097,397,17,4390,4485,17,42,276,4096,2341,4353,17,257,4113,277,513]

theorem envBound42391 : H12AffineFastState.Bounded env42391 := by
  intro p hp
  have h : env42391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42390_42391 : H12AffineEnvironment.transform 9 4 env42390 = env42391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42390 == env42391) = true)

theorem identity42391 : scanCanonicalize (H12AffineFastState.compose env42391 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound42391 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env42392 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,649,900,277,276,310,276,438,5,277,648,397,17,943,780,17,42,276,649,2341,904,17,257,664,277,513]

theorem envBound42392 : H12AffineFastState.Bounded env42392 := by
  intro p hp
  have h : env42392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42391_42392 : H12AffineEnvironment.transform 11 649 env42391 = env42392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env42391 == env42392) = true)

theorem identity42392 : scanCanonicalize (H12AffineFastState.compose env42392 (packedSelected [0,1,5,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound42392 : packedSelected [0,1,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env42393 : List Nat := [2,4,8,16,32,17,128,256,512,4,691,649,900,277,276,310,276,438,5,277,648,397,17,943,780,17,42,276,649,918,904,17,257,664,277,513]

theorem envBound42393 : H12AffineFastState.Bounded env42393 := by
  intro p hp
  have h : env42393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42392_42393 : H12AffineEnvironment.transform 10 691 env42392 = env42393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env42392 == env42393) = true)

theorem identity42393 : scanCanonicalize (H12AffineFastState.compose env42393 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 181) := by decide +kernel

theorem selectedBound42393 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env42394 : List Nat := [2,4,8,16,32,17,128,256,181,4,6,60,305,277,276,310,276,438,5,277,61,397,17,282,441,17,42,276,60,291,317,17,257,45,277,180]

theorem envBound42394 : H12AffineFastState.Bounded env42394 := by
  intro p hp
  have h : env42394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42393_42394 : H12AffineEnvironment.transform 8 181 env42393 = env42394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 181 env42393 == env42394) = true)

theorem identity42394 : scanCanonicalize (H12AffineFastState.compose env42394 (packedSelected [2,5,19] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound42394 : packedSelected [2,5,19] rootPS < 2^1333 := by decide +kernel

def env42395 : List Nat := [2,4,8,16,28,17,128,256,137,4,6,0,269,277,276,266,276,394,5,277,1,397,17,282,389,17,22,276,0,287,257,17,257,17,277,136]

theorem envBound42395 : H12AffineFastState.Bounded env42395 := by
  intro p hp
  have h : env42395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42394_42395 : H12AffineEnvironment.transform 4 28 env42394 = env42395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env42394 == env42395) = true)

theorem identity42395 : scanCanonicalize (H12AffineFastState.compose env42395 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42395 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env42396 : List Nat := [2,4,8,1,13,0,128,256,137,4,6,0,269,260,261,266,261,394,5,260,1,397,0,267,389,0,7,261,0,270,257,0,257,0,260,136]

theorem envBound42396 : H12AffineFastState.Bounded env42396 := by
  intro p hp
  have h : env42396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42395_42396 : H12AffineEnvironment.transform 3 1 env42395 = env42396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42395 == env42396) = true)

theorem identity42396 : scanCanonicalize (H12AffineFastState.compose env42396 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42396 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42397 : List Nat := [2,4,8,1,13,0,128,5,137,4,6,0,8,1,0,15,0,143,5,1,1,136,0,14,128,0,7,0,0,11,4,0,4,0,1,136]

theorem envBound42397 : H12AffineFastState.Bounded env42397 := by
  intro p hp
  have h : env42397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42396_42397 : H12AffineEnvironment.transform 7 5 env42396 = env42397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42396 == env42397) = true)

theorem identity42397 : scanCanonicalize (H12AffineFastState.compose env42397 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound42397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42398 : List Nat := [2,4,8,1,13,0,2,5,11,4,6,0,8,1,0,15,0,13,5,1,1,10,0,14,2,0,7,0,0,11,4,0,4,0,1,10]

theorem envBound42398 : H12AffineFastState.Bounded env42398 := by
  intro p hp
  have h : env42398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42397_42398 : H12AffineEnvironment.transform 6 2 env42397 = env42398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env42397 == env42398) = true)

def env42399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77935,13340,4097,476,17,69649,70886,78894,77841,1296,74815,81227,8205,65830,257,74798,1344,79471]

theorem envBound42399 : H12AffineFastState.Bounded env42399 := by
  intro p hp
  have h : env42399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42375_42399 : H12AffineEnvironment.transform 17 65665 env42375 = env42399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42375 == env42399) = true)

theorem identity42399 : scanCanonicalize (H12AffineFastState.compose env42399 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound42399 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5159,1345,5286,9288,13340,4097,476,17,1078,193,8201,9270,1296,12312,10604,8205,5377,257,12297,1344,8776]

theorem envBound42400 : H12AffineFastState.Bounded env42400 := by
  intro p hp
  have h : env42400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42399_42400 : H12AffineEnvironment.transform 15 5159 env42399 = env42400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env42399 == env42400) = true)

def env42401 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5159,1297,5286,9240,13340,4097,396,17,1078,145,8201,9270,1296,12312,10556,8205,5377,257,12297,1296,8728]

theorem envBound42401 : H12AffineFastState.Bounded env42401 := by
  intro p hp
  have h : env42401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42400_42401 : H12AffineEnvironment.transform 5 16 env42400 = env42401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42400 == env42401) = true)

theorem identity42401 : scanCanonicalize (H12AffineFastState.compose env42401 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42401 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42402 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,8192,277,12313,4131,277,4258,8220,12312,4097,396,17,50,145,8201,8242,276,12312,10556,8205,4357,257,12297,276,8728]

theorem envBound42402 : H12AffineFastState.Bounded env42402 := by
  intro p hp
  have h : env42402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42401_42402 : H12AffineEnvironment.transform 9 4 env42401 = env42402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42401 == env42402) = true)

theorem identity42402 : scanCanonicalize (H12AffineFastState.compose env42402 (packedSelected [2,3,10,13,21,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound42402 : packedSelected [2,3,10,13,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env42403 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,657,277,4744,4131,277,4258,653,4745,4097,396,17,50,145,664,675,276,4745,2989,668,4357,257,4760,276,137]

theorem envBound42403 : H12AffineFastState.Bounded env42403 := by
  intro p hp
  have h : env42403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42402_42403 : H12AffineEnvironment.transform 12 657 env42402 = env42403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env42402 == env42403) = true)

theorem identity42403 : scanCanonicalize (H12AffineFastState.compose env42403 (packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound42403 : packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42404 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,2194,657,277,2586,2225,277,2096,653,2587,2195,396,17,50,145,664,675,276,2587,2989,668,2455,257,2570,276,137]

theorem envBound42404 : H12AffineFastState.Bounded env42404 := by
  intro p hp
  have h : env42404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42403_42404 : H12AffineEnvironment.transform 11 2194 env42403 = env42404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env42403 == env42404) = true)

theorem identity42404 : scanCanonicalize (H12AffineFastState.compose env42404 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,18,21] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound42404 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env42405 : List Nat := [2,4,8,16,32,16,128,256,512,4,391,277,657,277,925,310,277,439,653,924,276,396,17,50,145,664,675,276,924,554,668,16,257,909,276,137]

theorem envBound42405 : H12AffineFastState.Bounded env42405 := by
  intro p hp
  have h : env42405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42404_42405 : H12AffineEnvironment.transform 10 391 env42404 = env42405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env42404 == env42405) = true)

theorem identity42405 : scanCanonicalize (H12AffineFastState.compose env42405 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42405 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env42406 : List Nat := [2,4,8,16,16,16,128,256,512,4,391,277,657,277,925,262,277,391,653,924,276,396,17,2,145,664,659,276,924,538,668,16,257,909,276,137]

theorem envBound42406 : H12AffineFastState.Bounded env42406 := by
  intro p hp
  have h : env42406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42405_42406 : H12AffineEnvironment.transform 4 16 env42405 = env42406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42405 == env42406) = true)

theorem identity42406 : scanCanonicalize (H12AffineFastState.compose env42406 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound42406 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env42407 : List Nat := [2,4,8,16,16,16,128,256,26,4,391,277,139,277,391,262,277,391,151,390,276,396,17,2,145,130,137,276,390,0,134,16,257,407,276,137]

theorem envBound42407 : H12AffineFastState.Bounded env42407 := by
  intro p hp
  have h : env42407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42406_42407 : H12AffineEnvironment.transform 8 26 env42406 = env42407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env42406 == env42407) = true)

theorem identity42407 : scanCanonicalize (H12AffineFastState.compose env42407 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound42407 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env42408 : List Nat := [2,4,8,16,16,16,128,15,26,4,136,26,139,26,136,9,26,136,151,137,27,131,17,2,145,130,137,27,137,0,134,16,14,152,27,137]

theorem envBound42408 : H12AffineFastState.Bounded env42408 := by
  intro p hp
  have h : env42408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42407_42408 : H12AffineEnvironment.transform 7 15 env42407 = env42408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env42407 == env42408) = true)

theorem identity42408 : scanCanonicalize (H12AffineFastState.compose env42408 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42409 : List Nat := [2,4,8,10,10,10,128,15,0,4,136,0,139,0,136,9,0,136,141,137,1,131,11,2,139,130,137,1,137,0,134,10,14,130,1,137]

theorem envBound42409 : H12AffineFastState.Bounded env42409 := by
  intro p hp
  have h : env42409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42408_42409 : H12AffineEnvironment.transform 3 10 env42408 = env42409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42408 == env42409) = true)

theorem identity42409 : scanCanonicalize (H12AffineFastState.compose env42409 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42409 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env42410 : List Nat := [2,2,8,10,10,10,128,9,0,2,136,0,139,0,136,9,0,136,139,137,1,131,11,2,139,130,137,1,137,0,128,10,8,130,1,137]

theorem envBound42410 : H12AffineFastState.Bounded env42410 := by
  intro p hp
  have h : env42410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42409_42410 : H12AffineEnvironment.transform 1 2 env42409 = env42410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42409 == env42410) = true)

theorem identity42410 : scanCanonicalize (H12AffineFastState.compose env42410 (packedSelected [0,1,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42410 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env42411 : List Nat := [2,2,8,10,10,10,9,9,0,2,1,0,2,0,1,9,0,1,2,0,1,10,11,2,2,11,0,1,0,0,9,10,8,11,1,0]

theorem envBound42411 : H12AffineFastState.Bounded env42411 := by
  intro p hp
  have h : env42411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42410_42411 : H12AffineEnvironment.transform 6 9 env42410 = env42411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42410 == env42411) = true)

def env42412 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5159,1296,5286,9241,13340,4097,397,17,1078,144,8201,9270,1296,12312,10557,8205,5377,257,12297,1297,8729]

theorem envBound42412 : H12AffineFastState.Bounded env42412 := by
  intro p hp
  have h : env42412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42400_42412 : H12AffineEnvironment.transform 5 17 env42400 = env42412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42400 == env42412) = true)

theorem identity42412 : scanCanonicalize (H12AffineFastState.compose env42412 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound42412 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42413 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,1297,4097,5159,1296,5286,5,4096,4097,397,17,1078,144,1045,42,1296,5124,3361,1041,5377,257,5141,1297,1541]

theorem envBound42413 : H12AffineFastState.Bounded env42413 := by
  intro p hp
  have h : env42413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42412_42413 : H12AffineEnvironment.transform 12 1052 env42412 = env42413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env42412 == env42413) = true)

def env42414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86519,94526,77840,1297,74815,96346,381312,308667,257,90430,1344,95102]

theorem envBound42414 : H12AffineFastState.Bounded env42414 := by
  intro p hp
  have h : env42414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42354_42414 : H12AffineEnvironment.transform 16 16465 env42354 = env42414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env42354 == env42414) = true)

def env42415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70887,78894,77840,1297,74815,81226,365712,308667,257,74798,1344,79470]

theorem envBound42415 : H12AffineFastState.Bounded env42415 := by
  intro p hp
  have h : env42415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42414_42415 : H12AffineEnvironment.transform 13 1296 env42414 = env42415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42414 == env42415) = true)

theorem identity42415 : scanCanonicalize (H12AffineFastState.compose env42415 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42415 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77934,13340,4097,477,16,266385,70887,78894,77840,1297,74815,81226,336013,262566,257,74798,1344,79470]

theorem envBound42416 : H12AffineFastState.Bounded env42416 := by
  intro p hp
  have h : env42416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42415_42416 : H12AffineEnvironment.transform 14 13341 env42415 = env42416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42415 == env42416) = true)

def env42417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77934,13340,4097,477,16,69649,70887,78894,77840,1297,74815,81226,8205,65830,257,74798,1344,79470]

theorem envBound42417 : H12AffineFastState.Bounded env42417 := by
  intro p hp
  have h : env42417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42416_42417 : H12AffineEnvironment.transform 17 65664 env42416 = env42417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42416 == env42417) = true)

theorem identity42417 : scanCanonicalize (H12AffineFastState.compose env42417 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound42417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12590,1345,12718,320,13340,4097,477,16,8511,9673,1280,318,1297,5393,3172,8205,12296,257,5376,1344,1856]

theorem envBound42418 : H12AffineFastState.Bounded env42418 := by
  intro p hp
  have h : env42418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42417_42418 : H12AffineEnvironment.transform 15 12590 env42417 = env42418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env42417 == env42418) = true)

def env42419 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12590,1,12718,320,12636,4097,477,16,8511,8329,64,318,81,4177,2340,8205,12296,257,4160,0,512]

theorem envBound42419 : H12AffineFastState.Bounded env42419 := by
  intro p hp
  have h : env42419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42418_42419 : H12AffineEnvironment.transform 9 320 env42418 = env42419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42418 == env42419) = true)

theorem identity42419 : scanCanonicalize (H12AffineFastState.compose env42419 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42419 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42420 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,4096,8192,80,12361,12346,1,12474,84,12360,4097,201,16,8235,8329,64,42,81,4177,2096,8205,12296,21,4160,0,512]

theorem envBound42420 : H12AffineFastState.Bounded env42420 := by
  intro p hp
  have h : env42420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42419_42420 : H12AffineEnvironment.transform 7 20 env42419 = env42420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42419 == env42420) = true)

theorem identity42420 : scanCanonicalize (H12AffineFastState.compose env42420 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42420 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42421 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,8192,0,12313,12346,1,12474,4,12312,4097,153,16,8235,8329,16,42,1,4097,2096,8205,12296,21,4112,0,512]

theorem envBound42421 : H12AffineFastState.Bounded env42421 := by
  intro p hp
  have h : env42421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42420_42421 : H12AffineEnvironment.transform 5 16 env42420 = env42421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42420 == env42421) = true)

theorem identity42421 : scanCanonicalize (H12AffineFastState.compose env42421 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound42421 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env42422 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,2091,8192,0,10290,10257,1,10385,4,10291,2090,153,16,8235,8329,16,42,1,2090,2096,8205,10275,21,2107,0,512]

theorem envBound42422 : H12AffineFastState.Bounded env42422 := by
  intro p hp
  have h : env42422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42421_42422 : H12AffineEnvironment.transform 11 2091 env42421 = env42422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env42421 == env42422) = true)

theorem identity42422 : scanCanonicalize (H12AffineFastState.compose env42422 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound42422 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42423 : List Nat := [2,4,8,16,32,16,128,20,512,4,49,26,8192,0,8195,8224,1,8352,4,8194,27,153,16,8235,8329,16,42,1,27,1,8205,8210,21,10,0,512]

theorem envBound42423 : H12AffineFastState.Bounded env42423 := by
  intro p hp
  have h : env42423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42422_42423 : H12AffineEnvironment.transform 10 49 env42422 = env42423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env42422 == env42423) = true)

theorem identity42423 : scanCanonicalize (H12AffineFastState.compose env42423 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound42423 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env42424 : List Nat := [2,4,8,16,32,16,128,20,512,4,49,26,562,0,561,530,1,658,4,560,27,153,16,537,699,16,42,1,27,1,575,544,21,10,0,512]

theorem envBound42424 : H12AffineFastState.Bounded env42424 := by
  intro p hp
  have h : env42424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42423_42424 : H12AffineEnvironment.transform 12 562 env42423 = env42424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env42423 == env42424) = true)

theorem identity42424 : scanCanonicalize (H12AffineFastState.compose env42424 (packedSelected [1,2,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound42424 : packedSelected [1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env42425 : List Nat := [2,4,8,16,32,16,128,20,184,4,49,26,138,0,137,170,1,42,4,136,27,153,16,161,3,16,42,1,27,1,135,152,21,10,0,184]

theorem envBound42425 : H12AffineFastState.Bounded env42425 := by
  intro p hp
  have h : env42425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42424_42425 : H12AffineEnvironment.transform 8 184 env42424 = env42425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env42424 == env42425) = true)

theorem identity42425 : scanCanonicalize (H12AffineFastState.compose env42425 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound42425 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42426 : List Nat := [2,4,8,16,32,16,34,20,26,4,49,26,40,0,43,8,1,42,4,42,27,59,16,3,3,16,42,1,27,1,37,58,21,10,0,26]

theorem envBound42426 : H12AffineFastState.Bounded env42426 := by
  intro p hp
  have h : env42426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42425_42426 : H12AffineEnvironment.transform 6 34 env42425 = env42426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env42425 == env42426) = true)

theorem identity42426 : scanCanonicalize (H12AffineFastState.compose env42426 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42426 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env42427 : List Nat := [2,4,8,16,16,16,18,20,26,4,1,26,24,0,27,8,1,26,4,26,27,11,16,3,3,16,26,1,27,1,21,10,21,10,0,26]

theorem envBound42427 : H12AffineFastState.Bounded env42427 := by
  intro p hp
  have h : env42427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42426_42427 : H12AffineEnvironment.transform 4 16 env42426 = env42427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42426 == env42427) = true)

theorem identity42427 : scanCanonicalize (H12AffineFastState.compose env42427 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42428 : List Nat := [2,4,4,16,16,16,18,20,22,4,1,22,20,0,23,4,1,22,4,22,23,7,16,3,3,16,22,1,23,1,21,6,21,6,0,22]

theorem envBound42428 : H12AffineFastState.Bounded env42428 := by
  intro p hp
  have h : env42428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42427_42428 : H12AffineEnvironment.transform 2 4 env42427 = env42428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42427 == env42428) = true)

theorem identity42428 : scanCanonicalize (H12AffineFastState.compose env42428 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound42428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42429 : List Nat := [2,4,4,6,6,6,4,2,0,4,1,0,2,0,1,4,1,0,4,0,1,7,6,3,3,6,0,1,1,1,3,6,3,6,0,0]

theorem envBound42429 : H12AffineFastState.Bounded env42429 := by
  intro p hp
  have h : env42429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42428_42429 : H12AffineEnvironment.transform 3 6 env42428 = env42429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env42428 == env42429) = true)

def env42430 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12590,0,12718,320,12637,4097,477,16,8511,8328,65,318,80,4176,2341,8205,12296,257,4161,1,513]

theorem envBound42430 : H12AffineFastState.Bounded env42430 := by
  intro p hp
  have h : env42430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42418_42430 : H12AffineEnvironment.transform 9 321 env42418 = env42430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42418 == env42430) = true)

theorem identity42430 : scanCanonicalize (H12AffineFastState.compose env42430 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound42430 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42431 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,8192,81,12312,12394,0,12522,4,12313,4097,153,16,8315,8328,65,122,80,4176,2145,8205,12296,69,4161,1,513]

theorem envBound42431 : H12AffineFastState.Bounded env42431 := by
  intro p hp
  have h : env42431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42430_42431 : H12AffineEnvironment.transform 7 68 env42430 = env42431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env42430 == env42431) = true)

theorem identity42431 : scanCanonicalize (H12AffineFastState.compose env42431 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound42431 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42432 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,25,81,4097,4211,0,4339,4,4096,4097,153,16,98,145,65,122,80,4176,2145,20,4113,69,4161,1,513]

theorem envBound42432 : H12AffineFastState.Bounded env42432 := by
  intro p hp
  have h : env42432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42431_42432 : H12AffineEnvironment.transform 12 25 env42431 = env42432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env42431 == env42432) = true)

theorem identity42432 : scanCanonicalize (H12AffineFastState.compose env42432 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound42432 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42433 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,65,25,81,64,50,0,178,4,65,64,153,16,98,145,65,122,80,17,2145,20,80,69,0,1,513]

theorem envBound42433 : H12AffineFastState.Bounded env42433 := by
  intro p hp
  have h : env42433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42432_42433 : H12AffineEnvironment.transform 11 65 env42432 = env42433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env42432 == env42433) = true)

theorem identity42433 : scanCanonicalize (H12AffineFastState.compose env42433 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound42433 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env42434 : List Nat := [2,4,8,16,32,64,128,68,512,5,130,65,25,81,64,50,0,178,4,65,64,153,16,98,145,65,122,80,17,227,20,80,69,0,1,513]

theorem envBound42434 : H12AffineFastState.Bounded env42434 := by
  intro p hp
  have h : env42434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42433_42434 : H12AffineEnvironment.transform 10 130 env42433 = env42434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env42433 == env42434) = true)

theorem identity42434 : scanCanonicalize (H12AffineFastState.compose env42434 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound42434 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42435 : List Nat := [2,4,8,16,32,64,128,68,97,5,130,65,25,81,64,50,0,178,4,65,64,153,16,98,145,65,122,80,17,227,20,80,69,0,1,96]

theorem envBound42435 : H12AffineFastState.Bounded env42435 := by
  intro p hp
  have h : env42435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42434_42435 : H12AffineEnvironment.transform 8 97 env42434 = env42435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env42434 == env42435) = true)

theorem identity42435 : scanCanonicalize (H12AffineFastState.compose env42435 (packedSelected [0,1,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound42435 : packedSelected [0,1,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env42436 : List Nat := [2,4,8,16,29,64,128,68,92,5,130,65,25,81,64,15,0,143,4,65,64,153,16,95,145,65,71,80,17,222,20,80,69,0,1,93]

theorem envBound42436 : H12AffineFastState.Bounded env42436 := by
  intro p hp
  have h : env42436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42435_42436 : H12AffineEnvironment.transform 4 29 env42435 = env42436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env42435 == env42436) = true)

theorem identity42436 : scanCanonicalize (H12AffineFastState.compose env42436 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound42436 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env42437 : List Nat := [2,4,8,16,29,64,21,68,92,5,23,65,25,81,64,15,0,26,4,65,64,12,16,95,4,65,71,80,17,75,20,80,69,0,1,93]

theorem envBound42437 : H12AffineFastState.Bounded env42437 := by
  intro p hp
  have h : env42437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42436_42437 : H12AffineEnvironment.transform 6 21 env42436 = env42437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env42436 == env42437) = true)

theorem identity42437 : scanCanonicalize (H12AffineFastState.compose env42437 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound42437 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42438 : List Nat := [2,4,8,16,29,23,21,19,11,5,23,22,25,6,23,15,0,26,4,22,23,12,16,8,4,22,16,7,17,28,20,7,18,0,1,10]

theorem envBound42438 : H12AffineFastState.Bounded env42438 := by
  intro p hp
  have h : env42438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42437_42438 : H12AffineEnvironment.transform 5 23 env42437 = env42438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env42437 == env42438) = true)

theorem identity42438 : scanCanonicalize (H12AffineFastState.compose env42438 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42438 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42439 : List Nat := [0,4,8,16,29,21,21,17,9,5,21,20,25,4,21,13,0,24,4,20,21,12,16,8,4,20,16,5,17,28,20,5,16,0,1,8]

theorem envBound42439 : H12AffineFastState.Bounded env42439 := by
  intro p hp
  have h : env42439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42438_42439 : H12AffineEnvironment.transform 0 0 env42438 = env42439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42438 == env42439) = true)

theorem identity42439 : scanCanonicalize (H12AffineFastState.compose env42439 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound42439 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42440 : List Nat := [0,4,8,13,0,8,8,12,9,5,8,9,4,4,8,13,0,5,4,9,8,12,13,8,4,9,13,5,12,1,9,5,13,0,1,8]

theorem envBound42440 : H12AffineFastState.Bounded env42440 := by
  intro p hp
  have h : env42440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42439_42440 : H12AffineEnvironment.transform 3 13 env42439 = env42440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env42439 == env42440) = true)

theorem identity42440 : scanCanonicalize (H12AffineFastState.compose env42440 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42441 : List Nat := [0,1,8,8,0,8,8,9,9,0,8,9,1,1,8,8,0,0,1,9,8,9,8,8,1,9,8,0,9,1,9,0,8,0,1,8]

theorem envBound42441 : H12AffineFastState.Bounded env42441 := by
  intro p hp
  have h : env42441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42440_42441 : H12AffineEnvironment.transform 1 1 env42440 = env42441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42440 == env42441) = true)

theorem identity42441 : scanCanonicalize (H12AffineFastState.compose env42441 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound42441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42442 : List Nat := [0,1,1,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,0,1,0,1,1,1,0,1,0,0,1,0,0,1,0,1,1]

theorem envBound42442 : H12AffineFastState.Bounded env42442 := by
  intro p hp
  have h : env42442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42441_42442 : H12AffineEnvironment.transform 2 1 env42441 = env42442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env42441 == env42442) = true)

def env42443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77934,13340,4097,477,16,69648,70887,78894,77840,1297,74815,81226,8204,65831,257,74798,1344,79470]

theorem envBound42443 : H12AffineFastState.Bounded env42443 := by
  intro p hp
  have h : env42443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42416_42443 : H12AffineEnvironment.transform 17 65665 env42416 = env42443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42416 == env42443) = true)

theorem identity42443 : scanCanonicalize (H12AffineFastState.compose env42443 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound42443 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9326,1345,9455,5120,13340,4097,477,16,13438,12425,4160,5246,1297,81,6436,8204,9545,257,64,1344,4608]

theorem envBound42444 : H12AffineFastState.Bounded env42444 := by
  intro p hp
  have h : env42444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42443_42444 : H12AffineEnvironment.transform 15 9326 env42443 = env42444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env42443 == env42444) = true)

def env42445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9326,1345,9455,1024,9244,1,477,16,9342,8329,64,1150,1297,81,2340,8204,9545,257,64,1344,512]

theorem envBound42445 : H12AffineFastState.Bounded env42445 := by
  intro p hp
  have h : env42445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42444_42445 : H12AffineEnvironment.transform 11 0 env42444 = env42445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42444 == env42445) = true)

theorem identity42445 : scanCanonicalize (H12AffineFastState.compose env42445 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42445 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42446 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,0,8192,324,8265,8250,277,8379,84,8264,1,477,16,8234,8329,64,42,325,81,2340,8204,8477,257,64,276,512]

theorem envBound42446 : H12AffineFastState.Bounded env42446 := by
  intro p hp
  have h : env42446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42445_42446 : H12AffineEnvironment.transform 9 84 env42445 = env42446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42445 == env42446) = true)

theorem identity42446 : scanCanonicalize (H12AffineFastState.compose env42446 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42446 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42447 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,8192,276,8217,8250,277,8379,4,8216,1,397,16,8234,8329,16,42,277,1,2340,8204,8477,257,16,276,512]

theorem envBound42447 : H12AffineFastState.Bounded env42447 := by
  intro p hp
  have h : env42447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42446_42447 : H12AffineEnvironment.transform 5 16 env42446 = env42447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42446 == env42447) = true)

theorem identity42447 : scanCanonicalize (H12AffineFastState.compose env42447 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound42447 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env42448 : List Nat := [2,4,8,16,32,16,128,256,512,4,42,0,8192,276,8217,8250,277,8379,4,8216,1,397,16,8234,8329,16,42,277,1,270,8204,8477,257,16,276,512]

theorem envBound42448 : H12AffineFastState.Bounded env42448 := by
  intro p hp
  have h : env42448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42447_42448 : H12AffineEnvironment.transform 10 42 env42447 = env42448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env42447 == env42448) = true)

theorem identity42448 : scanCanonicalize (H12AffineFastState.compose env42448 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42448 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env42449 : List Nat := [2,4,8,16,32,16,56,256,512,4,42,0,8192,276,8217,8250,277,8195,4,8216,1,309,16,8234,8241,16,42,277,1,270,8204,8477,257,16,276,512]

theorem envBound42449 : H12AffineFastState.Bounded env42449 := by
  intro p hp
  have h : env42449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42448_42449 : H12AffineEnvironment.transform 6 56 env42448 = env42449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42448 == env42449) = true)

theorem identity42449 : scanCanonicalize (H12AffineFastState.compose env42449 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound42449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42450 : List Nat := [2,4,8,16,32,16,56,256,43,4,42,0,8192,276,8217,8250,277,8195,4,8216,1,309,16,8234,8241,16,42,277,1,270,8204,8477,257,16,276,43]

theorem envBound42450 : H12AffineFastState.Bounded env42450 := by
  intro p hp
  have h : env42450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42449_42450 : H12AffineEnvironment.transform 8 43 env42449 = env42450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env42449 == env42450) = true)

theorem identity42450 : scanCanonicalize (H12AffineFastState.compose env42450 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42450 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42451 : List Nat := [2,4,8,11,32,11,35,256,43,4,42,0,8192,271,8194,8225,270,8195,4,8195,1,302,11,8234,8234,11,42,270,1,270,8204,8454,257,11,271,43]

theorem envBound42451 : H12AffineFastState.Bounded env42451 := by
  intro p hp
  have h : env42451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42450_42451 : H12AffineEnvironment.transform 3 11 env42450 = env42451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42450 == env42451) = true)

theorem identity42451 : scanCanonicalize (H12AffineFastState.compose env42451 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42451 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42452 : List Nat := [2,4,8,11,10,11,9,256,1,4,0,0,8192,271,8194,8203,270,8195,4,8195,1,260,11,8192,8192,11,0,270,1,270,8204,8454,257,11,271,1]

theorem envBound42452 : H12AffineFastState.Bounded env42452 := by
  intro p hp
  have h : env42452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42451_42452 : H12AffineEnvironment.transform 4 10 env42451 = env42452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42451 == env42452) = true)

theorem identity42452 : scanCanonicalize (H12AffineFastState.compose env42452 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound42452 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42453 : List Nat := [2,4,8,11,10,11,9,15,1,4,0,0,8192,0,8194,8203,1,8195,4,8195,1,11,11,8192,8192,11,0,1,1,1,8204,8201,14,11,0,1]

theorem envBound42453 : H12AffineFastState.Bounded env42453 := by
  intro p hp
  have h : env42453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42452_42453 : H12AffineEnvironment.transform 7 15 env42452 = env42453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env42452 == env42453) = true)

theorem identity42453 : scanCanonicalize (H12AffineFastState.compose env42453 (packedSelected [0,3] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound42453 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env42454 : List Nat := [2,4,8,11,10,11,9,15,1,4,0,0,3,0,1,8,1,0,4,0,1,11,11,3,3,11,0,1,1,1,15,10,14,11,0,1]

theorem envBound42454 : H12AffineFastState.Bounded env42454 := by
  intro p hp
  have h : env42454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42453_42454 : H12AffineEnvironment.transform 12 3 env42453 = env42454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env42453 == env42454) = true)

theorem identity42454 : scanCanonicalize (H12AffineFastState.compose env42454 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42455 : List Nat := [2,3,8,11,10,11,9,8,1,3,0,0,3,0,1,8,1,0,3,0,1,11,11,3,3,11,0,1,1,1,8,10,9,11,0,1]

theorem envBound42455 : H12AffineFastState.Bounded env42455 := by
  intro p hp
  have h : env42455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42454_42455 : H12AffineEnvironment.transform 1 3 env42454 = env42455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42454 == env42455) = true)

def env42456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9326,1345,9455,1025,9245,0,477,16,9343,8328,65,1151,1297,81,2341,8204,9545,257,64,1344,513]

theorem envBound42456 : H12AffineFastState.Bounded env42456 := by
  intro p hp
  have h : env42456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42444_42456 : H12AffineEnvironment.transform 11 1 env42444 = env42456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42444 == env42456) = true)

theorem identity42456 : scanCanonicalize (H12AffineFastState.compose env42456 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42456 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42457 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,1,8192,277,8217,8299,324,8426,4,8216,0,477,16,8314,8328,65,122,276,81,2341,8204,8524,257,64,325,513]

theorem envBound42457 : H12AffineFastState.Bounded env42457 := by
  intro p hp
  have h : env42457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42456_42457 : H12AffineEnvironment.transform 9 5 env42456 = env42457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42456 == env42457) = true)

theorem identity42457 : scanCanonicalize (H12AffineFastState.compose env42457 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42457 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42458 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,1,348,277,325,311,324,438,4,324,0,477,16,294,468,65,122,276,81,2341,336,16,257,64,325,513]

theorem envBound42458 : H12AffineFastState.Bounded env42458 := by
  intro p hp
  have h : env42458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42457_42458 : H12AffineEnvironment.transform 12 348 env42457 = env42458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42457 == env42458) = true)

theorem identity42458 : scanCanonicalize (H12AffineFastState.compose env42458 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42458 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42459 : List Nat := [2,4,8,16,32,64,128,5,512,5,2048,1,89,16,64,50,65,179,4,65,0,216,16,35,209,65,122,17,81,2080,85,16,4,64,64,513]

theorem envBound42459 : H12AffineFastState.Bounded env42459 := by
  intro p hp
  have h : env42459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42458_42459 : H12AffineEnvironment.transform 7 5 env42458 = env42459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42458 == env42459) = true)

theorem identity42459 : scanCanonicalize (H12AffineFastState.compose env42459 (packedSelected [1,2,3,5,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 245) := by decide +kernel

theorem selectedBound42459 : packedSelected [1,2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env42460 : List Nat := [2,4,8,16,32,64,128,5,245,5,2048,1,89,16,64,50,65,179,4,65,0,216,16,35,209,65,122,17,81,2080,85,16,4,64,64,244]

theorem envBound42460 : H12AffineFastState.Bounded env42460 := by
  intro p hp
  have h : env42460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42459_42460 : H12AffineEnvironment.transform 8 245 env42459 = env42460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 245 env42459 == env42460) = true)

theorem identity42460 : scanCanonicalize (H12AffineFastState.compose env42460 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound42460 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env42461 : List Nat := [2,4,8,16,32,61,128,5,136,5,2048,1,36,16,61,50,60,179,4,60,0,165,16,35,172,60,7,17,44,2080,40,16,4,61,61,137]

theorem envBound42461 : H12AffineFastState.Bounded env42461 := by
  intro p hp
  have h : env42461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42460_42461 : H12AffineEnvironment.transform 5 61 env42460 = env42461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env42460 == env42461) = true)

def env42462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70886,78895,77840,1297,74815,81227,365713,308667,257,74799,1344,79471]

theorem envBound42462 : H12AffineFastState.Bounded env42462 := by
  intro p hp
  have h : env42462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42414_42462 : H12AffineEnvironment.transform 13 1297 env42414 = env42462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42414 == env42462) = true)

theorem identity42462 : scanCanonicalize (H12AffineFastState.compose env42462 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound42462 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,16,266384,38037,46172,45155,1297,42060,48440,267490,308667,257,42076,1344,46620]

theorem envBound42463 : H12AffineFastState.Bounded env42463 := by
  intro p hp
  have h : env42463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42462_42463 : H12AffineEnvironment.transform 15 32883 env42462 = env42463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env42462 == env42463) = true)

def env42464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263632,33237,41244,42275,1297,42060,43128,262562,303355,257,42076,1344,41820]

theorem envBound42464 : H12AffineFastState.Bounded env42464 := by
  intro p hp
  have h : env42464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42463_42464 : H12AffineEnvironment.transform 11 1344 env42463 = env42464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env42463 == env42464) = true)

theorem identity42464 : scanCanonicalize (H12AffineFastState.compose env42464 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound42464 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,41146,42332,32769,1345,41089,16,42346,33237,41244,42275,1297,42060,43128,41240,65,257,42076,1344,41820]

theorem envBound42465 : H12AffineFastState.Bounded env42465 := by
  intro p hp
  have h : env42465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42464_42465 : H12AffineEnvironment.transform 17 41146 env42464 = env42465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env42464 == env42465) = true)

theorem identity42465 : scanCanonicalize (H12AffineFastState.compose env42465 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42465 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1344,486,1024,8541,1345,477,16,1078,8329,64,1151,1297,1296,2340,68,65,257,1280,1344,512]

theorem envBound42466 : H12AffineFastState.Bounded env42466 := by
  intro p hp
  have h : env42466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42465_42466 : H12AffineEnvironment.transform 14 8540 env42465 = env42466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42465 == env42466) = true)

theorem identity42466 : scanCanonicalize (H12AffineFastState.compose env42466 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42466 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42467 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,325,8540,8495,276,486,84,8541,277,477,16,98,8329,64,43,325,324,2340,68,65,257,340,276,512]

theorem envBound42467 : H12AffineFastState.Bounded env42467 := by
  intro p hp
  have h : env42467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42466_42467 : H12AffineEnvironment.transform 9 84 env42466 = env42467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42466 == env42467) = true)

theorem identity42467 : scanCanonicalize (H12AffineFastState.compose env42467 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound42467 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42468 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,705,325,925,1006,276,486,84,924,277,477,16,98,584,64,43,325,324,2340,68,65,257,340,276,512]

theorem envBound42468 : H12AffineFastState.Bounded env42468 := by
  intro p hp
  have h : env42468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42467_42468 : H12AffineEnvironment.transform 12 705 env42467 = env42468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env42467 == env42468) = true)

theorem identity42468 : scanCanonicalize (H12AffineFastState.compose env42468 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42468 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42469 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,657,277,925,958,276,438,4,924,277,397,16,50,536,16,43,277,276,2340,20,17,257,260,276,512]

theorem envBound42469 : H12AffineFastState.Bounded env42469 := by
  intro p hp
  have h : env42469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42468_42469 : H12AffineEnvironment.transform 5 16 env42468 = env42469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42468 == env42469) = true)

theorem identity42469 : scanCanonicalize (H12AffineFastState.compose env42469 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound42469 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42470 : List Nat := [2,4,8,16,32,16,128,256,512,4,439,276,657,277,925,958,276,438,4,924,277,397,16,50,536,16,43,277,276,147,20,17,257,260,276,512]

theorem envBound42470 : H12AffineFastState.Bounded env42470 := by
  intro p hp
  have h : env42470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42469_42470 : H12AffineEnvironment.transform 10 439 env42469 = env42470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env42469 == env42470) = true)

theorem identity42470 : scanCanonicalize (H12AffineFastState.compose env42470 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound42470 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42471 : List Nat := [2,4,8,16,32,16,57,256,512,4,270,276,552,277,804,775,276,271,4,805,277,308,16,50,536,16,43,277,276,42,20,17,257,260,276,512]

theorem envBound42471 : H12AffineFastState.Bounded env42471 := by
  intro p hp
  have h : env42471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42470_42471 : H12AffineEnvironment.transform 6 57 env42470 = env42471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env42470 == env42471) = true)

theorem identity42471 : scanCanonicalize (H12AffineFastState.compose env42471 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound42471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42472 : List Nat := [2,4,8,16,32,16,57,256,318,4,270,276,278,277,26,57,276,271,4,27,277,308,16,50,294,16,43,277,276,42,20,17,257,260,276,318]

theorem envBound42472 : H12AffineFastState.Bounded env42472 := by
  intro p hp
  have h : env42472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42471_42472 : H12AffineEnvironment.transform 8 318 env42471 = env42472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env42471 == env42472) = true)

theorem identity42472 : scanCanonicalize (H12AffineFastState.compose env42472 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42472 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env42473 : List Nat := [2,4,8,16,32,16,57,36,26,4,42,48,50,49,26,57,48,43,4,27,49,16,16,50,2,16,43,49,48,42,20,17,37,32,48,26]

theorem envBound42473 : H12AffineFastState.Bounded env42473 := by
  intro p hp
  have h : env42473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42472_42473 : H12AffineEnvironment.transform 7 36 env42472 = env42473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42472 == env42473) = true)

def env42474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263633,33236,41245,42274,1297,42060,43129,262563,303354,257,42076,1344,41821]

theorem envBound42474 : H12AffineFastState.Bounded env42474 := by
  intro p hp
  have h : env42474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42463_42474 : H12AffineEnvironment.transform 11 1345 env42463 = env42474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env42463 == env42474) = true)

theorem identity42474 : scanCanonicalize (H12AffineFastState.compose env42474 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound42474 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1297,32768,32883,1344,262144,34069,32769,1344,32968,16,263633,33236,33109,34154,1297,33796,34865,262563,295090,257,33812,1344,33557]

theorem envBound42475 : H12AffineFastState.Bounded env42475 := by
  intro p hp
  have h : env42475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42474_42475 : H12AffineEnvironment.transform 12 72 env42474 = env42475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42474 == env42475) = true)

theorem identity42475 : scanCanonicalize (H12AffineFastState.compose env42475 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound42475 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env42476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1345,72,1297,32768,32883,1344,262144,34069,32769,1344,32968,16,263633,33236,33109,34154,1297,33796,34503,262563,295090,257,33812,1344,33557]

theorem envBound42476 : H12AffineFastState.Bounded env42476 := by
  intro p hp
  have h : env42476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42475_42476 : H12AffineEnvironment.transform 10 1782 env42475 = env42476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env42475 == env42476) = true)

def env42477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245633,148800,545089,96346,16876545,16949354,257,676880,1345,525824]

theorem envBound42477 : H12AffineFastState.Bounded env42477 := by
  intro p hp
  have h : env42477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42245_42477 : H12AffineEnvironment.transform 26 17245633 env42245 = env42477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env42245 == env42477) = true)

theorem identity42477 : scanCanonicalize (H12AffineFastState.compose env42477 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound42477 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,16777216,533641,614527,17039791,90414,545089,96346,16876545,16876548,257,618622,1345,525824]

theorem envBound42478 : H12AffineFastState.Bounded env42478 := by
  intro p hp
  have h : env42478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42477_42478 : H12AffineEnvironment.transform 16 74862 env42477 = env42478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env42477 == env42478) = true)

def env42479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123164,533641,614527,385203,90414,545089,96346,25885,25880,257,618622,1345,525824]

theorem envBound42479 : H12AffineFastState.Bounded env42479 := by
  intro p hp
  have h : env42479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42478_42479 : H12AffineEnvironment.transform 23 123164 env42478 = env42479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env42478 == env42479) = true)

def env42480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123164,28889,78895,385203,90414,1297,96346,25885,25880,257,74798,1345,21072]

theorem envBound42480 : H12AffineFastState.Bounded env42480 := by
  intro p hp
  have h : env42480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42479_42480 : H12AffineEnvironment.transform 18 21584 env42479 = env42480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env42479 == env42480) = true)

theorem identity42480 : scanCanonicalize (H12AffineFastState.compose env42480 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42480 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4097,17613,91183,87297,28889,78895,349358,90414,1297,96346,25885,25880,257,74798,1345,21072]

theorem envBound42481 : H12AffineFastState.Bounded env42481 := by
  intro p hp
  have h : env42481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42480_42481 : H12AffineEnvironment.transform 14 13341 env42480 = env42481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42480 == env42481) = true)

def env42482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4097,477,74047,69649,13769,78895,332222,74814,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound42482 : H12AffineFastState.Bounded env42482 := by
  intro p hp
  have h : env42482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42481_42482 : H12AffineEnvironment.transform 13 1296 env42481 = env42482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42481 == env42482) = true)

def env42483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4097,477,74047,69649,13769,78895,4414,74814,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound42483 : H12AffineFastState.Bounded env42483 := by
  intro p hp
  have h : env42483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42482_42483 : H12AffineEnvironment.transform 17 65664 env42482 = env42483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42482 == env42483) = true)

theorem identity42483 : scanCanonicalize (H12AffineFastState.compose env42483 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound42483 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4097,477,65911,69649,5505,70759,4414,66678,1297,72962,69,64,257,66662,1345,5952]

theorem envBound42484 : H12AffineFastState.Bounded env42484 := by
  intro p hp
  have h : env42484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42483_42484 : H12AffineEnvironment.transform 12 72 env42483 = env42484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42483 == env42484) = true)

def env42485 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4097,477,65911,69649,5505,70759,4414,66678,1297,72962,69,64,257,66662,1345,5140]

theorem envBound42485 : H12AffineFastState.Bounded env42485 := by
  intro p hp
  have h : env42485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42484_42485 : H12AffineEnvironment.transform 8 340 env42484 = env42485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env42484 == env42485) = true)

def env42486 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4373,65536,65894,65664,4416,4372,4097,477,65911,69649,4289,69927,4414,65846,81,71746,69,64,257,65830,1,4436]

theorem envBound42486 : H12AffineFastState.Bounded env42486 := by
  intro p hp
  have h : env42486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42485_42486 : H12AffineEnvironment.transform 9 320 env42485 = env42486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42485 == env42486) = true)

theorem identity42486 : scanCanonicalize (H12AffineFastState.compose env42486 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42486 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42487 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,4096,72,80,4097,65536,65650,65664,4180,4096,4097,201,65635,69649,4289,69683,4138,65570,81,71746,69,64,21,65586,1,4160]

theorem envBound42487 : H12AffineFastState.Bounded env42487 := by
  intro p hp
  have h : env42487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42486_42487 : H12AffineEnvironment.transform 7 20 env42486 = env42487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42486 == env42487) = true)

theorem identity42487 : scanCanonicalize (H12AffineFastState.compose env42487 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound42487 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42488 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,2058,72,80,2059,65536,65650,65664,2142,2058,2059,201,65635,67611,2251,67641,2080,65570,81,65608,69,64,21,65586,1,2122]

theorem envBound42488 : H12AffineFastState.Bounded env42488 := by
  intro p hp
  have h : env42488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42487_42488 : H12AffineEnvironment.transform 11 2058 env42487 = env42488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env42487 == env42488) = true)

theorem identity42488 : scanCanonicalize (H12AffineFastState.compose env42488 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 238) := by decide +kernel

theorem selectedBound42488 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42489 : List Nat := [2,4,8,16,32,64,128,20,64,84,238,228,72,80,229,65536,65650,65664,176,228,229,201,65635,65781,37,65751,206,65570,81,65608,69,64,21,65586,1,164]

theorem envBound42489 : H12AffineFastState.Bounded env42489 := by
  intro p hp
  have h : env42489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42488_42489 : H12AffineEnvironment.transform 10 238 env42488 = env42489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 238 env42488 == env42489) = true)

theorem identity42489 : scanCanonicalize (H12AffineFastState.compose env42489 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound42489 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env42490 : List Nat := [2,4,8,16,32,64,100,20,64,84,10,0,72,80,1,65536,65650,65636,84,0,1,45,65635,65553,37,65587,42,65570,81,65608,69,64,21,65586,1,64]

theorem envBound42490 : H12AffineFastState.Bounded env42490 := by
  intro p hp
  have h : env42490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42489_42490 : H12AffineEnvironment.transform 6 100 env42489 = env42490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env42489 == env42490) = true)

theorem identity42490 : scanCanonicalize (H12AffineFastState.compose env42490 (packedSelected [2,3,10] rootPS)) = affineNative (2^(15+1) ^^^ 14) := by decide +kernel

theorem selectedBound42490 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env42491 : List Nat := [2,4,8,16,32,64,100,20,64,84,10,0,72,80,1,14,124,106,84,0,1,45,109,31,37,61,42,44,81,70,69,64,21,60,1,64]

theorem envBound42491 : H12AffineFastState.Bounded env42491 := by
  intro p hp
  have h : env42491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42490_42491 : H12AffineEnvironment.transform 15 14 env42490 = env42491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14 env42490 == env42491) = true)

theorem identity42491 : scanCanonicalize (H12AffineFastState.compose env42491 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound42491 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42492 : List Nat := [2,4,8,16,27,64,95,20,64,84,10,0,72,80,1,14,71,81,84,0,1,22,86,31,30,6,17,23,81,70,69,64,21,7,1,64]

theorem envBound42492 : H12AffineFastState.Bounded env42492 := by
  intro p hp
  have h : env42492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42491_42492 : H12AffineEnvironment.transform 4 27 env42491 = env42492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env42491 == env42492) = true)

theorem identity42492 : scanCanonicalize (H12AffineFastState.compose env42492 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound42492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42493 : List Nat := [2,4,8,16,27,22,9,20,22,2,10,0,30,6,1,14,17,7,2,0,1,22,0,31,30,6,17,23,7,16,19,22,21,7,1,22]

theorem envBound42493 : H12AffineFastState.Bounded env42493 := by
  intro p hp
  have h : env42493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42492_42493 : H12AffineEnvironment.transform 5 22 env42492 = env42493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env42492 == env42493) = true)

theorem identity42493 : scanCanonicalize (H12AffineFastState.compose env42493 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42493 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42494 : List Nat := [2,4,8,7,12,1,9,3,1,2,10,0,9,6,1,14,6,7,2,0,1,1,0,8,9,6,6,0,7,7,4,1,2,7,1,1]

theorem envBound42494 : H12AffineFastState.Bounded env42494 := by
  intro p hp
  have h : env42494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42493_42494 : H12AffineEnvironment.transform 3 7 env42493 = env42494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42493 == env42494) = true)

theorem identity42494 : scanCanonicalize (H12AffineFastState.compose env42494 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42494 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42495 : List Nat := [2,4,3,7,7,1,2,3,1,2,1,0,2,6,1,5,6,7,2,0,1,1,0,3,2,6,6,0,7,7,4,1,2,7,1,1]

theorem envBound42495 : H12AffineFastState.Bounded env42495 := by
  intro p hp
  have h : env42495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42494_42495 : H12AffineEnvironment.transform 2 3 env42494 = env42495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42494 == env42495) = true)

theorem identity42495 : scanCanonicalize (H12AffineFastState.compose env42495 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42495 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42496 : List Nat := [2,3,3,0,0,1,2,3,1,2,1,0,2,1,1,2,1,0,2,0,1,1,0,3,2,1,1,0,0,0,3,1,2,0,1,1]

theorem envBound42496 : H12AffineFastState.Bounded env42496 := by
  intro p hp
  have h : env42496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42495_42496 : H12AffineEnvironment.transform 1 3 env42495 = env42496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42495 == env42496) = true)

def env42497 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4372,65536,65895,65664,4416,4373,4097,477,65911,69649,4288,69926,4414,65847,80,71747,69,64,257,65831,0,4437]

theorem envBound42497 : H12AffineFastState.Bounded env42497 := by
  intro p hp
  have h : env42497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42485_42497 : H12AffineEnvironment.transform 9 321 env42485 = env42497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42485 == env42497) = true)

theorem identity42497 : scanCanonicalize (H12AffineFastState.compose env42497 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound42497 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42498 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,72,81,0,65536,65895,65664,84,1,277,477,65911,65797,468,65586,42,65847,80,67927,69,64,257,65831,0,65]

theorem envBound42498 : H12AffineFastState.Bounded env42498 := by
  intro p hp
  have h : env42498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42497_42498 : H12AffineEnvironment.transform 11 276 env42497 = env42498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env42497 == env42498) = true)

theorem identity42498 : scanCanonicalize (H12AffineFastState.compose env42498 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound42498 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42499 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,72,81,0,2193,2550,2065,84,1,277,477,2534,2452,468,2211,42,2470,80,454,69,64,257,2486,0,65]

theorem envBound42499 : H12AffineFastState.Bounded env42499 := by
  intro p hp
  have h : env42499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42498_42499 : H12AffineEnvironment.transform 15 2193 env42498 = env42499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env42498 == env42499) = true)

theorem identity42499 : scanCanonicalize (H12AffineFastState.compose env42499 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound42499 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42500 : List Nat := [2,4,8,16,32,64,128,215,131,150,2048,195,72,81,0,2193,2081,2065,84,1,194,10,2097,2115,3,2211,42,2161,80,17,69,64,214,2145,0,65]

theorem envBound42500 : H12AffineFastState.Bounded env42500 := by
  intro p hp
  have h : env42500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42499_42500 : H12AffineEnvironment.transform 7 215 env42499 = env42500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env42499 == env42500) = true)

theorem identity42500 : scanCanonicalize (H12AffineFastState.compose env42500 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42500 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42501 : List Nat := [2,4,8,16,32,64,18,69,17,4,2048,81,72,81,0,2051,2081,2065,84,1,80,10,2097,2115,3,2097,42,2161,80,17,69,64,68,2145,0,65]

theorem envBound42501 : H12AffineFastState.Bounded env42501 := by
  intro p hp
  have h : env42501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42500_42501 : H12AffineEnvironment.transform 6 18 env42500 = env42501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42500 == env42501) = true)

theorem identity42501 : scanCanonicalize (H12AffineFastState.compose env42501 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42501 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42502 : List Nat := [2,4,8,16,32,17,18,20,17,4,2048,0,25,0,0,2051,2081,2065,5,1,1,10,2097,2066,3,2097,42,2080,1,17,20,17,21,2096,0,16]

theorem envBound42502 : H12AffineFastState.Bounded env42502 := by
  intro p hp
  have h : env42502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42501_42502 : H12AffineEnvironment.transform 5 17 env42501 = env42502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42501 == env42502) = true)

theorem identity42502 : scanCanonicalize (H12AffineFastState.compose env42502 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound42502 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42503 : List Nat := [2,4,8,16,29,17,18,20,17,4,2048,0,25,0,0,2051,2076,2065,5,1,1,10,2060,2066,3,2060,23,2077,1,17,20,17,21,2061,0,16]

theorem envBound42503 : H12AffineFastState.Bounded env42503 := by
  intro p hp
  have h : env42503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42502_42503 : H12AffineEnvironment.transform 4 29 env42502 = env42503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env42502 == env42503) = true)

theorem identity42503 : scanCanonicalize (H12AffineFastState.compose env42503 (packedSelected [0,1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound42503 : packedSelected [0,1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env42504 : List Nat := [2,4,8,16,29,17,18,20,17,4,8,0,25,0,0,11,20,25,5,1,1,10,4,26,3,4,23,21,1,17,20,17,21,5,0,16]

theorem envBound42504 : H12AffineFastState.Bounded env42504 := by
  intro p hp
  have h : env42504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42503_42504 : H12AffineEnvironment.transform 10 8 env42503 = env42504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env42503 == env42504) = true)

theorem identity42504 : scanCanonicalize (H12AffineFastState.compose env42504 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound42504 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env42505 : List Nat := [2,4,8,3,14,2,1,7,2,4,8,0,10,0,0,11,7,10,5,1,1,10,4,9,3,4,4,6,1,2,7,2,6,5,0,3]

theorem envBound42505 : H12AffineFastState.Bounded env42505 := by
  intro p hp
  have h : env42505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42504_42505 : H12AffineEnvironment.transform 3 3 env42504 = env42505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env42504 == env42505) = true)

theorem identity42505 : scanCanonicalize (H12AffineFastState.compose env42505 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42505 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env42506 : List Nat := [2,4,3,3,5,2,1,7,2,4,3,0,1,0,0,0,7,1,5,1,1,1,4,2,3,4,4,6,1,2,7,2,6,5,0,3]

theorem envBound42506 : H12AffineFastState.Bounded env42506 := by
  intro p hp
  have h : env42506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42505_42506 : H12AffineEnvironment.transform 2 3 env42505 = env42506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42505 == env42506) = true)

theorem identity42506 : scanCanonicalize (H12AffineFastState.compose env42506 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42507 : List Nat := [0,4,1,1,5,0,1,5,0,4,1,0,1,0,0,0,5,1,5,1,1,1,4,0,1,4,4,4,1,0,5,0,4,5,0,1]

theorem envBound42507 : H12AffineFastState.Bounded env42507 := by
  intro p hp
  have h : env42507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42506_42507 : H12AffineEnvironment.transform 0 0 env42506 = env42507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42506 == env42507) = true)

theorem identity42507 : scanCanonicalize (H12AffineFastState.compose env42507 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42508 : List Nat := [0,0,1,1,1,0,1,1,0,0,1,0,1,0,0,0,1,1,1,1,1,1,0,0,1,0,0,0,1,0,1,0,0,1,0,1]

theorem envBound42508 : H12AffineFastState.Bounded env42508 := by
  intro p hp
  have h : env42508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42507_42508 : H12AffineEnvironment.transform 1 0 env42507 = env42508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42507 == env42508) = true)

def env42509 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4097,477,65911,69649,5505,70759,4414,66678,1297,72962,69,64,257,66662,1345,5141]

theorem envBound42509 : H12AffineFastState.Bounded env42509 := by
  intro p hp
  have h : env42509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42484_42509 : H12AffineEnvironment.transform 8 341 env42484 = env42509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env42484 == env42509) = true)

def env42510 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4373,65536,65894,65664,4416,4372,4097,477,65911,69649,4289,69927,4414,65846,81,71746,69,64,257,65830,1,4437]

theorem envBound42510 : H12AffineFastState.Bounded env42510 := by
  intro p hp
  have h : env42510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42509_42510 : H12AffineEnvironment.transform 9 320 env42509 = env42510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42509 == env42510) = true)

theorem identity42510 : scanCanonicalize (H12AffineFastState.compose env42510 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42510 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42511 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,4096,72,80,4097,65536,65650,65664,4180,4096,4097,201,65635,69649,4289,69683,4138,65570,81,71746,69,64,21,65586,1,4161]

theorem envBound42511 : H12AffineFastState.Bounded env42511 := by
  intro p hp
  have h : env42511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42510_42511 : H12AffineEnvironment.transform 7 20 env42510 = env42511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42510 == env42511) = true)

theorem identity42511 : scanCanonicalize (H12AffineFastState.compose env42511 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound42511 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42512 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,2059,72,80,2058,65536,65650,65664,2143,2059,2058,201,65635,67610,2250,67640,2081,65570,81,65609,69,64,21,65586,1,2122]

theorem envBound42512 : H12AffineFastState.Bounded env42512 := by
  intro p hp
  have h : env42512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42511_42512 : H12AffineEnvironment.transform 11 2059 env42511 = env42512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env42511 == env42512) = true)

theorem identity42512 : scanCanonicalize (H12AffineFastState.compose env42512 (packedSelected [2,5] rootPS)) = affineNative (2^(15+1) ^^^ 2204) := by decide +kernel

theorem selectedBound42512 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42513 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,2059,72,80,2058,2204,2286,2076,2143,2059,2058,201,2303,134,2250,164,2081,2238,81,2261,69,64,21,2222,1,2122]

theorem envBound42513 : H12AffineFastState.Bounded env42513 := by
  intro p hp
  have h : env42513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42512_42513 : H12AffineEnvironment.transform 15 2204 env42512 = env42513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2204 env42512 == env42513) = true)

theorem identity42513 : scanCanonicalize (H12AffineFastState.compose env42513 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42513 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env42514 : List Nat := [2,4,8,16,32,64,128,20,65,84,11,0,72,80,1,151,229,23,84,0,1,201,244,134,193,164,42,181,81,222,69,64,21,165,1,65]

theorem envBound42514 : H12AffineFastState.Bounded env42514 := by
  intro p hp
  have h : env42514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42513_42514 : H12AffineEnvironment.transform 10 11 env42513 = env42514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42513 == env42514) = true)

theorem identity42514 : scanCanonicalize (H12AffineFastState.compose env42514 (packedSelected [2,3,10] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound42514 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env42515 : List Nat := [2,4,8,16,32,60,128,20,61,40,11,0,52,44,1,151,153,23,40,0,1,181,136,134,189,164,42,181,45,162,57,60,21,165,1,61]

theorem envBound42515 : H12AffineFastState.Bounded env42515 := by
  intro p hp
  have h : env42515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42514_42515 : H12AffineEnvironment.transform 5 60 env42514 = env42515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env42514 == env42515) = true)

theorem identity42515 : scanCanonicalize (H12AffineFastState.compose env42515 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound42515 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42516 : List Nat := [2,4,8,16,26,6,128,20,7,18,11,0,14,22,1,151,153,23,18,0,1,143,136,134,135,158,16,143,23,152,3,6,21,159,1,7]

theorem envBound42516 : H12AffineFastState.Bounded env42516 := by
  intro p hp
  have h : env42516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42515_42516 : H12AffineEnvironment.transform 4 26 env42515 = env42516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env42515 == env42516) = true)

theorem identity42516 : scanCanonicalize (H12AffineFastState.compose env42516 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42517 : List Nat := [2,4,8,16,26,6,9,20,7,18,11,0,14,22,1,30,16,23,18,0,1,6,1,15,14,23,16,6,23,17,3,6,21,22,1,7]

theorem envBound42517 : H12AffineFastState.Bounded env42517 := by
  intro p hp
  have h : env42517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42516_42517 : H12AffineEnvironment.transform 6 9 env42516 = env42517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42516 == env42517) = true)

theorem identity42517 : scanCanonicalize (H12AffineFastState.compose env42517 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42517 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42518 : List Nat := [2,2,8,16,26,0,9,18,1,18,11,0,8,16,1,24,16,17,18,0,1,0,1,9,8,17,16,0,17,17,3,0,19,16,1,1]

theorem envBound42518 : H12AffineFastState.Bounded env42518 := by
  intro p hp
  have h : env42518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42517_42518 : H12AffineEnvironment.transform 1 2 env42517 = env42518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42517 == env42518) = true)

theorem identity42518 : scanCanonicalize (H12AffineFastState.compose env42518 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42518 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42519 : List Nat := [2,2,2,16,16,0,3,18,1,18,1,0,2,16,1,18,16,17,18,0,1,0,1,3,2,17,16,0,17,17,3,0,19,16,1,1]

theorem envBound42519 : H12AffineFastState.Bounded env42519 := by
  intro p hp
  have h : env42519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42518_42519 : H12AffineEnvironment.transform 2 2 env42518 = env42519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42518 == env42519) = true)

theorem identity42519 : scanCanonicalize (H12AffineFastState.compose env42519 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42519 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42520 : List Nat := [2,2,2,1,1,0,3,3,1,3,1,0,2,1,1,3,1,0,3,0,1,0,1,3,2,0,1,0,0,0,3,0,2,1,1,1]

theorem envBound42520 : H12AffineFastState.Bounded env42520 := by
  intro p hp
  have h : env42520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42519_42520 : H12AffineEnvironment.transform 3 1 env42519 = env42520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42519 == env42520) = true)

def env42521 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4372,65536,65895,65664,4416,4373,4097,477,65911,69649,4288,69926,4414,65847,80,71747,69,64,257,65831,0,4436]

theorem envBound42521 : H12AffineFastState.Bounded env42521 := by
  intro p hp
  have h : env42521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42509_42521 : H12AffineEnvironment.transform 9 321 env42509 = env42521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42509 == env42521) = true)

theorem identity42521 : scanCanonicalize (H12AffineFastState.compose env42521 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound42521 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42522 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,72,81,0,65536,65895,65664,84,1,277,477,65911,65797,468,65586,42,65847,80,67927,69,64,257,65831,0,64]

theorem envBound42522 : H12AffineFastState.Bounded env42522 := by
  intro p hp
  have h : env42522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42521_42522 : H12AffineEnvironment.transform 11 276 env42521 = env42522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env42521 == env42522) = true)

theorem identity42522 : scanCanonicalize (H12AffineFastState.compose env42522 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2192) := by decide +kernel

theorem selectedBound42522 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42523 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,72,81,0,2192,2551,2064,84,1,277,477,2535,2453,468,2210,42,2471,80,455,69,64,257,2487,0,64]

theorem envBound42523 : H12AffineFastState.Bounded env42523 := by
  intro p hp
  have h : env42523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42522_42523 : H12AffineEnvironment.transform 15 2192 env42522 = env42523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2192 env42522 == env42523) = true)

theorem identity42523 : scanCanonicalize (H12AffineFastState.compose env42523 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound42523 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42524 : List Nat := [2,4,8,16,32,64,128,215,130,150,2048,195,72,81,0,2192,2080,2064,84,1,194,10,2096,2114,3,2210,42,2160,80,16,69,64,214,2144,0,64]

theorem envBound42524 : H12AffineFastState.Bounded env42524 := by
  intro p hp
  have h : env42524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42523_42524 : H12AffineEnvironment.transform 7 215 env42523 = env42524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env42523 == env42524) = true)

theorem identity42524 : scanCanonicalize (H12AffineFastState.compose env42524 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42524 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42525 : List Nat := [2,4,8,16,32,64,18,69,16,4,2048,81,72,81,0,2050,2080,2064,84,1,80,10,2096,2114,3,2096,42,2160,80,16,69,64,68,2144,0,64]

theorem envBound42525 : H12AffineFastState.Bounded env42525 := by
  intro p hp
  have h : env42525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42524_42525 : H12AffineEnvironment.transform 6 18 env42524 = env42525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42524 == env42525) = true)

def env42526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4097,477,74047,69649,13769,78895,4415,74814,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound42526 : H12AffineFastState.Bounded env42526 := by
  intro p hp
  have h : env42526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42482_42526 : H12AffineEnvironment.transform 17 65665 env42482 = env42526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42482 == env42526) = true)

theorem identity42526 : scanCanonicalize (H12AffineFastState.compose env42526 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound42526 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4097,477,70710,69649,192,65830,4415,69943,1297,67651,5380,5377,257,69927,1345,5952]

theorem envBound42527 : H12AffineFastState.Bounded env42527 := by
  intro p hp
  have h : env42527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42526_42527 : H12AffineEnvironment.transform 12 5385 env42526 = env42527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env42526 == env42527) = true)

def env42528 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4097,477,70710,69649,192,65830,4415,69943,1297,67651,5380,5377,257,69927,1345,5140]

theorem envBound42528 : H12AffineFastState.Bounded env42528 := by
  intro p hp
  have h : env42528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42527_42528 : H12AffineEnvironment.transform 8 340 env42527 = env42528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env42527 == env42528) = true)

def env42529 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,276,65536,65895,65665,320,277,1,477,66614,65553,192,65830,319,65847,1297,67651,1284,1281,257,65831,1345,1044]

theorem envBound42529 : H12AffineFastState.Bounded env42529 := by
  intro p hp
  have h : env42529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42528_42529 : H12AffineEnvironment.transform 11 0 env42528 = env42529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42528 == env42529) = true)

theorem identity42529 : scanCanonicalize (H12AffineFastState.compose env42529 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42529 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42530 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,0,1053,1028,0,65536,65651,65665,84,1,1,201,66614,65553,192,65586,43,65571,1029,67651,1040,1045,21,65587,1109,1044]

theorem envBound42530 : H12AffineFastState.Bounded env42530 := by
  intro p hp
  have h : env42530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42529_42530 : H12AffineEnvironment.transform 7 20 env42529 = env42530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42529 == env42530) = true)

theorem identity42530 : scanCanonicalize (H12AffineFastState.compose env42530 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42530 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42531 : List Nat := [2,4,8,16,32,64,128,20,64,4,2048,0,25,0,0,65536,65651,65665,84,1,1,201,65586,65553,192,65586,43,65571,1,67651,20,17,21,65587,81,16]

theorem envBound42531 : H12AffineFastState.Bounded env42531 := by
  intro p hp
  have h : env42531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42530_42531 : H12AffineEnvironment.transform 9 4 env42530 = env42531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42530 == env42531) = true)

theorem identity42531 : scanCanonicalize (H12AffineFastState.compose env42531 (packedSelected [8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound42531 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env42532 : List Nat := [2,4,8,16,32,64,128,20,64,4,71,0,25,0,0,65536,65651,65665,84,1,1,201,65586,65553,192,65586,43,65571,1,65540,20,17,21,65587,81,16]

theorem envBound42532 : H12AffineFastState.Bounded env42532 := by
  intro p hp
  have h : env42532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42531_42532 : H12AffineEnvironment.transform 10 71 env42531 = env42532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env42531 == env42532) = true)

theorem identity42532 : scanCanonicalize (H12AffineFastState.compose env42532 (packedSelected [0,1,7,8,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound42532 : packedSelected [0,1,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env42533 : List Nat := [2,4,8,16,32,64,34,20,64,4,71,0,25,0,0,65536,65651,65571,84,1,1,107,65586,65553,98,65586,43,65571,1,65540,20,17,21,65587,81,16]

theorem envBound42533 : H12AffineFastState.Bounded env42533 := by
  intro p hp
  have h : env42533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42532_42533 : H12AffineEnvironment.transform 6 34 env42532 = env42533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env42532 == env42533) = true)

theorem identity42533 : scanCanonicalize (H12AffineFastState.compose env42533 (packedSelected [0,2,7,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound42533 : packedSelected [0,2,7,11,13] rootPS < 2^1333 := by decide +kernel

def env42534 : List Nat := [2,4,8,16,32,64,34,20,64,4,71,0,25,0,0,72,59,107,84,1,1,107,122,89,98,122,43,107,1,76,20,17,21,123,81,16]

theorem envBound42534 : H12AffineFastState.Bounded env42534 := by
  intro p hp
  have h : env42534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42533_42534 : H12AffineEnvironment.transform 15 72 env42533 = env42534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env42533 == env42534) = true)

theorem identity42534 : scanCanonicalize (H12AffineFastState.compose env42534 (packedSelected [10] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound42534 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42535 : List Nat := [2,4,8,16,32,54,34,20,54,4,49,0,25,0,0,62,59,29,34,1,1,29,12,47,20,12,43,29,1,58,20,17,21,13,39,16]

theorem envBound42535 : H12AffineFastState.Bounded env42535 := by
  intro p hp
  have h : env42535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42534_42535 : H12AffineEnvironment.transform 5 54 env42534 = env42535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env42534 == env42535) = true)

theorem identity42535 : scanCanonicalize (H12AffineFastState.compose env42535 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42535 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env42536 : List Nat := [2,4,8,16,11,29,9,20,29,4,26,0,25,0,0,21,16,29,9,1,1,29,12,4,20,12,0,29,1,17,20,17,21,13,12,16]

theorem envBound42536 : H12AffineFastState.Bounded env42536 := by
  intro p hp
  have h : env42536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42535_42536 : H12AffineEnvironment.transform 4 11 env42535 = env42536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42535 == env42536) = true)

theorem identity42536 : scanCanonicalize (H12AffineFastState.compose env42536 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42536 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env42537 : List Nat := [2,4,2,16,1,23,3,20,23,4,16,0,19,0,0,21,16,23,3,1,1,23,6,4,20,6,0,23,1,17,20,17,21,7,6,16]

theorem envBound42537 : H12AffineFastState.Bounded env42537 := by
  intro p hp
  have h : env42537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42536_42537 : H12AffineEnvironment.transform 2 2 env42536 = env42537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42536 == env42537) = true)

theorem identity42537 : scanCanonicalize (H12AffineFastState.compose env42537 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42537 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env42538 : List Nat := [2,4,2,0,1,7,3,4,7,4,0,0,3,0,0,5,0,7,3,1,1,7,6,4,4,6,0,7,1,1,4,1,5,7,6,0]

theorem envBound42538 : H12AffineFastState.Bounded env42538 := by
  intro p hp
  have h : env42538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42537_42538 : H12AffineEnvironment.transform 3 0 env42537 = env42538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42537 == env42538) = true)

def env42539 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,276,65536,65894,65665,321,277,0,477,66615,65552,192,65830,318,65846,1297,67651,1285,1280,257,65830,1345,1045]

theorem envBound42539 : H12AffineFastState.Bounded env42539 := by
  intro p hp
  have h : env42539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42528_42539 : H12AffineEnvironment.transform 11 1 env42528 = env42539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42528 == env42539) = true)

theorem identity42539 : scanCanonicalize (H12AffineFastState.compose env42539 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42539 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42540 : List Nat := [2,4,8,16,32,64,128,256,340,84,2048,1,348,324,276,65536,65894,65665,321,277,0,477,65635,65552,192,65830,318,65846,325,67651,337,340,257,65830,277,65]

theorem envBound42540 : H12AffineFastState.Bounded env42540 := by
  intro p hp
  have h : env42540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42539_42540 : H12AffineEnvironment.transform 9 84 env42539 = env42540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42539 == env42540) = true)

theorem identity42540 : scanCanonicalize (H12AffineFastState.compose env42540 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2365) := by decide +kernel

theorem selectedBound42540 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42541 : List Nat := [2,4,8,16,32,64,128,256,340,84,2048,1,348,324,276,2365,2139,2492,321,277,0,477,2398,2349,192,2075,318,2059,325,382,337,340,257,2075,277,65]

theorem envBound42541 : H12AffineFastState.Bounded env42541 := by
  intro p hp
  have h : env42541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42540_42541 : H12AffineEnvironment.transform 15 2365 env42540 = env42541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2365 env42540 == env42541) = true)

theorem identity42541 : scanCanonicalize (H12AffineFastState.compose env42541 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 416) := by decide +kernel

theorem selectedBound42541 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env42542 : List Nat := [2,4,8,16,32,64,128,256,340,84,416,1,348,324,276,157,507,28,321,277,0,477,254,141,192,443,318,427,325,382,337,340,257,443,277,65]

theorem envBound42542 : H12AffineFastState.Bounded env42542 := by
  intro p hp
  have h : env42542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42541_42542 : H12AffineEnvironment.transform 10 416 env42541 = env42542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 416 env42541 == env42542) = true)

theorem identity42542 : scanCanonicalize (H12AffineFastState.compose env42542 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42542 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42543 : List Nat := [2,4,8,16,32,64,128,21,65,84,181,1,73,81,1,157,238,28,84,0,0,200,254,141,192,174,43,190,80,107,68,65,20,174,0,65]

theorem envBound42543 : H12AffineFastState.Bounded env42543 := by
  intro p hp
  have h : env42543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42542_42543 : H12AffineEnvironment.transform 7 21 env42542 = env42543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42542 == env42543) = true)

theorem identity42543 : scanCanonicalize (H12AffineFastState.compose env42543 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound42543 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42544 : List Nat := [2,4,8,16,32,55,128,21,54,35,181,1,62,38,1,157,153,28,35,0,0,191,137,141,183,174,43,190,39,28,51,54,20,174,0,54]

theorem envBound42544 : H12AffineFastState.Bounded env42544 := by
  intro p hp
  have h : env42544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42543_42544 : H12AffineEnvironment.transform 5 55 env42543 = env42544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env42543 == env42544) = true)

theorem identity42544 : scanCanonicalize (H12AffineFastState.compose env42544 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound42544 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env42545 : List Nat := [2,4,8,6,32,33,128,3,32,35,163,1,40,38,1,139,143,10,35,0,0,169,137,141,161,174,43,168,39,10,37,32,2,174,0,32]

theorem envBound42545 : H12AffineFastState.Bounded env42545 := by
  intro p hp
  have h : env42545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42544_42545 : H12AffineEnvironment.transform 3 6 env42544 = env42545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env42544 == env42545) = true)

end H12CloudChart2