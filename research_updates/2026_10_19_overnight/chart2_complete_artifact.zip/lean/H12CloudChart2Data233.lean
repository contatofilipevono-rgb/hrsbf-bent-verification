import H12CloudChart2Data232

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans58829_58830 : H12AffineEnvironment.transform 0 1 env58829 = env58830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58829 == env58830) = true)

def env58831 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,65536,66082,65664,516,576,837,648,66083,65537,193,65831,303,66163,64,67651,784,81,256,65830,17,340]

theorem envBound58831 : H12AffineFastState.Bounded env58831 := by
  intro p hp
  have h : env58831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58810_58831 : H12AffineEnvironment.transform 9 337 env58810 = env58831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env58810 == env58831) = true)

theorem identity58831 : scanCanonicalize (H12AffineFastState.compose env58831 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 875) := by decide +kernel

theorem selectedBound58831 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58832 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,875,329,1003,516,576,837,648,328,874,193,588,303,280,64,2856,784,81,256,589,17,340]

theorem envBound58832 : H12AffineFastState.Bounded env58832 := by
  intro p hp
  have h : env58832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58831_58832 : H12AffineEnvironment.transform 15 875 env58831 = env58832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 875 env58831 == env58832) = true)

def env58833 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,780,65,577,875,329,1003,516,576,837,648,328,874,193,588,303,264,64,2856,768,65,256,589,1,324]

theorem envBound58833 : H12AffineFastState.Bounded env58833 := by
  intro p hp
  have h : env58833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58832_58833 : H12AffineEnvironment.transform 3 0 env58832 = env58833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58832 == env58833) = true)

theorem identity58833 : scanCanonicalize (H12AffineFastState.compose env58833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound58833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58834 : List Nat := [2,4,8,0,32,64,128,256,64,321,2048,260,332,65,1,299,329,427,68,0,261,200,328,298,193,12,303,264,64,2408,320,65,256,13,1,324]

theorem envBound58834 : H12AffineFastState.Bounded env58834 := by
  intro p hp
  have h : env58834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58833_58834 : H12AffineEnvironment.transform 8 64 env58833 = env58834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env58833 == env58834) = true)

theorem identity58834 : scanCanonicalize (H12AffineFastState.compose env58834 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound58834 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58835 : List Nat := [2,4,8,0,32,64,128,8,64,73,2048,12,68,65,1,35,65,163,68,0,13,200,64,34,193,12,39,0,64,2144,72,65,8,13,1,76]

theorem envBound58835 : H12AffineFastState.Bounded env58835 := by
  intro p hp
  have h : env58835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58834_58835 : H12AffineEnvironment.transform 7 8 env58834 = env58835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env58834 == env58835) = true)

theorem identity58835 : scanCanonicalize (H12AffineFastState.compose env58835 (packedSelected [1,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound58835 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env58836 : List Nat := [2,4,8,0,32,64,128,8,64,73,168,12,68,65,1,35,65,163,68,0,13,200,64,34,193,12,39,0,64,200,72,65,8,13,1,76]

theorem envBound58836 : H12AffineFastState.Bounded env58836 := by
  intro p hp
  have h : env58836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58835_58836 : H12AffineEnvironment.transform 10 168 env58835 = env58836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env58835 == env58836) = true)

theorem identity58836 : scanCanonicalize (H12AffineFastState.compose env58836 (packedSelected [0,1,3,7,8,11,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58836 : packedSelected [0,1,3,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58837 : List Nat := [2,4,4,0,32,64,128,4,64,69,164,0,68,65,1,35,65,163,68,0,1,196,64,34,193,0,39,0,64,196,68,65,4,1,1,64]

theorem envBound58837 : H12AffineFastState.Bounded env58837 := by
  intro p hp
  have h : env58837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58836_58837 : H12AffineEnvironment.transform 2 4 env58836 = env58837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58836 == env58837) = true)

theorem identity58837 : scanCanonicalize (H12AffineFastState.compose env58837 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58837 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58838 : List Nat := [2,4,4,0,0,64,128,4,64,69,132,0,68,65,1,3,65,131,68,0,1,196,64,2,193,0,7,0,64,196,68,65,4,1,1,64]

theorem envBound58838 : H12AffineFastState.Bounded env58838 := by
  intro p hp
  have h : env58838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58837_58838 : H12AffineEnvironment.transform 4 0 env58837 = env58838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58837 == env58838) = true)

theorem identity58838 : scanCanonicalize (H12AffineFastState.compose env58838 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound58838 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env58839 : List Nat := [2,4,4,0,0,1,128,4,1,4,132,0,5,0,1,3,0,131,5,0,1,133,1,2,128,0,7,0,1,133,5,0,4,1,1,1]

theorem envBound58839 : H12AffineFastState.Bounded env58839 := by
  intro p hp
  have h : env58839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58838_58839 : H12AffineEnvironment.transform 5 1 env58838 = env58839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env58838 == env58839) = true)

theorem identity58839 : scanCanonicalize (H12AffineFastState.compose env58839 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound58839 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58840 : List Nat := [2,4,4,0,0,1,4,4,1,4,0,0,5,0,1,3,0,7,5,0,1,1,1,2,4,0,7,0,1,1,5,0,4,1,1,1]

theorem envBound58840 : H12AffineFastState.Bounded env58840 := by
  intro p hp
  have h : env58840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58839_58840 : H12AffineEnvironment.transform 6 4 env58839 = env58840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env58839 == env58840) = true)

def env58841 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,781,65,577,875,329,1003,516,576,837,648,328,874,193,588,303,265,64,2856,769,64,256,589,0,325]

theorem envBound58841 : H12AffineFastState.Bounded env58841 := by
  intro p hp
  have h : env58841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58832_58841 : H12AffineEnvironment.transform 3 1 env58832 = env58841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58832 == env58841) = true)

theorem identity58841 : scanCanonicalize (H12AffineFastState.compose env58841 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound58841 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58842 : List Nat := [2,4,8,1,32,64,128,5,512,69,2048,577,520,65,577,622,76,750,516,576,576,648,77,623,193,588,42,12,64,2605,516,64,5,589,0,64]

theorem envBound58842 : H12AffineFastState.Bounded env58842 := by
  intro p hp
  have h : env58842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58841_58842 : H12AffineEnvironment.transform 7 5 env58841 = env58842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env58841 == env58842) = true)

theorem identity58842 : scanCanonicalize (H12AffineFastState.compose env58842 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound58842 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58843 : List Nat := [2,4,8,1,32,64,128,5,512,69,162,577,520,65,577,622,76,750,516,576,576,648,77,623,193,588,42,12,64,655,516,64,5,589,0,64]

theorem envBound58843 : H12AffineFastState.Bounded env58843 := by
  intro p hp
  have h : env58843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58842_58843 : H12AffineEnvironment.transform 10 162 env58842 = env58843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env58842 == env58843) = true)

theorem identity58843 : scanCanonicalize (H12AffineFastState.compose env58843 (packedSelected [0,1,2,3,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58843 : packedSelected [0,1,2,3,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env58844 : List Nat := [2,4,8,1,0,64,128,5,512,69,130,577,520,65,577,590,76,718,516,576,576,648,77,591,193,588,10,12,64,655,516,64,5,589,0,64]

theorem envBound58844 : H12AffineFastState.Bounded env58844 := by
  intro p hp
  have h : env58844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58843_58844 : H12AffineEnvironment.transform 4 0 env58843 = env58844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58843 == env58844) = true)

theorem identity58844 : scanCanonicalize (H12AffineFastState.compose env58844 (packedSelected [0,9,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58844 : packedSelected [0,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58845 : List Nat := [2,4,5,1,0,64,128,5,512,69,130,577,517,65,577,579,65,707,516,576,576,645,64,578,193,577,7,1,64,642,516,64,5,576,0,64]

theorem envBound58845 : H12AffineFastState.Bounded env58845 := by
  intro p hp
  have h : env58845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58844_58845 : H12AffineEnvironment.transform 2 5 env58844 = env58845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58844 == env58845) = true)

theorem identity58845 : scanCanonicalize (H12AffineFastState.compose env58845 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58845 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env58846 : List Nat := [2,4,5,1,0,64,128,5,1,69,130,64,4,65,64,66,65,194,5,65,65,132,64,67,193,64,7,1,64,131,5,64,5,65,0,64]

theorem envBound58846 : H12AffineFastState.Bounded env58846 := by
  intro p hp
  have h : env58846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58845_58846 : H12AffineEnvironment.transform 8 1 env58845 = env58846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58845 == env58846) = true)

theorem identity58846 : scanCanonicalize (H12AffineFastState.compose env58846 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound58846 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58847 : List Nat := [2,4,5,1,0,64,2,5,1,69,0,64,4,65,64,66,65,64,5,65,65,6,64,67,67,64,7,1,64,1,5,64,5,65,0,64]

theorem envBound58847 : H12AffineFastState.Bounded env58847 := by
  intro p hp
  have h : env58847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58846_58847 : H12AffineEnvironment.transform 6 2 env58846 = env58847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env58846 == env58847) = true)

def env58848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4097,5277,74047,66896,13768,78894,1151,74814,1297,81226,8204,1280,256,65830,1344,5953]

theorem envBound58848 : H12AffineFastState.Bounded env58848 := by
  intro p hp
  have h : env58848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58773_58848 : H12AffineEnvironment.transform 17 65665 env58773 = env58848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58773 == env58848) = true)

theorem identity58848 : scanCanonicalize (H12AffineFastState.compose env58848 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound58848 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,65536,66598,65665,4416,277,4097,5277,65910,66896,5505,70759,1151,66679,1297,72963,69,1280,256,65830,1344,5953]

theorem envBound58849 : H12AffineFastState.Bounded env58849 := by
  intro p hp
  have h : env58849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58848_58849 : H12AffineEnvironment.transform 12 73 env58848 = env58849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env58848 == env58849) = true)

def env58850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1296,276,65536,66598,65665,1876,277,1557,649,65910,66896,917,66163,1151,66679,1297,68375,69,1280,256,65830,1344,341]

theorem envBound58850 : H12AffineFastState.Bounded env58850 := by
  intro p hp
  have h : env58850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58849_58850 : H12AffineEnvironment.transform 11 1556 env58849 = env58850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env58849 == env58850) = true)

def env58851 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,65536,65894,65665,532,277,853,649,65910,65552,917,66163,319,65847,81,68375,69,64,256,65830,0,341]

theorem envBound58851 : H12AffineFastState.Bounded env58851 := by
  intro p hp
  have h : env58851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58850_58851 : H12AffineEnvironment.transform 9 320 env58850 = env58851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58850 == env58851) = true)

theorem identity58851 : scanCanonicalize (H12AffineFastState.compose env58851 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound58851 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58852 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,276,73,80,276,65536,65894,65665,84,277,277,201,65910,65552,469,65587,319,65847,81,67927,69,64,256,65830,0,341]

theorem envBound58852 : H12AffineFastState.Bounded env58852 := by
  intro p hp
  have h : env58852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58851_58852 : H12AffineEnvironment.transform 8 64 env58851 = env58852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env58851 == env58852) = true)

theorem identity58852 : scanCanonicalize (H12AffineFastState.compose env58852 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58852 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env58853 : List Nat := [2,4,8,16,32,64,128,21,64,85,2048,1,73,80,1,65536,65651,65665,84,0,0,201,65635,65552,192,65587,42,65570,81,67650,69,64,21,65587,0,64]

theorem envBound58853 : H12AffineFastState.Bounded env58853 := by
  intro p hp
  have h : env58853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58852_58853 : H12AffineEnvironment.transform 7 21 env58852 = env58853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58852 == env58853) = true)

theorem identity58853 : scanCanonicalize (H12AffineFastState.compose env58853 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound58853 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58854 : List Nat := [2,4,8,16,32,64,73,21,64,85,2048,1,73,80,1,65536,65651,65608,84,0,0,0,65635,65552,9,65587,42,65570,81,67650,69,64,21,65587,0,64]

theorem envBound58854 : H12AffineFastState.Bounded env58854 := by
  intro p hp
  have h : env58854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58853_58854 : H12AffineEnvironment.transform 6 73 env58853 = env58854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env58853 == env58854) = true)

theorem identity58854 : scanCanonicalize (H12AffineFastState.compose env58854 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound58854 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env58855 : List Nat := [2,4,8,16,1,64,73,21,64,85,2048,1,73,80,1,65536,65618,65608,84,0,0,0,65602,65552,9,65554,11,65539,81,67650,69,64,21,65554,0,64]

theorem envBound58855 : H12AffineFastState.Bounded env58855 := by
  intro p hp
  have h : env58855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58854_58855 : H12AffineEnvironment.transform 4 1 env58854 = env58855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env58854 == env58855) = true)

theorem identity58855 : scanCanonicalize (H12AffineFastState.compose env58855 (packedSelected [0,2,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound58855 : packedSelected [0,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env58856 : List Nat := [2,4,8,16,1,64,73,21,64,85,77,1,73,80,1,65536,65618,65608,84,0,0,0,65602,65552,9,65554,11,65539,81,65551,69,64,21,65554,0,64]

theorem envBound58856 : H12AffineFastState.Bounded env58856 := by
  intro p hp
  have h : env58856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58855_58856 : H12AffineEnvironment.transform 10 77 env58855 = env58856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env58855 == env58856) = true)

theorem identity58856 : scanCanonicalize (H12AffineFastState.compose env58856 (packedSelected [0,4,5,7,9,13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58856 : packedSelected [0,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58857 : List Nat := [2,4,2,16,1,64,67,21,64,85,71,1,67,80,1,65536,65618,65602,84,0,0,0,65602,65552,3,65554,1,65539,81,65541,69,64,21,65554,0,64]

theorem envBound58857 : H12AffineFastState.Bounded env58857 := by
  intro p hp
  have h : env58857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58856_58857 : H12AffineEnvironment.transform 2 2 env58856 = env58857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58856 == env58857) = true)

theorem identity58857 : scanCanonicalize (H12AffineFastState.compose env58857 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58857 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env58858 : List Nat := [2,2,2,16,1,64,67,19,64,83,65,1,67,80,1,65536,65618,65602,82,0,0,0,65602,65552,3,65554,1,65539,81,65539,67,64,19,65554,0,64]

theorem envBound58858 : H12AffineFastState.Bounded env58858 := by
  intro p hp
  have h : env58858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58857_58858 : H12AffineEnvironment.transform 1 2 env58857 = env58858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58857 == env58858) = true)

theorem identity58858 : scanCanonicalize (H12AffineFastState.compose env58858 (packedSelected [2,3] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound58858 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58859 : List Nat := [2,2,2,16,1,64,67,19,64,83,65,1,67,80,1,18,64,80,82,0,0,0,80,2,3,0,1,17,81,17,67,64,19,0,0,64]

theorem envBound58859 : H12AffineFastState.Bounded env58859 := by
  intro p hp
  have h : env58859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58858_58859 : H12AffineEnvironment.transform 15 18 env58858 = env58859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env58858 == env58859) = true)

def env58860 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,65536,65895,65665,533,277,852,649,65910,65553,917,66163,318,65846,80,68375,69,65,256,65830,1,341]

theorem envBound58860 : H12AffineFastState.Bounded env58860 := by
  intro p hp
  have h : env58860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58850_58860 : H12AffineEnvironment.transform 9 321 env58850 = env58860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58850 == env58860) = true)

theorem identity58860 : scanCanonicalize (H12AffineFastState.compose env58860 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58860 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58861 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,576,73,81,1,65536,65650,65665,533,0,577,649,65635,65553,640,66163,43,65571,80,68098,69,65,21,65587,1,64]

theorem envBound58861 : H12AffineFastState.Bounded env58861 := by
  intro p hp
  have h : env58861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58860_58861 : H12AffineEnvironment.transform 7 21 env58860 = env58861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58860 == env58861) = true)

theorem identity58861 : scanCanonicalize (H12AffineFastState.compose env58861 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound58861 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58862 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,576,73,81,1,35,81,162,533,0,577,649,64,50,640,592,43,0,80,2593,69,65,21,16,1,64]

theorem envBound58862 : H12AffineFastState.Bounded env58862 := by
  intro p hp
  have h : env58862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58861_58862 : H12AffineEnvironment.transform 15 35 env58861 = env58862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env58861 == env58862) = true)

theorem identity58862 : scanCanonicalize (H12AffineFastState.compose env58862 (packedSelected [1,10,11,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 615) := by decide +kernel

theorem selectedBound58862 : packedSelected [1,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env58863 : List Nat := [2,4,8,16,32,64,128,21,512,84,615,576,73,81,1,35,81,162,533,0,577,649,64,50,640,592,43,0,80,70,69,65,21,16,1,64]

theorem envBound58863 : H12AffineFastState.Bounded env58863 := by
  intro p hp
  have h : env58863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58862_58863 : H12AffineEnvironment.transform 10 615 env58862 = env58863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 615 env58862 == env58863) = true)

theorem identity58863 : scanCanonicalize (H12AffineFastState.compose env58863 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound58863 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58864 : List Nat := [2,4,8,16,32,64,128,21,16,84,119,80,73,81,1,35,81,162,5,0,81,153,64,50,144,64,43,0,80,70,69,65,21,16,1,64]

theorem envBound58864 : H12AffineFastState.Bounded env58864 := by
  intro p hp
  have h : env58864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58863_58864 : H12AffineEnvironment.transform 8 16 env58863 = env58864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env58863 == env58864) = true)

theorem identity58864 : scanCanonicalize (H12AffineFastState.compose env58864 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound58864 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env58865 : List Nat := [2,4,8,16,32,64,110,21,16,84,119,80,73,81,1,35,81,76,5,0,81,119,64,50,126,64,43,0,80,70,69,65,21,16,1,64]

theorem envBound58865 : H12AffineFastState.Bounded env58865 := by
  intro p hp
  have h : env58865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58864_58865 : H12AffineEnvironment.transform 6 110 env58864 = env58865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env58864 == env58865) = true)

theorem identity58865 : scanCanonicalize (H12AffineFastState.compose env58865 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58866 : List Nat := [2,4,8,16,17,64,95,21,16,84,70,80,73,81,1,18,81,76,5,0,81,70,64,3,79,64,26,0,80,70,69,65,21,16,1,64]

theorem envBound58866 : H12AffineFastState.Bounded env58866 := by
  intro p hp
  have h : env58866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58865_58866 : H12AffineEnvironment.transform 4 17 env58865 = env58866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58865 == env58866) = true)

theorem identity58866 : scanCanonicalize (H12AffineFastState.compose env58866 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58866 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58867 : List Nat := [2,4,8,16,17,11,20,21,16,31,13,27,2,26,1,18,26,7,5,0,26,13,11,3,4,11,26,0,27,13,14,10,21,16,1,11]

theorem envBound58867 : H12AffineFastState.Bounded env58867 := by
  intro p hp
  have h : env58867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58866_58867 : H12AffineEnvironment.transform 5 11 env58866 = env58867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58866 == env58867) = true)

theorem identity58867 : scanCanonicalize (H12AffineFastState.compose env58867 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58867 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env58868 : List Nat := [2,4,5,16,17,6,20,21,16,18,0,22,2,23,1,18,23,7,5,0,23,0,6,3,4,6,23,0,22,0,3,7,21,16,1,6]

theorem envBound58868 : H12AffineFastState.Bounded env58868 := by
  intro p hp
  have h : env58868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58867_58868 : H12AffineEnvironment.transform 2 5 env58867 = env58868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58867 == env58868) = true)

theorem identity58868 : scanCanonicalize (H12AffineFastState.compose env58868 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58869 : List Nat := [2,3,2,16,17,1,19,18,16,18,0,17,2,16,1,18,16,0,2,0,16,0,1,3,3,1,16,0,17,0,3,0,18,16,1,1]

theorem envBound58869 : H12AffineFastState.Bounded env58869 := by
  intro p hp
  have h : env58869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58868_58869 : H12AffineEnvironment.transform 1 3 env58868 = env58869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58868 == env58869) = true)

def env58870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1296,276,65536,66598,65665,1877,277,1556,648,65910,66896,916,66162,1151,66679,1297,68374,69,1280,256,65830,1344,340]

theorem envBound58870 : H12AffineFastState.Bounded env58870 := by
  intro p hp
  have h : env58870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58849_58870 : H12AffineEnvironment.transform 11 1557 env58849 = env58870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env58849 == env58870) = true)

def env58871 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,65536,65894,65665,533,277,852,648,65910,65552,916,66162,319,65847,81,68374,69,64,256,65830,0,340]

theorem envBound58871 : H12AffineFastState.Bounded env58871 := by
  intro p hp
  have h : env58871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58870_58871 : H12AffineEnvironment.transform 9 320 env58870 = env58871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58870 == env58871) = true)

theorem identity58871 : scanCanonicalize (H12AffineFastState.compose env58871 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound58871 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58872 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,276,73,80,276,65536,65894,65665,84,277,277,201,65910,65552,469,65587,319,65847,81,67927,69,64,256,65830,0,340]

theorem envBound58872 : H12AffineFastState.Bounded env58872 := by
  intro p hp
  have h : env58872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58871_58872 : H12AffineEnvironment.transform 8 65 env58871 = env58872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env58871 == env58872) = true)

theorem identity58872 : scanCanonicalize (H12AffineFastState.compose env58872 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58872 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env58873 : List Nat := [2,4,8,16,32,64,128,21,65,85,2048,1,73,80,1,65536,65651,65665,84,0,0,201,65635,65552,192,65587,42,65570,81,67650,69,64,21,65587,0,65]

theorem envBound58873 : H12AffineFastState.Bounded env58873 := by
  intro p hp
  have h : env58873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58872_58873 : H12AffineEnvironment.transform 7 21 env58872 = env58873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58872 == env58873) = true)

theorem identity58873 : scanCanonicalize (H12AffineFastState.compose env58873 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound58873 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58874 : List Nat := [2,4,8,16,32,64,72,21,65,85,2048,1,73,80,1,65536,65651,65609,84,0,0,1,65635,65552,8,65587,42,65570,81,67650,69,64,21,65587,0,65]

theorem envBound58874 : H12AffineFastState.Bounded env58874 := by
  intro p hp
  have h : env58874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58873_58874 : H12AffineEnvironment.transform 6 72 env58873 = env58874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env58873 == env58874) = true)

theorem identity58874 : scanCanonicalize (H12AffineFastState.compose env58874 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58874 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env58875 : List Nat := [2,4,8,16,0,64,72,21,65,85,2048,1,73,80,1,65536,65619,65609,84,0,0,1,65603,65552,8,65555,10,65538,81,67650,69,64,21,65555,0,65]

theorem envBound58875 : H12AffineFastState.Bounded env58875 := by
  intro p hp
  have h : env58875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58874_58875 : H12AffineEnvironment.transform 4 0 env58874 = env58875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58874 == env58875) = true)

theorem identity58875 : scanCanonicalize (H12AffineFastState.compose env58875 (packedSelected [0,2,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 2079) := by decide +kernel

theorem selectedBound58875 : packedSelected [0,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env58876 : List Nat := [2,4,8,16,0,64,72,21,65,85,2048,1,73,80,1,2079,2124,2134,84,0,0,1,2140,2063,8,2060,10,2077,81,93,69,64,21,2060,0,65]

theorem envBound58876 : H12AffineFastState.Bounded env58876 := by
  intro p hp
  have h : env58876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58875_58876 : H12AffineEnvironment.transform 15 2079 env58875 = env58876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2079 env58875 == env58876) = true)

theorem identity58876 : scanCanonicalize (H12AffineFastState.compose env58876 (packedSelected [0,4,5,7,9,13] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58876 : packedSelected [0,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58877 : List Nat := [2,4,3,16,0,64,67,21,65,85,2048,1,66,80,1,2068,2119,2134,84,0,0,1,2135,2052,3,2055,1,2070,81,86,69,64,21,2055,0,65]

theorem envBound58877 : H12AffineFastState.Bounded env58877 := by
  intro p hp
  have h : env58877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58876_58877 : H12AffineEnvironment.transform 2 3 env58876 = env58877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58876 == env58877) = true)

theorem identity58877 : scanCanonicalize (H12AffineFastState.compose env58877 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound58877 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env58878 : List Nat := [2,4,3,16,0,64,67,21,65,85,64,1,66,80,1,84,7,22,84,0,0,1,23,68,3,71,1,86,81,86,69,64,21,71,0,65]

theorem envBound58878 : H12AffineFastState.Bounded env58878 := by
  intro p hp
  have h : env58878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58877_58878 : H12AffineEnvironment.transform 10 64 env58877 = env58878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env58877 == env58878) = true)

theorem identity58878 : scanCanonicalize (H12AffineFastState.compose env58878 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound58878 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58879 : List Nat := [2,4,3,16,0,6,5,21,7,19,6,1,4,22,1,18,7,22,18,0,0,1,23,2,3,1,1,16,23,16,3,6,21,1,0,7]

theorem envBound58879 : H12AffineFastState.Bounded env58879 := by
  intro p hp
  have h : env58879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58878_58879 : H12AffineEnvironment.transform 5 6 env58878 = env58879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env58878 == env58879) = true)

def env58880 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,65536,65895,65665,532,277,853,648,65910,65553,916,66162,318,65846,80,68374,69,65,256,65830,1,340]

theorem envBound58880 : H12AffineFastState.Bounded env58880 := by
  intro p hp
  have h : env58880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58870_58880 : H12AffineEnvironment.transform 9 321 env58870 = env58880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58870 == env58880) = true)

theorem identity58880 : scanCanonicalize (H12AffineFastState.compose env58880 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58880 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58881 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,577,73,81,1,65536,65650,65665,532,0,576,648,65635,65553,641,66162,43,65571,80,68099,69,65,21,65587,1,65]

theorem envBound58881 : H12AffineFastState.Bounded env58881 := by
  intro p hp
  have h : env58881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58880_58881 : H12AffineEnvironment.transform 7 21 env58880 = env58881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58880 == env58881) = true)

theorem identity58881 : scanCanonicalize (H12AffineFastState.compose env58881 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound58881 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58882 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,577,73,81,1,35,81,162,532,0,576,648,64,50,641,593,43,0,80,2592,69,65,21,16,1,65]

theorem envBound58882 : H12AffineFastState.Bounded env58882 := by
  intro p hp
  have h : env58882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58881_58882 : H12AffineEnvironment.transform 15 35 env58881 = env58882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env58881 == env58882) = true)

theorem identity58882 : scanCanonicalize (H12AffineFastState.compose env58882 (packedSelected [1,10,11,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 567) := by decide +kernel

theorem selectedBound58882 : packedSelected [1,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env58883 : List Nat := [2,4,8,16,32,64,128,21,512,84,567,577,73,81,1,35,81,162,532,0,576,648,64,50,641,593,43,0,80,23,69,65,21,16,1,65]

theorem envBound58883 : H12AffineFastState.Bounded env58883 := by
  intro p hp
  have h : env58883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58882_58883 : H12AffineEnvironment.transform 10 567 env58882 = env58883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 567 env58882 == env58883) = true)

theorem identity58883 : scanCanonicalize (H12AffineFastState.compose env58883 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound58883 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58884 : List Nat := [2,4,8,16,32,64,128,21,17,84,38,80,73,81,1,35,81,162,5,0,81,153,64,50,144,64,43,0,80,23,69,65,21,16,1,65]

theorem envBound58884 : H12AffineFastState.Bounded env58884 := by
  intro p hp
  have h : env58884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58883_58884 : H12AffineEnvironment.transform 8 17 env58883 = env58884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env58883 == env58884) = true)

theorem identity58884 : scanCanonicalize (H12AffineFastState.compose env58884 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound58884 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env58885 : List Nat := [2,4,8,16,32,64,110,21,17,84,38,80,73,81,1,35,81,76,5,0,81,119,64,50,126,64,43,0,80,23,69,65,21,16,1,65]

theorem envBound58885 : H12AffineFastState.Bounded env58885 := by
  intro p hp
  have h : env58885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58884_58885 : H12AffineEnvironment.transform 6 110 env58884 = env58885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env58884 == env58885) = true)

theorem identity58885 : scanCanonicalize (H12AffineFastState.compose env58885 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58885 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58886 : List Nat := [2,4,8,16,17,64,95,21,17,84,23,80,73,81,1,18,81,76,5,0,81,70,64,3,79,64,26,0,80,23,69,65,21,16,1,65]

theorem envBound58886 : H12AffineFastState.Bounded env58886 := by
  intro p hp
  have h : env58886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58885_58886 : H12AffineEnvironment.transform 4 17 env58885 = env58886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58885 == env58886) = true)

theorem identity58886 : scanCanonicalize (H12AffineFastState.compose env58886 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58886 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58887 : List Nat := [2,4,8,16,17,11,20,21,17,31,23,27,2,26,1,18,26,7,5,0,26,13,11,3,4,11,26,0,27,23,14,10,21,16,1,10]

theorem envBound58887 : H12AffineFastState.Bounded env58887 := by
  intro p hp
  have h : env58887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58886_58887 : H12AffineEnvironment.transform 5 11 env58886 = env58887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58886 == env58887) = true)

theorem identity58887 : scanCanonicalize (H12AffineFastState.compose env58887 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound58887 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env58888 : List Nat := [2,4,8,7,6,11,3,2,6,8,0,12,2,13,1,5,13,7,5,0,13,13,11,3,4,11,13,0,12,0,14,10,2,7,1,10]

theorem envBound58888 : H12AffineFastState.Bounded env58888 := by
  intro p hp
  have h : env58888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58887_58888 : H12AffineEnvironment.transform 3 7 env58887 = env58888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env58887 == env58888) = true)

theorem identity58888 : scanCanonicalize (H12AffineFastState.compose env58888 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58889 : List Nat := [2,4,3,7,6,0,3,2,6,3,0,7,2,6,1,5,6,7,5,0,6,6,0,3,4,0,6,0,7,0,5,1,2,7,1,1]

theorem envBound58889 : H12AffineFastState.Bounded env58889 := by
  intro p hp
  have h : env58889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58888_58889 : H12AffineEnvironment.transform 2 3 env58888 = env58889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58888 == env58889) = true)

def env58890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4097,5277,74046,66896,13769,78894,328958,74815,1297,81227,8205,1280,256,65831,1344,5952]

theorem envBound58890 : H12AffineFastState.Bounded env58890 := by
  intro p hp
  have h : env58890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58772_58890 : H12AffineEnvironment.transform 13 1297 env58772 = env58890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58772 == env58890) = true)

def env58891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4097,5277,74046,66896,13769,78894,1150,74815,1297,81227,8205,1280,256,65831,1344,5952]

theorem envBound58891 : H12AffineFastState.Bounded env58891 := by
  intro p hp
  have h : env58891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58890_58891 : H12AffineEnvironment.transform 17 65664 env58890 = env58891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58890 == env58891) = true)

theorem identity58891 : scanCanonicalize (H12AffineFastState.compose env58891 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound58891 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58892 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,65536,74031,65664,4417,8541,4097,4573,74046,65552,12425,78190,318,74111,81,79883,8205,64,256,65831,0,4608]

theorem envBound58892 : H12AffineFastState.Bounded env58892 := by
  intro p hp
  have h : env58892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58891_58892 : H12AffineEnvironment.transform 9 320 env58891 = env58892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58891 == env58892) = true)

def env58893 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,81,8540,65536,74031,65664,533,8541,853,649,74046,65552,9181,74298,318,74111,81,76639,8205,64,256,65831,0,340]

theorem envBound58893 : H12AffineFastState.Bounded env58893 := by
  intro p hp
  have h : env58893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58892_58893 : H12AffineEnvironment.transform 11 852 env58892 = env58893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env58892 == env58893) = true)

def env58894 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,65536,74031,65664,517,8525,837,649,74030,65536,9165,74282,302,74095,65,76623,8205,64,256,65831,0,324]

theorem envBound58894 : H12AffineFastState.Bounded env58894 := by
  intro p hp
  have h : env58894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58893_58894 : H12AffineEnvironment.transform 3 0 env58893 = env58894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58893 == env58894) = true)

theorem identity58894 : scanCanonicalize (H12AffineFastState.compose env58894 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8619) := by decide +kernel

theorem selectedBound58894 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58895 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,8619,132,8491,517,8525,837,649,133,8619,9165,897,302,196,65,2788,8205,64,256,8332,0,324]

theorem envBound58895 : H12AffineFastState.Bounded env58895 := by
  intro p hp
  have h : env58895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58894_58895 : H12AffineEnvironment.transform 15 8619 env58894 = env58895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8619 env58894 == env58895) = true)

def env58896 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,204,65,384,359,132,487,517,385,837,649,133,359,769,897,302,196,65,2788,193,64,256,64,0,324]

theorem envBound58896 : H12AffineFastState.Bounded env58896 := by
  intro p hp
  have h : env58896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58895_58896 : H12AffineEnvironment.transform 12 204 env58895 = env58896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 204 env58895 == env58896) = true)

theorem identity58896 : scanCanonicalize (H12AffineFastState.compose env58896 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58896 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58897 : List Nat := [2,4,8,0,32,64,128,256,1,320,2048,325,204,65,384,359,132,487,4,385,324,136,133,359,256,384,302,196,65,2277,193,64,256,64,0,324]

theorem envBound58897 : H12AffineFastState.Bounded env58897 := by
  intro p hp
  have h : env58897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58896_58897 : H12AffineEnvironment.transform 8 1 env58896 = env58897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58896 == env58897) = true)

theorem identity58897 : scanCanonicalize (H12AffineFastState.compose env58897 (packedSelected [2,5,8,10,12,15,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 139) := by decide +kernel

theorem selectedBound58897 : packedSelected [2,5,8,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env58898 : List Nat := [2,4,8,0,32,64,128,139,1,203,2048,206,204,65,11,236,132,108,4,10,207,136,133,236,139,11,165,196,65,2277,193,64,139,64,0,207]

theorem envBound58898 : H12AffineFastState.Bounded env58898 := by
  intro p hp
  have h : env58898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58897_58898 : H12AffineEnvironment.transform 7 139 env58897 = env58898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 139 env58897 == env58898) = true)

theorem identity58898 : scanCanonicalize (H12AffineFastState.compose env58898 (packedSelected [0,2,3,4,7,9,10,12,13,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58898 : packedSelected [0,2,3,4,7,9,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env58899 : List Nat := [2,4,8,0,32,64,34,41,1,105,2048,108,110,65,11,78,38,108,4,10,109,42,39,78,41,11,7,102,65,2119,99,64,41,64,0,109]

theorem envBound58899 : H12AffineFastState.Bounded env58899 := by
  intro p hp
  have h : env58899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58898_58899 : H12AffineEnvironment.transform 6 34 env58898 = env58899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58898 == env58899) = true)

theorem identity58899 : scanCanonicalize (H12AffineFastState.compose env58899 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58899 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env58900 : List Nat := [2,4,8,0,7,64,5,14,1,78,2048,75,73,65,11,78,1,75,4,10,74,13,0,78,14,11,7,65,65,2119,68,64,14,64,0,74]

theorem envBound58900 : H12AffineFastState.Bounded env58900 := by
  intro p hp
  have h : env58900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58899_58900 : H12AffineEnvironment.transform 4 7 env58899 = env58900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58899 == env58900) = true)

theorem identity58900 : scanCanonicalize (H12AffineFastState.compose env58900 (packedSelected [4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound58900 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env58901 : List Nat := [2,4,8,0,7,64,5,14,1,78,11,75,73,65,11,78,1,75,4,10,74,13,0,78,14,11,7,65,65,76,68,64,14,64,0,74]

theorem envBound58901 : H12AffineFastState.Bounded env58901 := by
  intro p hp
  have h : env58901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58900_58901 : H12AffineEnvironment.transform 10 11 env58900 = env58901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env58900 == env58901) = true)

theorem identity58901 : scanCanonicalize (H12AffineFastState.compose env58901 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound58901 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env58902 : List Nat := [2,4,8,0,7,12,5,14,1,2,11,7,5,13,11,2,1,7,4,10,6,13,0,2,14,11,7,13,13,0,8,12,14,12,0,6]

theorem envBound58902 : H12AffineFastState.Bounded env58902 := by
  intro p hp
  have h : env58902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58901_58902 : H12AffineEnvironment.transform 5 12 env58901 = env58902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env58901 == env58902) = true)

theorem identity58902 : scanCanonicalize (H12AffineFastState.compose env58902 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58902 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58903 : List Nat := [2,4,4,0,7,0,5,2,1,2,7,7,5,1,7,2,1,7,4,6,6,1,0,2,2,7,7,1,1,0,4,0,2,0,0,6]

theorem envBound58903 : H12AffineFastState.Bounded env58903 := by
  intro p hp
  have h : env58903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58902_58903 : H12AffineEnvironment.transform 2 4 env58902 = env58903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58902 == env58903) = true)

theorem identity58903 : scanCanonicalize (H12AffineFastState.compose env58903 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58904 : List Nat := [2,2,2,0,1,0,3,2,1,2,1,1,3,1,1,2,1,1,2,0,0,1,0,2,2,1,1,1,1,0,2,0,2,0,0,0]

theorem envBound58904 : H12AffineFastState.Bounded env58904 := by
  intro p hp
  have h : env58904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58903_58904 : H12AffineEnvironment.transform 1 2 env58903 = env58904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58903 == env58904) = true)

theorem identity58904 : scanCanonicalize (H12AffineFastState.compose env58904 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58905 : List Nat := [0,0,0,0,1,0,1,0,1,0,1,1,1,1,1,0,1,1,0,0,0,1,0,0,0,1,1,1,1,0,0,0,0,0,0,0]

theorem envBound58905 : H12AffineFastState.Bounded env58905 := by
  intro p hp
  have h : env58905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58904_58905 : H12AffineEnvironment.transform 0 0 env58904 = env58905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58904 == env58905) = true)

def env58906 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,205,65,385,358,132,486,517,384,837,649,133,358,768,897,302,196,65,2788,192,64,256,65,0,324]

theorem envBound58906 : H12AffineFastState.Bounded env58906 := by
  intro p hp
  have h : env58906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58895_58906 : H12AffineEnvironment.transform 12 205 env58895 = env58906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env58895 == env58906) = true)

theorem identity58906 : scanCanonicalize (H12AffineFastState.compose env58906 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 384) := by decide +kernel

theorem selectedBound58906 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58907 : List Nat := [2,4,8,0,32,64,128,256,384,320,2048,196,205,65,385,358,132,486,389,384,197,265,133,358,128,1,302,196,65,2404,192,64,256,65,0,324]

theorem envBound58907 : H12AffineFastState.Bounded env58907 := by
  intro p hp
  have h : env58907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58906_58907 : H12AffineEnvironment.transform 8 384 env58906 = env58907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 384 env58906 == env58907) = true)

theorem identity58907 : scanCanonicalize (H12AffineFastState.compose env58907 (packedSelected [1,3,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 486) := by decide +kernel

theorem selectedBound58907 : packedSelected [1,3,10,12,15] rootPS < 2^1333 := by decide +kernel

def env58908 : List Nat := [2,4,8,0,32,64,128,256,384,320,486,196,205,65,385,358,132,486,389,384,197,265,133,358,128,1,302,196,65,130,192,64,256,65,0,324]

theorem envBound58908 : H12AffineFastState.Bounded env58908 := by
  intro p hp
  have h : env58908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58907_58908 : H12AffineEnvironment.transform 10 486 env58907 = env58908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 486 env58907 == env58908) = true)

theorem identity58908 : scanCanonicalize (H12AffineFastState.compose env58908 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound58908 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58909 : List Nat := [2,4,8,0,32,64,128,128,0,192,102,196,205,65,1,230,132,102,5,0,197,137,133,230,128,1,174,196,65,130,192,64,128,65,0,196]

theorem envBound58909 : H12AffineFastState.Bounded env58909 := by
  intro p hp
  have h : env58909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58908_58909 : H12AffineEnvironment.transform 7 128 env58908 = env58909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env58908 == env58909) = true)

theorem identity58909 : scanCanonicalize (H12AffineFastState.compose env58909 (packedSelected [0,1,2,7,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58909 : packedSelected [0,1,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env58910 : List Nat := [2,3,8,0,32,64,128,128,0,192,97,195,202,65,1,225,131,97,2,0,194,137,130,225,128,1,169,195,65,130,192,64,128,65,0,195]

theorem envBound58910 : H12AffineFastState.Bounded env58910 := by
  intro p hp
  have h : env58910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58909_58910 : H12AffineEnvironment.transform 1 3 env58909 = env58910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58909 == env58910) = true)

theorem identity58910 : scanCanonicalize (H12AffineFastState.compose env58910 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58910 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58911 : List Nat := [2,3,8,0,32,64,9,9,0,73,97,74,67,65,1,104,10,97,2,0,75,0,11,104,9,1,32,74,65,11,73,64,9,65,0,74]

theorem envBound58911 : H12AffineFastState.Bounded env58911 := by
  intro p hp
  have h : env58911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58910_58911 : H12AffineEnvironment.transform 6 9 env58910 = env58911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58910 == env58911) = true)

theorem identity58911 : scanCanonicalize (H12AffineFastState.compose env58911 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58911 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58912 : List Nat := [2,3,8,0,32,11,9,9,0,2,42,1,8,10,1,35,10,42,2,0,0,0,11,35,9,1,32,1,10,11,2,11,9,10,0,1]

theorem envBound58912 : H12AffineFastState.Bounded env58912 := by
  intro p hp
  have h : env58912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58911_58912 : H12AffineEnvironment.transform 5 11 env58911 = env58912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58911 == env58912) = true)

def env58913 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,65536,74031,65664,516,8524,836,649,74031,65537,9164,74283,303,74094,64,76622,8205,64,256,65831,0,325]

theorem envBound58913 : H12AffineFastState.Bounded env58913 := by
  intro p hp
  have h : env58913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58893_58913 : H12AffineEnvironment.transform 3 1 env58893 = env58913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58893 == env58913) = true)

theorem identity58913 : scanCanonicalize (H12AffineFastState.compose env58913 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 483) := by decide +kernel

theorem selectedBound58913 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58914 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,483,8396,355,516,8524,836,649,8396,482,9164,9160,303,8333,64,10925,8205,64,256,196,0,325]

theorem envBound58914 : H12AffineFastState.Bounded env58914 := by
  intro p hp
  have h : env58914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58913_58914 : H12AffineEnvironment.transform 15 483 env58913 = env58914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 483 env58913 == env58914) = true)

def env58915 : List Nat := [2,4,8,1,32,64,4,256,512,320,2048,837,8192,64,8525,359,8264,355,516,8524,836,525,8264,358,9032,9036,303,8201,64,10793,8205,64,256,64,0,325]

theorem envBound58915 : H12AffineFastState.Bounded env58915 := by
  intro p hp
  have h : env58915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58914_58915 : H12AffineEnvironment.transform 6 4 env58914 = env58915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env58914 == env58915) = true)

theorem identity58915 : scanCanonicalize (H12AffineFastState.compose env58915 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58915 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58916 : List Nat := [2,4,8,1,32,64,4,256,0,320,2048,325,8192,64,8525,359,8264,355,4,8524,324,13,8264,358,8520,8524,303,8201,64,10281,8205,64,256,64,0,325]

theorem envBound58916 : H12AffineFastState.Bounded env58916 := by
  intro p hp
  have h : env58916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58915_58916 : H12AffineEnvironment.transform 8 0 env58915 = env58916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58915 == env58916) = true)

theorem identity58916 : scanCanonicalize (H12AffineFastState.compose env58916 (packedSelected [2,5,8,10,12,15,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58916 : packedSelected [2,5,8,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env58917 : List Nat := [2,4,8,1,32,10,4,256,0,266,2048,271,8192,10,8455,301,8194,297,4,8454,270,13,8194,300,8450,8454,303,8201,10,10281,8205,10,256,10,0,271]

theorem envBound58917 : H12AffineFastState.Bounded env58917 := by
  intro p hp
  have h : env58917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58916_58917 : H12AffineEnvironment.transform 5 10 env58916 = env58917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58916 == env58917) = true)

theorem identity58917 : scanCanonicalize (H12AffineFastState.compose env58917 (packedSelected [0,1,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound58917 : packedSelected [0,1,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env58918 : List Nat := [2,4,8,1,32,10,4,256,0,266,2048,271,15,10,264,301,13,297,4,265,270,13,13,300,269,265,303,6,10,2086,2,10,256,10,0,271]

theorem envBound58918 : H12AffineFastState.Bounded env58918 := by
  intro p hp
  have h : env58918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58917_58918 : H12AffineEnvironment.transform 12 15 env58917 = env58918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env58917 == env58918) = true)

theorem identity58918 : scanCanonicalize (H12AffineFastState.compose env58918 (packedSelected [1,5,7,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound58918 : packedSelected [1,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env58919 : List Nat := [2,4,8,1,32,10,4,4,0,14,2048,11,15,10,12,41,13,45,4,13,10,13,13,40,9,13,43,6,10,2086,2,10,4,10,0,11]

theorem envBound58919 : H12AffineFastState.Bounded env58919 := by
  intro p hp
  have h : env58919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58918_58919 : H12AffineEnvironment.transform 7 4 env58918 = env58919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env58918 == env58919) = true)

theorem identity58919 : scanCanonicalize (H12AffineFastState.compose env58919 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound58919 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env58920 : List Nat := [2,4,8,1,32,10,4,4,0,14,43,11,15,10,12,41,13,45,4,13,10,13,13,40,9,13,43,6,10,13,2,10,4,10,0,11]

theorem envBound58920 : H12AffineFastState.Bounded env58920 := by
  intro p hp
  have h : env58920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58919_58920 : H12AffineEnvironment.transform 10 43 env58919 = env58920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env58919 == env58920) = true)

theorem identity58920 : scanCanonicalize (H12AffineFastState.compose env58920 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58920 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58921 : List Nat := [2,4,4,1,32,6,4,4,0,2,39,7,3,6,0,37,1,33,4,1,6,1,1,36,5,1,39,6,6,1,2,6,4,6,0,7]

theorem envBound58921 : H12AffineFastState.Bounded env58921 := by
  intro p hp
  have h : env58921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58920_58921 : H12AffineEnvironment.transform 2 4 env58920 = env58921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58920 == env58921) = true)

theorem identity58921 : scanCanonicalize (H12AffineFastState.compose env58921 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound58921 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58922 : List Nat := [2,4,4,1,1,6,4,4,0,2,6,7,3,6,0,4,1,0,4,1,6,1,1,5,5,1,6,6,6,1,2,6,4,6,0,7]

theorem envBound58922 : H12AffineFastState.Bounded env58922 := by
  intro p hp
  have h : env58922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58921_58922 : H12AffineEnvironment.transform 4 1 env58921 = env58922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env58921 == env58922) = true)

theorem identity58922 : scanCanonicalize (H12AffineFastState.compose env58922 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58923 : List Nat := [2,2,2,1,1,0,2,2,0,2,0,1,3,0,0,2,1,0,2,1,0,1,1,3,3,1,0,0,0,1,2,0,2,0,0,1]

theorem envBound58923 : H12AffineFastState.Bounded env58923 := by
  intro p hp
  have h : env58923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58922_58923 : H12AffineEnvironment.transform 1 2 env58922 = env58923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58922 == env58923) = true)

theorem identity58923 : scanCanonicalize (H12AffineFastState.compose env58923 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58924 : List Nat := [0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,0,0,0,1,0,0,0,0,0,1]

theorem envBound58924 : H12AffineFastState.Bounded env58924 := by
  intro p hp
  have h : env58924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58923_58924 : H12AffineEnvironment.transform 0 0 env58923 = env58924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58923 == env58924) = true)

def env58925 : List Nat := [2,4,8,1,32,64,5,256,512,320,2048,837,8192,64,8525,358,8265,355,516,8524,836,524,8265,359,9033,9037,303,8200,64,10792,8205,64,256,65,0,325]

theorem envBound58925 : H12AffineFastState.Bounded env58925 := by
  intro p hp
  have h : env58925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58914_58925 : H12AffineEnvironment.transform 6 5 env58914 = env58925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env58914 == env58925) = true)

theorem identity58925 : scanCanonicalize (H12AffineFastState.compose env58925 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 845) := by decide +kernel

theorem selectedBound58925 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58926 : List Nat := [2,4,8,1,32,64,5,256,512,320,2048,837,845,64,512,358,772,355,516,513,836,524,772,359,4,0,303,837,64,2405,832,64,256,65,0,325]

theorem envBound58926 : H12AffineFastState.Bounded env58926 := by
  intro p hp
  have h : env58926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58925_58926 : H12AffineEnvironment.transform 12 845 env58925 = env58926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 845 env58925 == env58926) = true)

theorem identity58926 : scanCanonicalize (H12AffineFastState.compose env58926 (packedSelected [1,3,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 614) := by decide +kernel

theorem selectedBound58926 : packedSelected [1,3,10,12,15] rootPS < 2^1333 := by decide +kernel

def env58927 : List Nat := [2,4,8,1,32,64,5,256,512,320,614,837,845,64,512,358,772,355,516,513,836,524,772,359,4,0,303,837,64,771,832,64,256,65,0,325]

theorem envBound58927 : H12AffineFastState.Bounded env58927 := by
  intro p hp
  have h : env58927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58926_58927 : H12AffineEnvironment.transform 10 614 env58926 = env58927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 614 env58926 == env58927) = true)

theorem identity58927 : scanCanonicalize (H12AffineFastState.compose env58927 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58927 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58928 : List Nat := [2,4,8,1,32,64,5,256,1,320,103,324,332,64,1,358,261,355,5,0,325,13,261,359,4,0,303,324,64,258,321,64,256,65,0,325]

theorem envBound58928 : H12AffineFastState.Bounded env58928 := by
  intro p hp
  have h : env58928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58927_58928 : H12AffineEnvironment.transform 8 1 env58927 = env58928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58927 == env58928) = true)

def env58929 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,81,8540,65536,74031,65664,532,8541,852,648,74046,65552,9180,74299,318,74111,81,76638,8205,64,256,65831,0,341]

theorem envBound58929 : H12AffineFastState.Bounded env58929 := by
  intro p hp
  have h : env58929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58892_58929 : H12AffineEnvironment.transform 11 853 env58892 = env58929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env58892 == env58929) = true)

def env58930 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,65536,74031,65664,516,8525,836,648,74030,65536,9164,74283,302,74095,65,76622,8205,64,256,65831,0,325]

theorem envBound58930 : H12AffineFastState.Bounded env58930 := by
  intro p hp
  have h : env58930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58929_58930 : H12AffineEnvironment.transform 3 0 env58929 = env58930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58929 == env58930) = true)

theorem identity58930 : scanCanonicalize (H12AffineFastState.compose env58930 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound58930 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58931 : List Nat := [2,4,8,0,32,64,4,256,512,320,2048,837,8192,65,8524,65536,74031,65540,516,8525,836,524,74030,65536,9032,74283,302,74095,65,76622,8205,64,256,65831,0,325]

theorem envBound58931 : H12AffineFastState.Bounded env58931 := by
  intro p hp
  have h : env58931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58930_58931 : H12AffineEnvironment.transform 6 4 env58930 = env58931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env58930 == env58931) = true)

def env58932 : List Nat := [2,4,8,0,32,64,4,256,512,320,2048,837,8192,65,8524,352,8271,356,516,8525,836,524,8270,352,9032,9035,302,8207,65,10798,8205,64,256,71,0,325]

theorem envBound58932 : H12AffineFastState.Bounded env58932 := by
  intro p hp
  have h : env58932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58931_58932 : H12AffineEnvironment.transform 15 352 env58931 = env58932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 352 env58931 == env58932) = true)

theorem identity58932 : scanCanonicalize (H12AffineFastState.compose env58932 (packedSelected [2,5,7,8,10,15,17,20,21,23,27,32] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound58932 : packedSelected [2,5,7,8,10,15,17,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env58933 : List Nat := [2,4,8,0,32,64,4,256,44,320,2048,361,8192,65,8524,352,8271,356,40,8525,360,32,8270,352,8548,8551,302,8207,65,10242,8205,64,256,71,0,325]

theorem envBound58933 : H12AffineFastState.Bounded env58933 := by
  intro p hp
  have h : env58933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58932_58933 : H12AffineEnvironment.transform 8 44 env58932 = env58933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env58932 == env58933) = true)

theorem identity58933 : scanCanonicalize (H12AffineFastState.compose env58933 (packedSelected [2,5,8,10,11,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 2381) := by decide +kernel

theorem selectedBound58933 : packedSelected [2,5,8,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env58934 : List Nat := [2,4,8,0,32,64,4,256,44,320,2048,361,2381,65,2049,352,2306,356,40,2048,360,32,2307,352,2089,2090,302,2370,65,335,2368,64,256,71,0,325]

theorem envBound58934 : H12AffineFastState.Bounded env58934 := by
  intro p hp
  have h : env58934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58933_58934 : H12AffineEnvironment.transform 12 2381 env58933 = env58934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2381 env58933 == env58934) = true)

theorem identity58934 : scanCanonicalize (H12AffineFastState.compose env58934 (packedSelected [0,3,7,10,11,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58934 : packedSelected [0,3,7,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env58935 : List Nat := [2,4,8,0,32,64,4,37,44,101,2048,76,2152,65,2049,69,2087,65,40,2048,77,32,2086,69,2089,2090,11,2151,65,106,2149,64,37,71,0,96]

theorem envBound58935 : H12AffineFastState.Bounded env58935 := by
  intro p hp
  have h : env58935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58934_58935 : H12AffineEnvironment.transform 7 37 env58934 = env58935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58934 == env58935) = true)

theorem identity58935 : scanCanonicalize (H12AffineFastState.compose env58935 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound58935 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env58936 : List Nat := [2,4,8,0,32,42,4,37,44,15,2048,38,2050,43,2049,47,2087,43,40,2048,39,32,2086,47,2089,2090,11,2061,43,0,2063,42,37,45,0,10]

theorem envBound58936 : H12AffineFastState.Bounded env58936 := by
  intro p hp
  have h : env58936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58935_58936 : H12AffineEnvironment.transform 5 42 env58935 = env58936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env58935 == env58936) = true)

theorem identity58936 : scanCanonicalize (H12AffineFastState.compose env58936 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound58936 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env58937 : List Nat := [2,4,8,0,32,42,4,37,44,15,44,38,46,43,45,47,11,43,40,44,39,32,10,47,5,6,11,33,43,0,35,42,37,45,0,10]

theorem envBound58937 : H12AffineFastState.Bounded env58937 := by
  intro p hp
  have h : env58937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58936_58937 : H12AffineEnvironment.transform 10 44 env58936 = env58937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env58936 == env58937) = true)

theorem identity58937 : scanCanonicalize (H12AffineFastState.compose env58937 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58937 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58938 : List Nat := [2,4,8,0,10,0,4,15,6,15,6,12,4,1,7,5,11,1,2,6,13,10,10,5,5,6,11,11,1,0,9,0,15,7,0,10]

theorem envBound58938 : H12AffineFastState.Bounded env58938 := by
  intro p hp
  have h : env58938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58937_58938 : H12AffineEnvironment.transform 4 10 env58937 = env58938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58937 == env58938) = true)

theorem identity58938 : scanCanonicalize (H12AffineFastState.compose env58938 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58938 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58939 : List Nat := [2,4,4,0,6,0,4,3,6,3,6,0,4,1,7,5,7,1,2,6,1,6,6,5,5,6,7,7,1,0,5,0,3,7,0,6]

theorem envBound58939 : H12AffineFastState.Bounded env58939 := by
  intro p hp
  have h : env58939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58938_58939 : H12AffineEnvironment.transform 2 4 env58938 = env58939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58938 == env58939) = true)

theorem identity58939 : scanCanonicalize (H12AffineFastState.compose env58939 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58939 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58940 : List Nat := [2,3,3,0,1,0,3,3,1,3,1,0,3,1,0,2,0,1,2,1,1,1,1,2,2,1,0,0,1,0,2,0,3,0,0,1]

theorem envBound58940 : H12AffineFastState.Bounded env58940 := by
  intro p hp
  have h : env58940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58939_58940 : H12AffineEnvironment.transform 1 3 env58939 = env58940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58939 == env58940) = true)

def env58941 : List Nat := [2,4,8,0,32,64,4,256,512,320,2048,837,8192,65,8524,353,8270,357,516,8525,836,524,8271,353,9032,9034,302,8206,65,10799,8205,64,256,70,0,325]

theorem envBound58941 : H12AffineFastState.Bounded env58941 := by
  intro p hp
  have h : env58941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58931_58941 : H12AffineEnvironment.transform 15 353 env58931 = env58941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 353 env58931 == env58941) = true)

theorem identity58941 : scanCanonicalize (H12AffineFastState.compose env58941 (packedSelected [2,5,7,8,10,15,17,20,21,23,27,32] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58941 : packedSelected [2,5,7,8,10,15,17,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env58942 : List Nat := [2,4,8,0,32,64,4,256,42,320,2048,367,8192,65,8524,353,8270,357,46,8525,366,38,8271,353,8546,8544,302,8206,65,10245,8205,64,256,70,0,325]

theorem envBound58942 : H12AffineFastState.Bounded env58942 := by
  intro p hp
  have h : env58942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58941_58942 : H12AffineEnvironment.transform 8 42 env58941 = env58942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58941 == env58942) = true)

theorem identity58942 : scanCanonicalize (H12AffineFastState.compose env58942 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound58942 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env58943 : List Nat := [2,4,8,0,32,64,4,256,42,320,2048,367,333,65,1,353,259,357,46,0,366,38,258,353,47,45,302,323,65,2376,320,64,256,70,0,325]

theorem envBound58943 : H12AffineFastState.Bounded env58943 := by
  intro p hp
  have h : env58943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58942_58943 : H12AffineEnvironment.transform 12 333 env58942 = env58943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env58942 == env58943) = true)

theorem identity58943 : scanCanonicalize (H12AffineFastState.compose env58943 (packedSelected [1,3,5,11,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound58943 : packedSelected [1,3,5,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58944 : List Nat := [2,4,8,0,32,64,4,256,42,320,367,367,333,65,1,353,259,357,46,0,366,38,258,353,47,45,302,323,65,39,320,64,256,70,0,325]

theorem envBound58944 : H12AffineFastState.Bounded env58944 := by
  intro p hp
  have h : env58944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58943_58944 : H12AffineEnvironment.transform 10 367 env58943 = env58944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env58943 == env58944) = true)

theorem identity58944 : scanCanonicalize (H12AffineFastState.compose env58944 (packedSelected [0,3,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58944 : packedSelected [0,3,9,11] rootPS < 2^1333 := by decide +kernel

def env58945 : List Nat := [2,4,8,0,32,32,4,256,42,288,271,271,301,33,1,257,259,261,46,0,270,38,258,257,47,45,302,291,33,39,288,32,256,38,0,293]

theorem envBound58945 : H12AffineFastState.Bounded env58945 := by
  intro p hp
  have h : env58945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58944_58945 : H12AffineEnvironment.transform 5 32 env58944 = env58945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58944 == env58945) = true)

theorem identity58945 : scanCanonicalize (H12AffineFastState.compose env58945 (packedSelected [0,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58945 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env58946 : List Nat := [2,4,5,0,32,32,4,256,39,288,258,258,288,33,1,257,259,261,35,0,259,38,258,257,34,32,291,291,33,39,288,32,256,38,0,293]

theorem envBound58946 : H12AffineFastState.Bounded env58946 := by
  intro p hp
  have h : env58946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58945_58946 : H12AffineEnvironment.transform 2 5 env58945 = env58946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58945 == env58946) = true)

theorem identity58946 : scanCanonicalize (H12AffineFastState.compose env58946 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58947 : List Nat := [2,2,3,0,32,32,2,256,33,288,258,258,288,33,1,257,259,259,35,0,259,32,258,257,34,32,291,291,33,33,288,32,256,32,0,291]

theorem envBound58947 : H12AffineFastState.Bounded env58947 := by
  intro p hp
  have h : env58947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58946_58947 : H12AffineEnvironment.transform 1 2 env58946 = env58947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58946 == env58947) = true)

def env58948 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,65536,74031,65664,517,8524,837,648,74031,65537,9165,74282,303,74094,64,76623,8205,64,256,65831,0,324]

theorem envBound58948 : H12AffineFastState.Bounded env58948 := by
  intro p hp
  have h : env58948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58929_58948 : H12AffineEnvironment.transform 3 1 env58929 = env58948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58929 == env58948) = true)

theorem identity58948 : scanCanonicalize (H12AffineFastState.compose env58948 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 204) := by decide +kernel

theorem selectedBound58948 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58949 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,204,64,385,65536,66019,65664,517,384,837,648,66019,65537,769,66278,303,65954,64,68483,193,64,256,65831,0,324]

theorem envBound58949 : H12AffineFastState.Bounded env58949 := by
  intro p hp
  have h : env58949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58948_58949 : H12AffineEnvironment.transform 12 204 env58948 = env58949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 204 env58948 == env58949) = true)

def env58950 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,204,64,385,352,131,480,517,384,837,648,131,353,769,902,303,194,64,2787,193,64,256,71,0,324]

theorem envBound58950 : H12AffineFastState.Bounded env58950 := by
  intro p hp
  have h : env58950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58949_58950 : H12AffineEnvironment.transform 15 352 env58949 = env58950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 352 env58949 == env58950) = true)

theorem identity58950 : scanCanonicalize (H12AffineFastState.compose env58950 (packedSelected [2,4,5,7,8,9,10,12,16,20,23,27,32,38,41] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound58950 : packedSelected [2,4,5,7,8,9,10,12,16,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env58951 : List Nat := [2,4,8,1,32,44,128,256,512,300,2048,808,160,44,385,268,131,396,517,384,809,648,131,269,769,902,303,174,44,2703,173,44,256,43,0,296]

theorem envBound58951 : H12AffineFastState.Bounded env58951 := by
  intro p hp
  have h : env58951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58950_58951 : H12AffineEnvironment.transform 5 44 env58950 = env58951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env58950 == env58951) = true)

theorem identity58951 : scanCanonicalize (H12AffineFastState.compose env58951 (packedSelected [0,4,7,9,10,13,16,17,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 290) := by decide +kernel

theorem selectedBound58951 : packedSelected [0,4,7,9,10,13,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env58952 : List Nat := [2,4,8,1,32,44,128,256,290,300,2048,10,160,44,385,268,131,396,295,384,11,426,131,269,35,164,303,174,44,2477,173,44,256,43,0,296]

theorem envBound58952 : H12AffineFastState.Bounded env58952 := by
  intro p hp
  have h : env58952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58951_58952 : H12AffineEnvironment.transform 8 290 env58951 = env58952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 290 env58951 == env58952) = true)

theorem identity58952 : scanCanonicalize (H12AffineFastState.compose env58952 (packedSelected [1,3,4,5,8,9,12,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound58952 : packedSelected [1,3,4,5,8,9,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58953 : List Nat := [2,4,8,1,32,44,128,256,290,300,302,10,160,44,385,268,131,396,295,384,11,426,131,269,35,164,303,174,44,131,173,44,256,43,0,296]

theorem envBound58953 : H12AffineFastState.Bounded env58953 := by
  intro p hp
  have h : env58953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58952_58953 : H12AffineEnvironment.transform 10 302 env58952 = env58953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env58952 == env58953) = true)

theorem identity58953 : scanCanonicalize (H12AffineFastState.compose env58953 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound58953 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env58954 : List Nat := [2,4,8,1,32,44,46,256,290,300,302,10,14,44,303,268,45,290,295,302,11,260,45,269,35,10,303,0,44,45,3,44,256,43,0,296]

theorem envBound58954 : H12AffineFastState.Bounded env58954 := by
  intro p hp
  have h : env58954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58953_58954 : H12AffineEnvironment.transform 6 46 env58953 = env58954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env58953 == env58954) = true)

theorem identity58954 : scanCanonicalize (H12AffineFastState.compose env58954 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound58954 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env58955 : List Nat := [2,4,8,1,32,44,46,4,38,40,42,10,14,44,43,8,45,38,35,42,11,0,45,9,35,10,43,0,44,45,3,44,4,43,0,44]

theorem envBound58955 : H12AffineFastState.Bounded env58955 := by
  intro p hp
  have h : env58955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58954_58955 : H12AffineEnvironment.transform 7 4 env58954 = env58955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env58954 == env58955) = true)

theorem identity58955 : scanCanonicalize (H12AffineFastState.compose env58955 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58955 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58956 : List Nat := [2,4,8,1,11,7,5,4,13,3,1,10,14,7,0,8,6,13,8,1,11,0,6,9,8,10,0,0,7,6,3,7,4,0,0,7]

theorem envBound58956 : H12AffineFastState.Bounded env58956 := by
  intro p hp
  have h : env58956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58955_58956 : H12AffineEnvironment.transform 4 11 env58955 = env58956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58955 == env58956) = true)

theorem identity58956 : scanCanonicalize (H12AffineFastState.compose env58956 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58957 : List Nat := [2,4,3,1,0,7,5,4,6,3,1,1,5,7,0,3,6,6,3,1,0,0,6,2,3,1,0,0,7,6,3,7,4,0,0,7]

theorem envBound58957 : H12AffineFastState.Bounded env58957 := by
  intro p hp
  have h : env58957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58956_58957 : H12AffineEnvironment.transform 2 3 env58956 = env58957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58956 == env58957) = true)

theorem identity58957 : scanCanonicalize (H12AffineFastState.compose env58957 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58958 : List Nat := [0,4,1,1,0,5,5,4,4,1,1,1,5,5,0,1,4,4,1,1,0,0,4,0,1,1,0,0,5,4,1,5,4,0,0,5]

theorem envBound58958 : H12AffineFastState.Bounded env58958 := by
  intro p hp
  have h : env58958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58957_58958 : H12AffineEnvironment.transform 0 0 env58957 = env58958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58957 == env58958) = true)

def env58959 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,204,64,385,353,130,481,517,384,837,648,130,352,769,903,303,195,64,2786,193,64,256,70,0,324]

theorem envBound58959 : H12AffineFastState.Bounded env58959 := by
  intro p hp
  have h : env58959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58949_58959 : H12AffineEnvironment.transform 15 353 env58949 = env58959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 353 env58949 == env58959) = true)

theorem identity58959 : scanCanonicalize (H12AffineFastState.compose env58959 (packedSelected [2,4,5,7,8,9,10,12,16,20,23,27,32,38,41] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound58959 : packedSelected [2,4,5,7,8,9,10,12,16,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env58960 : List Nat := [2,4,8,1,32,42,128,256,512,298,2048,814,166,42,385,267,130,395,517,384,815,648,130,266,769,903,303,169,42,2696,171,42,256,44,0,302]

theorem envBound58960 : H12AffineFastState.Bounded env58960 := by
  intro p hp
  have h : env58960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58959_58960 : H12AffineEnvironment.transform 5 42 env58959 = env58960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env58959 == env58960) = true)

theorem identity58960 : scanCanonicalize (H12AffineFastState.compose env58960 (packedSelected [0,1,5,8,11,12,16,21,27] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound58960 : packedSelected [0,1,5,8,11,12,16,21,27] rootPS < 2^1333 := by decide +kernel

def env58961 : List Nat := [2,4,8,1,32,42,128,256,512,298,163,814,166,42,385,267,130,395,517,384,815,648,130,266,769,903,303,169,42,555,171,42,256,44,0,302]

theorem envBound58961 : H12AffineFastState.Bounded env58961 := by
  intro p hp
  have h : env58961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58960_58961 : H12AffineEnvironment.transform 10 163 env58960 = env58961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env58960 == env58961) = true)

def env58962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4097,5277,74046,66896,13769,78894,1151,74815,1297,81227,8205,1280,256,65831,1344,5952]

theorem envBound58962 : H12AffineFastState.Bounded env58962 := by
  intro p hp
  have h : env58962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58890_58962 : H12AffineEnvironment.transform 17 65665 env58890 = env58962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58890 == env58962) = true)

theorem identity58962 : scanCanonicalize (H12AffineFastState.compose env58962 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound58962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,65536,74863,65665,320,8541,0,1180,74046,66896,9672,74799,1151,74815,1297,77130,8205,1280,256,65831,1344,1857]

theorem envBound58963 : H12AffineFastState.Bounded env58963 := by
  intro p hp
  have h : env58963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58962_58963 : H12AffineEnvironment.transform 11 1 env58962 = env58963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58962 == env58963) = true)

def env58964 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,65536,74031,65665,320,8541,0,476,74046,65552,8328,74095,319,74111,81,75786,8205,64,256,65831,0,513]

theorem envBound58964 : H12AffineFastState.Bounded env58964 := by
  intro p hp
  have h : env58964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58963_58964 : H12AffineEnvironment.transform 9 320 env58963 = env58964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58963 == env58964) = true)

theorem identity58964 : scanCanonicalize (H12AffineFastState.compose env58964 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound58964 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58965 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,35,8460,162,320,8541,0,476,8477,51,8328,8524,319,8540,81,10281,8205,64,256,260,0,513]

theorem envBound58965 : H12AffineFastState.Bounded env58965 := by
  intro p hp
  have h : env58965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58964_58965 : H12AffineEnvironment.transform 15 35 env58964 = env58965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env58964 == env58965) = true)

theorem identity58965 : scanCanonicalize (H12AffineFastState.compose env58965 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58965 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58966 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,8192,81,8264,35,8216,162,84,8265,0,200,8201,51,8328,8280,43,8264,81,10281,8205,64,20,16,0,513]

theorem envBound58966 : H12AffineFastState.Bounded env58966 := by
  intro p hp
  have h : env58966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58965_58966 : H12AffineEnvironment.transform 7 20 env58965 = env58966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58965 == env58966) = true)

theorem identity58966 : scanCanonicalize (H12AffineFastState.compose env58966 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound58966 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58967 : List Nat := [2,4,8,16,32,0,128,20,512,20,2048,1,8192,17,8200,35,8216,162,20,8201,0,136,8201,51,8328,8216,43,8200,17,10281,8205,0,20,16,0,513]

theorem envBound58967 : H12AffineFastState.Bounded env58967 := by
  intro p hp
  have h : env58967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58966_58967 : H12AffineEnvironment.transform 5 0 env58966 = env58967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env58966 == env58967) = true)

theorem identity58967 : scanCanonicalize (H12AffineFastState.compose env58967 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound58967 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env58968 : List Nat := [2,4,8,16,32,0,128,20,512,20,2048,1,657,17,665,35,649,162,20,664,0,136,664,51,537,649,43,665,17,2744,668,0,20,16,0,513]

theorem envBound58968 : H12AffineFastState.Bounded env58968 := by
  intro p hp
  have h : env58968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58967_58968 : H12AffineEnvironment.transform 12 657 env58967 = env58968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env58967 == env58968) = true)

theorem identity58968 : scanCanonicalize (H12AffineFastState.compose env58968 (packedSelected [1,2,3,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58968 : packedSelected [1,2,3,13,15] rootPS < 2^1333 := by decide +kernel

def env58969 : List Nat := [2,4,8,16,32,0,128,20,136,20,2048,1,25,17,17,35,1,162,20,16,0,136,16,51,145,1,43,17,17,2096,20,0,20,16,0,137]

theorem envBound58969 : H12AffineFastState.Bounded env58969 := by
  intro p hp
  have h : env58969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58968_58969 : H12AffineEnvironment.transform 8 136 env58968 = env58969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58968 == env58969) = true)

theorem identity58969 : scanCanonicalize (H12AffineFastState.compose env58969 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 178) := by decide +kernel

theorem selectedBound58969 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env58970 : List Nat := [2,4,8,16,32,0,128,20,136,20,178,1,25,17,17,35,1,162,20,16,0,136,16,51,145,1,43,17,17,130,20,0,20,16,0,137]

theorem envBound58970 : H12AffineFastState.Bounded env58970 := by
  intro p hp
  have h : env58970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58969_58970 : H12AffineEnvironment.transform 10 178 env58969 = env58970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 178 env58969 == env58970) = true)

theorem identity58970 : scanCanonicalize (H12AffineFastState.compose env58970 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound58970 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58971 : List Nat := [2,4,8,16,27,0,128,20,136,20,137,1,25,17,17,24,1,153,20,16,0,136,16,8,145,1,16,17,17,130,20,0,20,16,0,137]

theorem envBound58971 : H12AffineFastState.Bounded env58971 := by
  intro p hp
  have h : env58971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58970_58971 : H12AffineEnvironment.transform 4 27 env58970 = env58971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env58970 == env58971) = true)

theorem identity58971 : scanCanonicalize (H12AffineFastState.compose env58971 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58971 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env58972 : List Nat := [2,4,8,16,27,0,8,20,0,20,1,1,25,17,17,24,1,17,20,16,0,0,16,8,25,1,16,17,17,10,20,0,20,16,0,1]

theorem envBound58972 : H12AffineFastState.Bounded env58972 := by
  intro p hp
  have h : env58972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58971_58972 : H12AffineEnvironment.transform 6 8 env58971 = env58972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58971 == env58972) = true)

theorem identity58972 : scanCanonicalize (H12AffineFastState.compose env58972 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound58972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58973 : List Nat := [2,4,8,14,5,0,8,10,0,10,1,1,7,15,15,6,1,15,10,14,0,0,14,8,7,1,14,15,15,10,10,0,10,14,0,1]

theorem envBound58973 : H12AffineFastState.Bounded env58973 := by
  intro p hp
  have h : env58973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58972_58973 : H12AffineEnvironment.transform 3 14 env58972 = env58973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env58972 == env58973) = true)

theorem identity58973 : scanCanonicalize (H12AffineFastState.compose env58973 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58973 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58974 : List Nat := [2,4,0,6,5,0,0,2,0,2,1,1,7,7,7,6,1,7,2,6,0,0,6,0,7,1,6,7,7,2,2,0,2,6,0,1]

theorem envBound58974 : H12AffineFastState.Bounded env58974 := by
  intro p hp
  have h : env58974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58973_58974 : H12AffineEnvironment.transform 2 0 env58973 = env58974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58973 == env58974) = true)

theorem identity58974 : scanCanonicalize (H12AffineFastState.compose env58974 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58974 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58975 : List Nat := [2,2,0,0,3,0,0,2,0,2,1,1,1,1,1,0,1,1,2,0,0,0,0,0,1,1,0,1,1,2,2,0,2,0,0,1]

theorem envBound58975 : H12AffineFastState.Bounded env58975 := by
  intro p hp
  have h : env58975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58974_58975 : H12AffineEnvironment.transform 1 2 env58974 = env58975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58974 == env58975) = true)

def env58976 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8540,65536,74030,65665,320,8541,0,477,74046,65553,8329,74094,318,74110,80,75787,8205,65,256,65831,1,512]

theorem envBound58976 : H12AffineFastState.Bounded env58976 := by
  intro p hp
  have h : env58976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58963_58976 : H12AffineEnvironment.transform 9 321 env58963 = env58976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58963 == env58976) = true)

theorem identity58976 : scanCanonicalize (H12AffineFastState.compose env58976 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound58976 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58977 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,349,80,1,65536,65651,65665,320,0,0,477,65635,65553,468,65587,318,65571,80,67926,336,65,256,65831,1,512]

theorem envBound58977 : H12AffineFastState.Bounded env58977 := by
  intro p hp
  have h : env58977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58976_58977 : H12AffineEnvironment.transform 12 349 env58976 = env58977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env58976 == env58977) = true)

theorem identity58977 : scanCanonicalize (H12AffineFastState.compose env58977 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound58977 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58978 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,349,80,1,34,81,163,320,0,0,477,65,51,468,17,318,1,80,2420,336,65,256,261,1,512]

theorem envBound58978 : H12AffineFastState.Bounded env58978 := by
  intro p hp
  have h : env58978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58977_58978 : H12AffineEnvironment.transform 15 34 env58977 = env58978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env58977 == env58978) = true)

theorem identity58978 : scanCanonicalize (H12AffineFastState.compose env58978 (packedSelected [2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 924) := by decide +kernel

theorem selectedBound58978 : packedSelected [2,10,13] rootPS < 2^1333 := by decide +kernel

def env58979 : List Nat := [2,4,8,16,32,64,128,256,512,321,924,1,349,80,1,34,81,163,320,0,0,477,65,51,468,17,318,1,80,744,336,65,256,261,1,512]

theorem envBound58979 : H12AffineFastState.Bounded env58979 := by
  intro p hp
  have h : env58979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58978_58979 : H12AffineEnvironment.transform 10 924 env58978 = env58979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 924 env58978 == env58979) = true)

theorem identity58979 : scanCanonicalize (H12AffineFastState.compose env58979 (packedSelected [0,1,2,5,7,10,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound58979 : packedSelected [0,1,2,5,7,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58980 : List Nat := [2,4,8,16,32,64,128,256,325,321,217,1,349,80,1,34,81,163,320,0,0,477,65,51,468,17,318,1,80,429,336,65,256,261,1,325]

theorem envBound58980 : H12AffineFastState.Bounded env58980 := by
  intro p hp
  have h : env58980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58979_58980 : H12AffineEnvironment.transform 8 325 env58979 = env58980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env58979 == env58980) = true)

theorem identity58980 : scanCanonicalize (H12AffineFastState.compose env58980 (packedSelected [1,2,3,4,5,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58980 : packedSelected [1,2,3,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env58981 : List Nat := [2,4,8,16,32,10,128,256,271,267,147,1,279,26,1,34,27,163,266,0,0,407,11,51,414,17,318,1,26,429,282,11,256,261,1,271]

theorem envBound58981 : H12AffineFastState.Bounded env58981 := by
  intro p hp
  have h : env58981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58980_58981 : H12AffineEnvironment.transform 5 10 env58980 = env58981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58980 == env58981) = true)

theorem identity58981 : scanCanonicalize (H12AffineFastState.compose env58981 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound58981 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58982 : List Nat := [2,4,8,16,32,10,128,14,1,5,147,1,25,26,1,34,27,163,4,0,0,153,11,51,144,17,48,1,26,163,20,11,14,11,1,1]

theorem envBound58982 : H12AffineFastState.Bounded env58982 := by
  intro p hp
  have h : env58982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58981_58982 : H12AffineEnvironment.transform 7 14 env58981 = env58982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env58981 == env58982) = true)

theorem identity58982 : scanCanonicalize (H12AffineFastState.compose env58982 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound58982 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58983 : List Nat := [2,4,8,7,32,10,128,14,1,5,132,1,14,13,1,34,12,163,4,0,0,142,11,36,135,6,39,1,13,163,3,11,14,11,1,1]

theorem envBound58983 : H12AffineFastState.Bounded env58983 := by
  intro p hp
  have h : env58983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58982_58983 : H12AffineEnvironment.transform 3 7 env58982 = env58983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env58982 == env58983) = true)

theorem identity58983 : scanCanonicalize (H12AffineFastState.compose env58983 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58983 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58984 : List Nat := [2,4,5,7,32,7,128,3,1,5,132,1,3,0,1,34,1,163,4,0,0,131,6,36,135,6,39,1,0,163,3,6,3,6,1,1]

theorem envBound58984 : H12AffineFastState.Bounded env58984 := by
  intro p hp
  have h : env58984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58983_58984 : H12AffineEnvironment.transform 2 5 env58983 = env58984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58983 == env58984) = true)

theorem identity58984 : scanCanonicalize (H12AffineFastState.compose env58984 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58985 : List Nat := [2,4,5,7,7,7,128,3,1,5,132,1,3,0,1,5,1,132,4,0,0,131,6,3,135,6,0,1,0,132,3,6,3,6,1,1]

theorem envBound58985 : H12AffineFastState.Bounded env58985 := by
  intro p hp
  have h : env58985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58984_58985 : H12AffineEnvironment.transform 4 7 env58984 = env58985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58984 == env58985) = true)

def env58986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123165,28889,78895,385203,90414,1296,96346,25884,1281,256,82998,1344,21072]

theorem envBound58986 : H12AffineFastState.Bounded env58986 := by
  intro p hp
  have h : env58986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58770_58986 : H12AffineEnvironment.transform 18 21585 env58770 = env58986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env58770 == env58986) = true)

theorem identity58986 : scanCanonicalize (H12AffineFastState.compose env58986 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound58986 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4097,17613,91183,87296,28889,78895,349358,90414,1296,96346,25884,1281,256,82998,1344,21072]

theorem envBound58987 : H12AffineFastState.Bounded env58987 := by
  intro p hp
  have h : env58987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58986_58987 : H12AffineEnvironment.transform 14 13341 env58986 = env58987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env58986 == env58987) = true)

def env58988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4097,477,74047,69648,13769,78895,332222,74814,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound58988 : H12AffineFastState.Bounded env58988 := by
  intro p hp
  have h : env58988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58987_58988 : H12AffineEnvironment.transform 13 1296 env58987 = env58988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58987 == env58988) = true)

def env58989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4097,477,74047,69648,13769,78895,4414,74814,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound58989 : H12AffineFastState.Bounded env58989 := by
  intro p hp
  have h : env58989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58988_58989 : H12AffineEnvironment.transform 17 65664 env58988 = env58989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58988 == env58989) = true)

theorem identity58989 : scanCanonicalize (H12AffineFastState.compose env58989 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound58989 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4097,477,65910,69648,5504,70758,4414,66679,1296,72963,69,1281,256,65830,1344,5952]

theorem envBound58990 : H12AffineFastState.Bounded env58990 := by
  intro p hp
  have h : env58990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58989_58990 : H12AffineEnvironment.transform 12 73 env58989 = env58990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env58989 == env58990) = true)

def env58991 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4097,477,65910,69648,5504,70758,4414,66679,1296,72963,69,1281,256,65830,1344,5140]

theorem envBound58991 : H12AffineFastState.Bounded env58991 := by
  intro p hp
  have h : env58991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58990_58991 : H12AffineEnvironment.transform 8 340 env58990 = env58991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env58990 == env58991) = true)

def env58992 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4372,65536,65894,65664,4417,4373,4097,477,65910,69648,4288,69926,4414,65847,80,71747,69,65,256,65830,0,4436]

theorem envBound58992 : H12AffineFastState.Bounded env58992 := by
  intro p hp
  have h : env58992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58991_58992 : H12AffineEnvironment.transform 9 320 env58991 = env58992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58991 == env58992) = true)

theorem identity58992 : scanCanonicalize (H12AffineFastState.compose env58992 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound58992 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58993 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,276,73,80,0,65536,65894,65664,85,1,277,477,65910,65796,468,65586,42,65847,80,67927,69,65,256,65830,0,64]

theorem envBound58993 : H12AffineFastState.Bounded env58993 := by
  intro p hp
  have h : env58993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58992_58993 : H12AffineEnvironment.transform 11 276 env58992 = env58993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env58992 == env58993) = true)

theorem identity58993 : scanCanonicalize (H12AffineFastState.compose env58993 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound58993 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env58994 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,276,73,80,0,2193,2551,2065,85,1,277,477,2535,2453,468,2211,42,2470,80,454,69,65,256,2487,0,64]

theorem envBound58994 : H12AffineFastState.Bounded env58994 := by
  intro p hp
  have h : env58994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58993_58994 : H12AffineEnvironment.transform 15 2193 env58993 = env58994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env58993 == env58994) = true)

theorem identity58994 : scanCanonicalize (H12AffineFastState.compose env58994 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound58994 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env58995 : List Nat := [2,4,8,16,32,64,128,256,340,320,184,276,73,80,0,41,335,169,85,1,277,477,351,301,468,27,42,286,80,454,69,65,256,271,0,64]

theorem envBound58995 : H12AffineFastState.Bounded env58995 := by
  intro p hp
  have h : env58995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58994_58995 : H12AffineEnvironment.transform 10 184 env58994 = env58995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env58994 == env58995) = true)

theorem identity58995 : scanCanonicalize (H12AffineFastState.compose env58995 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58995 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58996 : List Nat := [2,4,8,16,32,64,128,69,17,5,184,81,73,80,0,41,10,169,85,1,80,152,26,104,145,27,42,91,80,131,69,65,69,74,0,64]

theorem envBound58996 : H12AffineFastState.Bounded env58996 := by
  intro p hp
  have h : env58996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58995_58996 : H12AffineEnvironment.transform 7 69 env58995 = env58996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58995 == env58996) = true)

theorem identity58996 : scanCanonicalize (H12AffineFastState.compose env58996 (packedSelected [2,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound58996 : packedSelected [2,5,12] rootPS < 2^1333 := by decide +kernel

def env58997 : List Nat := [2,4,8,16,32,64,62,69,17,5,6,81,73,80,0,41,10,23,85,1,80,38,26,104,47,27,42,91,80,61,69,65,69,74,0,64]

theorem envBound58997 : H12AffineFastState.Bounded env58997 := by
  intro p hp
  have h : env58997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58996_58997 : H12AffineEnvironment.transform 6 62 env58996 = env58997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env58996 == env58997) = true)

theorem identity58997 : scanCanonicalize (H12AffineFastState.compose env58997 (packedSelected [5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound58997 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env58998 : List Nat := [2,4,8,16,22,64,8,69,17,5,6,81,73,80,0,31,10,23,85,1,80,16,26,94,25,27,28,91,80,11,69,65,69,74,0,64]

theorem envBound58998 : H12AffineFastState.Bounded env58998 := by
  intro p hp
  have h : env58998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58997_58998 : H12AffineEnvironment.transform 4 22 env58997 = env58998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env58997 == env58998) = true)

theorem identity58998 : scanCanonicalize (H12AffineFastState.compose env58998 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58998 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env58999 : List Nat := [2,4,8,16,22,10,8,15,17,5,6,27,3,26,0,31,10,23,31,1,26,16,26,20,25,27,28,17,26,11,15,11,15,0,0,10]

theorem envBound58999 : H12AffineFastState.Bounded env58999 := by
  intro p hp
  have h : env58999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58998_58999 : H12AffineEnvironment.transform 5 10 env58998 = env58999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58998 == env58999) = true)

theorem identity58999 : scanCanonicalize (H12AffineFastState.compose env58999 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58999 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59000 : List Nat := [2,4,3,16,22,1,3,4,17,5,6,16,3,17,0,20,1,23,20,1,17,16,17,20,18,16,23,17,17,0,4,0,4,0,0,1]

theorem envBound59000 : H12AffineFastState.Bounded env59000 := by
  intro p hp
  have h : env59000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58999_59000 : H12AffineEnvironment.transform 2 3 env58999 = env59000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58999 == env59000) = true)

theorem identity59000 : scanCanonicalize (H12AffineFastState.compose env59000 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound59000 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59001 : List Nat := [2,4,3,7,1,1,3,4,6,5,6,7,3,6,0,3,1,0,3,1,6,7,6,3,5,7,0,6,6,0,4,0,4,0,0,1]

theorem envBound59001 : H12AffineFastState.Bounded env59001 := by
  intro p hp
  have h : env59001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59000_59001 : H12AffineEnvironment.transform 3 7 env59000 = env59001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env59000 == env59001) = true)

def env59002 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4373,65536,65895,65664,4417,4372,4097,477,65910,69648,4289,69927,4414,65846,81,71746,69,64,256,65830,1,4437]

theorem envBound59002 : H12AffineFastState.Bounded env59002 := by
  intro p hp
  have h : env59002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58991_59002 : H12AffineEnvironment.transform 9 321 env58991 = env59002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58991 == env59002) = true)

theorem identity59002 : scanCanonicalize (H12AffineFastState.compose env59002 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59002 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59003 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,4096,73,81,4097,65536,65651,65664,4181,4096,4097,201,65634,69648,4289,69683,4138,65570,81,71746,69,64,20,65586,1,4161]

theorem envBound59003 : H12AffineFastState.Bounded env59003 := by
  intro p hp
  have h : env59003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59002_59003 : H12AffineEnvironment.transform 7 20 env59002 = env59003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59002 == env59003) = true)

theorem identity59003 : scanCanonicalize (H12AffineFastState.compose env59003 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 2168) := by decide +kernel

theorem selectedBound59003 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59004 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,4096,73,81,4097,2168,2059,2296,4181,4096,4097,201,2074,6248,4289,6219,4138,2138,81,4154,69,64,20,2122,1,4161]

theorem envBound59004 : H12AffineFastState.Bounded env59004 := by
  intro p hp
  have h : env59004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59003_59004 : H12AffineEnvironment.transform 15 2168 env59003 = env59004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2168 env59003 == env59004) = true)

theorem identity59004 : scanCanonicalize (H12AffineFastState.compose env59004 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound59004 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env59005 : List Nat := [2,4,8,16,32,64,128,20,64,85,12,4096,73,81,4097,116,7,244,4181,4096,4097,201,22,4196,4289,4167,4138,86,81,4154,69,64,20,70,1,4161]

theorem envBound59005 : H12AffineFastState.Bounded env59005 := by
  intro p hp
  have h : env59005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59004_59005 : H12AffineEnvironment.transform 10 12 env59004 = env59005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env59004 == env59005) = true)

theorem identity59005 : scanCanonicalize (H12AffineFastState.compose env59005 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound59005 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env59006 : List Nat := [2,4,8,16,32,64,128,20,64,85,12,1,73,81,0,116,7,244,84,1,0,201,22,101,192,70,43,86,81,59,69,64,20,70,1,64]

theorem envBound59006 : H12AffineFastState.Bounded env59006 := by
  intro p hp
  have h : env59006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59005_59006 : H12AffineEnvironment.transform 11 1 env59005 = env59006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59005 == env59006) = true)

theorem identity59006 : scanCanonicalize (H12AffineFastState.compose env59006 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound59006 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env59007 : List Nat := [2,4,8,16,32,64,30,20,64,85,12,1,73,81,0,116,7,106,84,1,0,87,22,101,94,70,43,86,81,59,69,64,20,70,1,64]

theorem envBound59007 : H12AffineFastState.Bounded env59007 := by
  intro p hp
  have h : env59007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59006_59007 : H12AffineEnvironment.transform 6 30 env59006 = env59007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env59006 == env59007) = true)

theorem identity59007 : scanCanonicalize (H12AffineFastState.compose env59007 (packedSelected [0,7,8,11,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59007 : packedSelected [0,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59008 : List Nat := [2,4,2,16,32,64,20,20,64,85,6,1,67,81,0,116,7,96,84,1,0,87,22,101,84,70,33,86,81,49,69,64,20,70,1,64]

theorem envBound59008 : H12AffineFastState.Bounded env59008 := by
  intro p hp
  have h : env59008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59007_59008 : H12AffineEnvironment.transform 2 2 env59007 = env59008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59007 == env59008) = true)

theorem identity59008 : scanCanonicalize (H12AffineFastState.compose env59008 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound59008 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env59009 : List Nat := [2,4,2,16,32,22,20,20,22,3,6,1,21,7,0,34,7,54,2,1,0,1,22,51,2,16,33,0,7,49,19,22,20,16,1,22]

theorem envBound59009 : H12AffineFastState.Bounded env59009 := by
  intro p hp
  have h : env59009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59008_59009 : H12AffineEnvironment.transform 5 22 env59008 = env59009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env59008 == env59009) = true)

theorem identity59009 : scanCanonicalize (H12AffineFastState.compose env59009 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59010 : List Nat := [2,4,2,16,7,22,20,20,22,3,6,1,21,7,0,5,7,17,2,1,0,1,22,20,2,16,6,0,7,22,19,22,20,16,1,22]

theorem envBound59010 : H12AffineFastState.Bounded env59010 := by
  intro p hp
  have h : env59010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59009_59010 : H12AffineEnvironment.transform 4 7 env59009 = env59010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59009 == env59010) = true)

theorem identity59010 : scanCanonicalize (H12AffineFastState.compose env59010 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound59010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59011 : List Nat := [2,4,2,6,7,0,2,2,0,3,6,1,3,7,0,5,7,7,2,1,0,1,0,2,2,6,6,0,7,0,5,0,2,6,1,0]

theorem envBound59011 : H12AffineFastState.Bounded env59011 := by
  intro p hp
  have h : env59011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59010_59011 : H12AffineEnvironment.transform 3 6 env59010 = env59011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env59010 == env59011) = true)

theorem identity59011 : scanCanonicalize (H12AffineFastState.compose env59011 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59012 : List Nat := [2,2,2,0,1,0,2,2,0,3,0,1,3,1,0,3,1,1,2,1,0,1,0,2,2,0,0,0,1,0,3,0,2,0,1,0]

theorem envBound59012 : H12AffineFastState.Bounded env59012 := by
  intro p hp
  have h : env59012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59011_59012 : H12AffineEnvironment.transform 1 2 env59011 = env59012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59011 == env59012) = true)

def env59013 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4097,477,65910,69648,5504,70758,4414,66679,1296,72963,69,1281,256,65830,1344,5141]

theorem envBound59013 : H12AffineFastState.Bounded env59013 := by
  intro p hp
  have h : env59013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58990_59013 : H12AffineEnvironment.transform 8 341 env58990 = env59013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env58990 == env59013) = true)

def env59014 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4372,65536,65894,65664,4417,4373,4097,477,65910,69648,4288,69926,4414,65847,80,71747,69,65,256,65830,0,4437]

theorem envBound59014 : H12AffineFastState.Bounded env59014 := by
  intro p hp
  have h : env59014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59013_59014 : H12AffineEnvironment.transform 9 320 env59013 = env59014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59013 == env59014) = true)

theorem identity59014 : scanCanonicalize (H12AffineFastState.compose env59014 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound59014 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59015 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,276,73,80,0,65536,65894,65664,85,1,277,477,65910,65796,468,65586,42,65847,80,67927,69,65,256,65830,0,65]

theorem envBound59015 : H12AffineFastState.Bounded env59015 := by
  intro p hp
  have h : env59015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59014_59015 : H12AffineEnvironment.transform 11 276 env59014 = env59015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env59014 == env59015) = true)

theorem identity59015 : scanCanonicalize (H12AffineFastState.compose env59015 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2192) := by decide +kernel

theorem selectedBound59015 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59016 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,276,73,80,0,2192,2550,2064,85,1,277,477,2534,2452,468,2210,42,2471,80,455,69,65,256,2486,0,65]

theorem envBound59016 : H12AffineFastState.Bounded env59016 := by
  intro p hp
  have h : env59016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59015_59016 : H12AffineEnvironment.transform 15 2192 env59015 = env59016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2192 env59015 == env59016) = true)

theorem identity59016 : scanCanonicalize (H12AffineFastState.compose env59016 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound59016 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59017 : List Nat := [2,4,8,16,32,64,128,256,341,320,184,276,73,80,0,40,334,168,85,1,277,477,350,300,468,26,42,287,80,455,69,65,256,270,0,65]

theorem envBound59017 : H12AffineFastState.Bounded env59017 := by
  intro p hp
  have h : env59017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59016_59017 : H12AffineEnvironment.transform 10 184 env59016 = env59017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env59016 == env59017) = true)

theorem identity59017 : scanCanonicalize (H12AffineFastState.compose env59017 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59017 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59018 : List Nat := [2,4,8,16,32,64,128,69,16,5,184,81,73,80,0,40,11,168,85,1,80,152,27,105,145,26,42,90,80,130,69,65,69,75,0,65]

theorem envBound59018 : H12AffineFastState.Bounded env59018 := by
  intro p hp
  have h : env59018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59017_59018 : H12AffineEnvironment.transform 7 69 env59017 = env59018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59017 == env59018) = true)

theorem identity59018 : scanCanonicalize (H12AffineFastState.compose env59018 (packedSelected [2,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound59018 : packedSelected [2,5,12] rootPS < 2^1333 := by decide +kernel

def env59019 : List Nat := [2,4,8,16,32,64,101,69,16,5,93,81,73,80,0,40,11,77,85,1,80,125,27,105,116,26,42,90,80,103,69,65,69,75,0,65]

theorem envBound59019 : H12AffineFastState.Bounded env59019 := by
  intro p hp
  have h : env59019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59018_59019 : H12AffineEnvironment.transform 6 101 env59018 = env59019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env59018 == env59019) = true)

theorem identity59019 : scanCanonicalize (H12AffineFastState.compose env59019 (packedSelected [5,8,13] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound59019 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env59020 : List Nat := [2,4,8,16,32,45,8,40,16,5,48,60,36,61,0,40,11,32,56,1,61,16,27,4,25,26,42,55,61,10,40,44,40,38,0,44]

theorem envBound59020 : H12AffineFastState.Bounded env59020 := by
  intro p hp
  have h : env59020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59019_59020 : H12AffineEnvironment.transform 5 45 env59019 = env59020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env59019 == env59020) = true)

theorem identity59020 : scanCanonicalize (H12AffineFastState.compose env59020 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59020 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env59021 : List Nat := [2,4,8,16,7,10,8,15,16,5,23,27,3,26,0,15,11,7,31,1,26,16,27,4,25,26,13,16,26,10,15,11,15,1,0,11]

theorem envBound59021 : H12AffineFastState.Bounded env59021 := by
  intro p hp
  have h : env59021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59020_59021 : H12AffineEnvironment.transform 4 7 env59020 = env59021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59020 == env59021) = true)

theorem identity59021 : scanCanonicalize (H12AffineFastState.compose env59021 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59021 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59022 : List Nat := [2,4,2,16,7,0,2,5,16,5,23,17,3,16,0,5,1,7,21,1,16,16,17,4,19,16,7,16,16,0,5,1,5,1,0,1]

theorem envBound59022 : H12AffineFastState.Bounded env59022 := by
  intro p hp
  have h : env59022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59021_59022 : H12AffineEnvironment.transform 2 2 env59021 = env59022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59021 == env59022) = true)

theorem identity59022 : scanCanonicalize (H12AffineFastState.compose env59022 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59022 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59023 : List Nat := [2,3,2,16,0,0,2,2,16,2,16,17,3,16,0,2,1,0,18,1,16,16,17,3,19,16,0,16,16,0,2,1,2,1,0,1]

theorem envBound59023 : H12AffineFastState.Bounded env59023 := by
  intro p hp
  have h : env59023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59022_59023 : H12AffineEnvironment.transform 1 3 env59022 = env59023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59022 == env59023) = true)

theorem identity59023 : scanCanonicalize (H12AffineFastState.compose env59023 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59024 : List Nat := [2,3,2,0,0,0,2,2,0,2,0,1,3,0,0,2,1,0,2,1,0,0,1,3,3,0,0,0,0,0,2,1,2,1,0,1]

theorem envBound59024 : H12AffineFastState.Bounded env59024 := by
  intro p hp
  have h : env59024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59023_59024 : H12AffineEnvironment.transform 3 0 env59023 = env59024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59023 == env59024) = true)

theorem identity59024 : scanCanonicalize (H12AffineFastState.compose env59024 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59025 : List Nat := [0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1,0,1]

theorem envBound59025 : H12AffineFastState.Bounded env59025 := by
  intro p hp
  have h : env59025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59024_59025 : H12AffineEnvironment.transform 0 0 env59024 = env59025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59024 == env59025) = true)

def env59026 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4373,65536,65895,65664,4417,4372,4097,477,65910,69648,4289,69927,4414,65846,81,71746,69,64,256,65830,1,4436]

theorem envBound59026 : H12AffineFastState.Bounded env59026 := by
  intro p hp
  have h : env59026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59013_59026 : H12AffineEnvironment.transform 9 321 env59013 = env59026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59013 == env59026) = true)

theorem identity59026 : scanCanonicalize (H12AffineFastState.compose env59026 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59026 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59027 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,4096,73,81,4097,65536,65651,65664,4181,4096,4097,201,65634,69648,4289,69683,4138,65570,81,71746,69,64,20,65586,1,4160]

theorem envBound59027 : H12AffineFastState.Bounded env59027 := by
  intro p hp
  have h : env59027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59026_59027 : H12AffineEnvironment.transform 7 20 env59026 = env59027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59026 == env59027) = true)

theorem identity59027 : scanCanonicalize (H12AffineFastState.compose env59027 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 2169) := by decide +kernel

theorem selectedBound59027 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59028 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,4096,73,81,4097,2169,2058,2297,4181,4096,4097,201,2075,6249,4289,6218,4138,2139,81,4155,69,64,20,2123,1,4160]

theorem envBound59028 : H12AffineFastState.Bounded env59028 := by
  intro p hp
  have h : env59028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59027_59028 : H12AffineEnvironment.transform 15 2169 env59027 = env59028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2169 env59027 == env59028) = true)

theorem identity59028 : scanCanonicalize (H12AffineFastState.compose env59028 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59028 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env59029 : List Nat := [2,2,8,16,32,64,128,18,65,83,2048,4096,73,81,4097,2169,2058,2297,4179,4096,4097,201,2075,6249,4289,6218,4138,2139,81,4155,67,64,18,2123,1,4160]

theorem envBound59029 : H12AffineFastState.Bounded env59029 := by
  intro p hp
  have h : env59029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59028_59029 : H12AffineEnvironment.transform 1 2 env59028 = env59029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59028 == env59029) = true)

theorem identity59029 : scanCanonicalize (H12AffineFastState.compose env59029 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound59029 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env59030 : List Nat := [2,2,8,16,32,64,128,18,65,83,2048,1,73,81,0,2169,2058,2297,82,1,0,201,2075,2152,192,2123,43,2139,81,58,67,64,18,2123,1,65]

theorem envBound59030 : H12AffineFastState.Bounded env59030 := by
  intro p hp
  have h : env59030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59029_59030 : H12AffineEnvironment.transform 11 1 env59029 = env59030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59029 == env59030) = true)

theorem identity59030 : scanCanonicalize (H12AffineFastState.compose env59030 (packedSelected [2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound59030 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env59031 : List Nat := [2,2,8,16,32,64,128,18,65,83,146,1,73,81,0,235,152,107,82,1,0,201,137,250,192,217,43,201,81,58,67,64,18,217,1,65]

theorem envBound59031 : H12AffineFastState.Bounded env59031 := by
  intro p hp
  have h : env59031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59030_59031 : H12AffineEnvironment.transform 10 146 env59030 = env59031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env59030 == env59031) = true)

theorem identity59031 : scanCanonicalize (H12AffineFastState.compose env59031 (packedSelected [0,7,8,11,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59031 : packedSelected [0,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59032 : List Nat := [2,2,3,16,32,64,128,18,65,83,146,1,66,81,0,224,147,96,82,1,0,194,130,241,192,210,32,194,81,49,67,64,18,210,1,65]

theorem envBound59032 : H12AffineFastState.Bounded env59032 := by
  intro p hp
  have h : env59032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59031_59032 : H12AffineEnvironment.transform 2 3 env59031 = env59032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59031 == env59032) = true)

theorem identity59032 : scanCanonicalize (H12AffineFastState.compose env59032 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound59032 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env59033 : List Nat := [2,2,3,16,32,64,66,18,65,83,80,1,66,81,0,34,81,96,82,1,0,0,64,51,2,16,32,0,81,49,67,64,18,16,1,65]

theorem envBound59033 : H12AffineFastState.Bounded env59033 := by
  intro p hp
  have h : env59033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59032_59033 : H12AffineEnvironment.transform 6 66 env59032 = env59033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env59032 == env59033) = true)

theorem identity59033 : scanCanonicalize (H12AffineFastState.compose env59033 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound59033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59034 : List Nat := [2,2,3,16,32,48,50,18,49,35,32,1,50,33,0,34,33,16,34,1,0,0,48,51,2,16,32,0,33,49,51,48,18,16,1,49]

theorem envBound59034 : H12AffineFastState.Bounded env59034 := by
  intro p hp
  have h : env59034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59033_59034 : H12AffineEnvironment.transform 5 48 env59033 = env59034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env59033 == env59034) = true)

theorem identity59034 : scanCanonicalize (H12AffineFastState.compose env59034 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59035 : List Nat := [2,2,3,16,17,1,3,18,0,18,17,1,3,16,0,19,16,16,19,1,0,0,1,2,2,16,17,0,16,0,2,1,18,16,1,0]

theorem envBound59035 : H12AffineFastState.Bounded env59035 := by
  intro p hp
  have h : env59035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59034_59035 : H12AffineEnvironment.transform 4 17 env59034 = env59035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59034 == env59035) = true)

theorem identity59035 : scanCanonicalize (H12AffineFastState.compose env59035 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59035 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59036 : List Nat := [2,2,3,1,0,1,3,3,0,3,0,1,3,1,0,2,1,1,2,1,0,0,1,2,2,1,0,0,1,0,2,1,3,1,1,0]

theorem envBound59036 : H12AffineFastState.Bounded env59036 := by
  intro p hp
  have h : env59036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59035_59036 : H12AffineEnvironment.transform 3 1 env59035 = env59036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59035 == env59036) = true)

def env59037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4097,477,74047,69648,13769,78895,4415,74814,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound59037 : H12AffineFastState.Bounded env59037 := by
  intro p hp
  have h : env59037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58988_59037 : H12AffineEnvironment.transform 17 65665 env58988 = env59037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58988 == env59037) = true)

theorem identity59037 : scanCanonicalize (H12AffineFastState.compose env59037 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound59037 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4097,477,70711,69648,193,65831,4415,69942,1296,67650,5380,1281,256,65830,1344,5952]

theorem envBound59038 : H12AffineFastState.Bounded env59038 := by
  intro p hp
  have h : env59038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59037_59038 : H12AffineEnvironment.transform 12 5384 env59037 = env59038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env59037 == env59038) = true)

def env59039 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4097,477,70711,69648,193,65831,4415,69942,1296,67650,5380,1281,256,65830,1344,5140]

theorem envBound59039 : H12AffineFastState.Bounded env59039 := by
  intro p hp
  have h : env59039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59038_59039 : H12AffineEnvironment.transform 8 340 env59038 = env59039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env59038 == env59039) = true)

def env59040 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,277,65536,65895,65665,321,276,1,477,66615,65552,193,65831,319,65846,1296,67650,1284,1281,256,65830,1344,1044]

theorem envBound59040 : H12AffineFastState.Bounded env59040 := by
  intro p hp
  have h : env59040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59039_59040 : H12AffineEnvironment.transform 11 0 env59039 = env59040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59039 == env59040) = true)

theorem identity59040 : scanCanonicalize (H12AffineFastState.compose env59040 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound59040 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59041 : List Nat := [2,4,8,16,32,64,128,256,340,85,2048,0,349,325,277,65536,65895,65665,321,276,1,477,65634,65552,193,65831,319,65846,325,67650,337,340,256,65830,277,65]

theorem envBound59041 : H12AffineFastState.Bounded env59041 := by
  intro p hp
  have h : env59041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59040_59041 : H12AffineEnvironment.transform 9 85 env59040 = env59041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env59040 == env59041) = true)

theorem identity59041 : scanCanonicalize (H12AffineFastState.compose env59041 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound59041 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59042 : List Nat := [2,4,8,16,32,64,128,256,340,85,91,0,349,325,277,65536,65895,65665,321,276,1,477,65634,65552,193,65831,319,65846,325,65561,337,340,256,65830,277,65]

theorem envBound59042 : H12AffineFastState.Bounded env59042 := by
  intro p hp
  have h : env59042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59041_59042 : H12AffineEnvironment.transform 10 91 env59041 = env59042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env59041 == env59042) = true)

theorem identity59042 : scanCanonicalize (H12AffineFastState.compose env59042 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound59042 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59043 : List Nat := [2,4,8,16,32,64,20,256,340,85,91,0,349,325,277,65536,65895,65557,321,276,1,329,65634,65552,85,65831,319,65846,325,65561,337,340,256,65830,277,65]

theorem envBound59043 : H12AffineFastState.Bounded env59043 := by
  intro p hp
  have h : env59043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59042_59043 : H12AffineEnvironment.transform 6 20 env59042 = env59043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env59042 == env59043) = true)

theorem identity59043 : scanCanonicalize (H12AffineFastState.compose env59043 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59043 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env59044 : List Nat := [2,4,8,16,32,64,20,21,65,85,91,0,72,80,0,65536,65650,65557,84,1,1,92,65634,65552,85,65586,42,65571,80,65561,68,65,21,65587,0,65]

theorem envBound59044 : H12AffineFastState.Bounded env59044 := by
  intro p hp
  have h : env59044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59043_59044 : H12AffineEnvironment.transform 7 21 env59043 = env59044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59043 == env59044) = true)

theorem identity59044 : scanCanonicalize (H12AffineFastState.compose env59044 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 126) := by decide +kernel

theorem selectedBound59044 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59045 : List Nat := [2,4,8,16,32,64,20,21,65,85,91,0,72,80,0,126,12,107,84,1,1,92,28,110,85,76,42,93,80,103,68,65,21,77,0,65]

theorem envBound59045 : H12AffineFastState.Bounded env59045 := by
  intro p hp
  have h : env59045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59044_59045 : H12AffineEnvironment.transform 15 126 env59044 = env59045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 126 env59044 == env59045) = true)

theorem identity59045 : scanCanonicalize (H12AffineFastState.compose env59045 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59045 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59046 : List Nat := [2,4,8,11,32,64,15,14,65,78,64,0,72,75,0,101,12,107,79,1,1,71,7,110,78,76,42,70,75,103,68,65,14,77,0,65]

theorem envBound59046 : H12AffineFastState.Bounded env59046 := by
  intro p hp
  have h : env59046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59045_59046 : H12AffineEnvironment.transform 3 11 env59045 = env59046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59045 == env59046) = true)

theorem identity59046 : scanCanonicalize (H12AffineFastState.compose env59046 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound59046 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env59047 : List Nat := [2,4,8,11,32,12,15,14,13,2,12,0,4,7,0,41,12,39,3,1,1,11,7,34,2,0,42,10,7,43,8,13,14,1,0,13]

theorem envBound59047 : H12AffineFastState.Bounded env59047 := by
  intro p hp
  have h : env59047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59046_59047 : H12AffineEnvironment.transform 5 12 env59046 = env59047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env59046 == env59047) = true)

theorem identity59047 : scanCanonicalize (H12AffineFastState.compose env59047 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59047 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env59048 : List Nat := [2,4,8,11,11,12,15,14,13,2,12,0,4,7,0,2,12,12,3,1,1,11,7,9,2,0,1,10,7,0,8,13,14,1,0,13]

theorem envBound59048 : H12AffineFastState.Bounded env59048 := by
  intro p hp
  have h : env59048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59047_59048 : H12AffineEnvironment.transform 4 11 env59047 = env59048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59047 == env59048) = true)

theorem identity59048 : scanCanonicalize (H12AffineFastState.compose env59048 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59048 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59049 : List Nat := [2,4,5,6,6,1,2,3,0,2,1,0,4,7,0,2,1,1,3,1,1,6,7,4,2,0,1,7,7,0,5,0,3,1,0,0]

theorem envBound59049 : H12AffineFastState.Bounded env59049 := by
  intro p hp
  have h : env59049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59048_59049 : H12AffineEnvironment.transform 2 5 env59048 = env59049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59048 == env59049) = true)

def env59050 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,277,65536,65894,65665,320,276,0,477,66614,65553,193,65831,318,65847,1296,67650,1285,1281,256,65830,1344,1045]

theorem envBound59050 : H12AffineFastState.Bounded env59050 := by
  intro p hp
  have h : env59050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59039_59050 : H12AffineEnvironment.transform 11 1 env59039 = env59050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59039 == env59050) = true)

theorem identity59050 : scanCanonicalize (H12AffineFastState.compose env59050 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59050 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59051 : List Nat := [2,4,8,16,32,64,128,21,65,1024,2048,1,1052,1029,0,65536,65651,65665,85,1,0,200,66614,65553,193,65586,43,65570,1029,67650,1040,1044,21,65587,1109,1045]

theorem envBound59051 : H12AffineFastState.Bounded env59051 := by
  intro p hp
  have h : env59051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59050_59051 : H12AffineEnvironment.transform 7 21 env59050 = env59051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59050 == env59051) = true)

theorem identity59051 : scanCanonicalize (H12AffineFastState.compose env59051 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59051 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59052 : List Nat := [2,4,8,16,32,64,128,21,65,5,2048,1,25,0,0,65536,65651,65665,85,1,0,200,65587,65553,193,65586,43,65570,0,67650,21,17,21,65587,80,16]

theorem envBound59052 : H12AffineFastState.Bounded env59052 := by
  intro p hp
  have h : env59052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59051_59052 : H12AffineEnvironment.transform 9 5 env59051 = env59052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59051 == env59052) = true)

theorem identity59052 : scanCanonicalize (H12AffineFastState.compose env59052 (packedSelected [8,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2078) := by decide +kernel

theorem selectedBound59052 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env59053 : List Nat := [2,4,8,16,32,64,128,21,65,5,2048,1,25,0,0,2078,2157,2207,85,1,0,200,2093,2063,193,2092,43,2108,0,92,21,17,21,2093,80,16]

theorem envBound59053 : H12AffineFastState.Bounded env59053 := by
  intro p hp
  have h : env59053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59052_59053 : H12AffineEnvironment.transform 15 2078 env59052 = env59053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2078 env59052 == env59053) = true)

theorem identity59053 : scanCanonicalize (H12AffineFastState.compose env59053 (packedSelected [0,1,7,8,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound59053 : packedSelected [0,1,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env59054 : List Nat := [2,4,8,16,32,64,35,21,65,5,2048,1,25,0,0,2078,2157,2108,85,1,0,107,2093,2063,98,2092,43,2108,0,92,21,17,21,2093,80,16]

theorem envBound59054 : H12AffineFastState.Bounded env59054 := by
  intro p hp
  have h : env59054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59053_59054 : H12AffineEnvironment.transform 6 35 env59053 = env59054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env59053 == env59054) = true)

theorem identity59054 : scanCanonicalize (H12AffineFastState.compose env59054 (packedSelected [0,2,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound59054 : packedSelected [0,2,7,11,13] rootPS < 2^1333 := by decide +kernel

def env59055 : List Nat := [2,4,8,16,32,64,35,21,65,5,6,1,25,0,0,24,107,58,85,1,0,107,43,9,98,42,43,58,0,92,21,17,21,43,80,16]

theorem envBound59055 : H12AffineFastState.Bounded env59055 := by
  intro p hp
  have h : env59055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59054_59055 : H12AffineEnvironment.transform 10 6 env59054 = env59055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env59054 == env59055) = true)

theorem identity59055 : scanCanonicalize (H12AffineFastState.compose env59055 (packedSelected [10] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound59055 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env59056 : List Nat := [2,4,8,16,32,42,35,21,43,5,6,1,25,0,0,24,1,58,63,1,0,1,43,9,8,42,43,58,0,54,21,17,21,43,58,16]

theorem envBound59056 : H12AffineFastState.Bounded env59056 := by
  intro p hp
  have h : env59056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59055_59056 : H12AffineEnvironment.transform 5 42 env59055 = env59056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env59055 == env59056) = true)

theorem identity59056 : scanCanonicalize (H12AffineFastState.compose env59056 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound59056 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env59057 : List Nat := [2,4,8,13,32,42,35,8,43,5,6,1,4,0,0,5,1,39,34,1,0,1,43,9,8,42,43,39,0,43,8,12,8,43,39,13]

theorem envBound59057 : H12AffineFastState.Bounded env59057 := by
  intro p hp
  have h : env59057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59056_59057 : H12AffineEnvironment.transform 3 13 env59056 = env59057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env59056 == env59057) = true)

def env59058 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4097,477,70711,69648,193,65831,4415,69942,1296,67650,5380,1281,256,65830,1344,5141]

theorem envBound59058 : H12AffineFastState.Bounded env59058 := by
  intro p hp
  have h : env59058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59038_59058 : H12AffineEnvironment.transform 8 341 env59038 = env59058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env59038 == env59058) = true)

def env59059 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,277,65536,65895,65665,321,276,1,477,66615,65552,193,65831,319,65846,1296,67650,1284,1281,256,65830,1344,1045]

theorem envBound59059 : H12AffineFastState.Bounded env59059 := by
  intro p hp
  have h : env59059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59058_59059 : H12AffineEnvironment.transform 11 0 env59058 = env59059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59058 == env59059) = true)

theorem identity59059 : scanCanonicalize (H12AffineFastState.compose env59059 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound59059 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59060 : List Nat := [2,4,8,16,32,64,128,256,341,85,2048,0,349,325,277,65536,65895,65665,321,276,1,477,65634,65552,193,65831,319,65846,325,67650,337,340,256,65830,277,64]

theorem envBound59060 : H12AffineFastState.Bounded env59060 := by
  intro p hp
  have h : env59060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59059_59060 : H12AffineEnvironment.transform 9 85 env59059 = env59060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env59059 == env59060) = true)

theorem identity59060 : scanCanonicalize (H12AffineFastState.compose env59060 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound59060 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59061 : List Nat := [2,4,8,16,32,64,128,256,341,85,90,0,349,325,277,65536,65895,65665,321,276,1,477,65634,65552,193,65831,319,65846,325,65560,337,340,256,65830,277,64]

theorem envBound59061 : H12AffineFastState.Bounded env59061 := by
  intro p hp
  have h : env59061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59060_59061 : H12AffineEnvironment.transform 10 90 env59060 = env59061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env59060 == env59061) = true)

theorem identity59061 : scanCanonicalize (H12AffineFastState.compose env59061 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 230) := by decide +kernel

theorem selectedBound59061 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59062 : List Nat := [2,4,8,16,32,64,128,256,341,85,90,0,349,325,277,230,385,103,321,276,1,477,132,246,193,449,319,464,325,254,337,340,256,448,277,64]

theorem envBound59062 : H12AffineFastState.Bounded env59062 := by
  intro p hp
  have h : env59062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59061_59062 : H12AffineEnvironment.transform 15 230 env59061 = env59062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 230 env59061 == env59062) = true)

theorem identity59062 : scanCanonicalize (H12AffineFastState.compose env59062 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59062 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env59063 : List Nat := [2,4,8,16,32,64,128,21,64,85,90,0,72,80,0,230,148,103,84,1,1,200,132,246,193,212,42,197,80,254,68,65,21,213,0,64]

theorem envBound59063 : H12AffineFastState.Bounded env59063 := by
  intro p hp
  have h : env59063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59062_59063 : H12AffineEnvironment.transform 7 21 env59062 = env59063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59062 == env59063) = true)

theorem identity59063 : scanCanonicalize (H12AffineFastState.compose env59063 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59063 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59064 : List Nat := [2,4,5,16,32,64,128,21,64,85,87,0,69,80,0,230,148,103,84,1,1,197,132,246,193,212,39,197,80,243,68,65,21,213,0,64]

theorem envBound59064 : H12AffineFastState.Bounded env59064 := by
  intro p hp
  have h : env59064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59063_59064 : H12AffineEnvironment.transform 2 5 env59063 = env59064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59063 == env59064) = true)

theorem identity59064 : scanCanonicalize (H12AffineFastState.compose env59064 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound59064 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59065 : List Nat := [2,4,5,6,32,64,128,3,64,67,65,0,69,70,0,230,130,103,66,1,1,197,132,224,193,194,39,197,70,229,68,65,3,195,0,64]

theorem envBound59065 : H12AffineFastState.Bounded env59065 := by
  intro p hp
  have h : env59065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59064_59065 : H12AffineEnvironment.transform 3 6 env59064 = env59065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env59064 == env59065) = true)

theorem identity59065 : scanCanonicalize (H12AffineFastState.compose env59065 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound59065 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env59066 : List Nat := [2,4,5,6,32,64,67,3,64,67,65,0,69,70,0,37,65,103,66,1,1,6,71,35,2,1,39,6,70,38,68,65,3,0,0,64]

theorem envBound59066 : H12AffineFastState.Bounded env59066 := by
  intro p hp
  have h : env59066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59065_59066 : H12AffineEnvironment.transform 6 67 env59065 = env59066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env59065 == env59066) = true)

theorem identity59066 : scanCanonicalize (H12AffineFastState.compose env59066 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59066 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env59067 : List Nat := [2,4,5,6,6,64,67,3,64,67,65,0,69,70,0,3,65,65,66,1,1,6,71,5,2,1,1,6,70,0,68,65,3,0,0,64]

theorem envBound59067 : H12AffineFastState.Bounded env59067 := by
  intro p hp
  have h : env59067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59066_59067 : H12AffineEnvironment.transform 4 6 env59066 = env59067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59066 == env59067) = true)

theorem identity59067 : scanCanonicalize (H12AffineFastState.compose env59067 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59067 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59068 : List Nat := [2,4,5,6,6,0,3,3,0,3,1,0,5,6,0,3,1,1,2,1,1,6,7,5,2,1,1,6,6,0,4,1,3,0,0,0]

theorem envBound59068 : H12AffineFastState.Bounded env59068 := by
  intro p hp
  have h : env59068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59067_59068 : H12AffineEnvironment.transform 5 0 env59067 = env59068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59067 == env59068) = true)

def env59069 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,277,65536,65894,65665,320,276,0,477,66614,65553,193,65831,318,65847,1296,67650,1285,1281,256,65830,1344,1044]

theorem envBound59069 : H12AffineFastState.Bounded env59069 := by
  intro p hp
  have h : env59069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59058_59069 : H12AffineEnvironment.transform 11 1 env59058 = env59069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59058 == env59069) = true)

theorem identity59069 : scanCanonicalize (H12AffineFastState.compose env59069 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59069 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59070 : List Nat := [2,4,8,16,32,64,128,21,64,1024,2048,1,1052,1029,0,65536,65651,65665,85,1,0,200,66614,65553,193,65586,43,65570,1029,67650,1040,1044,21,65587,1109,1044]

theorem envBound59070 : H12AffineFastState.Bounded env59070 := by
  intro p hp
  have h : env59070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59069_59070 : H12AffineEnvironment.transform 7 21 env59069 = env59070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59069 == env59070) = true)

theorem identity59070 : scanCanonicalize (H12AffineFastState.compose env59070 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59070 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59071 : List Nat := [2,4,8,16,32,64,128,21,64,5,2048,1,25,0,0,65536,65651,65665,85,1,0,200,65587,65553,193,65586,43,65570,0,67650,21,17,21,65587,80,17]

theorem envBound59071 : H12AffineFastState.Bounded env59071 := by
  intro p hp
  have h : env59071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59070_59071 : H12AffineEnvironment.transform 9 5 env59070 = env59071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59070 == env59071) = true)

theorem identity59071 : scanCanonicalize (H12AffineFastState.compose env59071 (packedSelected [8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 108) := by decide +kernel

theorem selectedBound59071 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env59072 : List Nat := [2,4,8,16,32,64,128,21,64,5,108,1,25,0,0,65536,65651,65665,85,1,0,200,65587,65553,193,65586,43,65570,0,65582,21,17,21,65587,80,17]

theorem envBound59072 : H12AffineFastState.Bounded env59072 := by
  intro p hp
  have h : env59072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59071_59072 : H12AffineEnvironment.transform 10 108 env59071 = env59072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 108 env59071 == env59072) = true)

theorem identity59072 : scanCanonicalize (H12AffineFastState.compose env59072 (packedSelected [0,1,7,8,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound59072 : packedSelected [0,1,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env59073 : List Nat := [2,4,8,16,32,64,35,21,64,5,108,1,25,0,0,65536,65651,65570,85,1,0,107,65587,65553,98,65586,43,65570,0,65582,21,17,21,65587,80,17]

theorem envBound59073 : H12AffineFastState.Bounded env59073 := by
  intro p hp
  have h : env59073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59072_59073 : H12AffineEnvironment.transform 6 35 env59072 = env59073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env59072 == env59073) = true)

theorem identity59073 : scanCanonicalize (H12AffineFastState.compose env59073 (packedSelected [0,2,7,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 25) := by decide +kernel

theorem selectedBound59073 : packedSelected [0,2,7,11,13] rootPS < 2^1333 := by decide +kernel

def env59074 : List Nat := [2,4,8,16,32,64,35,21,64,5,108,1,25,0,0,25,106,59,85,1,0,107,42,8,98,43,43,59,0,55,21,17,21,42,80,17]

theorem envBound59074 : H12AffineFastState.Bounded env59074 := by
  intro p hp
  have h : env59074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59073_59074 : H12AffineEnvironment.transform 15 25 env59073 = env59074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env59073 == env59074) = true)

theorem identity59074 : scanCanonicalize (H12AffineFastState.compose env59074 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound59074 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env59075 : List Nat := [2,4,8,16,26,64,25,21,64,5,86,1,25,0,0,25,80,1,85,1,0,81,16,8,88,17,17,1,0,13,21,17,21,16,80,17]

theorem envBound59075 : H12AffineFastState.Bounded env59075 := by
  intro p hp
  have h : env59075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59074_59075 : H12AffineEnvironment.transform 4 26 env59074 = env59075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env59074 == env59075) = true)

theorem identity59075 : scanCanonicalize (H12AffineFastState.compose env59075 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59075 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59076 : List Nat := [2,4,8,16,26,0,25,21,0,5,22,1,25,0,0,25,16,1,21,1,0,17,16,8,24,17,17,1,0,13,21,17,21,16,16,17]

theorem envBound59076 : H12AffineFastState.Bounded env59076 := by
  intro p hp
  have h : env59076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59075_59076 : H12AffineEnvironment.transform 5 0 env59075 = env59076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59075 == env59076) = true)

def env59077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4097,476,74046,69649,13768,78895,332223,74815,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound59077 : H12AffineFastState.Bounded env59077 := by
  intro p hp
  have h : env59077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58987_59077 : H12AffineEnvironment.transform 13 1297 env58987 = env59077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58987 == env59077) = true)

def env59078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4097,476,74046,69649,13768,78895,4415,74815,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound59078 : H12AffineFastState.Bounded env59078 := by
  intro p hp
  have h : env59078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59077_59078 : H12AffineEnvironment.transform 17 65664 env59077 = env59078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59077 == env59078) = true)

theorem identity59078 : scanCanonicalize (H12AffineFastState.compose env59078 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound59078 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,0,476,74046,65552,9673,74798,318,74815,1296,77130,8205,1281,256,65831,1344,1856]

theorem envBound59079 : H12AffineFastState.Bounded env59079 := by
  intro p hp
  have h : env59079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59078_59079 : H12AffineEnvironment.transform 11 1 env59078 = env59079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59078 == env59079) = true)

def env59080 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,0,476,74046,65552,9673,74798,318,74815,1296,77130,8205,1281,256,65831,1344,1044]

theorem envBound59080 : H12AffineFastState.Bounded env59080 := by
  intro p hp
  have h : env59080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59079_59080 : H12AffineEnvironment.transform 8 340 env59079 = env59080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env59079 == env59080) = true)

def env59081 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9228,65536,74863,65664,321,9229,0,460,74030,65536,9673,74798,302,74799,1280,77130,8205,1281,256,65831,1344,1028]

theorem envBound59081 : H12AffineFastState.Bounded env59081 := by
  intro p hp
  have h : env59081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59080_59081 : H12AffineEnvironment.transform 3 0 env59080 = env59081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59080 == env59081) = true)

theorem identity59081 : scanCanonicalize (H12AffineFastState.compose env59081 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1024) := by decide +kernel

theorem selectedBound59081 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59082 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,1024,1281,12,65536,65647,65664,321,13,0,460,66862,65536,457,65582,302,65583,1280,67914,1037,1281,256,65831,1344,1028]

theorem envBound59082 : H12AffineFastState.Bounded env59082 := by
  intro p hp
  have h : env59082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59081_59082 : H12AffineEnvironment.transform 12 1024 env59081 = env59082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1024 env59081 == env59082) = true)

def env59083 : List Nat := [2,4,4,0,32,64,128,256,324,1024,2048,1,1024,1281,0,65536,65635,65664,321,1,0,448,66850,65536,453,65570,290,65571,1280,67910,1025,1281,256,65831,1344,1028]

theorem envBound59083 : H12AffineFastState.Bounded env59083 := by
  intro p hp
  have h : env59083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59082_59083 : H12AffineEnvironment.transform 2 4 env59082 = env59083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59082 == env59083) = true)

theorem identity59083 : scanCanonicalize (H12AffineFastState.compose env59083 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59083 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59084 : List Nat := [2,4,4,0,32,1,128,256,261,1024,2048,1,1024,1281,0,65536,65570,65664,256,1,0,385,66850,65536,388,65570,290,65571,1280,67847,1025,1281,256,65831,1281,1028]

theorem envBound59084 : H12AffineFastState.Bounded env59084 := by
  intro p hp
  have h : env59084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59083_59084 : H12AffineEnvironment.transform 5 1 env59083 = env59084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59083 == env59084) = true)

theorem identity59084 : scanCanonicalize (H12AffineFastState.compose env59084 (packedSelected [5,11,13,18,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound59084 : packedSelected [5,11,13,18,19,21] rootPS < 2^1333 := by decide +kernel

def env59085 : List Nat := [2,4,4,0,32,1,128,256,261,1024,2048,1,1024,1281,0,2343,2309,2471,256,1,0,385,3077,2343,388,2309,290,2308,1280,32,1025,1281,256,2048,1281,1028]

theorem envBound59085 : H12AffineFastState.Bounded env59085 := by
  intro p hp
  have h : env59085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59084_59085 : H12AffineEnvironment.transform 15 2343 env59084 = env59085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env59084 == env59085) = true)

theorem identity59085 : scanCanonicalize (H12AffineFastState.compose env59085 (packedSelected [2,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1287) := by decide +kernel

theorem selectedBound59085 : packedSelected [2,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env59086 : List Nat := [2,4,4,0,32,1,128,256,261,1024,1287,1,1024,1281,0,1056,1026,1184,256,1,0,385,258,1056,388,1026,290,1027,1280,32,1025,1281,256,1287,1281,1028]

theorem envBound59086 : H12AffineFastState.Bounded env59086 := by
  intro p hp
  have h : env59086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59085_59086 : H12AffineEnvironment.transform 10 1287 env59085 = env59086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1287 env59085 == env59086) = true)

theorem identity59086 : scanCanonicalize (H12AffineFastState.compose env59086 (packedSelected [2,3,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 388) := by decide +kernel

theorem selectedBound59086 : packedSelected [2,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59087 : List Nat := [2,4,4,0,32,1,128,256,261,388,131,1,388,133,0,420,390,292,256,1,0,385,258,420,388,390,290,391,132,32,389,133,256,131,133,384]

theorem envBound59087 : H12AffineFastState.Bounded env59087 := by
  intro p hp
  have h : env59087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59086_59087 : H12AffineEnvironment.transform 9 388 env59086 = env59087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env59086 == env59087) = true)

theorem identity59087 : scanCanonicalize (H12AffineFastState.compose env59087 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59087 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59088 : List Nat := [2,4,4,0,6,1,128,256,261,388,131,1,388,133,0,386,390,258,256,1,0,385,258,386,388,390,260,391,132,6,389,133,256,131,133,384]

theorem envBound59088 : H12AffineFastState.Bounded env59088 := by
  intro p hp
  have h : env59088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59087_59088 : H12AffineEnvironment.transform 4 6 env59087 = env59088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59087 == env59088) = true)

theorem identity59088 : scanCanonicalize (H12AffineFastState.compose env59088 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound59088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59089 : List Nat := [2,4,4,0,6,1,2,256,261,262,1,1,262,7,0,256,260,258,256,1,0,259,258,256,262,260,260,261,6,6,263,7,256,1,7,258]

theorem envBound59089 : H12AffineFastState.Bounded env59089 := by
  intro p hp
  have h : env59089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59088_59089 : H12AffineEnvironment.transform 6 2 env59088 = env59089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env59088 == env59089) = true)

theorem identity59089 : scanCanonicalize (H12AffineFastState.compose env59089 (packedSelected [0,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound59089 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env59090 : List Nat := [2,4,4,0,6,1,2,3,6,5,1,1,5,7,0,3,7,1,3,1,0,0,1,3,5,7,7,6,6,6,4,7,3,1,7,1]

theorem envBound59090 : H12AffineFastState.Bounded env59090 := by
  intro p hp
  have h : env59090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2