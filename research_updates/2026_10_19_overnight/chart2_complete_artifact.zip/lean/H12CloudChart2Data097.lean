import H12CloudChart2Data096

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound23820 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23821 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,9,0,1,65536,1,512,272,0,1,513,17,65796,129,16,65674,0,0,292,21,65706,257,773,65934,512]

theorem envBound23821 : H12AffineFastState.Bounded env23821 := by
  intro p hp
  have h : env23821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23820_23821 : H12AffineEnvironment.transform 26 65674 env23820 = env23821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 65674 env23820 == env23821) = true)

theorem identity23821 : scanCanonicalize (H12AffineFastState.compose env23821 (packedSelected [8,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound23821 : packedSelected [8,15,17] rootPS < 2^1333 := by decide +kernel

def env23822 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,9,0,1,399,1,512,272,0,1,513,17,139,129,16,261,0,0,292,21,293,257,773,1,512]

theorem envBound23822 : H12AffineFastState.Bounded env23822 := by
  intro p hp
  have h : env23822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23821_23822 : H12AffineEnvironment.transform 15 399 env23821 = env23822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env23821 == env23822) = true)

theorem identity23822 : scanCanonicalize (H12AffineFastState.compose env23822 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound23822 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23823 : List Nat := [2,4,8,16,32,17,128,256,261,273,2048,1,9,0,1,399,1,261,272,0,1,260,17,139,129,16,261,0,0,292,21,293,257,0,1,261]

theorem envBound23823 : H12AffineFastState.Bounded env23823 := by
  intro p hp
  have h : env23823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23822_23823 : H12AffineEnvironment.transform 8 261 env23822 = env23823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env23822 == env23823) = true)

theorem identity23823 : scanCanonicalize (H12AffineFastState.compose env23823 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound23823 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23824 : List Nat := [2,4,8,16,32,17,128,256,261,273,292,1,9,0,1,399,1,261,272,0,1,260,17,139,129,16,261,0,0,292,21,293,257,0,1,261]

theorem envBound23824 : H12AffineFastState.Bounded env23824 := by
  intro p hp
  have h : env23824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23823_23824 : H12AffineEnvironment.transform 10 292 env23823 = env23824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env23823 == env23824) = true)

def env23825 : List Nat := [2,4,8,16,0,17,128,256,261,273,260,1,9,0,1,399,1,261,272,0,1,260,17,139,129,16,261,0,0,260,21,261,257,0,1,261]

theorem envBound23825 : H12AffineFastState.Bounded env23825 := by
  intro p hp
  have h : env23825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23824_23825 : H12AffineEnvironment.transform 4 0 env23824 = env23825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23824 == env23825) = true)

theorem identity23825 : scanCanonicalize (H12AffineFastState.compose env23825 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23826 : List Nat := [2,4,8,16,0,17,128,4,1,21,0,1,9,0,1,139,1,1,20,0,1,0,17,139,129,16,1,0,0,0,21,1,5,0,1,1]

theorem envBound23826 : H12AffineFastState.Bounded env23826 := by
  intro p hp
  have h : env23826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23825_23826 : H12AffineEnvironment.transform 7 4 env23825 = env23826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23825 == env23826) = true)

def env23827 : List Nat := [2,4,8,16,1,17,128,256,261,273,261,1,9,0,1,399,1,261,272,0,1,260,17,139,129,16,261,0,0,261,21,260,257,0,1,261]

theorem envBound23827 : H12AffineFastState.Bounded env23827 := by
  intro p hp
  have h : env23827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23824_23827 : H12AffineEnvironment.transform 4 1 env23824 = env23827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23824 == env23827) = true)

def env23828 : List Nat := [2,4,8,16,1,17,8,256,261,273,261,1,9,0,1,263,1,261,272,0,1,260,17,3,9,16,261,0,0,261,21,260,257,0,1,261]

theorem envBound23828 : H12AffineFastState.Bounded env23828 := by
  intro p hp
  have h : env23828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23827_23828 : H12AffineEnvironment.transform 6 8 env23827 = env23828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23827 == env23828) = true)

def env23829 : List Nat := [2,4,8,16,1,17,9,256,261,273,261,1,9,0,1,262,1,261,272,0,1,260,17,2,8,16,261,0,0,261,21,260,257,0,1,261]

theorem envBound23829 : H12AffineFastState.Bounded env23829 := by
  intro p hp
  have h : env23829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23827_23829 : H12AffineEnvironment.transform 6 9 env23827 = env23829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23827 == env23829) = true)

theorem identity23829 : scanCanonicalize (H12AffineFastState.compose env23829 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23829 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23830 : List Nat := [2,4,8,16,1,17,9,5,0,20,0,1,9,0,1,3,1,0,21,0,1,1,17,2,8,16,0,0,0,0,21,1,4,0,1,0]

theorem envBound23830 : H12AffineFastState.Bounded env23830 := by
  intro p hp
  have h : env23830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23829_23830 : H12AffineEnvironment.transform 7 5 env23829 = env23830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23829 == env23830) = true)

def leafEnv23830 : List Nat := [2,4,8,16,1,17,9,5,0,20,0,1,9,0,1,3,1,0,21,0,1,1,17,2,20,8,1,16,0,0,0,0,21,1,4,0,5,3,1,0,0,0,1]

def active23830 : List Nat := [0,1,2,3]

def tree23830 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23830 : H12WitnessSearch.Good tree23830 := H12GlobalWitnessIndex.good

theorem leafIdentity23830 : H12AffineFastState.composeSystem env23830 rootObs = leafEnv23830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23830 rootObs == leafEnv23830) = true)

theorem terminalChecked23830 : H12PackedTerminal.terminalCheckFast leafEnv23830 active23830 tree23830 = true := by decide +kernel

def env23831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,4194304,17,98565,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4299260335,138413636,512]

theorem envBound23831 : H12AffineFastState.Bounded env23831 := by
  intro p hp
  have h : env23831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23747_23831 : H12AffineEnvironment.transform 17 513 env23747 = env23831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env23747 == env23831) = true)

theorem identity23831 : scanCanonicalize (H12AffineFastState.compose env23831 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 41228) := by decide +kernel

theorem selectedBound23831 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,4194304,17,98565,8328,65,41228,1297,1297,1073741824,1284,4294967296,257,4299260335,4237128,512]

theorem envBound23832 : H12AffineFastState.Bounded env23832 := by
  intro p hp
  have h : env23832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23831_23832 : H12AffineEnvironment.transform 26 41228 env23831 = env23832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 41228 env23831 == env23832) = true)

theorem identity23832 : scanCanonicalize (H12AffineFastState.compose env23832 (packedSelected [1,5,8,13,15,21,28,41] rootPS)) = affineNative (2^(21+1) ^^^ 41481) := by decide +kernel

theorem selectedBound23832 : packedSelected [1,5,8,13,15,21,28,41] rootPS < 2^1333 := by decide +kernel

def env23833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,41481,17,98565,8328,65,41228,1297,1297,1073741824,1284,4294967296,257,4295041958,1345,512]

theorem envBound23833 : H12AffineFastState.Bounded env23833 := by
  intro p hp
  have h : env23833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23832_23833 : H12AffineEnvironment.transform 21 41481 env23832 = env23833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41481 env23832 == env23833) = true)

theorem identity23833 : scanCanonicalize (H12AffineFastState.compose env23833 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 76419) := by decide +kernel

theorem selectedBound23833 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,41481,17,98565,8328,65,41228,1297,1297,76419,1284,4294967296,257,4295041958,1345,512]

theorem envBound23834 : H12AffineFastState.Bounded env23834 := by
  intro p hp
  have h : env23834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23833_23834 : H12AffineEnvironment.transform 29 76419 env23833 = env23834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76419 env23833 == env23834) = true)

def env23835 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1297,32768,65536,1345,137,1025,32769,1345,41089,17,98565,8328,65,41228,1297,1297,75787,1284,4294967296,257,4295041326,1345,136]

theorem envBound23835 : H12AffineFastState.Bounded env23835 := by
  intro p hp
  have h : env23835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23834_23835 : H12AffineEnvironment.transform 8 136 env23834 = env23835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env23834 == env23835) = true)

theorem identity23835 : scanCanonicalize (H12AffineFastState.compose env23835 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound23835 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23836 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1297,32768,65536,1345,137,1025,32769,1345,41089,17,98565,8328,65,41228,1297,1297,75787,1284,74031,257,1,1345,136]

theorem envBound23836 : H12AffineFastState.Bounded env23836 := by
  intro p hp
  have h : env23836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23835_23836 : H12AffineEnvironment.transform 31 74031 env23835 = env23836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env23835 == env23836) = true)

def env23837 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1297,0,65536,1345,137,1025,1,1345,8321,17,65797,8328,65,8460,1297,1297,75787,1284,74031,257,1,1345,136]

theorem envBound23837 : H12AffineFastState.Bounded env23837 := by
  intro p hp
  have h : env23837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23836_23837 : H12AffineEnvironment.transform 14 0 env23836 = env23837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23836 == env23837) = true)

theorem identity23837 : scanCanonicalize (H12AffineFastState.compose env23837 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound23837 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23838 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,469,1297,0,65536,1345,137,1025,1,1345,340,17,65797,349,65,217,1297,1297,68062,1284,65786,257,1,1345,136]

theorem envBound23838 : H12AffineFastState.Bounded env23838 := by
  intro p hp
  have h : env23838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23837_23838 : H12AffineEnvironment.transform 12 469 env23837 = env23838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env23837 == env23838) = true)

def env23839 : List Nat := [2,4,8,16,32,64,128,256,136,272,2048,81,469,1,0,65536,81,137,273,1,81,340,17,65797,349,65,217,1,1,68062,20,65786,257,1,81,136]

theorem envBound23839 : H12AffineFastState.Bounded env23839 := by
  intro p hp
  have h : env23839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23838_23839 : H12AffineEnvironment.transform 9 272 env23838 = env23839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23838 == env23839) = true)

theorem identity23839 : scanCanonicalize (H12AffineFastState.compose env23839 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound23839 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23840 : List Nat := [2,4,8,16,32,64,128,256,136,272,2048,81,469,1,0,478,81,137,273,1,81,340,17,219,349,65,217,1,1,2048,20,292,257,1,81,136]

theorem envBound23840 : H12AffineFastState.Bounded env23840 := by
  intro p hp
  have h : env23840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23839_23840 : H12AffineEnvironment.transform 15 478 env23839 = env23840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env23839 == env23840) = true)

theorem identity23840 : scanCanonicalize (H12AffineFastState.compose env23840 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23840 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env23841 : List Nat := [2,4,8,16,32,64,128,4,136,20,2048,81,209,1,0,218,81,137,21,1,81,80,17,219,89,65,217,1,1,2048,20,32,5,1,81,136]

theorem envBound23841 : H12AffineFastState.Bounded env23841 := by
  intro p hp
  have h : env23841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23840_23841 : H12AffineEnvironment.transform 7 4 env23840 = env23841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23840 == env23841) = true)

theorem identity23841 : scanCanonicalize (H12AffineFastState.compose env23841 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23841 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23842 : List Nat := [2,4,8,16,32,16,128,4,136,20,2048,1,129,1,0,138,1,137,21,1,1,0,17,139,9,17,137,1,1,2048,20,32,5,1,1,136]

theorem envBound23842 : H12AffineFastState.Bounded env23842 := by
  intro p hp
  have h : env23842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23841_23842 : H12AffineEnvironment.transform 5 16 env23841 = env23842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23841 == env23842) = true)

theorem identity23842 : scanCanonicalize (H12AffineFastState.compose env23842 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound23842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23843 : List Nat := [2,4,8,16,32,16,128,4,136,20,33,1,129,1,0,138,1,137,21,1,1,0,17,139,9,17,137,1,1,33,20,32,5,1,1,136]

theorem envBound23843 : H12AffineFastState.Bounded env23843 := by
  intro p hp
  have h : env23843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23842_23843 : H12AffineEnvironment.transform 10 33 env23842 = env23843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env23842 == env23843) = true)

theorem identity23843 : scanCanonicalize (H12AffineFastState.compose env23843 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23844 : List Nat := [2,4,8,16,32,16,40,4,32,20,33,1,41,1,0,34,1,33,21,1,1,0,17,35,9,17,33,1,1,33,20,32,5,1,1,32]

theorem envBound23844 : H12AffineFastState.Bounded env23844 := by
  intro p hp
  have h : env23844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23843_23844 : H12AffineEnvironment.transform 6 40 env23843 = env23844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23843 == env23844) = true)

def leafEnv23844 : List Nat := [2,4,8,16,32,16,40,4,32,20,33,1,41,1,0,34,1,33,21,1,1,0,17,35,21,9,1,17,33,1,1,33,20,32,5,1,5,3,1,32,0,1,1]

def active23844 : List Nat := [0,1,2,3,4]

def tree23844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23844 : H12WitnessSearch.Good tree23844 := H12GlobalWitnessIndex.good

theorem leafIdentity23844 : H12AffineFastState.composeSystem env23844 rootObs = leafEnv23844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23844 rootObs == leafEnv23844) = true)

theorem terminalChecked23844 : H12PackedTerminal.terminalCheckFast leafEnv23844 active23844 tree23844 = true := by decide +kernel

def env23845 : List Nat := [2,4,8,16,32,64,128,256,136,273,2048,80,469,0,0,65536,80,137,272,1,80,340,17,65797,349,65,217,0,0,68062,21,65786,257,1,80,136]

theorem envBound23845 : H12AffineFastState.Bounded env23845 := by
  intro p hp
  have h : env23845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23838_23845 : H12AffineEnvironment.transform 9 273 env23838 = env23845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23838 == env23845) = true)

theorem identity23845 : scanCanonicalize (H12AffineFastState.compose env23845 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23845 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23846 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,0,389,0,0,65536,0,137,272,1,0,260,17,65797,269,17,137,0,0,67982,21,65706,257,1,0,136]

theorem envBound23846 : H12AffineFastState.Bounded env23846 := by
  intro p hp
  have h : env23846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23845_23846 : H12AffineEnvironment.transform 5 16 env23845 = env23846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23845 == env23846) = true)

theorem identity23846 : scanCanonicalize (H12AffineFastState.compose env23846 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23846 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23847 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,0,129,0,0,65536,0,137,20,1,0,0,17,65537,9,17,137,0,0,67722,21,65706,5,1,0,136]

theorem envBound23847 : H12AffineFastState.Bounded env23847 := by
  intro p hp
  have h : env23847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23846_23847 : H12AffineEnvironment.transform 7 4 env23846 = env23847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23846 == env23847) = true)

theorem identity23847 : scanCanonicalize (H12AffineFastState.compose env23847 (packedSelected [2,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23847 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23848 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,0,129,0,0,34,0,137,20,1,0,0,17,35,9,17,137,0,0,2216,21,136,5,1,0,136]

theorem envBound23848 : H12AffineFastState.Bounded env23848 := by
  intro p hp
  have h : env23848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23847_23848 : H12AffineEnvironment.transform 15 34 env23847 = env23848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23847 == env23848) = true)

theorem identity23848 : scanCanonicalize (H12AffineFastState.compose env23848 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound23848 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env23849 : List Nat := [2,4,8,16,32,16,128,4,136,21,137,0,129,0,0,34,0,137,20,1,0,0,17,35,9,17,137,0,0,33,21,136,5,1,0,136]

theorem envBound23849 : H12AffineFastState.Bounded env23849 := by
  intro p hp
  have h : env23849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23848_23849 : H12AffineEnvironment.transform 10 137 env23848 = env23849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env23848 == env23849) = true)

theorem identity23849 : scanCanonicalize (H12AffineFastState.compose env23849 (packedSelected [18] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23849 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23850 : List Nat := [2,4,8,16,32,16,40,4,32,21,33,0,41,0,0,34,0,33,20,1,0,0,17,35,9,17,33,0,0,33,21,32,5,1,0,32]

theorem envBound23850 : H12AffineFastState.Bounded env23850 := by
  intro p hp
  have h : env23850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23849_23850 : H12AffineEnvironment.transform 6 40 env23849 = env23850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23849 == env23850) = true)

def leafEnv23850 : List Nat := [2,4,8,16,32,16,40,4,32,21,33,0,41,0,0,34,0,33,20,1,0,0,17,35,20,9,1,17,33,0,0,33,21,32,5,1,5,3,0,32,0,0,1]

def active23850 : List Nat := [0,1,2,3,4]

def tree23850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23850 : H12WitnessSearch.Good tree23850 := H12GlobalWitnessIndex.good

theorem leafIdentity23850 : H12AffineFastState.composeSystem env23850 rootObs = leafEnv23850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23850 rootObs == leafEnv23850) = true)

theorem terminalChecked23850 : H12PackedTerminal.terminalCheckFast leafEnv23850 active23850 tree23850 = true := by decide +kernel

def env23851 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1297,1,65536,1345,137,1025,0,1345,8320,17,65796,8328,65,8461,1297,1297,75787,1284,74031,257,1,1345,136]

theorem envBound23851 : H12AffineFastState.Bounded env23851 := by
  intro p hp
  have h : env23851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23836_23851 : H12AffineEnvironment.transform 14 1 env23836 = env23851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23836 == env23851) = true)

theorem identity23851 : scanCanonicalize (H12AffineFastState.compose env23851 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23851 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23852 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,1,65536,1296,137,1025,0,1296,8320,17,65796,8328,16,8461,1297,1297,75787,1284,74031,257,1,1296,136]

theorem envBound23852 : H12AffineFastState.Bounded env23852 := by
  intro p hp
  have h : env23852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23851_23852 : H12AffineEnvironment.transform 5 17 env23851 = env23852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23851 == env23852) = true)

theorem identity23852 : scanCanonicalize (H12AffineFastState.compose env23852 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound23852 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23853 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2209,1297,1,65536,1296,137,1025,0,1296,2081,17,65796,2089,16,2476,1297,1297,65706,1284,67982,257,1,1296,136]

theorem envBound23853 : H12AffineFastState.Bounded env23853 := by
  intro p hp
  have h : env23853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23852_23853 : H12AffineEnvironment.transform 12 2209 env23852 = env23853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env23852 == env23853) = true)

theorem identity23853 : scanCanonicalize (H12AffineFastState.compose env23853 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23854 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1181,2209,1180,1,65536,1181,137,1025,0,1181,2081,17,65673,2089,16,2081,1180,1180,65706,1161,67587,140,1,1181,136]

theorem envBound23854 : H12AffineFastState.Bounded env23854 := by
  intro p hp
  have h : env23854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23853_23854 : H12AffineEnvironment.transform 7 141 env23853 = env23854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23853 == env23854) = true)

theorem identity23854 : scanCanonicalize (H12AffineFastState.compose env23854 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound23854 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env23855 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1181,2209,1180,1,2,1181,137,1025,0,1181,2081,17,139,2089,16,2081,1180,1180,168,1161,2049,140,1,1181,136]

theorem envBound23855 : H12AffineFastState.Bounded env23855 := by
  intro p hp
  have h : env23855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23854_23855 : H12AffineEnvironment.transform 15 2 env23854 = env23855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env23854 == env23855) = true)

theorem identity23855 : scanCanonicalize (H12AffineFastState.compose env23855 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound23855 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23856 : List Nat := [2,4,8,16,32,17,128,141,136,1024,168,1181,9,1180,1,2,1181,137,1025,0,1181,137,17,139,129,16,137,1180,1180,168,1161,169,140,1,1181,136]

theorem envBound23856 : H12AffineFastState.Bounded env23856 := by
  intro p hp
  have h : env23856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23855_23856 : H12AffineEnvironment.transform 10 168 env23855 = env23856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env23855 == env23856) = true)

theorem identity23856 : scanCanonicalize (H12AffineFastState.compose env23856 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23856 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23857 : List Nat := [2,4,8,16,0,17,128,141,136,1024,136,1181,9,1180,1,2,1181,137,1025,0,1181,137,17,139,129,16,137,1180,1180,136,1161,137,140,1,1181,136]

theorem envBound23857 : H12AffineFastState.Bounded env23857 := by
  intro p hp
  have h : env23857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23856_23857 : H12AffineEnvironment.transform 4 0 env23856 = env23857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23856 == env23857) = true)

def env23858 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1345,136,1025,32769,1345,41088,17,98565,8328,65,41228,1297,1297,75786,1284,4294967296,257,4295041327,1345,137]

theorem envBound23858 : H12AffineFastState.Bounded env23858 := by
  intro p hp
  have h : env23858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23834_23858 : H12AffineEnvironment.transform 8 137 env23834 = env23858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23834 == env23858) = true)

theorem identity23858 : scanCanonicalize (H12AffineFastState.compose env23858 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98338) := by decide +kernel

theorem selectedBound23858 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23859 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1345,136,1025,32769,1345,41088,17,98565,8328,65,41228,1297,1297,75786,1284,98338,257,41229,1345,137]

theorem envBound23859 : H12AffineFastState.Bounded env23859 := by
  intro p hp
  have h : env23859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23858_23859 : H12AffineEnvironment.transform 31 98338 env23858 = env23859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98338 env23858 == env23859) = true)

def env23860 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,0,65536,1345,136,1025,1,1345,8320,17,65797,8328,65,8460,1297,1297,75786,1284,65570,257,8461,1345,137]

theorem envBound23860 : H12AffineFastState.Bounded env23860 := by
  intro p hp
  have h : env23860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23859_23860 : H12AffineEnvironment.transform 14 0 env23859 = env23860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23859 == env23860) = true)

theorem identity23860 : scanCanonicalize (H12AffineFastState.compose env23860 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound23860 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23861 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1345,8192,1297,0,65536,1345,80,1025,1,1345,8280,17,65797,8272,65,8460,1297,1297,75786,1284,65570,257,8461,1345,81]

theorem envBound23861 : H12AffineFastState.Bounded env23861 := by
  intro p hp
  have h : env23861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23860_23861 : H12AffineEnvironment.transform 6 88 env23860 = env23861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env23860 == env23861) = true)

def env23862 : List Nat := [2,4,8,16,32,64,88,256,81,320,2048,1,8192,81,0,65536,1,80,321,1,1,8280,17,65797,8272,65,8460,81,81,75786,68,65570,257,8461,1,81]

theorem envBound23862 : H12AffineFastState.Bounded env23862 := by
  intro p hp
  have h : env23862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23861_23862 : H12AffineEnvironment.transform 9 320 env23861 = env23862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23861 == env23862) = true)

theorem identity23862 : scanCanonicalize (H12AffineFastState.compose env23862 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound23862 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23863 : List Nat := [2,4,8,16,32,64,88,256,81,320,32,1,8192,81,0,65536,1,80,321,1,1,8280,17,65797,8272,65,8460,81,81,73770,68,65570,257,8461,1,81]

theorem envBound23863 : H12AffineFastState.Bounded env23863 := by
  intro p hp
  have h : env23863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23862_23863 : H12AffineEnvironment.transform 10 32 env23862 = env23863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env23862 == env23863) = true)

theorem identity23863 : scanCanonicalize (H12AffineFastState.compose env23863 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 8463) := by decide +kernel

theorem selectedBound23863 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23864 : List Nat := [2,4,8,16,32,64,88,256,81,320,32,1,8192,81,0,8463,1,80,321,1,1,8280,17,8202,8272,65,8460,81,81,293,68,8493,257,8461,1,81]

theorem envBound23864 : H12AffineFastState.Bounded env23864 := by
  intro p hp
  have h : env23864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23863_23864 : H12AffineEnvironment.transform 15 8463 env23863 = env23864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8463 env23863 == env23864) = true)

theorem identity23864 : scanCanonicalize (H12AffineFastState.compose env23864 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound23864 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23865 : List Nat := [2,4,8,16,32,64,88,256,81,320,32,1,89,81,0,342,1,80,321,1,1,1,17,83,9,65,341,81,81,293,68,372,257,340,1,81]

theorem envBound23865 : H12AffineFastState.Bounded env23865 := by
  intro p hp
  have h : env23865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23864_23865 : H12AffineEnvironment.transform 12 89 env23864 = env23865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env23864 == env23865) = true)

def env23866 : List Nat := [2,4,8,16,32,48,40,256,33,304,32,1,41,33,0,294,1,32,305,1,1,1,17,35,9,49,293,33,33,293,52,260,257,292,1,33]

theorem envBound23866 : H12AffineFastState.Bounded env23866 := by
  intro p hp
  have h : env23866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23865_23866 : H12AffineEnvironment.transform 5 48 env23865 = env23866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23865 == env23866) = true)

def env23867 : List Nat := [2,4,8,16,0,16,8,256,1,272,0,1,9,1,0,262,1,0,273,1,1,1,17,3,9,17,261,1,1,261,20,260,257,260,1,1]

theorem envBound23867 : H12AffineFastState.Bounded env23867 := by
  intro p hp
  have h : env23867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23866_23867 : H12AffineEnvironment.transform 4 0 env23866 = env23867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23866 == env23867) = true)

def leafEnv23867 : List Nat := [2,4,8,16,0,16,8,256,1,272,0,1,9,1,0,262,1,0,273,1,1,1,17,3,21,9,1,17,261,1,1,261,20,260,257,260,5,263,1,1,0,1,1]

def active23867 : List Nat := [0,1,2,3,7]

def tree23867 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23867 : H12WitnessSearch.Good tree23867 := H12GlobalWitnessIndex.good

theorem leafIdentity23867 : H12AffineFastState.composeSystem env23867 rootObs = leafEnv23867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23867 rootObs == leafEnv23867) = true)

theorem terminalChecked23867 : H12PackedTerminal.terminalCheckFast leafEnv23867 active23867 tree23867 = true := by decide +kernel

def env23868 : List Nat := [2,4,8,16,1,17,9,256,0,273,1,1,8,0,0,263,1,1,272,1,1,1,17,2,9,16,260,0,0,260,21,260,257,261,1,0]

theorem envBound23868 : H12AffineFastState.Bounded env23868 := by
  intro p hp
  have h : env23868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23866_23868 : H12AffineEnvironment.transform 4 1 env23866 = env23868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23866 == env23868) = true)

theorem identity23868 : scanCanonicalize (H12AffineFastState.compose env23868 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23868 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23869 : List Nat := [2,4,8,16,1,17,9,5,0,20,1,1,8,0,0,2,1,1,21,1,1,1,17,2,9,16,1,0,0,1,21,1,4,0,1,0]

theorem envBound23869 : H12AffineFastState.Bounded env23869 := by
  intro p hp
  have h : env23869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23868_23869 : H12AffineEnvironment.transform 7 5 env23868 = env23869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23868 == env23869) = true)

def leafEnv23869 : List Nat := [2,4,8,16,1,17,9,5,0,20,1,1,8,0,0,2,1,1,21,1,1,1,17,2,20,9,1,16,1,0,0,1,21,1,4,0,5,2,1,0,0,0,1]

def active23869 : List Nat := [0,1,2,3]

def tree23869 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23869 : H12WitnessSearch.Good tree23869 := H12GlobalWitnessIndex.good

theorem leafIdentity23869 : H12AffineFastState.composeSystem env23869 rootObs = leafEnv23869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23869 rootObs == leafEnv23869) = true)

theorem terminalChecked23869 : H12PackedTerminal.terminalCheckFast leafEnv23869 active23869 tree23869 = true := by decide +kernel

def env23870 : List Nat := [2,4,8,16,32,49,41,256,32,305,32,1,40,32,0,295,1,33,304,1,1,1,17,34,9,48,292,32,32,293,53,261,257,293,1,32]

theorem envBound23870 : H12AffineFastState.Bounded env23870 := by
  intro p hp
  have h : env23870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23865_23870 : H12AffineEnvironment.transform 5 49 env23865 = env23870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23865 == env23870) = true)

theorem identity23870 : scanCanonicalize (H12AffineFastState.compose env23870 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23871 : List Nat := [2,4,8,16,32,49,41,5,32,52,32,1,40,32,0,34,1,33,53,1,1,1,17,34,9,48,33,32,32,32,53,0,4,32,1,32]

theorem envBound23871 : H12AffineFastState.Bounded env23871 := by
  intro p hp
  have h : env23871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23870_23871 : H12AffineEnvironment.transform 7 5 env23870 = env23871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23870 == env23871) = true)

theorem identity23871 : scanCanonicalize (H12AffineFastState.compose env23871 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23872 : List Nat := [2,4,8,16,1,16,8,5,1,21,1,1,9,1,0,3,1,0,20,1,1,1,17,3,9,17,0,1,1,1,20,0,4,1,1,1]

theorem envBound23872 : H12AffineFastState.Bounded env23872 := by
  intro p hp
  have h : env23872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23871_23872 : H12AffineEnvironment.transform 4 1 env23871 = env23872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23871 == env23872) = true)

def leafEnv23872 : List Nat := [2,4,8,16,1,16,8,5,1,21,1,1,9,1,0,3,1,0,20,1,1,1,17,3,21,9,1,17,0,1,1,1,20,0,4,1,5,2,1,1,0,1,1]

def active23872 : List Nat := [0,1,2,3]

def tree23872 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23872 : H12WitnessSearch.Good tree23872 := H12GlobalWitnessIndex.good

theorem leafIdentity23872 : H12AffineFastState.composeSystem env23872 rootObs = leafEnv23872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23872 rootObs == leafEnv23872) = true)

theorem terminalChecked23872 : H12PackedTerminal.terminalCheckFast leafEnv23872 active23872 tree23872 = true := by decide +kernel

def env23873 : List Nat := [2,4,8,16,32,64,88,256,81,321,2048,0,8192,80,0,65536,0,80,320,1,0,8280,17,65797,8272,65,8460,80,80,75786,69,65570,257,8461,0,81]

theorem envBound23873 : H12AffineFastState.Bounded env23873 := by
  intro p hp
  have h : env23873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23861_23873 : H12AffineEnvironment.transform 9 321 env23861 = env23873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23861 == env23873) = true)

theorem identity23873 : scanCanonicalize (H12AffineFastState.compose env23873 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound23873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23874 : List Nat := [2,4,8,16,32,64,88,256,81,321,2048,0,89,80,0,65536,0,80,320,1,0,1,17,65797,9,65,341,80,80,67667,69,65570,257,340,0,81]

theorem envBound23874 : H12AffineFastState.Bounded env23874 := by
  intro p hp
  have h : env23874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23873_23874 : H12AffineEnvironment.transform 12 89 env23873 = env23874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env23873 == env23874) = true)

def env23875 : List Nat := [2,4,8,16,32,48,40,256,33,305,2048,0,41,32,0,65536,0,32,304,1,0,1,17,65797,9,49,293,32,32,67619,53,65570,257,292,0,33]

theorem envBound23875 : H12AffineFastState.Bounded env23875 := by
  intro p hp
  have h : env23875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23874_23875 : H12AffineEnvironment.transform 5 48 env23874 = env23875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23874 == env23875) = true)

theorem identity23875 : scanCanonicalize (H12AffineFastState.compose env23875 (packedSelected [9,11] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound23875 : packedSelected [9,11] rootPS < 2^1333 := by decide +kernel

def env23876 : List Nat := [2,4,8,16,32,48,40,256,33,305,2048,0,41,32,0,294,0,32,304,1,0,1,17,35,9,49,293,32,32,2309,53,260,257,292,0,33]

theorem envBound23876 : H12AffineFastState.Bounded env23876 := by
  intro p hp
  have h : env23876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23875_23876 : H12AffineEnvironment.transform 15 294 env23875 = env23876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env23875 == env23876) = true)

theorem identity23876 : scanCanonicalize (H12AffineFastState.compose env23876 (packedSelected [0,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound23876 : packedSelected [0,4,9] rootPS < 2^1333 := by decide +kernel

def env23877 : List Nat := [2,4,8,16,32,48,40,256,33,305,32,0,41,32,0,294,0,32,304,1,0,1,17,35,9,49,293,32,32,293,53,260,257,292,0,33]

theorem envBound23877 : H12AffineFastState.Bounded env23877 := by
  intro p hp
  have h : env23877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23876_23877 : H12AffineEnvironment.transform 10 32 env23876 = env23877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env23876 == env23877) = true)

def env23878 : List Nat := [2,4,8,16,0,16,8,256,1,273,0,0,9,0,0,262,0,0,272,1,0,1,17,3,9,17,261,0,0,261,21,260,257,260,0,1]

theorem envBound23878 : H12AffineFastState.Bounded env23878 := by
  intro p hp
  have h : env23878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23877_23878 : H12AffineEnvironment.transform 4 0 env23877 = env23878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23877 == env23878) = true)

def leafEnv23878 : List Nat := [2,4,8,16,0,16,8,256,1,273,0,0,9,0,0,262,0,0,272,1,0,1,17,3,20,9,1,17,261,0,0,261,21,260,257,260,5,263,0,1,0,0,1]

def active23878 : List Nat := [0,1,2,3,7]

def tree23878 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23878 : H12WitnessSearch.Good tree23878 := H12GlobalWitnessIndex.good

theorem leafIdentity23878 : H12AffineFastState.composeSystem env23878 rootObs = leafEnv23878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23878 rootObs == leafEnv23878) = true)

theorem terminalChecked23878 : H12PackedTerminal.terminalCheckFast leafEnv23878 active23878 tree23878 = true := by decide +kernel

def env23879 : List Nat := [2,4,8,16,1,17,9,256,0,272,1,0,8,1,0,263,0,1,273,1,0,1,17,2,9,16,260,1,1,260,20,260,257,261,0,0]

theorem envBound23879 : H12AffineFastState.Bounded env23879 := by
  intro p hp
  have h : env23879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23877_23879 : H12AffineEnvironment.transform 4 1 env23877 = env23879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23877 == env23879) = true)

theorem identity23879 : scanCanonicalize (H12AffineFastState.compose env23879 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23879 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23880 : List Nat := [2,4,8,16,1,17,9,5,0,21,1,0,8,1,0,2,0,1,20,1,0,1,17,2,9,16,1,1,1,1,20,1,4,0,0,0]

theorem envBound23880 : H12AffineFastState.Bounded env23880 := by
  intro p hp
  have h : env23880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23879_23880 : H12AffineEnvironment.transform 7 5 env23879 = env23880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23879 == env23880) = true)

def leafEnv23880 : List Nat := [2,4,8,16,1,17,9,5,0,21,1,0,8,1,0,2,0,1,20,1,0,1,17,2,21,9,1,16,1,1,1,1,20,1,4,0,5,2,0,0,0,1,1]

def active23880 : List Nat := [0,1,2,3]

def tree23880 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23880 : H12WitnessSearch.Good tree23880 := H12GlobalWitnessIndex.good

theorem leafIdentity23880 : H12AffineFastState.composeSystem env23880 rootObs = leafEnv23880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23880 rootObs == leafEnv23880) = true)

theorem terminalChecked23880 : H12PackedTerminal.terminalCheckFast leafEnv23880 active23880 tree23880 = true := by decide +kernel

def env23881 : List Nat := [2,4,8,16,32,49,41,256,32,304,2048,0,40,33,0,65536,0,33,305,1,0,1,17,65797,9,48,292,33,33,67618,52,65570,257,293,0,32]

theorem envBound23881 : H12AffineFastState.Bounded env23881 := by
  intro p hp
  have h : env23881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23874_23881 : H12AffineEnvironment.transform 5 49 env23874 = env23881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23874 == env23881) = true)

theorem identity23881 : scanCanonicalize (H12AffineFastState.compose env23881 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23882 : List Nat := [2,4,8,16,32,49,41,36,32,20,2048,0,40,33,0,65536,0,33,21,1,0,1,17,65569,9,48,0,33,33,67618,52,65570,37,1,0,32]

theorem envBound23882 : H12AffineFastState.Bounded env23882 := by
  intro p hp
  have h : env23882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23881_23882 : H12AffineEnvironment.transform 7 36 env23881 = env23882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23881 == env23882) = true)

theorem identity23882 : scanCanonicalize (H12AffineFastState.compose env23882 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23882 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23883 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,0,9,0,0,65536,0,0,21,1,0,1,17,65536,9,17,0,0,0,67587,21,65539,4,1,0,1]

theorem envBound23883 : H12AffineFastState.Bounded env23883 := by
  intro p hp
  have h : env23883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23882_23883 : H12AffineEnvironment.transform 4 1 env23882 = env23883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23882 == env23883) = true)

theorem identity23883 : scanCanonicalize (H12AffineFastState.compose env23883 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 2050) := by decide +kernel

theorem selectedBound23883 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23884 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,0,9,0,0,2050,0,0,21,1,0,1,17,2050,9,17,0,0,0,1,21,2049,4,1,0,1]

theorem envBound23884 : H12AffineFastState.Bounded env23884 := by
  intro p hp
  have h : env23884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23883_23884 : H12AffineEnvironment.transform 15 2050 env23883 = env23884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2050 env23883 == env23884) = true)

theorem identity23884 : scanCanonicalize (H12AffineFastState.compose env23884 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23884 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23885 : List Nat := [2,4,8,16,1,16,8,5,1,20,1,0,9,0,0,3,0,0,21,1,0,1,17,3,9,17,0,0,0,1,21,0,4,1,0,1]

theorem envBound23885 : H12AffineFastState.Bounded env23885 := by
  intro p hp
  have h : env23885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23884_23885 : H12AffineEnvironment.transform 10 1 env23884 = env23885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23884 == env23885) = true)

def leafEnv23885 : List Nat := [2,4,8,16,1,16,8,5,1,20,1,0,9,0,0,3,0,0,21,1,0,1,17,3,20,9,1,17,0,0,0,1,21,0,4,1,5,2,0,1,0,0,1]

def active23885 : List Nat := [0,1,2,3]

def tree23885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23885 : H12WitnessSearch.Good tree23885 := H12GlobalWitnessIndex.good

theorem leafIdentity23885 : H12AffineFastState.composeSystem env23885 rootObs = leafEnv23885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23885 rootObs == leafEnv23885) = true)

theorem terminalChecked23885 : H12PackedTerminal.terminalCheckFast leafEnv23885 active23885 tree23885 = true := by decide +kernel

def env23886 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,1,65536,1345,136,1025,0,1345,8321,17,65796,8328,65,8461,1297,1297,75786,1284,65571,257,8460,1345,137]

theorem envBound23886 : H12AffineFastState.Bounded env23886 := by
  intro p hp
  have h : env23886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23859_23886 : H12AffineEnvironment.transform 14 1 env23859 = env23886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23859 == env23886) = true)

theorem identity23886 : scanCanonicalize (H12AffineFastState.compose env23886 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23886 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23887 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,348,1297,1,65536,1345,136,1025,0,1345,477,17,65796,468,65,81,1297,1297,67926,1284,65571,257,80,1345,137]

theorem envBound23887 : H12AffineFastState.Bounded env23887 := by
  intro p hp
  have h : env23887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23886_23887 : H12AffineEnvironment.transform 12 348 env23886 = env23887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23886 == env23887) = true)

theorem identity23887 : scanCanonicalize (H12AffineFastState.compose env23887 (packedSelected [1,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23887 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env23888 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,8,1093,1,65536,1045,136,1025,0,1045,137,17,65616,128,65,81,1093,1093,67586,1104,65571,85,80,1045,137]

theorem envBound23888 : H12AffineFastState.Bounded env23888 := by
  intro p hp
  have h : env23888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23887_23888 : H12AffineEnvironment.transform 7 84 env23887 = env23888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23887 == env23888) = true)

theorem identity23888 : scanCanonicalize (H12AffineFastState.compose env23888 (packedSelected [1,2,3,4,8,9,23] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound23888 : packedSelected [1,2,3,4,8,9,23] rootPS < 2^1333 := by decide +kernel

def env23889 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,8,1093,1,115,1045,136,1025,0,1045,137,17,35,128,65,81,1093,1093,2161,1104,80,85,80,1045,137]

theorem envBound23889 : H12AffineFastState.Bounded env23889 := by
  intro p hp
  have h : env23889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23888_23889 : H12AffineEnvironment.transform 15 115 env23888 = env23889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env23888 == env23889) = true)

theorem identity23889 : scanCanonicalize (H12AffineFastState.compose env23889 (packedSelected [0,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23889 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env23890 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8,1045,1,35,1045,136,1025,0,1045,137,17,35,128,17,1,1045,1045,2081,1024,0,5,0,1045,137]

theorem envBound23890 : H12AffineFastState.Bounded env23890 := by
  intro p hp
  have h : env23890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23889_23890 : H12AffineEnvironment.transform 5 16 env23889 = env23890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23889 == env23890) = true)

def env23891 : List Nat := [2,4,8,16,32,16,128,4,137,1024,0,1045,8,1045,1,35,1045,136,1025,0,1045,137,17,35,128,17,1,1045,1045,33,1024,0,5,0,1045,137]

theorem envBound23891 : H12AffineFastState.Bounded env23891 := by
  intro p hp
  have h : env23891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23890_23891 : H12AffineEnvironment.transform 10 0 env23890 = env23891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23890 == env23891) = true)

theorem identity23891 : scanCanonicalize (H12AffineFastState.compose env23891 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23891 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23892 : List Nat := [2,4,8,16,32,16,40,4,33,1024,0,1045,8,1045,1,35,1045,32,1025,0,1045,33,17,35,40,17,1,1045,1045,33,1024,0,5,0,1045,33]

theorem envBound23892 : H12AffineFastState.Bounded env23892 := by
  intro p hp
  have h : env23892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23891_23892 : H12AffineEnvironment.transform 6 40 env23891 = env23892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23891 == env23892) = true)

def leafEnv23892 : List Nat := [2,4,8,16,32,16,40,4,33,1024,0,1045,8,1045,1,35,1045,32,1025,0,1045,33,17,35,1025,40,1,17,1,1045,1045,33,1024,0,5,0,5,2,1045,33,0,1045,1]

def active23892 : List Nat := [0,1,2,3,4,9]

def tree23892 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23892 : H12WitnessSearch.Good tree23892 := H12GlobalWitnessIndex.good

theorem leafIdentity23892 : H12AffineFastState.composeSystem env23892 rootObs = leafEnv23892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23892 rootObs == leafEnv23892) = true)

theorem terminalChecked23892 : H12PackedTerminal.terminalCheckFast leafEnv23892 active23892 tree23892 = true := by decide +kernel

def env23893 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1,1045,8,1045,1,35,1045,136,1025,0,1045,137,17,35,128,17,1,1045,1045,32,1024,0,5,0,1045,137]

theorem envBound23893 : H12AffineFastState.Bounded env23893 := by
  intro p hp
  have h : env23893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23890_23893 : H12AffineEnvironment.transform 10 1 env23890 = env23893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23890 == env23893) = true)

theorem identity23893 : scanCanonicalize (H12AffineFastState.compose env23893 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23894 : List Nat := [2,4,8,16,0,16,128,4,137,1024,1,1045,8,1045,1,3,1045,136,1025,0,1045,137,17,3,128,17,1,1045,1045,0,1024,0,5,0,1045,137]

theorem envBound23894 : H12AffineFastState.Bounded env23894 := by
  intro p hp
  have h : env23894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23893_23894 : H12AffineEnvironment.transform 4 0 env23893 = env23894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23893 == env23894) = true)

theorem identity23894 : scanCanonicalize (H12AffineFastState.compose env23894 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound23894 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23895 : List Nat := [2,4,8,16,0,16,128,4,137,21,1,0,8,0,1,3,0,136,20,0,0,137,17,3,128,17,1,0,0,0,21,0,5,0,0,137]

theorem envBound23895 : H12AffineFastState.Bounded env23895 := by
  intro p hp
  have h : env23895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23894_23895 : H12AffineEnvironment.transform 9 21 env23894 = env23895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23894 == env23895) = true)

theorem identity23895 : scanCanonicalize (H12AffineFastState.compose env23895 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23895 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23896 : List Nat := [2,4,8,16,0,16,8,4,1,21,1,0,8,0,1,3,0,0,20,0,0,1,17,3,8,17,1,0,0,0,21,0,5,0,0,1]

theorem envBound23896 : H12AffineFastState.Bounded env23896 := by
  intro p hp
  have h : env23896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23895_23896 : H12AffineEnvironment.transform 6 8 env23895 = env23896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23895 == env23896) = true)

def env23897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,164610304,512]

theorem envBound23897 : H12AffineFastState.Bounded env23897 := by
  intro p hp
  have h : env23897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23387_23897 : H12AffineEnvironment.transform 20 4097 env23387 = env23897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env23387 == env23897) = true)

theorem identity23897 : scanCanonicalize (H12AffineFastState.compose env23897 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 21352528) := by decide +kernel

theorem selectedBound23897 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env23898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,21352528,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,9048400,512]

theorem envBound23898 : H12AffineFastState.Bounded env23898 := by
  intro p hp
  have h : env23898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23897_23898 : H12AffineEnvironment.transform 26 21352528 env23897 = env23898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21352528 env23897 == env23898) = true)

def env23899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,672832,16777216,8328,147473,21352528,541697,676864,1073741824,17399809,4294967296,525569,4315938986,21776,512]

theorem envBound23899 : H12AffineFastState.Bounded env23899 := by
  intro p hp
  have h : env23899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23898_23899 : H12AffineEnvironment.transform 22 672832 env23898 = env23899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672832 env23898 == env23899) = true)

theorem identity23899 : scanCanonicalize (H12AffineFastState.compose env23899 (packedSelected [4,9,16] rootPS)) = affineNative (2^(23+1) ^^^ 623877) := by decide +kernel

theorem selectedBound23899 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env23900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,672832,623877,8328,147473,5002581,541697,676864,1073741824,1284,4294967296,525569,4299785647,21776,512]

theorem envBound23900 : H12AffineFastState.Bounded env23900 := by
  intro p hp
  have h : env23900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23899_23900 : H12AffineEnvironment.transform 23 623877 env23899 = env23900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623877 env23899 == env23900) = true)

theorem identity23900 : scanCanonicalize (H12AffineFastState.compose env23900 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 4315355) := by decide +kernel

theorem selectedBound23900 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,672832,623877,8328,147473,5002581,541697,676864,4315355,1284,4294967296,525569,4299785647,21776,512]

theorem envBound23901 : H12AffineFastState.Bounded env23901 := by
  intro p hp
  have h : env23901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23900_23901 : H12AffineEnvironment.transform 29 4315355 env23900 = env23901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4315355 env23900 == env23901) = true)

theorem identity23901 : scanCanonicalize (H12AffineFastState.compose env23901 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound23901 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env23902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32769,4097,4194304,660496,623877,8328,135233,4982021,529489,656464,4294795,1284,4294967296,525569,4299785647,1344,512]

theorem envBound23902 : H12AffineFastState.Bounded env23902 := by
  intro p hp
  have h : env23902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23901_23902 : H12AffineEnvironment.transform 13 4176 env23901 = env23902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env23901 == env23902) = true)

theorem identity23902 : scanCanonicalize (H12AffineFastState.compose env23902 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 42884) := by decide +kernel

theorem selectedBound23902 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,42884,32769,4097,4194304,177044,74369,8328,135233,4498049,46037,173012,4294795,1284,4294967296,41605,4299235883,1344,512]

theorem envBound23903 : H12AffineFastState.Bounded env23903 := by
  intro p hp
  have h : env23903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23902_23903 : H12AffineEnvironment.transform 18 42884 env23902 = env23903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42884 env23902 == env23903) = true)

def env23904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,672833,16777216,8328,147472,21352528,541696,676864,1073741824,17399808,4294967296,525568,4315938986,21777,512]

theorem envBound23904 : H12AffineFastState.Bounded env23904 := by
  intro p hp
  have h : env23904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23898_23904 : H12AffineEnvironment.transform 22 672833 env23898 = env23904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672833 env23898 == env23904) = true)

def env23905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4097,4194304,147521,16777216,8328,147472,21352528,16384,151552,1073741824,16876544,4294967296,256,4315938986,21777,512]

theorem envBound23905 : H12AffineFastState.Bounded env23905 := by
  intro p hp
  have h : env23905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23904_23905 : H12AffineEnvironment.transform 18 1024 env23904 = env23905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23904 == env23905) = true)

def env23906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4097,4194304,17665,16777216,8328,17744,21352528,16384,21824,1073741824,16876544,4294967296,256,4315938986,21777,512]

theorem envBound23906 : H12AffineFastState.Bounded env23906 := by
  intro p hp
  have h : env23906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23905_23906 : H12AffineEnvironment.transform 16 1344 env23905 = env23906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23905 == env23906) = true)

theorem identity23906 : scanCanonicalize (H12AffineFastState.compose env23906 (packedSelected [7,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound23906 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env23907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4097,4194304,5457,16777216,8328,5376,21331968,4176,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23907 : H12AffineFastState.Bounded env23907 := by
  intro p hp
  have h : env23907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23906_23907 : H12AffineEnvironment.transform 13 4176 env23906 = env23907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env23906 == env23907) = true)

def env23908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,17,16777216,8328,64,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23908 : H12AffineFastState.Bounded env23908 := by
  intro p hp
  have h : env23908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23907_23908 : H12AffineEnvironment.transform 11 1344 env23907 = env23908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23907 == env23908) = true)

theorem identity23908 : scanCanonicalize (H12AffineFastState.compose env23908 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23908 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23909 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound23909 : H12AffineFastState.Bounded env23909 := by
  intro p hp
  have h : env23909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23908_23909 : H12AffineEnvironment.transform 5 17 env23908 = env23909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23908 == env23909) = true)

theorem identity23909 : scanCanonicalize (H12AffineFastState.compose env23909 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound23909 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23910 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8328,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23910 : H12AffineFastState.Bounded env23910 := by
  intro p hp
  have h : env23910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23909_23910 : H12AffineEnvironment.transform 31 1073842178 env23909 = env23910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env23909 == env23910) = true)

def env23911 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23911 : H12AffineFastState.Bounded env23911 := by
  intro p hp
  have h : env23911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23910_23911 : H12AffineEnvironment.transform 12 128 env23910 = env23911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env23910 == env23911) = true)

theorem identity23911 : scanCanonicalize (H12AffineFastState.compose env23911 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 98944) := by decide +kernel

theorem selectedBound23911 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23912 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,98944,17,16777216,8,17,17040000,1296,1296,1073741824,16876544,1073842178,256,1090521640,1296,512]

theorem envBound23912 : H12AffineFastState.Bounded env23912 := by
  intro p hp
  have h : env23912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23911_23912 : H12AffineEnvironment.transform 21 98944 env23911 = env23912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98944 env23911 == env23912) = true)

def env23913 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,98944,17,16777216,8,17,17040000,1296,1296,16779904,16876544,16876162,256,168,1296,512]

theorem envBound23913 : H12AffineFastState.Bounded env23913 := by
  intro p hp
  have h : env23913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23912_23913 : H12AffineEnvironment.transform 29 16779904 env23912 = env23913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16779904 env23912 == env23913) = true)

theorem identity23913 : scanCanonicalize (H12AffineFastState.compose env23913 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 674) := by decide +kernel

theorem selectedBound23913 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23914 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,674,65536,1297,262144,1024,675,1296,65570,17,16777216,8,17,17040000,1296,1296,16779904,16844450,16842784,256,168,1296,512]

theorem envBound23914 : H12AffineFastState.Bounded env23914 := by
  intro p hp
  have h : env23914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23913_23914 : H12AffineEnvironment.transform 14 674 env23913 = env23914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 674 env23913 == env23914) = true)

theorem identity23914 : scanCanonicalize (H12AffineFastState.compose env23914 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 330157) := by decide +kernel

theorem selectedBound23914 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23915 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,674,65536,1297,262144,1024,675,1296,65570,17,330157,8,17,68397,1296,1296,328493,265999,264589,256,168,1296,512]

theorem envBound23915 : H12AffineFastState.Bounded env23915 := by
  intro p hp
  have h : env23915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23914_23915 : H12AffineEnvironment.transform 23 330157 env23914 = env23915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 330157 env23914 == env23915) = true)

theorem identity23915 : scanCanonicalize (H12AffineFastState.compose env23915 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 2571) := by decide +kernel

theorem selectedBound23915 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env23916 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,674,65536,1297,2571,1024,675,1296,65570,17,66470,8,17,68397,1296,1296,67878,1284,902,256,168,1296,512]

theorem envBound23916 : H12AffineFastState.Bounded env23916 := by
  intro p hp
  have h : env23916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23915_23916 : H12AffineEnvironment.transform 17 2571 env23915 = env23916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2571 env23915 == env23916) = true)

theorem identity23916 : scanCanonicalize (H12AffineFastState.compose env23916 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23916 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23917 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,128,1296,162,65536,1297,2059,1024,163,1296,65570,17,65958,8,17,67885,1296,1296,67878,1284,390,256,168,1296,0]

theorem envBound23917 : H12AffineFastState.Bounded env23917 := by
  intro p hp
  have h : env23917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23916_23917 : H12AffineEnvironment.transform 8 0 env23916 = env23917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23916 == env23917) = true)

def env23918 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,98944,17,16777216,8,17,17040000,1296,1296,16779905,16876544,16876163,256,169,1296,512]

theorem envBound23918 : H12AffineFastState.Bounded env23918 := by
  intro p hp
  have h : env23918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23912_23918 : H12AffineEnvironment.transform 29 16779905 env23912 = env23918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16779905 env23912 == env23918) = true)

theorem identity23918 : scanCanonicalize (H12AffineFastState.compose env23918 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 1971) := by decide +kernel

theorem selectedBound23918 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23919 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,1971,65536,1297,262144,1024,1970,1296,66867,17,16777216,8,17,17040000,1296,1296,16779905,16843699,16844080,256,169,1296,512]

theorem envBound23919 : H12AffineFastState.Bounded env23919 := by
  intro p hp
  have h : env23919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23918_23919 : H12AffineEnvironment.transform 14 1971 env23918 = env23919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1971 env23918 == env23919) = true)

theorem identity23919 : scanCanonicalize (H12AffineFastState.compose env23919 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 812) := by decide +kernel

theorem selectedBound23919 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23920 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,1971,812,1297,262144,1024,1970,1296,1567,17,16777216,8,17,17040000,1296,1296,16779905,16777375,16778780,256,169,1296,512]

theorem envBound23920 : H12AffineFastState.Bounded env23920 := by
  intro p hp
  have h : env23920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23919_23920 : H12AffineEnvironment.transform 15 812 env23919 = env23920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 812 env23919 == env23920) = true)

theorem identity23920 : scanCanonicalize (H12AffineFastState.compose env23920 (packedSelected [1,3,8] rootPS)) = affineNative (2^(23+1) ^^^ 1435) := by decide +kernel

theorem selectedBound23920 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23921 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,1971,812,1297,262144,1024,1970,1296,1567,17,1435,8,17,263963,1296,1296,3866,1284,903,256,169,1296,512]

theorem envBound23921 : H12AffineFastState.Bounded env23921 := by
  intro p hp
  have h : env23921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23920_23921 : H12AffineEnvironment.transform 23 1435 env23920 = env23921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 1435 env23920 == env23921) = true)

theorem identity23921 : scanCanonicalize (H12AffineFastState.compose env23921 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23921 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23922 : List Nat := [2,4,8,16,32,17,128,256,1,1024,2048,1297,128,1296,1458,301,1297,262144,1024,1459,1296,1054,17,1435,8,17,263450,1296,1296,3355,1284,390,256,169,1296,1]

theorem envBound23922 : H12AffineFastState.Bounded env23922 := by
  intro p hp
  have h : env23922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23921_23922 : H12AffineEnvironment.transform 8 1 env23921 = env23922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23921 == env23922) = true)

theorem identity23922 : scanCanonicalize (H12AffineFastState.compose env23922 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23922 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env23923 : List Nat := [2,4,8,16,32,17,128,256,1,272,2048,1,128,0,162,301,1,262144,272,163,0,270,17,139,8,17,262154,0,0,2059,20,390,256,169,0,1]

theorem envBound23923 : H12AffineFastState.Bounded env23923 := by
  intro p hp
  have h : env23923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23922_23923 : H12AffineEnvironment.transform 9 272 env23922 = env23923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23922 == env23923) = true)

theorem identity23923 : scanCanonicalize (H12AffineFastState.compose env23923 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23924 : List Nat := [2,4,3,16,32,17,128,256,1,272,2048,1,128,0,162,294,1,262144,272,163,0,261,17,128,3,17,262145,0,0,2048,20,390,256,162,0,1]

theorem envBound23924 : H12AffineFastState.Bounded env23924 := by
  intro p hp
  have h : env23924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23923_23924 : H12AffineEnvironment.transform 2 3 env23923 = env23924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23923 == env23924) = true)

theorem identity23924 : scanCanonicalize (H12AffineFastState.compose env23924 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound23924 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23925 : List Nat := [2,4,3,16,32,17,128,256,1,272,130,1,128,0,162,294,1,262144,272,163,0,261,17,128,3,17,262145,0,0,130,20,390,256,162,0,1]

theorem envBound23925 : H12AffineFastState.Bounded env23925 := by
  intro p hp
  have h : env23925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23924_23925 : H12AffineEnvironment.transform 10 130 env23924 = env23925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env23924 == env23925) = true)

theorem identity23925 : scanCanonicalize (H12AffineFastState.compose env23925 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound23925 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23926 : List Nat := [2,4,3,16,32,17,3,256,1,272,1,1,3,0,33,294,1,262144,272,32,0,261,17,3,3,17,262145,0,0,1,20,261,256,33,0,1]

theorem envBound23926 : H12AffineFastState.Bounded env23926 := by
  intro p hp
  have h : env23926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23925_23926 : H12AffineEnvironment.transform 6 3 env23925 = env23926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env23925 == env23926) = true)

theorem identity23926 : scanCanonicalize (H12AffineFastState.compose env23926 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23927 : List Nat := [2,4,3,16,16,17,3,256,1,272,1,1,3,0,17,278,1,262144,272,16,0,261,17,3,3,17,262145,0,0,1,20,261,256,17,0,1]

theorem envBound23927 : H12AffineFastState.Bounded env23927 := by
  intro p hp
  have h : env23927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23926_23927 : H12AffineEnvironment.transform 4 16 env23926 = env23927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23926 == env23927) = true)

def env23928 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,9,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23928 : H12AffineFastState.Bounded env23928 := by
  intro p hp
  have h : env23928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23910_23928 : H12AffineEnvironment.transform 12 129 env23910 = env23928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env23910 == env23928) = true)

theorem identity23928 : scanCanonicalize (H12AffineFastState.compose env23928 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4195205) := by decide +kernel

theorem selectedBound23928 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23929 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,17,4195205,9,17,361349,1296,1296,1073741824,4294533,1073842178,256,1073842989,1296,512]

theorem envBound23929 : H12AffineFastState.Bounded env23929 := by
  intro p hp
  have h : env23929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23928_23929 : H12AffineEnvironment.transform 23 4195205 env23928 = env23929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195205 env23928 == env23929) = true)

def env23930 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,4194304,17,4195205,9,17,361349,0,0,1073741824,4293269,1073842178,256,1073842989,0,512]

theorem envBound23930 : H12AffineFastState.Bounded env23930 := by
  intro p hp
  have h : env23930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23929_23930 : H12AffineEnvironment.transform 9 272 env23929 = env23930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23929 == env23930) = true)

theorem identity23930 : scanCanonicalize (H12AffineFastState.compose env23930 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 4230054) := by decide +kernel

theorem selectedBound23930 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23931 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,4194304,17,4195205,9,17,361349,0,0,4230054,4293269,4260772,256,4259979,0,512]

theorem envBound23931 : H12AffineFastState.Bounded env23931 := by
  intro p hp
  have h : env23931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23930_23931 : H12AffineEnvironment.transform 29 4230054 env23930 = env23931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4230054 env23930 == env23931) = true)

def env23932 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,98944,17,98565,9,17,361349,0,0,67878,21,33060,256,33291,0,512]

theorem envBound23932 : H12AffineFastState.Bounded env23932 := by
  intro p hp
  have h : env23932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23931_23932 : H12AffineEnvironment.transform 21 98944 env23931 = env23932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98944 env23931 == env23932) = true)

theorem identity23932 : scanCanonicalize (H12AffineFastState.compose env23932 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound23932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23933 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,648,65536,1,262144,272,649,0,65544,17,66445,9,17,327949,0,0,67878,21,940,256,131,0,512]

theorem envBound23933 : H12AffineFastState.Bounded env23933 := by
  intro p hp
  have h : env23933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23932_23933 : H12AffineEnvironment.transform 14 648 env23932 = env23933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env23932 == env23933) = true)

theorem identity23933 : scanCanonicalize (H12AffineFastState.compose env23933 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 651) := by decide +kernel

theorem selectedBound23933 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23934 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,648,651,1,262144,272,649,0,643,17,262,9,17,263046,0,0,2989,21,940,256,131,0,512]

theorem envBound23934 : H12AffineFastState.Bounded env23934 := by
  intro p hp
  have h : env23934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23933_23934 : H12AffineEnvironment.transform 15 651 env23933 = env23934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 651 env23933 == env23934) = true)

theorem identity23934 : scanCanonicalize (H12AffineFastState.compose env23934 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23934 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23935 : List Nat := [2,4,8,16,32,17,128,141,512,157,2048,1,129,0,648,651,1,262144,157,649,0,643,17,139,9,17,262667,0,0,2592,21,545,141,131,0,512]

theorem envBound23935 : H12AffineFastState.Bounded env23935 := by
  intro p hp
  have h : env23935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23934_23935 : H12AffineEnvironment.transform 7 141 env23934 = env23935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23934 == env23935) = true)

theorem identity23935 : scanCanonicalize (H12AffineFastState.compose env23935 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound23935 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23936 : List Nat := [2,4,8,16,32,17,128,141,162,157,2048,1,129,0,42,41,1,262144,157,43,0,33,17,139,9,17,262313,0,0,2178,21,131,141,131,0,162]

theorem envBound23936 : H12AffineFastState.Bounded env23936 := by
  intro p hp
  have h : env23936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23935_23936 : H12AffineEnvironment.transform 8 162 env23935 = env23936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env23935 == env23936) = true)

theorem identity23936 : scanCanonicalize (H12AffineFastState.compose env23936 (packedSelected [0,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 2216) := by decide +kernel

theorem selectedBound23936 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env23937 : List Nat := [2,4,8,16,32,17,128,141,162,157,2048,1,129,0,42,41,1,2216,157,43,0,33,17,139,9,17,2049,0,0,2178,21,131,141,131,0,162]

theorem envBound23937 : H12AffineFastState.Bounded env23937 := by
  intro p hp
  have h : env23937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23936_23937 : H12AffineEnvironment.transform 17 2216 env23936 = env23937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2216 env23936 == env23937) = true)

theorem identity23937 : scanCanonicalize (H12AffineFastState.compose env23937 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23937 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env23938 : List Nat := [2,4,8,16,32,17,24,21,58,5,2048,1,25,0,42,41,1,2096,5,43,0,33,17,19,9,17,2049,0,0,2074,21,27,21,27,0,58]

theorem envBound23938 : H12AffineFastState.Bounded env23938 := by
  intro p hp
  have h : env23938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23937_23938 : H12AffineEnvironment.transform 6 24 env23937 = env23938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23937 == env23938) = true)

theorem identity23938 : scanCanonicalize (H12AffineFastState.compose env23938 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound23938 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env23939 : List Nat := [2,4,8,16,11,17,24,21,17,5,2048,1,25,0,1,2,1,2075,5,0,0,10,17,19,9,17,2049,0,0,2074,21,27,21,27,0,17]

theorem envBound23939 : H12AffineFastState.Bounded env23939 := by
  intro p hp
  have h : env23939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23938_23939 : H12AffineEnvironment.transform 4 11 env23938 = env23939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env23938 == env23939) = true)

def env23940 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,98945,17,98564,9,17,361349,0,0,67879,20,33061,256,33290,0,512]

theorem envBound23940 : H12AffineFastState.Bounded env23940 := by
  intro p hp
  have h : env23940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23931_23940 : H12AffineEnvironment.transform 21 98945 env23931 = env23940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98945 env23931 == env23940) = true)

theorem identity23940 : scanCanonicalize (H12AffineFastState.compose env23940 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33157) := by decide +kernel

theorem selectedBound23940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23941 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,32768,33157,1,262144,272,32769,0,772,17,129,9,17,262656,0,0,34978,20,33061,256,33290,0,512]

theorem envBound23941 : H12AffineFastState.Bounded env23941 := by
  intro p hp
  have h : env23941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23940_23941 : H12AffineEnvironment.transform 15 33157 env23940 = env23941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33157 env23940 == env23941) = true)

theorem identity23941 : scanCanonicalize (H12AffineFastState.compose env23941 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 162) := by decide +kernel

theorem selectedBound23941 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23942 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,0,162,295,1,262144,272,163,0,772,17,129,9,17,262656,0,0,2048,20,391,256,680,0,512]

theorem envBound23942 : H12AffineFastState.Bounded env23942 := by
  intro p hp
  have h : env23942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23941_23942 : H12AffineEnvironment.transform 14 162 env23941 = env23942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 162 env23941 == env23942) = true)

theorem identity23942 : scanCanonicalize (H12AffineFastState.compose env23942 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23942 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23943 : List Nat := [2,4,8,16,32,17,128,256,1,272,2048,1,129,0,162,295,1,262144,272,163,0,261,17,129,9,17,262145,0,0,2048,20,391,256,169,0,1]

theorem envBound23943 : H12AffineFastState.Bounded env23943 := by
  intro p hp
  have h : env23943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23942_23943 : H12AffineEnvironment.transform 8 1 env23942 = env23943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23942 == env23943) = true)

theorem identity23943 : scanCanonicalize (H12AffineFastState.compose env23943 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound23943 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23944 : List Nat := [2,4,8,16,32,17,128,256,1,272,137,1,129,0,162,295,1,262144,272,163,0,261,17,129,9,17,262145,0,0,137,20,391,256,169,0,1]

theorem envBound23944 : H12AffineFastState.Bounded env23944 := by
  intro p hp
  have h : env23944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23943_23944 : H12AffineEnvironment.transform 10 137 env23943 = env23944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env23943 == env23944) = true)

theorem identity23944 : scanCanonicalize (H12AffineFastState.compose env23944 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound23944 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23945 : List Nat := [2,4,8,16,32,17,3,256,1,272,10,1,2,0,33,295,1,262144,272,32,0,261,17,2,9,17,262145,0,0,10,20,260,256,42,0,1]

theorem envBound23945 : H12AffineFastState.Bounded env23945 := by
  intro p hp
  have h : env23945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23944_23945 : H12AffineEnvironment.transform 6 3 env23944 = env23945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env23944 == env23945) = true)

theorem identity23945 : scanCanonicalize (H12AffineFastState.compose env23945 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound23945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23946 : List Nat := [2,4,8,16,32,17,3,31,1,15,10,1,2,0,33,56,1,262144,15,32,0,26,17,2,9,17,262145,0,0,10,20,27,31,42,0,1]

theorem envBound23946 : H12AffineFastState.Bounded env23946 := by
  intro p hp
  have h : env23946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23945_23946 : H12AffineEnvironment.transform 7 31 env23945 = env23946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env23945 == env23946) = true)

theorem identity23946 : scanCanonicalize (H12AffineFastState.compose env23946 (packedSelected [4,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23946 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23947 : List Nat := [2,4,2,16,32,17,3,21,1,5,0,1,2,0,33,50,1,262144,5,32,0,16,17,2,3,17,262145,0,0,0,20,17,21,32,0,1]

theorem envBound23947 : H12AffineFastState.Bounded env23947 := by
  intro p hp
  have h : env23947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23946_23947 : H12AffineEnvironment.transform 2 2 env23946 = env23947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23946 == env23947) = true)

def env23948 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,262144,273,32769,1,4194304,17,4195205,9,17,361349,1,1,1073741824,4293268,1073842178,256,1073842989,1,512]

theorem envBound23948 : H12AffineFastState.Bounded env23948 := by
  intro p hp
  have h : env23948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23929_23948 : H12AffineEnvironment.transform 9 273 env23929 = env23948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23929 == env23948) = true)

theorem identity23948 : scanCanonicalize (H12AffineFastState.compose env23948 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 65571) := by decide +kernel

theorem selectedBound23948 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23949 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,262144,273,32769,1,65571,17,66470,9,17,361349,1,1,1073741824,33463,1073842178,256,1073842989,1,512]

theorem envBound23949 : H12AffineFastState.Bounded env23949 := by
  intro p hp
  have h : env23949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23948_23949 : H12AffineEnvironment.transform 21 65571 env23948 = env23949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65571 env23948 == env23949) = true)

def env23950 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,262144,273,32769,1,65571,17,66470,9,17,361349,1,1,34952,33463,65674,256,66469,1,512]

theorem envBound23950 : H12AffineFastState.Bounded env23950 := by
  intro p hp
  have h : env23950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23949_23950 : H12AffineEnvironment.transform 29 34952 env23949 = env23950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34952 env23949 == env23950) = true)

theorem identity23950 : scanCanonicalize (H12AffineFastState.compose env23950 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound23950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23951 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,2561,273,32769,1,65571,17,66470,9,17,100740,1,1,34952,33463,65674,256,66469,1,512]

theorem envBound23951 : H12AffineFastState.Bounded env23951 := by
  intro p hp
  have h : env23951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23950_23951 : H12AffineEnvironment.transform 17 2561 env23950 = env23951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env23950 == env23951) = true)

def env23952 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,0,65536,0,2561,273,1,1,65571,17,66470,9,17,67972,1,1,2184,695,65674,256,66469,1,512]

theorem envBound23952 : H12AffineFastState.Bounded env23952 := by
  intro p hp
  have h : env23952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23951_23952 : H12AffineEnvironment.transform 14 0 env23951 = env23952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23951 == env23952) = true)

theorem identity23952 : scanCanonicalize (H12AffineFastState.compose env23952 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound23952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23953 : List Nat := [2,4,8,16,32,17,50,256,512,273,2048,0,51,1,0,65536,0,2561,273,1,1,65571,17,66324,9,17,67894,1,1,2106,517,65592,256,66327,1,512]

theorem envBound23953 : H12AffineFastState.Bounded env23953 := by
  intro p hp
  have h : env23953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23952_23953 : H12AffineEnvironment.transform 6 50 env23952 = env23953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env23952 == env23953) = true)

theorem identity23953 : scanCanonicalize (H12AffineFastState.compose env23953 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23953 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env23954 : List Nat := [2,4,8,16,1,17,19,256,512,273,2048,0,18,1,0,65536,0,2561,273,1,1,65538,17,66324,9,17,67863,1,1,2075,517,65561,256,66327,1,512]

theorem envBound23954 : H12AffineFastState.Bounded env23954 := by
  intro p hp
  have h : env23954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23953_23954 : H12AffineEnvironment.transform 4 1 env23953 = env23954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23953 == env23954) = true)

def env23955 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,1,65536,0,2561,273,0,1,65571,17,66470,9,17,67973,1,1,2185,694,65674,256,66469,1,512]

theorem envBound23955 : H12AffineFastState.Bounded env23955 := by
  intro p hp
  have h : env23955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23951_23955 : H12AffineEnvironment.transform 14 1 env23951 = env23955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23951 == env23955) = true)

theorem identity23955 : scanCanonicalize (H12AffineFastState.compose env23955 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 176) := by decide +kernel

theorem selectedBound23955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23956 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,1,176,0,2561,273,0,1,147,17,790,9,17,2357,1,1,2185,694,58,256,789,1,512]

theorem envBound23956 : H12AffineFastState.Bounded env23956 := by
  intro p hp
  have h : env23956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23955_23956 : H12AffineEnvironment.transform 15 176 env23955 = env23956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 176 env23955 == env23956) = true)

theorem identity23956 : scanCanonicalize (H12AffineFastState.compose env23956 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound23956 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env23957 : List Nat := [2,4,8,16,32,17,128,256,130,273,2048,0,129,1,1,176,0,2179,273,0,1,147,17,404,9,17,2357,1,1,2185,52,58,256,407,1,130]

theorem envBound23957 : H12AffineFastState.Bounded env23957 := by
  intro p hp
  have h : env23957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23956_23957 : H12AffineEnvironment.transform 8 130 env23956 = env23957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env23956 == env23957) = true)

theorem identity23957 : scanCanonicalize (H12AffineFastState.compose env23957 (packedSelected [3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23957 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env23958 : List Nat := [2,4,8,16,0,17,128,256,130,273,2048,0,129,1,1,144,0,2179,273,0,1,147,17,404,9,17,2325,1,1,2185,20,26,256,407,1,130]

theorem envBound23958 : H12AffineFastState.Bounded env23958 := by
  intro p hp
  have h : env23958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23957_23958 : H12AffineEnvironment.transform 4 0 env23957 = env23958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23957 == env23958) = true)

theorem identity23958 : scanCanonicalize (H12AffineFastState.compose env23958 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound23958 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23959 : List Nat := [2,4,8,16,0,17,128,134,130,151,2048,0,129,1,1,144,0,2179,151,0,1,147,17,18,9,17,2195,1,1,2185,20,26,134,17,1,130]

theorem envBound23959 : H12AffineFastState.Bounded env23959 := by
  intro p hp
  have h : env23959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23958_23959 : H12AffineEnvironment.transform 7 134 env23958 = env23959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env23958 == env23959) = true)

def env23960 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,262144,273,32769,1,65571,17,66470,9,17,361349,1,1,34953,33463,65675,256,66468,1,512]

theorem envBound23960 : H12AffineFastState.Bounded env23960 := by
  intro p hp
  have h : env23960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23949_23960 : H12AffineEnvironment.transform 29 34953 env23949 = env23960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34953 env23949 == env23960) = true)

theorem identity23960 : scanCanonicalize (H12AffineFastState.compose env23960 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 34979) := by decide +kernel

theorem selectedBound23960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23961 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,32768,65536,0,34979,273,32769,1,65571,17,66470,9,17,68390,1,1,34953,33463,65675,256,66468,1,512]

theorem envBound23961 : H12AffineFastState.Bounded env23961 := by
  intro p hp
  have h : env23961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23960_23961 : H12AffineEnvironment.transform 17 34979 env23960 = env23961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34979 env23960 == env23961) = true)

def env23962 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,0,65536,0,2211,273,1,1,65571,17,66470,9,17,68390,1,1,2185,695,65675,256,66468,1,512]

theorem envBound23962 : H12AffineFastState.Bounded env23962 := by
  intro p hp
  have h : env23962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23961_23962 : H12AffineEnvironment.transform 14 0 env23961 = env23962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23961 == env23962) = true)

theorem identity23962 : scanCanonicalize (H12AffineFastState.compose env23962 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound23962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23963 : List Nat := [2,4,8,16,32,17,128,256,413,273,2048,0,129,1,0,65536,0,2211,273,1,1,65571,17,65595,9,17,67771,1,1,2185,298,65675,256,65593,1,413]

theorem envBound23963 : H12AffineFastState.Bounded env23963 := by
  intro p hp
  have h : env23963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23962_23963 : H12AffineEnvironment.transform 8 413 env23962 = env23963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env23962 == env23963) = true)

theorem identity23963 : scanCanonicalize (H12AffineFastState.compose env23963 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound23963 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env23964 : List Nat := [2,4,8,16,32,17,128,30,131,15,2048,0,129,1,0,65536,0,2211,15,1,1,65571,17,65595,9,17,67771,1,1,2185,52,65675,30,65593,1,131]

theorem envBound23964 : H12AffineFastState.Bounded env23964 := by
  intro p hp
  have h : env23964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23963_23964 : H12AffineEnvironment.transform 7 30 env23963 = env23964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env23963 == env23964) = true)

def env23965 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,1,65536,0,2210,273,0,1,65571,17,66470,9,17,68390,1,1,2184,694,65675,256,66468,1,512]

theorem envBound23965 : H12AffineFastState.Bounded env23965 := by
  intro p hp
  have h : env23965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23961_23965 : H12AffineEnvironment.transform 14 1 env23961 = env23965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23961 == env23965) = true)

theorem identity23965 : scanCanonicalize (H12AffineFastState.compose env23965 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 927) := by decide +kernel

theorem selectedBound23965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23966 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,1,1,927,0,2210,273,0,1,956,17,57,9,17,2233,1,1,2184,694,788,256,59,1,512]

theorem envBound23966 : H12AffineFastState.Bounded env23966 := by
  intro p hp
  have h : env23966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23965_23966 : H12AffineEnvironment.transform 15 927 env23965 = env23966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 927 env23965 == env23966) = true)

theorem identity23966 : scanCanonicalize (H12AffineFastState.compose env23966 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23966 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env23967 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,1,1,927,0,2179,273,0,1,925,17,24,9,17,2200,1,1,2184,663,788,256,26,1,512]

theorem envBound23967 : H12AffineFastState.Bounded env23967 := by
  intro p hp
  have h : env23967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23966_23967 : H12AffineEnvironment.transform 4 1 env23966 = env23967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23966 == env23967) = true)

theorem identity23967 : scanCanonicalize (H12AffineFastState.compose env23967 (packedSelected [3,10] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound23967 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env23968 : List Nat := [2,4,8,16,1,17,128,256,131,273,2048,0,129,1,1,284,0,2179,273,0,1,286,17,24,9,17,2200,1,1,2184,20,407,256,26,1,131]

theorem envBound23968 : H12AffineFastState.Bounded env23968 := by
  intro p hp
  have h : env23968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23967_23968 : H12AffineEnvironment.transform 8 131 env23967 = env23968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env23967 == env23968) = true)

theorem identity23968 : scanCanonicalize (H12AffineFastState.compose env23968 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound23968 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23969 : List Nat := [2,4,8,16,1,17,128,135,131,150,2048,0,129,1,1,155,0,2179,150,0,1,153,17,24,9,17,2200,1,1,2184,20,16,135,26,1,131]

theorem envBound23969 : H12AffineFastState.Bounded env23969 := by
  intro p hp
  have h : env23969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23968_23969 : H12AffineEnvironment.transform 7 135 env23968 = env23969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env23968 == env23969) = true)

def env23970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1297,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23970 : H12AffineFastState.Bounded env23970 := by
  intro p hp
  have h : env23970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23907_23970 : H12AffineEnvironment.transform 11 1345 env23907 = env23970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23907 == env23970) = true)

theorem identity23970 : scanCanonicalize (H12AffineFastState.compose env23970 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound23970 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1297,1296,1073741824,1365,4294967296,256,4299260415,1345,512]

theorem envBound23971 : H12AffineFastState.Bounded env23971 := by
  intro p hp
  have h : env23971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23970_23971 : H12AffineEnvironment.transform 23 98645 env23970 = env23971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env23970 == env23971) = true)

theorem identity23971 : scanCanonicalize (H12AffineFastState.compose env23971 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979376) := by decide +kernel

theorem selectedBound23971 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env23972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1297,1296,1073741824,1365,1077979376,256,1073817871,1345,512]

theorem envBound23972 : H12AffineFastState.Bounded env23972 := by
  intro p hp
  have h : env23972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23971_23972 : H12AffineEnvironment.transform 31 1077979376 env23971 = env23972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979376 env23971 == env23972) = true)

theorem identity23972 : scanCanonicalize (H12AffineFastState.compose env23972 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43129) := by decide +kernel

theorem selectedBound23972 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1297,1296,43129,1365,4194441,256,98678,1345,512]

theorem envBound23973 : H12AffineFastState.Bounded env23973 := by
  intro p hp
  have h : env23973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23972_23973 : H12AffineEnvironment.transform 29 43129 env23972 = env23973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43129 env23972 == env23973) = true)

theorem identity23973 : scanCanonicalize (H12AffineFastState.compose env23973 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23973 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env23974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,98565,8328,17,4456709,1297,1296,43049,1285,4194441,256,98598,1297,512]

theorem envBound23974 : H12AffineFastState.Bounded env23974 := by
  intro p hp
  have h : env23974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23973_23974 : H12AffineEnvironment.transform 5 16 env23973 = env23974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23973 == env23974) = true)

theorem identity23974 : scanCanonicalize (H12AffineFastState.compose env23974 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 74637) := by decide +kernel

theorem selectedBound23974 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1024,32769,1296,74637,16,98565,8328,17,336520,1297,1296,43049,1285,74500,256,98598,1297,512]

theorem envBound23975 : H12AffineFastState.Bounded env23975 := by
  intro p hp
  have h : env23975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23974_23975 : H12AffineEnvironment.transform 21 74637 env23974 = env23975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74637 env23974 == env23975) = true)

theorem identity23975 : scanCanonicalize (H12AffineFastState.compose env23975 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound23975 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23976 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9092,65536,1296,262144,1024,9093,1296,74637,16,74369,8328,17,336520,1297,1296,2989,1285,74500,256,74402,1297,512]

theorem envBound23976 : H12AffineFastState.Bounded env23976 := by
  intro p hp
  have h : env23976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23975_23976 : H12AffineEnvironment.transform 14 9092 env23975 = env23976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env23975 == env23976) = true)

theorem identity23976 : scanCanonicalize (H12AffineFastState.compose env23976 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 75776) := by decide +kernel

theorem selectedBound23976 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23977 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9092,65536,1296,75776,1024,9093,1296,74637,16,74369,8328,17,2696,1297,1296,2989,1285,74500,256,74402,1297,512]

theorem envBound23977 : H12AffineFastState.Bounded env23977 := by
  intro p hp
  have h : env23977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23976_23977 : H12AffineEnvironment.transform 17 75776 env23976 = env23977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75776 env23976 == env23977) = true)

theorem identity23977 : scanCanonicalize (H12AffineFastState.compose env23977 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound23977 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env23978 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9092,8323,1296,2179,1024,9093,1296,782,16,514,8328,17,2696,1297,1296,2989,1285,903,256,545,1297,512]

theorem envBound23978 : H12AffineFastState.Bounded env23978 := by
  intro p hp
  have h : env23978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23977_23978 : H12AffineEnvironment.transform 15 8323 env23977 = env23978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env23977 == env23978) = true)

theorem identity23978 : scanCanonicalize (H12AffineFastState.compose env23978 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23978 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23979 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,268,1297,648,399,1296,2179,1024,649,1296,782,16,514,388,17,2696,1297,1296,2989,1285,903,256,545,1297,512]

theorem envBound23979 : H12AffineFastState.Bounded env23979 := by
  intro p hp
  have h : env23979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23978_23979 : H12AffineEnvironment.transform 12 268 env23978 = env23979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23978 == env23979) = true)

theorem identity23979 : scanCanonicalize (H12AffineFastState.compose env23979 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 183) := by decide +kernel

theorem selectedBound23979 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23980 : List Nat := [2,4,8,16,32,16,128,256,512,183,2048,422,268,422,648,399,423,2179,183,649,423,782,16,514,388,17,2696,422,423,2989,434,903,256,545,422,512]

theorem envBound23980 : H12AffineFastState.Bounded env23980 := by
  intro p hp
  have h : env23980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23979_23980 : H12AffineEnvironment.transform 9 183 env23979 = env23980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 183 env23979 == env23980) = true)

theorem identity23980 : scanCanonicalize (H12AffineFastState.compose env23980 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound23980 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23981 : List Nat := [2,4,8,16,32,16,128,166,512,183,2048,0,170,0,648,41,1,2179,183,649,1,680,16,514,34,17,2696,0,1,2571,20,545,166,545,0,512]

theorem envBound23981 : H12AffineFastState.Bounded env23981 := by
  intro p hp
  have h : env23981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23980_23981 : H12AffineEnvironment.transform 7 166 env23980 = env23981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env23980 == env23981) = true)

theorem identity23981 : scanCanonicalize (H12AffineFastState.compose env23981 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23981 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23982 : List Nat := [2,4,8,16,32,16,128,166,137,183,2048,0,170,0,1,41,1,2179,183,0,1,33,16,139,34,17,2049,0,1,2178,20,168,166,168,0,137]

theorem envBound23982 : H12AffineFastState.Bounded env23982 := by
  intro p hp
  have h : env23982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23981_23982 : H12AffineEnvironment.transform 8 137 env23981 = env23982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23981 == env23982) = true)

theorem identity23982 : scanCanonicalize (H12AffineFastState.compose env23982 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound23982 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23983 : List Nat := [2,4,8,16,32,16,51,21,58,4,2048,0,25,0,1,41,1,2096,4,0,1,33,16,56,34,17,2049,0,1,2097,20,27,21,27,0,58]

theorem envBound23983 : H12AffineFastState.Bounded env23983 := by
  intro p hp
  have h : env23983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23982_23983 : H12AffineEnvironment.transform 6 51 env23982 = env23983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env23982 == env23983) = true)

def env23984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4097,4194304,17664,16777216,8328,17745,21352528,16384,21825,1073741824,16876544,4294967296,256,4315938986,21777,512]

theorem envBound23984 : H12AffineFastState.Bounded env23984 := by
  intro p hp
  have h : env23984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23905_23984 : H12AffineEnvironment.transform 16 1345 env23905 = env23984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23905 == env23984) = true)

def env23985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4097,4194304,147520,16777216,8328,147472,21352528,16385,151553,1073741824,16876545,4294967296,257,4315938986,21777,512]

theorem envBound23985 : H12AffineFastState.Bounded env23985 := by
  intro p hp
  have h : env23985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23904_23985 : H12AffineEnvironment.transform 18 1025 env23904 = env23985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23904 == env23985) = true)

def env23986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,4194304,17664,16777216,8328,17744,21352528,16385,21825,1073741824,16876545,4294967296,257,4315938986,21777,512]

theorem envBound23986 : H12AffineFastState.Bounded env23986 := by
  intro p hp
  have h : env23986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23985_23986 : H12AffineEnvironment.transform 16 1344 env23985 = env23986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23985 == env23986) = true)

theorem identity23986 : scanCanonicalize (H12AffineFastState.compose env23986 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 119125) := by decide +kernel

theorem selectedBound23986 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env23987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,4194304,17664,119125,8328,17744,4456709,16385,21825,1073741824,21844,4294967296,257,4299280895,21777,512]

theorem envBound23987 : H12AffineFastState.Bounded env23987 := by
  intro p hp
  have h : env23987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23986_23987 : H12AffineEnvironment.transform 23 119125 env23986 = env23987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119125 env23986 == env23987) = true)

def env23988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,4194304,64,103445,8328,16,4456709,1345,4097,1073741824,4116,4294967296,257,4299265215,4177,512]

theorem envBound23988 : H12AffineFastState.Bounded env23988 := by
  intro p hp
  have h : env23988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23987_23988 : H12AffineEnvironment.transform 13 1344 env23987 = env23988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env23987 == env23988) = true)

theorem identity23988 : scanCanonicalize (H12AffineFastState.compose env23988 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23988 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23989 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,1297,262144,1025,32769,4097,4194304,17,103445,8328,16,4456709,1296,4097,1073741824,4116,4294967296,257,4299265215,4096,512]

theorem envBound23989 : H12AffineFastState.Bounded env23989 := by
  intro p hp
  have h : env23989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23988_23989 : H12AffineEnvironment.transform 5 17 env23988 = env23989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23988 == env23989) = true)

def env23990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,1025,32769,4097,4194304,65,103444,8328,17,4456709,1344,4096,1073741824,4117,4294967296,257,4299265214,4176,512]

theorem envBound23990 : H12AffineFastState.Bounded env23990 := by
  intro p hp
  have h : env23990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23987_23990 : H12AffineEnvironment.transform 13 1345 env23987 = env23990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env23987 == env23990) = true)

theorem identity23990 : scanCanonicalize (H12AffineFastState.compose env23990 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound23990 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1025,32769,1345,4194304,65,98644,8328,17,4456709,1344,1344,1073741824,1365,4294967296,257,4299260414,1296,512]

theorem envBound23991 : H12AffineFastState.Bounded env23991 := by
  intro p hp
  have h : env23991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23990_23991 : H12AffineEnvironment.transform 11 1344 env23990 = env23991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23990 == env23991) = true)

theorem identity23991 : scanCanonicalize (H12AffineFastState.compose env23991 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound23991 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,262144,1025,32769,1345,4194304,65,138,8328,17,4456709,1344,1344,1073741824,1365,4294967296,257,4299161632,1296,512]

theorem envBound23992 : H12AffineFastState.Bounded env23992 := by
  intro p hp
  have h : env23992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23991_23992 : H12AffineEnvironment.transform 15 33246 env23991 = env23992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env23991 == env23992) = true)

theorem identity23992 : scanCanonicalize (H12AffineFastState.compose env23992 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 1074045428) := by decide +kernel

theorem selectedBound23992 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env23993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,262144,1025,32769,1345,4194304,65,138,8328,17,4456709,1344,1344,1073741824,1365,1074045428,257,1078239700,1296,512]

theorem envBound23993 : H12AffineFastState.Bounded env23993 := by
  intro p hp
  have h : env23993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23992_23993 : H12AffineEnvironment.transform 31 1074045428 env23992 = env23993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074045428 env23992 == env23993) = true)

theorem identity23993 : scanCanonicalize (H12AffineFastState.compose env23993 (packedSelected [1,5,10,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound23993 : packedSelected [1,5,10,24,28] rootPS < 2^1333 := by decide +kernel

def env23994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,43129,1025,32769,1345,4194304,65,138,8328,17,4237692,1344,1344,1073741824,1365,1073744269,257,1077938605,1296,512]

theorem envBound23994 : H12AffineFastState.Bounded env23994 := by
  intro p hp
  have h : env23994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23993_23994 : H12AffineEnvironment.transform 17 43129 env23993 = env23994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env23993 == env23994) = true)

theorem identity23994 : scanCanonicalize (H12AffineFastState.compose env23994 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound23994 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env23995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8460,1025,2420,1345,4194304,65,138,8328,17,4202505,1344,1344,1073741824,1365,1073744269,257,1077938605,1296,512]

theorem envBound23995 : H12AffineFastState.Bounded env23995 := by
  intro p hp
  have h : env23995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23994_23995 : H12AffineEnvironment.transform 14 2421 env23994 = env23995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env23994 == env23995) = true)

theorem identity23995 : scanCanonicalize (H12AffineFastState.compose env23995 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8461) := by decide +kernel

theorem selectedBound23995 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8460,1025,2420,1345,4194304,65,138,8328,17,4202505,1344,1344,8461,1365,10368,257,4204704,1296,512]

theorem envBound23996 : H12AffineFastState.Bounded env23996 := by
  intro p hp
  have h : env23996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23995_23996 : H12AffineEnvironment.transform 29 8461 env23995 = env23996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8461 env23995 == env23996) = true)

theorem identity23996 : scanCanonicalize (H12AffineFastState.compose env23996 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 3036) := by decide +kernel

theorem selectedBound23996 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8460,1025,2420,1345,3036,65,138,8328,17,11221,1344,1344,8461,1365,10368,257,9084,1296,512]

theorem envBound23997 : H12AffineFastState.Bounded env23997 := by
  intro p hp
  have h : env23997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23996_23997 : H12AffineEnvironment.transform 21 3036 env23996 = env23997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3036 env23996 == env23997) = true)

theorem identity23997 : scanCanonicalize (H12AffineFastState.compose env23997 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound23997 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,980,1345,2421,2219,1344,728,1025,2420,1345,3036,65,138,860,17,2049,1344,1344,729,1365,2900,257,168,1296,512]

theorem envBound23998 : H12AffineFastState.Bounded env23998 := by
  intro p hp
  have h : env23998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23997_23998 : H12AffineEnvironment.transform 12 980 env23997 = env23998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env23997 == env23998) = true)

theorem identity23998 : scanCanonicalize (H12AffineFastState.compose env23998 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound23998 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23999 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1344,348,1345,2421,2219,1344,80,1025,2420,1345,2388,65,138,468,17,2049,1344,1344,81,1365,2524,257,168,1296,136]

theorem envBound23999 : H12AffineFastState.Bounded env23999 := by
  intro p hp
  have h : env23999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23998_23999 : H12AffineEnvironment.transform 8 136 env23998 = env23999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env23998 == env23999) = true)

theorem identity23999 : scanCanonicalize (H12AffineFastState.compose env23999 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound23999 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24000 : List Nat := [2,4,8,16,32,64,128,256,136,1024,80,1344,348,1345,293,251,1344,80,1025,292,1345,260,65,138,468,17,81,1344,1344,81,1365,396,257,168,1296,136]

theorem envBound24000 : H12AffineFastState.Bounded env24000 := by
  intro p hp
  have h : env24000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23999_24000 : H12AffineEnvironment.transform 10 80 env23999 = env24000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env23999 == env24000) = true)

theorem identity24000 : scanCanonicalize (H12AffineFastState.compose env24000 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24000 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24001 : List Nat := [2,4,8,16,32,64,128,256,136,273,80,81,348,80,293,251,81,80,272,292,80,260,65,138,468,17,81,81,81,81,68,396,257,168,1,136]

theorem envBound24001 : H12AffineFastState.Bounded env24001 := by
  intro p hp
  have h : env24001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24000_24001 : H12AffineEnvironment.transform 9 273 env24000 = env24001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24000 == env24001) = true)

def env24002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17665,16777216,8328,17745,21352528,16385,21824,1073741824,16876545,4294967296,257,4315938986,21777,512]

theorem envBound24002 : H12AffineFastState.Bounded env24002 := by
  intro p hp
  have h : env24002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23985_24002 : H12AffineEnvironment.transform 16 1345 env23985 = env24002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23985 == env24002) = true)

theorem identity24002 : scanCanonicalize (H12AffineFastState.compose env24002 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound24002 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env24003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17665,98565,8328,17745,4477269,16385,21824,1073741824,1284,4294967296,257,4299260335,21777,512]

theorem envBound24003 : H12AffineFastState.Bounded env24003 := by
  intro p hp
  have h : env24003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24002_24003 : H12AffineEnvironment.transform 23 98565 env24002 = env24003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env24002 == env24003) = true)

def env24004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4097,4194304,5377,98565,8328,5457,4456789,4097,1344,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound24004 : H12AffineFastState.Bounded env24004 := by
  intro p hp
  have h : env24004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24003_24004 : H12AffineEnvironment.transform 13 4096 env24003 = env24004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env24003 == env24004) = true)

theorem identity24004 : scanCanonicalize (H12AffineFastState.compose env24004 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24004 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456708,4097,1297,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound24005 : H12AffineFastState.Bounded env24005 := by
  intro p hp
  have h : env24005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24004_24005 : H12AffineEnvironment.transform 5 17 env24004 = env24005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24004 == env24005) = true)

theorem identity24005 : scanCanonicalize (H12AffineFastState.compose env24005 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound24005 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env24006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,33166,1296,262144,1025,32769,4097,4194304,5377,139,8328,5376,4456708,4097,1297,1073741824,1284,4294967296,257,4299161633,1297,512]

theorem envBound24006 : H12AffineFastState.Bounded env24006 := by
  intro p hp
  have h : env24006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24005_24006 : H12AffineEnvironment.transform 15 33166 env24005 = env24006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env24005 == env24006) = true)

theorem identity24006 : scanCanonicalize (H12AffineFastState.compose env24006 (packedSelected [3,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound24006 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env24007 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,33166,1296,262144,1025,32769,4097,4194304,5377,139,8328,5376,4456708,4097,1297,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound24007 : H12AffineFastState.Bounded env24007 := by
  intro p hp
  have h : env24007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24006_24007 : H12AffineEnvironment.transform 29 4196612 env24006 = env24007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env24006 == env24007) = true)

theorem identity24007 : scanCanonicalize (H12AffineFastState.compose env24007 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24007 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24008 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,33166,1296,43049,1025,32769,4097,4194304,5377,139,8328,5376,4237613,4097,1297,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound24008 : H12AffineFastState.Bounded env24008 := by
  intro p hp
  have h : env24008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24007_24008 : H12AffineEnvironment.transform 17 43049 env24007 = env24008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24007 == env24008) = true)

def env24009 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,4194304,17,139,8328,16,4237613,1297,1297,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound24009 : H12AffineFastState.Bounded env24009 := by
  intro p hp
  have h : env24009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24008_24009 : H12AffineEnvironment.transform 11 1296 env24008 = env24009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24008 == env24009) = true)

theorem identity24009 : scanCanonicalize (H12AffineFastState.compose env24009 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 11053) := by decide +kernel

theorem selectedBound24009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24010 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,4194304,17,139,8328,16,4237613,1297,1297,4196612,1284,11053,257,4205324,1297,512]

theorem envBound24010 : H12AffineFastState.Bounded env24010 := by
  intro p hp
  have h : env24010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24009_24010 : H12AffineEnvironment.transform 31 11053 env24009 = env24010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11053 env24009 == env24010) = true)

theorem identity24010 : scanCanonicalize (H12AffineFastState.compose env24010 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound24010 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24011 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,260,17,139,8328,16,43049,1297,1297,2048,1284,11053,257,10760,1297,512]

theorem envBound24011 : H12AffineFastState.Bounded env24011 := by
  intro p hp
  have h : env24011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24010_24011 : H12AffineEnvironment.transform 21 260 env24010 = env24011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env24010 == env24011) = true)

theorem identity24011 : scanCanonicalize (H12AffineFastState.compose env24011 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 8973) := by decide +kernel

theorem selectedBound24011 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24012 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8973,8835,1296,2852,1025,8972,1297,260,17,139,8328,16,2852,1297,1297,2048,1284,11053,257,10760,1297,512]

theorem envBound24012 : H12AffineFastState.Bounded env24012 := by
  intro p hp
  have h : env24012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24011_24012 : H12AffineEnvironment.transform 14 8973 env24011 = env24012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8973 env24011 == env24012) = true)

theorem identity24012 : scanCanonicalize (H12AffineFastState.compose env24012 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24013 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,1296,8192,1296,8973,8835,1296,2821,1025,8972,1297,260,17,139,8328,16,2821,1297,1297,2048,1284,11020,257,10760,1297,512]

theorem envBound24013 : H12AffineFastState.Bounded env24013 := by
  intro p hp
  have h : env24013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24012_24013 : H12AffineEnvironment.transform 4 1 env24012 = env24013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24012 == env24013) = true)

theorem identity24013 : scanCanonicalize (H12AffineFastState.compose env24013 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound24013 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24014 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,1296,2317,1296,2560,2958,1296,2821,1025,2561,1297,260,17,139,2437,16,2821,1297,1297,2048,1284,513,257,773,1297,512]

theorem envBound24014 : H12AffineFastState.Bounded env24014 := by
  intro p hp
  have h : env24014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24013_24014 : H12AffineEnvironment.transform 12 2317 env24013 = env24014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env24013 == env24014) = true)

theorem identity24014 : scanCanonicalize (H12AffineFastState.compose env24014 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound24014 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env24015 : List Nat := [2,4,8,16,1,17,128,256,261,1024,2048,1296,2317,1296,2309,2187,1296,2048,1025,2308,1297,260,17,139,2437,16,2048,1297,1297,2048,1284,260,257,0,1297,261]

theorem envBound24015 : H12AffineFastState.Bounded env24015 := by
  intro p hp
  have h : env24015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24014_24015 : H12AffineEnvironment.transform 8 261 env24014 = env24015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env24014 == env24015) = true)

def env24016 : List Nat := [2,4,8,16,1,17,8,256,261,1024,2048,1296,2317,1296,2309,2051,1296,2048,1025,2308,1297,260,17,3,2317,16,2048,1297,1297,2048,1284,260,257,0,1297,261]

theorem envBound24016 : H12AffineFastState.Bounded env24016 := by
  intro p hp
  have h : env24016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24015_24016 : H12AffineEnvironment.transform 6 8 env24015 = env24016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24015 == env24016) = true)

def env24017 : List Nat := [2,4,8,16,1,17,9,256,261,1024,2048,1296,2317,1296,2309,2050,1296,2048,1025,2308,1297,260,17,2,2316,16,2048,1297,1297,2048,1284,260,257,0,1297,261]

theorem envBound24017 : H12AffineFastState.Bounded env24017 := by
  intro p hp
  have h : env24017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24015_24017 : H12AffineEnvironment.transform 6 9 env24015 = env24017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24015 == env24017) = true)

theorem identity24017 : scanCanonicalize (H12AffineFastState.compose env24017 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24017 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24018 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2056,1045,2048,2050,1045,2048,1025,2049,1044,1,17,2,2057,16,2048,1044,1044,2048,1025,1,4,0,1044,0]

theorem envBound24018 : H12AffineFastState.Bounded env24018 := by
  intro p hp
  have h : env24018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24017_24018 : H12AffineEnvironment.transform 7 5 env24017 = env24018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24017 == env24018) = true)

def leafEnv24018 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2056,1045,2048,2050,1045,2048,1025,2049,1044,1,17,2,1024,2057,1,16,2048,1044,1044,2048,1025,1,4,0,5,2050,1044,0,0,1045,1]

def active24018 : List Nat := [0,1,2,3,9,10]

def tree24018 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24018 : H12WitnessSearch.Good tree24018 := H12GlobalWitnessIndex.good

theorem leafIdentity24018 : H12AffineFastState.composeSystem env24018 rootObs = leafEnv24018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24018 rootObs == leafEnv24018) = true)

theorem terminalChecked24018 : H12PackedTerminal.terminalCheckFast leafEnv24018 active24018 tree24018 = true := by decide +kernel

def env24019 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1296,4194304,16,139,8328,17,4237613,1296,1297,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound24019 : H12AffineFastState.Bounded env24019 := by
  intro p hp
  have h : env24019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24008_24019 : H12AffineEnvironment.transform 11 1297 env24008 = env24019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24008 == env24019) = true)

theorem identity24019 : scanCanonicalize (H12AffineFastState.compose env24019 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4194305) := by decide +kernel

theorem selectedBound24019 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24020 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1296,4194304,16,139,8328,17,4237613,1296,1297,4196612,1284,4194305,257,32,1297,512]

theorem envBound24020 : H12AffineFastState.Bounded env24020 := by
  intro p hp
  have h : env24020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24019_24020 : H12AffineEnvironment.transform 31 4194305 env24019 = env24020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194305 env24019 == env24020) = true)

theorem identity24020 : scanCanonicalize (H12AffineFastState.compose env24020 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound24020 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24021 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8581,8203,1296,2476,1025,8580,1296,4194304,16,139,8328,17,4196520,1296,1297,4196612,1284,4194305,257,32,1297,512]

theorem envBound24021 : H12AffineFastState.Bounded env24021 := by
  intro p hp
  have h : env24021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24020_24021 : H12AffineEnvironment.transform 14 8581 env24020 = env24021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env24020 == env24021) = true)

theorem identity24021 : scanCanonicalize (H12AffineFastState.compose env24021 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound24021 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24022 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,8192,1297,8581,8203,1296,2476,1025,8580,1296,4194304,16,139,8328,17,4196520,1296,1297,4196612,1284,4194305,257,32,1297,0]

theorem envBound24022 : H12AffineFastState.Bounded env24022 := by
  intro p hp
  have h : env24022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24021_24022 : H12AffineEnvironment.transform 8 0 env24021 = env24022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env24021 == env24022) = true)

theorem identity24022 : scanCanonicalize (H12AffineFastState.compose env24022 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound24022 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24023 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,8192,1297,8581,8203,1296,2476,1025,8580,1296,169,16,139,8328,17,2049,1296,1297,2477,1284,168,257,32,1297,0]

theorem envBound24023 : H12AffineFastState.Bounded env24023 := by
  intro p hp
  have h : env24023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24022_24023 : H12AffineEnvironment.transform 21 169 env24022 = env24023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env24022 == env24023) = true)

def env24024 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,2208,1297,2341,2219,1296,2476,1025,2340,1296,169,16,139,2088,17,2049,1296,1297,2477,1284,168,257,32,1297,0]

theorem envBound24024 : H12AffineFastState.Bounded env24024 := by
  intro p hp
  have h : env24024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24023_24024 : H12AffineEnvironment.transform 12 2208 env24023 = env24024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env24023 == env24024) = true)

theorem identity24024 : scanCanonicalize (H12AffineFastState.compose env24024 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24025 : List Nat := [2,4,8,16,32,17,40,256,0,1024,2048,1297,2056,1297,2341,2051,1296,2308,1025,2340,1296,1,16,35,2088,17,2049,1296,1297,2309,1284,0,257,32,1297,0]

theorem envBound24025 : H12AffineFastState.Bounded env24025 := by
  intro p hp
  have h : env24025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24024_24025 : H12AffineEnvironment.transform 6 40 env24024 = env24025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24024 == env24025) = true)

def env24026 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,2056,1297,2309,2051,1296,2308,1025,2308,1296,1,16,3,2056,17,2049,1296,1297,2309,1284,0,257,0,1297,0]

theorem envBound24026 : H12AffineFastState.Bounded env24026 := by
  intro p hp
  have h : env24026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24025_24026 : H12AffineEnvironment.transform 4 0 env24025 = env24026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24025 == env24026) = true)

theorem identity24026 : scanCanonicalize (H12AffineFastState.compose env24026 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24027 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2056,1044,2048,2051,1045,2049,1025,2049,1045,1,16,3,2056,17,2049,1045,1044,2048,1025,0,4,0,1044,0]

theorem envBound24027 : H12AffineFastState.Bounded env24027 := by
  intro p hp
  have h : env24027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24026_24027 : H12AffineEnvironment.transform 7 5 env24026 = env24027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24026 == env24027) = true)

def leafEnv24027 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2056,1044,2048,2051,1045,2049,1025,2049,1045,1,16,3,1024,2056,1,17,2049,1045,1044,2048,1025,0,4,0,5,2050,1044,0,0,1045,1]

def active24027 : List Nat := [0,1,2,3,9,10]

def tree24027 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24027 : H12WitnessSearch.Good tree24027 := H12GlobalWitnessIndex.good

theorem leafIdentity24027 : H12AffineFastState.composeSystem env24027 rootObs = leafEnv24027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24027 rootObs == leafEnv24027) = true)

theorem terminalChecked24027 : H12PackedTerminal.terminalCheckFast leafEnv24027 active24027 tree24027 = true := by decide +kernel

def env24028 : List Nat := [2,4,8,16,1,17,9,256,0,1024,2048,1297,2056,1297,2308,2051,1296,2308,1025,2309,1296,1,16,2,2057,17,2049,1296,1297,2309,1284,0,257,1,1297,0]

theorem envBound24028 : H12AffineFastState.Bounded env24028 := by
  intro p hp
  have h : env24028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24025_24028 : H12AffineEnvironment.transform 4 1 env24025 = env24028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24025 == env24028) = true)

def env24029 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,2209,1297,2340,2218,1296,2476,1025,2341,1296,169,16,139,2089,17,2049,1296,1297,2477,1284,168,257,32,1297,0]

theorem envBound24029 : H12AffineFastState.Bounded env24029 := by
  intro p hp
  have h : env24029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24023_24029 : H12AffineEnvironment.transform 12 2209 env24023 = env24029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env24023 == env24029) = true)

theorem identity24029 : scanCanonicalize (H12AffineFastState.compose env24029 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24030 : List Nat := [2,4,8,16,32,17,128,4,0,1024,2048,1045,2209,1045,2080,2218,1044,2216,1025,2081,1044,169,16,139,2089,17,2049,1044,1045,2217,1024,168,5,32,1045,0]

theorem envBound24030 : H12AffineFastState.Bounded env24030 := by
  intro p hp
  have h : env24030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24029_24030 : H12AffineEnvironment.transform 7 4 env24029 = env24030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24029 == env24030) = true)

def env24031 : List Nat := [2,4,8,16,0,17,128,4,0,1024,2048,1045,2177,1045,2048,2186,1044,2184,1025,2049,1044,137,16,139,2057,17,2049,1044,1045,2185,1024,136,5,0,1045,0]

theorem envBound24031 : H12AffineFastState.Bounded env24031 := by
  intro p hp
  have h : env24031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24030_24031 : H12AffineEnvironment.transform 4 0 env24030 = env24031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24030 == env24031) = true)

theorem identity24031 : scanCanonicalize (H12AffineFastState.compose env24031 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24032 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2056,1045,2048,2051,1044,2049,1025,2049,1044,0,16,2,2057,17,2049,1044,1045,2048,1024,1,5,0,1045,0]

theorem envBound24032 : H12AffineFastState.Bounded env24032 := by
  intro p hp
  have h : env24032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24031_24032 : H12AffineEnvironment.transform 6 9 env24031 = env24032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24031 == env24032) = true)

def leafEnv24032 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2056,1045,2048,2051,1044,2049,1025,2049,1044,0,16,2,1025,2057,1,17,2049,1044,1045,2048,1024,1,5,0,5,2051,1045,0,0,1044,1]

def active24032 : List Nat := [0,1,2,3,9,10]

def tree24032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24032 : H12WitnessSearch.Good tree24032 := H12GlobalWitnessIndex.good

theorem leafIdentity24032 : H12AffineFastState.composeSystem env24032 rootObs = leafEnv24032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24032 rootObs == leafEnv24032) = true)

theorem terminalChecked24032 : H12PackedTerminal.terminalCheckFast leafEnv24032 active24032 tree24032 = true := by decide +kernel

def env24033 : List Nat := [2,4,8,16,1,17,128,4,0,1024,2048,1045,2176,1045,2049,2187,1044,2185,1025,2048,1044,136,16,139,2056,17,2049,1044,1045,2184,1024,137,5,1,1045,0]

theorem envBound24033 : H12AffineFastState.Bounded env24033 := by
  intro p hp
  have h : env24033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24030_24033 : H12AffineEnvironment.transform 4 1 env24030 = env24033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24030 == env24033) = true)

def env24034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4097,4194304,5376,98565,8328,5456,4456788,4096,1345,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound24034 : H12AffineFastState.Bounded env24034 := by
  intro p hp
  have h : env24034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24003_24034 : H12AffineEnvironment.transform 13 4097 env24003 = env24034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env24003 == env24034) = true)

def env24035 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98565,8328,5376,4456708,4096,1297,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound24035 : H12AffineFastState.Bounded env24035 := by
  intro p hp
  have h : env24035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24034_24035 : H12AffineEnvironment.transform 5 16 env24034 = env24035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24034 == env24035) = true)

theorem identity24035 : scanCanonicalize (H12AffineFastState.compose env24035 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound24035 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env24036 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98565,8328,5376,4456708,4096,1297,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound24036 : H12AffineFastState.Bounded env24036 := by
  intro p hp
  have h : env24036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24035_24036 : H12AffineEnvironment.transform 29 4196612 env24035 = env24036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env24035 == env24036) = true)

theorem identity24036 : scanCanonicalize (H12AffineFastState.compose env24036 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24036 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24037 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,43049,1025,32769,4097,4194304,5376,98565,8328,5376,4237613,4096,1297,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound24037 : H12AffineFastState.Bounded env24037 := by
  intro p hp
  have h : env24037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24036_24037 : H12AffineEnvironment.transform 17 43049 env24036 = env24037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24036 == env24037) = true)

theorem identity24037 : scanCanonicalize (H12AffineFastState.compose env24037 (packedSelected [10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound24037 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env24038 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,33166,1297,43049,1025,32769,4097,4194304,5376,139,8328,5376,4237613,4096,1297,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound24038 : H12AffineFastState.Bounded env24038 := by
  intro p hp
  have h : env24038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24037_24038 : H12AffineEnvironment.transform 15 33166 env24037 = env24038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env24037 == env24038) = true)

def env24039 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,4194304,16,139,8328,16,4237613,1296,1297,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound24039 : H12AffineFastState.Bounded env24039 := by
  intro p hp
  have h : env24039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24038_24039 : H12AffineEnvironment.transform 11 1296 env24038 = env24039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24038 == env24039) = true)

theorem identity24039 : scanCanonicalize (H12AffineFastState.compose env24039 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 34984) := by decide +kernel

theorem selectedBound24039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24040 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,4194304,16,139,8328,16,4237613,1296,1297,4196612,1284,34984,257,4229257,1296,512]

theorem envBound24040 : H12AffineFastState.Bounded env24040 := by
  intro p hp
  have h : env24040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24039_24040 : H12AffineEnvironment.transform 31 34984 env24039 = env24040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 34984 env24039 == env24040) = true)

theorem identity24040 : scanCanonicalize (H12AffineFastState.compose env24040 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound24040 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24041 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,260,16,139,8328,16,43049,1296,1297,2048,1284,34984,257,35213,1296,512]

theorem envBound24041 : H12AffineFastState.Bounded env24041 := by
  intro p hp
  have h : env24041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24040_24041 : H12AffineEnvironment.transform 21 260 env24040 = env24041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env24040 == env24041) = true)

theorem identity24041 : scanCanonicalize (H12AffineFastState.compose env24041 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound24041 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24042 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,8581,8203,1297,2476,1025,8580,1297,260,16,139,8328,16,2476,1296,1297,2048,1284,10541,257,10248,1296,512]

theorem envBound24042 : H12AffineFastState.Bounded env24042 := by
  intro p hp
  have h : env24042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24041_24042 : H12AffineEnvironment.transform 14 8581 env24041 = env24042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env24041 == env24042) = true)

theorem identity24042 : scanCanonicalize (H12AffineFastState.compose env24042 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24043 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2056,1297,2445,2051,1297,2476,1025,2444,1297,260,16,139,2176,16,2476,1296,1297,2048,1284,293,257,0,1296,512]

theorem envBound24043 : H12AffineFastState.Bounded env24043 := by
  intro p hp
  have h : env24043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24042_24043 : H12AffineEnvironment.transform 12 2056 env24042 = env24043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24042 == env24043) = true)

theorem identity24043 : scanCanonicalize (H12AffineFastState.compose env24043 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24043 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24044 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1045,2056,1044,2184,2051,1044,2217,1025,2185,1044,1,16,139,2176,16,2217,1045,1044,2048,1025,32,4,0,1045,512]

theorem envBound24044 : H12AffineFastState.Bounded env24044 := by
  intro p hp
  have h : env24044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24043_24044 : H12AffineEnvironment.transform 7 5 env24043 = env24044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24043 == env24044) = true)

theorem identity24044 : scanCanonicalize (H12AffineFastState.compose env24044 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound24044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24045 : List Nat := [2,4,8,16,32,16,128,5,32,1024,2048,1045,2056,1044,2184,2051,1044,2217,1025,2185,1044,1,16,139,2176,16,2217,1045,1044,2048,1025,32,4,0,1045,32]

theorem envBound24045 : H12AffineFastState.Bounded env24045 := by
  intro p hp
  have h : env24045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24044_24045 : H12AffineEnvironment.transform 8 32 env24044 = env24045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env24044 == env24045) = true)

theorem identity24045 : scanCanonicalize (H12AffineFastState.compose env24045 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24045 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24046 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1045,2056,1044,2081,2051,1044,2048,1025,2080,1044,1,16,34,2089,16,2048,1045,1044,2048,1025,32,4,0,1045,32]

theorem envBound24046 : H12AffineFastState.Bounded env24046 := by
  intro p hp
  have h : env24046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24045_24046 : H12AffineEnvironment.transform 6 41 env24045 = env24046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24045 == env24046) = true)

theorem identity24046 : scanCanonicalize (H12AffineFastState.compose env24046 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24047 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2056,1044,2048,2051,1044,2048,1025,2049,1044,1,16,3,2056,16,2048,1045,1044,2048,1025,1,4,0,1045,1]

theorem envBound24047 : H12AffineFastState.Bounded env24047 := by
  intro p hp
  have h : env24047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24046_24047 : H12AffineEnvironment.transform 4 1 env24046 = env24047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24046 == env24047) = true)

def leafEnv24047 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2056,1044,2048,2051,1044,2048,1025,2049,1044,1,16,3,1024,2056,1,16,2048,1045,1044,2048,1025,1,4,0,5,2050,1045,1,0,1045,1]

def active24047 : List Nat := [0,1,2,3,9,10]

def tree24047 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24047 : H12WitnessSearch.Good tree24047 := H12GlobalWitnessIndex.good

theorem leafIdentity24047 : H12AffineFastState.composeSystem env24047 rootObs = leafEnv24047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24047 rootObs == leafEnv24047) = true)

theorem terminalChecked24047 : H12PackedTerminal.terminalCheckFast leafEnv24047 active24047 tree24047 = true := by decide +kernel

def env24048 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1296,4194304,17,139,8328,17,4237613,1297,1297,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound24048 : H12AffineFastState.Bounded env24048 := by
  intro p hp
  have h : env24048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24038_24048 : H12AffineEnvironment.transform 11 1297 env24038 = env24048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24038 == env24048) = true)

theorem identity24048 : scanCanonicalize (H12AffineFastState.compose env24048 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4236164) := by decide +kernel

theorem selectedBound24048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24049 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1296,4194304,17,139,8328,17,4237613,1297,1297,4196612,1284,4236164,257,41893,1296,512]

theorem envBound24049 : H12AffineFastState.Bounded env24049 := by
  intro p hp
  have h : env24049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24048_24049 : H12AffineEnvironment.transform 31 4236164 env24048 = env24049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4236164 env24048 == env24049) = true)

theorem identity24049 : scanCanonicalize (H12AffineFastState.compose env24049 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 8973) := by decide +kernel

theorem selectedBound24049 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24050 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8973,8835,1297,2852,1025,8972,1296,4194304,17,139,8328,17,4196896,1297,1297,4196612,1284,4194441,257,168,1296,512]

theorem envBound24050 : H12AffineFastState.Bounded env24050 := by
  intro p hp
  have h : env24050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24049_24050 : H12AffineEnvironment.transform 14 8973 env24049 = env24050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8973 env24049 == env24050) = true)

theorem identity24050 : scanCanonicalize (H12AffineFastState.compose env24050 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 545) := by decide +kernel

theorem selectedBound24050 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24051 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8973,8835,1297,2852,1025,8972,1296,545,17,139,8328,17,2049,1297,1297,2853,1284,680,257,168,1296,512]

theorem envBound24051 : H12AffineFastState.Bounded env24051 := by
  intro p hp
  have h : env24051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24050_24051 : H12AffineEnvironment.transform 21 545 env24050 = env24051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 545 env24050 == env24051) = true)

theorem identity24051 : scanCanonicalize (H12AffineFastState.compose env24051 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound24051 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24052 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,8580,8202,1297,2477,1025,8581,1296,168,17,139,8328,17,2049,1297,1297,2476,1284,33,257,168,1296,137]

theorem envBound24052 : H12AffineFastState.Bounded env24052 := by
  intro p hp
  have h : env24052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24051_24052 : H12AffineEnvironment.transform 8 137 env24051 = env24052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24051 == env24052) = true)

def env24053 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2088,1296,2476,2082,1297,2477,1025,2477,1296,168,17,139,2208,17,2049,1297,1297,2476,1284,33,257,168,1296,137]

theorem envBound24053 : H12AffineFastState.Bounded env24053 := by
  intro p hp
  have h : env24053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24052_24053 : H12AffineEnvironment.transform 12 2088 env24052 = env24053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env24052 == env24053) = true)

theorem identity24053 : scanCanonicalize (H12AffineFastState.compose env24053 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound24053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24054 : List Nat := [2,4,8,16,32,16,128,141,137,1024,2048,1180,2088,1181,2081,2082,1180,2080,1025,2080,1181,168,17,139,2208,17,2049,1180,1180,2081,1161,33,140,168,1181,137]

theorem envBound24054 : H12AffineFastState.Bounded env24054 := by
  intro p hp
  have h : env24054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24053_24054 : H12AffineEnvironment.transform 7 141 env24053 = env24054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env24053 == env24054) = true)

def env24055 : List Nat := [2,4,8,16,0,16,128,141,137,1024,2048,1180,2056,1181,2049,2050,1180,2048,1025,2048,1181,136,17,139,2176,17,2049,1180,1180,2049,1161,1,140,136,1181,137]

theorem envBound24055 : H12AffineFastState.Bounded env24055 := by
  intro p hp
  have h : env24055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24054_24055 : H12AffineEnvironment.transform 4 0 env24054 = env24055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24054 == env24055) = true)

theorem identity24055 : scanCanonicalize (H12AffineFastState.compose env24055 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24056 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1045,2056,1044,2049,2050,1045,2048,1025,2048,1044,1,17,2,2057,17,2049,1045,1045,2049,1024,1,5,1,1044,0]

theorem envBound24056 : H12AffineFastState.Bounded env24056 := by
  intro p hp
  have h : env24056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24055_24056 : H12AffineEnvironment.transform 6 9 env24055 = env24056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24055 == env24056) = true)

def leafEnv24056 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1045,2056,1044,2049,2050,1045,2048,1025,2048,1044,1,17,2,1025,2057,1,17,2049,1045,1045,2049,1024,1,5,1,5,2050,1044,0,0,1044,1]

def active24056 : List Nat := [0,1,2,3,9,10]

def tree24056 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24056 : H12WitnessSearch.Good tree24056 := H12GlobalWitnessIndex.good

theorem leafIdentity24056 : H12AffineFastState.composeSystem env24056 rootObs = leafEnv24056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24056 rootObs == leafEnv24056) = true)

theorem terminalChecked24056 : H12PackedTerminal.terminalCheckFast leafEnv24056 active24056 tree24056 = true := by decide +kernel

def env24057 : List Nat := [2,4,8,16,1,16,128,141,137,1024,2048,1180,2057,1181,2048,2051,1180,2049,1025,2049,1181,137,17,139,2177,17,2049,1180,1180,2048,1161,0,140,137,1181,137]

theorem envBound24057 : H12AffineFastState.Bounded env24057 := by
  intro p hp
  have h : env24057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24054_24057 : H12AffineEnvironment.transform 4 1 env24054 = env24057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24054 == env24057) = true)

def leafEnv24057 : List Nat := [2,4,8,16,1,16,128,141,137,1024,2048,1180,2057,1181,2048,2051,1180,2049,1025,2049,1181,137,17,139,1160,2177,1,17,2049,1180,1180,2048,1161,0,140,137,5,2186,1181,137,0,1181,1]

def active24057 : List Nat := [0,1,2,3,6,9,10]

def tree24057 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24057 : H12WitnessSearch.Good tree24057 := H12GlobalWitnessIndex.good

theorem leafIdentity24057 : H12AffineFastState.composeSystem env24057 rootObs = leafEnv24057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24057 rootObs == leafEnv24057) = true)

theorem terminalChecked24057 : H12PackedTerminal.terminalCheckFast leafEnv24057 active24057 tree24057 = true := by decide +kernel

def env24058 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2089,1296,2477,2083,1297,2477,1025,2476,1296,168,17,139,2209,17,2049,1297,1297,2476,1284,33,257,168,1296,137]

theorem envBound24058 : H12AffineFastState.Bounded env24058 := by
  intro p hp
  have h : env24058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24052_24058 : H12AffineEnvironment.transform 12 2089 env24052 = env24058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env24052 == env24058) = true)

theorem identity24058 : scanCanonicalize (H12AffineFastState.compose env24058 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24059 : List Nat := [2,4,8,16,0,16,128,256,137,1024,2048,1297,2057,1296,2445,2051,1297,2445,1025,2444,1296,136,17,139,2177,17,2049,1297,1297,2444,1284,1,257,136,1296,137]

theorem envBound24059 : H12AffineFastState.Bounded env24059 := by
  intro p hp
  have h : env24059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24058_24059 : H12AffineEnvironment.transform 4 0 env24058 = env24059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24058 == env24059) = true)

def env24060 : List Nat := [2,4,8,16,0,16,8,256,1,1024,2048,1297,2057,1296,2309,2051,1297,2309,1025,2308,1296,0,17,3,2057,17,2049,1297,1297,2308,1284,1,257,0,1296,1]

theorem envBound24060 : H12AffineFastState.Bounded env24060 := by
  intro p hp
  have h : env24060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24059_24060 : H12AffineEnvironment.transform 6 8 env24059 = env24060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24059 == env24060) = true)

def env24061 : List Nat := [2,4,8,16,0,16,9,256,0,1024,2048,1297,2057,1296,2308,2051,1297,2308,1025,2309,1296,1,17,2,2056,17,2049,1297,1297,2309,1284,1,257,1,1296,0]

theorem envBound24061 : H12AffineFastState.Bounded env24061 := by
  intro p hp
  have h : env24061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24059_24061 : H12AffineEnvironment.transform 6 9 env24059 = env24061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24059 == env24061) = true)

theorem identity24061 : scanCanonicalize (H12AffineFastState.compose env24061 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24062 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1045,2057,1044,2048,2051,1045,2048,1025,2049,1044,1,17,2,2056,17,2049,1045,1045,2049,1024,1,5,1,1044,0]

theorem envBound24062 : H12AffineFastState.Bounded env24062 := by
  intro p hp
  have h : env24062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24061_24062 : H12AffineEnvironment.transform 7 4 env24061 = env24062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24061 == env24062) = true)

def leafEnv24062 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1045,2057,1044,2048,2051,1045,2048,1025,2049,1044,1,17,2,1025,2056,1,17,2049,1045,1045,2049,1024,1,5,1,5,2051,1044,0,0,1044,1]

def active24062 : List Nat := [0,1,2,3,9,10]

def tree24062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24062 : H12WitnessSearch.Good tree24062 := H12GlobalWitnessIndex.good

theorem leafIdentity24062 : H12AffineFastState.composeSystem env24062 rootObs = leafEnv24062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24062 rootObs == leafEnv24062) = true)

theorem terminalChecked24062 : H12PackedTerminal.terminalCheckFast leafEnv24062 active24062 tree24062 = true := by decide +kernel

def env24063 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456709,4096,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound24063 : H12AffineFastState.Bounded env24063 := by
  intro p hp
  have h : env24063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24034_24063 : H12AffineEnvironment.transform 5 17 env24034 = env24063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24034 == env24063) = true)

theorem identity24063 : scanCanonicalize (H12AffineFastState.compose env24063 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 1074038953) := by decide +kernel

theorem selectedBound24063 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env24064 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456709,4096,1296,1073741824,1284,1074038953,257,1078266118,1296,512]

theorem envBound24064 : H12AffineFastState.Bounded env24064 := by
  intro p hp
  have h : env24064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24063_24064 : H12AffineEnvironment.transform 31 1074038953 env24063 = env24064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074038953 env24063 == env24064) = true)

theorem identity24064 : scanCanonicalize (H12AffineFastState.compose env24064 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 303657) := by decide +kernel

theorem selectedBound24064 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env24065 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456709,4096,1296,303657,1284,10880,257,4303663,1296,512]

theorem envBound24065 : H12AffineFastState.Bounded env24065 := by
  intro p hp
  have h : env24065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24064_24065 : H12AffineEnvironment.transform 29 303657 env24064 = env24065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 303657 env24064 == env24065) = true)

theorem identity24065 : scanCanonicalize (H12AffineFastState.compose env24065 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 270344) := by decide +kernel

theorem selectedBound24065 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env24066 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4097,270344,5376,98565,8328,5377,8461,4096,1296,303657,1284,10880,257,363303,1296,512]

theorem envBound24066 : H12AffineFastState.Bounded env24066 := by
  intro p hp
  have h : env24066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24065_24066 : H12AffineEnvironment.transform 21 270344 env24065 = env24066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270344 env24065 == env24066) = true)

theorem identity24066 : scanCanonicalize (H12AffineFastState.compose env24066 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24066 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env24067 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,8203,1296,262144,1025,32769,4097,270344,5376,41230,8328,5377,8461,4096,1296,303657,1284,10880,257,305964,1296,512]

theorem envBound24067 : H12AffineFastState.Bounded env24067 := by
  intro p hp
  have h : env24067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24066_24067 : H12AffineEnvironment.transform 15 8203 env24066 = env24067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24066 == env24067) = true)

theorem identity24067 : scanCanonicalize (H12AffineFastState.compose env24067 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(17+1) ^^^ 8972) := by decide +kernel

theorem selectedBound24067 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env24068 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,8203,1296,8972,1025,32769,4097,772,5376,41230,8328,5377,8461,4096,1296,33061,1284,10880,257,34848,1296,512]

theorem envBound24068 : H12AffineFastState.Bounded env24068 := by
  intro p hp
  have h : env24068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24067_24068 : H12AffineEnvironment.transform 17 8972 env24067 = env24068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8972 env24067 == env24068) = true)

theorem identity24068 : scanCanonicalize (H12AffineFastState.compose env24068 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound24068 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24069 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,8581,8203,1296,8972,1025,8580,4097,772,5376,139,8328,5377,8461,4096,1296,8352,1284,10880,257,10661,1296,512]

theorem envBound24069 : H12AffineFastState.Bounded env24069 := by
  intro p hp
  have h : env24069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24068_24069 : H12AffineEnvironment.transform 14 8581 env24068 = env24069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env24068 == env24069) = true)

theorem identity24069 : scanCanonicalize (H12AffineFastState.compose env24069 (packedSelected [0,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound24069 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2