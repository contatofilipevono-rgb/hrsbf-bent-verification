import H12CloudChart2Data035

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans8786_8788 : H12AffineEnvironment.transform 17 8321 env8786 = env8788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8321 env8786 == env8788) = true)

theorem identity8788 : scanCanonicalize (H12AffineFastState.compose env8788 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8788 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8789 : List Nat := [2,4,8,16,32,16,8,4,1,1024,2048,4096,8192,4096,13340,35,1044,8201,1025,13340,4096,1,5124,13374,8193,5125,8200,4096,1045,15420,1025,13366,5,43,1044,0]

theorem envBound8789 : H12AffineFastState.Bounded env8789 := by
  intro p hp
  have h : env8789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8788_8789 : H12AffineEnvironment.transform 6 8 env8788 = env8789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8788 == env8789) = true)

theorem identity8789 : scanCanonicalize (H12AffineFastState.compose env8789 (packedSelected [0,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8789 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env8790 : List Nat := [2,4,8,16,32,16,8,4,1,1024,0,4096,8192,4096,13340,35,1044,8201,1025,13340,4096,1,5124,13374,8193,5125,8200,4096,1045,13372,1025,13366,5,43,1044,0]

theorem envBound8790 : H12AffineFastState.Bounded env8790 := by
  intro p hp
  have h : env8790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8789_8790 : H12AffineEnvironment.transform 10 0 env8789 = env8790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8789 == env8790) = true)

theorem identity8790 : scanCanonicalize (H12AffineFastState.compose env8790 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound8790 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8791 : List Nat := [2,4,8,16,32,16,8,4,1,1024,0,4096,5180,4096,32,35,1044,5173,1025,32,4096,1,5124,2,5181,5125,5172,4096,1045,0,1025,10,5,43,1044,0]

theorem envBound8791 : H12AffineFastState.Bounded env8791 := by
  intro p hp
  have h : env8791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8790_8791 : H12AffineEnvironment.transform 12 5180 env8790 = env8791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env8790 == env8791) = true)

def env8792 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,4096,5148,4096,0,3,1044,5141,1025,0,4096,1,5124,2,5149,5125,5140,4096,1045,0,1025,10,5,11,1044,0]

theorem envBound8792 : H12AffineFastState.Bounded env8792 := by
  intro p hp
  have h : env8792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8791_8792 : H12AffineEnvironment.transform 4 0 env8791 = env8792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8791 == env8792) = true)

theorem identity8792 : scanCanonicalize (H12AffineFastState.compose env8792 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8793 : List Nat := [2,4,8,1,0,1,8,4,1,1024,0,4096,5133,4096,0,3,1029,5124,1025,0,4096,1,5124,2,5132,5125,5125,4096,1028,0,1025,10,5,11,1029,0]

theorem envBound8793 : H12AffineFastState.Bounded env8793 := by
  intro p hp
  have h : env8793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8792_8793 : H12AffineEnvironment.transform 3 1 env8792 = env8793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8792 == env8793) = true)

def leafEnv8793 : List Nat := [2,4,8,1,0,1,8,4,1,1024,0,4096,5133,4096,0,3,1029,5124,1025,0,4096,1,5124,2,1024,5132,1,5125,5125,4096,1028,0,1025,10,5,11,5,2,1029,0,0,1028,1]

def active8793 : List Nat := [0,1,2,9,11]

def tree8793 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8793 : H12WitnessSearch.Good tree8793 := H12GlobalWitnessIndex.good

theorem leafIdentity8793 : H12AffineFastState.composeSystem env8793 rootObs = leafEnv8793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8793 rootObs == leafEnv8793) = true)

theorem terminalChecked8793 : H12PackedTerminal.terminalCheckFast leafEnv8793 active8793 tree8793 = true := by decide +kernel

def env8794 : List Nat := [2,4,8,16,1,16,8,4,1,1024,0,4096,5149,4096,1,2,1044,5140,1025,1,4096,1,5124,2,5148,5125,5141,4096,1045,0,1025,10,5,10,1044,0]

theorem envBound8794 : H12AffineFastState.Bounded env8794 := by
  intro p hp
  have h : env8794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8791_8794 : H12AffineEnvironment.transform 4 1 env8791 = env8794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8791 == env8794) = true)

theorem identity8794 : scanCanonicalize (H12AffineFastState.compose env8794 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8795 : List Nat := [2,4,8,11,1,11,8,4,1,1024,0,4096,5126,4096,1,2,1039,5135,1025,1,4096,1,5124,2,5127,5125,5134,4096,1038,0,1025,10,5,10,1039,0]

theorem envBound8795 : H12AffineFastState.Bounded env8795 := by
  intro p hp
  have h : env8795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8794_8795 : H12AffineEnvironment.transform 3 11 env8794 = env8795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8794 == env8795) = true)

def leafEnv8795 : List Nat := [2,4,8,11,1,11,8,4,1,1024,0,4096,5126,4096,1,2,1039,5135,1025,1,4096,1,5124,2,1024,5127,1,5125,5134,4096,1038,0,1025,10,5,10,5,3,1039,0,0,1038,1]

def active8795 : List Nat := [0,1,2,9,11]

def tree8795 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8795 : H12WitnessSearch.Good tree8795 := H12GlobalWitnessIndex.good

theorem leafIdentity8795 : H12AffineFastState.composeSystem env8795 rootObs = leafEnv8795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8795 rootObs == leafEnv8795) = true)

theorem terminalChecked8795 : H12PackedTerminal.terminalCheckFast leafEnv8795 active8795 tree8795 = true := by decide +kernel

def env8796 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,4096,8192,4097,13340,34,1045,262144,1025,13340,4096,136,5125,13375,8329,5125,262280,4097,1045,15420,1025,4294967296,5,4294980637,1045,136]

theorem envBound8796 : H12AffineFastState.Bounded env8796 := by
  intro p hp
  have h : env8796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8784_8796 : H12AffineEnvironment.transform 5 17 env8784 = env8796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8784 == env8796) = true)

theorem identity8796 : scanCanonicalize (H12AffineFastState.compose env8796 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 262306) := by decide +kernel

theorem selectedBound8796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8797 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,4096,8192,4097,13340,34,1045,262144,1025,13340,4096,136,5125,13375,8329,5125,262280,4097,1045,15420,1025,262306,5,275647,1045,136]

theorem envBound8797 : H12AffineFastState.Bounded env8797 := by
  intro p hp
  have h : env8797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8796_8797 : H12AffineEnvironment.transform 31 262306 env8796 = env8797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 262306 env8796 == env8797) = true)

def env8798 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,4096,8192,4097,13340,34,1045,8320,1025,13340,4096,136,5125,13375,8329,5125,8200,4097,1045,15420,1025,8226,5,5183,1045,136]

theorem envBound8798 : H12AffineFastState.Bounded env8798 := by
  intro p hp
  have h : env8798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8797_8798 : H12AffineEnvironment.transform 17 8320 env8797 = env8798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8320 env8797 == env8798) = true)

theorem identity8798 : scanCanonicalize (H12AffineFastState.compose env8798 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound8798 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8799 : List Nat := [2,4,8,16,32,17,9,4,0,1024,2048,4096,8192,4097,13340,34,1045,8201,1025,13340,4096,1,5125,13375,8192,5125,8200,4097,1045,15420,1025,8226,5,5183,1045,1]

theorem envBound8799 : H12AffineFastState.Bounded env8799 := by
  intro p hp
  have h : env8799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8798_8799 : H12AffineEnvironment.transform 6 9 env8798 = env8799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8798 == env8799) = true)

theorem identity8799 : scanCanonicalize (H12AffineFastState.compose env8799 (packedSelected [0,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8799 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env8800 : List Nat := [2,4,8,16,32,17,9,4,0,1024,0,4096,8192,4097,13340,34,1045,8201,1025,13340,4096,1,5125,13375,8192,5125,8200,4097,1045,13372,1025,8226,5,5183,1045,1]

theorem envBound8800 : H12AffineFastState.Bounded env8800 := by
  intro p hp
  have h : env8800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8799_8800 : H12AffineEnvironment.transform 10 0 env8799 = env8800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8799 == env8800) = true)

theorem identity8800 : scanCanonicalize (H12AffineFastState.compose env8800 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound8800 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8801 : List Nat := [2,4,8,16,32,17,9,4,0,1024,0,4096,5180,4097,32,34,1045,5173,1025,32,4096,1,5125,3,5180,5125,5172,4097,1045,0,1025,5150,5,5183,1045,1]

theorem envBound8801 : H12AffineFastState.Bounded env8801 := by
  intro p hp
  have h : env8801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8800_8801 : H12AffineEnvironment.transform 12 5180 env8800 = env8801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env8800 == env8801) = true)

def env8802 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,4096,5148,4097,0,2,1045,5141,1025,0,4096,1,5125,3,5148,5125,5140,4097,1045,0,1025,5150,5,5151,1045,1]

theorem envBound8802 : H12AffineFastState.Bounded env8802 := by
  intro p hp
  have h : env8802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8801_8802 : H12AffineEnvironment.transform 4 0 env8801 = env8802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8801 == env8802) = true)

theorem identity8802 : scanCanonicalize (H12AffineFastState.compose env8802 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound8802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8803 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1028,24,1029,0,2,1045,17,1025,0,1028,1,1,3,24,1,16,1029,1045,0,1025,26,5,27,1045,1]

theorem envBound8803 : H12AffineFastState.Bounded env8803 := by
  intro p hp
  have h : env8803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8802_8803 : H12AffineEnvironment.transform 11 1028 env8802 = env8803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env8802 == env8803) = true)

def leafEnv8803 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1028,24,1029,0,2,1045,17,1025,0,1028,1,1,3,1024,24,1,1,16,1029,1045,0,1025,26,5,27,5,2,1045,1,0,1045,1]

def active8803 : List Nat := [0,1,2,3,9]

def tree8803 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8803 : H12WitnessSearch.Good tree8803 := H12GlobalWitnessIndex.good

theorem leafIdentity8803 : H12AffineFastState.composeSystem env8803 rootObs = leafEnv8803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8803 rootObs == leafEnv8803) = true)

theorem terminalChecked8803 : H12PackedTerminal.terminalCheckFast leafEnv8803 active8803 tree8803 = true := by decide +kernel

def env8804 : List Nat := [2,4,8,16,1,17,9,4,0,1024,0,4096,5149,4097,1,3,1045,5140,1025,1,4096,1,5125,3,5149,5125,5141,4097,1045,0,1025,5150,5,5150,1045,1]

theorem envBound8804 : H12AffineFastState.Bounded env8804 := by
  intro p hp
  have h : env8804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8801_8804 : H12AffineEnvironment.transform 4 1 env8801 = env8804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8801 == env8804) = true)

theorem identity8804 : scanCanonicalize (H12AffineFastState.compose env8804 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8804 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8805 : List Nat := [2,4,8,10,1,11,9,4,0,1024,0,4096,5127,4097,1,3,1039,5134,1025,1,4096,1,5125,3,5127,5125,5135,4097,1039,0,1025,5124,5,5124,1039,1]

theorem envBound8805 : H12AffineFastState.Bounded env8805 := by
  intro p hp
  have h : env8805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8804_8805 : H12AffineEnvironment.transform 3 10 env8804 = env8805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8804 == env8805) = true)

def leafEnv8805 : List Nat := [2,4,8,10,1,11,9,4,0,1024,0,4096,5127,4097,1,3,1039,5134,1025,1,4096,1,5125,3,1024,5127,1,5125,5135,4097,1039,0,1025,5124,5,5124,5,3,1039,1,0,1039,1]

def active8805 : List Nat := [0,1,2,9,11]

def tree8805 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8805 : H12WitnessSearch.Good tree8805 := H12GlobalWitnessIndex.good

theorem leafIdentity8805 : H12AffineFastState.composeSystem env8805 rootObs = leafEnv8805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8805 rootObs == leafEnv8805) = true)

theorem terminalChecked8805 : H12PackedTerminal.terminalCheckFast leafEnv8805 active8805 tree8805 = true := by decide +kernel

def env8806 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,4096,8192,4097,13340,34,1045,8321,1025,13340,4096,136,5125,13375,8329,5125,8201,4097,1045,15420,1025,8227,5,5182,1045,136]

theorem envBound8806 : H12AffineFastState.Bounded env8806 := by
  intro p hp
  have h : env8806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8797_8806 : H12AffineEnvironment.transform 17 8321 env8797 = env8806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8321 env8797 == env8806) = true)

def env8807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,33554432,135233,21352528,148800,131153,1073741824,16876544,4294967296,257,4350177586,131072,33563272]

theorem envBound8807 : H12AffineFastState.Bounded env8807 := by
  intro p hp
  have h : env8807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8734_8807 : H12AffineEnvironment.transform 20 4097 env8734 = env8807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8734 == env8807) = true)

theorem identity8807 : scanCanonicalize (H12AffineFastState.compose env8807 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound8807 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,230469,33554432,135233,4609045,148800,131153,1073741824,131141,4294967296,257,4333368695,131072,33563272]

theorem envBound8808 : H12AffineFastState.Bounded env8808 := by
  intro p hp
  have h : env8808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8807_8808 : H12AffineEnvironment.transform 23 230469 env8807 = env8808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env8807 == env8808) = true)

theorem identity8808 : scanCanonicalize (H12AffineFastState.compose env8808 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound8808 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,230469,8328,135233,4609045,148800,131153,1073741824,131141,4294967296,257,4299806207,131072,512]

theorem envBound8809 : H12AffineFastState.Bounded env8809 := by
  intro p hp
  have h : env8809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8808_8809 : H12AffineEnvironment.transform 24 8328 env8808 = env8809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env8808 == env8809) = true)

theorem identity8809 : scanCanonicalize (H12AffineFastState.compose env8809 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(29+1) ^^^ 4279455) := by decide +kernel

theorem selectedBound8809 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,230469,8328,135233,4609045,148800,131153,4279455,131141,4294967296,257,4299806207,131072,512]

theorem envBound8810 : H12AffineFastState.Bounded env8810 := by
  intro p hp
  have h : env8810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8809_8810 : H12AffineEnvironment.transform 29 4279455 env8809 = env8810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4279455 env8809 == env8810) = true)

theorem identity8810 : scanCanonicalize (H12AffineFastState.compose env8810 (packedSelected [4,16,22] rootPS)) = affineNative (2^(21+1) ^^^ 143748) := by decide +kernel

theorem selectedBound8810 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env8811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,143748,17664,230469,8328,135233,288145,148800,131153,228635,131141,4294967296,257,4295746683,131072,512]

theorem envBound8811 : H12AffineFastState.Bounded env8811 := by
  intro p hp
  have h : env8811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8810_8811 : H12AffineEnvironment.transform 21 143748 env8810 = env8811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 143748 env8810 == env8811) = true)

theorem identity8811 : scanCanonicalize (H12AffineFastState.compose env8811 (packedSelected [4,6,9,16,25] rootPS)) = affineNative (2^(18+1) ^^^ 24856) := by decide +kernel

theorem selectedBound8811 : packedSelected [4,6,9,16,25] rootPS < 2^1333 := by decide +kernel

def env8812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,24856,32768,4097,143748,17664,230469,8328,135233,288145,148800,131153,228635,131141,4294967296,257,4295198051,131072,512]

theorem envBound8812 : H12AffineFastState.Bounded env8812 := by
  intro p hp
  have h : env8812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8811_8812 : H12AffineEnvironment.transform 18 24856 env8811 = env8812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 24856 env8811 == env8812) = true)

theorem identity8812 : scanCanonicalize (H12AffineFastState.compose env8812 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound8812 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,24856,32768,4097,13509,17664,98564,8328,5376,288145,16385,1296,96346,1284,4294967296,257,4295065634,1345,512]

theorem envBound8813 : H12AffineFastState.Bounded env8813 := by
  intro p hp
  have h : env8813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8812_8813 : H12AffineEnvironment.transform 16 1345 env8812 = env8813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8812 == env8813) = true)

theorem identity8813 : scanCanonicalize (H12AffineFastState.compose env8813 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(31+1) ^^^ 123026) := by decide +kernel

theorem selectedBound8813 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env8814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,24856,32768,4097,13509,17664,98564,8328,5376,288145,16385,1296,96346,1284,123026,257,24752,1345,512]

theorem envBound8814 : H12AffineFastState.Bounded env8814 := by
  intro p hp
  have h : env8814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8813_8814 : H12AffineEnvironment.transform 31 123026 env8813 = env8814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 123026 env8813 == env8814) = true)

theorem identity8814 : scanCanonicalize (H12AffineFastState.compose env8814 (packedSelected [0,27] rootPS)) = affineNative (2^(14+1) ^^^ 5189) := by decide +kernel

theorem selectedBound8814 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env8815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5189,65536,1345,262144,24856,5189,4097,13509,17664,70977,8328,5376,288145,16385,1296,96346,1284,95447,257,24752,1345,512]

theorem envBound8815 : H12AffineFastState.Bounded env8815 := by
  intro p hp
  have h : env8815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8814_8815 : H12AffineEnvironment.transform 14 5189 env8814 = env8815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5189 env8814 == env8815) = true)

theorem identity8815 : scanCanonicalize (H12AffineFastState.compose env8815 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound8815 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5189,65536,1345,2341,24856,5189,4097,13509,17664,70977,8328,5376,27828,16385,1296,96346,1284,95447,257,24752,1345,512]

theorem envBound8816 : H12AffineFastState.Bounded env8816 := by
  intro p hp
  have h : env8816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8815_8816 : H12AffineEnvironment.transform 17 2341 env8815 = env8816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env8815 == env8816) = true)

theorem identity8816 : scanCanonicalize (H12AffineFastState.compose env8816 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 9496) := by decide +kernel

theorem selectedBound8816 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9496,5189,65536,1345,2341,1024,5189,4097,13509,8216,70977,8328,5376,2476,9497,1296,73026,1284,70095,257,1448,1345,512]

theorem envBound8817 : H12AffineFastState.Bounded env8817 := by
  intro p hp
  have h : env8817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8816_8817 : H12AffineEnvironment.transform 13 9496 env8816 = env8817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9496 env8816 == env8817) = true)

theorem identity8817 : scanCanonicalize (H12AffineFastState.compose env8817 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound8817 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9496,5189,515,1345,2341,1024,5189,4097,13509,8216,5954,8328,5376,2476,9497,1296,8001,1284,5068,257,1448,1345,512]

theorem envBound8818 : H12AffineFastState.Bounded env8818 := by
  intro p hp
  have h : env8818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8817_8818 : H12AffineEnvironment.transform 15 515 env8817 = env8818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env8817 == env8818) = true)

theorem identity8818 : scanCanonicalize (H12AffineFastState.compose env8818 (packedSelected [3,6,8,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound8818 : packedSelected [3,6,8,12,17] rootPS < 2^1333 := by decide +kernel

def env8819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,9496,1197,515,1345,2341,1024,1197,233,9261,8216,1962,8328,1512,2476,9497,1296,4009,1284,804,257,1448,1345,512]

theorem envBound8819 : H12AffineFastState.Bounded env8819 := by
  intro p hp
  have h : env8819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8818_8819 : H12AffineEnvironment.transform 11 232 env8818 = env8819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env8818 == env8819) = true)

theorem identity8819 : scanCanonicalize (H12AffineFastState.compose env8819 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(12+1) ^^^ 1440) := by decide +kernel

theorem selectedBound8819 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env8820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,1440,184,1197,515,1345,2341,1024,1197,233,397,1464,1962,1320,1512,2476,185,1296,4009,1284,804,257,1448,1345,512]

theorem envBound8820 : H12AffineFastState.Bounded env8820 := by
  intro p hp
  have h : env8820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8819_8820 : H12AffineEnvironment.transform 12 1440 env8819 = env8820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1440 env8819 == env8820) = true)

theorem identity8820 : scanCanonicalize (H12AffineFastState.compose env8820 (packedSelected [1,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1238) := by decide +kernel

theorem selectedBound8820 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env8821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1238,232,1440,184,1197,515,1345,1523,1024,1197,233,397,1464,1962,1320,1512,1402,185,1296,895,1284,804,257,1448,1345,512]

theorem envBound8821 : H12AffineFastState.Bounded env8821 := by
  intro p hp
  have h : env8821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8820_8821 : H12AffineEnvironment.transform 10 1238 env8820 = env8821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1238 env8820 == env8821) = true)

theorem identity8821 : scanCanonicalize (H12AffineFastState.compose env8821 (packedSelected [11,32] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound8821 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env8822 : List Nat := [2,4,8,16,32,64,128,256,512,800,1014,232,640,184,909,515,609,723,800,909,233,397,664,138,520,712,602,185,560,895,548,804,257,648,609,512]

theorem envBound8822 : H12AffineFastState.Bounded env8822 := by
  intro p hp
  have h : env8822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8821_8822 : H12AffineEnvironment.transform 9 800 env8821 = env8822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env8821 == env8822) = true)

theorem identity8822 : scanCanonicalize (H12AffineFastState.compose env8822 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 210) := by decide +kernel

theorem selectedBound8822 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8823 : List Nat := [2,4,8,16,32,64,128,256,210,498,292,232,82,184,351,209,179,1,498,351,233,397,74,138,218,26,136,185,226,429,246,502,257,90,179,210]

theorem envBound8823 : H12AffineFastState.Bounded env8823 := by
  intro p hp
  have h : env8823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8822_8823 : H12AffineEnvironment.transform 8 210 env8822 = env8823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 210 env8822 == env8823) = true)

def env8824 : List Nat := [2,4,8,16,32,64,8,256,90,378,292,96,82,48,351,89,59,1,378,351,97,261,74,2,82,26,0,49,106,293,126,382,257,90,59,90]

theorem envBound8824 : H12AffineFastState.Bounded env8824 := by
  intro p hp
  have h : env8824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8823_8824 : H12AffineEnvironment.transform 6 8 env8823 = env8824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8823 == env8824) = true)

theorem identity8824 : scanCanonicalize (H12AffineFastState.compose env8824 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 40) := by decide +kernel

theorem selectedBound8824 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8825 : List Nat := [2,4,8,16,32,40,8,256,50,274,292,8,58,48,311,49,59,1,274,311,9,261,34,2,58,26,0,49,2,293,22,278,257,50,59,50]

theorem envBound8825 : H12AffineFastState.Bounded env8825 := by
  intro p hp
  have h : env8825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8824_8825 : H12AffineEnvironment.transform 5 40 env8824 = env8825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 40 env8824 == env8825) = true)

theorem identity8825 : scanCanonicalize (H12AffineFastState.compose env8825 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound8825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8826 : List Nat := [2,4,8,16,32,40,8,47,50,61,11,8,58,48,24,49,59,1,61,24,9,42,34,2,58,26,0,49,2,10,22,57,46,50,59,50]

theorem envBound8826 : H12AffineFastState.Bounded env8826 := by
  intro p hp
  have h : env8826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8825_8826 : H12AffineEnvironment.transform 7 47 env8825 = env8826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env8825 == env8826) = true)

def env8827 : List Nat := [2,4,8,16,32,64,9,256,91,379,292,97,82,49,351,88,58,1,379,351,96,260,74,3,83,26,1,48,107,292,127,383,257,90,58,91]

theorem envBound8827 : H12AffineFastState.Bounded env8827 := by
  intro p hp
  have h : env8827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8823_8827 : H12AffineEnvironment.transform 6 9 env8823 = env8827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8823 == env8827) = true)

theorem identity8827 : scanCanonicalize (H12AffineFastState.compose env8827 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound8827 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8828 : List Nat := [2,4,8,2,32,64,9,256,73,361,292,97,64,35,333,74,40,1,361,333,96,260,74,3,65,8,1,34,107,292,109,365,257,72,40,73]

theorem envBound8828 : H12AffineFastState.Bounded env8828 := by
  intro p hp
  have h : env8828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8827_8828 : H12AffineEnvironment.transform 3 2 env8827 = env8828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env8827 == env8828) = true)

theorem identity8828 : scanCanonicalize (H12AffineFastState.compose env8828 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8828 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8829 : List Nat := [2,4,8,2,32,64,9,36,73,77,0,97,64,35,105,74,40,1,77,105,96,32,74,3,65,8,1,34,107,0,109,73,37,72,40,73]

theorem envBound8829 : H12AffineFastState.Bounded env8829 := by
  intro p hp
  have h : env8829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8828_8829 : H12AffineEnvironment.transform 7 36 env8828 = env8829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8828 == env8829) = true)

theorem identity8829 : scanCanonicalize (H12AffineFastState.compose env8829 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8829 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8830 : List Nat := [2,4,3,2,32,64,2,36,66,70,0,97,64,35,98,65,35,1,70,98,96,32,65,3,65,3,1,34,96,0,102,66,37,67,35,66]

theorem envBound8830 : H12AffineFastState.Bounded env8830 := by
  intro p hp
  have h : env8830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8829_8830 : H12AffineEnvironment.transform 2 3 env8829 = env8830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8829 == env8830) = true)

theorem identity8830 : scanCanonicalize (H12AffineFastState.compose env8830 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 34) := by decide +kernel

theorem selectedBound8830 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8831 : List Nat := [2,4,3,2,32,34,2,36,32,36,0,3,34,35,0,35,35,1,36,0,2,32,35,3,35,3,1,34,2,0,4,32,37,33,35,32]

theorem envBound8831 : H12AffineFastState.Bounded env8831 := by
  intro p hp
  have h : env8831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8830_8831 : H12AffineEnvironment.transform 5 34 env8830 = env8831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 34 env8830 == env8831) = true)

theorem identity8831 : scanCanonicalize (H12AffineFastState.compose env8831 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8832 : List Nat := [2,4,3,2,0,2,2,4,0,4,0,3,2,3,0,3,3,1,4,0,2,0,3,3,3,3,1,2,2,0,4,0,5,1,3,0]

theorem envBound8832 : H12AffineFastState.Bounded env8832 := by
  intro p hp
  have h : env8832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8831_8832 : H12AffineEnvironment.transform 4 0 env8831 = env8832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8831 == env8832) = true)

def leafEnv8832 : List Nat := [2,4,3,2,0,2,2,4,0,4,0,3,2,3,0,3,3,1,4,0,2,0,3,3,4,3,1,3,1,2,2,0,4,0,5,1,5,2,3,0,0,2,1]

def active8832 : List Nat := [0,1]

def tree8832 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8832 : H12WitnessSearch.Good tree8832 := H12GlobalWitnessIndex.good

theorem leafIdentity8832 : H12AffineFastState.composeSystem env8832 rootObs = leafEnv8832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8832 rootObs == leafEnv8832) = true)

theorem terminalChecked8832 : H12PackedTerminal.terminalCheckFast leafEnv8832 active8832 tree8832 = true := by decide +kernel

def env8833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,157794305,1073741824,140788816,4294967296,157663569,4417151347,131073,33563272]

theorem envBound8833 : H12AffineFastState.Bounded env8833 := by
  intro p hp
  have h : env8833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8716_8833 : H12AffineEnvironment.transform 28 157794305 env8716 = env8833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env8716 == env8833) = true)

theorem identity8833 : scanCanonicalize (H12AffineFastState.compose env8833 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 88588305) := by decide +kernel

theorem selectedBound8833 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,88588305,67130625,69206032,1073741824,86213697,4294967296,69337408,4417151347,131073,33563272]

theorem envBound8834 : H12AffineFastState.Bounded env8834 := by
  intro p hp
  have h : env8834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8833_8834 : H12AffineEnvironment.transform 26 88588305 env8833 = env8834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 88588305 env8833 == env8834) = true)

def env8835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,2228288,23445585,2250049,131152,1073741824,16876545,4294967296,256,4352270643,131073,33563272]

theorem envBound8835 : H12AffineFastState.Bounded env8835 := by
  intro p hp
  have h : env8835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8834_8835 : H12AffineEnvironment.transform 25 2228288 env8834 = env8835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2228288 env8834 == env8835) = true)

def env8836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,16777216,33554432,135232,21352529,148801,131152,1073741824,16876545,4294967296,256,4350177587,131073,33563272]

theorem envBound8836 : H12AffineFastState.Bounded env8836 := by
  intro p hp
  have h : env8836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8835_8836 : H12AffineEnvironment.transform 20 4096 env8835 = env8836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env8835 == env8836) = true)

theorem identity8836 : scanCanonicalize (H12AffineFastState.compose env8836 (packedSelected [35] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound8836 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,16777216,33554432,5377,21352529,16384,1297,1073741824,16876545,4294967296,256,4350047346,1344,33563272]

theorem envBound8837 : H12AffineFastState.Bounded env8837 := by
  intro p hp
  have h : env8837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8836_8837 : H12AffineEnvironment.transform 16 1345 env8836 = env8837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8836 == env8837) = true)

theorem identity8837 : scanCanonicalize (H12AffineFastState.compose env8837 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound8837 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env8838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,16777216,8329,5377,21352529,16384,1297,1073741824,16876545,4294967296,256,4316484859,1344,513]

theorem envBound8838 : H12AffineFastState.Bounded env8838 := by
  intro p hp
  have h : env8838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8837_8838 : H12AffineEnvironment.transform 24 8329 env8837 = env8838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env8837 == env8838) = true)

theorem identity8838 : scanCanonicalize (H12AffineFastState.compose env8838 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound8838 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,644436,8329,5377,4982021,16384,1297,1073741824,545109,4294967296,256,4299260335,1344,513]

theorem envBound8839 : H12AffineFastState.Bounded env8839 := by
  intro p hp
  have h : env8839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8838_8839 : H12AffineEnvironment.transform 23 644436 env8838 = env8839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env8838 == env8839) = true)

theorem identity8839 : scanCanonicalize (H12AffineFastState.compose env8839 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4840667) := by decide +kernel

theorem selectedBound8839 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,644436,8329,5377,4982021,16384,1297,4840667,545109,4294967296,256,4299260335,1344,513]

theorem envBound8840 : H12AffineFastState.Bounded env8840 := by
  intro p hp
  have h : env8840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8839_8840 : H12AffineEnvironment.transform 29 4840667 env8839 = env8840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4840667 env8839 == env8840) = true)

theorem identity8840 : scanCanonicalize (H12AffineFastState.compose env8840 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound8840 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env8841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,524288,32768,4096,4194304,5457,623877,8329,5377,4982021,4177,1297,4820106,524548,4294967296,256,4299260335,1344,513]

theorem envBound8841 : H12AffineFastState.Bounded env8841 := by
  intro p hp
  have h : env8841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8840_8841 : H12AffineEnvironment.transform 13 4177 env8840 = env8841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env8840 == env8841) = true)

theorem identity8841 : scanCanonicalize (H12AffineFastState.compose env8841 (packedSelected [6,25] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound8841 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env8842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1025,32768,4096,4194304,5457,98564,8329,5377,4456708,4177,1297,4294795,1285,4294967296,256,4299260335,1344,513]

theorem envBound8842 : H12AffineFastState.Bounded env8842 := by
  intro p hp
  have h : env8842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8841_8842 : H12AffineEnvironment.transform 18 1025 env8841 = env8842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8841 == env8842) = true)

theorem identity8842 : scanCanonicalize (H12AffineFastState.compose env8842 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 99327) := by decide +kernel

theorem selectedBound8842 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1025,32768,4096,4194304,5457,98564,8329,5377,4456708,4177,1297,4294795,1285,99327,256,4194896,1344,513]

theorem envBound8843 : H12AffineFastState.Bounded env8843 := by
  intro p hp
  have h : env8843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8842_8843 : H12AffineEnvironment.transform 31 99327 env8842 = env8843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 99327 env8842 == env8843) = true)

theorem identity8843 : scanCanonicalize (H12AffineFastState.compose env8843 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 38422) := by decide +kernel

theorem selectedBound8843 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38422,1345,262144,1025,32768,4096,4194304,5457,5906,8329,5377,4456708,4177,1297,4202141,1285,5609,256,4194896,1344,513]

theorem envBound8844 : H12AffineFastState.Bounded env8844 := by
  intro p hp
  have h : env8844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8843_8844 : H12AffineEnvironment.transform 15 38422 env8843 = env8844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38422 env8843 == env8844) = true)

theorem identity8844 : scanCanonicalize (H12AffineFastState.compose env8844 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound8844 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env8845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13973,8323,1345,262144,1025,13973,4096,4194304,5457,5906,8329,5377,4456708,4177,1297,4202141,1285,5609,256,4194896,1344,513]

theorem envBound8845 : H12AffineFastState.Bounded env8845 := by
  intro p hp
  have h : env8845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8844_8845 : H12AffineEnvironment.transform 14 13973 env8844 = env8845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env8844 == env8845) = true)

theorem identity8845 : scanCanonicalize (H12AffineFastState.compose env8845 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound8845 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,8192,1992,8460,8323,1345,262144,1025,8460,1945,4194304,712,139,8329,664,4456708,1992,1297,4196612,1285,624,256,4194896,1344,513]

theorem envBound8846 : H12AffineFastState.Bounded env8846 := by
  intro p hp
  have h : env8846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8845_8846 : H12AffineEnvironment.transform 11 1945 env8845 = env8846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env8845 == env8846) = true)

theorem identity8846 : scanCanonicalize (H12AffineFastState.compose env8846 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1670) := by decide +kernel

theorem selectedBound8846 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,8192,1992,8460,8323,1345,1670,1025,8460,1945,4194304,712,139,8329,664,4196226,1992,1297,4196612,1285,624,256,4194896,1344,513]

theorem envBound8847 : H12AffineFastState.Bounded env8847 := by
  intro p hp
  have h : env8847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8846_8847 : H12AffineEnvironment.transform 17 1670 env8846 = env8847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1670 env8846 == env8847) = true)

theorem identity8847 : scanCanonicalize (H12AffineFastState.compose env8847 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound8847 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1323,1945,8192,1992,8460,8323,1345,1670,1025,8460,1945,4194304,712,139,8329,664,4196226,1992,1297,4195375,1285,624,256,4194896,1344,513]

theorem envBound8848 : H12AffineFastState.Bounded env8848 := by
  intro p hp
  have h : env8848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8847_8848 : H12AffineEnvironment.transform 10 1323 env8847 = env8848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env8847 == env8848) = true)

theorem identity8848 : scanCanonicalize (H12AffineFastState.compose env8848 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 681) := by decide +kernel

theorem selectedBound8848 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1323,1945,8192,1992,8460,8323,1345,1670,1025,8460,1945,681,712,139,8329,664,1323,1992,1297,1670,1285,624,256,249,1344,513]

theorem envBound8849 : H12AffineFastState.Bounded env8849 := by
  intro p hp
  have h : env8849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8848_8849 : H12AffineEnvironment.transform 21 681 env8848 = env8849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 681 env8848 == env8849) = true)

theorem identity8849 : scanCanonicalize (H12AffineFastState.compose env8849 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound8849 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1323,1945,900,1992,648,775,1345,1670,1025,648,1945,681,712,139,781,664,1323,1992,1297,1670,1285,624,256,249,1344,513]

theorem envBound8850 : H12AffineFastState.Bounded env8850 := by
  intro p hp
  have h : env8850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8849_8850 : H12AffineEnvironment.transform 12 900 env8849 = env8850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env8849 == env8850) = true)

theorem identity8850 : scanCanonicalize (H12AffineFastState.compose env8850 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound8850 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8851 : List Nat := [2,4,8,16,32,64,128,256,48,1024,1323,1449,436,1528,184,311,1345,1206,1025,184,1449,153,248,139,317,168,1323,1528,1297,1206,1285,64,256,249,1344,49]

theorem envBound8851 : H12AffineFastState.Bounded env8851 := by
  intro p hp
  have h : env8851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8850_8851 : H12AffineEnvironment.transform 8 48 env8850 = env8851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env8850 == env8851) = true)

theorem identity8851 : scanCanonicalize (H12AffineFastState.compose env8851 (packedSelected [1,2,12] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound8851 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env8852 : List Nat := [2,4,8,16,32,64,128,252,48,1024,1239,1109,72,1028,184,203,1213,1206,1025,184,1109,153,248,139,193,168,1239,1028,1261,1206,1273,64,252,249,1212,49]

theorem envBound8852 : H12AffineFastState.Bounded env8852 := by
  intro p hp
  have h : env8852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8851_8852 : H12AffineEnvironment.transform 7 252 env8851 = env8852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env8851 == env8852) = true)

theorem identity8852 : scanCanonicalize (H12AffineFastState.compose env8852 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound8852 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8853 : List Nat := [2,4,8,16,32,64,128,252,48,156,75,201,72,152,184,203,33,42,157,184,201,153,248,139,193,168,75,152,113,42,101,64,252,249,32,49]

theorem envBound8853 : H12AffineFastState.Bounded env8853 := by
  intro p hp
  have h : env8853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8852_8853 : H12AffineEnvironment.transform 9 156 env8852 = env8853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env8852 == env8853) = true)

def env8854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,33554432,135233,21352528,148800,131152,1073741824,16876545,4294967296,256,4350177586,131073,33563272]

theorem envBound8854 : H12AffineFastState.Bounded env8854 := by
  intro p hp
  have h : env8854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8835_8854 : H12AffineEnvironment.transform 20 4097 env8835 = env8854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8835 == env8854) = true)

def env8855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,2228289,23445584,2250048,131153,1073741824,16876544,4294967296,257,4352270642,131073,33563272]

theorem envBound8855 : H12AffineFastState.Bounded env8855 := by
  intro p hp
  have h : env8855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8834_8855 : H12AffineEnvironment.transform 25 2228289 env8834 = env8855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2228289 env8834 == env8855) = true)

def env8856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,16777216,33554432,135233,21352528,148800,131153,1073741824,16876544,4294967296,257,4350177586,131073,33563272]

theorem envBound8856 : H12AffineFastState.Bounded env8856 := by
  intro p hp
  have h : env8856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8855_8856 : H12AffineEnvironment.transform 20 4096 env8855 = env8856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env8855 == env8856) = true)

theorem identity8856 : scanCanonicalize (H12AffineFastState.compose env8856 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound8856 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,98565,33554432,135233,4477269,148800,131153,1073741824,1285,4294967296,257,4333498423,131073,33563272]

theorem envBound8857 : H12AffineFastState.Bounded env8857 := by
  intro p hp
  have h : env8857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8856_8857 : H12AffineEnvironment.transform 23 98565 env8856 = env8857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env8856 == env8857) = true)

theorem identity8857 : scanCanonicalize (H12AffineFastState.compose env8857 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound8857 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,98565,33554432,5376,4477269,16385,1296,1073741824,1285,4294967296,257,4333368694,1344,33563272]

theorem envBound8858 : H12AffineFastState.Bounded env8858 := by
  intro p hp
  have h : env8858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8857_8858 : H12AffineEnvironment.transform 16 1345 env8857 = env8858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8857 == env8858) = true)

theorem identity8858 : scanCanonicalize (H12AffineFastState.compose env8858 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 63608) := by decide +kernel

theorem selectedBound8858 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,63608,524288,32768,4096,4194304,17664,98565,33554432,5376,4237613,16385,1296,1073741824,1285,4294967296,257,4333368694,1344,33563272]

theorem envBound8859 : H12AffineFastState.Bounded env8859 := by
  intro p hp
  have h : env8859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8858_8859 : H12AffineEnvironment.transform 17 63608 env8858 = env8859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63608 env8858 == env8859) = true)

theorem identity8859 : scanCanonicalize (H12AffineFastState.compose env8859 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(29+1) ^^^ 37779933) := by decide +kernel

theorem selectedBound8859 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env8860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,63608,524288,32768,4096,4194304,17664,98565,33554432,5376,4237613,16385,1296,37779933,1285,4294967296,257,4333368694,1344,33563272]

theorem envBound8860 : H12AffineFastState.Bounded env8860 := by
  intro p hp
  have h : env8860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8859_8860 : H12AffineEnvironment.transform 29 37779933 env8859 = env8860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 37779933 env8859 == env8860) = true)

def env8861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,43048,524288,32768,4096,4194304,5456,98565,33554432,5376,4237613,4177,1296,37759373,1285,4294967296,257,4333348134,1344,33563272]

theorem envBound8861 : H12AffineFastState.Bounded env8861 := by
  intro p hp
  have h : env8861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8860_8861 : H12AffineEnvironment.transform 13 4176 env8860 = env8861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8860 == env8861) = true)

theorem identity8861 : scanCanonicalize (H12AffineFastState.compose env8861 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound8861 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,43048,524288,32768,4096,4194304,5456,98565,8328,5376,4237613,4177,1296,4196613,1285,4294967296,257,4299785646,1344,512]

theorem envBound8862 : H12AffineFastState.Bounded env8862 := by
  intro p hp
  have h : env8862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8861_8862 : H12AffineEnvironment.transform 24 8328 env8861 = env8862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env8861 == env8862) = true)

theorem identity8862 : scanCanonicalize (H12AffineFastState.compose env8862 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound8862 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,138,1345,43048,524288,32768,4096,4194304,5456,33167,8328,5376,4237613,4177,1296,4196613,1285,4294967296,257,4299719972,1344,512]

theorem envBound8863 : H12AffineFastState.Bounded env8863 := by
  intro p hp
  have h : env8863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8862_8863 : H12AffineEnvironment.transform 15 138 env8862 = env8863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env8862 == env8863) = true)

theorem identity8863 : scanCanonicalize (H12AffineFastState.compose env8863 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound8863 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env8864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,138,1345,43048,524288,32768,4096,397,5456,33167,8328,5376,43168,4177,1296,2184,1285,4294967296,257,4295525545,1344,512]

theorem envBound8864 : H12AffineFastState.Bounded env8864 := by
  intro p hp
  have h : env8864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8863_8864 : H12AffineEnvironment.transform 21 397 env8863 = env8864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env8863 == env8864) = true)

theorem identity8864 : scanCanonicalize (H12AffineFastState.compose env8864 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 38377) := by decide +kernel

theorem selectedBound8864 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,138,1345,43048,524288,32768,4096,397,5456,33167,8328,5376,43168,4177,1296,2184,1285,38377,257,528704,1344,512]

theorem envBound8865 : H12AffineFastState.Bounded env8865 := by
  intro p hp
  have h : env8865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8864_8865 : H12AffineEnvironment.transform 31 38377 env8864 = env8865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 38377 env8864 == env8865) = true)

theorem identity8865 : scanCanonicalize (H12AffineFastState.compose env8865 (packedSelected [1,5,15,21] rootPS)) = affineNative (2^(18+1) ^^^ 32773) := by decide +kernel

theorem selectedBound8865 : packedSelected [1,5,15,21] rootPS < 2^1333 := by decide +kernel

def env8866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,138,1345,43048,32773,32768,4096,397,5456,33167,8328,5376,43168,4177,1296,2184,1285,38377,257,37189,1344,512]

theorem envBound8866 : H12AffineFastState.Bounded env8866 := by
  intro p hp
  have h : env8866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8865_8866 : H12AffineEnvironment.transform 18 32773 env8865 = env8866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 32773 env8865 == env8866) = true)

theorem identity8866 : scanCanonicalize (H12AffineFastState.compose env8866 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8866 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env8867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4176,32768,138,1345,34848,32773,32768,4096,397,5456,33167,128,5376,34984,4177,1296,2184,1285,38377,257,37189,1344,512]

theorem envBound8867 : H12AffineFastState.Bounded env8867 := by
  intro p hp
  have h : env8867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8866_8867 : H12AffineEnvironment.transform 12 8 env8866 = env8867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8866 == env8867) = true)

theorem identity8867 : scanCanonicalize (H12AffineFastState.compose env8867 (packedSelected [0,7,11,23] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound8867 : packedSelected [0,7,11,23] rootPS < 2^1333 := by decide +kernel

def env8868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4176,261,138,1345,2341,256,261,4096,397,5456,138,128,5376,2477,4177,1296,2184,1285,5356,257,4160,1344,512]

theorem envBound8868 : H12AffineFastState.Bounded env8868 := by
  intro p hp
  have h : env8868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8867_8868 : H12AffineEnvironment.transform 14 261 env8867 = env8868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env8867 == env8868) = true)

theorem identity8868 : scanCanonicalize (H12AffineFastState.compose env8868 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound8868 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env8869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,8,4176,261,138,1345,1923,256,261,4096,397,5456,138,128,5376,1803,4177,1296,1582,1285,5356,257,4160,1344,512]

theorem envBound8869 : H12AffineFastState.Bounded env8869 := by
  intro p hp
  have h : env8869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8868_8869 : H12AffineEnvironment.transform 10 1702 env8868 = env8869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env8868 == env8869) = true)

def env8870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1582,4096,8,4176,261,2,1345,1803,256,261,4096,261,5456,2,8,5376,1803,4177,1296,1582,1285,5220,257,4160,1344,512]

theorem envBound8870 : H12AffineFastState.Bounded env8870 := by
  intro p hp
  have h : env8870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8869_8870 : H12AffineEnvironment.transform 6 8 env8869 = env8870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8869 == env8870) = true)

theorem identity8870 : scanCanonicalize (H12AffineFastState.compose env8870 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 585) := by decide +kernel

theorem selectedBound8870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1582,585,8,537,261,2,1345,1803,256,261,585,261,1817,2,8,1865,1803,536,1296,1582,1285,1581,257,521,1344,512]

theorem envBound8871 : H12AffineFastState.Bounded env8871 := by
  intro p hp
  have h : env8871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8870_8871 : H12AffineEnvironment.transform 11 585 env8870 = env8871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 585 env8870 == env8871) = true)

theorem identity8871 : scanCanonicalize (H12AffineFastState.compose env8871 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound8871 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8872 : List Nat := [2,4,8,16,32,64,8,256,512,36,522,585,8,537,261,2,357,815,256,261,585,261,829,2,8,877,815,536,308,522,289,521,257,521,356,512]

theorem envBound8872 : H12AffineFastState.Bounded env8872 := by
  intro p hp
  have h : env8872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8871_8872 : H12AffineEnvironment.transform 9 36 env8871 = env8872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env8871 == env8872) = true)

theorem identity8872 : scanCanonicalize (H12AffineFastState.compose env8872 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 381) := by decide +kernel

theorem selectedBound8872 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8873 : List Nat := [2,4,8,16,32,64,8,256,381,36,375,308,8,356,261,2,357,82,256,261,308,261,64,2,8,16,82,357,308,375,289,372,257,372,356,381]

theorem envBound8873 : H12AffineFastState.Bounded env8873 := by
  intro p hp
  have h : env8873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8872_8873 : H12AffineEnvironment.transform 8 381 env8872 = env8873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 381 env8872 == env8873) = true)

theorem identity8873 : scanCanonicalize (H12AffineFastState.compose env8873 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 87) := by decide +kernel

theorem selectedBound8873 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8874 : List Nat := [2,4,8,16,32,64,8,87,42,36,32,99,8,51,82,2,50,82,87,82,99,82,64,2,8,16,82,50,99,32,118,35,86,35,51,42]

theorem envBound8874 : H12AffineFastState.Bounded env8874 := by
  intro p hp
  have h : env8874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8873_8874 : H12AffineEnvironment.transform 7 87 env8873 = env8874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 87 env8873 == env8874) = true)

def env8875 : List Nat := [2,4,8,16,32,16,8,7,42,36,32,51,8,51,2,2,50,2,7,2,51,2,16,2,8,16,2,50,51,32,38,35,6,35,51,42]

theorem envBound8875 : H12AffineFastState.Bounded env8875 := by
  intro p hp
  have h : env8875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8874_8875 : H12AffineEnvironment.transform 5 16 env8874 = env8875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8874 == env8875) = true)

theorem identity8875 : scanCanonicalize (H12AffineFastState.compose env8875 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound8875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8876 : List Nat := [2,4,8,16,8,16,8,7,2,12,8,27,8,27,2,2,26,2,7,2,27,2,16,2,8,16,2,26,27,8,14,11,6,11,27,2]

theorem envBound8876 : H12AffineFastState.Bounded env8876 := by
  intro p hp
  have h : env8876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8875_8876 : H12AffineEnvironment.transform 4 8 env8875 = env8876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env8875 == env8876) = true)

theorem identity8876 : scanCanonicalize (H12AffineFastState.compose env8876 (packedSelected [1,10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound8876 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env8877 : List Nat := [1,4,8,16,8,16,8,4,1,12,8,24,8,24,1,1,25,1,4,1,24,1,16,1,8,16,1,25,24,8,13,8,5,8,24,1]

theorem envBound8877 : H12AffineFastState.Bounded env8877 := by
  intro p hp
  have h : env8877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8876_8877 : H12AffineEnvironment.transform 0 1 env8876 = env8877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env8876 == env8877) = true)

theorem identity8877 : scanCanonicalize (H12AffineFastState.compose env8877 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound8877 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8878 : List Nat := [1,4,0,16,0,16,0,4,1,4,0,16,0,16,1,1,17,1,4,1,16,1,16,1,0,16,1,17,16,0,5,0,5,0,16,1]

theorem envBound8878 : H12AffineFastState.Bounded env8878 := by
  intro p hp
  have h : env8878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8877_8878 : H12AffineEnvironment.transform 2 0 env8877 = env8878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env8877 == env8878) = true)

def leafEnv8878 : List Nat := [1,4,0,16,0,16,0,4,1,4,0,16,0,16,1,1,17,1,4,1,16,1,16,1,5,0,1,16,1,17,16,0,5,0,5,0,5,1,16,1,0,16,1]

def active8878 : List Nat := [1,3]

def tree8878 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8878 : H12WitnessSearch.Good tree8878 := H12GlobalWitnessIndex.good

theorem leafIdentity8878 : H12AffineFastState.composeSystem env8878 rootObs = leafEnv8878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8878 rootObs == leafEnv8878) = true)

theorem terminalChecked8878 : H12PackedTerminal.terminalCheckFast leafEnv8878 active8878 tree8878 = true := by decide +kernel

def env8879 : List Nat := [2,4,8,16,32,17,8,6,42,36,32,50,8,51,3,2,50,3,6,3,50,3,17,2,8,16,3,50,50,32,39,35,7,35,51,42]

theorem envBound8879 : H12AffineFastState.Bounded env8879 := by
  intro p hp
  have h : env8879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8874_8879 : H12AffineEnvironment.transform 5 17 env8874 = env8879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8874 == env8879) = true)

theorem identity8879 : scanCanonicalize (H12AffineFastState.compose env8879 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8880 : List Nat := [2,4,2,16,32,17,2,6,32,36,32,50,2,51,3,2,50,3,6,3,50,3,17,2,2,16,3,50,50,32,39,35,7,35,51,32]

theorem envBound8880 : H12AffineFastState.Bounded env8880 := by
  intro p hp
  have h : env8880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8879_8880 : H12AffineEnvironment.transform 2 2 env8879 = env8880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8879 == env8880) = true)

theorem identity8880 : scanCanonicalize (H12AffineFastState.compose env8880 (packedSelected [1,10] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound8880 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env8881 : List Nat := [2,4,2,16,3,17,2,6,3,7,3,17,2,16,3,2,17,3,6,3,17,3,17,2,2,16,3,17,17,3,4,0,7,0,16,3]

theorem envBound8881 : H12AffineFastState.Bounded env8881 := by
  intro p hp
  have h : env8881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8880_8881 : H12AffineEnvironment.transform 4 3 env8880 = env8881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env8880 == env8881) = true)

def leafEnv8881 : List Nat := [2,4,2,16,3,17,2,6,3,7,3,17,2,16,3,2,17,3,6,3,17,3,17,2,5,2,1,16,3,17,17,3,4,0,7,0,5,2,16,3,0,17,1]

def active8881 : List Nat := [0,1,3]

def tree8881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8881 : H12WitnessSearch.Good tree8881 := H12GlobalWitnessIndex.good

theorem leafIdentity8881 : H12AffineFastState.composeSystem env8881 rootObs = leafEnv8881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8881 rootObs == leafEnv8881) = true)

theorem terminalChecked8881 : H12PackedTerminal.terminalCheckFast leafEnv8881 active8881 tree8881 = true := by decide +kernel

def env8882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1583,4096,8,4176,261,3,1345,1802,256,261,4096,260,5456,3,9,5376,1803,4177,1296,1582,1285,5221,257,4160,1344,512]

theorem envBound8882 : H12AffineFastState.Bounded env8882 := by
  intro p hp
  have h : env8882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8869_8882 : H12AffineEnvironment.transform 6 9 env8869 = env8882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8869 == env8882) = true)

theorem identity8882 : scanCanonicalize (H12AffineFastState.compose env8882 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1378) := by decide +kernel

theorem selectedBound8882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1583,1378,8,1330,261,3,1345,1802,256,261,1378,260,50,3,9,98,1803,1331,1296,1582,1285,263,257,1314,1344,512]

theorem envBound8883 : H12AffineFastState.Bounded env8883 := by
  intro p hp
  have h : env8883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8882_8883 : H12AffineEnvironment.transform 11 1378 env8882 = env8883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1378 env8882 == env8883) = true)

theorem identity8883 : scanCanonicalize (H12AffineFastState.compose env8883 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 86) := by decide +kernel

theorem selectedBound8883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8884 : List Nat := [2,4,8,16,32,64,9,86,512,1024,1583,1076,8,1124,83,3,1047,1628,86,83,1076,82,50,3,9,98,1629,1125,1094,1582,1107,81,87,1140,1046,512]

theorem envBound8884 : H12AffineFastState.Bounded env8884 := by
  intro p hp
  have h : env8884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8883_8884 : H12AffineEnvironment.transform 7 86 env8883 = env8884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 86 env8883 == env8884) = true)

def env8885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,43049,524288,32768,4096,4194304,5457,98565,33554432,5376,4237613,4176,1296,37759372,1285,4294967296,257,4333348135,1344,33563272]

theorem envBound8885 : H12AffineFastState.Bounded env8885 := by
  intro p hp
  have h : env8885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8860_8885 : H12AffineEnvironment.transform 13 4177 env8860 = env8885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env8860 == env8885) = true)

theorem identity8885 : scanCanonicalize (H12AffineFastState.compose env8885 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8885 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8886 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,43049,524288,32768,4096,4194304,5457,98565,33554432,5376,4237613,4176,1296,37759372,1285,4294967296,257,4333348135,1344,33562625]

theorem envBound8886 : H12AffineFastState.Bounded env8886 := by
  intro p hp
  have h : env8886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8885_8886 : H12AffineEnvironment.transform 8 137 env8885 = env8886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8885 == env8886) = true)

theorem identity8886 : scanCanonicalize (H12AffineFastState.compose env8886 (packedSelected [1,3,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound8886 : packedSelected [1,3,10,19] rootPS < 2^1333 := by decide +kernel

def env8887 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,43049,524288,32768,4096,4194304,5457,98565,8329,5376,4237613,4176,1296,4196613,1285,4294967296,257,4299785646,1344,136]

theorem envBound8887 : H12AffineFastState.Bounded env8887 := by
  intro p hp
  have h : env8887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8886_8887 : H12AffineEnvironment.transform 24 8329 env8886 = env8887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env8886 == env8887) = true)

theorem identity8887 : scanCanonicalize (H12AffineFastState.compose env8887 (packedSelected [5,8] rootPS)) = affineNative (2^(18+1) ^^^ 99726) := by decide +kernel

theorem selectedBound8887 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8888 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,43049,99726,32768,4096,4194304,5457,98565,8329,5376,4237613,4176,1296,4196613,1285,4294967296,257,4299161632,1344,136]

theorem envBound8888 : H12AffineFastState.Bounded env8888 := by
  intro p hp
  have h : env8888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8887_8888 : H12AffineEnvironment.transform 18 99726 env8887 = env8888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99726 env8887 == env8888) = true)

def env8889 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,43049,99726,32768,4096,10248,5457,98565,8329,5376,33061,4176,1296,8461,1285,4294967296,257,4294977576,1344,136]

theorem envBound8889 : H12AffineFastState.Bounded env8889 := by
  intro p hp
  have h : env8889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8888_8889 : H12AffineEnvironment.transform 21 10248 env8888 = env8889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env8888 == env8889) = true)

theorem identity8889 : scanCanonicalize (H12AffineFastState.compose env8889 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound8889 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8890 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,2316,4177,32768,65536,1345,33061,99726,32768,4096,260,5457,98565,2437,5376,33061,4176,1296,2049,1285,4294967296,257,4294967588,1344,136]

theorem envBound8890 : H12AffineFastState.Bounded env8890 := by
  intro p hp
  have h : env8890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8889_8890 : H12AffineEnvironment.transform 12 2316 env8889 = env8890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env8889 == env8890) = true)

theorem identity8890 : scanCanonicalize (H12AffineFastState.compose env8890 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound8890 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8891 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2316,1344,32768,65536,1345,33061,99726,32768,1297,260,64,98565,2437,17,33061,1345,1296,2049,1285,4294967296,257,4294967588,1344,136]

theorem envBound8891 : H12AffineFastState.Bounded env8891 := by
  intro p hp
  have h : env8891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8890_8891 : H12AffineEnvironment.transform 11 1297 env8890 = env8891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8890 == env8891) = true)

theorem identity8891 : scanCanonicalize (H12AffineFastState.compose env8891 (packedSelected [2,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8891 : packedSelected [2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env8892 : List Nat := [2,4,8,16,32,64,128,36,137,1024,2048,1077,2088,1124,32768,65536,1125,32769,99498,32768,1077,32,64,98337,2209,17,32769,1125,1076,2049,1057,4294967296,37,4294967296,1124,136]

theorem envBound8892 : H12AffineFastState.Bounded env8892 := by
  intro p hp
  have h : env8892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8891_8892 : H12AffineEnvironment.transform 7 36 env8891 = env8892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8891 == env8892) = true)

theorem identity8892 : scanCanonicalize (H12AffineFastState.compose env8892 (packedSelected [1,3,4] rootPS)) = affineNative (2^(31+1) ^^^ 35001) := by decide +kernel

theorem selectedBound8892 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env8893 : List Nat := [2,4,8,16,32,64,128,36,137,1024,2048,1077,2088,1124,32768,65536,1125,32769,99498,32768,1077,32,64,98337,2209,17,32769,1125,1076,2049,1057,35001,37,35001,1124,136]

theorem envBound8893 : H12AffineFastState.Bounded env8893 := by
  intro p hp
  have h : env8893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8892_8893 : H12AffineEnvironment.transform 31 35001 env8892 = env8893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 35001 env8892 == env8893) = true)

theorem identity8893 : scanCanonicalize (H12AffineFastState.compose env8893 (packedSelected [1,3,12] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound8893 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env8894 : List Nat := [2,4,8,16,32,64,128,36,137,1024,2048,1077,2088,1124,2048,65536,1125,2049,68778,2048,1077,32,64,67617,2209,17,2049,1125,1076,2049,1057,185,37,185,1124,136]

theorem envBound8894 : H12AffineFastState.Bounded env8894 := by
  intro p hp
  have h : env8894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8893_8894 : H12AffineEnvironment.transform 14 2048 env8893 = env8894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env8893 == env8894) = true)

def env8895 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1077,40,1124,0,65536,1125,1,66730,0,1077,32,64,65569,161,17,1,1125,1076,1,1057,185,37,185,1124,136]

theorem envBound8895 : H12AffineFastState.Bounded env8895 := by
  intro p hp
  have h : env8895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8894_8895 : H12AffineEnvironment.transform 10 0 env8894 = env8895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8894 == env8895) = true)

theorem identity8895 : scanCanonicalize (H12AffineFastState.compose env8895 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 224) := by decide +kernel

theorem selectedBound8895 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8896 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1077,40,1124,0,224,1125,1,1098,0,1077,32,64,193,161,17,1,1125,1076,1,1057,185,37,185,1124,136]

theorem envBound8896 : H12AffineFastState.Bounded env8896 := by
  intro p hp
  have h : env8896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8895_8896 : H12AffineEnvironment.transform 15 224 env8895 = env8896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 224 env8895 == env8896) = true)

theorem identity8896 : scanCanonicalize (H12AffineFastState.compose env8896 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8896 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env8897 : List Nat := [2,4,8,16,32,10,128,36,137,1024,0,1077,40,1070,0,170,1071,1,1024,0,1077,32,10,139,161,17,1,1071,1076,1,1057,185,37,185,1070,136]

theorem envBound8897 : H12AffineFastState.Bounded env8897 := by
  intro p hp
  have h : env8897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8896_8897 : H12AffineEnvironment.transform 5 10 env8896 = env8897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8896 == env8897) = true)

theorem identity8897 : scanCanonicalize (H12AffineFastState.compose env8897 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8898 : List Nat := [2,4,8,16,32,10,19,36,26,1024,0,1077,40,1070,0,57,1071,1,1024,0,1077,32,10,24,50,17,1,1071,1076,1,1057,42,37,42,1070,27]

theorem envBound8898 : H12AffineFastState.Bounded env8898 := by
  intro p hp
  have h : env8898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8897_8898 : H12AffineEnvironment.transform 6 19 env8897 = env8898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8897 == env8898) = true)

def leafEnv8898 : List Nat := [2,4,8,16,32,10,19,36,26,1024,0,1077,40,1070,0,57,1071,1,1024,0,1077,32,10,24,1057,50,1,17,1,1071,1076,1,1057,42,37,42,5,34,1070,27,0,1076,1]

def active8898 : List Nat := [0,1,2,3,4,9]

def tree8898 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8898 : H12WitnessSearch.Good tree8898 := H12GlobalWitnessIndex.good

theorem leafIdentity8898 : H12AffineFastState.composeSystem env8898 rootObs = leafEnv8898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8898 rootObs == leafEnv8898) = true)

theorem terminalChecked8898 : H12PackedTerminal.terminalCheckFast leafEnv8898 active8898 tree8898 = true := by decide +kernel

def env8899 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1077,41,1124,1,65536,1125,0,66731,1,1077,32,64,65568,160,17,0,1125,1076,0,1057,185,37,185,1124,136]

theorem envBound8899 : H12AffineFastState.Bounded env8899 := by
  intro p hp
  have h : env8899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8894_8899 : H12AffineEnvironment.transform 10 1 env8894 = env8899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8894 == env8899) = true)

theorem identity8899 : scanCanonicalize (H12AffineFastState.compose env8899 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8900 : List Nat := [2,4,8,16,32,10,128,36,137,1024,1,1077,41,1070,1,65536,1071,0,66731,1,1077,32,10,65568,160,17,0,1071,1076,0,1057,185,37,185,1070,136]

theorem envBound8900 : H12AffineFastState.Bounded env8900 := by
  intro p hp
  have h : env8900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8899_8900 : H12AffineEnvironment.transform 5 10 env8899 = env8900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8899 == env8900) = true)

def env8901 : List Nat := [2,4,8,16,0,10,128,4,137,1024,1,1045,9,1038,1,65536,1039,0,66699,1,1045,0,10,65536,128,17,0,1039,1044,0,1025,153,5,153,1038,136]

theorem envBound8901 : H12AffineFastState.Bounded env8901 := by
  intro p hp
  have h : env8901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8900_8901 : H12AffineEnvironment.transform 4 0 env8900 = env8901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8900 == env8901) = true)

theorem identity8901 : scanCanonicalize (H12AffineFastState.compose env8901 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 24) := by decide +kernel

theorem selectedBound8901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8902 : List Nat := [2,4,8,16,0,10,128,4,137,1024,1,1045,9,1038,1,24,1039,0,1171,1,1045,0,10,24,128,17,0,1039,1044,0,1025,153,5,153,1038,136]

theorem envBound8902 : H12AffineFastState.Bounded env8902 := by
  intro p hp
  have h : env8902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8901_8902 : H12AffineEnvironment.transform 15 24 env8901 = env8902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env8901 == env8902) = true)

def leafEnv8902 : List Nat := [2,4,8,16,0,10,128,4,137,1024,1,1045,9,1038,1,24,1039,0,1171,1,1045,0,10,24,1170,128,1,17,0,1039,1044,0,1025,153,5,153,5,3,1038,136,0,1044,1]

def active8902 : List Nat := [0,1,2,3,6,9]

def tree8902 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8902 : H12WitnessSearch.Good tree8902 := H12GlobalWitnessIndex.good

theorem leafIdentity8902 : H12AffineFastState.composeSystem env8902 rootObs = leafEnv8902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8902 rootObs == leafEnv8902) = true)

theorem terminalChecked8902 : H12PackedTerminal.terminalCheckFast leafEnv8902 active8902 tree8902 = true := by decide +kernel

def env8903 : List Nat := [2,4,8,16,1,10,128,5,137,1024,1,1044,8,1039,1,65536,1038,0,66698,1,1044,1,10,65537,129,17,0,1038,1045,0,1024,152,4,152,1039,136]

theorem envBound8903 : H12AffineFastState.Bounded env8903 := by
  intro p hp
  have h : env8903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8900_8903 : H12AffineEnvironment.transform 4 1 env8900 = env8903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8900 == env8903) = true)

theorem identity8903 : scanCanonicalize (H12AffineFastState.compose env8903 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound8903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8904 : List Nat := [2,4,8,16,1,10,19,5,26,1024,1,1044,8,1039,1,65536,1038,0,66585,1,1044,1,10,65537,18,17,0,1038,1045,0,1024,11,4,11,1039,27]

theorem envBound8904 : H12AffineFastState.Bounded env8904 := by
  intro p hp
  have h : env8904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8903_8904 : H12AffineEnvironment.transform 6 19 env8903 = env8904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env8903 == env8904) = true)

theorem identity8904 : scanCanonicalize (H12AffineFastState.compose env8904 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 25) := by decide +kernel

theorem selectedBound8904 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8905 : List Nat := [2,4,8,16,1,10,19,5,26,1024,1,1044,8,1039,1,25,1038,0,1024,1,1044,1,10,24,18,17,0,1038,1045,0,1024,11,4,11,1039,27]

theorem envBound8905 : H12AffineFastState.Bounded env8905 := by
  intro p hp
  have h : env8905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8904_8905 : H12AffineEnvironment.transform 15 25 env8904 = env8905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env8904 == env8905) = true)

def leafEnv8905 : List Nat := [2,4,8,16,1,10,19,5,26,1024,1,1044,8,1039,1,25,1038,0,1024,1,1044,1,10,24,1024,18,1,17,0,1038,1045,0,1024,11,4,11,5,2,1039,27,0,1045,1]

def active8905 : List Nat := [0,1,2,3,9]

def tree8905 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8905 : H12WitnessSearch.Good tree8905 := H12GlobalWitnessIndex.good

theorem leafIdentity8905 : H12AffineFastState.composeSystem env8905 rootObs = leafEnv8905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8905 rootObs == leafEnv8905) = true)

theorem terminalChecked8905 : H12PackedTerminal.terminalCheckFast leafEnv8905 active8905 tree8905 = true := by decide +kernel

def env8906 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,43049,99726,32768,4096,10249,5457,98565,8329,5376,33060,4176,1296,8460,1285,4294967296,257,4294977577,1344,136]

theorem envBound8906 : H12AffineFastState.Bounded env8906 := by
  intro p hp
  have h : env8906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8888_8906 : H12AffineEnvironment.transform 21 10249 env8888 = env8906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env8888 == env8906) = true)

theorem identity8906 : scanCanonicalize (H12AffineFastState.compose env8906 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound8906 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8907 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8233,65536,1345,2048,75175,8233,4096,10249,5457,74028,8329,5376,8461,4176,1296,8460,1285,4294967296,257,4294977577,1344,136]

theorem envBound8907 : H12AffineFastState.Bounded env8907 := by
  intro p hp
  have h : env8907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8906_8907 : H12AffineEnvironment.transform 14 8233 env8906 = env8907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env8906 == env8907) = true)

theorem identity8907 : scanCanonicalize (H12AffineFastState.compose env8907 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound8907 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8908 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1345,8233,65536,1345,2048,75175,8233,1296,10249,65,74028,8329,16,8461,1344,1296,8460,1285,4294967296,257,4294977577,1344,136]

theorem envBound8908 : H12AffineFastState.Bounded env8908 := by
  intro p hp
  have h : env8908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8907_8908 : H12AffineEnvironment.transform 11 1296 env8907 = env8908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env8907 == env8908) = true)

theorem identity8908 : scanCanonicalize (H12AffineFastState.compose env8908 (packedSelected [1,2,3,4,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound8908 : packedSelected [1,2,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env8909 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2089,1345,2048,65536,1345,2048,69006,2048,1296,32,65,67845,2208,16,2340,1344,1296,2341,1285,4294967296,257,4294967296,1344,136]

theorem envBound8909 : H12AffineFastState.Bounded env8909 := by
  intro p hp
  have h : env8909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8908_8909 : H12AffineEnvironment.transform 12 2089 env8908 = env8909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env8908 == env8909) = true)

theorem identity8909 : scanCanonicalize (H12AffineFastState.compose env8909 (packedSelected [2,5] rootPS)) = affineNative (2^(31+1) ^^^ 232) := by decide +kernel

theorem selectedBound8909 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env8910 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2089,1345,2048,65536,1345,2048,69006,2048,1296,32,65,67845,2208,16,2340,1344,1296,2341,1285,232,257,232,1344,136]

theorem envBound8910 : H12AffineFastState.Bounded env8910 := by
  intro p hp
  have h : env8910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8909_8910 : H12AffineEnvironment.transform 31 232 env8909 = env8910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 232 env8909 == env8910) = true)

theorem identity8910 : scanCanonicalize (H12AffineFastState.compose env8910 (packedSelected [1,2,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8910 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env8911 : List Nat := [2,4,8,16,32,64,128,36,137,1024,2048,1076,2089,1125,2048,65536,1125,2048,68778,2048,1076,32,65,67617,2208,16,2048,1124,1076,2049,1057,232,37,232,1124,136]

theorem envBound8911 : H12AffineFastState.Bounded env8911 := by
  intro p hp
  have h : env8911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8910_8911 : H12AffineEnvironment.transform 7 36 env8910 = env8911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8910 == env8911) = true)

def env8912 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1076,41,1125,0,65536,1125,0,66730,0,1076,32,65,65569,160,16,0,1124,1076,1,1057,232,37,232,1124,136]

theorem envBound8912 : H12AffineFastState.Bounded env8912 := by
  intro p hp
  have h : env8912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8911_8912 : H12AffineEnvironment.transform 10 0 env8911 = env8912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8911 == env8912) = true)

theorem identity8912 : scanCanonicalize (H12AffineFastState.compose env8912 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound8912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8913 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1076,41,1125,0,56,1125,0,1170,0,1076,32,65,25,160,16,0,1124,1076,1,1057,232,37,232,1124,136]

theorem envBound8913 : H12AffineFastState.Bounded env8913 := by
  intro p hp
  have h : env8913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8912_8913 : H12AffineEnvironment.transform 15 56 env8912 = env8913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env8912 == env8913) = true)

theorem identity8913 : scanCanonicalize (H12AffineFastState.compose env8913 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8913 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env8914 : List Nat := [2,4,8,16,32,64,18,36,27,1024,0,1076,41,1125,0,56,1125,0,1024,0,1076,32,65,25,50,16,0,1124,1076,1,1057,122,37,122,1124,26]

theorem envBound8914 : H12AffineFastState.Bounded env8914 := by
  intro p hp
  have h : env8914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8913_8914 : H12AffineEnvironment.transform 6 18 env8913 = env8914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8913 == env8914) = true)

theorem identity8914 : scanCanonicalize (H12AffineFastState.compose env8914 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8915 : List Nat := [2,4,8,16,32,11,18,36,27,1024,0,1076,41,1070,0,56,1070,0,1024,0,1076,32,10,25,50,16,0,1071,1076,1,1057,49,37,49,1071,26]

theorem envBound8915 : H12AffineFastState.Bounded env8915 := by
  intro p hp
  have h : env8915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8914_8915 : H12AffineEnvironment.transform 5 11 env8914 = env8915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8914 == env8915) = true)

def leafEnv8915 : List Nat := [2,4,8,16,32,11,18,36,27,1024,0,1076,41,1070,0,56,1070,0,1024,0,1076,32,10,25,1057,50,1,16,0,1071,1076,1,1057,49,37,49,5,34,1071,26,0,1076,1]

def active8915 : List Nat := [0,1,2,3,4,9]

def tree8915 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8915 : H12WitnessSearch.Good tree8915 := H12GlobalWitnessIndex.good

theorem leafIdentity8915 : H12AffineFastState.composeSystem env8915 rootObs = leafEnv8915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8915 rootObs == leafEnv8915) = true)

theorem terminalChecked8915 : H12PackedTerminal.terminalCheckFast leafEnv8915 active8915 tree8915 = true := by decide +kernel

def env8916 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,40,1125,1,65536,1125,1,66731,1,1076,32,65,65568,161,16,1,1124,1076,0,1057,232,37,232,1124,136]

theorem envBound8916 : H12AffineFastState.Bounded env8916 := by
  intro p hp
  have h : env8916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8911_8916 : H12AffineEnvironment.transform 10 1 env8911 = env8916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8911 == env8916) = true)

theorem identity8916 : scanCanonicalize (H12AffineFastState.compose env8916 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8917 : List Nat := [2,4,8,16,32,64,18,36,27,1024,1,1076,40,1125,1,65536,1125,1,66617,1,1076,32,65,65568,51,16,1,1124,1076,0,1057,122,37,122,1124,26]

theorem envBound8917 : H12AffineFastState.Bounded env8917 := by
  intro p hp
  have h : env8917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8916_8917 : H12AffineEnvironment.transform 6 18 env8916 = env8917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8916 == env8917) = true)

def env8918 : List Nat := [2,4,8,16,32,64,18,36,27,1024,1,1076,40,1125,1,56,1125,1,1025,1,1076,32,65,24,51,16,1,1124,1076,0,1057,122,37,122,1124,26]

theorem envBound8918 : H12AffineFastState.Bounded env8918 := by
  intro p hp
  have h : env8918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8917_8918 : H12AffineEnvironment.transform 15 56 env8917 = env8918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env8917 == env8918) = true)

theorem identity8918 : scanCanonicalize (H12AffineFastState.compose env8918 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8919 : List Nat := [2,4,8,16,0,64,18,4,27,1024,1,1044,8,1093,1,24,1093,1,1025,1,1044,0,65,24,19,16,1,1092,1044,0,1025,90,5,90,1092,26]

theorem envBound8919 : H12AffineFastState.Bounded env8919 := by
  intro p hp
  have h : env8919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8918_8919 : H12AffineEnvironment.transform 4 0 env8918 = env8919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8918 == env8919) = true)

theorem identity8919 : scanCanonicalize (H12AffineFastState.compose env8919 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8919 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8920 : List Nat := [2,4,8,16,0,10,18,4,27,1024,1,1044,8,1039,1,24,1039,1,1025,1,1044,0,11,24,19,16,1,1038,1044,0,1025,16,5,16,1038,26]

theorem envBound8920 : H12AffineFastState.Bounded env8920 := by
  intro p hp
  have h : env8920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8919_8920 : H12AffineEnvironment.transform 5 10 env8919 = env8920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8919 == env8920) = true)

def leafEnv8920 : List Nat := [2,4,8,16,0,10,18,4,27,1024,1,1044,8,1039,1,24,1039,1,1025,1,1044,0,11,24,1024,19,1,16,1,1038,1044,0,1025,16,5,16,5,3,1038,26,0,1044,1]

def active8920 : List Nat := [0,1,2,3,9]

def tree8920 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8920 : H12WitnessSearch.Good tree8920 := H12GlobalWitnessIndex.good

theorem leafIdentity8920 : H12AffineFastState.composeSystem env8920 rootObs = leafEnv8920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8920 rootObs == leafEnv8920) = true)

theorem terminalChecked8920 : H12PackedTerminal.terminalCheckFast leafEnv8920 active8920 tree8920 = true := by decide +kernel

def env8921 : List Nat := [2,4,8,16,32,64,18,36,27,1024,1,1076,40,1125,1,57,1125,1,1024,1,1076,32,65,25,51,16,1,1124,1076,0,1057,122,37,122,1124,26]

theorem envBound8921 : H12AffineFastState.Bounded env8921 := by
  intro p hp
  have h : env8921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8917_8921 : H12AffineEnvironment.transform 15 57 env8917 = env8921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 57 env8917 == env8921) = true)

theorem identity8921 : scanCanonicalize (H12AffineFastState.compose env8921 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8922 : List Nat := [2,4,8,16,32,11,18,36,27,1024,1,1076,40,1070,1,57,1070,1,1024,1,1076,32,10,25,51,16,1,1071,1076,0,1057,49,37,49,1071,26]

theorem envBound8922 : H12AffineFastState.Bounded env8922 := by
  intro p hp
  have h : env8922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8921_8922 : H12AffineEnvironment.transform 5 11 env8921 = env8922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8921 == env8922) = true)

def leafEnv8922 : List Nat := [2,4,8,16,32,11,18,36,27,1024,1,1076,40,1070,1,57,1070,1,1024,1,1076,32,10,25,1057,51,1,16,1,1071,1076,0,1057,49,37,49,5,35,1071,26,0,1076,1]

def active8922 : List Nat := [0,1,2,3,4,9]

def tree8922 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8922 : H12WitnessSearch.Good tree8922 := H12GlobalWitnessIndex.good

theorem leafIdentity8922 : H12AffineFastState.composeSystem env8922 rootObs = leafEnv8922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8922 rootObs == leafEnv8922) = true)

theorem terminalChecked8922 : H12PackedTerminal.terminalCheckFast leafEnv8922 active8922 tree8922 = true := by decide +kernel

def env8923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,33554432,135232,21352529,148801,131153,1073741824,16876544,4294967296,257,4350177587,131073,33563272]

theorem envBound8923 : H12AffineFastState.Bounded env8923 := by
  intro p hp
  have h : env8923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8855_8923 : H12AffineEnvironment.transform 20 4097 env8855 = env8923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8855 == env8923) = true)

theorem identity8923 : scanCanonicalize (H12AffineFastState.compose env8923 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound8923 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,230468,33554432,135232,4609045,148801,131153,1073741824,131140,4294967296,257,4333368695,131073,33563272]

theorem envBound8924 : H12AffineFastState.Bounded env8924 := by
  intro p hp
  have h : env8924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8923_8924 : H12AffineEnvironment.transform 23 230468 env8923 = env8924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env8923 == env8924) = true)

theorem identity8924 : scanCanonicalize (H12AffineFastState.compose env8924 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 684441) := by decide +kernel

theorem selectedBound8924 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,230468,684441,135232,4609045,148801,131153,1073741824,131140,4294967296,257,4299392238,131073,676625]

theorem envBound8925 : H12AffineFastState.Bounded env8925 := by
  intro p hp
  have h : env8925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8924_8925 : H12AffineEnvironment.transform 24 684441 env8924 = env8925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 684441 env8924 == env8925) = true)

def env8926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4097,4194304,5456,230468,664009,135232,4588613,136465,131153,1073741824,131140,4294967296,257,4299392238,131073,656193]

theorem envBound8926 : H12AffineFastState.Bounded env8926 := by
  intro p hp
  have h : env8926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8925_8926 : H12AffineEnvironment.transform 13 4176 env8925 = env8926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8925 == env8926) = true)

theorem identity8926 : scanCanonicalize (H12AffineFastState.compose env8926 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 4950474) := by decide +kernel

theorem selectedBound8926 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4097,4194304,5456,230468,664009,135232,4588613,136465,131153,4950474,131140,4294967296,257,4299392238,131073,656193]

theorem envBound8927 : H12AffineFastState.Bounded env8927 := by
  intro p hp
  have h : env8927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8926_8927 : H12AffineEnvironment.transform 29 4950474 env8926 = env8927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4950474 env8926 == env8927) = true)

theorem identity8927 : scanCanonicalize (H12AffineFastState.compose env8927 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound8927 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env8928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,524288,32768,4097,4194304,5456,98564,533641,5376,4456709,4177,1297,4820106,1284,4294967296,257,4299260334,1345,525825]

theorem envBound8928 : H12AffineFastState.Bounded env8928 := by
  intro p hp
  have h : env8928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8927_8928 : H12AffineEnvironment.transform 16 1344 env8927 = env8928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8927 == env8928) = true)

theorem identity8928 : scanCanonicalize (H12AffineFastState.compose env8928 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 305964) := by decide +kernel

theorem selectedBound8928 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,524288,32768,4097,305964,5456,98564,533641,5376,43561,4177,1297,862118,1284,4294967296,257,4295305858,1345,525825]

theorem envBound8929 : H12AffineFastState.Bounded env8929 := by
  intro p hp
  have h : env8929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8928_8929 : H12AffineEnvironment.transform 21 305964 env8928 = env8929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305964 env8928 == env8929) = true)

theorem identity8929 : scanCanonicalize (H12AffineFastState.compose env8929 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8929 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32768,4097,305964,5456,98564,8329,5376,43561,4177,1297,336806,1284,4294967296,257,4295305858,1345,513]

theorem envBound8930 : H12AffineFastState.Bounded env8930 := by
  intro p hp
  have h : env8930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8929_8930 : H12AffineEnvironment.transform 18 1024 env8929 = env8930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8929 == env8930) = true)

theorem identity8930 : scanCanonicalize (H12AffineFastState.compose env8930 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33530) := by decide +kernel

theorem selectedBound8930 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33530,1344,262144,1024,32768,4097,305964,5456,1022,8329,5376,43561,4177,1297,303452,1284,4294967296,257,4295272568,1345,513]

theorem envBound8931 : H12AffineFastState.Bounded env8931 := by
  intro p hp
  have h : env8931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8930_8931 : H12AffineEnvironment.transform 15 33530 env8930 = env8931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33530 env8930 == env8931) = true)

theorem identity8931 : scanCanonicalize (H12AffineFastState.compose env8931 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 15420) := by decide +kernel

theorem selectedBound8931 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33530,1344,262144,1024,32768,4097,305964,5456,1022,8329,5376,43561,4177,1297,303452,1284,15420,257,300100,1345,513]

theorem envBound8932 : H12AffineFastState.Bounded env8932 := by
  intro p hp
  have h : env8932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8931_8932 : H12AffineEnvironment.transform 31 15420 env8931 = env8932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 15420 env8931 == env8932) = true)

theorem identity8932 : scanCanonicalize (H12AffineFastState.compose env8932 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound8932 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8933 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,4096,8192,4176,32768,32803,1344,262144,1024,32768,4097,305653,5456,295,8329,5376,43248,4177,1297,303452,1284,15420,257,300100,1345,216]

theorem envBound8933 : H12AffineFastState.Bounded env8933 := by
  intro p hp
  have h : env8933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8932_8933 : H12AffineEnvironment.transform 8 217 env8932 = env8933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8932 == env8933) = true)

theorem identity8933 : scanCanonicalize (H12AffineFastState.compose env8933 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 7269) := by decide +kernel

theorem selectedBound8933 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8934 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,4096,8192,4176,7269,7238,1344,262144,1024,7269,4097,275856,5456,295,8329,5376,13461,4177,1297,277817,1284,15420,257,264225,1345,216]

theorem envBound8934 : H12AffineFastState.Bounded env8934 := by
  intro p hp
  have h : env8934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8933_8934 : H12AffineEnvironment.transform 14 7269 env8933 = env8934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7269 env8933 == env8934) = true)

def env8935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,230468,664008,135232,4588612,136464,131153,1073741824,131140,4294967296,257,4299392238,131073,656192]

theorem envBound8935 : H12AffineFastState.Bounded env8935 := by
  intro p hp
  have h : env8935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8925_8935 : H12AffineEnvironment.transform 13 4177 env8925 = env8935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env8925 == env8935) = true)

theorem identity8935 : scanCanonicalize (H12AffineFastState.compose env8935 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 4427211) := by decide +kernel

theorem selectedBound8935 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,230468,664008,135232,4588612,136464,131153,4427211,131140,4294967296,257,4299392238,131073,656192]

theorem envBound8936 : H12AffineFastState.Bounded env8936 := by
  intro p hp
  have h : env8936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8935_8936 : H12AffineEnvironment.transform 29 4427211 env8935 = env8936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4427211 env8935 == env8936) = true)

theorem identity8936 : scanCanonicalize (H12AffineFastState.compose env8936 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound8936 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,524288,32768,4097,4194304,5457,98565,533641,5377,4456709,4177,1296,4294794,1285,4294967296,257,4299260335,1344,525825]

theorem envBound8937 : H12AffineFastState.Bounded env8937 := by
  intro p hp
  have h : env8937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8936_8937 : H12AffineEnvironment.transform 16 1345 env8936 = env8937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8936 == env8937) = true)

theorem identity8937 : scanCanonicalize (H12AffineFastState.compose env8937 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 863275) := by decide +kernel

theorem selectedBound8937 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,524288,32768,4097,863275,5457,98565,533641,5377,601390,4177,1296,828577,1285,4294967296,257,4295798148,1344,525825]

theorem envBound8938 : H12AffineFastState.Bounded env8938 := by
  intro p hp
  have h : env8938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8937_8938 : H12AffineEnvironment.transform 21 863275 env8937 = env8938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 863275 env8937 == env8938) = true)

theorem identity8938 : scanCanonicalize (H12AffineFastState.compose env8938 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS)) = affineNative (2^(18+1) ^^^ 363691) := by decide +kernel

theorem selectedBound8938 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env8939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,363691,32768,4097,41088,5457,98565,370722,5377,303493,4177,1296,75786,1285,4294967296,257,4295041327,1344,363178]

theorem envBound8939 : H12AffineFastState.Bounded env8939 := by
  intro p hp
  have h : env8939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8938_8939 : H12AffineEnvironment.transform 18 363691 env8938 = env8939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 363691 env8938 == env8939) = true)

theorem identity8939 : scanCanonicalize (H12AffineFastState.compose env8939 (packedSelected [1,3,4,5,8,9,12,13,15,16,21] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound8939 : packedSelected [1,3,4,5,8,9,12,13,15,16,21] rootPS < 2^1333 := by decide +kernel

def env8940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,100522,1025,32768,4097,41088,5457,98565,8328,5377,76079,4177,1296,75786,1285,4294967296,257,4295041327,1344,512]

theorem envBound8940 : H12AffineFastState.Bounded env8940 := by
  intro p hp
  have h : env8940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8939_8940 : H12AffineEnvironment.transform 17 100522 env8939 = env8940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env8939 == env8940) = true)

theorem identity8940 : scanCanonicalize (H12AffineFastState.compose env8940 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 111930) := by decide +kernel

theorem selectedBound8940 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,100522,1025,32768,4097,41088,5457,98565,8328,5377,76079,4177,1296,75786,1285,111930,257,37909,1344,512]

theorem envBound8941 : H12AffineFastState.Bounded env8941 := by
  intro p hp
  have h : env8941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8940_8941 : H12AffineEnvironment.transform 31 111930 env8940 = env8941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 111930 env8940 == env8941) = true)

theorem identity8941 : scanCanonicalize (H12AffineFastState.compose env8941 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1361) := by decide +kernel

theorem selectedBound8941 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,1361,65536,1345,69115,1025,1361,4097,9681,5457,66644,8328,5377,76079,4177,1296,75786,1285,77931,257,4420,1344,512]

theorem envBound8942 : H12AffineFastState.Bounded env8942 := by
  intro p hp
  have h : env8942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8941_8942 : H12AffineEnvironment.transform 14 1361 env8941 = env8942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1361 env8941 == env8942) = true)

theorem identity8942 : scanCanonicalize (H12AffineFastState.compose env8942 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1116) := by decide +kernel

theorem selectedBound8942 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1116,4177,1361,65536,1345,69115,1025,1361,4097,397,5457,66644,1236,5377,68979,4177,1296,68694,1285,70711,257,4420,1344,512]

theorem envBound8943 : H12AffineFastState.Bounded env8943 := by
  intro p hp
  have h : env8943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8942_8943 : H12AffineEnvironment.transform 12 1116 env8942 = env8943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1116 env8942 == env8943) = true)

theorem identity8943 : scanCanonicalize (H12AffineFastState.compose env8943 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 1246) := by decide +kernel

theorem selectedBound8943 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env8944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1116,4177,1361,1246,1345,2341,1025,1361,4097,397,5457,138,1236,5377,2477,4177,1296,2184,1285,4329,257,4420,1344,512]

theorem envBound8944 : H12AffineFastState.Bounded env8944 := by
  intro p hp
  have h : env8944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8943_8944 : H12AffineEnvironment.transform 15 1246 env8943 = env8944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1246 env8943 == env8944) = true)

theorem identity8944 : scanCanonicalize (H12AffineFastState.compose env8944 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8944 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8945 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,89,4177,340,219,324,2341,4,340,4097,397,4436,138,209,4356,2477,4177,277,2184,256,4329,257,4420,325,512]

theorem envBound8945 : H12AffineFastState.Bounded env8945 := by
  intro p hp
  have h : env8945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8944_8945 : H12AffineEnvironment.transform 9 5 env8944 = env8945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8944 == env8945) = true)

theorem identity8945 : scanCanonicalize (H12AffineFastState.compose env8945 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(11+1) ^^^ 2787) := by decide +kernel

theorem selectedBound8945 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env8946 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,2787,89,2738,340,219,324,2341,4,340,2786,397,2999,138,209,3047,2477,2738,277,2184,256,2570,257,2983,325,512]

theorem envBound8946 : H12AffineFastState.Bounded env8946 := by
  intro p hp
  have h : env8946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8945_8946 : H12AffineEnvironment.transform 11 2787 env8945 = env8946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2787 env8945 == env8946) = true)

theorem identity8946 : scanCanonicalize (H12AffineFastState.compose env8946 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound8946 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env8947 : List Nat := [2,4,8,16,32,64,128,256,512,5,935,324,89,277,340,219,324,642,4,340,325,397,16,138,209,64,522,277,277,815,256,429,257,0,325,512]

theorem envBound8947 : H12AffineFastState.Bounded env8947 := by
  intro p hp
  have h : env8947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8946_8947 : H12AffineEnvironment.transform 10 935 env8946 = env8947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env8946 == env8947) = true)

theorem identity8947 : scanCanonicalize (H12AffineFastState.compose env8947 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound8947 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8948 : List Nat := [2,4,8,16,32,64,128,256,350,5,249,324,89,277,340,219,324,476,4,340,325,397,16,138,209,64,340,277,277,113,256,429,257,0,325,350]

theorem envBound8948 : H12AffineFastState.Bounded env8948 := by
  intro p hp
  have h : env8948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8947_8948 : H12AffineEnvironment.transform 8 350 env8947 = env8948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env8947 == env8948) = true)

theorem identity8948 : scanCanonicalize (H12AffineFastState.compose env8948 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound8948 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8949 : List Nat := [2,4,8,16,32,18,128,256,268,5,171,278,11,277,262,137,278,398,4,262,279,397,16,138,131,18,262,277,277,35,256,429,257,0,279,268]

theorem envBound8949 : H12AffineFastState.Bounded env8949 := by
  intro p hp
  have h : env8949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8948_8949 : H12AffineEnvironment.transform 5 18 env8948 = env8949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env8948 == env8949) = true)

def env8950 : List Nat := [2,4,8,16,32,18,8,256,268,5,35,278,11,277,262,1,278,262,4,262,279,261,16,2,11,18,262,277,277,35,256,293,257,0,279,268]

theorem envBound8950 : H12AffineFastState.Bounded env8950 := by
  intro p hp
  have h : env8950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8949_8950 : H12AffineEnvironment.transform 6 8 env8949 = env8950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8949 == env8950) = true)

theorem identity8950 : scanCanonicalize (H12AffineFastState.compose env8950 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound8950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8951 : List Nat := [0,4,8,16,32,16,8,256,268,5,33,276,9,277,260,1,276,260,4,260,277,261,16,0,9,16,260,277,277,33,256,293,257,0,277,268]

theorem envBound8951 : H12AffineFastState.Bounded env8951 := by
  intro p hp
  have h : env8951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8950_8951 : H12AffineEnvironment.transform 0 0 env8950 = env8951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env8950 == env8951) = true)

theorem identity8951 : scanCanonicalize (H12AffineFastState.compose env8951 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound8951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8952 : List Nat := [0,4,8,16,32,16,8,37,41,5,33,49,9,48,33,1,49,33,4,33,48,32,16,0,9,16,33,48,48,33,37,0,36,0,48,41]

theorem envBound8952 : H12AffineFastState.Bounded env8952 := by
  intro p hp
  have h : env8952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8951_8952 : H12AffineEnvironment.transform 7 37 env8951 = env8952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env8951 == env8952) = true)

theorem identity8952 : scanCanonicalize (H12AffineFastState.compose env8952 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound8952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8953 : List Nat := [0,4,1,16,32,16,1,37,32,5,33,49,0,48,33,1,49,33,4,33,48,32,16,0,0,16,33,48,48,33,37,0,36,0,48,32]

theorem envBound8953 : H12AffineFastState.Bounded env8953 := by
  intro p hp
  have h : env8953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8952_8953 : H12AffineEnvironment.transform 2 1 env8952 = env8953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env8952 == env8953) = true)

def leafEnv8953 : List Nat := [0,4,1,16,32,16,1,37,32,5,33,49,0,48,33,1,49,33,4,33,48,32,16,0,36,0,1,16,33,48,48,33,37,0,36,0,5,1,48,32,0,48,1]

def active8953 : List Nat := [1,3,4]

def tree8953 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8953 : H12WitnessSearch.Good tree8953 := H12GlobalWitnessIndex.good

theorem leafIdentity8953 : H12AffineFastState.composeSystem env8953 rootObs = leafEnv8953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8953 rootObs == leafEnv8953) = true)

theorem terminalChecked8953 : H12PackedTerminal.terminalCheckFast leafEnv8953 active8953 tree8953 = true := by decide +kernel

def env8954 : List Nat := [2,4,8,16,32,18,9,256,268,5,34,278,11,277,262,0,278,263,4,262,279,260,16,3,10,18,262,277,277,35,256,292,257,0,279,268]

theorem envBound8954 : H12AffineFastState.Bounded env8954 := by
  intro p hp
  have h : env8954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8949_8954 : H12AffineEnvironment.transform 6 9 env8949 = env8954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8949 == env8954) = true)

theorem identity8954 : scanCanonicalize (H12AffineFastState.compose env8954 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 39) := by decide +kernel

theorem selectedBound8954 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8955 : List Nat := [2,4,8,16,32,18,9,39,43,5,34,49,11,50,33,0,49,32,4,33,48,35,16,3,10,18,33,50,50,35,39,3,38,0,48,43]

theorem envBound8955 : H12AffineFastState.Bounded env8955 := by
  intro p hp
  have h : env8955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8954_8955 : H12AffineEnvironment.transform 7 39 env8954 = env8955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 39 env8954 == env8955) = true)

def env8956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878609,4294967296,537002320,4417151347,694534145,33563272]

theorem envBound8956 : H12AffineFastState.Bounded env8956 := by
  intro p hp
  have h : env8956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8715_8956 : H12AffineEnvironment.transform 34 694534145 env8715 = env8956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534145 env8715 == env8956) = true)

def env8957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,157794304,1073741824,140788817,4294967296,157663568,4417151347,131073,33563272]

theorem envBound8957 : H12AffineFastState.Bounded env8957 := by
  intro p hp
  have h : env8957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8956_8957 : H12AffineEnvironment.transform 28 157794304 env8956 = env8957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env8956 == env8957) = true)

theorem identity8957 : scanCanonicalize (H12AffineFastState.compose env8957 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 21484817) := by decide +kernel

theorem selectedBound8957 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,21484817,67130625,2102545,1073741824,19108160,4294967296,2233409,4417151347,131073,33563272]

theorem envBound8958 : H12AffineFastState.Bounded env8958 := by
  intro p hp
  have h : env8958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8957_8958 : H12AffineEnvironment.transform 26 21484817 env8957 = env8958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21484817 env8957 == env8958) = true)

def env8959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,659776,4194304,17664,16777216,33554432,67108864,21484817,67130625,656465,1073741824,17399808,4294967296,525569,4417151347,131073,33563272]

theorem envBound8959 : H12AffineFastState.Bounded env8959 := by
  intro p hp
  have h : env8959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8958_8959 : H12AffineEnvironment.transform 20 659776 env8958 = env8959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 659776 env8958 == env8959) = true)

theorem identity8959 : scanCanonicalize (H12AffineFastState.compose env8959 (packedSelected [4,6,7,9,16,20,25,27,35] rootPS)) = affineNative (2^(29+1) ^^^ 71944666) := by decide +kernel

theorem selectedBound8959 : packedSelected [4,6,7,9,16,20,25,27,35] rootPS < 2^1333 := by decide +kernel

def env8960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,659776,4194304,17664,16777216,33554432,67108864,21484817,67130625,656465,71944666,17399808,4294967296,525569,4417151347,131073,33563272]

theorem envBound8960 : H12AffineFastState.Bounded env8960 := by
  intro p hp
  have h : env8960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8959_8960 : H12AffineEnvironment.transform 29 71944666 env8959 = env8960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 71944666 env8959 == env8960) = true)

def env8961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,4194304,17664,16777216,33554432,67108864,21484817,67130625,131153,71421402,16876544,4294967296,257,4416628083,131073,33563272]

theorem envBound8961 : H12AffineFastState.Bounded env8961 := by
  intro p hp
  have h : env8961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8960_8961 : H12AffineEnvironment.transform 18 1024 env8960 = env8961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8960 == env8961) = true)

def env8962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,4194304,17664,16777216,33554432,5376,21484817,16385,131153,4315354,16876544,4294967296,257,4349522035,131073,33563272]

theorem envBound8962 : H12AffineFastState.Bounded env8962 := by
  intro p hp
  have h : env8962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8961_8962 : H12AffineEnvironment.transform 25 5376 env8961 = env8962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env8961 == env8962) = true)

theorem identity8962 : scanCanonicalize (H12AffineFastState.compose env8962 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound8962 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,4194304,17664,230468,33554432,5376,4477269,16385,131153,4315354,131140,4294967296,257,4332975159,131073,33563272]

theorem envBound8963 : H12AffineFastState.Bounded env8963 := by
  intro p hp
  have h : env8963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8962_8963 : H12AffineEnvironment.transform 23 230468 env8962 = env8963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env8962 == env8963) = true)

theorem identity8963 : scanCanonicalize (H12AffineFastState.compose env8963 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(16+1) ^^^ 21776) := by decide +kernel

theorem selectedBound8963 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env8964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1024,32768,16464,4194304,17664,119124,33554432,5376,4477269,16385,21825,4315354,21844,4294967296,257,4332822823,21777,33563272]

theorem envBound8964 : H12AffineFastState.Bounded env8964 := by
  intro p hp
  have h : env8964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8963_8964 : H12AffineEnvironment.transform 16 21776 env8963 = env8964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21776 env8963 == env8964) = true)

theorem identity8964 : scanCanonicalize (H12AffineFastState.compose env8964 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound8964 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1024,32768,16464,4194304,17664,119124,8329,5376,4477269,16385,21825,4315354,21844,4294967296,257,4299260334,21777,513]

theorem envBound8965 : H12AffineFastState.Bounded env8965 := by
  intro p hp
  have h : env8965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8964_8965 : H12AffineEnvironment.transform 24 8329 env8964 = env8965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env8964 == env8965) = true)

theorem identity8965 : scanCanonicalize (H12AffineFastState.compose env8965 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound8965 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env8966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1024,32768,4097,4194304,5457,98565,8329,5376,4456708,4176,1296,4294795,1285,4294967296,257,4299260334,1344,513]

theorem envBound8966 : H12AffineFastState.Bounded env8966 := by
  intro p hp
  have h : env8966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8965_8966 : H12AffineEnvironment.transform 13 4177 env8965 = env8966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env8965 == env8966) = true)

theorem identity8966 : scanCanonicalize (H12AffineFastState.compose env8966 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound8966 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13973,65536,1345,262144,1024,13973,4097,4194304,5457,79760,8329,5376,4456708,4176,1296,4275742,1285,4294967296,257,4299241275,1344,513]

theorem envBound8967 : H12AffineFastState.Bounded env8967 := by
  intro p hp
  have h : env8967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8966_8967 : H12AffineEnvironment.transform 14 13973 env8966 = env8967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env8966 == env8967) = true)

theorem identity8967 : scanCanonicalize (H12AffineFastState.compose env8967 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8967 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8968 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4177,13341,65536,1345,262144,1024,13341,4097,4194304,5457,79128,8329,5376,4456708,4176,1296,4275350,1285,4294967296,257,4299240883,1344,137]

theorem envBound8968 : H12AffineFastState.Bounded env8968 := by
  intro p hp
  have h : env8968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8967_8968 : H12AffineEnvironment.transform 8 136 env8967 = env8968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8967 == env8968) = true)

def env8969 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1345,8461,65536,1345,262144,1024,8461,1297,4194304,65,73736,8329,16,4456708,1344,1296,4270470,1285,4294967296,257,4299235491,1344,137]

theorem envBound8969 : H12AffineFastState.Bounded env8969 := by
  intro p hp
  have h : env8969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8968_8969 : H12AffineEnvironment.transform 11 1296 env8968 = env8969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env8968 == env8969) = true)

theorem identity8969 : scanCanonicalize (H12AffineFastState.compose env8969 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound8969 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8970 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1345,8461,65536,1345,76199,1024,8461,1297,4194304,65,73736,8329,16,4270243,1344,1296,4270470,1285,4294967296,257,4299235491,1344,137]

theorem envBound8970 : H12AffineFastState.Bounded env8970 := by
  intro p hp
  have h : env8970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8969_8970 : H12AffineEnvironment.transform 17 76199 env8969 = env8970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env8969 == env8970) = true)

theorem identity8970 : scanCanonicalize (H12AffineFastState.compose env8970 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 67593) := by decide +kernel

theorem selectedBound8970 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8971 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1345,8461,65536,1345,76199,1024,8461,1297,4194304,65,73736,8329,16,4270243,1344,1296,4270470,1285,67593,257,4204714,1344,137]

theorem envBound8971 : H12AffineFastState.Bounded env8971 := by
  intro p hp
  have h : env8971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8970_8971 : H12AffineEnvironment.transform 31 67593 env8970 = env8971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67593 env8970 == env8971) = true)

theorem identity8971 : scanCanonicalize (H12AffineFastState.compose env8971 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8971 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env8972 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1345,8461,8323,1345,2340,1024,8461,1297,4194304,65,139,8329,16,4196384,1344,1296,4196613,1285,10378,257,4204714,1344,137]

theorem envBound8972 : H12AffineFastState.Bounded env8972 := by
  intro p hp
  have h : env8972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8971_8972 : H12AffineEnvironment.transform 15 8323 env8971 = env8972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8971 == env8972) = true)

theorem identity8972 : scanCanonicalize (H12AffineFastState.compose env8972 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 10395) := by decide +kernel

theorem selectedBound8972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8973 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1345,8461,8323,1345,2340,1024,8461,1297,10395,65,139,8329,16,8379,1344,1296,8606,1285,10378,257,49,1344,137]

theorem envBound8973 : H12AffineFastState.Bounded env8973 := by
  intro p hp
  have h : env8973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8972_8973 : H12AffineEnvironment.transform 21 10395 env8972 = env8973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10395 env8972 == env8973) = true)

theorem identity8973 : scanCanonicalize (H12AffineFastState.compose env8973 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound8973 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8974 : List Nat := [2,4,8,16,32,64,128,183,136,1024,2048,1191,8192,1270,8378,8323,1270,2195,1024,8378,1190,10395,65,139,8329,16,8379,1271,1191,8233,1202,10378,182,49,1271,137]

theorem envBound8974 : H12AffineFastState.Bounded env8974 := by
  intro p hp
  have h : env8974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8973_8974 : H12AffineEnvironment.transform 7 183 env8973 = env8974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env8973 == env8974) = true)

theorem identity8974 : scanCanonicalize (H12AffineFastState.compose env8974 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound8974 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8975 : List Nat := [2,4,8,16,32,64,128,183,136,1024,2048,1191,2089,1270,2195,2218,1270,2195,1024,2195,1190,178,65,139,2208,16,2194,1271,1191,2048,1202,163,182,49,1271,137]

theorem envBound8975 : H12AffineFastState.Bounded env8975 := by
  intro p hp
  have h : env8975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8974_8975 : H12AffineEnvironment.transform 12 2089 env8974 = env8975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env8974 == env8975) = true)

def env8976 : List Nat := [2,4,8,0,32,64,128,167,136,1024,2048,1191,2089,1254,2179,2218,1254,2179,1024,2179,1190,162,65,139,2208,0,2178,1255,1191,2048,1186,163,166,33,1255,137]

theorem envBound8976 : H12AffineFastState.Bounded env8976 := by
  intro p hp
  have h : env8976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8975_8976 : H12AffineEnvironment.transform 3 0 env8975 = env8976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8975 == env8976) = true)

def leafEnv8976 : List Nat := [2,4,8,0,32,64,128,167,136,1024,2048,1191,2089,1254,2179,2218,1254,2179,1024,2179,1190,162,65,139,1186,2208,1,0,2178,1255,1191,2048,1186,163,166,33,5,2082,1255,137,0,1190,1]

def active8976 : List Nat := [0,1,2,4,5,6,9,10]

def tree8976 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8976 : H12WitnessSearch.Good tree8976 := H12GlobalWitnessIndex.good

theorem leafIdentity8976 : H12AffineFastState.composeSystem env8976 rootObs = leafEnv8976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8976 rootObs == leafEnv8976) = true)

theorem terminalChecked8976 : H12PackedTerminal.terminalCheckFast leafEnv8976 active8976 tree8976 = true := by decide +kernel

def env8977 : List Nat := [2,4,8,1,32,64,128,166,136,1024,2048,1191,2089,1255,2178,2218,1255,2178,1024,2178,1190,163,65,139,2208,1,2179,1254,1191,2048,1187,163,167,32,1254,137]

theorem envBound8977 : H12AffineFastState.Bounded env8977 := by
  intro p hp
  have h : env8977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8975_8977 : H12AffineEnvironment.transform 3 1 env8975 = env8977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8975 == env8977) = true)

theorem identity8977 : scanCanonicalize (H12AffineFastState.compose env8977 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound8977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8978 : List Nat := [2,4,8,1,32,64,3,37,11,1024,2048,1060,2089,1124,2049,2089,1124,2049,1024,2049,1061,32,65,8,2083,1,2048,1125,1060,2048,1056,32,36,32,1125,10]

theorem envBound8978 : H12AffineFastState.Bounded env8978 := by
  intro p hp
  have h : env8978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8977_8978 : H12AffineEnvironment.transform 6 3 env8977 = env8978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env8977 == env8978) = true)

def leafEnv8978 : List Nat := [2,4,8,1,32,64,3,37,11,1024,2048,1060,2089,1124,2049,2089,1124,2049,1024,2049,1061,32,65,8,1056,2083,1,1,2048,1125,1060,2048,1056,32,36,32,5,2082,1125,10,0,1061,1]

def active8978 : List Nat := [0,1,2,4,5,9,10]

def tree8978 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8978 : H12WitnessSearch.Good tree8978 := H12GlobalWitnessIndex.good

theorem leafIdentity8978 : H12AffineFastState.composeSystem env8978 rootObs = leafEnv8978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8978 rootObs == leafEnv8978) = true)

theorem terminalChecked8978 : H12PackedTerminal.terminalCheckFast leafEnv8978 active8978 tree8978 = true := by decide +kernel

def env8979 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1344,8460,65536,1345,262144,1024,8460,1296,4194304,64,73737,8329,17,4456708,1345,1296,4270471,1285,4294967296,257,4299235490,1344,137]

theorem envBound8979 : H12AffineFastState.Bounded env8979 := by
  intro p hp
  have h : env8979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8968_8979 : H12AffineEnvironment.transform 11 1297 env8968 = env8979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8968 == env8979) = true)

theorem identity8979 : scanCanonicalize (H12AffineFastState.compose env8979 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound8979 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8980 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1344,8460,8322,1345,262144,1024,8460,1296,4194304,64,139,8329,17,4456708,1345,1296,4196613,1285,4294967296,257,4299161632,1344,137]

theorem envBound8980 : H12AffineFastState.Bounded env8980 := by
  intro p hp
  have h : env8980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8979_8980 : H12AffineEnvironment.transform 15 8322 env8979 = env8980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env8979 == env8980) = true)

theorem identity8980 : scanCanonicalize (H12AffineFastState.compose env8980 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 4464675) := by decide +kernel

theorem selectedBound8980 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8981 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1344,8460,8322,1345,262144,1024,8460,1296,4194304,64,139,8329,17,4456708,1345,1296,4196613,1285,4464675,257,270339,1344,137]

theorem envBound8981 : H12AffineFastState.Bounded env8981 := by
  intro p hp
  have h : env8981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8980_8981 : H12AffineEnvironment.transform 31 4464675 env8980 = env8981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4464675 env8980 == env8981) = true)

theorem identity8981 : scanCanonicalize (H12AffineFastState.compose env8981 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound8981 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env8982 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1344,8460,8322,1345,2341,1024,8460,1296,4194304,64,139,8329,17,4196385,1345,1296,4196613,1285,4204806,257,10534,1344,137]

theorem envBound8982 : H12AffineFastState.Bounded env8982 := by
  intro p hp
  have h : env8982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8981_8982 : H12AffineEnvironment.transform 17 2341 env8981 = env8982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env8981 == env8982) = true)

theorem identity8982 : scanCanonicalize (H12AffineFastState.compose env8982 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound8982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8983 : List Nat := [2,4,8,16,32,64,128,111,136,1024,2048,1150,8192,1071,8291,8322,1070,2122,1024,8291,1151,4194304,64,139,8329,17,4196385,1070,1151,4196458,1130,4204649,110,10313,1071,137]

theorem envBound8983 : H12AffineFastState.Bounded env8983 := by
  intro p hp
  have h : env8983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8982_8983 : H12AffineEnvironment.transform 7 111 env8982 = env8983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env8982 == env8983) = true)

theorem identity8983 : scanCanonicalize (H12AffineFastState.compose env8983 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound8983 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8984 : List Nat := [2,4,8,16,32,64,128,111,136,1024,2048,1150,2088,1071,2123,2218,1070,2122,1024,2123,1151,4194304,64,139,2209,17,4196385,1070,1151,4196458,1130,4194369,110,97,1071,137]

theorem envBound8984 : H12AffineFastState.Bounded env8984 := by
  intro p hp
  have h : env8984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8983_8984 : H12AffineEnvironment.transform 12 2088 env8983 = env8984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env8983 == env8984) = true)

theorem identity8984 : scanCanonicalize (H12AffineFastState.compose env8984 (packedSelected [0,2,4] rootPS)) = affineNative (2^(21+1) ^^^ 106) := by decide +kernel

theorem selectedBound8984 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8985 : List Nat := [2,4,8,16,32,64,128,111,136,1024,2048,1150,2088,1071,2123,2218,1070,2122,1024,2123,1151,106,64,139,2209,17,2123,1070,1151,2048,1130,43,110,97,1071,137]

theorem envBound8985 : H12AffineFastState.Bounded env8985 := by
  intro p hp
  have h : env8985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8984_8985 : H12AffineEnvironment.transform 21 106 env8984 = env8985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106 env8984 == env8985) = true)

def env8986 : List Nat := [2,4,8,16,32,0,128,47,136,1024,2048,1086,2088,1071,2059,2218,1070,2058,1024,2059,1087,42,0,139,2209,17,2059,1070,1087,2048,1066,43,46,33,1071,137]

theorem envBound8986 : H12AffineFastState.Bounded env8986 := by
  intro p hp
  have h : env8986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8985_8986 : H12AffineEnvironment.transform 5 0 env8985 = env8986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8985 == env8986) = true)

def leafEnv8986 : List Nat := [2,4,8,16,32,0,128,47,136,1024,2048,1086,2088,1071,2059,2218,1070,2058,1024,2059,1087,42,0,139,1066,2209,1,17,2059,1070,1087,2048,1066,43,46,33,5,2082,1071,137,0,1086,1]

def active8986 : List Nat := [0,1,2,3,4,6,9,10]

def tree8986 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8986 : H12WitnessSearch.Good tree8986 := H12GlobalWitnessIndex.good

theorem leafIdentity8986 : H12AffineFastState.composeSystem env8986 rootObs = leafEnv8986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8986 rootObs == leafEnv8986) = true)

theorem terminalChecked8986 : H12PackedTerminal.terminalCheckFast leafEnv8986 active8986 tree8986 = true := by decide +kernel

def env8987 : List Nat := [2,4,8,16,32,1,128,46,136,1024,2048,1087,2088,1071,2058,2218,1070,2059,1024,2058,1086,43,1,139,2209,17,2058,1070,1086,2048,1067,43,47,32,1071,137]

theorem envBound8987 : H12AffineFastState.Bounded env8987 := by
  intro p hp
  have h : env8987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8985_8987 : H12AffineEnvironment.transform 5 1 env8985 = env8987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8985 == env8987) = true)

theorem identity8987 : scanCanonicalize (H12AffineFastState.compose env8987 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8988 : List Nat := [2,4,3,16,32,1,128,37,131,1024,2048,1076,2083,1060,2049,2209,1061,2048,1024,2049,1077,32,1,128,2209,17,2049,1061,1077,2048,1056,32,36,32,1060,130]

theorem envBound8988 : H12AffineFastState.Bounded env8988 := by
  intro p hp
  have h : env8988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8987_8988 : H12AffineEnvironment.transform 2 3 env8987 = env8988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8987 == env8988) = true)

def leafEnv8988 : List Nat := [2,4,3,16,32,1,128,37,131,1024,2048,1076,2083,1060,2049,2209,1061,2048,1024,2049,1077,32,1,128,1056,2209,1,17,2049,1061,1077,2048,1056,32,36,32,5,2082,1060,130,0,1076,1]

def active8988 : List Nat := [0,1,3,4,6,9,10]

def tree8988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8988 : H12WitnessSearch.Good tree8988 := H12GlobalWitnessIndex.good

theorem leafIdentity8988 : H12AffineFastState.composeSystem env8988 rootObs = leafEnv8988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8988 rootObs == leafEnv8988) = true)

theorem terminalChecked8988 : H12PackedTerminal.terminalCheckFast leafEnv8988 active8988 tree8988 = true := by decide +kernel

def env8989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,4194304,17664,16777216,33554432,5377,21484817,16384,131153,4315355,16876544,4294967296,257,4349522034,131073,33563272]

theorem envBound8989 : H12AffineFastState.Bounded env8989 := by
  intro p hp
  have h : env8989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8961_8989 : H12AffineEnvironment.transform 25 5377 env8961 = env8989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env8961 == env8989) = true)

theorem identity8989 : scanCanonicalize (H12AffineFastState.compose env8989 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound8989 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,4194304,17664,98564,33554432,5377,4609045,16384,131153,4315355,1284,4294967296,257,4332843382,131073,33563272]

theorem envBound8990 : H12AffineFastState.Bounded env8990 := by
  intro p hp
  have h : env8990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8989_8990 : H12AffineEnvironment.transform 23 98564 env8989 = env8990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env8989 == env8990) = true)

def env8991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,1344,4194304,17664,98564,33554432,5377,4473877,16384,4177,4315355,1284,4294967296,257,4332843382,4097,33563272]

theorem envBound8991 : H12AffineFastState.Bounded env8991 := by
  intro p hp
  have h : env8991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8990_8991 : H12AffineEnvironment.transform 16 4096 env8990 = env8991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env8990 == env8991) = true)

def env8992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32768,1344,4194304,17664,98564,33554432,65,4473877,16384,1297,4312475,1284,4294967296,257,4332839990,1345,33563272]

theorem envBound8992 : H12AffineFastState.Bounded env8992 := by
  intro p hp
  have h : env8992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8991_8992 : H12AffineEnvironment.transform 11 1344 env8991 = env8992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env8991 == env8992) = true)

theorem identity8992 : scanCanonicalize (H12AffineFastState.compose env8992 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound8992 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32768,1344,4194304,17664,98564,8328,65,4473877,16384,1297,4312475,1284,4294967296,257,4299277502,1345,512]

theorem envBound8993 : H12AffineFastState.Bounded env8993 := by
  intro p hp
  have h : env8993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8992_8993 : H12AffineEnvironment.transform 24 8328 env8992 = env8993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env8992 == env8993) = true)

theorem identity8993 : scanCanonicalize (H12AffineFastState.compose env8993 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 17564) := by decide +kernel

theorem selectedBound8993 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32768,1344,17564,17664,98564,8328,65,262281,16384,1297,100615,1284,4294967296,257,4295065634,1345,512]

theorem envBound8994 : H12AffineFastState.Bounded env8994 := by
  intro p hp
  have h : env8994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8993_8994 : H12AffineEnvironment.transform 21 17564 env8993 = env8994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17564 env8993 == env8994) = true)

theorem identity8994 : scanCanonicalize (H12AffineFastState.compose env8994 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 124219) := by decide +kernel

theorem selectedBound8994 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32768,1344,17564,17664,98564,8328,65,262281,16384,1297,100615,1284,124219,257,25881,1345,512]

theorem envBound8995 : H12AffineFastState.Bounded env8995 := by
  intro p hp
  have h : env8995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8994_8995 : H12AffineEnvironment.transform 31 124219 env8994 = env8995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 124219 env8994 == env8995) = true)

theorem identity8995 : scanCanonicalize (H12AffineFastState.compose env8995 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 17082) := by decide +kernel

theorem selectedBound8995 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,17082,1344,262144,1024,32768,1344,17564,17664,50110,8328,65,262281,16384,1297,52157,1284,42881,257,25881,1345,512]

theorem envBound8996 : H12AffineFastState.Bounded env8996 := by
  intro p hp
  have h : env8996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8995_8996 : H12AffineEnvironment.transform 15 17082 env8995 = env8996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17082 env8995 == env8996) = true)

theorem identity8996 : scanCanonicalize (H12AffineFastState.compose env8996 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 17429) := by decide +kernel

theorem selectedBound8996 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,17429,17082,1344,262144,1024,17429,1344,17564,17664,1963,8328,65,262281,16384,1297,4008,1284,25492,257,25881,1345,512]

theorem envBound8997 : H12AffineFastState.Bounded env8997 := by
  intro p hp
  have h : env8997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8996_8997 : H12AffineEnvironment.transform 14 17429 env8996 = env8997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17429 env8996 == env8997) = true)

theorem identity8997 : scanCanonicalize (H12AffineFastState.compose env8997 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8997 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,9,16384,17429,17082,1344,262144,1024,17429,1344,17564,17664,1963,129,65,262281,16384,1297,4008,1284,17309,257,17680,1345,512]

theorem envBound8998 : H12AffineFastState.Bounded env8998 := by
  intro p hp
  have h : env8998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8997_8998 : H12AffineEnvironment.transform 12 9 env8997 = env8998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8997 == env8998) = true)

theorem identity8998 : scanCanonicalize (H12AffineFastState.compose env8998 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound8998 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,9,16384,17429,17082,1344,2341,1024,17429,1344,17564,17664,1963,129,65,2476,16384,1297,4008,1284,17309,257,17680,1345,512]

theorem envBound8999 : H12AffineFastState.Bounded env8999 := by
  intro p hp
  have h : env8999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8998_8999 : H12AffineEnvironment.transform 17 2341 env8998 = env8999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env8998 == env8999) = true)

theorem identity8999 : scanCanonicalize (H12AffineFastState.compose env8999 (packedSelected [1,3,8,12,17,24] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound8999 : packedSelected [1,3,8,12,17,24] rootPS < 2^1333 := by decide +kernel

def env9000 : List Nat := [2,4,8,16,32,64,128,256,512,424,2048,232,9,16384,16829,17082,232,2341,424,16829,232,16692,16552,515,129,65,2476,16384,185,2560,172,17309,257,16568,233,512]

theorem envBound9000 : H12AffineFastState.Bounded env9000 := by
  intro p hp
  have h : env9000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8999_9000 : H12AffineEnvironment.transform 9 424 env8999 = env9000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env8999 == env9000) = true)

theorem identity9000 : scanCanonicalize (H12AffineFastState.compose env9000 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound9000 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env9001 : List Nat := [2,4,8,16,32,64,128,256,512,424,2048,232,9,185,260,515,232,2341,424,260,232,397,17,515,129,65,2476,185,185,2560,172,804,257,1,233,512]

theorem envBound9001 : H12AffineFastState.Bounded env9001 := by
  intro p hp
  have h : env9001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9000_9001 : H12AffineEnvironment.transform 13 185 env9000 = env9001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env9000 == env9001) = true)

theorem identity9001 : scanCanonicalize (H12AffineFastState.compose env9001 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound9001 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9002 : List Nat := [2,4,8,16,32,64,128,256,512,424,292,232,9,185,260,515,232,1,424,260,232,397,17,515,129,65,136,185,185,804,172,804,257,1,233,512]

theorem envBound9002 : H12AffineFastState.Bounded env9002 := by
  intro p hp
  have h : env9002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9001_9002 : H12AffineEnvironment.transform 10 292 env9001 = env9002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env9001 == env9002) = true)

theorem identity9002 : scanCanonicalize (H12AffineFastState.compose env9002 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound9002 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env9003 : List Nat := [2,4,8,16,32,64,128,256,372,424,292,232,9,185,260,375,232,1,424,260,232,397,17,375,129,65,136,185,185,80,172,80,257,1,233,372]

theorem envBound9003 : H12AffineFastState.Bounded env9003 := by
  intro p hp
  have h : env9003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9002_9003 : H12AffineEnvironment.transform 8 372 env9002 = env9003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env9002 == env9003) = true)

theorem identity9003 : scanCanonicalize (H12AffineFastState.compose env9003 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9003 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9004 : List Nat := [2,4,8,16,32,64,128,253,137,85,217,232,9,185,249,138,232,1,85,249,232,112,17,138,129,65,136,185,185,80,172,80,252,1,233,137]

theorem envBound9004 : H12AffineFastState.Bounded env9004 := by
  intro p hp
  have h : env9004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9003_9004 : H12AffineEnvironment.transform 7 253 env9003 = env9004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9003 == env9004) = true)

theorem identity9004 : scanCanonicalize (H12AffineFastState.compose env9004 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9004 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9005 : List Nat := [2,4,8,16,10,64,128,215,137,85,217,194,9,147,211,138,194,1,85,211,194,90,17,138,129,65,136,147,147,80,134,80,214,1,195,137]

theorem envBound9005 : H12AffineFastState.Bounded env9005 := by
  intro p hp
  have h : env9005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9004_9005 : H12AffineEnvironment.transform 4 10 env9004 = env9005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9004 == env9005) = true)

theorem identity9005 : scanCanonicalize (H12AffineFastState.compose env9005 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound9005 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env9006 : List Nat := [2,4,8,16,10,64,83,4,90,85,10,17,9,64,0,89,17,1,85,0,17,90,17,89,82,65,91,64,64,80,85,80,5,1,16,90]

theorem envBound9006 : H12AffineFastState.Bounded env9006 := by
  intro p hp
  have h : env9006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9005_9006 : H12AffineEnvironment.transform 6 83 env9005 = env9006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env9005 == env9006) = true)

theorem identity9006 : scanCanonicalize (H12AffineFastState.compose env9006 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound9006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9007 : List Nat := [2,4,8,16,10,26,9,4,0,15,10,17,9,26,0,3,17,1,15,0,17,0,17,3,8,27,1,26,26,10,15,10,5,1,16,0]

theorem envBound9007 : H12AffineFastState.Bounded env9007 := by
  intro p hp
  have h : env9007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9006_9007 : H12AffineEnvironment.transform 5 26 env9006 = env9007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env9006 == env9007) = true)

theorem identity9007 : scanCanonicalize (H12AffineFastState.compose env9007 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound9007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9008 : List Nat := [2,4,8,9,10,3,9,4,0,15,10,8,9,3,0,3,8,1,15,0,8,0,8,3,8,2,1,3,3,10,15,10,5,1,9,0]

theorem envBound9008 : H12AffineFastState.Bounded env9008 := by
  intro p hp
  have h : env9008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9007_9008 : H12AffineEnvironment.transform 3 9 env9007 = env9008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env9007 == env9008) = true)

theorem identity9008 : scanCanonicalize (H12AffineFastState.compose env9008 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9008 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9009 : List Nat := [2,4,2,3,0,3,3,4,0,5,0,2,3,3,0,3,2,1,5,0,2,0,2,3,2,2,1,3,3,0,5,0,5,1,3,0]

theorem envBound9009 : H12AffineFastState.Bounded env9009 := by
  intro p hp
  have h : env9009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9008_9009 : H12AffineEnvironment.transform 2 2 env9008 = env9009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9008 == env9009) = true)

def leafEnv9009 : List Nat := [2,4,2,3,0,3,3,4,0,5,0,2,3,3,0,3,2,1,5,0,2,0,2,3,5,2,1,2,1,3,3,0,5,0,5,1,5,2,3,0,0,2,1]

def active9009 : List Nat := [0,1]

def tree9009 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9009 : H12WitnessSearch.Good tree9009 := H12GlobalWitnessIndex.good

theorem leafIdentity9009 : H12AffineFastState.composeSystem env9009 rootObs = leafEnv9009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9009 rootObs == leafEnv9009) = true)

theorem terminalChecked9009 : H12PackedTerminal.terminalCheckFast leafEnv9009 active9009 tree9009 = true := by decide +kernel

def env9010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,1024,32768,1344,4194304,17664,98564,33554432,64,4473877,16384,1296,4312474,1284,4294967296,257,4332839991,1344,33563272]

theorem envBound9010 : H12AffineFastState.Bounded env9010 := by
  intro p hp
  have h : env9010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8991_9010 : H12AffineEnvironment.transform 11 1345 env8991 = env9010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env8991 == env9010) = true)

theorem identity9010 : scanCanonicalize (H12AffineFastState.compose env9010 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 26009) := by decide +kernel

theorem selectedBound9010 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,1024,32768,1344,4194304,17664,98564,26009,64,4473877,16384,1296,4312474,1284,4294967296,257,4299260334,1344,18193]

theorem envBound9011 : H12AffineFastState.Bounded env9011 := by
  intro p hp
  have h : env9011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9010_9011 : H12AffineEnvironment.transform 24 26009 env9010 = env9011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26009 env9010 == env9011) = true)

theorem identity9011 : scanCanonicalize (H12AffineFastState.compose env9011 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 19776) := by decide +kernel

theorem selectedBound9011 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env9012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,19776,65536,1345,262144,1024,19776,1344,4194304,17664,85060,26009,64,4473877,16384,1296,4260058,1284,4294967296,257,4299246830,1344,18193]

theorem envBound9012 : H12AffineFastState.Bounded env9012 := by
  intro p hp
  have h : env9012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9011_9012 : H12AffineEnvironment.transform 14 19776 env9011 = env9012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19776 env9011 == env9012) = true)

theorem identity9012 : scanCanonicalize (H12AffineFastState.compose env9012 (packedSelected [3,10,13,15,17,21,24] rootPS)) = affineNative (2^(21+1) ^^^ 92131) := by decide +kernel

theorem selectedBound9012 : packedSelected [3,10,13,15,17,21,24] rootPS < 2^1333 := by decide +kernel

def env9013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,19776,65536,1345,262144,1024,19776,1344,92131,17664,85060,26009,64,336886,16384,1296,26425,1284,4294967296,257,4294978317,1344,18193]

theorem envBound9013 : H12AffineFastState.Bounded env9013 := by
  intro p hp
  have h : env9013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9012_9013 : H12AffineEnvironment.transform 21 92131 env9012 = env9013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 92131 env9012 == env9013) = true)

theorem identity9013 : scanCanonicalize (H12AffineFastState.compose env9013 (packedSelected [6,25] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound9013 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2128,65536,1345,262144,1024,2128,1344,74483,16,67924,8329,64,336886,1296,1296,8745,1284,4294967296,257,4294978317,1344,513]

theorem envBound9014 : H12AffineFastState.Bounded env9014 := by
  intro p hp
  have h : env9014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9013_9014 : H12AffineEnvironment.transform 13 1296 env9013 = env9014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env9013 == env9014) = true)

theorem identity9014 : scanCanonicalize (H12AffineFastState.compose env9014 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 2731) := by decide +kernel

theorem selectedBound9014 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2128,2731,1345,262144,1024,2128,1344,10328,16,1023,8329,64,272733,1296,1296,8745,1284,4294967296,257,4294978317,1344,513]

theorem envBound9015 : H12AffineFastState.Bounded env9015 := by
  intro p hp
  have h : env9015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9014_9015 : H12AffineEnvironment.transform 15 2731 env9014 = env9015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2731 env9014 == env9015) = true)

theorem identity9015 : scanCanonicalize (H12AffineFastState.compose env9015 (packedSelected [1,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 8999) := by decide +kernel

theorem selectedBound9015 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2128,2731,1345,262144,1024,2128,1344,10328,16,1023,8329,64,272733,1296,1296,8745,1284,8999,257,2090,1344,513]

theorem envBound9016 : H12AffineFastState.Bounded env9016 := by
  intro p hp
  have h : env9016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9015_9016 : H12AffineEnvironment.transform 31 8999 env9015 = env9016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8999 env9015 == env9016) = true)

theorem identity9016 : scanCanonicalize (H12AffineFastState.compose env9016 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound9016 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,814,1345,8192,1296,894,389,1345,262144,1024,894,1344,9078,16,1023,8329,64,270963,1296,1296,8745,1284,8999,257,772,1344,513]

theorem envBound9017 : H12AffineFastState.Bounded env9017 := by
  intro p hp
  have h : env9017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9016_9017 : H12AffineEnvironment.transform 10 814 env9016 = env9017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env9016 == env9017) = true)

theorem identity9017 : scanCanonicalize (H12AffineFastState.compose env9017 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 114) := by decide +kernel

theorem selectedBound9017 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env9018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,814,1345,114,1296,894,389,1345,262144,1024,894,1344,772,16,1023,251,64,262657,1296,1296,603,1284,853,257,772,1344,513]

theorem envBound9018 : H12AffineFastState.Bounded env9018 := by
  intro p hp
  have h : env9018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9017_9018 : H12AffineEnvironment.transform 12 114 env9017 = env9018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 114 env9017 == env9018) = true)

theorem identity9018 : scanCanonicalize (H12AffineFastState.compose env9018 (packedSelected [0,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9018 : packedSelected [0,6,11,18] rootPS < 2^1333 := by decide +kernel

def env9019 : List Nat := [2,4,8,16,32,64,128,37,512,1024,523,1124,114,1077,603,160,1124,262144,1024,603,1125,545,16,730,251,64,262657,1077,1077,603,1057,624,36,545,1125,513]

theorem envBound9019 : H12AffineFastState.Bounded env9019 := by
  intro p hp
  have h : env9019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9018_9019 : H12AffineEnvironment.transform 7 37 env9018 = env9019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9018 == env9019) = true)

theorem identity9019 : scanCanonicalize (H12AffineFastState.compose env9019 (packedSelected [0,2,5,6,8] rootPS)) = affineNative (2^(17+1) ^^^ 587) := by decide +kernel

theorem selectedBound9019 : packedSelected [0,2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env9020 : List Nat := [2,4,8,16,32,64,128,37,512,1024,523,1124,114,1077,603,160,1124,587,1024,603,1125,545,16,730,251,64,74,1077,1077,603,1057,624,36,545,1125,513]

theorem envBound9020 : H12AffineFastState.Bounded env9020 := by
  intro p hp
  have h : env9020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9019_9020 : H12AffineEnvironment.transform 17 587 env9019 = env9020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 587 env9019 == env9020) = true)

theorem identity9020 : scanCanonicalize (H12AffineFastState.compose env9020 (packedSelected [1,2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9020 : packedSelected [1,2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env9021 : List Nat := [2,4,8,16,32,0,128,37,512,1024,523,1060,50,1077,539,160,1060,523,1024,539,1061,545,16,666,187,0,10,1077,1077,539,1057,560,36,545,1061,513]

theorem envBound9021 : H12AffineFastState.Bounded env9021 := by
  intro p hp
  have h : env9021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9020_9021 : H12AffineEnvironment.transform 5 0 env9020 = env9021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9020 == env9021) = true)

theorem identity9021 : scanCanonicalize (H12AffineFastState.compose env9021 (packedSelected [0,1,2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound9021 : packedSelected [0,1,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env9022 : List Nat := [2,4,8,16,32,0,128,37,0,1024,11,1060,50,1077,27,160,1060,11,1024,27,1061,33,16,154,187,0,10,1077,1077,27,1057,48,36,33,1061,1]

theorem envBound9022 : H12AffineFastState.Bounded env9022 := by
  intro p hp
  have h : env9022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9021_9022 : H12AffineEnvironment.transform 8 0 env9021 = env9022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env9021 == env9022) = true)

theorem identity9022 : scanCanonicalize (H12AffineFastState.compose env9022 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound9022 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9023 : List Nat := [2,4,8,16,32,0,128,37,0,141,11,169,50,184,27,160,169,11,141,27,168,33,16,154,187,0,10,184,184,27,172,48,36,33,168,1]

theorem envBound9023 : H12AffineFastState.Bounded env9023 := by
  intro p hp
  have h : env9023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9022_9023 : H12AffineEnvironment.transform 9 141 env9022 = env9023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env9022 == env9023) = true)

theorem identity9023 : scanCanonicalize (H12AffineFastState.compose env9023 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9023 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9024 : List Nat := [2,4,8,16,32,0,41,37,0,36,11,0,50,17,27,9,0,11,36,27,1,33,16,51,18,0,10,17,17,27,5,48,36,33,1,1]

theorem envBound9024 : H12AffineFastState.Bounded env9024 := by
  intro p hp
  have h : env9024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9023_9024 : H12AffineEnvironment.transform 6 41 env9023 = env9024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9023 == env9024) = true)

theorem identity9024 : scanCanonicalize (H12AffineFastState.compose env9024 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9024 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9025 : List Nat := [2,4,8,16,26,0,19,31,0,30,11,0,8,17,27,9,0,11,30,27,1,27,16,9,18,0,10,17,17,27,5,10,30,27,1,1]

theorem envBound9025 : H12AffineFastState.Bounded env9025 := by
  intro p hp
  have h : env9025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9024_9025 : H12AffineEnvironment.transform 4 26 env9024 = env9025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9024 == env9025) = true)

theorem identity9025 : scanCanonicalize (H12AffineFastState.compose env9025 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9025 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9026 : List Nat := [2,4,8,1,11,0,2,14,0,15,11,0,8,0,10,9,0,11,15,10,1,10,1,9,3,0,10,0,0,10,5,10,15,10,1,1]

theorem envBound9026 : H12AffineFastState.Bounded env9026 := by
  intro p hp
  have h : env9026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2