import H12CloudChart2Data080

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env19882 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,1,398,1345,25961,16704,0,4097,8200,17664,139,8328,17,293,16385,4097,25676,1285,4294967296,257,4294975529,1344,137]

theorem envBound19882 : H12AffineFastState.Bounded env19882 := by
  intro p hp
  have h : env19882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19866_19882 : H12AffineEnvironment.transform 14 1 env19866 = env19882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19866 == env19882) = true)

theorem identity19882 : scanCanonicalize (H12AffineFastState.compose env19882 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4469) := by decide +kernel

theorem selectedBound19882 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env19883 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4469,1,398,1345,13340,4149,0,4097,8200,5237,139,8328,17,293,4468,4097,13625,1285,4294967296,257,4294975529,1344,137]

theorem envBound19883 : H12AffineFastState.Bounded env19883 := by
  intro p hp
  have h : env19883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19882_19883 : H12AffineEnvironment.transform 13 4469 env19882 = env19883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4469 env19882 == env19883) = true)

theorem identity19883 : scanCanonicalize (H12AffineFastState.compose env19883 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19883 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19884 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,40,4469,1,398,1345,5172,4149,0,4097,32,5237,139,160,17,293,4468,4097,5393,1285,4294967296,257,4294967297,1344,137]

theorem envBound19884 : H12AffineFastState.Bounded env19884 := by
  intro p hp
  have h : env19884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19883_19884 : H12AffineEnvironment.transform 12 40 env19883 = env19884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19883 == env19884) = true)

theorem identity19884 : scanCanonicalize (H12AffineFastState.compose env19884 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19884 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19885 : List Nat := [2,4,8,16,32,64,128,37,137,1024,0,4096,40,4176,1,171,1124,5172,4149,0,4097,32,5237,139,160,17,0,4177,4097,5172,1056,4294967296,36,4294967297,1125,137]

theorem envBound19885 : H12AffineFastState.Bounded env19885 := by
  intro p hp
  have h : env19885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19884_19885 : H12AffineEnvironment.transform 7 37 env19884 = env19885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19884 == env19885) = true)

theorem identity19885 : scanCanonicalize (H12AffineFastState.compose env19885 (packedSelected [0,1,2] rootPS)) = affineNative (2^(31+1) ^^^ 33) := by decide +kernel

theorem selectedBound19885 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env19886 : List Nat := [2,4,8,16,32,64,128,37,137,1024,0,4096,40,4176,1,171,1124,5172,4149,0,4097,32,5237,139,160,17,0,4177,4097,5172,1056,33,36,32,1125,137]

theorem envBound19886 : H12AffineFastState.Bounded env19886 := by
  intro p hp
  have h : env19886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19885_19886 : H12AffineEnvironment.transform 31 33 env19885 = env19886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33 env19885 == env19886) = true)

theorem identity19886 : scanCanonicalize (H12AffineFastState.compose env19886 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound19886 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19887 : List Nat := [2,4,8,16,32,64,128,37,137,1024,0,1076,40,1124,1,171,1124,0,1025,0,1077,32,65,139,160,17,0,1125,1077,0,1056,33,36,32,1125,137]

theorem envBound19887 : H12AffineFastState.Bounded env19887 := by
  intro p hp
  have h : env19887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19886_19887 : H12AffineEnvironment.transform 11 1076 env19886 = env19887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env19886 == env19887) = true)

theorem identity19887 : scanCanonicalize (H12AffineFastState.compose env19887 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19888 : List Nat := [2,4,8,16,32,48,128,37,137,1024,0,1076,40,1044,1,171,1044,0,1025,0,1077,32,49,139,160,17,0,1045,1077,0,1056,33,36,32,1045,137]

theorem envBound19888 : H12AffineFastState.Bounded env19888 := by
  intro p hp
  have h : env19888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19887_19888 : H12AffineEnvironment.transform 5 48 env19887 = env19888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19887 == env19888) = true)

theorem identity19888 : scanCanonicalize (H12AffineFastState.compose env19888 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19889 : List Nat := [2,4,8,16,32,48,40,37,33,1024,0,1076,40,1044,1,3,1044,0,1025,0,1077,32,49,35,8,17,0,1045,1077,0,1056,33,36,32,1045,33]

theorem envBound19889 : H12AffineFastState.Bounded env19889 := by
  intro p hp
  have h : env19889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19888_19889 : H12AffineEnvironment.transform 6 40 env19888 = env19889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19888 == env19889) = true)

theorem identity19889 : scanCanonicalize (H12AffineFastState.compose env19889 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19889 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19890 : List Nat := [2,4,8,16,0,16,8,5,1,1024,0,1044,8,1044,1,3,1044,0,1025,0,1045,0,17,3,8,17,0,1045,1045,0,1024,1,4,0,1045,1]

theorem envBound19890 : H12AffineFastState.Bounded env19890 := by
  intro p hp
  have h : env19890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19889_19890 : H12AffineEnvironment.transform 4 0 env19889 = env19890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19889 == env19890) = true)

def env19891 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,33167,1345,58729,16705,32769,4097,8200,17664,139,8328,16,33060,16385,4096,25677,1285,4294967296,257,4294975529,1344,137]

theorem envBound19891 : H12AffineFastState.Bounded env19891 := by
  intro p hp
  have h : env19891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19865_19891 : H12AffineEnvironment.transform 17 58729 env19865 = env19891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env19865 == env19891) = true)

def env19892 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,0,399,1345,25961,16705,1,4097,8200,17664,139,8328,16,292,16385,4096,25677,1285,4294967296,257,4294975529,1344,137]

theorem envBound19892 : H12AffineFastState.Bounded env19892 := by
  intro p hp
  have h : env19892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19891_19892 : H12AffineEnvironment.transform 14 0 env19891 = env19892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19891 == env19892) = true)

theorem identity19892 : scanCanonicalize (H12AffineFastState.compose env19892 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19892 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env19893 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,16384,0,399,1345,25961,16705,1,1297,8200,17664,139,8328,16,292,16385,1296,25677,1285,4294967296,257,4294975529,1344,137]

theorem envBound19893 : H12AffineFastState.Bounded env19893 := by
  intro p hp
  have h : env19893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19892_19893 : H12AffineEnvironment.transform 11 1296 env19892 = env19893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19892 == env19893) = true)

def env19894 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,0,399,1345,8233,1025,1,1297,8200,64,139,8328,16,292,1345,1296,8461,1285,4294967296,257,4294975529,1344,137]

theorem envBound19894 : H12AffineFastState.Bounded env19894 := by
  intro p hp
  have h : env19894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19893_19894 : H12AffineEnvironment.transform 13 1344 env19893 = env19894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19893 == env19894) = true)

theorem identity19894 : scanCanonicalize (H12AffineFastState.compose env19894 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound19894 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19895 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,161,1344,0,399,1345,136,1025,1,1297,169,64,139,41,16,292,1345,1296,428,1285,4294967296,257,4294967432,1344,137]

theorem envBound19895 : H12AffineFastState.Bounded env19895 := by
  intro p hp
  have h : env19895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19894_19895 : H12AffineEnvironment.transform 12 161 env19894 = env19895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env19894 == env19895) = true)

theorem identity19895 : scanCanonicalize (H12AffineFastState.compose env19895 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19895 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19896 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,161,1296,0,399,1297,136,1025,1,1297,169,16,139,41,16,292,1297,1296,428,1285,4294967296,257,4294967432,1296,137]

theorem envBound19896 : H12AffineFastState.Bounded env19896 := by
  intro p hp
  have h : env19896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19895_19896 : H12AffineEnvironment.transform 5 16 env19895 = env19896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19895 == env19896) = true)

theorem identity19896 : scanCanonicalize (H12AffineFastState.compose env19896 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19897 : List Nat := [2,4,8,16,32,16,8,256,1,1024,0,1296,41,1296,0,263,1297,0,1025,1,1297,33,16,3,41,16,292,1297,1296,292,1285,4294967296,257,4294967296,1296,1]

theorem envBound19897 : H12AffineFastState.Bounded env19897 := by
  intro p hp
  have h : env19897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19896_19897 : H12AffineEnvironment.transform 6 8 env19896 = env19897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19896 == env19897) = true)

theorem identity19897 : scanCanonicalize (H12AffineFastState.compose env19897 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound19897 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19898 : List Nat := [2,4,8,16,32,16,8,256,1,1024,0,1296,41,1296,0,263,1297,0,1025,1,1297,33,16,3,41,16,292,1297,1296,292,1285,293,257,293,1296,1]

theorem envBound19898 : H12AffineFastState.Bounded env19898 := by
  intro p hp
  have h : env19898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19897_19898 : H12AffineEnvironment.transform 31 293 env19897 = env19898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env19897 == env19898) = true)

def env19899 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1345,0,399,1345,8232,1024,1,1297,8200,65,139,8328,16,292,1344,1296,8460,1285,4294967296,257,4294975529,1344,137]

theorem envBound19899 : H12AffineFastState.Bounded env19899 := by
  intro p hp
  have h : env19899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19893_19899 : H12AffineEnvironment.transform 13 1345 env19893 = env19899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19893 == env19899) = true)

theorem identity19899 : scanCanonicalize (H12AffineFastState.compose env19899 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19899 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19900 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1076,8192,1125,0,171,1125,8232,1024,1,1077,8200,65,139,8328,16,0,1124,1076,8232,1057,4294967296,37,4294975529,1124,137]

theorem envBound19900 : H12AffineFastState.Bounded env19900 := by
  intro p hp
  have h : env19900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19899_19900 : H12AffineEnvironment.transform 7 36 env19899 = env19900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19899 == env19900) = true)

theorem identity19900 : scanCanonicalize (H12AffineFastState.compose env19900 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19900 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19901 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1076,40,1125,0,171,1125,0,1024,1,1077,32,65,139,160,16,0,1124,1076,0,1057,4294967296,37,4294967297,1124,137]

theorem envBound19901 : H12AffineFastState.Bounded env19901 := by
  intro p hp
  have h : env19901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19900_19901 : H12AffineEnvironment.transform 12 40 env19900 = env19901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19900 == env19901) = true)

theorem identity19901 : scanCanonicalize (H12AffineFastState.compose env19901 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound19901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19902 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1076,40,1125,0,171,1125,0,1024,1,1077,32,65,139,160,16,0,1124,1076,0,1057,137,37,136,1124,137]

theorem envBound19902 : H12AffineFastState.Bounded env19902 := by
  intro p hp
  have h : env19902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19901_19902 : H12AffineEnvironment.transform 31 137 env19901 = env19902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env19901 == env19902) = true)

theorem identity19902 : scanCanonicalize (H12AffineFastState.compose env19902 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound19902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19903 : List Nat := [2,4,8,16,32,64,34,36,43,1024,0,1076,40,1125,0,9,1125,0,1024,1,1077,32,65,41,2,16,0,1124,1076,0,1057,43,37,42,1124,43]

theorem envBound19903 : H12AffineFastState.Bounded env19903 := by
  intro p hp
  have h : env19903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19902_19903 : H12AffineEnvironment.transform 6 34 env19902 = env19903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env19902 == env19903) = true)

theorem identity19903 : scanCanonicalize (H12AffineFastState.compose env19903 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19904 : List Nat := [2,4,8,16,27,64,25,31,16,1024,0,1039,19,1118,0,9,1118,0,1024,1,1038,27,65,18,2,16,0,1119,1039,0,1050,16,30,17,1119,16]

theorem envBound19904 : H12AffineFastState.Bounded env19904 := by
  intro p hp
  have h : env19904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19903_19904 : H12AffineEnvironment.transform 4 27 env19903 = env19904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19903 == env19904) = true)

def leafEnv19904 : List Nat := [2,4,8,16,27,64,25,31,16,1024,0,1039,19,1118,0,9,1118,0,1024,1,1038,27,65,18,1050,2,1,16,0,1119,1039,0,1050,16,30,17,5,25,1119,16,0,1038,1]

def active19904 : List Nat := [0,1,2,3,5,9]

def tree19904 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19904 : H12WitnessSearch.Good tree19904 := H12GlobalWitnessIndex.good

theorem leafIdentity19904 : H12AffineFastState.composeSystem env19904 rootObs = leafEnv19904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19904 rootObs == leafEnv19904) = true)

theorem terminalChecked19904 : H12PackedTerminal.terminalCheckFast leafEnv19904 active19904 tree19904 = true := by decide +kernel

def env19905 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,1,398,1345,25960,16705,0,4097,8200,17664,139,8328,16,293,16385,4096,25677,1285,4294967296,257,4294975529,1344,137]

theorem envBound19905 : H12AffineFastState.Bounded env19905 := by
  intro p hp
  have h : env19905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19891_19905 : H12AffineEnvironment.transform 14 1 env19891 = env19905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19891 == env19905) = true)

theorem identity19905 : scanCanonicalize (H12AffineFastState.compose env19905 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound19905 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env19906 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4176,1,398,1345,13624,4369,0,4097,8200,5456,139,8328,16,293,4177,4096,13341,1285,4294967296,257,4294975529,1344,137]

theorem envBound19906 : H12AffineFastState.Bounded env19906 := by
  intro p hp
  have h : env19906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19905_19906 : H12AffineEnvironment.transform 13 4176 env19905 = env19906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env19905 == env19906) = true)

theorem identity19906 : scanCanonicalize (H12AffineFastState.compose env19906 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19906 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19907 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,1,398,1345,8232,1025,0,1297,8200,64,139,8328,16,293,1345,1296,8461,1285,4294967296,257,4294975529,1344,137]

theorem envBound19907 : H12AffineFastState.Bounded env19907 := by
  intro p hp
  have h : env19907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19906_19907 : H12AffineEnvironment.transform 11 1296 env19906 = env19907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19906 == env19907) = true)

theorem identity19907 : scanCanonicalize (H12AffineFastState.compose env19907 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound19907 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19908 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,160,1344,1,398,1345,136,1025,0,1297,168,64,139,40,16,293,1345,1296,429,1285,4294967296,257,4294967433,1344,137]

theorem envBound19908 : H12AffineFastState.Bounded env19908 := by
  intro p hp
  have h : env19908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19907_19908 : H12AffineEnvironment.transform 12 160 env19907 = env19908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env19907 == env19908) = true)

theorem identity19908 : scanCanonicalize (H12AffineFastState.compose env19908 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19908 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19909 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,160,1296,1,398,1297,136,1025,0,1297,168,16,139,40,16,293,1297,1296,429,1285,4294967296,257,4294967433,1296,137]

theorem envBound19909 : H12AffineFastState.Bounded env19909 := by
  intro p hp
  have h : env19909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19908_19909 : H12AffineEnvironment.transform 5 16 env19908 = env19909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19908 == env19909) = true)

theorem identity19909 : scanCanonicalize (H12AffineFastState.compose env19909 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19909 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19910 : List Nat := [2,4,8,16,32,16,9,256,0,1024,0,1296,41,1296,1,263,1297,1,1025,0,1297,33,16,2,40,16,293,1297,1296,292,1285,4294967296,257,4294967296,1296,0]

theorem envBound19910 : H12AffineFastState.Bounded env19910 := by
  intro p hp
  have h : env19910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19909_19910 : H12AffineEnvironment.transform 6 9 env19909 = env19910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19909 == env19910) = true)

theorem identity19910 : scanCanonicalize (H12AffineFastState.compose env19910 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound19910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19911 : List Nat := [2,4,8,16,32,16,9,256,0,1024,0,1296,41,1296,1,263,1297,1,1025,0,1297,33,16,2,40,16,293,1297,1296,292,1285,292,257,292,1296,0]

theorem envBound19911 : H12AffineFastState.Bounded env19911 := by
  intro p hp
  have h : env19911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19910_19911 : H12AffineEnvironment.transform 31 292 env19910 = env19911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env19910 == env19911) = true)

theorem identity19911 : scanCanonicalize (H12AffineFastState.compose env19911 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19912 : List Nat := [2,4,8,16,32,16,9,37,0,1024,0,1077,41,1077,1,34,1076,1,1025,0,1076,33,16,2,40,16,0,1076,1077,1,1056,1,36,1,1077,0]

theorem envBound19912 : H12AffineFastState.Bounded env19912 := by
  intro p hp
  have h : env19912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19911_19912 : H12AffineEnvironment.transform 7 37 env19911 = env19912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19911 == env19912) = true)

def env19913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,147521,230469,8328,672784,925772,16385,676864,1073741824,131140,4294967296,257,4295206118,1344,512]

theorem envBound19913 : H12AffineFastState.Bounded env19913 := by
  intro p hp
  have h : env19913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19750_19913 : H12AffineEnvironment.transform 10 1 env19750 = env19913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19750 == env19913) = true)

def env19914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98565,8328,541008,795916,16385,545088,1073741824,1284,4294967296,257,4295074214,1344,512]

theorem envBound19914 : H12AffineFastState.Bounded env19914 := by
  intro p hp
  have h : env19914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19913_19914 : H12AffineEnvironment.transform 16 1344 env19913 = env19914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19913 == env19914) = true)

theorem identity19914 : scanCanonicalize (H12AffineFastState.compose env19914 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 533853) := by decide +kernel

theorem selectedBound19914 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98565,8328,541008,795916,16385,545088,533853,1284,4294967296,257,4295074214,1344,512]

theorem envBound19915 : H12AffineFastState.Bounded env19915 := by
  intro p hp
  have h : env19915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19914_19915 : H12AffineEnvironment.transform 29 533853 env19914 = env19915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 533853 env19914 == env19915) = true)

theorem identity19915 : scanCanonicalize (H12AffineFastState.compose env19915 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound19915 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env19916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8201,17665,98565,8328,17745,270605,16385,21825,8540,1284,4294967296,257,4295074214,1344,512]

theorem envBound19916 : H12AffineFastState.Bounded env19916 := by
  intro p hp
  have h : env19916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19915_19916 : H12AffineEnvironment.transform 18 1025 env19915 = env19916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19915 == env19916) = true)

theorem identity19916 : scanCanonicalize (H12AffineFastState.compose env19916 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound19916 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env19917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33246,1344,262144,1025,32769,4097,8201,17665,219,8328,17745,270605,16385,21825,8540,1284,4294967296,257,4294975608,1344,512]

theorem envBound19917 : H12AffineFastState.Bounded env19917 := by
  intro p hp
  have h : env19917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19916_19917 : H12AffineEnvironment.transform 15 33246 env19916 = env19917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env19916 == env19917) = true)

theorem identity19917 : scanCanonicalize (H12AffineFastState.compose env19917 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound19917 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,33246,1344,262144,1025,32769,4097,8201,5457,219,8328,5377,270605,4177,1297,8540,1284,4294967296,257,4294975608,1344,512]

theorem envBound19918 : H12AffineFastState.Bounded env19918 := by
  intro p hp
  have h : env19918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19917_19918 : H12AffineEnvironment.transform 13 4176 env19917 = env19918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env19917 == env19918) = true)

theorem identity19918 : scanCanonicalize (H12AffineFastState.compose env19918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound19918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,33246,1344,262144,1025,32769,4097,8201,5457,219,8328,5377,270605,4177,1297,8540,1284,8321,257,249,1344,512]

theorem envBound19919 : H12AffineFastState.Bounded env19919 := by
  intro p hp
  have h : env19919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19918_19919 : H12AffineEnvironment.transform 31 8321 env19918 = env19919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env19918 == env19919) = true)

theorem identity19919 : scanCanonicalize (H12AffineFastState.compose env19919 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41081) := by decide +kernel

theorem selectedBound19919 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env19920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,33246,1344,41081,1025,32769,4097,8201,5457,219,8328,5377,33140,4177,1297,8540,1284,8321,257,249,1344,512]

theorem envBound19920 : H12AffineFastState.Bounded env19920 := by
  intro p hp
  have h : env19920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19919_19920 : H12AffineEnvironment.transform 17 41081 env19919 = env19920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41081 env19919 == env19920) = true)

theorem identity19920 : scanCanonicalize (H12AffineFastState.compose env19920 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 13388) := by decide +kernel

theorem selectedBound19920 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,13388,13714,1344,5173,1025,13389,4097,8201,5457,219,8328,5377,13624,4177,1297,8540,1284,8321,257,249,1344,512]

theorem envBound19921 : H12AffineFastState.Bounded env19921 := by
  intro p hp
  have h : env19921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19920_19921 : H12AffineEnvironment.transform 14 13388 env19920 = env19921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13388 env19920 == env19921) = true)

theorem identity19921 : scanCanonicalize (H12AffineFastState.compose env19921 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 5317) := by decide +kernel

theorem selectedBound19921 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env19922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5317,4176,137,343,1344,5173,1025,136,4097,5324,5457,219,5197,5377,509,4177,1297,5529,1284,5188,257,249,1344,512]

theorem envBound19922 : H12AffineFastState.Bounded env19922 := by
  intro p hp
  have h : env19922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19921_19922 : H12AffineEnvironment.transform 12 5317 env19921 = env19922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5317 env19921 == env19922) = true)

theorem identity19922 : scanCanonicalize (H12AffineFastState.compose env19922 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound19922 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1465,380,1513,137,343,1344,396,1025,136,1464,373,232,219,500,184,509,1512,1297,32,1284,509,257,249,1344,512]

theorem envBound19923 : H12AffineFastState.Bounded env19923 := by
  intro p hp
  have h : env19923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19922_19923 : H12AffineEnvironment.transform 11 1465 env19922 = env19923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env19922 == env19923) = true)

theorem identity19923 : scanCanonicalize (H12AffineFastState.compose env19923 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound19923 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env19924 : List Nat := [2,4,8,16,32,64,128,189,512,1024,1,1028,193,1108,137,234,1277,49,1025,136,1029,200,232,219,73,184,64,1109,1196,32,1209,64,188,249,1277,512]

theorem envBound19924 : H12AffineFastState.Bounded env19924 := by
  intro p hp
  have h : env19924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19923_19924 : H12AffineEnvironment.transform 7 189 env19923 = env19924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env19923 == env19924) = true)

def env19925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541009,795917,16385,545089,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound19925 : H12AffineFastState.Bounded env19925 := by
  intro p hp
  have h : env19925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19913_19925 : H12AffineEnvironment.transform 16 1345 env19913 = env19925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env19913 == env19925) = true)

theorem identity19925 : scanCanonicalize (H12AffineFastState.compose env19925 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 533772) := by decide +kernel

theorem selectedBound19925 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541009,795917,16385,545089,533772,1285,4294967296,257,4295074215,1344,512]

theorem envBound19926 : H12AffineFastState.Bounded env19926 := by
  intro p hp
  have h : env19926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19925_19926 : H12AffineEnvironment.transform 29 533772 env19925 = env19926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 533772 env19925 == env19926) = true)

theorem identity19926 : scanCanonicalize (H12AffineFastState.compose env19926 (packedSelected [4,9,20] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound19926 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env19927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98564,8328,320888,33060,16385,324968,295205,1285,4294967296,257,4295074215,1344,512]

theorem envBound19927 : H12AffineFastState.Bounded env19927 := by
  intro p hp
  have h : env19927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19926_19927 : H12AffineEnvironment.transform 18 304169 env19926 = env19927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env19926 == env19927) = true)

def env19928 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98564,8328,320888,33060,16385,324968,295205,1285,4294967296,257,4295074215,1344,136]

theorem envBound19928 : H12AffineFastState.Bounded env19928 := by
  intro p hp
  have h : env19928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19927_19928 : H12AffineEnvironment.transform 8 136 env19927 = env19928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19927 == env19928) = true)

def env19929 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,32768,65536,1345,0,42025,32769,4097,8201,17664,98564,8328,58744,33060,16385,62824,33061,1285,4294967296,257,4295074215,1344,136]

theorem envBound19929 : H12AffineFastState.Bounded env19929 := by
  intro p hp
  have h : env19929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19928_19929 : H12AffineEnvironment.transform 17 0 env19928 = env19929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env19928 == env19929) = true)

def env19930 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,16384,32768,65536,1345,0,42025,32769,1297,8201,17664,98564,8328,58744,33060,16385,57464,33061,1285,4294967296,257,4295074215,1344,136]

theorem envBound19930 : H12AffineFastState.Bounded env19930 := by
  intro p hp
  have h : env19930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19929_19930 : H12AffineEnvironment.transform 11 1296 env19929 = env19930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19929 == env19930) = true)

theorem identity19930 : scanCanonicalize (H12AffineFastState.compose env19930 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9292) := by decide +kernel

theorem selectedBound19930 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19931 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,9292,32768,65536,1345,0,42025,32769,1297,8201,8524,98564,8328,33076,33060,9293,33844,33061,1285,4294967296,257,4295074215,1344,136]

theorem envBound19931 : H12AffineFastState.Bounded env19931 := by
  intro p hp
  have h : env19931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19930_19931 : H12AffineEnvironment.transform 13 9292 env19930 = env19931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9292 env19930 == env19931) = true)

theorem identity19931 : scanCanonicalize (H12AffineFastState.compose env19931 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound19931 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19932 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,9292,292,65536,1345,0,9485,293,1297,8201,8524,65568,8328,16,0,9293,1296,1,1285,4294967296,257,4295041155,1344,136]

theorem envBound19932 : H12AffineFastState.Bounded env19932 := by
  intro p hp
  have h : env19932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19931_19932 : H12AffineEnvironment.transform 14 292 env19931 = env19932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env19931 == env19932) = true)

theorem identity19932 : scanCanonicalize (H12AffineFastState.compose env19932 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19932 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env19933 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,268,1344,292,65536,1345,0,1025,293,1297,261,64,65568,388,16,0,1345,1296,1,1285,4294967296,257,4295033231,1344,136]

theorem envBound19933 : H12AffineFastState.Bounded env19933 := by
  intro p hp
  have h : env19933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19932_19933 : H12AffineEnvironment.transform 12 268 env19932 = env19933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19932 == env19933) = true)

def env19934 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1076,40,1124,0,65536,1125,0,1025,1,1077,33,64,65568,160,16,0,1125,1076,1,1057,4294967296,37,4295033003,1124,136]

theorem envBound19934 : H12AffineFastState.Bounded env19934 := by
  intro p hp
  have h : env19934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19933_19934 : H12AffineEnvironment.transform 7 36 env19933 = env19934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19933 == env19934) = true)

theorem identity19934 : scanCanonicalize (H12AffineFastState.compose env19934 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 216) := by decide +kernel

theorem selectedBound19934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19935 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1076,40,1124,0,65536,1125,0,1025,1,1077,33,64,65568,160,16,0,1125,1076,1,1057,216,37,65651,1124,136]

theorem envBound19935 : H12AffineFastState.Bounded env19935 := by
  intro p hp
  have h : env19935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19934_19935 : H12AffineEnvironment.transform 31 216 env19934 = env19935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 216 env19934 == env19935) = true)

theorem identity19935 : scanCanonicalize (H12AffineFastState.compose env19935 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19935 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19936 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1076,40,1124,0,170,1125,0,1025,1,1077,33,64,138,160,16,0,1125,1076,1,1057,216,37,217,1124,136]

theorem envBound19936 : H12AffineFastState.Bounded env19936 := by
  intro p hp
  have h : env19936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19935_19936 : H12AffineEnvironment.transform 15 170 env19935 = env19936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19935 == env19936) = true)

theorem identity19936 : scanCanonicalize (H12AffineFastState.compose env19936 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19936 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19937 : List Nat := [2,4,8,16,32,64,128,36,136,100,1,80,40,0,0,170,1,0,101,1,81,33,64,138,160,16,0,1,80,1,69,216,37,217,0,136]

theorem envBound19937 : H12AffineFastState.Bounded env19937 := by
  intro p hp
  have h : env19937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19936_19937 : H12AffineEnvironment.transform 9 100 env19936 = env19937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19936 == env19937) = true)

theorem identity19937 : scanCanonicalize (H12AffineFastState.compose env19937 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19938 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,40,0,0,170,1,0,52,1,0,33,17,138,160,16,0,1,1,1,20,137,37,136,0,136]

theorem envBound19938 : H12AffineFastState.Bounded env19938 := by
  intro p hp
  have h : env19938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19937_19938 : H12AffineEnvironment.transform 5 17 env19937 = env19938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19937 == env19938) = true)

theorem identity19938 : scanCanonicalize (H12AffineFastState.compose env19938 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19938 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19939 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,0,0,138,1,0,20,1,0,1,17,138,128,16,0,1,1,1,20,137,5,136,0,136]

theorem envBound19939 : H12AffineFastState.Bounded env19939 := by
  intro p hp
  have h : env19939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19938_19939 : H12AffineEnvironment.transform 4 0 env19938 = env19939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19938 == env19939) = true)

def leafEnv19939 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,0,0,138,1,0,20,1,0,1,17,138,21,128,1,16,0,1,1,1,20,137,5,136,5,2,0,136,0,0,1]

def active19939 : List Nat := [0,1,2,3,6]

def tree19939 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19939 : H12WitnessSearch.Good tree19939 := H12GlobalWitnessIndex.good

theorem leafIdentity19939 : H12AffineFastState.composeSystem env19939 rootObs = leafEnv19939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19939 rootObs == leafEnv19939) = true)

theorem terminalChecked19939 : H12PackedTerminal.terminalCheckFast leafEnv19939 active19939 tree19939 = true := by decide +kernel

def env19940 : List Nat := [2,4,8,16,32,64,128,37,136,1024,1,1077,41,1125,1,65536,1124,0,1025,0,1076,32,64,65568,161,16,0,1124,1077,1,1056,4294967296,36,4295033002,1125,136]

theorem envBound19940 : H12AffineFastState.Bounded env19940 := by
  intro p hp
  have h : env19940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19933_19940 : H12AffineEnvironment.transform 7 37 env19933 = env19940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19933 == env19940) = true)

theorem identity19940 : scanCanonicalize (H12AffineFastState.compose env19940 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65786) := by decide +kernel

theorem selectedBound19940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19941 : List Nat := [2,4,8,16,32,64,128,37,136,1024,1,1077,41,1125,1,65536,1124,0,1025,0,1076,32,64,65568,161,16,0,1124,1077,1,1056,65786,36,80,1125,136]

theorem envBound19941 : H12AffineFastState.Bounded env19941 := by
  intro p hp
  have h : env19941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19940_19941 : H12AffineEnvironment.transform 31 65786 env19940 = env19941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65786 env19940 == env19941) = true)

def env19942 : List Nat := [2,4,8,16,32,64,128,37,136,100,1,81,41,1,1,65536,0,0,101,0,80,32,64,65568,161,16,0,0,81,1,68,65786,36,80,1,136]

theorem envBound19942 : H12AffineFastState.Bounded env19942 := by
  intro p hp
  have h : env19942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19941_19942 : H12AffineEnvironment.transform 9 100 env19941 = env19942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19941 == env19942) = true)

theorem identity19942 : scanCanonicalize (H12AffineFastState.compose env19942 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound19942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19943 : List Nat := [2,4,8,16,32,64,128,37,136,100,1,81,41,1,1,250,0,0,101,0,80,32,64,218,161,16,0,0,81,1,68,0,36,80,1,136]

theorem envBound19943 : H12AffineFastState.Bounded env19943 := by
  intro p hp
  have h : env19943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19942_19943 : H12AffineEnvironment.transform 15 250 env19942 = env19943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env19942 == env19943) = true)

theorem identity19943 : scanCanonicalize (H12AffineFastState.compose env19943 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19943 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19944 : List Nat := [2,4,8,16,32,17,128,37,136,53,1,0,41,1,1,171,0,0,52,0,1,32,17,139,161,16,0,0,0,1,21,0,36,1,1,136]

theorem envBound19944 : H12AffineFastState.Bounded env19944 := by
  intro p hp
  have h : env19944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19943_19944 : H12AffineEnvironment.transform 5 17 env19943 = env19944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19943 == env19944) = true)

theorem identity19944 : scanCanonicalize (H12AffineFastState.compose env19944 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19944 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19945 : List Nat := [2,4,8,16,32,17,40,37,32,53,1,0,41,1,1,3,0,0,52,0,1,32,17,35,9,16,0,0,0,1,21,0,36,1,1,32]

theorem envBound19945 : H12AffineFastState.Bounded env19945 := by
  intro p hp
  have h : env19945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19944_19945 : H12AffineEnvironment.transform 6 40 env19944 = env19945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19944 == env19945) = true)

def env19946 : List Nat := [2,4,8,16,32,64,128,37,136,101,1,80,41,0,1,65536,1,0,100,0,81,32,64,65568,161,16,0,1,80,1,69,65786,36,80,0,136]

theorem envBound19946 : H12AffineFastState.Bounded env19946 := by
  intro p hp
  have h : env19946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19941_19946 : H12AffineEnvironment.transform 9 101 env19941 = env19946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19941 == env19946) = true)

theorem identity19946 : scanCanonicalize (H12AffineFastState.compose env19946 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19947 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,41,0,1,65536,1,0,53,0,0,32,17,65568,161,16,0,1,1,1,20,65707,36,1,0,136]

theorem envBound19947 : H12AffineFastState.Bounded env19947 := by
  intro p hp
  have h : env19947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19946_19947 : H12AffineEnvironment.transform 5 17 env19946 = env19947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19946 == env19947) = true)

def env19948 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,41,0,1,65536,1,0,53,0,0,32,17,65568,41,16,0,1,1,1,20,65571,36,1,0,0]

theorem envBound19948 : H12AffineFastState.Bounded env19948 := by
  intro p hp
  have h : env19948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19947_19948 : H12AffineEnvironment.transform 6 8 env19947 = env19948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19947 == env19948) = true)

theorem identity19948 : scanCanonicalize (H12AffineFastState.compose env19948 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19949 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,41,0,1,3,1,0,53,0,0,32,17,35,41,16,0,1,1,1,20,32,36,1,0,0]

theorem envBound19949 : H12AffineFastState.Bounded env19949 := by
  intro p hp
  have h : env19949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19948_19949 : H12AffineEnvironment.transform 15 3 env19948 = env19949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19948 == env19949) = true)

theorem identity19949 : scanCanonicalize (H12AffineFastState.compose env19949 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19949 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19950 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,0,1,3,1,0,20,0,0,1,17,2,8,16,0,1,1,1,20,1,5,1,0,0]

theorem envBound19950 : H12AffineFastState.Bounded env19950 := by
  intro p hp
  have h : env19950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19949_19950 : H12AffineEnvironment.transform 4 1 env19949 = env19950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19949 == env19950) = true)

def leafEnv19950 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,0,1,3,1,0,20,0,0,1,17,2,21,8,1,16,0,1,1,1,20,1,5,1,5,3,0,0,0,0,1]

def active19950 : List Nat := [0,1,2,3]

def tree19950 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19950 : H12WitnessSearch.Good tree19950 := H12GlobalWitnessIndex.good

theorem leafIdentity19950 : H12AffineFastState.composeSystem env19950 rootObs = leafEnv19950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19950 rootObs == leafEnv19950) = true)

theorem terminalChecked19950 : H12PackedTerminal.terminalCheckFast leafEnv19950 active19950 tree19950 = true := by decide +kernel

def env19951 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,41,0,1,65536,1,0,53,0,0,32,17,65568,40,16,0,1,1,1,20,65570,36,1,0,1]

theorem envBound19951 : H12AffineFastState.Bounded env19951 := by
  intro p hp
  have h : env19951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19947_19951 : H12AffineEnvironment.transform 6 9 env19947 = env19951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19947 == env19951) = true)

theorem identity19951 : scanCanonicalize (H12AffineFastState.compose env19951 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19951 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19952 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,8,0,1,65536,1,0,20,0,0,1,17,65537,9,16,0,1,1,1,20,65539,5,1,0,1]

theorem envBound19952 : H12AffineFastState.Bounded env19952 := by
  intro p hp
  have h : env19952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19951_19952 : H12AffineEnvironment.transform 4 1 env19951 = env19952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19951 == env19952) = true)

theorem identity19952 : scanCanonicalize (H12AffineFastState.compose env19952 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19952 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19953 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,8,0,1,2,1,0,20,0,0,1,17,3,9,16,0,1,1,1,20,1,5,1,0,1]

theorem envBound19953 : H12AffineFastState.Bounded env19953 := by
  intro p hp
  have h : env19953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19952_19953 : H12AffineEnvironment.transform 15 2 env19952 = env19953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19952 == env19953) = true)

def leafEnv19953 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,8,0,1,2,1,0,20,0,0,1,17,3,21,9,1,16,0,1,1,1,20,1,5,1,5,3,0,1,0,0,1]

def active19953 : List Nat := [0,1,2,3]

def tree19953 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19953 : H12WitnessSearch.Good tree19953 := H12GlobalWitnessIndex.good

theorem leafIdentity19953 : H12AffineFastState.composeSystem env19953 rootObs = leafEnv19953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19953 rootObs == leafEnv19953) = true)

theorem terminalChecked19953 : H12PackedTerminal.terminalCheckFast leafEnv19953 active19953 tree19953 = true := by decide +kernel

def env19954 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,16384,32768,65536,1345,0,42025,32769,1296,8201,17664,98564,8328,58744,33060,16385,57465,33061,1285,4294967296,257,4295074215,1344,136]

theorem envBound19954 : H12AffineFastState.Bounded env19954 := by
  intro p hp
  have h : env19954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19929_19954 : H12AffineEnvironment.transform 11 1297 env19929 = env19954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env19929 == env19954) = true)

theorem identity19954 : scanCanonicalize (H12AffineFastState.compose env19954 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound19954 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19955 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,16384,292,65536,1345,0,9485,293,1296,8201,17664,65568,8328,25692,0,16385,24925,1,1285,4294967296,257,4295041155,1344,136]

theorem envBound19955 : H12AffineFastState.Bounded env19955 := by
  intro p hp
  have h : env19955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19954_19955 : H12AffineEnvironment.transform 14 292 env19954 = env19955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env19954 == env19955) = true)

theorem identity19955 : scanCanonicalize (H12AffineFastState.compose env19955 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19955 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19956 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,16384,292,171,1345,0,9485,293,1296,8201,17664,139,8328,25692,0,16385,24925,1,1285,4294967296,257,4294975528,1344,136]

theorem envBound19956 : H12AffineFastState.Bounded env19956 := by
  intro p hp
  have h : env19956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19955_19956 : H12AffineEnvironment.transform 15 171 env19955 = env19956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19955 == env19956) = true)

theorem identity19956 : scanCanonicalize (H12AffineFastState.compose env19956 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19956 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19957 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,1344,292,171,1345,0,9485,293,1296,8201,64,139,8328,8476,0,1345,9245,1,1285,4294967296,257,4294975528,1344,136]

theorem envBound19957 : H12AffineFastState.Bounded env19957 := by
  intro p hp
  have h : env19957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19956_19957 : H12AffineEnvironment.transform 13 1344 env19956 = env19957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19956 == env19957) = true)

theorem identity19957 : scanCanonicalize (H12AffineFastState.compose env19957 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19957 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19958 : List Nat := [2,4,8,16,32,64,128,37,136,1024,1,1076,8192,1125,1,171,1124,0,9256,0,1077,8201,64,139,8328,8249,0,1124,9245,1,1056,4294967296,36,4294975528,1125,136]

theorem envBound19958 : H12AffineFastState.Bounded env19958 := by
  intro p hp
  have h : env19958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19957_19958 : H12AffineEnvironment.transform 7 37 env19957 = env19958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19957 == env19958) = true)

theorem identity19958 : scanCanonicalize (H12AffineFastState.compose env19958 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound19958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19959 : List Nat := [2,4,8,16,32,64,128,37,136,1024,1,1076,83,1125,1,171,1124,0,1147,0,1077,90,64,139,219,106,0,1124,1102,1,1056,4294967296,36,4294967419,1125,136]

theorem envBound19959 : H12AffineFastState.Bounded env19959 := by
  intro p hp
  have h : env19959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19958_19959 : H12AffineEnvironment.transform 12 83 env19958 = env19959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env19958 == env19959) = true)

theorem identity19959 : scanCanonicalize (H12AffineFastState.compose env19959 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19959 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19960 : List Nat := [2,4,8,16,11,64,128,14,136,1024,1,1055,83,1102,1,128,1103,0,1104,0,1054,90,64,139,219,65,0,1103,1102,1,1035,4294967296,15,4294967376,1102,136]

theorem envBound19960 : H12AffineFastState.Bounded env19960 := by
  intro p hp
  have h : env19960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19959_19960 : H12AffineEnvironment.transform 4 11 env19959 = env19960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19959 == env19960) = true)

def env19961 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,32768,65536,1345,1,42024,32769,4097,8201,17664,98564,8328,58745,33060,16385,62825,33060,1285,4294967296,257,4295074215,1344,136]

theorem envBound19961 : H12AffineFastState.Bounded env19961 := by
  intro p hp
  have h : env19961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19928_19961 : H12AffineEnvironment.transform 17 1 env19928 = env19961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19928 == env19961) = true)

def env19962 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,16384,32768,65536,1345,1,42024,32769,1297,8201,17664,98564,8328,58745,33060,16385,57465,33060,1285,4294967296,257,4295074215,1344,136]

theorem envBound19962 : H12AffineFastState.Bounded env19962 := by
  intro p hp
  have h : env19962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19961_19962 : H12AffineEnvironment.transform 11 1296 env19961 = env19962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19961 == env19962) = true)

theorem identity19962 : scanCanonicalize (H12AffineFastState.compose env19962 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 25961) := by decide +kernel

theorem selectedBound19962 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19963 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,16384,25961,65536,1345,1,16705,25960,1297,8201,17664,91245,8328,16,25677,16385,1296,25677,1285,4294967296,257,4295050446,1344,136]

theorem envBound19963 : H12AffineFastState.Bounded env19963 := by
  intro p hp
  have h : env19963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19962_19963 : H12AffineEnvironment.transform 14 25961 env19962 = env19963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25961 env19962 == env19963) = true)

theorem identity19963 : scanCanonicalize (H12AffineFastState.compose env19963 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19963 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env19964 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,8192,1344,8233,65536,1345,1,1025,8232,1297,8201,64,74029,8328,16,8461,1345,1296,8461,1285,4294967296,257,4295033230,1344,136]

theorem envBound19964 : H12AffineFastState.Bounded env19964 := by
  intro p hp
  have h : env19964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19963_19964 : H12AffineEnvironment.transform 13 1344 env19963 = env19964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19963 == env19964) = true)

def env19965 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1296,8192,1296,8233,65536,1297,1,1025,8232,1297,8201,16,74029,8328,16,8461,1297,1296,8461,1285,4294967296,257,4295033230,1296,136]

theorem envBound19965 : H12AffineFastState.Bounded env19965 := by
  intro p hp
  have h : env19965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19964_19965 : H12AffineEnvironment.transform 5 16 env19964 = env19965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19964 == env19965) = true)

theorem identity19965 : scanCanonicalize (H12AffineFastState.compose env19965 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound19965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19966 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1296,8192,1296,8233,8614,1297,1,1025,8232,1297,8201,16,139,8328,16,8461,1297,1296,8461,1285,4294967296,257,4294975528,1296,136]

theorem envBound19966 : H12AffineFastState.Bounded env19966 := by
  intro p hp
  have h : env19966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19965_19966 : H12AffineEnvironment.transform 15 8614 env19965 = env19966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env19965 == env19966) = true)

theorem identity19966 : scanCanonicalize (H12AffineFastState.compose env19966 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19967 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1296,40,1296,1,398,1297,1,1025,0,1297,33,16,139,160,16,293,1297,1296,293,1285,4294967296,257,4294967296,1296,136]

theorem envBound19967 : H12AffineFastState.Bounded env19967 := by
  intro p hp
  have h : env19967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19966_19967 : H12AffineEnvironment.transform 12 40 env19966 = env19967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19966 == env19967) = true)

theorem identity19967 : scanCanonicalize (H12AffineFastState.compose env19967 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound19967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19968 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1296,40,1296,1,398,1297,1,1025,0,1297,33,16,139,160,16,293,1297,1296,293,1285,429,257,429,1296,136]

theorem envBound19968 : H12AffineFastState.Bounded env19968 := by
  intro p hp
  have h : env19968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19967_19968 : H12AffineEnvironment.transform 31 429 env19967 = env19968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env19967 == env19968) = true)

theorem identity19968 : scanCanonicalize (H12AffineFastState.compose env19968 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19968 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19969 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,40,1076,1,170,1077,1,1025,0,1077,33,16,139,160,16,1,1077,1076,1,1057,137,37,137,1076,136]

theorem envBound19969 : H12AffineFastState.Bounded env19969 := by
  intro p hp
  have h : env19969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19968_19969 : H12AffineEnvironment.transform 7 36 env19968 = env19969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19968 == env19969) = true)

theorem identity19969 : scanCanonicalize (H12AffineFastState.compose env19969 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19970 : List Nat := [2,4,8,16,32,16,8,36,0,1024,1,1076,40,1076,1,34,1077,1,1025,0,1077,33,16,3,40,16,1,1077,1076,1,1057,1,37,1,1076,0]

theorem envBound19970 : H12AffineFastState.Bounded env19970 := by
  intro p hp
  have h : env19970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19969_19970 : H12AffineEnvironment.transform 6 8 env19969 = env19970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19969 == env19970) = true)

def leafEnv19970 : List Nat := [2,4,8,16,32,16,8,36,0,1024,1,1076,40,1076,1,34,1077,1,1025,0,1077,33,16,3,1056,40,1,16,1,1077,1076,1,1057,1,37,1,5,35,1076,0,0,1077,1]

def active19970 : List Nat := [0,1,2,3,4,9]

def tree19970 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19970 : H12WitnessSearch.Good tree19970 := H12GlobalWitnessIndex.good

theorem leafIdentity19970 : H12AffineFastState.composeSystem env19970 rootObs = leafEnv19970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19970 rootObs == leafEnv19970) = true)

theorem terminalChecked19970 : H12PackedTerminal.terminalCheckFast leafEnv19970 active19970 tree19970 = true := by decide +kernel

def env19971 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1296,8192,1297,8233,65536,1296,1,1025,8232,1297,8201,17,74029,8328,16,8461,1296,1296,8461,1285,4294967296,257,4295033230,1297,136]

theorem envBound19971 : H12AffineFastState.Bounded env19971 := by
  intro p hp
  have h : env19971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19964_19971 : H12AffineEnvironment.transform 5 17 env19964 = env19971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19964 == env19971) = true)

def env19972 : List Nat := [2,4,8,16,32,17,128,256,136,272,1,0,8192,1,8233,65536,0,1,273,8232,1,8201,17,74029,8328,16,8461,0,0,8461,21,4294967296,257,4295033230,1,136]

theorem envBound19972 : H12AffineFastState.Bounded env19972 := by
  intro p hp
  have h : env19972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19971_19972 : H12AffineEnvironment.transform 9 272 env19971 = env19972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19971 == env19972) = true)

theorem identity19972 : scanCanonicalize (H12AffineFastState.compose env19972 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19973 : List Nat := [2,4,8,16,32,17,128,256,136,272,1,0,8192,1,8233,171,0,1,273,8232,1,8201,17,8582,8328,16,8461,0,0,8461,21,4294967296,257,4294967589,1,136]

theorem envBound19973 : H12AffineFastState.Bounded env19973 := by
  intro p hp
  have h : env19973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19972_19973 : H12AffineEnvironment.transform 15 171 env19972 = env19973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19972 == env19973) = true)

def env19974 : List Nat := [2,4,8,16,32,17,8,256,0,272,1,0,8192,1,8233,35,0,1,273,8232,1,8201,17,8462,8192,16,8461,0,0,8461,21,4294967296,257,4294967589,1,0]

theorem envBound19974 : H12AffineFastState.Bounded env19974 := by
  intro p hp
  have h : env19974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19973_19974 : H12AffineEnvironment.transform 6 8 env19973 = env19974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19973 == env19974) = true)

theorem identity19974 : scanCanonicalize (H12AffineFastState.compose env19974 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19975 : List Nat := [2,4,8,16,32,17,8,256,0,272,1,0,8192,1,8233,35,0,1,273,8232,1,8201,17,8462,8192,16,8461,0,0,8461,21,8461,257,8232,1,0]

theorem envBound19975 : H12AffineFastState.Bounded env19975 := by
  intro p hp
  have h : env19975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19974_19975 : H12AffineEnvironment.transform 31 8461 env19974 = env19975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8461 env19974 == env19975) = true)

def env19976 : List Nat := [2,4,8,16,0,17,8,256,0,272,1,0,8192,1,8201,3,0,1,273,8200,1,8201,17,8462,8192,16,8461,0,0,8461,21,8461,257,8200,1,0]

theorem envBound19976 : H12AffineFastState.Bounded env19976 := by
  intro p hp
  have h : env19976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19975_19976 : H12AffineEnvironment.transform 4 0 env19975 = env19976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19975 == env19976) = true)

theorem identity19976 : scanCanonicalize (H12AffineFastState.compose env19976 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19977 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,0,8192,1,8201,3,0,1,21,8200,1,8201,17,8202,8192,16,8201,0,0,8201,21,8201,5,8200,1,0]

theorem envBound19977 : H12AffineFastState.Bounded env19977 := by
  intro p hp
  have h : env19977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19976_19977 : H12AffineEnvironment.transform 7 4 env19976 = env19977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19976 == env19977) = true)

def env19978 : List Nat := [2,4,8,16,1,17,8,256,0,272,1,0,8192,1,8200,2,0,1,273,8201,1,8201,17,8462,8192,16,8461,0,0,8461,21,8461,257,8201,1,0]

theorem envBound19978 : H12AffineFastState.Bounded env19978 := by
  intro p hp
  have h : env19978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19975_19978 : H12AffineEnvironment.transform 4 1 env19975 = env19978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19975 == env19978) = true)

theorem identity19978 : scanCanonicalize (H12AffineFastState.compose env19978 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19979 : List Nat := [2,4,8,16,1,17,8,256,0,272,1,0,268,1,260,2,0,1,273,261,1,261,17,2,268,16,1,0,0,1,21,1,257,261,1,0]

theorem envBound19979 : H12AffineFastState.Bounded env19979 := by
  intro p hp
  have h : env19979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19978_19979 : H12AffineEnvironment.transform 12 268 env19978 = env19979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19978 == env19979) = true)

theorem identity19979 : scanCanonicalize (H12AffineFastState.compose env19979 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19980 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,0,9,1,1,2,0,1,20,0,1,0,17,2,9,16,1,0,0,1,21,1,4,0,1,0]

theorem envBound19980 : H12AffineFastState.Bounded env19980 := by
  intro p hp
  have h : env19980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19979_19980 : H12AffineEnvironment.transform 7 5 env19979 = env19980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19979 == env19980) = true)

def leafEnv19980 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,0,9,1,1,2,0,1,20,0,1,0,17,2,20,9,1,16,1,0,0,1,21,1,4,0,5,2,1,0,0,1,1]

def active19980 : List Nat := [0,1,2,3]

def tree19980 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19980 : H12WitnessSearch.Good tree19980 := H12GlobalWitnessIndex.good

theorem leafIdentity19980 : H12AffineFastState.composeSystem env19980 rootObs = leafEnv19980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19980 rootObs == leafEnv19980) = true)

theorem terminalChecked19980 : H12PackedTerminal.terminalCheckFast leafEnv19980 active19980 tree19980 = true := by decide +kernel

def env19981 : List Nat := [2,4,8,16,32,17,9,256,1,272,1,0,8192,1,8233,34,0,1,273,8232,1,8201,17,8463,8193,16,8461,0,0,8461,21,4294967296,257,4294967589,1,1]

theorem envBound19981 : H12AffineFastState.Bounded env19981 := by
  intro p hp
  have h : env19981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19973_19981 : H12AffineEnvironment.transform 6 9 env19973 = env19981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19973 == env19981) = true)

theorem identity19981 : scanCanonicalize (H12AffineFastState.compose env19981 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8233) := by decide +kernel

theorem selectedBound19981 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19982 : List Nat := [2,4,8,16,32,17,9,256,1,272,1,0,8192,1,8233,34,0,1,273,8232,1,8201,17,8463,8193,16,8461,0,0,8461,21,8233,257,8460,1,1]

theorem envBound19982 : H12AffineFastState.Bounded env19982 := by
  intro p hp
  have h : env19982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19981_19982 : H12AffineEnvironment.transform 31 8233 env19981 = env19982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8233 env19981 == env19982) = true)

def env19983 : List Nat := [2,4,8,16,0,17,9,256,1,272,1,0,8192,1,8201,2,0,1,273,8200,1,8201,17,8463,8193,16,8461,0,0,8461,21,8201,257,8460,1,1]

theorem envBound19983 : H12AffineFastState.Bounded env19983 := by
  intro p hp
  have h : env19983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19982_19983 : H12AffineEnvironment.transform 4 0 env19982 = env19983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19982 == env19983) = true)

theorem identity19983 : scanCanonicalize (H12AffineFastState.compose env19983 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19984 : List Nat := [2,4,8,16,0,17,9,256,1,272,1,0,268,1,261,2,0,1,273,260,1,261,17,3,269,16,1,0,0,1,21,261,257,0,1,1]

theorem envBound19984 : H12AffineFastState.Bounded env19984 := by
  intro p hp
  have h : env19984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19983_19984 : H12AffineEnvironment.transform 12 268 env19983 = env19984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19983 == env19984) = true)

theorem identity19984 : scanCanonicalize (H12AffineFastState.compose env19984 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19984 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19985 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,9,1,0,2,0,1,20,1,1,0,17,3,8,16,1,0,0,1,21,0,4,0,1,1]

theorem envBound19985 : H12AffineFastState.Bounded env19985 := by
  intro p hp
  have h : env19985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19984_19985 : H12AffineEnvironment.transform 7 5 env19984 = env19985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19984 == env19985) = true)

def leafEnv19985 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,9,1,0,2,0,1,20,1,1,0,17,3,20,8,1,16,1,0,0,1,21,0,4,0,5,3,1,1,0,1,1]

def active19985 : List Nat := [0,1,2,3]

def tree19985 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19985 : H12WitnessSearch.Good tree19985 := H12GlobalWitnessIndex.good

theorem leafIdentity19985 : H12AffineFastState.composeSystem env19985 rootObs = leafEnv19985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19985 rootObs == leafEnv19985) = true)

theorem terminalChecked19985 : H12PackedTerminal.terminalCheckFast leafEnv19985 active19985 tree19985 = true := by decide +kernel

def env19986 : List Nat := [2,4,8,16,1,17,9,256,1,272,1,0,8192,1,8200,3,0,1,273,8201,1,8201,17,8463,8193,16,8461,0,0,8461,21,8200,257,8460,1,1]

theorem envBound19986 : H12AffineFastState.Bounded env19986 := by
  intro p hp
  have h : env19986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19982_19986 : H12AffineEnvironment.transform 4 1 env19982 = env19986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19982 == env19986) = true)

theorem identity19986 : scanCanonicalize (H12AffineFastState.compose env19986 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19986 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19987 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,0,8192,1,8200,3,0,1,20,8201,1,8201,17,8202,8193,16,8200,0,0,8200,21,8200,4,8201,1,1]

theorem envBound19987 : H12AffineFastState.Bounded env19987 := by
  intro p hp
  have h : env19987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19986_19987 : H12AffineEnvironment.transform 7 5 env19986 = env19987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19986 == env19987) = true)

theorem identity19987 : scanCanonicalize (H12AffineFastState.compose env19987 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound19987 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19988 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,0,9,1,1,3,0,1,20,0,1,0,17,3,8,16,1,0,0,1,21,1,4,0,1,1]

theorem envBound19988 : H12AffineFastState.Bounded env19988 := by
  intro p hp
  have h : env19988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19987_19988 : H12AffineEnvironment.transform 12 9 env19987 = env19988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env19987 == env19988) = true)

def leafEnv19988 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,0,9,1,1,3,0,1,20,0,1,0,17,3,20,8,1,16,1,0,0,1,21,1,4,0,5,2,1,1,0,1,1]

def active19988 : List Nat := [0,1,2,3]

def tree19988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19988 : H12WitnessSearch.Good tree19988 := H12GlobalWitnessIndex.good

theorem leafIdentity19988 : H12AffineFastState.composeSystem env19988 rootObs = leafEnv19988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19988 rootObs == leafEnv19988) = true)

theorem terminalChecked19988 : H12PackedTerminal.terminalCheckFast leafEnv19988 active19988 tree19988 = true := by decide +kernel

def env19989 : List Nat := [2,4,8,16,32,17,128,256,136,273,1,1,8192,0,8233,65536,1,1,272,8232,0,8201,17,74029,8328,16,8461,1,1,8461,20,4294967296,257,4295033230,0,136]

theorem envBound19989 : H12AffineFastState.Bounded env19989 := by
  intro p hp
  have h : env19989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19971_19989 : H12AffineEnvironment.transform 9 273 env19971 = env19989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19971 == env19989) = true)

theorem identity19989 : scanCanonicalize (H12AffineFastState.compose env19989 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19990 : List Nat := [2,4,8,16,32,17,128,256,136,273,1,1,269,0,292,65536,1,1,272,293,0,260,17,65568,389,16,0,1,1,0,20,4294967296,257,4295033230,0,136]

theorem envBound19990 : H12AffineFastState.Bounded env19990 := by
  intro p hp
  have h : env19990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19989_19990 : H12AffineEnvironment.transform 12 269 env19989 = env19990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19989 == env19990) = true)

def env19991 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,41,0,0,65536,1,1,52,1,0,32,17,65568,161,16,0,1,1,0,20,4294967296,37,4295033002,0,136]

theorem envBound19991 : H12AffineFastState.Bounded env19991 := by
  intro p hp
  have h : env19991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19990_19991 : H12AffineEnvironment.transform 7 36 env19990 = env19991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19990 == env19991) = true)

theorem identity19991 : scanCanonicalize (H12AffineFastState.compose env19991 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19992 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,41,0,0,65536,1,1,52,1,0,32,17,65568,161,16,0,1,1,0,20,0,37,65706,0,136]

theorem envBound19992 : H12AffineFastState.Bounded env19992 := by
  intro p hp
  have h : env19992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19991_19992 : H12AffineEnvironment.transform 31 0 env19991 = env19992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19991 == env19992) = true)

def env19993 : List Nat := [2,4,8,16,32,17,8,36,0,53,1,1,41,0,0,65536,1,1,52,1,0,32,17,65568,41,16,0,1,1,0,20,0,37,65570,0,0]

theorem envBound19993 : H12AffineFastState.Bounded env19993 := by
  intro p hp
  have h : env19993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19992_19993 : H12AffineEnvironment.transform 6 8 env19992 = env19993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19992 == env19993) = true)

theorem identity19993 : scanCanonicalize (H12AffineFastState.compose env19993 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19994 : List Nat := [2,4,8,16,32,17,8,36,0,53,1,1,41,0,0,3,1,1,52,1,0,32,17,35,41,16,0,1,1,0,20,0,37,33,0,0]

theorem envBound19994 : H12AffineFastState.Bounded env19994 := by
  intro p hp
  have h : env19994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19993_19994 : H12AffineEnvironment.transform 15 3 env19993 = env19994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19993 == env19994) = true)

def env19995 : List Nat := [2,4,8,16,32,17,9,36,1,53,1,1,41,0,0,65536,1,1,52,1,0,32,17,65568,40,16,0,1,1,0,20,0,37,65571,0,1]

theorem envBound19995 : H12AffineFastState.Bounded env19995 := by
  intro p hp
  have h : env19995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19992_19995 : H12AffineEnvironment.transform 6 9 env19992 = env19995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19992 == env19995) = true)

theorem identity19995 : scanCanonicalize (H12AffineFastState.compose env19995 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19996 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,1,8,0,0,65536,1,1,21,1,0,1,17,65537,9,16,0,1,1,0,20,0,4,65538,0,1]

theorem envBound19996 : H12AffineFastState.Bounded env19996 := by
  intro p hp
  have h : env19996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19995_19996 : H12AffineEnvironment.transform 4 1 env19995 = env19996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19995 == env19996) = true)

def env19997 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,40,0,1,65536,1,1,53,0,0,33,17,65568,160,16,0,1,1,0,20,4294967296,36,4295033003,0,136]

theorem envBound19997 : H12AffineFastState.Bounded env19997 := by
  intro p hp
  have h : env19997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19990_19997 : H12AffineEnvironment.transform 7 37 env19990 = env19997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19990 == env19997) = true)

theorem identity19997 : scanCanonicalize (H12AffineFastState.compose env19997 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound19997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19998 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,40,0,1,65536,1,1,53,0,0,33,17,65568,160,16,0,1,1,0,20,65571,36,136,0,136]

theorem envBound19998 : H12AffineFastState.Bounded env19998 := by
  intro p hp
  have h : env19998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19997_19998 : H12AffineEnvironment.transform 31 65571 env19997 = env19998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env19997 == env19998) = true)

theorem identity19998 : scanCanonicalize (H12AffineFastState.compose env19998 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19999 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,40,0,1,170,1,1,53,0,0,33,17,138,160,16,0,1,1,0,20,137,36,136,0,136]

theorem envBound19999 : H12AffineFastState.Bounded env19999 := by
  intro p hp
  have h : env19999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19998_19999 : H12AffineEnvironment.transform 15 170 env19998 = env19999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19998 == env19999) = true)

theorem identity19999 : scanCanonicalize (H12AffineFastState.compose env19999 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19999 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20000 : List Nat := [2,4,8,16,1,17,128,4,136,21,1,1,9,0,1,139,1,1,20,0,0,0,17,138,129,16,0,1,1,0,20,137,5,136,0,136]

theorem envBound20000 : H12AffineFastState.Bounded env20000 := by
  intro p hp
  have h : env20000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19999_20000 : H12AffineEnvironment.transform 4 1 env19999 = env20000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19999 == env20000) = true)

def leafEnv20000 : List Nat := [2,4,8,16,1,17,128,4,136,21,1,1,9,0,1,139,1,1,20,0,0,0,17,138,21,129,1,16,0,1,1,0,20,137,5,136,5,3,0,136,0,0,1]

def active20000 : List Nat := [0,1,2,3,6]

def tree20000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20000 : H12WitnessSearch.Good tree20000 := H12GlobalWitnessIndex.good

theorem leafIdentity20000 : H12AffineFastState.composeSystem env20000 rootObs = leafEnv20000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20000 rootObs == leafEnv20000) = true)

theorem terminalChecked20000 : H12PackedTerminal.terminalCheckFast leafEnv20000 active20000 tree20000 = true := by decide +kernel

def env20001 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,16384,32768,65536,1345,1,42024,32769,1296,8201,17664,98564,8328,58745,33060,16385,57464,33060,1285,4294967296,257,4295074215,1344,136]

theorem envBound20001 : H12AffineFastState.Bounded env20001 := by
  intro p hp
  have h : env20001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19961_20001 : H12AffineEnvironment.transform 11 1297 env19961 = env20001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env19961 == env20001) = true)

theorem identity20001 : scanCanonicalize (H12AffineFastState.compose env20001 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound20001 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20002 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,9293,32768,65536,1345,1,42024,32769,1296,8201,8525,98564,8328,33076,33060,9292,33845,33060,1285,4294967296,257,4295074215,1344,136]

theorem envBound20002 : H12AffineFastState.Bounded env20002 := by
  intro p hp
  have h : env20002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20001_20002 : H12AffineEnvironment.transform 13 9293 env20001 = env20002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env20001 == env20002) = true)

theorem identity20002 : scanCanonicalize (H12AffineFastState.compose env20002 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound20002 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env20003 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,9293,32768,8614,1345,1,42024,32769,1296,8201,8525,41122,8328,33076,33060,9292,33845,33060,1285,4294967296,257,4295000065,1344,136]

theorem envBound20003 : H12AffineFastState.Bounded env20003 := by
  intro p hp
  have h : env20003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20002_20003 : H12AffineEnvironment.transform 15 8614 env20002 = env20003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env20002 == env20003) = true)

theorem identity20003 : scanCanonicalize (H12AffineFastState.compose env20003 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound20003 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20004 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,9293,8233,8614,1345,1,1025,8232,1296,8201,8525,139,8328,8477,8461,9292,9244,8461,1285,4294967296,257,4294975528,1344,136]

theorem envBound20004 : H12AffineFastState.Bounded env20004 := by
  intro p hp
  have h : env20004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20003_20004 : H12AffineEnvironment.transform 14 8233 env20003 = env20004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env20003 == env20004) = true)

theorem identity20004 : scanCanonicalize (H12AffineFastState.compose env20004 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20004 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20005 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,268,1345,293,170,1345,1,1025,292,1296,261,65,139,388,17,1,1344,1296,1,1285,4294967296,257,4294967588,1344,136]

theorem envBound20005 : H12AffineFastState.Bounded env20005 := by
  intro p hp
  have h : env20005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20004_20005 : H12AffineEnvironment.transform 12 268 env20004 = env20005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20004 == env20005) = true)

def env20006 : List Nat := [2,4,8,16,32,64,8,256,0,1024,1,1297,268,1345,293,34,1345,1,1025,292,1296,261,65,3,268,17,1,1344,1296,1,1285,4294967296,257,4294967588,1344,0]

theorem envBound20006 : H12AffineFastState.Bounded env20006 := by
  intro p hp
  have h : env20006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20005_20006 : H12AffineEnvironment.transform 6 8 env20005 = env20006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20005 == env20006) = true)

theorem identity20006 : scanCanonicalize (H12AffineFastState.compose env20006 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 372) := by decide +kernel

theorem selectedBound20006 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20007 : List Nat := [2,4,8,16,32,64,8,256,0,1024,1,1297,268,1345,293,34,1345,1,1025,292,1296,261,65,3,268,17,1,1344,1296,1,1285,372,257,80,1344,0]

theorem envBound20007 : H12AffineFastState.Bounded env20007 := by
  intro p hp
  have h : env20007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20006_20007 : H12AffineEnvironment.transform 31 372 env20006 = env20007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 372 env20006 == env20007) = true)

def env20008 : List Nat := [2,4,8,16,32,16,8,256,0,1024,1,1297,268,1297,293,34,1297,1,1025,292,1296,261,17,3,268,17,1,1296,1296,1,1285,292,257,0,1296,0]

theorem envBound20008 : H12AffineFastState.Bounded env20008 := by
  intro p hp
  have h : env20008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20007_20008 : H12AffineEnvironment.transform 5 16 env20007 = env20008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20007 == env20008) = true)

def env20009 : List Nat := [2,4,8,16,32,17,8,256,0,1024,1,1297,268,1296,293,34,1296,1,1025,292,1296,261,16,3,268,17,1,1297,1296,1,1285,293,257,1,1297,0]

theorem envBound20009 : H12AffineFastState.Bounded env20009 := by
  intro p hp
  have h : env20009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20007_20009 : H12AffineEnvironment.transform 5 17 env20007 = env20009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20007 == env20009) = true)

theorem identity20009 : scanCanonicalize (H12AffineFastState.compose env20009 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20010 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,40,1076,1,34,1076,1,1025,0,1076,33,16,3,40,17,1,1077,1076,1,1057,1,37,1,1077,0]

theorem envBound20010 : H12AffineFastState.Bounded env20010 := by
  intro p hp
  have h : env20010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20009_20010 : H12AffineEnvironment.transform 7 36 env20009 = env20010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20009 == env20010) = true)

def leafEnv20010 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,40,1076,1,34,1076,1,1025,0,1076,33,16,3,1056,40,1,17,1,1077,1076,1,1057,1,37,1,5,35,1077,0,0,1077,1]

def active20010 : List Nat := [0,1,2,3,4,9]

def tree20010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20010 : H12WitnessSearch.Good tree20010 := H12GlobalWitnessIndex.good

theorem leafIdentity20010 : H12AffineFastState.composeSystem env20010 rootObs = leafEnv20010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20010 rootObs == leafEnv20010) = true)

theorem terminalChecked20010 : H12PackedTerminal.terminalCheckFast leafEnv20010 active20010 tree20010 = true := by decide +kernel

def env20011 : List Nat := [2,4,8,16,32,64,9,256,1,1024,1,1297,268,1345,293,35,1345,1,1025,292,1296,261,65,2,269,17,1,1344,1296,1,1285,4294967296,257,4294967588,1344,1]

theorem envBound20011 : H12AffineFastState.Bounded env20011 := by
  intro p hp
  have h : env20011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20005_20011 : H12AffineEnvironment.transform 6 9 env20005 = env20011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20005 == env20011) = true)

theorem identity20011 : scanCanonicalize (H12AffineFastState.compose env20011 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 80) := by decide +kernel

theorem selectedBound20011 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20012 : List Nat := [2,4,8,16,32,64,9,256,1,1024,1,1297,268,1345,293,35,1345,1,1025,292,1296,261,65,2,269,17,1,1344,1296,1,1285,80,257,372,1344,1]

theorem envBound20012 : H12AffineFastState.Bounded env20012 := by
  intro p hp
  have h : env20012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20011_20012 : H12AffineEnvironment.transform 31 80 env20011 = env20012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 80 env20011 == env20012) = true)

def env20013 : List Nat := [2,4,8,16,32,16,9,256,1,1024,1,1297,268,1297,293,35,1297,1,1025,292,1296,261,17,2,269,17,1,1296,1296,1,1285,0,257,292,1296,1]

theorem envBound20013 : H12AffineFastState.Bounded env20013 := by
  intro p hp
  have h : env20013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20012_20013 : H12AffineEnvironment.transform 5 16 env20012 = env20013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20012 == env20013) = true)

def env20014 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,268,1297,261,3,1297,1,1025,260,1296,261,17,2,269,17,1,1296,1296,1,1285,0,257,260,1296,1]

theorem envBound20014 : H12AffineFastState.Bounded env20014 := by
  intro p hp
  have h : env20014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20013_20014 : H12AffineEnvironment.transform 4 0 env20013 = env20014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20013 == env20014) = true)

def leafEnv20014 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,268,1297,261,3,1297,1,1025,260,1296,261,17,2,1284,269,1,17,1,1296,1296,1,1285,0,257,260,5,3,1296,1,0,1297,1]

def active20014 : List Nat := [0,1,2,3,7,9]

def tree20014 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20014 : H12WitnessSearch.Good tree20014 := H12GlobalWitnessIndex.good

theorem leafIdentity20014 : H12AffineFastState.composeSystem env20014 rootObs = leafEnv20014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20014 rootObs == leafEnv20014) = true)

theorem terminalChecked20014 : H12PackedTerminal.terminalCheckFast leafEnv20014 active20014 tree20014 = true := by decide +kernel

def env20015 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1297,268,1297,260,2,1297,1,1025,261,1296,261,17,2,269,17,1,1296,1296,1,1285,0,257,261,1296,1]

theorem envBound20015 : H12AffineFastState.Bounded env20015 := by
  intro p hp
  have h : env20015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20013_20015 : H12AffineEnvironment.transform 4 1 env20013 = env20015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20013 == env20015) = true)

theorem identity20015 : scanCanonicalize (H12AffineFastState.compose env20015 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20016 : List Nat := [2,4,8,16,1,16,9,5,1,1024,1,1044,9,1044,1,2,1044,1,1025,0,1045,0,17,2,8,17,1,1045,1045,1,1024,0,4,0,1045,1]

theorem envBound20016 : H12AffineFastState.Bounded env20016 := by
  intro p hp
  have h : env20016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20015_20016 : H12AffineEnvironment.transform 7 5 env20015 = env20016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20015 == env20016) = true)

def leafEnv20016 : List Nat := [2,4,8,16,1,16,9,5,1,1024,1,1044,9,1044,1,2,1044,1,1025,0,1045,0,17,2,1025,8,1,17,1,1045,1045,1,1024,0,4,0,5,2,1045,1,0,1044,1]

def active20016 : List Nat := [0,1,2,3,9]

def tree20016 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20016 : H12WitnessSearch.Good tree20016 := H12GlobalWitnessIndex.good

theorem leafIdentity20016 : H12AffineFastState.composeSystem env20016 rootObs = leafEnv20016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20016 rootObs == leafEnv20016) = true)

theorem terminalChecked20016 : H12PackedTerminal.terminalCheckFast leafEnv20016 active20016 tree20016 = true := by decide +kernel

def env20017 : List Nat := [2,4,8,16,32,17,9,256,1,1024,1,1297,268,1296,293,35,1296,1,1025,292,1296,261,16,2,269,17,1,1297,1296,1,1285,1,257,293,1297,1]

theorem envBound20017 : H12AffineFastState.Bounded env20017 := by
  intro p hp
  have h : env20017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20012_20017 : H12AffineEnvironment.transform 5 17 env20012 = env20017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20012 == env20017) = true)

theorem identity20017 : scanCanonicalize (H12AffineFastState.compose env20017 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20017 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20018 : List Nat := [2,4,8,16,32,17,9,37,1,1024,1,1076,41,1077,0,35,1077,1,1025,1,1077,32,16,2,40,17,1,1076,1077,1,1056,1,36,0,1076,1]

theorem envBound20018 : H12AffineFastState.Bounded env20018 := by
  intro p hp
  have h : env20018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20017_20018 : H12AffineEnvironment.transform 7 37 env20017 = env20018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20017 == env20018) = true)

theorem identity20018 : scanCanonicalize (H12AffineFastState.compose env20018 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20018 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20019 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1044,9,1045,0,3,1045,1,1025,1,1045,0,16,2,8,17,1,1044,1045,1,1024,1,4,0,1044,1]

theorem envBound20019 : H12AffineFastState.Bounded env20019 := by
  intro p hp
  have h : env20019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20018_20019 : H12AffineEnvironment.transform 4 0 env20018 = env20019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20018 == env20019) = true)

def leafEnv20019 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1044,9,1045,0,3,1045,1,1025,1,1045,0,16,2,1025,8,1,17,1,1044,1045,1,1024,1,4,0,5,3,1044,1,0,1044,1]

def active20019 : List Nat := [0,1,2,3,9]

def tree20019 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20019 : H12WitnessSearch.Good tree20019 := H12GlobalWitnessIndex.good

theorem leafIdentity20019 : H12AffineFastState.composeSystem env20019 rootObs = leafEnv20019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20019 rootObs == leafEnv20019) = true)

theorem terminalChecked20019 : H12PackedTerminal.terminalCheckFast leafEnv20019 active20019 tree20019 = true := by decide +kernel

def env20020 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98564,8328,320888,33060,16385,324968,295205,1285,4294967296,257,4295074215,1344,137]

theorem envBound20020 : H12AffineFastState.Bounded env20020 := by
  intro p hp
  have h : env20020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19927_20020 : H12AffineEnvironment.transform 8 137 env19927 = env20020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19927 == env20020) = true)

theorem identity20020 : scanCanonicalize (H12AffineFastState.compose env20020 (packedSelected [0,1,2,3,4,6,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20020 : packedSelected [0,1,2,3,4,6,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20021 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,32768,33167,1345,262144,304169,32769,4097,8201,17664,139,8328,320888,33060,16385,324968,295205,1285,4294967296,257,4294975528,1344,137]

theorem envBound20021 : H12AffineFastState.Bounded env20021 := by
  intro p hp
  have h : env20021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20020_20021 : H12AffineEnvironment.transform 15 33167 env20020 = env20021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20020 == env20021) = true)

def env20022 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,32768,33167,1345,58728,16705,32769,4097,8201,17664,139,8328,16,33060,16385,4096,25677,1285,4294967296,257,4294975528,1344,137]

theorem envBound20022 : H12AffineFastState.Bounded env20022 := by
  intro p hp
  have h : env20022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20021_20022 : H12AffineEnvironment.transform 17 58728 env20021 = env20022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env20021 == env20022) = true)

def env20023 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,0,399,1345,25960,16705,1,4097,8201,17664,139,8328,16,292,16385,4096,25677,1285,4294967296,257,4294975528,1344,137]

theorem envBound20023 : H12AffineFastState.Bounded env20023 := by
  intro p hp
  have h : env20023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20022_20023 : H12AffineEnvironment.transform 14 0 env20022 = env20023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20022 == env20023) = true)

theorem identity20023 : scanCanonicalize (H12AffineFastState.compose env20023 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20023 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20024 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4176,0,399,1345,13624,4369,1,4097,8201,5456,139,8328,16,292,4177,4096,13341,1285,4294967296,257,4294975528,1344,137]

theorem envBound20024 : H12AffineFastState.Bounded env20024 := by
  intro p hp
  have h : env20024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20023_20024 : H12AffineEnvironment.transform 13 4176 env20023 = env20024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20023 == env20024) = true)

theorem identity20024 : scanCanonicalize (H12AffineFastState.compose env20024 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20024 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20025 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,0,399,1345,8232,1025,1,1297,8201,64,139,8328,16,292,1345,1296,8461,1285,4294967296,257,4294975528,1344,137]

theorem envBound20025 : H12AffineFastState.Bounded env20025 := by
  intro p hp
  have h : env20025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20024_20025 : H12AffineEnvironment.transform 11 1296 env20024 = env20025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env20024 == env20025) = true)

theorem identity20025 : scanCanonicalize (H12AffineFastState.compose env20025 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound20025 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20026 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,161,1344,0,399,1345,137,1025,1,1297,168,64,139,41,16,292,1345,1296,428,1285,4294967296,257,4294967433,1344,137]

theorem envBound20026 : H12AffineFastState.Bounded env20026 := by
  intro p hp
  have h : env20026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20025_20026 : H12AffineEnvironment.transform 12 161 env20025 = env20026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20025 == env20026) = true)

theorem identity20026 : scanCanonicalize (H12AffineFastState.compose env20026 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20026 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20027 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,161,1296,0,399,1297,137,1025,1,1297,168,16,139,41,16,292,1297,1296,428,1285,4294967296,257,4294967433,1296,137]

theorem envBound20027 : H12AffineFastState.Bounded env20027 := by
  intro p hp
  have h : env20027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20026_20027 : H12AffineEnvironment.transform 5 16 env20026 = env20027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20026 == env20027) = true)

theorem identity20027 : scanCanonicalize (H12AffineFastState.compose env20027 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20028 : List Nat := [2,4,8,16,32,16,9,256,0,1024,1,1296,40,1296,0,262,1297,0,1025,1,1297,33,16,2,41,16,292,1297,1296,293,1285,4294967296,257,4294967296,1296,0]

theorem envBound20028 : H12AffineFastState.Bounded env20028 := by
  intro p hp
  have h : env20028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20027_20028 : H12AffineEnvironment.transform 6 9 env20027 = env20028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20027 == env20028) = true)

theorem identity20028 : scanCanonicalize (H12AffineFastState.compose env20028 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20028 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20029 : List Nat := [2,4,8,16,32,16,9,256,0,1024,1,1296,40,1296,0,262,1297,0,1025,1,1297,33,16,2,41,16,292,1297,1296,293,1285,292,257,292,1296,0]

theorem envBound20029 : H12AffineFastState.Bounded env20029 := by
  intro p hp
  have h : env20029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20028_20029 : H12AffineEnvironment.transform 31 292 env20028 = env20029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20028 == env20029) = true)

theorem identity20029 : scanCanonicalize (H12AffineFastState.compose env20029 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20030 : List Nat := [2,4,8,16,32,16,9,37,0,1024,1,1077,40,1077,0,35,1076,0,1025,1,1076,33,16,2,41,16,1,1076,1077,0,1056,1,36,1,1077,0]

theorem envBound20030 : H12AffineFastState.Bounded env20030 := by
  intro p hp
  have h : env20030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20029_20030 : H12AffineEnvironment.transform 7 37 env20029 = env20030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20029 == env20030) = true)

def env20031 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,1,398,1345,25961,16705,0,4097,8201,17664,139,8328,16,293,16385,4096,25677,1285,4294967296,257,4294975528,1344,137]

theorem envBound20031 : H12AffineFastState.Bounded env20031 := by
  intro p hp
  have h : env20031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20022_20031 : H12AffineEnvironment.transform 14 1 env20022 = env20031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20022 == env20031) = true)

theorem identity20031 : scanCanonicalize (H12AffineFastState.compose env20031 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20031 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20032 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,16384,1,398,1345,25961,16705,0,1297,8201,17664,139,8328,16,293,16385,1296,25677,1285,4294967296,257,4294975528,1344,137]

theorem envBound20032 : H12AffineFastState.Bounded env20032 := by
  intro p hp
  have h : env20032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20031_20032 : H12AffineEnvironment.transform 11 1296 env20031 = env20032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env20031 == env20032) = true)

def env20033 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,1,398,1345,8233,1025,0,1297,8201,64,139,8328,16,293,1345,1296,8461,1285,4294967296,257,4294975528,1344,137]

theorem envBound20033 : H12AffineFastState.Bounded env20033 := by
  intro p hp
  have h : env20033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20032_20033 : H12AffineEnvironment.transform 13 1344 env20032 = env20033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env20032 == env20033) = true)

theorem identity20033 : scanCanonicalize (H12AffineFastState.compose env20033 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound20033 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20034 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,160,1344,1,398,1345,137,1025,0,1297,169,64,139,40,16,293,1345,1296,429,1285,4294967296,257,4294967432,1344,137]

theorem envBound20034 : H12AffineFastState.Bounded env20034 := by
  intro p hp
  have h : env20034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20033_20034 : H12AffineEnvironment.transform 12 160 env20033 = env20034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20033 == env20034) = true)

theorem identity20034 : scanCanonicalize (H12AffineFastState.compose env20034 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20034 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20035 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,160,1296,1,398,1297,137,1025,0,1297,169,16,139,40,16,293,1297,1296,429,1285,4294967296,257,4294967432,1296,137]

theorem envBound20035 : H12AffineFastState.Bounded env20035 := by
  intro p hp
  have h : env20035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20034_20035 : H12AffineEnvironment.transform 5 16 env20034 = env20035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20034 == env20035) = true)

theorem identity20035 : scanCanonicalize (H12AffineFastState.compose env20035 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20036 : List Nat := [2,4,8,16,32,16,8,256,1,1024,1,1296,40,1296,1,262,1297,1,1025,0,1297,33,16,3,40,16,293,1297,1296,293,1285,4294967296,257,4294967296,1296,1]

theorem envBound20036 : H12AffineFastState.Bounded env20036 := by
  intro p hp
  have h : env20036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20035_20036 : H12AffineEnvironment.transform 6 8 env20035 = env20036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20035 == env20036) = true)

theorem identity20036 : scanCanonicalize (H12AffineFastState.compose env20036 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound20036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20037 : List Nat := [2,4,8,16,32,16,8,256,1,1024,1,1296,40,1296,1,262,1297,1,1025,0,1297,33,16,3,40,16,293,1297,1296,293,1285,293,257,293,1296,1]

theorem envBound20037 : H12AffineFastState.Bounded env20037 := by
  intro p hp
  have h : env20037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20036_20037 : H12AffineEnvironment.transform 31 293 env20036 = env20037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env20036 == env20037) = true)

def env20038 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1345,1,398,1345,8232,1024,0,1297,8201,65,139,8328,16,293,1344,1296,8460,1285,4294967296,257,4294975528,1344,137]

theorem envBound20038 : H12AffineFastState.Bounded env20038 := by
  intro p hp
  have h : env20038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20032_20038 : H12AffineEnvironment.transform 13 1345 env20032 = env20038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20032 == env20038) = true)

theorem identity20038 : scanCanonicalize (H12AffineFastState.compose env20038 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20038 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20039 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,8192,1125,1,170,1125,8232,1024,0,1077,8201,65,139,8328,16,1,1124,1076,8232,1057,4294967296,37,4294975528,1124,137]

theorem envBound20039 : H12AffineFastState.Bounded env20039 := by
  intro p hp
  have h : env20039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20038_20039 : H12AffineEnvironment.transform 7 36 env20038 = env20039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20038 == env20039) = true)

theorem identity20039 : scanCanonicalize (H12AffineFastState.compose env20039 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20039 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20040 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,41,1125,1,170,1125,1,1024,0,1077,32,65,139,161,16,1,1124,1076,1,1057,4294967296,37,4294967297,1124,137]

theorem envBound20040 : H12AffineFastState.Bounded env20040 := by
  intro p hp
  have h : env20040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20039_20040 : H12AffineEnvironment.transform 12 41 env20039 = env20040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20039 == env20040) = true)

theorem identity20040 : scanCanonicalize (H12AffineFastState.compose env20040 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound20040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20041 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,41,1125,1,170,1125,1,1024,0,1077,32,65,139,161,16,1,1124,1076,1,1057,137,37,136,1124,137]

theorem envBound20041 : H12AffineFastState.Bounded env20041 := by
  intro p hp
  have h : env20041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20040_20041 : H12AffineEnvironment.transform 31 137 env20040 = env20041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env20040 == env20041) = true)

theorem identity20041 : scanCanonicalize (H12AffineFastState.compose env20041 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20042 : List Nat := [2,4,8,16,32,64,34,36,43,1024,1,1076,41,1125,1,8,1125,1,1024,0,1077,32,65,41,3,16,1,1124,1076,1,1057,43,37,42,1124,43]

theorem envBound20042 : H12AffineFastState.Bounded env20042 := by
  intro p hp
  have h : env20042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20041_20042 : H12AffineEnvironment.transform 6 34 env20041 = env20042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20041 == env20042) = true)

theorem identity20042 : scanCanonicalize (H12AffineFastState.compose env20042 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound20042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20043 : List Nat := [2,4,8,16,27,64,25,31,16,1024,1,1039,18,1118,1,8,1118,1,1024,0,1038,27,65,18,3,16,1,1119,1039,1,1050,16,30,17,1119,16]

theorem envBound20043 : H12AffineFastState.Bounded env20043 := by
  intro p hp
  have h : env20043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20042_20043 : H12AffineEnvironment.transform 4 27 env20042 = env20043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env20042 == env20043) = true)

def leafEnv20043 : List Nat := [2,4,8,16,27,64,25,31,16,1024,1,1039,18,1118,1,8,1118,1,1024,0,1038,27,65,18,1050,3,1,16,1,1119,1039,1,1050,16,30,17,5,24,1119,16,0,1038,1]

def active20043 : List Nat := [0,1,2,3,5,9]

def tree20043 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20043 : H12WitnessSearch.Good tree20043 := H12GlobalWitnessIndex.good

theorem leafIdentity20043 : H12AffineFastState.composeSystem env20043 rootObs = leafEnv20043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20043 rootObs == leafEnv20043) = true)

theorem terminalChecked20043 : H12PackedTerminal.terminalCheckFast leafEnv20043 active20043 tree20043 = true := by decide +kernel

def env20044 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,32768,33167,1345,58729,16704,32769,4097,8201,17664,139,8328,17,33060,16385,4097,25676,1285,4294967296,257,4294975528,1344,137]

theorem envBound20044 : H12AffineFastState.Bounded env20044 := by
  intro p hp
  have h : env20044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20021_20044 : H12AffineEnvironment.transform 17 58729 env20021 = env20044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env20021 == env20044) = true)

def env20045 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,0,399,1345,25961,16704,1,4097,8201,17664,139,8328,17,292,16385,4097,25676,1285,4294967296,257,4294975528,1344,137]

theorem envBound20045 : H12AffineFastState.Bounded env20045 := by
  intro p hp
  have h : env20045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20044_20045 : H12AffineEnvironment.transform 14 0 env20044 = env20045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20044 == env20045) = true)

theorem identity20045 : scanCanonicalize (H12AffineFastState.compose env20045 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4469) := by decide +kernel

theorem selectedBound20045 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20046 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4469,0,399,1345,13340,4149,1,4097,8201,5237,139,8328,17,292,4468,4097,13625,1285,4294967296,257,4294975528,1344,137]

theorem envBound20046 : H12AffineFastState.Bounded env20046 := by
  intro p hp
  have h : env20046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20045_20046 : H12AffineEnvironment.transform 13 4469 env20045 = env20046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4469 env20045 == env20046) = true)

theorem identity20046 : scanCanonicalize (H12AffineFastState.compose env20046 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20046 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20047 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,41,4469,0,399,1345,5173,4149,1,4097,32,5237,139,161,17,292,4468,4097,5392,1285,4294967296,257,4294967297,1344,137]

theorem envBound20047 : H12AffineFastState.Bounded env20047 := by
  intro p hp
  have h : env20047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20046_20047 : H12AffineEnvironment.transform 12 41 env20046 = env20047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20046 == env20047) = true)

theorem identity20047 : scanCanonicalize (H12AffineFastState.compose env20047 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20047 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20048 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,4096,41,4176,0,170,1124,5173,4149,1,4097,32,5237,139,161,17,1,4177,4097,5173,1056,4294967296,36,4294967297,1125,137]

theorem envBound20048 : H12AffineFastState.Bounded env20048 := by
  intro p hp
  have h : env20048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20047_20048 : H12AffineEnvironment.transform 7 37 env20047 = env20048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20047 == env20048) = true)

theorem identity20048 : scanCanonicalize (H12AffineFastState.compose env20048 (packedSelected [0,1,2] rootPS)) = affineNative (2^(31+1) ^^^ 33) := by decide +kernel

theorem selectedBound20048 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env20049 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,4096,41,4176,0,170,1124,5173,4149,1,4097,32,5237,139,161,17,1,4177,4097,5173,1056,33,36,32,1125,137]

theorem envBound20049 : H12AffineFastState.Bounded env20049 := by
  intro p hp
  have h : env20049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20048_20049 : H12AffineEnvironment.transform 31 33 env20048 = env20049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33 env20048 == env20049) = true)

theorem identity20049 : scanCanonicalize (H12AffineFastState.compose env20049 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound20049 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20050 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,1076,41,1124,0,170,1124,1,1025,1,1077,32,65,139,161,17,1,1125,1077,1,1056,33,36,32,1125,137]

theorem envBound20050 : H12AffineFastState.Bounded env20050 := by
  intro p hp
  have h : env20050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20049_20050 : H12AffineEnvironment.transform 11 1076 env20049 = env20050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env20049 == env20050) = true)

theorem identity20050 : scanCanonicalize (H12AffineFastState.compose env20050 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20051 : List Nat := [2,4,8,16,32,48,128,37,137,1024,1,1076,41,1044,0,170,1044,1,1025,1,1077,32,49,139,161,17,1,1045,1077,1,1056,33,36,32,1045,137]

theorem envBound20051 : H12AffineFastState.Bounded env20051 := by
  intro p hp
  have h : env20051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20050_20051 : H12AffineEnvironment.transform 5 48 env20050 = env20051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20050 == env20051) = true)

theorem identity20051 : scanCanonicalize (H12AffineFastState.compose env20051 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20052 : List Nat := [2,4,8,16,32,48,40,37,33,1024,1,1076,41,1044,0,2,1044,1,1025,1,1077,32,49,35,9,17,1,1045,1077,1,1056,33,36,32,1045,33]

theorem envBound20052 : H12AffineFastState.Bounded env20052 := by
  intro p hp
  have h : env20052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20051_20052 : H12AffineEnvironment.transform 6 40 env20051 = env20052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20051 == env20052) = true)

theorem identity20052 : scanCanonicalize (H12AffineFastState.compose env20052 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20052 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20053 : List Nat := [2,4,8,16,0,16,8,5,1,1024,1,1044,9,1044,0,2,1044,1,1025,1,1045,0,17,3,9,17,1,1045,1045,1,1024,1,4,0,1045,1]

theorem envBound20053 : H12AffineFastState.Bounded env20053 := by
  intro p hp
  have h : env20053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20052_20053 : H12AffineEnvironment.transform 4 0 env20052 = env20053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20052 == env20053) = true)

def env20054 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,1,398,1345,25960,16704,0,4097,8201,17664,139,8328,17,293,16385,4097,25676,1285,4294967296,257,4294975528,1344,137]

theorem envBound20054 : H12AffineFastState.Bounded env20054 := by
  intro p hp
  have h : env20054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20044_20054 : H12AffineEnvironment.transform 14 1 env20044 = env20054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20044 == env20054) = true)

theorem identity20054 : scanCanonicalize (H12AffineFastState.compose env20054 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound20054 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20055 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1077,8192,16384,1,398,1345,25960,16704,0,1076,8201,17664,139,8328,17,293,16385,1076,25676,1285,4294967296,257,4294975528,1344,137]

theorem envBound20055 : H12AffineFastState.Bounded env20055 := by
  intro p hp
  have h : env20055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20054_20055 : H12AffineEnvironment.transform 11 1077 env20054 = env20055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env20054 == env20055) = true)

theorem identity20055 : scanCanonicalize (H12AffineFastState.compose env20055 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 9577) := by decide +kernel

theorem selectedBound20055 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env20056 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1077,8192,9577,1,398,1345,1,9257,0,1076,8201,8297,139,8328,17,293,9576,1076,293,1285,4294967296,257,4294975528,1344,137]

theorem envBound20056 : H12AffineFastState.Bounded env20056 := by
  intro p hp
  have h : env20056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20055_20056 : H12AffineEnvironment.transform 13 9577 env20055 = env20056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9577 env20055 == env20056) = true)

theorem identity20056 : scanCanonicalize (H12AffineFastState.compose env20056 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20056 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20057 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1077,8192,9293,1,170,1125,1,9257,0,1076,8201,8297,139,8328,17,1,9292,1076,1,1057,4294967296,37,4294975528,1124,137]

theorem envBound20057 : H12AffineFastState.Bounded env20057 := by
  intro p hp
  have h : env20057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20056_20057 : H12AffineEnvironment.transform 7 36 env20056 = env20057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20056 == env20057) = true)

theorem identity20057 : scanCanonicalize (H12AffineFastState.compose env20057 (packedSelected [0,5] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound20057 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env20058 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1077,8192,9293,1,170,1125,1,9257,0,1076,8201,8297,139,8328,17,1,9292,1076,1,1057,137,37,8353,1124,137]

theorem envBound20058 : H12AffineFastState.Bounded env20058 := by
  intro p hp
  have h : env20058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20057_20058 : H12AffineEnvironment.transform 31 137 env20057 = env20058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env20057 == env20058) = true)

def env20059 : List Nat := [2,4,8,16,32,16,128,36,137,1024,1,1077,8192,9245,1,170,1077,1,9257,0,1076,8201,8249,139,8328,17,1,9244,1076,1,1057,137,37,8353,1076,137]

theorem envBound20059 : H12AffineFastState.Bounded env20059 := by
  intro p hp
  have h : env20059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20058_20059 : H12AffineEnvironment.transform 5 16 env20058 = env20059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20058 == env20059) = true)

theorem identity20059 : scanCanonicalize (H12AffineFastState.compose env20059 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20060 : List Nat := [2,4,8,16,32,16,128,36,137,1024,1,1077,41,1076,1,170,1077,1,1024,0,1076,32,16,139,161,17,1,1077,1076,1,1057,137,37,136,1076,137]

theorem envBound20060 : H12AffineFastState.Bounded env20060 := by
  intro p hp
  have h : env20060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20059_20060 : H12AffineEnvironment.transform 12 41 env20059 = env20060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20059 == env20060) = true)

theorem identity20060 : scanCanonicalize (H12AffineFastState.compose env20060 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20061 : List Nat := [2,4,8,16,10,16,128,14,137,1024,1,1055,3,1054,1,128,1055,1,1024,0,1054,10,16,139,139,17,1,1055,1054,1,1035,137,15,136,1054,137]

theorem envBound20061 : H12AffineFastState.Bounded env20061 := by
  intro p hp
  have h : env20061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20060_20061 : H12AffineEnvironment.transform 4 10 env20060 = env20061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20060 == env20061) = true)

theorem identity20061 : scanCanonicalize (H12AffineFastState.compose env20061 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound20061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20062 : List Nat := [2,4,8,16,10,16,25,14,16,1024,1,1055,3,1054,1,25,1055,1,1024,0,1054,10,16,18,18,17,1,1055,1054,1,1035,16,15,17,1054,16]

theorem envBound20062 : H12AffineFastState.Bounded env20062 := by
  intro p hp
  have h : env20062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20061_20062 : H12AffineEnvironment.transform 6 25 env20061 = env20062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env20061 == env20062) = true)

def leafEnv20062 : List Nat := [2,4,8,16,10,16,25,14,16,1024,1,1055,3,1054,1,25,1055,1,1024,0,1054,10,16,18,1035,18,1,17,1,1055,1054,1,1035,16,15,17,5,9,1054,16,0,1055,1]

def active20062 : List Nat := [0,1,2,3,9]

def tree20062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20062 : H12WitnessSearch.Good tree20062 := H12GlobalWitnessIndex.good

theorem leafIdentity20062 : H12AffineFastState.composeSystem env20062 rootObs = leafEnv20062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20062 rootObs == leafEnv20062) = true)

theorem terminalChecked20062 : H12PackedTerminal.terminalCheckFast leafEnv20062 active20062 tree20062 = true := by decide +kernel

def env20063 : List Nat := [2,4,8,16,32,17,128,36,137,1024,1,1077,8192,9244,1,170,1076,1,9257,0,1076,8201,8248,139,8328,17,1,9245,1076,1,1057,137,37,8353,1077,137]

theorem envBound20063 : H12AffineFastState.Bounded env20063 := by
  intro p hp
  have h : env20063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20058_20063 : H12AffineEnvironment.transform 5 17 env20058 = env20063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20058 == env20063) = true)

def env20064 : List Nat := [2,4,8,16,32,17,128,36,137,1024,1,1077,40,1076,1,170,1076,1,1025,0,1076,33,16,139,160,17,1,1077,1076,1,1057,137,37,137,1077,137]

theorem envBound20064 : H12AffineFastState.Bounded env20064 := by
  intro p hp
  have h : env20064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20063_20064 : H12AffineEnvironment.transform 12 40 env20063 = env20064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20063 == env20064) = true)

theorem identity20064 : scanCanonicalize (H12AffineFastState.compose env20064 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20065 : List Nat := [2,4,8,16,32,17,8,36,1,1024,1,1077,40,1076,1,34,1076,1,1025,0,1076,33,16,3,40,17,1,1077,1076,1,1057,1,37,1,1077,1]

theorem envBound20065 : H12AffineFastState.Bounded env20065 := by
  intro p hp
  have h : env20065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20064_20065 : H12AffineEnvironment.transform 6 8 env20064 = env20065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20064 == env20065) = true)

def env20066 : List Nat := [2,4,8,16,32,17,128,36,137,1024,1,1077,41,1077,1,170,1076,1,1024,0,1076,32,17,139,161,17,1,1076,1076,1,1057,137,37,136,1077,137]

theorem envBound20066 : H12AffineFastState.Bounded env20066 := by
  intro p hp
  have h : env20066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20063_20066 : H12AffineEnvironment.transform 12 41 env20063 = env20066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20063 == env20066) = true)

theorem identity20066 : scanCanonicalize (H12AffineFastState.compose env20066 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20066 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20067 : List Nat := [2,4,8,16,10,17,128,14,137,1024,1,1055,3,1055,1,128,1054,1,1024,0,1054,10,17,139,139,17,1,1054,1054,1,1035,137,15,136,1055,137]

theorem envBound20067 : H12AffineFastState.Bounded env20067 := by
  intro p hp
  have h : env20067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20066_20067 : H12AffineEnvironment.transform 4 10 env20066 = env20067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20066 == env20067) = true)

theorem identity20067 : scanCanonicalize (H12AffineFastState.compose env20067 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound20067 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20068 : List Nat := [2,4,8,16,10,17,24,14,17,1024,1,1055,3,1055,1,24,1054,1,1024,0,1054,10,17,19,19,17,1,1054,1054,1,1035,17,15,16,1055,17]

theorem envBound20068 : H12AffineFastState.Bounded env20068 := by
  intro p hp
  have h : env20068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20067_20068 : H12AffineEnvironment.transform 6 24 env20067 = env20068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env20067 == env20068) = true)

def leafEnv20068 : List Nat := [2,4,8,16,10,17,24,14,17,1024,1,1055,3,1055,1,24,1054,1,1024,0,1054,10,17,19,1035,19,1,17,1,1054,1054,1,1035,17,15,16,5,9,1055,17,0,1055,1]

def active20068 : List Nat := [0,1,2,3,9]

def tree20068 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20068 : H12WitnessSearch.Good tree20068 := H12GlobalWitnessIndex.good

theorem leafIdentity20068 : H12AffineFastState.composeSystem env20068 rootObs = leafEnv20068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20068 rootObs == leafEnv20068) = true)

theorem terminalChecked20068 : H12PackedTerminal.terminalCheckFast leafEnv20068 active20068 tree20068 = true := by decide +kernel

def env20069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10249,147521,230469,8328,672784,927820,16385,676864,1073741824,131140,4294967296,257,4295208166,1344,512]

theorem envBound20069 : H12AffineFastState.Bounded env20069 := by
  intro p hp
  have h : env20069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19749_20069 : H12AffineEnvironment.transform 21 10249 env19749 = env20069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env19749 == env20069) = true)

def env20070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,147521,230469,8328,672784,925772,16385,676864,1073741824,131140,4294967296,257,4295206118,1344,512]

theorem envBound20070 : H12AffineFastState.Bounded env20070 := by
  intro p hp
  have h : env20070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20069_20070 : H12AffineEnvironment.transform 10 0 env20069 = env20070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20069 == env20070) = true)

def env20071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98565,8328,541008,795916,16385,545088,1073741824,1284,4294967296,257,4295074214,1344,512]

theorem envBound20071 : H12AffineFastState.Bounded env20071 := by
  intro p hp
  have h : env20071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20070_20071 : H12AffineEnvironment.transform 16 1344 env20070 = env20071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20070 == env20071) = true)

theorem identity20071 : scanCanonicalize (H12AffineFastState.compose env20071 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 566393) := by decide +kernel

theorem selectedBound20071 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98565,8328,541008,795916,16385,545088,566393,1284,4294967296,257,4295074214,1344,512]

theorem envBound20072 : H12AffineFastState.Bounded env20072 := by
  intro p hp
  have h : env20072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20071_20072 : H12AffineEnvironment.transform 29 566393 env20071 = env20072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 566393 env20071 == env20072) = true)

theorem identity20072 : scanCanonicalize (H12AffineFastState.compose env20072 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20072 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8201,17665,98565,8328,17745,270605,16385,21825,41080,1284,4294967296,257,4295074214,1344,512]

theorem envBound20073 : H12AffineFastState.Bounded env20073 := by
  intro p hp
  have h : env20073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20072_20073 : H12AffineEnvironment.transform 18 1025 env20072 = env20073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20072 == env20073) = true)

theorem identity20073 : scanCanonicalize (H12AffineFastState.compose env20073 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound20073 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,251,1344,262144,1025,32769,4097,8201,17665,33278,8328,17745,270605,16385,21825,41080,1284,4294967296,257,4295008605,1344,512]

theorem envBound20074 : H12AffineFastState.Bounded env20074 := by
  intro p hp
  have h : env20074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20073_20074 : H12AffineEnvironment.transform 15 251 env20073 = env20074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env20073 == env20074) = true)

theorem identity20074 : scanCanonicalize (H12AffineFastState.compose env20074 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20074 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,251,1344,262144,1025,32769,4097,8201,5457,33278,8328,5377,270605,4177,1297,41080,1284,4294967296,257,4295008605,1344,512]

theorem envBound20075 : H12AffineFastState.Bounded env20075 := by
  intro p hp
  have h : env20075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20074_20075 : H12AffineEnvironment.transform 13 4176 env20074 = env20075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20074 == env20075) = true)

theorem identity20075 : scanCanonicalize (H12AffineFastState.compose env20075 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound20075 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,251,1344,262144,1025,32769,4097,8201,5457,33278,8328,5377,270605,4177,1297,41080,1284,8321,257,33244,1344,512]

theorem envBound20076 : H12AffineFastState.Bounded env20076 := by
  intro p hp
  have h : env20076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20075_20076 : H12AffineEnvironment.transform 31 8321 env20075 = env20076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env20075 == env20076) = true)

theorem identity20076 : scanCanonicalize (H12AffineFastState.compose env20076 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20076 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,251,1344,8541,1025,32769,4097,8201,5457,33278,8328,5377,80,4177,1297,41080,1284,8321,257,33244,1344,512]

theorem envBound20077 : H12AffineFastState.Bounded env20077 := by
  intro p hp
  have h : env20077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20076_20077 : H12AffineEnvironment.transform 17 8541 env20076 = env20077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8541 env20076 == env20077) = true)

theorem identity20077 : scanCanonicalize (H12AffineFastState.compose env20077 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5481) := by decide +kernel

theorem selectedBound20077 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5481,4176,32768,251,1344,5172,1025,32769,4097,5472,5457,33278,5601,5377,80,4177,1297,38161,1284,5608,257,33244,1344,512]

theorem envBound20078 : H12AffineFastState.Bounded env20078 := by
  intro p hp
  have h : env20078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20077_20078 : H12AffineEnvironment.transform 12 5481 env20077 = env20078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5481 env20077 == env20078) = true)

theorem identity20078 : scanCanonicalize (H12AffineFastState.compose env20078 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20078 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5481,4176,137,251,1344,5172,1025,136,4097,5472,5457,375,5601,5377,80,4177,1297,5528,1284,5608,257,341,1344,512]

theorem envBound20079 : H12AffineFastState.Bounded env20079 := by
  intro p hp
  have h : env20079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20078_20079 : H12AffineEnvironment.transform 14 137 env20078 = env20079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20078 == env20079) = true)

theorem identity20079 : scanCanonicalize (H12AffineFastState.compose env20079 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound20079 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1465,208,1513,137,251,1344,397,1025,136,1464,217,232,375,88,184,80,1512,1297,33,1284,81,257,341,1344,512]

theorem envBound20080 : H12AffineFastState.Bounded env20080 := by
  intro p hp
  have h : env20080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20079_20080 : H12AffineEnvironment.transform 11 1465 env20079 = env20080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env20079 == env20080) = true)

theorem identity20080 : scanCanonicalize (H12AffineFastState.compose env20080 (packedSelected [0,9] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound20080 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env20081 : List Nat := [2,4,8,16,32,64,128,256,341,1024,0,1465,208,1513,137,251,1344,397,1025,136,1464,217,232,375,88,184,80,1512,1297,33,1284,81,257,341,1344,341]

theorem envBound20081 : H12AffineFastState.Bounded env20081 := by
  intro p hp
  have h : env20081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20080_20081 : H12AffineEnvironment.transform 8 341 env20080 = env20081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env20080 == env20081) = true)

theorem identity20081 : scanCanonicalize (H12AffineFastState.compose env20081 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound20081 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20082 : List Nat := [2,4,8,16,32,64,128,256,341,221,0,356,208,308,137,251,413,397,220,136,357,217,232,375,88,184,80,309,460,33,473,81,257,341,413,341]

theorem envBound20082 : H12AffineFastState.Bounded env20082 := by
  intro p hp
  have h : env20082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20081_20082 : H12AffineEnvironment.transform 9 221 env20081 = env20082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env20081 == env20082) = true)

theorem identity20082 : scanCanonicalize (H12AffineFastState.compose env20082 (packedSelected [0,1,2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound20082 : packedSelected [0,1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env20083 : List Nat := [2,4,8,16,32,64,56,256,341,101,0,356,104,308,49,67,293,309,100,48,357,97,80,375,88,0,80,309,372,33,353,81,257,341,293,341]

theorem envBound20083 : H12AffineFastState.Bounded env20083 := by
  intro p hp
  have h : env20083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20082_20083 : H12AffineEnvironment.transform 6 56 env20082 = env20083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env20082 == env20083) = true)

theorem identity20083 : scanCanonicalize (H12AffineFastState.compose env20083 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20083 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env20084 : List Nat := [2,4,8,16,17,64,9,256,341,84,0,341,89,261,0,67,276,260,85,1,340,80,80,326,88,0,80,260,325,16,336,81,257,341,276,341]

theorem envBound20084 : H12AffineFastState.Bounded env20084 := by
  intro p hp
  have h : env20084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20083_20084 : H12AffineEnvironment.transform 4 17 env20083 = env20084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20083 == env20084) = true)

theorem identity20084 : scanCanonicalize (H12AffineFastState.compose env20084 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20085 : List Nat := [2,4,8,16,17,64,9,4,81,84,0,81,89,1,0,67,16,0,85,1,80,80,80,66,88,0,80,0,65,16,84,81,5,81,16,81]

theorem envBound20085 : H12AffineFastState.Bounded env20085 := by
  intro p hp
  have h : env20085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20084_20085 : H12AffineEnvironment.transform 7 4 env20084 = env20085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20084 == env20085) = true)

def env20086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541009,795917,16385,545089,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound20086 : H12AffineFastState.Bounded env20086 := by
  intro p hp
  have h : env20086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20070_20086 : H12AffineEnvironment.transform 16 1345 env20070 = env20086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20070 == env20086) = true)

theorem identity20086 : scanCanonicalize (H12AffineFastState.compose env20086 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 566313) := by decide +kernel

theorem selectedBound20086 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541009,795917,16385,545089,566313,1285,4294967296,257,4295074215,1344,512]

theorem envBound20087 : H12AffineFastState.Bounded env20087 := by
  intro p hp
  have h : env20087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20086_20087 : H12AffineEnvironment.transform 29 566313 env20086 = env20087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 566313 env20086 == env20087) = true)

def env20088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8201,17664,98564,8328,320889,33061,16385,324969,262145,1285,4294967296,257,4295074215,1344,512]

theorem envBound20088 : H12AffineFastState.Bounded env20088 := by
  intro p hp
  have h : env20088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20087_20088 : H12AffineEnvironment.transform 18 304168 env20087 = env20088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20087 == env20088) = true)

theorem identity20088 : scanCanonicalize (H12AffineFastState.compose env20088 (packedSelected [4,9,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound20088 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,292,65536,1345,262144,271628,293,4097,8201,17664,65568,8328,287837,1,16385,291917,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20089 : H12AffineFastState.Bounded env20089 := by
  intro p hp
  have h : env20089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20088_20089 : H12AffineEnvironment.transform 14 292 env20088 = env20089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env20088 == env20089) = true)

def env20090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,292,65536,1345,262144,271628,293,1297,8201,17664,65568,8328,287837,1,16385,287069,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20090 : H12AffineFastState.Bounded env20090 := by
  intro p hp
  have h : env20090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20089_20090 : H12AffineEnvironment.transform 11 1296 env20089 = env20090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env20089 == env20090) = true)

theorem identity20090 : scanCanonicalize (H12AffineFastState.compose env20090 (packedSelected [4,9] rootPS)) = affineNative (2^(17+1) ^^^ 25677) := by decide +kernel

theorem selectedBound20090 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,292,65536,1345,25677,16705,293,1297,8201,17664,65568,8328,16,1,16385,1296,25676,1285,4294967296,257,4295041155,1344,512]

theorem envBound20091 : H12AffineFastState.Bounded env20091 := by
  intro p hp
  have h : env20091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20090_20091 : H12AffineEnvironment.transform 17 25677 env20090 = env20091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25677 env20090 == env20091) = true)

def env20092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,16384,292,65536,1297,25629,16657,293,1297,8201,17664,65568,8328,16,1,16385,1296,25628,1285,4294967296,257,4295041155,1296,512]

theorem envBound20092 : H12AffineFastState.Bounded env20092 := by
  intro p hp
  have h : env20092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20091_20092 : H12AffineEnvironment.transform 5 16 env20091 = env20092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20091 == env20092) = true)

def env20093 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1296,292,65536,1297,8461,1025,293,1297,8201,16,65568,8328,16,1,1297,1296,8460,1285,4294967296,257,4295041155,1296,512]

theorem envBound20093 : H12AffineFastState.Bounded env20093 := by
  intro p hp
  have h : env20093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20092_20093 : H12AffineEnvironment.transform 13 1296 env20092 = env20093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env20092 == env20093) = true)

theorem identity20093 : scanCanonicalize (H12AffineFastState.compose env20093 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound20093 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20094 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1296,292,171,1297,8461,1025,293,1297,8201,16,139,8328,16,1,1297,1296,8460,1285,4294967296,257,4294975528,1296,512]

theorem envBound20094 : H12AffineFastState.Bounded env20094 := by
  intro p hp
  have h : env20094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20093_20094 : H12AffineEnvironment.transform 15 171 env20093 = env20094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env20093 == env20094) = true)

theorem identity20094 : scanCanonicalize (H12AffineFastState.compose env20094 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20094 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20095 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,40,1296,292,171,1297,293,1025,293,1297,33,16,139,160,16,1,1297,1296,292,1285,4294967296,257,4294967296,1296,512]

theorem envBound20095 : H12AffineFastState.Bounded env20095 := by
  intro p hp
  have h : env20095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20094_20095 : H12AffineEnvironment.transform 12 40 env20094 = env20095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20094 == env20095) = true)

theorem identity20095 : scanCanonicalize (H12AffineFastState.compose env20095 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound20095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20096 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,40,1296,292,171,1297,293,1025,293,1297,33,16,139,160,16,1,1297,1296,292,1285,805,257,805,1296,512]

theorem envBound20096 : H12AffineFastState.Bounded env20096 := by
  intro p hp
  have h : env20096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20095_20096 : H12AffineEnvironment.transform 31 805 env20095 = env20096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env20095 == env20096) = true)

theorem identity20096 : scanCanonicalize (H12AffineFastState.compose env20096 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound20096 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20097 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1296,40,1296,292,171,1297,293,1025,293,1297,33,16,139,160,16,1,1297,1296,292,1285,429,257,429,1296,136]

theorem envBound20097 : H12AffineFastState.Bounded env20097 := by
  intro p hp
  have h : env20097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20096_20097 : H12AffineEnvironment.transform 8 136 env20096 = env20097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20096 == env20097) = true)

theorem identity20097 : scanCanonicalize (H12AffineFastState.compose env20097 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20098 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,40,1076,0,171,1077,1,1025,1,1077,33,16,139,160,16,1,1077,1076,0,1057,137,37,137,1076,136]

theorem envBound20098 : H12AffineFastState.Bounded env20098 := by
  intro p hp
  have h : env20098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20097_20098 : H12AffineEnvironment.transform 7 36 env20097 = env20098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20097 == env20098) = true)

def leafEnv20098 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,40,1076,0,171,1077,1,1025,1,1077,33,16,139,1056,160,1,16,1,1077,1076,0,1057,137,37,137,5,34,1076,136,0,1077,1]

def active20098 : List Nat := [0,1,2,3,4,6,9]

def tree20098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20098 : H12WitnessSearch.Good tree20098 := H12GlobalWitnessIndex.good

theorem leafIdentity20098 : H12AffineFastState.composeSystem env20098 rootObs = leafEnv20098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20098 rootObs == leafEnv20098) = true)

theorem terminalChecked20098 : H12PackedTerminal.terminalCheckFast leafEnv20098 active20098 tree20098 = true := by decide +kernel

def env20099 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1297,292,65536,1297,8460,1024,293,1297,8201,17,65568,8328,16,1,1296,1296,8461,1285,4294967296,257,4295041155,1296,512]

theorem envBound20099 : H12AffineFastState.Bounded env20099 := by
  intro p hp
  have h : env20099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20092_20099 : H12AffineEnvironment.transform 13 1297 env20092 = env20099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env20092 == env20099) = true)

theorem identity20099 : scanCanonicalize (H12AffineFastState.compose env20099 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 775) := by decide +kernel

theorem selectedBound20099 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20100 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1297,292,775,1297,8460,1024,293,1297,8201,17,807,8328,16,1,1296,1296,8461,1285,4294967296,257,4294976388,1296,512]

theorem envBound20100 : H12AffineFastState.Bounded env20100 := by
  intro p hp
  have h : env20100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20099_20100 : H12AffineEnvironment.transform 15 775 env20099 = env20100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 775 env20099 == env20100) = true)

theorem identity20100 : scanCanonicalize (H12AffineFastState.compose env20100 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20100 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20101 : List Nat := [2,4,8,16,32,16,128,37,512,1024,0,1077,8192,1076,1,546,1076,8233,1024,0,1076,8201,17,514,8328,16,1,1077,1077,8232,1056,4294967296,36,4294976161,1077,512]

theorem envBound20101 : H12AffineFastState.Bounded env20101 := by
  intro p hp
  have h : env20101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20100_20101 : H12AffineEnvironment.transform 7 37 env20100 = env20101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20100 == env20101) = true)

theorem identity20101 : scanCanonicalize (H12AffineFastState.compose env20101 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound20101 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20102 : List Nat := [2,4,8,16,32,16,128,37,137,1024,0,1077,8192,1076,1,171,1076,8233,1024,0,1076,8201,17,139,8328,16,1,1077,1077,8232,1056,4294967296,36,4294975528,1077,137]

theorem envBound20102 : H12AffineFastState.Bounded env20102 := by
  intro p hp
  have h : env20102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20101_20102 : H12AffineEnvironment.transform 8 137 env20101 = env20102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20101 == env20102) = true)

theorem identity20102 : scanCanonicalize (H12AffineFastState.compose env20102 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20103 : List Nat := [2,4,8,16,32,16,34,37,43,1024,0,1077,8192,1076,1,9,1076,8233,1024,0,1076,8201,17,41,8234,16,1,1077,1077,8232,1056,4294967296,36,4294975528,1077,43]

theorem envBound20103 : H12AffineFastState.Bounded env20103 := by
  intro p hp
  have h : env20103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20102_20103 : H12AffineEnvironment.transform 6 34 env20102 = env20103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20102 == env20103) = true)

theorem identity20103 : scanCanonicalize (H12AffineFastState.compose env20103 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20103 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20104 : List Nat := [2,4,8,16,32,16,34,37,43,1024,0,1077,40,1076,1,9,1076,1,1024,0,1076,33,17,41,2,16,1,1077,1077,0,1056,4294967296,36,4294967296,1077,43]

theorem envBound20104 : H12AffineFastState.Bounded env20104 := by
  intro p hp
  have h : env20104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20103_20104 : H12AffineEnvironment.transform 12 40 env20103 = env20104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20103 == env20104) = true)

theorem identity20104 : scanCanonicalize (H12AffineFastState.compose env20104 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound20104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20105 : List Nat := [2,4,8,16,32,16,34,37,43,1024,0,1077,40,1076,1,9,1076,1,1024,0,1076,33,17,41,2,16,1,1077,1077,0,1056,42,36,42,1077,43]

theorem envBound20105 : H12AffineFastState.Bounded env20105 := by
  intro p hp
  have h : env20105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20104_20105 : H12AffineEnvironment.transform 31 42 env20104 = env20105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env20104 == env20105) = true)

theorem identity20105 : scanCanonicalize (H12AffineFastState.compose env20105 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20106 : List Nat := [2,4,8,16,16,16,18,21,27,1024,0,1029,24,1028,1,9,1028,1,1024,0,1028,17,17,25,2,16,1,1029,1029,0,1040,26,20,26,1029,27]

theorem envBound20106 : H12AffineFastState.Bounded env20106 := by
  intro p hp
  have h : env20106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20105_20106 : H12AffineEnvironment.transform 4 16 env20105 = env20106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20105 == env20106) = true)

def leafEnv20106 : List Nat := [2,4,8,16,16,16,18,21,27,1024,0,1029,24,1028,1,9,1028,1,1024,0,1028,17,17,25,1040,2,1,16,1,1029,1029,0,1040,26,20,26,5,18,1029,27,0,1028,1]

def active20106 : List Nat := [0,1,2,3,9]

def tree20106 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20106 : H12WitnessSearch.Good tree20106 := H12GlobalWitnessIndex.good

theorem leafIdentity20106 : H12AffineFastState.composeSystem env20106 rootObs = leafEnv20106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20106 rootObs == leafEnv20106) = true)

theorem terminalChecked20106 : H12PackedTerminal.terminalCheckFast leafEnv20106 active20106 tree20106 = true := by decide +kernel

def env20107 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,8192,16384,292,65536,1296,25628,16656,293,1297,8201,17664,65568,8328,16,1,16385,1296,25629,1285,4294967296,257,4295041155,1297,512]

theorem envBound20107 : H12AffineFastState.Bounded env20107 := by
  intro p hp
  have h : env20107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20091_20107 : H12AffineEnvironment.transform 5 17 env20091 = env20107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20091 == env20107) = true)

theorem identity20107 : scanCanonicalize (H12AffineFastState.compose env20107 (packedSelected [1,3,8] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound20107 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env20108 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,8192,1945,292,65536,1296,9093,1673,293,1297,8201,665,65568,8328,16,1,1944,1296,9092,1285,4294967296,257,4295041155,1297,512]

theorem envBound20108 : H12AffineFastState.Bounded env20108 := by
  intro p hp
  have h : env20108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20107_20108 : H12AffineEnvironment.transform 13 1945 env20107 = env20108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env20107 == env20108) = true)

def env20109 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1296,8192,1297,292,65536,1296,8461,1025,293,1297,8201,17,65568,8328,16,1,1296,1296,8460,1285,4294967296,257,4295041155,1297,136]

theorem envBound20109 : H12AffineFastState.Bounded env20109 := by
  intro p hp
  have h : env20109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20108_20109 : H12AffineEnvironment.transform 8 136 env20108 = env20109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20108 == env20109) = true)

def env20110 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,0,8192,1,292,65536,0,8461,273,293,1,8201,17,65568,8328,16,1,0,0,8460,21,4294967296,257,4295041155,1,136]

theorem envBound20110 : H12AffineFastState.Bounded env20110 := by
  intro p hp
  have h : env20110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20109_20110 : H12AffineEnvironment.transform 9 272 env20109 = env20110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20109 == env20110) = true)

theorem identity20110 : scanCanonicalize (H12AffineFastState.compose env20110 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound20110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20111 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,0,8192,1,292,171,0,8461,273,293,1,8201,17,139,8328,16,1,0,0,8460,21,4294967296,257,4294975528,1,136]

theorem envBound20111 : H12AffineFastState.Bounded env20111 := by
  intro p hp
  have h : env20111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20110_20111 : H12AffineEnvironment.transform 15 171 env20110 = env20111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env20110 == env20111) = true)

theorem identity20111 : scanCanonicalize (H12AffineFastState.compose env20111 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20111 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20112 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,0,268,1,292,171,0,1,273,293,1,261,17,139,388,16,1,0,0,0,21,4294967296,257,4294967588,1,136]

theorem envBound20112 : H12AffineFastState.Bounded env20112 := by
  intro p hp
  have h : env20112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20111_20112 : H12AffineEnvironment.transform 12 268 env20111 = env20112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20111 == env20112) = true)

def env20113 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,268,1,292,35,0,1,273,293,1,261,17,3,268,16,1,0,0,0,21,4294967296,257,4294967588,1,0]

theorem envBound20113 : H12AffineFastState.Bounded env20113 := by
  intro p hp
  have h : env20113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20112_20113 : H12AffineEnvironment.transform 6 8 env20112 = env20113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20112 == env20113) = true)

theorem identity20113 : scanCanonicalize (H12AffineFastState.compose env20113 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20113 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20114 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,268,1,292,35,0,1,273,293,1,261,17,3,268,16,1,0,0,0,21,292,257,0,1,0]

theorem envBound20114 : H12AffineFastState.Bounded env20114 := by
  intro p hp
  have h : env20114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20113_20114 : H12AffineEnvironment.transform 31 292 env20113 = env20114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20113 == env20114) = true)

def env20115 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,268,1,260,3,0,1,273,261,1,261,17,3,268,16,1,0,0,0,21,260,257,0,1,0]

theorem envBound20115 : H12AffineFastState.Bounded env20115 := by
  intro p hp
  have h : env20115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20114_20115 : H12AffineEnvironment.transform 4 0 env20114 = env20115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20114 == env20115) = true)

def leafEnv20115 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,268,1,260,3,0,1,273,261,1,261,17,3,20,268,1,16,1,0,0,0,21,260,257,0,5,2,1,0,0,1,1]

def active20115 : List Nat := [0,1,2,3,7]

def tree20115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20115 : H12WitnessSearch.Good tree20115 := H12GlobalWitnessIndex.good

theorem leafIdentity20115 : H12AffineFastState.composeSystem env20115 rootObs = leafEnv20115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20115 rootObs == leafEnv20115) = true)

theorem terminalChecked20115 : H12PackedTerminal.terminalCheckFast leafEnv20115 active20115 tree20115 = true := by decide +kernel

def env20116 : List Nat := [2,4,8,16,1,17,8,256,0,272,0,0,268,1,261,2,0,1,273,260,1,261,17,3,268,16,1,0,0,0,21,261,257,0,1,0]

theorem envBound20116 : H12AffineFastState.Bounded env20116 := by
  intro p hp
  have h : env20116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20114_20116 : H12AffineEnvironment.transform 4 1 env20114 = env20116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20114 == env20116) = true)

theorem identity20116 : scanCanonicalize (H12AffineFastState.compose env20116 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20116 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20117 : List Nat := [2,4,8,16,1,17,8,5,0,21,0,0,9,1,0,2,0,1,20,1,1,0,17,3,9,16,1,0,0,0,21,0,4,0,1,0]

theorem envBound20117 : H12AffineFastState.Bounded env20117 := by
  intro p hp
  have h : env20117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20116_20117 : H12AffineEnvironment.transform 7 5 env20116 = env20117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20116 == env20117) = true)

def leafEnv20117 : List Nat := [2,4,8,16,1,17,8,5,0,21,0,0,9,1,0,2,0,1,20,1,1,0,17,3,20,9,1,16,1,0,0,0,21,0,4,0,5,3,1,0,0,1,1]

def active20117 : List Nat := [0,1,2,3]

def tree20117 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20117 : H12WitnessSearch.Good tree20117 := H12GlobalWitnessIndex.good

theorem leafIdentity20117 : H12AffineFastState.composeSystem env20117 rootObs = leafEnv20117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20117 rootObs == leafEnv20117) = true)

theorem terminalChecked20117 : H12PackedTerminal.terminalCheckFast leafEnv20117 active20117 tree20117 = true := by decide +kernel

def env20118 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,268,1,292,34,0,1,273,293,1,261,17,2,269,16,1,0,0,0,21,4294967296,257,4294967588,1,1]

theorem envBound20118 : H12AffineFastState.Bounded env20118 := by
  intro p hp
  have h : env20118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20112_20118 : H12AffineEnvironment.transform 6 9 env20112 = env20118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20112 == env20118) = true)

theorem identity20118 : scanCanonicalize (H12AffineFastState.compose env20118 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound20118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20119 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,268,1,292,34,0,1,273,293,1,261,17,2,269,16,1,0,0,0,21,1,257,293,1,1]

theorem envBound20119 : H12AffineFastState.Bounded env20119 := by
  intro p hp
  have h : env20119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20118_20119 : H12AffineEnvironment.transform 31 1 env20118 = env20119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env20118 == env20119) = true)

def env20120 : List Nat := [2,4,8,16,0,17,9,256,1,272,0,0,268,1,260,2,0,1,273,261,1,261,17,2,269,16,1,0,0,0,21,1,257,261,1,1]

theorem envBound20120 : H12AffineFastState.Bounded env20120 := by
  intro p hp
  have h : env20120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20119_20120 : H12AffineEnvironment.transform 4 0 env20119 = env20120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20119 == env20120) = true)

theorem identity20120 : scanCanonicalize (H12AffineFastState.compose env20120 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20121 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,0,8,1,0,2,0,1,21,1,1,1,17,2,9,16,1,0,0,0,21,1,5,1,1,1]

theorem envBound20121 : H12AffineFastState.Bounded env20121 := by
  intro p hp
  have h : env20121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20120_20121 : H12AffineEnvironment.transform 7 4 env20120 = env20121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20120 == env20121) = true)

def leafEnv20121 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,0,8,1,0,2,0,1,21,1,1,1,17,2,20,9,1,16,1,0,0,0,21,1,5,1,5,2,1,1,0,1,1]

def active20121 : List Nat := [0,1,2,3]

def tree20121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20121 : H12WitnessSearch.Good tree20121 := H12GlobalWitnessIndex.good

theorem leafIdentity20121 : H12AffineFastState.composeSystem env20121 rootObs = leafEnv20121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20121 rootObs == leafEnv20121) = true)

theorem terminalChecked20121 : H12PackedTerminal.terminalCheckFast leafEnv20121 active20121 tree20121 = true := by decide +kernel

def env20122 : List Nat := [2,4,8,16,1,17,9,256,1,272,0,0,268,1,261,3,0,1,273,260,1,261,17,2,269,16,1,0,0,0,21,1,257,260,1,1]

theorem envBound20122 : H12AffineFastState.Bounded env20122 := by
  intro p hp
  have h : env20122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20119_20122 : H12AffineEnvironment.transform 4 1 env20119 = env20122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20119 == env20122) = true)

def leafEnv20122 : List Nat := [2,4,8,16,1,17,9,256,1,272,0,0,268,1,261,3,0,1,273,260,1,261,17,2,20,269,1,16,1,0,0,0,21,1,257,260,5,3,1,1,0,1,1]

def active20122 : List Nat := [0,1,2,3,7]

def tree20122 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20122 : H12WitnessSearch.Good tree20122 := H12GlobalWitnessIndex.good

theorem leafIdentity20122 : H12AffineFastState.composeSystem env20122 rootObs = leafEnv20122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20122 rootObs == leafEnv20122) = true)

theorem terminalChecked20122 : H12PackedTerminal.terminalCheckFast leafEnv20122 active20122 tree20122 = true := by decide +kernel

def env20123 : List Nat := [2,4,8,16,32,17,128,256,136,273,0,1,8192,0,292,65536,1,8461,272,293,0,8201,17,65568,8328,16,1,1,1,8460,20,4294967296,257,4295041155,0,136]

theorem envBound20123 : H12AffineFastState.Bounded env20123 := by
  intro p hp
  have h : env20123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20109_20123 : H12AffineEnvironment.transform 9 273 env20109 = env20123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20109 == env20123) = true)

def env20124 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,8192,0,0,65536,1,8233,52,1,0,8201,17,65568,8328,16,1,1,1,8232,20,4294967296,37,4295041155,0,136]

theorem envBound20124 : H12AffineFastState.Bounded env20124 := by
  intro p hp
  have h : env20124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20123_20124 : H12AffineEnvironment.transform 7 36 env20123 = env20124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20123 == env20124) = true)

def env20125 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,160,0,0,65536,1,137,52,1,0,169,17,65568,40,16,1,1,1,136,20,4294967296,37,4295032867,0,136]

theorem envBound20125 : H12AffineFastState.Bounded env20125 := by
  intro p hp
  have h : env20125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20124_20125 : H12AffineEnvironment.transform 12 160 env20124 = env20125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20124 == env20125) = true)

theorem identity20125 : scanCanonicalize (H12AffineFastState.compose env20125 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20126 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,160,0,0,65536,1,137,52,1,0,169,17,65568,40,16,1,1,1,136,20,0,37,65571,0,136]

theorem envBound20126 : H12AffineFastState.Bounded env20126 := by
  intro p hp
  have h : env20126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2