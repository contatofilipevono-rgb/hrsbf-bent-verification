import H12CloudChart2Data075

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound18629 : H12AffineFastState.Bounded env18629 := by
  intro p hp
  have h : env18629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18626_18629 : H12AffineEnvironment.transform 4 1 env18626 = env18629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18626 == env18629) = true)

def leafEnv18629 : List Nat := [2,4,8,16,1,17,128,140,136,1024,2048,1180,2176,1180,2185,2186,1181,2049,1025,2184,1181,136,16,139,1160,2056,1,17,2048,1180,1181,2049,1161,137,141,1,5,2051,1181,136,0,1180,1]

def active18629 : List Nat := [0,1,2,3,6,9,10]

def tree18629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18629 : H12WitnessSearch.Good tree18629 := H12GlobalWitnessIndex.good

theorem leafIdentity18629 : H12AffineFastState.composeSystem env18629 rootObs = leafEnv18629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18629 rootObs == leafEnv18629) = true)

theorem terminalChecked18629 : H12PackedTerminal.terminalCheckFast leafEnv18629 active18629 tree18629 = true := by decide +kernel

def env18630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,4194304,65,98564,8328,525328,4984900,4097,529408,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound18630 : H12AffineFastState.Bounded env18630 := by
  intro p hp
  have h : env18630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18605_18630 : H12AffineEnvironment.transform 13 4097 env18605 = env18630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env18605 == env18630) = true)

theorem identity18630 : scanCanonicalize (H12AffineFastState.compose env18630 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1105) := by decide +kernel

theorem selectedBound18630 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env18631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,1105,32769,4097,4194304,65,98564,8328,65,4461589,4097,4177,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound18631 : H12AffineFastState.Bounded env18631 := by
  intro p hp
  have h : env18631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18630_18631 : H12AffineEnvironment.transform 18 1105 env18630 = env18631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env18630 == env18631) = true)

def env18632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1105,32769,1345,4194304,65,98564,8328,65,4456789,1345,1297,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18632 : H12AffineFastState.Bounded env18632 := by
  intro p hp
  have h : env18632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18631_18632 : H12AffineEnvironment.transform 11 1344 env18631 = env18632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18631 == env18632) = true)

theorem identity18632 : scanCanonicalize (H12AffineFastState.compose env18632 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 106706) := by decide +kernel

theorem selectedBound18632 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,106706,1105,32769,1345,4194304,65,98564,8328,65,4301191,1345,1297,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18633 : H12AffineFastState.Bounded env18633 := by
  intro p hp
  have h : env18633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18632_18633 : H12AffineEnvironment.transform 17 106706 env18632 = env18633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106706 env18632 == env18633) = true)

theorem identity18633 : scanCanonicalize (H12AffineFastState.compose env18633 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4294874) := by decide +kernel

theorem selectedBound18633 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,106706,1105,32769,1345,4194304,65,98564,8328,65,4301191,1345,1297,4294874,1285,4294967296,257,4299260334,1344,512]

theorem envBound18634 : H12AffineFastState.Bounded env18634 := by
  intro p hp
  have h : env18634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18633_18634 : H12AffineEnvironment.transform 29 4294874 env18633 = env18634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294874 env18633 == env18634) = true)

theorem identity18634 : scanCanonicalize (H12AffineFastState.compose env18634 (packedSelected [1,3,5,10,12,21] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound18634 : packedSelected [1,3,5,10,12,21] rootPS < 2^1333 := by decide +kernel

def env18635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,2219,1344,43129,1105,32769,1345,4194304,65,35247,8328,65,4237612,1345,1297,4227185,1285,4294967296,257,4299196677,1344,512]

theorem envBound18635 : H12AffineFastState.Bounded env18635 := by
  intro p hp
  have h : env18635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18634_18635 : H12AffineEnvironment.transform 15 2219 env18634 = env18635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env18634 == env18635) = true)

theorem identity18635 : scanCanonicalize (H12AffineFastState.compose env18635 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2420) := by decide +kernel

theorem selectedBound18635 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env18636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2420,2219,1344,8461,1105,2421,1345,4194304,65,219,8328,65,4202584,1345,1297,4196613,1285,4294967296,257,4299161713,1344,512]

theorem envBound18636 : H12AffineFastState.Bounded env18636 := by
  intro p hp
  have h : env18636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18635_18636 : H12AffineEnvironment.transform 14 2420 env18635 = env18636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2420 env18635 == env18636) = true)

theorem identity18636 : scanCanonicalize (H12AffineFastState.compose env18636 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18636 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env18637 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,2340,2219,1296,8461,1025,2341,1297,4194304,17,139,8328,17,4202504,1297,1297,4196613,1285,4294967296,257,4299161633,1296,512]

theorem envBound18637 : H12AffineFastState.Bounded env18637 := by
  intro p hp
  have h : env18637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18636_18637 : H12AffineEnvironment.transform 5 16 env18636 = env18637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18636 == env18637) = true)

theorem identity18637 : scanCanonicalize (H12AffineFastState.compose env18637 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound18637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18638 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,2340,2219,1296,8461,1025,2341,1297,397,17,139,8328,17,8581,1297,1297,2184,1285,4294967296,257,4294967724,1296,512]

theorem envBound18638 : H12AffineFastState.Bounded env18638 := by
  intro p hp
  have h : env18638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18637_18638 : H12AffineEnvironment.transform 21 397 env18637 = env18638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env18637 == env18638) = true)

theorem identity18638 : scanCanonicalize (H12AffineFastState.compose env18638 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound18638 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18639 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2316,1297,2340,2219,1296,2049,1025,2341,1297,397,17,139,2436,17,2185,1297,1297,2184,1285,4294967296,257,4294967724,1296,512]

theorem envBound18639 : H12AffineFastState.Bounded env18639 := by
  intro p hp
  have h : env18639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18638_18639 : H12AffineEnvironment.transform 12 2316 env18638 = env18639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env18638 == env18639) = true)

theorem identity18639 : scanCanonicalize (H12AffineFastState.compose env18639 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound18639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18640 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2316,1297,2340,2219,1296,2049,1025,2341,1297,397,17,139,2436,17,2185,1297,1297,2184,1285,428,257,0,1296,512]

theorem envBound18640 : H12AffineFastState.Bounded env18640 := by
  intro p hp
  have h : env18640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18639_18640 : H12AffineEnvironment.transform 31 428 env18639 = env18640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env18639 == env18640) = true)

theorem identity18640 : scanCanonicalize (H12AffineFastState.compose env18640 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18640 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18641 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1296,2316,1297,2340,2082,1296,2049,1025,2341,1297,260,17,2,2317,17,2048,1297,1297,2049,1285,293,257,0,1296,512]

theorem envBound18641 : H12AffineFastState.Bounded env18641 := by
  intro p hp
  have h : env18641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18640_18641 : H12AffineEnvironment.transform 6 9 env18640 = env18641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18640 == env18641) = true)

def env18642 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,1296,2316,1297,2308,2050,1296,2049,1025,2309,1297,260,17,2,2317,17,2048,1297,1297,2049,1285,261,257,0,1296,512]

theorem envBound18642 : H12AffineFastState.Bounded env18642 := by
  intro p hp
  have h : env18642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18641_18642 : H12AffineEnvironment.transform 4 0 env18641 = env18642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18641 == env18642) = true)

theorem identity18642 : scanCanonicalize (H12AffineFastState.compose env18642 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound18642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18643 : List Nat := [2,4,8,16,0,16,9,256,260,1024,2048,1296,2316,1297,2308,2050,1296,2049,1025,2309,1297,260,17,2,2317,17,2048,1297,1297,2049,1285,261,257,0,1296,260]

theorem envBound18643 : H12AffineFastState.Bounded env18643 := by
  intro p hp
  have h : env18643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18642_18643 : H12AffineEnvironment.transform 8 260 env18642 = env18643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env18642 == env18643) = true)

def leafEnv18643 : List Nat := [2,4,8,16,0,16,9,256,260,1024,2048,1296,2316,1297,2308,2050,1296,2049,1025,2309,1297,260,17,2,1284,2317,1,17,2048,1297,1297,2049,1285,261,257,0,5,2050,1296,260,0,1296,1]

def active18643 : List Nat := [0,1,2,3,7,9,10]

def tree18643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18643 : H12WitnessSearch.Good tree18643 := H12GlobalWitnessIndex.good

theorem leafIdentity18643 : H12AffineFastState.composeSystem env18643 rootObs = leafEnv18643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18643 rootObs == leafEnv18643) = true)

theorem terminalChecked18643 : H12PackedTerminal.terminalCheckFast leafEnv18643 active18643 tree18643 = true := by decide +kernel

def env18644 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1296,2316,1297,2309,2051,1296,2049,1025,2308,1297,260,17,2,2317,17,2048,1297,1297,2049,1285,260,257,0,1296,512]

theorem envBound18644 : H12AffineFastState.Bounded env18644 := by
  intro p hp
  have h : env18644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18641_18644 : H12AffineEnvironment.transform 4 1 env18641 = env18644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18641 == env18644) = true)

theorem identity18644 : scanCanonicalize (H12AffineFastState.compose env18644 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18645 : List Nat := [2,4,8,16,1,16,9,256,1,1024,2048,1296,2316,1297,2309,2051,1296,2049,1025,2308,1297,260,17,2,2317,17,2048,1297,1297,2049,1285,260,257,0,1296,1]

theorem envBound18645 : H12AffineFastState.Bounded env18645 := by
  intro p hp
  have h : env18645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18644_18645 : H12AffineEnvironment.transform 8 1 env18644 = env18645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18644 == env18645) = true)

def leafEnv18645 : List Nat := [2,4,8,16,1,16,9,256,1,1024,2048,1296,2316,1297,2309,2051,1296,2049,1025,2308,1297,260,17,2,1284,2317,1,17,2048,1297,1297,2049,1285,260,257,0,5,2051,1296,1,0,1296,1]

def active18645 : List Nat := [0,1,2,3,7,9,10]

def tree18645 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18645 : H12WitnessSearch.Good tree18645 := H12GlobalWitnessIndex.good

theorem leafIdentity18645 : H12AffineFastState.composeSystem env18645 rootObs = leafEnv18645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18645 rootObs == leafEnv18645) = true)

theorem terminalChecked18645 : H12PackedTerminal.terminalCheckFast leafEnv18645 active18645 tree18645 = true := by decide +kernel

def env18646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1105,32769,1344,4194304,65,98564,8328,65,4456788,1344,1296,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18646 : H12AffineFastState.Bounded env18646 := by
  intro p hp
  have h : env18646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18631_18646 : H12AffineEnvironment.transform 11 1345 env18631 = env18646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18631 == env18646) = true)

theorem identity18646 : scanCanonicalize (H12AffineFastState.compose env18646 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound18646 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,552,1344,32768,65536,1345,262144,1105,32769,1344,4194304,65,98564,672,65,4456788,1344,1296,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18647 : H12AffineFastState.Bounded env18647 := by
  intro p hp
  have h : env18647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18646_18647 : H12AffineEnvironment.transform 12 552 env18646 = env18647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env18646 == env18647) = true)

theorem identity18647 : scanCanonicalize (H12AffineFastState.compose env18647 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1073775581) := by decide +kernel

theorem selectedBound18647 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,552,1344,32768,65536,1345,262144,1105,32769,1344,4194304,65,98564,672,65,4456788,1344,1296,1073741824,1285,1073775581,257,1078002291,1345,512]

theorem envBound18648 : H12AffineFastState.Bounded env18648 := by
  intro p hp
  have h : env18648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18647_18648 : H12AffineEnvironment.transform 31 1073775581 env18647 = env18648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073775581 env18647 == env18648) = true)

theorem identity18648 : scanCanonicalize (H12AffineFastState.compose env18648 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18648 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18649 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,552,1296,32768,65536,1297,262144,1025,32769,1296,4194304,17,98564,672,17,4456708,1296,1296,1073741824,1285,1073775501,257,1078002211,1297,512]

theorem envBound18649 : H12AffineFastState.Bounded env18649 := by
  intro p hp
  have h : env18649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18648_18649 : H12AffineEnvironment.transform 5 16 env18648 = env18649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18648 == env18649) = true)

theorem identity18649 : scanCanonicalize (H12AffineFastState.compose env18649 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4294659) := by decide +kernel

theorem selectedBound18649 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18650 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,552,1296,32768,65536,1297,262144,1025,32769,1296,4194304,17,98564,672,17,4456708,1296,1296,4294659,1285,4262798,257,35360,1297,512]

theorem envBound18650 : H12AffineFastState.Bounded env18650 := by
  intro p hp
  have h : env18650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18649_18650 : H12AffineEnvironment.transform 29 4294659 env18649 = env18650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294659 env18649 == env18650) = true)

theorem identity18650 : scanCanonicalize (H12AffineFastState.compose env18650 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 2823) := by decide +kernel

theorem selectedBound18650 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18651 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,552,1296,32768,2823,1297,262144,1025,32769,1296,4194304,17,35331,672,17,4456708,1296,1296,4227844,1285,4194441,257,35360,1297,512]

theorem envBound18651 : H12AffineFastState.Bounded env18651 := by
  intro p hp
  have h : env18651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18650_18651 : H12AffineEnvironment.transform 15 2823 env18650 = env18651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2823 env18650 == env18651) = true)

theorem identity18651 : scanCanonicalize (H12AffineFastState.compose env18651 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 264873) := by decide +kernel

theorem selectedBound18651 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env18652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,552,1296,32768,2823,1297,262144,1025,32769,1296,264873,17,35331,672,17,2989,1296,1296,297389,1285,264736,257,35360,1297,512]

theorem envBound18652 : H12AffineFastState.Bounded env18652 := by
  intro p hp
  have h : env18652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18651_18652 : H12AffineEnvironment.transform 21 264873 env18651 = env18652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264873 env18651 == env18652) = true)

def env18653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21987649,16385,676865,1073741824,16876544,4294967296,256,4315938986,131072,512]

theorem envBound18653 : H12AffineFastState.Bounded env18653 := by
  intro p hp
  have h : env18653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18399_18653 : H12AffineEnvironment.transform 22 147521 env18399 = env18653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env18399 == env18653) = true)

theorem identity18653 : scanCanonicalize (H12AffineFastState.compose env18653 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound18653 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env18654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21857280,16385,545088,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18654 : H12AffineFastState.Bounded env18654 := by
  intro p hp
  have h : env18654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18653_18654 : H12AffineEnvironment.transform 16 1345 env18653 = env18654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env18653 == env18654) = true)

theorem identity18654 : scanCanonicalize (H12AffineFastState.compose env18654 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound18654 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4097,4194304,17664,16777216,8328,17745,21331968,16385,21824,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18655 : H12AffineFastState.Bounded env18655 := by
  intro p hp
  have h : env18655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18654_18655 : H12AffineEnvironment.transform 18 1024 env18654 = env18655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18654 == env18655) = true)

def env18656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,1024,32769,1345,4194304,17664,16777216,8328,17745,21331968,16385,16384,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18656 : H12AffineFastState.Bounded env18656 := by
  intro p hp
  have h : env18656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18655_18656 : H12AffineEnvironment.transform 11 1344 env18655 = env18656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18655 == env18656) = true)

def env18657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,64,16777216,8328,17,21331968,1345,1344,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18657 : H12AffineFastState.Bounded env18657 := by
  intro p hp
  have h : env18657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18656_18657 : H12AffineEnvironment.transform 13 1344 env18656 = env18657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env18656 == env18657) = true)

theorem identity18657 : scanCanonicalize (H12AffineFastState.compose env18657 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound18657 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1345,1344,1073741824,1365,4294967296,256,4299260415,1345,512]

theorem envBound18658 : H12AffineFastState.Bounded env18658 := by
  intro p hp
  have h : env18658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18657_18658 : H12AffineEnvironment.transform 23 98645 env18657 = env18658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env18657 == env18658) = true)

theorem identity18658 : scanCanonicalize (H12AffineFastState.compose env18658 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 4196693) := by decide +kernel

theorem selectedBound18658 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env18659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1345,1344,4196693,1365,4294967296,256,4299260415,1345,512]

theorem envBound18659 : H12AffineFastState.Bounded env18659 := by
  intro p hp
  have h : env18659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18658_18659 : H12AffineEnvironment.transform 29 4196693 env18658 = env18659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196693 env18658 == env18659) = true)

theorem identity18659 : scanCanonicalize (H12AffineFastState.compose env18659 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(31+1) ^^^ 305653) := by decide +kernel

theorem selectedBound18659 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1345,1344,4196693,1365,305653,256,4532234,1345,512]

theorem envBound18660 : H12AffineFastState.Bounded env18660 := by
  intro p hp
  have h : env18660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18659_18660 : H12AffineEnvironment.transform 31 305653 env18659 = env18660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 305653 env18659 == env18660) = true)

theorem identity18660 : scanCanonicalize (H12AffineFastState.compose env18660 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound18660 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,43129,1024,32769,1345,4194304,64,98645,8328,17,4237612,1345,1344,4196693,1365,396,256,4292723,1345,512]

theorem envBound18661 : H12AffineFastState.Bounded env18661 := by
  intro p hp
  have h : env18661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18660_18661 : H12AffineEnvironment.transform 17 43129 env18660 = env18661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env18660 == env18661) = true)

theorem identity18661 : scanCanonicalize (H12AffineFastState.compose env18661 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound18661 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env18662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,8312,65536,1345,2049,1024,8313,1345,4194304,64,74029,8328,17,4196692,1345,1344,4196693,1365,396,256,4268043,1345,512]

theorem envBound18662 : H12AffineFastState.Bounded env18662 := by
  intro p hp
  have h : env18662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18661_18662 : H12AffineEnvironment.transform 14 8312 env18661 = env18662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env18661 == env18662) = true)

theorem identity18662 : scanCanonicalize (H12AffineFastState.compose env18662 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound18662 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,8312,65536,1345,2049,1024,8313,1345,261,64,74029,8328,17,2129,1345,1344,2128,1365,396,256,73998,1345,512]

theorem envBound18663 : H12AffineFastState.Bounded env18663 := by
  intro p hp
  have h : env18663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18662_18663 : H12AffineEnvironment.transform 21 261 env18662 = env18663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env18662 == env18663) = true)

theorem identity18663 : scanCanonicalize (H12AffineFastState.compose env18663 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18663 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env18664 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8233,65536,1296,2049,1024,8232,1296,261,17,74029,8328,17,2048,1296,1297,2049,1284,396,256,73998,1296,512]

theorem envBound18664 : H12AffineFastState.Bounded env18664 := by
  intro p hp
  have h : env18664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18663_18664 : H12AffineEnvironment.transform 5 17 env18663 = env18664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18663 == env18664) = true)

theorem identity18664 : scanCanonicalize (H12AffineFastState.compose env18664 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18664 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18665 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8233,65536,1296,2049,1024,8232,1296,261,17,74029,8328,17,2048,1296,1297,2049,1284,396,256,73998,1296,137]

theorem envBound18665 : H12AffineFastState.Bounded env18665 := by
  intro p hp
  have h : env18665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18664_18665 : H12AffineEnvironment.transform 8 137 env18664 = env18665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18664 == env18665) = true)

theorem identity18665 : scanCanonicalize (H12AffineFastState.compose env18665 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2479) := by decide +kernel

theorem selectedBound18665 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18666 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8233,2479,1296,2049,1024,8232,1296,261,17,10370,8328,17,2048,1296,1297,2049,1284,396,256,10401,1296,137]

theorem envBound18666 : H12AffineFastState.Bounded env18666 := by
  intro p hp
  have h : env18666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18665_18666 : H12AffineEnvironment.transform 15 2479 env18665 = env18666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2479 env18665 == env18666) = true)

theorem identity18666 : scanCanonicalize (H12AffineFastState.compose env18666 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound18666 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18667 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2317,1297,2340,2479,1296,2049,1024,2341,1296,261,17,399,2437,17,2048,1296,1297,2049,1284,396,256,428,1296,137]

theorem envBound18667 : H12AffineFastState.Bounded env18667 := by
  intro p hp
  have h : env18667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18666_18667 : H12AffineEnvironment.transform 12 2317 env18666 = env18667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env18666 == env18667) = true)

theorem identity18667 : scanCanonicalize (H12AffineFastState.compose env18667 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18667 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env18668 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,2056,1044,2081,2218,1045,2049,1024,2080,1045,0,17,138,2176,17,2048,1045,1044,2049,1025,137,5,169,1045,137]

theorem envBound18668 : H12AffineFastState.Bounded env18668 := by
  intro p hp
  have h : env18668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18667_18668 : H12AffineEnvironment.transform 7 5 env18667 = env18668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18667 == env18668) = true)

theorem identity18668 : scanCanonicalize (H12AffineFastState.compose env18668 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound18668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18669 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1212,1044,1204,1044,1181,1046,1045,1213,1024,1180,1045,0,17,138,1084,17,1212,1045,1044,1213,1025,137,5,169,1045,137]

theorem envBound18669 : H12AffineFastState.Bounded env18669 := by
  intro p hp
  have h : env18669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18668_18669 : H12AffineEnvironment.transform 10 1212 env18668 = env18669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env18668 == env18669) = true)

def env18670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,65,16777216,8328,16,21331968,1344,1345,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18670 : H12AffineFastState.Bounded env18670 := by
  intro p hp
  have h : env18670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18656_18670 : H12AffineEnvironment.transform 13 1345 env18656 = env18670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18656 == env18670) = true)

theorem identity18670 : scanCanonicalize (H12AffineFastState.compose env18670 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound18670 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,65,98564,8328,16,4456708,1344,1345,1073741824,1284,4294967296,256,4299260334,1345,512]

theorem envBound18671 : H12AffineFastState.Bounded env18671 := by
  intro p hp
  have h : env18671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18670_18671 : H12AffineEnvironment.transform 23 98564 env18670 = env18671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env18670 == env18671) = true)

theorem identity18671 : scanCanonicalize (H12AffineFastState.compose env18671 (packedSelected [17,21] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound18671 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,65,98564,8328,16,4456708,1344,1345,43049,1284,4294967296,256,4299260334,1345,512]

theorem envBound18672 : H12AffineFastState.Bounded env18672 := by
  intro p hp
  have h : env18672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18671_18672 : H12AffineEnvironment.transform 29 43049 env18671 = env18672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env18671 == env18672) = true)

def env18673 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,320,32769,1,4194304,65,98564,8328,16,4456708,0,1,43049,68,4294967296,256,4299260334,1,512]

theorem envBound18673 : H12AffineFastState.Bounded env18673 := by
  intro p hp
  have h : env18673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18672_18673 : H12AffineEnvironment.transform 9 320 env18672 = env18673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env18672 == env18673) = true)

theorem identity18673 : scanCanonicalize (H12AffineFastState.compose env18673 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound18673 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env18674 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,320,32769,1,8573,65,98564,8328,16,270457,0,1,43049,68,4294967296,256,4295074003,1,512]

theorem envBound18674 : H12AffineFastState.Bounded env18674 := by
  intro p hp
  have h : env18674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18673_18674 : H12AffineEnvironment.transform 21 8573 env18673 = env18674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env18673 == env18674) = true)

theorem identity18674 : scanCanonicalize (H12AffineFastState.compose env18674 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound18674 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env18675 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,43681,320,32769,1,8573,65,98564,8328,16,35544,0,1,43049,68,4294967296,256,4295074003,1,512]

theorem envBound18675 : H12AffineFastState.Bounded env18675 := by
  intro p hp
  have h : env18675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18674_18675 : H12AffineEnvironment.transform 17 43681 env18674 = env18675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env18674 == env18675) = true)

theorem identity18675 : scanCanonicalize (H12AffineFastState.compose env18675 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 107171) := by decide +kernel

theorem selectedBound18675 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env18676 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,43681,320,32769,1,8573,65,98564,8328,16,35544,0,1,43049,68,107171,256,624,1,512]

theorem envBound18676 : H12AffineFastState.Bounded env18676 := by
  intro p hp
  have h : env18676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18675_18676 : H12AffineEnvironment.transform 31 107171 env18675 = env18676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 107171 env18675 == env18676) = true)

def env18677 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,32768,65536,1,43681,272,32769,1,8493,17,98564,8328,16,35464,0,1,43049,20,107171,256,544,1,512]

theorem envBound18677 : H12AffineFastState.Bounded env18677 := by
  intro p hp
  have h : env18677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18676_18677 : H12AffineEnvironment.transform 5 16 env18676 = env18677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18676 == env18677) = true)

theorem identity18677 : scanCanonicalize (H12AffineFastState.compose env18677 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 680) := by decide +kernel

theorem selectedBound18677 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18678 : List Nat := [2,4,8,16,32,16,128,256,512,272,680,0,8192,1,32768,65536,1,40969,272,32769,1,8493,17,98564,8328,16,32800,0,1,41601,20,107171,256,544,1,512]

theorem envBound18678 : H12AffineFastState.Bounded env18678 := by
  intro p hp
  have h : env18678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18677_18678 : H12AffineEnvironment.transform 10 680 env18677 = env18678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 680 env18677 == env18678) = true)

theorem identity18678 : scanCanonicalize (H12AffineFastState.compose env18678 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18678 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18679 : List Nat := [2,4,8,16,32,16,128,256,512,272,680,0,8192,1,0,65536,1,8201,272,1,1,8493,17,65796,8328,16,32,0,1,8833,20,74403,256,544,1,512]

theorem envBound18679 : H12AffineFastState.Bounded env18679 := by
  intro p hp
  have h : env18679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18678_18679 : H12AffineEnvironment.transform 14 0 env18678 = env18679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18678 == env18679) = true)

theorem identity18679 : scanCanonicalize (H12AffineFastState.compose env18679 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18679 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18680 : List Nat := [2,4,8,16,32,16,128,256,137,272,33,0,8192,1,0,65536,1,8201,272,1,1,8493,17,65796,8328,16,32,0,1,8200,20,73770,256,169,1,137]

theorem envBound18680 : H12AffineFastState.Bounded env18680 := by
  intro p hp
  have h : env18680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18679_18680 : H12AffineEnvironment.transform 8 137 env18679 = env18680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18679 == env18680) = true)

def env18681 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,8192,1,0,65536,1,8201,20,1,1,8233,17,65536,8328,16,32,0,1,8200,20,73770,4,169,1,137]

theorem envBound18681 : H12AffineFastState.Bounded env18681 := by
  intro p hp
  have h : env18681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18680_18681 : H12AffineEnvironment.transform 7 4 env18680 = env18681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18680 == env18681) = true)

theorem identity18681 : scanCanonicalize (H12AffineFastState.compose env18681 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18681 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18682 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,8192,1,0,139,1,8201,20,1,1,8233,17,139,8328,16,32,0,1,8200,20,8353,4,169,1,137]

theorem envBound18682 : H12AffineFastState.Bounded env18682 := by
  intro p hp
  have h : env18682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18681_18682 : H12AffineEnvironment.transform 15 139 env18681 = env18682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18681 == env18682) = true)

theorem identity18682 : scanCanonicalize (H12AffineFastState.compose env18682 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound18682 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18683 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,9,1,0,139,1,0,20,1,1,32,17,139,129,16,32,0,1,1,20,168,4,169,1,137]

theorem envBound18683 : H12AffineFastState.Bounded env18683 := by
  intro p hp
  have h : env18683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18682_18683 : H12AffineEnvironment.transform 12 9 env18682 = env18683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env18682 == env18683) = true)

theorem identity18683 : scanCanonicalize (H12AffineFastState.compose env18683 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound18683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18684 : List Nat := [2,4,8,16,32,16,56,4,49,20,33,0,9,1,0,51,1,0,20,1,1,32,17,51,57,16,32,0,1,1,20,16,4,17,1,49]

theorem envBound18684 : H12AffineFastState.Bounded env18684 := by
  intro p hp
  have h : env18684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18683_18684 : H12AffineEnvironment.transform 6 56 env18683 = env18684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env18683 == env18684) = true)

def leafEnv18684 : List Nat := [2,4,8,16,32,16,56,4,49,20,33,0,9,1,0,51,1,0,20,1,1,32,17,51,21,57,1,16,32,0,1,1,20,16,4,17,5,2,1,49,0,1,1]

def active18684 : List Nat := [0,1,2,3,4]

def tree18684 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18684 : H12WitnessSearch.Good tree18684 := H12GlobalWitnessIndex.good

theorem leafIdentity18684 : H12AffineFastState.composeSystem env18684 rootObs = leafEnv18684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18684 rootObs == leafEnv18684) = true)

theorem terminalChecked18684 : H12PackedTerminal.terminalCheckFast leafEnv18684 active18684 tree18684 = true := by decide +kernel

def env18685 : List Nat := [2,4,8,16,32,16,128,5,137,21,33,0,8192,1,0,65536,1,8201,21,1,1,8232,17,65537,8328,16,32,0,1,8200,20,73770,5,169,1,137]

theorem envBound18685 : H12AffineFastState.Bounded env18685 := by
  intro p hp
  have h : env18685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18680_18685 : H12AffineEnvironment.transform 7 5 env18680 = env18685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18680 == env18685) = true)

theorem identity18685 : scanCanonicalize (H12AffineFastState.compose env18685 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18685 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18686 : List Nat := [2,4,8,16,32,16,128,5,137,21,33,0,40,1,0,65536,1,33,21,1,1,0,17,65537,160,16,32,0,1,32,20,65538,5,169,1,137]

theorem envBound18686 : H12AffineFastState.Bounded env18686 := by
  intro p hp
  have h : env18686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18685_18686 : H12AffineEnvironment.transform 12 40 env18685 = env18686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18685 == env18686) = true)

def env18687 : List Nat := [2,4,8,16,0,16,128,5,137,21,1,0,8,1,0,65536,1,1,21,1,1,0,17,65537,128,16,0,0,1,0,20,65538,5,137,1,137]

theorem envBound18687 : H12AffineFastState.Bounded env18687 := by
  intro p hp
  have h : env18687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18686_18687 : H12AffineEnvironment.transform 4 0 env18686 = env18687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18686 == env18687) = true)

theorem identity18687 : scanCanonicalize (H12AffineFastState.compose env18687 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound18687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18688 : List Nat := [2,4,8,16,0,16,128,5,137,21,1,0,8,1,0,18,1,1,21,1,1,0,17,19,128,16,0,0,1,0,20,16,5,137,1,137]

theorem envBound18688 : H12AffineFastState.Bounded env18688 := by
  intro p hp
  have h : env18688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18687_18688 : H12AffineEnvironment.transform 15 18 env18687 = env18688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env18687 == env18688) = true)

theorem identity18688 : scanCanonicalize (H12AffineFastState.compose env18688 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18688 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18689 : List Nat := [2,4,8,16,0,16,24,5,17,21,1,0,8,1,0,18,1,1,21,1,1,0,17,19,24,16,0,0,1,0,20,16,5,17,1,17]

theorem envBound18689 : H12AffineFastState.Bounded env18689 := by
  intro p hp
  have h : env18689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18688_18689 : H12AffineEnvironment.transform 6 24 env18688 = env18689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18688 == env18689) = true)

def leafEnv18689 : List Nat := [2,4,8,16,0,16,24,5,17,21,1,0,8,1,0,18,1,1,21,1,1,0,17,19,21,24,1,16,0,0,1,0,20,16,5,17,5,3,1,17,0,1,1]

def active18689 : List Nat := [0,1,2,3]

def tree18689 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18689 : H12WitnessSearch.Good tree18689 := H12GlobalWitnessIndex.good

theorem leafIdentity18689 : H12AffineFastState.composeSystem env18689 rootObs = leafEnv18689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18689 rootObs == leafEnv18689) = true)

theorem terminalChecked18689 : H12PackedTerminal.terminalCheckFast leafEnv18689 active18689 tree18689 = true := by decide +kernel

def env18690 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,0,9,1,0,65536,1,0,21,1,1,0,17,65537,129,16,1,0,1,1,20,65538,5,136,1,137]

theorem envBound18690 : H12AffineFastState.Bounded env18690 := by
  intro p hp
  have h : env18690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18686_18690 : H12AffineEnvironment.transform 4 1 env18686 = env18690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18686 == env18690) = true)

theorem identity18690 : scanCanonicalize (H12AffineFastState.compose env18690 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound18690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18691 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,0,9,1,0,154,1,0,21,1,1,0,17,155,129,16,1,0,1,1,20,152,5,136,1,137]

theorem envBound18691 : H12AffineFastState.Bounded env18691 := by
  intro p hp
  have h : env18691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18690_18691 : H12AffineEnvironment.transform 15 154 env18690 = env18691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env18690 == env18691) = true)

def env18692 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,32768,65536,1,43681,273,32769,1,8492,16,98564,8328,16,35465,0,1,43049,21,107171,256,545,1,512]

theorem envBound18692 : H12AffineFastState.Bounded env18692 := by
  intro p hp
  have h : env18692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18676_18692 : H12AffineEnvironment.transform 5 17 env18676 = env18692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18676 == env18692) = true)

theorem identity18692 : scanCanonicalize (H12AffineFastState.compose env18692 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2958) := by decide +kernel

theorem selectedBound18692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18693 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2958,1,32768,65536,1,33071,273,32769,1,2722,16,98564,2822,16,35465,0,1,33703,21,100653,256,545,1,512]

theorem envBound18693 : H12AffineFastState.Bounded env18693 := by
  intro p hp
  have h : env18693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18692_18693 : H12AffineEnvironment.transform 12 2958 env18692 = env18693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2958 env18692 == env18693) = true)

theorem identity18693 : scanCanonicalize (H12AffineFastState.compose env18693 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound18693 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18694 : List Nat := [2,4,8,16,32,17,128,256,512,273,643,0,269,1,32768,65536,1,33071,273,32769,1,33,16,98564,389,16,32778,0,1,33703,21,99246,256,545,1,512]

theorem envBound18694 : H12AffineFastState.Bounded env18694 := by
  intro p hp
  have h : env18694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18693_18694 : H12AffineEnvironment.transform 10 643 env18693 = env18694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env18693 == env18694) = true)

theorem identity18694 : scanCanonicalize (H12AffineFastState.compose env18694 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound18694 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18695 : List Nat := [2,4,8,16,32,17,128,256,512,273,643,0,269,1,32768,398,1,33071,273,32769,1,33,16,32906,389,16,32778,0,1,33703,21,33312,256,545,1,512]

theorem envBound18695 : H12AffineFastState.Bounded env18695 := by
  intro p hp
  have h : env18695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18694_18695 : H12AffineEnvironment.transform 15 398 env18694 = env18695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env18694 == env18695) = true)

theorem identity18695 : scanCanonicalize (H12AffineFastState.compose env18695 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound18695 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18696 : List Nat := [2,4,8,16,32,17,128,256,512,273,643,0,269,1,648,398,1,935,273,649,1,33,16,514,389,16,642,0,1,303,21,168,256,545,1,512]

theorem envBound18696 : H12AffineFastState.Bounded env18696 := by
  intro p hp
  have h : env18696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18695_18696 : H12AffineEnvironment.transform 14 648 env18695 = env18696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env18695 == env18696) = true)

def env18697 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,262144,321,32769,0,4194304,65,98564,8328,16,4456708,1,0,43049,69,4294967296,256,4299260334,0,512]

theorem envBound18697 : H12AffineFastState.Bounded env18697 := by
  intro p hp
  have h : env18697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18672_18697 : H12AffineEnvironment.transform 9 321 env18672 = env18697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env18672 == env18697) = true)

theorem identity18697 : scanCanonicalize (H12AffineFastState.compose env18697 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 329946) := by decide +kernel

theorem selectedBound18697 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env18698 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,262144,321,32769,0,329946,65,98564,8328,16,68062,1,0,43049,69,4294967296,256,4295264628,0,512]

theorem envBound18698 : H12AffineFastState.Bounded env18698 := by
  intro p hp
  have h : env18698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18697_18698 : H12AffineEnvironment.transform 21 329946 env18697 = env18698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329946 env18697 == env18698) = true)

theorem identity18698 : scanCanonicalize (H12AffineFastState.compose env18698 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 854) := by decide +kernel

theorem selectedBound18698 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env18699 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,854,0,262144,321,32769,0,265100,65,33362,8328,16,2696,1,0,43049,69,4294967296,256,4295264628,0,512]

theorem envBound18699 : H12AffineFastState.Bounded env18699 := by
  intro p hp
  have h : env18699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18698_18699 : H12AffineEnvironment.transform 15 854 env18698 = env18699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 854 env18698 == env18699) = true)

theorem identity18699 : scanCanonicalize (H12AffineFastState.compose env18699 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 297357) := by decide +kernel

theorem selectedBound18699 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env18700 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,854,0,262144,321,32769,0,265100,65,33362,8328,16,2696,1,0,43049,69,297357,256,249,0,512]

theorem envBound18700 : H12AffineFastState.Bounded env18700 := by
  intro p hp
  have h : env18700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18699_18700 : H12AffineEnvironment.transform 31 297357 env18699 = env18700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 297357 env18699 == env18700) = true)

def env18701 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,774,0,262144,273,32769,0,265100,17,33282,8328,16,2696,1,0,43049,21,297357,256,169,0,512]

theorem envBound18701 : H12AffineFastState.Bounded env18701 := by
  intro p hp
  have h : env18701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18700_18701 : H12AffineEnvironment.transform 5 16 env18700 = env18701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18700 == env18701) = true)

theorem identity18701 : scanCanonicalize (H12AffineFastState.compose env18701 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 8201) := by decide +kernel

theorem selectedBound18701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18702 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,774,0,8201,273,32769,0,11141,17,33282,8328,16,2696,1,0,43049,21,43396,256,169,0,512]

theorem envBound18702 : H12AffineFastState.Bounded env18702 := by
  intro p hp
  have h : env18702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18701_18702 : H12AffineEnvironment.transform 17 8201 env18701 = env18702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8201 env18701 == env18702) = true)

theorem identity18702 : scanCanonicalize (H12AffineFastState.compose env18702 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound18702 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18703 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,2081,774,0,8201,273,2080,0,11141,17,2595,8328,16,2696,1,0,8200,21,8613,256,169,0,512]

theorem envBound18703 : H12AffineFastState.Bounded env18703 := by
  intro p hp
  have h : env18703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18702_18703 : H12AffineEnvironment.transform 14 2081 env18702 = env18703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env18702 == env18703) = true)

theorem identity18703 : scanCanonicalize (H12AffineFastState.compose env18703 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18703 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18704 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,0,2081,399,0,8201,273,2080,0,10508,17,2218,8328,16,2049,1,0,8200,21,8613,256,169,0,137]

theorem envBound18704 : H12AffineFastState.Bounded env18704 := by
  intro p hp
  have h : env18704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18703_18704 : H12AffineEnvironment.transform 8 137 env18703 = env18704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18703 == env18704) = true)

def env18705 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,40,0,2081,399,0,33,273,2080,0,2340,17,2218,160,16,2049,1,0,32,21,397,256,169,0,137]

theorem envBound18705 : H12AffineFastState.Bounded env18705 := by
  intro p hp
  have h : env18705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18704_18705 : H12AffineEnvironment.transform 12 40 env18704 = env18705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18704 == env18705) = true)

theorem identity18705 : scanCanonicalize (H12AffineFastState.compose env18705 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound18705 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18706 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,40,0,0,399,0,33,273,1,0,261,17,139,160,16,32,1,0,32,21,397,256,169,0,137]

theorem envBound18706 : H12AffineFastState.Bounded env18706 := by
  intro p hp
  have h : env18706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18705_18706 : H12AffineEnvironment.transform 10 33 env18705 = env18706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env18705 == env18706) = true)

theorem identity18706 : scanCanonicalize (H12AffineFastState.compose env18706 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18706 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18707 : List Nat := [2,4,8,16,32,16,128,36,137,53,33,1,40,0,0,171,0,33,53,1,0,33,17,139,160,16,32,1,0,32,21,169,36,169,0,137]

theorem envBound18707 : H12AffineFastState.Bounded env18707 := by
  intro p hp
  have h : env18707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18706_18707 : H12AffineEnvironment.transform 7 36 env18706 = env18707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18706 == env18707) = true)

theorem identity18707 : scanCanonicalize (H12AffineFastState.compose env18707 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18708 : List Nat := [2,4,8,16,16,16,128,20,137,5,17,1,24,0,0,155,0,17,5,1,0,17,17,139,144,16,16,1,0,16,21,153,20,153,0,137]

theorem envBound18708 : H12AffineFastState.Bounded env18708 := by
  intro p hp
  have h : env18708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18707_18708 : H12AffineEnvironment.transform 4 16 env18707 = env18708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18707 == env18708) = true)

def leafEnv18708 : List Nat := [2,4,8,16,16,16,128,20,137,5,17,1,24,0,0,155,0,17,5,1,0,17,17,139,20,144,1,16,16,1,0,16,21,153,20,153,5,18,0,137,0,0,1]

def active18708 : List Nat := [0,1,2,3,6]

def tree18708 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18708 : H12WitnessSearch.Good tree18708 := H12GlobalWitnessIndex.good

theorem leafIdentity18708 : H12AffineFastState.composeSystem env18708 rootObs = leafEnv18708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18708 rootObs == leafEnv18708) = true)

theorem terminalChecked18708 : H12PackedTerminal.terminalCheckFast leafEnv18708 active18708 tree18708 = true := by decide +kernel

def env18709 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,41,0,2081,399,0,32,273,2080,0,2341,17,2218,161,16,2049,1,0,33,21,396,256,169,0,137]

theorem envBound18709 : H12AffineFastState.Bounded env18709 := by
  intro p hp
  have h : env18709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18704_18709 : H12AffineEnvironment.transform 12 41 env18704 = env18709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18704 == env18709) = true)

theorem identity18709 : scanCanonicalize (H12AffineFastState.compose env18709 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound18709 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18710 : List Nat := [2,4,8,16,32,16,128,256,137,273,293,1,41,0,260,399,0,32,273,261,0,0,17,399,161,16,292,1,0,33,21,396,256,169,0,137]

theorem envBound18710 : H12AffineFastState.Bounded env18710 := by
  intro p hp
  have h : env18710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18709_18710 : H12AffineEnvironment.transform 10 293 env18709 = env18710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env18709 == env18710) = true)

def env18711 : List Nat := [2,4,8,16,0,16,128,256,137,273,261,1,9,0,260,399,0,0,273,261,0,0,17,399,129,16,260,1,0,1,21,396,256,137,0,137]

theorem envBound18711 : H12AffineFastState.Bounded env18711 := by
  intro p hp
  have h : env18711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18710_18711 : H12AffineEnvironment.transform 4 0 env18710 = env18711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18710 == env18711) = true)

theorem identity18711 : scanCanonicalize (H12AffineFastState.compose env18711 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18712 : List Nat := [2,4,8,16,0,16,25,256,16,273,261,1,9,0,260,278,0,0,273,261,0,0,17,278,24,16,260,1,0,1,21,277,256,16,0,16]

theorem envBound18712 : H12AffineFastState.Bounded env18712 := by
  intro p hp
  have h : env18712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18711_18712 : H12AffineEnvironment.transform 6 25 env18711 = env18712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18711 == env18712) = true)

def env18713 : List Nat := [2,4,8,16,1,16,128,256,137,273,260,1,8,0,260,399,0,1,273,261,0,0,17,399,128,16,261,1,0,0,21,396,256,136,0,137]

theorem envBound18713 : H12AffineFastState.Bounded env18713 := by
  intro p hp
  have h : env18713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18710_18713 : H12AffineEnvironment.transform 4 1 env18710 = env18713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18710 == env18713) = true)

theorem identity18713 : scanCanonicalize (H12AffineFastState.compose env18713 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18714 : List Nat := [2,4,8,16,1,16,128,20,137,5,16,1,8,0,16,155,0,1,5,17,0,0,17,155,128,16,17,1,0,0,21,152,20,136,0,137]

theorem envBound18714 : H12AffineFastState.Bounded env18714 := by
  intro p hp
  have h : env18714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18713_18714 : H12AffineEnvironment.transform 7 20 env18713 = env18714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18713 == env18714) = true)

theorem identity18714 : scanCanonicalize (H12AffineFastState.compose env18714 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18715 : List Nat := [2,4,8,0,1,0,128,4,137,5,0,1,8,0,0,139,0,1,5,1,0,0,1,139,128,0,1,1,0,0,5,136,4,136,0,137]

theorem envBound18715 : H12AffineFastState.Bounded env18715 := by
  intro p hp
  have h : env18715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18714_18715 : H12AffineEnvironment.transform 3 0 env18714 = env18715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18714 == env18715) = true)

def leafEnv18715 : List Nat := [2,4,8,0,1,0,128,4,137,5,0,1,8,0,0,139,0,1,5,1,0,0,1,139,4,128,1,0,1,1,0,0,5,136,4,136,5,2,0,137,0,0,1]

def active18715 : List Nat := [0,1,2,6]

def tree18715 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18715 : H12WitnessSearch.Good tree18715 := H12GlobalWitnessIndex.good

theorem leafIdentity18715 : H12AffineFastState.composeSystem env18715 rootObs = leafEnv18715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18715 rootObs == leafEnv18715) = true)

theorem terminalChecked18715 : H12PackedTerminal.terminalCheckFast leafEnv18715 active18715 tree18715 = true := by decide +kernel

def env18716 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,32768,775,0,262144,272,32769,0,265100,16,33283,8328,16,2696,1,0,43049,20,297357,256,168,0,512]

theorem envBound18716 : H12AffineFastState.Bounded env18716 := by
  intro p hp
  have h : env18716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18700_18716 : H12AffineEnvironment.transform 5 17 env18700 = env18716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18700 == env18716) = true)

theorem identity18716 : scanCanonicalize (H12AffineFastState.compose env18716 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2958) := by decide +kernel

theorem selectedBound18716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18717 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2958,0,32768,775,0,262144,272,32769,0,265100,16,33283,2822,16,2696,1,0,33703,20,297357,256,168,0,512]

theorem envBound18717 : H12AffineFastState.Bounded env18717 := by
  intro p hp
  have h : env18717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18716_18717 : H12AffineEnvironment.transform 12 2958 env18716 = env18717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2958 env18716 == env18717) = true)

theorem identity18717 : scanCanonicalize (H12AffineFastState.compose env18717 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2059) := by decide +kernel

theorem selectedBound18717 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18718 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2958,0,2059,775,0,262144,272,2058,0,265100,16,2568,2822,16,2696,1,0,2988,20,262534,256,168,0,512]

theorem envBound18718 : H12AffineFastState.Bounded env18718 := by
  intro p hp
  have h : env18718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18717_18718 : H12AffineEnvironment.transform 14 2059 env18717 = env18718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2059 env18717 == env18718) = true)

theorem identity18718 : scanCanonicalize (H12AffineFastState.compose env18718 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound18718 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18719 : List Nat := [2,4,8,16,32,17,128,256,512,272,643,1,269,0,648,775,0,262144,272,649,0,262415,16,139,389,16,11,1,0,303,20,262534,256,168,0,512]

theorem envBound18719 : H12AffineFastState.Bounded env18719 := by
  intro p hp
  have h : env18719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18718_18719 : H12AffineEnvironment.transform 10 643 env18718 = env18719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env18718 == env18719) = true)

theorem identity18719 : scanCanonicalize (H12AffineFastState.compose env18719 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 935) := by decide +kernel

theorem selectedBound18719 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18720 : List Nat := [2,4,8,16,32,17,128,256,512,272,643,1,269,0,648,775,0,935,272,649,0,680,16,139,389,16,11,1,0,303,20,545,256,168,0,512]

theorem envBound18720 : H12AffineFastState.Bounded env18720 := by
  intro p hp
  have h : env18720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18719_18720 : H12AffineEnvironment.transform 17 935 env18719 = env18720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 935 env18719 == env18720) = true)

theorem identity18720 : scanCanonicalize (H12AffineFastState.compose env18720 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18721 : List Nat := [2,4,8,16,32,17,128,256,137,272,10,1,269,0,1,398,0,302,272,0,0,33,16,139,389,16,11,1,0,303,20,168,256,168,0,137]

theorem envBound18721 : H12AffineFastState.Bounded env18721 := by
  intro p hp
  have h : env18721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18720_18721 : H12AffineEnvironment.transform 8 137 env18720 = env18721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18720 == env18721) = true)

theorem identity18721 : scanCanonicalize (H12AffineFastState.compose env18721 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18721 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18722 : List Nat := [2,4,8,16,32,17,128,21,137,5,10,1,24,0,1,155,0,59,5,0,0,33,16,139,144,16,11,1,0,58,20,168,21,168,0,137]

theorem envBound18722 : H12AffineFastState.Bounded env18722 := by
  intro p hp
  have h : env18722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18721_18722 : H12AffineEnvironment.transform 7 21 env18721 = env18722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18721 == env18722) = true)

def env18723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,1024,32769,1344,4194304,17664,16777216,8328,17745,21331968,16385,16385,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18723 : H12AffineFastState.Bounded env18723 := by
  intro p hp
  have h : env18723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18655_18723 : H12AffineEnvironment.transform 11 1345 env18655 = env18723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18655 == env18723) = true)

def env18724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1024,32769,1344,4194304,64,16777216,8328,17,21331968,1345,1345,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18724 : H12AffineFastState.Bounded env18724 := by
  intro p hp
  have h : env18724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18723_18724 : H12AffineEnvironment.transform 13 1344 env18723 = env18724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env18723 == env18724) = true)

theorem identity18724 : scanCanonicalize (H12AffineFastState.compose env18724 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18724 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18725 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound18725 : H12AffineFastState.Bounded env18725 := by
  intro p hp
  have h : env18725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18724_18725 : H12AffineEnvironment.transform 5 16 env18724 = env18725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18724 == env18725) = true)

theorem identity18725 : scanCanonicalize (H12AffineFastState.compose env18725 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound18725 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18726 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound18726 : H12AffineFastState.Bounded env18726 := by
  intro p hp
  have h : env18726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18725_18726 : H12AffineEnvironment.transform 31 4194440 env18725 = env18726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env18725 == env18726) = true)

theorem identity18726 : scanCanonicalize (H12AffineFastState.compose env18726 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 21071872) := by decide +kernel

theorem selectedBound18726 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env18727 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1297,1297,21071872,16876544,4194440,256,16777250,1297,512]

theorem envBound18727 : H12AffineFastState.Bounded env18727 := by
  intro p hp
  have h : env18727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18726_18727 : H12AffineEnvironment.transform 29 21071872 env18726 = env18727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env18726 == env18727) = true)

theorem identity18727 : scanCanonicalize (H12AffineFastState.compose env18727 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 338220) := by decide +kernel

theorem selectedBound18727 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18728 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,338220,8328,17,4237612,1297,1297,4497708,306476,4194440,256,338190,1297,512]

theorem envBound18728 : H12AffineFastState.Bounded env18728 := by
  intro p hp
  have h : env18728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18727_18728 : H12AffineEnvironment.transform 23 338220 env18727 = env18728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338220 env18727 == env18728) = true)

theorem identity18728 : scanCanonicalize (H12AffineFastState.compose env18728 (packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound18728 : packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env18729 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,362634,16,338220,8328,17,336294,1297,1297,76198,306476,362498,256,338190,1297,512]

theorem envBound18729 : H12AffineFastState.Bounded env18729 := by
  intro p hp
  have h : env18729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18728_18729 : H12AffineEnvironment.transform 21 362634 env18728 = env18729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env18728 == env18729) = true)

theorem identity18729 : scanCanonicalize (H12AffineFastState.compose env18729 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound18729 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env18730 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,2049,1024,32769,1296,98443,16,74029,8328,17,76199,1297,1297,76198,42285,98307,256,73999,1297,512]

theorem envBound18730 : H12AffineFastState.Bounded env18730 := by
  intro p hp
  have h : env18730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18729_18730 : H12AffineEnvironment.transform 17 2049 env18729 = env18730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env18729 == env18730) = true)

theorem identity18730 : scanCanonicalize (H12AffineFastState.compose env18730 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound18730 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18731 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,2049,1024,32769,1296,261,16,41123,8328,17,43049,1297,1297,43048,42285,397,256,41089,1297,512]

theorem envBound18731 : H12AffineFastState.Bounded env18731 := by
  intro p hp
  have h : env18731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18730_18731 : H12AffineEnvironment.transform 15 33166 env18730 = env18731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env18730 == env18731) = true)

theorem identity18731 : scanCanonicalize (H12AffineFastState.compose env18731 (packedSelected [1,2,3,6,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound18731 : packedSelected [1,2,3,6,11,13] rootPS < 2^1333 := by decide +kernel

def env18732 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,32768,33166,1297,2049,1024,32769,1296,261,16,35247,2436,17,33061,1297,1297,33060,35873,397,256,35213,1297,512]

theorem envBound18732 : H12AffineFastState.Bounded env18732 := by
  intro p hp
  have h : env18732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18731_18732 : H12AffineEnvironment.transform 12 2316 env18731 = env18732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env18731 == env18732) = true)

theorem identity18732 : scanCanonicalize (H12AffineFastState.compose env18732 (packedSelected [11,23] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound18732 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env18733 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2341,2219,1297,2049,1024,2340,1296,261,16,138,2436,17,2048,1297,1297,2049,1284,397,256,168,1297,512]

theorem envBound18733 : H12AffineFastState.Bounded env18733 := by
  intro p hp
  have h : env18733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18732_18733 : H12AffineEnvironment.transform 14 2341 env18732 = env18733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env18732 == env18733) = true)

theorem identity18733 : scanCanonicalize (H12AffineFastState.compose env18733 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound18733 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18734 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1557,1297,1817,1296,1840,1726,1297,1556,1024,1841,1296,261,16,138,1937,17,1557,1297,1297,1556,1284,397,256,168,1297,512]

theorem envBound18734 : H12AffineFastState.Bounded env18734 := by
  intro p hp
  have h : env18734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18733_18734 : H12AffineEnvironment.transform 10 1557 env18733 = env18734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env18733 == env18734) = true)

theorem identity18734 : scanCanonicalize (H12AffineFastState.compose env18734 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18734 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18735 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1180,1297,1424,1296,1465,1079,1297,1181,1024,1464,1296,261,16,138,1304,17,1180,1297,1297,1181,1284,397,256,168,1297,137]

theorem envBound18735 : H12AffineFastState.Bounded env18735 := by
  intro p hp
  have h : env18735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18734_18735 : H12AffineEnvironment.transform 8 137 env18734 = env18735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18734 == env18735) = true)

def env18736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,65,16777216,8328,16,21331968,1344,1344,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound18736 : H12AffineFastState.Bounded env18736 := by
  intro p hp
  have h : env18736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18723_18736 : H12AffineEnvironment.transform 13 1345 env18723 = env18736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18723 == env18736) = true)

def env18737 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound18737 : H12AffineFastState.Bounded env18737 := by
  intro p hp
  have h : env18737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18736_18737 : H12AffineEnvironment.transform 5 16 env18736 = env18737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18736 == env18737) = true)

theorem identity18737 : scanCanonicalize (H12AffineFastState.compose env18737 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound18737 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18738 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8328,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound18738 : H12AffineFastState.Bounded env18738 := by
  intro p hp
  have h : env18738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18737_18738 : H12AffineEnvironment.transform 31 1073842178 env18737 = env18738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env18737 == env18738) = true)

def env18739 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,8,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound18739 : H12AffineFastState.Bounded env18739 := by
  intro p hp
  have h : env18739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18738_18739 : H12AffineEnvironment.transform 12 128 env18738 = env18739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18738 == env18739) = true)

theorem identity18739 : scanCanonicalize (H12AffineFastState.compose env18739 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 327809) := by decide +kernel

theorem selectedBound18739 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18740 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,327809,17,16777216,8,16,16810113,1296,1296,1073741824,16876544,1073842178,256,1090816041,1297,512]

theorem envBound18740 : H12AffineFastState.Bounded env18740 := by
  intro p hp
  have h : env18740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18739_18740 : H12AffineEnvironment.transform 21 327809 env18739 = env18740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 327809 env18739 == env18740) = true)

def env18741 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,327809,17,16777216,8,16,16810113,1296,1296,17074304,16876544,17105026,256,169,1297,512]

theorem envBound18741 : H12AffineFastState.Bounded env18741 := by
  intro p hp
  have h : env18741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18740_18741 : H12AffineEnvironment.transform 29 17074304 env18740 = env18741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 17074304 env18740 == env18741) = true)

theorem identity18741 : scanCanonicalize (H12AffineFastState.compose env18741 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 298291) := by decide +kernel

theorem selectedBound18741 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18742 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,327809,17,298291,8,16,265650,1296,1296,1459,330035,101809,256,169,1297,512]

theorem envBound18742 : H12AffineFastState.Bounded env18742 := by
  intro p hp
  have h : env18742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18741_18742 : H12AffineEnvironment.transform 23 298291 env18741 = env18742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 298291 env18741 == env18742) = true)

theorem identity18742 : scanCanonicalize (H12AffineFastState.compose env18742 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 98604) := by decide +kernel

theorem selectedBound18742 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18743 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,98604,1024,32769,1296,33197,17,68639,8,16,101534,1296,1296,1459,34847,101809,256,169,1297,512]

theorem envBound18743 : H12AffineFastState.Bounded env18743 := by
  intro p hp
  have h : env18743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18742_18743 : H12AffineEnvironment.transform 17 98604 env18742 = env18743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 98604 env18742 == env18743) = true)

theorem identity18743 : scanCanonicalize (H12AffineFastState.compose env18743 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 3354) := by decide +kernel

theorem selectedBound18743 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18744 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,3354,65536,1297,68662,1024,3355,1296,3255,17,68639,8,16,65924,1296,1296,1459,1285,65707,256,169,1297,512]

theorem envBound18744 : H12AffineFastState.Bounded env18744 := by
  intro p hp
  have h : env18744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18743_18744 : H12AffineEnvironment.transform 14 3354 env18743 = env18744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3354 env18743 == env18744) = true)

theorem identity18744 : scanCanonicalize (H12AffineFastState.compose env18744 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1971) := by decide +kernel

theorem selectedBound18744 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18745 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1971,1297,128,1297,681,65536,1297,66437,1024,680,1296,772,17,66476,8,16,65924,1296,1296,1459,1285,65707,256,169,1297,512]

theorem envBound18745 : H12AffineFastState.Bounded env18745 := by
  intro p hp
  have h : env18745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18744_18745 : H12AffineEnvironment.transform 10 1971 env18744 = env18745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1971 env18744 == env18745) = true)

theorem identity18745 : scanCanonicalize (H12AffineFastState.compose env18745 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18745 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18746 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1458,1297,128,1297,168,65536,1297,65924,1024,169,1296,261,17,65965,8,16,65924,1296,1296,1459,1285,65707,256,169,1297,1]

theorem envBound18746 : H12AffineFastState.Bounded env18746 := by
  intro p hp
  have h : env18746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18745_18746 : H12AffineEnvironment.transform 8 1 env18745 = env18746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18745 == env18746) = true)

theorem identity18746 : scanCanonicalize (H12AffineFastState.compose env18746 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 389) := by decide +kernel

theorem selectedBound18746 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18747 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1458,1297,128,1297,168,389,1297,1,1024,169,1296,261,17,40,8,16,1,1296,1296,1459,1285,302,256,169,1297,1]

theorem envBound18747 : H12AffineFastState.Bounded env18747 := by
  intro p hp
  have h : env18747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18746_18747 : H12AffineEnvironment.transform 15 389 env18746 = env18747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 389 env18746 == env18747) = true)

theorem identity18747 : scanCanonicalize (H12AffineFastState.compose env18747 (packedSelected [4,6] rootPS)) = affineNative (2^(9+1) ^^^ 182) := by decide +kernel

theorem selectedBound18747 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18748 : List Nat := [2,4,8,16,32,16,128,256,1,182,260,423,128,423,168,389,423,1,182,169,422,261,17,40,8,16,1,422,422,261,435,302,256,169,423,1]

theorem envBound18748 : H12AffineFastState.Bounded env18748 := by
  intro p hp
  have h : env18748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18747_18748 : H12AffineEnvironment.transform 9 182 env18747 = env18748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 182 env18747 == env18748) = true)

theorem identity18748 : scanCanonicalize (H12AffineFastState.compose env18748 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound18748 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18749 : List Nat := [2,4,8,16,32,16,35,256,1,21,260,260,35,260,11,294,260,1,21,10,261,261,17,40,8,16,1,261,261,261,272,302,256,10,260,1]

theorem envBound18749 : H12AffineFastState.Bounded env18749 := by
  intro p hp
  have h : env18749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18748_18749 : H12AffineEnvironment.transform 6 35 env18748 = env18749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env18748 == env18749) = true)

theorem identity18749 : scanCanonicalize (H12AffineFastState.compose env18749 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18749 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18750 : List Nat := [2,4,8,16,11,16,8,256,1,21,260,260,8,260,11,269,260,1,21,10,261,261,17,3,8,16,1,261,261,261,272,261,256,10,260,1]

theorem envBound18750 : H12AffineFastState.Bounded env18750 := by
  intro p hp
  have h : env18750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18749_18750 : H12AffineEnvironment.transform 4 11 env18749 = env18750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18749 == env18750) = true)

theorem identity18750 : scanCanonicalize (H12AffineFastState.compose env18750 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18751 : List Nat := [2,4,8,16,11,16,8,21,1,21,17,17,8,17,11,24,17,1,21,10,16,16,17,3,8,16,1,16,16,16,5,16,21,10,17,1]

theorem envBound18751 : H12AffineFastState.Bounded env18751 := by
  intro p hp
  have h : env18751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18750_18751 : H12AffineEnvironment.transform 7 21 env18750 = env18751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18750 == env18751) = true)

theorem identity18751 : scanCanonicalize (H12AffineFastState.compose env18751 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18751 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18752 : List Nat := [2,4,8,0,11,0,8,5,1,5,1,1,8,1,11,8,1,1,5,10,0,0,1,3,8,0,1,0,0,0,5,0,5,10,1,1]

theorem envBound18752 : H12AffineFastState.Bounded env18752 := by
  intro p hp
  have h : env18752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18751_18752 : H12AffineEnvironment.transform 3 0 env18751 = env18752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18751 == env18752) = true)

theorem identity18752 : scanCanonicalize (H12AffineFastState.compose env18752 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18752 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18753 : List Nat := [2,4,2,0,1,0,2,5,1,5,1,1,2,1,1,2,1,1,5,0,0,0,1,3,2,0,1,0,0,0,5,0,5,0,1,1]

theorem envBound18753 : H12AffineFastState.Bounded env18753 := by
  intro p hp
  have h : env18753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18752_18753 : H12AffineEnvironment.transform 2 2 env18752 = env18753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18752 == env18753) = true)

def env18754 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,327809,17,16777216,8,16,16810113,1296,1296,17074305,16876544,17105027,256,168,1297,512]

theorem envBound18754 : H12AffineFastState.Bounded env18754 := by
  intro p hp
  have h : env18754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18740_18754 : H12AffineEnvironment.transform 29 17074305 env18740 = env18754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 17074305 env18740 == env18754) = true)

theorem identity18754 : scanCanonicalize (H12AffineFastState.compose env18754 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 296995) := by decide +kernel

theorem selectedBound18754 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18755 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1296,327809,17,296995,8,16,264354,1296,1296,162,330787,100512,256,168,1297,512]

theorem envBound18755 : H12AffineFastState.Bounded env18755 := by
  intro p hp
  have h : env18755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18754_18755 : H12AffineEnvironment.transform 23 296995 env18754 = env18755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 296995 env18754 == env18755) = true)

theorem identity18755 : scanCanonicalize (H12AffineFastState.compose env18755 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18755 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18756 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,32768,33167,1297,262144,1024,32769,1296,295182,17,296995,8,16,264354,1296,1296,162,298412,2351,256,168,1297,512]

theorem envBound18756 : H12AffineFastState.Bounded env18756 := by
  intro p hp
  have h : env18756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18755_18756 : H12AffineEnvironment.transform 15 33167 env18755 = env18756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18755 == env18756) = true)

theorem identity18756 : scanCanonicalize (H12AffineFastState.compose env18756 (packedSelected [3,10] rootPS)) = affineNative (2^(14+1) ^^^ 2059) := by decide +kernel

theorem selectedBound18756 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env18757 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1297,2059,2436,1297,262144,1024,2058,1296,264453,17,262184,8,16,264354,1296,1296,162,263591,2351,256,168,1297,512]

theorem envBound18757 : H12AffineFastState.Bounded env18757 := by
  intro p hp
  have h : env18757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18756_18757 : H12AffineEnvironment.transform 14 2059 env18756 = env18757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2059 env18756 == env18757) = true)

theorem identity18757 : scanCanonicalize (H12AffineFastState.compose env18757 (packedSelected [0,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound18757 : packedSelected [0,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env18758 : List Nat := [2,4,8,16,32,16,128,256,512,533,2048,772,128,772,2059,2436,772,262144,533,2058,773,264453,17,262184,8,16,264354,773,773,162,263090,2351,256,168,772,512]

theorem envBound18758 : H12AffineFastState.Bounded env18758 := by
  intro p hp
  have h : env18758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18757_18758 : H12AffineEnvironment.transform 9 533 env18757 = env18758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env18757 == env18758) = true)

theorem identity18758 : scanCanonicalize (H12AffineFastState.compose env18758 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound18758 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18759 : List Nat := [2,4,8,16,32,16,128,256,512,533,2048,772,128,772,2059,2436,772,163,533,2058,773,2470,17,139,8,16,2049,773,773,162,785,2351,256,168,772,512]

theorem envBound18759 : H12AffineFastState.Bounded env18759 := by
  intro p hp
  have h : env18759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18758_18759 : H12AffineEnvironment.transform 17 163 env18758 = env18759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env18758 == env18759) = true)

theorem identity18759 : scanCanonicalize (H12AffineFastState.compose env18759 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound18759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18760 : List Nat := [2,4,8,16,32,16,128,256,512,533,643,772,128,772,648,775,772,163,533,649,773,805,17,139,8,16,642,773,773,162,785,940,256,168,772,512]

theorem envBound18760 : H12AffineFastState.Bounded env18760 := by
  intro p hp
  have h : env18760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18759_18760 : H12AffineEnvironment.transform 10 643 env18759 = env18760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env18759 == env18760) = true)

theorem identity18760 : scanCanonicalize (H12AffineFastState.compose env18760 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound18760 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18761 : List Nat := [2,4,8,16,32,16,128,141,512,533,643,649,128,649,648,650,649,163,533,649,648,680,17,139,8,16,642,648,648,162,668,545,141,168,649,512]

theorem envBound18761 : H12AffineFastState.Bounded env18761 := by
  intro p hp
  have h : env18761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18760_18761 : H12AffineEnvironment.transform 7 141 env18760 = env18761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env18760 == env18761) = true)

def env18762 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,16777216,9,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound18762 : H12AffineFastState.Bounded env18762 := by
  intro p hp
  have h : env18762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18738_18762 : H12AffineEnvironment.transform 12 129 env18738 = env18762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18738 == env18762) = true)

theorem identity18762 : scanCanonicalize (H12AffineFastState.compose env18762 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4489605) := by decide +kernel

theorem selectedBound18762 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,4489605,9,16,65925,1296,1296,1073741824,4523397,1073842178,256,1074071853,1297,512]

theorem envBound18763 : H12AffineFastState.Bounded env18763 := by
  intro p hp
  have h : env18763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18762_18763 : H12AffineEnvironment.transform 23 4489605 env18762 = env18763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4489605 env18762 == env18763) = true)

def env18764 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,0,4194304,17,4489605,9,16,65925,0,0,1073741824,4522133,1073842178,256,1074071853,1,512]

theorem envBound18764 : H12AffineFastState.Bounded env18764 := by
  intro p hp
  have h : env18764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18763_18764 : H12AffineEnvironment.transform 9 272 env18763 = env18764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18763 == env18764) = true)

theorem identity18764 : scanCanonicalize (H12AffineFastState.compose env18764 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 2471) := by decide +kernel

theorem selectedBound18764 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18765 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,0,2471,17,296994,9,16,65925,0,0,1073741824,330034,1073842178,256,1074071853,1,512]

theorem envBound18765 : H12AffineFastState.Bounded env18765 := by
  intro p hp
  have h : env18765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18764_18765 : H12AffineEnvironment.transform 21 2471 env18764 = env18765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2471 env18764 == env18765) = true)

def env18766 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,0,2471,17,296994,9,16,65925,0,0,98572,330034,2318,256,296993,1,512]

theorem envBound18766 : H12AffineFastState.Bounded env18766 := by
  intro p hp
  have h : env18766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18765_18766 : H12AffineEnvironment.transform 29 98572 env18765 = env18766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 98572 env18765 == env18766) = true)

theorem identity18766 : scanCanonicalize (H12AffineFastState.compose env18766 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 680) := by decide +kernel

theorem selectedBound18766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18767 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,65536,1,262144,272,681,0,2471,17,264842,9,16,65925,0,0,66468,330034,2318,256,264841,1,512]

theorem envBound18767 : H12AffineFastState.Bounded env18767 := by
  intro p hp
  have h : env18767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18766_18767 : H12AffineEnvironment.transform 14 680 env18766 = env18767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env18766 == env18767) = true)

def env18768 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,65536,1,65576,272,681,0,2471,17,68258,9,16,65925,0,0,66468,2330,2318,256,68257,1,512]

theorem envBound18768 : H12AffineFastState.Bounded env18768 := by
  intro p hp
  have h : env18768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18767_18768 : H12AffineEnvironment.transform 17 65576 env18767 = env18768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65576 env18767 == env18768) = true)

theorem identity18768 : scanCanonicalize (H12AffineFastState.compose env18768 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound18768 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18769 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,262,1,302,272,681,0,2471,17,2980,9,16,131,0,0,674,2330,2318,256,2983,1,512]

theorem envBound18769 : H12AffineFastState.Bounded env18769 := by
  intro p hp
  have h : env18769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18768_18769 : H12AffineEnvironment.transform 15 262 env18768 = env18769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env18768 == env18769) = true)

theorem identity18769 : scanCanonicalize (H12AffineFastState.compose env18769 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound18769 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env18770 : List Nat := [2,4,8,16,32,16,128,256,512,272,643,1,129,1,680,262,1,302,272,681,0,804,17,295,9,16,131,0,0,674,921,909,256,292,1,512]

theorem envBound18770 : H12AffineFastState.Bounded env18770 := by
  intro p hp
  have h : env18770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18769_18770 : H12AffineEnvironment.transform 10 643 env18769 = env18770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env18769 == env18770) = true)

theorem identity18770 : scanCanonicalize (H12AffineFastState.compose env18770 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound18770 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env18771 : List Nat := [2,4,8,16,32,16,128,256,397,272,270,1,129,1,293,262,1,302,272,292,0,169,17,295,9,16,131,0,0,303,20,0,256,292,1,397]

theorem envBound18771 : H12AffineFastState.Bounded env18771 := by
  intro p hp
  have h : env18771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18770_18771 : H12AffineEnvironment.transform 8 397 env18770 = env18771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env18770 == env18771) = true)

theorem identity18771 : scanCanonicalize (H12AffineFastState.compose env18771 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound18771 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env18772 : List Nat := [2,4,8,16,32,16,128,52,185,36,58,1,129,1,17,50,1,26,36,16,0,169,17,19,9,16,131,0,0,27,20,0,52,16,1,185]

theorem envBound18772 : H12AffineFastState.Bounded env18772 := by
  intro p hp
  have h : env18772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18771_18772 : H12AffineEnvironment.transform 7 52 env18771 = env18772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env18771 == env18772) = true)

theorem identity18772 : scanCanonicalize (H12AffineFastState.compose env18772 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18772 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18773 : List Nat := [2,4,8,16,32,16,24,52,33,36,58,1,25,1,17,50,1,26,36,16,0,49,17,19,9,16,27,0,0,27,20,0,52,16,1,33]

theorem envBound18773 : H12AffineFastState.Bounded env18773 := by
  intro p hp
  have h : env18773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18772_18773 : H12AffineEnvironment.transform 6 24 env18772 = env18773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18772 == env18773) = true)

theorem identity18773 : scanCanonicalize (H12AffineFastState.compose env18773 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18773 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18774 : List Nat := [2,4,8,0,32,0,8,36,33,36,42,1,9,1,1,34,1,10,36,0,0,33,1,3,9,0,11,0,0,11,4,0,36,0,1,33]

theorem envBound18774 : H12AffineFastState.Bounded env18774 := by
  intro p hp
  have h : env18774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18773_18774 : H12AffineEnvironment.transform 3 0 env18773 = env18774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18773 == env18774) = true)

theorem identity18774 : scanCanonicalize (H12AffineFastState.compose env18774 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18774 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18775 : List Nat := [2,4,8,0,1,0,8,5,0,5,11,1,9,1,1,3,1,10,5,0,0,0,1,3,9,0,11,0,0,11,4,0,5,0,1,0]

theorem envBound18775 : H12AffineFastState.Bounded env18775 := by
  intro p hp
  have h : env18775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18774_18775 : H12AffineEnvironment.transform 4 1 env18774 = env18775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18774 == env18775) = true)

theorem identity18775 : scanCanonicalize (H12AffineFastState.compose env18775 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18776 : List Nat := [2,4,2,0,1,0,2,5,0,5,1,1,3,1,1,3,1,0,5,0,0,0,1,3,3,0,1,0,0,1,4,0,5,0,1,0]

theorem envBound18776 : H12AffineFastState.Bounded env18776 := by
  intro p hp
  have h : env18776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18775_18776 : H12AffineEnvironment.transform 2 2 env18775 = env18776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18775 == env18776) = true)

def env18777 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,65536,1,65577,272,681,0,2471,17,68259,9,16,65925,0,0,66468,2331,2318,256,68256,1,512]

theorem envBound18777 : H12AffineFastState.Bounded env18777 := by
  intro p hp
  have h : env18777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18767_18777 : H12AffineEnvironment.transform 17 65577 env18767 = env18777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65577 env18767 == env18777) = true)

theorem identity18777 : scanCanonicalize (H12AffineFastState.compose env18777 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 2056) := by decide +kernel

theorem selectedBound18777 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18778 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,2056,1,2081,272,681,0,2471,17,683,9,16,2445,0,0,2988,2331,2318,256,680,1,512]

theorem envBound18778 : H12AffineFastState.Bounded env18778 := by
  intro p hp
  have h : env18778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18777_18778 : H12AffineEnvironment.transform 15 2056 env18777 = env18778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2056 env18777 == env18778) = true)

theorem identity18778 : scanCanonicalize (H12AffineFastState.compose env18778 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound18778 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env18779 : List Nat := [2,4,8,16,32,16,128,256,512,272,643,1,129,1,680,651,1,674,272,681,0,804,17,683,9,16,782,0,0,303,920,909,256,680,1,512]

theorem envBound18779 : H12AffineFastState.Bounded env18779 := by
  intro p hp
  have h : env18779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18778_18779 : H12AffineEnvironment.transform 10 643 env18778 = env18779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env18778 == env18779) = true)

theorem identity18779 : scanCanonicalize (H12AffineFastState.compose env18779 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound18779 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env18780 : List Nat := [2,4,8,16,32,16,128,256,396,272,271,1,129,1,292,263,1,302,272,293,0,168,17,295,9,16,130,0,0,303,20,1,256,292,1,396]

theorem envBound18780 : H12AffineFastState.Bounded env18780 := by
  intro p hp
  have h : env18780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18779_18780 : H12AffineEnvironment.transform 8 396 env18779 = env18780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env18779 == env18780) = true)

theorem identity18780 : scanCanonicalize (H12AffineFastState.compose env18780 (packedSelected [0,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18780 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env18781 : List Nat := [2,4,8,16,32,16,24,256,276,272,271,1,25,1,292,263,1,302,272,293,0,48,17,295,9,16,26,0,0,303,20,1,256,292,1,276]

theorem envBound18781 : H12AffineFastState.Bounded env18781 := by
  intro p hp
  have h : env18781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18780_18781 : H12AffineEnvironment.transform 6 24 env18780 = env18781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18780 == env18781) = true)

theorem identity18781 : scanCanonicalize (H12AffineFastState.compose env18781 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound18781 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18782 : List Nat := [2,4,8,16,32,16,24,52,32,36,59,1,25,1,16,51,1,26,36,17,0,48,17,19,9,16,26,0,0,27,20,1,52,16,1,32]

theorem envBound18782 : H12AffineFastState.Bounded env18782 := by
  intro p hp
  have h : env18782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18781_18782 : H12AffineEnvironment.transform 7 52 env18781 = env18782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env18781 == env18782) = true)

theorem identity18782 : scanCanonicalize (H12AffineFastState.compose env18782 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18782 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18783 : List Nat := [2,4,8,1,32,1,9,37,32,36,42,1,8,1,1,34,1,11,36,0,0,33,0,2,9,1,11,0,0,10,5,1,37,1,1,32]

theorem envBound18783 : H12AffineFastState.Bounded env18783 := by
  intro p hp
  have h : env18783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18782_18783 : H12AffineEnvironment.transform 3 1 env18782 = env18783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18782 == env18783) = true)

def env18784 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,0,2471,17,296994,9,16,65925,0,0,98573,330034,2319,256,296992,1,512]

theorem envBound18784 : H12AffineFastState.Bounded env18784 := by
  intro p hp
  have h : env18784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18765_18784 : H12AffineEnvironment.transform 29 98573 env18765 = env18784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 98573 env18765 == env18784) = true)

theorem identity18784 : scanCanonicalize (H12AffineFastState.compose env18784 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 101263) := by decide +kernel

theorem selectedBound18784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18785 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,32768,65536,1,101263,272,32769,0,2471,17,66477,9,16,65925,0,0,98573,33469,2319,256,66479,1,512]

theorem envBound18785 : H12AffineFastState.Bounded env18785 := by
  intro p hp
  have h : env18785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18784_18785 : H12AffineEnvironment.transform 17 101263 env18784 = env18785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 101263 env18784 == env18785) = true)

def env18786 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,65536,1,67879,272,681,0,2471,17,66477,9,16,65925,0,0,66469,21,2319,256,66479,1,512]

theorem envBound18786 : H12AffineFastState.Bounded env18786 := by
  intro p hp
  have h : env18786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18785_18786 : H12AffineEnvironment.transform 14 680 env18785 = env18786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env18785 == env18786) = true)

theorem identity18786 : scanCanonicalize (H12AffineFastState.compose env18786 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18786 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18787 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,680,263,1,2080,272,681,0,2471,17,682,9,16,130,0,0,674,21,2319,256,680,1,512]

theorem envBound18787 : H12AffineFastState.Bounded env18787 := by
  intro p hp
  have h : env18787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18786_18787 : H12AffineEnvironment.transform 15 263 env18786 = env18787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18786 == env18787) = true)

theorem identity18787 : scanCanonicalize (H12AffineFastState.compose env18787 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18787 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18788 : List Nat := [2,4,8,16,32,16,128,256,1,272,2048,1,129,1,169,263,1,2080,272,168,0,2471,17,171,9,16,130,0,0,163,21,2319,256,169,1,1]

theorem envBound18788 : H12AffineFastState.Bounded env18788 := by
  intro p hp
  have h : env18788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18787_18788 : H12AffineEnvironment.transform 8 1 env18787 = env18788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18787 == env18788) = true)

theorem identity18788 : scanCanonicalize (H12AffineFastState.compose env18788 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound18788 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18789 : List Nat := [2,4,8,16,32,16,128,256,1,272,162,1,129,1,169,263,1,130,272,168,0,261,17,171,9,16,130,0,0,163,21,429,256,169,1,1]

theorem envBound18789 : H12AffineFastState.Bounded env18789 := by
  intro p hp
  have h : env18789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18788_18789 : H12AffineEnvironment.transform 10 162 env18788 = env18789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env18788 == env18789) = true)

theorem identity18789 : scanCanonicalize (H12AffineFastState.compose env18789 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound18789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18790 : List Nat := [2,4,8,16,32,16,3,256,1,272,33,1,2,1,42,263,1,1,272,43,0,261,17,40,9,16,1,0,0,32,21,302,256,42,1,1]

theorem envBound18790 : H12AffineFastState.Bounded env18790 := by
  intro p hp
  have h : env18790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18789_18790 : H12AffineEnvironment.transform 6 3 env18789 = env18790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env18789 == env18790) = true)

theorem identity18790 : scanCanonicalize (H12AffineFastState.compose env18790 (packedSelected [4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18790 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18791 : List Nat := [2,4,8,16,32,16,3,4,1,20,33,1,2,1,42,3,1,1,20,43,0,1,17,40,9,16,1,0,0,32,21,42,4,42,1,1]

theorem envBound18791 : H12AffineFastState.Bounded env18791 := by
  intro p hp
  have h : env18791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18790_18791 : H12AffineEnvironment.transform 7 4 env18790 = env18791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18790 == env18791) = true)

theorem identity18791 : scanCanonicalize (H12AffineFastState.compose env18791 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18792 : List Nat := [2,4,8,16,16,16,3,4,1,20,17,1,2,1,26,3,1,1,20,27,0,1,17,24,9,16,1,0,0,16,21,26,4,26,1,1]

theorem envBound18792 : H12AffineFastState.Bounded env18792 := by
  intro p hp
  have h : env18792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18791_18792 : H12AffineEnvironment.transform 4 16 env18791 = env18792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18791 == env18792) = true)

theorem identity18792 : scanCanonicalize (H12AffineFastState.compose env18792 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18792 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18793 : List Nat := [2,4,8,0,0,0,3,4,1,4,1,1,2,1,10,3,1,1,4,11,0,1,1,8,9,0,1,0,0,0,5,10,4,10,1,1]

theorem envBound18793 : H12AffineFastState.Bounded env18793 := by
  intro p hp
  have h : env18793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18792_18793 : H12AffineEnvironment.transform 3 0 env18792 = env18793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18792 == env18793) = true)

theorem identity18793 : scanCanonicalize (H12AffineFastState.compose env18793 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18794 : List Nat := [2,4,3,0,0,0,3,4,1,4,1,1,2,1,1,3,1,1,4,0,0,1,1,3,2,0,1,0,0,0,5,1,4,1,1,1]

theorem envBound18794 : H12AffineFastState.Bounded env18794 := by
  intro p hp
  have h : env18794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18793_18794 : H12AffineEnvironment.transform 2 3 env18793 = env18794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18793 == env18794) = true)

def env18795 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,681,65536,1,67878,272,680,0,2471,17,66477,9,16,65925,0,0,66468,20,2319,256,66479,1,512]

theorem envBound18795 : H12AffineFastState.Bounded env18795 := by
  intro p hp
  have h : env18795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18785_18795 : H12AffineEnvironment.transform 14 681 env18785 = env18795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 681 env18785 == env18795) = true)

theorem identity18795 : scanCanonicalize (H12AffineFastState.compose env18795 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 2056) := by decide +kernel

theorem selectedBound18795 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18796 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,129,1,681,2056,1,302,272,680,0,2471,17,2981,9,16,2445,0,0,2988,20,2319,256,2983,1,512]

theorem envBound18796 : H12AffineFastState.Bounded env18796 := by
  intro p hp
  have h : env18796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18795_18796 : H12AffineEnvironment.transform 15 2056 env18795 = env18796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2056 env18795 == env18796) = true)

theorem identity18796 : scanCanonicalize (H12AffineFastState.compose env18796 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound18796 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18797 : List Nat := [2,4,8,16,32,16,128,173,512,189,2048,1,129,1,681,2056,1,131,189,680,0,2058,17,2568,9,16,2080,0,0,2561,20,2210,173,2570,1,512]

theorem envBound18797 : H12AffineFastState.Bounded env18797 := by
  intro p hp
  have h : env18797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18796_18797 : H12AffineEnvironment.transform 7 173 env18796 = env18797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env18796 == env18797) = true)

theorem identity18797 : scanCanonicalize (H12AffineFastState.compose env18797 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18797 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18798 : List Nat := [2,4,8,16,32,16,128,173,137,189,2048,1,129,1,32,2056,1,131,189,33,0,2058,17,2177,9,16,2080,0,0,2184,20,2210,173,2179,1,137]

theorem envBound18798 : H12AffineFastState.Bounded env18798 := by
  intro p hp
  have h : env18798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18797_18798 : H12AffineEnvironment.transform 8 137 env18797 = env18798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18797 == env18798) = true)

theorem identity18798 : scanCanonicalize (H12AffineFastState.compose env18798 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18798 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18799 : List Nat := [2,4,8,16,1,16,128,140,137,156,2048,1,129,1,1,2056,1,131,156,0,0,2058,17,2177,9,16,2049,0,0,2184,20,2179,140,2179,1,137]

theorem envBound18799 : H12AffineFastState.Bounded env18799 := by
  intro p hp
  have h : env18799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18798_18799 : H12AffineEnvironment.transform 4 1 env18798 = env18799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18798 == env18799) = true)

theorem identity18799 : scanCanonicalize (H12AffineFastState.compose env18799 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound18799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18800 : List Nat := [2,4,8,16,1,16,128,140,137,156,147,1,129,1,1,155,1,131,156,0,0,153,17,18,9,16,146,0,0,27,20,16,140,16,1,137]

theorem envBound18800 : H12AffineFastState.Bounded env18800 := by
  intro p hp
  have h : env18800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18799_18800 : H12AffineEnvironment.transform 10 147 env18799 = env18800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env18799 == env18800) = true)

theorem identity18800 : scanCanonicalize (H12AffineFastState.compose env18800 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18800 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18801 : List Nat := [2,4,8,16,1,16,25,21,16,5,10,1,24,1,1,2,1,26,5,0,0,0,17,18,9,16,11,0,0,27,20,16,21,16,1,16]

theorem envBound18801 : H12AffineFastState.Bounded env18801 := by
  intro p hp
  have h : env18801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18800_18801 : H12AffineEnvironment.transform 6 25 env18800 = env18801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18800 == env18801) = true)

def env18802 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,1,4194304,17,4489605,9,16,65925,1,1,1073741824,4522132,1073842178,256,1074071853,0,512]

theorem envBound18802 : H12AffineFastState.Bounded env18802 := by
  intro p hp
  have h : env18802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18763_18802 : H12AffineEnvironment.transform 9 273 env18763 = env18802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18763 == env18802) = true)

theorem identity18802 : scanCanonicalize (H12AffineFastState.compose env18802 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 4522018) := by decide +kernel

theorem selectedBound18802 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18803 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,1,4194304,17,4489605,9,16,65925,1,1,4522018,4522132,4491296,256,4196623,0,512]

theorem envBound18803 : H12AffineFastState.Bounded env18803 := by
  intro p hp
  have h : env18803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18802_18803 : H12AffineEnvironment.transform 29 4522018 env18802 = env18803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4522018 env18802 == env18803) = true)

def env18804 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,1,327808,17,98565,9,16,65925,1,1,162,20,100512,256,330127,0,512]

theorem envBound18804 : H12AffineFastState.Bounded env18804 := by
  intro p hp
  have h : env18804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18803_18804 : H12AffineEnvironment.transform 21 327808 env18803 = env18804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 327808 env18803 == env18804) = true)

theorem identity18804 : scanCanonicalize (H12AffineFastState.compose env18804 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 680) := by decide +kernel

theorem selectedBound18804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18805 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,680,65536,0,262144,273,681,1,327808,17,66477,9,16,65925,1,1,162,20,68104,256,330127,0,512]

theorem envBound18805 : H12AffineFastState.Bounded env18805 := by
  intro p hp
  have h : env18805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18804_18805 : H12AffineEnvironment.transform 14 680 env18804 = env18805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env18804 == env18805) = true)

theorem identity18805 : scanCanonicalize (H12AffineFastState.compose env18805 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 68391) := by decide +kernel

theorem selectedBound18805 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18806 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,680,65536,0,68391,273,681,1,2983,17,66477,9,16,65925,1,1,162,20,68104,256,680,0,512]

theorem envBound18806 : H12AffineFastState.Bounded env18806 := by
  intro p hp
  have h : env18806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18805_18806 : H12AffineEnvironment.transform 17 68391 env18805 = env18806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68391 env18805 == env18806) = true)

theorem identity18806 : scanCanonicalize (H12AffineFastState.compose env18806 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18806 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18807 : List Nat := [2,4,8,16,32,16,128,256,1,273,2048,0,129,0,169,65536,0,67878,273,168,1,2470,17,65964,9,16,65925,1,1,162,20,67593,256,169,0,1]

theorem envBound18807 : H12AffineFastState.Bounded env18807 := by
  intro p hp
  have h : env18807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18806_18807 : H12AffineEnvironment.transform 8 1 env18806 = env18807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18806 == env18807) = true)

theorem identity18807 : scanCanonicalize (H12AffineFastState.compose env18807 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound18807 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18808 : List Nat := [2,4,8,16,32,16,128,256,1,273,163,0,129,0,169,65536,0,65925,273,168,1,261,17,65964,9,16,65925,1,1,162,20,65706,256,169,0,1]

theorem envBound18808 : H12AffineFastState.Bounded env18808 := by
  intro p hp
  have h : env18808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18807_18808 : H12AffineEnvironment.transform 10 163 env18807 = env18808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env18807 == env18808) = true)

theorem identity18808 : scanCanonicalize (H12AffineFastState.compose env18808 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 388) := by decide +kernel

theorem selectedBound18808 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18809 : List Nat := [2,4,8,16,32,16,128,256,1,273,163,0,129,0,169,388,0,1,273,168,1,261,17,40,9,16,1,1,1,162,20,302,256,169,0,1]

theorem envBound18809 : H12AffineFastState.Bounded env18809 := by
  intro p hp
  have h : env18809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18808_18809 : H12AffineEnvironment.transform 15 388 env18808 = env18809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 388 env18808 == env18809) = true)

theorem identity18809 : scanCanonicalize (H12AffineFastState.compose env18809 (packedSelected [4,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18809 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18810 : List Nat := [2,4,8,16,32,16,128,5,1,20,163,0,129,0,169,129,0,1,20,168,1,0,17,40,9,16,1,1,1,162,20,43,5,169,0,1]

theorem envBound18810 : H12AffineFastState.Bounded env18810 := by
  intro p hp
  have h : env18810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18809_18810 : H12AffineEnvironment.transform 7 5 env18809 = env18810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18809 == env18810) = true)

theorem identity18810 : scanCanonicalize (H12AffineFastState.compose env18810 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound18810 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18811 : List Nat := [2,4,8,16,32,16,34,5,1,20,1,0,35,0,11,35,0,1,20,10,1,0,17,40,9,16,1,1,1,0,20,43,5,11,0,1]

theorem envBound18811 : H12AffineFastState.Bounded env18811 := by
  intro p hp
  have h : env18811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18810_18811 : H12AffineEnvironment.transform 6 34 env18810 = env18811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env18810 == env18811) = true)

def env18812 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,1,327809,17,98564,9,16,65925,1,1,163,21,100513,256,330126,0,512]

theorem envBound18812 : H12AffineFastState.Bounded env18812 := by
  intro p hp
  have h : env18812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18803_18812 : H12AffineEnvironment.transform 21 327809 env18803 = env18812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 327809 env18803 == env18812) = true)

theorem identity18812 : scanCanonicalize (H12AffineFastState.compose env18812 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2593) := by decide +kernel

theorem selectedBound18812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18813 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,129,0,32768,65536,0,2593,273,32769,1,68256,17,98564,9,16,65925,1,1,163,21,100513,256,66479,0,512]

theorem envBound18813 : H12AffineFastState.Bounded env18813 := by
  intro p hp
  have h : env18813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18812_18813 : H12AffineEnvironment.transform 17 2593 env18812 = env18813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2593 env18812 == env18813) = true)

theorem identity18813 : scanCanonicalize (H12AffineFastState.compose env18813 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound18813 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18814 : List Nat := [2,4,8,16,32,16,128,256,512,273,783,0,129,0,32768,65536,0,302,273,32769,1,65967,17,98564,9,16,65925,1,1,163,21,99246,256,66479,0,512]

theorem envBound18814 : H12AffineFastState.Bounded env18814 := by
  intro p hp
  have h : env18814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18813_18814 : H12AffineEnvironment.transform 10 783 env18813 = env18814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env18813 == env18814) = true)

theorem identity18814 : scanCanonicalize (H12AffineFastState.compose env18814 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 772) := by decide +kernel

theorem selectedBound18814 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18815 : List Nat := [2,4,8,16,32,16,128,256,512,273,783,0,129,0,772,65536,0,302,273,773,1,65967,17,66048,9,16,65925,1,1,163,21,65706,256,66479,0,512]

theorem envBound18815 : H12AffineFastState.Bounded env18815 := by
  intro p hp
  have h : env18815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18814_18815 : H12AffineEnvironment.transform 14 772 env18814 = env18815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 772 env18814 == env18815) = true)

theorem identity18815 : scanCanonicalize (H12AffineFastState.compose env18815 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18815 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18816 : List Nat := [2,4,8,16,32,16,128,256,136,273,391,0,129,0,396,65536,0,302,273,397,1,65967,17,65672,9,16,65925,1,1,163,21,65706,256,65831,0,136]

theorem envBound18816 : H12AffineFastState.Bounded env18816 := by
  intro p hp
  have h : env18816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18815_18816 : H12AffineEnvironment.transform 8 136 env18815 = env18816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18815 == env18816) = true)

theorem identity18816 : scanCanonicalize (H12AffineFastState.compose env18816 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18816 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env18817 : List Nat := [2,4,8,16,32,16,128,140,136,157,11,0,129,0,0,65536,0,162,157,1,1,65571,17,65672,9,16,65545,1,1,163,21,65706,140,65707,0,136]

theorem envBound18817 : H12AffineFastState.Bounded env18817 := by
  intro p hp
  have h : env18817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18816_18817 : H12AffineEnvironment.transform 7 140 env18816 = env18817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18816 == env18817) = true)

theorem identity18817 : scanCanonicalize (H12AffineFastState.compose env18817 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound18817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18818 : List Nat := [2,4,8,16,32,16,57,53,49,36,11,0,56,0,0,65536,0,27,36,1,1,65571,17,65585,9,16,65545,1,1,26,21,65555,53,65554,0,49]

theorem envBound18818 : H12AffineFastState.Bounded env18818 := by
  intro p hp
  have h : env18818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18817_18818 : H12AffineEnvironment.transform 6 57 env18817 = env18818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env18817 == env18818) = true)

theorem identity18818 : scanCanonicalize (H12AffineFastState.compose env18818 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18818 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18819 : List Nat := [2,4,8,16,32,16,57,53,49,36,11,0,56,0,0,3,0,27,36,1,1,32,17,50,9,16,10,1,1,26,21,16,53,17,0,49]

theorem envBound18819 : H12AffineFastState.Bounded env18819 := by
  intro p hp
  have h : env18819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18818_18819 : H12AffineEnvironment.transform 15 3 env18818 = env18819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18818 == env18819) = true)

def env18820 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound18820 : H12AffineFastState.Bounded env18820 := by
  intro p hp
  have h : env18820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18736_18820 : H12AffineEnvironment.transform 5 17 env18736 = env18820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18736 == env18820) = true)

theorem identity18820 : scanCanonicalize (H12AffineFastState.compose env18820 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound18820 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18821 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound18821 : H12AffineFastState.Bounded env18821 := by
  intro p hp
  have h : env18821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18820_18821 : H12AffineEnvironment.transform 31 4194440 env18820 = env18821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env18820 == env18821) = true)

def env18822 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound18822 : H12AffineFastState.Bounded env18822 := by
  intro p hp
  have h : env18822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18821_18822 : H12AffineEnvironment.transform 12 128 env18821 = env18822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18821 == env18822) = true)

theorem identity18822 : scanCanonicalize (H12AffineFastState.compose env18822 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 137) := by decide +kernel

theorem selectedBound18822 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18823 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,4194304,16,16777216,8,16,21069961,1297,1297,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound18823 : H12AffineFastState.Bounded env18823 := by
  intro p hp
  have h : env18823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18822_18823 : H12AffineEnvironment.transform 17 137 env18822 = env18823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env18822 == env18823) = true)

def env18824 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,4194304,16,16777216,8,16,21069961,1297,1297,21071872,16876544,4194440,256,16777250,1296,512]

theorem envBound18824 : H12AffineFastState.Bounded env18824 := by
  intro p hp
  have h : env18824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18823_18824 : H12AffineEnvironment.transform 29 21071872 env18823 = env18824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env18823 == env18824) = true)

theorem identity18824 : scanCanonicalize (H12AffineFastState.compose env18824 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 4294792) := by decide +kernel

theorem selectedBound18824 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18825 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,4194304,16,4294792,8,16,2049,1297,1297,136,4197512,4194440,256,4294826,1296,512]

theorem envBound18825 : H12AffineFastState.Bounded env18825 := by
  intro p hp
  have h : env18825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18824_18825 : H12AffineEnvironment.transform 23 4294792 env18824 = env18825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4294792 env18824 == env18825) = true)

theorem identity18825 : scanCanonicalize (H12AffineFastState.compose env18825 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound18825 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18826 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,2081,65536,1296,137,1024,2080,1297,4194304,16,4260009,8,16,2049,1297,1297,136,4197512,4194440,256,4259979,1296,512]

theorem envBound18826 : H12AffineFastState.Bounded env18826 := by
  intro p hp
  have h : env18826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18825_18826 : H12AffineEnvironment.transform 14 2081 env18825 = env18826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env18825 == env18826) = true)

theorem identity18826 : scanCanonicalize (H12AffineFastState.compose env18826 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 2444) := by decide +kernel

theorem selectedBound18826 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18827 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,2081,65536,1296,137,1024,2080,1297,2444,16,67877,8,16,2049,1297,1297,136,1284,2308,256,67847,1296,512]

theorem envBound18827 : H12AffineFastState.Bounded env18827 := by
  intro p hp
  have h : env18827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18826_18827 : H12AffineEnvironment.transform 21 2444 env18826 = env18827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2444 env18826 == env18827) = true)

theorem identity18827 : scanCanonicalize (H12AffineFastState.compose env18827 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18827 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18828 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,128,1296,2081,65536,1296,137,1024,2080,1297,2444,16,67877,8,16,2049,1297,1297,136,1284,2308,256,67847,1296,137]

theorem envBound18828 : H12AffineFastState.Bounded env18828 := by
  intro p hp
  have h : env18828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18827_18828 : H12AffineEnvironment.transform 8 137 env18827 = env18828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18827 == env18828) = true)

def env18829 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,128,0,2081,65536,0,137,272,2080,1,2444,16,67877,8,16,2049,1,1,136,20,2308,256,67847,0,137]

theorem envBound18829 : H12AffineFastState.Bounded env18829 := by
  intro p hp
  have h : env18829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18828_18829 : H12AffineEnvironment.transform 9 272 env18828 = env18829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18828 == env18829) = true)

theorem identity18829 : scanCanonicalize (H12AffineFastState.compose env18829 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound18829 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18830 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,128,0,2081,2082,0,137,272,2080,1,2444,16,263,8,16,2049,1,1,136,20,2308,256,293,0,137]

theorem envBound18830 : H12AffineFastState.Bounded env18830 := by
  intro p hp
  have h : env18830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18829_18830 : H12AffineEnvironment.transform 15 2082 env18829 = env18830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env18829 == env18830) = true)

def env18831 : List Nat := [2,4,8,16,32,17,128,256,137,272,168,0,128,0,137,138,0,137,272,136,1,292,16,263,8,16,169,1,1,136,20,428,256,293,0,137]

theorem envBound18831 : H12AffineFastState.Bounded env18831 := by
  intro p hp
  have h : env18831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18830_18831 : H12AffineEnvironment.transform 10 168 env18830 = env18831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env18830 == env18831) = true)

theorem identity18831 : scanCanonicalize (H12AffineFastState.compose env18831 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound18831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18832 : List Nat := [2,4,8,16,32,17,56,256,49,272,16,0,56,0,49,50,0,49,272,48,1,292,16,263,8,16,17,1,1,48,20,276,256,293,0,49]

theorem envBound18832 : H12AffineFastState.Bounded env18832 := by
  intro p hp
  have h : env18832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18831_18832 : H12AffineEnvironment.transform 6 56 env18831 = env18832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env18831 == env18832) = true)

def env18833 : List Nat := [2,4,8,16,0,17,24,256,17,272,16,0,24,0,17,18,0,17,272,16,1,260,16,263,8,16,17,1,1,16,20,276,256,261,0,17]

theorem envBound18833 : H12AffineFastState.Bounded env18833 := by
  intro p hp
  have h : env18833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18832_18833 : H12AffineEnvironment.transform 4 0 env18832 = env18833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18832 == env18833) = true)

def env18834 : List Nat := [2,4,8,0,0,1,8,256,1,256,0,0,8,0,1,2,0,1,256,0,1,260,0,263,8,0,1,1,1,0,4,260,256,261,0,1]

theorem envBound18834 : H12AffineFastState.Bounded env18834 := by
  intro p hp
  have h : env18834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18833_18834 : H12AffineEnvironment.transform 3 0 env18833 = env18834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18833 == env18834) = true)

theorem identity18834 : scanCanonicalize (H12AffineFastState.compose env18834 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18834 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18835 : List Nat := [2,4,8,0,0,1,8,4,1,4,0,0,8,0,1,2,0,1,4,0,1,0,0,3,8,0,1,1,1,0,4,0,4,1,0,1]

theorem envBound18835 : H12AffineFastState.Bounded env18835 := by
  intro p hp
  have h : env18835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18834_18835 : H12AffineEnvironment.transform 7 4 env18834 = env18835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18834 == env18835) = true)

def leafEnv18835 : List Nat := [2,4,8,0,0,1,8,4,1,4,0,0,8,0,1,2,0,1,4,0,1,0,0,3,5,8,1,0,1,1,1,0,4,0,4,1,5,3,0,1,0,1,1]

def active18835 : List Nat := [0,1,2]

def tree18835 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18835 : H12WitnessSearch.Good tree18835 := H12GlobalWitnessIndex.good

theorem leafIdentity18835 : H12AffineFastState.composeSystem env18835 rootObs = leafEnv18835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18835 rootObs == leafEnv18835) = true)

theorem terminalChecked18835 : H12PackedTerminal.terminalCheckFast leafEnv18835 active18835 tree18835 = true := by decide +kernel

def env18836 : List Nat := [2,4,8,1,0,0,9,256,0,257,1,0,9,0,0,3,0,0,257,1,1,260,1,263,8,1,0,1,1,1,5,261,256,261,0,0]

theorem envBound18836 : H12AffineFastState.Bounded env18836 := by
  intro p hp
  have h : env18836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18833_18836 : H12AffineEnvironment.transform 3 1 env18833 = env18836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18833 == env18836) = true)

def env18837 : List Nat := [2,4,8,16,1,17,25,256,16,272,16,0,25,0,16,19,0,16,272,17,1,261,16,263,8,16,17,1,1,17,20,276,256,260,0,16]

theorem envBound18837 : H12AffineFastState.Bounded env18837 := by
  intro p hp
  have h : env18837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18832_18837 : H12AffineEnvironment.transform 4 1 env18832 = env18837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18832 == env18837) = true)

theorem identity18837 : scanCanonicalize (H12AffineFastState.compose env18837 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18837 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18838 : List Nat := [2,4,8,16,1,17,25,4,16,20,16,0,25,0,16,19,0,16,20,17,1,1,16,3,8,16,17,1,1,17,20,16,4,0,0,16]

theorem envBound18838 : H12AffineFastState.Bounded env18838 := by
  intro p hp
  have h : env18838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18837_18838 : H12AffineEnvironment.transform 7 4 env18837 = env18838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18837 == env18838) = true)

theorem identity18838 : scanCanonicalize (H12AffineFastState.compose env18838 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18838 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18839 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,0,8,0,1,2,0,1,5,0,1,1,1,3,8,1,0,1,1,0,5,1,4,0,0,1]

theorem envBound18839 : H12AffineFastState.Bounded env18839 := by
  intro p hp
  have h : env18839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18838_18839 : H12AffineEnvironment.transform 3 1 env18838 = env18839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18838 == env18839) = true)

def leafEnv18839 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,0,8,0,1,2,0,1,5,0,1,1,1,3,4,8,1,1,0,1,1,0,5,1,4,0,5,3,0,1,0,1,1]

def active18839 : List Nat := [0,1,2]

def tree18839 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18839 : H12WitnessSearch.Good tree18839 := H12GlobalWitnessIndex.good

theorem leafIdentity18839 : H12AffineFastState.composeSystem env18839 rootObs = leafEnv18839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18839 rootObs == leafEnv18839) = true)

theorem terminalChecked18839 : H12PackedTerminal.terminalCheckFast leafEnv18839 active18839 tree18839 = true := by decide +kernel

def env18840 : List Nat := [2,4,8,16,32,17,128,256,137,272,169,0,128,0,136,139,0,137,272,137,1,293,16,263,8,16,168,1,1,136,20,429,256,293,0,137]

theorem envBound18840 : H12AffineFastState.Bounded env18840 := by
  intro p hp
  have h : env18840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18830_18840 : H12AffineEnvironment.transform 10 169 env18830 = env18840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env18830 == env18840) = true)

theorem identity18840 : scanCanonicalize (H12AffineFastState.compose env18840 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound18840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18841 : List Nat := [2,4,8,16,32,17,128,157,137,141,169,0,128,0,136,139,0,137,141,137,1,184,16,154,8,16,168,1,1,136,20,48,157,184,0,137]

theorem envBound18841 : H12AffineFastState.Bounded env18841 := by
  intro p hp
  have h : env18841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18840_18841 : H12AffineEnvironment.transform 7 157 env18840 = env18841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env18840 == env18841) = true)

def env18842 : List Nat := [2,4,8,16,0,17,128,157,137,141,137,0,128,0,136,139,0,137,141,137,1,152,16,154,8,16,136,1,1,136,20,16,157,152,0,137]

theorem envBound18842 : H12AffineFastState.Bounded env18842 := by
  intro p hp
  have h : env18842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18841_18842 : H12AffineEnvironment.transform 4 0 env18841 = env18842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18841 == env18842) = true)

theorem identity18842 : scanCanonicalize (H12AffineFastState.compose env18842 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18843 : List Nat := [2,4,8,16,0,17,9,20,0,4,0,0,9,0,1,2,0,0,4,0,1,17,16,19,8,16,1,1,1,1,20,16,20,17,0,0]

theorem envBound18843 : H12AffineFastState.Bounded env18843 := by
  intro p hp
  have h : env18843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18842_18843 : H12AffineEnvironment.transform 6 9 env18842 = env18843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18842 == env18843) = true)

theorem identity18843 : scanCanonicalize (H12AffineFastState.compose env18843 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18843 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18844 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,0,9,0,1,2,0,0,4,0,1,0,1,2,8,1,1,1,1,1,5,1,5,0,0,0]

theorem envBound18844 : H12AffineFastState.Bounded env18844 := by
  intro p hp
  have h : env18844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18843_18844 : H12AffineEnvironment.transform 3 1 env18843 = env18844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18843 == env18844) = true)

def leafEnv18844 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,0,9,0,1,2,0,0,4,0,1,0,1,2,4,8,1,1,1,1,1,1,5,1,5,0,5,2,0,0,0,1,1]

def active18844 : List Nat := [0,1,2]

def tree18844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18844 : H12WitnessSearch.Good tree18844 := H12GlobalWitnessIndex.good

theorem leafIdentity18844 : H12AffineFastState.composeSystem env18844 rootObs = leafEnv18844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18844 rootObs == leafEnv18844) = true)

theorem terminalChecked18844 : H12PackedTerminal.terminalCheckFast leafEnv18844 active18844 tree18844 = true := by decide +kernel

def env18845 : List Nat := [2,4,8,16,1,17,128,157,137,141,136,0,128,0,136,139,0,137,141,137,1,153,16,154,8,16,137,1,1,136,20,17,157,153,0,137]

theorem envBound18845 : H12AffineFastState.Bounded env18845 := by
  intro p hp
  have h : env18845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18841_18845 : H12AffineEnvironment.transform 4 1 env18841 = env18845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18841 == env18845) = true)

theorem identity18845 : scanCanonicalize (H12AffineFastState.compose env18845 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18846 : List Nat := [2,4,8,0,1,1,128,141,137,141,136,0,128,0,136,139,0,137,141,137,1,137,0,138,8,0,137,1,1,136,4,1,141,137,0,137]

theorem envBound18846 : H12AffineFastState.Bounded env18846 := by
  intro p hp
  have h : env18846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18845_18846 : H12AffineEnvironment.transform 3 0 env18845 = env18846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18845 == env18846) = true)

def env18847 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,128,1,2081,65536,1,137,273,2080,0,2444,16,67877,8,16,2049,0,0,136,21,2308,256,67847,1,137]

theorem envBound18847 : H12AffineFastState.Bounded env18847 := by
  intro p hp
  have h : env18847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18828_18847 : H12AffineEnvironment.transform 9 273 env18828 = env18847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18828 == env18847) = true)

theorem identity18847 : scanCanonicalize (H12AffineFastState.compose env18847 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18848 : List Nat := [2,4,8,16,32,17,128,140,137,157,2048,1,128,1,2081,65536,1,137,157,2080,0,2048,16,67753,8,16,2049,0,0,136,21,2184,140,67723,1,137]

theorem envBound18848 : H12AffineFastState.Bounded env18848 := by
  intro p hp
  have h : env18848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18847_18848 : H12AffineEnvironment.transform 7 140 env18847 = env18848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18847 == env18848) = true)

def env18849 : List Nat := [2,4,8,16,32,17,128,140,137,157,0,1,128,1,33,65536,1,137,157,32,0,0,16,65705,8,16,1,0,0,136,21,136,140,65675,1,137]

theorem envBound18849 : H12AffineFastState.Bounded env18849 := by
  intro p hp
  have h : env18849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18848_18849 : H12AffineEnvironment.transform 10 0 env18848 = env18849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18848 == env18849) = true)

theorem identity18849 : scanCanonicalize (H12AffineFastState.compose env18849 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 186) := by decide +kernel

theorem selectedBound18849 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18850 : List Nat := [2,4,8,16,32,17,128,140,137,157,0,1,128,1,33,186,1,137,157,32,0,0,16,19,8,16,1,0,0,136,21,136,140,49,1,137]

theorem envBound18850 : H12AffineFastState.Bounded env18850 := by
  intro p hp
  have h : env18850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18849_18850 : H12AffineEnvironment.transform 15 186 env18849 = env18850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 186 env18849 == env18850) = true)

def env18851 : List Nat := [2,4,8,16,0,17,128,140,137,157,0,1,128,1,1,154,1,137,157,0,0,0,16,19,8,16,1,0,0,136,21,136,140,17,1,137]

theorem envBound18851 : H12AffineFastState.Bounded env18851 := by
  intro p hp
  have h : env18851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18850_18851 : H12AffineEnvironment.transform 4 0 env18850 = env18851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18850 == env18851) = true)

def env18852 : List Nat := [2,4,8,16,1,17,128,140,137,157,0,1,128,1,0,155,1,137,157,1,0,0,16,19,8,16,1,0,0,136,21,136,140,16,1,137]

theorem envBound18852 : H12AffineFastState.Bounded env18852 := by
  intro p hp
  have h : env18852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18850_18852 : H12AffineEnvironment.transform 4 1 env18850 = env18852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18850 == env18852) = true)

theorem identity18852 : scanCanonicalize (H12AffineFastState.compose env18852 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18853 : List Nat := [2,4,8,16,1,17,24,20,17,5,0,1,24,1,0,3,1,17,5,1,0,0,16,19,8,16,1,0,0,16,21,16,20,16,1,17]

theorem envBound18853 : H12AffineFastState.Bounded env18853 := by
  intro p hp
  have h : env18853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18852_18853 : H12AffineEnvironment.transform 6 24 env18852 = env18853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18852 == env18853) = true)

def leafEnv18853 : List Nat := [2,4,8,16,1,17,24,20,17,5,0,1,24,1,0,3,1,17,5,1,0,0,16,19,20,8,1,16,1,0,0,16,21,16,20,16,5,18,1,17,0,0,1]

def active18853 : List Nat := [0,1,2,3]

def tree18853 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18853 : H12WitnessSearch.Good tree18853 := H12GlobalWitnessIndex.good

theorem leafIdentity18853 : H12AffineFastState.composeSystem env18853 rootObs = leafEnv18853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18853 rootObs == leafEnv18853) = true)

theorem terminalChecked18853 : H12PackedTerminal.terminalCheckFast leafEnv18853 active18853 tree18853 = true := by decide +kernel

def env18854 : List Nat := [2,4,8,16,32,17,128,140,137,157,1,1,128,1,32,65536,1,137,157,33,0,1,16,65704,8,16,0,0,0,136,21,137,140,65674,1,137]

theorem envBound18854 : H12AffineFastState.Bounded env18854 := by
  intro p hp
  have h : env18854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18848_18854 : H12AffineEnvironment.transform 10 1 env18848 = env18854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18848 == env18854) = true)

theorem identity18854 : scanCanonicalize (H12AffineFastState.compose env18854 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound18854 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18855 : List Nat := [2,4,8,16,32,17,128,140,137,157,1,1,128,1,32,19,1,137,157,33,0,1,16,187,8,16,0,0,0,136,21,137,140,153,1,137]

theorem envBound18855 : H12AffineFastState.Bounded env18855 := by
  intro p hp
  have h : env18855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18854_18855 : H12AffineEnvironment.transform 15 19 env18854 = env18855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env18854 == env18855) = true)

def env18856 : List Nat := [2,4,8,16,0,17,128,140,137,157,1,1,128,1,0,19,1,137,157,1,0,1,16,155,8,16,0,0,0,136,21,137,140,153,1,137]

theorem envBound18856 : H12AffineFastState.Bounded env18856 := by
  intro p hp
  have h : env18856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18855_18856 : H12AffineEnvironment.transform 4 0 env18855 = env18856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18855 == env18856) = true)

theorem identity18856 : scanCanonicalize (H12AffineFastState.compose env18856 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18856 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18857 : List Nat := [2,4,8,0,0,1,128,140,137,141,1,1,128,1,0,3,1,137,141,1,0,1,0,139,8,0,0,0,0,136,5,137,140,137,1,137]

theorem envBound18857 : H12AffineFastState.Bounded env18857 := by
  intro p hp
  have h : env18857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18856_18857 : H12AffineEnvironment.transform 3 0 env18856 = env18857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18856 == env18857) = true)

theorem identity18857 : scanCanonicalize (H12AffineFastState.compose env18857 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18858 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,1,8,1,0,3,1,1,5,1,0,1,0,3,8,0,0,0,0,0,5,1,4,1,1,1]

theorem envBound18858 : H12AffineFastState.Bounded env18858 := by
  intro p hp
  have h : env18858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18857_18858 : H12AffineEnvironment.transform 6 8 env18857 = env18858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18857 == env18858) = true)

def leafEnv18858 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,1,8,1,0,3,1,1,5,1,0,1,0,3,4,8,1,0,0,0,0,0,5,1,4,1,5,2,1,1,0,0,1]

def active18858 : List Nat := [0,1,2]

def tree18858 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18858 : H12WitnessSearch.Good tree18858 := H12GlobalWitnessIndex.good

theorem leafIdentity18858 : H12AffineFastState.composeSystem env18858 rootObs = leafEnv18858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18858 rootObs == leafEnv18858) = true)

theorem terminalChecked18858 : H12PackedTerminal.terminalCheckFast leafEnv18858 active18858 tree18858 = true := by decide +kernel

def env18859 : List Nat := [2,4,8,16,1,17,128,140,137,157,1,1,128,1,1,19,1,137,157,0,0,1,16,154,8,16,0,0,0,136,21,137,140,153,1,137]

theorem envBound18859 : H12AffineFastState.Bounded env18859 := by
  intro p hp
  have h : env18859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18855_18859 : H12AffineEnvironment.transform 4 1 env18855 = env18859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18855 == env18859) = true)

def env18860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,4194304,16,16777216,8,16,21069961,1297,1297,21071873,16876544,4194440,256,16777250,1296,512]

theorem envBound18860 : H12AffineFastState.Bounded env18860 := by
  intro p hp
  have h : env18860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18823_18860 : H12AffineEnvironment.transform 29 21071873 env18823 = env18860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071873 env18823 == env18860) = true)

theorem identity18860 : scanCanonicalize (H12AffineFastState.compose env18860 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 4296088) := by decide +kernel

theorem selectedBound18860 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,4194304,16,4296088,8,16,3345,1297,1297,1433,4196760,4194440,256,4296122,1296,512]

theorem envBound18861 : H12AffineFastState.Bounded env18861 := by
  intro p hp
  have h : env18861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18860_18861 : H12AffineEnvironment.transform 23 4296088 env18860 = env18861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4296088 env18860 == env18861) = true)

theorem identity18861 : scanCanonicalize (H12AffineFastState.compose env18861 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33197) := by decide +kernel

theorem selectedBound18861 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,137,1024,32769,1297,33197,16,68661,8,16,3345,1297,1297,1433,34869,33061,256,68631,1296,512]

theorem envBound18862 : H12AffineFastState.Bounded env18862 := by
  intro p hp
  have h : env18862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18861_18862 : H12AffineEnvironment.transform 21 33197 env18861 = env18862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33197 env18861 == env18862) = true)

theorem identity18862 : scanCanonicalize (H12AffineFastState.compose env18862 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 3376) := by decide +kernel

theorem selectedBound18862 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18863 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,3376,65536,1296,137,1024,3377,1297,3229,16,68661,8,16,3345,1297,1297,1433,1285,3093,256,68631,1296,512]

theorem envBound18863 : H12AffineFastState.Bounded env18863 := by
  intro p hp
  have h : env18863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18862_18863 : H12AffineEnvironment.transform 14 3376 env18862 = env18863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3376 env18862 == env18863) = true)

theorem identity18863 : scanCanonicalize (H12AffineFastState.compose env18863 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1724) := by decide +kernel

theorem selectedBound18863 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18864 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1724,1296,128,1296,908,65536,1296,137,1024,909,1297,545,16,66185,8,16,941,1297,1297,1433,1285,681,256,66219,1296,512]

theorem envBound18864 : H12AffineFastState.Bounded env18864 := by
  intro p hp
  have h : env18864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18863_18864 : H12AffineEnvironment.transform 10 1724 env18863 = env18864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1724 env18863 == env18864) = true)

theorem identity18864 : scanCanonicalize (H12AffineFastState.compose env18864 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18864 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18865 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1589,1296,9,1296,773,65536,1296,0,1024,772,1297,545,16,66048,8,16,804,1297,1297,1296,1285,544,256,66082,1296,512]

theorem envBound18865 : H12AffineFastState.Bounded env18865 := by
  intro p hp
  have h : env18865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18864_18865 : H12AffineEnvironment.transform 6 9 env18864 = env18865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18864 == env18865) = true)

theorem identity18865 : scanCanonicalize (H12AffineFastState.compose env18865 (packedSelected [1,13] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18865 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env18866 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1589,1296,9,1296,773,35,1296,0,1024,772,1297,545,16,547,8,16,804,1297,1297,1296,1285,544,256,513,1296,512]

theorem envBound18866 : H12AffineFastState.Bounded env18866 := by
  intro p hp
  have h : env18866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18865_18866 : H12AffineEnvironment.transform 15 35 env18865 = env18866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18865 == env18866) = true)

theorem identity18866 : scanCanonicalize (H12AffineFastState.compose env18866 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18866 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env18867 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1077,1296,9,1296,261,35,1296,0,1024,260,1297,33,16,35,8,16,292,1297,1297,1296,1285,32,256,1,1296,0]

theorem envBound18867 : H12AffineFastState.Bounded env18867 := by
  intro p hp
  have h : env18867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18866_18867 : H12AffineEnvironment.transform 8 0 env18866 = env18867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18866 == env18867) = true)

theorem identity18867 : scanCanonicalize (H12AffineFastState.compose env18867 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound18867 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18868 : List Nat := [2,4,8,16,32,17,9,256,0,257,308,17,9,17,261,35,17,0,257,260,16,33,16,35,8,16,292,16,16,17,4,32,256,1,17,0]

theorem envBound18868 : H12AffineFastState.Bounded env18868 := by
  intro p hp
  have h : env18868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18867_18868 : H12AffineEnvironment.transform 9 257 env18867 = env18868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env18867 == env18868) = true)

theorem identity18868 : scanCanonicalize (H12AffineFastState.compose env18868 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound18868 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18869 : List Nat := [2,4,8,16,32,17,9,53,0,52,1,17,9,17,48,35,17,0,52,49,16,33,16,35,8,16,17,16,16,17,4,32,53,1,17,0]

theorem envBound18869 : H12AffineFastState.Bounded env18869 := by
  intro p hp
  have h : env18869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18868_18869 : H12AffineEnvironment.transform 7 53 env18868 = env18869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env18868 == env18869) = true)

def env18870 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,9,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound18870 : H12AffineFastState.Bounded env18870 := by
  intro p hp
  have h : env18870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18821_18870 : H12AffineEnvironment.transform 12 129 env18821 = env18870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18821 == env18870) = true)

theorem identity18870 : scanCanonicalize (H12AffineFastState.compose env18870 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 360844) := by decide +kernel

theorem selectedBound18870 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18871 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,360844,9,16,4194700,1297,1297,1073741824,263564,4194440,256,360878,1296,512]

theorem envBound18871 : H12AffineFastState.Bounded env18871 := by
  intro p hp
  have h : env18871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18870_18871 : H12AffineEnvironment.transform 23 360844 env18870 = env18871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 360844 env18870 == env18871) = true)

def env18872 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,1,4194304,16,360844,9,16,4194700,1,1,1073741824,262300,4194440,256,360878,0,512]

theorem envBound18872 : H12AffineFastState.Bounded env18872 := by
  intro p hp
  have h : env18872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18871_18872 : H12AffineEnvironment.transform 9 272 env18871 = env18872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18871 == env18872) = true)

theorem identity18872 : scanCanonicalize (H12AffineFastState.compose env18872 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 2445) := by decide +kernel

theorem selectedBound18872 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18873 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,1,2445,16,360844,9,16,2049,1,1,1073741824,262300,2309,256,360878,0,512]

theorem envBound18873 : H12AffineFastState.Bounded env18873 := by
  intro p hp
  have h : env18873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18872_18873 : H12AffineEnvironment.transform 21 2445 env18872 = env18873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2445 env18872 == env18873) = true)

theorem identity18873 : scanCanonicalize (H12AffineFastState.compose env18873 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound18873 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18874 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2081,65536,0,262144,272,2080,1,2445,16,330157,9,16,2049,1,1,1073741824,262300,2309,256,330127,0,512]

theorem envBound18874 : H12AffineFastState.Bounded env18874 := by
  intro p hp
  have h : env18874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18873_18874 : H12AffineEnvironment.transform 14 2081 env18873 = env18874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env18873 == env18874) = true)

theorem identity18874 : scanCanonicalize (H12AffineFastState.compose env18874 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 137) := by decide +kernel

theorem selectedBound18874 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18875 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2081,65536,0,262144,272,2080,1,2445,16,330157,9,16,2049,1,1,137,262300,2309,256,330127,0,512]

theorem envBound18875 : H12AffineFastState.Bounded env18875 := by
  intro p hp
  have h : env18875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18874_18875 : H12AffineEnvironment.transform 29 137 env18874 = env18875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 137 env18874 == env18875) = true)

theorem identity18875 : scanCanonicalize (H12AffineFastState.compose env18875 (packedSelected [0,7,15] rootPS)) = affineNative (2^(17+1) ^^^ 136) := by decide +kernel

theorem selectedBound18875 : packedSelected [0,7,15] rootPS < 2^1333 := by decide +kernel

def env18876 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2081,65536,0,136,272,2080,1,2445,16,67877,9,16,2049,1,1,137,20,2309,256,67847,0,512]

theorem envBound18876 : H12AffineFastState.Bounded env18876 := by
  intro p hp
  have h : env18876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18875_18876 : H12AffineEnvironment.transform 17 136 env18875 = env18876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 136 env18875 == env18876) = true)

theorem identity18876 : scanCanonicalize (H12AffineFastState.compose env18876 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound18876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18877 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2081,2730,0,136,272,2080,1,2445,16,911,9,16,2049,1,1,137,20,2309,256,941,0,512]

theorem envBound18877 : H12AffineFastState.Bounded env18877 := by
  intro p hp
  have h : env18877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18876_18877 : H12AffineEnvironment.transform 15 2730 env18876 = env18877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env18876 == env18877) = true)

theorem identity18877 : scanCanonicalize (H12AffineFastState.compose env18877 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18877 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18878 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,129,0,2081,2083,0,136,272,2080,1,2445,16,262,9,16,2049,1,1,137,20,2309,256,292,0,137]

theorem envBound18878 : H12AffineFastState.Bounded env18878 := by
  intro p hp
  have h : env18878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18877_18878 : H12AffineEnvironment.transform 8 137 env18877 = env18878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18877 == env18878) = true)

def env18879 : List Nat := [2,4,8,16,32,17,128,256,137,272,168,0,129,0,137,139,0,136,272,136,1,293,16,262,9,16,169,1,1,137,20,429,256,292,0,137]

theorem envBound18879 : H12AffineFastState.Bounded env18879 := by
  intro p hp
  have h : env18879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18878_18879 : H12AffineEnvironment.transform 10 168 env18878 = env18879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env18878 == env18879) = true)

theorem identity18879 : scanCanonicalize (H12AffineFastState.compose env18879 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18880 : List Nat := [2,4,8,16,32,17,24,256,17,272,48,0,25,0,17,19,0,16,272,16,1,293,16,262,9,16,49,1,1,17,20,309,256,292,0,17]

theorem envBound18880 : H12AffineFastState.Bounded env18880 := by
  intro p hp
  have h : env18880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2