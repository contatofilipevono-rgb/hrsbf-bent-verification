import H12CloudChart2Data195

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity49269 : scanCanonicalize (H12AffineFastState.compose env49269 (packedSelected [0,3,5,7,8,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49269 : packedSelected [0,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env49270 : List Nat := [2,4,2,16,22,64,66,256,65,321,16,276,66,80,277,20,325,86,85,276,277,1,341,5,278,16,259,276,81,338,68,64,256,261,0,340]

theorem envBound49270 : H12AffineFastState.Bounded env49270 := by
  intro p hp
  have h : env49270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49269_49270 : H12AffineEnvironment.transform 2 2 env49269 = env49270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49269 == env49270) = true)

theorem identity49270 : scanCanonicalize (H12AffineFastState.compose env49270 (packedSelected [0,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49270 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env49271 : List Nat := [2,4,2,16,22,64,66,84,65,21,16,64,66,80,65,20,17,86,85,64,65,1,1,5,66,16,87,64,81,6,68,64,84,81,0,0]

theorem envBound49271 : H12AffineFastState.Bounded env49271 := by
  intro p hp
  have h : env49271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49270_49271 : H12AffineEnvironment.transform 7 84 env49270 = env49271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49270 == env49271) = true)

theorem identity49271 : scanCanonicalize (H12AffineFastState.compose env49271 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49271 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49272 : List Nat := [2,4,2,0,6,64,66,68,65,5,0,64,66,64,65,4,1,70,69,64,65,1,1,5,66,0,71,64,65,6,68,64,68,65,0,0]

theorem envBound49272 : H12AffineFastState.Bounded env49272 := by
  intro p hp
  have h : env49272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49271_49272 : H12AffineEnvironment.transform 3 0 env49271 = env49272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49271 == env49272) = true)

theorem identity49272 : scanCanonicalize (H12AffineFastState.compose env49272 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound49272 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49273 : List Nat := [2,4,2,0,6,6,4,2,7,5,0,6,4,6,7,4,1,0,3,6,7,1,1,5,4,0,1,6,7,6,2,6,2,7,0,0]

theorem envBound49273 : H12AffineFastState.Bounded env49273 := by
  intro p hp
  have h : env49273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49272_49273 : H12AffineEnvironment.transform 5 6 env49272 = env49273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env49272 == env49273) = true)

theorem identity49273 : scanCanonicalize (H12AffineFastState.compose env49273 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49274 : List Nat := [2,3,2,0,1,1,3,2,0,2,0,1,3,1,0,3,1,0,3,1,0,1,1,2,3,0,1,1,0,1,2,1,2,0,0,0]

theorem envBound49274 : H12AffineFastState.Bounded env49274 := by
  intro p hp
  have h : env49274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49273_49274 : H12AffineEnvironment.transform 1 3 env49273 = env49274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49273 == env49274) = true)

def env49275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1297,277,65536,66598,65664,1876,276,1556,649,65911,66896,916,66162,1150,66679,1296,68374,68,1281,256,65831,1345,341]

theorem envBound49275 : H12AffineFastState.Bounded env49275 := by
  intro p hp
  have h : env49275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49252_49275 : H12AffineEnvironment.transform 11 1557 env49252 = env49275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env49252 == env49275) = true)

def env49276 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,81,277,65536,65894,65664,532,276,852,649,65911,65552,916,66162,318,65847,80,68374,68,65,256,65831,1,341]

theorem envBound49276 : H12AffineFastState.Bounded env49276 := by
  intro p hp
  have h : env49276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49275_49276 : H12AffineEnvironment.transform 9 320 env49275 = env49276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49275 == env49276) = true)

theorem identity49276 : scanCanonicalize (H12AffineFastState.compose env49276 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound49276 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49277 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,576,72,81,0,65536,65651,65664,532,1,577,649,65634,65552,641,66162,43,65570,80,68099,68,65,21,65586,1,64]

theorem envBound49277 : H12AffineFastState.Bounded env49277 := by
  intro p hp
  have h : env49277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49276_49277 : H12AffineEnvironment.transform 7 21 env49276 = env49277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env49276 == env49277) = true)

theorem identity49277 : scanCanonicalize (H12AffineFastState.compose env49277 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 610) := by decide +kernel

theorem selectedBound49277 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49278 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,576,72,81,0,610,529,738,532,1,577,649,512,626,641,16,43,576,80,2145,68,65,21,592,1,64]

theorem envBound49278 : H12AffineFastState.Bounded env49278 := by
  intro p hp
  have h : env49278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49277_49278 : H12AffineEnvironment.transform 15 610 env49277 = env49278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 610 env49277 == env49278) = true)

theorem identity49278 : scanCanonicalize (H12AffineFastState.compose env49278 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound49278 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49279 : List Nat := [2,4,8,16,32,64,128,21,512,85,659,576,72,81,0,610,529,738,532,1,577,649,512,626,641,16,43,576,80,754,68,65,21,592,1,64]

theorem envBound49279 : H12AffineFastState.Bounded env49279 := by
  intro p hp
  have h : env49279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49278_49279 : H12AffineEnvironment.transform 10 659 env49278 = env49279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env49278 == env49279) = true)

theorem identity49279 : scanCanonicalize (H12AffineFastState.compose env49279 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound49279 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49280 : List Nat := [2,4,8,16,32,64,128,21,64,85,211,0,72,81,0,34,81,162,84,1,1,201,64,50,193,16,43,0,80,178,68,65,21,16,1,64]

theorem envBound49280 : H12AffineFastState.Bounded env49280 := by
  intro p hp
  have h : env49280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49279_49280 : H12AffineEnvironment.transform 8 64 env49279 = env49280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env49279 == env49280) = true)

theorem identity49280 : scanCanonicalize (H12AffineFastState.compose env49280 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49280 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49281 : List Nat := [2,4,8,16,32,64,88,21,64,85,11,0,72,81,0,34,81,122,84,1,1,17,64,50,25,16,43,0,80,106,68,65,21,16,1,64]

theorem envBound49281 : H12AffineFastState.Bounded env49281 := by
  intro p hp
  have h : env49281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49280_49281 : H12AffineEnvironment.transform 6 88 env49280 = env49281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49280 == env49281) = true)

theorem identity49281 : scanCanonicalize (H12AffineFastState.compose env49281 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49282 : List Nat := [2,4,8,16,32,10,18,21,10,31,11,0,2,27,0,34,27,48,30,1,1,17,10,50,25,16,43,0,26,32,14,11,21,16,1,10]

theorem envBound49282 : H12AffineFastState.Bounded env49282 := by
  intro p hp
  have h : env49282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49281_49282 : H12AffineEnvironment.transform 5 10 env49281 = env49282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49281 == env49282) = true)

theorem identity49282 : scanCanonicalize (H12AffineFastState.compose env49282 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49282 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49283 : List Nat := [2,4,5,16,32,7,18,21,7,18,6,0,2,22,0,34,22,48,19,1,1,17,7,50,20,16,38,0,23,32,3,6,21,16,1,7]

theorem envBound49283 : H12AffineFastState.Bounded env49283 := by
  intro p hp
  have h : env49283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49282_49283 : H12AffineEnvironment.transform 2 5 env49282 = env49283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49282 == env49283) = true)

theorem identity49283 : scanCanonicalize (H12AffineFastState.compose env49283 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49283 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env49284 : List Nat := [2,4,5,16,16,7,18,21,7,18,6,0,2,22,0,18,22,0,19,1,1,17,7,2,20,16,22,0,23,16,3,6,21,16,1,7]

theorem envBound49284 : H12AffineFastState.Bounded env49284 := by
  intro p hp
  have h : env49284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49283_49284 : H12AffineEnvironment.transform 4 16 env49283 = env49284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49283 == env49284) = true)

theorem identity49284 : scanCanonicalize (H12AffineFastState.compose env49284 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49285 : List Nat := [2,4,5,6,6,7,4,3,7,4,6,0,2,0,0,4,0,0,5,1,1,7,7,2,2,6,0,0,1,6,3,6,3,6,1,7]

theorem envBound49285 : H12AffineFastState.Bounded env49285 := by
  intro p hp
  have h : env49285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49284_49285 : H12AffineEnvironment.transform 3 6 env49284 = env49285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49284 == env49285) = true)

def env49286 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,80,277,65536,65895,65664,533,276,853,649,65911,65553,916,66162,319,65846,81,68374,68,64,256,65831,0,341]

theorem envBound49286 : H12AffineFastState.Bounded env49286 := by
  intro p hp
  have h : env49286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49275_49286 : H12AffineEnvironment.transform 9 321 env49275 = env49286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49275 == env49286) = true)

theorem identity49286 : scanCanonicalize (H12AffineFastState.compose env49286 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound49286 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49287 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,276,72,80,277,65536,65895,65664,85,276,277,201,65911,65553,468,65586,319,65846,81,67926,68,64,256,65831,0,341]

theorem envBound49287 : H12AffineFastState.Bounded env49287 := by
  intro p hp
  have h : env49287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49286_49287 : H12AffineEnvironment.transform 8 64 env49286 = env49287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env49286 == env49287) = true)

theorem identity49287 : scanCanonicalize (H12AffineFastState.compose env49287 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49287 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env49288 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,276,72,80,277,34,325,162,85,276,277,201,341,51,468,16,319,276,81,2420,68,64,256,261,0,341]

theorem envBound49288 : H12AffineFastState.Bounded env49288 := by
  intro p hp
  have h : env49288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49287_49288 : H12AffineEnvironment.transform 15 34 env49287 = env49288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49287 == env49288) = true)

theorem identity49288 : scanCanonicalize (H12AffineFastState.compose env49288 (packedSelected [0,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound49288 : packedSelected [0,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env49289 : List Nat := [2,4,8,16,32,64,128,256,64,321,191,276,72,80,277,34,325,162,85,276,277,201,341,51,468,16,319,276,81,459,68,64,256,261,0,341]

theorem envBound49289 : H12AffineFastState.Bounded env49289 := by
  intro p hp
  have h : env49289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49288_49289 : H12AffineEnvironment.transform 10 191 env49288 = env49289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env49288 == env49289) = true)

theorem identity49289 : scanCanonicalize (H12AffineFastState.compose env49289 (packedSelected [8,11,12,15,20] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound49289 : packedSelected [8,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env49290 : List Nat := [2,4,8,16,32,64,73,256,64,321,118,276,72,80,277,34,325,107,85,276,277,0,341,51,285,16,319,276,81,258,68,64,256,261,0,341]

theorem envBound49290 : H12AffineFastState.Bounded env49290 := by
  intro p hp
  have h : env49290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49289_49290 : H12AffineEnvironment.transform 6 73 env49289 = env49290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env49289 == env49290) = true)

theorem identity49290 : scanCanonicalize (H12AffineFastState.compose env49290 (packedSelected [1,2,13] rootPS)) = affineNative (2^(7+1) ^^^ 121) := by decide +kernel

theorem selectedBound49290 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env49291 : List Nat := [2,4,8,16,32,64,73,121,64,56,118,109,72,80,108,34,60,107,85,109,108,0,44,51,100,16,70,109,81,123,68,64,121,124,0,44]

theorem envBound49291 : H12AffineFastState.Bounded env49291 := by
  intro p hp
  have h : env49291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49290_49291 : H12AffineEnvironment.transform 7 121 env49290 = env49291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 121 env49290 == env49291) = true)

theorem identity49291 : scanCanonicalize (H12AffineFastState.compose env49291 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound49291 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49292 : List Nat := [2,4,8,16,32,26,19,35,26,56,44,55,18,10,54,34,60,49,15,55,54,0,44,51,62,16,28,55,11,33,30,26,35,38,0,44]

theorem envBound49292 : H12AffineFastState.Bounded env49292 := by
  intro p hp
  have h : env49292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49291_49292 : H12AffineEnvironment.transform 5 26 env49291 = env49292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env49291 == env49292) = true)

theorem identity49292 : scanCanonicalize (H12AffineFastState.compose env49292 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49292 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env49293 : List Nat := [2,4,8,16,0,26,19,3,26,24,12,23,18,10,22,2,28,17,15,23,22,0,12,19,30,16,28,23,11,1,30,26,3,6,0,12]

theorem envBound49293 : H12AffineFastState.Bounded env49293 := by
  intro p hp
  have h : env49293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49292_49293 : H12AffineEnvironment.transform 4 0 env49292 = env49293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49292 == env49293) = true)

theorem identity49293 : scanCanonicalize (H12AffineFastState.compose env49293 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49293 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49294 : List Nat := [2,4,8,10,0,0,9,3,0,2,12,13,8,10,12,2,6,11,15,13,12,0,12,9,4,10,6,13,11,1,4,0,3,6,0,12]

theorem envBound49294 : H12AffineFastState.Bounded env49294 := by
  intro p hp
  have h : env49294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49293_49294 : H12AffineEnvironment.transform 3 10 env49293 = env49294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49293 == env49294) = true)

theorem identity49294 : scanCanonicalize (H12AffineFastState.compose env49294 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49295 : List Nat := [2,4,3,1,0,0,2,3,0,2,7,6,3,1,7,2,6,0,4,6,7,0,7,2,4,1,6,6,0,1,4,0,3,6,0,7]

theorem envBound49295 : H12AffineFastState.Bounded env49295 := by
  intro p hp
  have h : env49295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49294_49295 : H12AffineEnvironment.transform 2 3 env49294 = env49295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49294 == env49295) = true)

def env49296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4097,5276,74047,66896,13769,78895,1151,74815,1296,81227,8204,1281,256,65831,1345,5952]

theorem envBound49296 : H12AffineFastState.Bounded env49296 := by
  intro p hp
  have h : env49296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49250_49296 : H12AffineEnvironment.transform 17 65665 env49250 = env49296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49250 == env49296) = true)

theorem identity49296 : scanCanonicalize (H12AffineFastState.compose env49296 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound49296 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,65536,69991,65665,4417,5205,4097,5276,70710,66896,192,65830,1151,69942,1296,67650,5381,1281,256,65831,1345,5952]

theorem envBound49297 : H12AffineFastState.Bounded env49297 := by
  intro p hp
  have h : env49297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49296_49297 : H12AffineEnvironment.transform 12 5385 env49296 = env49297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env49296 == env49297) = true)

def env49298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1297,576,65536,67443,65665,1877,577,1557,648,66082,66896,192,65830,1151,67362,1296,67650,785,1281,256,65831,1345,340]

theorem envBound49298 : H12AffineFastState.Bounded env49298 := by
  intro p hp
  have h : env49298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49297_49298 : H12AffineEnvironment.transform 11 1556 env49297 = env49298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env49297 == env49298) = true)

def env49299 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,65,576,65536,66083,65665,517,577,837,648,66082,65536,192,65830,303,66162,64,67650,785,81,256,65831,17,340]

theorem envBound49299 : H12AffineFastState.Bounded env49299 := by
  intro p hp
  have h : env49299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49298_49299 : H12AffineEnvironment.transform 9 336 env49298 = env49299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env49298 == env49299) = true)

theorem identity49299 : scanCanonicalize (H12AffineFastState.compose env49299 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 946) := by decide +kernel

theorem selectedBound49299 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49300 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,65,576,946,401,819,517,577,837,648,400,946,192,660,303,448,64,3056,785,81,256,661,17,340]

theorem envBound49300 : H12AffineFastState.Bounded env49300 := by
  intro p hp
  have h : env49300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49299_49300 : H12AffineEnvironment.transform 15 946 env49299 = env49300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 946 env49299 == env49300) = true)

def env49301 : List Nat := [2,4,8,16,32,64,128,256,196,336,2048,384,473,65,132,374,401,503,193,133,385,76,400,374,192,80,303,448,64,2356,469,81,256,81,17,340]

theorem envBound49301 : H12AffineFastState.Bounded env49301 := by
  intro p hp
  have h : env49301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49300_49301 : H12AffineEnvironment.transform 8 196 env49300 = env49301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 196 env49300 == env49301) = true)

theorem identity49301 : scanCanonicalize (H12AffineFastState.compose env49301 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound49301 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49302 : List Nat := [2,4,8,16,32,64,68,256,0,336,2048,324,285,65,64,374,341,307,5,65,325,76,340,374,4,80,303,260,64,2356,273,81,256,81,17,340]

theorem envBound49302 : H12AffineFastState.Bounded env49302 := by
  intro p hp
  have h : env49302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49301_49302 : H12AffineEnvironment.transform 6 68 env49301 = env49302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env49301 == env49302) = true)

theorem identity49302 : scanCanonicalize (H12AffineFastState.compose env49302 (packedSelected [1,3,5,8,10,11,12,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound49302 : packedSelected [1,3,5,8,10,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env49303 : List Nat := [2,4,8,16,32,64,68,256,0,336,97,324,285,65,64,374,341,307,5,65,325,76,340,374,4,80,303,260,64,341,273,81,256,81,17,340]

theorem envBound49303 : H12AffineFastState.Bounded env49303 := by
  intro p hp
  have h : env49303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49302_49303 : H12AffineEnvironment.transform 10 97 env49302 = env49303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env49302 == env49303) = true)

theorem identity49303 : scanCanonicalize (H12AffineFastState.compose env49303 (packedSelected [1,3,4,5,8,9,10,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49303 : packedSelected [1,3,4,5,8,9,10,15,16,19] rootPS < 2^1333 := by decide +kernel

def env49304 : List Nat := [2,4,8,16,32,64,68,36,0,116,97,96,57,65,64,82,113,23,5,65,97,76,112,82,4,80,11,32,64,113,53,81,36,81,17,112]

theorem envBound49304 : H12AffineFastState.Bounded env49304 := by
  intro p hp
  have h : env49304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49303_49304 : H12AffineEnvironment.transform 7 36 env49303 = env49304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49303 == env49304) = true)

theorem identity49304 : scanCanonicalize (H12AffineFastState.compose env49304 (packedSelected [1,2,12] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound49304 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env49305 : List Nat := [2,4,8,12,32,64,68,36,0,104,97,96,37,65,64,78,109,11,5,65,97,76,108,78,4,76,11,32,64,109,41,77,36,77,13,108]

theorem envBound49305 : H12AffineFastState.Bounded env49305 := by
  intro p hp
  have h : env49305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49304_49305 : H12AffineEnvironment.transform 3 12 env49304 = env49305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env49304 == env49305) = true)

theorem identity49305 : scanCanonicalize (H12AffineFastState.compose env49305 (packedSelected [2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49305 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49306 : List Nat := [2,2,8,10,32,64,66,34,0,104,97,96,35,65,64,72,107,11,3,65,97,74,106,72,2,74,11,32,64,107,41,75,34,75,11,106]

theorem envBound49306 : H12AffineFastState.Bounded env49306 := by
  intro p hp
  have h : env49306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49305_49306 : H12AffineEnvironment.transform 1 2 env49305 = env49306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49305 == env49306) = true)

def env49307 : List Nat := [2,4,8,16,32,64,128,256,197,336,2048,385,472,65,133,375,401,502,192,132,384,77,400,375,192,81,303,448,64,2357,468,81,256,80,17,340]

theorem envBound49307 : H12AffineFastState.Bounded env49307 := by
  intro p hp
  have h : env49307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49300_49307 : H12AffineEnvironment.transform 8 197 env49300 = env49307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 197 env49300 == env49307) = true)

theorem identity49307 : scanCanonicalize (H12AffineFastState.compose env49307 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49307 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49308 : List Nat := [2,4,8,16,32,1,128,256,132,273,2048,385,409,0,133,310,401,439,129,132,384,12,400,310,129,16,303,385,1,2357,405,16,256,17,17,277]

theorem envBound49308 : H12AffineFastState.Bounded env49308 := by
  intro p hp
  have h : env49308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49307_49308 : H12AffineEnvironment.transform 5 1 env49307 = env49308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49307 == env49308) = true)

theorem identity49308 : scanCanonicalize (H12AffineFastState.compose env49308 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49308 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49309 : List Nat := [2,4,8,16,32,1,128,20,132,5,2048,149,141,0,133,34,133,163,129,132,148,12,132,34,129,16,59,149,1,2081,129,16,20,17,17,1]

theorem envBound49309 : H12AffineFastState.Bounded env49309 := by
  intro p hp
  have h : env49309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49308_49309 : H12AffineEnvironment.transform 7 20 env49308 = env49309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49308 == env49309) = true)

theorem identity49309 : scanCanonicalize (H12AffineFastState.compose env49309 (packedSelected [1,2,3,5,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49309 : packedSelected [1,2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49310 : List Nat := [2,4,8,16,12,1,128,20,132,5,2048,149,141,0,133,14,133,143,129,132,148,12,132,14,129,16,23,149,1,2061,129,16,20,17,17,1]

theorem envBound49310 : H12AffineFastState.Bounded env49310 := by
  intro p hp
  have h : env49310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49309_49310 : H12AffineEnvironment.transform 4 12 env49309 = env49310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49309 == env49310) = true)

theorem identity49310 : scanCanonicalize (H12AffineFastState.compose env49310 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound49310 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49311 : List Nat := [2,4,8,16,12,1,2,20,6,5,2048,23,15,0,7,14,7,13,3,6,22,12,6,14,3,16,23,23,1,2061,3,16,20,17,17,1]

theorem envBound49311 : H12AffineFastState.Bounded env49311 := by
  intro p hp
  have h : env49311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49310_49311 : H12AffineEnvironment.transform 6 2 env49310 = env49311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env49310 == env49311) = true)

theorem identity49311 : scanCanonicalize (H12AffineFastState.compose env49311 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49311 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env49312 : List Nat := [2,4,8,1,12,1,2,5,6,5,2048,6,15,0,7,14,7,13,3,6,7,12,6,14,3,1,6,6,1,2061,3,1,5,0,0,1]

theorem envBound49312 : H12AffineFastState.Bounded env49312 := by
  intro p hp
  have h : env49312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49311_49312 : H12AffineEnvironment.transform 3 1 env49311 = env49312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49311 == env49312) = true)

theorem identity49312 : scanCanonicalize (H12AffineFastState.compose env49312 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound49312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49313 : List Nat := [2,4,8,1,12,1,2,5,6,5,10,6,15,0,7,14,7,13,3,6,7,12,6,14,3,1,6,6,1,7,3,1,5,0,0,1]

theorem envBound49313 : H12AffineFastState.Bounded env49313 := by
  intro p hp
  have h : env49313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49312_49313 : H12AffineEnvironment.transform 10 10 env49312 = env49313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env49312 == env49313) = true)

theorem identity49313 : scanCanonicalize (H12AffineFastState.compose env49313 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49313 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49314 : List Nat := [2,4,4,1,0,1,2,5,6,5,6,6,3,0,7,2,7,1,3,6,7,0,6,2,3,1,6,6,1,7,3,1,5,0,0,1]

theorem envBound49314 : H12AffineFastState.Bounded env49314 := by
  intro p hp
  have h : env49314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49313_49314 : H12AffineEnvironment.transform 2 4 env49313 = env49314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49313 == env49314) = true)

theorem identity49314 : scanCanonicalize (H12AffineFastState.compose env49314 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49315 : List Nat := [2,2,2,1,0,1,2,3,0,3,0,0,3,0,1,2,1,1,3,0,1,0,0,2,3,1,0,0,1,1,3,1,3,0,0,1]

theorem envBound49315 : H12AffineFastState.Bounded env49315 := by
  intro p hp
  have h : env49315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49314_49315 : H12AffineEnvironment.transform 1 2 env49314 = env49315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49314 == env49315) = true)

theorem identity49315 : scanCanonicalize (H12AffineFastState.compose env49315 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49316 : List Nat := [0,0,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,1,1,0,1,0,0,0,1,1,0,0,1,1,1,1,1,0,0,1]

theorem envBound49316 : H12AffineFastState.Bounded env49316 := by
  intro p hp
  have h : env49316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49315_49316 : H12AffineEnvironment.transform 0 0 env49315 = env49316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49315 == env49316) = true)

def env49317 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,64,576,65536,66082,65665,516,577,836,648,66082,65537,192,65830,302,66163,65,67650,785,80,256,65831,16,340]

theorem envBound49317 : H12AffineFastState.Bounded env49317 := by
  intro p hp
  have h : env49317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49298_49317 : H12AffineEnvironment.transform 9 337 env49298 = env49317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env49298 == env49317) = true)

theorem identity49317 : scanCanonicalize (H12AffineFastState.compose env49317 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 247) := by decide +kernel

theorem selectedBound49317 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49318 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,64,576,247,725,118,516,577,836,648,725,246,192,465,302,644,65,2229,785,80,256,464,16,340]

theorem envBound49318 : H12AffineFastState.Bounded env49318 := by
  intro p hp
  have h : env49318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49317_49318 : H12AffineEnvironment.transform 15 247 env49317 = env49318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 247 env49317 == env49318) = true)

def env49319 : List Nat := [2,4,8,16,32,64,128,256,148,337,2048,465,393,64,212,247,65,118,144,213,464,28,65,246,192,465,302,16,65,2229,389,80,256,464,16,340]

theorem envBound49319 : H12AffineFastState.Bounded env49319 := by
  intro p hp
  have h : env49319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49318_49319 : H12AffineEnvironment.transform 8 148 env49318 = env49319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env49318 == env49319) = true)

theorem identity49319 : scanCanonicalize (H12AffineFastState.compose env49319 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49319 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49320 : List Nat := [2,4,8,16,32,64,128,20,148,69,2048,197,157,64,212,247,65,118,144,213,196,28,65,246,192,197,58,16,65,2229,145,80,20,196,16,64]

theorem envBound49320 : H12AffineFastState.Bounded env49320 := by
  intro p hp
  have h : env49320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49319_49320 : H12AffineEnvironment.transform 7 20 env49319 = env49320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49319 == env49320) = true)

theorem identity49320 : scanCanonicalize (H12AffineFastState.compose env49320 (packedSelected [0,2,3,5,7,8,11,13,17,18,19,20] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49320 : packedSelected [0,2,3,5,7,8,11,13,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env49321 : List Nat := [2,4,8,16,17,64,128,20,148,69,2048,197,157,64,212,198,65,71,144,213,196,28,65,199,192,197,11,16,65,2180,145,80,20,196,16,64]

theorem envBound49321 : H12AffineFastState.Bounded env49321 := by
  intro p hp
  have h : env49321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49320_49321 : H12AffineEnvironment.transform 4 17 env49320 = env49321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49320 == env49321) = true)

theorem identity49321 : scanCanonicalize (H12AffineFastState.compose env49321 (packedSelected [1,5,8,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 206) := by decide +kernel

theorem selectedBound49321 : packedSelected [1,5,8,17,19] rootPS < 2^1333 := by decide +kernel

def env49322 : List Nat := [2,4,8,16,17,64,128,20,148,69,206,197,157,64,212,198,65,71,144,213,196,28,65,199,192,197,11,16,65,74,145,80,20,196,16,64]

theorem envBound49322 : H12AffineFastState.Bounded env49322 := by
  intro p hp
  have h : env49322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49321_49322 : H12AffineEnvironment.transform 10 206 env49321 = env49322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 206 env49321 == env49322) = true)

theorem identity49322 : scanCanonicalize (H12AffineFastState.compose env49322 (packedSelected [0,1,3,4,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound49322 : packedSelected [0,1,3,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env49323 : List Nat := [2,4,8,16,17,64,14,20,26,69,64,75,19,64,90,72,65,71,30,91,74,28,65,73,78,75,11,16,65,74,31,80,20,74,16,64]

theorem envBound49323 : H12AffineFastState.Bounded env49323 := by
  intro p hp
  have h : env49323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49322_49323 : H12AffineEnvironment.transform 6 14 env49322 = env49323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env49322 == env49323) = true)

theorem identity49323 : scanCanonicalize (H12AffineFastState.compose env49323 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49323 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env49324 : List Nat := [2,4,8,16,17,17,14,20,26,20,17,26,19,17,11,25,16,22,30,10,27,28,16,24,31,26,11,16,16,27,31,1,20,27,16,17]

theorem envBound49324 : H12AffineFastState.Bounded env49324 := by
  intro p hp
  have h : env49324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49323_49324 : H12AffineEnvironment.transform 5 17 env49323 = env49324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49323 == env49324) = true)

theorem identity49324 : scanCanonicalize (H12AffineFastState.compose env49324 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound49324 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49325 : List Nat := [2,4,8,13,12,12,14,9,7,9,12,7,14,12,11,4,13,11,3,10,6,1,13,5,2,7,11,13,13,6,2,1,9,6,13,12]

theorem envBound49325 : H12AffineFastState.Bounded env49325 := by
  intro p hp
  have h : env49325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49324_49325 : H12AffineEnvironment.transform 3 13 env49324 = env49325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env49324 == env49325) = true)

theorem identity49325 : scanCanonicalize (H12AffineFastState.compose env49325 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49326 : List Nat := [2,2,8,11,10,10,8,9,1,9,10,1,8,10,11,2,11,11,3,10,0,1,11,3,2,1,11,11,11,0,2,1,9,0,11,10]

theorem envBound49326 : H12AffineFastState.Bounded env49326 := by
  intro p hp
  have h : env49326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49325_49326 : H12AffineEnvironment.transform 1 2 env49325 = env49326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49325 == env49326) = true)

theorem identity49326 : scanCanonicalize (H12AffineFastState.compose env49326 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49327 : List Nat := [2,2,2,1,0,0,2,3,1,3,0,1,2,0,1,2,1,1,3,0,0,1,1,3,2,1,1,1,1,0,2,1,3,0,1,0]

theorem envBound49327 : H12AffineFastState.Bounded env49327 := by
  intro p hp
  have h : env49327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49326_49327 : H12AffineEnvironment.transform 2 2 env49326 = env49327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49326 == env49327) = true)

theorem identity49327 : scanCanonicalize (H12AffineFastState.compose env49327 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49328 : List Nat := [1,1,1,1,0,0,1,0,1,0,0,1,1,0,1,1,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,1,0,0,1,0]

theorem envBound49328 : H12AffineFastState.Bounded env49328 := by
  intro p hp
  have h : env49328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49327_49328 : H12AffineEnvironment.transform 0 1 env49327 = env49328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49327 == env49328) = true)

def env49329 : List Nat := [2,4,8,16,32,64,128,256,149,337,2048,464,392,64,213,247,64,118,145,212,465,29,64,246,192,465,302,17,65,2229,388,80,256,464,16,340]

theorem envBound49329 : H12AffineFastState.Bounded env49329 := by
  intro p hp
  have h : env49329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49318_49329 : H12AffineEnvironment.transform 8 149 env49318 = env49329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env49318 == env49329) = true)

theorem identity49329 : scanCanonicalize (H12AffineFastState.compose env49329 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound49329 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49330 : List Nat := [2,4,8,16,32,64,85,256,64,337,2048,261,349,64,0,34,64,118,68,1,260,29,64,35,21,260,302,17,65,2144,337,80,256,261,16,340]

theorem envBound49330 : H12AffineFastState.Bounded env49330 := by
  intro p hp
  have h : env49330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49329_49330 : H12AffineEnvironment.transform 6 85 env49329 = env49330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env49329 == env49330) = true)

theorem identity49330 : scanCanonicalize (H12AffineFastState.compose env49330 (packedSelected [2,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound49330 : packedSelected [2,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env49331 : List Nat := [2,4,8,16,32,64,85,256,64,337,39,261,349,64,0,34,64,118,68,1,260,29,64,35,21,260,302,17,65,71,337,80,256,261,16,340]

theorem envBound49331 : H12AffineFastState.Bounded env49331 := by
  intro p hp
  have h : env49331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49330_49331 : H12AffineEnvironment.transform 10 39 env49330 = env49331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env49330 == env49331) = true)

theorem identity49331 : scanCanonicalize (H12AffineFastState.compose env49331 (packedSelected [0,7,8,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 56) := by decide +kernel

theorem selectedBound49331 : packedSelected [0,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env49332 : List Nat := [2,4,8,16,32,64,85,56,64,105,39,61,101,64,0,34,64,118,68,1,60,29,64,35,21,60,22,17,65,71,105,80,56,61,16,108]

theorem envBound49332 : H12AffineFastState.Bounded env49332 := by
  intro p hp
  have h : env49332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49331_49332 : H12AffineEnvironment.transform 7 56 env49331 = env49332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 56 env49331 == env49332) = true)

theorem identity49332 : scanCanonicalize (H12AffineFastState.compose env49332 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49332 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env49333 : List Nat := [2,4,8,1,32,64,68,41,64,105,39,44,101,64,0,34,64,103,68,1,45,12,64,35,4,45,7,0,65,71,105,65,41,44,1,108]

theorem envBound49333 : H12AffineFastState.Bounded env49333 := by
  intro p hp
  have h : env49333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49332_49333 : H12AffineEnvironment.transform 3 1 env49332 = env49333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49332 == env49333) = true)

theorem identity49333 : scanCanonicalize (H12AffineFastState.compose env49333 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49333 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env49334 : List Nat := [2,4,2,1,32,64,68,35,64,99,39,38,101,64,0,34,64,103,68,1,39,6,64,35,4,39,7,0,65,71,99,65,35,38,1,102]

theorem envBound49334 : H12AffineFastState.Bounded env49334 := by
  intro p hp
  have h : env49334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49333_49334 : H12AffineEnvironment.transform 2 2 env49333 = env49334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49333 == env49334) = true)

theorem identity49334 : scanCanonicalize (H12AffineFastState.compose env49334 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound49334 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49335 : List Nat := [2,4,2,1,32,7,3,35,7,36,39,38,34,7,0,34,7,32,3,1,39,6,7,35,4,39,7,0,6,0,36,6,35,38,1,33]

theorem envBound49335 : H12AffineFastState.Bounded env49335 := by
  intro p hp
  have h : env49335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49334_49335 : H12AffineEnvironment.transform 5 7 env49334 = env49335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env49334 == env49335) = true)

theorem identity49335 : scanCanonicalize (H12AffineFastState.compose env49335 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49335 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49336 : List Nat := [2,4,2,1,0,7,3,3,7,4,7,6,2,7,0,2,7,0,3,1,7,6,7,3,4,7,7,0,6,0,4,6,3,6,1,1]

theorem envBound49336 : H12AffineFastState.Bounded env49336 := by
  intro p hp
  have h : env49336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49335_49336 : H12AffineEnvironment.transform 4 0 env49335 = env49336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49335 == env49336) = true)

theorem identity49336 : scanCanonicalize (H12AffineFastState.compose env49336 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49337 : List Nat := [2,2,2,1,0,1,3,3,1,2,1,0,2,1,0,2,1,0,3,1,1,0,1,3,2,1,1,0,0,0,2,0,3,0,1,1]

theorem envBound49337 : H12AffineFastState.Bounded env49337 := by
  intro p hp
  have h : env49337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49336_49337 : H12AffineEnvironment.transform 1 2 env49336 = env49337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49336 == env49337) = true)

def env49338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1297,577,65536,67442,65665,1876,576,1556,649,66083,66896,192,65830,1151,67363,1296,67650,784,1281,256,65831,1345,341]

theorem envBound49338 : H12AffineFastState.Bounded env49338 := by
  intro p hp
  have h : env49338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49297_49338 : H12AffineEnvironment.transform 11 1557 env49297 = env49338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env49297 == env49338) = true)

def env49339 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,65,577,65536,66082,65665,516,576,836,649,66083,65536,192,65830,303,66163,64,67650,784,81,256,65831,17,341]

theorem envBound49339 : H12AffineFastState.Bounded env49339 := by
  intro p hp
  have h : env49339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49338_49339 : H12AffineEnvironment.transform 9 336 env49338 = env49339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env49338 == env49339) = true)

theorem identity49339 : scanCanonicalize (H12AffineFastState.compose env49339 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound49339 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49340 : List Nat := [2,4,8,16,32,64,128,129,512,209,2048,708,669,65,577,65536,66082,65665,516,576,709,649,66083,65536,192,65703,174,66163,64,67650,657,81,129,65702,17,212]

theorem envBound49340 : H12AffineFastState.Bounded env49340 := by
  intro p hp
  have h : env49340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49339_49340 : H12AffineEnvironment.transform 7 129 env49339 = env49340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env49339 == env49340) = true)

def env49341 : List Nat := [2,4,8,16,32,64,128,129,512,209,2048,708,669,65,577,240,722,113,516,576,709,649,723,240,192,87,174,643,64,2226,657,81,129,86,17,212]

theorem envBound49341 : H12AffineFastState.Bounded env49341 := by
  intro p hp
  have h : env49341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49340_49341 : H12AffineEnvironment.transform 15 240 env49340 = env49341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 240 env49340 == env49341) = true)

theorem identity49341 : scanCanonicalize (H12AffineFastState.compose env49341 (packedSelected [1,2,4,8,9,10,12,13,15,17,18,20,21,24,32] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound49341 : packedSelected [1,2,4,8,9,10,12,13,15,17,18,20,21,24,32] rootPS < 2^1333 := by decide +kernel

def env49342 : List Nat := [2,4,8,16,32,64,128,129,39,209,2048,227,186,65,102,240,245,113,35,103,226,174,244,240,192,87,174,164,64,2226,182,81,129,86,17,212]

theorem envBound49342 : H12AffineFastState.Bounded env49342 := by
  intro p hp
  have h : env49342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49341_49342 : H12AffineEnvironment.transform 8 39 env49341 = env49342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env49341 == env49342) = true)

theorem identity49342 : scanCanonicalize (H12AffineFastState.compose env49342 (packedSelected [2,3,5,7,8,9,10,12,13,15,16,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound49342 : packedSelected [2,3,5,7,8,9,10,12,13,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env49343 : List Nat := [2,4,8,16,32,55,128,129,39,166,2048,148,186,54,17,135,130,6,35,16,149,174,131,135,183,32,174,164,55,2226,182,38,129,33,17,163]

theorem envBound49343 : H12AffineFastState.Bounded env49343 := by
  intro p hp
  have h : env49343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49342_49343 : H12AffineEnvironment.transform 5 55 env49342 = env49343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env49342 == env49343) = true)

theorem identity49343 : scanCanonicalize (H12AffineFastState.compose env49343 (packedSelected [0,3,7,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound49343 : packedSelected [0,3,7,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49344 : List Nat := [2,4,8,16,32,55,21,20,39,51,2048,1,47,54,17,18,23,6,35,16,0,59,22,18,34,32,59,49,55,2087,35,38,20,33,17,54]

theorem envBound49344 : H12AffineFastState.Bounded env49344 := by
  intro p hp
  have h : env49344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49343_49344 : H12AffineEnvironment.transform 6 21 env49343 = env49344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env49343 == env49344) = true)

theorem identity49344 : scanCanonicalize (H12AffineFastState.compose env49344 (packedSelected [0,4,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49344 : packedSelected [0,4,5,10] rootPS < 2^1333 := by decide +kernel

def env49345 : List Nat := [2,4,8,16,32,55,21,20,39,51,48,1,47,54,17,18,23,6,35,16,0,59,22,18,34,32,59,49,55,23,35,38,20,33,17,54]

theorem envBound49345 : H12AffineFastState.Bounded env49345 := by
  intro p hp
  have h : env49345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49344_49345 : H12AffineEnvironment.transform 10 48 env49344 = env49345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49344 == env49345) = true)

theorem identity49345 : scanCanonicalize (H12AffineFastState.compose env49345 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49345 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env49346 : List Nat := [2,4,4,16,32,55,21,20,39,51,48,1,35,54,17,18,23,6,35,16,0,55,22,18,34,32,55,49,55,23,35,38,20,33,17,54]

theorem envBound49346 : H12AffineFastState.Bounded env49346 := by
  intro p hp
  have h : env49346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49345_49346 : H12AffineEnvironment.transform 2 4 env49345 = env49346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49345 == env49346) = true)

theorem identity49346 : scanCanonicalize (H12AffineFastState.compose env49346 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound49346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49347 : List Nat := [2,4,4,16,22,1,21,20,17,5,6,1,21,0,17,18,23,6,21,16,0,1,22,18,20,22,1,7,1,23,21,16,20,23,17,0]

theorem envBound49347 : H12AffineFastState.Bounded env49347 := by
  intro p hp
  have h : env49347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49346_49347 : H12AffineEnvironment.transform 4 22 env49346 = env49347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env49346 == env49347) = true)

theorem identity49347 : scanCanonicalize (H12AffineFastState.compose env49347 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49347 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49348 : List Nat := [2,4,4,6,0,1,3,2,7,5,6,1,3,0,7,4,1,6,3,6,0,1,0,4,2,0,1,7,1,1,3,6,2,1,7,0]

theorem envBound49348 : H12AffineFastState.Bounded env49348 := by
  intro p hp
  have h : env49348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49347_49348 : H12AffineEnvironment.transform 3 6 env49347 = env49348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49347 == env49348) = true)

theorem identity49348 : scanCanonicalize (H12AffineFastState.compose env49348 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49348 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49349 : List Nat := [2,2,2,0,0,1,3,2,1,3,0,1,3,0,1,2,1,0,3,0,0,1,0,2,2,0,1,1,1,1,3,0,2,1,1,0]

theorem envBound49349 : H12AffineFastState.Bounded env49349 := by
  intro p hp
  have h : env49349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49348_49349 : H12AffineEnvironment.transform 1 2 env49348 = env49349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49348 == env49349) = true)

theorem identity49349 : scanCanonicalize (H12AffineFastState.compose env49349 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49350 : List Nat := [1,1,1,0,0,1,0,1,1,0,0,1,0,0,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,1,1,1,0]

theorem envBound49350 : H12AffineFastState.Bounded env49350 := by
  intro p hp
  have h : env49350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49349_49350 : H12AffineEnvironment.transform 0 1 env49349 = env49350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49349 == env49350) = true)

def env49351 : List Nat := [2,4,8,16,32,64,128,129,512,209,2048,708,669,65,577,241,723,112,516,576,709,649,722,241,192,86,174,642,64,2227,657,81,129,87,17,212]

theorem envBound49351 : H12AffineFastState.Bounded env49351 := by
  intro p hp
  have h : env49351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49340_49351 : H12AffineEnvironment.transform 15 241 env49340 = env49351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 241 env49340 == env49351) = true)

theorem identity49351 : scanCanonicalize (H12AffineFastState.compose env49351 (packedSelected [1,2,4,8,9,10,12,13,15,17,18,20,21,24,32] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound49351 : packedSelected [1,2,4,8,9,10,12,13,15,17,18,20,21,24,32] rootPS < 2^1333 := by decide +kernel

def env49352 : List Nat := [2,4,8,16,32,64,53,52,512,100,2048,625,552,65,577,68,614,112,516,576,624,572,615,68,117,86,27,567,64,2054,548,81,52,87,17,97]

theorem envBound49352 : H12AffineFastState.Bounded env49352 := by
  intro p hp
  have h : env49352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49351_49352 : H12AffineEnvironment.transform 6 53 env49351 = env49352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env49351 == env49352) = true)

theorem identity49352 : scanCanonicalize (H12AffineFastState.compose env49352 (packedSelected [1,3,4,5,7,15,16,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 634) := by decide +kernel

theorem selectedBound49352 : packedSelected [1,3,4,5,7,15,16,17,23] rootPS < 2^1333 := by decide +kernel

def env49353 : List Nat := [2,4,8,16,32,64,53,52,512,100,634,625,552,65,577,68,614,112,516,576,624,572,615,68,117,86,27,567,64,636,548,81,52,87,17,97]

theorem envBound49353 : H12AffineFastState.Bounded env49353 := by
  intro p hp
  have h : env49353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49352_49353 : H12AffineEnvironment.transform 10 634 env49352 = env49353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 634 env49352 == env49353) = true)

theorem identity49353 : scanCanonicalize (H12AffineFastState.compose env49353 (packedSelected [0,7,8,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound49353 : packedSelected [0,7,8,13,16] rootPS < 2^1333 := by decide +kernel

def env49354 : List Nat := [2,4,8,16,26,64,15,14,512,94,576,587,530,65,577,68,604,74,516,576,586,518,605,68,79,86,27,525,64,582,542,81,14,87,17,91]

theorem envBound49354 : H12AffineFastState.Bounded env49354 := by
  intro p hp
  have h : env49354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49353_49354 : H12AffineEnvironment.transform 4 26 env49353 = env49354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env49353 == env49354) = true)

theorem identity49354 : scanCanonicalize (H12AffineFastState.compose env49354 (packedSelected [1,3,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound49354 : packedSelected [1,3,10,11] rootPS < 2^1333 := by decide +kernel

def env49355 : List Nat := [2,4,8,16,26,13,15,14,512,19,525,518,530,12,524,9,529,7,516,525,519,518,528,9,2,27,27,525,13,523,542,28,14,26,17,22]

theorem envBound49355 : H12AffineFastState.Bounded env49355 := by
  intro p hp
  have h : env49355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49354_49355 : H12AffineEnvironment.transform 5 13 env49354 = env49355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env49354 == env49355) = true)

def env49356 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,64,577,65536,66083,65665,517,576,837,649,66083,65537,192,65830,302,66162,65,67650,784,80,256,65831,16,341]

theorem envBound49356 : H12AffineFastState.Bounded env49356 := by
  intro p hp
  have h : env49356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49338_49356 : H12AffineEnvironment.transform 9 337 env49338 = env49356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env49338 == env49356) = true)

theorem identity49356 : scanCanonicalize (H12AffineFastState.compose env49356 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 197) := by decide +kernel

theorem selectedBound49356 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49357 : List Nat := [2,4,8,16,32,64,128,256,197,337,2048,385,473,64,132,65536,65766,65665,192,133,384,76,65766,65537,192,65830,302,65719,65,67650,469,80,256,65831,16,341]

theorem envBound49357 : H12AffineFastState.Bounded env49357 := by
  intro p hp
  have h : env49357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49356_49357 : H12AffineEnvironment.transform 8 197 env49356 = env49357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 197 env49356 == env49357) = true)

def env49358 : List Nat := [2,4,8,16,32,64,128,128,197,209,2048,1,89,64,132,65536,65766,65665,192,133,0,76,65766,65537,192,65702,174,65719,65,67650,85,80,128,65703,16,213]

theorem envBound49358 : H12AffineFastState.Bounded env49358 := by
  intro p hp
  have h : env49358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49357_49358 : H12AffineEnvironment.transform 7 128 env49357 = env49358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env49357 == env49358) = true)

theorem identity49358 : scanCanonicalize (H12AffineFastState.compose env49358 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound49358 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49359 : List Nat := [2,4,8,16,32,64,4,4,65,85,2048,1,89,64,0,65536,65634,65541,68,1,0,76,65634,65537,68,65570,42,65587,65,67650,85,80,4,65571,16,81]

theorem envBound49359 : H12AffineFastState.Bounded env49359 := by
  intro p hp
  have h : env49359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49358_49359 : H12AffineEnvironment.transform 6 4 env49358 = env49359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env49358 == env49359) = true)

theorem identity49359 : scanCanonicalize (H12AffineFastState.compose env49359 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound49359 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49360 : List Nat := [2,4,8,16,32,64,4,4,65,85,2048,1,89,64,0,50,80,55,68,1,0,76,80,51,68,16,42,1,65,2160,85,80,4,17,16,81]

theorem envBound49360 : H12AffineFastState.Bounded env49360 := by
  intro p hp
  have h : env49360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49359_49360 : H12AffineEnvironment.transform 15 50 env49359 = env49360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env49359 == env49360) = true)

theorem identity49360 : scanCanonicalize (H12AffineFastState.compose env49360 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 87) := by decide +kernel

theorem selectedBound49360 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49361 : List Nat := [2,4,8,16,32,64,4,4,65,85,87,1,89,64,0,50,80,55,68,1,0,76,80,51,68,16,42,1,65,39,85,80,4,17,16,81]

theorem envBound49361 : H12AffineFastState.Bounded env49361 := by
  intro p hp
  have h : env49361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49360_49361 : H12AffineEnvironment.transform 10 87 env49360 = env49361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 87 env49360 == env49361) = true)

theorem identity49361 : scanCanonicalize (H12AffineFastState.compose env49361 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound49361 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49362 : List Nat := [2,4,8,16,32,44,4,4,45,57,59,1,53,44,0,50,60,55,40,1,0,32,60,51,40,16,42,1,45,39,57,60,4,17,16,61]

theorem envBound49362 : H12AffineFastState.Bounded env49362 := by
  intro p hp
  have h : env49362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49361_49362 : H12AffineEnvironment.transform 5 44 env49361 = env49362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env49361 == env49362) = true)

theorem identity49362 : scanCanonicalize (H12AffineFastState.compose env49362 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound49362 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env49363 : List Nat := [2,4,8,16,13,1,4,4,0,20,22,1,24,1,0,31,17,26,5,1,0,13,17,30,5,16,7,1,0,10,20,17,4,17,16,16]

theorem envBound49363 : H12AffineFastState.Bounded env49363 := by
  intro p hp
  have h : env49363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49362_49363 : H12AffineEnvironment.transform 4 13 env49362 = env49363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env49362 == env49363) = true)

theorem identity49363 : scanCanonicalize (H12AffineFastState.compose env49363 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49364 : List Nat := [2,3,8,16,10,1,3,3,0,19,17,1,24,1,0,24,17,26,2,1,0,10,17,25,2,16,0,1,0,10,19,17,3,17,16,16]

theorem envBound49364 : H12AffineFastState.Bounded env49364 := by
  intro p hp
  have h : env49364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49363_49364 : H12AffineEnvironment.transform 1 3 env49363 = env49364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49363 == env49364) = true)

theorem identity49364 : scanCanonicalize (H12AffineFastState.compose env49364 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49364 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49365 : List Nat := [2,3,2,16,0,1,3,3,0,19,17,1,18,1,0,18,17,16,2,1,0,0,17,19,2,16,0,1,0,0,19,17,3,17,16,16]

theorem envBound49365 : H12AffineFastState.Bounded env49365 := by
  intro p hp
  have h : env49365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49364_49365 : H12AffineEnvironment.transform 2 2 env49364 = env49365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49364 == env49365) = true)

theorem identity49365 : scanCanonicalize (H12AffineFastState.compose env49365 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49366 : List Nat := [2,3,2,1,0,1,3,3,0,2,0,1,3,1,0,3,0,1,2,1,0,0,0,2,2,1,0,1,0,0,2,0,3,0,1,1]

theorem envBound49366 : H12AffineFastState.Bounded env49366 := by
  intro p hp
  have h : env49366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49365_49366 : H12AffineEnvironment.transform 3 1 env49365 = env49366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49365 == env49366) = true)

theorem identity49366 : scanCanonicalize (H12AffineFastState.compose env49366 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49367 : List Nat := [1,0,1,1,0,1,0,0,0,1,0,1,0,1,0,0,0,1,1,1,0,0,0,1,1,1,0,1,0,0,1,0,0,0,1,1]

theorem envBound49367 : H12AffineFastState.Bounded env49367 := by
  intro p hp
  have h : env49367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49366_49367 : H12AffineEnvironment.transform 0 1 env49366 = env49367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49366 == env49367) = true)

def env49368 : List Nat := [2,4,8,16,32,64,128,129,197,208,2048,0,88,64,132,65536,65766,65665,192,133,1,76,65766,65537,192,65703,175,65719,65,67650,84,80,129,65702,16,212]

theorem envBound49368 : H12AffineFastState.Bounded env49368 := by
  intro p hp
  have h : env49368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49357_49368 : H12AffineEnvironment.transform 7 129 env49357 = env49368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env49357 == env49368) = true)

theorem identity49368 : scanCanonicalize (H12AffineFastState.compose env49368 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound49368 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49369 : List Nat := [2,4,8,16,32,64,21,20,80,69,2048,0,88,64,17,65536,65651,65556,85,16,1,76,65651,65537,85,65586,58,65570,65,67650,84,80,20,65587,16,65]

theorem envBound49369 : H12AffineFastState.Bounded env49369 := by
  intro p hp
  have h : env49369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49368_49369 : H12AffineEnvironment.transform 6 21 env49368 = env49369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env49368 == env49369) = true)

theorem identity49369 : scanCanonicalize (H12AffineFastState.compose env49369 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound49369 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env49370 : List Nat := [2,4,8,16,32,42,21,20,58,47,2048,0,50,42,17,65536,65561,65556,63,16,1,38,65561,65537,63,65586,58,65570,43,67624,62,58,20,65587,16,43]

theorem envBound49370 : H12AffineFastState.Bounded env49370 := by
  intro p hp
  have h : env49370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49369_49370 : H12AffineEnvironment.transform 5 42 env49369 = env49370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env49369 == env49370) = true)

theorem identity49370 : scanCanonicalize (H12AffineFastState.compose env49370 (packedSelected [1,2,3,5,8,11,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound49370 : packedSelected [1,2,3,5,8,11,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env49371 : List Nat := [2,4,8,16,32,42,21,20,58,47,23,0,50,42,17,65536,65561,65556,63,16,1,38,65561,65537,63,65586,58,65570,43,65599,62,58,20,65587,16,43]

theorem envBound49371 : H12AffineFastState.Bounded env49371 := by
  intro p hp
  have h : env49371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49370_49371 : H12AffineEnvironment.transform 10 23 env49370 = env49371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env49370 == env49371) = true)

theorem identity49371 : scanCanonicalize (H12AffineFastState.compose env49371 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound49371 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49372 : List Nat := [2,4,8,16,32,42,21,20,58,47,23,0,50,42,17,50,43,38,63,16,1,38,43,51,63,0,58,16,43,13,62,58,20,1,16,43]

theorem envBound49372 : H12AffineFastState.Bounded env49372 := by
  intro p hp
  have h : env49372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49371_49372 : H12AffineEnvironment.transform 15 50 env49371 = env49372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env49371 == env49372) = true)

theorem identity49372 : scanCanonicalize (H12AffineFastState.compose env49372 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49372 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env49373 : List Nat := [2,4,4,16,32,38,21,20,54,35,23,0,50,38,17,50,39,38,51,16,1,38,39,51,51,0,54,16,39,1,50,54,20,1,16,39]

theorem envBound49373 : H12AffineFastState.Bounded env49373 := by
  intro p hp
  have h : env49373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49372_49373 : H12AffineEnvironment.transform 2 4 env49372 = env49373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49372 == env49373) = true)

theorem identity49373 : scanCanonicalize (H12AffineFastState.compose env49373 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound49373 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49374 : List Nat := [2,4,4,16,23,17,21,20,1,20,23,0,5,17,17,5,16,17,4,16,1,17,16,4,4,0,1,16,16,1,5,1,20,1,16,16]

theorem envBound49374 : H12AffineFastState.Bounded env49374 := by
  intro p hp
  have h : env49374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49373_49374 : H12AffineEnvironment.transform 4 23 env49373 = env49374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env49373 == env49374) = true)

theorem identity49374 : scanCanonicalize (H12AffineFastState.compose env49374 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49374 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49375 : List Nat := [2,4,4,0,7,1,5,4,1,4,7,0,5,1,1,5,0,1,4,0,1,1,0,4,4,0,1,0,0,1,5,1,4,1,0,0]

theorem envBound49375 : H12AffineFastState.Bounded env49375 := by
  intro p hp
  have h : env49375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49374_49375 : H12AffineEnvironment.transform 3 0 env49374 = env49375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49374 == env49375) = true)

theorem identity49375 : scanCanonicalize (H12AffineFastState.compose env49375 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49376 : List Nat := [1,4,4,0,4,1,5,4,1,4,4,0,5,1,1,5,0,1,4,0,1,1,0,4,4,0,1,0,0,1,5,1,4,1,0,0]

theorem envBound49376 : H12AffineFastState.Bounded env49376 := by
  intro p hp
  have h : env49376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49375_49376 : H12AffineEnvironment.transform 0 1 env49375 = env49376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49375 == env49376) = true)

def env49377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123164,28889,78894,385202,90414,1297,96346,25885,1280,256,82998,1345,21072]

theorem envBound49377 : H12AffineFastState.Bounded env49377 := by
  intro p hp
  have h : env49377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49137_49377 : H12AffineEnvironment.transform 18 21585 env49137 = env49377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env49137 == env49377) = true)

theorem identity49377 : scanCanonicalize (H12AffineFastState.compose env49377 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound49377 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env49378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4097,17612,91182,87296,28889,78894,349358,90414,1297,96346,25885,1280,256,82998,1345,21072]

theorem envBound49378 : H12AffineFastState.Bounded env49378 := by
  intro p hp
  have h : env49378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49377_49378 : H12AffineEnvironment.transform 14 13340 env49377 = env49378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env49377 == env49378) = true)

def env49379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4097,476,74046,69648,13769,78894,332222,74814,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound49379 : H12AffineFastState.Bounded env49379 := by
  intro p hp
  have h : env49379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49378_49379 : H12AffineEnvironment.transform 13 1296 env49378 = env49379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env49378 == env49379) = true)

def env49380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4097,476,74046,69648,13769,78894,4414,74814,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound49380 : H12AffineFastState.Bounded env49380 := by
  intro p hp
  have h : env49380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49379_49380 : H12AffineEnvironment.transform 17 65664 env49379 = env49380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49379 == env49380) = true)

theorem identity49380 : scanCanonicalize (H12AffineFastState.compose env49380 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49380 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49381 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,65536,74030,65664,4417,12637,4097,476,74046,69648,12425,78190,4414,74110,81,79882,8205,64,256,65830,1,4608]

theorem envBound49381 : H12AffineFastState.Bounded env49381 := by
  intro p hp
  have h : env49381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49380_49381 : H12AffineEnvironment.transform 9 320 env49380 = env49381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49380 == env49381) = true)

def env49382 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,80,12636,65536,74030,65664,4417,12637,4097,476,74046,69648,12425,78190,4414,74110,81,79882,8205,64,256,65830,1,4436]

theorem envBound49382 : H12AffineFastState.Bounded env49382 := by
  intro p hp
  have h : env49382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49381_49382 : H12AffineEnvironment.transform 8 340 env49381 = env49382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env49381 == env49382) = true)

def env49383 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,80,8524,65536,74030,65664,337,8525,17,476,74046,65536,8345,74110,302,74110,81,75802,8205,64,256,65830,1,324]

theorem envBound49383 : H12AffineFastState.Bounded env49383 := by
  intro p hp
  have h : env49383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49382_49383 : H12AffineEnvironment.transform 11 16 env49382 = env49383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49382 == env49383) = true)

theorem identity49383 : scanCanonicalize (H12AffineFastState.compose env49383 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 209) := by decide +kernel

theorem selectedBound49383 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49384 : List Nat := [2,4,8,16,32,64,128,209,133,145,2048,16,8192,80,8349,65536,73983,65664,128,8348,17,13,73967,65536,8345,73903,255,73903,81,75802,8205,64,209,65783,1,149]

theorem envBound49384 : H12AffineFastState.Bounded env49384 := by
  intro p hp
  have h : env49384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49383_49384 : H12AffineEnvironment.transform 7 209 env49383 = env49384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 209 env49383 == env49384) = true)

def env49385 : List Nat := [2,4,8,0,32,64,128,193,133,129,2048,0,8192,64,8333,65536,73967,65664,128,8332,1,13,73967,65536,8329,73903,239,73903,65,75786,8205,64,193,65767,1,133]

theorem envBound49385 : H12AffineFastState.Bounded env49385 := by
  intro p hp
  have h : env49385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49384_49385 : H12AffineEnvironment.transform 3 0 env49384 = env49385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49384 == env49385) = true)

theorem identity49385 : scanCanonicalize (H12AffineFastState.compose env49385 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound49385 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49386 : List Nat := [2,4,8,0,32,64,128,193,133,129,2048,0,140,64,1,65536,65635,65664,128,0,1,13,65635,65536,5,65571,239,65571,65,67718,129,64,193,65767,1,133]

theorem envBound49386 : H12AffineFastState.Bounded env49386 := by
  intro p hp
  have h : env49386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49385_49386 : H12AffineEnvironment.transform 12 140 env49385 = env49386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env49385 == env49386) = true)

theorem identity49386 : scanCanonicalize (H12AffineFastState.compose env49386 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49386 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49387 : List Nat := [2,4,8,0,32,1,128,128,133,129,2048,0,140,1,1,65536,65570,65664,128,0,1,13,65570,65536,5,65571,174,65571,0,67718,129,1,128,65702,1,133]

theorem envBound49387 : H12AffineFastState.Bounded env49387 := by
  intro p hp
  have h : env49387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49386_49387 : H12AffineEnvironment.transform 5 1 env49386 = env49387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49386 == env49387) = true)

theorem identity49387 : scanCanonicalize (H12AffineFastState.compose env49387 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 2095) := by decide +kernel

theorem selectedBound49387 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env49388 : List Nat := [2,4,8,0,32,1,128,128,133,129,2048,0,140,1,1,2095,2061,2223,128,0,1,13,2061,2095,5,2060,174,2060,0,169,129,1,128,2185,1,133]

theorem envBound49388 : H12AffineFastState.Bounded env49388 := by
  intro p hp
  have h : env49388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49387_49388 : H12AffineEnvironment.transform 15 2095 env49387 = env49388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2095 env49387 == env49388) = true)

theorem identity49388 : scanCanonicalize (H12AffineFastState.compose env49388 (packedSelected [0,1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound49388 : packedSelected [0,1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49389 : List Nat := [2,4,8,0,32,1,128,128,133,129,12,0,140,1,1,35,1,163,128,0,1,13,1,35,5,0,174,0,0,169,129,1,128,133,1,133]

theorem envBound49389 : H12AffineFastState.Bounded env49389 := by
  intro p hp
  have h : env49389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49388_49389 : H12AffineEnvironment.transform 10 12 env49388 = env49389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env49388 == env49389) = true)

theorem identity49389 : scanCanonicalize (H12AffineFastState.compose env49389 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound49389 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49390 : List Nat := [2,4,8,0,32,1,3,3,6,2,12,0,15,1,1,35,1,32,3,0,1,13,1,35,5,0,45,0,0,42,2,1,3,6,1,6]

theorem envBound49390 : H12AffineFastState.Bounded env49390 := by
  intro p hp
  have h : env49390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49389_49390 : H12AffineEnvironment.transform 6 3 env49389 = env49390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env49389 == env49390) = true)

theorem identity49390 : scanCanonicalize (H12AffineFastState.compose env49390 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49390 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env49391 : List Nat := [2,4,8,0,0,1,3,3,6,2,12,0,15,1,1,3,1,0,3,0,1,13,1,3,5,0,13,0,0,10,2,1,3,6,1,6]

theorem envBound49391 : H12AffineFastState.Bounded env49391 := by
  intro p hp
  have h : env49391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49390_49391 : H12AffineEnvironment.transform 4 0 env49390 = env49391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49390 == env49391) = true)

theorem identity49391 : scanCanonicalize (H12AffineFastState.compose env49391 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49392 : List Nat := [2,4,5,0,0,1,3,3,6,2,1,0,2,1,1,3,1,0,3,0,1,0,1,3,5,0,0,0,0,7,2,1,3,6,1,6]

theorem envBound49392 : H12AffineFastState.Bounded env49392 := by
  intro p hp
  have h : env49392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49391_49392 : H12AffineEnvironment.transform 2 5 env49391 = env49392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49391 == env49392) = true)

theorem identity49392 : scanCanonicalize (H12AffineFastState.compose env49392 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49392 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49393 : List Nat := [2,3,2,0,0,1,3,3,1,2,1,0,2,1,1,3,1,0,3,0,1,0,1,3,2,0,0,0,0,0,2,1,3,1,1,1]

theorem envBound49393 : H12AffineFastState.Bounded env49393 := by
  intro p hp
  have h : env49393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49392_49393 : H12AffineEnvironment.transform 1 3 env49392 = env49393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49392 == env49393) = true)

def env49394 : List Nat := [2,4,8,1,32,64,128,192,133,128,2048,1,8192,65,8332,65536,73966,65664,128,8333,0,13,73967,65536,8328,73903,238,73903,64,75787,8205,64,192,65766,1,132]

theorem envBound49394 : H12AffineFastState.Bounded env49394 := by
  intro p hp
  have h : env49394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49384_49394 : H12AffineEnvironment.transform 3 1 env49384 = env49394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49384 == env49394) = true)

theorem identity49394 : scanCanonicalize (H12AffineFastState.compose env49394 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49394 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49395 : List Nat := [2,4,8,1,32,64,128,192,133,128,2048,1,8192,65,8332,34,8396,162,128,8333,0,13,8397,34,8328,8333,238,8333,64,10281,8205,64,192,196,1,132]

theorem envBound49395 : H12AffineFastState.Bounded env49395 := by
  intro p hp
  have h : env49395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49394_49395 : H12AffineEnvironment.transform 15 34 env49394 = env49395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49394 == env49395) = true)

theorem identity49395 : scanCanonicalize (H12AffineFastState.compose env49395 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound49395 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49396 : List Nat := [2,4,8,1,32,64,69,5,64,69,2048,1,8192,65,8265,34,8201,103,69,8264,0,13,8200,34,8269,8264,43,8264,64,10281,8205,64,5,1,1,65]

theorem envBound49396 : H12AffineFastState.Bounded env49396 := by
  intro p hp
  have h : env49396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49395_49396 : H12AffineEnvironment.transform 6 69 env49395 = env49396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env49395 == env49396) = true)

theorem identity49396 : scanCanonicalize (H12AffineFastState.compose env49396 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49396 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49397 : List Nat := [2,4,8,1,32,64,69,5,64,69,2048,1,9,65,64,34,0,103,69,65,0,13,1,34,68,65,43,65,64,2080,4,64,5,1,1,65]

theorem envBound49397 : H12AffineFastState.Bounded env49397 := by
  intro p hp
  have h : env49397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49396_49397 : H12AffineEnvironment.transform 12 9 env49396 = env49397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49396 == env49397) = true)

theorem identity49397 : scanCanonicalize (H12AffineFastState.compose env49397 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound49397 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env49398 : List Nat := [2,4,8,1,32,11,14,5,11,14,2048,1,9,10,11,34,0,44,14,10,0,13,1,34,15,10,43,10,11,2080,4,11,5,1,1,10]

theorem envBound49398 : H12AffineFastState.Bounded env49398 := by
  intro p hp
  have h : env49398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49397_49398 : H12AffineEnvironment.transform 5 11 env49397 = env49398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env49397 == env49398) = true)

theorem identity49398 : scanCanonicalize (H12AffineFastState.compose env49398 (packedSelected [1,2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49398 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49399 : List Nat := [2,2,8,1,32,11,8,3,11,8,2048,1,9,10,11,34,0,42,8,10,0,11,1,34,9,10,43,10,11,2080,2,11,3,1,1,10]

theorem envBound49399 : H12AffineFastState.Bounded env49399 := by
  intro p hp
  have h : env49399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49398_49399 : H12AffineEnvironment.transform 1 2 env49398 = env49399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49398 == env49399) = true)

theorem identity49399 : scanCanonicalize (H12AffineFastState.compose env49399 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49400 : List Nat := [2,2,8,1,32,11,8,3,11,8,1,1,9,10,11,34,0,42,8,10,0,11,1,34,9,10,43,10,11,33,2,11,3,1,1,10]

theorem envBound49400 : H12AffineFastState.Bounded env49400 := by
  intro p hp
  have h : env49400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49399_49400 : H12AffineEnvironment.transform 10 1 env49399 = env49400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49399 == env49400) = true)

theorem identity49400 : scanCanonicalize (H12AffineFastState.compose env49400 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound49400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49401 : List Nat := [2,2,8,1,8,11,8,3,11,8,1,1,9,10,11,10,0,2,8,10,0,11,1,10,9,10,3,10,11,9,2,11,3,1,1,10]

theorem envBound49401 : H12AffineFastState.Bounded env49401 := by
  intro p hp
  have h : env49401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49400_49401 : H12AffineEnvironment.transform 4 8 env49400 = env49401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env49400 == env49401) = true)

def env49402 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,80,8525,65536,74030,65664,336,8524,16,476,74046,65537,8344,74111,303,74110,81,75803,8205,64,256,65830,1,325]

theorem envBound49402 : H12AffineFastState.Bounded env49402 := by
  intro p hp
  have h : env49402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49382_49402 : H12AffineEnvironment.transform 11 17 env49382 = env49402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49382 == env49402) = true)

theorem identity49402 : scanCanonicalize (H12AffineFastState.compose env49402 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 408) := by decide +kernel

theorem selectedBound49402 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49403 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,408,80,213,65536,65718,65664,336,212,16,476,65702,65537,256,65767,303,65766,81,67971,405,64,256,65830,1,325]

theorem envBound49403 : H12AffineFastState.Bounded env49403 := by
  intro p hp
  have h : env49403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49402_49403 : H12AffineEnvironment.transform 12 408 env49402 = env49403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 408 env49402 == env49403) = true)

def env49404 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,392,64,197,65536,65702,65664,320,196,0,460,65702,65537,256,65767,303,65766,65,67971,389,64,256,65830,1,325]

theorem envBound49404 : H12AffineFastState.Bounded env49404 := by
  intro p hp
  have h : env49404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49403_49404 : H12AffineEnvironment.transform 3 0 env49403 = env49404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49403 == env49404) = true)

theorem identity49404 : scanCanonicalize (H12AffineFastState.compose env49404 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49404 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49405 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,392,64,197,34,132,162,320,196,0,460,132,35,256,197,303,196,65,2465,389,64,256,260,1,325]

theorem envBound49405 : H12AffineFastState.Bounded env49405 := by
  intro p hp
  have h : env49405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49404_49405 : H12AffineEnvironment.transform 15 34 env49404 = env49405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49404 == env49405) = true)

theorem identity49405 : scanCanonicalize (H12AffineFastState.compose env49405 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49405 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49406 : List Nat := [2,4,8,0,32,64,128,4,64,68,2048,1,140,64,197,34,132,162,68,196,0,200,132,35,4,197,43,196,65,2213,129,64,4,0,1,65]

theorem envBound49406 : H12AffineFastState.Bounded env49406 := by
  intro p hp
  have h : env49406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49405_49406 : H12AffineEnvironment.transform 7 4 env49405 = env49406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49405 == env49406) = true)

theorem identity49406 : scanCanonicalize (H12AffineFastState.compose env49406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49407 : List Nat := [2,4,8,0,32,64,5,4,64,68,2048,1,9,64,64,34,1,39,68,65,0,77,1,35,4,64,43,65,65,2080,4,64,4,0,1,65]

theorem envBound49407 : H12AffineFastState.Bounded env49407 := by
  intro p hp
  have h : env49407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49406_49407 : H12AffineEnvironment.transform 6 5 env49406 = env49407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49406 == env49407) = true)

theorem identity49407 : scanCanonicalize (H12AffineFastState.compose env49407 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound49407 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env49408 : List Nat := [2,4,8,0,32,64,5,4,64,68,103,1,9,64,64,34,1,39,68,65,0,77,1,35,4,64,43,65,65,71,4,64,4,0,1,65]

theorem envBound49408 : H12AffineFastState.Bounded env49408 := by
  intro p hp
  have h : env49408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49407_49408 : H12AffineEnvironment.transform 10 103 env49407 = env49408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env49407 == env49408) = true)

theorem identity49408 : scanCanonicalize (H12AffineFastState.compose env49408 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49408 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49409 : List Nat := [2,4,2,0,32,64,5,4,64,68,103,1,3,64,64,34,1,39,68,65,0,71,1,35,4,64,33,65,65,71,4,64,4,0,1,65]

theorem envBound49409 : H12AffineFastState.Bounded env49409 := by
  intro p hp
  have h : env49409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49408_49409 : H12AffineEnvironment.transform 2 2 env49408 = env49409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49408 == env49409) = true)

theorem identity49409 : scanCanonicalize (H12AffineFastState.compose env49409 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound49409 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49410 : List Nat := [2,4,2,0,32,7,5,4,7,3,32,1,3,7,7,34,1,39,3,6,0,0,1,35,4,7,33,6,6,0,4,7,4,0,1,6]

theorem envBound49410 : H12AffineFastState.Bounded env49410 := by
  intro p hp
  have h : env49410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49409_49410 : H12AffineEnvironment.transform 5 7 env49409 = env49410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env49409 == env49410) = true)

theorem identity49410 : scanCanonicalize (H12AffineFastState.compose env49410 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49411 : List Nat := [1,4,1,0,32,4,5,4,4,0,32,1,0,4,4,33,1,36,0,5,0,0,1,32,4,4,33,5,5,0,4,4,4,0,1,5]

theorem envBound49411 : H12AffineFastState.Bounded env49411 := by
  intro p hp
  have h : env49411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49410_49411 : H12AffineEnvironment.transform 0 1 env49410 = env49411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49410 == env49411) = true)

theorem identity49411 : scanCanonicalize (H12AffineFastState.compose env49411 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49412 : List Nat := [1,0,1,0,32,0,1,0,0,0,32,1,0,0,0,33,1,32,0,1,0,0,1,32,0,0,33,1,1,0,0,0,0,0,1,1]

theorem envBound49412 : H12AffineFastState.Bounded env49412 := by
  intro p hp
  have h : env49412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49411_49412 : H12AffineEnvironment.transform 1 0 env49411 = env49412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49411 == env49412) = true)

def env49413 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,393,65,196,65536,65703,65664,321,197,1,461,65702,65537,256,65767,303,65766,64,67971,388,64,256,65830,1,325]

theorem envBound49413 : H12AffineFastState.Bounded env49413 := by
  intro p hp
  have h : env49413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49403_49413 : H12AffineEnvironment.transform 3 1 env49403 = env49413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49403 == env49413) = true)

theorem identity49413 : scanCanonicalize (H12AffineFastState.compose env49413 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound49413 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49414 : List Nat := [2,4,8,1,32,64,69,256,325,320,2048,0,332,65,1,65536,65634,65605,321,0,1,264,65635,65537,256,65570,303,65571,64,67910,321,64,256,65830,1,325]

theorem envBound49414 : H12AffineFastState.Bounded env49414 := by
  intro p hp
  have h : env49414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49413_49414 : H12AffineEnvironment.transform 6 69 env49413 = env49414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env49413 == env49414) = true)

theorem identity49414 : scanCanonicalize (H12AffineFastState.compose env49414 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49414 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49415 : List Nat := [2,4,8,1,32,0,5,256,261,256,2048,0,268,1,1,65536,65570,65541,257,0,1,264,65571,65537,256,65570,303,65571,0,67846,257,0,256,65830,1,261]

theorem envBound49415 : H12AffineFastState.Bounded env49415 := by
  intro p hp
  have h : env49415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49414_49415 : H12AffineEnvironment.transform 5 0 env49414 = env49415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49414 == env49415) = true)

theorem identity49415 : scanCanonicalize (H12AffineFastState.compose env49415 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 265) := by decide +kernel

theorem selectedBound49415 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env49416 : List Nat := [2,4,8,1,32,0,5,256,261,256,265,0,268,1,1,65536,65570,65541,257,0,1,264,65571,65537,256,65570,303,65571,0,65551,257,0,256,65830,1,261]

theorem envBound49416 : H12AffineFastState.Bounded env49416 := by
  intro p hp
  have h : env49416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49415_49416 : H12AffineEnvironment.transform 10 265 env49415 = env49416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 265 env49415 == env49416) = true)

theorem identity49416 : scanCanonicalize (H12AffineFastState.compose env49416 (packedSelected [0,1,2,4,5,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound49416 : packedSelected [0,1,2,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env49417 : List Nat := [2,4,8,1,32,0,5,9,12,9,0,0,5,1,1,65536,65570,65541,8,0,1,1,65571,65537,9,65570,38,65571,0,65551,8,0,9,65583,1,12]

theorem envBound49417 : H12AffineFastState.Bounded env49417 := by
  intro p hp
  have h : env49417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49416_49417 : H12AffineEnvironment.transform 7 9 env49416 = env49417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env49416 == env49417) = true)

theorem identity49417 : scanCanonicalize (H12AffineFastState.compose env49417 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49417 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49418 : List Nat := [2,4,8,1,12,0,5,9,12,9,0,0,5,1,1,65536,65550,65541,8,0,1,1,65551,65537,9,65550,10,65551,0,65551,8,0,9,65539,1,12]

theorem envBound49418 : H12AffineFastState.Bounded env49418 := by
  intro p hp
  have h : env49418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49417_49418 : H12AffineEnvironment.transform 4 12 env49417 = env49418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49417 == env49418) = true)

theorem identity49418 : scanCanonicalize (H12AffineFastState.compose env49418 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound49418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49419 : List Nat := [2,4,8,1,12,0,5,9,12,9,0,0,5,1,1,3,13,6,8,0,1,1,12,2,9,13,10,12,0,12,8,0,9,0,1,12]

theorem envBound49419 : H12AffineFastState.Bounded env49419 := by
  intro p hp
  have h : env49419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49418_49419 : H12AffineEnvironment.transform 15 3 env49418 = env49419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env49418 == env49419) = true)

def env49420 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,80,12636,65536,74030,65664,4417,12637,4097,476,74046,69648,12425,78190,4414,74110,81,79882,8205,64,256,65830,1,4437]

theorem envBound49420 : H12AffineFastState.Bounded env49420 := by
  intro p hp
  have h : env49420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49381_49420 : H12AffineEnvironment.transform 8 341 env49381 = env49420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env49381 == env49420) = true)

def env49421 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8524,65536,74030,65664,337,8525,17,476,74046,65536,8345,74110,302,74110,81,75802,8205,64,256,65830,1,325]

theorem envBound49421 : H12AffineFastState.Bounded env49421 := by
  intro p hp
  have h : env49421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49420_49421 : H12AffineEnvironment.transform 11 16 env49420 = env49421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49420 == env49421) = true)

theorem identity49421 : scanCanonicalize (H12AffineFastState.compose env49421 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8446) := by decide +kernel

theorem selectedBound49421 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49422 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8524,8446,464,8318,337,8525,17,476,448,8446,8345,384,302,384,81,2276,8205,64,256,8664,1,325]

theorem envBound49422 : H12AffineFastState.Bounded env49422 := by
  intro p hp
  have h : env49422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49421_49422 : H12AffineEnvironment.transform 15 8446 env49421 = env49422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8446 env49421 == env49422) = true)

def env49423 : List Nat := [2,4,8,16,32,64,128,128,213,192,2048,16,8192,80,8396,8446,80,8318,209,8397,17,92,64,8446,8345,0,174,0,81,2276,8205,64,128,8280,1,197]

theorem envBound49423 : H12AffineFastState.Bounded env49423 := by
  intro p hp
  have h : env49423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49422_49423 : H12AffineEnvironment.transform 7 128 env49422 = env49423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env49422 == env49423) = true)

theorem identity49423 : scanCanonicalize (H12AffineFastState.compose env49423 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 205) := by decide +kernel

theorem selectedBound49423 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49424 : List Nat := [2,4,8,16,32,64,128,128,213,192,2048,16,205,80,1,51,80,179,209,0,17,92,64,51,84,0,174,0,81,2276,192,64,128,149,1,197]

theorem envBound49424 : H12AffineFastState.Bounded env49424 := by
  intro p hp
  have h : env49424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49423_49424 : H12AffineEnvironment.transform 12 205 env49423 = env49424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env49423 == env49424) = true)

theorem identity49424 : scanCanonicalize (H12AffineFastState.compose env49424 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49424 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49425 : List Nat := [2,4,8,16,32,1,128,128,148,129,2048,16,140,17,1,51,17,179,144,0,17,29,1,51,21,0,174,0,16,2213,129,1,128,149,1,132]

theorem envBound49425 : H12AffineFastState.Bounded env49425 := by
  intro p hp
  have h : env49425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49424_49425 : H12AffineEnvironment.transform 5 1 env49424 = env49425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49424 == env49425) = true)

theorem identity49425 : scanCanonicalize (H12AffineFastState.compose env49425 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound49425 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env49426 : List Nat := [2,4,8,16,32,1,128,128,148,129,22,16,140,17,1,51,17,179,144,0,17,29,1,51,21,0,174,0,16,179,129,1,128,149,1,132]

theorem envBound49426 : H12AffineFastState.Bounded env49426 := by
  intro p hp
  have h : env49426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49425_49426 : H12AffineEnvironment.transform 10 22 env49425 = env49426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env49425 == env49426) = true)

theorem identity49426 : scanCanonicalize (H12AffineFastState.compose env49426 (packedSelected [0,2,3,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49426 : packedSelected [0,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env49427 : List Nat := [2,4,4,16,32,1,128,128,148,129,22,16,128,17,1,51,17,179,144,0,17,17,1,51,21,0,162,0,16,179,129,1,128,149,1,132]

theorem envBound49427 : H12AffineFastState.Bounded env49427 := by
  intro p hp
  have h : env49427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49426_49427 : H12AffineEnvironment.transform 2 4 env49426 = env49427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49426 == env49427) = true)

theorem identity49427 : scanCanonicalize (H12AffineFastState.compose env49427 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound49427 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49428 : List Nat := [2,4,4,16,32,1,35,35,55,34,22,16,35,17,1,51,17,16,51,0,17,17,1,51,21,0,1,0,16,16,34,1,35,54,1,39]

theorem envBound49428 : H12AffineFastState.Bounded env49428 := by
  intro p hp
  have h : env49428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49427_49428 : H12AffineEnvironment.transform 6 35 env49427 = env49428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env49427 == env49428) = true)

theorem identity49428 : scanCanonicalize (H12AffineFastState.compose env49428 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49428 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49429 : List Nat := [2,4,4,1,32,1,35,35,38,34,7,1,35,0,1,34,0,1,34,0,0,0,1,34,4,0,1,0,1,1,34,1,35,39,1,39]

theorem envBound49429 : H12AffineFastState.Bounded env49429 := by
  intro p hp
  have h : env49429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49428_49429 : H12AffineEnvironment.transform 3 1 env49428 = env49429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49428 == env49429) = true)

theorem identity49429 : scanCanonicalize (H12AffineFastState.compose env49429 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound49429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49430 : List Nat := [2,4,4,1,5,1,6,6,3,7,7,1,6,0,1,7,0,1,7,0,0,0,1,7,4,0,1,0,1,1,7,1,6,2,1,2]

theorem envBound49430 : H12AffineFastState.Bounded env49430 := by
  intro p hp
  have h : env49430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49429_49430 : H12AffineEnvironment.transform 4 5 env49429 = env49430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env49429 == env49430) = true)

theorem identity49430 : scanCanonicalize (H12AffineFastState.compose env49430 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49430 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env49431 : List Nat := [2,1,1,1,0,1,3,3,3,2,2,1,3,0,1,2,0,1,2,0,0,0,1,2,1,0,1,0,1,1,2,1,3,2,1,2]

theorem envBound49431 : H12AffineFastState.Bounded env49431 := by
  intro p hp
  have h : env49431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49430_49431 : H12AffineEnvironment.transform 1 1 env49430 = env49431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49430 == env49431) = true)

theorem identity49431 : scanCanonicalize (H12AffineFastState.compose env49431 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49432 : List Nat := [1,1,1,1,0,1,0,0,0,1,1,1,0,0,1,1,0,1,1,0,0,0,1,1,1,0,1,0,1,1,1,1,0,1,1,1]

theorem envBound49432 : H12AffineFastState.Bounded env49432 := by
  intro p hp
  have h : env49432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49431_49432 : H12AffineEnvironment.transform 0 1 env49431 = env49432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49431 == env49432) = true)

def env49433 : List Nat := [2,4,8,16,32,64,128,129,212,193,2048,16,8192,80,8397,8446,81,8318,208,8396,17,93,65,8446,8345,1,175,1,81,2276,8205,64,129,8281,1,196]

theorem envBound49433 : H12AffineFastState.Bounded env49433 := by
  intro p hp
  have h : env49433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49422_49433 : H12AffineEnvironment.transform 7 129 env49422 = env49433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env49422 == env49433) = true)

theorem identity49433 : scanCanonicalize (H12AffineFastState.compose env49433 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 220) := by decide +kernel

theorem selectedBound49433 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49434 : List Nat := [2,4,8,16,32,64,128,129,212,193,2048,16,220,80,17,34,81,162,208,16,17,93,65,34,69,1,175,1,81,2276,209,64,129,133,1,196]

theorem envBound49434 : H12AffineFastState.Bounded env49434 := by
  intro p hp
  have h : env49434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49433_49434 : H12AffineEnvironment.transform 12 220 env49433 = env49434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 220 env49433 == env49434) = true)

theorem identity49434 : scanCanonicalize (H12AffineFastState.compose env49434 (packedSelected [5,10,13,21] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49434 : packedSelected [5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env49435 : List Nat := [2,2,8,16,32,64,128,129,210,193,2048,16,218,80,17,34,81,162,208,16,17,91,65,34,67,1,169,1,81,2274,209,64,129,131,1,194]

theorem envBound49435 : H12AffineFastState.Bounded env49435 := by
  intro p hp
  have h : env49435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49434_49435 : H12AffineEnvironment.transform 1 2 env49434 = env49435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49434 == env49435) = true)

theorem identity49435 : scanCanonicalize (H12AffineFastState.compose env49435 (packedSelected [1,3,5,10,13,15,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound49435 : packedSelected [1,3,5,10,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env49436 : List Nat := [2,2,8,16,32,64,128,129,210,193,227,16,218,80,17,34,81,162,208,16,17,91,65,34,67,1,169,1,81,1,209,64,129,131,1,194]

theorem envBound49436 : H12AffineFastState.Bounded env49436 := by
  intro p hp
  have h : env49436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49435_49436 : H12AffineEnvironment.transform 10 227 env49435 = env49436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env49435 == env49436) = true)

theorem identity49436 : scanCanonicalize (H12AffineFastState.compose env49436 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound49436 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env49437 : List Nat := [2,2,8,16,32,59,128,129,169,186,152,16,161,43,17,34,42,162,171,16,17,32,58,34,56,1,169,1,42,1,170,59,129,131,1,185]

theorem envBound49437 : H12AffineFastState.Bounded env49437 := by
  intro p hp
  have h : env49437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49436_49437 : H12AffineEnvironment.transform 5 59 env49436 = env49437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env49436 == env49437) = true)

theorem identity49437 : scanCanonicalize (H12AffineFastState.compose env49437 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49437 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env49438 : List Nat := [2,2,8,16,16,11,128,129,153,138,152,16,145,27,17,18,26,146,155,16,17,16,10,18,8,1,153,1,26,1,154,11,129,131,1,137]

theorem envBound49438 : H12AffineFastState.Bounded env49438 := by
  intro p hp
  have h : env49438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49437_49438 : H12AffineEnvironment.transform 4 16 env49437 = env49438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49437 == env49438) = true)

theorem identity49438 : scanCanonicalize (H12AffineFastState.compose env49438 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound49438 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49439 : List Nat := [2,2,8,16,16,11,3,2,26,9,27,16,18,27,17,18,26,17,24,16,17,16,10,18,8,1,26,1,26,1,25,11,2,0,1,10]

theorem envBound49439 : H12AffineFastState.Bounded env49439 := by
  intro p hp
  have h : env49439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49438_49439 : H12AffineEnvironment.transform 6 3 env49438 = env49439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env49438 == env49439) = true)

theorem identity49439 : scanCanonicalize (H12AffineFastState.compose env49439 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49440 : List Nat := [2,2,8,11,11,11,3,2,1,9,0,11,9,0,10,9,1,10,3,11,10,11,10,9,8,1,1,1,1,1,2,11,2,0,1,10]

theorem envBound49440 : H12AffineFastState.Bounded env49440 := by
  intro p hp
  have h : env49440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49439_49440 : H12AffineEnvironment.transform 3 11 env49439 = env49440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49439 == env49440) = true)

theorem identity49440 : scanCanonicalize (H12AffineFastState.compose env49440 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49441 : List Nat := [2,2,3,0,0,0,3,2,1,2,0,0,2,0,1,2,1,1,3,0,1,0,1,2,3,1,1,1,1,1,2,0,2,0,1,1]

theorem envBound49441 : H12AffineFastState.Bounded env49441 := by
  intro p hp
  have h : env49441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49440_49441 : H12AffineEnvironment.transform 2 3 env49440 = env49441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49440 == env49441) = true)

def env49442 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8525,65536,74030,65664,336,8524,16,476,74046,65537,8344,74111,303,74110,81,75803,8205,64,256,65830,1,324]

theorem envBound49442 : H12AffineFastState.Bounded env49442 := by
  intro p hp
  have h : env49442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49420_49442 : H12AffineEnvironment.transform 11 17 env49420 = env49442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49420 == env49442) = true)

theorem identity49442 : scanCanonicalize (H12AffineFastState.compose env49442 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 183) := by decide +kernel

theorem selectedBound49442 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49443 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8525,183,8601,55,336,8524,16,476,8585,182,8344,8648,303,8649,81,10412,8205,64,256,401,1,324]

theorem envBound49443 : H12AffineFastState.Bounded env49443 := by
  intro p hp
  have h : env49443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49442_49443 : H12AffineEnvironment.transform 15 183 env49442 = env49443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 183 env49442 == env49443) = true)

def env49444 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,8192,64,8525,167,8585,39,320,8524,0,460,8585,166,8328,8648,303,8649,65,10412,8205,64,256,385,1,324]

theorem envBound49444 : H12AffineFastState.Bounded env49444 := by
  intro p hp
  have h : env49444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49443_49444 : H12AffineEnvironment.transform 3 0 env49443 = env49444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49443 == env49444) = true)

theorem identity49444 : scanCanonicalize (H12AffineFastState.compose env49444 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49444 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49445 : List Nat := [2,4,8,0,32,64,5,256,325,320,2048,1,8192,64,8525,34,8460,39,320,8524,0,329,8460,35,8205,8525,303,8524,65,10281,8205,64,256,260,1,324]

theorem envBound49445 : H12AffineFastState.Bounded env49445 := by
  intro p hp
  have h : env49445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49444_49445 : H12AffineEnvironment.transform 6 5 env49444 = env49445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49444 == env49445) = true)

theorem identity49445 : scanCanonicalize (H12AffineFastState.compose env49445 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49445 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49446 : List Nat := [2,4,8,0,32,64,5,4,65,68,2048,1,8192,64,8265,34,8200,39,68,8264,0,77,8200,35,8205,8265,43,8264,65,10281,8205,64,4,0,1,64]

theorem envBound49446 : H12AffineFastState.Bounded env49446 := by
  intro p hp
  have h : env49446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49445_49446 : H12AffineEnvironment.transform 7 4 env49445 = env49446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49445 == env49446) = true)

theorem identity49446 : scanCanonicalize (H12AffineFastState.compose env49446 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49446 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49447 : List Nat := [2,4,8,0,32,64,5,4,65,68,2048,1,9,64,64,34,1,39,68,65,0,77,1,35,4,64,43,65,65,2080,4,64,4,0,1,64]

theorem envBound49447 : H12AffineFastState.Bounded env49447 := by
  intro p hp
  have h : env49447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49446_49447 : H12AffineEnvironment.transform 12 9 env49446 = env49447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49446 == env49447) = true)

theorem identity49447 : scanCanonicalize (H12AffineFastState.compose env49447 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound49447 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env49448 : List Nat := [2,4,8,0,32,64,5,4,65,68,103,1,9,64,64,34,1,39,68,65,0,77,1,35,4,64,43,65,65,71,4,64,4,0,1,64]

theorem envBound49448 : H12AffineFastState.Bounded env49448 := by
  intro p hp
  have h : env49448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49447_49448 : H12AffineEnvironment.transform 10 103 env49447 = env49448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env49447 == env49448) = true)

theorem identity49448 : scanCanonicalize (H12AffineFastState.compose env49448 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49448 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49449 : List Nat := [2,4,2,0,32,64,5,4,65,68,103,1,3,64,64,34,1,39,68,65,0,71,1,35,4,64,33,65,65,71,4,64,4,0,1,64]

theorem envBound49449 : H12AffineFastState.Bounded env49449 := by
  intro p hp
  have h : env49449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49448_49449 : H12AffineEnvironment.transform 2 2 env49448 = env49449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49448 == env49449) = true)

theorem identity49449 : scanCanonicalize (H12AffineFastState.compose env49449 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound49449 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49450 : List Nat := [2,4,2,0,32,6,5,4,7,2,33,1,3,6,6,34,1,39,2,7,0,1,1,35,4,6,33,7,7,1,4,6,4,0,1,6]

theorem envBound49450 : H12AffineFastState.Bounded env49450 := by
  intro p hp
  have h : env49450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49449_49450 : H12AffineEnvironment.transform 5 6 env49449 = env49450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env49449 == env49450) = true)

theorem identity49450 : scanCanonicalize (H12AffineFastState.compose env49450 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound49450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49451 : List Nat := [2,4,2,0,5,6,5,4,7,2,4,1,3,6,6,7,1,2,2,7,0,1,1,6,4,6,4,7,7,1,4,6,4,0,1,6]

theorem envBound49451 : H12AffineFastState.Bounded env49451 := by
  intro p hp
  have h : env49451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49450_49451 : H12AffineEnvironment.transform 4 5 env49450 = env49451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env49450 == env49451) = true)

theorem identity49451 : scanCanonicalize (H12AffineFastState.compose env49451 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49451 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env49452 : List Nat := [2,2,2,0,3,0,3,2,1,2,2,1,3,0,0,1,1,2,2,1,0,1,1,0,2,0,2,1,1,1,2,0,2,0,1,0]

theorem envBound49452 : H12AffineFastState.Bounded env49452 := by
  intro p hp
  have h : env49452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49451_49452 : H12AffineEnvironment.transform 1 2 env49451 = env49452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49451 == env49452) = true)

theorem identity49452 : scanCanonicalize (H12AffineFastState.compose env49452 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49452 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env49453 : List Nat := [1,1,1,0,0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,1,0,1,1,0,1,0,1,1,1,1,1,0,1,0,1,0]

theorem envBound49453 : H12AffineFastState.Bounded env49453 := by
  intro p hp
  have h : env49453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49452_49453 : H12AffineEnvironment.transform 0 1 env49452 = env49453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49452 == env49453) = true)

def env49454 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,8192,65,8525,166,8584,38,321,8524,1,461,8585,167,8329,8648,303,8649,64,10412,8205,64,256,384,1,324]

theorem envBound49454 : H12AffineFastState.Bounded env49454 := by
  intro p hp
  have h : env49454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49443_49454 : H12AffineEnvironment.transform 3 1 env49443 = env49454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49443 == env49454) = true)

theorem identity49454 : scanCanonicalize (H12AffineFastState.compose env49454 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound49454 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49455 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,332,65,1,166,196,38,321,0,1,461,197,167,453,132,303,133,64,2528,321,64,256,384,1,324]

theorem envBound49455 : H12AffineFastState.Bounded env49455 := by
  intro p hp
  have h : env49455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49454_49455 : H12AffineEnvironment.transform 12 332 env49454 = env49455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env49454 == env49455) = true)

theorem identity49455 : scanCanonicalize (H12AffineFastState.compose env49455 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49455 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49456 : List Nat := [2,4,8,1,32,0,128,256,260,256,2048,0,268,1,1,166,132,38,257,0,1,397,133,167,389,132,303,133,0,2464,257,0,256,384,1,260]

theorem envBound49456 : H12AffineFastState.Bounded env49456 := by
  intro p hp
  have h : env49456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49455_49456 : H12AffineEnvironment.transform 5 0 env49455 = env49456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49455 == env49456) = true)

theorem identity49456 : scanCanonicalize (H12AffineFastState.compose env49456 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound49456 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env49457 : List Nat := [2,4,8,1,32,0,128,256,260,256,264,0,268,1,1,166,132,38,257,0,1,397,133,167,389,132,303,133,0,168,257,0,256,384,1,260]

theorem envBound49457 : H12AffineFastState.Bounded env49457 := by
  intro p hp
  have h : env49457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49456_49457 : H12AffineEnvironment.transform 10 264 env49456 = env49457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env49456 == env49457) = true)

theorem identity49457 : scanCanonicalize (H12AffineFastState.compose env49457 (packedSelected [0,1,3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49457 : packedSelected [0,1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49458 : List Nat := [2,4,8,1,32,0,5,256,260,256,264,0,268,1,1,35,1,38,257,0,1,264,0,34,256,1,303,0,0,45,257,0,256,261,1,260]

theorem envBound49458 : H12AffineFastState.Bounded env49458 := by
  intro p hp
  have h : env49458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49457_49458 : H12AffineEnvironment.transform 6 5 env49457 = env49458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49457 == env49458) = true)

theorem identity49458 : scanCanonicalize (H12AffineFastState.compose env49458 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49458 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49459 : List Nat := [2,3,8,1,32,0,2,256,259,256,264,0,267,1,1,35,1,33,257,0,1,264,0,34,256,1,296,0,0,42,257,0,256,258,1,259]

theorem envBound49459 : H12AffineFastState.Bounded env49459 := by
  intro p hp
  have h : env49459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49458_49459 : H12AffineEnvironment.transform 1 3 env49458 = env49459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49458 == env49459) = true)

theorem identity49459 : scanCanonicalize (H12AffineFastState.compose env49459 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49459 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env49460 : List Nat := [2,3,8,1,1,0,2,256,259,256,264,0,267,1,1,2,1,0,257,0,1,264,0,3,256,1,265,0,0,11,257,0,256,258,1,259]

theorem envBound49460 : H12AffineFastState.Bounded env49460 := by
  intro p hp
  have h : env49460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49459_49460 : H12AffineEnvironment.transform 4 1 env49459 = env49460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49459 == env49460) = true)

theorem identity49460 : scanCanonicalize (H12AffineFastState.compose env49460 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound49460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49461 : List Nat := [2,3,8,1,1,0,2,9,10,9,1,0,2,1,1,2,1,0,8,0,1,1,0,3,9,1,0,0,0,11,8,0,9,11,1,10]

theorem envBound49461 : H12AffineFastState.Bounded env49461 := by
  intro p hp
  have h : env49461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49460_49461 : H12AffineEnvironment.transform 7 9 env49460 = env49461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env49460 == env49461) = true)

theorem identity49461 : scanCanonicalize (H12AffineFastState.compose env49461 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49462 : List Nat := [2,3,3,1,1,0,2,2,1,2,1,0,2,1,1,2,1,0,3,0,1,1,0,3,2,1,0,0,0,0,3,0,2,0,1,1]

theorem envBound49462 : H12AffineFastState.Bounded env49462 := by
  intro p hp
  have h : env49462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49461_49462 : H12AffineEnvironment.transform 2 3 env49461 = env49462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49461 == env49462) = true)

def env49463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4097,476,74046,69648,13769,78894,4415,74814,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound49463 : H12AffineFastState.Bounded env49463 := by
  intro p hp
  have h : env49463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49379_49463 : H12AffineEnvironment.transform 17 65665 env49379 = env49463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49379 == env49463) = true)

theorem identity49463 : scanCanonicalize (H12AffineFastState.compose env49463 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound49463 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,65536,74862,65665,320,9244,0,476,74046,65553,9672,74799,318,74814,1297,77131,8205,1280,256,65830,1345,1857]

theorem envBound49464 : H12AffineFastState.Bounded env49464 := by
  intro p hp
  have h : env49464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49463_49464 : H12AffineEnvironment.transform 11 1 env49463 = env49464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49463 == env49464) = true)

def env49465 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1296,9245,65536,74862,65665,320,9244,0,476,74046,65553,9672,74799,318,74814,1297,77131,8205,1280,256,65830,1345,1045]

theorem envBound49465 : H12AffineFastState.Bounded env49465 := by
  intro p hp
  have h : env49465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49464_49465 : H12AffineEnvironment.transform 8 340 env49464 = env49465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env49464 == env49465) = true)

def env49466 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1280,9229,65536,74862,65665,320,9228,0,460,74030,65537,9672,74799,302,74798,1281,77131,8205,1280,256,65830,1345,1029]

theorem envBound49466 : H12AffineFastState.Bounded env49466 := by
  intro p hp
  have h : env49466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49465_49466 : H12AffineEnvironment.transform 3 0 env49465 = env49466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49465 == env49466) = true)

theorem identity49466 : scanCanonicalize (H12AffineFastState.compose env49466 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 392) := by decide +kernel

theorem selectedBound49466 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49467 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,392,1280,1413,65536,67046,65665,320,1412,0,460,65702,65537,1088,66983,302,66982,1281,68803,389,1280,256,65830,1345,1029]

theorem envBound49467 : H12AffineFastState.Bounded env49467 := by
  intro p hp
  have h : env49467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49466_49467 : H12AffineEnvironment.transform 12 392 env49466 = env49467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 392 env49466 == env49467) = true)

def env49468 : List Nat := [2,4,8,0,32,64,128,256,324,1024,260,1,392,1280,1413,65536,67046,65665,320,1412,0,460,65702,65537,1088,66983,302,66982,1281,67015,389,1280,256,65830,1345,1029]

theorem envBound49468 : H12AffineFastState.Bounded env49468 := by
  intro p hp
  have h : env49468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49467_49468 : H12AffineEnvironment.transform 10 260 env49467 = env49468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env49467 == env49468) = true)

theorem identity49468 : scanCanonicalize (H12AffineFastState.compose env49468 (packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound49468 : packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS < 2^1333 := by decide +kernel

def env49469 : List Nat := [2,4,8,0,32,64,128,256,324,1024,260,1,392,1280,1413,1378,132,1507,320,1412,0,460,1476,1379,1088,197,302,196,1281,165,389,1280,256,1092,1345,1029]

theorem envBound49469 : H12AffineFastState.Bounded env49469 := by
  intro p hp
  have h : env49469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49468_49469 : H12AffineEnvironment.transform 15 1378 env49468 = env49469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env49468 == env49469) = true)

theorem identity49469 : scanCanonicalize (H12AffineFastState.compose env49469 (packedSelected [0,1,2,3,4,5,7,9,11,12,16,17,18,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound49469 : packedSelected [0,1,2,3,4,5,7,9,11,12,16,17,18,20,24] rootPS < 2^1333 := by decide +kernel

def env49470 : List Nat := [2,4,8,0,32,64,128,256,324,4,260,1,392,260,385,358,132,487,320,384,0,460,448,359,68,197,302,196,261,165,389,260,256,64,325,1]

theorem envBound49470 : H12AffineFastState.Bounded env49470 := by
  intro p hp
  have h : env49470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49469_49470 : H12AffineEnvironment.transform 9 4 env49469 = env49470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env49469 == env49470) = true)

theorem identity49470 : scanCanonicalize (H12AffineFastState.compose env49470 (packedSelected [1,2,3,4,5,9,10,12,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound49470 : packedSelected [1,2,3,4,5,9,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49471 : List Nat := [2,4,8,0,32,12,128,256,264,4,260,1,392,260,385,298,132,427,268,384,0,384,396,299,8,137,302,136,261,165,389,260,256,12,265,1]

theorem envBound49471 : H12AffineFastState.Bounded env49471 := by
  intro p hp
  have h : env49471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49470_49471 : H12AffineEnvironment.transform 5 12 env49470 = env49471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env49470 == env49471) = true)

theorem identity49471 : scanCanonicalize (H12AffineFastState.compose env49471 (packedSelected [0,3,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound49471 : packedSelected [0,3,7,10] rootPS < 2^1333 := by decide +kernel

def env49472 : List Nat := [2,4,8,0,32,12,36,256,264,4,260,1,300,260,293,298,32,271,268,292,0,292,296,299,8,45,302,44,261,1,289,260,256,12,265,1]

theorem envBound49472 : H12AffineFastState.Bounded env49472 := by
  intro p hp
  have h : env49472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49471_49472 : H12AffineEnvironment.transform 6 36 env49471 = env49472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env49471 == env49472) = true)

theorem identity49472 : scanCanonicalize (H12AffineFastState.compose env49472 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound49472 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env49473 : List Nat := [2,4,8,0,32,12,36,40,32,4,44,1,4,44,13,2,32,39,36,12,0,12,0,3,8,45,6,44,45,1,9,44,40,12,33,1]

theorem envBound49473 : H12AffineFastState.Bounded env49473 := by
  intro p hp
  have h : env49473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49472_49473 : H12AffineEnvironment.transform 7 40 env49472 = env49473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env49472 == env49473) = true)

theorem identity49473 : scanCanonicalize (H12AffineFastState.compose env49473 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49473 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env49474 : List Nat := [2,4,8,0,1,12,5,9,1,4,13,1,4,13,13,2,1,6,5,12,0,12,0,3,8,12,6,13,12,1,9,13,9,12,0,1]

theorem envBound49474 : H12AffineFastState.Bounded env49474 := by
  intro p hp
  have h : env49474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49473_49474 : H12AffineEnvironment.transform 4 1 env49473 = env49474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49473 == env49474) = true)

theorem identity49474 : scanCanonicalize (H12AffineFastState.compose env49474 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49475 : List Nat := [2,4,4,0,1,0,5,5,1,4,1,1,4,1,1,2,1,6,5,0,0,0,0,3,4,0,6,1,0,1,5,1,5,0,0,1]

theorem envBound49475 : H12AffineFastState.Bounded env49475 := by
  intro p hp
  have h : env49475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49474_49475 : H12AffineEnvironment.transform 2 4 env49474 = env49475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49474 == env49475) = true)

def env49476 : List Nat := [2,4,8,0,32,64,128,256,324,1024,261,1,392,1280,1413,65536,67046,65665,320,1412,0,460,65702,65537,1088,66983,302,66982,1281,67014,389,1280,256,65830,1345,1029]

theorem envBound49476 : H12AffineFastState.Bounded env49476 := by
  intro p hp
  have h : env49476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49467_49476 : H12AffineEnvironment.transform 10 261 env49467 = env49476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env49467 == env49476) = true)

theorem identity49476 : scanCanonicalize (H12AffineFastState.compose env49476 (packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound49476 : packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS < 2^1333 := by decide +kernel

def env49477 : List Nat := [2,4,8,0,32,64,128,69,1,1024,64,1,205,1093,1216,65536,66723,65665,5,1217,0,137,65702,65537,1088,66786,107,66787,1092,66691,192,1093,69,65635,1028,1029]

theorem envBound49477 : H12AffineFastState.Bounded env49477 := by
  intro p hp
  have h : env49477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49476_49477 : H12AffineEnvironment.transform 7 69 env49476 = env49477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env49476 == env49477) = true)

theorem identity49477 : scanCanonicalize (H12AffineFastState.compose env49477 (packedSelected [0,2,8,10,11,12,17,18,19,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 1250) := by decide +kernel

theorem selectedBound49477 : packedSelected [0,2,8,10,11,12,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env49478 : List Nat := [2,4,8,0,32,64,128,69,1,1024,64,1,205,1093,1216,1250,65,1123,5,1217,0,137,1092,1251,1088,0,107,1,1092,97,192,1093,69,1153,1028,1029]

theorem envBound49478 : H12AffineFastState.Bounded env49478 := by
  intro p hp
  have h : env49478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49477_49478 : H12AffineEnvironment.transform 15 1250 env49477 = env49478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1250 env49477 == env49478) = true)

theorem identity49478 : scanCanonicalize (H12AffineFastState.compose env49478 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound49478 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49479 : List Nat := [2,4,8,0,32,64,69,69,1,1024,64,1,8,1093,1029,1063,65,1123,5,1028,0,76,1092,1062,1088,0,107,1,1092,97,5,1093,69,1092,1028,1029]

theorem envBound49479 : H12AffineFastState.Bounded env49479 := by
  intro p hp
  have h : env49479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49478_49479 : H12AffineEnvironment.transform 6 69 env49478 = env49479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env49478 == env49479) = true)

theorem identity49479 : scanCanonicalize (H12AffineFastState.compose env49479 (packedSelected [0,2,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 67) := by decide +kernel

theorem selectedBound49479 : packedSelected [0,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env49480 : List Nat := [2,4,8,0,32,64,69,69,1,67,64,1,8,6,70,100,65,32,5,71,0,76,7,101,3,0,107,1,7,97,5,6,69,7,71,70]

theorem envBound49480 : H12AffineFastState.Bounded env49480 := by
  intro p hp
  have h : env49480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49479_49480 : H12AffineEnvironment.transform 9 67 env49479 = env49480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 67 env49479 == env49480) = true)

theorem identity49480 : scanCanonicalize (H12AffineFastState.compose env49480 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound49480 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env49481 : List Nat := [2,4,8,0,32,38,35,35,1,37,38,1,8,6,32,2,39,32,5,33,0,42,7,3,3,0,13,1,7,7,5,6,35,7,33,32]

theorem envBound49481 : H12AffineFastState.Bounded env49481 := by
  intro p hp
  have h : env49481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49480_49481 : H12AffineEnvironment.transform 5 38 env49480 = env49481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env49480 == env49481) = true)

theorem identity49481 : scanCanonicalize (H12AffineFastState.compose env49481 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49481 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49482 : List Nat := [2,3,8,0,32,33,35,35,1,34,33,1,8,1,32,2,32,32,2,33,0,42,0,3,3,0,10,1,0,0,2,1,35,0,33,32]

theorem envBound49482 : H12AffineFastState.Bounded env49482 := by
  intro p hp
  have h : env49482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49481_49482 : H12AffineEnvironment.transform 1 3 env49481 = env49482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49481 == env49482) = true)

theorem identity49482 : scanCanonicalize (H12AffineFastState.compose env49482 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49482 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49483 : List Nat := [2,3,8,0,0,1,3,3,1,2,1,1,8,1,0,2,0,0,2,1,0,10,0,3,3,0,10,1,0,0,2,1,3,0,1,0]

theorem envBound49483 : H12AffineFastState.Bounded env49483 := by
  intro p hp
  have h : env49483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49482_49483 : H12AffineEnvironment.transform 4 0 env49482 = env49483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49482 == env49483) = true)

theorem identity49483 : scanCanonicalize (H12AffineFastState.compose env49483 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49483 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49484 : List Nat := [2,3,1,0,0,1,3,3,1,2,1,1,1,1,0,2,0,0,2,1,0,3,0,3,3,0,3,1,0,0,2,1,3,0,1,0]

theorem envBound49484 : H12AffineFastState.Bounded env49484 := by
  intro p hp
  have h : env49484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49483_49484 : H12AffineEnvironment.transform 2 1 env49483 = env49484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49483 == env49484) = true)

theorem identity49484 : scanCanonicalize (H12AffineFastState.compose env49484 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49484 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env49485 : List Nat := [0,1,1,0,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,1,0,1,0,1,1,0,1,1,0,0,0,1,1,0,1,0]

theorem envBound49485 : H12AffineFastState.Bounded env49485 := by
  intro p hp
  have h : env49485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49484_49485 : H12AffineEnvironment.transform 0 0 env49484 = env49485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49484 == env49485) = true)

def env49486 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1281,9228,65536,74862,65665,320,9229,0,461,74031,65536,9672,74799,303,74799,1280,77131,8205,1280,256,65830,1345,1028]

theorem envBound49486 : H12AffineFastState.Bounded env49486 := by
  intro p hp
  have h : env49486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49465_49486 : H12AffineEnvironment.transform 3 1 env49465 = env49486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49465 == env49486) = true)

theorem identity49486 : scanCanonicalize (H12AffineFastState.compose env49486 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 128) := by decide +kernel

theorem selectedBound49486 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49487 : List Nat := [2,4,8,1,32,64,128,256,325,128,2048,1,8192,385,8332,65536,73966,65665,320,8333,0,461,74031,65536,8520,73903,303,73903,384,76235,8205,384,256,65830,449,132]

theorem envBound49487 : H12AffineFastState.Bounded env49487 := by
  intro p hp
  have h : env49487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49486_49487 : H12AffineEnvironment.transform 9 128 env49486 = env49487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env49486 == env49487) = true)

def env49488 : List Nat := [2,4,8,1,32,64,128,256,325,128,260,1,8192,385,8332,65536,73966,65665,320,8333,0,461,74031,65536,8520,73903,303,73903,384,73935,8205,384,256,65830,449,132]

theorem envBound49488 : H12AffineFastState.Bounded env49488 := by
  intro p hp
  have h : env49488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49487_49488 : H12AffineEnvironment.transform 10 260 env49487 = env49488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env49487 == env49488) = true)

theorem identity49488 : scanCanonicalize (H12AffineFastState.compose env49488 (packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound49488 : packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS < 2^1333 := by decide +kernel

def env49489 : List Nat := [2,4,8,1,32,64,128,256,325,128,260,1,8192,385,8332,8298,132,8427,320,8333,0,461,325,8298,8520,197,303,197,384,165,8205,384,256,8524,449,132]

theorem envBound49489 : H12AffineFastState.Bounded env49489 := by
  intro p hp
  have h : env49489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49488_49489 : H12AffineEnvironment.transform 15 8298 env49488 = env49489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env49488 == env49489) = true)

theorem identity49489 : scanCanonicalize (H12AffineFastState.compose env49489 (packedSelected [0,2,4,7,8,9,10,11,12,16,17,18,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound49489 : packedSelected [0,2,4,7,8,9,10,11,12,16,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env49490 : List Nat := [2,4,8,1,32,64,128,129,196,128,133,1,8192,0,8332,8298,132,8427,193,8333,0,76,196,8298,8393,197,174,197,1,165,8205,1,129,8397,64,132]

theorem envBound49490 : H12AffineFastState.Bounded env49490 := by
  intro p hp
  have h : env49490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49489_49490 : H12AffineEnvironment.transform 7 129 env49489 = env49490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env49489 == env49490) = true)

theorem identity49490 : scanCanonicalize (H12AffineFastState.compose env49490 (packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 135) := by decide +kernel

theorem selectedBound49490 : packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env49491 : List Nat := [2,4,8,1,32,64,128,129,196,128,133,1,135,0,11,237,132,108,193,10,0,76,196,237,78,197,174,197,1,165,138,1,129,74,64,132]

theorem envBound49491 : H12AffineFastState.Bounded env49491 := by
  intro p hp
  have h : env49491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49490_49491 : H12AffineEnvironment.transform 12 135 env49490 = env49491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 135 env49490 == env49491) = true)

theorem identity49491 : scanCanonicalize (H12AffineFastState.compose env49491 (packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound49491 : packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49492 : List Nat := [2,4,8,1,32,45,128,129,169,128,133,1,135,0,11,128,132,1,172,10,0,33,169,128,35,168,174,168,1,165,138,1,129,39,45,132]

theorem envBound49492 : H12AffineFastState.Bounded env49492 := by
  intro p hp
  have h : env49492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49491_49492 : H12AffineEnvironment.transform 5 45 env49491 = env49492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env49491 == env49492) = true)

theorem identity49492 : scanCanonicalize (H12AffineFastState.compose env49492 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49492 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49493 : List Nat := [2,4,8,1,11,6,128,129,130,128,133,1,135,0,11,128,132,1,135,10,0,10,130,128,8,131,133,131,1,142,138,1,129,12,6,132]

theorem envBound49493 : H12AffineFastState.Bounded env49493 := by
  intro p hp
  have h : env49493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49492_49493 : H12AffineEnvironment.transform 4 11 env49492 = env49493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49492 == env49493) = true)

theorem identity49493 : scanCanonicalize (H12AffineFastState.compose env49493 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49493 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env49494 : List Nat := [2,2,8,1,11,0,128,129,130,128,131,1,129,0,11,128,130,1,129,10,0,10,130,128,8,131,131,131,1,136,138,1,129,10,0,130]

theorem envBound49494 : H12AffineFastState.Bounded env49494 := by
  intro p hp
  have h : env49494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49493_49494 : H12AffineEnvironment.transform 1 2 env49493 = env49494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49493 == env49494) = true)

theorem identity49494 : scanCanonicalize (H12AffineFastState.compose env49494 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49495 : List Nat := [2,2,3,1,0,0,128,129,130,128,131,1,129,0,0,128,130,1,129,1,0,1,130,128,3,131,131,131,1,131,129,1,129,1,0,130]

theorem envBound49495 : H12AffineFastState.Bounded env49495 := by
  intro p hp
  have h : env49495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49494_49495 : H12AffineEnvironment.transform 2 3 env49494 = env49495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49494 == env49495) = true)

theorem identity49495 : scanCanonicalize (H12AffineFastState.compose env49495 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound49495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49496 : List Nat := [2,2,3,1,0,0,3,2,1,3,0,1,2,0,0,3,1,1,2,1,0,1,1,3,3,0,0,0,1,0,2,1,2,1,0,1]

theorem envBound49496 : H12AffineFastState.Bounded env49496 := by
  intro p hp
  have h : env49496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49495_49496 : H12AffineEnvironment.transform 6 3 env49495 = env49496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env49495 == env49496) = true)

def env49497 : List Nat := [2,4,8,1,32,64,128,256,325,128,261,1,8192,385,8332,65536,73966,65665,320,8333,0,461,74031,65536,8520,73903,303,73903,384,73934,8205,384,256,65830,449,132]

theorem envBound49497 : H12AffineFastState.Bounded env49497 := by
  intro p hp
  have h : env49497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49487_49497 : H12AffineEnvironment.transform 10 261 env49487 = env49497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env49487 == env49497) = true)

theorem identity49497 : scanCanonicalize (H12AffineFastState.compose env49497 (packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS)) = affineNative (2^(12+1) ^^^ 205) := by decide +kernel

theorem selectedBound49497 : packedSelected [0,2,7,8,10,11,12,15,18,19,20,24,41] rootPS < 2^1333 := by decide +kernel

def env49498 : List Nat := [2,4,8,1,32,64,128,256,325,128,261,1,205,385,65,65536,65571,65665,320,64,0,461,66018,65536,389,65634,303,65634,384,65539,192,384,256,65830,449,132]

theorem envBound49498 : H12AffineFastState.Bounded env49498 := by
  intro p hp
  have h : env49498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49497_49498 : H12AffineEnvironment.transform 12 205 env49497 = env49498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env49497 == env49498) = true)

theorem identity49498 : scanCanonicalize (H12AffineFastState.compose env49498 (packedSelected [0,3,5,7,10,11,12,13,15,16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 288) := by decide +kernel

theorem selectedBound49498 : packedSelected [0,3,5,7,10,11,12,13,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env49499 : List Nat := [2,4,8,1,32,64,128,256,325,128,261,1,205,385,65,288,259,417,320,64,0,461,194,288,389,322,303,322,384,291,192,384,256,6,449,132]

theorem envBound49499 : H12AffineFastState.Bounded env49499 := by
  intro p hp
  have h : env49499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49498_49499 : H12AffineEnvironment.transform 15 288 env49498 = env49499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 288 env49498 == env49499) = true)

theorem identity49499 : scanCanonicalize (H12AffineFastState.compose env49499 (packedSelected [0,2,3,9,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound49499 : packedSelected [0,2,3,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49500 : List Nat := [2,4,8,1,32,64,128,134,195,128,131,1,205,7,65,166,133,39,198,64,0,75,194,166,3,196,169,196,6,165,192,6,134,6,71,132]

theorem envBound49500 : H12AffineFastState.Bounded env49500 := by
  intro p hp
  have h : env49500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49499_49500 : H12AffineEnvironment.transform 7 134 env49499 = env49500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env49499 == env49500) = true)

theorem identity49500 : scanCanonicalize (H12AffineFastState.compose env49500 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound49500 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49501 : List Nat := [2,4,8,1,32,38,128,134,165,128,131,1,171,7,39,166,133,39,160,38,0,45,164,166,3,162,169,162,6,165,166,6,134,6,33,132]

theorem envBound49501 : H12AffineFastState.Bounded env49501 := by
  intro p hp
  have h : env49501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49500_49501 : H12AffineEnvironment.transform 5 38 env49500 = env49501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env49500 == env49501) = true)

theorem identity49501 : scanCanonicalize (H12AffineFastState.compose env49501 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound49501 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49502 : List Nat := [2,4,8,1,32,38,2,4,39,2,1,1,41,7,39,36,7,39,34,38,0,45,38,36,3,32,43,32,6,39,36,6,4,6,33,6]

theorem envBound49502 : H12AffineFastState.Bounded env49502 := by
  intro p hp
  have h : env49502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49501_49502 : H12AffineEnvironment.transform 6 2 env49501 = env49502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env49501 == env49502) = true)

theorem identity49502 : scanCanonicalize (H12AffineFastState.compose env49502 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49502 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env49503 : List Nat := [2,4,5,1,32,38,2,4,39,2,1,1,36,7,39,36,7,39,34,38,0,32,38,36,3,32,38,32,6,39,36,6,4,6,33,6]

theorem envBound49503 : H12AffineFastState.Bounded env49503 := by
  intro p hp
  have h : env49503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49502_49503 : H12AffineEnvironment.transform 2 5 env49502 = env49503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49502 == env49503) = true)

theorem identity49503 : scanCanonicalize (H12AffineFastState.compose env49503 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49504 : List Nat := [2,3,2,1,32,33,2,3,32,2,1,1,35,0,32,35,0,32,34,33,0,32,33,35,3,32,33,32,1,32,35,1,3,1,33,1]

theorem envBound49504 : H12AffineFastState.Bounded env49504 := by
  intro p hp
  have h : env49504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49503_49504 : H12AffineEnvironment.transform 1 3 env49503 = env49504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49503 == env49504) = true)

def env49505 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1296,9245,65536,74862,65665,320,9244,0,476,74046,65553,9672,74799,318,74814,1297,77131,8205,1280,256,65830,1345,1044]

theorem envBound49505 : H12AffineFastState.Bounded env49505 := by
  intro p hp
  have h : env49505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49464_49505 : H12AffineEnvironment.transform 8 341 env49464 = env49505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env49464 == env49505) = true)

def env49506 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1280,9229,65536,74862,65665,320,9228,0,460,74030,65537,9672,74799,302,74798,1281,77131,8205,1280,256,65830,1345,1028]

theorem envBound49506 : H12AffineFastState.Bounded env49506 := by
  intro p hp
  have h : env49506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49505_49506 : H12AffineEnvironment.transform 3 0 env49505 = env49506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49505 == env49506) = true)

theorem identity49506 : scanCanonicalize (H12AffineFastState.compose env49506 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound49506 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49507 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1280,9229,167,9417,38,320,9228,0,460,8585,166,9672,9352,302,9353,1281,11756,8205,1280,256,385,1345,1028]

theorem envBound49507 : H12AffineFastState.Bounded env49507 := by
  intro p hp
  have h : env49507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49506_49507 : H12AffineEnvironment.transform 15 167 env49506 = env49507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env49506 == env49507) = true)

def env49508 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,8192,64,8525,167,8585,38,320,8524,0,460,8585,166,8328,8648,302,8649,65,10412,8205,64,256,385,1,324]

theorem envBound49508 : H12AffineFastState.Bounded env49508 := by
  intro p hp
  have h : env49508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49507_49508 : H12AffineEnvironment.transform 9 320 env49507 = env49508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49507 == env49508) = true)

theorem identity49508 : scanCanonicalize (H12AffineFastState.compose env49508 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49508 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49509 : List Nat := [2,4,8,0,32,64,5,256,325,320,2048,1,8192,64,8525,34,8460,38,320,8524,0,329,8460,35,8205,8525,302,8524,65,10281,8205,64,256,260,1,324]

theorem envBound49509 : H12AffineFastState.Bounded env49509 := by
  intro p hp
  have h : env49509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49508_49509 : H12AffineEnvironment.transform 6 5 env49508 = env49509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49508 == env49509) = true)

theorem identity49509 : scanCanonicalize (H12AffineFastState.compose env49509 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49509 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49510 : List Nat := [2,4,8,0,32,64,5,4,65,68,2048,1,8192,64,8265,34,8200,38,68,8264,0,77,8200,35,8205,8265,42,8264,65,10281,8205,64,4,0,1,64]

theorem envBound49510 : H12AffineFastState.Bounded env49510 := by
  intro p hp
  have h : env49510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49509_49510 : H12AffineEnvironment.transform 7 4 env49509 = env49510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49509 == env49510) = true)

theorem identity49510 : scanCanonicalize (H12AffineFastState.compose env49510 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49510 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49511 : List Nat := [2,4,8,0,32,64,5,4,65,68,2048,1,9,64,64,34,1,38,68,65,0,77,1,35,4,64,42,65,65,2080,4,64,4,0,1,64]

theorem envBound49511 : H12AffineFastState.Bounded env49511 := by
  intro p hp
  have h : env49511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49510_49511 : H12AffineEnvironment.transform 12 9 env49510 = env49511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49510 == env49511) = true)

theorem identity49511 : scanCanonicalize (H12AffineFastState.compose env49511 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound49511 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env49512 : List Nat := [2,4,8,0,32,64,5,4,65,68,103,1,9,64,64,34,1,38,68,65,0,77,1,35,4,64,42,65,65,71,4,64,4,0,1,64]

theorem envBound49512 : H12AffineFastState.Bounded env49512 := by
  intro p hp
  have h : env49512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49511_49512 : H12AffineEnvironment.transform 10 103 env49511 = env49512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env49511 == env49512) = true)

theorem identity49512 : scanCanonicalize (H12AffineFastState.compose env49512 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49512 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49513 : List Nat := [2,4,8,0,32,10,5,4,11,14,45,1,9,10,10,34,1,38,14,11,0,7,1,35,4,10,42,11,11,13,4,10,4,0,1,10]

theorem envBound49513 : H12AffineFastState.Bounded env49513 := by
  intro p hp
  have h : env49513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49512_49513 : H12AffineEnvironment.transform 5 10 env49512 = env49513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49512 == env49513) = true)

theorem identity49513 : scanCanonicalize (H12AffineFastState.compose env49513 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49513 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49514 : List Nat := [2,4,8,0,6,10,5,4,11,14,11,1,9,10,10,4,1,0,14,11,0,7,1,5,4,10,12,11,11,13,4,10,4,0,1,10]

theorem envBound49514 : H12AffineFastState.Bounded env49514 := by
  intro p hp
  have h : env49514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49513_49514 : H12AffineEnvironment.transform 4 6 env49513 = env49514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49513 == env49514) = true)

theorem identity49514 : scanCanonicalize (H12AffineFastState.compose env49514 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound49514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49515 : List Nat := [2,4,7,0,6,5,5,4,4,1,4,1,6,5,5,4,1,0,1,4,0,7,1,5,4,5,3,4,4,2,4,5,4,0,1,5]

theorem envBound49515 : H12AffineFastState.Bounded env49515 := by
  intro p hp
  have h : env49515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49514_49515 : H12AffineEnvironment.transform 2 7 env49514 = env49515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env49514 == env49515) = true)

theorem identity49515 : scanCanonicalize (H12AffineFastState.compose env49515 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49515 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49516 : List Nat := [2,2,1,0,0,3,3,2,2,1,2,1,0,3,3,2,1,0,1,2,0,1,1,3,2,3,3,2,2,2,2,3,2,0,1,3]

theorem envBound49516 : H12AffineFastState.Bounded env49516 := by
  intro p hp
  have h : env49516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49515_49516 : H12AffineEnvironment.transform 1 2 env49515 = env49516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49515 == env49516) = true)

theorem identity49516 : scanCanonicalize (H12AffineFastState.compose env49516 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49516 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49517 : List Nat := [0,0,1,0,0,1,1,0,0,1,0,1,0,1,1,0,1,0,1,0,0,1,1,1,0,1,1,0,0,0,0,1,0,0,1,1]

theorem envBound49517 : H12AffineFastState.Bounded env49517 := by
  intro p hp
  have h : env49517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49516_49517 : H12AffineEnvironment.transform 0 0 env49516 = env49517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49516 == env49517) = true)

def env49518 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,8192,65,8524,167,8584,38,320,8525,0,460,8585,166,8329,8649,302,8648,64,10413,8205,65,256,385,0,325]

theorem envBound49518 : H12AffineFastState.Bounded env49518 := by
  intro p hp
  have h : env49518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49507_49518 : H12AffineEnvironment.transform 9 321 env49507 = env49518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49507 == env49518) = true)

theorem identity49518 : scanCanonicalize (H12AffineFastState.compose env49518 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound49518 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49519 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,333,65,1,167,197,38,320,0,0,460,196,166,452,132,302,133,64,2528,320,65,256,385,0,325]

theorem envBound49519 : H12AffineFastState.Bounded env49519 := by
  intro p hp
  have h : env49519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49518_49519 : H12AffineEnvironment.transform 12 333 env49518 = env49519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env49518 == env49519) = true)

theorem identity49519 : scanCanonicalize (H12AffineFastState.compose env49519 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49519 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49520 : List Nat := [2,4,8,0,32,1,128,256,260,256,2048,1,268,0,1,167,132,38,257,0,0,397,133,166,389,132,302,133,1,2465,257,0,256,385,0,260]

theorem envBound49520 : H12AffineFastState.Bounded env49520 := by
  intro p hp
  have h : env49520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49519_49520 : H12AffineEnvironment.transform 5 1 env49519 = env49520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49519 == env49520) = true)

theorem identity49520 : scanCanonicalize (H12AffineFastState.compose env49520 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49520 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env49521 : List Nat := [2,4,3,0,32,1,128,256,260,256,2048,1,263,0,1,167,132,38,257,0,0,390,133,166,389,132,293,133,1,2465,257,0,256,385,0,260]

theorem envBound49521 : H12AffineFastState.Bounded env49521 := by
  intro p hp
  have h : env49521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49520_49521 : H12AffineEnvironment.transform 2 3 env49520 = env49521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49520 == env49521) = true)

theorem identity49521 : scanCanonicalize (H12AffineFastState.compose env49521 (packedSelected [0,2,3,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound49521 : packedSelected [0,2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49522 : List Nat := [2,4,3,0,32,1,128,160,164,160,2048,1,167,0,1,167,132,38,161,0,0,38,133,166,37,132,133,133,1,2049,161,0,160,33,0,164]

theorem envBound49522 : H12AffineFastState.Bounded env49522 := by
  intro p hp
  have h : env49522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49521_49522 : H12AffineEnvironment.transform 7 160 env49521 = env49522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env49521 == env49522) = true)

theorem identity49522 : scanCanonicalize (H12AffineFastState.compose env49522 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound49522 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49523 : List Nat := [2,4,3,0,32,1,128,160,164,160,164,1,167,0,1,167,132,38,161,0,0,38,133,166,37,132,133,133,1,165,161,0,160,33,0,164]

theorem envBound49523 : H12AffineFastState.Bounded env49523 := by
  intro p hp
  have h : env49523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49522_49523 : H12AffineEnvironment.transform 10 164 env49522 = env49523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env49522 == env49523) = true)

theorem identity49523 : scanCanonicalize (H12AffineFastState.compose env49523 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound49523 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49524 : List Nat := [2,4,3,0,32,1,36,4,0,4,0,1,3,0,1,3,32,38,5,0,0,38,33,2,37,32,33,33,1,1,5,0,4,33,0,0]

theorem envBound49524 : H12AffineFastState.Bounded env49524 := by
  intro p hp
  have h : env49524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49523_49524 : H12AffineEnvironment.transform 6 36 env49523 = env49524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env49523 == env49524) = true)

theorem identity49524 : scanCanonicalize (H12AffineFastState.compose env49524 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49525 : List Nat := [2,2,3,0,32,1,34,2,0,2,0,1,3,0,1,3,32,32,3,0,0,32,33,2,35,32,33,33,1,1,3,0,2,33,0,0]

theorem envBound49525 : H12AffineFastState.Bounded env49525 := by
  intro p hp
  have h : env49525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49524_49525 : H12AffineEnvironment.transform 1 2 env49524 = env49525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49524 == env49525) = true)

def env49526 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1281,9228,65536,74862,65665,320,9229,0,461,74031,65536,9672,74799,303,74799,1280,77131,8205,1280,256,65830,1345,1029]

theorem envBound49526 : H12AffineFastState.Bounded env49526 := by
  intro p hp
  have h : env49526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49505_49526 : H12AffineEnvironment.transform 3 1 env49505 = env49526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49505 == env49526) = true)

theorem identity49526 : scanCanonicalize (H12AffineFastState.compose env49526 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9647) := by decide +kernel

theorem selectedBound49526 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49527 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1281,9228,9647,449,9518,320,9229,0,461,1152,9647,9672,384,303,384,1280,2276,8205,1280,256,9353,1345,1029]

theorem envBound49527 : H12AffineFastState.Bounded env49527 := by
  intro p hp
  have h : env49527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49526_49527 : H12AffineEnvironment.transform 15 9647 env49526 = env49527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9647 env49526 == env49527) = true)

def env49528 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,8192,1217,9228,9327,1,9454,128,9229,0,13,1152,9327,9224,64,239,64,1216,2276,8205,1216,192,9353,1153,1029]

theorem envBound49528 : H12AffineFastState.Bounded env49528 := by
  intro p hp
  have h : env49528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49527_49528 : H12AffineEnvironment.transform 7 192 env49527 = env49528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env49527 == env49528) = true)

theorem identity49528 : scanCanonicalize (H12AffineFastState.compose env49528 (packedSelected [1,4,8,9,18,20,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound49528 : packedSelected [1,4,8,9,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env49529 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,2282,1217,3302,3205,1,3076,128,3303,0,13,1152,3205,3298,64,239,64,1216,2276,2279,1216,192,3171,1153,1029]

end H12CloudChart2