import H12CloudChart2Data238

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env60384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58683,143497,20496,508155,148800,148801,96347,90427,74799,257,205167,1344,135680]

theorem envBound60384 : H12AffineFastState.Bounded env60384 := by
  intro p hp
  have h : env60384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60383_60384 : H12AffineEnvironment.transform 18 136192 env60383 = env60384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env60383 == env60384) = true)

def env60385 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143497,20496,508155,148716,148717,96347,90263,74799,173,204995,1260,135680]

theorem envBound60385 : H12AffineFastState.Bounded env60385 := by
  intro p hp
  have h : env60385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60384_60385 : H12AffineEnvironment.transform 7 172 env60384 = env60385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60384 == env60385) = true)

def env60386 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143497,20496,508075,148668,148669,96267,90263,74799,173,204947,1212,135680]

theorem envBound60386 : H12AffineFastState.Bounded env60386 := by
  intro p hp
  have h : env60386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60385_60386 : H12AffineEnvironment.transform 5 16 env60385 = env60386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60385 == env60386) = true)

theorem identity60386 : scanCanonicalize (H12AffineFastState.compose env60386 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound60386 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60387 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,58519,32809,20496,356363,62492,62493,96267,90263,74799,173,102451,1212,41632]

theorem envBound60387 : H12AffineFastState.Bounded env60387 := by
  intro p hp
  have h : env60387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60386_60387 : H12AffineEnvironment.transform 16 45216 env60386 = env60387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env60386 == env60387) = true)

theorem identity60387 : scanCanonicalize (H12AffineFastState.compose env60387 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60387 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env60388 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4096,61569,61617,58519,32809,20496,96386,62492,62493,96267,90263,74799,173,102451,1212,41632]

theorem envBound60388 : H12AffineFastState.Bounded env60388 := by
  intro p hp
  have h : env60388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60387_60388 : H12AffineEnvironment.transform 17 2185 env60387 = env60388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env60387 == env60388) = true)

theorem identity60388 : scanCanonicalize (H12AffineFastState.compose env60388 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound60388 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60389 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,37019,45216,2185,42144,32769,4096,61569,61617,58519,32809,20496,59417,62492,62493,59536,61452,46260,173,168,1212,41632]

theorem envBound60389 : H12AffineFastState.Bounded env60389 := by
  intro p hp
  have h : env60389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60388_60389 : H12AffineEnvironment.transform 15 37019 env60388 = env60389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env60388 == env60389) = true)

theorem identity60389 : scanCanonicalize (H12AffineFastState.compose env60389 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound60389 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env60390 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,13375,5124,2185,4,9381,4096,21541,21525,16435,9357,20496,19645,20664,20665,19508,21672,4112,173,168,1212,1540]

theorem envBound60390 : H12AffineFastState.Bounded env60390 := by
  intro p hp
  have h : env60390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60389_60390 : H12AffineEnvironment.transform 14 9380 env60389 = env60390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env60389 == env60390) = true)

theorem identity60390 : scanCanonicalize (H12AffineFastState.compose env60390 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound60390 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env60391 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,513,9380,13375,5124,2185,4,9381,4096,5668,5652,562,9357,4625,3772,4793,4792,3637,5801,4112,173,168,1212,1540]

theorem envBound60391 : H12AffineFastState.Bounded env60391 := by
  intro p hp
  have h : env60391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60390_60391 : H12AffineEnvironment.transform 13 513 env60390 = env60391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env60390 == env60391) = true)

theorem identity60391 : scanCanonicalize (H12AffineFastState.compose env60391 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound60391 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60392 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3223,8192,513,9380,10408,2195,2185,4,9381,3223,2739,2691,562,9357,3718,3772,3630,3631,3637,2622,3207,173,168,1212,1540]

theorem envBound60392 : H12AffineFastState.Bounded env60392 := by
  intro p hp
  have h : env60392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60391_60392 : H12AffineEnvironment.transform 11 3223 env60391 = env60392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env60391 == env60392) = true)

theorem identity60392 : scanCanonicalize (H12AffineFastState.compose env60392 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3236) := by decide +kernel

theorem selectedBound60392 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env60393 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3223,3236,513,2048,1036,2195,2185,4,2049,3223,2739,2691,562,2089,3718,3772,3630,3631,3637,2622,3207,173,168,1212,1540]

theorem envBound60393 : H12AffineFastState.Bounded env60393 := by
  intro p hp
  have h : env60393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60392_60393 : H12AffineEnvironment.transform 12 3236 env60392 = env60393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3236 env60392 == env60393) = true)

theorem identity60393 : scanCanonicalize (H12AffineFastState.compose env60393 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound60393 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env60394 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,163,144,513,1076,1036,1191,1213,4,1077,163,1671,1719,562,1053,690,648,538,539,513,1546,179,173,168,1212,1540]

theorem envBound60394 : H12AffineFastState.Bounded env60394 := by
  intro p hp
  have h : env60394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60393_60394 : H12AffineEnvironment.transform 10 1076 env60393 = env60394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env60393 == env60394) = true)

theorem identity60394 : scanCanonicalize (H12AffineFastState.compose env60394 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound60394 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env60395 : List Nat := [2,4,8,16,32,16,128,172,48,1024,1076,163,144,49,1076,1036,1191,1213,4,1077,163,1207,1159,2,1053,130,184,42,43,49,1082,179,173,168,1212,1076]

theorem envBound60395 : H12AffineFastState.Bounded env60395 := by
  intro p hp
  have h : env60395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60394_60395 : H12AffineEnvironment.transform 8 48 env60394 = env60395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env60394 == env60395) = true)

theorem identity60395 : scanCanonicalize (H12AffineFastState.compose env60395 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60395 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env60396 : List Nat := [2,4,8,16,32,16,18,62,48,1024,1076,49,2,49,1076,1036,1077,1071,4,1077,49,1061,1045,2,1053,16,42,42,43,49,1082,33,63,58,1070,1076]

theorem envBound60396 : H12AffineFastState.Bounded env60396 := by
  intro p hp
  have h : env60396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60395_60396 : H12AffineEnvironment.transform 6 18 env60395 = env60396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60395 == env60396) = true)

theorem identity60396 : scanCanonicalize (H12AffineFastState.compose env60396 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60396 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env60397 : List Nat := [2,4,8,16,10,16,18,20,26,1024,1054,27,2,27,1054,1036,1055,1029,4,1055,27,1039,1045,2,1053,16,0,0,1,27,1040,11,21,16,1028,1054]

theorem envBound60397 : H12AffineFastState.Bounded env60397 := by
  intro p hp
  have h : env60397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60396_60397 : H12AffineEnvironment.transform 4 10 env60396 = env60397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60396 == env60397) = true)

theorem identity60397 : scanCanonicalize (H12AffineFastState.compose env60397 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound60397 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60398 : List Nat := [2,4,8,16,10,16,18,20,26,31,1,27,2,27,1,19,0,26,4,0,27,16,10,2,2,16,0,0,1,27,15,11,21,16,27,1]

theorem envBound60398 : H12AffineFastState.Bounded env60398 := by
  intro p hp
  have h : env60398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60397_60398 : H12AffineEnvironment.transform 9 31 env60397 = env60398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env60397 == env60398) = true)

theorem identity60398 : scanCanonicalize (H12AffineFastState.compose env60398 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60399 : List Nat := [2,4,8,10,10,10,8,14,0,5,1,1,2,1,1,9,0,0,4,0,1,10,10,2,2,10,0,0,1,1,15,11,15,10,1,1]

theorem envBound60399 : H12AffineFastState.Bounded env60399 := by
  intro p hp
  have h : env60399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60398_60399 : H12AffineEnvironment.transform 3 10 env60398 = env60399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60398 == env60399) = true)

theorem identity60399 : scanCanonicalize (H12AffineFastState.compose env60399 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60400 : List Nat := [2,1,8,10,10,10,8,11,0,0,1,1,2,1,1,9,0,0,1,0,1,10,10,2,2,10,0,0,1,1,10,11,10,10,1,1]

theorem envBound60400 : H12AffineFastState.Bounded env60400 := by
  intro p hp
  have h : env60400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60399_60400 : H12AffineEnvironment.transform 1 1 env60399 = env60400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60399 == env60400) = true)

theorem identity60400 : scanCanonicalize (H12AffineFastState.compose env60400 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60400 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60401 : List Nat := [2,1,1,3,3,3,1,2,0,0,1,1,2,1,1,0,0,0,1,0,1,3,3,2,2,3,0,0,1,1,3,2,3,3,1,1]

theorem envBound60401 : H12AffineFastState.Bounded env60401 := by
  intro p hp
  have h : env60401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60400_60401 : H12AffineEnvironment.transform 2 1 env60400 = env60401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60400 == env60401) = true)

theorem identity60401 : scanCanonicalize (H12AffineFastState.compose env60401 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60401 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60402 : List Nat := [1,1,1,0,0,0,1,1,0,0,1,1,1,1,1,0,0,0,1,0,1,0,0,1,1,0,0,0,1,1,0,1,0,0,1,1]

theorem envBound60402 : H12AffineFastState.Bounded env60402 := by
  intro p hp
  have h : env60402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60401_60402 : H12AffineEnvironment.transform 0 1 env60401 = env60402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60401 == env60402) = true)

def env60403 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143497,20496,508074,148669,148668,96266,90263,74799,173,204946,1213,135680]

theorem envBound60403 : H12AffineFastState.Bounded env60403 := by
  intro p hp
  have h : env60403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60385_60403 : H12AffineEnvironment.transform 5 17 env60385 = env60403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60385 == env60403) = true)

theorem identity60403 : scanCanonicalize (H12AffineFastState.compose env60403 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound60403 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60404 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,58519,143497,20496,120866,148669,148668,96266,90263,74799,173,204946,1213,135680]

theorem envBound60404 : H12AffineFastState.Bounded env60404 := by
  intro p hp
  have h : env60404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60403_60404 : H12AffineEnvironment.transform 17 137352 env60403 = env60404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env60403 == env60404) = true)

theorem identity60404 : scanCanonicalize (H12AffineFastState.compose env60404 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound60404 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env60405 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4096,61568,46092,58519,50325,20496,120866,45217,45216,96266,90263,74799,173,119950,1213,58908]

theorem envBound60405 : H12AffineFastState.Bounded env60405 := by
  intro p hp
  have h : env60405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60404_60405 : H12AffineEnvironment.transform 16 62492 env60404 = env60405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env60404 == env60405) = true)

theorem identity60405 : scanCanonicalize (H12AffineFastState.compose env60405 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound60405 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60406 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,184,32768,65536,46244,44076,41124,32769,4096,45112,46092,42031,33837,4264,104602,45217,45216,80050,73775,74799,173,103478,1213,42660]

theorem envBound60406 : H12AffineFastState.Bounded env60406 := by
  intro p hp
  have h : env60406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60405_60406 : H12AffineEnvironment.transform 13 184 env60405 = env60406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env60405 == env60406) = true)

theorem identity60406 : scanCanonicalize (H12AffineFastState.compose env60406 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 44559) := by decide +kernel

theorem selectedBound60406 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env60407 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,184,32768,44559,46244,44076,41124,32769,4096,45112,46092,42031,33837,4264,13973,45217,45216,38589,36384,35360,173,14905,1213,42660]

theorem envBound60407 : H12AffineFastState.Bounded env60407 := by
  intro p hp
  have h : env60407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60406_60407 : H12AffineEnvironment.transform 15 44559 env60406 = env60407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 44559 env60406 == env60407) = true)

theorem identity60407 : scanCanonicalize (H12AffineFastState.compose env60407 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound60407 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env60408 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7828,184,32768,37019,35376,37560,40496,32769,4096,36524,35480,39611,33837,4264,2049,36405,36404,38589,36384,35360,173,1197,1213,38960]

theorem envBound60408 : H12AffineFastState.Bounded env60408 := by
  intro p hp
  have h : env60408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60407_60408 : H12AffineEnvironment.transform 12 7828 env60407 = env60408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env60407 == env60408) = true)

theorem identity60408 : scanCanonicalize (H12AffineFastState.compose env60408 (packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound60408 : packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env60409 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,49,3749,184,32768,32938,35376,33417,36353,32769,49,36524,35480,35466,33837,153,2049,36405,36404,34444,36384,35360,173,1197,1213,34817]

theorem envBound60409 : H12AffineFastState.Bounded env60409 := by
  intro p hp
  have h : env60409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60408_60409 : H12AffineEnvironment.transform 11 49 env60408 = env60409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env60408 == env60409) = true)

theorem identity60409 : scanCanonicalize (H12AffineFastState.compose env60409 (packedSelected [0,2,3,4,6,7,8,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 3103) := by decide +kernel

theorem selectedBound60409 : packedSelected [0,2,3,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60410 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,49,3749,184,3103,3253,1583,3734,542,3102,49,691,1671,1685,2098,153,2049,554,555,2707,575,1599,173,1197,1213,1054]

theorem envBound60410 : H12AffineFastState.Bounded env60410 := by
  intro p hp
  have h : env60410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60409_60410 : H12AffineEnvironment.transform 14 3103 env60409 = env60410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3103 env60409 == env60410) = true)

theorem identity60410 : scanCanonicalize (H12AffineFastState.compose env60410 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound60410 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env60411 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1077,49,656,184,42,128,1583,675,542,43,49,691,1671,1685,1031,153,1076,554,555,1702,575,1599,173,1197,1213,1054]

theorem envBound60411 : H12AffineFastState.Bounded env60411 := by
  intro p hp
  have h : env60411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60410_60411 : H12AffineEnvironment.transform 10 1077 env60410 = env60411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env60410 == env60411) = true)

theorem identity60411 : scanCanonicalize (H12AffineFastState.compose env60411 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60411 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env60412 : List Nat := [2,4,8,10,32,11,128,172,512,1024,1071,43,650,162,42,128,1583,675,516,43,43,681,1671,1679,1031,131,1070,554,555,1702,549,1573,173,1197,1191,1028]

theorem envBound60412 : H12AffineFastState.Bounded env60412 := by
  intro p hp
  have h : env60412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60411_60412 : H12AffineEnvironment.transform 3 10 env60411 = env60412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60411 == env60412) = true)

def env60413 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143497,20496,508155,148717,148716,96347,90262,74799,172,204994,1261,135680]

theorem envBound60413 : H12AffineFastState.Bounded env60413 := by
  intro p hp
  have h : env60413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60384_60413 : H12AffineEnvironment.transform 7 173 env60384 = env60413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env60384 == env60413) = true)

def env60414 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143497,20496,508075,148669,148668,96267,90262,74799,172,204946,1213,135680]

theorem envBound60414 : H12AffineFastState.Bounded env60414 := by
  intro p hp
  have h : env60414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60413_60414 : H12AffineEnvironment.transform 5 16 env60413 = env60414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60413 == env60414) = true)

theorem identity60414 : scanCanonicalize (H12AffineFastState.compose env60414 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound60414 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60415 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61569,115854,58518,111638,20496,279604,114722,114723,96267,90262,74799,172,41997,1213,104095]

theorem envBound60415 : H12AffineFastState.Bounded env60415 := by
  intro p hp
  have h : env60415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60414_60415 : H12AffineEnvironment.transform 16 99487 env60414 = env60415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env60414 == env60415) = true)

theorem identity60415 : scanCanonicalize (H12AffineFastState.compose env60415 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound60415 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env60416 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,29830,61465,262144,58393,32769,4096,61569,45064,58518,49296,20496,279604,46244,46245,3213,5136,20649,172,41997,1213,57881]

theorem envBound60416 : H12AffineFastState.Bounded env60416 := by
  intro p hp
  have h : env60416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60415_60416 : H12AffineEnvironment.transform 15 29830 env60415 = env60416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env60415 == env60416) = true)

theorem identity60416 : scanCanonicalize (H12AffineFastState.compose env60416 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound60416 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60417 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,29830,4096,262144,1024,24600,4096,4248,20497,1167,8329,20496,279604,21693,21692,3213,5136,20649,172,17428,1213,512]

theorem envBound60417 : H12AffineFastState.Bounded env60417 := by
  intro p hp
  have h : env60417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60416_60417 : H12AffineEnvironment.transform 14 24601 env60416 = env60417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env60416 == env60417) = true)

theorem identity60417 : scanCanonicalize (H12AffineFastState.compose env60417 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound60417 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60418 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9381,12346,4096,262144,1024,9380,4096,4248,5293,1167,8329,5292,262280,4097,4096,3213,5136,5141,172,168,1213,512]

theorem envBound60418 : H12AffineFastState.Bounded env60418 := by
  intro p hp
  have h : env60418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60417_60418 : H12AffineEnvironment.transform 13 1212 env60417 = env60418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env60417 == env60418) = true)

theorem identity60418 : scanCanonicalize (H12AffineFastState.compose env60418 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound60418 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60419 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4649,1212,5772,531,4096,262144,1024,5773,4096,4248,5293,1167,4768,5292,262280,4097,4096,3213,5136,5141,172,168,1213,512]

theorem envBound60419 : H12AffineFastState.Bounded env60419 := by
  intro p hp
  have h : env60419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60418_60419 : H12AffineEnvironment.transform 12 4649 env60418 = env60419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env60418 == env60419) = true)

theorem identity60419 : scanCanonicalize (H12AffineFastState.compose env60419 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7221) := by decide +kernel

theorem selectedBound60419 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env60420 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4649,1212,5772,531,4096,7221,1024,5773,4096,4248,5293,1167,4768,5292,7357,4097,4096,3213,5136,5141,172,168,1213,512]

theorem envBound60420 : H12AffineFastState.Bounded env60420 := by
  intro p hp
  have h : env60420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60419_60420 : H12AffineEnvironment.transform 17 7221 env60419 = env60420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7221 env60419 == env60420) = true)

theorem identity60420 : scanCanonicalize (H12AffineFastState.compose env60420 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound60420 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env60421 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2586,2099,1212,3222,531,2586,1583,1024,3223,2586,2690,3767,1167,2234,3766,1703,2587,2586,3213,3594,3599,172,168,1213,512]

theorem envBound60421 : H12AffineFastState.Bounded env60421 := by
  intro p hp
  have h : env60421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60420_60421 : H12AffineEnvironment.transform 11 2586 env60420 = env60421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env60420 == env60421) = true)

def env60422 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143497,20496,508074,148668,148669,96266,90262,74799,172,204947,1212,135680]

theorem envBound60422 : H12AffineFastState.Bounded env60422 := by
  intro p hp
  have h : env60422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60413_60422 : H12AffineEnvironment.transform 5 17 env60413 = env60422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60413 == env60422) = true)

theorem identity60422 : scanCanonicalize (H12AffineFastState.compose env60422 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound60422 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60423 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61568,147472,58518,143497,20496,60444,148668,148669,96266,90262,74799,172,204947,1212,135680]

theorem envBound60423 : H12AffineFastState.Bounded env60423 := by
  intro p hp
  have h : env60423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60422_60423 : H12AffineEnvironment.transform 17 208054 env60422 = env60423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env60422 == env60423) = true)

theorem identity60423 : scanCanonicalize (H12AffineFastState.compose env60423 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound60423 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env60424 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4096,61568,147472,58518,143497,20496,60444,148668,148669,43048,45236,62477,172,192689,1212,135680]

theorem envBound60424 : H12AffineFastState.Bounded env60424 := by
  intro p hp
  have h : env60424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60423_60424 : H12AffineEnvironment.transform 15 53282 env60423 = env60424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env60423 == env60424) = true)

theorem identity60424 : scanCanonicalize (H12AffineFastState.compose env60424 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound60424 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60425 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4096,61568,5292,58518,25653,20496,60444,4096,4097,43048,45236,62477,172,41997,1212,18108]

theorem envBound60425 : H12AffineFastState.Bounded env60425 := by
  intro p hp
  have h : env60425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60424_60425 : H12AffineEnvironment.transform 16 21692 env60424 = env60425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env60424 == env60425) = true)

theorem identity60425 : scanCanonicalize (H12AffineFastState.compose env60425 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound60425 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env60426 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,12347,21692,18481,16572,24600,4096,4249,5292,1167,25653,20496,3077,4096,4097,18481,20653,5140,172,17428,1212,18108]

theorem envBound60426 : H12AffineFastState.Bounded env60426 := by
  intro p hp
  have h : env60426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60425_60426 : H12AffineEnvironment.transform 14 24601 env60425 = env60426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env60425 == env60426) = true)

theorem identity60426 : scanCanonicalize (H12AffineFastState.compose env60426 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound60426 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env60427 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,672,16384,17081,4763,21692,18481,16572,17080,4096,4249,5292,1167,18069,20496,3077,4096,4097,18481,20653,5140,172,17428,1212,18108]

theorem envBound60427 : H12AffineFastState.Bounded env60427 := by
  intro p hp
  have h : env60427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60426_60427 : H12AffineEnvironment.transform 12 672 env60426 = env60427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env60426 == env60427) = true)

theorem identity60427 : scanCanonicalize (H12AffineFastState.compose env60427 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound60427 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60428 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2090,672,16384,17081,2737,19606,18481,16572,17080,2090,2227,3206,1167,18069,18490,3077,2090,2091,18481,18567,3134,172,17428,1212,18108]

theorem envBound60428 : H12AffineFastState.Bounded env60428 := by
  intro p hp
  have h : env60428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60427_60428 : H12AffineEnvironment.transform 11 2090 env60427 = env60428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env60427 == env60428) = true)

theorem identity60428 : scanCanonicalize (H12AffineFastState.compose env60428 (packedSelected [0,1,2,4,5,6,11,13,16] rootPS)) = affineNative (2^(13+1) ^^^ 3103) := by decide +kernel

theorem selectedBound60428 : packedSelected [0,1,2,4,5,6,11,13,16] rootPS < 2^1333 := by decide +kernel

def env60429 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2090,672,3103,3750,2737,137,1070,3235,3751,2090,2227,3206,1167,2698,1061,3077,2090,2091,1070,1176,3134,172,2059,1212,2723]

theorem envBound60429 : H12AffineFastState.Bounded env60429 := by
  intro p hp
  have h : env60429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60428_60429 : H12AffineEnvironment.transform 13 3103 env60428 = env60429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3103 env60428 == env60429) = true)

theorem identity60429 : scanCanonicalize (H12AffineFastState.compose env60429 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound60429 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60430 : List Nat := [2,4,8,16,32,17,128,173,512,1024,136,162,672,1175,1582,569,137,1070,1067,1583,162,59,1038,1167,514,1061,1165,162,163,1070,1176,1206,172,131,1212,555]

theorem envBound60430 : H12AffineFastState.Bounded env60430 := by
  intro p hp
  have h : env60430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60429_60430 : H12AffineEnvironment.transform 10 136 env60429 = env60430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env60429 == env60430) = true)

theorem identity60430 : scanCanonicalize (H12AffineFastState.compose env60430 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound60430 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env60431 : List Nat := [2,4,8,16,32,17,128,173,1,1024,136,162,161,1175,1071,56,137,1070,1067,1070,162,59,1038,1167,3,1061,1165,162,163,1070,1176,1206,172,131,1212,42]

theorem envBound60431 : H12AffineFastState.Bounded env60431 := by
  intro p hp
  have h : env60431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60430_60431 : H12AffineEnvironment.transform 8 1 env60430 = env60431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60430 == env60431) = true)

theorem identity60431 : scanCanonicalize (H12AffineFastState.compose env60431 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound60431 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env60432 : List Nat := [2,4,8,16,32,17,128,173,1,150,136,162,161,1,185,56,137,184,189,184,162,59,152,25,3,179,27,162,163,184,14,32,172,131,42,42]

theorem envBound60432 : H12AffineFastState.Bounded env60432 := by
  intro p hp
  have h : env60432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60431_60432 : H12AffineEnvironment.transform 9 150 env60431 = env60432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env60431 == env60432) = true)

theorem identity60432 : scanCanonicalize (H12AffineFastState.compose env60432 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound60432 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60433 : List Nat := [2,4,8,16,32,17,56,21,1,46,48,26,25,1,1,56,49,0,5,0,26,59,32,25,3,11,27,26,27,0,14,32,20,59,42,42]

theorem envBound60433 : H12AffineFastState.Bounded env60433 := by
  intro p hp
  have h : env60433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60432_60433 : H12AffineEnvironment.transform 6 56 env60432 = env60433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env60432 == env60433) = true)

theorem identity60433 : scanCanonicalize (H12AffineFastState.compose env60433 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound60433 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60434 : List Nat := [2,4,8,16,29,17,5,21,1,19,13,26,25,1,1,5,12,0,5,0,26,6,29,25,3,11,27,26,27,0,14,29,20,6,23,23]

theorem envBound60434 : H12AffineFastState.Bounded env60434 := by
  intro p hp
  have h : env60434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60433_60434 : H12AffineEnvironment.transform 4 29 env60433 = env60434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env60433 == env60434) = true)

theorem identity60434 : scanCanonicalize (H12AffineFastState.compose env60434 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60434 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env60435 : List Nat := [2,4,8,10,7,11,5,15,1,9,13,0,3,1,1,5,12,0,5,0,0,6,7,3,3,11,1,0,1,0,14,7,14,6,13,13]

theorem envBound60435 : H12AffineFastState.Bounded env60435 := by
  intro p hp
  have h : env60435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60434_60435 : H12AffineEnvironment.transform 3 10 env60434 = env60435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60434 == env60435) = true)

theorem identity60435 : scanCanonicalize (H12AffineFastState.compose env60435 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60435 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env60436 : List Nat := [2,4,4,6,7,7,5,3,1,5,1,0,3,1,1,5,0,0,5,0,0,6,7,3,3,7,1,0,1,0,2,7,2,6,1,1]

theorem envBound60436 : H12AffineFastState.Bounded env60436 := by
  intro p hp
  have h : env60436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60435_60436 : H12AffineEnvironment.transform 2 4 env60435 = env60436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60435 == env60436) = true)

def env60437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58682,143496,20497,508154,148800,148800,96347,90426,74799,257,205167,1344,135681]

theorem envBound60437 : H12AffineFastState.Bounded env60437 := by
  intro p hp
  have h : env60437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60383_60437 : H12AffineEnvironment.transform 18 136193 env60383 = env60437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env60383 == env60437) = true)

def env60438 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143496,20497,508154,148716,148716,96347,90262,74799,173,204995,1260,135681]

theorem envBound60438 : H12AffineFastState.Bounded env60438 := by
  intro p hp
  have h : env60438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60437_60438 : H12AffineEnvironment.transform 7 172 env60437 = env60438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60437 == env60438) = true)

def env60439 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143496,20497,508074,148668,148668,96267,90262,74799,173,204947,1212,135681]

theorem envBound60439 : H12AffineFastState.Bounded env60439 := by
  intro p hp
  have h : env60439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60438_60439 : H12AffineEnvironment.transform 5 16 env60438 = env60439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60438 == env60439) = true)

theorem identity60439 : scanCanonicalize (H12AffineFastState.compose env60439 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound60439 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60440 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,58518,143496,20497,120867,148668,148668,96267,90262,74799,173,204947,1212,135681]

theorem envBound60440 : H12AffineFastState.Bounded env60440 := by
  intro p hp
  have h : env60440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60439_60440 : H12AffineEnvironment.transform 17 137353 env60439 = env60440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env60439 == env60440) = true)

theorem identity60440 : scanCanonicalize (H12AffineFastState.compose env60440 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound60440 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env60441 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4096,61569,46093,58518,50324,20497,120867,45216,45216,96267,90262,74799,173,119951,1212,58909]

theorem envBound60441 : H12AffineFastState.Bounded env60441 := by
  intro p hp
  have h : env60441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60440_60441 : H12AffineEnvironment.transform 16 62492 env60440 = env60441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env60440 == env60441) = true)

theorem identity60441 : scanCanonicalize (H12AffineFastState.compose env60441 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound60441 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60442 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,32768,65536,46244,44077,41125,32769,4096,45113,46093,42030,33836,4265,104603,45216,45216,80051,73774,74799,173,103479,1212,42661]

theorem envBound60442 : H12AffineFastState.Bounded env60442 := by
  intro p hp
  have h : env60442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60441_60442 : H12AffineEnvironment.transform 13 184 env60441 = env60442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env60441 == env60442) = true)

theorem identity60442 : scanCanonicalize (H12AffineFastState.compose env60442 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 7732) := by decide +kernel

theorem selectedBound60442 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env60443 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,7732,65536,10896,12825,16017,7733,4096,11789,10809,14874,6680,4265,67247,11924,11924,80051,73774,74799,173,68099,1212,14481]

theorem envBound60443 : H12AffineFastState.Bounded env60443 := by
  intro p hp
  have h : env60443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60442_60443 : H12AffineEnvironment.transform 14 7732 env60442 = env60443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7732 env60442 == env60443) = true)

theorem identity60443 : scanCanonicalize (H12AffineFastState.compose env60443 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 3758) := by decide +kernel

theorem selectedBound60443 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env60444 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,7732,3758,10896,12825,16017,7733,4096,11789,10809,14874,6680,4265,2049,11924,11924,13853,11904,10881,173,1197,1212,14481]

theorem envBound60444 : H12AffineFastState.Bounded env60444 := by
  intro p hp
  have h : env60444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60443_60444 : H12AffineEnvironment.transform 15 3758 env60443 = env60444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3758 env60443 == env60444) = true)

theorem identity60444 : scanCanonicalize (H12AffineFastState.compose env60444 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3117) := by decide +kernel

theorem selectedBound60444 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60445 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3117,184,7732,3758,1725,7732,4796,7733,4096,544,1556,5687,6680,4265,2049,697,697,6704,685,1708,173,1197,1212,5308]

theorem envBound60445 : H12AffineFastState.Bounded env60445 := by
  intro p hp
  have h : env60445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60444_60445 : H12AffineEnvironment.transform 12 3117 env60444 = env60445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3117 env60444 == env60445) = true)

theorem identity60445 : scanCanonicalize (H12AffineFastState.compose env60445 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3735) := by decide +kernel

theorem selectedBound60445 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60446 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3735,3117,184,163,3758,1725,163,3115,162,3735,544,1556,2208,1167,3646,2049,697,697,1191,685,1708,173,1197,1212,2603]

theorem envBound60446 : H12AffineFastState.Bounded env60446 := by
  intro p hp
  have h : env60446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60445_60446 : H12AffineEnvironment.transform 11 3735 env60445 = env60446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3735 env60445 == env60446) = true)

theorem identity60446 : scanCanonicalize (H12AffineFastState.compose env60446 (packedSelected [1,2,3,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound60446 : packedSelected [1,2,3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env60447 : List Nat := [2,4,8,16,32,16,128,172,512,1024,42,1725,1031,184,163,1668,1725,163,1025,162,1725,544,1556,138,1167,1556,43,697,697,1191,685,1708,173,1197,1212,513]

theorem envBound60447 : H12AffineFastState.Bounded env60447 := by
  intro p hp
  have h : env60447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60446_60447 : H12AffineEnvironment.transform 10 42 env60446 = env60447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env60446 == env60447) = true)

theorem identity60447 : scanCanonicalize (H12AffineFastState.compose env60447 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound60447 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env60448 : List Nat := [2,4,8,16,32,16,128,172,512,527,42,178,520,184,163,139,178,163,526,162,178,544,27,138,640,27,43,697,697,680,685,163,173,674,691,513]

theorem envBound60448 : H12AffineFastState.Bounded env60448 := by
  intro p hp
  have h : env60448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60447_60448 : H12AffineEnvironment.transform 9 527 env60447 = env60448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env60447 == env60448) = true)

theorem identity60448 : scanCanonicalize (H12AffineFastState.compose env60448 (packedSelected [1,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 153) := by decide +kernel

theorem selectedBound60448 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env60449 : List Nat := [2,4,8,16,32,16,128,172,153,150,42,178,145,184,163,139,178,163,151,162,178,185,27,138,25,27,43,32,32,49,52,163,173,59,42,152]

theorem envBound60449 : H12AffineFastState.Bounded env60449 := by
  intro p hp
  have h : env60449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60448_60449 : H12AffineEnvironment.transform 8 153 env60448 = env60449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env60448 == env60449) = true)

theorem identity60449 : scanCanonicalize (H12AffineFastState.compose env60449 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60449 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env60450 : List Nat := [2,4,8,16,32,16,9,37,16,31,42,59,24,49,42,2,59,42,30,43,59,48,27,3,25,27,43,32,32,49,52,42,36,59,42,17]

theorem envBound60450 : H12AffineFastState.Bounded env60450 := by
  intro p hp
  have h : env60450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60449_60450 : H12AffineEnvironment.transform 6 9 env60449 = env60450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60449 == env60450) = true)

theorem identity60450 : scanCanonicalize (H12AffineFastState.compose env60450 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60450 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60451 : List Nat := [2,4,8,16,9,16,9,12,16,31,3,18,24,24,3,2,18,3,30,2,18,25,27,3,25,27,2,9,9,24,29,3,13,18,3,17]

theorem envBound60451 : H12AffineFastState.Bounded env60451 := by
  intro p hp
  have h : env60451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60450_60451 : H12AffineEnvironment.transform 4 9 env60450 = env60451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60450 == env60451) = true)

theorem identity60451 : scanCanonicalize (H12AffineFastState.compose env60451 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60451 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60452 : List Nat := [2,4,1,16,0,16,0,5,16,22,3,18,17,17,3,2,18,3,23,2,18,16,18,3,16,18,2,0,0,17,20,3,4,18,3,17]

theorem envBound60452 : H12AffineFastState.Bounded env60452 := by
  intro p hp
  have h : env60452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60451_60452 : H12AffineEnvironment.transform 2 1 env60451 = env60452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60451 == env60452) = true)

theorem identity60452 : scanCanonicalize (H12AffineFastState.compose env60452 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60453 : List Nat := [2,1,1,16,0,16,0,0,16,19,3,18,17,17,3,2,18,3,18,2,18,16,18,3,16,18,2,0,0,17,17,3,1,18,3,17]

theorem envBound60453 : H12AffineFastState.Bounded env60453 := by
  intro p hp
  have h : env60453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60452_60453 : H12AffineEnvironment.transform 1 1 env60452 = env60453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60452 == env60453) = true)

theorem identity60453 : scanCanonicalize (H12AffineFastState.compose env60453 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60453 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env60454 : List Nat := [2,1,1,2,0,2,0,0,2,1,3,0,3,3,3,2,0,3,0,2,0,2,0,3,2,0,2,0,0,3,3,3,1,0,3,3]

theorem envBound60454 : H12AffineFastState.Bounded env60454 := by
  intro p hp
  have h : env60454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60453_60454 : H12AffineEnvironment.transform 3 2 env60453 = env60454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60453 == env60454) = true)

theorem identity60454 : scanCanonicalize (H12AffineFastState.compose env60454 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60455 : List Nat := [1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,0,1,0,0,0]

theorem envBound60455 : H12AffineFastState.Bounded env60455 := by
  intro p hp
  have h : env60455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60454_60455 : H12AffineEnvironment.transform 0 1 env60454 = env60455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60454 == env60455) = true)

def env60456 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143496,20497,508075,148669,148669,96266,90262,74799,173,204946,1213,135681]

theorem envBound60456 : H12AffineFastState.Bounded env60456 := by
  intro p hp
  have h : env60456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60438_60456 : H12AffineEnvironment.transform 5 17 env60438 = env60456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60438 == env60456) = true)

theorem identity60456 : scanCanonicalize (H12AffineFastState.compose env60456 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound60456 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60457 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,58518,32809,20497,356362,62492,62492,96266,90262,74799,173,102451,1213,41632]

theorem envBound60457 : H12AffineFastState.Bounded env60457 := by
  intro p hp
  have h : env60457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60456_60457 : H12AffineEnvironment.transform 16 45217 env60456 = env60457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env60456 == env60457) = true)

theorem identity60457 : scanCanonicalize (H12AffineFastState.compose env60457 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60457 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env60458 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4096,61568,61617,58518,32809,20497,96387,62492,62492,96266,90262,74799,173,102451,1213,41632]

theorem envBound60458 : H12AffineFastState.Bounded env60458 := by
  intro p hp
  have h : env60458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60457_60458 : H12AffineEnvironment.transform 17 2185 env60457 = env60458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env60457 == env60458) = true)

theorem identity60458 : scanCanonicalize (H12AffineFastState.compose env60458 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound60458 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60459 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,37018,45217,2185,42144,32769,4096,61568,61617,58518,32809,20497,59417,62492,62492,59536,61452,46261,173,169,1213,41632]

theorem envBound60459 : H12AffineFastState.Bounded env60459 := by
  intro p hp
  have h : env60459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60458_60459 : H12AffineEnvironment.transform 15 37018 env60458 = env60459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env60458 == env60459) = true)

theorem identity60459 : scanCanonicalize (H12AffineFastState.compose env60459 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound60459 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env60460 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,13375,5124,2185,5,9380,4096,21541,21524,16435,9356,20497,19644,20665,20665,19509,21673,4112,173,169,1213,1541]

theorem envBound60460 : H12AffineFastState.Bounded env60460 := by
  intro p hp
  have h : env60460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60459_60460 : H12AffineEnvironment.transform 14 9381 env60459 = env60460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env60459 == env60460) = true)

theorem identity60460 : scanCanonicalize (H12AffineFastState.compose env60460 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound60460 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env60461 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,512,9381,13375,5124,2185,5,9380,4096,5669,5652,563,9356,4625,3772,4793,4793,3637,5801,4112,173,169,1213,1541]

theorem envBound60461 : H12AffineFastState.Bounded env60461 := by
  intro p hp
  have h : env60461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60460_60461 : H12AffineEnvironment.transform 13 512 env60460 = env60461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env60460 == env60461) = true)

theorem identity60461 : scanCanonicalize (H12AffineFastState.compose env60461 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound60461 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60462 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2602,8192,512,9381,11797,3630,2185,5,9380,2602,3087,3134,563,9356,2107,3772,2195,2195,3637,3203,2618,173,169,1213,1541]

theorem envBound60462 : H12AffineFastState.Bounded env60462 := by
  intro p hp
  have h : env60462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60461_60462 : H12AffineEnvironment.transform 11 2602 env60461 = env60462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env60461 == env60462) = true)

theorem identity60462 : scanCanonicalize (H12AffineFastState.compose env60462 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound60462 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env60463 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2602,3613,512,2744,8,3630,2185,5,2745,2602,3087,3134,563,2705,2107,3772,2195,2195,3637,3203,2618,173,169,1213,1541]

theorem envBound60463 : H12AffineFastState.Bounded env60463 := by
  intro p hp
  have h : env60463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60462_60463 : H12AffineEnvironment.transform 12 3613 env60462 = env60463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env60462 == env60463) = true)

theorem identity60463 : scanCanonicalize (H12AffineFastState.compose env60463 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound60463 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env60464 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1077,1567,552,512,1677,8,539,1212,5,1676,1567,58,11,563,1700,1038,649,1190,1190,512,182,1551,173,169,1213,1541]

theorem envBound60464 : H12AffineFastState.Bounded env60464 := by
  intro p hp
  have h : env60464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60463_60464 : H12AffineEnvironment.transform 10 1077 env60463 = env60464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env60463 == env60464) = true)

theorem identity60464 : scanCanonicalize (H12AffineFastState.compose env60464 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60464 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60465 : List Nat := [2,4,8,10,32,11,128,172,512,1024,1071,1541,552,512,1677,8,513,1190,5,1676,1541,32,11,553,1700,1038,649,1190,1190,512,172,1551,173,169,1191,1541]

theorem envBound60465 : H12AffineFastState.Bounded env60465 := by
  intro p hp
  have h : env60465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60464_60465 : H12AffineEnvironment.transform 3 10 env60464 = env60465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60464 == env60465) = true)

theorem identity60465 : scanCanonicalize (H12AffineFastState.compose env60465 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound60465 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env60466 : List Nat := [2,4,8,10,32,11,128,172,512,679,648,162,552,512,42,8,513,513,5,43,162,32,11,553,3,681,649,513,513,512,172,168,173,169,512,162]

theorem envBound60466 : H12AffineFastState.Bounded env60466 := by
  intro p hp
  have h : env60466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60465_60466 : H12AffineEnvironment.transform 9 679 env60465 = env60466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env60465 == env60466) = true)

theorem identity60466 : scanCanonicalize (H12AffineFastState.compose env60466 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound60466 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env60467 : List Nat := [2,4,8,10,12,11,128,128,512,651,648,142,516,512,6,8,513,513,5,7,142,12,11,517,3,645,649,513,513,512,128,132,129,133,512,142]

theorem envBound60467 : H12AffineFastState.Bounded env60467 := by
  intro p hp
  have h : env60467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60466_60467 : H12AffineEnvironment.transform 4 12 env60466 = env60467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env60466 == env60467) = true)

theorem identity60467 : scanCanonicalize (H12AffineFastState.compose env60467 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound60467 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env60468 : List Nat := [2,4,8,10,12,11,128,128,0,139,136,142,4,0,6,8,1,1,5,7,142,12,11,5,3,133,137,1,1,0,128,132,129,133,0,142]

theorem envBound60468 : H12AffineFastState.Bounded env60468 := by
  intro p hp
  have h : env60468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60467_60468 : H12AffineEnvironment.transform 8 0 env60467 = env60468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60467 == env60468) = true)

theorem identity60468 : scanCanonicalize (H12AffineFastState.compose env60468 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound60468 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60469 : List Nat := [2,4,8,10,12,11,14,14,0,5,6,0,4,0,6,8,1,1,5,7,0,12,11,5,3,11,7,1,1,0,14,10,15,11,0,0]

theorem envBound60469 : H12AffineFastState.Bounded env60469 := by
  intro p hp
  have h : env60469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60468_60469 : H12AffineEnvironment.transform 6 14 env60468 = env60469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env60468 == env60469) = true)

theorem identity60469 : scanCanonicalize (H12AffineFastState.compose env60469 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60470 : List Nat := [2,3,8,10,11,11,9,9,0,2,1,0,3,0,1,8,1,1,2,0,0,11,11,2,3,11,0,1,1,0,9,10,8,11,0,0]

theorem envBound60470 : H12AffineFastState.Bounded env60470 := by
  intro p hp
  have h : env60470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60469_60470 : H12AffineEnvironment.transform 1 3 env60469 = env60470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60469 == env60470) = true)

def env60471 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143496,20497,508154,148717,148717,96347,90263,74799,172,204994,1261,135681]

theorem envBound60471 : H12AffineFastState.Bounded env60471 := by
  intro p hp
  have h : env60471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60437_60471 : H12AffineEnvironment.transform 7 173 env60437 = env60471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env60437 == env60471) = true)

def env60472 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143496,20497,508074,148669,148669,96267,90263,74799,172,204946,1213,135681]

theorem envBound60472 : H12AffineFastState.Bounded env60472 := by
  intro p hp
  have h : env60472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60471_60472 : H12AffineEnvironment.transform 5 16 env60471 = env60472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60471 == env60472) = true)

theorem identity60472 : scanCanonicalize (H12AffineFastState.compose env60472 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound60472 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60473 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61569,147473,58519,143496,20497,60445,148669,148669,96267,90263,74799,172,204946,1213,135681]

theorem envBound60473 : H12AffineFastState.Bounded env60473 := by
  intro p hp
  have h : env60473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60472_60473 : H12AffineEnvironment.transform 17 208055 env60472 = env60473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env60472 == env60473) = true)

theorem identity60473 : scanCanonicalize (H12AffineFastState.compose env60473 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound60473 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env60474 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4096,61569,147473,58519,143496,20497,60445,148669,148669,43048,45236,62476,172,192689,1213,135681]

theorem envBound60474 : H12AffineFastState.Bounded env60474 := by
  intro p hp
  have h : env60474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60473_60474 : H12AffineEnvironment.transform 15 53283 env60473 = env60474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env60473 == env60474) = true)

theorem identity60474 : scanCanonicalize (H12AffineFastState.compose env60474 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound60474 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60475 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4096,61569,5293,58519,25652,20497,60445,4097,4097,43048,45236,62476,172,41997,1213,18109]

theorem envBound60475 : H12AffineFastState.Bounded env60475 := by
  intro p hp
  have h : env60475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60474_60475 : H12AffineEnvironment.transform 16 21692 env60474 = env60475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env60474 == env60475) = true)

theorem identity60475 : scanCanonicalize (H12AffineFastState.compose env60475 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound60475 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env60476 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,12346,21692,18481,16573,24600,4096,4248,5293,1166,25652,20497,3076,4097,4097,18481,20653,5141,172,17428,1213,18109]

theorem envBound60476 : H12AffineFastState.Bounded env60476 := by
  intro p hp
  have h : env60476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60475_60476 : H12AffineEnvironment.transform 14 24601 env60475 = env60476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env60475 == env60476) = true)

theorem identity60476 : scanCanonicalize (H12AffineFastState.compose env60476 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 8729) := by decide +kernel

theorem selectedBound60476 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env60477 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8729,512,12346,13989,10792,8868,513,4096,4248,5293,1166,1581,12808,3076,4097,4097,10792,12980,5141,172,9741,1213,9380]

theorem envBound60477 : H12AffineFastState.Bounded env60477 := by
  intro p hp
  have h : env60477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60476_60477 : H12AffineEnvironment.transform 13 8729 env60476 = env60477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8729 env60476 == env60477) = true)

theorem identity60477 : scanCanonicalize (H12AffineFastState.compose env60477 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound60477 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env60478 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3119,8192,8729,512,11285,10890,10792,8868,513,3119,3255,2178,1166,1581,11815,3076,3118,3118,10792,11931,2106,172,9741,1213,9380]

theorem envBound60478 : H12AffineFastState.Bounded env60478 := by
  intro p hp
  have h : env60478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60477_60478 : H12AffineEnvironment.transform 11 3119 env60477 = env60478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env60477 == env60478) = true)

theorem identity60478 : scanCanonicalize (H12AffineFastState.compose env60478 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound60478 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env60479 : List Nat := [2,4,8,16,32,16,128,173,512,1024,162,1165,8192,8729,512,9399,8744,8842,8868,513,1165,1045,32,1166,1581,9861,1190,1164,1164,8842,9785,152,172,9741,1213,9380]

theorem envBound60479 : H12AffineFastState.Bounded env60479 := by
  intro p hp
  have h : env60479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60478_60479 : H12AffineEnvironment.transform 10 162 env60478 = env60479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env60478 == env60479) = true)

theorem identity60479 : scanCanonicalize (H12AffineFastState.compose env60479 (packedSelected [0,2,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1678) := by decide +kernel

theorem selectedBound60479 : packedSelected [0,2,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60480 : List Nat := [2,4,8,16,32,16,128,173,512,1024,162,1165,1678,1175,512,569,1190,1028,1066,513,1165,1045,32,1166,1581,11,1190,1164,1164,1028,183,152,172,131,1213,554]

theorem envBound60480 : H12AffineFastState.Bounded env60480 := by
  intro p hp
  have h : env60480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60479_60480 : H12AffineEnvironment.transform 12 1678 env60479 = env60480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1678 env60479 == env60480) = true)

theorem identity60480 : scanCanonicalize (H12AffineFastState.compose env60480 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound60480 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60481 : List Nat := [2,4,8,16,32,16,128,173,512,516,162,649,138,659,512,569,674,512,558,513,649,529,32,650,41,11,674,648,648,512,183,152,172,131,697,554]

theorem envBound60481 : H12AffineFastState.Bounded env60481 := by
  intro p hp
  have h : env60481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60480_60481 : H12AffineEnvironment.transform 9 516 env60480 = env60481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env60480 == env60481) = true)

theorem identity60481 : scanCanonicalize (H12AffineFastState.compose env60481 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60481 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env60482 : List Nat := [2,4,8,16,32,16,19,62,512,516,49,538,25,512,512,569,561,512,558,513,538,529,32,537,41,11,561,539,539,512,36,11,63,16,554,554]

theorem envBound60482 : H12AffineFastState.Bounded env60482 := by
  intro p hp
  have h : env60482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60481_60482 : H12AffineEnvironment.transform 6 19 env60481 = env60482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60481 == env60482) = true)

theorem identity60482 : scanCanonicalize (H12AffineFastState.compose env60482 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60482 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env60483 : List Nat := [2,4,8,16,17,16,19,15,512,516,0,538,25,512,512,520,512,512,543,513,538,529,17,537,24,11,512,539,539,512,21,11,14,16,539,539]

theorem envBound60483 : H12AffineFastState.Bounded env60483 := by
  intro p hp
  have h : env60483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60482_60483 : H12AffineEnvironment.transform 4 17 env60482 = env60483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60482 == env60483) = true)

theorem identity60483 : scanCanonicalize (H12AffineFastState.compose env60483 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound60483 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60484 : List Nat := [2,4,8,16,17,16,19,15,26,30,0,0,25,26,26,18,26,26,5,27,0,11,17,3,24,11,26,1,1,26,21,11,14,16,1,1]

theorem envBound60484 : H12AffineFastState.Bounded env60484 := by
  intro p hp
  have h : env60484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60483_60484 : H12AffineEnvironment.transform 8 26 env60483 = env60484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env60483 == env60484) = true)

theorem identity60484 : scanCanonicalize (H12AffineFastState.compose env60484 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound60484 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60485 : List Nat := [2,4,8,12,13,12,15,15,6,2,0,0,5,6,6,14,6,6,5,7,0,11,13,3,4,11,6,1,1,6,9,11,14,12,1,1]

theorem envBound60485 : H12AffineFastState.Bounded env60485 := by
  intro p hp
  have h : env60485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60484_60485 : H12AffineEnvironment.transform 3 12 env60484 = env60485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env60484 == env60485) = true)

theorem identity60485 : scanCanonicalize (H12AffineFastState.compose env60485 (packedSelected [1,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60485 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env60486 : List Nat := [2,3,8,11,10,11,8,8,1,2,0,0,2,1,1,9,1,1,2,0,0,11,10,3,3,11,1,1,1,1,9,11,9,11,1,1]

theorem envBound60486 : H12AffineFastState.Bounded env60486 := by
  intro p hp
  have h : env60486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60485_60486 : H12AffineEnvironment.transform 1 3 env60485 = env60486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60485 == env60486) = true)

def env60487 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143496,20497,508075,148668,148668,96266,90263,74799,172,204947,1212,135681]

theorem envBound60487 : H12AffineFastState.Bounded env60487 := by
  intro p hp
  have h : env60487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60471_60487 : H12AffineEnvironment.transform 5 17 env60471 = env60487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60471 == env60487) = true)

theorem identity60487 : scanCanonicalize (H12AffineFastState.compose env60487 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound60487 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env60488 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61568,115854,58519,111638,20497,279605,114722,114722,96266,90263,74799,172,41997,1212,104095]

theorem envBound60488 : H12AffineFastState.Bounded env60488 := by
  intro p hp
  have h : env60488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60487_60488 : H12AffineEnvironment.transform 16 99486 env60487 = env60488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env60487 == env60488) = true)

theorem identity60488 : scanCanonicalize (H12AffineFastState.compose env60488 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound60488 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env60489 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,29830,61464,262144,58393,32769,4096,61568,45064,58519,49296,20497,279605,46244,46244,3212,5137,20649,172,41997,1212,57881]

theorem envBound60489 : H12AffineFastState.Bounded env60489 := by
  intro p hp
  have h : env60489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60488_60489 : H12AffineEnvironment.transform 15 29830 env60488 = env60489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env60488 == env60489) = true)

theorem identity60489 : scanCanonicalize (H12AffineFastState.compose env60489 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound60489 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60490 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,29830,4097,262144,1024,24600,4096,4249,20497,1166,8329,20497,279605,21693,21693,3212,5137,20649,172,17428,1212,512]

theorem envBound60490 : H12AffineFastState.Bounded env60490 := by
  intro p hp
  have h : env60490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60489_60490 : H12AffineEnvironment.transform 14 24601 env60489 = env60490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env60489 == env60490) = true)

theorem identity60490 : scanCanonicalize (H12AffineFastState.compose env60490 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound60490 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60491 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9380,12347,4097,262144,1024,9381,4096,4249,5292,1166,8329,5292,262280,4096,4096,3212,5137,5140,172,169,1212,512]

theorem envBound60491 : H12AffineFastState.Bounded env60491 := by
  intro p hp
  have h : env60491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60490_60491 : H12AffineEnvironment.transform 13 1213 env60490 = env60491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env60490 == env60491) = true)

theorem identity60491 : scanCanonicalize (H12AffineFastState.compose env60491 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound60491 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60492 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5676,1213,4744,1559,4097,262144,1024,4745,4096,4249,5292,1166,5797,5292,262280,4096,4096,3212,5137,5140,172,169,1212,512]

theorem envBound60492 : H12AffineFastState.Bounded env60492 := by
  intro p hp
  have h : env60492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60491_60492 : H12AffineEnvironment.transform 12 5676 env60491 = env60492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env60491 == env60492) = true)

theorem identity60492 : scanCanonicalize (H12AffineFastState.compose env60492 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound60492 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env60493 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5676,1213,4744,1559,4097,6193,1024,4745,4096,4249,5292,1166,5797,5292,6329,4096,4096,3212,5137,5140,172,169,1212,512]

theorem envBound60493 : H12AffineFastState.Bounded env60493 := by
  intro p hp
  have h : env60493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60492_60493 : H12AffineEnvironment.transform 17 6193 env60492 = env60493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env60492 == env60493) = true)

theorem identity60493 : scanCanonicalize (H12AffineFastState.compose env60493 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3615) := by decide +kernel

theorem selectedBound60493 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env60494 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3615,2099,1213,3223,1559,3614,1582,1024,3222,3615,3718,2739,1166,2234,2739,1702,3615,3615,3212,2574,2571,172,169,1212,512]

theorem envBound60494 : H12AffineFastState.Bounded env60494 := by
  intro p hp
  have h : env60494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60493_60494 : H12AffineEnvironment.transform 11 3615 env60493 = env60494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3615 env60493 == env60494) = true)

theorem identity60494 : scanCanonicalize (H12AffineFastState.compose env60494 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound60494 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env60495 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2587,2099,185,2195,531,2586,554,4,2194,2587,2690,2739,138,2234,2739,674,2587,2587,2184,2574,2571,172,169,184,512]

theorem envBound60495 : H12AffineFastState.Bounded env60495 := by
  intro p hp
  have h : env60495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60494_60495 : H12AffineEnvironment.transform 9 4 env60494 = env60495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env60494 == env60495) = true)

theorem identity60495 : scanCanonicalize (H12AffineFastState.compose env60495 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound60495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60496 : List Nat := [2,4,8,16,32,17,128,173,512,4,513,26,562,185,658,531,27,554,4,659,26,131,178,138,699,178,674,26,26,649,15,10,172,169,184,512]

theorem envBound60496 : H12AffineFastState.Bounded env60496 := by
  intro p hp
  have h : env60496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60495_60496 : H12AffineEnvironment.transform 10 513 env60495 = env60496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env60495 == env60496) = true)

theorem identity60496 : scanCanonicalize (H12AffineFastState.compose env60496 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60496 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60497 : List Nat := [2,4,8,11,32,10,128,173,512,4,513,1,553,162,649,520,0,554,4,648,1,131,169,138,672,169,674,1,1,649,15,10,172,169,163,512]

theorem envBound60497 : H12AffineFastState.Bounded env60497 := by
  intro p hp
  have h : env60497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60496_60497 : H12AffineEnvironment.transform 3 11 env60496 = env60497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60496 == env60497) = true)

theorem identity60497 : scanCanonicalize (H12AffineFastState.compose env60497 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60497 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60498 : List Nat := [2,4,8,11,11,10,128,134,512,4,513,1,514,137,649,520,0,513,4,648,1,131,130,138,651,130,649,1,1,649,15,10,135,130,136,512]

theorem envBound60498 : H12AffineFastState.Bounded env60498 := by
  intro p hp
  have h : env60498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60497_60498 : H12AffineEnvironment.transform 4 11 env60497 = env60498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60497 == env60498) = true)

theorem identity60498 : scanCanonicalize (H12AffineFastState.compose env60498 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60499 : List Nat := [2,4,4,7,7,6,128,134,512,4,513,1,514,133,645,516,0,513,4,644,1,131,130,134,647,130,645,1,1,645,3,6,135,130,132,512]

theorem envBound60499 : H12AffineFastState.Bounded env60499 := by
  intro p hp
  have h : env60499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60498_60499 : H12AffineEnvironment.transform 2 4 env60498 = env60499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60498 == env60499) = true)

theorem identity60499 : scanCanonicalize (H12AffineFastState.compose env60499 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound60499 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60500 : List Nat := [2,4,4,7,7,6,128,134,132,4,133,1,134,133,1,128,0,133,4,0,1,131,130,134,3,130,1,1,1,1,3,6,135,130,132,132]

theorem envBound60500 : H12AffineFastState.Bounded env60500 := by
  intro p hp
  have h : env60500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60499_60500 : H12AffineEnvironment.transform 8 132 env60499 = env60500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env60499 == env60500) = true)

theorem identity60500 : scanCanonicalize (H12AffineFastState.compose env60500 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound60500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60501 : List Nat := [2,4,4,7,7,6,4,2,0,4,1,1,2,1,1,4,0,1,4,0,1,7,6,2,3,6,1,1,1,1,3,6,3,6,0,0]

theorem envBound60501 : H12AffineFastState.Bounded env60501 := by
  intro p hp
  have h : env60501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60500_60501 : H12AffineEnvironment.transform 6 4 env60500 = env60501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env60500 == env60501) = true)

def env60502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245633,148800,545089,96347,16876544,74799,257,17420372,1345,525824]

theorem envBound60502 : H12AffineFastState.Bounded env60502 := by
  intro p hp
  have h : env60502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60381_60502 : H12AffineEnvironment.transform 26 17245633 env60381 = env60502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env60381 == env60502) = true)

theorem identity60502 : scanCanonicalize (H12AffineFastState.compose env60502 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound60502 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env60503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41003,533641,672784,493034,148800,545089,96347,74795,74799,257,618623,1345,525824]

theorem envBound60503 : H12AffineFastState.Bounded env60503 := by
  intro p hp
  have h : env60503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60502_60503 : H12AffineEnvironment.transform 23 41003 env60502 = env60503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env60502 == env60503) = true)

def env60504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,493034,148800,148801,96347,74795,74799,257,222335,1345,135680]

theorem envBound60504 : H12AffineFastState.Bounded env60504 := by
  intro p hp
  have h : env60504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60503_60504 : H12AffineEnvironment.transform 18 136192 env60503 = env60504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env60503 == env60504) = true)

def env60505 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,492614,148716,148717,96347,74795,74799,173,222335,1261,135680]

theorem envBound60505 : H12AffineFastState.Bounded env60505 := by
  intro p hp
  have h : env60505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60504_60505 : H12AffineEnvironment.transform 7 172 env60504 = env60505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60504 == env60505) = true)

def env60506 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143497,20496,492566,148668,148669,96267,74795,74799,173,222255,1213,135680]

theorem envBound60506 : H12AffineFastState.Bounded env60506 := by
  intro p hp
  have h : env60506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60505_60506 : H12AffineEnvironment.transform 5 16 env60505 = env60506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60505 == env60506) = true)

theorem identity60506 : scanCanonicalize (H12AffineFastState.compose env60506 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound60506 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60507 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,41003,32809,20496,341174,62492,62493,96267,74795,74799,173,119951,1213,41632]

theorem envBound60507 : H12AffineFastState.Bounded env60507 := by
  intro p hp
  have h : env60507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60506_60507 : H12AffineEnvironment.transform 16 45216 env60506 = env60507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env60506 == env60507) = true)

theorem identity60507 : scanCanonicalize (H12AffineFastState.compose env60507 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound60507 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env60508 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4096,46141,46093,41003,32809,5292,341174,45216,45217,81079,74795,74799,173,102451,1213,41632]

theorem envBound60508 : H12AffineFastState.Bounded env60508 := by
  intro p hp
  have h : env60508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60507_60508 : H12AffineEnvironment.transform 13 1212 env60507 = env60508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env60507 == env60508) = true)

theorem identity60508 : scanCanonicalize (H12AffineFastState.compose env60508 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound60508 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60509 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,184,32768,65536,45216,262144,41124,32769,4096,45113,45065,41003,32809,4264,340146,45216,45217,80051,73775,73771,173,102451,185,41632]

theorem envBound60509 : H12AffineFastState.Bounded env60509 := by
  intro p hp
  have h : env60509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60508_60509 : H12AffineEnvironment.transform 9 4 env60508 = env60509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env60508 == env60509) = true)

theorem identity60509 : scanCanonicalize (H12AffineFastState.compose env60509 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound60509 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env60510 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,184,32768,37018,45216,262144,41124,32769,4096,45113,45065,41003,32809,4264,303144,45216,45217,43049,45237,45233,173,169,185,41632]

theorem envBound60510 : H12AffineFastState.Bounded env60510 := by
  intro p hp
  have h : env60510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60509_60510 : H12AffineEnvironment.transform 15 37018 env60509 = env60510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env60509 == env60510) = true)

theorem identity60510 : scanCanonicalize (H12AffineFastState.compose env60510 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound60510 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env60511 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,184,32768,37018,45216,43048,41124,32769,4096,45113,45065,41003,32809,4264,2048,45216,45217,43049,45237,45233,173,169,185,41632]

theorem envBound60511 : H12AffineFastState.Bounded env60511 := by
  intro p hp
  have h : env60511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60510_60511 : H12AffineEnvironment.transform 17 43048 env60510 = env60511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env60510 == env60511) = true)

theorem identity60511 : scanCanonicalize (H12AffineFastState.compose env60511 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound60511 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env60512 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,539,8192,184,32768,33409,41659,43048,41124,32769,539,41506,41490,41003,32809,691,2048,41659,41658,43049,41646,41642,173,169,185,41632]

theorem envBound60512 : H12AffineFastState.Bounded env60512 := by
  intro p hp
  have h : env60512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60511_60512 : H12AffineEnvironment.transform 11 539 env60511 = env60512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env60511 == env60512) = true)

theorem identity60512 : scanCanonicalize (H12AffineFastState.compose env60512 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 10242) := by decide +kernel

theorem selectedBound60512 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env60513 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,539,8192,184,10242,10883,2745,42,2214,10243,539,2592,2576,2089,10283,691,2048,2745,2744,43,2732,2728,173,169,185,2722]

theorem envBound60513 : H12AffineFastState.Bounded env60513 := by
  intro p hp
  have h : env60513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60512_60513 : H12AffineEnvironment.transform 14 10242 env60512 = env60513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10242 env60512 == env60513) = true)

theorem identity60513 : scanCanonicalize (H12AffineFastState.compose env60513 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound60513 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env60514 : List Nat := [2,4,8,16,32,16,128,172,512,4,185,539,8192,184,8379,8762,512,42,31,8378,539,665,681,144,8338,691,185,512,513,43,533,529,173,169,185,539]

theorem envBound60514 : H12AffineFastState.Bounded env60514 := by
  intro p hp
  have h : env60514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60513_60514 : H12AffineEnvironment.transform 10 185 env60513 = env60514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env60513 == env60514) = true)

theorem identity60514 : scanCanonicalize (H12AffineFastState.compose env60514 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound60514 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env60515 : List Nat := [2,4,8,16,32,16,128,172,512,4,185,539,673,184,538,155,512,42,31,539,539,665,681,144,563,691,185,512,513,43,533,529,173,169,185,539]

theorem envBound60515 : H12AffineFastState.Bounded env60515 := by
  intro p hp
  have h : env60515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60514_60515 : H12AffineEnvironment.transform 12 673 env60514 = env60515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env60514 == env60515) = true)

theorem identity60515 : scanCanonicalize (H12AffineFastState.compose env60515 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60515 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60516 : List Nat := [2,4,8,16,10,16,128,134,512,4,147,539,651,146,538,155,512,0,31,539,539,665,643,144,537,665,147,512,513,1,533,529,135,131,147,539]

theorem envBound60516 : H12AffineFastState.Bounded env60516 := by
  intro p hp
  have h : env60516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60515_60516 : H12AffineEnvironment.transform 4 10 env60515 = env60516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60515 == env60516) = true)

theorem identity60516 : scanCanonicalize (H12AffineFastState.compose env60516 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound60516 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60517 : List Nat := [2,4,8,16,10,16,30,24,512,4,13,539,533,12,538,5,512,0,31,539,539,519,541,14,537,519,13,512,513,1,533,529,25,29,13,539]

theorem envBound60517 : H12AffineFastState.Bounded env60517 := by
  intro p hp
  have h : env60517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60516_60517 : H12AffineEnvironment.transform 6 30 env60516 = env60517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env60516 == env60517) = true)

theorem identity60517 : scanCanonicalize (H12AffineFastState.compose env60517 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound60517 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60518 : List Nat := [2,4,8,16,10,16,30,24,1,4,13,26,20,12,27,5,1,0,31,26,26,6,28,14,24,6,13,1,0,1,20,16,25,29,13,26]

theorem envBound60518 : H12AffineFastState.Bounded env60518 := by
  intro p hp
  have h : env60518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60517_60518 : H12AffineEnvironment.transform 8 1 env60517 = env60518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60517 == env60518) = true)

theorem identity60518 : scanCanonicalize (H12AffineFastState.compose env60518 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound60518 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env60519 : List Nat := [2,4,8,7,10,7,9,15,1,4,13,13,3,12,12,5,1,0,8,13,13,6,11,14,15,6,13,1,0,1,3,7,14,10,13,13]

theorem envBound60519 : H12AffineFastState.Bounded env60519 := by
  intro p hp
  have h : env60519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60518_60519 : H12AffineEnvironment.transform 3 7 env60518 = env60519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env60518 == env60519) = true)

def env60520 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143497,20496,492567,148669,148668,96266,74795,74799,173,222254,1212,135680]

theorem envBound60520 : H12AffineFastState.Bounded env60520 := by
  intro p hp
  have h : env60520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60505_60520 : H12AffineEnvironment.transform 5 17 env60505 = env60520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60505 == env60520) = true)

theorem identity60520 : scanCanonicalize (H12AffineFastState.compose env60520 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound60520 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60521 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,41003,143497,20496,105631,148669,148668,96266,74795,74799,173,222254,1212,135680]

theorem envBound60521 : H12AffineFastState.Bounded env60521 := by
  intro p hp
  have h : env60521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60520_60521 : H12AffineEnvironment.transform 17 137352 env60520 = env60521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env60520 == env60521) = true)

theorem identity60521 : scanCanonicalize (H12AffineFastState.compose env60521 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound60521 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env60522 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4096,61568,147472,41003,143497,20496,43169,148669,148668,19508,4117,4113,173,151568,1212,135680]

theorem envBound60522 : H12AffineFastState.Bounded env60522 := by
  intro p hp
  have h : env60522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60521_60522 : H12AffineEnvironment.transform 15 13374 env60521 = env60522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env60521 == env60522) = true)

theorem identity60522 : scanCanonicalize (H12AffineFastState.compose env60522 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound60522 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60523 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136192,32769,4096,46140,132268,41003,143497,5292,43169,131073,131072,2184,4117,4113,173,136364,1212,135680]

theorem envBound60523 : H12AffineFastState.Bounded env60523 := by
  intro p hp
  have h : env60523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60522_60523 : H12AffineEnvironment.transform 13 1212 env60522 = env60523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env60522 == env60523) = true)

theorem identity60523 : scanCanonicalize (H12AffineFastState.compose env60523 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound60523 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env60524 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,40984,47248,46104,32769,4096,46140,42164,41003,37009,5292,43169,40985,40984,2184,4117,4113,173,46260,1212,45592]

theorem envBound60524 : H12AffineFastState.Bounded env60524 := by
  intro p hp
  have h : env60524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60523_60524 : H12AffineEnvironment.transform 16 40984 env60523 = env60524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env60523 == env60524) = true)

theorem identity60524 : scanCanonicalize (H12AffineFastState.compose env60524 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 11271) := by decide +kernel

theorem selectedBound60524 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60525 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,11271,13374,3103,5271,6175,11270,4096,6203,2227,3116,15510,5292,1190,3102,3103,2184,4117,4113,173,6323,1212,7711]

theorem envBound60525 : H12AffineFastState.Bounded env60525 := by
  intro p hp
  have h : env60525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60524_60525 : H12AffineEnvironment.transform 14 11271 env60524 = env60525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11271 env60524 == env60525) = true)

theorem identity60525 : scanCanonicalize (H12AffineFastState.compose env60525 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound60525 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env60526 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1190,4096,8192,1212,8353,13374,185,5271,5305,8352,4096,5277,1045,138,12336,5292,1190,184,185,1070,4117,4113,173,5141,1212,4793]

theorem envBound60526 : H12AffineFastState.Bounded env60526 := by
  intro p hp
  have h : env60526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60525_60526 : H12AffineEnvironment.transform 10 1190 env60525 = env60526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env60525 == env60526) = true)

theorem identity60526 : scanCanonicalize (H12AffineFastState.compose env60526 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound60526 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env60527 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1190,4096,1172,1212,1077,4266,185,5271,5305,1076,4096,5277,1045,138,5284,5292,1190,184,185,1070,4117,4113,173,5141,1212,4793]

theorem envBound60527 : H12AffineFastState.Bounded env60527 := by
  intro p hp
  have h : env60527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60526_60527 : H12AffineEnvironment.transform 12 1172 env60526 = env60527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env60526 == env60527) = true)

theorem identity60527 : scanCanonicalize (H12AffineFastState.compose env60527 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound60527 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env60528 : List Nat := [2,4,8,16,32,17,128,172,512,663,561,4096,515,555,674,4266,185,4608,4654,675,4096,4618,642,138,4659,4667,561,184,185,697,4117,4113,173,4738,555,4793]

theorem envBound60528 : H12AffineFastState.Bounded env60528 := by
  intro p hp
  have h : env60528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60527_60528 : H12AffineEnvironment.transform 9 663 env60527 = env60528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env60527 == env60528) = true)

theorem identity60528 : scanCanonicalize (H12AffineFastState.compose env60528 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60528 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env60529 : List Nat := [2,4,8,16,32,17,34,14,512,565,561,4096,515,555,512,4104,27,4608,4654,513,4096,4618,544,40,4659,4667,561,26,27,539,4117,4113,15,4640,555,4635]

theorem envBound60529 : H12AffineFastState.Bounded env60529 := by
  intro p hp
  have h : env60529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60528_60529 : H12AffineEnvironment.transform 6 34 env60528 = env60529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60528 == env60529) = true)

theorem identity60529 : scanCanonicalize (H12AffineFastState.compose env60529 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound60529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60530 : List Nat := [2,4,8,16,32,17,34,14,512,565,561,560,515,555,512,568,27,48,30,513,560,58,544,40,3,11,561,26,27,539,549,545,15,16,555,43]

theorem envBound60530 : H12AffineFastState.Bounded env60530 := by
  intro p hp
  have h : env60530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60529_60530 : H12AffineEnvironment.transform 11 560 env60529 = env60530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env60529 == env60530) = true)

theorem identity60530 : scanCanonicalize (H12AffineFastState.compose env60530 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound60530 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60531 : List Nat := [2,4,8,16,32,17,34,14,54,3,7,6,53,29,54,14,27,48,30,55,6,58,22,40,3,11,7,26,27,45,19,23,15,16,29,43]

theorem envBound60531 : H12AffineFastState.Bounded env60531 := by
  intro p hp
  have h : env60531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60530_60531 : H12AffineEnvironment.transform 8 54 env60530 = env60531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env60530 == env60531) = true)

theorem identity60531 : scanCanonicalize (H12AffineFastState.compose env60531 (packedSelected [1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60531 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env60532 : List Nat := [2,4,8,16,16,17,18,14,6,3,7,6,5,29,6,14,27,0,30,7,6,10,22,24,3,11,7,26,27,29,19,23,15,16,29,27]

theorem envBound60532 : H12AffineFastState.Bounded env60532 := by
  intro p hp
  have h : env60532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60531_60532 : H12AffineEnvironment.transform 4 16 env60531 = env60532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60531 == env60532) = true)

theorem identity60532 : scanCanonicalize (H12AffineFastState.compose env60532 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60532 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60533 : List Nat := [2,4,8,11,11,10,9,14,6,3,7,6,5,6,6,14,0,0,5,7,6,10,13,3,3,11,7,1,0,6,8,12,15,11,6,0]

theorem envBound60533 : H12AffineFastState.Bounded env60533 := by
  intro p hp
  have h : env60533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60532_60533 : H12AffineEnvironment.transform 3 11 env60532 = env60533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60532 == env60533) = true)

theorem identity60533 : scanCanonicalize (H12AffineFastState.compose env60533 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60533 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60534 : List Nat := [2,2,8,11,11,10,9,8,0,3,1,0,3,0,0,8,0,0,3,1,0,10,11,3,3,11,1,1,0,0,8,10,9,11,0,0]

theorem envBound60534 : H12AffineFastState.Bounded env60534 := by
  intro p hp
  have h : env60534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60533_60534 : H12AffineEnvironment.transform 1 2 env60533 = env60534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60533 == env60534) = true)

def env60535 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143497,20496,492615,148717,148716,96347,74795,74799,172,222335,1260,135680]

theorem envBound60535 : H12AffineFastState.Bounded env60535 := by
  intro p hp
  have h : env60535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60504_60535 : H12AffineEnvironment.transform 7 173 env60504 = env60535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env60504 == env60535) = true)

def env60536 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143497,20496,492567,148669,148668,96267,74795,74799,172,222255,1212,135680]

theorem envBound60536 : H12AffineFastState.Bounded env60536 := by
  intro p hp
  have h : env60536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60535_60536 : H12AffineEnvironment.transform 5 16 env60535 = env60536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60535 == env60536) = true)

theorem identity60536 : scanCanonicalize (H12AffineFastState.compose env60536 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound60536 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60537 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61569,98355,41003,127147,20496,279605,99487,99486,96267,74795,74799,172,41997,1212,119330]

theorem envBound60537 : H12AffineFastState.Bounded env60537 := by
  intro p hp
  have h : env60537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60536_60537 : H12AffineEnvironment.transform 16 114722 env60536 = env60537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env60536 == env60537) = true)

theorem identity60537 : scanCanonicalize (H12AffineFastState.compose env60537 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 122031) := by decide +kernel

theorem selectedBound60537 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env60538 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,122031,119842,32769,4096,61569,98355,41003,127147,20496,104602,99487,99486,96267,74795,74799,172,41997,1212,119330]

theorem envBound60538 : H12AffineFastState.Bounded env60538 := by
  intro p hp
  have h : env60538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60537_60538 : H12AffineEnvironment.transform 17 122031 env60537 = env60538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122031 env60537 == env60538) = true)

theorem identity60538 : scanCanonicalize (H12AffineFastState.compose env60538 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound60538 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env60539 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,3213,1024,32769,4096,61569,20497,41003,8329,20496,18616,21693,21692,43049,62473,62477,172,41997,1212,512]

theorem envBound60539 : H12AffineFastState.Bounded env60539 := by
  intro p hp
  have h : env60539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60538_60539 : H12AffineEnvironment.transform 15 53282 env60538 = env60539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env60538 == env60539) = true)

theorem identity60539 : scanCanonicalize (H12AffineFastState.compose env60539 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound60539 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60540 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24600,12346,4096,3213,1024,24601,4096,4249,20497,16435,8329,20496,18616,21693,21692,18481,5137,5141,172,17429,1212,512]

theorem envBound60540 : H12AffineFastState.Bounded env60540 := by
  intro p hp
  have h : env60540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60539_60540 : H12AffineEnvironment.transform 14 24600 env60539 = env60540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env60539 == env60540) = true)

theorem identity60540 : scanCanonicalize (H12AffineFastState.compose env60540 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound60540 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60541 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8744,560,12346,4096,3213,1024,561,4096,4249,12857,8731,8329,12856,10896,13973,13972,10777,5137,5141,172,9789,1212,512]

theorem envBound60541 : H12AffineFastState.Bounded env60541 := by
  intro p hp
  have h : env60541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60540_60541 : H12AffineEnvironment.transform 13 8744 env60540 = env60541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env60540 == env60541) = true)

theorem identity60541 : scanCanonicalize (H12AffineFastState.compose env60541 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound60541 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env60542 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,4096,8192,8243,43,12346,4096,3213,1024,42,4096,4249,12322,8192,8329,12323,10379,13454,13455,10242,5137,5141,172,9254,1212,27]

theorem envBound60542 : H12AffineFastState.Bounded env60542 := by
  intro p hp
  have h : env60542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60541_60542 : H12AffineEnvironment.transform 8 27 env60541 = env60542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env60541 == env60542) = true)

theorem identity60542 : scanCanonicalize (H12AffineFastState.compose env60542 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound60542 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env60543 : List Nat := [2,4,8,16,32,16,128,173,27,5,2048,4096,8192,8243,43,12346,4096,2184,5,42,4096,4249,12322,8192,8329,12323,10379,12427,12426,10242,4116,4112,172,8227,185,27]

theorem envBound60543 : H12AffineFastState.Bounded env60543 := by
  intro p hp
  have h : env60543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60542_60543 : H12AffineEnvironment.transform 9 5 env60542 = env60543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env60542 == env60543) = true)

theorem identity60543 : scanCanonicalize (H12AffineFastState.compose env60543 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound60543 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env60544 : List Nat := [2,4,8,16,32,16,128,173,27,5,2048,4096,2098,2049,43,6152,4096,2184,5,42,4096,4249,6160,2098,2235,6161,185,6329,6328,48,4116,4112,172,2065,185,27]

theorem envBound60544 : H12AffineFastState.Bounded env60544 := by
  intro p hp
  have h : env60544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60543_60544 : H12AffineEnvironment.transform 12 2098 env60543 = env60544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env60543 == env60544) = true)

theorem identity60544 : scanCanonicalize (H12AffineFastState.compose env60544 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound60544 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env60545 : List Nat := [2,4,8,16,32,16,128,173,27,5,2048,49,2098,2049,43,2105,49,2184,5,42,49,168,2081,2098,2235,2080,185,2184,2185,48,37,33,172,2065,185,27]

theorem envBound60545 : H12AffineFastState.Bounded env60545 := by
  intro p hp
  have h : env60545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60544_60545 : H12AffineEnvironment.transform 11 49 env60544 = env60545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env60544 == env60545) = true)

theorem identity60545 : scanCanonicalize (H12AffineFastState.compose env60545 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60545 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env60546 : List Nat := [2,4,8,10,32,10,128,173,1,5,2048,43,2088,2049,43,2083,43,2184,5,42,43,168,2081,2088,2209,2080,163,2184,2185,42,37,33,172,2059,163,1]

theorem envBound60546 : H12AffineFastState.Bounded env60546 := by
  intro p hp
  have h : env60546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60545_60546 : H12AffineEnvironment.transform 3 10 env60545 = env60546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60545 == env60546) = true)

theorem identity60546 : scanCanonicalize (H12AffineFastState.compose env60546 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60546 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env60547 : List Nat := [2,4,8,10,32,10,9,36,1,5,2048,43,2088,2049,43,2083,43,2049,5,42,43,33,2081,2088,2088,2080,42,2049,2048,42,37,33,37,2059,42,1]

theorem envBound60547 : H12AffineFastState.Bounded env60547 := by
  intro p hp
  have h : env60547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60546_60547 : H12AffineEnvironment.transform 6 9 env60546 = env60547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60546 == env60547) = true)

theorem identity60547 : scanCanonicalize (H12AffineFastState.compose env60547 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound60547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60548 : List Nat := [2,4,8,10,12,10,9,8,1,5,2048,7,2052,2049,7,2063,7,2049,5,6,7,13,2061,2052,2052,2060,6,2049,2048,6,9,13,9,2059,6,1]

theorem envBound60548 : H12AffineFastState.Bounded env60548 := by
  intro p hp
  have h : env60548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60547_60548 : H12AffineEnvironment.transform 4 12 env60547 = env60548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env60547 == env60548) = true)

theorem identity60548 : scanCanonicalize (H12AffineFastState.compose env60548 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound60548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60549 : List Nat := [2,4,8,10,12,10,9,8,1,5,6,7,2,7,7,9,7,7,5,6,7,13,11,2,2,10,6,7,6,6,9,13,9,13,6,1]

theorem envBound60549 : H12AffineFastState.Bounded env60549 := by
  intro p hp
  have h : env60549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60548_60549 : H12AffineEnvironment.transform 10 6 env60548 = env60549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env60548 == env60549) = true)

def env60550 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143497,20496,492566,148668,148669,96266,74795,74799,172,222254,1213,135680]

theorem envBound60550 : H12AffineFastState.Bounded env60550 := by
  intro p hp
  have h : env60550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60535_60550 : H12AffineEnvironment.transform 5 17 env60535 = env60550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60535 == env60550) = true)

theorem identity60550 : scanCanonicalize (H12AffineFastState.compose env60550 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound60550 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60551 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61568,147472,41003,143497,20496,60445,148668,148669,96266,74795,74799,172,222254,1213,135680]

theorem envBound60551 : H12AffineFastState.Bounded env60551 := by
  intro p hp
  have h : env60551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60550_60551 : H12AffineEnvironment.transform 17 223243 env60550 = env60551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env60550 == env60551) = true)

theorem identity60551 : scanCanonicalize (H12AffineFastState.compose env60551 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound60551 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env60552 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4096,61568,147472,41003,143497,20496,60445,148668,148669,2184,21673,21677,172,136364,1213,135680]

theorem envBound60552 : H12AffineFastState.Bounded env60552 := by
  intro p hp
  have h : env60552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60551_60552 : H12AffineEnvironment.transform 15 28802 env60551 = env60552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env60551 == env60552) = true)

theorem identity60552 : scanCanonicalize (H12AffineFastState.compose env60552 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound60552 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env60553 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,46245,44076,41125,32769,4096,61568,62645,41003,33836,20496,60445,61465,61464,2184,21673,21677,172,40969,1213,42661]

theorem envBound60553 : H12AffineFastState.Bounded env60553 := by
  intro p hp
  have h : env60553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60552_60553 : H12AffineEnvironment.transform 16 46245 env60552 = env60553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env60552 == env60553) = true)

theorem identity60553 : scanCanonicalize (H12AffineFastState.compose env60553 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound60553 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env60554 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,46245,44076,41125,32769,4096,46141,45064,41003,33836,5293,43168,46244,46245,2184,4116,4112,172,40969,1213,42661]

theorem envBound60554 : H12AffineFastState.Bounded env60554 := by
  intro p hp
  have h : env60554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60553_60554 : H12AffineEnvironment.transform 13 1213 env60553 = env60554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env60553 == env60554) = true)

theorem identity60554 : scanCanonicalize (H12AffineFastState.compose env60554 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound60554 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60555 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,32768,9350,42012,44076,41125,32769,185,42116,41137,41003,33836,1044,43168,42013,42012,2184,173,169,172,40969,1213,42661]

theorem envBound60555 : H12AffineFastState.Bounded env60555 := by
  intro p hp
  have h : env60555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60554_60555 : H12AffineEnvironment.transform 11 185 env60554 = env60555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env60554 == env60555) = true)

theorem identity60555 : scanCanonicalize (H12AffineFastState.compose env60555 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 2706) := by decide +kernel

theorem selectedBound60555 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env60556 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,2706,9350,11918,9918,10807,2707,185,11798,10787,10937,3774,1044,8754,11919,11918,2184,173,169,172,10907,1213,11319]

theorem envBound60556 : H12AffineFastState.Bounded env60556 := by
  intro p hp
  have h : env60556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60555_60556 : H12AffineEnvironment.transform 14 2706 env60555 = env60556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2706 env60555 == env60556) = true)

theorem identity60556 : scanCanonicalize (H12AffineFastState.compose env60556 (packedSelected [0,1,3,4,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 3083) := by decide +kernel

theorem selectedBound60556 : packedSelected [0,1,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env60557 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,3083,1213,2706,2189,645,2741,1596,2707,185,541,1576,1714,3774,1044,3641,644,645,2184,173,169,172,1680,1213,60]

theorem envBound60557 : H12AffineFastState.Bounded env60557 := by
  intro p hp
  have h : env60557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60556_60557 : H12AffineEnvironment.transform 12 3083 env60556 = env60557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3083 env60556 == env60557) = true)

theorem identity60557 : scanCanonicalize (H12AffineFastState.compose env60557 (packedSelected [0,5,7,8,10,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound60557 : packedSelected [0,5,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60558 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,185,3083,1213,2195,2189,132,2228,1085,2194,185,28,1065,1203,3263,1044,3128,133,132,2184,173,169,172,1169,1213,60]

theorem envBound60558 : H12AffineFastState.Bounded env60558 := by
  intro p hp
  have h : env60558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60557_60558 : H12AffineEnvironment.transform 8 1 env60557 = env60558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60557 == env60558) = true)

theorem identity60558 : scanCanonicalize (H12AffineFastState.compose env60558 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound60558 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60559 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1191,185,172,1213,1076,1066,132,1043,1085,1077,185,28,1065,1203,24,1044,159,133,132,1071,173,169,172,1169,1213,60]

theorem envBound60559 : H12AffineFastState.Bounded env60559 := by
  intro p hp
  have h : env60559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60558_60559 : H12AffineEnvironment.transform 10 1191 env60558 = env60559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env60558 == env60559) = true)

theorem identity60559 : scanCanonicalize (H12AffineFastState.compose env60559 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60559 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env60560 : List Nat := [2,4,8,16,32,17,18,63,1,1024,1077,43,62,1071,1076,1066,22,1043,1085,1077,43,28,1065,1057,24,1044,13,23,22,1071,63,59,62,1027,1071,60]

theorem envBound60560 : H12AffineFastState.Bounded env60560 := by
  intro p hp
  have h : env60560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60559_60560 : H12AffineEnvironment.transform 6 18 env60559 = env60560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60559 == env60560) = true)

theorem identity60560 : scanCanonicalize (H12AffineFastState.compose env60560 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound60560 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env60561 : List Nat := [2,4,8,16,29,17,18,2,1,1024,1032,22,3,1042,1033,1047,22,1043,1024,1032,22,28,1044,1052,24,1044,13,23,22,1042,2,6,3,1027,1042,1]

theorem envBound60561 : H12AffineFastState.Bounded env60561 := by
  intro p hp
  have h : env60561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60560_60561 : H12AffineEnvironment.transform 4 29 env60560 = env60561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env60560 == env60561) = true)

theorem identity60561 : scanCanonicalize (H12AffineFastState.compose env60561 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound60561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60562 : List Nat := [2,4,8,16,29,17,18,2,1,31,23,22,3,13,22,8,22,12,31,23,22,28,11,3,24,11,13,23,22,13,2,6,3,28,13,1]

theorem envBound60562 : H12AffineFastState.Bounded env60562 := by
  intro p hp
  have h : env60562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60561_60562 : H12AffineEnvironment.transform 9 31 env60561 = env60562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env60561 == env60562) = true)

theorem identity60562 : scanCanonicalize (H12AffineFastState.compose env60562 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60563 : List Nat := [2,4,8,10,7,11,8,2,1,5,13,12,3,13,12,8,12,12,5,13,12,6,11,3,2,11,13,13,12,13,2,6,3,6,13,1]

theorem envBound60563 : H12AffineFastState.Bounded env60563 := by
  intro p hp
  have h : env60563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60562_60563 : H12AffineEnvironment.transform 3 10 env60562 = env60563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60562 == env60563) = true)

def env60564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,493034,148800,148800,96347,74795,74799,257,222334,1345,135681]

theorem envBound60564 : H12AffineFastState.Bounded env60564 := by
  intro p hp
  have h : env60564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60503_60564 : H12AffineEnvironment.transform 18 136193 env60503 = env60564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env60503 == env60564) = true)

def env60565 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,492614,148716,148716,96347,74795,74799,173,222334,1261,135681]

theorem envBound60565 : H12AffineFastState.Bounded env60565 := by
  intro p hp
  have h : env60565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60564_60565 : H12AffineEnvironment.transform 7 172 env60564 = env60565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60564 == env60565) = true)

def env60566 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143496,20497,492566,148668,148668,96267,74795,74799,173,222254,1213,135681]

theorem envBound60566 : H12AffineFastState.Bounded env60566 := by
  intro p hp
  have h : env60566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60565_60566 : H12AffineEnvironment.transform 5 16 env60565 = env60566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60565 == env60566) = true)

theorem identity60566 : scanCanonicalize (H12AffineFastState.compose env60566 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound60566 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60567 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,41003,143496,20497,105631,148668,148668,96267,74795,74799,173,222254,1213,135681]

theorem envBound60567 : H12AffineFastState.Bounded env60567 := by
  intro p hp
  have h : env60567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60566_60567 : H12AffineEnvironment.transform 17 137353 env60566 = env60567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env60566 == env60567) = true)

theorem identity60567 : scanCanonicalize (H12AffineFastState.compose env60567 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound60567 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env60568 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4096,61569,147473,41003,143496,20497,43169,148668,148668,19509,4117,4113,173,151568,1213,135681]

theorem envBound60568 : H12AffineFastState.Bounded env60568 := by
  intro p hp
  have h : env60568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60567_60568 : H12AffineEnvironment.transform 15 13374 env60567 = env60568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env60567 == env60568) = true)

theorem identity60568 : scanCanonicalize (H12AffineFastState.compose env60568 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound60568 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env60569 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136193,32769,4096,46140,132268,41003,143496,5292,43169,131073,131073,2184,4117,4113,173,136365,1213,135681]

theorem envBound60569 : H12AffineFastState.Bounded env60569 := by
  intro p hp
  have h : env60569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60568_60569 : H12AffineEnvironment.transform 13 1213 env60568 = env60569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env60568 == env60569) = true)

theorem identity60569 : scanCanonicalize (H12AffineFastState.compose env60569 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound60569 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env60570 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12312,13374,131072,137353,136193,12313,4096,1060,132268,4147,143496,5292,6329,131073,131073,2184,4117,4113,173,136365,1213,135681]

theorem envBound60570 : H12AffineFastState.Bounded env60570 := by
  intro p hp
  have h : env60570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60569_60570 : H12AffineEnvironment.transform 14 12312 env60569 = env60570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env60569 == env60570) = true)

theorem identity60570 : scanCanonicalize (H12AffineFastState.compose env60570 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound60570 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60571 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1213,12312,13374,131072,136238,136193,12313,4096,1060,132268,4147,143496,5292,5150,131073,131073,1071,4117,4113,173,136365,1213,135681]

theorem envBound60571 : H12AffineFastState.Bounded env60571 := by
  intro p hp
  have h : env60571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60570_60571 : H12AffineEnvironment.transform 10 1191 env60570 = env60571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env60570 == env60571) = true)

theorem identity60571 : scanCanonicalize (H12AffineFastState.compose env60571 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 4256) := by decide +kernel

theorem selectedBound60571 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60572 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4256,1213,184,1182,131072,136238,136193,185,4096,1060,132268,4147,131112,5292,5150,131073,131073,1071,4117,4113,173,136365,1213,135681]

theorem envBound60572 : H12AffineFastState.Bounded env60572 := by
  intro p hp
  have h : env60572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60571_60572 : H12AffineEnvironment.transform 12 4256 env60571 = env60572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4256 env60571 == env60572) = true)

theorem identity60572 : scanCanonicalize (H12AffineFastState.compose env60572 (packedSelected [1,7,8,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 1588) := by decide +kernel

theorem selectedBound60572 : packedSelected [1,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env60573 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4256,1213,184,1182,1588,4634,4661,185,4096,1060,664,4147,1564,5292,5150,1589,1589,1071,4117,4113,173,4761,1213,5173]

theorem envBound60573 : H12AffineFastState.Bounded env60573 := by
  intro p hp
  have h : env60573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60572_60573 : H12AffineEnvironment.transform 16 1588 env60572 = env60573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1588 env60572 == env60573) = true)

theorem identity60573 : scanCanonicalize (H12AffineFastState.compose env60573 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound60573 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env60574 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,184,24,1213,184,1182,1588,674,653,185,184,1060,664,139,1564,1044,1190,1589,1589,1071,173,169,173,545,1213,1165]

theorem envBound60574 : H12AffineFastState.Bounded env60574 := by
  intro p hp
  have h : env60574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60573_60574 : H12AffineEnvironment.transform 11 184 env60573 = env60574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env60573 == env60574) = true)

theorem identity60574 : scanCanonicalize (H12AffineFastState.compose env60574 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound60574 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env60575 : List Nat := [2,4,8,16,32,16,128,172,512,150,49,184,24,43,184,8,674,674,653,185,184,178,664,139,650,130,48,675,675,185,173,169,173,545,43,27]

theorem envBound60575 : H12AffineFastState.Bounded env60575 := by
  intro p hp
  have h : env60575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60574_60575 : H12AffineEnvironment.transform 9 150 env60574 = env60575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env60574 == env60575) = true)

theorem identity60575 : scanCanonicalize (H12AffineFastState.compose env60575 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound60575 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env60576 : List Nat := [2,4,8,16,32,16,128,172,26,150,49,184,24,43,184,8,184,184,151,185,184,178,130,139,144,130,48,185,185,185,173,169,173,59,43,27]

theorem envBound60576 : H12AffineFastState.Bounded env60576 := by
  intro p hp
  have h : env60576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60575_60576 : H12AffineEnvironment.transform 8 26 env60575 = env60576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env60575 == env60576) = true)

theorem identity60576 : scanCanonicalize (H12AffineFastState.compose env60576 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound60576 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60577 : List Nat := [2,4,8,16,32,16,43,7,26,61,49,19,24,43,19,8,19,19,60,18,19,25,41,32,59,41,48,18,18,18,6,2,6,59,43,27]

theorem envBound60577 : H12AffineFastState.Bounded env60577 := by
  intro p hp
  have h : env60577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60576_60577 : H12AffineEnvironment.transform 6 43 env60576 = env60577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env60576 == env60577) = true)

theorem identity60577 : scanCanonicalize (H12AffineFastState.compose env60577 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60577 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60578 : List Nat := [2,4,8,3,32,3,43,7,9,46,34,0,11,43,0,8,0,0,47,1,0,10,41,32,40,41,35,1,1,1,6,2,6,40,43,8]

theorem envBound60578 : H12AffineFastState.Bounded env60578 := by
  intro p hp
  have h : env60578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60577_60578 : H12AffineEnvironment.transform 3 3 env60577 = env60578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60577 == env60578) = true)

theorem identity60578 : scanCanonicalize (H12AffineFastState.compose env60578 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60578 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60579 : List Nat := [2,4,0,3,32,3,35,7,1,38,34,0,3,35,0,0,0,0,39,1,0,2,33,32,32,33,35,1,1,1,6,2,6,32,35,0]

theorem envBound60579 : H12AffineFastState.Bounded env60579 := by
  intro p hp
  have h : env60579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60578_60579 : H12AffineEnvironment.transform 2 0 env60578 = env60579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60578 == env60579) = true)

theorem identity60579 : scanCanonicalize (H12AffineFastState.compose env60579 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60579 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60580 : List Nat := [2,1,0,3,32,3,35,2,1,35,34,0,3,35,0,0,0,0,34,1,0,2,33,32,32,33,35,1,1,1,3,2,3,32,35,0]

theorem envBound60580 : H12AffineFastState.Bounded env60580 := by
  intro p hp
  have h : env60580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60579_60580 : H12AffineEnvironment.transform 1 1 env60579 = env60580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60579 == env60580) = true)

theorem identity60580 : scanCanonicalize (H12AffineFastState.compose env60580 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60580 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60581 : List Nat := [0,1,0,1,32,1,33,0,1,33,32,0,1,33,0,0,0,0,32,1,0,0,33,32,32,33,33,1,1,1,1,0,1,32,33,0]

theorem envBound60581 : H12AffineFastState.Bounded env60581 := by
  intro p hp
  have h : env60581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60580_60581 : H12AffineEnvironment.transform 0 0 env60580 = env60581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60580 == env60581) = true)

def env60582 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143496,20497,492567,148669,148669,96266,74795,74799,173,222255,1212,135681]

theorem envBound60582 : H12AffineFastState.Bounded env60582 := by
  intro p hp
  have h : env60582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60565_60582 : H12AffineEnvironment.transform 5 17 env60565 = env60582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60565 == env60582) = true)

theorem identity60582 : scanCanonicalize (H12AffineFastState.compose env60582 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound60582 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60583 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,41003,32809,20497,341174,62492,62492,96266,74795,74799,173,119950,1212,41632]

theorem envBound60583 : H12AffineFastState.Bounded env60583 := by
  intro p hp
  have h : env60583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60582_60583 : H12AffineEnvironment.transform 16 45217 env60582 = env60583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env60582 == env60583) = true)

theorem identity60583 : scanCanonicalize (H12AffineFastState.compose env60583 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound60583 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env60584 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4096,46141,46092,41003,32809,5292,341174,45217,45217,81079,74795,74799,173,102451,1212,41632]

theorem envBound60584 : H12AffineFastState.Bounded env60584 := by
  intro p hp
  have h : env60584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60583_60584 : H12AffineEnvironment.transform 13 1213 env60583 = env60584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env60583 == env60584) = true)

theorem identity60584 : scanCanonicalize (H12AffineFastState.compose env60584 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound60584 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60585 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,32768,65536,45217,262144,41125,32769,4096,45112,45065,41003,32809,4265,340147,45217,45217,80050,73774,73770,173,102451,185,41632]

theorem envBound60585 : H12AffineFastState.Bounded env60585 := by
  intro p hp
  have h : env60585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60584_60585 : H12AffineEnvironment.transform 9 5 env60584 = env60585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env60584 == env60585) = true)

theorem identity60585 : scanCanonicalize (H12AffineFastState.compose env60585 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound60585 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env60586 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,32768,37019,45217,262144,41125,32769,4096,45112,45065,41003,32809,4265,303144,45217,45217,43049,45237,45233,173,168,185,41632]

theorem envBound60586 : H12AffineFastState.Bounded env60586 := by
  intro p hp
  have h : env60586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60585_60586 : H12AffineEnvironment.transform 15 37019 env60585 = env60586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env60585 == env60586) = true)

theorem identity60586 : scanCanonicalize (H12AffineFastState.compose env60586 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound60586 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env60587 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,32768,37019,45217,2184,41125,32769,4096,45112,45065,41003,32809,4265,43168,45217,45217,43049,45237,45233,173,168,185,41632]

theorem envBound60587 : H12AffineFastState.Bounded env60587 := by
  intro p hp
  have h : env60587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60586_60587 : H12AffineEnvironment.transform 17 2184 env60586 = env60587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env60586 == env60587) = true)

theorem identity60587 : scanCanonicalize (H12AffineFastState.compose env60587 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 2560) := by decide +kernel

theorem selectedBound60587 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60588 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,2560,6811,15009,2184,10917,2561,4096,14904,14857,10795,2601,4265,8864,15009,15009,8745,15029,15025,173,168,185,10400]

theorem envBound60588 : H12AffineFastState.Bounded env60588 := by
  intro p hp
  have h : env60588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60587_60588 : H12AffineEnvironment.transform 14 2560 env60587 = env60588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env60587 == env60588) = true)

theorem identity60588 : scanCanonicalize (H12AffineFastState.compose env60588 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60588 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env60589 : List Nat := [2,4,8,16,32,17,34,14,512,5,2048,4096,8192,26,2560,6713,14851,2090,10759,2561,4096,14904,14857,10795,2601,4107,8706,14851,14851,8745,14871,14867,15,10,27,10242]

theorem envBound60589 : H12AffineFastState.Bounded env60589 := by
  intro p hp
  have h : env60589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60588_60589 : H12AffineEnvironment.transform 6 34 env60588 = env60589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60588 == env60589) = true)

theorem identity60589 : scanCanonicalize (H12AffineFastState.compose env60589 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound60589 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60590 : List Nat := [2,4,8,16,32,17,34,14,512,5,48,4096,8192,26,560,4617,12851,26,8759,561,4096,12808,12857,8731,537,4107,8706,12851,12851,8745,12839,12835,15,10,27,8242]

theorem envBound60590 : H12AffineFastState.Bounded env60590 := by
  intro p hp
  have h : env60590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60589_60590 : H12AffineEnvironment.transform 10 48 env60589 = env60590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env60589 == env60590) = true)

theorem identity60590 : scanCanonicalize (H12AffineFastState.compose env60590 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60591 : List Nat := [2,4,8,16,11,17,9,14,512,5,27,4096,8192,26,539,4617,12824,26,8732,538,4096,12808,12818,8731,537,4107,8706,12824,12824,8706,12812,12808,15,10,27,8217]

theorem envBound60591 : H12AffineFastState.Bounded env60591 := by
  intro p hp
  have h : env60591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60590_60591 : H12AffineEnvironment.transform 4 11 env60590 = env60591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60590 == env60591) = true)

theorem identity60591 : scanCanonicalize (H12AffineFastState.compose env60591 (packedSelected [1,6] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound60591 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env60592 : List Nat := [2,4,8,16,11,17,9,14,512,5,27,22,8192,26,539,543,8718,26,8732,538,22,8734,8708,8731,537,29,8706,8718,8718,8706,8730,8734,15,10,27,8217]

theorem envBound60592 : H12AffineFastState.Bounded env60592 := by
  intro p hp
  have h : env60592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60591_60592 : H12AffineEnvironment.transform 11 22 env60591 = env60592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env60591 == env60592) = true)

theorem identity60592 : scanCanonicalize (H12AffineFastState.compose env60592 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound60592 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env60593 : List Nat := [2,4,8,16,11,17,9,14,512,5,27,22,515,26,539,543,13,26,31,538,22,29,7,24,537,29,1,13,13,1,25,29,15,10,27,538]

theorem envBound60593 : H12AffineFastState.Bounded env60593 := by
  intro p hp
  have h : env60593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60592_60593 : H12AffineEnvironment.transform 12 515 env60592 = env60593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env60592 == env60593) = true)

theorem identity60593 : scanCanonicalize (H12AffineFastState.compose env60593 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60593 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60594 : List Nat := [2,4,8,11,11,10,9,14,512,5,0,13,515,1,512,516,13,1,4,513,13,6,7,3,514,6,1,13,13,1,2,6,15,10,0,513]

theorem envBound60594 : H12AffineFastState.Bounded env60594 := by
  intro p hp
  have h : env60594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60593_60594 : H12AffineEnvironment.transform 3 11 env60593 = env60594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60593 == env60594) = true)

theorem identity60594 : scanCanonicalize (H12AffineFastState.compose env60594 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound60594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60595 : List Nat := [2,0,8,11,11,10,9,10,512,1,0,9,515,1,512,512,9,1,0,513,9,2,3,3,514,2,1,9,9,1,2,2,11,10,0,513]

theorem envBound60595 : H12AffineFastState.Bounded env60595 := by
  intro p hp
  have h : env60595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60594_60595 : H12AffineEnvironment.transform 1 0 env60594 = env60595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env60594 == env60595) = true)

theorem identity60595 : scanCanonicalize (H12AffineFastState.compose env60595 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60596 : List Nat := [2,0,0,3,3,2,1,2,512,1,0,1,515,1,512,512,1,1,0,513,1,2,3,3,514,2,1,1,1,1,2,2,3,2,0,513]

theorem envBound60596 : H12AffineFastState.Bounded env60596 := by
  intro p hp
  have h : env60596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60595_60596 : H12AffineEnvironment.transform 2 0 env60595 = env60596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60595 == env60596) = true)

theorem identity60596 : scanCanonicalize (H12AffineFastState.compose env60596 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound60596 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60597 : List Nat := [2,0,0,3,3,2,1,2,1,1,0,1,2,1,1,1,1,1,0,0,1,2,3,3,3,2,1,1,1,1,2,2,3,2,0,0]

theorem envBound60597 : H12AffineFastState.Bounded env60597 := by
  intro p hp
  have h : env60597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60596_60597 : H12AffineEnvironment.transform 8 1 env60596 = env60597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60596 == env60597) = true)

theorem identity60597 : scanCanonicalize (H12AffineFastState.compose env60597 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60597 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60598 : List Nat := [1,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,0,1,1,0,0,0,1,1,1,1,1,1,1,0,1,0,0]

theorem envBound60598 : H12AffineFastState.Bounded env60598 := by
  intro p hp
  have h : env60598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60597_60598 : H12AffineEnvironment.transform 0 1 env60597 = env60598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60597 == env60598) = true)

def env60599 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,492615,148717,148717,96347,74795,74799,172,222334,1260,135681]

theorem envBound60599 : H12AffineFastState.Bounded env60599 := by
  intro p hp
  have h : env60599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60564_60599 : H12AffineEnvironment.transform 7 173 env60564 = env60599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env60564 == env60599) = true)

def env60600 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143496,20497,492567,148669,148669,96267,74795,74799,172,222254,1212,135681]

theorem envBound60600 : H12AffineFastState.Bounded env60600 := by
  intro p hp
  have h : env60600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60599_60600 : H12AffineEnvironment.transform 5 16 env60599 = env60600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60599 == env60600) = true)

theorem identity60600 : scanCanonicalize (H12AffineFastState.compose env60600 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound60600 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60601 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61569,147473,41003,143496,20497,60444,148669,148669,96267,74795,74799,172,222254,1212,135681]

theorem envBound60601 : H12AffineFastState.Bounded env60601 := by
  intro p hp
  have h : env60601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60600_60601 : H12AffineEnvironment.transform 17 223243 env60600 = env60601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env60600 == env60601) = true)

theorem identity60601 : scanCanonicalize (H12AffineFastState.compose env60601 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound60601 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env60602 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4096,61569,147473,41003,143496,20497,60444,148669,148669,2184,21672,21676,172,136365,1212,135681]

theorem envBound60602 : H12AffineFastState.Bounded env60602 := by
  intro p hp
  have h : env60602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60601_60602 : H12AffineEnvironment.transform 15 28803 env60601 = env60602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env60601 == env60602) = true)

theorem identity60602 : scanCanonicalize (H12AffineFastState.compose env60602 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound60602 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env60603 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,46245,44077,41124,32769,4096,61569,62644,41003,33837,20497,60444,61464,61464,2184,21672,21676,172,40968,1212,42660]

theorem envBound60603 : H12AffineFastState.Bounded env60603 := by
  intro p hp
  have h : env60603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60602_60603 : H12AffineEnvironment.transform 16 46245 env60602 = env60603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env60602 == env60603) = true)

theorem identity60603 : scanCanonicalize (H12AffineFastState.compose env60603 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound60603 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env60604 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13375,46245,44077,41124,32769,4096,46141,45064,41003,33837,5293,43168,46244,46244,2184,4116,4112,172,40968,1212,42660]

theorem envBound60604 : H12AffineFastState.Bounded env60604 := by
  intro p hp
  have h : env60604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60603_60604 : H12AffineEnvironment.transform 13 1212 env60603 = env60604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env60603 == env60604) = true)

theorem identity60604 : scanCanonicalize (H12AffineFastState.compose env60604 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound60604 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60605 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1212,32768,8322,40984,44077,41124,32769,1213,41088,42165,41003,33837,16,43168,40985,40985,2184,1193,1197,172,40968,1212,42660]

theorem envBound60605 : H12AffineFastState.Bounded env60605 := by
  intro p hp
  have h : env60605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60604_60605 : H12AffineEnvironment.transform 11 1213 env60604 = env60605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env60604 == env60605) = true)

theorem identity60605 : scanCanonicalize (H12AffineFastState.compose env60605 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 2707) := by decide +kernel

theorem selectedBound60605 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env60606 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1212,2707,8322,10891,9918,10807,2706,1213,10771,11814,10936,3774,16,8755,10890,10890,2184,1193,1197,172,10907,1212,11319]

theorem envBound60606 : H12AffineFastState.Bounded env60606 := by
  intro p hp
  have h : env60606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60605_60606 : H12AffineEnvironment.transform 14 2707 env60605 = env60606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2707 env60605 == env60606) = true)

theorem identity60606 : scanCanonicalize (H12AffineFastState.compose env60606 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound60606 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60607 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,2098,1212,2707,2224,697,3724,517,2706,1213,545,1556,650,3774,16,2561,696,696,2184,1193,1197,172,681,1212,1029]

theorem envBound60607 : H12AffineFastState.Bounded env60607 := by
  intro p hp
  have h : env60607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60606_60607 : H12AffineEnvironment.transform 12 2098 env60606 = env60607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env60606 == env60607) = true)

theorem identity60607 : scanCanonicalize (H12AffineFastState.compose env60607 (packedSelected [0,1,3,4,6,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound60607 : packedSelected [0,1,3,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60608 : List Nat := [2,4,8,16,32,16,128,173,132,1024,2048,1213,2098,1212,2071,2224,61,3080,129,2070,1213,165,1168,14,3130,16,2181,60,60,2184,1193,1197,172,45,1212,1029]

theorem envBound60608 : H12AffineFastState.Bounded env60608 := by
  intro p hp
  have h : env60608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60607_60608 : H12AffineEnvironment.transform 8 132 env60607 = env60608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env60607 == env60608) = true)

theorem identity60608 : scanCanonicalize (H12AffineFastState.compose env60608 (packedSelected [0,1,3,5,6,7,16] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound60608 : packedSelected [0,1,3,5,6,7,16] rootPS < 2^1333 := by decide +kernel

def env60609 : List Nat := [2,4,8,16,32,16,128,173,132,1024,39,1213,21,1212,48,151,61,1071,129,49,1213,165,1168,14,1053,16,162,60,60,175,1193,1197,172,45,1212,1029]

theorem envBound60609 : H12AffineFastState.Bounded env60609 := by
  intro p hp
  have h : env60609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60608_60609 : H12AffineEnvironment.transform 10 39 env60608 = env60609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env60608 == env60609) = true)

theorem identity60609 : scanCanonicalize (H12AffineFastState.compose env60609 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 129) := by decide +kernel

theorem selectedBound60609 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60610 : List Nat := [2,4,8,16,32,16,128,173,132,129,39,60,21,61,48,151,61,174,129,49,60,165,17,14,156,16,162,60,60,175,40,44,172,45,61,132]

theorem envBound60610 : H12AffineFastState.Bounded env60610 := by
  intro p hp
  have h : env60610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60609_60610 : H12AffineEnvironment.transform 9 129 env60609 = env60610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 129 env60609 == env60610) = true)

theorem identity60610 : scanCanonicalize (H12AffineFastState.compose env60610 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60610 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60611 : List Nat := [2,4,8,16,32,16,19,62,23,18,39,60,21,61,48,4,61,61,18,49,60,54,17,14,15,16,49,60,60,60,40,44,63,45,61,23]

theorem envBound60611 : H12AffineFastState.Bounded env60611 := by
  intro p hp
  have h : env60611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60610_60611 : H12AffineEnvironment.transform 6 19 env60610 = env60611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60610 == env60611) = true)

def env60612 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143496,20497,492566,148668,148668,96266,74795,74799,172,222255,1213,135681]

theorem envBound60612 : H12AffineFastState.Bounded env60612 := by
  intro p hp
  have h : env60612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60599_60612 : H12AffineEnvironment.transform 5 17 env60599 = env60612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60599 == env60612) = true)

theorem identity60612 : scanCanonicalize (H12AffineFastState.compose env60612 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound60612 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env60613 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61568,98354,41003,127146,20497,279604,99486,99486,96266,74795,74799,172,41997,1213,119331]

theorem envBound60613 : H12AffineFastState.Bounded env60613 := by
  intro p hp
  have h : env60613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60612_60613 : H12AffineEnvironment.transform 16 114722 env60612 = env60613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env60612 == env60613) = true)

theorem identity60613 : scanCanonicalize (H12AffineFastState.compose env60613 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 122031) := by decide +kernel

theorem selectedBound60613 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env60614 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,122031,119843,32769,4096,61568,98354,41003,127146,20497,104603,99486,99486,96266,74795,74799,172,41997,1213,119331]

theorem envBound60614 : H12AffineFastState.Bounded env60614 := by
  intro p hp
  have h : env60614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60613_60614 : H12AffineEnvironment.transform 17 122031 env60613 = env60614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122031 env60613 == env60614) = true)

theorem identity60614 : scanCanonicalize (H12AffineFastState.compose env60614 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound60614 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env60615 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,3212,1024,32769,4096,61568,20497,41003,8329,20497,18616,21693,21693,43049,62472,62476,172,41997,1213,512]

theorem envBound60615 : H12AffineFastState.Bounded env60615 := by
  intro p hp
  have h : env60615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60614_60615 : H12AffineEnvironment.transform 15 53283 env60614 = env60615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env60614 == env60615) = true)

theorem identity60615 : scanCanonicalize (H12AffineFastState.compose env60615 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound60615 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60616 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24600,12347,4097,3212,1024,24601,4096,4248,20497,16435,8329,20497,18616,21693,21693,18481,5136,5140,172,17429,1213,512]

theorem envBound60616 : H12AffineFastState.Bounded env60616 := by
  intro p hp
  have h : env60616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60615_60616 : H12AffineEnvironment.transform 14 24600 env60615 = env60616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env60615 == env60616) = true)

theorem identity60616 : scanCanonicalize (H12AffineFastState.compose env60616 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound60616 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60617 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,657,16384,17033,4778,4097,3212,1024,17032,4096,4248,20497,16435,536,20497,18616,21693,21693,18481,5136,5140,172,17429,1213,512]

theorem envBound60617 : H12AffineFastState.Bounded env60617 := by
  intro p hp
  have h : env60617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60616_60617 : H12AffineEnvironment.transform 12 657 env60616 = env60617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env60616 == env60617) = true)

theorem identity60617 : scanCanonicalize (H12AffineFastState.compose env60617 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound60617 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env60618 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,4096,657,16384,17033,4778,4097,2707,543,17032,4096,4248,20497,16435,536,20497,18616,21154,21154,18481,4623,4619,172,16906,674,512]

theorem envBound60618 : H12AffineFastState.Bounded env60618 := by
  intro p hp
  have h : env60618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60617_60618 : H12AffineEnvironment.transform 9 543 env60617 = env60618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env60617 == env60618) = true)

theorem identity60618 : scanCanonicalize (H12AffineFastState.compose env60618 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6818) := by decide +kernel

theorem selectedBound60618 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env60619 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,4096,657,6818,6187,4778,4097,2707,543,6186,4096,4248,2739,6801,536,2739,4634,2048,2048,4755,4623,4619,172,6312,674,512]

theorem envBound60619 : H12AffineFastState.Bounded env60619 := by
  intro p hp
  have h : env60619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60618_60619 : H12AffineEnvironment.transform 13 6818 env60618 = env60619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6818 env60618 == env60619) = true)

theorem identity60619 : scanCanonicalize (H12AffineFastState.compose env60619 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound60619 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60620 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,184,657,2586,2195,530,185,2707,543,2194,184,32,2739,2601,536,2739,674,2048,2048,555,695,691,172,2064,674,512]

theorem envBound60620 : H12AffineFastState.Bounded env60620 := by
  intro p hp
  have h : env60620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60619_60620 : H12AffineEnvironment.transform 11 184 env60619 = env60620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env60619 == env60620) = true)

theorem identity60620 : scanCanonicalize (H12AffineFastState.compose env60620 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound60620 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60621 : List Nat := [2,4,8,16,32,17,128,173,512,543,675,184,657,185,560,530,185,48,543,561,184,32,16,138,536,16,674,675,675,555,695,691,172,691,674,512]

theorem envBound60621 : H12AffineFastState.Bounded env60621 := by
  intro p hp
  have h : env60621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60620_60621 : H12AffineEnvironment.transform 10 675 env60620 = env60621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env60620 == env60621) = true)

theorem identity60621 : scanCanonicalize (H12AffineFastState.compose env60621 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound60621 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60622 : List Nat := [2,4,8,16,32,17,128,173,27,4,184,184,138,185,43,9,185,48,4,42,184,32,16,138,3,16,185,184,184,48,172,168,172,168,185,27]

theorem envBound60622 : H12AffineFastState.Bounded env60622 := by
  intro p hp
  have h : env60622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60621_60622 : H12AffineEnvironment.transform 8 27 env60621 = env60622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env60621 == env60622) = true)

theorem identity60622 : scanCanonicalize (H12AffineFastState.compose env60622 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound60622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60623 : List Nat := [2,4,8,16,32,17,21,56,27,4,45,45,31,44,43,9,44,48,4,42,45,32,16,31,3,16,44,45,45,48,57,61,57,61,44,27]

theorem envBound60623 : H12AffineFastState.Bounded env60623 := by
  intro p hp
  have h : env60623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60622_60623 : H12AffineEnvironment.transform 6 21 env60622 = env60623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env60622 == env60623) = true)

theorem identity60623 : scanCanonicalize (H12AffineFastState.compose env60623 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound60623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60624 : List Nat := [2,4,8,12,32,13,9,36,7,4,45,45,3,44,43,9,44,44,4,42,45,32,12,3,3,12,44,45,45,44,37,33,37,33,44,7]

theorem envBound60624 : H12AffineFastState.Bounded env60624 := by
  intro p hp
  have h : env60624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60623_60624 : H12AffineEnvironment.transform 3 12 env60623 = env60624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env60623 == env60624) = true)

theorem identity60624 : scanCanonicalize (H12AffineFastState.compose env60624 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60624 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60625 : List Nat := [2,3,8,11,32,10,9,35,0,3,42,42,3,43,43,9,43,43,3,42,42,32,11,3,3,11,43,42,42,43,34,33,34,33,43,0]

theorem envBound60625 : H12AffineFastState.Bounded env60625 := by
  intro p hp
  have h : env60625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60624_60625 : H12AffineEnvironment.transform 1 3 env60624 = env60625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60624 == env60625) = true)

theorem identity60625 : scanCanonicalize (H12AffineFastState.compose env60625 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60625 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60626 : List Nat := [2,3,8,11,11,10,9,8,0,3,1,1,3,0,0,9,0,0,3,1,1,11,11,3,3,11,0,1,1,0,9,10,9,10,0,0]

theorem envBound60626 : H12AffineFastState.Bounded env60626 := by
  intro p hp
  have h : env60626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60625_60626 : H12AffineEnvironment.transform 4 11 env60625 = env60626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60625 == env60626) = true)

def env60627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148800,33584584,96346,50962569,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound60627 : H12AffineFastState.Bounded env60627 := by
  intro p hp
  have h : env60627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59467_60627 : H12AffineEnvironment.transform 20 4097 env59467 = env60627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env59467 == env60627) = true)

theorem identity60627 : scanCanonicalize (H12AffineFastState.compose env60627 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 151258286) := by decide +kernel

theorem selectedBound60627 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env60628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148800,33584584,96346,50962569,151258286,34088328,168088669,151462016,33563273]

theorem envBound60628 : H12AffineFastState.Bounded env60628 := by
  intro p hp
  have h : env60628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60627_60628 : H12AffineEnvironment.transform 31 151258286 env60627 = env60628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 151258286 env60627 == env60628) = true)

def env60629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,134217728,148800,545088,96346,16876545,151258286,256,135065813,151462016,525825]

theorem envBound60629 : H12AffineFastState.Bounded env60629 := by
  intro p hp
  have h : env60629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60628_60629 : H12AffineEnvironment.transform 24 533640 env60628 = env60629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env60628 == env60629) = true)

def env60630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245632,148800,545088,96346,16876545,205166,256,17552661,1344,525825]

theorem envBound60630 : H12AffineFastState.Bounded env60630 := by
  intro p hp
  have h : env60630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60629_60630 : H12AffineEnvironment.transform 26 17245632 env60629 = env60630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env60629 == env60630) = true)

theorem identity60630 : scanCanonicalize (H12AffineFastState.compose env60630 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound60630 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env60631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86518,209262,17245632,148800,74814,96346,16876545,205166,256,16949355,1344,95103]

theorem envBound60631 : H12AffineFastState.Bounded env60631 := by
  intro p hp
  have h : env60631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60630_60631 : H12AffineEnvironment.transform 18 95614 env60630 = env60631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env60630 == env60631) = true)

def env60632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86518,209262,225344,148800,74814,96346,381313,205166,256,456171,1344,95103]

theorem envBound60632 : H12AffineFastState.Bounded env60632 := by
  intro p hp
  have h : env60632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60631_60632 : H12AffineEnvironment.transform 23 284032 env60631 = env60632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env60631 == env60632) = true)

def env60633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86518,94526,77840,1296,74814,96346,381313,90430,256,308667,1344,95103]

theorem envBound60633 : H12AffineFastState.Bounded env60633 := by
  intro p hp
  have h : env60633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60632_60633 : H12AffineEnvironment.transform 16 16464 env60632 = env60633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env60632 == env60633) = true)

def env60634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70886,78894,77840,1296,74814,81226,365713,74798,256,308667,1344,79471]

theorem envBound60634 : H12AffineFastState.Bounded env60634 := by
  intro p hp
  have h : env60634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60633_60634 : H12AffineEnvironment.transform 13 1296 env60633 = env60634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60633 == env60634) = true)

theorem identity60634 : scanCanonicalize (H12AffineFastState.compose env60634 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound60634 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,17,266384,38036,46172,45154,1296,42060,48440,267491,42076,256,308667,1344,46621]

theorem envBound60635 : H12AffineFastState.Bounded env60635 := by
  intro p hp
  have h : env60635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60634_60635 : H12AffineEnvironment.transform 15 32882 env60634 = env60635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env60634 == env60635) = true)

def env60636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263632,33236,41244,42274,1296,42060,43128,262563,42076,256,303355,1344,41821]

theorem envBound60636 : H12AffineFastState.Bounded env60636 := by
  intro p hp
  have h : env60636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60635_60636 : H12AffineEnvironment.transform 11 1344 env60635 = env60636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env60635 == env60636) = true)

theorem identity60636 : scanCanonicalize (H12AffineFastState.compose env60636 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound60636 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,325,311,1344,262144,9241,324,1345,8645,17,263632,145,8281,9319,1296,9481,10557,262563,9497,256,270782,1344,8728]

theorem envBound60637 : H12AffineFastState.Bounded env60637 := by
  intro p hp
  have h : env60637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60636_60637 : H12AffineEnvironment.transform 14 325 env60636 = env60637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env60636 == env60637) = true)

theorem identity60637 : scanCanonicalize (H12AffineFastState.compose env60637 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound60637 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2