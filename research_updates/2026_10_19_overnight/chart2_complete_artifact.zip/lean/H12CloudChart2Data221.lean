import H12CloudChart2Data220

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity55733 : scanCanonicalize (H12AffineFastState.compose env55733 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55733 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55734 : List Nat := [2,4,5,6,7,7,5,2,1,5,0,0,8192,0,8194,8199,0,1,4,8195,0,7,7,3,8193,6,1,1,0,0,2,7,2,6,1,1]

theorem envBound55734 : H12AffineFastState.Bounded env55734 := by
  intro p hp
  have h : env55734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55733_55734 : H12AffineEnvironment.transform 4 7 env55733 = env55734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55733 == env55734) = true)

def env55735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1374,32769,4096,61649,5456,284032,8662,5215,21872,4177,21535,2170,303520,21840,256,324084,1345,863]

theorem envBound55735 : H12AffineFastState.Bounded env55735 := by
  intro p hp
  have h : env55735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55720_55735 : H12AffineEnvironment.transform 15 28705 env55720 = env55735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env55720 == env55735) = true)

def env55736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86519,209262,225344,148801,74814,96347,381312,131136,256,513220,1345,95102]

theorem envBound55736 : H12AffineFastState.Bounded env55736 := by
  intro p hp
  have h : env55736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55701_55736 : H12AffineEnvironment.transform 23 284033 env55701 = env55736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env55701 == env55736) = true)

def env55737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95615,32769,4096,61649,91504,284033,86519,5214,21872,90225,74814,96347,381312,75120,256,324084,1345,95102]

theorem envBound55737 : H12AffineFastState.Bounded env55737 := by
  intro p hp
  have h : env55737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55736_55737 : H12AffineEnvironment.transform 16 75056 env55736 = env55737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env55736 == env55737) = true)

def env55738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1375,32769,4096,61649,5456,284033,8663,5214,21872,4177,21534,2171,303520,21840,256,324084,1345,862]

theorem envBound55738 : H12AffineFastState.Bounded env55738 := by
  intro p hp
  have h : env55738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55737_55738 : H12AffineEnvironment.transform 15 28704 env55737 = env55738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env55737 == env55738) = true)

def env55739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1374,32769,4096,61649,5457,284033,8662,5214,21872,4176,21535,2170,303521,21841,256,324084,1345,863]

theorem envBound55739 : H12AffineFastState.Bounded env55739 := by
  intro p hp
  have h : env55739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55737_55739 : H12AffineEnvironment.transform 15 28705 env55737 = env55739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env55737 == env55739) = true)

theorem identity55739 : scanCanonicalize (H12AffineFastState.compose env55739 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound55739 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55740 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21582,262144,1025,32769,4096,61649,5134,283870,8329,5214,21551,4176,21535,2170,303358,21518,95,323755,1054,512]

theorem envBound55740 : H12AffineFastState.Bounded env55740 := by
  intro p hp
  have h : env55740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55739_55740 : H12AffineEnvironment.transform 7 95 env55739 = env55740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env55739 == env55740) = true)

theorem identity55740 : scanCanonicalize (H12AffineFastState.compose env55740 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound55740 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55741 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21582,5356,1025,32769,4096,61649,5134,16434,8329,5214,21551,4176,21535,2170,46098,21518,95,58439,1054,512]

theorem envBound55741 : H12AffineFastState.Bounded env55741 := by
  intro p hp
  have h : env55741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55740_55741 : H12AffineEnvironment.transform 17 5356 env55740 = env55741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env55740 == env55741) = true)

theorem identity55741 : scanCanonicalize (H12AffineFastState.compose env55741 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound55741 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55742 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25677,28705,21582,5356,1025,25676,4096,5276,5134,16434,8329,5214,21551,4176,21535,2170,20575,21518,95,10,1054,512]

theorem envBound55742 : H12AffineFastState.Bounded env55742 := by
  intro p hp
  have h : env55742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55741_55742 : H12AffineEnvironment.transform 14 25677 env55741 = env55742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env55741 == env55742) = true)

theorem identity55742 : scanCanonicalize (H12AffineFastState.compose env55742 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55742 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55743 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25628,28705,21535,5309,1025,25629,4096,5276,5134,16434,8329,5135,21551,4097,21535,2091,20494,21518,14,10,1054,512]

theorem envBound55743 : H12AffineFastState.Bounded env55743 := by
  intro p hp
  have h : env55743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55742_55743 : H12AffineEnvironment.transform 5 17 env55742 = env55743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55742 == env55743) = true)

theorem identity55743 : scanCanonicalize (H12AffineFastState.compose env55743 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55743 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55744 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,16384,24601,28705,20506,4280,4,24600,4096,4249,4107,16434,8329,4106,20522,4097,20506,2091,20494,20491,14,10,27,512]

theorem envBound55744 : H12AffineFastState.Bounded env55744 := by
  intro p hp
  have h : env55744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55743_55744 : H12AffineEnvironment.transform 9 5 env55743 = env55744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55743 == env55744) = true)

theorem identity55744 : scanCanonicalize (H12AffineFastState.compose env55744 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound55744 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55745 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,1,8216,12320,4123,4280,4,8217,4096,4249,4107,51,8329,4106,4139,4097,4123,2091,4111,4106,14,10,27,512]

theorem envBound55745 : H12AffineFastState.Bounded env55745 := by
  intro p hp
  have h : env55745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55744_55745 : H12AffineEnvironment.transform 13 1 env55744 = env55745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env55744 == env55745) = true)

theorem identity55745 : scanCanonicalize (H12AffineFastState.compose env55745 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound55745 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55746 : List Nat := [2,4,8,16,32,17,128,14,512,5,649,4096,8192,1,8216,12320,4123,4280,4,8217,4096,4249,4107,51,8329,4106,4139,4097,4123,674,4111,4106,14,10,27,512]

theorem envBound55746 : H12AffineFastState.Bounded env55746 := by
  intro p hp
  have h : env55746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55745_55746 : H12AffineEnvironment.transform 10 649 env55745 = env55746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env55745 == env55746) = true)

theorem identity55746 : scanCanonicalize (H12AffineFastState.compose env55746 (packedSelected [10,15] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound55746 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env55747 : List Nat := [2,4,8,16,32,17,128,14,512,5,649,555,8192,1,8216,8715,560,659,4,8217,555,690,544,51,8329,545,512,554,560,674,548,545,14,10,27,512]

theorem envBound55747 : H12AffineFastState.Bounded env55747 := by
  intro p hp
  have h : env55747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55746_55747 : H12AffineEnvironment.transform 11 555 env55746 = env55747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env55746 == env55747) = true)

theorem identity55747 : scanCanonicalize (H12AffineFastState.compose env55747 (packedSelected [4,5,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound55747 : packedSelected [4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55748 : List Nat := [2,4,8,16,32,17,53,14,512,5,572,555,8192,1,8216,8715,560,550,4,8217,555,519,544,51,8252,545,512,554,560,535,548,545,14,10,27,512]

theorem envBound55748 : H12AffineFastState.Bounded env55748 := by
  intro p hp
  have h : env55748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55747_55748 : H12AffineEnvironment.transform 6 53 env55747 = env55748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env55747 == env55748) = true)

theorem identity55748 : scanCanonicalize (H12AffineFastState.compose env55748 (packedSelected [1,2,3,4,5,7,8,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound55748 : packedSelected [1,2,3,4,5,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env55749 : List Nat := [2,4,8,16,32,17,53,14,39,5,27,12,8192,1,8216,8236,23,1,4,8217,12,32,7,51,8252,6,39,13,23,48,3,6,14,10,27,39]

theorem envBound55749 : H12AffineFastState.Bounded env55749 := by
  intro p hp
  have h : env55749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55748_55749 : H12AffineEnvironment.transform 8 39 env55748 = env55749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env55748 == env55749) = true)

theorem identity55749 : scanCanonicalize (H12AffineFastState.compose env55749 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55749 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env55750 : List Nat := [2,4,8,10,32,11,47,14,39,5,1,12,8192,1,8194,8236,13,1,4,8195,12,32,7,41,8230,6,39,13,13,42,3,6,14,10,1,39]

theorem envBound55750 : H12AffineFastState.Bounded env55750 := by
  intro p hp
  have h : env55750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55749_55750 : H12AffineEnvironment.transform 3 10 env55749 = env55750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55749 == env55750) = true)

theorem identity55750 : scanCanonicalize (H12AffineFastState.compose env55750 (packedSelected [2,3] rootPS)) = affineNative (2^(12+1) ^^^ 37) := by decide +kernel

theorem selectedBound55750 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env55751 : List Nat := [2,4,8,10,32,11,47,14,39,5,1,12,37,1,39,9,13,1,4,38,12,32,7,41,3,6,39,13,13,42,3,6,14,10,1,39]

theorem envBound55751 : H12AffineFastState.Bounded env55751 := by
  intro p hp
  have h : env55751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55750_55751 : H12AffineEnvironment.transform 12 37 env55750 = env55751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 37 env55750 == env55751) = true)

theorem identity55751 : scanCanonicalize (H12AffineFastState.compose env55751 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55752 : List Nat := [2,4,8,10,10,11,5,14,13,5,1,12,15,1,13,9,13,1,4,12,12,10,7,3,3,6,13,13,13,0,3,6,14,10,1,13]

theorem envBound55752 : H12AffineFastState.Bounded env55752 := by
  intro p hp
  have h : env55752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55751_55752 : H12AffineEnvironment.transform 4 10 env55751 = env55752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55751 == env55752) = true)

def env55753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95615,32769,4096,61649,91505,284033,86519,5215,21873,90224,74814,96347,381312,75121,256,324085,1345,95102]

theorem envBound55753 : H12AffineFastState.Bounded env55753 := by
  intro p hp
  have h : env55753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55736_55753 : H12AffineEnvironment.transform 16 75057 env55736 = env55753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env55736 == env55753) = true)

def env55754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1375,32769,4096,61649,5457,284033,8663,5215,21873,4176,21534,2171,303520,21841,256,324085,1345,862]

theorem envBound55754 : H12AffineFastState.Bounded env55754 := by
  intro p hp
  have h : env55754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55753_55754 : H12AffineEnvironment.transform 15 28704 env55753 = env55754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env55753 == env55754) = true)

theorem identity55754 : scanCanonicalize (H12AffineFastState.compose env55754 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound55754 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55755 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21583,262144,1025,32769,4096,61649,5135,283871,8329,5215,21551,4176,21534,2171,303358,21519,94,323755,1055,512]

theorem envBound55755 : H12AffineFastState.Bounded env55755 := by
  intro p hp
  have h : env55755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55754_55755 : H12AffineEnvironment.transform 7 94 env55754 = env55755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env55754 == env55755) = true)

theorem identity55755 : scanCanonicalize (H12AffineFastState.compose env55755 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound55755 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55756 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21583,5357,1025,32769,4096,61649,5135,16434,8329,5215,21551,4176,21534,2171,46099,21519,94,58438,1055,512]

theorem envBound55756 : H12AffineFastState.Bounded env55756 := by
  intro p hp
  have h : env55756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55755_55756 : H12AffineEnvironment.transform 17 5357 env55755 = env55756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env55755 == env55756) = true)

theorem identity55756 : scanCanonicalize (H12AffineFastState.compose env55756 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound55756 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55757 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25677,28704,21583,5357,1025,25676,4096,5276,5135,16434,8329,5215,21551,4176,21534,2171,20574,21519,94,11,1055,512]

theorem envBound55757 : H12AffineFastState.Bounded env55757 := by
  intro p hp
  have h : env55757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55756_55757 : H12AffineEnvironment.transform 14 25677 env55756 = env55757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env55756 == env55757) = true)

theorem identity55757 : scanCanonicalize (H12AffineFastState.compose env55757 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55757 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55758 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25628,28704,21534,5308,1025,25629,4096,5276,5135,16434,8329,5134,21551,4097,21534,2090,20495,21519,15,11,1055,512]

theorem envBound55758 : H12AffineFastState.Bounded env55758 := by
  intro p hp
  have h : env55758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55757_55758 : H12AffineEnvironment.transform 5 17 env55757 = env55758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55757 == env55758) = true)

theorem identity55758 : scanCanonicalize (H12AffineFastState.compose env55758 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55758 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55759 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,16384,24601,28704,20507,4281,4,24600,4096,4249,4106,16434,8329,4107,20522,4097,20507,2090,20495,20490,15,11,26,512]

theorem envBound55759 : H12AffineFastState.Bounded env55759 := by
  intro p hp
  have h : env55759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55758_55759 : H12AffineEnvironment.transform 9 5 env55758 = env55759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55758 == env55759) = true)

theorem identity55759 : scanCanonicalize (H12AffineFastState.compose env55759 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound55759 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55760 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,1,8216,12321,4122,4281,4,8217,4096,4249,4106,51,8329,4107,4139,4097,4122,2090,4110,4107,15,11,26,512]

theorem envBound55760 : H12AffineFastState.Bounded env55760 := by
  intro p hp
  have h : env55760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55759_55760 : H12AffineEnvironment.transform 13 1 env55759 = env55760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env55759 == env55760) = true)

theorem identity55760 : scanCanonicalize (H12AffineFastState.compose env55760 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound55760 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55761 : List Nat := [2,4,8,16,32,17,128,15,512,5,649,4096,8192,1,8216,12321,4122,4281,4,8217,4096,4249,4106,51,8329,4107,4139,4097,4122,675,4110,4107,15,11,26,512]

theorem envBound55761 : H12AffineFastState.Bounded env55761 := by
  intro p hp
  have h : env55761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55760_55761 : H12AffineEnvironment.transform 10 649 env55760 = env55761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env55760 == env55761) = true)

theorem identity55761 : scanCanonicalize (H12AffineFastState.compose env55761 (packedSelected [10,15] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound55761 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env55762 : List Nat := [2,4,8,16,32,17,128,15,512,5,649,555,8192,1,8216,8714,561,658,4,8217,555,690,545,51,8329,544,512,554,561,675,549,544,15,11,26,512]

theorem envBound55762 : H12AffineFastState.Bounded env55762 := by
  intro p hp
  have h : env55762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55761_55762 : H12AffineEnvironment.transform 11 555 env55761 = env55762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env55761 == env55762) = true)

theorem identity55762 : scanCanonicalize (H12AffineFastState.compose env55762 (packedSelected [4,5,7,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound55762 : packedSelected [4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55763 : List Nat := [2,4,8,16,28,17,128,15,512,5,649,535,8192,1,8216,8714,525,658,4,8217,535,654,541,15,8329,540,512,534,525,671,537,540,15,11,26,512]

theorem envBound55763 : H12AffineFastState.Bounded env55763 := by
  intro p hp
  have h : env55763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55762_55763 : H12AffineEnvironment.transform 4 28 env55762 = env55763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env55762 == env55763) = true)

theorem identity55763 : scanCanonicalize (H12AffineFastState.compose env55763 (packedSelected [1,2,3,4,5,7,8,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55763 : packedSelected [1,2,3,4,5,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env55764 : List Nat := [2,4,8,16,28,17,128,15,1,5,136,22,8192,1,8216,8203,12,147,4,8217,22,143,28,15,8329,29,1,23,12,158,24,29,15,11,26,1]

theorem envBound55764 : H12AffineFastState.Bounded env55764 := by
  intro p hp
  have h : env55764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55763_55764 : H12AffineEnvironment.transform 8 1 env55763 = env55764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55763 == env55764) = true)

theorem identity55764 : scanCanonicalize (H12AffineFastState.compose env55764 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound55764 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55765 : List Nat := [2,4,8,16,28,17,18,15,1,5,26,22,8192,1,8216,8203,12,1,4,8217,22,29,28,15,8219,29,1,23,12,12,24,29,15,11,26,1]

theorem envBound55765 : H12AffineFastState.Bounded env55765 := by
  intro p hp
  have h : env55765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55764_55765 : H12AffineEnvironment.transform 6 18 env55764 = env55765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env55764 == env55765) = true)

theorem identity55765 : scanCanonicalize (H12AffineFastState.compose env55765 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55765 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55766 : List Nat := [2,4,8,7,11,6,5,15,1,5,13,1,8192,1,8207,8203,12,1,4,8206,1,10,11,15,8204,10,1,0,12,12,15,10,15,11,13,1]

theorem envBound55766 : H12AffineFastState.Bounded env55766 := by
  intro p hp
  have h : env55766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55765_55766 : H12AffineEnvironment.transform 3 7 env55765 = env55766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55765 == env55766) = true)

theorem identity55766 : scanCanonicalize (H12AffineFastState.compose env55766 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 14) := by decide +kernel

theorem selectedBound55766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55767 : List Nat := [2,4,8,7,11,6,5,15,1,5,13,1,14,1,1,5,12,1,4,0,1,10,11,15,2,10,1,0,12,12,15,10,15,11,13,1]

theorem envBound55767 : H12AffineFastState.Bounded env55767 := by
  intro p hp
  have h : env55767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55766_55767 : H12AffineEnvironment.transform 12 14 env55766 = env55767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 14 env55766 == env55767) = true)

theorem identity55767 : scanCanonicalize (H12AffineFastState.compose env55767 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55767 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55768 : List Nat := [2,4,5,7,6,6,5,2,1,5,0,1,3,1,1,5,1,1,4,0,1,7,6,2,2,7,1,0,1,1,2,7,2,6,0,1]

theorem envBound55768 : H12AffineFastState.Bounded env55768 := by
  intro p hp
  have h : env55768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55767_55768 : H12AffineEnvironment.transform 2 5 env55767 = env55768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55767 == env55768) = true)

def env55769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1374,32769,4096,61649,5456,284033,8662,5215,21873,4177,21535,2170,303521,21840,256,324085,1345,863]

theorem envBound55769 : H12AffineFastState.Bounded env55769 := by
  intro p hp
  have h : env55769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55753_55769 : H12AffineEnvironment.transform 15 28705 env55753 = env55769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env55753 == env55769) = true)

def env55770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,134217728,148801,545088,96347,16876544,750911,257,17006916,151462016,525824]

theorem envBound55770 : H12AffineFastState.Bounded env55770 := by
  intro p hp
  have h : env55770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54914_55770 : H12AffineEnvironment.transform 24 533641 env54914 = env55770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env54914 == env55770) = true)

def env55771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245632,148801,545088,96347,16876544,750911,257,17006916,1344,525824]

theorem envBound55771 : H12AffineFastState.Bounded env55771 := by
  intro p hp
  have h : env55771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55770_55771 : H12AffineEnvironment.transform 26 17245632 env55770 = env55771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env55770 == env55771) = true)

theorem identity55771 : scanCanonicalize (H12AffineFastState.compose env55771 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound55771 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41002,533641,672785,493034,148801,545088,96347,74794,750911,257,205166,1344,525824]

theorem envBound55772 : H12AffineFastState.Bounded env55772 := by
  intro p hp
  have h : env55772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55771_55772 : H12AffineEnvironment.transform 23 41002 env55771 = env55772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env55771 == env55772) = true)

def env55773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,493034,148801,148800,96347,74794,90431,257,205166,1344,135680]

theorem envBound55773 : H12AffineFastState.Bounded env55773 := by
  intro p hp
  have h : env55773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55772_55773 : H12AffineEnvironment.transform 18 136192 env55772 = env55773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env55772 == env55773) = true)

def env55774 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,492614,148717,148716,96347,74794,90259,173,204994,1260,135680]

theorem envBound55774 : H12AffineFastState.Bounded env55774 := by
  intro p hp
  have h : env55774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55773_55774 : H12AffineEnvironment.transform 7 172 env55773 = env55774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55773 == env55774) = true)

def env55775 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143497,20497,492566,148669,148668,96267,74794,90259,173,204946,1212,135680]

theorem envBound55775 : H12AffineFastState.Bounded env55775 := by
  intro p hp
  have h : env55775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55774_55775 : H12AffineEnvironment.transform 5 16 env55774 = env55775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55774 == env55775) = true)

theorem identity55775 : scanCanonicalize (H12AffineFastState.compose env55775 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound55775 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55776 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61569,98354,41002,127147,20497,279604,99487,99486,96267,74794,90259,173,57520,1212,119330]

theorem envBound55776 : H12AffineFastState.Bounded env55776 := by
  intro p hp
  have h : env55776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55775_55776 : H12AffineEnvironment.transform 16 114722 env55775 = env55776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env55775 == env55776) = true)

theorem identity55776 : scanCanonicalize (H12AffineFastState.compose env55776 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 18480) := by decide +kernel

theorem selectedBound55776 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55777 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,18480,119842,32769,4096,61569,98354,41002,127147,20497,3076,99487,99486,96267,74794,90259,173,57520,1212,119330]

theorem envBound55777 : H12AffineFastState.Bounded env55777 := by
  intro p hp
  have h : env55777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55776_55777 : H12AffineEnvironment.transform 17 18480 env55776 = env55777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18480 env55776 == env55777) = true)

theorem identity55777 : scanCanonicalize (H12AffineFastState.compose env55777 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound55777 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env55778 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,18480,1024,32769,4096,61569,20496,41002,8329,20497,3076,21693,21692,43049,62472,45233,173,57520,1212,512]

theorem envBound55778 : H12AffineFastState.Bounded env55778 := by
  intro p hp
  have h : env55778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55777_55778 : H12AffineEnvironment.transform 15 53282 env55777 = env55778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env55777 == env55778) = true)

theorem identity55778 : scanCanonicalize (H12AffineFastState.compose env55778 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound55778 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55779 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,29831,4096,18480,1024,9380,4096,21540,20496,1167,8329,20497,3076,21693,21692,3212,20653,5140,173,17429,1212,512]

theorem envBound55779 : H12AffineFastState.Bounded env55779 := by
  intro p hp
  have h : env55779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55778_55779 : H12AffineEnvironment.transform 14 9381 env55778 = env55779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env55778 == env55779) = true)

theorem identity55779 : scanCanonicalize (H12AffineFastState.compose env55779 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound55779 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55780 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,8745,9381,5806,4096,10777,1024,9380,4096,13837,12857,1167,8329,12856,3076,13972,13973,3212,12932,5140,173,9788,1212,512]

theorem envBound55780 : H12AffineFastState.Bounded env55780 := by
  intro p hp
  have h : env55780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55779_55780 : H12AffineEnvironment.transform 13 8745 env55779 = env55780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env55779 == env55780) = true)

theorem identity55780 : scanCanonicalize (H12AffineFastState.compose env55780 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound55780 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env55781 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1167,1702,42,5806,4096,3734,1024,43,4096,4738,5814,1167,1030,5815,3076,4635,4634,3212,5643,5140,173,691,1212,512]

theorem envBound55781 : H12AffineFastState.Bounded env55781 := by
  intro p hp
  have h : env55781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55780_55781 : H12AffineEnvironment.transform 12 1167 env55780 = env55781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env55780 == env55781) = true)

def env55782 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143497,20497,492567,148668,148669,96266,74794,90259,173,204947,1213,135680]

theorem envBound55782 : H12AffineFastState.Bounded env55782 := by
  intro p hp
  have h : env55782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55774_55782 : H12AffineEnvironment.transform 5 17 env55774 = env55782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55774 == env55782) = true)

theorem identity55782 : scanCanonicalize (H12AffineFastState.compose env55782 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound55782 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55783 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61568,147473,41002,143497,20497,60444,148668,148669,96266,74794,90259,173,204947,1213,135680]

theorem envBound55783 : H12AffineFastState.Bounded env55783 := by
  intro p hp
  have h : env55783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55782_55783 : H12AffineEnvironment.transform 17 223243 env55782 = env55783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env55782 == env55783) = true)

theorem identity55783 : scanCanonicalize (H12AffineFastState.compose env55783 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound55783 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55784 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4096,61568,147473,41002,143497,20497,60444,148668,148669,2185,21673,4112,173,151568,1213,135680]

theorem envBound55784 : H12AffineFastState.Bounded env55784 := by
  intro p hp
  have h : env55784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55783_55784 : H12AffineEnvironment.transform 15 28803 env55783 = env55784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env55783 == env55784) = true)

theorem identity55784 : scanCanonicalize (H12AffineFastState.compose env55784 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55784 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55785 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,28803,131072,137352,136192,24601,4096,4248,147473,16434,143497,20497,3076,148668,148669,2185,21673,4112,173,151568,1213,135680]

theorem envBound55785 : H12AffineFastState.Bounded env55785 := by
  intro p hp
  have h : env55785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55784_55785 : H12AffineEnvironment.transform 14 24600 env55784 = env55785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55784 == env55785) = true)

theorem identity55785 : scanCanonicalize (H12AffineFastState.compose env55785 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound55785 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55786 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,13374,131072,137352,136192,9380,4096,4248,132268,1167,143497,5292,3076,131073,131072,2185,4116,4112,173,136365,1213,135680]

theorem envBound55786 : H12AffineFastState.Bounded env55786 := by
  intro p hp
  have h : env55786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55785_55786 : H12AffineEnvironment.transform 13 1213 env55785 = env55786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env55785 == env55786) = true)

theorem identity55786 : scanCanonicalize (H12AffineFastState.compose env55786 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound55786 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55787 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,6282,1213,7215,3252,131072,137352,136192,7214,4096,4248,132268,1167,133123,5292,3076,131073,131072,2185,4116,4112,173,136365,1213,135680]

theorem envBound55787 : H12AffineFastState.Bounded env55787 := by
  intro p hp
  have h : env55787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55786_55787 : H12AffineEnvironment.transform 12 6282 env55786 = env55787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env55786 == env55787) = true)

theorem identity55787 : scanCanonicalize (H12AffineFastState.compose env55787 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound55787 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env55788 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,2098,1213,3223,3252,131072,133168,132280,3222,184,32,132268,1167,133123,1044,3076,131073,131072,2185,172,168,173,132117,1213,131768]

theorem envBound55788 : H12AffineFastState.Bounded env55788 := by
  intro p hp
  have h : env55788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55787_55788 : H12AffineEnvironment.transform 11 184 env55787 = env55788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env55787 == env55788) = true)

theorem identity55788 : scanCanonicalize (H12AffineFastState.compose env55788 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound55788 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env55789 : List Nat := [2,4,8,16,32,17,128,172,512,517,2048,184,2098,696,2706,2737,131072,133168,131773,2707,184,32,131753,650,133123,529,2561,131073,131072,2185,172,168,173,131600,696,131768]

theorem envBound55789 : H12AffineFastState.Bounded env55789 := by
  intro p hp
  have h : env55789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55788_55789 : H12AffineEnvironment.transform 9 517 env55788 = env55789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env55788 == env55789) = true)

theorem identity55789 : scanCanonicalize (H12AffineFastState.compose env55789 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound55789 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env55790 : List Nat := [2,4,8,16,32,17,128,172,512,517,674,184,656,696,48,19,131072,131730,131773,49,184,32,131753,650,131745,529,163,131073,131072,555,172,168,173,131600,696,131768]

theorem envBound55790 : H12AffineFastState.Bounded env55790 := by
  intro p hp
  have h : env55790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55789_55790 : H12AffineEnvironment.transform 10 674 env55789 = env55790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env55789 == env55790) = true)

theorem identity55790 : scanCanonicalize (H12AffineFastState.compose env55790 (packedSelected [1,5] rootPS)) = affineNative (2^(16+1) ^^^ 185) := by decide +kernel

theorem selectedBound55790 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55791 : List Nat := [2,4,8,16,32,17,128,172,512,517,674,184,656,696,48,19,185,555,516,49,184,32,528,650,536,529,163,184,185,555,172,168,173,681,696,513]

theorem envBound55791 : H12AffineFastState.Bounded env55791 := by
  intro p hp
  have h : env55791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55790_55791 : H12AffineEnvironment.transform 16 185 env55790 = env55791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 185 env55790 == env55791) = true)

theorem identity55791 : scanCanonicalize (H12AffineFastState.compose env55791 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55791 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55792 : List Nat := [2,4,8,16,32,17,128,172,43,46,137,184,187,147,48,19,185,0,47,49,184,32,59,161,51,58,163,184,185,0,172,168,173,130,147,42]

theorem envBound55792 : H12AffineFastState.Bounded env55792 := by
  intro p hp
  have h : env55792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55791_55792 : H12AffineEnvironment.transform 8 43 env55791 = env55792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55791 == env55792) = true)

theorem identity55792 : scanCanonicalize (H12AffineFastState.compose env55792 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55792 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env55793 : List Nat := [2,4,8,7,32,6,128,172,43,46,137,175,172,132,39,4,174,0,47,38,175,32,44,161,36,45,163,175,174,0,172,168,173,130,132,42]

theorem envBound55793 : H12AffineFastState.Bounded env55793 := by
  intro p hp
  have h : env55793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55792_55793 : H12AffineEnvironment.transform 3 7 env55792 = env55793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55792 == env55793) = true)

theorem identity55793 : scanCanonicalize (H12AffineFastState.compose env55793 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound55793 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55794 : List Nat := [2,4,8,7,32,6,46,2,43,46,39,1,2,42,39,4,0,0,47,38,1,32,44,15,36,45,13,1,0,0,2,6,3,44,42,42]

theorem envBound55794 : H12AffineFastState.Bounded env55794 := by
  intro p hp
  have h : env55794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55793_55794 : H12AffineEnvironment.transform 6 46 env55793 = env55794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env55793 == env55794) = true)

theorem identity55794 : scanCanonicalize (H12AffineFastState.compose env55794 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound55794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55795 : List Nat := [2,4,7,7,32,6,33,2,36,33,39,1,2,37,39,4,0,0,32,38,1,32,35,0,36,34,2,1,0,0,2,6,3,35,37,37]

theorem envBound55795 : H12AffineFastState.Bounded env55795 := by
  intro p hp
  have h : env55795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55794_55795 : H12AffineEnvironment.transform 2 7 env55794 = env55795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env55794 == env55795) = true)

theorem identity55795 : scanCanonicalize (H12AffineFastState.compose env55795 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55796 : List Nat := [1,4,4,4,32,5,33,1,36,33,36,1,1,37,36,4,0,0,32,37,1,32,32,0,36,33,1,1,0,0,1,5,0,32,37,37]

theorem envBound55796 : H12AffineFastState.Bounded env55796 := by
  intro p hp
  have h : env55796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55795_55796 : H12AffineEnvironment.transform 0 1 env55795 = env55796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55795 == env55796) = true)

theorem identity55796 : scanCanonicalize (H12AffineFastState.compose env55796 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55796 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55797 : List Nat := [1,4,4,4,0,5,1,1,4,1,4,1,1,5,4,4,0,0,0,5,1,0,0,0,4,1,1,1,0,0,1,5,0,0,5,5]

theorem envBound55797 : H12AffineFastState.Bounded env55797 := by
  intro p hp
  have h : env55797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55796_55797 : H12AffineEnvironment.transform 4 0 env55796 = env55797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55796 == env55797) = true)

theorem identity55797 : scanCanonicalize (H12AffineFastState.compose env55797 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55797 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55798 : List Nat := [1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,1,0,0,0,0,1,0,0,0,1,1,1,1,0,0,1,0,0,0,0,0]

theorem envBound55798 : H12AffineFastState.Bounded env55798 := by
  intro p hp
  have h : env55798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55797_55798 : H12AffineEnvironment.transform 1 1 env55797 = env55798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55797 == env55798) = true)

def env55799 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,492615,148716,148717,96347,74794,90258,172,204995,1261,135680]

theorem envBound55799 : H12AffineFastState.Bounded env55799 := by
  intro p hp
  have h : env55799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55773_55799 : H12AffineEnvironment.transform 7 173 env55773 = env55799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55773 == env55799) = true)

def env55800 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143497,20497,492567,148668,148669,96267,74794,90258,172,204947,1213,135680]

theorem envBound55800 : H12AffineFastState.Bounded env55800 := by
  intro p hp
  have h : env55800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55799_55800 : H12AffineEnvironment.transform 5 16 env55799 = env55800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55799 == env55800) = true)

theorem identity55800 : scanCanonicalize (H12AffineFastState.compose env55800 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound55800 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55801 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,41002,32808,20497,341174,62493,62492,96267,74794,90258,172,102450,1213,41633]

theorem envBound55801 : H12AffineFastState.Bounded env55801 := by
  intro p hp
  have h : env55801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55800_55801 : H12AffineEnvironment.transform 16 45217 env55800 = env55801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env55800 == env55801) = true)

theorem identity55801 : scanCanonicalize (H12AffineFastState.compose env55801 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound55801 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env55802 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4096,46141,46093,41002,32808,5293,341174,45217,45216,81079,74794,74798,172,102450,1213,41633]

theorem envBound55802 : H12AffineFastState.Bounded env55802 := by
  intro p hp
  have h : env55802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55801_55802 : H12AffineEnvironment.transform 13 1212 env55801 = env55802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env55801 == env55802) = true)

theorem identity55802 : scanCanonicalize (H12AffineFastState.compose env55802 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound55802 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55803 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,65536,5125,262144,5,9381,4096,4249,4265,1166,9356,5293,341174,5125,5124,81079,74794,74798,172,78998,1213,1541]

theorem envBound55803 : H12AffineFastState.Bounded env55803 := by
  intro p hp
  have h : env55803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55802_55803 : H12AffineEnvironment.transform 14 9380 env55802 = env55803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env55802 == env55803) = true)

theorem identity55803 : scanCanonicalize (H12AffineFastState.compose env55803 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound55803 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env55804 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,12346,5125,262144,5,9381,4096,4249,4265,1166,9356,5293,263308,5125,5124,3213,5136,5140,172,1196,1213,1541]

theorem envBound55804 : H12AffineFastState.Bounded env55804 := by
  intro p hp
  have h : env55804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55803_55804 : H12AffineEnvironment.transform 15 12346 env55803 = env55804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env55803 == env55804) = true)

theorem identity55804 : scanCanonicalize (H12AffineFastState.compose env55804 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55804 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env55805 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,8353,12346,4096,262144,5,8352,4096,4249,4265,139,8329,4264,262281,4096,4097,2184,4117,4113,172,169,184,512]

theorem envBound55805 : H12AffineFastState.Bounded env55805 := by
  intro p hp
  have h : env55805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55804_55805 : H12AffineEnvironment.transform 9 5 env55804 = env55805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55804 == env55805) = true)

theorem identity55805 : scanCanonicalize (H12AffineFastState.compose env55805 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound55805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55806 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2600,185,2697,6674,4096,262144,5,2696,4096,4249,4265,139,2721,4264,262281,4096,4097,2184,4117,4113,172,169,184,512]

theorem envBound55806 : H12AffineFastState.Bounded env55806 := by
  intro p hp
  have h : env55806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55805_55806 : H12AffineEnvironment.transform 12 2600 env55805 = env55806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env55805 == env55806) = true)

theorem identity55806 : scanCanonicalize (H12AffineFastState.compose env55806 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound55806 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55807 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2600,185,2697,6674,4096,2706,5,2696,4096,4249,4265,139,2721,4264,2587,4096,4097,2184,4117,4113,172,169,184,512]

theorem envBound55807 : H12AffineFastState.Bounded env55807 := by
  intro p hp
  have h : env55807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55806_55807 : H12AffineEnvironment.transform 17 2706 env55806 = env55807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env55806 == env55807) = true)

theorem identity55807 : scanCanonicalize (H12AffineFastState.compose env55807 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound55807 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55808 : List Nat := [2,4,8,16,32,16,128,173,512,5,184,4096,656,185,561,4778,4096,554,5,560,4096,4249,4265,139,537,4264,675,4096,4097,48,4117,4113,172,169,184,512]

theorem envBound55808 : H12AffineFastState.Bounded env55808 := by
  intro p hp
  have h : env55808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55807_55808 : H12AffineEnvironment.transform 10 184 env55807 = env55808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env55807 == env55808) = true)

theorem identity55808 : scanCanonicalize (H12AffineFastState.compose env55808 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55808 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55809 : List Nat := [2,4,8,16,32,16,128,173,0,5,184,4096,144,185,49,4266,4096,42,5,48,4096,4249,4265,139,25,4264,163,4096,4097,48,4117,4113,172,169,184,0]

theorem envBound55809 : H12AffineFastState.Bounded env55809 := by
  intro p hp
  have h : env55809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55808_55809 : H12AffineEnvironment.transform 8 0 env55808 = env55809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55808 == env55809) = true)

theorem identity55809 : scanCanonicalize (H12AffineFastState.compose env55809 (packedSelected [3,4] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound55809 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env55810 : List Nat := [2,4,8,16,32,16,128,173,0,5,184,163,144,185,49,9,163,42,5,48,163,58,10,139,25,11,163,163,162,48,182,178,172,169,184,0]

theorem envBound55810 : H12AffineFastState.Bounded env55810 := by
  intro p hp
  have h : env55810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55809_55810 : H12AffineEnvironment.transform 11 163 env55809 = env55810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env55809 == env55810) = true)

theorem identity55810 : scanCanonicalize (H12AffineFastState.compose env55810 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55810 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55811 : List Nat := [2,4,8,16,32,16,9,36,0,5,49,42,25,48,49,9,42,42,5,48,42,58,10,2,25,11,42,42,43,48,63,59,37,32,49,0]

theorem envBound55811 : H12AffineFastState.Bounded env55811 := by
  intro p hp
  have h : env55811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55810_55811 : H12AffineEnvironment.transform 6 9 env55810 = env55811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55810 == env55811) = true)

theorem identity55811 : scanCanonicalize (H12AffineFastState.compose env55811 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55811 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55812 : List Nat := [2,4,4,16,32,16,5,36,0,5,49,38,21,48,49,5,38,38,5,48,38,54,6,2,21,7,38,38,39,48,51,55,37,32,49,0]

theorem envBound55812 : H12AffineFastState.Bounded env55812 := by
  intro p hp
  have h : env55812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55811_55812 : H12AffineEnvironment.transform 2 4 env55811 = env55812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55811 == env55812) = true)

theorem identity55812 : scanCanonicalize (H12AffineFastState.compose env55812 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55812 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env55813 : List Nat := [2,4,4,7,32,7,5,36,0,5,38,38,2,39,38,5,38,38,5,39,38,33,6,2,2,7,38,38,39,39,36,32,37,32,38,0]

theorem envBound55813 : H12AffineFastState.Bounded env55813 := by
  intro p hp
  have h : env55813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55812_55813 : H12AffineEnvironment.transform 3 7 env55812 = env55813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55812 == env55813) = true)

theorem identity55813 : scanCanonicalize (H12AffineFastState.compose env55813 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55814 : List Nat := [2,4,4,7,6,7,5,2,0,5,0,0,2,1,0,5,0,0,5,1,0,7,6,2,2,7,0,0,1,1,2,6,3,6,0,0]

theorem envBound55814 : H12AffineFastState.Bounded env55814 := by
  intro p hp
  have h : env55814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55813_55814 : H12AffineEnvironment.transform 4 6 env55813 = env55814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55813 == env55814) = true)

def env55815 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143497,20497,492566,148669,148668,96266,74794,90258,172,204946,1212,135680]

theorem envBound55815 : H12AffineFastState.Bounded env55815 := by
  intro p hp
  have h : env55815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55799_55815 : H12AffineEnvironment.transform 5 17 env55799 = env55815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55799 == env55815) = true)

theorem identity55815 : scanCanonicalize (H12AffineFastState.compose env55815 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound55815 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55816 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,41002,143497,20497,105631,148669,148668,96266,74794,90258,172,204946,1212,135680]

theorem envBound55816 : H12AffineFastState.Bounded env55816 := by
  intro p hp
  have h : env55816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55815_55816 : H12AffineEnvironment.transform 17 137353 env55815 = env55816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env55815 == env55816) = true)

theorem identity55816 : scanCanonicalize (H12AffineFastState.compose env55816 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound55816 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55817 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4096,61568,147473,41002,143497,20497,43168,148669,148668,19509,4117,21677,172,136365,1212,135680]

theorem envBound55817 : H12AffineFastState.Bounded env55817 := by
  intro p hp
  have h : env55817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55816_55817 : H12AffineEnvironment.transform 15 13375 env55816 = env55817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env55816 == env55817) = true)

theorem identity55817 : scanCanonicalize (H12AffineFastState.compose env55817 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound55817 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55818 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136192,32769,4096,46140,132269,41002,143497,5293,43168,131073,131072,2185,4117,4113,172,136365,1212,135680]

theorem envBound55818 : H12AffineFastState.Bounded env55818 := by
  intro p hp
  have h : env55818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55817_55818 : H12AffineEnvironment.transform 13 1212 env55817 = env55818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env55817 == env55818) = true)

theorem identity55818 : scanCanonicalize (H12AffineFastState.compose env55818 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound55818 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env55819 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,40985,47248,46105,32769,4096,46140,42164,41002,37008,5293,43168,40984,40985,2185,4117,4113,172,46260,1212,45593]

theorem envBound55819 : H12AffineFastState.Bounded env55819 := by
  intro p hp
  have h : env55819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55818_55819 : H12AffineEnvironment.transform 16 40985 env55818 = env55819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env55818 == env55819) = true)

theorem identity55819 : scanCanonicalize (H12AffineFastState.compose env55819 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound55819 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env55820 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,8192,1212,32768,13375,40985,46135,46105,32769,4096,46140,42164,41002,37008,5293,41991,40984,40985,1070,4117,4113,172,46260,1212,45593]

theorem envBound55820 : H12AffineFastState.Bounded env55820 := by
  intro p hp
  have h : env55820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55819_55820 : H12AffineEnvironment.transform 10 1191 env55819 = env55820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env55819 == env55820) = true)

theorem identity55820 : scanCanonicalize (H12AffineFastState.compose env55820 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound55820 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55821 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,8192,1212,8353,13375,184,5270,5304,8352,4096,5277,1045,139,12337,5293,1190,185,184,1070,4117,4113,172,5141,1212,4792]

theorem envBound55821 : H12AffineFastState.Bounded env55821 := by
  intro p hp
  have h : env55821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55820_55821 : H12AffineEnvironment.transform 14 8353 env55820 = env55821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env55820 == env55821) = true)

theorem identity55821 : scanCanonicalize (H12AffineFastState.compose env55821 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 4282) := by decide +kernel

theorem selectedBound55821 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55822 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,4282,1212,4123,1157,184,5270,5304,4122,4096,5277,1045,139,139,5293,1190,185,184,1070,4117,4113,172,5141,1212,4792]

theorem envBound55822 : H12AffineFastState.Bounded env55822 := by
  intro p hp
  have h : env55822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55821_55822 : H12AffineEnvironment.transform 12 4282 env55821 = env55822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4282 env55821 == env55822) = true)

theorem identity55822 : scanCanonicalize (H12AffineFastState.compose env55822 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound55822 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env55823 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1191,4096,4282,1212,4123,1157,184,5270,5304,4122,4096,5277,1045,139,139,5293,1190,185,184,1070,4117,4113,172,5141,1212,4258]

theorem envBound55823 : H12AffineFastState.Bounded env55823 := by
  intro p hp
  have h : env55823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55822_55823 : H12AffineEnvironment.transform 8 26 env55822 = env55823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env55822 == env55823) = true)

theorem identity55823 : scanCanonicalize (H12AffineFastState.compose env55823 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound55823 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env55824 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1191,163,25,1212,184,1157,184,1077,1051,185,163,1086,1045,139,139,1038,1190,185,184,1070,182,178,172,1206,1212,1]

theorem envBound55824 : H12AffineFastState.Bounded env55824 := by
  intro p hp
  have h : env55824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55823_55824 : H12AffineEnvironment.transform 11 163 env55823 = env55824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env55823 == env55824) = true)

theorem identity55824 : scanCanonicalize (H12AffineFastState.compose env55824 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound55824 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55825 : List Nat := [2,4,8,16,32,17,128,173,26,141,42,163,25,49,184,8,184,184,150,185,163,179,152,139,139,131,43,185,184,163,182,178,172,59,49,1]

theorem envBound55825 : H12AffineFastState.Bounded env55825 := by
  intro p hp
  have h : env55825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55824_55825 : H12AffineEnvironment.transform 9 141 env55824 = env55825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env55824 == env55825) = true)

theorem identity55825 : scanCanonicalize (H12AffineFastState.compose env55825 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55826 : List Nat := [2,4,8,11,32,10,128,173,1,141,42,163,2,42,163,8,163,163,141,162,163,168,131,139,139,131,43,162,163,163,173,169,172,32,42,1]

theorem envBound55826 : H12AffineFastState.Bounded env55826 := by
  intro p hp
  have h : env55826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55825_55826 : H12AffineEnvironment.transform 3 11 env55825 = env55826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55825 == env55826) = true)

theorem identity55826 : scanCanonicalize (H12AffineFastState.compose env55826 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55826 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55827 : List Nat := [2,4,8,11,32,10,8,37,1,5,42,43,2,42,43,8,43,43,5,42,43,32,11,3,3,11,43,42,43,43,37,33,36,32,42,1]

theorem envBound55827 : H12AffineFastState.Bounded env55827 := by
  intro p hp
  have h : env55827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55826_55827 : H12AffineEnvironment.transform 6 8 env55826 = env55827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55826 == env55827) = true)

theorem identity55827 : scanCanonicalize (H12AffineFastState.compose env55827 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55827 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55828 : List Nat := [2,2,8,11,32,10,8,35,1,3,42,43,2,42,43,8,43,43,3,42,43,32,11,3,3,11,43,42,43,43,35,33,34,32,42,1]

theorem envBound55828 : H12AffineFastState.Bounded env55828 := by
  intro p hp
  have h : env55828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55827_55828 : H12AffineEnvironment.transform 1 2 env55827 = env55828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55827 == env55828) = true)

def env55829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,493034,148801,148801,96347,74794,90430,257,205166,1344,135681]

theorem envBound55829 : H12AffineFastState.Bounded env55829 := by
  intro p hp
  have h : env55829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55772_55829 : H12AffineEnvironment.transform 18 136193 env55772 = env55829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env55772 == env55829) = true)

def env55830 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,492614,148717,148717,96347,74794,90258,173,204994,1260,135681]

theorem envBound55830 : H12AffineFastState.Bounded env55830 := by
  intro p hp
  have h : env55830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55829_55830 : H12AffineEnvironment.transform 7 172 env55829 = env55830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55829 == env55830) = true)

def env55831 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143496,20496,492566,148669,148669,96267,74794,90258,173,204946,1212,135681]

theorem envBound55831 : H12AffineFastState.Bounded env55831 := by
  intro p hp
  have h : env55831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55830_55831 : H12AffineEnvironment.transform 5 16 env55830 = env55831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55830 == env55831) = true)

theorem identity55831 : scanCanonicalize (H12AffineFastState.compose env55831 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound55831 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55832 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61569,147472,41002,143496,20496,60445,148669,148669,96267,74794,90258,173,204946,1212,135681]

theorem envBound55832 : H12AffineFastState.Bounded env55832 := by
  intro p hp
  have h : env55832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55831_55832 : H12AffineEnvironment.transform 17 223243 env55831 = env55832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env55831 == env55832) = true)

theorem identity55832 : scanCanonicalize (H12AffineFastState.compose env55832 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound55832 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55833 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4096,61569,147472,41002,143496,20496,60445,148669,148669,2185,21672,4112,173,151568,1212,135681]

theorem envBound55833 : H12AffineFastState.Bounded env55833 := by
  intro p hp
  have h : env55833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55832_55833 : H12AffineEnvironment.transform 15 28802 env55832 = env55833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env55832 == env55833) = true)

theorem identity55833 : scanCanonicalize (H12AffineFastState.compose env55833 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55833 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55834 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,28802,131072,137353,136193,24601,4096,4249,147472,16434,143496,20496,3077,148669,148669,2185,21672,4112,173,151568,1212,135681]

theorem envBound55834 : H12AffineFastState.Bounded env55834 := by
  intro p hp
  have h : env55834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55833_55834 : H12AffineEnvironment.transform 14 24600 env55833 = env55834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55833 == env55834) = true)

theorem identity55834 : scanCanonicalize (H12AffineFastState.compose env55834 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound55834 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55835 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13374,131072,137353,136193,9381,4096,4249,132268,1166,143496,5292,3077,131073,131073,2185,4116,4112,173,136364,1212,135681]

theorem envBound55835 : H12AffineFastState.Bounded env55835 := by
  intro p hp
  have h : env55835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55834_55835 : H12AffineEnvironment.transform 13 1212 env55834 = env55835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env55834 == env55835) = true)

theorem identity55835 : scanCanonicalize (H12AffineFastState.compose env55835 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 10378) := by decide +kernel

theorem selectedBound55835 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55836 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13374,10378,12291,15499,9381,4096,4249,11302,1166,6146,5292,3077,10379,10379,2185,4116,4112,173,15398,1212,14987]

theorem envBound55836 : H12AffineFastState.Bounded env55836 := by
  intro p hp
  have h : env55836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55835_55836 : H12AffineEnvironment.transform 16 10378 env55835 = env55836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10378 env55835 == env55836) = true)

theorem identity55836 : scanCanonicalize (H12AffineFastState.compose env55836 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound55836 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env55837 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2099,1212,3223,7181,185,6192,5304,3222,4096,4249,1045,1166,6146,5292,3077,184,184,2185,4116,4112,173,5141,1212,4792]

theorem envBound55837 : H12AffineFastState.Bounded env55837 := by
  intro p hp
  have h : env55837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55836_55837 : H12AffineEnvironment.transform 12 2099 env55836 = env55837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env55836 == env55837) = true)

theorem identity55837 : scanCanonicalize (H12AffineFastState.compose env55837 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound55837 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env55838 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,697,2099,1212,3223,3764,185,2697,1537,3222,697,544,1045,1166,2747,1557,3077,184,184,2185,685,681,173,1708,1212,1]

theorem envBound55838 : H12AffineFastState.Bounded env55838 := by
  intro p hp
  have h : env55838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55837_55838 : H12AffineEnvironment.transform 11 697 env55837 = env55838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env55837 == env55838) = true)

theorem identity55838 : scanCanonicalize (H12AffineFastState.compose env55838 (packedSelected [0,1,3,4,5,6,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound55838 : packedSelected [0,1,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env55839 : List Nat := [2,4,8,16,32,16,47,3,512,1024,2048,534,2099,1043,3128,3611,22,2598,1537,3129,534,544,1045,1057,2580,1557,3077,23,23,2086,514,518,2,1539,1043,1]

theorem envBound55839 : H12AffineFastState.Bounded env55839 := by
  intro p hp
  have h : env55839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55838_55839 : H12AffineEnvironment.transform 6 47 env55838 = env55839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env55838 == env55839) = true)

theorem identity55839 : scanCanonicalize (H12AffineFastState.compose env55839 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound55839 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env55840 : List Nat := [2,4,8,16,32,16,47,3,512,1024,525,534,574,1043,1589,1046,22,43,1537,1588,534,544,1045,1057,25,1557,1544,23,23,555,514,518,2,1539,1043,1]

theorem envBound55840 : H12AffineFastState.Bounded env55840 := by
  intro p hp
  have h : env55840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55839_55840 : H12AffineEnvironment.transform 10 525 env55839 = env55840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env55839 == env55840) = true)

theorem identity55840 : scanCanonicalize (H12AffineFastState.compose env55840 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 56) := by decide +kernel

theorem selectedBound55840 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env55841 : List Nat := [2,4,8,16,32,16,47,3,512,56,525,534,574,43,525,46,22,43,569,524,534,544,45,25,25,557,560,23,23,555,514,518,2,571,43,1]

theorem envBound55841 : H12AffineFastState.Bounded env55841 := by
  intro p hp
  have h : env55841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55840_55841 : H12AffineEnvironment.transform 9 56 env55840 = env55841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env55840 == env55841) = true)

theorem identity55841 : scanCanonicalize (H12AffineFastState.compose env55841 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound55841 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55842 : List Nat := [2,4,8,16,28,16,19,3,512,4,525,534,514,23,525,18,22,23,517,524,534,540,17,25,25,529,524,23,23,535,514,518,2,519,23,1]

theorem envBound55842 : H12AffineFastState.Bounded env55842 := by
  intro p hp
  have h : env55842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55841_55842 : H12AffineEnvironment.transform 4 28 env55841 = env55842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env55841 == env55842) = true)

theorem identity55842 : scanCanonicalize (H12AffineFastState.compose env55842 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound55842 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55843 : List Nat := [2,4,8,16,28,16,19,3,22,4,27,0,20,23,27,18,22,23,19,26,0,10,17,25,25,7,26,23,23,1,20,16,2,17,23,1]

theorem envBound55843 : H12AffineFastState.Bounded env55843 := by
  intro p hp
  have h : env55843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55842_55843 : H12AffineEnvironment.transform 8 22 env55842 = env55843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env55842 == env55843) = true)

theorem identity55843 : scanCanonicalize (H12AffineFastState.compose env55843 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55843 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55844 : List Nat := [2,4,8,6,10,6,5,3,0,4,13,0,2,1,13,4,0,1,5,12,0,10,7,15,15,7,12,1,1,1,2,6,2,7,1,1]

theorem envBound55844 : H12AffineFastState.Bounded env55844 := by
  intro p hp
  have h : env55844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55843_55844 : H12AffineEnvironment.transform 3 6 env55843 = env55844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55843 == env55844) = true)

theorem identity55844 : scanCanonicalize (H12AffineFastState.compose env55844 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55845 : List Nat := [2,4,6,6,4,6,5,3,0,4,3,0,2,1,3,4,0,1,5,2,0,4,7,1,1,7,2,1,1,1,2,6,2,7,1,1]

theorem envBound55845 : H12AffineFastState.Bounded env55845 := by
  intro p hp
  have h : env55845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55844_55845 : H12AffineEnvironment.transform 2 6 env55844 = env55845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55844 == env55845) = true)

theorem identity55845 : scanCanonicalize (H12AffineFastState.compose env55845 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55845 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55846 : List Nat := [2,1,3,3,1,3,0,3,0,1,3,0,2,1,3,1,0,1,0,2,0,1,2,1,1,2,2,1,1,1,2,3,2,2,1,1]

theorem envBound55846 : H12AffineFastState.Bounded env55846 := by
  intro p hp
  have h : env55846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55845_55846 : H12AffineEnvironment.transform 1 1 env55845 = env55846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55845 == env55846) = true)

theorem identity55846 : scanCanonicalize (H12AffineFastState.compose env55846 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55847 : List Nat := [0,1,1,1,1,1,0,1,0,1,1,0,0,1,1,1,0,1,0,0,0,1,0,1,1,0,0,1,1,1,0,1,0,0,1,1]

theorem envBound55847 : H12AffineFastState.Bounded env55847 := by
  intro p hp
  have h : env55847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55846_55847 : H12AffineEnvironment.transform 0 0 env55846 = env55847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55846 == env55847) = true)

def env55848 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143496,20496,492567,148668,148668,96266,74794,90258,173,204947,1213,135681]

theorem envBound55848 : H12AffineFastState.Bounded env55848 := by
  intro p hp
  have h : env55848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55830_55848 : H12AffineEnvironment.transform 5 17 env55830 = env55848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55830 == env55848) = true)

theorem identity55848 : scanCanonicalize (H12AffineFastState.compose env55848 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound55848 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55849 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61568,98355,41002,127146,20496,279605,99486,99486,96266,74794,90258,173,57521,1213,119331]

theorem envBound55849 : H12AffineFastState.Bounded env55849 := by
  intro p hp
  have h : env55849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55848_55849 : H12AffineEnvironment.transform 16 114722 env55848 = env55849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env55848 == env55849) = true)

theorem identity55849 : scanCanonicalize (H12AffineFastState.compose env55849 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 18480) := by decide +kernel

theorem selectedBound55849 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55850 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,18480,119843,32769,4096,61568,98355,41002,127146,20496,3077,99486,99486,96266,74794,90258,173,57521,1213,119331]

theorem envBound55850 : H12AffineFastState.Bounded env55850 := by
  intro p hp
  have h : env55850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55849_55850 : H12AffineEnvironment.transform 17 18480 env55849 = env55850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18480 env55849 == env55850) = true)

theorem identity55850 : scanCanonicalize (H12AffineFastState.compose env55850 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound55850 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env55851 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,18480,1024,32769,4096,61568,20496,41002,8329,20496,3077,21693,21693,43049,62473,45233,173,57521,1213,512]

theorem envBound55851 : H12AffineFastState.Bounded env55851 := by
  intro p hp
  have h : env55851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55850_55851 : H12AffineEnvironment.transform 15 53283 env55850 = env55851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env55850 == env55851) = true)

theorem identity55851 : scanCanonicalize (H12AffineFastState.compose env55851 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound55851 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55852 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,29831,4097,18480,1024,9381,4096,21540,20496,1166,8329,20496,3077,21693,21693,3213,20653,5141,173,17429,1213,512]

theorem envBound55852 : H12AffineFastState.Bounded env55852 := by
  intro p hp
  have h : env55852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55851_55852 : H12AffineEnvironment.transform 14 9380 env55851 = env55852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env55851 == env55852) = true)

theorem identity55852 : scanCanonicalize (H12AffineFastState.compose env55852 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 9773) := by decide +kernel

theorem selectedBound55852 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55853 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,9773,9380,4778,4097,11805,1024,9381,4096,12809,13885,1166,8329,13885,3077,12944,12944,3213,13952,5141,173,8760,1213,512]

theorem envBound55853 : H12AffineFastState.Bounded env55853 := by
  intro p hp
  have h : env55853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55852_55853 : H12AffineEnvironment.transform 13 9773 env55852 = env55853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9773 env55852 == env55853) = true)

theorem identity55853 : scanCanonicalize (H12AffineFastState.compose env55853 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound55853 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env55854 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,139,1702,1071,4778,4097,3734,1024,1070,4096,4738,5814,1166,2,5814,3077,4635,4635,3213,5643,5141,173,691,1213,512]

theorem envBound55854 : H12AffineFastState.Bounded env55854 := by
  intro p hp
  have h : env55854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55853_55854 : H12AffineEnvironment.transform 12 139 env55853 = env55854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env55853 == env55854) = true)

theorem identity55854 : scanCanonicalize (H12AffineFastState.compose env55854 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3615) := by decide +kernel

theorem selectedBound55854 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env55855 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3615,139,1702,1071,3253,3614,3734,1024,1070,3615,3229,2217,1166,2,2217,3077,3076,3076,3213,2068,2570,173,691,1213,512]

theorem envBound55855 : H12AffineFastState.Bounded env55855 := by
  intro p hp
  have h : env55855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55854_55855 : H12AffineEnvironment.transform 11 3615 env55854 = env55855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3615 env55854 == env55855) = true)

theorem identity55855 : scanCanonicalize (H12AffineFastState.compose env55855 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound55855 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env55856 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1213,674,139,1702,1071,8,675,555,1024,1070,674,32,1044,1166,2,1044,184,185,185,48,1193,1719,173,691,1213,512]

theorem envBound55856 : H12AffineFastState.Bounded env55856 := by
  intro p hp
  have h : env55856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55855_55856 : H12AffineEnvironment.transform 10 1213 env55855 = env55856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env55855 == env55856) = true)

theorem identity55856 : scanCanonicalize (H12AffineFastState.compose env55856 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound55856 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55857 : List Nat := [2,4,8,16,32,17,128,172,512,4,185,674,139,674,43,8,675,555,4,42,674,32,16,138,2,16,184,185,185,48,173,691,173,691,185,512]

theorem envBound55857 : H12AffineFastState.Bounded env55857 := by
  intro p hp
  have h : env55857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55856_55857 : H12AffineEnvironment.transform 9 4 env55856 = env55857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env55856 == env55857) = true)

def env55858 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,492615,148716,148716,96347,74794,90259,172,204995,1261,135681]

theorem envBound55858 : H12AffineFastState.Bounded env55858 := by
  intro p hp
  have h : env55858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55829_55858 : H12AffineEnvironment.transform 7 173 env55829 = env55858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55829 == env55858) = true)

def env55859 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143496,20496,492567,148668,148668,96267,74794,90259,172,204947,1213,135681]

theorem envBound55859 : H12AffineFastState.Bounded env55859 := by
  intro p hp
  have h : env55859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55858_55859 : H12AffineEnvironment.transform 5 16 env55858 = env55859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55858 == env55859) = true)

theorem identity55859 : scanCanonicalize (H12AffineFastState.compose env55859 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound55859 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55860 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,41002,143496,20496,105631,148668,148668,96267,74794,90259,172,204947,1213,135681]

theorem envBound55860 : H12AffineFastState.Bounded env55860 := by
  intro p hp
  have h : env55860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55859_55860 : H12AffineEnvironment.transform 17 137352 env55859 = env55860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env55859 == env55860) = true)

theorem identity55860 : scanCanonicalize (H12AffineFastState.compose env55860 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound55860 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55861 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4096,61569,147472,41002,143496,20496,43168,148668,148668,19508,4117,21676,172,136364,1213,135681]

theorem envBound55861 : H12AffineFastState.Bounded env55861 := by
  intro p hp
  have h : env55861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55860_55861 : H12AffineEnvironment.transform 15 13375 env55860 = env55861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env55860 == env55861) = true)

theorem identity55861 : scanCanonicalize (H12AffineFastState.compose env55861 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound55861 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55862 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136193,32769,4096,46140,132269,41002,143496,5293,43168,131073,131073,2185,4117,4113,172,136364,1213,135681]

theorem envBound55862 : H12AffineFastState.Bounded env55862 := by
  intro p hp
  have h : env55862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55861_55862 : H12AffineEnvironment.transform 13 1213 env55861 = env55862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env55861 == env55862) = true)

theorem identity55862 : scanCanonicalize (H12AffineFastState.compose env55862 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound55862 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env55863 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13375,131072,137352,136193,12312,4096,1061,132269,4147,143496,5293,6329,131073,131073,2185,4117,4113,172,136364,1213,135681]

theorem envBound55863 : H12AffineFastState.Bounded env55863 := by
  intro p hp
  have h : env55863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55862_55863 : H12AffineEnvironment.transform 14 12313 env55862 = env55863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env55862 == env55863) = true)

theorem identity55863 : scanCanonicalize (H12AffineFastState.compose env55863 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound55863 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env55864 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,8192,1213,11270,10272,131072,132247,133150,11271,3103,1061,132269,3116,142487,2226,1190,131073,131073,2185,3082,3086,172,133299,1213,134686]

theorem envBound55864 : H12AffineFastState.Bounded env55864 := by
  intro p hp
  have h : env55864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55863_55864 : H12AffineEnvironment.transform 11 3103 env55863 = env55864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env55863 == env55864) = true)

theorem identity55864 : scanCanonicalize (H12AffineFastState.compose env55864 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound55864 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env55865 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1052,1213,2074,3132,131072,132247,133150,2075,3103,1061,132269,3116,133259,2226,1190,131073,131073,2185,3082,3086,172,133299,1213,134686]

theorem envBound55865 : H12AffineFastState.Bounded env55865 := by
  intro p hp
  have h : env55865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55864_55865 : H12AffineEnvironment.transform 12 1052 env55864 = env55865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env55864 == env55865) = true)

theorem identity55865 : scanCanonicalize (H12AffineFastState.compose env55865 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 2194) := by decide +kernel

theorem selectedBound55865 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55866 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1052,1213,2074,3132,2194,3077,140,2075,3103,1061,3135,3116,25,2226,1190,2195,2195,2185,3082,3086,172,33,1213,1676]

theorem envBound55866 : H12AffineFastState.Bounded env55866 := by
  intro p hp
  have h : env55866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55865_55866 : H12AffineEnvironment.transform 16 2194 env55865 = env55866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2194 env55865 == env55866) = true)

theorem identity55866 : scanCanonicalize (H12AffineFastState.compose env55866 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound55866 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55867 : List Nat := [2,4,8,16,32,16,128,173,512,1024,163,1212,1052,1213,185,1183,49,1190,140,184,1212,1061,1180,1167,25,17,1190,48,48,42,1193,1197,172,33,1213,1676]

theorem envBound55867 : H12AffineFastState.Bounded env55867 := by
  intro p hp
  have h : env55867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55866_55867 : H12AffineEnvironment.transform 10 163 env55866 = env55867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env55866 == env55867) = true)

theorem identity55867 : scanCanonicalize (H12AffineFastState.compose env55867 (packedSelected [0,1,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound55867 : packedSelected [0,1,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env55868 : List Nat := [2,4,8,16,32,16,128,173,512,41,163,149,53,148,185,182,49,143,140,184,149,12,181,166,25,17,143,48,48,42,128,132,172,33,148,677]

theorem envBound55868 : H12AffineFastState.Bounded env55868 := by
  intro p hp
  have h : env55868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55867_55868 : H12AffineEnvironment.transform 9 41 env55867 = env55868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env55867 == env55868) = true)

theorem identity55868 : scanCanonicalize (H12AffineFastState.compose env55868 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound55868 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env55869 : List Nat := [2,4,8,16,32,16,128,173,27,41,163,149,53,148,185,182,49,143,140,184,149,12,181,166,25,17,143,48,48,42,128,132,172,33,148,190]

theorem envBound55869 : H12AffineFastState.Bounded env55869 := by
  intro p hp
  have h : env55869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55868_55869 : H12AffineEnvironment.transform 8 27 env55868 = env55869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env55868 == env55869) = true)

def env55870 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143496,20496,492566,148669,148669,96266,74794,90259,172,204946,1212,135681]

theorem envBound55870 : H12AffineFastState.Bounded env55870 := by
  intro p hp
  have h : env55870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55858_55870 : H12AffineEnvironment.transform 5 17 env55858 = env55870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55858 == env55870) = true)

theorem identity55870 : scanCanonicalize (H12AffineFastState.compose env55870 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound55870 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env55871 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,41002,32808,20496,341174,62493,62493,96266,74794,90259,172,102450,1212,41633]

theorem envBound55871 : H12AffineFastState.Bounded env55871 := by
  intro p hp
  have h : env55871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55870_55871 : H12AffineEnvironment.transform 16 45216 env55870 = env55871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env55870 == env55871) = true)

theorem identity55871 : scanCanonicalize (H12AffineFastState.compose env55871 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound55871 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env55872 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4096,46141,46092,41002,32808,5293,341174,45216,45216,81079,74794,74798,172,102450,1212,41633]

theorem envBound55872 : H12AffineFastState.Bounded env55872 := by
  intro p hp
  have h : env55872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55871_55872 : H12AffineEnvironment.transform 13 1213 env55871 = env55872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env55871 == env55872) = true)

theorem identity55872 : scanCanonicalize (H12AffineFastState.compose env55872 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound55872 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55873 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9381,65536,5125,262144,4,9380,4096,4248,4265,1167,9357,5293,341174,5125,5125,81079,74794,74798,172,78999,1212,1540]

theorem envBound55873 : H12AffineFastState.Bounded env55873 := by
  intro p hp
  have h : env55873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55872_55873 : H12AffineEnvironment.transform 14 9381 env55872 = env55873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env55872 == env55873) = true)

theorem identity55873 : scanCanonicalize (H12AffineFastState.compose env55873 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound55873 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env55874 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9381,12347,5125,262144,4,9380,4096,4248,4265,1167,9357,5293,263309,5125,5125,3212,5137,5141,172,1196,1212,1540]

theorem envBound55874 : H12AffineFastState.Bounded env55874 := by
  intro p hp
  have h : env55874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55873_55874 : H12AffineEnvironment.transform 15 12347 env55873 = env55874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env55873 == env55874) = true)

theorem identity55874 : scanCanonicalize (H12AffineFastState.compose env55874 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound55874 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env55875 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1213,6186,3252,5125,262144,4,6187,4096,4248,4265,1167,6146,5293,263309,5125,5125,3212,5137,5141,172,1196,1212,1540]

theorem envBound55875 : H12AffineFastState.Bounded env55875 := by
  intro p hp
  have h : env55875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55874_55875 : H12AffineEnvironment.transform 12 7311 env55874 = env55875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env55874 == env55875) = true)

theorem identity55875 : scanCanonicalize (H12AffineFastState.compose env55875 (packedSelected [1,2,3,5,8,11,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound55875 : packedSelected [1,2,3,5,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env55876 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,4096,6658,560,6186,2617,4744,262144,4,6187,4096,4248,4265,514,6146,4640,262656,4744,4744,2561,4764,4760,172,545,561,137]

theorem envBound55876 : H12AffineFastState.Bounded env55876 := by
  intro p hp
  have h : env55876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55875_55876 : H12AffineEnvironment.transform 9 653 env55875 = env55876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env55875 == env55876) = true)

theorem identity55876 : scanCanonicalize (H12AffineFastState.compose env55876 (packedSelected [10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 4123) := by decide +kernel

theorem selectedBound55876 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env55877 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,4096,6658,560,6186,2617,4744,4123,4,6187,4096,4248,4265,514,6146,4640,4635,4744,4744,2561,4764,4760,172,545,561,137]

theorem envBound55877 : H12AffineFastState.Bounded env55877 := by
  intro p hp
  have h : env55877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55876_55877 : H12AffineEnvironment.transform 17 4123 env55876 = env55877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4123 env55876 == env55877) = true)

theorem identity55877 : scanCanonicalize (H12AffineFastState.compose env55877 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound55877 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55878 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,2194,656,560,184,2617,2586,2185,4,185,2194,2058,2107,514,144,2738,2697,2586,2586,2561,2574,2570,172,545,561,137]

theorem envBound55878 : H12AffineFastState.Bounded env55878 := by
  intro p hp
  have h : env55878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55877_55878 : H12AffineEnvironment.transform 11 2194 env55877 = env55878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env55877 == env55878) = true)

theorem identity55878 : scanCanonicalize (H12AffineFastState.compose env55878 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55878 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55879 : List Nat := [2,4,8,10,32,11,128,173,512,653,2048,2184,650,554,162,2595,2560,2185,4,163,2184,2058,2081,514,138,2728,2697,2560,2560,2561,2574,2570,172,545,555,137]

theorem envBound55879 : H12AffineFastState.Bounded env55879 := by
  intro p hp
  have h : env55879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55878_55879 : H12AffineEnvironment.transform 3 10 env55878 = env55879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55878 == env55879) = true)

theorem identity55879 : scanCanonicalize (H12AffineFastState.compose env55879 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound55879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55880 : List Nat := [2,4,8,10,32,11,128,173,512,653,163,43,650,554,162,640,675,42,4,163,43,169,130,514,138,523,554,675,675,674,685,681,172,545,555,137]

theorem envBound55880 : H12AffineFastState.Bounded env55880 := by
  intro p hp
  have h : env55880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55879_55880 : H12AffineEnvironment.transform 10 163 env55879 = env55880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env55879 == env55880) = true)

theorem identity55880 : scanCanonicalize (H12AffineFastState.compose env55880 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55880 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55881 : List Nat := [2,4,8,10,32,11,128,173,42,167,163,43,160,0,162,170,137,42,4,163,43,169,130,40,138,33,0,137,137,136,135,131,172,11,1,137]

theorem envBound55881 : H12AffineFastState.Bounded env55881 := by
  intro p hp
  have h : env55881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55880_55881 : H12AffineEnvironment.transform 8 42 env55880 = env55881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55880 == env55881) = true)

theorem identity55881 : scanCanonicalize (H12AffineFastState.compose env55881 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55882 : List Nat := [2,4,8,10,32,11,8,37,42,47,43,43,40,0,42,34,1,42,4,43,43,33,10,40,2,33,0,1,1,0,15,11,36,11,1,1]

theorem envBound55882 : H12AffineFastState.Bounded env55882 := by
  intro p hp
  have h : env55882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55881_55882 : H12AffineEnvironment.transform 6 8 env55881 = env55882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55881 == env55882) = true)

theorem identity55882 : scanCanonicalize (H12AffineFastState.compose env55882 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55883 : List Nat := [2,4,8,10,6,11,8,3,12,9,13,13,14,0,12,4,1,12,4,13,13,7,10,14,2,7,0,1,1,0,15,11,2,11,1,1]

theorem envBound55883 : H12AffineFastState.Bounded env55883 := by
  intro p hp
  have h : env55883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55882_55883 : H12AffineEnvironment.transform 4 6 env55882 = env55883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55882 == env55883) = true)

theorem identity55883 : scanCanonicalize (H12AffineFastState.compose env55883 (packedSelected [4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55883 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env55884 : List Nat := [2,4,4,6,6,7,4,3,0,5,1,1,2,0,0,4,1,0,4,1,1,7,6,2,2,7,0,1,1,0,3,7,2,7,1,1]

theorem envBound55884 : H12AffineFastState.Bounded env55884 := by
  intro p hp
  have h : env55884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55883_55884 : H12AffineEnvironment.transform 2 4 env55883 = env55884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55883 == env55884) = true)

theorem identity55884 : scanCanonicalize (H12AffineFastState.compose env55884 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55884 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55885 : List Nat := [2,0,0,2,2,3,0,3,0,1,1,1,2,0,0,0,1,0,0,1,1,3,2,2,2,3,0,1,1,0,3,3,2,3,1,1]

theorem envBound55885 : H12AffineFastState.Bounded env55885 := by
  intro p hp
  have h : env55885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55884_55885 : H12AffineEnvironment.transform 1 0 env55884 = env55885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55884 == env55885) = true)

theorem identity55885 : scanCanonicalize (H12AffineFastState.compose env55885 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55885 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55886 : List Nat := [0,0,0,0,0,1,0,1,0,1,1,1,0,0,0,0,1,0,0,1,1,1,0,0,0,1,0,1,1,0,1,1,0,1,1,1]

theorem envBound55886 : H12AffineFastState.Bounded env55886 := by
  intro p hp
  have h : env55886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55885_55886 : H12AffineEnvironment.transform 0 0 env55885 = env55886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55885 == env55886) = true)

def env55887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245633,148801,545088,96347,16876544,750911,257,17006916,1345,525824]

theorem envBound55887 : H12AffineFastState.Bounded env55887 := by
  intro p hp
  have h : env55887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55770_55887 : H12AffineEnvironment.transform 26 17245633 env55770 = env55887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env55770 == env55887) = true)

theorem identity55887 : scanCanonicalize (H12AffineFastState.compose env55887 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound55887 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717115,533641,672785,906490,148801,545088,96347,750907,750911,257,618623,1345,525824]

theorem envBound55888 : H12AffineFastState.Bounded env55888 := by
  intro p hp
  have h : env55888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55887_55888 : H12AffineEnvironment.transform 23 717115 env55887 = env55888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env55887 == env55888) = true)

def env55889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58683,143497,20497,508154,148801,148800,96347,90427,90431,257,222335,1345,135680]

theorem envBound55889 : H12AffineFastState.Bounded env55889 := by
  intro p hp
  have h : env55889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55888_55889 : H12AffineEnvironment.transform 18 136192 env55888 = env55889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env55888 == env55889) = true)

def env55890 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143497,20497,508154,148717,148716,96347,90263,90259,173,222335,1261,135680]

theorem envBound55890 : H12AffineFastState.Bounded env55890 := by
  intro p hp
  have h : env55890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55889_55890 : H12AffineEnvironment.transform 7 172 env55889 = env55890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55889 == env55890) = true)

def env55891 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143497,20497,508074,148669,148668,96267,90263,90259,173,222255,1213,135680]

theorem envBound55891 : H12AffineFastState.Bounded env55891 := by
  intro p hp
  have h : env55891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55890_55891 : H12AffineEnvironment.transform 5 16 env55890 = env55891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55890 == env55891) = true)

theorem identity55891 : scanCanonicalize (H12AffineFastState.compose env55891 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound55891 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55892 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61569,115855,58519,111638,20497,279605,114722,114723,96267,90263,90259,173,57520,1213,104095]

theorem envBound55892 : H12AffineFastState.Bounded env55892 := by
  intro p hp
  have h : env55892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55891_55892 : H12AffineEnvironment.transform 16 99487 env55891 = env55892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env55891 == env55892) = true)

theorem identity55892 : scanCanonicalize (H12AffineFastState.compose env55892 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound55892 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env55893 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,65536,73787,262144,78907,9381,4096,21541,90155,16435,69810,20497,279605,91270,91271,96267,90263,90259,173,17428,1213,78395]

theorem envBound55893 : H12AffineFastState.Bounded env55893 := by
  intro p hp
  have h : env55893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55892_55893 : H12AffineEnvironment.transform 14 9380 env55892 = env55893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env55892 == env55893) = true)

theorem identity55893 : scanCanonicalize (H12AffineFastState.compose env55893 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound55893 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env55894 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,12347,4096,262144,1024,9381,4096,21541,20496,16435,8329,20497,279605,21693,21692,18480,20652,20648,173,17428,1213,512]

theorem envBound55894 : H12AffineFastState.Bounded env55894 := by
  intro p hp
  have h : env55894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55893_55894 : H12AffineEnvironment.transform 15 12347 env55893 = env55894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env55893 == env55894) = true)

theorem identity55894 : scanCanonicalize (H12AffineFastState.compose env55894 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound55894 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55895 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,12347,4096,262144,1024,9381,4096,4249,5292,1167,8329,5293,262281,4097,4096,3212,5136,5140,173,168,1213,512]

theorem envBound55895 : H12AffineFastState.Bounded env55895 := by
  intro p hp
  have h : env55895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55894_55895 : H12AffineEnvironment.transform 13 1212 env55894 = env55895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env55894 == env55895) = true)

theorem identity55895 : scanCanonicalize (H12AffineFastState.compose env55895 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound55895 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55896 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4649,1212,5773,530,4096,262144,1024,5772,4096,4249,5292,1167,4768,5293,262281,4097,4096,3212,5136,5140,173,168,1213,512]

theorem envBound55896 : H12AffineFastState.Bounded env55896 := by
  intro p hp
  have h : env55896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55895_55896 : H12AffineEnvironment.transform 12 4649 env55895 = env55896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env55895 == env55896) = true)

theorem identity55896 : scanCanonicalize (H12AffineFastState.compose env55896 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound55896 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env55897 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1212,1685,1212,561,530,1212,262144,1024,560,1212,1061,16,1167,1564,17,262281,1213,1212,3212,172,168,173,168,1213,512]

theorem envBound55897 : H12AffineFastState.Bounded env55897 := by
  intro p hp
  have h : env55897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55896_55897 : H12AffineEnvironment.transform 11 1212 env55896 = env55897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env55896 == env55897) = true)

theorem identity55897 : scanCanonicalize (H12AffineFastState.compose env55897 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound55897 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55898 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1212,1685,1212,561,530,1212,1582,1024,560,1212,1061,16,1167,1564,17,1703,1213,1212,3212,172,168,173,168,1213,512]

theorem envBound55898 : H12AffineFastState.Bounded env55898 := by
  intro p hp
  have h : env55898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55897_55898 : H12AffineEnvironment.transform 17 1582 env55897 = env55898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env55897 == env55898) = true)

def env55899 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143497,20497,508075,148668,148669,96266,90263,90259,173,222254,1212,135680]

theorem envBound55899 : H12AffineFastState.Bounded env55899 := by
  intro p hp
  have h : env55899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55890_55899 : H12AffineEnvironment.transform 5 17 env55890 = env55899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55890 == env55899) = true)

theorem identity55899 : scanCanonicalize (H12AffineFastState.compose env55899 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound55899 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55900 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61568,147473,58519,143497,20497,60445,148668,148669,96266,90263,90259,173,222254,1212,135680]

theorem envBound55900 : H12AffineFastState.Bounded env55900 := by
  intro p hp
  have h : env55900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55899_55900 : H12AffineEnvironment.transform 17 208054 env55899 = env55900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env55899 == env55900) = true)

theorem identity55900 : scanCanonicalize (H12AffineFastState.compose env55900 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound55900 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env55901 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4096,61568,147473,58519,143497,20497,60445,148668,148669,43048,45237,45233,173,177164,1212,135680]

theorem envBound55901 : H12AffineFastState.Bounded env55901 := by
  intro p hp
  have h : env55901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55900_55901 : H12AffineEnvironment.transform 15 53282 env55900 = env55901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env55900 == env55901) = true)

theorem identity55901 : scanCanonicalize (H12AffineFastState.compose env55901 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound55901 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55902 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4096,61568,5293,58519,25653,20497,60445,4096,4097,43048,45237,45233,173,57520,1212,18108]

theorem envBound55902 : H12AffineFastState.Bounded env55902 := by
  intro p hp
  have h : env55902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55901_55902 : H12AffineEnvironment.transform 16 21692 env55901 = env55902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env55901 == env55902) = true)

theorem identity55902 : scanCanonicalize (H12AffineFastState.compose env55902 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55902 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env55903 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,12346,21692,18480,16572,24601,4096,4248,5293,1167,25653,20497,3077,4096,4097,18480,20653,20649,173,168,1212,18108]

theorem envBound55903 : H12AffineFastState.Bounded env55903 := by
  intro p hp
  have h : env55903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55902_55903 : H12AffineEnvironment.transform 14 24600 env55902 = env55903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55902 == env55903) = true)

theorem identity55903 : scanCanonicalize (H12AffineFastState.compose env55903 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13988) := by decide +kernel

theorem selectedBound55903 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env55904 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,13988,5820,12346,8728,16020,13848,5821,4096,4248,5293,1167,4753,9909,3077,4096,4097,16020,9737,9741,173,168,1212,12312]

theorem envBound55904 : H12AffineFastState.Bounded env55904 := by
  intro p hp
  have h : env55904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55903_55904 : H12AffineEnvironment.transform 13 13988 env55903 = env55904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13988 env55903 == env55904) = true)

theorem identity55904 : scanCanonicalize (H12AffineFastState.compose env55904 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 7823) := by decide +kernel

theorem selectedBound55904 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55905 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7823,2091,5820,3765,7319,27,2199,5821,4096,4248,5293,1167,4753,6202,3077,4096,4097,27,6278,6274,173,168,1212,3735]

theorem envBound55905 : H12AffineFastState.Bounded env55905 := by
  intro p hp
  have h : env55905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55904_55905 : H12AffineEnvironment.transform 12 7823 env55904 = env55905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7823 env55904 == env55905) = true)

theorem identity55905 : scanCanonicalize (H12AffineFastState.compose env55905 (packedSelected [0,2,3,4,5,7,9,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55905 : packedSelected [0,2,3,4,5,7,9,15,16] rootPS < 2^1333 := by decide +kernel

def env55906 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,4096,6842,2091,4745,2688,6306,27,2199,4744,4096,4248,4248,186,4753,6202,2096,4096,4097,27,6278,6274,173,168,137,2722]

theorem envBound55906 : H12AffineFastState.Bounded env55906 := by
  intro p hp
  have h : env55906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55905_55906 : H12AffineEnvironment.transform 9 53 env55905 = env55906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55905 == env55906) = true)

theorem identity55906 : scanCanonicalize (H12AffineFastState.compose env55906 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound55906 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55907 : List Nat := [2,4,8,16,32,17,128,172,512,53,696,4096,4098,659,4745,56,4634,27,559,4744,4096,4248,4248,186,4753,4738,648,4096,4097,27,4670,4666,173,168,137,26]

theorem envBound55907 : H12AffineFastState.Bounded env55907 := by
  intro p hp
  have h : env55907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55906_55907 : H12AffineEnvironment.transform 10 696 env55906 = env55907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env55906 == env55907) = true)

theorem identity55907 : scanCanonicalize (H12AffineFastState.compose env55907 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55907 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55908 : List Nat := [2,4,8,16,11,17,128,135,512,30,659,4096,4098,659,4745,19,4634,27,516,4744,4096,4248,4248,145,4753,4738,648,4096,4097,27,4629,4625,134,131,137,26]

theorem envBound55908 : H12AffineFastState.Bounded env55908 := by
  intro p hp
  have h : env55908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55907_55908 : H12AffineEnvironment.transform 4 11 env55907 = env55908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55907 == env55908) = true)

theorem identity55908 : scanCanonicalize (H12AffineFastState.compose env55908 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55908 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env55909 : List Nat := [2,4,8,16,11,17,9,14,512,30,538,4096,4098,538,4608,19,4634,27,516,4609,4096,4113,4113,24,4632,4619,513,4096,4097,27,4629,4625,15,10,0,26]

theorem envBound55909 : H12AffineFastState.Bounded env55909 := by
  intro p hp
  have h : env55909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55908_55909 : H12AffineEnvironment.transform 6 9 env55908 = env55909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55908 == env55909) = true)

theorem identity55909 : scanCanonicalize (H12AffineFastState.compose env55909 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound55909 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env55910 : List Nat := [2,4,8,16,11,17,9,14,512,30,538,513,515,538,1,19,27,27,516,0,513,528,528,24,25,10,513,513,512,27,20,16,15,10,0,26]

theorem envBound55910 : H12AffineFastState.Bounded env55910 := by
  intro p hp
  have h : env55910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55909_55910 : H12AffineEnvironment.transform 11 513 env55909 = env55910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env55909 == env55910) = true)

def env55911 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143497,20497,508154,148716,148717,96347,90262,90258,172,222335,1260,135680]

theorem envBound55911 : H12AffineFastState.Bounded env55911 := by
  intro p hp
  have h : env55911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55889_55911 : H12AffineEnvironment.transform 7 173 env55889 = env55911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55889 == env55911) = true)

def env55912 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143497,20497,508074,148668,148669,96267,90262,90258,172,222255,1212,135680]

theorem envBound55912 : H12AffineFastState.Bounded env55912 := by
  intro p hp
  have h : env55912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55911_55912 : H12AffineEnvironment.transform 5 16 env55911 = env55912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55911 == env55912) = true)

theorem identity55912 : scanCanonicalize (H12AffineFastState.compose env55912 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound55912 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55913 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,58518,32808,20497,356363,62493,62492,96267,90262,90258,172,119950,1212,41633]

theorem envBound55913 : H12AffineFastState.Bounded env55913 := by
  intro p hp
  have h : env55913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55912_55913 : H12AffineEnvironment.transform 16 45217 env55912 = env55913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env55912 == env55913) = true)

theorem identity55913 : scanCanonicalize (H12AffineFastState.compose env55913 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound55913 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55914 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4096,61569,61617,58518,32808,20497,96387,62493,62492,96267,90262,90258,172,119950,1212,41633]

theorem envBound55914 : H12AffineFastState.Bounded env55914 := by
  intro p hp
  have h : env55914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55913_55914 : H12AffineEnvironment.transform 17 2184 env55913 = env55914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env55913 == env55914) = true)

theorem identity55914 : scanCanonicalize (H12AffineFastState.compose env55914 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound55914 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55915 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,29831,45217,2184,42145,32769,4096,61569,61617,58518,32808,20497,3076,62493,62492,3212,5137,5141,172,40969,1212,41633]

theorem envBound55915 : H12AffineFastState.Bounded env55915 := by
  intro p hp
  have h : env55915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55914_55915 : H12AffineEnvironment.transform 15 29831 env55914 = env55915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env55914 == env55915) = true)

theorem identity55915 : scanCanonicalize (H12AffineFastState.compose env55915 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound55915 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env55916 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,13374,45217,2184,42145,32769,4096,45112,45064,42031,32808,4264,3076,46244,46245,3212,5137,5141,172,40969,1212,41633]

theorem envBound55916 : H12AffineFastState.Bounded env55916 := by
  intro p hp
  have h : env55916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55915_55916 : H12AffineEnvironment.transform 13 185 env55915 = env55916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env55915 == env55916) = true)

theorem identity55916 : scanCanonicalize (H12AffineFastState.compose env55916 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 2745) := by decide +kernel

theorem selectedBound55916 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env55917 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,2745,13374,14872,2184,11800,2744,4096,14977,15025,11926,2705,4264,3076,15901,15900,3212,5137,5141,172,10928,1212,10264]

theorem envBound55917 : H12AffineFastState.Bounded env55917 := by
  intro p hp
  have h : env55917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55916_55917 : H12AffineEnvironment.transform 14 2745 env55916 = env55917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2745 env55916 == env55917) = true)

theorem identity55917 : scanCanonicalize (H12AffineFastState.compose env55917 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 4256) := by decide +kernel

theorem selectedBound55917 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55918 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4256,185,2745,1182,2744,2184,7864,2744,4096,2593,2577,7734,2705,4264,3076,3773,3772,3212,5137,5141,172,6672,1212,6328]

theorem envBound55918 : H12AffineFastState.Bounded env55918 := by
  intro p hp
  have h : env55918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55917_55918 : H12AffineEnvironment.transform 12 4256 env55917 = env55918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4256 env55917 == env55918) = true)

theorem identity55918 : scanCanonicalize (H12AffineFastState.compose env55918 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound55918 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env55919 : List Nat := [2,4,8,16,32,16,128,173,162,1024,2048,4096,4256,185,2075,1182,2074,2184,7194,2074,4096,2179,2227,7316,2099,4264,3076,3103,3102,3212,5137,5141,172,6322,1212,6328]

theorem envBound55919 : H12AffineFastState.Bounded env55919 := by
  intro p hp
  have h : env55919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55918_55919 : H12AffineEnvironment.transform 8 162 env55918 = env55919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env55918 == env55919) = true)

theorem identity55919 : scanCanonicalize (H12AffineFastState.compose env55919 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55919 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env55920 : List Nat := [2,4,8,16,32,16,8,37,42,1024,2048,4096,4136,49,2075,1046,2074,2048,7194,2074,4096,2059,2107,7196,2099,4128,3076,3103,3102,3076,5137,5141,36,6202,1076,6192]

theorem envBound55920 : H12AffineFastState.Bounded env55920 := by
  intro p hp
  have h : env55920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55919_55920 : H12AffineEnvironment.transform 6 8 env55919 = env55920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55919 == env55920) = true)

theorem identity55920 : scanCanonicalize (H12AffineFastState.compose env55920 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 3125) := by decide +kernel

theorem selectedBound55920 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env55921 : List Nat := [2,4,8,16,32,16,8,37,42,1024,2048,3125,3101,49,2075,1046,2074,2048,47,2074,3125,2059,2107,41,2099,3093,3076,3103,3102,3076,2084,2080,36,1039,1076,1029]

theorem envBound55921 : H12AffineFastState.Bounded env55921 := by
  intro p hp
  have h : env55921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55920_55921 : H12AffineEnvironment.transform 11 3125 env55920 = env55921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3125 env55920 == env55921) = true)

theorem identity55921 : scanCanonicalize (H12AffineFastState.compose env55921 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound55921 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env55922 : List Nat := [2,4,8,16,32,16,8,37,42,4,2048,2097,2073,49,2075,18,2074,2048,47,2074,2097,2059,2107,41,2099,2065,2048,2075,2074,2048,2084,2080,36,11,48,1]

theorem envBound55922 : H12AffineFastState.Bounded env55922 := by
  intro p hp
  have h : env55922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55921_55922 : H12AffineEnvironment.transform 9 4 env55921 = env55922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env55921 == env55922) = true)

theorem identity55922 : scanCanonicalize (H12AffineFastState.compose env55922 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55922 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55923 : List Nat := [2,4,8,11,32,11,8,37,42,4,2048,2090,2050,42,2048,9,2049,2048,47,2049,2090,2059,2080,41,2088,2058,2048,2048,2049,2048,2084,2080,36,11,43,1]

theorem envBound55923 : H12AffineFastState.Bounded env55923 := by
  intro p hp
  have h : env55923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55922_55923 : H12AffineEnvironment.transform 3 11 env55922 = env55923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55922 == env55923) = true)

theorem identity55923 : scanCanonicalize (H12AffineFastState.compose env55923 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55924 : List Nat := [2,4,8,11,11,11,8,14,1,4,2048,2049,2050,1,2048,9,2049,2048,4,2049,2049,2059,2059,2,2051,2058,2048,2048,2049,2048,2063,2059,15,11,0,1]

theorem envBound55924 : H12AffineFastState.Bounded env55924 := by
  intro p hp
  have h : env55924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55923_55924 : H12AffineEnvironment.transform 4 11 env55923 = env55924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55923 == env55924) = true)

theorem identity55924 : scanCanonicalize (H12AffineFastState.compose env55924 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55925 : List Nat := [2,4,5,6,6,6,5,3,1,4,2048,2049,2050,1,2048,4,2049,2048,4,2049,2049,2054,2054,2,2051,2055,2048,2048,2049,2048,2050,2054,2,6,0,1]

theorem envBound55925 : H12AffineFastState.Bounded env55925 := by
  intro p hp
  have h : env55925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55924_55925 : H12AffineEnvironment.transform 2 5 env55924 = env55925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55924 == env55925) = true)

theorem identity55925 : scanCanonicalize (H12AffineFastState.compose env55925 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55926 : List Nat := [2,4,5,6,6,6,5,3,1,4,1,0,3,1,1,4,0,1,4,0,0,7,7,2,2,6,1,1,0,1,3,7,2,6,0,1]

theorem envBound55926 : H12AffineFastState.Bounded env55926 := by
  intro p hp
  have h : env55926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55925_55926 : H12AffineEnvironment.transform 10 1 env55925 = env55926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55925 == env55926) = true)

def env55927 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143497,20497,508075,148669,148668,96266,90262,90258,172,222254,1213,135680]

theorem envBound55927 : H12AffineFastState.Bounded env55927 := by
  intro p hp
  have h : env55927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55911_55927 : H12AffineEnvironment.transform 5 17 env55911 = env55927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55911 == env55927) = true)

theorem identity55927 : scanCanonicalize (H12AffineFastState.compose env55927 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound55927 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55928 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,58518,143497,20497,120866,148669,148668,96266,90262,90258,172,222254,1213,135680]

theorem envBound55928 : H12AffineFastState.Bounded env55928 := by
  intro p hp
  have h : env55928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55927_55928 : H12AffineEnvironment.transform 17 137353 env55927 = env55928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env55927 == env55928) = true)

theorem identity55928 : scanCanonicalize (H12AffineFastState.compose env55928 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound55928 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env55929 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4096,61568,46092,58518,50324,20497,120866,45216,45217,96266,90262,90258,172,102451,1213,58909]

theorem envBound55929 : H12AffineFastState.Bounded env55929 := by
  intro p hp
  have h : env55929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55928_55929 : H12AffineEnvironment.transform 16 62493 env55928 = env55929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env55928 == env55929) = true)

theorem identity55929 : scanCanonicalize (H12AffineFastState.compose env55929 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55929 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55930 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24600,65536,5125,3212,5,24601,4096,4248,21524,1166,9356,20497,79930,20664,20665,96266,90262,90258,172,94251,1213,1541]

theorem envBound55930 : H12AffineFastState.Bounded env55930 := by
  intro p hp
  have h : env55930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55929_55930 : H12AffineEnvironment.transform 14 24600 env55929 = env55930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55929 == env55930) = true)

theorem identity55930 : scanCanonicalize (H12AffineFastState.compose env55930 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 6800) := by decide +kernel

theorem selectedBound55930 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env55931 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6800,16384,23176,65536,5125,3212,5,23177,4096,4248,21524,1166,7708,20497,66218,20664,20665,82586,88582,88578,172,84667,1213,1541]

theorem envBound55931 : H12AffineFastState.Bounded env55931 := by
  intro p hp
  have h : env55931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55930_55931 : H12AffineEnvironment.transform 12 6800 env55930 = env55931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6800 env55930 == env55931) = true)

theorem identity55931 : scanCanonicalize (H12AffineFastState.compose env55931 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 2731) := by decide +kernel

theorem selectedBound55931 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env55932 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6800,16384,23176,2731,5125,3212,5,23177,4096,4248,21524,1166,7708,20497,2049,20664,20665,18481,20653,20649,172,16400,1213,1541]

theorem envBound55932 : H12AffineFastState.Bounded env55932 := by
  intro p hp
  have h : env55932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55931_55932 : H12AffineEnvironment.transform 15 2731 env55931 = env55932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2731 env55931 == env55932) = true)

theorem identity55932 : scanCanonicalize (H12AffineFastState.compose env55932 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound55932 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env55933 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1724,3116,16384,19508,2731,697,3212,5,19509,1724,1572,17064,1166,2208,18093,2049,17924,17925,18481,17937,17941,172,16400,1213,1541]

theorem envBound55933 : H12AffineFastState.Bounded env55933 := by
  intro p hp
  have h : env55933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55932_55933 : H12AffineEnvironment.transform 11 1724 env55932 = env55933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env55932 == env55933) = true)

theorem identity55933 : scanCanonicalize (H12AffineFastState.compose env55933 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2194) := by decide +kernel

theorem selectedBound55933 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env55934 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1724,3116,2194,1190,2731,697,3212,5,1191,1724,1572,2618,1166,2208,3647,2049,3734,3735,163,3715,3719,172,2178,1213,1541]

theorem envBound55934 : H12AffineFastState.Bounded env55934 := by
  intro p hp
  have h : env55934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55933_55934 : H12AffineEnvironment.transform 13 2194 env55933 = env55934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2194 env55933 == env55934) = true)

theorem identity55934 : scanCanonicalize (H12AffineFastState.compose env55934 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound55934 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env55935 : List Nat := [2,4,8,16,32,17,128,173,512,1024,561,1724,1565,675,1190,154,697,1725,5,1191,1724,1572,11,1166,657,1038,560,1191,1190,163,1202,1206,172,691,1213,1541]

theorem envBound55935 : H12AffineFastState.Bounded env55935 := by
  intro p hp
  have h : env55935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55934_55935 : H12AffineEnvironment.transform 10 561 env55934 = env55935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env55934 == env55935) = true)

theorem identity55935 : scanCanonicalize (H12AffineFastState.compose env55935 (packedSelected [2,4,5,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55935 : packedSelected [2,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env55936 : List Nat := [2,4,8,16,32,17,128,173,1,1024,48,1213,1052,162,1190,154,184,1212,5,1191,1213,1061,11,1166,144,1038,49,1191,1190,163,1202,1206,172,178,1213,1028]

theorem envBound55936 : H12AffineFastState.Bounded env55936 := by
  intro p hp
  have h : env55936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55935_55936 : H12AffineEnvironment.transform 8 1 env55935 = env55936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55935 == env55936) = true)

def env55937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58682,143496,20496,508155,148801,148801,96347,90426,90430,257,222334,1345,135681]

theorem envBound55937 : H12AffineFastState.Bounded env55937 := by
  intro p hp
  have h : env55937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55888_55937 : H12AffineEnvironment.transform 18 136193 env55888 = env55937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env55888 == env55937) = true)

def env55938 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143496,20496,508155,148717,148717,96347,90262,90258,173,222334,1261,135681]

theorem envBound55938 : H12AffineFastState.Bounded env55938 := by
  intro p hp
  have h : env55938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55937_55938 : H12AffineEnvironment.transform 7 172 env55937 = env55938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55937 == env55938) = true)

def env55939 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143496,20496,508075,148669,148669,96267,90262,90258,173,222254,1213,135681]

theorem envBound55939 : H12AffineFastState.Bounded env55939 := by
  intro p hp
  have h : env55939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55938_55939 : H12AffineEnvironment.transform 5 16 env55938 = env55939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55938 == env55939) = true)

theorem identity55939 : scanCanonicalize (H12AffineFastState.compose env55939 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound55939 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55940 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61569,147472,58518,143496,20496,60444,148669,148669,96267,90262,90258,173,222254,1213,135681]

theorem envBound55940 : H12AffineFastState.Bounded env55940 := by
  intro p hp
  have h : env55940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55939_55940 : H12AffineEnvironment.transform 17 208055 env55939 = env55940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env55939 == env55940) = true)

theorem identity55940 : scanCanonicalize (H12AffineFastState.compose env55940 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound55940 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env55941 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4096,61569,147472,58518,143496,20496,60444,148669,148669,43048,45237,45233,173,177165,1213,135681]

theorem envBound55941 : H12AffineFastState.Bounded env55941 := by
  intro p hp
  have h : env55941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55940_55941 : H12AffineEnvironment.transform 15 53283 env55940 = env55941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env55940 == env55941) = true)

theorem identity55941 : scanCanonicalize (H12AffineFastState.compose env55941 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound55941 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55942 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4096,61569,5292,58518,25652,20496,60444,4097,4097,43048,45237,45233,173,57521,1213,18109]

theorem envBound55942 : H12AffineFastState.Bounded env55942 := by
  intro p hp
  have h : env55942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55941_55942 : H12AffineEnvironment.transform 16 21692 env55941 = env55942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env55941 == env55942) = true)

theorem identity55942 : scanCanonicalize (H12AffineFastState.compose env55942 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55942 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env55943 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,12347,21692,18480,16573,24601,4096,4249,5292,1166,25652,20496,3076,4097,4097,18480,20653,20649,173,169,1213,18109]

theorem envBound55943 : H12AffineFastState.Bounded env55943 := by
  intro p hp
  have h : env55943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55942_55943 : H12AffineEnvironment.transform 14 24600 env55942 = env55943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55942 == env55943) = true)

theorem identity55943 : scanCanonicalize (H12AffineFastState.compose env55943 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 12961) := by decide +kernel

theorem selectedBound55943 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env55944 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,12961,4793,12347,9757,14993,12828,4792,4096,4249,5292,1166,5781,8881,3076,4097,4097,14993,8716,8712,173,169,1213,13340]

theorem envBound55944 : H12AffineFastState.Bounded env55944 := by
  intro p hp
  have h : env55944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55943_55944 : H12AffineEnvironment.transform 13 12961 env55943 = env55944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12961 env55943 == env55944) = true)

theorem identity55944 : scanCanonicalize (H12AffineFastState.compose env55944 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound55944 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env55945 : List Nat := [2,4,8,16,32,16,128,172,512,1024,147,4096,8192,12961,4793,12347,9757,12802,12828,4792,4096,4249,5292,1166,5781,8881,1175,4097,4097,12802,8716,8712,173,169,1213,13340]

theorem envBound55945 : H12AffineFastState.Bounded env55945 := by
  intro p hp
  have h : env55945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55944_55945 : H12AffineEnvironment.transform 10 147 env55944 = env55945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env55944 == env55945) = true)

theorem identity55945 : scanCanonicalize (H12AffineFastState.compose env55945 (packedSelected [0,2,3,4,5,7,9,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55945 : packedSelected [0,2,3,4,5,7,9,15,16] rootPS < 2^1333 := by decide +kernel

def env55946 : List Nat := [2,4,8,16,16,16,128,156,512,1024,147,4096,8192,12945,4745,12299,9757,12802,12828,4744,4096,4249,5276,1166,5781,8833,1175,4097,4097,12802,8716,8712,157,153,1165,13340]

theorem envBound55946 : H12AffineFastState.Bounded env55946 := by
  intro p hp
  have h : env55946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55945_55946 : H12AffineEnvironment.transform 4 16 env55945 = env55946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55945 == env55946) = true)

theorem identity55946 : scanCanonicalize (H12AffineFastState.compose env55946 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound55946 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55947 : List Nat := [2,4,8,16,16,16,128,156,512,543,147,4096,8192,12945,4745,12299,8194,12802,12828,4744,4096,4249,4739,657,4234,8833,648,4097,4097,12802,8716,8712,157,153,658,12803]

theorem envBound55947 : H12AffineFastState.Bounded env55947 := by
  intro p hp
  have h : env55947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55946_55947 : H12AffineEnvironment.transform 9 543 env55946 = env55947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env55946 == env55947) = true)

theorem identity55947 : scanCanonicalize (H12AffineFastState.compose env55947 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55947 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55948 : List Nat := [2,4,8,16,16,16,128,156,1,30,147,4096,8192,12432,4232,12299,8194,12291,12317,4233,4096,4249,4226,144,4234,8320,137,4097,4097,12291,8205,8201,157,153,147,12290]

theorem envBound55948 : H12AffineFastState.Bounded env55948 := by
  intro p hp
  have h : env55948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55947_55948 : H12AffineEnvironment.transform 8 1 env55947 = env55948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55947 == env55948) = true)

theorem identity55948 : scanCanonicalize (H12AffineFastState.compose env55948 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound55948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55949 : List Nat := [2,4,8,16,16,16,18,14,1,30,1,4096,8192,12290,4122,12299,8194,12291,12317,4123,4096,4107,4112,2,4120,8210,27,4097,4097,12291,8205,8201,15,11,1,12290]

theorem envBound55949 : H12AffineFastState.Bounded env55949 := by
  intro p hp
  have h : env55949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55948_55949 : H12AffineEnvironment.transform 6 18 env55948 = env55949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env55948 == env55949) = true)

theorem identity55949 : scanCanonicalize (H12AffineFastState.compose env55949 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound55949 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env55950 : List Nat := [2,4,8,16,16,16,18,14,1,30,1,4096,25,4123,4122,4114,27,4122,4100,4123,4096,4107,4112,2,4120,11,27,4097,4097,4122,20,16,15,11,1,4123]

theorem envBound55950 : H12AffineFastState.Bounded env55950 := by
  intro p hp
  have h : env55950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55949_55950 : H12AffineEnvironment.transform 12 25 env55949 = env55950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env55949 == env55950) = true)

theorem identity55950 : scanCanonicalize (H12AffineFastState.compose env55950 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound55950 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55951 : List Nat := [2,4,8,16,16,16,18,14,1,30,1,27,25,0,1,9,27,1,31,0,27,16,11,2,3,11,27,26,26,1,20,16,15,11,1,0]

theorem envBound55951 : H12AffineFastState.Bounded env55951 := by
  intro p hp
  have h : env55951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55950_55951 : H12AffineEnvironment.transform 11 27 env55950 = env55951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env55950 == env55951) = true)

theorem identity55951 : scanCanonicalize (H12AffineFastState.compose env55951 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound55951 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55952 : List Nat := [2,4,8,3,3,3,1,14,1,13,1,8,10,0,1,9,8,1,12,0,8,3,11,2,3,11,8,9,9,1,7,3,15,11,1,0]

theorem envBound55952 : H12AffineFastState.Bounded env55952 := by
  intro p hp
  have h : env55952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55951_55952 : H12AffineEnvironment.transform 3 3 env55951 = env55952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env55951 == env55952) = true)

theorem identity55952 : scanCanonicalize (H12AffineFastState.compose env55952 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound55952 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env55953 : List Nat := [2,4,1,3,3,3,1,7,1,4,1,1,3,0,1,0,1,1,5,0,1,3,2,2,3,2,1,0,0,1,7,3,6,2,1,0]

theorem envBound55953 : H12AffineFastState.Bounded env55953 := by
  intro p hp
  have h : env55953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55952_55953 : H12AffineEnvironment.transform 2 1 env55952 = env55953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env55952 == env55953) = true)

theorem identity55953 : scanCanonicalize (H12AffineFastState.compose env55953 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55954 : List Nat := [2,1,1,3,3,3,1,2,1,1,1,1,3,0,1,0,1,1,0,0,1,3,2,2,3,2,1,0,0,1,2,3,3,2,1,0]

theorem envBound55954 : H12AffineFastState.Bounded env55954 := by
  intro p hp
  have h : env55954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55953_55954 : H12AffineEnvironment.transform 1 1 env55953 = env55954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55953 == env55954) = true)

theorem identity55954 : scanCanonicalize (H12AffineFastState.compose env55954 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55954 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55955 : List Nat := [0,1,1,1,1,1,1,0,1,1,1,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,1,1,0,1,0]

theorem envBound55955 : H12AffineFastState.Bounded env55955 := by
  intro p hp
  have h : env55955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55954_55955 : H12AffineEnvironment.transform 0 0 env55954 = env55955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55954 == env55955) = true)

def env55956 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143496,20496,508074,148668,148668,96266,90262,90258,173,222255,1212,135681]

theorem envBound55956 : H12AffineFastState.Bounded env55956 := by
  intro p hp
  have h : env55956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55938_55956 : H12AffineEnvironment.transform 5 17 env55938 = env55956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55938 == env55956) = true)

theorem identity55956 : scanCanonicalize (H12AffineFastState.compose env55956 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound55956 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55957 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61568,115855,58518,111638,20496,279604,114722,114722,96266,90262,90258,173,57521,1212,104095]

theorem envBound55957 : H12AffineFastState.Bounded env55957 := by
  intro p hp
  have h : env55957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55956_55957 : H12AffineEnvironment.transform 16 99486 env55956 = env55957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env55956 == env55957) = true)

theorem identity55957 : scanCanonicalize (H12AffineFastState.compose env55957 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound55957 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env55958 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,65536,73787,262144,78906,9380,4096,21541,90154,16435,69811,20496,279604,91271,91271,96266,90262,90258,173,17428,1212,78394]

theorem envBound55958 : H12AffineFastState.Bounded env55958 := by
  intro p hp
  have h : env55958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55957_55958 : H12AffineEnvironment.transform 14 9381 env55957 = env55958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env55957 == env55958) = true)

theorem identity55958 : scanCanonicalize (H12AffineFastState.compose env55958 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound55958 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env55959 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,12346,4097,262144,1024,9380,4096,21541,20496,16435,8329,20496,279604,21693,21693,18480,20652,20648,173,17428,1212,512]

theorem envBound55959 : H12AffineFastState.Bounded env55959 := by
  intro p hp
  have h : env55959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55958_55959 : H12AffineEnvironment.transform 15 12346 env55958 = env55959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env55958 == env55959) = true)

theorem identity55959 : scanCanonicalize (H12AffineFastState.compose env55959 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound55959 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55960 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,12346,4097,262144,1024,9380,4096,4248,5293,1166,8329,5293,262281,4096,4096,3213,5137,5141,173,169,1212,512]

theorem envBound55960 : H12AffineFastState.Bounded env55960 := by
  intro p hp
  have h : env55960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55959_55960 : H12AffineEnvironment.transform 13 1213 env55959 = env55960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env55959 == env55960) = true)

theorem identity55960 : scanCanonicalize (H12AffineFastState.compose env55960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound55960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55961 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5676,1213,4745,1558,4097,262144,1024,4744,4096,4248,5293,1166,5797,5293,262281,4096,4096,3213,5137,5141,173,169,1212,512]

theorem envBound55961 : H12AffineFastState.Bounded env55961 := by
  intro p hp
  have h : env55961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55960_55961 : H12AffineEnvironment.transform 12 5676 env55960 = env55961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env55960 == env55961) = true)

theorem identity55961 : scanCanonicalize (H12AffineFastState.compose env55961 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound55961 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env55962 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1213,561,1558,185,262144,1024,560,184,32,1045,1166,1565,1045,262281,184,184,3213,1193,1197,173,169,1212,512]

theorem envBound55962 : H12AffineFastState.Bounded env55962 := by
  intro p hp
  have h : env55962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55961_55962 : H12AffineEnvironment.transform 11 184 env55961 = env55962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env55961 == env55962) = true)

theorem identity55962 : scanCanonicalize (H12AffineFastState.compose env55962 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound55962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55963 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1213,561,1558,185,554,1024,560,184,32,1045,1166,1565,1045,675,184,184,3213,1193,1197,173,169,1212,512]

theorem envBound55963 : H12AffineFastState.Bounded env55963 := by
  intro p hp
  have h : env55963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55962_55963 : H12AffineEnvironment.transform 17 554 env55962 = env55963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env55962 == env55963) = true)

theorem identity55963 : scanCanonicalize (H12AffineFastState.compose env55963 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound55963 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env55964 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,656,185,561,530,185,554,4,560,184,32,17,138,537,17,675,184,184,2185,173,169,173,169,184,512]

theorem envBound55964 : H12AffineFastState.Bounded env55964 := by
  intro p hp
  have h : env55964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55963_55964 : H12AffineEnvironment.transform 9 4 env55963 = env55964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env55963 == env55964) = true)

theorem identity55964 : scanCanonicalize (H12AffineFastState.compose env55964 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound55964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55965 : List Nat := [2,4,8,16,32,17,128,172,512,4,512,184,656,185,561,530,185,554,4,560,184,32,17,138,537,17,675,184,184,649,173,169,173,169,184,512]

theorem envBound55965 : H12AffineFastState.Bounded env55965 := by
  intro p hp
  have h : env55965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55964_55965 : H12AffineEnvironment.transform 10 512 env55964 = env55965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env55964 == env55965) = true)

theorem identity55965 : scanCanonicalize (H12AffineFastState.compose env55965 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound55965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55966 : List Nat := [2,4,8,16,32,17,57,21,512,4,512,1,553,0,561,530,0,554,4,560,1,32,17,51,537,17,538,1,1,560,20,16,20,16,1,512]

theorem envBound55966 : H12AffineFastState.Bounded env55966 := by
  intro p hp
  have h : env55966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55965_55966 : H12AffineEnvironment.transform 6 57 env55965 = env55966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env55965 == env55966) = true)

theorem identity55966 : scanCanonicalize (H12AffineFastState.compose env55966 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound55966 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55967 : List Nat := [2,4,8,16,32,17,57,21,61,4,61,1,20,0,12,47,0,23,4,13,1,32,17,51,36,17,39,1,1,13,20,16,20,16,1,61]

theorem envBound55967 : H12AffineFastState.Bounded env55967 := by
  intro p hp
  have h : env55967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55966_55967 : H12AffineEnvironment.transform 8 61 env55966 = env55967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env55966 == env55967) = true)

theorem identity55967 : scanCanonicalize (H12AffineFastState.compose env55967 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55968 : List Nat := [2,4,4,16,32,17,53,21,49,4,49,1,20,0,0,35,0,23,4,1,1,32,17,51,36,17,39,1,1,1,20,16,20,16,1,49]

theorem envBound55968 : H12AffineFastState.Bounded env55968 := by
  intro p hp
  have h : env55968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55967_55968 : H12AffineEnvironment.transform 2 4 env55967 = env55968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55967 == env55968) = true)

theorem identity55968 : scanCanonicalize (H12AffineFastState.compose env55968 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55968 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55969 : List Nat := [2,4,4,16,7,17,18,21,22,4,22,1,20,0,0,4,0,23,4,1,1,7,17,20,3,17,0,1,1,1,20,16,20,16,1,22]

theorem envBound55969 : H12AffineFastState.Bounded env55969 := by
  intro p hp
  have h : env55969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55968_55969 : H12AffineEnvironment.transform 4 7 env55968 = env55969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55968 == env55969) = true)

theorem identity55969 : scanCanonicalize (H12AffineFastState.compose env55969 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55969 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55970 : List Nat := [2,4,4,7,7,6,5,2,1,4,1,1,3,0,0,4,0,0,4,1,1,7,6,3,3,6,0,1,1,1,3,7,3,7,1,1]

theorem envBound55970 : H12AffineFastState.Bounded env55970 := by
  intro p hp
  have h : env55970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55969_55970 : H12AffineEnvironment.transform 3 7 env55969 = env55970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55969 == env55970) = true)

def env55971 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143496,20496,508155,148716,148716,96347,90263,90259,172,222334,1260,135681]

theorem envBound55971 : H12AffineFastState.Bounded env55971 := by
  intro p hp
  have h : env55971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55937_55971 : H12AffineEnvironment.transform 7 173 env55937 = env55971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55937 == env55971) = true)

def env55972 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143496,20496,508075,148668,148668,96267,90263,90259,172,222254,1212,135681]

theorem envBound55972 : H12AffineFastState.Bounded env55972 := by
  intro p hp
  have h : env55972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55971_55972 : H12AffineEnvironment.transform 5 16 env55971 = env55972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55971 == env55972) = true)

theorem identity55972 : scanCanonicalize (H12AffineFastState.compose env55972 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound55972 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55973 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,58519,143496,20496,120867,148668,148668,96267,90263,90259,172,222254,1212,135681]

theorem envBound55973 : H12AffineFastState.Bounded env55973 := by
  intro p hp
  have h : env55973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55972_55973 : H12AffineEnvironment.transform 17 137352 env55972 = env55973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env55972 == env55973) = true)

theorem identity55973 : scanCanonicalize (H12AffineFastState.compose env55973 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound55973 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env55974 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4096,61569,46093,58519,50325,20496,120867,45217,45217,96267,90263,90259,172,102451,1212,58908]

theorem envBound55974 : H12AffineFastState.Bounded env55974 := by
  intro p hp
  have h : env55974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55973_55974 : H12AffineEnvironment.transform 16 62493 env55973 = env55974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env55973 == env55974) = true)

theorem identity55974 : scanCanonicalize (H12AffineFastState.compose env55974 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound55974 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55975 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24600,65536,5125,3213,4,24601,4096,4249,21525,1167,9357,20496,79931,20665,20665,96267,90263,90259,172,94251,1212,1540]

theorem envBound55975 : H12AffineFastState.Bounded env55975 := by
  intro p hp
  have h : env55975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55974_55975 : H12AffineEnvironment.transform 14 24600 env55974 = env55975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env55974 == env55975) = true)

theorem identity55975 : scanCanonicalize (H12AffineFastState.compose env55975 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 18962) := by decide +kernel

theorem selectedBound55975 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env55976 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24600,18962,5125,3213,4,24601,4096,4249,21525,1167,9357,20496,29225,20665,20665,12825,10885,10881,172,14905,1212,1540]

theorem envBound55976 : H12AffineFastState.Bounded env55976 := by
  intro p hp
  have h : env55976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55975_55976 : H12AffineEnvironment.transform 15 18962 env55975 = env55976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18962 env55975 == env55976) = true)

theorem identity55976 : scanCanonicalize (H12AffineFastState.compose env55976 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 14888) := by decide +kernel

theorem selectedBound55976 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env55977 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,14888,6704,12346,5125,3213,4,6705,4096,4249,11837,1167,9357,10808,2049,10897,10897,12825,10885,10881,172,14905,1212,1540]

theorem envBound55977 : H12AffineFastState.Bounded env55977 := by
  intro p hp
  have h : env55977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55976_55977 : H12AffineEnvironment.transform 13 14888 env55976 = env55977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14888 env55976 == env55977) = true)

theorem identity55977 : scanCanonicalize (H12AffineFastState.compose env55977 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound55977 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env55978 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2721,4233,6704,6811,5125,3213,4,6705,4096,4249,1180,1167,3628,153,2049,48,48,6328,36,32,172,4248,1212,1540]

theorem envBound55978 : H12AffineFastState.Bounded env55978 := by
  intro p hp
  have h : env55978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55977_55978 : H12AffineEnvironment.transform 12 2721 env55977 = env55978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env55977 == env55978) = true)

theorem identity55978 : scanCanonicalize (H12AffineFastState.compose env55978 (packedSelected [1,2,4,6,7,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55978 : packedSelected [1,2,4,6,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55979 : List Nat := [2,4,8,16,32,16,128,173,1,1024,2048,4096,2208,4233,6193,6298,5125,3213,4,6192,4096,4249,1180,1167,3117,153,2049,48,48,6328,36,32,172,4248,1212,1029]

theorem envBound55979 : H12AffineFastState.Bounded env55979 := by
  intro p hp
  have h : env55979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55978_55979 : H12AffineEnvironment.transform 8 1 env55978 = env55979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55978 == env55979) = true)

theorem identity55979 : scanCanonicalize (H12AffineFastState.compose env55979 (packedSelected [1,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55979 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env55980 : List Nat := [2,4,8,16,32,16,128,173,1,1024,49,4096,145,4233,4096,4267,5125,1212,4,4097,4096,4249,1180,1167,1052,153,48,48,48,4233,36,32,172,4248,1212,1029]

theorem envBound55980 : H12AffineFastState.Bounded env55980 := by
  intro p hp
  have h : env55980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55979_55980 : H12AffineEnvironment.transform 10 49 env55979 = env55980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55979 == env55980) = true)

theorem identity55980 : scanCanonicalize (H12AffineFastState.compose env55980 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound55980 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env55981 : List Nat := [2,4,8,16,32,16,128,173,1,31,49,4096,145,4233,4096,4267,4122,163,4,4097,4096,4249,131,144,3,153,48,48,48,4233,36,32,172,4248,163,26]

theorem envBound55981 : H12AffineFastState.Bounded env55981 := by
  intro p hp
  have h : env55981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55980_55981 : H12AffineEnvironment.transform 9 31 env55980 = env55981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env55980 == env55981) = true)

theorem identity55981 : scanCanonicalize (H12AffineFastState.compose env55981 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound55981 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env55982 : List Nat := [2,4,8,16,32,16,128,173,1,31,49,48,145,185,48,155,42,163,4,49,48,169,131,144,3,153,48,48,48,185,36,32,172,168,163,26]

theorem envBound55982 : H12AffineFastState.Bounded env55982 := by
  intro p hp
  have h : env55982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55981_55982 : H12AffineEnvironment.transform 11 48 env55981 = env55982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55981 == env55982) = true)

theorem identity55982 : scanCanonicalize (H12AffineFastState.compose env55982 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55982 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55983 : List Nat := [2,4,8,16,10,16,128,135,1,31,27,26,145,147,26,155,0,137,4,27,26,131,131,144,3,153,26,26,26,147,14,10,134,130,137,26]

theorem envBound55983 : H12AffineFastState.Bounded env55983 := by
  intro p hp
  have h : env55983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55982_55983 : H12AffineEnvironment.transform 4 10 env55982 = env55983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55982 == env55983) = true)

theorem identity55983 : scanCanonicalize (H12AffineFastState.compose env55983 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55984 : List Nat := [2,4,8,11,10,11,128,135,1,4,0,1,138,136,1,128,0,137,4,0,1,131,131,139,3,130,1,1,1,136,14,10,134,130,137,1]

theorem envBound55984 : H12AffineFastState.Bounded env55984 := by
  intro p hp
  have h : env55984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55983_55984 : H12AffineEnvironment.transform 3 11 env55983 = env55984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55983 == env55984) = true)

theorem identity55984 : scanCanonicalize (H12AffineFastState.compose env55984 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55985 : List Nat := [2,4,4,7,6,7,128,135,1,4,0,1,134,132,1,128,0,133,4,0,1,131,131,135,3,130,1,1,1,132,2,6,134,130,133,1]

theorem envBound55985 : H12AffineFastState.Bounded env55985 := by
  intro p hp
  have h : env55985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55984_55985 : H12AffineEnvironment.transform 2 4 env55984 = env55985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55984 == env55985) = true)

def env55986 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143496,20496,508074,148669,148669,96266,90263,90259,172,222255,1213,135681]

theorem envBound55986 : H12AffineFastState.Bounded env55986 := by
  intro p hp
  have h : env55986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55971_55986 : H12AffineEnvironment.transform 5 17 env55971 = env55986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55971 == env55986) = true)

theorem identity55986 : scanCanonicalize (H12AffineFastState.compose env55986 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound55986 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55987 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,58519,32808,20496,356362,62493,62493,96266,90263,90259,172,119951,1213,41633]

theorem envBound55987 : H12AffineFastState.Bounded env55987 := by
  intro p hp
  have h : env55987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55986_55987 : H12AffineEnvironment.transform 16 45216 env55986 = env55987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env55986 == env55987) = true)

theorem identity55987 : scanCanonicalize (H12AffineFastState.compose env55987 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound55987 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55988 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4096,61568,61617,58519,32808,20496,96386,62493,62493,96266,90263,90259,172,119951,1213,41633]

theorem envBound55988 : H12AffineFastState.Bounded env55988 := by
  intro p hp
  have h : env55988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55987_55988 : H12AffineEnvironment.transform 17 2184 env55987 = env55988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env55987 == env55988) = true)

theorem identity55988 : scanCanonicalize (H12AffineFastState.compose env55988 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound55988 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env55989 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,29831,45216,2184,42145,32769,4096,61568,61617,58519,32808,20496,3077,62493,62493,3213,5136,5140,172,40968,1213,41633]

end H12CloudChart2