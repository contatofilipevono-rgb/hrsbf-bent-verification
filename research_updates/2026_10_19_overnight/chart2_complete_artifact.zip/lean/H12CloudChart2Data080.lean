import H12CloudChart2Data079

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound19631 : H12AffineFastState.Bounded env19631 := by
  intro p hp
  have h : env19631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19630_19631 : H12AffineEnvironment.transform 23 330157 env19630 = env19631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 330157 env19630 == env19631) = true)

theorem identity19631 : scanCanonicalize (H12AffineFastState.compose env19631 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33196) := by decide +kernel

theorem selectedBound19631 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19632 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,33196,16,330157,9,16,2049,1296,1296,262145,298413,33060,256,330127,1296,396]

theorem envBound19632 : H12AffineFastState.Bounded env19632 := by
  intro p hp
  have h : env19632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19631_19632 : H12AffineEnvironment.transform 21 33196 env19631 = env19632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33196 env19631 == env19632) = true)

theorem identity19632 : scanCanonicalize (H12AffineFastState.compose env19632 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 34985) := by decide +kernel

theorem selectedBound19632 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19633 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,34985,1024,32769,1296,33196,16,98564,9,16,2049,1296,1296,34984,1284,33060,256,98598,1296,396]

theorem envBound19633 : H12AffineFastState.Bounded env19633 := by
  intro p hp
  have h : env19633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19632_19633 : H12AffineEnvironment.transform 17 34985 env19632 = env19633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34985 env19632 == env19633) = true)

theorem identity19633 : scanCanonicalize (H12AffineFastState.compose env19633 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19633 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19634 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,129,1045,32768,65536,1044,34985,1024,32769,1045,32937,16,98305,9,16,2049,1045,1045,34984,1025,32801,5,98339,1045,137]

theorem envBound19634 : H12AffineFastState.Bounded env19634 := by
  intro p hp
  have h : env19634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19633_19634 : H12AffineEnvironment.transform 7 5 env19633 = env19634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19633 == env19634) = true)

def env19635 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,129,1,32768,65536,0,34985,20,32769,1,32937,16,98305,9,16,2049,1,1,34984,21,32801,5,98339,1,137]

theorem envBound19635 : H12AffineFastState.Bounded env19635 := by
  intro p hp
  have h : env19635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19634_19635 : H12AffineEnvironment.transform 9 20 env19634 = env19635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19634 == env19635) = true)

theorem identity19635 : scanCanonicalize (H12AffineFastState.compose env19635 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 32770) := by decide +kernel

theorem selectedBound19635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19636 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,129,1,32768,32770,0,34985,20,32769,1,32937,16,3,9,16,2049,1,1,34984,21,32801,5,33,1,137]

theorem envBound19636 : H12AffineFastState.Bounded env19636 := by
  intro p hp
  have h : env19636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19635_19636 : H12AffineEnvironment.transform 15 32770 env19635 = env19636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32770 env19635 == env19636) = true)

def env19637 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,129,1,2048,2050,0,169,20,2049,1,2217,16,3,9,16,2049,1,1,168,21,2081,5,33,1,137]

theorem envBound19637 : H12AffineFastState.Bounded env19637 := by
  intro p hp
  have h : env19637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19636_19637 : H12AffineEnvironment.transform 14 2048 env19636 = env19637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env19636 == env19637) = true)

theorem identity19637 : scanCanonicalize (H12AffineFastState.compose env19637 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound19637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19638 : List Nat := [2,4,8,16,32,17,24,5,17,20,2048,0,25,1,2048,2050,0,49,20,2049,1,2097,16,3,9,16,2049,1,1,48,21,2081,5,33,1,17]

theorem envBound19638 : H12AffineFastState.Bounded env19638 := by
  intro p hp
  have h : env19638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19637_19638 : H12AffineEnvironment.transform 6 24 env19637 = env19638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env19637 == env19638) = true)

def env19639 : List Nat := [2,4,8,16,32,17,24,5,17,20,32,0,25,1,32,34,0,49,20,33,1,17,16,3,9,16,33,1,1,48,21,1,5,33,1,17]

theorem envBound19639 : H12AffineFastState.Bounded env19639 := by
  intro p hp
  have h : env19639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19638_19639 : H12AffineEnvironment.transform 10 32 env19638 = env19639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env19638 == env19639) = true)

def env19640 : List Nat := [2,4,8,16,0,17,24,5,17,20,0,0,25,1,0,2,0,17,20,1,1,17,16,3,9,16,1,1,1,16,21,1,5,1,1,17]

theorem envBound19640 : H12AffineFastState.Bounded env19640 := by
  intro p hp
  have h : env19640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19639_19640 : H12AffineEnvironment.transform 4 0 env19639 = env19640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19639 == env19640) = true)

def env19641 : List Nat := [2,4,8,16,1,17,24,5,17,20,1,0,25,1,1,3,0,16,20,0,1,17,16,3,9,16,0,1,1,17,21,1,5,0,1,17]

theorem envBound19641 : H12AffineFastState.Bounded env19641 := by
  intro p hp
  have h : env19641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19639_19641 : H12AffineEnvironment.transform 4 1 env19639 = env19641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19639 == env19641) = true)

theorem identity19641 : scanCanonicalize (H12AffineFastState.compose env19641 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19641 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19642 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,0,9,1,1,3,0,0,4,0,1,1,0,3,9,0,0,1,1,1,5,1,5,0,1,1]

theorem envBound19642 : H12AffineFastState.Bounded env19642 := by
  intro p hp
  have h : env19642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19641_19642 : H12AffineEnvironment.transform 3 0 env19641 = env19642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19641 == env19642) = true)

def leafEnv19642 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,0,9,1,1,3,0,0,4,0,1,1,0,3,4,9,1,0,0,1,1,1,5,1,5,0,5,2,1,1,0,1,1]

def active19642 : List Nat := [0,1,2]

def tree19642 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19642 : H12WitnessSearch.Good tree19642 := H12GlobalWitnessIndex.good

theorem leafIdentity19642 : H12AffineFastState.composeSystem env19642 rootObs = leafEnv19642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19642 rootObs == leafEnv19642) = true)

theorem terminalChecked19642 : H12PackedTerminal.terminalCheckFast leafEnv19642 active19642 tree19642 = true := by decide +kernel

def env19643 : List Nat := [2,4,8,16,32,17,24,5,17,20,33,0,25,1,33,35,0,49,20,32,1,16,16,3,9,16,32,1,1,48,21,0,5,33,1,17]

theorem envBound19643 : H12AffineFastState.Bounded env19643 := by
  intro p hp
  have h : env19643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19638_19643 : H12AffineEnvironment.transform 10 33 env19638 = env19643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env19638 == env19643) = true)

theorem identity19643 : scanCanonicalize (H12AffineFastState.compose env19643 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19644 : List Nat := [2,4,8,16,17,17,24,5,17,20,16,0,25,1,16,18,0,0,20,17,1,16,16,3,9,16,17,1,1,1,21,0,5,16,1,17]

theorem envBound19644 : H12AffineFastState.Bounded env19644 := by
  intro p hp
  have h : env19644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19643_19644 : H12AffineEnvironment.transform 4 17 env19643 = env19644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19643 == env19644) = true)

def env19645 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,129,1,2049,2051,0,168,20,2048,1,2216,16,3,9,16,2049,1,1,169,21,2080,5,33,1,137]

theorem envBound19645 : H12AffineFastState.Bounded env19645 := by
  intro p hp
  have h : env19645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19636_19645 : H12AffineEnvironment.transform 14 2049 env19636 = env19645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env19636 == env19645) = true)

theorem identity19645 : scanCanonicalize (H12AffineFastState.compose env19645 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound19645 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19646 : List Nat := [2,4,8,16,32,17,128,5,137,20,48,0,129,1,49,51,0,168,20,48,1,152,16,3,9,16,49,1,1,169,21,16,5,33,1,137]

theorem envBound19646 : H12AffineFastState.Bounded env19646 := by
  intro p hp
  have h : env19646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19645_19646 : H12AffineEnvironment.transform 10 48 env19645 = env19646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env19645 == env19646) = true)

def env19647 : List Nat := [2,4,8,0,32,1,128,5,137,4,32,0,129,1,33,35,0,168,4,32,1,136,0,3,9,0,33,1,1,169,5,0,5,33,1,137]

theorem envBound19647 : H12AffineFastState.Bounded env19647 := by
  intro p hp
  have h : env19647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19646_19647 : H12AffineEnvironment.transform 3 0 env19646 = env19647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19646 == env19647) = true)

theorem identity19647 : scanCanonicalize (H12AffineFastState.compose env19647 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19647 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19648 : List Nat := [2,4,8,0,1,1,128,5,137,4,1,0,129,1,0,2,0,137,4,1,1,136,0,3,9,0,0,1,1,136,5,0,5,0,1,137]

theorem envBound19648 : H12AffineFastState.Bounded env19648 := by
  intro p hp
  have h : env19648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19647_19648 : H12AffineEnvironment.transform 4 1 env19647 = env19648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19647 == env19648) = true)

def env19649 : List Nat := [2,4,8,1,32,0,128,5,137,5,33,0,129,1,32,34,0,168,5,33,1,137,1,3,9,1,32,1,1,169,4,1,5,33,1,137]

theorem envBound19649 : H12AffineFastState.Bounded env19649 := by
  intro p hp
  have h : env19649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19646_19649 : H12AffineEnvironment.transform 3 1 env19646 = env19649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19646 == env19649) = true)

theorem identity19649 : scanCanonicalize (H12AffineFastState.compose env19649 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19650 : List Nat := [2,4,8,1,32,0,9,5,0,5,33,0,8,1,32,34,0,33,5,33,1,0,1,3,9,1,32,1,1,32,4,1,5,33,1,0]

theorem envBound19650 : H12AffineFastState.Bounded env19650 := by
  intro p hp
  have h : env19650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19649_19650 : H12AffineEnvironment.transform 6 9 env19649 = env19650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19649 == env19650) = true)

def env19651 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,129,0,32768,65536,1,34985,21,32769,0,32937,16,98305,9,16,2049,0,0,34984,20,32801,5,98339,0,137]

theorem envBound19651 : H12AffineFastState.Bounded env19651 := by
  intro p hp
  have h : env19651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19634_19651 : H12AffineEnvironment.transform 9 21 env19634 = env19651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19634 == env19651) = true)

theorem identity19651 : scanCanonicalize (H12AffineFastState.compose env19651 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19652 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,0,32768,65536,1,34849,21,32769,0,32801,16,98305,9,16,2049,0,0,34848,20,32801,5,98339,0,1]

theorem envBound19652 : H12AffineFastState.Bounded env19652 := by
  intro p hp
  have h : env19652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19651_19652 : H12AffineEnvironment.transform 6 8 env19651 = env19652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19651 == env19652) = true)

def env19653 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,0,0,65536,1,2081,21,1,0,33,16,65537,9,16,2049,0,0,2080,20,33,5,65571,0,1]

theorem envBound19653 : H12AffineFastState.Bounded env19653 := by
  intro p hp
  have h : env19653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19652_19653 : H12AffineEnvironment.transform 14 0 env19652 = env19653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19652 == env19653) = true)

theorem identity19653 : scanCanonicalize (H12AffineFastState.compose env19653 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound19653 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19654 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,0,0,18,1,2081,21,1,0,33,16,19,9,16,2049,0,0,2080,20,33,5,49,0,1]

theorem envBound19654 : H12AffineFastState.Bounded env19654 := by
  intro p hp
  have h : env19654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19653_19654 : H12AffineEnvironment.transform 15 18 env19653 = env19654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env19653 == env19654) = true)

theorem identity19654 : scanCanonicalize (H12AffineFastState.compose env19654 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19654 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19655 : List Nat := [2,4,8,0,32,1,8,5,1,5,2048,1,9,0,0,2,1,2081,5,1,0,33,0,3,9,0,2049,0,0,2080,4,33,5,33,0,1]

theorem envBound19655 : H12AffineFastState.Bounded env19655 := by
  intro p hp
  have h : env19655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19654_19655 : H12AffineEnvironment.transform 3 0 env19654 = env19655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19654 == env19655) = true)

def env19656 : List Nat := [2,4,8,0,32,1,8,5,1,5,0,1,9,0,0,2,1,33,5,1,0,33,0,3,9,0,1,0,0,32,4,33,5,33,0,1]

theorem envBound19656 : H12AffineFastState.Bounded env19656 := by
  intro p hp
  have h : env19656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19655_19656 : H12AffineEnvironment.transform 10 0 env19655 = env19656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19655 == env19656) = true)

def env19657 : List Nat := [2,4,8,0,32,1,8,5,1,5,1,1,9,0,0,2,1,32,5,1,0,33,0,3,9,0,0,0,0,33,4,33,5,33,0,1]

theorem envBound19657 : H12AffineFastState.Bounded env19657 := by
  intro p hp
  have h : env19657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19655_19657 : H12AffineEnvironment.transform 10 1 env19655 = env19657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19655 == env19657) = true)

theorem identity19657 : scanCanonicalize (H12AffineFastState.compose env19657 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19658 : List Nat := [2,4,8,0,0,1,8,5,1,5,1,1,9,0,0,2,1,0,5,1,0,1,0,3,9,0,0,0,0,1,4,1,5,1,0,1]

theorem envBound19658 : H12AffineFastState.Bounded env19658 := by
  intro p hp
  have h : env19658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19657_19658 : H12AffineEnvironment.transform 4 0 env19657 = env19658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19657 == env19658) = true)

def leafEnv19658 : List Nat := [2,4,8,0,0,1,8,5,1,5,1,1,9,0,0,2,1,0,5,1,0,1,0,3,5,9,1,0,0,0,0,1,4,1,5,1,5,3,0,1,0,0,1]

def active19658 : List Nat := [0,1,2]

def tree19658 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19658 : H12WitnessSearch.Good tree19658 := H12GlobalWitnessIndex.good

theorem leafIdentity19658 : H12AffineFastState.composeSystem env19658 rootObs = leafEnv19658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19658 rootObs == leafEnv19658) = true)

theorem terminalChecked19658 : H12PackedTerminal.terminalCheckFast leafEnv19658 active19658 tree19658 = true := by decide +kernel

def env19659 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,0,1,65536,1,2080,21,0,0,32,16,65536,9,16,2049,0,0,2081,20,32,5,65570,0,1]

theorem envBound19659 : H12AffineFastState.Bounded env19659 := by
  intro p hp
  have h : env19659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19652_19659 : H12AffineEnvironment.transform 14 1 env19652 = env19659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19652 == env19659) = true)

theorem identity19659 : scanCanonicalize (H12AffineFastState.compose env19659 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound19659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19660 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,0,1,50,1,2080,21,0,0,32,16,50,9,16,2049,0,0,2081,20,32,5,16,0,1]

theorem envBound19660 : H12AffineFastState.Bounded env19660 := by
  intro p hp
  have h : env19660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19659_19660 : H12AffineEnvironment.transform 15 50 env19659 = env19660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env19659 == env19660) = true)

def env19661 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,9,16,21331968,1296,1296,21071873,16876544,4194440,256,16777250,1296,396]

theorem envBound19661 : H12AffineFastState.Bounded env19661 := by
  intro p hp
  have h : env19661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19629_19661 : H12AffineEnvironment.transform 29 21071873 env19629 = env19661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071873 env19629 == env19661) = true)

theorem identity19661 : scanCanonicalize (H12AffineFastState.compose env19661 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19661 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19662 : List Nat := [2,4,8,16,32,17,128,256,396,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,4194304,16,16777216,9,16,21331968,0,0,21071873,16875792,4194440,256,16777250,0,396]

theorem envBound19662 : H12AffineFastState.Bounded env19662 := by
  intro p hp
  have h : env19662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19661_19662 : H12AffineEnvironment.transform 9 272 env19661 = env19662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19661 == env19662) = true)

theorem identity19662 : scanCanonicalize (H12AffineFastState.compose env19662 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33196) := by decide +kernel

theorem selectedBound19662 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19663 : List Nat := [2,4,8,16,32,17,128,256,396,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,33196,16,16777216,9,16,17105324,0,0,16845229,16875792,33060,256,16777250,0,396]

theorem envBound19663 : H12AffineFastState.Bounded env19663 := by
  intro p hp
  have h : env19663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19662_19663 : H12AffineEnvironment.transform 21 33196 env19662 = env19663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33196 env19662 == env19663) = true)

theorem identity19663 : scanCanonicalize (H12AffineFastState.compose env19663 (packedSelected [1,3,8] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound19663 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env19664 : List Nat := [2,4,8,16,32,17,128,256,396,272,2048,1,129,0,32768,65536,1,262144,272,32769,0,33196,16,98565,9,16,295081,0,0,34984,21,33060,256,98599,0,396]

theorem envBound19664 : H12AffineFastState.Bounded env19664 := by
  intro p hp
  have h : env19664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19663_19664 : H12AffineEnvironment.transform 23 98565 env19663 = env19664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env19663 == env19664) = true)

theorem identity19664 : scanCanonicalize (H12AffineFastState.compose env19664 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19664 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19665 : List Nat := [2,4,8,16,32,17,40,256,292,272,2048,1,41,0,32768,65536,1,262144,272,32769,0,33028,16,98565,9,16,294913,0,0,34816,21,33060,256,98599,0,292]

theorem envBound19665 : H12AffineFastState.Bounded env19665 := by
  intro p hp
  have h : env19665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19664_19665 : H12AffineEnvironment.transform 6 40 env19664 = env19665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19664 == env19665) = true)

theorem identity19665 : scanCanonicalize (H12AffineFastState.compose env19665 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19665 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19666 : List Nat := [2,4,8,16,32,17,40,256,292,272,2048,1,41,0,1,65536,1,262144,272,0,0,261,16,65796,9,16,262144,0,0,2049,21,293,256,65830,0,292]

theorem envBound19666 : H12AffineFastState.Bounded env19666 := by
  intro p hp
  have h : env19666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19665_19666 : H12AffineEnvironment.transform 14 1 env19665 = env19666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19665 == env19666) = true)

theorem identity19666 : scanCanonicalize (H12AffineFastState.compose env19666 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19667 : List Nat := [2,4,8,16,32,17,40,256,292,272,2048,1,41,0,1,2,1,262144,272,0,0,261,16,262,9,16,262144,0,0,2049,21,293,256,292,0,292]

theorem envBound19667 : H12AffineFastState.Bounded env19667 := by
  intro p hp
  have h : env19667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19666_19667 : H12AffineEnvironment.transform 15 2 env19666 = env19667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19666 == env19667) = true)

theorem identity19667 : scanCanonicalize (H12AffineFastState.compose env19667 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19668 : List Nat := [2,4,8,16,32,17,40,20,48,4,2048,1,41,0,1,2,1,262144,4,0,0,17,16,18,9,16,262144,0,0,2049,21,49,20,48,0,48]

theorem envBound19668 : H12AffineFastState.Bounded env19668 := by
  intro p hp
  have h : env19668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19667_19668 : H12AffineEnvironment.transform 7 20 env19667 = env19668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19667 == env19668) = true)

theorem identity19668 : scanCanonicalize (H12AffineFastState.compose env19668 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19668 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19669 : List Nat := [2,4,8,1,32,0,40,5,33,4,2048,1,41,0,1,2,1,262144,4,0,0,0,1,3,9,1,262144,0,0,2049,4,32,5,33,0,33]

theorem envBound19669 : H12AffineFastState.Bounded env19669 := by
  intro p hp
  have h : env19669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19668_19669 : H12AffineEnvironment.transform 3 1 env19668 = env19669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19668 == env19669) = true)

theorem identity19669 : scanCanonicalize (H12AffineFastState.compose env19669 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound19669 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env19670 : List Nat := [2,4,8,1,32,0,40,5,33,4,2048,1,41,0,1,2,1,1,4,0,0,0,1,3,9,1,1,0,0,2049,4,32,5,33,0,33]

theorem envBound19670 : H12AffineFastState.Bounded env19670 := by
  intro p hp
  have h : env19670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19669_19670 : H12AffineEnvironment.transform 17 1 env19669 = env19670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19669 == env19670) = true)

theorem identity19670 : scanCanonicalize (H12AffineFastState.compose env19670 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19670 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19671 : List Nat := [2,4,8,1,32,0,40,5,33,4,0,1,41,0,1,2,1,1,4,0,0,0,1,3,9,1,1,0,0,1,4,32,5,33,0,33]

theorem envBound19671 : H12AffineFastState.Bounded env19671 := by
  intro p hp
  have h : env19671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19670_19671 : H12AffineEnvironment.transform 10 0 env19670 = env19671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19670 == env19671) = true)

theorem identity19671 : scanCanonicalize (H12AffineFastState.compose env19671 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19671 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19672 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,1,9,0,1,2,1,1,4,0,0,0,1,3,9,1,1,0,0,1,4,0,5,1,0,1]

theorem envBound19672 : H12AffineFastState.Bounded env19672 := by
  intro p hp
  have h : env19672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19671_19672 : H12AffineEnvironment.transform 4 0 env19671 = env19672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19671 == env19672) = true)

def env19673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32769,1344,4194304,17664,16777216,8328,17745,21331968,16384,16385,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19673 : H12AffineFastState.Bounded env19673 := by
  intro p hp
  have h : env19673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19474_19673 : H12AffineEnvironment.transform 11 1345 env19474 = env19673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19474 == env19673) = true)

def env19674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,64,16777216,8328,17,21331968,1344,1345,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19674 : H12AffineFastState.Bounded env19674 := by
  intro p hp
  have h : env19674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19673_19674 : H12AffineEnvironment.transform 13 1344 env19673 = env19674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19673 == env19674) = true)

theorem identity19674 : scanCanonicalize (H12AffineFastState.compose env19674 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound19674 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1344,1345,1073741824,1365,4294967296,256,4299260415,1345,512]

theorem envBound19675 : H12AffineFastState.Bounded env19675 := by
  intro p hp
  have h : env19675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19674_19675 : H12AffineEnvironment.transform 23 98645 env19674 = env19675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env19674 == env19675) = true)

theorem identity19675 : scanCanonicalize (H12AffineFastState.compose env19675 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 4196693) := by decide +kernel

theorem selectedBound19675 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env19676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1344,1345,4196693,1365,4294967296,256,4299260415,1345,512]

theorem envBound19676 : H12AffineFastState.Bounded env19676 := by
  intro p hp
  have h : env19676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19675_19676 : H12AffineEnvironment.transform 29 4196693 env19675 = env19676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196693 env19675 == env19676) = true)

theorem identity19676 : scanCanonicalize (H12AffineFastState.compose env19676 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(31+1) ^^^ 4235425) := by decide +kernel

theorem selectedBound19676 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1344,1345,4196693,1365,4235425,256,74078,1345,512]

theorem envBound19677 : H12AffineFastState.Bounded env19677 := by
  intro p hp
  have h : env19677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19676_19677 : H12AffineEnvironment.transform 31 4235425 env19676 = env19677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4235425 env19676 == env19677) = true)

theorem identity19677 : scanCanonicalize (H12AffineFastState.compose env19677 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound19677 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,43129,1024,32769,1344,4194304,64,98645,8328,17,4237612,1344,1345,4196693,1365,4235425,256,74078,1345,512]

theorem envBound19678 : H12AffineFastState.Bounded env19678 := by
  intro p hp
  have h : env19678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19677_19678 : H12AffineEnvironment.transform 17 43129 env19677 = env19678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env19677 == env19678) = true)

theorem identity19678 : scanCanonicalize (H12AffineFastState.compose env19678 (packedSelected [13,17] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound19678 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env19679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,43129,1024,32769,1344,341,64,98645,8328,17,43129,1344,1345,2048,1365,41460,256,74078,1345,512]

theorem envBound19679 : H12AffineFastState.Bounded env19679 := by
  intro p hp
  have h : env19679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19678_19679 : H12AffineEnvironment.transform 21 341 env19678 = env19679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env19678 == env19679) = true)

theorem identity19679 : scanCanonicalize (H12AffineFastState.compose env19679 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19679 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,43048,1024,32769,1297,260,17,98564,8328,17,43048,1297,1296,2048,1284,41381,256,73999,1296,512]

theorem envBound19680 : H12AffineFastState.Bounded env19680 := by
  intro p hp
  have h : env19680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19679_19680 : H12AffineEnvironment.transform 5 17 env19679 = env19680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19679 == env19680) = true)

theorem identity19680 : scanCanonicalize (H12AffineFastState.compose env19680 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19680 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19681 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,32768,65536,1297,43048,1024,32769,1297,260,17,98564,8328,17,43048,1297,1296,2048,1284,41381,256,73999,1296,137]

theorem envBound19681 : H12AffineFastState.Bounded env19681 := by
  intro p hp
  have h : env19681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19680_19681 : H12AffineEnvironment.transform 8 137 env19680 = env19681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19680 == env19681) = true)

theorem identity19681 : scanCanonicalize (H12AffineFastState.compose env19681 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound19681 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19682 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,32768,8355,1297,43048,1024,32769,1297,260,17,41383,8328,17,43048,1297,1296,2048,1284,41381,256,428,1296,137]

theorem envBound19682 : H12AffineFastState.Bounded env19682 := by
  intro p hp
  have h : env19682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19681_19682 : H12AffineEnvironment.transform 15 8355 env19681 = env19682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env19681 == env19682) = true)

theorem identity19682 : scanCanonicalize (H12AffineFastState.compose env19682 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19682 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env19683 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1044,32768,8355,1044,43048,1024,32769,1044,1,17,41122,8328,17,43048,1044,1045,2048,1025,41120,5,169,1045,137]

theorem envBound19683 : H12AffineFastState.Bounded env19683 := by
  intro p hp
  have h : env19683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19682_19683 : H12AffineEnvironment.transform 7 5 env19682 = env19683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19682 == env19683) = true)

theorem identity19683 : scanCanonicalize (H12AffineFastState.compose env19683 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound19683 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19684 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1044,2081,8355,1044,8201,1024,2080,1044,1,17,10371,8328,17,8201,1044,1045,2048,1025,10369,5,169,1045,137]

theorem envBound19684 : H12AffineFastState.Bounded env19684 := by
  intro p hp
  have h : env19684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19683_19684 : H12AffineEnvironment.transform 14 2081 env19683 = env19684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env19683 == env19684) = true)

def env19685 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2056,1044,2081,2219,1044,2049,1024,2080,1044,1,17,139,2176,17,2049,1044,1045,2048,1025,137,5,169,1045,137]

theorem envBound19685 : H12AffineFastState.Bounded env19685 := by
  intro p hp
  have h : env19685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19684_19685 : H12AffineEnvironment.transform 12 2056 env19684 = env19685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env19684 == env19685) = true)

theorem identity19685 : scanCanonicalize (H12AffineFastState.compose env19685 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound19685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19686 : List Nat := [2,4,8,16,32,17,128,5,137,1024,169,1045,161,1044,136,2,1044,168,1024,137,1044,1,17,139,41,17,168,1044,1045,169,1025,137,5,169,1045,137]

theorem envBound19686 : H12AffineFastState.Bounded env19686 := by
  intro p hp
  have h : env19686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19685_19686 : H12AffineEnvironment.transform 10 169 env19685 = env19686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env19685 == env19686) = true)

theorem identity19686 : scanCanonicalize (H12AffineFastState.compose env19686 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound19686 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19687 : List Nat := [2,4,8,16,32,17,128,5,137,53,169,32,161,33,136,2,33,168,53,137,33,1,17,139,41,17,168,33,32,169,52,137,5,169,32,137]

theorem envBound19687 : H12AffineFastState.Bounded env19687 := by
  intro p hp
  have h : env19687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19686_19687 : H12AffineEnvironment.transform 9 53 env19686 = env19687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19686 == env19687) = true)

def env19688 : List Nat := [2,4,8,16,0,17,128,5,137,21,137,0,129,1,136,2,1,136,21,137,1,1,17,139,9,17,136,1,0,137,20,137,5,137,0,137]

theorem envBound19688 : H12AffineFastState.Bounded env19688 := by
  intro p hp
  have h : env19688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19687_19688 : H12AffineEnvironment.transform 4 0 env19687 = env19688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19687 == env19688) = true)

theorem identity19688 : scanCanonicalize (H12AffineFastState.compose env19688 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19688 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19689 : List Nat := [2,4,8,0,0,1,128,5,137,5,137,0,129,1,136,2,1,136,5,137,1,1,1,139,9,1,136,1,0,137,4,137,5,137,0,137]

theorem envBound19689 : H12AffineFastState.Bounded env19689 := by
  intro p hp
  have h : env19689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19688_19689 : H12AffineEnvironment.transform 3 0 env19688 = env19689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19688 == env19689) = true)

def leafEnv19689 : List Nat := [2,4,8,0,0,1,128,5,137,5,137,0,129,1,136,2,1,136,5,137,1,1,1,139,5,9,1,1,136,1,0,137,4,137,5,137,5,139,0,137,0,0,1]

def active19689 : List Nat := [0,1,2,6]

def tree19689 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19689 : H12WitnessSearch.Good tree19689 := H12GlobalWitnessIndex.good

theorem leafIdentity19689 : H12AffineFastState.composeSystem env19689 rootObs = leafEnv19689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19689 rootObs == leafEnv19689) = true)

theorem terminalChecked19689 : H12PackedTerminal.terminalCheckFast leafEnv19689 active19689 tree19689 = true := by decide +kernel

def env19690 : List Nat := [2,4,8,16,1,17,128,5,137,20,136,1,128,0,136,2,0,137,20,137,0,1,17,139,8,17,137,0,1,136,21,137,5,136,1,137]

theorem envBound19690 : H12AffineFastState.Bounded env19690 := by
  intro p hp
  have h : env19690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19687_19690 : H12AffineEnvironment.transform 4 1 env19687 = env19690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19687 == env19690) = true)

theorem identity19690 : scanCanonicalize (H12AffineFastState.compose env19690 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound19690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19691 : List Nat := [2,4,8,16,1,17,24,5,17,20,16,1,24,0,16,2,0,17,20,17,0,1,17,19,8,17,17,0,1,16,21,17,5,16,1,17]

theorem envBound19691 : H12AffineFastState.Bounded env19691 := by
  intro p hp
  have h : env19691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19690_19691 : H12AffineEnvironment.transform 6 24 env19690 = env19691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env19690 == env19691) = true)

def leafEnv19691 : List Nat := [2,4,8,16,1,17,24,5,17,20,16,1,24,0,16,2,0,17,20,17,0,1,17,19,20,8,1,17,17,0,1,16,21,17,5,16,5,19,1,17,0,1,1]

def active19691 : List Nat := [0,1,2,3]

def tree19691 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19691 : H12WitnessSearch.Good tree19691 := H12GlobalWitnessIndex.good

theorem leafIdentity19691 : H12AffineFastState.composeSystem env19691 rootObs = leafEnv19691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19691 rootObs == leafEnv19691) = true)

theorem terminalChecked19691 : H12PackedTerminal.terminalCheckFast leafEnv19691 active19691 tree19691 = true := by decide +kernel

def env19692 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2057,1044,2081,2218,1044,2048,1024,2080,1044,1,17,138,2177,17,2048,1044,1045,2048,1025,136,5,169,1045,137]

theorem envBound19692 : H12AffineFastState.Bounded env19692 := by
  intro p hp
  have h : env19692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19684_19692 : H12AffineEnvironment.transform 12 2057 env19684 = env19692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env19684 == env19692) = true)

theorem identity19692 : scanCanonicalize (H12AffineFastState.compose env19692 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound19692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19693 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1213,1045,1204,1044,1180,1047,1044,1213,1024,1181,1044,1,17,138,1084,17,1213,1044,1045,1213,1025,136,5,169,1045,137]

theorem envBound19693 : H12AffineFastState.Bounded env19693 := by
  intro p hp
  have h : env19693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19692_19693 : H12AffineEnvironment.transform 10 1213 env19692 = env19693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env19692 == env19693) = true)

def env19694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,65,16777216,8328,16,21331968,1345,1344,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19694 : H12AffineFastState.Bounded env19694 := by
  intro p hp
  have h : env19694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19673_19694 : H12AffineEnvironment.transform 13 1345 env19673 = env19694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19673 == env19694) = true)

theorem identity19694 : scanCanonicalize (H12AffineFastState.compose env19694 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound19694 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,65,98564,8328,16,4456708,1345,1344,1073741824,1284,4294967296,256,4299260334,1345,512]

theorem envBound19695 : H12AffineFastState.Bounded env19695 := by
  intro p hp
  have h : env19695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19694_19695 : H12AffineEnvironment.transform 23 98564 env19694 = env19695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env19694 == env19695) = true)

theorem identity19695 : scanCanonicalize (H12AffineFastState.compose env19695 (packedSelected [17,21] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound19695 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,65,98564,8328,16,4456708,1345,1344,43049,1284,4294967296,256,4299260334,1345,512]

theorem envBound19696 : H12AffineFastState.Bounded env19696 := by
  intro p hp
  have h : env19696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19695_19696 : H12AffineEnvironment.transform 29 43049 env19695 = env19696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env19695 == env19696) = true)

def env19697 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,0,262144,320,32769,0,4194304,65,98564,8328,16,4456708,1,0,43049,68,4294967296,256,4299260334,1,512]

theorem envBound19697 : H12AffineFastState.Bounded env19697 := by
  intro p hp
  have h : env19697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19696_19697 : H12AffineEnvironment.transform 9 320 env19696 = env19697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env19696 == env19697) = true)

theorem identity19697 : scanCanonicalize (H12AffineFastState.compose env19697 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound19697 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19698 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,479,0,262144,320,32769,0,4194304,65,32987,8328,16,4456708,1,0,43049,68,4294967296,256,4299194481,1,512]

theorem envBound19698 : H12AffineFastState.Bounded env19698 := by
  intro p hp
  have h : env19698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19697_19698 : H12AffineEnvironment.transform 15 479 env19697 = env19698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env19697 == env19698) = true)

theorem identity19698 : scanCanonicalize (H12AffineFastState.compose env19698 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound19698 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19699 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,479,0,43681,320,32769,0,4194304,65,32987,8328,16,4238245,1,0,43049,68,4294967296,256,4299194481,1,512]

theorem envBound19699 : H12AffineFastState.Bounded env19699 := by
  intro p hp
  have h : env19699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19698_19699 : H12AffineEnvironment.transform 17 43681 env19698 = env19699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env19698 == env19699) = true)

theorem identity19699 : scanCanonicalize (H12AffineFastState.compose env19699 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 4227585) := by decide +kernel

theorem selectedBound19699 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env19700 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,479,0,43681,320,32769,0,4194304,65,32987,8328,16,4238245,1,0,43049,68,4227585,256,624,1,512]

theorem envBound19700 : H12AffineFastState.Bounded env19700 := by
  intro p hp
  have h : env19700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19699_19700 : H12AffineEnvironment.transform 31 4227585 env19699 = env19700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4227585 env19699 == env19700) = true)

def env19701 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,1,32768,399,0,43681,272,32769,0,4194304,17,32907,8328,16,4238245,1,0,43049,20,4227585,256,544,1,512]

theorem envBound19701 : H12AffineFastState.Bounded env19701 := by
  intro p hp
  have h : env19701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19700_19701 : H12AffineEnvironment.transform 5 16 env19700 = env19701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19700 == env19701) = true)

theorem identity19701 : scanCanonicalize (H12AffineFastState.compose env19701 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19702 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,1,8192,1,32768,138,0,43681,21,32769,0,4194304,17,32907,8328,16,4237984,1,0,43049,20,4227585,5,544,1,512]

theorem envBound19702 : H12AffineFastState.Bounded env19702 := by
  intro p hp
  have h : env19702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19701_19702 : H12AffineEnvironment.transform 7 5 env19701 = env19702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19701 == env19702) = true)

theorem identity19702 : scanCanonicalize (H12AffineFastState.compose env19702 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 41633) := by decide +kernel

theorem selectedBound19702 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19703 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,1,8192,1,32768,138,0,43681,21,32769,0,41633,17,32907,8328,16,2049,1,0,43049,20,8352,5,544,1,512]

theorem envBound19703 : H12AffineFastState.Bounded env19703 := by
  intro p hp
  have h : env19703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19702_19703 : H12AffineEnvironment.transform 21 41633 env19702 = env19703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41633 env19702 == env19703) = true)

theorem identity19703 : scanCanonicalize (H12AffineFastState.compose env19703 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19703 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19704 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,8192,1,32768,138,0,43048,21,32769,0,41000,17,32907,8328,16,2049,1,0,43049,20,8352,5,169,1,137]

theorem envBound19704 : H12AffineFastState.Bounded env19704 := by
  intro p hp
  have h : env19704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19703_19704 : H12AffineEnvironment.transform 8 137 env19703 = env19704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19703 == env19704) = true)

def env19705 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,160,1,32768,138,0,34952,21,32769,0,32904,17,32907,40,16,2049,1,0,34953,20,0,5,169,1,137]

theorem envBound19705 : H12AffineFastState.Bounded env19705 := by
  intro p hp
  have h : env19705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19704_19705 : H12AffineEnvironment.transform 12 160 env19704 = env19705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env19704 == env19705) = true)

theorem identity19705 : scanCanonicalize (H12AffineFastState.compose env19705 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound19705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19706 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,1,32768,51,0,34865,21,32769,0,32817,17,32818,40,16,2049,1,0,34864,20,0,5,16,1,48]

theorem envBound19706 : H12AffineFastState.Bounded env19706 := by
  intro p hp
  have h : env19706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19705_19706 : H12AffineEnvironment.transform 6 57 env19705 = env19706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env19705 == env19706) = true)

def env19707 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,1,2080,51,0,17,21,2081,0,2065,17,2066,40,16,2049,1,0,16,20,0,5,16,1,48]

theorem envBound19707 : H12AffineFastState.Bounded env19707 := by
  intro p hp
  have h : env19707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19706_19707 : H12AffineEnvironment.transform 14 2080 env19706 = env19707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env19706 == env19707) = true)

def env19708 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,1,2081,51,0,16,21,2080,0,2064,17,2067,40,16,2049,1,0,17,20,0,5,16,1,48]

theorem envBound19708 : H12AffineFastState.Bounded env19708 := by
  intro p hp
  have h : env19708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19706_19708 : H12AffineEnvironment.transform 14 2081 env19706 = env19708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env19706 == env19708) = true)

theorem identity19708 : scanCanonicalize (H12AffineFastState.compose env19708 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound19708 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19709 : List Nat := [2,4,8,16,32,16,57,5,48,21,17,1,25,1,48,51,0,16,21,49,0,1,17,2,40,16,16,1,0,17,20,0,5,16,1,48]

theorem envBound19709 : H12AffineFastState.Bounded env19709 := by
  intro p hp
  have h : env19709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19708_19709 : H12AffineEnvironment.transform 10 17 env19708 = env19709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env19708 == env19709) = true)

def env19710 : List Nat := [2,4,8,16,0,16,25,5,16,21,17,1,25,1,16,19,0,16,21,17,0,1,17,2,8,16,16,1,0,17,20,0,5,16,1,16]

theorem envBound19710 : H12AffineFastState.Bounded env19710 := by
  intro p hp
  have h : env19710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19709_19710 : H12AffineEnvironment.transform 4 0 env19709 = env19710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19709 == env19710) = true)

theorem identity19710 : scanCanonicalize (H12AffineFastState.compose env19710 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19711 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,1,9,1,0,3,0,0,5,1,0,1,1,2,8,0,0,1,0,1,4,0,5,0,1,0]

theorem envBound19711 : H12AffineFastState.Bounded env19711 := by
  intro p hp
  have h : env19711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19710_19711 : H12AffineEnvironment.transform 3 0 env19710 = env19711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19710 == env19711) = true)

def leafEnv19711 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,1,9,1,0,3,0,0,5,1,0,1,1,2,5,8,1,0,0,1,0,1,4,0,5,0,5,3,1,0,0,0,1]

def active19711 : List Nat := [0,1,2]

def tree19711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19711 : H12WitnessSearch.Good tree19711 := H12GlobalWitnessIndex.good

theorem leafIdentity19711 : H12AffineFastState.composeSystem env19711 rootObs = leafEnv19711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19711 rootObs == leafEnv19711) = true)

theorem terminalChecked19711 : H12PackedTerminal.terminalCheckFast leafEnv19711 active19711 tree19711 = true := by decide +kernel

def env19712 : List Nat := [2,4,8,16,1,16,24,5,17,21,17,1,25,1,17,18,0,16,21,16,0,1,17,2,9,16,16,1,0,17,20,0,5,16,1,17]

theorem envBound19712 : H12AffineFastState.Bounded env19712 := by
  intro p hp
  have h : env19712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19709_19712 : H12AffineEnvironment.transform 4 1 env19709 = env19712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19709 == env19712) = true)

def env19713 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,161,1,32768,138,0,34953,21,32769,0,32905,17,32907,41,16,2049,1,0,34952,20,1,5,169,1,137]

theorem envBound19713 : H12AffineFastState.Bounded env19713 := by
  intro p hp
  have h : env19713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19704_19713 : H12AffineEnvironment.transform 12 161 env19704 = env19713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env19704 == env19713) = true)

theorem identity19713 : scanCanonicalize (H12AffineFastState.compose env19713 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 16) := by decide +kernel

theorem selectedBound19713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19714 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,161,1,16,138,0,2201,21,17,0,153,17,155,41,16,2049,1,0,2200,20,1,5,169,1,137]

theorem envBound19714 : H12AffineFastState.Bounded env19714 := by
  intro p hp
  have h : env19714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19713_19714 : H12AffineEnvironment.transform 14 16 env19713 = env19714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16 env19713 == env19714) = true)

def env19715 : List Nat := [2,4,8,16,32,16,128,5,137,21,48,1,161,1,16,138,0,169,21,17,0,153,17,155,41,16,49,1,0,168,20,1,5,169,1,137]

theorem envBound19715 : H12AffineFastState.Bounded env19715 := by
  intro p hp
  have h : env19715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19714_19715 : H12AffineEnvironment.transform 10 48 env19714 = env19715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env19714 == env19715) = true)

def env19716 : List Nat := [2,4,8,16,32,16,128,5,137,21,49,1,161,1,16,138,0,168,21,17,0,153,17,155,41,16,48,1,0,169,20,1,5,169,1,137]

theorem envBound19716 : H12AffineFastState.Bounded env19716 := by
  intro p hp
  have h : env19716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19714_19716 : H12AffineEnvironment.transform 10 49 env19714 = env19716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19714 == env19716) = true)

theorem identity19716 : scanCanonicalize (H12AffineFastState.compose env19716 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound19716 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19717 : List Nat := [2,4,8,16,32,16,24,5,17,21,49,1,57,1,16,18,0,48,21,17,0,1,17,3,41,16,48,1,0,49,20,1,5,49,1,17]

theorem envBound19717 : H12AffineFastState.Bounded env19717 := by
  intro p hp
  have h : env19717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19716_19717 : H12AffineEnvironment.transform 6 24 env19716 = env19717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env19716 == env19717) = true)

def env19718 : List Nat := [2,4,8,16,0,16,24,5,17,21,17,1,25,1,16,18,0,16,21,17,0,1,17,3,9,16,16,1,0,17,20,1,5,17,1,17]

theorem envBound19718 : H12AffineFastState.Bounded env19718 := by
  intro p hp
  have h : env19718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19717_19718 : H12AffineEnvironment.transform 4 0 env19717 = env19718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19717 == env19718) = true)

theorem identity19718 : scanCanonicalize (H12AffineFastState.compose env19718 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19719 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,1,9,1,0,2,0,0,5,1,0,1,1,3,9,0,0,1,0,1,4,1,5,1,1,1]

theorem envBound19719 : H12AffineFastState.Bounded env19719 := by
  intro p hp
  have h : env19719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19718_19719 : H12AffineEnvironment.transform 3 0 env19718 = env19719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19718 == env19719) = true)

def leafEnv19719 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,1,9,1,0,2,0,0,5,1,0,1,1,3,5,9,1,0,0,1,0,1,4,1,5,1,5,3,1,1,0,0,1]

def active19719 : List Nat := [0,1,2]

def tree19719 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19719 : H12WitnessSearch.Good tree19719 := H12GlobalWitnessIndex.good

theorem leafIdentity19719 : H12AffineFastState.composeSystem env19719 rootObs = leafEnv19719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19719 rootObs == leafEnv19719) = true)

theorem terminalChecked19719 : H12PackedTerminal.terminalCheckFast leafEnv19719 active19719 tree19719 = true := by decide +kernel

def env19720 : List Nat := [2,4,8,16,1,16,24,5,17,21,16,1,24,1,16,18,0,17,21,17,0,1,17,3,8,16,17,1,0,16,20,1,5,16,1,17]

theorem envBound19720 : H12AffineFastState.Bounded env19720 := by
  intro p hp
  have h : env19720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19717_19720 : H12AffineEnvironment.transform 4 1 env19717 = env19720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19717 == env19720) = true)

def env19721 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,398,0,43681,273,32769,0,4194304,16,32906,8328,16,4238245,1,0,43049,21,4227585,256,545,1,512]

theorem envBound19721 : H12AffineFastState.Bounded env19721 := by
  intro p hp
  have h : env19721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19700_19721 : H12AffineEnvironment.transform 5 17 env19700 = env19721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19700 == env19721) = true)

theorem identity19721 : scanCanonicalize (H12AffineFastState.compose env19721 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 270) := by decide +kernel

theorem selectedBound19721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19722 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,398,0,43681,273,32769,0,270,16,32906,8328,16,43691,1,0,43049,21,33551,256,545,1,512]

theorem envBound19722 : H12AffineFastState.Bounded env19722 := by
  intro p hp
  have h : env19722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19721_19722 : H12AffineEnvironment.transform 21 270 env19721 = env19722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270 env19721 == env19722) = true)

theorem identity19722 : scanCanonicalize (H12AffineFastState.compose env19722 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound19722 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19723 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,9093,398,0,2340,273,9092,0,270,16,8975,8328,16,2350,1,0,2988,21,8330,256,545,1,512]

theorem envBound19723 : H12AffineFastState.Bounded env19723 := by
  intro p hp
  have h : env19723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19722_19723 : H12AffineEnvironment.transform 14 9093 env19722 = env19723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env19722 == env19723) = true)

theorem identity19723 : scanCanonicalize (H12AffineFastState.compose env19723 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19723 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19724 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,1,648,398,0,2340,273,649,0,270,16,514,389,16,2350,1,0,2988,21,391,256,545,1,512]

theorem envBound19724 : H12AffineFastState.Bounded env19724 := by
  intro p hp
  have h : env19724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19723_19724 : H12AffineEnvironment.transform 12 269 env19723 = env19724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19723 == env19724) = true)

theorem identity19724 : scanCanonicalize (H12AffineFastState.compose env19724 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 422) := by decide +kernel

theorem selectedBound19724 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19725 : List Nat := [2,4,8,16,32,17,128,256,422,273,2048,1,269,1,302,398,0,2340,273,303,0,270,16,420,389,16,2350,1,0,2058,21,391,256,391,1,422]

theorem envBound19725 : H12AffineFastState.Bounded env19725 := by
  intro p hp
  have h : env19725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19724_19725 : H12AffineEnvironment.transform 8 422 env19724 = env19725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 422 env19724 == env19725) = true)

theorem identity19725 : scanCanonicalize (H12AffineFastState.compose env19725 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound19725 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19726 : List Nat := [2,4,8,16,32,17,128,47,137,62,2048,1,34,1,1,161,0,2059,62,0,0,33,16,139,170,16,2049,1,0,2058,21,168,47,168,1,137]

theorem envBound19726 : H12AffineFastState.Bounded env19726 := by
  intro p hp
  have h : env19726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19725_19726 : H12AffineEnvironment.transform 7 47 env19725 = env19726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env19725 == env19726) = true)

theorem identity19726 : scanCanonicalize (H12AffineFastState.compose env19726 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19727 : List Nat := [2,4,8,16,27,17,128,20,137,5,2048,1,25,1,1,154,0,2059,5,0,0,26,16,139,145,16,2049,1,0,2058,21,147,20,147,1,137]

theorem envBound19727 : H12AffineFastState.Bounded env19727 := by
  intro p hp
  have h : env19727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19726_19727 : H12AffineEnvironment.transform 4 27 env19726 = env19727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19726 == env19727) = true)

def env19728 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,262144,321,32769,1,4194304,65,98564,8328,16,4456708,0,1,43049,69,4294967296,256,4299260334,0,512]

theorem envBound19728 : H12AffineFastState.Bounded env19728 := by
  intro p hp
  have h : env19728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19696_19728 : H12AffineEnvironment.transform 9 321 env19696 = env19728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env19696 == env19728) = true)

theorem identity19728 : scanCanonicalize (H12AffineFastState.compose env19728 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound19728 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19729 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,10360,321,32769,1,4194304,65,98564,8328,16,4204924,0,1,43049,69,4294967296,256,4299260334,0,512]

theorem envBound19729 : H12AffineFastState.Bounded env19729 := by
  intro p hp
  have h : env19729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19728_19729 : H12AffineEnvironment.transform 17 10360 env19728 = env19729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env19728 == env19729) = true)

theorem identity19729 : scanCanonicalize (H12AffineFastState.compose env19729 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 9204) := by decide +kernel

theorem selectedBound19729 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19730 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,10360,321,32769,1,9204,65,98564,8328,16,2696,0,1,43049,69,4294967296,256,4295074394,0,512]

theorem envBound19730 : H12AffineFastState.Bounded env19730 := by
  intro p hp
  have h : env19730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19729_19730 : H12AffineEnvironment.transform 21 9204 env19729 = env19730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9204 env19729 == env19730) = true)

theorem identity19730 : scanCanonicalize (H12AffineFastState.compose env19730 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 107171) := by decide +kernel

theorem selectedBound19730 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env19731 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,10360,321,32769,1,9204,65,98564,8328,16,2696,0,1,43049,69,107171,256,249,0,512]

theorem envBound19731 : H12AffineFastState.Bounded env19731 := by
  intro p hp
  have h : env19731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19730_19731 : H12AffineEnvironment.transform 31 107171 env19730 = env19731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 107171 env19730 == env19731) = true)

def env19732 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,32768,65536,1,10280,273,32769,1,9124,17,98564,8328,16,2696,0,1,43049,21,107171,256,169,0,512]

theorem envBound19732 : H12AffineFastState.Bounded env19732 := by
  intro p hp
  have h : env19732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19731_19732 : H12AffineEnvironment.transform 5 16 env19731 = env19732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19731 == env19732) = true)

theorem identity19732 : scanCanonicalize (H12AffineFastState.compose env19732 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19733 : List Nat := [2,4,8,16,32,16,128,5,512,20,2048,0,8192,0,32768,65536,1,10280,20,32769,1,8865,17,98305,8328,16,2696,0,1,43049,21,107171,5,169,0,512]

theorem envBound19733 : H12AffineFastState.Bounded env19733 := by
  intro p hp
  have h : env19733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19732_19733 : H12AffineEnvironment.transform 7 5 env19732 = env19733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19732 == env19733) = true)

theorem identity19733 : scanCanonicalize (H12AffineFastState.compose env19733 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 649) := by decide +kernel

theorem selectedBound19733 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19734 : List Nat := [2,4,8,16,32,16,128,5,512,20,2048,0,8192,0,649,65536,1,10280,20,648,1,8865,17,66184,8328,16,2696,0,1,10912,21,73770,5,169,0,512]

theorem envBound19734 : H12AffineFastState.Bounded env19734 := by
  intro p hp
  have h : env19734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19733_19734 : H12AffineEnvironment.transform 14 649 env19733 = env19734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 649 env19733 == env19734) = true)

theorem identity19734 : scanCanonicalize (H12AffineFastState.compose env19734 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19734 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19735 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8192,0,0,65536,1,10280,20,1,1,8232,17,65537,8328,16,2049,0,1,10281,21,73770,5,169,0,137]

theorem envBound19735 : H12AffineFastState.Bounded env19735 := by
  intro p hp
  have h : env19735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19734_19735 : H12AffineEnvironment.transform 8 137 env19734 = env19735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19734 == env19735) = true)

def env19736 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8,0,0,65536,1,2080,20,1,1,32,17,65537,128,16,2049,0,1,2081,21,65570,5,169,0,137]

theorem envBound19736 : H12AffineFastState.Bounded env19736 := by
  intro p hp
  have h : env19736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19735_19736 : H12AffineEnvironment.transform 12 8 env19735 = env19736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env19735 == env19736) = true)

theorem identity19736 : scanCanonicalize (H12AffineFastState.compose env19736 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound19736 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19737 : List Nat := [2,4,8,16,32,16,57,5,48,20,2048,0,8,0,0,65536,1,2080,20,1,1,32,17,65537,57,16,2049,0,1,2081,21,65570,5,16,0,48]

theorem envBound19737 : H12AffineFastState.Bounded env19737 := by
  intro p hp
  have h : env19737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19736_19737 : H12AffineEnvironment.transform 6 57 env19736 = env19737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env19736 == env19737) = true)

theorem identity19737 : scanCanonicalize (H12AffineFastState.compose env19737 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound19737 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19738 : List Nat := [2,4,8,16,32,16,57,5,48,20,2048,0,8,0,0,51,1,2080,20,1,1,32,17,50,57,16,2049,0,1,2081,21,17,5,16,0,48]

theorem envBound19738 : H12AffineFastState.Bounded env19738 := by
  intro p hp
  have h : env19738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19737_19738 : H12AffineEnvironment.transform 15 51 env19737 = env19738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env19737 == env19738) = true)

def env19739 : List Nat := [2,4,8,16,32,16,57,5,48,20,0,0,8,0,0,51,1,32,20,1,1,32,17,50,57,16,1,0,1,33,21,17,5,16,0,48]

theorem envBound19739 : H12AffineFastState.Bounded env19739 := by
  intro p hp
  have h : env19739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19738_19739 : H12AffineEnvironment.transform 10 0 env19738 = env19739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19738 == env19739) = true)

theorem identity19739 : scanCanonicalize (H12AffineFastState.compose env19739 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19740 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,0,8,0,0,18,1,1,20,1,1,1,17,19,24,16,1,0,1,0,21,17,5,16,0,17]

theorem envBound19740 : H12AffineFastState.Bounded env19740 := by
  intro p hp
  have h : env19740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19739_19740 : H12AffineEnvironment.transform 4 1 env19739 = env19740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19739 == env19740) = true)

def leafEnv19740 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,0,8,0,0,18,1,1,20,1,1,1,17,19,20,24,1,16,1,0,1,0,21,17,5,16,5,3,0,17,0,1,1]

def active19740 : List Nat := [0,1,2,3]

def tree19740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19740 : H12WitnessSearch.Good tree19740 := H12GlobalWitnessIndex.good

theorem leafIdentity19740 : H12AffineFastState.composeSystem env19740 rootObs = leafEnv19740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19740 rootObs == leafEnv19740) = true)

theorem terminalChecked19740 : H12PackedTerminal.terminalCheckFast leafEnv19740 active19740 tree19740 = true := by decide +kernel

def env19741 : List Nat := [2,4,8,16,32,16,57,5,48,20,1,0,8,0,0,51,1,33,20,1,1,32,17,50,57,16,0,0,1,32,21,17,5,16,0,48]

theorem envBound19741 : H12AffineFastState.Bounded env19741 := by
  intro p hp
  have h : env19741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19738_19741 : H12AffineEnvironment.transform 10 1 env19738 = env19741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19738 == env19741) = true)

def env19742 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,9,0,0,65536,1,2081,20,1,1,33,17,65537,129,16,2049,0,1,2080,21,65571,5,169,0,137]

theorem envBound19742 : H12AffineFastState.Bounded env19742 := by
  intro p hp
  have h : env19742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19735_19742 : H12AffineEnvironment.transform 12 9 env19735 = env19742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env19735 == env19742) = true)

theorem identity19742 : scanCanonicalize (H12AffineFastState.compose env19742 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound19742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19743 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,9,0,0,154,1,2081,20,1,1,33,17,155,129,16,2049,0,1,2080,21,185,5,169,0,137]

theorem envBound19743 : H12AffineFastState.Bounded env19743 := by
  intro p hp
  have h : env19743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19742_19743 : H12AffineEnvironment.transform 15 154 env19742 = env19743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env19742 == env19743) = true)

def env19744 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,65536,1,10281,272,32769,1,9125,16,98564,8328,16,2696,0,1,43049,20,107171,256,168,0,512]

theorem envBound19744 : H12AffineFastState.Bounded env19744 := by
  intro p hp
  have h : env19744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19731_19744 : H12AffineEnvironment.transform 5 17 env19731 = env19744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19731 == env19744) = true)

theorem identity19744 : scanCanonicalize (H12AffineFastState.compose env19744 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 683) := by decide +kernel

theorem selectedBound19744 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19745 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,683,0,32768,65536,1,2690,272,32769,1,270,16,98564,547,16,2696,0,1,35458,20,98312,256,168,0,512]

theorem envBound19745 : H12AffineFastState.Bounded env19745 := by
  intro p hp
  have h : env19745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19744_19745 : H12AffineEnvironment.transform 12 683 env19744 = env19745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 683 env19744 == env19745) = true)

theorem identity19745 : scanCanonicalize (H12AffineFastState.compose env19745 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 935) := by decide +kernel

theorem selectedBound19745 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19746 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,683,0,935,65536,1,2690,272,934,1,270,16,66211,547,16,2696,0,1,2341,20,66479,256,168,0,512]

theorem envBound19746 : H12AffineFastState.Bounded env19746 := by
  intro p hp
  have h : env19746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19745_19746 : H12AffineEnvironment.transform 14 935 env19745 = env19746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 935 env19745 == env19746) = true)

theorem identity19746 : scanCanonicalize (H12AffineFastState.compose env19746 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 161) := by decide +kernel

theorem selectedBound19746 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19747 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,683,0,935,161,1,2690,272,934,1,270,16,514,547,16,2696,0,1,2341,20,782,256,168,0,512]

theorem envBound19747 : H12AffineFastState.Bounded env19747 := by
  intro p hp
  have h : env19747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19746_19747 : H12AffineEnvironment.transform 15 161 env19746 = env19747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 161 env19746 == env19747) = true)

def env19748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21857280,16385,676864,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound19748 : H12AffineFastState.Bounded env19748 := by
  intro p hp
  have h : env19748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19471_19748 : H12AffineEnvironment.transform 22 147521 env19471 = env19748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env19471 == env19748) = true)

theorem identity19748 : scanCanonicalize (H12AffineFastState.compose env19748 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound19748 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env19749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,230469,8328,672784,5111877,16385,676864,1073741824,131140,4294967296,257,4299392239,1344,512]

theorem envBound19749 : H12AffineFastState.Bounded env19749 := by
  intro p hp
  have h : env19749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19748_19749 : H12AffineEnvironment.transform 23 230469 env19748 = env19749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env19748 == env19749) = true)

def env19750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10248,147521,230469,8328,672784,927821,16385,676864,1073741824,131140,4294967296,257,4295208167,1344,512]

theorem envBound19750 : H12AffineFastState.Bounded env19750 := by
  intro p hp
  have h : env19750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19749_19750 : H12AffineEnvironment.transform 21 10248 env19749 = env19750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env19749 == env19750) = true)

def env19751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,147521,230469,8328,672784,925773,16385,676864,1073741824,131140,4294967296,257,4295206119,1344,512]

theorem envBound19751 : H12AffineFastState.Bounded env19751 := by
  intro p hp
  have h : env19751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19750_19751 : H12AffineEnvironment.transform 10 0 env19750 = env19751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19750 == env19751) = true)

def env19752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98565,8328,541008,795917,16385,545088,1073741824,1284,4294967296,257,4295074215,1344,512]

theorem envBound19752 : H12AffineFastState.Bounded env19752 := by
  intro p hp
  have h : env19752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19751_19752 : H12AffineEnvironment.transform 16 1344 env19751 = env19752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19751 == env19752) = true)

theorem identity19752 : scanCanonicalize (H12AffineFastState.compose env19752 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 295285) := by decide +kernel

theorem selectedBound19752 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98565,8328,541008,795917,16385,545088,295285,1284,4294967296,257,4295074215,1344,512]

theorem envBound19753 : H12AffineFastState.Bounded env19753 := by
  intro p hp
  have h : env19753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19752_19753 : H12AffineEnvironment.transform 29 295285 env19752 = env19753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295285 env19752 == env19753) = true)

theorem identity19753 : scanCanonicalize (H12AffineFastState.compose env19753 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound19753 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env19754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8200,17665,98565,8328,17745,270604,16385,21825,295285,1284,4294967296,257,4295074215,1344,512]

theorem envBound19754 : H12AffineFastState.Bounded env19754 := by
  intro p hp
  have h : env19754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19753_19754 : H12AffineEnvironment.transform 18 1025 env19753 = env19754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19753 == env19754) = true)

theorem identity19754 : scanCanonicalize (H12AffineFastState.compose env19754 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74231) := by decide +kernel

theorem selectedBound19754 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env19755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,74231,1025,32769,4097,8200,17665,98565,8328,17745,65787,16385,21825,106626,1284,4294967296,257,4295074215,1344,512]

theorem envBound19755 : H12AffineFastState.Bounded env19755 := by
  intro p hp
  have h : env19755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19754_19755 : H12AffineEnvironment.transform 17 74231 env19754 = env19755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74231 env19754 == env19755) = true)

theorem identity19755 : scanCanonicalize (H12AffineFastState.compose env19755 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound19755 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,65536,1344,74231,1025,32769,4097,8200,5457,98565,8328,5377,65787,4177,1297,106626,1284,4294967296,257,4295074215,1344,512]

theorem envBound19756 : H12AffineFastState.Bounded env19756 := by
  intro p hp
  have h : env19756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19755_19756 : H12AffineEnvironment.transform 13 4176 env19755 = env19756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env19755 == env19756) = true)

theorem identity19756 : scanCanonicalize (H12AffineFastState.compose env19756 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound19756 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,65536,1344,74231,1025,32769,4097,8200,5457,98565,8328,5377,65787,4177,1297,106626,1284,8320,257,98599,1344,512]

theorem envBound19757 : H12AffineFastState.Bounded env19757 := by
  intro p hp
  have h : env19757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19756_19757 : H12AffineEnvironment.transform 31 8320 env19756 = env19757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env19756 == env19757) = true)

theorem identity19757 : scanCanonicalize (H12AffineFastState.compose env19757 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19757 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env19758 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4097,32768,65536,1297,74150,1025,32769,4097,8200,5376,98565,8328,5377,65706,4096,1297,106626,1284,8320,257,98599,1297,512]

theorem envBound19758 : H12AffineFastState.Bounded env19758 := by
  intro p hp
  have h : env19758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19757_19758 : H12AffineEnvironment.transform 5 17 env19757 = env19758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19757 == env19758) = true)

theorem identity19758 : scanCanonicalize (H12AffineFastState.compose env19758 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 13714) := by decide +kernel

theorem selectedBound19758 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19759 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4097,32768,13714,1297,5172,1025,32769,4097,8200,5376,46231,8328,5377,13624,4096,1297,38160,1284,8320,257,46261,1297,512]

theorem envBound19759 : H12AffineFastState.Bounded env19759 := by
  intro p hp
  have h : env19759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19758_19759 : H12AffineEnvironment.transform 15 13714 env19758 = env19759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13714 env19758 == env19759) = true)

theorem identity19759 : scanCanonicalize (H12AffineFastState.compose env19759 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound19759 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env19760 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4097,136,13714,1297,5172,1025,137,4097,8200,5376,13343,8328,5377,13624,4096,1297,5528,1284,8320,257,13373,1297,512]

theorem envBound19760 : H12AffineFastState.Bounded env19760 := by
  intro p hp
  have h : env19760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19759_19760 : H12AffineEnvironment.transform 14 136 env19759 = env19760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env19759 == env19760) = true)

theorem identity19760 : scanCanonicalize (H12AffineFastState.compose env19760 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound19760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19761 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1465,8192,1464,136,8235,1297,397,1025,137,1464,8200,185,8614,8328,184,8321,1465,1297,33,1284,8320,257,8580,1297,512]

theorem envBound19761 : H12AffineFastState.Bounded env19761 := by
  intro p hp
  have h : env19761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19760_19761 : H12AffineEnvironment.transform 11 1465 env19760 = env19761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env19760 == env19761) = true)

theorem identity19761 : scanCanonicalize (H12AffineFastState.compose env19761 (packedSelected [1,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19761 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env19762 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1465,389,1464,136,430,1297,397,1025,137,1464,397,185,35,269,184,260,1465,1297,33,1284,261,257,1,1297,512]

theorem envBound19762 : H12AffineFastState.Bounded env19762 := by
  intro p hp
  have h : env19762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19761_19762 : H12AffineEnvironment.transform 12 389 env19761 = env19762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19761 == env19762) = true)

theorem identity19762 : scanCanonicalize (H12AffineFastState.compose env19762 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound19762 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19763 : List Nat := [2,4,8,16,32,17,128,256,309,1024,0,1465,389,1464,136,430,1297,397,1025,137,1464,397,185,35,269,184,260,1465,1297,33,1284,261,257,1,1297,309]

theorem envBound19763 : H12AffineFastState.Bounded env19763 := by
  intro p hp
  have h : env19763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19762_19763 : H12AffineEnvironment.transform 8 309 env19762 = env19763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env19762 == env19763) = true)

theorem identity19763 : scanCanonicalize (H12AffineFastState.compose env19763 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound19763 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env19764 : List Nat := [2,4,8,16,32,17,128,156,169,1024,0,1061,25,1060,136,50,1165,17,1025,137,1060,17,185,35,145,184,152,1061,1165,33,1176,153,157,1,1165,169]

theorem envBound19764 : H12AffineFastState.Bounded env19764 := by
  intro p hp
  have h : env19764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19763_19764 : H12AffineEnvironment.transform 7 156 env19763 = env19764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env19763 == env19764) = true)

theorem identity19764 : scanCanonicalize (H12AffineFastState.compose env19764 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound19764 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19765 : List Nat := [2,4,8,16,32,17,41,53,0,1024,0,1061,25,1060,33,50,1060,17,1025,32,1060,17,16,35,56,17,49,1061,1060,33,1073,48,52,1,1060,0]

theorem envBound19765 : H12AffineFastState.Bounded env19765 := by
  intro p hp
  have h : env19765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19764_19765 : H12AffineEnvironment.transform 6 41 env19764 = env19765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env19764 == env19765) = true)

theorem identity19765 : scanCanonicalize (H12AffineFastState.compose env19765 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19766 : List Nat := [2,4,8,1,32,0,41,36,0,1024,0,1061,8,1060,33,35,1060,0,1025,32,1060,0,1,35,41,0,32,1061,1060,33,1056,33,37,1,1060,0]

theorem envBound19766 : H12AffineFastState.Bounded env19766 := by
  intro p hp
  have h : env19766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19765_19766 : H12AffineEnvironment.transform 3 1 env19765 = env19766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19765 == env19766) = true)

theorem identity19766 : scanCanonicalize (H12AffineFastState.compose env19766 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19767 : List Nat := [2,4,8,1,0,0,9,4,0,1024,0,1029,8,1028,1,3,1028,0,1025,0,1028,0,1,3,9,0,0,1029,1028,1,1024,1,5,1,1028,0]

theorem envBound19767 : H12AffineFastState.Bounded env19767 := by
  intro p hp
  have h : env19767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19766_19767 : H12AffineEnvironment.transform 4 0 env19766 = env19767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19766 == env19767) = true)

theorem identity19767 : scanCanonicalize (H12AffineFastState.compose env19767 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound19767 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19768 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,0,1,3,0,0,5,0,0,0,1,3,9,0,0,1,0,1,4,1,5,1,0,0]

theorem envBound19768 : H12AffineFastState.Bounded env19768 := by
  intro p hp
  have h : env19768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19767_19768 : H12AffineEnvironment.transform 9 4 env19767 = env19768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env19767 == env19768) = true)

def env19769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541009,795916,16385,545089,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound19769 : H12AffineFastState.Bounded env19769 := by
  intro p hp
  have h : env19769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19751_19769 : H12AffineEnvironment.transform 16 1345 env19751 = env19769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env19751 == env19769) = true)

theorem identity19769 : scanCanonicalize (H12AffineFastState.compose env19769 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 295204) := by decide +kernel

theorem selectedBound19769 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541009,795916,16385,545089,295204,1285,4294967296,257,4295074214,1344,512]

theorem envBound19770 : H12AffineFastState.Bounded env19770 := by
  intro p hp
  have h : env19770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19769_19770 : H12AffineEnvironment.transform 29 295204 env19769 = env19770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295204 env19769 == env19770) = true)

theorem identity19770 : scanCanonicalize (H12AffineFastState.compose env19770 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 304168) := by decide +kernel

theorem selectedBound19770 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8200,17664,98564,8328,320889,33060,16385,324969,295204,1285,4294967296,257,4295074214,1344,512]

theorem envBound19771 : H12AffineFastState.Bounded env19771 := by
  intro p hp
  have h : env19771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19770_19771 : H12AffineEnvironment.transform 18 304168 env19770 = env19771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env19770 == env19771) = true)

def env19772 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8200,17664,98564,8328,320889,33060,16385,324969,295204,1285,4294967296,257,4295074214,1344,136]

theorem envBound19772 : H12AffineFastState.Bounded env19772 := by
  intro p hp
  have h : env19772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19771_19772 : H12AffineEnvironment.transform 8 136 env19771 = env19772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19771 == env19772) = true)

def env19773 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,16384,32768,65536,1345,0,42024,32769,4097,8200,17664,98564,8328,58745,33060,16385,62825,33060,1285,4294967296,257,4295074214,1344,136]

theorem envBound19773 : H12AffineFastState.Bounded env19773 := by
  intro p hp
  have h : env19773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19772_19773 : H12AffineEnvironment.transform 17 0 env19772 = env19773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env19772 == env19773) = true)

def env19774 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,16384,32768,65536,1345,0,42024,32769,1297,8200,17664,98564,8328,58745,33060,16385,57465,33060,1285,4294967296,257,4295074214,1344,136]

theorem envBound19774 : H12AffineFastState.Bounded env19774 := by
  intro p hp
  have h : env19774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19773_19774 : H12AffineEnvironment.transform 11 1296 env19773 = env19774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19773 == env19774) = true)

theorem identity19774 : scanCanonicalize (H12AffineFastState.compose env19774 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 25961) := by decide +kernel

theorem selectedBound19774 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19775 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,16384,25961,65536,1345,0,16705,25960,1297,8200,17664,91245,8328,16,25677,16385,1296,25677,1285,4294967296,257,4295050447,1344,136]

theorem envBound19775 : H12AffineFastState.Bounded env19775 := by
  intro p hp
  have h : env19775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19774_19775 : H12AffineEnvironment.transform 14 25961 env19774 = env19775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25961 env19774 == env19775) = true)

theorem identity19775 : scanCanonicalize (H12AffineFastState.compose env19775 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19775 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env19776 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,1344,8233,65536,1345,0,1025,8232,1297,8200,64,74029,8328,16,8461,1345,1296,8461,1285,4294967296,257,4295033231,1344,136]

theorem envBound19776 : H12AffineFastState.Bounded env19776 := by
  intro p hp
  have h : env19776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19775_19776 : H12AffineEnvironment.transform 13 1344 env19775 = env19776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19775 == env19776) = true)

def env19777 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1296,8192,1296,8233,65536,1297,0,1025,8232,1297,8200,16,74029,8328,16,8461,1297,1296,8461,1285,4294967296,257,4295033231,1296,136]

theorem envBound19777 : H12AffineFastState.Bounded env19777 := by
  intro p hp
  have h : env19777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19776_19777 : H12AffineEnvironment.transform 5 16 env19776 = env19777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19776 == env19777) = true)

theorem identity19777 : scanCanonicalize (H12AffineFastState.compose env19777 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound19777 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19778 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1296,8192,1296,8233,8614,1297,0,1025,8232,1297,8200,16,139,8328,16,8461,1297,1296,8461,1285,4294967296,257,4294975529,1296,136]

theorem envBound19778 : H12AffineFastState.Bounded env19778 := by
  intro p hp
  have h : env19778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19777_19778 : H12AffineEnvironment.transform 15 8614 env19777 = env19778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env19777 == env19778) = true)

theorem identity19778 : scanCanonicalize (H12AffineFastState.compose env19778 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19779 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1296,41,1296,0,399,1297,0,1025,1,1297,33,16,139,161,16,292,1297,1296,292,1285,4294967296,257,4294967296,1296,136]

theorem envBound19779 : H12AffineFastState.Bounded env19779 := by
  intro p hp
  have h : env19779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19778_19779 : H12AffineEnvironment.transform 12 41 env19778 = env19779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19778 == env19779) = true)

theorem identity19779 : scanCanonicalize (H12AffineFastState.compose env19779 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound19779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19780 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1296,41,1296,0,399,1297,0,1025,1,1297,33,16,139,161,16,292,1297,1296,292,1285,429,257,429,1296,136]

theorem envBound19780 : H12AffineFastState.Bounded env19780 := by
  intro p hp
  have h : env19780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19779_19780 : H12AffineEnvironment.transform 31 429 env19779 = env19780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env19779 == env19780) = true)

theorem identity19780 : scanCanonicalize (H12AffineFastState.compose env19780 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19780 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19781 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,41,1076,0,171,1077,0,1025,1,1077,33,16,139,161,16,0,1077,1076,0,1057,137,37,137,1076,136]

theorem envBound19781 : H12AffineFastState.Bounded env19781 := by
  intro p hp
  have h : env19781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19780_19781 : H12AffineEnvironment.transform 7 36 env19780 = env19781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19780 == env19781) = true)

theorem identity19781 : scanCanonicalize (H12AffineFastState.compose env19781 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19781 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19782 : List Nat := [2,4,8,16,32,16,8,36,0,1024,0,1076,41,1076,0,35,1077,0,1025,1,1077,33,16,3,41,16,0,1077,1076,0,1057,1,37,1,1076,0]

theorem envBound19782 : H12AffineFastState.Bounded env19782 := by
  intro p hp
  have h : env19782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19781_19782 : H12AffineEnvironment.transform 6 8 env19781 = env19782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19781 == env19782) = true)

def leafEnv19782 : List Nat := [2,4,8,16,32,16,8,36,0,1024,0,1076,41,1076,0,35,1077,0,1025,1,1077,33,16,3,1056,41,1,16,0,1077,1076,0,1057,1,37,1,5,34,1076,0,0,1077,1]

def active19782 : List Nat := [0,1,2,3,4,9]

def tree19782 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19782 : H12WitnessSearch.Good tree19782 := H12GlobalWitnessIndex.good

theorem leafIdentity19782 : H12AffineFastState.composeSystem env19782 rootObs = leafEnv19782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19782 rootObs == leafEnv19782) = true)

theorem terminalChecked19782 : H12PackedTerminal.terminalCheckFast leafEnv19782 active19782 tree19782 = true := by decide +kernel

def env19783 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1296,8192,1297,8233,65536,1296,0,1025,8232,1297,8200,17,74029,8328,16,8461,1296,1296,8461,1285,4294967296,257,4295033231,1297,136]

theorem envBound19783 : H12AffineFastState.Bounded env19783 := by
  intro p hp
  have h : env19783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19776_19783 : H12AffineEnvironment.transform 5 17 env19776 = env19783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19776 == env19783) = true)

def env19784 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,0,8192,1,8233,65536,0,0,273,8232,1,8200,17,74029,8328,16,8461,0,0,8461,21,4294967296,257,4295033231,1,136]

theorem envBound19784 : H12AffineFastState.Bounded env19784 := by
  intro p hp
  have h : env19784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19783_19784 : H12AffineEnvironment.transform 9 272 env19783 = env19784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19783 == env19784) = true)

theorem identity19784 : scanCanonicalize (H12AffineFastState.compose env19784 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19785 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,0,8192,1,8233,170,0,0,273,8232,1,8200,17,8583,8328,16,8461,0,0,8461,21,4294967296,257,4294967589,1,136]

theorem envBound19785 : H12AffineFastState.Bounded env19785 := by
  intro p hp
  have h : env19785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19784_19785 : H12AffineEnvironment.transform 15 170 env19784 = env19785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19784 == env19785) = true)

def env19786 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,8192,1,8233,34,0,0,273,8232,1,8200,17,8463,8192,16,8461,0,0,8461,21,4294967296,257,4294967589,1,0]

theorem envBound19786 : H12AffineFastState.Bounded env19786 := by
  intro p hp
  have h : env19786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19785_19786 : H12AffineEnvironment.transform 6 8 env19785 = env19786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19785 == env19786) = true)

theorem identity19786 : scanCanonicalize (H12AffineFastState.compose env19786 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19787 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,8192,1,8233,34,0,0,273,8232,1,8200,17,8463,8192,16,8461,0,0,8461,21,0,257,293,1,0]

theorem envBound19787 : H12AffineFastState.Bounded env19787 := by
  intro p hp
  have h : env19787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19786_19787 : H12AffineEnvironment.transform 31 0 env19786 = env19787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19786 == env19787) = true)

def env19788 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,40,1,1,34,0,0,273,0,1,32,17,295,40,16,293,0,0,293,21,0,257,293,1,0]

theorem envBound19788 : H12AffineFastState.Bounded env19788 := by
  intro p hp
  have h : env19788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19787_19788 : H12AffineEnvironment.transform 12 40 env19787 = env19788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19787 == env19788) = true)

theorem identity19788 : scanCanonicalize (H12AffineFastState.compose env19788 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19789 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,8,1,1,2,0,0,273,0,1,0,17,263,8,16,261,0,0,261,21,0,257,261,1,0]

theorem envBound19789 : H12AffineFastState.Bounded env19789 := by
  intro p hp
  have h : env19789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19788_19789 : H12AffineEnvironment.transform 4 0 env19788 = env19789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19788 == env19789) = true)

theorem identity19789 : scanCanonicalize (H12AffineFastState.compose env19789 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19789 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19790 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,0,8,1,1,2,0,0,20,0,1,0,17,2,8,16,0,0,0,0,21,0,4,0,1,0]

theorem envBound19790 : H12AffineFastState.Bounded env19790 := by
  intro p hp
  have h : env19790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19789_19790 : H12AffineEnvironment.transform 7 5 env19789 = env19790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19789 == env19790) = true)

def leafEnv19790 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,0,8,1,1,2,0,0,20,0,1,0,17,2,20,8,1,16,0,0,0,0,21,0,4,0,5,2,1,0,0,1,1]

def active19790 : List Nat := [0,1,2,3]

def tree19790 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19790 : H12WitnessSearch.Good tree19790 := H12GlobalWitnessIndex.good

theorem leafIdentity19790 : H12AffineFastState.composeSystem env19790 rootObs = leafEnv19790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19790 rootObs == leafEnv19790) = true)

theorem terminalChecked19790 : H12PackedTerminal.terminalCheckFast leafEnv19790 active19790 tree19790 = true := by decide +kernel

def env19791 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,41,1,0,34,0,0,273,1,1,33,17,294,41,16,292,0,0,292,21,0,257,293,1,0]

theorem envBound19791 : H12AffineFastState.Bounded env19791 := by
  intro p hp
  have h : env19791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19787_19791 : H12AffineEnvironment.transform 12 41 env19787 = env19791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19787 == env19791) = true)

theorem identity19791 : scanCanonicalize (H12AffineFastState.compose env19791 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19792 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,0,41,1,0,34,0,0,53,1,1,33,17,2,41,16,0,0,0,0,21,0,37,1,1,0]

theorem envBound19792 : H12AffineFastState.Bounded env19792 := by
  intro p hp
  have h : env19792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19791_19792 : H12AffineEnvironment.transform 7 36 env19791 = env19792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19791 == env19792) = true)

theorem identity19792 : scanCanonicalize (H12AffineFastState.compose env19792 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19792 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19793 : List Nat := [2,4,8,16,1,17,8,5,0,21,0,0,8,1,0,3,0,0,20,1,1,0,17,2,8,16,0,0,0,0,21,0,4,1,1,0]

theorem envBound19793 : H12AffineFastState.Bounded env19793 := by
  intro p hp
  have h : env19793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19792_19793 : H12AffineEnvironment.transform 4 1 env19792 = env19793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19792 == env19793) = true)

def leafEnv19793 : List Nat := [2,4,8,16,1,17,8,5,0,21,0,0,8,1,0,3,0,0,20,1,1,0,17,2,20,8,1,16,0,0,0,0,21,0,4,1,5,3,1,0,0,1,1]

def active19793 : List Nat := [0,1,2,3]

def tree19793 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19793 : H12WitnessSearch.Good tree19793 := H12GlobalWitnessIndex.good

theorem leafIdentity19793 : H12AffineFastState.composeSystem env19793 rootObs = leafEnv19793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19793 rootObs == leafEnv19793) = true)

theorem terminalChecked19793 : H12PackedTerminal.terminalCheckFast leafEnv19793 active19793 tree19793 = true := by decide +kernel

def env19794 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,8192,1,8233,35,0,0,273,8232,1,8200,17,8462,8193,16,8461,0,0,8461,21,4294967296,257,4294967589,1,1]

theorem envBound19794 : H12AffineFastState.Bounded env19794 := by
  intro p hp
  have h : env19794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19785_19794 : H12AffineEnvironment.transform 6 9 env19785 = env19794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19785 == env19794) = true)

theorem identity19794 : scanCanonicalize (H12AffineFastState.compose env19794 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound19794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19795 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,8192,1,8233,35,0,0,273,8232,1,8200,17,8462,8193,16,8461,0,0,8461,21,292,257,1,1,1]

theorem envBound19795 : H12AffineFastState.Bounded env19795 := by
  intro p hp
  have h : env19795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19794_19795 : H12AffineEnvironment.transform 31 292 env19794 = env19795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env19794 == env19795) = true)

def env19796 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,40,1,1,35,0,0,273,0,1,32,17,294,41,16,293,0,0,293,21,292,257,1,1,1]

theorem envBound19796 : H12AffineFastState.Bounded env19796 := by
  intro p hp
  have h : env19796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19795_19796 : H12AffineEnvironment.transform 12 40 env19795 = env19796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19795 == env19796) = true)

theorem identity19796 : scanCanonicalize (H12AffineFastState.compose env19796 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19797 : List Nat := [2,4,8,16,1,17,9,256,1,272,0,0,9,1,1,2,0,0,273,0,1,1,17,263,8,16,260,0,0,260,21,261,257,1,1,1]

theorem envBound19797 : H12AffineFastState.Bounded env19797 := by
  intro p hp
  have h : env19797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19796_19797 : H12AffineEnvironment.transform 4 1 env19796 = env19797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19796 == env19797) = true)

def env19798 : List Nat := [2,4,8,16,32,17,9,256,1,272,0,0,41,1,0,35,0,0,273,1,1,33,17,295,40,16,292,0,0,292,21,292,257,1,1,1]

theorem envBound19798 : H12AffineFastState.Bounded env19798 := by
  intro p hp
  have h : env19798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19795_19798 : H12AffineEnvironment.transform 12 41 env19795 = env19798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19795 == env19798) = true)

theorem identity19798 : scanCanonicalize (H12AffineFastState.compose env19798 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19799 : List Nat := [2,4,8,16,32,17,9,36,1,52,0,0,41,1,0,35,0,0,53,1,1,33,17,3,40,16,0,0,0,0,21,0,37,1,1,1]

theorem envBound19799 : H12AffineFastState.Bounded env19799 := by
  intro p hp
  have h : env19799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19798_19799 : H12AffineEnvironment.transform 7 36 env19798 = env19799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19798 == env19799) = true)

theorem identity19799 : scanCanonicalize (H12AffineFastState.compose env19799 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19799 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19800 : List Nat := [2,4,8,16,1,17,9,5,1,21,0,0,8,1,0,2,0,0,20,1,1,0,17,3,9,16,0,0,0,0,21,0,4,1,1,1]

theorem envBound19800 : H12AffineFastState.Bounded env19800 := by
  intro p hp
  have h : env19800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19799_19800 : H12AffineEnvironment.transform 4 1 env19799 = env19800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19799 == env19800) = true)

def leafEnv19800 : List Nat := [2,4,8,16,1,17,9,5,1,21,0,0,8,1,0,2,0,0,20,1,1,0,17,3,20,9,1,16,0,0,0,0,21,0,4,1,5,3,1,1,0,1,1]

def active19800 : List Nat := [0,1,2,3]

def tree19800 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19800 : H12WitnessSearch.Good tree19800 := H12GlobalWitnessIndex.good

theorem leafIdentity19800 : H12AffineFastState.composeSystem env19800 rootObs = leafEnv19800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19800 rootObs == leafEnv19800) = true)

theorem terminalChecked19800 : H12PackedTerminal.terminalCheckFast leafEnv19800 active19800 tree19800 = true := by decide +kernel

def env19801 : List Nat := [2,4,8,16,32,17,128,256,136,273,0,1,8192,0,8233,65536,1,0,272,8232,0,8200,17,74029,8328,16,8461,1,1,8461,20,4294967296,257,4295033231,0,136]

theorem envBound19801 : H12AffineFastState.Bounded env19801 := by
  intro p hp
  have h : env19801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19783_19801 : H12AffineEnvironment.transform 9 273 env19783 = env19801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19783 == env19801) = true)

theorem identity19801 : scanCanonicalize (H12AffineFastState.compose env19801 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19802 : List Nat := [2,4,8,16,32,17,128,256,136,273,0,1,268,0,293,65536,1,0,272,292,0,260,17,65569,388,16,1,1,1,1,20,4294967296,257,4295033231,0,136]

theorem envBound19802 : H12AffineFastState.Bounded env19802 := by
  intro p hp
  have h : env19802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19801_19802 : H12AffineEnvironment.transform 12 268 env19801 = env19802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19801 == env19802) = true)

def env19803 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,40,0,1,65536,1,0,52,0,0,32,17,65569,160,16,1,1,1,1,20,4294967296,37,4295033003,0,136]

theorem envBound19803 : H12AffineFastState.Bounded env19803 := by
  intro p hp
  have h : env19803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19802_19803 : H12AffineEnvironment.transform 7 36 env19802 = env19803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19802 == env19803) = true)

theorem identity19803 : scanCanonicalize (H12AffineFastState.compose env19803 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound19803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19804 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,40,0,1,65536,1,0,52,0,0,32,17,65569,160,16,1,1,1,1,20,65706,37,1,0,136]

theorem envBound19804 : H12AffineFastState.Bounded env19804 := by
  intro p hp
  have h : env19804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19803_19804 : H12AffineEnvironment.transform 31 65706 env19803 = env19804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env19803 == env19804) = true)

def env19805 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,1,40,0,1,65536,1,0,52,0,0,32,17,65569,40,16,1,1,1,1,20,65570,37,1,0,0]

theorem envBound19805 : H12AffineFastState.Bounded env19805 := by
  intro p hp
  have h : env19805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19804_19805 : H12AffineEnvironment.transform 6 8 env19804 = env19805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19804 == env19805) = true)

theorem identity19805 : scanCanonicalize (H12AffineFastState.compose env19805 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19806 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,1,65536,1,0,20,0,0,0,17,65537,8,16,1,1,1,1,20,65538,5,1,0,0]

theorem envBound19806 : H12AffineFastState.Bounded env19806 := by
  intro p hp
  have h : env19806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19805_19806 : H12AffineEnvironment.transform 4 0 env19805 = env19806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19805 == env19806) = true)

theorem identity19806 : scanCanonicalize (H12AffineFastState.compose env19806 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19806 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19807 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,1,3,1,0,20,0,0,0,17,2,8,16,1,1,1,1,20,1,5,1,0,0]

theorem envBound19807 : H12AffineFastState.Bounded env19807 := by
  intro p hp
  have h : env19807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19806_19807 : H12AffineEnvironment.transform 15 3 env19806 = env19807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19806 == env19807) = true)

def leafEnv19807 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,1,3,1,0,20,0,0,0,17,2,21,8,1,16,1,1,1,1,20,1,5,1,5,3,0,0,0,0,1]

def active19807 : List Nat := [0,1,2,3]

def tree19807 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19807 : H12WitnessSearch.Good tree19807 := H12GlobalWitnessIndex.good

theorem leafIdentity19807 : H12AffineFastState.composeSystem env19807 rootObs = leafEnv19807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19807 rootObs == leafEnv19807) = true)

theorem terminalChecked19807 : H12PackedTerminal.terminalCheckFast leafEnv19807 active19807 tree19807 = true := by decide +kernel

def env19808 : List Nat := [2,4,8,16,32,17,9,36,1,53,0,1,40,0,1,65536,1,0,52,0,0,32,17,65569,41,16,1,1,1,1,20,65571,37,1,0,1]

theorem envBound19808 : H12AffineFastState.Bounded env19808 := by
  intro p hp
  have h : env19808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19804_19808 : H12AffineEnvironment.transform 6 9 env19804 = env19808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19804 == env19808) = true)

theorem identity19808 : scanCanonicalize (H12AffineFastState.compose env19808 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19808 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19809 : List Nat := [2,4,8,16,32,17,9,36,1,53,0,1,40,0,1,2,1,0,52,0,0,32,17,35,41,16,1,1,1,1,20,33,37,1,0,1]

theorem envBound19809 : H12AffineFastState.Bounded env19809 := by
  intro p hp
  have h : env19809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19808_19809 : H12AffineEnvironment.transform 15 2 env19808 = env19809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19808 == env19809) = true)

theorem identity19809 : scanCanonicalize (H12AffineFastState.compose env19809 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19809 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19810 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,8,0,1,2,1,0,20,0,0,0,17,3,9,16,1,1,1,1,20,1,5,1,0,1]

theorem envBound19810 : H12AffineFastState.Bounded env19810 := by
  intro p hp
  have h : env19810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19809_19810 : H12AffineEnvironment.transform 4 0 env19809 = env19810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19809 == env19810) = true)

def leafEnv19810 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,8,0,1,2,1,0,20,0,0,0,17,3,21,9,1,16,1,1,1,1,20,1,5,1,5,3,0,1,0,0,1]

def active19810 : List Nat := [0,1,2,3]

def tree19810 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19810 : H12WitnessSearch.Good tree19810 := H12GlobalWitnessIndex.good

theorem leafIdentity19810 : H12AffineFastState.composeSystem env19810 rootObs = leafEnv19810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19810 rootObs == leafEnv19810) = true)

theorem terminalChecked19810 : H12PackedTerminal.terminalCheckFast leafEnv19810 active19810 tree19810 = true := by decide +kernel

def env19811 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,41,0,0,65536,1,0,53,1,0,33,17,65569,161,16,1,1,1,1,20,4294967296,36,4295033002,0,136]

theorem envBound19811 : H12AffineFastState.Bounded env19811 := by
  intro p hp
  have h : env19811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19802_19811 : H12AffineEnvironment.transform 7 37 env19802 = env19811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19802 == env19811) = true)

theorem identity19811 : scanCanonicalize (H12AffineFastState.compose env19811 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound19811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19812 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,41,0,0,65536,1,0,53,1,0,33,17,65569,161,16,1,1,1,1,20,136,36,65570,0,136]

theorem envBound19812 : H12AffineFastState.Bounded env19812 := by
  intro p hp
  have h : env19812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19811_19812 : H12AffineEnvironment.transform 31 136 env19811 = env19812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env19811 == env19812) = true)

theorem identity19812 : scanCanonicalize (H12AffineFastState.compose env19812 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19812 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19813 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,41,0,0,171,1,0,53,1,0,33,17,138,161,16,1,1,1,1,20,136,36,137,0,136]

theorem envBound19813 : H12AffineFastState.Bounded env19813 := by
  intro p hp
  have h : env19813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19812_19813 : H12AffineEnvironment.transform 15 171 env19812 = env19813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19812 == env19813) = true)

theorem identity19813 : scanCanonicalize (H12AffineFastState.compose env19813 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19813 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19814 : List Nat := [2,4,8,16,1,17,128,4,136,21,0,1,8,0,0,138,1,0,20,1,0,0,17,138,128,16,1,1,1,1,20,136,5,137,0,136]

theorem envBound19814 : H12AffineFastState.Bounded env19814 := by
  intro p hp
  have h : env19814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19813_19814 : H12AffineEnvironment.transform 4 1 env19813 = env19814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19813 == env19814) = true)

def leafEnv19814 : List Nat := [2,4,8,16,1,17,128,4,136,21,0,1,8,0,0,138,1,0,20,1,0,0,17,138,21,128,1,16,1,1,1,1,20,136,5,137,5,2,0,136,0,0,1]

def active19814 : List Nat := [0,1,2,3,6]

def tree19814 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19814 : H12WitnessSearch.Good tree19814 := H12GlobalWitnessIndex.good

theorem leafIdentity19814 : H12AffineFastState.composeSystem env19814 rootObs = leafEnv19814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19814 rootObs == leafEnv19814) = true)

theorem terminalChecked19814 : H12PackedTerminal.terminalCheckFast leafEnv19814 active19814 tree19814 = true := by decide +kernel

def env19815 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,16384,32768,65536,1345,0,42024,32769,1296,8200,17664,98564,8328,58745,33060,16385,57464,33060,1285,4294967296,257,4295074214,1344,136]

theorem envBound19815 : H12AffineFastState.Bounded env19815 := by
  intro p hp
  have h : env19815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19773_19815 : H12AffineEnvironment.transform 11 1297 env19773 = env19815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env19773 == env19815) = true)

theorem identity19815 : scanCanonicalize (H12AffineFastState.compose env19815 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 9292) := by decide +kernel

theorem selectedBound19815 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env19816 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,9292,32768,65536,1345,0,42024,32769,1296,8200,8524,98564,8328,33077,33060,9293,33844,33060,1285,4294967296,257,4295074214,1344,136]

theorem envBound19816 : H12AffineFastState.Bounded env19816 := by
  intro p hp
  have h : env19816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19815_19816 : H12AffineEnvironment.transform 13 9292 env19815 = env19816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9292 env19815 == env19816) = true)

theorem identity19816 : scanCanonicalize (H12AffineFastState.compose env19816 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound19816 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19817 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,9292,32768,8614,1345,0,42024,32769,1296,8200,8524,41122,8328,33077,33060,9293,33844,33060,1285,4294967296,257,4295000064,1344,136]

theorem envBound19817 : H12AffineFastState.Bounded env19817 := by
  intro p hp
  have h : env19817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19816_19817 : H12AffineEnvironment.transform 15 8614 env19816 = env19817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env19816 == env19817) = true)

theorem identity19817 : scanCanonicalize (H12AffineFastState.compose env19817 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound19817 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env19818 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,9292,8233,8614,1345,0,1025,8232,1296,8200,8524,139,8328,8476,8461,9293,9245,8461,1285,4294967296,257,4294975529,1344,136]

theorem envBound19818 : H12AffineFastState.Bounded env19818 := by
  intro p hp
  have h : env19818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19817_19818 : H12AffineEnvironment.transform 14 8233 env19817 = env19818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env19817 == env19818) = true)

theorem identity19818 : scanCanonicalize (H12AffineFastState.compose env19818 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19818 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19819 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,269,1345,292,171,1345,0,1025,293,1296,261,65,139,389,17,0,1344,1296,0,1285,4294967296,257,4294967588,1344,136]

theorem envBound19819 : H12AffineFastState.Bounded env19819 := by
  intro p hp
  have h : env19819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19818_19819 : H12AffineEnvironment.transform 12 269 env19818 = env19819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19818 == env19819) = true)

def env19820 : List Nat := [2,4,8,16,32,64,8,256,0,1024,0,1297,269,1345,292,35,1345,0,1025,293,1296,261,65,3,269,17,0,1344,1296,0,1285,4294967296,257,4294967588,1344,0]

theorem envBound19820 : H12AffineFastState.Bounded env19820 := by
  intro p hp
  have h : env19820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19819_19820 : H12AffineEnvironment.transform 6 8 env19819 = env19820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19819 == env19820) = true)

theorem identity19820 : scanCanonicalize (H12AffineFastState.compose env19820 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 372) := by decide +kernel

theorem selectedBound19820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19821 : List Nat := [2,4,8,16,32,64,8,256,0,1024,0,1297,269,1345,292,35,1345,0,1025,293,1296,261,65,3,269,17,0,1344,1296,0,1285,372,257,80,1344,0]

theorem envBound19821 : H12AffineFastState.Bounded env19821 := by
  intro p hp
  have h : env19821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19820_19821 : H12AffineEnvironment.transform 31 372 env19820 = env19821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 372 env19820 == env19821) = true)

def env19822 : List Nat := [2,4,8,16,32,16,8,256,0,1024,0,1297,269,1297,292,35,1297,0,1025,293,1296,261,17,3,269,17,0,1296,1296,0,1285,292,257,0,1296,0]

theorem envBound19822 : H12AffineFastState.Bounded env19822 := by
  intro p hp
  have h : env19822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19821_19822 : H12AffineEnvironment.transform 5 16 env19821 = env19822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19821 == env19822) = true)

def env19823 : List Nat := [2,4,8,16,32,17,8,256,0,1024,0,1297,269,1296,292,35,1296,0,1025,293,1296,261,16,3,269,17,0,1297,1296,0,1285,293,257,1,1297,0]

theorem envBound19823 : H12AffineFastState.Bounded env19823 := by
  intro p hp
  have h : env19823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19821_19823 : H12AffineEnvironment.transform 5 17 env19821 = env19823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19821 == env19823) = true)

theorem identity19823 : scanCanonicalize (H12AffineFastState.compose env19823 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19824 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,41,1076,0,35,1076,0,1025,1,1076,33,16,3,41,17,0,1077,1076,0,1057,1,37,1,1077,0]

theorem envBound19824 : H12AffineFastState.Bounded env19824 := by
  intro p hp
  have h : env19824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19823_19824 : H12AffineEnvironment.transform 7 36 env19823 = env19824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19823 == env19824) = true)

def leafEnv19824 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,41,1076,0,35,1076,0,1025,1,1076,33,16,3,1056,41,1,17,0,1077,1076,0,1057,1,37,1,5,34,1077,0,0,1077,1]

def active19824 : List Nat := [0,1,2,3,4,9]

def tree19824 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19824 : H12WitnessSearch.Good tree19824 := H12GlobalWitnessIndex.good

theorem leafIdentity19824 : H12AffineFastState.composeSystem env19824 rootObs = leafEnv19824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19824 rootObs == leafEnv19824) = true)

theorem terminalChecked19824 : H12PackedTerminal.terminalCheckFast leafEnv19824 active19824 tree19824 = true := by decide +kernel

def env19825 : List Nat := [2,4,8,16,32,64,9,256,1,1024,0,1297,269,1345,292,34,1345,0,1025,293,1296,261,65,2,268,17,0,1344,1296,0,1285,4294967296,257,4294967588,1344,1]

theorem envBound19825 : H12AffineFastState.Bounded env19825 := by
  intro p hp
  have h : env19825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19819_19825 : H12AffineEnvironment.transform 6 9 env19819 = env19825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19819 == env19825) = true)

theorem identity19825 : scanCanonicalize (H12AffineFastState.compose env19825 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 80) := by decide +kernel

theorem selectedBound19825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19826 : List Nat := [2,4,8,16,32,64,9,256,1,1024,0,1297,269,1345,292,34,1345,0,1025,293,1296,261,65,2,268,17,0,1344,1296,0,1285,80,257,372,1344,1]

theorem envBound19826 : H12AffineFastState.Bounded env19826 := by
  intro p hp
  have h : env19826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19825_19826 : H12AffineEnvironment.transform 31 80 env19825 = env19826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 80 env19825 == env19826) = true)

def env19827 : List Nat := [2,4,8,16,32,16,9,256,1,1024,0,1297,269,1297,292,34,1297,0,1025,293,1296,261,17,2,268,17,0,1296,1296,0,1285,0,257,292,1296,1]

theorem envBound19827 : H12AffineFastState.Bounded env19827 := by
  intro p hp
  have h : env19827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19826_19827 : H12AffineEnvironment.transform 5 16 env19826 = env19827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19826 == env19827) = true)

def env19828 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,269,1297,260,2,1297,0,1025,261,1296,261,17,2,268,17,0,1296,1296,0,1285,0,257,260,1296,1]

theorem envBound19828 : H12AffineFastState.Bounded env19828 := by
  intro p hp
  have h : env19828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19827_19828 : H12AffineEnvironment.transform 4 0 env19827 = env19828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19827 == env19828) = true)

def leafEnv19828 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,269,1297,260,2,1297,0,1025,261,1296,261,17,2,1284,268,1,17,0,1296,1296,0,1285,0,257,260,5,2,1296,1,0,1297,1]

def active19828 : List Nat := [0,1,2,3,7,9]

def tree19828 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19828 : H12WitnessSearch.Good tree19828 := H12GlobalWitnessIndex.good

theorem leafIdentity19828 : H12AffineFastState.composeSystem env19828 rootObs = leafEnv19828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19828 rootObs == leafEnv19828) = true)

theorem terminalChecked19828 : H12PackedTerminal.terminalCheckFast leafEnv19828 active19828 tree19828 = true := by decide +kernel

def env19829 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1297,269,1297,261,3,1297,0,1025,260,1296,261,17,2,268,17,0,1296,1296,0,1285,0,257,261,1296,1]

theorem envBound19829 : H12AffineFastState.Bounded env19829 := by
  intro p hp
  have h : env19829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19827_19829 : H12AffineEnvironment.transform 4 1 env19827 = env19829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19827 == env19829) = true)

theorem identity19829 : scanCanonicalize (H12AffineFastState.compose env19829 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19830 : List Nat := [2,4,8,16,1,16,9,5,1,1024,0,1044,8,1044,0,3,1044,0,1025,1,1045,0,17,2,9,17,0,1045,1045,0,1024,0,4,0,1045,1]

theorem envBound19830 : H12AffineFastState.Bounded env19830 := by
  intro p hp
  have h : env19830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19829_19830 : H12AffineEnvironment.transform 7 5 env19829 = env19830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19829 == env19830) = true)

def leafEnv19830 : List Nat := [2,4,8,16,1,16,9,5,1,1024,0,1044,8,1044,0,3,1044,0,1025,1,1045,0,17,2,1025,9,1,17,0,1045,1045,0,1024,0,4,0,5,3,1045,1,0,1044,1]

def active19830 : List Nat := [0,1,2,3,9]

def tree19830 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19830 : H12WitnessSearch.Good tree19830 := H12GlobalWitnessIndex.good

theorem leafIdentity19830 : H12AffineFastState.composeSystem env19830 rootObs = leafEnv19830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19830 rootObs == leafEnv19830) = true)

theorem terminalChecked19830 : H12PackedTerminal.terminalCheckFast leafEnv19830 active19830 tree19830 = true := by decide +kernel

def env19831 : List Nat := [2,4,8,16,32,17,9,256,1,1024,0,1297,269,1296,292,34,1296,0,1025,293,1296,261,16,2,268,17,0,1297,1296,0,1285,1,257,293,1297,1]

theorem envBound19831 : H12AffineFastState.Bounded env19831 := by
  intro p hp
  have h : env19831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19826_19831 : H12AffineEnvironment.transform 5 17 env19826 = env19831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19826 == env19831) = true)

theorem identity19831 : scanCanonicalize (H12AffineFastState.compose env19831 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19832 : List Nat := [2,4,8,16,32,17,9,37,1,1024,0,1076,40,1077,1,34,1077,0,1025,0,1077,32,16,2,41,17,0,1076,1077,0,1056,1,36,0,1076,1]

theorem envBound19832 : H12AffineFastState.Bounded env19832 := by
  intro p hp
  have h : env19832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19831_19832 : H12AffineEnvironment.transform 7 37 env19831 = env19832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19831 == env19832) = true)

theorem identity19832 : scanCanonicalize (H12AffineFastState.compose env19832 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19833 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1044,8,1045,1,2,1045,0,1025,0,1045,0,16,2,9,17,0,1044,1045,0,1024,1,4,0,1044,1]

theorem envBound19833 : H12AffineFastState.Bounded env19833 := by
  intro p hp
  have h : env19833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19832_19833 : H12AffineEnvironment.transform 4 0 env19832 = env19833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19832 == env19833) = true)

def leafEnv19833 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1044,8,1045,1,2,1045,0,1025,0,1045,0,16,2,1025,9,1,17,0,1044,1045,0,1024,1,4,0,5,2,1044,1,0,1044,1]

def active19833 : List Nat := [0,1,2,3,9]

def tree19833 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19833 : H12WitnessSearch.Good tree19833 := H12GlobalWitnessIndex.good

theorem leafIdentity19833 : H12AffineFastState.composeSystem env19833 rootObs = leafEnv19833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19833 rootObs == leafEnv19833) = true)

theorem terminalChecked19833 : H12PackedTerminal.terminalCheckFast leafEnv19833 active19833 tree19833 = true := by decide +kernel

def env19834 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,16384,32768,65536,1345,1,42025,32769,4097,8200,17664,98564,8328,58744,33060,16385,62824,33061,1285,4294967296,257,4295074214,1344,136]

theorem envBound19834 : H12AffineFastState.Bounded env19834 := by
  intro p hp
  have h : env19834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19772_19834 : H12AffineEnvironment.transform 17 1 env19772 = env19834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19772 == env19834) = true)

def env19835 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,16384,32768,65536,1345,1,42025,32769,1297,8200,17664,98564,8328,58744,33060,16385,57464,33061,1285,4294967296,257,4295074214,1344,136]

theorem envBound19835 : H12AffineFastState.Bounded env19835 := by
  intro p hp
  have h : env19835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19834_19835 : H12AffineEnvironment.transform 11 1296 env19834 = env19835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env19834 == env19835) = true)

theorem identity19835 : scanCanonicalize (H12AffineFastState.compose env19835 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound19835 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19836 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,9293,32768,65536,1345,1,42025,32769,1297,8200,8525,98564,8328,33077,33060,9292,33845,33061,1285,4294967296,257,4295074214,1344,136]

theorem envBound19836 : H12AffineFastState.Bounded env19836 := by
  intro p hp
  have h : env19836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19835_19836 : H12AffineEnvironment.transform 13 9293 env19835 = env19836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env19835 == env19836) = true)

theorem identity19836 : scanCanonicalize (H12AffineFastState.compose env19836 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound19836 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19837 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,8192,9293,293,65536,1345,1,9484,292,1297,8200,8525,65569,8328,16,1,9292,1296,0,1285,4294967296,257,4295041155,1344,136]

theorem envBound19837 : H12AffineFastState.Bounded env19837 := by
  intro p hp
  have h : env19837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19836_19837 : H12AffineEnvironment.transform 14 293 env19836 = env19837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env19836 == env19837) = true)

theorem identity19837 : scanCanonicalize (H12AffineFastState.compose env19837 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19837 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env19838 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1296,269,1344,293,65536,1345,1,1025,292,1297,261,64,65569,389,16,1,1345,1296,0,1285,4294967296,257,4295033230,1344,136]

theorem envBound19838 : H12AffineFastState.Bounded env19838 := by
  intro p hp
  have h : env19838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19837_19838 : H12AffineEnvironment.transform 12 269 env19837 = env19838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19837 == env19838) = true)

def env19839 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,1076,41,1124,1,65536,1125,1,1025,0,1077,33,64,65569,161,16,1,1125,1076,0,1057,4294967296,37,4295033002,1124,136]

theorem envBound19839 : H12AffineFastState.Bounded env19839 := by
  intro p hp
  have h : env19839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19838_19839 : H12AffineEnvironment.transform 7 36 env19838 = env19839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19838 == env19839) = true)

theorem identity19839 : scanCanonicalize (H12AffineFastState.compose env19839 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65650) := by decide +kernel

theorem selectedBound19839 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19840 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,1076,41,1124,1,65536,1125,1,1025,0,1077,33,64,65569,161,16,1,1125,1076,0,1057,65650,37,216,1124,136]

theorem envBound19840 : H12AffineFastState.Bounded env19840 := by
  intro p hp
  have h : env19840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19839_19840 : H12AffineEnvironment.transform 31 65650 env19839 = env19840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65650 env19839 == env19840) = true)

theorem identity19840 : scanCanonicalize (H12AffineFastState.compose env19840 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19840 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19841 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,1076,41,1124,1,171,1125,1,1025,0,1077,33,64,138,161,16,1,1125,1076,0,1057,217,37,216,1124,136]

theorem envBound19841 : H12AffineFastState.Bounded env19841 := by
  intro p hp
  have h : env19841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19840_19841 : H12AffineEnvironment.transform 15 171 env19840 = env19841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19840 == env19841) = true)

theorem identity19841 : scanCanonicalize (H12AffineFastState.compose env19841 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19842 : List Nat := [2,4,8,16,32,64,128,36,136,100,0,80,41,0,1,171,1,1,101,0,81,33,64,138,161,16,1,1,80,0,69,217,37,216,0,136]

theorem envBound19842 : H12AffineFastState.Bounded env19842 := by
  intro p hp
  have h : env19842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19841_19842 : H12AffineEnvironment.transform 9 100 env19841 = env19842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19841 == env19842) = true)

theorem identity19842 : scanCanonicalize (H12AffineFastState.compose env19842 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19843 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,41,0,1,171,1,1,52,0,0,33,17,138,161,16,1,1,1,0,20,136,37,137,0,136]

theorem envBound19843 : H12AffineFastState.Bounded env19843 := by
  intro p hp
  have h : env19843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19842_19843 : H12AffineEnvironment.transform 5 17 env19842 = env19843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19842 == env19843) = true)

theorem identity19843 : scanCanonicalize (H12AffineFastState.compose env19843 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19843 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19844 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,9,0,1,139,1,1,20,0,0,1,17,138,129,16,1,1,1,0,20,136,5,137,0,136]

theorem envBound19844 : H12AffineFastState.Bounded env19844 := by
  intro p hp
  have h : env19844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19843_19844 : H12AffineEnvironment.transform 4 0 env19843 = env19844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19843 == env19844) = true)

def leafEnv19844 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,9,0,1,139,1,1,20,0,0,1,17,138,21,129,1,16,1,1,1,0,20,136,5,137,5,3,0,136,0,0,1]

def active19844 : List Nat := [0,1,2,3,6]

def tree19844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19844 : H12WitnessSearch.Good tree19844 := H12GlobalWitnessIndex.good

theorem leafIdentity19844 : H12AffineFastState.composeSystem env19844 rootObs = leafEnv19844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19844 rootObs == leafEnv19844) = true)

theorem terminalChecked19844 : H12PackedTerminal.terminalCheckFast leafEnv19844 active19844 tree19844 = true := by decide +kernel

def env19845 : List Nat := [2,4,8,16,32,64,128,37,136,1024,0,1077,40,1125,0,65536,1124,1,1025,1,1076,32,64,65569,160,16,1,1124,1077,0,1056,4294967296,36,4295033003,1125,136]

theorem envBound19845 : H12AffineFastState.Bounded env19845 := by
  intro p hp
  have h : env19845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19838_19845 : H12AffineEnvironment.transform 7 37 env19838 = env19845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19838 == env19845) = true)

theorem identity19845 : scanCanonicalize (H12AffineFastState.compose env19845 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 81) := by decide +kernel

theorem selectedBound19845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19846 : List Nat := [2,4,8,16,32,64,128,37,136,1024,0,1077,40,1125,0,65536,1124,1,1025,1,1076,32,64,65569,160,16,1,1124,1077,0,1056,81,36,65786,1125,136]

theorem envBound19846 : H12AffineFastState.Bounded env19846 := by
  intro p hp
  have h : env19846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19845_19846 : H12AffineEnvironment.transform 31 81 env19845 = env19846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 81 env19845 == env19846) = true)

def env19847 : List Nat := [2,4,8,16,32,64,128,37,136,100,0,81,40,1,0,65536,0,1,101,1,80,32,64,65569,160,16,1,0,81,0,68,81,36,65786,1,136]

theorem envBound19847 : H12AffineFastState.Bounded env19847 := by
  intro p hp
  have h : env19847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19846_19847 : H12AffineEnvironment.transform 9 100 env19846 = env19847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19846 == env19847) = true)

theorem identity19847 : scanCanonicalize (H12AffineFastState.compose env19847 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19848 : List Nat := [2,4,8,16,32,64,128,37,136,100,0,81,40,1,0,251,0,1,101,1,80,32,64,218,160,16,1,0,81,0,68,81,36,1,1,136]

theorem envBound19848 : H12AffineFastState.Bounded env19848 := by
  intro p hp
  have h : env19848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19847_19848 : H12AffineEnvironment.transform 15 251 env19847 = env19848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19847 == env19848) = true)

theorem identity19848 : scanCanonicalize (H12AffineFastState.compose env19848 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19848 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19849 : List Nat := [2,4,8,16,32,17,128,37,136,53,0,0,40,1,0,170,0,1,52,1,1,32,17,139,160,16,1,0,0,0,21,0,36,1,1,136]

theorem envBound19849 : H12AffineFastState.Bounded env19849 := by
  intro p hp
  have h : env19849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19848_19849 : H12AffineEnvironment.transform 5 17 env19848 = env19849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19848 == env19849) = true)

theorem identity19849 : scanCanonicalize (H12AffineFastState.compose env19849 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19850 : List Nat := [2,4,8,16,32,17,40,37,32,53,0,0,40,1,0,2,0,1,52,1,1,32,17,35,8,16,1,0,0,0,21,0,36,1,1,32]

theorem envBound19850 : H12AffineFastState.Bounded env19850 := by
  intro p hp
  have h : env19850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19849_19850 : H12AffineEnvironment.transform 6 40 env19849 = env19850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19849 == env19850) = true)

def env19851 : List Nat := [2,4,8,16,32,64,128,37,136,101,0,80,40,0,0,65536,1,1,100,1,81,32,64,65569,160,16,1,1,80,0,69,81,36,65786,0,136]

theorem envBound19851 : H12AffineFastState.Bounded env19851 := by
  intro p hp
  have h : env19851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19846_19851 : H12AffineEnvironment.transform 9 101 env19846 = env19851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19846 == env19851) = true)

theorem identity19851 : scanCanonicalize (H12AffineFastState.compose env19851 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19851 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19852 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,40,0,0,65536,1,1,53,1,0,32,17,65569,160,16,1,1,1,0,20,0,36,65707,0,136]

theorem envBound19852 : H12AffineFastState.Bounded env19852 := by
  intro p hp
  have h : env19852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19851_19852 : H12AffineEnvironment.transform 5 17 env19851 = env19852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19851 == env19852) = true)

def env19853 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,40,0,0,65536,1,1,53,1,0,32,17,65569,40,16,1,1,1,0,20,0,36,65571,0,0]

theorem envBound19853 : H12AffineFastState.Bounded env19853 := by
  intro p hp
  have h : env19853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19852_19853 : H12AffineEnvironment.transform 6 8 env19852 = env19853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19852 == env19853) = true)

theorem identity19853 : scanCanonicalize (H12AffineFastState.compose env19853 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19854 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,8,0,0,65536,1,1,21,1,0,0,17,65537,8,16,1,1,1,0,20,0,4,65539,0,0]

theorem envBound19854 : H12AffineFastState.Bounded env19854 := by
  intro p hp
  have h : env19854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19853_19854 : H12AffineEnvironment.transform 4 0 env19853 = env19854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19853 == env19854) = true)

def env19855 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,40,0,0,65536,1,1,53,1,0,32,17,65569,41,16,1,1,1,0,20,0,36,65570,0,1]

theorem envBound19855 : H12AffineFastState.Bounded env19855 := by
  intro p hp
  have h : env19855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19852_19855 : H12AffineEnvironment.transform 6 9 env19852 = env19855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19852 == env19855) = true)

theorem identity19855 : scanCanonicalize (H12AffineFastState.compose env19855 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19855 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19856 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,40,0,0,2,1,1,53,1,0,32,17,35,41,16,1,1,1,0,20,0,36,32,0,1]

theorem envBound19856 : H12AffineFastState.Bounded env19856 := by
  intro p hp
  have h : env19856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19855_19856 : H12AffineEnvironment.transform 15 2 env19855 = env19856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19855 == env19856) = true)

def env19857 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,16384,32768,65536,1345,1,42025,32769,1296,8200,17664,98564,8328,58744,33060,16385,57465,33061,1285,4294967296,257,4295074214,1344,136]

theorem envBound19857 : H12AffineFastState.Bounded env19857 := by
  intro p hp
  have h : env19857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19834_19857 : H12AffineEnvironment.transform 11 1297 env19834 = env19857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env19834 == env19857) = true)

theorem identity19857 : scanCanonicalize (H12AffineFastState.compose env19857 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound19857 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19858 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,16384,293,65536,1345,1,9484,292,1296,8200,17664,65569,8328,25693,1,16385,24924,0,1285,4294967296,257,4295041155,1344,136]

theorem envBound19858 : H12AffineFastState.Bounded env19858 := by
  intro p hp
  have h : env19858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19857_19858 : H12AffineEnvironment.transform 14 293 env19857 = env19858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env19857 == env19858) = true)

theorem identity19858 : scanCanonicalize (H12AffineFastState.compose env19858 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19858 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19859 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,16384,293,170,1345,1,9484,292,1296,8200,17664,139,8328,25693,1,16385,24924,0,1285,4294967296,257,4294975529,1344,136]

theorem envBound19859 : H12AffineFastState.Bounded env19859 := by
  intro p hp
  have h : env19859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19858_19859 : H12AffineEnvironment.transform 15 170 env19858 = env19859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19858 == env19859) = true)

theorem identity19859 : scanCanonicalize (H12AffineFastState.compose env19859 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19859 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19860 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1297,8192,1344,293,170,1345,1,9484,292,1296,8200,64,139,8328,8477,1,1345,9244,0,1285,4294967296,257,4294975529,1344,136]

theorem envBound19860 : H12AffineFastState.Bounded env19860 := by
  intro p hp
  have h : env19860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19859_19860 : H12AffineEnvironment.transform 13 1344 env19859 = env19860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19859 == env19860) = true)

theorem identity19860 : scanCanonicalize (H12AffineFastState.compose env19860 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19860 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19861 : List Nat := [2,4,8,16,32,64,128,37,136,1024,0,1076,8192,1125,0,170,1124,1,9257,1,1077,8200,64,139,8328,8248,1,1124,9244,0,1056,4294967296,36,4294975529,1125,136]

theorem envBound19861 : H12AffineFastState.Bounded env19861 := by
  intro p hp
  have h : env19861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19860_19861 : H12AffineEnvironment.transform 7 37 env19860 = env19861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19860 == env19861) = true)

theorem identity19861 : scanCanonicalize (H12AffineFastState.compose env19861 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 82) := by decide +kernel

theorem selectedBound19861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19862 : List Nat := [2,4,8,16,32,64,128,37,136,1024,0,1076,82,1125,0,170,1124,1,1147,1,1077,90,64,139,218,106,1,1124,1102,0,1056,4294967296,36,4294967419,1125,136]

theorem envBound19862 : H12AffineFastState.Bounded env19862 := by
  intro p hp
  have h : env19862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19861_19862 : H12AffineEnvironment.transform 12 82 env19861 = env19862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 82 env19861 == env19862) = true)

theorem identity19862 : scanCanonicalize (H12AffineFastState.compose env19862 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19862 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19863 : List Nat := [2,4,8,16,11,64,128,14,136,1024,0,1055,82,1102,0,129,1103,1,1104,1,1054,90,64,139,218,65,1,1103,1102,0,1035,4294967296,15,4294967376,1102,136]

theorem envBound19863 : H12AffineFastState.Bounded env19863 := by
  intro p hp
  have h : env19863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19862_19863 : H12AffineEnvironment.transform 4 11 env19862 = env19863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19862 == env19863) = true)

def env19864 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8200,17664,98564,8328,320889,33060,16385,324969,295204,1285,4294967296,257,4295074214,1344,137]

theorem envBound19864 : H12AffineFastState.Bounded env19864 := by
  intro p hp
  have h : env19864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19771_19864 : H12AffineEnvironment.transform 8 137 env19771 = env19864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19771 == env19864) = true)

theorem identity19864 : scanCanonicalize (H12AffineFastState.compose env19864 (packedSelected [0,1,2,3,4,6,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound19864 : packedSelected [0,1,2,3,4,6,10,13,15] rootPS < 2^1333 := by decide +kernel

def env19865 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,33167,1345,262144,304168,32769,4097,8200,17664,139,8328,320889,33060,16385,324969,295204,1285,4294967296,257,4294975529,1344,137]

theorem envBound19865 : H12AffineFastState.Bounded env19865 := by
  intro p hp
  have h : env19865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19864_19865 : H12AffineEnvironment.transform 15 33167 env19864 = env19865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env19864 == env19865) = true)

def env19866 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,33167,1345,58728,16704,32769,4097,8200,17664,139,8328,17,33060,16385,4097,25676,1285,4294967296,257,4294975529,1344,137]

theorem envBound19866 : H12AffineFastState.Bounded env19866 := by
  intro p hp
  have h : env19866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19865_19866 : H12AffineEnvironment.transform 17 58728 env19865 = env19866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env19865 == env19866) = true)

def env19867 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,0,399,1345,25960,16704,1,4097,8200,17664,139,8328,17,292,16385,4097,25676,1285,4294967296,257,4294975529,1344,137]

theorem envBound19867 : H12AffineFastState.Bounded env19867 := by
  intro p hp
  have h : env19867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19866_19867 : H12AffineEnvironment.transform 14 0 env19866 = env19867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19866 == env19867) = true)

theorem identity19867 : scanCanonicalize (H12AffineFastState.compose env19867 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound19867 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env19868 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1077,8192,16384,0,399,1345,25960,16704,1,1076,8200,17664,139,8328,17,292,16385,1076,25676,1285,4294967296,257,4294975529,1344,137]

theorem envBound19868 : H12AffineFastState.Bounded env19868 := by
  intro p hp
  have h : env19868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19867_19868 : H12AffineEnvironment.transform 11 1077 env19867 = env19868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env19867 == env19868) = true)

theorem identity19868 : scanCanonicalize (H12AffineFastState.compose env19868 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 9576) := by decide +kernel

theorem selectedBound19868 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19869 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1077,8192,9576,0,399,1345,0,9256,1,1076,8200,8296,139,8328,17,292,9577,1076,292,1285,4294967296,257,4294975529,1344,137]

theorem envBound19869 : H12AffineFastState.Bounded env19869 := by
  intro p hp
  have h : env19869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19868_19869 : H12AffineEnvironment.transform 13 9576 env19868 = env19869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9576 env19868 == env19869) = true)

theorem identity19869 : scanCanonicalize (H12AffineFastState.compose env19869 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19869 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19870 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1077,8192,9292,0,171,1125,0,9256,1,1076,8200,8296,139,8328,17,0,9293,1076,0,1057,4294967296,37,4294975529,1124,137]

theorem envBound19870 : H12AffineFastState.Bounded env19870 := by
  intro p hp
  have h : env19870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19869_19870 : H12AffineEnvironment.transform 7 36 env19869 = env19870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19869 == env19870) = true)

theorem identity19870 : scanCanonicalize (H12AffineFastState.compose env19870 (packedSelected [0,5] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound19870 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env19871 : List Nat := [2,4,8,16,32,64,128,36,137,1024,0,1077,8192,9292,0,171,1125,0,9256,1,1076,8200,8296,139,8328,17,0,9293,1076,0,1057,137,37,8352,1124,137]

theorem envBound19871 : H12AffineFastState.Bounded env19871 := by
  intro p hp
  have h : env19871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19870_19871 : H12AffineEnvironment.transform 31 137 env19870 = env19871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env19870 == env19871) = true)

def env19872 : List Nat := [2,4,8,16,32,16,128,36,137,1024,0,1077,8192,9244,0,171,1077,0,9256,1,1076,8200,8248,139,8328,17,0,9245,1076,0,1057,137,37,8352,1076,137]

theorem envBound19872 : H12AffineFastState.Bounded env19872 := by
  intro p hp
  have h : env19872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19871_19872 : H12AffineEnvironment.transform 5 16 env19871 = env19872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19871 == env19872) = true)

theorem identity19872 : scanCanonicalize (H12AffineFastState.compose env19872 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19872 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19873 : List Nat := [2,4,8,16,32,16,128,36,137,1024,0,1077,40,1076,0,171,1077,0,1024,1,1076,32,16,139,160,17,0,1077,1076,0,1057,137,37,136,1076,137]

theorem envBound19873 : H12AffineFastState.Bounded env19873 := by
  intro p hp
  have h : env19873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19872_19873 : H12AffineEnvironment.transform 12 40 env19872 = env19873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19872 == env19873) = true)

theorem identity19873 : scanCanonicalize (H12AffineFastState.compose env19873 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound19873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19874 : List Nat := [2,4,8,16,10,16,128,14,137,1024,0,1055,2,1054,0,129,1055,0,1024,1,1054,10,16,139,138,17,0,1055,1054,0,1035,137,15,136,1054,137]

theorem envBound19874 : H12AffineFastState.Bounded env19874 := by
  intro p hp
  have h : env19874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19873_19874 : H12AffineEnvironment.transform 4 10 env19873 = env19874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env19873 == env19874) = true)

theorem identity19874 : scanCanonicalize (H12AffineFastState.compose env19874 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19875 : List Nat := [2,4,8,16,10,16,25,14,16,1024,0,1055,2,1054,0,24,1055,0,1024,1,1054,10,16,18,19,17,0,1055,1054,0,1035,16,15,17,1054,16]

theorem envBound19875 : H12AffineFastState.Bounded env19875 := by
  intro p hp
  have h : env19875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19874_19875 : H12AffineEnvironment.transform 6 25 env19874 = env19875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19874 == env19875) = true)

def leafEnv19875 : List Nat := [2,4,8,16,10,16,25,14,16,1024,0,1055,2,1054,0,24,1055,0,1024,1,1054,10,16,18,1035,19,1,17,0,1055,1054,0,1035,16,15,17,5,8,1054,16,0,1055,1]

def active19875 : List Nat := [0,1,2,3,9]

def tree19875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19875 : H12WitnessSearch.Good tree19875 := H12GlobalWitnessIndex.good

theorem leafIdentity19875 : H12AffineFastState.composeSystem env19875 rootObs = leafEnv19875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19875 rootObs == leafEnv19875) = true)

theorem terminalChecked19875 : H12PackedTerminal.terminalCheckFast leafEnv19875 active19875 tree19875 = true := by decide +kernel

def env19876 : List Nat := [2,4,8,16,32,17,128,36,137,1024,0,1077,8192,9245,0,171,1076,0,9256,1,1076,8200,8249,139,8328,17,0,9244,1076,0,1057,137,37,8352,1077,137]

theorem envBound19876 : H12AffineFastState.Bounded env19876 := by
  intro p hp
  have h : env19876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19871_19876 : H12AffineEnvironment.transform 5 17 env19871 = env19876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19871 == env19876) = true)

def env19877 : List Nat := [2,4,8,16,32,17,128,36,137,1024,0,1077,40,1077,0,171,1076,0,1024,1,1076,32,17,139,160,17,0,1076,1076,0,1057,137,37,136,1077,137]

theorem envBound19877 : H12AffineFastState.Bounded env19877 := by
  intro p hp
  have h : env19877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19876_19877 : H12AffineEnvironment.transform 12 40 env19876 = env19877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19876 == env19877) = true)

theorem identity19877 : scanCanonicalize (H12AffineFastState.compose env19877 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound19877 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19878 : List Nat := [2,4,8,16,10,17,128,14,137,1024,0,1055,2,1055,0,129,1054,0,1024,1,1054,10,17,139,138,17,0,1054,1054,0,1035,137,15,136,1055,137]

theorem envBound19878 : H12AffineFastState.Bounded env19878 := by
  intro p hp
  have h : env19878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19877_19878 : H12AffineEnvironment.transform 4 10 env19877 = env19878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env19877 == env19878) = true)

theorem identity19878 : scanCanonicalize (H12AffineFastState.compose env19878 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound19878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19879 : List Nat := [2,4,8,16,10,17,24,14,17,1024,0,1055,2,1055,0,25,1054,0,1024,1,1054,10,17,19,18,17,0,1054,1054,0,1035,17,15,16,1055,17]

theorem envBound19879 : H12AffineFastState.Bounded env19879 := by
  intro p hp
  have h : env19879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19878_19879 : H12AffineEnvironment.transform 6 24 env19878 = env19879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env19878 == env19879) = true)

def leafEnv19879 : List Nat := [2,4,8,16,10,17,24,14,17,1024,0,1055,2,1055,0,25,1054,0,1024,1,1054,10,17,19,1035,18,1,17,0,1054,1054,0,1035,17,15,16,5,8,1055,17,0,1055,1]

def active19879 : List Nat := [0,1,2,3,9]

def tree19879 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19879 : H12WitnessSearch.Good tree19879 := H12GlobalWitnessIndex.good

theorem leafIdentity19879 : H12AffineFastState.composeSystem env19879 rootObs = leafEnv19879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19879 rootObs == leafEnv19879) = true)

theorem terminalChecked19879 : H12PackedTerminal.terminalCheckFast leafEnv19879 active19879 tree19879 = true := by decide +kernel

def env19880 : List Nat := [2,4,8,16,32,17,128,36,137,1024,0,1077,41,1076,0,171,1076,0,1025,1,1076,33,16,139,161,17,0,1077,1076,0,1057,137,37,137,1077,137]

theorem envBound19880 : H12AffineFastState.Bounded env19880 := by
  intro p hp
  have h : env19880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19876_19880 : H12AffineEnvironment.transform 12 41 env19876 = env19880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19876 == env19880) = true)

theorem identity19880 : scanCanonicalize (H12AffineFastState.compose env19880 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19881 : List Nat := [2,4,8,16,32,17,8,36,1,1024,0,1077,41,1076,0,35,1076,0,1025,1,1076,33,16,3,41,17,0,1077,1076,0,1057,1,37,1,1077,1]

theorem envBound19881 : H12AffineFastState.Bounded env19881 := by
  intro p hp
  have h : env19881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19880_19881 : H12AffineEnvironment.transform 6 8 env19880 = env19881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19880 == env19881) = true)

end H12CloudChart2