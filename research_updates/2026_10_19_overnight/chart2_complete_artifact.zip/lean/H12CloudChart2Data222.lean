import H12CloudChart2Data221

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound55989 : H12AffineFastState.Bounded env55989 := by
  intro p hp
  have h : env55989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55988_55989 : H12AffineEnvironment.transform 15 29831 env55988 = env55989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env55988 == env55989) = true)

theorem identity55989 : scanCanonicalize (H12AffineFastState.compose env55989 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound55989 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env55990 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,13374,45216,2184,42145,32769,4096,45113,45064,42030,32808,4265,3077,46244,46244,3213,5136,5140,172,40968,1213,41633]

theorem envBound55990 : H12AffineFastState.Bounded env55990 := by
  intro p hp
  have h : env55990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55989_55990 : H12AffineEnvironment.transform 13 185 env55989 = env55990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env55989 == env55990) = true)

theorem identity55990 : scanCanonicalize (H12AffineFastState.compose env55990 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound55990 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env55991 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3613,185,32768,6691,40637,2184,35516,32769,4096,40484,40469,35379,32808,4265,3077,39609,39609,3213,5136,5140,172,36373,1213,36028]

theorem envBound55991 : H12AffineFastState.Bounded env55991 := by
  intro p hp
  have h : env55991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55990_55991 : H12AffineEnvironment.transform 12 3613 env55990 = env55991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env55990 == env55991) = true)

theorem identity55991 : scanCanonicalize (H12AffineFastState.compose env55991 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 4096) := by decide +kernel

theorem selectedBound55991 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55992 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3613,185,4096,6691,3773,2184,6844,4097,4096,3620,3605,6707,4136,4265,3077,2745,2745,3213,5136,5140,172,7701,1213,7356]

theorem envBound55992 : H12AffineFastState.Bounded env55992 := by
  intro p hp
  have h : env55992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55991_55992 : H12AffineEnvironment.transform 14 4096 env55991 = env55992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4096 env55991 == env55992) = true)

theorem identity55992 : scanCanonicalize (H12AffineFastState.compose env55992 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55992 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env55993 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,3613,49,4096,6691,3637,2048,6708,4097,4096,3620,3605,6707,4136,4129,3077,2609,2609,3077,5136,5140,36,7701,1077,7220]

theorem envBound55993 : H12AffineFastState.Bounded env55993 := by
  intro p hp
  have h : env55993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55992_55993 : H12AffineEnvironment.transform 6 8 env55992 = env55993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55992 == env55993) = true)

theorem identity55993 : scanCanonicalize (H12AffineFastState.compose env55993 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound55993 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env55994 : List Nat := [2,4,8,16,32,17,8,37,512,564,2048,4096,2089,49,4096,6691,2049,2048,6708,4097,4096,2064,2081,6707,4136,4129,2609,2609,2609,2609,4644,4640,36,6177,513,6656]

theorem envBound55994 : H12AffineFastState.Bounded env55994 := by
  intro p hp
  have h : env55994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55993_55994 : H12AffineEnvironment.transform 9 564 env55993 = env55994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env55993 == env55994) = true)

theorem identity55994 : scanCanonicalize (H12AffineFastState.compose env55994 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound55994 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55995 : List Nat := [2,4,8,16,32,17,8,37,512,564,2048,513,2089,49,513,2082,2049,2048,2101,512,513,2064,2081,2098,553,544,2609,2609,2609,2609,37,33,36,2592,513,2049]

theorem envBound55995 : H12AffineFastState.Bounded env55995 := by
  intro p hp
  have h : env55995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55994_55995 : H12AffineEnvironment.transform 11 513 env55994 = env55995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env55994 == env55995) = true)

theorem identity55995 : scanCanonicalize (H12AffineFastState.compose env55995 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound55995 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55996 : List Nat := [2,4,8,16,32,17,8,37,512,564,539,513,562,49,513,569,538,539,558,512,513,523,570,553,553,544,42,42,42,42,37,33,36,59,513,538]

theorem envBound55996 : H12AffineFastState.Bounded env55996 := by
  intro p hp
  have h : env55996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55995_55996 : H12AffineEnvironment.transform 10 539 env55995 = env55996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env55995 == env55996) = true)

theorem identity55996 : scanCanonicalize (H12AffineFastState.compose env55996 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55996 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55997 : List Nat := [2,4,8,16,10,17,8,15,512,542,539,513,536,27,513,531,538,539,516,512,513,523,528,515,515,522,0,0,0,0,15,11,14,17,513,538]

theorem envBound55997 : H12AffineFastState.Bounded env55997 := by
  intro p hp
  have h : env55997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55996_55997 : H12AffineEnvironment.transform 4 10 env55996 = env55997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55996 == env55997) = true)

theorem identity55997 : scanCanonicalize (H12AffineFastState.compose env55997 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55997 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55998 : List Nat := [2,4,8,16,10,17,8,15,0,30,27,1,24,27,1,19,26,27,4,0,1,11,16,3,3,10,0,0,0,0,15,11,14,17,1,26]

theorem envBound55998 : H12AffineFastState.Bounded env55998 := by
  intro p hp
  have h : env55998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55997_55998 : H12AffineEnvironment.transform 8 0 env55997 = env55998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55997 == env55998) = true)

theorem identity55998 : scanCanonicalize (H12AffineFastState.compose env55998 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55998 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55999 : List Nat := [2,3,8,16,10,17,8,8,0,25,27,1,24,27,1,19,26,27,3,0,1,11,16,3,3,10,0,0,0,0,8,11,9,17,1,26]

theorem envBound55999 : H12AffineFastState.Bounded env55999 := by
  intro p hp
  have h : env55999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55998_55999 : H12AffineEnvironment.transform 1 3 env55998 = env55999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55998 == env55999) = true)

def env56000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148801,33584585,96346,50962569,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound56000 : H12AffineFastState.Bounded env56000 := by
  intro p hp
  have h : env56000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54912_56000 : H12AffineEnvironment.transform 20 4097 env54912 = env56000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env54912 == env56000) = true)

theorem identity56000 : scanCanonicalize (H12AffineFastState.compose env56000 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 151934398) := by decide +kernel

theorem selectedBound56000 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148801,33584585,96346,50962569,151934398,34088328,168723789,151462016,33563273]

theorem envBound56001 : H12AffineFastState.Bounded env56001 := by
  intro p hp
  have h : env56001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56000_56001 : H12AffineEnvironment.transform 31 151934398 env56000 = env56001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 151934398 env56000 == env56001) = true)

def env56002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,134217728,148801,545089,96346,16876545,151934398,256,134652357,151462016,525825]

theorem envBound56002 : H12AffineFastState.Bounded env56002 := by
  intro p hp
  have h : env56002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56001_56002 : H12AffineEnvironment.transform 24 533640 env56001 = env56002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env56001 == env56002) = true)

def env56003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245632,148801,545089,96346,16876545,618622,256,16876549,1344,525825]

theorem envBound56003 : H12AffineFastState.Bounded env56003 := by
  intro p hp
  have h : env56003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56002_56003 : H12AffineEnvironment.transform 26 17245632 env56002 = env56003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env56002 == env56003) = true)

theorem identity56003 : scanCanonicalize (H12AffineFastState.compose env56003 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound56003 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,16777216,533640,614527,17039790,90415,545089,96346,16876545,618622,256,16876549,1344,525825]

theorem envBound56004 : H12AffineFastState.Bounded env56004 := by
  intro p hp
  have h : env56004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56003_56004 : H12AffineEnvironment.transform 16 74862 env56003 = env56004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env56003 == env56004) = true)

def env56005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123164,533640,614527,385202,90415,545089,96346,25885,618622,256,25881,1344,525825]

theorem envBound56005 : H12AffineFastState.Bounded env56005 := by
  intro p hp
  have h : env56005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56004_56005 : H12AffineEnvironment.transform 23 123164 env56004 = env56005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env56004 == env56005) = true)

def env56006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123164,28888,78895,385202,90415,1297,96346,25885,74798,256,25881,1344,21073]

theorem envBound56006 : H12AffineFastState.Bounded env56006 := by
  intro p hp
  have h : env56006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56005_56006 : H12AffineEnvironment.transform 18 21584 env56005 = env56006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env56005 == env56006) = true)

theorem identity56006 : scanCanonicalize (H12AffineFastState.compose env56006 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56006 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4097,17612,91182,87296,28888,78895,349358,90415,1297,96346,25885,74798,256,25881,1344,21073]

theorem envBound56007 : H12AffineFastState.Bounded env56007 := by
  intro p hp
  have h : env56007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56006_56007 : H12AffineEnvironment.transform 14 13340 env56006 = env56007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56006 == env56007) = true)

def env56008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4097,476,74046,69648,13768,78895,332222,74815,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound56008 : H12AffineFastState.Bounded env56008 := by
  intro p hp
  have h : env56008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56007_56008 : H12AffineEnvironment.transform 13 1296 env56007 = env56008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56007 == env56008) = true)

def env56009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4097,476,74046,69648,13768,78895,4414,74815,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound56009 : H12AffineFastState.Bounded env56009 := by
  intro p hp
  have h : env56009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56008_56009 : H12AffineEnvironment.transform 17 65664 env56008 = env56009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56008 == env56009) = true)

theorem identity56009 : scanCanonicalize (H12AffineFastState.compose env56009 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound56009 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4097,476,70711,69648,193,65830,4414,69942,1297,67651,5380,69927,256,5376,1344,5953]

theorem envBound56010 : H12AffineFastState.Bounded env56010 := by
  intro p hp
  have h : env56010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56009_56010 : H12AffineEnvironment.transform 12 5385 env56009 = env56010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env56009 == env56010) = true)

def env56011 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4097,476,70711,69648,193,65830,4414,69942,1297,67651,5380,69927,256,5376,1344,5141]

theorem envBound56011 : H12AffineFastState.Bounded env56011 := by
  intro p hp
  have h : env56011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56010_56011 : H12AffineEnvironment.transform 8 340 env56010 = env56011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env56010 == env56011) = true)

def env56012 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,277,65536,65895,65664,320,276,1,476,66615,65552,193,65830,318,65846,1297,67651,1284,65831,256,1280,1344,1045]

theorem envBound56012 : H12AffineFastState.Bounded env56012 := by
  intro p hp
  have h : env56012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56011_56012 : H12AffineEnvironment.transform 11 0 env56011 = env56012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56011 == env56012) = true)

theorem identity56012 : scanCanonicalize (H12AffineFastState.compose env56012 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound56012 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56013 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,277,1330,1109,1458,320,276,1,476,261,1314,193,1044,318,1028,1297,3441,1284,1045,256,1280,1344,1045]

theorem envBound56013 : H12AffineFastState.Bounded env56013 := by
  intro p hp
  have h : env56013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56012_56013 : H12AffineEnvironment.transform 15 1330 env56012 = env56013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env56012 == env56013) = true)

theorem identity56013 : scanCanonicalize (H12AffineFastState.compose env56013 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound56013 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env56014 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1038,0,1289,1296,277,1330,1109,1458,320,276,1,476,261,1314,193,1044,318,1028,1297,383,1284,1045,256,1280,1344,1045]

theorem envBound56014 : H12AffineFastState.Bounded env56014 := by
  intro p hp
  have h : env56014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56013_56014 : H12AffineEnvironment.transform 10 1038 env56013 = env56014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env56013 == env56014) = true)

theorem identity56014 : scanCanonicalize (H12AffineFastState.compose env56014 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56014 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56015 : List Nat := [2,4,8,16,32,64,128,256,340,4,10,0,269,276,277,310,81,438,320,276,1,476,261,294,193,16,318,0,277,383,256,17,256,260,324,17]

theorem envBound56015 : H12AffineFastState.Bounded env56015 := by
  intro p hp
  have h : env56015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56014_56015 : H12AffineEnvironment.transform 9 4 env56014 = env56015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56014 == env56015) = true)

theorem identity56015 : scanCanonicalize (H12AffineFastState.compose env56015 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound56015 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env56016 : List Nat := [2,4,8,16,32,64,128,150,194,4,10,0,155,130,131,160,81,32,214,130,1,74,147,176,193,16,168,0,131,233,150,17,150,146,210,17]

theorem envBound56016 : H12AffineFastState.Bounded env56016 := by
  intro p hp
  have h : env56016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56015_56016 : H12AffineEnvironment.transform 7 150 env56015 = env56016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env56015 == env56016) = true)

theorem identity56016 : scanCanonicalize (H12AffineFastState.compose env56016 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound56016 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env56017 : List Nat := [2,4,8,16,32,64,83,69,17,4,10,0,72,81,80,115,81,32,5,81,1,74,64,99,18,16,123,0,80,58,69,17,69,65,1,17]

theorem envBound56017 : H12AffineFastState.Bounded env56017 := by
  intro p hp
  have h : env56017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56016_56017 : H12AffineEnvironment.transform 6 83 env56016 = env56017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env56016 == env56017) = true)

theorem identity56017 : scanCanonicalize (H12AffineFastState.compose env56017 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound56017 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env56018 : List Nat := [2,4,8,16,32,7,20,2,17,4,10,0,15,22,23,52,22,32,5,22,1,13,7,36,18,16,60,0,23,58,2,17,2,6,1,17]

theorem envBound56018 : H12AffineFastState.Bounded env56018 := by
  intro p hp
  have h : env56018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56017_56018 : H12AffineEnvironment.transform 5 7 env56017 = env56018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env56017 == env56018) = true)

theorem identity56018 : scanCanonicalize (H12AffineFastState.compose env56018 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound56018 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env56019 : List Nat := [2,4,8,6,32,7,2,2,7,4,10,0,15,0,1,34,0,32,5,0,1,13,7,36,4,6,42,0,1,44,2,7,2,6,1,7]

theorem envBound56019 : H12AffineFastState.Bounded env56019 := by
  intro p hp
  have h : env56019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56018_56019 : H12AffineEnvironment.transform 3 6 env56018 = env56019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env56018 == env56019) = true)

theorem identity56019 : scanCanonicalize (H12AffineFastState.compose env56019 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56019 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56020 : List Nat := [2,3,8,1,32,0,2,2,0,3,10,0,8,0,1,34,0,32,2,0,1,10,0,35,3,1,42,0,1,43,2,0,2,1,1,0]

theorem envBound56020 : H12AffineFastState.Bounded env56020 := by
  intro p hp
  have h : env56020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56019_56020 : H12AffineEnvironment.transform 1 3 env56019 = env56020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56019 == env56020) = true)

theorem identity56020 : scanCanonicalize (H12AffineFastState.compose env56020 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56020 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56021 : List Nat := [2,3,2,1,32,0,2,2,0,3,0,0,2,0,1,34,0,32,2,0,1,0,0,35,3,1,32,0,1,33,2,0,2,1,1,0]

theorem envBound56021 : H12AffineFastState.Bounded env56021 := by
  intro p hp
  have h : env56021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56020_56021 : H12AffineEnvironment.transform 2 2 env56020 = env56021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56020 == env56021) = true)

def env56022 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,277,65536,65894,65664,321,276,0,476,66614,65553,193,65830,319,65847,1297,67651,1285,65830,256,1281,1344,1044]

theorem envBound56022 : H12AffineFastState.Bounded env56022 := by
  intro p hp
  have h : env56022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56011_56022 : H12AffineEnvironment.transform 11 1 env56011 = env56022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56011 == env56022) = true)

theorem identity56022 : scanCanonicalize (H12AffineFastState.compose env56022 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56022 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56023 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,277,115,277,243,321,276,0,476,1093,98,193,341,319,324,1297,2096,1285,341,256,1281,1344,1044]

theorem envBound56023 : H12AffineFastState.Bounded env56023 := by
  intro p hp
  have h : env56023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56022_56023 : H12AffineEnvironment.transform 15 115 env56022 = env56023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56022 == env56023) = true)

theorem identity56023 : scanCanonicalize (H12AffineFastState.compose env56023 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1255) := by decide +kernel

theorem selectedBound56023 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56024 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1255,1,1288,1296,277,115,277,243,321,276,0,476,1093,98,193,341,319,324,1297,1239,1285,341,256,1281,1344,1044]

theorem envBound56024 : H12AffineFastState.Bounded env56024 := by
  intro p hp
  have h : env56024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56023_56024 : H12AffineEnvironment.transform 10 1255 env56023 = env56024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1255 env56023 == env56024) = true)

theorem identity56024 : scanCanonicalize (H12AffineFastState.compose env56024 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56024 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env56025 : List Nat := [2,4,8,16,32,64,128,20,64,1024,1255,1,1052,1028,1,115,1,243,85,0,0,200,1093,98,193,65,43,80,1029,1239,1041,65,20,1045,1108,1044]

theorem envBound56025 : H12AffineFastState.Bounded env56025 := by
  intro p hp
  have h : env56025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56024_56025 : H12AffineEnvironment.transform 7 20 env56024 = env56025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56024 == env56025) = true)

theorem identity56025 : scanCanonicalize (H12AffineFastState.compose env56025 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound56025 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56026 : List Nat := [2,4,8,16,32,29,128,20,29,1024,1210,1,1052,1028,1,46,1,174,8,0,0,149,1048,63,156,28,43,13,1029,1162,1041,28,20,1045,1033,1044]

theorem envBound56026 : H12AffineFastState.Bounded env56026 := by
  intro p hp
  have h : env56026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56025_56026 : H12AffineEnvironment.transform 5 29 env56025 = env56026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env56025 == env56026) = true)

theorem identity56026 : scanCanonicalize (H12AffineFastState.compose env56026 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound56026 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env56027 : List Nat := [2,4,8,16,26,29,128,20,29,1024,1152,1,1052,1028,1,20,1,148,8,0,0,149,1048,5,156,28,17,13,1029,1162,1041,28,20,1045,1033,1044]

theorem envBound56027 : H12AffineFastState.Bounded env56027 := by
  intro p hp
  have h : env56027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56026_56027 : H12AffineEnvironment.transform 4 26 env56026 = env56027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env56026 == env56027) = true)

theorem identity56027 : scanCanonicalize (H12AffineFastState.compose env56027 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 18) := by decide +kernel

theorem selectedBound56027 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env56028 : List Nat := [2,4,8,16,26,29,128,20,29,18,146,1,14,22,1,20,1,148,8,0,0,149,10,5,156,28,17,13,23,152,3,28,20,7,27,6]

theorem envBound56028 : H12AffineFastState.Bounded env56028 := by
  intro p hp
  have h : env56028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56027_56028 : H12AffineEnvironment.transform 9 18 env56027 = env56028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 18 env56027 == env56028) = true)

theorem identity56028 : scanCanonicalize (H12AffineFastState.compose env56028 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56028 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env56029 : List Nat := [2,4,8,11,1,6,128,15,6,9,137,1,14,13,1,15,1,143,8,0,0,142,10,5,135,7,10,13,12,131,3,7,15,7,0,6]

theorem envBound56029 : H12AffineFastState.Bounded env56029 := by
  intro p hp
  have h : env56029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56028_56029 : H12AffineEnvironment.transform 3 11 env56028 = env56029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56028 == env56029) = true)

theorem identity56029 : scanCanonicalize (H12AffineFastState.compose env56029 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56029 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56030 : List Nat := [2,3,8,11,1,1,128,8,1,9,137,1,9,10,1,8,1,136,8,0,0,137,10,2,128,0,10,10,11,131,3,0,8,0,0,1]

theorem envBound56030 : H12AffineFastState.Bounded env56030 := by
  intro p hp
  have h : env56030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56029_56030 : H12AffineEnvironment.transform 1 3 env56029 = env56030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56029 == env56030) = true)

def env56031 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4097,476,70711,69648,193,65830,4414,69942,1297,67651,5380,69927,256,5376,1344,5140]

theorem envBound56031 : H12AffineFastState.Bounded env56031 := by
  intro p hp
  have h : env56031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56010_56031 : H12AffineEnvironment.transform 8 341 env56010 = env56031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env56010 == env56031) = true)

def env56032 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,277,65536,65895,65664,320,276,1,476,66615,65552,193,65830,318,65846,1297,67651,1284,65831,256,1280,1344,1044]

theorem envBound56032 : H12AffineFastState.Bounded env56032 := by
  intro p hp
  have h : env56032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56031_56032 : H12AffineEnvironment.transform 11 0 env56031 = env56032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56031 == env56032) = true)

theorem identity56032 : scanCanonicalize (H12AffineFastState.compose env56032 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound56032 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56033 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,277,1330,1109,1458,320,276,1,476,261,1314,193,1044,318,1028,1297,3441,1284,1045,256,1280,1344,1044]

theorem envBound56033 : H12AffineFastState.Bounded env56033 := by
  intro p hp
  have h : env56033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56032_56033 : H12AffineEnvironment.transform 15 1330 env56032 = env56033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env56032 == env56033) = true)

theorem identity56033 : scanCanonicalize (H12AffineFastState.compose env56033 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound56033 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env56034 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1039,0,1289,1296,277,1330,1109,1458,320,276,1,476,261,1314,193,1044,318,1028,1297,382,1284,1045,256,1280,1344,1044]

theorem envBound56034 : H12AffineFastState.Bounded env56034 := by
  intro p hp
  have h : env56034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56033_56034 : H12AffineEnvironment.transform 10 1039 env56033 = env56034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env56033 == env56034) = true)

theorem identity56034 : scanCanonicalize (H12AffineFastState.compose env56034 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56034 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56035 : List Nat := [2,4,8,16,32,64,128,256,341,4,11,0,269,276,277,310,81,438,320,276,1,476,261,294,193,16,318,0,277,382,256,17,256,260,324,16]

theorem envBound56035 : H12AffineFastState.Bounded env56035 := by
  intro p hp
  have h : env56035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56034_56035 : H12AffineEnvironment.transform 9 4 env56034 = env56035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56034 == env56035) = true)

theorem identity56035 : scanCanonicalize (H12AffineFastState.compose env56035 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound56035 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env56036 : List Nat := [2,4,8,16,32,64,82,256,341,4,11,0,269,276,277,310,81,356,320,276,1,270,261,294,19,16,318,0,277,382,256,17,256,260,324,16]

theorem envBound56036 : H12AffineFastState.Bounded env56036 := by
  intro p hp
  have h : env56036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56035_56036 : H12AffineEnvironment.transform 6 82 env56035 = env56036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env56035 == env56036) = true)

theorem identity56036 : scanCanonicalize (H12AffineFastState.compose env56036 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56036 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env56037 : List Nat := [2,3,8,16,32,64,82,256,338,3,11,0,266,275,274,305,81,355,320,275,1,265,258,289,19,16,313,0,274,377,256,17,256,259,323,16]

theorem envBound56037 : H12AffineFastState.Bounded env56037 := by
  intro p hp
  have h : env56037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56036_56037 : H12AffineEnvironment.transform 1 3 env56036 = env56037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56036 == env56037) = true)

theorem identity56037 : scanCanonicalize (H12AffineFastState.compose env56037 (packedSelected [0,1,2,3,5,7,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound56037 : packedSelected [0,1,2,3,5,7,11,13,15] rootPS < 2^1333 := by decide +kernel

def env56038 : List Nat := [2,3,8,16,32,64,82,19,65,3,11,0,25,0,1,34,81,112,83,0,1,26,17,50,19,16,42,0,1,106,19,17,19,16,80,16]

theorem envBound56038 : H12AffineFastState.Bounded env56038 := by
  intro p hp
  have h : env56038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56037_56038 : H12AffineEnvironment.transform 7 19 env56037 = env56038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env56037 == env56038) = true)

theorem identity56038 : scanCanonicalize (H12AffineFastState.compose env56038 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56038 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56039 : List Nat := [2,3,8,16,32,11,25,19,10,3,11,0,25,0,1,34,26,59,24,0,1,26,17,50,19,16,42,0,1,33,19,17,19,16,27,16]

theorem envBound56039 : H12AffineFastState.Bounded env56039 := by
  intro p hp
  have h : env56039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56038_56039 : H12AffineEnvironment.transform 5 11 env56038 = env56039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56038 == env56039) = true)

theorem identity56039 : scanCanonicalize (H12AffineFastState.compose env56039 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56039 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56040 : List Nat := [2,3,2,16,32,1,19,19,0,3,1,0,19,0,1,34,16,49,18,0,1,16,17,50,19,16,32,0,1,33,19,17,19,16,17,16]

theorem envBound56040 : H12AffineFastState.Bounded env56040 := by
  intro p hp
  have h : env56040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56039_56040 : H12AffineEnvironment.transform 2 2 env56039 = env56040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56039 == env56040) = true)

theorem identity56040 : scanCanonicalize (H12AffineFastState.compose env56040 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56040 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56041 : List Nat := [2,3,2,0,32,1,3,3,0,3,1,0,3,0,1,34,0,33,2,0,1,0,1,34,3,0,32,0,1,33,3,1,3,0,1,0]

theorem envBound56041 : H12AffineFastState.Bounded env56041 := by
  intro p hp
  have h : env56041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56040_56041 : H12AffineEnvironment.transform 3 0 env56040 = env56041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56040 == env56041) = true)

theorem identity56041 : scanCanonicalize (H12AffineFastState.compose env56041 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56041 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56042 : List Nat := [2,3,2,0,0,1,3,3,0,3,1,0,3,0,1,2,0,1,2,0,1,0,1,2,3,0,0,0,1,1,3,1,3,0,1,0]

theorem envBound56042 : H12AffineFastState.Bounded env56042 := by
  intro p hp
  have h : env56042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56041_56042 : H12AffineEnvironment.transform 4 0 env56041 = env56042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56041 == env56042) = true)

def env56043 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,277,65536,65894,65664,321,276,0,476,66614,65553,193,65830,319,65847,1297,67651,1285,65830,256,1281,1344,1045]

theorem envBound56043 : H12AffineFastState.Bounded env56043 := by
  intro p hp
  have h : env56043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56031_56043 : H12AffineEnvironment.transform 11 1 env56031 = env56043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56031 == env56043) = true)

theorem identity56043 : scanCanonicalize (H12AffineFastState.compose env56043 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56043 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56044 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,277,115,277,243,321,276,0,476,1093,98,193,341,319,324,1297,2096,1285,341,256,1281,1344,1045]

theorem envBound56044 : H12AffineFastState.Bounded env56044 := by
  intro p hp
  have h : env56044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56043_56044 : H12AffineEnvironment.transform 15 115 env56043 = env56044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56043 == env56044) = true)

theorem identity56044 : scanCanonicalize (H12AffineFastState.compose env56044 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1254) := by decide +kernel

theorem selectedBound56044 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56045 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1254,1,1288,1296,277,115,277,243,321,276,0,476,1093,98,193,341,319,324,1297,1238,1285,341,256,1281,1344,1045]

theorem envBound56045 : H12AffineFastState.Bounded env56045 := by
  intro p hp
  have h : env56045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56044_56045 : H12AffineEnvironment.transform 10 1254 env56044 = env56045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1254 env56044 == env56045) = true)

theorem identity56045 : scanCanonicalize (H12AffineFastState.compose env56045 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56045 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env56046 : List Nat := [2,4,8,16,32,64,128,20,65,1024,1254,1,1052,1028,1,115,1,243,85,0,0,200,1093,98,193,65,43,80,1029,1238,1041,65,20,1045,1108,1045]

theorem envBound56046 : H12AffineFastState.Bounded env56046 := by
  intro p hp
  have h : env56046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56045_56046 : H12AffineEnvironment.transform 7 20 env56045 = env56046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56045 == env56046) = true)

theorem identity56046 : scanCanonicalize (H12AffineFastState.compose env56046 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound56046 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56047 : List Nat := [2,4,8,16,32,64,128,20,65,8,238,1,20,12,1,115,1,243,85,0,0,200,77,98,193,65,43,80,13,222,25,65,20,29,92,29]

theorem envBound56047 : H12AffineFastState.Bounded env56047 := by
  intro p hp
  have h : env56047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56046_56047 : H12AffineEnvironment.transform 9 8 env56046 = env56047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env56046 == env56047) = true)

theorem identity56047 : scanCanonicalize (H12AffineFastState.compose env56047 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound56047 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env56048 : List Nat := [2,4,8,16,32,39,128,20,38,8,137,1,20,12,1,20,1,148,50,0,0,175,42,5,166,38,43,55,13,185,25,38,20,29,59,29]

theorem envBound56048 : H12AffineFastState.Bounded env56048 := by
  intro p hp
  have h : env56048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56047_56048 : H12AffineEnvironment.transform 5 39 env56047 = env56048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env56047 == env56048) = true)

theorem identity56048 : scanCanonicalize (H12AffineFastState.compose env56048 (packedSelected [0,1,3,7,8,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56048 : packedSelected [0,1,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env56049 : List Nat := [2,4,8,16,0,7,128,20,6,8,137,1,20,12,1,20,1,148,18,0,0,143,10,5,134,6,11,23,13,153,25,6,20,29,27,29]

theorem envBound56049 : H12AffineFastState.Bounded env56049 := by
  intro p hp
  have h : env56049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56048_56049 : H12AffineEnvironment.transform 4 0 env56048 = env56049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56048 == env56049) = true)

theorem identity56049 : scanCanonicalize (H12AffineFastState.compose env56049 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56049 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env56050 : List Nat := [2,4,8,16,0,7,8,20,6,8,1,1,20,12,1,20,1,28,18,0,0,7,10,5,14,6,11,23,13,17,25,6,20,29,27,29]

theorem envBound56050 : H12AffineFastState.Bounded env56050 := by
  intro p hp
  have h : env56050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56049_56050 : H12AffineEnvironment.transform 6 8 env56049 = env56050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56049 == env56050) = true)

theorem identity56050 : scanCanonicalize (H12AffineFastState.compose env56050 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56050 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56051 : List Nat := [2,2,8,16,0,1,8,18,0,8,1,1,18,10,1,18,1,26,18,0,0,1,10,3,8,0,11,17,11,17,25,0,18,27,27,27]

theorem envBound56051 : H12AffineFastState.Bounded env56051 := by
  intro p hp
  have h : env56051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56050_56051 : H12AffineEnvironment.transform 1 2 env56050 = env56051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56050 == env56051) = true)

theorem identity56051 : scanCanonicalize (H12AffineFastState.compose env56051 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56052 : List Nat := [2,2,8,11,0,1,8,9,0,8,1,1,9,10,1,9,1,1,9,0,0,1,10,3,8,0,11,10,11,10,2,0,9,0,0,0]

theorem envBound56052 : H12AffineFastState.Bounded env56052 := by
  intro p hp
  have h : env56052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56051_56052 : H12AffineEnvironment.transform 3 11 env56051 = env56052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56051 == env56052) = true)

def env56053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4097,476,74046,69648,13768,78895,4415,74815,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound56053 : H12AffineFastState.Bounded env56053 := by
  intro p hp
  have h : env56053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56008_56053 : H12AffineEnvironment.transform 17 65665 env56008 = env56053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56008 == env56053) = true)

theorem identity56053 : scanCanonicalize (H12AffineFastState.compose env56053 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound56053 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4097,476,65911,69648,5505,70758,4415,66678,1297,72963,68,66663,256,64,1344,5953]

theorem envBound56054 : H12AffineFastState.Bounded env56054 := by
  intro p hp
  have h : env56054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56053_56054 : H12AffineEnvironment.transform 12 73 env56053 = env56054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56053 == env56054) = true)

def env56055 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4097,476,65911,69648,5505,70758,4415,66678,1297,72963,68,66663,256,64,1344,5141]

theorem envBound56055 : H12AffineFastState.Bounded env56055 := by
  intro p hp
  have h : env56055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56054_56055 : H12AffineEnvironment.transform 8 340 env56054 = env56055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env56054 == env56055) = true)

def env56056 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4373,65536,65895,65665,4416,4372,4097,476,65911,69648,4289,69926,4415,65846,81,71747,68,65831,256,64,0,4437]

theorem envBound56056 : H12AffineFastState.Bounded env56056 := by
  intro p hp
  have h : env56056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56055_56056 : H12AffineEnvironment.transform 9 320 env56055 = env56056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56055 == env56056) = true)

theorem identity56056 : scanCanonicalize (H12AffineFastState.compose env56056 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound56056 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56057 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4373,4210,4373,4339,4416,4372,4097,476,4357,98,4289,340,4415,4420,81,2097,68,4437,256,64,0,4437]

theorem envBound56057 : H12AffineFastState.Bounded env56057 := by
  intro p hp
  have h : env56057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56056_56057 : H12AffineEnvironment.transform 15 4210 env56056 = env56057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env56056 == env56057) = true)

theorem identity56057 : scanCanonicalize (H12AffineFastState.compose env56057 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56057 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56058 : List Nat := [2,4,8,16,32,64,128,68,16,4,2048,4096,73,80,4177,4210,4177,4339,4100,4176,4097,152,4161,98,4289,16,4219,4096,81,2097,68,4113,68,64,0,4113]

theorem envBound56058 : H12AffineFastState.Bounded env56058 := by
  intro p hp
  have h : env56058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56057_56058 : H12AffineEnvironment.transform 7 68 env56057 = env56058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56057 == env56058) = true)

theorem identity56058 : scanCanonicalize (H12AffineFastState.compose env56058 (packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 2277) := by decide +kernel

theorem selectedBound56058 : packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env56059 : List Nat := [2,4,8,16,32,64,128,68,16,4,2048,2277,73,80,2228,2199,2228,2070,2273,2229,2276,152,2212,98,2084,16,2206,2277,81,2097,68,2292,68,64,0,2292]

theorem envBound56059 : H12AffineFastState.Bounded env56059 := by
  intro p hp
  have h : env56059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56058_56059 : H12AffineEnvironment.transform 11 2277 env56058 = env56059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2277 env56058 == env56059) = true)

theorem identity56059 : scanCanonicalize (H12AffineFastState.compose env56059 (packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound56059 : packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env56060 : List Nat := [2,4,8,16,32,64,128,68,16,4,217,60,73,80,109,78,109,207,56,108,61,152,125,98,253,16,71,60,81,232,68,45,68,64,0,45]

theorem envBound56060 : H12AffineFastState.Bounded env56060 := by
  intro p hp
  have h : env56060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56059_56060 : H12AffineEnvironment.transform 10 217 env56059 = env56060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env56059 == env56060) = true)

theorem identity56060 : scanCanonicalize (H12AffineFastState.compose env56060 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound56060 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env56061 : List Nat := [2,4,8,16,32,43,128,47,16,4,178,60,34,59,6,37,6,164,56,7,61,152,22,9,150,16,44,60,58,131,47,45,47,43,0,45]

theorem envBound56061 : H12AffineFastState.Bounded env56061 := by
  intro p hp
  have h : env56061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56060_56061 : H12AffineEnvironment.transform 5 43 env56060 = env56061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env56060 == env56061) = true)

theorem identity56061 : scanCanonicalize (H12AffineFastState.compose env56061 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56061 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56062 : List Nat := [2,4,8,16,11,0,128,4,16,4,153,23,9,16,6,14,6,143,19,7,22,152,22,9,150,16,7,23,17,131,4,6,4,0,0,6]

theorem envBound56062 : H12AffineFastState.Bounded env56062 := by
  intro p hp
  have h : env56062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56061_56062 : H12AffineEnvironment.transform 4 11 env56061 = env56062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56061 == env56062) = true)

theorem identity56062 : scanCanonicalize (H12AffineFastState.compose env56062 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound56062 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56063 : List Nat := [2,4,8,16,11,0,20,4,16,4,13,23,9,16,6,14,6,27,19,7,22,12,22,9,2,16,7,23,17,23,4,6,4,0,0,6]

theorem envBound56063 : H12AffineFastState.Bounded env56063 := by
  intro p hp
  have h : env56063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56062_56063 : H12AffineEnvironment.transform 6 20 env56062 = env56063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env56062 == env56063) = true)

theorem identity56063 : scanCanonicalize (H12AffineFastState.compose env56063 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56063 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56064 : List Nat := [2,4,8,10,11,0,14,4,10,4,13,13,9,10,6,14,6,1,9,7,12,12,12,9,2,10,7,13,11,13,4,6,4,0,0,6]

theorem envBound56064 : H12AffineFastState.Bounded env56064 := by
  intro p hp
  have h : env56064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56063_56064 : H12AffineEnvironment.transform 3 10 env56063 = env56064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56063 == env56064) = true)

theorem identity56064 : scanCanonicalize (H12AffineFastState.compose env56064 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56065 : List Nat := [2,2,8,10,11,0,8,2,10,2,11,11,9,10,0,8,0,1,9,1,10,10,10,9,2,10,1,11,11,11,2,0,2,0,0,0]

theorem envBound56065 : H12AffineFastState.Bounded env56065 := by
  intro p hp
  have h : env56065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56064_56065 : H12AffineEnvironment.transform 1 2 env56064 = env56065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56064 == env56065) = true)

def env56066 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4372,65536,65894,65665,4416,4373,4097,476,65911,69648,4288,69927,4415,65847,80,71746,68,65830,256,64,1,4436]

theorem envBound56066 : H12AffineFastState.Bounded env56066 := by
  intro p hp
  have h : env56066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56055_56066 : H12AffineEnvironment.transform 9 321 env56055 = env56066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56055 == env56066) = true)

theorem identity56066 : scanCanonicalize (H12AffineFastState.compose env56066 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56066 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56067 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4372,115,277,242,4416,4373,4097,476,260,4195,4288,4436,4415,324,80,6193,68,341,256,64,1,4436]

theorem envBound56067 : H12AffineFastState.Bounded env56067 := by
  intro p hp
  have h : env56067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56066_56067 : H12AffineEnvironment.transform 15 115 env56066 = env56067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56066 == env56067) = true)

theorem identity56067 : scanCanonicalize (H12AffineFastState.compose env56067 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 503) := by decide +kernel

theorem selectedBound56067 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env56068 : List Nat := [2,4,8,16,32,64,128,256,340,321,503,4096,73,81,4372,115,277,242,4416,4373,4097,476,260,4195,4288,4436,4415,324,80,4550,68,341,256,64,1,4436]

theorem envBound56068 : H12AffineFastState.Bounded env56068 := by
  intro p hp
  have h : env56068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56067_56068 : H12AffineEnvironment.transform 10 503 env56067 = env56068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 503 env56067 == env56068) = true)

theorem identity56068 : scanCanonicalize (H12AffineFastState.compose env56068 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 459) := by decide +kernel

theorem selectedBound56068 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env56069 : List Nat := [2,4,8,16,32,64,128,256,340,321,503,459,73,81,223,115,277,242,139,222,458,476,260,424,267,159,244,324,80,13,68,341,256,64,1,159]

theorem envBound56069 : H12AffineFastState.Bounded env56069 := by
  intro p hp
  have h : env56069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56068_56069 : H12AffineEnvironment.transform 11 459 env56068 = env56069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 459 env56068 == env56069) = true)

theorem identity56069 : scanCanonicalize (H12AffineFastState.compose env56069 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 94) := by decide +kernel

theorem selectedBound56069 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56070 : List Nat := [2,4,8,16,32,64,94,256,340,321,297,277,73,81,1,115,277,44,85,0,276,258,260,374,267,65,42,324,80,13,68,341,256,64,1,65]

theorem envBound56070 : H12AffineFastState.Bounded env56070 := by
  intro p hp
  have h : env56070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56069_56070 : H12AffineEnvironment.transform 6 94 env56069 = env56070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 94 env56069 == env56070) = true)

theorem identity56070 : scanCanonicalize (H12AffineFastState.compose env56070 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound56070 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56071 : List Nat := [2,4,8,16,32,13,19,256,281,268,297,277,4,28,1,62,277,44,24,0,276,258,260,315,267,12,42,265,29,13,9,280,256,13,1,12]

theorem envBound56071 : H12AffineFastState.Bounded env56071 := by
  intro p hp
  have h : env56071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56070_56071 : H12AffineEnvironment.transform 5 13 env56070 = env56071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env56070 == env56071) = true)

theorem identity56071 : scanCanonicalize (H12AffineFastState.compose env56071 (packedSelected [2,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56071 : packedSelected [2,8,12] rootPS < 2^1333 := by decide +kernel

def env56072 : List Nat := [2,4,8,0,32,13,3,256,265,268,297,261,4,12,1,46,261,44,8,0,260,258,260,299,267,12,42,265,13,13,9,264,256,13,1,12]

theorem envBound56072 : H12AffineFastState.Bounded env56072 := by
  intro p hp
  have h : env56072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56071_56072 : H12AffineEnvironment.transform 3 0 env56071 = env56072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56071 == env56072) = true)

theorem identity56072 : scanCanonicalize (H12AffineFastState.compose env56072 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56072 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56073 : List Nat := [2,4,8,0,1,13,3,256,265,268,264,261,4,12,1,15,261,13,8,0,260,258,260,266,267,12,11,265,13,13,9,264,256,13,1,12]

theorem envBound56073 : H12AffineFastState.Bounded env56073 := by
  intro p hp
  have h : env56073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56072_56073 : H12AffineEnvironment.transform 4 1 env56072 = env56073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56072 == env56073) = true)

theorem identity56073 : scanCanonicalize (H12AffineFastState.compose env56073 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56073 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56074 : List Nat := [2,4,8,0,1,13,3,4,13,8,12,1,4,12,1,15,1,13,8,0,0,6,0,14,15,12,11,13,13,13,9,12,4,13,1,12]

theorem envBound56074 : H12AffineFastState.Bounded env56074 := by
  intro p hp
  have h : env56074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56073_56074 : H12AffineEnvironment.transform 7 4 env56073 = env56074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56073 == env56074) = true)

theorem identity56074 : scanCanonicalize (H12AffineFastState.compose env56074 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound56074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56075 : List Nat := [2,4,6,0,1,3,3,4,3,6,2,1,4,2,1,1,1,3,6,0,0,6,0,0,1,2,5,3,3,3,7,2,4,3,1,2]

theorem envBound56075 : H12AffineFastState.Bounded env56075 := by
  intro p hp
  have h : env56075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56074_56075 : H12AffineEnvironment.transform 2 6 env56074 = env56075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env56074 == env56075) = true)

theorem identity56075 : scanCanonicalize (H12AffineFastState.compose env56075 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound56075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56076 : List Nat := [2,1,3,0,1,3,3,1,3,3,2,1,1,2,1,1,1,3,3,0,0,3,0,0,1,2,0,3,3,3,2,2,1,3,1,2]

theorem envBound56076 : H12AffineFastState.Bounded env56076 := by
  intro p hp
  have h : env56076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56075_56076 : H12AffineEnvironment.transform 1 1 env56075 = env56076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env56075 == env56076) = true)

theorem identity56076 : scanCanonicalize (H12AffineFastState.compose env56076 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56076 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56077 : List Nat := [1,1,0,0,1,0,0,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,1,1]

theorem envBound56077 : H12AffineFastState.Bounded env56077 := by
  intro p hp
  have h : env56077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56076_56077 : H12AffineEnvironment.transform 0 1 env56076 = env56077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56076 == env56077) = true)

def env56078 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4097,476,65911,69648,5505,70758,4415,66678,1297,72963,68,66663,256,64,1344,5140]

theorem envBound56078 : H12AffineFastState.Bounded env56078 := by
  intro p hp
  have h : env56078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56054_56078 : H12AffineEnvironment.transform 8 341 env56054 = env56078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env56054 == env56078) = true)

def env56079 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4373,65536,65895,65665,4416,4372,4097,476,65911,69648,4289,69926,4415,65846,81,71747,68,65831,256,64,0,4436]

theorem envBound56079 : H12AffineFastState.Bounded env56079 := by
  intro p hp
  have h : env56079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56078_56079 : H12AffineEnvironment.transform 9 320 env56078 = env56079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56078 == env56079) = true)

theorem identity56079 : scanCanonicalize (H12AffineFastState.compose env56079 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound56079 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56080 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4373,4210,4373,4339,4416,4372,4097,476,4357,98,4289,340,4415,4420,81,2097,68,4437,256,64,0,4436]

theorem envBound56080 : H12AffineFastState.Bounded env56080 := by
  intro p hp
  have h : env56080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56079_56080 : H12AffineEnvironment.transform 15 4210 env56079 = env56080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env56079 == env56080) = true)

theorem identity56080 : scanCanonicalize (H12AffineFastState.compose env56080 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56080 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56081 : List Nat := [2,4,8,16,32,64,128,68,17,4,2048,4096,73,80,4177,4210,4177,4339,4100,4176,4097,152,4161,98,4289,16,4219,4096,81,2097,68,4113,68,64,0,4112]

theorem envBound56081 : H12AffineFastState.Bounded env56081 := by
  intro p hp
  have h : env56081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56080_56081 : H12AffineEnvironment.transform 7 68 env56080 = env56081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56080 == env56081) = true)

theorem identity56081 : scanCanonicalize (H12AffineFastState.compose env56081 (packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 181) := by decide +kernel

theorem selectedBound56081 : packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env56082 : List Nat := [2,4,8,16,32,64,128,68,17,4,181,4096,73,80,4177,4210,4177,4339,4100,4176,4097,152,4161,98,4289,16,4219,4096,81,132,68,4113,68,64,0,4112]

theorem envBound56082 : H12AffineFastState.Bounded env56082 := by
  intro p hp
  have h : env56082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56081_56082 : H12AffineEnvironment.transform 10 181 env56081 = env56082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 181 env56081 == env56082) = true)

theorem identity56082 : scanCanonicalize (H12AffineFastState.compose env56082 (packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound56082 : packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env56083 : List Nat := [2,4,8,16,32,44,128,40,17,4,181,4096,37,60,4157,4126,4157,4255,4100,4156,4097,152,4141,14,4269,16,4119,4096,61,132,40,4113,40,44,0,4112]

theorem envBound56083 : H12AffineFastState.Bounded env56083 := by
  intro p hp
  have h : env56083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56082_56083 : H12AffineEnvironment.transform 5 44 env56082 = env56083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env56082 == env56083) = true)

theorem identity56083 : scanCanonicalize (H12AffineFastState.compose env56083 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56083 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env56084 : List Nat := [2,2,8,16,32,42,128,40,17,2,179,4096,35,58,4155,4120,4155,4249,4098,4154,4097,152,4139,8,4267,16,4113,4096,59,130,40,4113,40,42,0,4112]

theorem envBound56084 : H12AffineFastState.Bounded env56084 := by
  intro p hp
  have h : env56084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56083_56084 : H12AffineEnvironment.transform 1 2 env56083 = env56084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56083 == env56084) = true)

theorem identity56084 : scanCanonicalize (H12AffineFastState.compose env56084 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56084 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56085 : List Nat := [2,2,8,16,11,1,128,3,17,2,152,4096,8,17,4112,4120,4112,4249,4098,4113,4097,152,4096,8,4224,16,4113,4096,16,130,3,4113,3,1,0,4112]

theorem envBound56085 : H12AffineFastState.Bounded env56085 := by
  intro p hp
  have h : env56085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56084_56085 : H12AffineEnvironment.transform 4 11 env56084 = env56085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56084 == env56085) = true)

theorem identity56085 : scanCanonicalize (H12AffineFastState.compose env56085 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 130) := by decide +kernel

theorem selectedBound56085 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56086 : List Nat := [2,2,8,16,11,1,128,3,17,2,152,130,8,17,146,154,146,27,128,147,131,152,130,8,2,16,147,130,16,130,3,147,3,1,0,146]

theorem envBound56086 : H12AffineFastState.Bounded env56086 := by
  intro p hp
  have h : env56086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56085_56086 : H12AffineEnvironment.transform 11 130 env56085 = env56086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 130 env56085 == env56086) = true)

theorem identity56086 : scanCanonicalize (H12AffineFastState.compose env56086 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound56086 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56087 : List Nat := [2,2,8,16,11,1,25,3,17,2,1,27,8,17,11,3,11,27,25,10,26,1,27,8,2,16,10,27,16,27,3,10,3,1,0,11]

theorem envBound56087 : H12AffineFastState.Bounded env56087 := by
  intro p hp
  have h : env56087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56086_56087 : H12AffineEnvironment.transform 6 25 env56086 = env56087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env56086 == env56087) = true)

theorem identity56087 : scanCanonicalize (H12AffineFastState.compose env56087 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56088 : List Nat := [2,2,2,16,1,1,19,3,17,2,1,17,2,17,1,3,1,17,19,0,16,1,17,2,2,16,0,17,16,17,3,0,3,1,0,1]

theorem envBound56088 : H12AffineFastState.Bounded env56088 := by
  intro p hp
  have h : env56088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56087_56088 : H12AffineEnvironment.transform 2 2 env56087 = env56088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56087 == env56088) = true)

def env56089 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4372,65536,65894,65665,4416,4373,4097,476,65911,69648,4288,69927,4415,65847,80,71746,68,65830,256,64,1,4437]

theorem envBound56089 : H12AffineFastState.Bounded env56089 := by
  intro p hp
  have h : env56089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56078_56089 : H12AffineEnvironment.transform 9 321 env56078 = env56089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56078 == env56089) = true)

theorem identity56089 : scanCanonicalize (H12AffineFastState.compose env56089 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56089 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56090 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4372,115,277,242,4416,4373,4097,476,260,4195,4288,4436,4415,324,80,6193,68,341,256,64,1,4437]

theorem envBound56090 : H12AffineFastState.Bounded env56090 := by
  intro p hp
  have h : env56090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56089_56090 : H12AffineEnvironment.transform 15 115 env56089 = env56090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56089 == env56090) = true)

theorem identity56090 : scanCanonicalize (H12AffineFastState.compose env56090 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound56090 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env56091 : List Nat := [2,4,8,16,32,64,128,256,341,321,502,4096,73,81,4372,115,277,242,4416,4373,4097,476,260,4195,4288,4436,4415,324,80,4551,68,341,256,64,1,4437]

theorem envBound56091 : H12AffineFastState.Bounded env56091 := by
  intro p hp
  have h : env56091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56090_56091 : H12AffineEnvironment.transform 10 502 env56090 = env56091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env56090 == env56091) = true)

theorem identity56091 : scanCanonicalize (H12AffineFastState.compose env56091 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 222) := by decide +kernel

theorem selectedBound56091 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env56092 : List Nat := [2,4,8,16,32,64,128,256,341,321,502,222,73,81,458,115,277,242,414,459,223,476,260,189,30,394,481,324,80,281,68,341,256,64,1,395]

theorem envBound56092 : H12AffineFastState.Bounded env56092 := by
  intro p hp
  have h : env56092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56091_56092 : H12AffineEnvironment.transform 11 222 env56091 = env56092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 222 env56091 == env56092) = true)

theorem identity56092 : scanCanonicalize (H12AffineFastState.compose env56092 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 203) := by decide +kernel

theorem selectedBound56092 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56093 : List Nat := [2,4,8,16,32,64,128,203,158,138,61,222,73,81,1,115,222,242,85,0,223,23,207,189,30,65,42,143,80,210,68,158,203,64,1,64]

theorem envBound56093 : H12AffineFastState.Bounded env56093 := by
  intro p hp
  have h : env56093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56092_56093 : H12AffineEnvironment.transform 7 203 env56092 = env56093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 203 env56092 == env56093) = true)

theorem identity56093 : scanCanonicalize (H12AffineFastState.compose env56093 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound56093 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56094 : List Nat := [2,4,8,16,32,13,128,134,158,138,61,147,4,28,1,62,147,191,24,0,146,23,130,189,30,12,42,143,29,159,9,158,134,13,1,13]

theorem envBound56094 : H12AffineFastState.Bounded env56094 := by
  intro p hp
  have h : env56094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56093_56094 : H12AffineEnvironment.transform 5 13 env56093 = env56094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env56093 == env56094) = true)

theorem identity56094 : scanCanonicalize (H12AffineFastState.compose env56094 (packedSelected [1,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound56094 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env56095 : List Nat := [2,4,8,16,32,13,37,35,59,47,61,54,4,28,1,62,54,26,24,0,55,23,39,24,30,12,42,42,29,58,9,59,35,13,1,13]

theorem envBound56095 : H12AffineFastState.Bounded env56095 := by
  intro p hp
  have h : env56095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56094_56095 : H12AffineEnvironment.transform 6 37 env56094 = env56095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env56094 == env56095) = true)

theorem identity56095 : scanCanonicalize (H12AffineFastState.compose env56095 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound56095 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56096 : List Nat := [2,4,8,16,7,13,2,4,28,8,26,17,4,28,1,25,17,26,24,0,16,23,0,24,30,12,13,13,29,29,9,28,4,13,1,13]

theorem envBound56096 : H12AffineFastState.Bounded env56096 := by
  intro p hp
  have h : env56096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56095_56096 : H12AffineEnvironment.transform 4 7 env56095 = env56096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env56095 == env56096) = true)

theorem identity56096 : scanCanonicalize (H12AffineFastState.compose env56096 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56096 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56097 : List Nat := [2,4,5,16,7,0,2,4,17,5,23,17,4,17,1,20,17,23,21,0,16,23,0,21,19,1,0,0,16,16,4,17,4,0,1,0]

theorem envBound56097 : H12AffineFastState.Bounded env56097 := by
  intro p hp
  have h : env56097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56096_56097 : H12AffineEnvironment.transform 2 5 env56096 = env56097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56096 == env56097) = true)

theorem identity56097 : scanCanonicalize (H12AffineFastState.compose env56097 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56098 : List Nat := [2,4,5,1,7,0,2,4,0,5,6,0,4,0,1,5,0,6,4,0,1,6,0,4,2,1,0,0,1,1,4,0,4,0,1,0]

theorem envBound56098 : H12AffineFastState.Bounded env56098 := by
  intro p hp
  have h : env56098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56097_56098 : H12AffineEnvironment.transform 3 1 env56097 = env56098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56097 == env56098) = true)

def env56099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4097,477,74047,69649,13769,78895,332223,74814,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound56099 : H12AffineFastState.Bounded env56099 := by
  intro p hp
  have h : env56099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56007_56099 : H12AffineEnvironment.transform 13 1297 env56007 = env56099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56007 == env56099) = true)

def env56100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4097,477,74047,69649,13769,78895,4415,74814,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound56100 : H12AffineFastState.Bounded env56100 := by
  intro p hp
  have h : env56100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56099_56100 : H12AffineEnvironment.transform 17 65664 env56099 = env56100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56099 == env56100) = true)

theorem identity56100 : scanCanonicalize (H12AffineFastState.compose env56100 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound56100 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56101 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4097,477,74047,69649,12425,78191,4415,74110,81,79883,8204,74094,256,8200,0,4608]

theorem envBound56101 : H12AffineFastState.Bounded env56101 := by
  intro p hp
  have h : env56101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56100_56101 : H12AffineEnvironment.transform 9 320 env56100 = env56101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56100 == env56101) = true)

def env56102 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4097,477,74047,69649,12425,78191,4415,74110,81,79883,8204,74094,256,8200,0,4436]

theorem envBound56102 : H12AffineFastState.Bounded env56102 := by
  intro p hp
  have h : env56102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56101_56102 : H12AffineEnvironment.transform 8 340 env56101 = env56102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env56101 == env56102) = true)

def env56103 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8524,65536,74030,65664,337,8525,17,477,74047,65537,8345,74111,303,74110,81,75803,8204,74094,256,8200,0,324]

theorem envBound56103 : H12AffineFastState.Bounded env56103 := by
  intro p hp
  have h : env56103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56102_56103 : H12AffineEnvironment.transform 11 16 env56102 = env56103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env56102 == env56103) = true)

theorem identity56103 : scanCanonicalize (H12AffineFastState.compose env56103 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 409) := by decide +kernel

theorem selectedBound56103 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56104 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8524,409,8375,281,337,8525,17,477,8358,408,8345,8422,303,8423,81,10626,8204,8439,256,8200,0,324]

theorem envBound56104 : H12AffineFastState.Bounded env56104 := by
  intro p hp
  have h : env56104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56103_56104 : H12AffineEnvironment.transform 15 409 env56103 = env56104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 409 env56103 == env56104) = true)

def env56105 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,8192,65,8524,393,8359,265,321,8525,1,461,8358,392,8329,8422,303,8423,65,10626,8204,8423,256,8200,0,324]

theorem envBound56105 : H12AffineFastState.Bounded env56105 := by
  intro p hp
  have h : env56105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56104_56105 : H12AffineEnvironment.transform 3 0 env56104 = env56105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56104 == env56105) = true)

theorem identity56105 : scanCanonicalize (H12AffineFastState.compose env56105 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound56105 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56106 : List Nat := [2,4,8,0,32,64,128,235,175,171,2048,0,8192,65,8359,98,8359,226,170,8358,1,38,8358,99,8329,8422,196,8423,65,10345,8204,8423,235,8200,0,175]

theorem envBound56106 : H12AffineFastState.Bounded env56106 := by
  intro p hp
  have h : env56106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56105_56106 : H12AffineEnvironment.transform 7 235 env56105 = env56106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env56105 == env56106) = true)

theorem identity56106 : scanCanonicalize (H12AffineFastState.compose env56106 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 231) := by decide +kernel

theorem selectedBound56106 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56107 : List Nat := [2,4,8,0,32,64,128,235,175,171,2048,0,231,65,64,98,64,226,170,65,1,38,65,99,110,1,196,0,65,2190,235,0,235,239,0,175]

theorem envBound56107 : H12AffineFastState.Bounded env56107 := by
  intro p hp
  have h : env56107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56106_56107 : H12AffineEnvironment.transform 12 231 env56106 = env56107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 231 env56106 == env56107) = true)

theorem identity56107 : scanCanonicalize (H12AffineFastState.compose env56107 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound56107 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56108 : List Nat := [2,4,8,0,32,64,67,40,108,104,2048,0,36,65,64,98,64,33,105,65,1,38,65,99,110,1,7,0,65,2125,40,0,40,44,0,108]

theorem envBound56108 : H12AffineFastState.Bounded env56108 := by
  intro p hp
  have h : env56108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56107_56108 : H12AffineEnvironment.transform 6 67 env56107 = env56108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env56107 == env56108) = true)

theorem identity56108 : scanCanonicalize (H12AffineFastState.compose env56108 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound56108 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env56109 : List Nat := [2,4,8,0,32,42,41,40,6,2,2048,0,36,43,42,8,42,33,3,43,1,38,43,9,4,1,7,0,43,2087,40,0,40,44,0,6]

theorem envBound56109 : H12AffineFastState.Bounded env56109 := by
  intro p hp
  have h : env56109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56108_56109 : H12AffineEnvironment.transform 5 42 env56108 = env56109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env56108 == env56109) = true)

theorem identity56109 : scanCanonicalize (H12AffineFastState.compose env56109 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56109 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56110 : List Nat := [2,4,2,0,32,32,35,34,6,2,2048,0,36,33,32,2,32,33,3,33,1,38,33,3,4,1,7,0,33,2087,34,0,34,38,0,6]

theorem envBound56110 : H12AffineFastState.Bounded env56110 := by
  intro p hp
  have h : env56110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56109_56110 : H12AffineEnvironment.transform 2 2 env56109 = env56110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56109 == env56110) = true)

theorem identity56110 : scanCanonicalize (H12AffineFastState.compose env56110 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound56110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56111 : List Nat := [2,4,2,0,32,32,35,34,6,2,32,0,36,33,32,2,32,33,3,33,1,38,33,3,4,1,7,0,33,7,34,0,34,38,0,6]

theorem envBound56111 : H12AffineFastState.Bounded env56111 := by
  intro p hp
  have h : env56111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56110_56111 : H12AffineEnvironment.transform 10 32 env56110 = env56111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env56110 == env56111) = true)

theorem identity56111 : scanCanonicalize (H12AffineFastState.compose env56111 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56112 : List Nat := [2,2,2,0,32,32,35,34,0,2,32,0,34,33,32,2,32,33,3,33,1,32,33,3,2,1,1,0,33,1,34,0,34,32,0,0]

theorem envBound56112 : H12AffineFastState.Bounded env56112 := by
  intro p hp
  have h : env56112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56111_56112 : H12AffineEnvironment.transform 1 2 env56111 = env56112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56111 == env56112) = true)

theorem identity56112 : scanCanonicalize (H12AffineFastState.compose env56112 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56112 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56113 : List Nat := [2,2,2,0,1,1,2,3,0,2,1,0,3,0,1,2,1,0,3,0,1,1,0,3,2,1,1,0,0,1,3,0,3,1,0,0]

theorem envBound56113 : H12AffineFastState.Bounded env56113 := by
  intro p hp
  have h : env56113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56112_56113 : H12AffineEnvironment.transform 4 1 env56112 = env56113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56112 == env56113) = true)

def env56114 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,8192,64,8524,392,8358,264,320,8525,0,460,8358,393,8328,8422,303,8423,64,10626,8204,8422,256,8200,0,324]

theorem envBound56114 : H12AffineFastState.Bounded env56114 := by
  intro p hp
  have h : env56114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56104_56114 : H12AffineEnvironment.transform 3 1 env56104 = env56114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56104 == env56114) = true)

theorem identity56114 : scanCanonicalize (H12AffineFastState.compose env56114 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56114 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56115 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,269,64,65,392,427,264,320,64,0,460,427,393,389,491,303,490,64,2191,257,491,256,261,0,324]

theorem envBound56115 : H12AffineFastState.Bounded env56115 := by
  intro p hp
  have h : env56115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56114_56115 : H12AffineEnvironment.transform 12 269 env56114 = env56115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56114 == env56115) = true)

theorem identity56115 : scanCanonicalize (H12AffineFastState.compose env56115 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound56115 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56116 : List Nat := [2,4,8,1,32,64,47,256,325,320,2048,1,269,64,65,295,260,264,320,64,0,355,260,294,298,324,303,325,64,2080,257,324,256,261,0,324]

theorem envBound56116 : H12AffineFastState.Bounded env56116 := by
  intro p hp
  have h : env56116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56115_56116 : H12AffineEnvironment.transform 6 47 env56115 = env56116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env56115 == env56116) = true)

theorem identity56116 : scanCanonicalize (H12AffineFastState.compose env56116 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56116 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56117 : List Nat := [2,4,8,1,32,0,47,256,261,256,2048,1,269,0,1,295,260,264,256,0,0,291,260,294,298,260,303,261,0,2080,257,260,256,261,0,260]

theorem envBound56117 : H12AffineFastState.Bounded env56117 := by
  intro p hp
  have h : env56117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56116_56117 : H12AffineEnvironment.transform 5 0 env56116 = env56117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56116 == env56117) = true)

theorem identity56117 : scanCanonicalize (H12AffineFastState.compose env56117 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56118 : List Nat := [2,3,8,1,32,0,40,256,258,256,2048,1,266,0,1,288,259,264,256,0,0,291,259,289,298,259,296,258,0,2080,257,259,256,258,0,259]

theorem envBound56118 : H12AffineFastState.Bounded env56118 := by
  intro p hp
  have h : env56118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56117_56118 : H12AffineEnvironment.transform 1 3 env56117 = env56118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56117 == env56118) = true)

theorem identity56118 : scanCanonicalize (H12AffineFastState.compose env56118 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56118 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56119 : List Nat := [2,3,8,1,10,0,2,256,258,256,2048,1,266,0,1,266,259,264,256,0,0,265,259,267,256,259,258,258,0,2058,257,259,256,258,0,259]

theorem envBound56119 : H12AffineFastState.Bounded env56119 := by
  intro p hp
  have h : env56119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56118_56119 : H12AffineEnvironment.transform 4 10 env56118 = env56119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56118 == env56119) = true)

def env56120 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8525,65536,74030,65664,336,8524,16,477,74047,65536,8344,74110,302,74110,81,75802,8204,74094,256,8200,0,325]

theorem envBound56120 : H12AffineFastState.Bounded env56120 := by
  intro p hp
  have h : env56120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56102_56120 : H12AffineEnvironment.transform 11 17 env56102 = env56120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env56102 == env56120) = true)

theorem identity56120 : scanCanonicalize (H12AffineFastState.compose env56120 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8657) := by decide +kernel

theorem selectedBound56120 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56121 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8525,8657,255,8529,336,8524,16,477,238,8657,8344,175,302,175,81,2507,8204,191,256,8200,0,325]

theorem envBound56121 : H12AffineFastState.Bounded env56121 := by
  intro p hp
  have h : env56121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56120_56121 : H12AffineEnvironment.transform 15 8657 env56120 = env56121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8657 env56120 == env56121) = true)

def env56122 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,8192,65,8525,8641,239,8513,320,8524,0,461,238,8641,8328,175,302,175,65,2507,8204,175,256,8200,0,325]

theorem envBound56122 : H12AffineFastState.Bounded env56122 := by
  intro p hp
  have h : env56122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56121_56122 : H12AffineEnvironment.transform 3 0 env56121 = env56122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56121 == env56122) = true)

theorem identity56122 : scanCanonicalize (H12AffineFastState.compose env56122 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56122 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56123 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,269,65,64,204,239,76,320,65,0,461,238,204,389,175,302,175,65,2507,257,175,256,261,0,325]

theorem envBound56123 : H12AffineFastState.Bounded env56123 := by
  intro p hp
  have h : env56123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56122_56123 : H12AffineEnvironment.transform 12 269 env56122 = env56123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56122 == env56123) = true)

theorem identity56123 : scanCanonicalize (H12AffineFastState.compose env56123 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound56123 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56124 : List Nat := [2,4,8,0,32,64,128,234,174,170,2048,1,231,65,64,204,239,76,170,65,0,39,238,204,111,175,196,175,65,2081,235,175,234,239,0,175]

theorem envBound56124 : H12AffineFastState.Bounded env56124 := by
  intro p hp
  have h : env56124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56123_56124 : H12AffineEnvironment.transform 7 234 env56123 = env56124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env56123 == env56124) = true)

theorem identity56124 : scanCanonicalize (H12AffineFastState.compose env56124 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56124 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56125 : List Nat := [2,4,8,0,32,0,128,170,174,170,2048,1,167,1,0,140,175,12,170,1,0,39,174,140,47,175,132,175,1,2081,171,175,170,175,0,175]

theorem envBound56125 : H12AffineFastState.Bounded env56125 := by
  intro p hp
  have h : env56125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56124_56125 : H12AffineEnvironment.transform 5 0 env56124 = env56125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56124 == env56125) = true)

theorem identity56125 : scanCanonicalize (H12AffineFastState.compose env56125 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound56125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56126 : List Nat := [2,4,8,0,6,0,128,140,136,140,2048,1,129,1,0,140,137,12,140,1,0,1,136,140,9,137,132,137,1,2055,141,137,140,137,0,137]

theorem envBound56126 : H12AffineFastState.Bounded env56126 := by
  intro p hp
  have h : env56126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56125_56126 : H12AffineEnvironment.transform 4 6 env56125 = env56126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env56125 == env56126) = true)

theorem identity56126 : scanCanonicalize (H12AffineFastState.compose env56126 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound56126 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56127 : List Nat := [2,4,8,0,6,0,128,140,136,140,7,1,129,1,0,140,137,12,140,1,0,1,136,140,9,137,132,137,1,0,141,137,140,137,0,137]

theorem envBound56127 : H12AffineFastState.Bounded env56127 := by
  intro p hp
  have h : env56127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56126_56127 : H12AffineEnvironment.transform 10 7 env56126 = env56127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env56126 == env56127) = true)

theorem identity56127 : scanCanonicalize (H12AffineFastState.compose env56127 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound56127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56128 : List Nat := [2,1,8,0,3,0,128,137,136,137,2,1,129,1,0,137,137,9,137,1,0,1,136,137,9,137,129,137,1,0,136,137,137,137,0,137]

theorem envBound56128 : H12AffineFastState.Bounded env56128 := by
  intro p hp
  have h : env56128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56127_56128 : H12AffineEnvironment.transform 1 1 env56127 = env56128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env56127 == env56128) = true)

theorem identity56128 : scanCanonicalize (H12AffineFastState.compose env56128 (packedSelected [1,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56128 : packedSelected [1,5,7] rootPS < 2^1333 := by decide +kernel

def env56129 : List Nat := [2,1,2,0,3,0,128,131,130,131,2,1,129,1,0,131,131,3,131,1,0,1,130,131,3,131,129,131,1,0,130,131,131,131,0,131]

theorem envBound56129 : H12AffineFastState.Bounded env56129 := by
  intro p hp
  have h : env56129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56128_56129 : H12AffineEnvironment.transform 2 2 env56128 = env56129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56128 == env56129) = true)

theorem identity56129 : scanCanonicalize (H12AffineFastState.compose env56129 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound56129 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56130 : List Nat := [2,1,2,0,3,0,1,2,3,2,2,1,0,1,0,2,2,3,2,1,0,1,3,2,3,2,0,2,1,0,3,2,2,2,0,2]

theorem envBound56130 : H12AffineFastState.Bounded env56130 := by
  intro p hp
  have h : env56130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56129_56130 : H12AffineEnvironment.transform 6 1 env56129 = env56130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env56129 == env56130) = true)

theorem identity56130 : scanCanonicalize (H12AffineFastState.compose env56130 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56131 : List Nat := [0,1,0,0,1,0,1,0,1,0,0,1,0,1,0,0,0,1,0,1,0,1,1,0,1,0,0,0,1,0,1,0,0,0,0,0]

theorem envBound56131 : H12AffineFastState.Bounded env56131 := by
  intro p hp
  have h : env56131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56130_56131 : H12AffineEnvironment.transform 0 0 env56130 = env56131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56130 == env56131) = true)

def env56132 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,8192,64,8525,8640,238,8512,321,8524,1,460,238,8640,8329,175,302,175,64,2507,8204,174,256,8200,0,325]

theorem envBound56132 : H12AffineFastState.Bounded env56132 := by
  intro p hp
  have h : env56132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56121_56132 : H12AffineEnvironment.transform 3 1 env56121 = env56132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56121 == env56132) = true)

theorem identity56132 : scanCanonicalize (H12AffineFastState.compose env56132 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 419) := by decide +kernel

theorem selectedBound56132 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56133 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,419,64,238,99,238,227,321,239,1,460,238,99,298,175,302,175,64,2507,431,174,256,427,0,325]

theorem envBound56133 : H12AffineFastState.Bounded env56133 := by
  intro p hp
  have h : env56133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56132_56133 : H12AffineEnvironment.transform 12 419 env56132 = env56133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 419 env56132 == env56133) = true)

theorem identity56133 : scanCanonicalize (H12AffineFastState.compose env56133 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound56133 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56134 : List Nat := [2,4,8,1,32,64,47,256,325,320,2048,0,268,64,65,99,65,76,321,64,1,355,65,99,298,0,302,0,64,2404,256,1,256,260,0,325]

theorem envBound56134 : H12AffineFastState.Bounded env56134 := by
  intro p hp
  have h : env56134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56133_56134 : H12AffineEnvironment.transform 6 47 env56133 = env56134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env56133 == env56134) = true)

theorem identity56134 : scanCanonicalize (H12AffineFastState.compose env56134 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound56134 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56135 : List Nat := [2,4,8,1,13,64,2,256,325,320,2048,0,268,64,65,78,65,76,321,64,1,334,65,78,263,0,259,0,64,2377,256,1,256,260,0,325]

theorem envBound56135 : H12AffineFastState.Bounded env56135 := by
  intro p hp
  have h : env56135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56134_56135 : H12AffineEnvironment.transform 4 13 env56134 = env56135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env56134 == env56135) = true)

theorem identity56135 : scanCanonicalize (H12AffineFastState.compose env56135 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56135 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env56136 : List Nat := [2,3,8,1,10,64,2,256,322,320,2048,0,267,64,65,73,65,75,321,64,1,329,65,73,256,0,259,0,64,2377,256,1,256,259,0,322]

theorem envBound56136 : H12AffineFastState.Bounded env56136 := by
  intro p hp
  have h : env56136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56135_56136 : H12AffineEnvironment.transform 1 3 env56135 = env56136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56135 == env56136) = true)

theorem identity56136 : scanCanonicalize (H12AffineFastState.compose env56136 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56136 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56137 : List Nat := [2,3,8,1,10,11,2,256,265,267,2048,0,267,11,10,2,10,0,266,11,1,258,10,2,256,0,259,0,11,2306,256,1,256,259,0,265]

theorem envBound56137 : H12AffineFastState.Bounded env56137 := by
  intro p hp
  have h : env56137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56136_56137 : H12AffineEnvironment.transform 5 11 env56136 = env56137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56136 == env56137) = true)

theorem identity56137 : scanCanonicalize (H12AffineFastState.compose env56137 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56138 : List Nat := [2,3,8,1,10,11,2,256,265,267,1,0,267,11,10,2,10,0,266,11,1,258,10,2,256,0,259,0,11,259,256,1,256,259,0,265]

theorem envBound56138 : H12AffineFastState.Bounded env56138 := by
  intro p hp
  have h : env56138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56137_56138 : H12AffineEnvironment.transform 10 1 env56137 = env56138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56137 == env56138) = true)

theorem identity56138 : scanCanonicalize (H12AffineFastState.compose env56138 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56139 : List Nat := [2,3,2,1,0,1,2,256,259,257,1,0,257,1,0,2,0,0,256,1,1,258,0,2,256,0,259,0,1,259,256,1,256,259,0,259]

theorem envBound56139 : H12AffineFastState.Bounded env56139 := by
  intro p hp
  have h : env56139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56138_56139 : H12AffineEnvironment.transform 2 2 env56138 = env56139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56138 == env56139) = true)

theorem identity56139 : scanCanonicalize (H12AffineFastState.compose env56139 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound56139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56140 : List Nat := [2,3,2,1,0,1,2,2,1,3,1,0,3,1,0,2,0,0,2,1,1,0,0,2,2,0,1,0,1,1,2,1,2,1,0,1]

theorem envBound56140 : H12AffineFastState.Bounded env56140 := by
  intro p hp
  have h : env56140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56139_56140 : H12AffineEnvironment.transform 7 2 env56139 = env56140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env56139 == env56140) = true)

def env56141 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4097,477,74047,69649,12425,78191,4415,74110,81,79883,8204,74094,256,8200,0,4437]

theorem envBound56141 : H12AffineFastState.Bounded env56141 := by
  intro p hp
  have h : env56141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56101_56141 : H12AffineEnvironment.transform 8 341 env56101 = env56141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env56101 == env56141) = true)

def env56142 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,81,8524,65536,74030,65664,337,8525,17,477,74047,65537,8345,74111,303,74110,81,75803,8204,74094,256,8200,0,325]

theorem envBound56142 : H12AffineFastState.Bounded env56142 := by
  intro p hp
  have h : env56142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56141_56142 : H12AffineEnvironment.transform 11 16 env56141 = env56142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env56141 == env56142) = true)

theorem identity56142 : scanCanonicalize (H12AffineFastState.compose env56142 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 182) := by decide +kernel

theorem selectedBound56142 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56143 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,182,81,506,65536,65944,65664,337,507,17,477,65929,65537,47,65993,303,65992,81,67757,186,66008,256,190,0,325]

theorem envBound56143 : H12AffineFastState.Bounded env56143 := by
  intro p hp
  have h : env56143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56142_56143 : H12AffineEnvironment.transform 12 182 env56142 = env56143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 182 env56142 == env56143) = true)

def env56144 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,166,65,490,65536,65928,65664,321,491,1,461,65929,65537,47,65993,303,65992,65,67757,170,65992,256,174,0,325]

theorem envBound56144 : H12AffineFastState.Bounded env56144 := by
  intro p hp
  have h : env56144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56143_56144 : H12AffineEnvironment.transform 3 0 env56143 = env56144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56143 == env56144) = true)

theorem identity56144 : scanCanonicalize (H12AffineFastState.compose env56144 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound56144 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56145 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,166,65,490,98,490,226,321,491,1,461,491,99,47,427,303,426,65,2255,170,426,256,174,0,325]

theorem envBound56145 : H12AffineFastState.Bounded env56145 := by
  intro p hp
  have h : env56145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56144_56145 : H12AffineEnvironment.transform 15 98 env56144 = env56145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env56144 == env56145) = true)

theorem identity56145 : scanCanonicalize (H12AffineFastState.compose env56145 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound56145 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56146 : List Nat := [2,4,8,0,32,64,128,170,239,234,2048,0,166,65,64,98,64,226,235,65,1,103,65,99,47,1,133,0,65,2255,170,0,170,174,0,239]

theorem envBound56146 : H12AffineFastState.Bounded env56146 := by
  intro p hp
  have h : env56146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56145_56146 : H12AffineEnvironment.transform 7 170 env56145 = env56146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env56145 == env56146) = true)

theorem identity56146 : scanCanonicalize (H12AffineFastState.compose env56146 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56146 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56147 : List Nat := [2,4,8,0,32,64,3,41,108,105,2048,0,37,65,64,98,64,97,104,65,1,103,65,99,47,1,6,0,65,2124,41,0,41,45,0,108]

theorem envBound56147 : H12AffineFastState.Bounded env56147 := by
  intro p hp
  have h : env56147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56146_56147 : H12AffineEnvironment.transform 6 3 env56146 = env56147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56146 == env56147) = true)

theorem identity56147 : scanCanonicalize (H12AffineFastState.compose env56147 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56147 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env56148 : List Nat := [2,4,8,0,10,64,3,3,70,67,2048,0,15,65,64,72,64,75,66,65,1,77,65,73,5,1,6,0,65,2124,3,0,3,7,0,70]

theorem envBound56148 : H12AffineFastState.Bounded env56148 := by
  intro p hp
  have h : env56148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56147_56148 : H12AffineEnvironment.transform 4 10 env56147 = env56148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56147 == env56148) = true)

theorem identity56148 : scanCanonicalize (H12AffineFastState.compose env56148 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56148 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56149 : List Nat := [2,4,8,0,10,11,3,3,13,8,2048,0,15,10,11,3,11,0,9,10,1,6,10,2,5,1,6,0,10,2055,3,0,3,7,0,13]

theorem envBound56149 : H12AffineFastState.Bounded env56149 := by
  intro p hp
  have h : env56149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56148_56149 : H12AffineEnvironment.transform 5 11 env56148 = env56149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56148 == env56149) = true)

theorem identity56149 : scanCanonicalize (H12AffineFastState.compose env56149 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56150 : List Nat := [2,4,8,0,10,11,3,3,13,8,1,0,15,10,11,3,11,0,9,10,1,6,10,2,5,1,6,0,10,6,3,0,3,7,0,13]

theorem envBound56150 : H12AffineFastState.Bounded env56150 := by
  intro p hp
  have h : env56150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56149_56150 : H12AffineEnvironment.transform 10 1 env56149 = env56150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56149 == env56150) = true)

theorem identity56150 : scanCanonicalize (H12AffineFastState.compose env56150 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56151 : List Nat := [2,4,3,0,1,0,3,3,6,3,1,0,4,1,0,3,0,0,2,1,1,6,1,2,5,1,6,0,1,6,3,0,3,7,0,6]

theorem envBound56151 : H12AffineFastState.Bounded env56151 := by
  intro p hp
  have h : env56151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56150_56151 : H12AffineEnvironment.transform 2 3 env56150 = env56151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56150 == env56151) = true)

theorem identity56151 : scanCanonicalize (H12AffineFastState.compose env56151 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56151 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56152 : List Nat := [2,3,3,0,1,0,3,3,1,3,1,0,3,1,0,3,0,0,2,1,1,1,1,2,2,1,1,0,1,1,3,0,3,0,0,1]

theorem envBound56152 : H12AffineFastState.Bounded env56152 := by
  intro p hp
  have h : env56152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56151_56152 : H12AffineEnvironment.transform 1 3 env56151 = env56152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56151 == env56152) = true)

def env56153 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,167,64,491,65536,65929,65664,320,490,0,460,65929,65537,47,65993,303,65992,64,67757,171,65993,256,175,0,325]

theorem envBound56153 : H12AffineFastState.Bounded env56153 := by
  intro p hp
  have h : env56153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56143_56153 : H12AffineEnvironment.transform 3 1 env56143 = env56153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56143 == env56153) = true)

theorem identity56153 : scanCanonicalize (H12AffineFastState.compose env56153 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound56153 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56154 : List Nat := [2,4,8,1,32,64,128,170,238,234,2048,1,167,64,65,65536,65571,65664,234,64,0,102,65571,65537,47,65635,133,65634,64,67757,171,65635,170,175,0,239]

theorem envBound56154 : H12AffineFastState.Bounded env56154 := by
  intro p hp
  have h : env56154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56153_56154 : H12AffineEnvironment.transform 7 170 env56153 = env56154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env56153 == env56154) = true)

theorem identity56154 : scanCanonicalize (H12AffineFastState.compose env56154 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound56154 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56155 : List Nat := [2,4,8,1,32,64,128,170,238,234,2048,1,167,64,65,141,174,13,234,64,0,102,174,140,47,238,133,239,64,2080,171,238,170,175,0,239]

theorem envBound56155 : H12AffineFastState.Bounded env56155 := by
  intro p hp
  have h : env56155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56154_56155 : H12AffineEnvironment.transform 15 141 env56154 = env56155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env56154 == env56155) = true)

theorem identity56155 : scanCanonicalize (H12AffineFastState.compose env56155 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56155 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56156 : List Nat := [2,4,8,1,32,0,128,170,174,170,2048,1,167,0,1,141,174,13,170,0,0,38,174,140,47,174,133,175,0,2080,171,174,170,175,0,175]

theorem envBound56156 : H12AffineFastState.Bounded env56156 := by
  intro p hp
  have h : env56156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56155_56156 : H12AffineEnvironment.transform 5 0 env56155 = env56156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56155 == env56156) = true)

theorem identity56156 : scanCanonicalize (H12AffineFastState.compose env56156 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56157 : List Nat := [2,4,8,1,32,0,41,3,7,3,2048,1,14,0,1,36,7,13,3,0,0,38,7,37,47,7,44,6,0,2080,2,7,3,6,0,6]

theorem envBound56157 : H12AffineFastState.Bounded env56157 := by
  intro p hp
  have h : env56157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56156_56157 : H12AffineEnvironment.transform 6 41 env56156 = env56157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56156 == env56157) = true)

theorem identity56157 : scanCanonicalize (H12AffineFastState.compose env56157 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56157 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56158 : List Nat := [2,4,8,1,12,0,5,3,7,3,2048,1,14,0,1,8,7,13,3,0,0,10,7,9,3,7,0,6,0,2060,2,7,3,6,0,6]

theorem envBound56158 : H12AffineFastState.Bounded env56158 := by
  intro p hp
  have h : env56158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56157_56158 : H12AffineEnvironment.transform 4 12 env56157 = env56158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56157 == env56158) = true)

theorem identity56158 : scanCanonicalize (H12AffineFastState.compose env56158 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56158 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56159 : List Nat := [2,2,8,1,10,0,3,3,1,3,2048,1,8,0,1,8,1,11,3,0,0,10,1,9,3,1,0,0,0,2058,2,1,3,0,0,0]

theorem envBound56159 : H12AffineFastState.Bounded env56159 := by
  intro p hp
  have h : env56159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56158_56159 : H12AffineEnvironment.transform 1 2 env56158 = env56159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56158 == env56159) = true)

theorem identity56159 : scanCanonicalize (H12AffineFastState.compose env56159 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56159 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56160 : List Nat := [2,2,8,1,10,0,3,3,1,3,0,1,8,0,1,8,1,11,3,0,0,10,1,9,3,1,0,0,0,10,2,1,3,0,0,0]

theorem envBound56160 : H12AffineFastState.Bounded env56160 := by
  intro p hp
  have h : env56160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56159_56160 : H12AffineEnvironment.transform 10 0 env56159 = env56160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56159 == env56160) = true)

theorem identity56160 : scanCanonicalize (H12AffineFastState.compose env56160 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56161 : List Nat := [2,2,0,1,2,0,3,3,1,3,0,1,0,0,1,0,1,3,3,0,0,2,1,1,3,1,0,0,0,2,2,1,3,0,0,0]

theorem envBound56161 : H12AffineFastState.Bounded env56161 := by
  intro p hp
  have h : env56161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56160_56161 : H12AffineEnvironment.transform 2 0 env56160 = env56161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56160 == env56161) = true)

def env56162 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,81,8525,65536,74030,65664,336,8524,16,477,74047,65536,8344,74110,302,74110,81,75802,8204,74094,256,8200,0,324]

theorem envBound56162 : H12AffineFastState.Bounded env56162 := by
  intro p hp
  have h : env56162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56141_56162 : H12AffineEnvironment.transform 11 17 env56141 = env56162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env56141 == env56162) = true)

theorem identity56162 : scanCanonicalize (H12AffineFastState.compose env56162 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 126) := by decide +kernel

theorem selectedBound56162 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56163 : List Nat := [2,4,8,16,32,64,126,256,341,320,2048,17,8192,81,8525,65536,74030,65662,336,8524,16,291,74047,65536,8294,74110,302,74110,81,75802,8204,74094,256,8200,0,324]

theorem envBound56163 : H12AffineFastState.Bounded env56163 := by
  intro p hp
  have h : env56163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56162_56163 : H12AffineEnvironment.transform 6 126 env56162 = env56163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 126 env56162 == env56163) = true)

def env56164 : List Nat := [2,4,8,0,32,64,110,256,325,320,2048,1,8192,65,8525,65536,74030,65646,320,8524,0,291,74031,65536,8294,74094,302,74094,65,75786,8204,74094,256,8200,0,324]

theorem envBound56164 : H12AffineFastState.Bounded env56164 := by
  intro p hp
  have h : env56164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56163_56164 : H12AffineEnvironment.transform 3 0 env56163 = env56164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56163 == env56164) = true)

theorem identity56164 : scanCanonicalize (H12AffineFastState.compose env56164 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56164 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56165 : List Nat := [2,4,8,0,32,64,110,256,325,320,2048,1,269,65,64,65536,65571,65646,320,65,0,291,65570,65536,363,65635,302,65635,65,67847,257,65635,256,261,0,324]

theorem envBound56165 : H12AffineFastState.Bounded env56165 := by
  intro p hp
  have h : env56165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56164_56165 : H12AffineEnvironment.transform 12 269 env56164 = env56165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56164 == env56165) = true)

theorem identity56165 : scanCanonicalize (H12AffineFastState.compose env56165 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound56165 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56166 : List Nat := [2,4,8,0,32,64,110,256,325,320,2048,1,269,65,64,294,261,328,320,65,0,291,260,294,363,325,302,325,65,2081,257,325,256,261,0,324]

theorem envBound56166 : H12AffineFastState.Bounded env56166 := by
  intro p hp
  have h : env56166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56165_56166 : H12AffineEnvironment.transform 15 294 env56165 = env56166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env56165 == env56166) = true)

theorem identity56166 : scanCanonicalize (H12AffineFastState.compose env56166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56167 : List Nat := [2,4,8,0,32,0,46,256,261,256,2048,1,269,1,0,294,261,264,256,1,0,291,260,294,299,261,302,261,1,2081,257,261,256,261,0,260]

theorem envBound56167 : H12AffineFastState.Bounded env56167 := by
  intro p hp
  have h : env56167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56166_56167 : H12AffineEnvironment.transform 5 0 env56166 = env56167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56166 == env56167) = true)

theorem identity56167 : scanCanonicalize (H12AffineFastState.compose env56167 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound56167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56168 : List Nat := [2,4,8,0,32,0,46,35,38,35,2048,1,46,1,0,5,38,43,35,1,0,0,39,5,8,38,13,38,1,2081,34,38,35,38,0,39]

theorem envBound56168 : H12AffineFastState.Bounded env56168 := by
  intro p hp
  have h : env56168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56167_56168 : H12AffineEnvironment.transform 7 35 env56167 = env56168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env56167 == env56168) = true)

theorem identity56168 : scanCanonicalize (H12AffineFastState.compose env56168 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound56168 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56169 : List Nat := [2,4,8,0,32,0,46,35,38,35,7,1,46,1,0,5,38,43,35,1,0,0,39,5,8,38,13,38,1,38,34,38,35,38,0,39]

theorem envBound56169 : H12AffineFastState.Bounded env56169 := by
  intro p hp
  have h : env56169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56168_56169 : H12AffineEnvironment.transform 10 7 env56168 = env56169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env56168 == env56169) = true)

theorem identity56169 : scanCanonicalize (H12AffineFastState.compose env56169 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound56169 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56170 : List Nat := [2,4,8,0,9,0,7,10,15,10,7,1,7,1,0,5,15,2,10,1,0,0,14,5,8,15,13,15,1,15,11,15,10,15,0,14]

theorem envBound56170 : H12AffineFastState.Bounded env56170 := by
  intro p hp
  have h : env56170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56169_56170 : H12AffineEnvironment.transform 4 9 env56169 = env56170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env56169 == env56170) = true)

theorem identity56170 : scanCanonicalize (H12AffineFastState.compose env56170 (packedSelected [0,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56170 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env56171 : List Nat := [2,4,5,0,4,0,7,7,2,7,7,1,7,1,0,5,2,2,7,1,0,0,3,5,5,2,0,2,1,2,6,2,7,2,0,3]

theorem envBound56171 : H12AffineFastState.Bounded env56171 := by
  intro p hp
  have h : env56171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56170_56171 : H12AffineEnvironment.transform 2 5 env56170 = env56171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56170 == env56171) = true)

def env56172 : List Nat := [2,4,8,1,32,64,111,256,324,320,2048,0,8192,64,8525,65536,74030,65647,321,8524,1,291,74030,65536,8294,74095,302,74095,64,75787,8204,74094,256,8200,0,324]

theorem envBound56172 : H12AffineFastState.Bounded env56172 := by
  intro p hp
  have h : env56172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56163_56172 : H12AffineEnvironment.transform 3 1 env56163 = env56172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56163 == env56172) = true)

theorem identity56172 : scanCanonicalize (H12AffineFastState.compose env56172 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound56172 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56173 : List Nat := [2,4,8,1,32,64,111,256,324,320,2048,0,8192,64,8525,99,8525,12,321,8524,1,291,8525,99,8294,8460,302,8460,64,10344,8204,8461,256,8200,0,324]

theorem envBound56173 : H12AffineFastState.Bounded env56173 := by
  intro p hp
  have h : env56173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56172_56173 : H12AffineEnvironment.transform 15 99 env56172 = env56173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env56172 == env56173) = true)

theorem identity56173 : scanCanonicalize (H12AffineFastState.compose env56173 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56173 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56174 : List Nat := [2,4,8,1,32,64,111,256,324,320,2048,0,268,64,65,99,65,12,321,64,1,291,65,99,362,0,302,0,64,2404,256,1,256,260,0,324]

theorem envBound56174 : H12AffineFastState.Bounded env56174 := by
  intro p hp
  have h : env56174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56173_56174 : H12AffineEnvironment.transform 12 268 env56173 = env56174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56173 == env56174) = true)

theorem identity56174 : scanCanonicalize (H12AffineFastState.compose env56174 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56174 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56175 : List Nat := [2,4,8,1,12,64,67,256,324,320,2048,0,268,64,65,79,65,12,321,64,1,271,65,79,326,0,258,0,64,2376,256,1,256,260,0,324]

theorem envBound56175 : H12AffineFastState.Bounded env56175 := by
  intro p hp
  have h : env56175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56174_56175 : H12AffineEnvironment.transform 4 12 env56174 = env56175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56174 == env56175) = true)

theorem identity56175 : scanCanonicalize (H12AffineFastState.compose env56175 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound56175 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env56176 : List Nat := [2,4,8,1,12,7,4,256,259,263,2048,0,268,7,6,8,6,12,262,7,1,271,6,8,257,0,258,0,7,2319,256,1,256,260,0,259]

theorem envBound56176 : H12AffineFastState.Bounded env56176 := by
  intro p hp
  have h : env56176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56175_56176 : H12AffineEnvironment.transform 5 7 env56175 = env56176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env56175 == env56176) = true)

theorem identity56176 : scanCanonicalize (H12AffineFastState.compose env56176 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56176 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56177 : List Nat := [2,4,3,1,7,7,4,256,259,263,2048,0,263,7,6,3,6,7,262,7,1,260,6,3,257,0,258,0,7,2308,256,1,256,260,0,259]

theorem envBound56177 : H12AffineFastState.Bounded env56177 := by
  intro p hp
  have h : env56177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56176_56177 : H12AffineEnvironment.transform 2 3 env56176 = env56177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56176 == env56177) = true)

theorem identity56177 : scanCanonicalize (H12AffineFastState.compose env56177 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound56177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56178 : List Nat := [2,4,3,1,7,7,4,256,259,263,6,0,263,7,6,3,6,7,262,7,1,260,6,3,257,0,258,0,7,258,256,1,256,260,0,259]

theorem envBound56178 : H12AffineFastState.Bounded env56178 := by
  intro p hp
  have h : env56178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56177_56178 : H12AffineEnvironment.transform 10 6 env56177 = env56178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env56177 == env56178) = true)

theorem identity56178 : scanCanonicalize (H12AffineFastState.compose env56178 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound56178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56179 : List Nat := [2,4,3,1,7,7,4,3,0,4,6,0,4,7,6,3,6,7,5,7,1,7,6,3,2,0,1,0,7,1,3,1,3,7,0,0]

theorem envBound56179 : H12AffineFastState.Bounded env56179 := by
  intro p hp
  have h : env56179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56178_56179 : H12AffineEnvironment.transform 7 3 env56178 = env56179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env56178 == env56179) = true)

theorem identity56179 : scanCanonicalize (H12AffineFastState.compose env56179 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56180 : List Nat := [2,3,3,1,0,0,3,3,0,3,1,0,3,0,1,3,1,0,2,0,1,0,1,3,2,0,1,0,0,1,3,1,3,0,0,0]

theorem envBound56180 : H12AffineFastState.Bounded env56180 := by
  intro p hp
  have h : env56180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56179_56180 : H12AffineEnvironment.transform 1 3 env56179 = env56180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56179 == env56180) = true)

def env56181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4097,477,74047,69649,13769,78895,4414,74814,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound56181 : H12AffineFastState.Bounded env56181 := by
  intro p hp
  have h : env56181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56099_56181 : H12AffineEnvironment.transform 17 65665 env56099 = env56181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56099 == env56181) = true)

theorem identity56181 : scanCanonicalize (H12AffineFastState.compose env56181 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound56181 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,0,477,74047,65552,9672,74798,319,74814,1297,77130,8204,74798,256,8200,1344,1857]

theorem envBound56182 : H12AffineFastState.Bounded env56182 := by
  intro p hp
  have h : env56182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56181_56182 : H12AffineEnvironment.transform 11 1 env56181 = env56182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56181 == env56182) = true)

def env56183 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,0,477,74047,65552,9672,74798,319,74814,1297,77130,8204,74798,256,8200,1344,1045]

theorem envBound56183 : H12AffineFastState.Bounded env56183 := by
  intro p hp
  have h : env56183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56182_56183 : H12AffineEnvironment.transform 8 340 env56182 = env56183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env56182 == env56183) = true)

def env56184 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9229,65536,74862,65665,320,9228,0,461,74031,65536,9672,74798,303,74798,1281,77130,8204,74798,256,8200,1344,1029]

theorem envBound56184 : H12AffineFastState.Bounded env56184 := by
  intro p hp
  have h : env56184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56183_56184 : H12AffineEnvironment.transform 3 0 env56183 = env56184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56183 == env56184) = true)

theorem identity56184 : scanCanonicalize (H12AffineFastState.compose env56184 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9345) := by decide +kernel

theorem selectedBound56184 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56185 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9229,9345,239,9216,320,9228,0,461,1454,9345,9672,175,303,175,1281,2507,8204,175,256,8200,1344,1029]

theorem envBound56185 : H12AffineFastState.Bounded env56185 := by
  intro p hp
  have h : env56185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56184_56185 : H12AffineEnvironment.transform 15 9345 env56184 = env56185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9345 env56184 == env56185) = true)

def env56186 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,160,1281,1197,1057,239,1184,320,1196,0,461,1454,1057,1384,175,303,175,1281,2507,172,175,256,168,1344,1029]

theorem envBound56186 : H12AffineFastState.Bounded env56186 := by
  intro p hp
  have h : env56186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56185_56186 : H12AffineEnvironment.transform 12 160 env56185 = env56186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env56185 == env56186) = true)

theorem identity56186 : scanCanonicalize (H12AffineFastState.compose env56186 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound56186 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56187 : List Nat := [2,4,8,0,32,64,128,67,7,1024,2048,1,160,1090,1197,1057,239,1184,3,1196,0,142,1261,1057,1067,175,108,175,1090,2184,172,175,67,168,1027,1029]

theorem envBound56187 : H12AffineFastState.Bounded env56187 := by
  intro p hp
  have h : env56187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56186_56187 : H12AffineEnvironment.transform 7 67 env56186 = env56187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env56186 == env56187) = true)

theorem identity56187 : scanCanonicalize (H12AffineFastState.compose env56187 (packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound56187 : packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env56188 : List Nat := [2,4,8,0,32,64,128,67,7,101,2048,1,160,39,200,68,239,197,3,201,0,142,136,68,78,175,108,175,39,2184,172,175,67,168,102,96]

theorem envBound56188 : H12AffineFastState.Bounded env56188 := by
  intro p hp
  have h : env56188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56187_56188 : H12AffineEnvironment.transform 9 101 env56187 = env56188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env56187 == env56188) = true)

theorem identity56188 : scanCanonicalize (H12AffineFastState.compose env56188 (packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56188 : packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56189 : List Nat := [2,2,8,0,32,64,128,67,1,99,2048,1,160,33,200,66,233,195,3,201,0,136,136,66,72,169,106,169,33,2184,170,169,67,168,96,96]

theorem envBound56189 : H12AffineFastState.Bounded env56189 := by
  intro p hp
  have h : env56189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56188_56189 : H12AffineEnvironment.transform 1 2 env56188 = env56189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56188 == env56189) = true)

theorem identity56189 : scanCanonicalize (H12AffineFastState.compose env56189 (packedSelected [2,4,5,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound56189 : packedSelected [2,4,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env56190 : List Nat := [2,2,8,0,32,33,128,34,1,2,2048,1,160,33,169,35,136,162,3,168,0,136,136,35,41,169,11,169,33,2184,170,169,34,168,1,1]

theorem envBound56190 : H12AffineFastState.Bounded env56190 := by
  intro p hp
  have h : env56190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56189_56190 : H12AffineEnvironment.transform 5 33 env56189 = env56190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56189 == env56190) = true)

theorem identity56190 : scanCanonicalize (H12AffineFastState.compose env56190 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound56190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56191 : List Nat := [2,2,8,0,32,33,128,34,1,2,137,1,160,33,169,35,136,162,3,168,0,136,136,35,41,169,11,169,33,1,170,169,34,168,1,1]

theorem envBound56191 : H12AffineFastState.Bounded env56191 := by
  intro p hp
  have h : env56191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56190_56191 : H12AffineEnvironment.transform 10 137 env56190 = env56191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env56190 == env56191) = true)

theorem identity56191 : scanCanonicalize (H12AffineFastState.compose env56191 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56191 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56192 : List Nat := [2,2,8,0,32,33,40,34,1,2,33,1,8,33,1,35,32,10,3,0,0,32,32,35,41,1,11,1,33,1,2,1,34,0,1,1]

theorem envBound56192 : H12AffineFastState.Bounded env56192 := by
  intro p hp
  have h : env56192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56191_56192 : H12AffineEnvironment.transform 6 40 env56191 = env56192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56191 == env56192) = true)

theorem identity56192 : scanCanonicalize (H12AffineFastState.compose env56192 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56193 : List Nat := [2,2,8,0,11,10,3,9,1,2,10,1,8,10,1,8,11,10,3,0,0,11,11,8,2,1,11,1,10,1,2,1,9,0,1,1]

theorem envBound56193 : H12AffineFastState.Bounded env56193 := by
  intro p hp
  have h : env56193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56192_56193 : H12AffineEnvironment.transform 4 11 env56192 = env56193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56192 == env56193) = true)

def env56194 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,161,1281,1196,1056,239,1185,320,1197,0,461,1454,1056,1385,175,303,175,1281,2507,173,175,256,169,1344,1029]

theorem envBound56194 : H12AffineFastState.Bounded env56194 := by
  intro p hp
  have h : env56194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56185_56194 : H12AffineEnvironment.transform 12 161 env56185 = env56194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env56185 == env56194) = true)

theorem identity56194 : scanCanonicalize (H12AffineFastState.compose env56194 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound56194 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56195 : List Nat := [2,4,8,0,32,64,128,256,324,236,2048,1,161,493,64,204,239,77,320,65,0,461,322,204,389,175,303,175,493,2507,173,175,256,169,428,233]

theorem envBound56195 : H12AffineFastState.Bounded env56195 := by
  intro p hp
  have h : env56195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56194_56195 : H12AffineEnvironment.transform 9 236 env56194 = env56195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env56194 == env56195) = true)

theorem identity56195 : scanCanonicalize (H12AffineFastState.compose env56195 (packedSelected [0,1,5,7,10,17,19,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound56195 : packedSelected [0,1,5,7,10,17,19,21,23] rootPS < 2^1333 := by decide +kernel

def env56196 : List Nat := [2,4,8,0,32,64,128,67,7,236,2048,1,161,174,64,204,239,77,3,65,0,142,1,204,198,175,108,175,174,2184,173,175,67,169,239,233]

theorem envBound56196 : H12AffineFastState.Bounded env56196 := by
  intro p hp
  have h : env56196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56195_56196 : H12AffineEnvironment.transform 7 67 env56195 = env56196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env56195 == env56196) = true)

theorem identity56196 : scanCanonicalize (H12AffineFastState.compose env56196 (packedSelected [0,2,4,5,7,8,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound56196 : packedSelected [0,2,4,5,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56197 : List Nat := [2,4,8,0,32,64,128,67,7,236,6,1,161,174,64,204,239,77,3,65,0,142,1,204,198,175,108,175,174,142,173,175,67,169,239,233]

theorem envBound56197 : H12AffineFastState.Bounded env56197 := by
  intro p hp
  have h : env56197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56196_56197 : H12AffineEnvironment.transform 10 6 env56196 = env56197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env56196 == env56197) = true)

theorem identity56197 : scanCanonicalize (H12AffineFastState.compose env56197 (packedSelected [1,2,5,7,8,9,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56197 : packedSelected [1,2,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env56198 : List Nat := [2,4,2,0,32,64,128,67,7,230,6,1,161,164,64,198,229,71,3,65,0,132,1,198,198,165,102,165,164,132,167,165,67,163,229,227]

theorem envBound56198 : H12AffineFastState.Bounded env56198 := by
  intro p hp
  have h : env56198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56197_56198 : H12AffineEnvironment.transform 2 2 env56197 = env56198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56197 == env56198) = true)

theorem identity56198 : scanCanonicalize (H12AffineFastState.compose env56198 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound56198 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env56199 : List Nat := [2,4,2,0,32,64,68,67,7,34,6,1,101,96,64,2,33,71,3,65,0,64,1,2,2,97,102,97,96,64,99,97,67,103,33,39]

theorem envBound56199 : H12AffineFastState.Bounded env56199 := by
  intro p hp
  have h : env56199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56198_56199 : H12AffineEnvironment.transform 6 68 env56198 = env56199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env56198 == env56199) = true)

theorem identity56199 : scanCanonicalize (H12AffineFastState.compose env56199 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56199 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56200 : List Nat := [2,3,2,0,32,64,67,67,0,34,1,1,98,96,64,2,33,64,3,65,0,64,1,2,2,97,97,97,96,64,99,97,67,96,33,32]

theorem envBound56200 : H12AffineFastState.Bounded env56200 := by
  intro p hp
  have h : env56200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56199_56200 : H12AffineEnvironment.transform 1 3 env56199 = env56200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56199 == env56200) = true)

def env56201 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9228,65536,74862,65665,320,9229,0,460,74030,65537,9672,74798,302,74799,1280,77130,8204,74798,256,8200,1344,1028]

theorem envBound56201 : H12AffineFastState.Bounded env56201 := by
  intro p hp
  have h : env56201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56183_56201 : H12AffineEnvironment.transform 3 1 env56183 = env56201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56183 == env56201) = true)

theorem identity56201 : scanCanonicalize (H12AffineFastState.compose env56201 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 392) := by decide +kernel

theorem selectedBound56201 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56202 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9228,392,9702,265,320,9229,0,460,8358,393,9672,9638,302,9639,1280,11458,8204,9638,256,8200,1344,1028]

theorem envBound56202 : H12AffineFastState.Bounded env56202 := by
  intro p hp
  have h : env56202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56201_56202 : H12AffineEnvironment.transform 15 392 env56201 = env56202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env56201 == env56202) = true)

def env56203 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,160,1280,1196,392,1350,265,320,1197,0,460,6,393,1384,1286,302,1287,1280,3170,172,1286,256,168,1344,1028]

theorem envBound56203 : H12AffineFastState.Bounded env56203 := by
  intro p hp
  have h : env56203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56202_56203 : H12AffineEnvironment.transform 12 160 env56202 = env56203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env56202 == env56203) = true)

theorem identity56203 : scanCanonicalize (H12AffineFastState.compose env56203 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound56203 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56204 : List Nat := [2,4,8,1,32,64,128,256,325,234,2048,1,160,490,70,392,428,265,320,71,0,460,6,393,386,492,302,493,490,2184,172,492,256,168,426,238]

theorem envBound56204 : H12AffineFastState.Bounded env56204 := by
  intro p hp
  have h : env56204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56203_56204 : H12AffineEnvironment.transform 9 234 env56203 = env56204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env56203 == env56204) = true)

theorem identity56204 : scanCanonicalize (H12AffineFastState.compose env56204 (packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound56204 : packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env56205 : List Nat := [2,4,8,1,32,64,14,256,325,100,2048,1,46,356,70,262,290,265,320,71,0,322,6,263,268,354,302,355,356,2054,34,354,256,38,292,96]

theorem envBound56205 : H12AffineFastState.Bounded env56205 := by
  intro p hp
  have h : env56205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56204_56205 : H12AffineEnvironment.transform 6 14 env56204 = env56205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env56204 == env56205) = true)

theorem identity56205 : scanCanonicalize (H12AffineFastState.compose env56205 (packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 361) := by decide +kernel

theorem selectedBound56205 : packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56206 : List Nat := [2,4,8,1,32,64,14,256,325,100,361,1,46,356,70,262,290,265,320,71,0,322,6,263,268,354,302,355,356,367,34,354,256,38,292,96]

theorem envBound56206 : H12AffineFastState.Bounded env56206 := by
  intro p hp
  have h : env56206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56205_56206 : H12AffineEnvironment.transform 10 361 env56205 = env56206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 361 env56205 == env56206) = true)

theorem identity56206 : scanCanonicalize (H12AffineFastState.compose env56206 (packedSelected [0,1,2,8,9,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56206 : packedSelected [0,1,2,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56207 : List Nat := [2,4,5,1,32,64,3,256,325,100,356,1,35,356,70,262,290,260,320,71,0,322,6,263,257,354,291,355,356,354,34,354,256,38,292,96]

theorem envBound56207 : H12AffineFastState.Bounded env56207 := by
  intro p hp
  have h : env56207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56206_56207 : H12AffineEnvironment.transform 2 5 env56206 = env56207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56206 == env56207) = true)

theorem identity56207 : scanCanonicalize (H12AffineFastState.compose env56207 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound56207 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56208 : List Nat := [2,4,5,1,32,32,3,256,293,4,260,1,35,260,38,262,290,260,288,39,0,290,6,263,257,258,291,259,260,258,34,258,256,38,292,0]

theorem envBound56208 : H12AffineFastState.Bounded env56208 := by
  intro p hp
  have h : env56208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56207_56208 : H12AffineEnvironment.transform 5 32 env56207 = env56208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56207 == env56208) = true)

theorem identity56208 : scanCanonicalize (H12AffineFastState.compose env56208 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound56208 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env56209 : List Nat := [2,4,5,1,32,32,3,35,6,4,39,1,35,39,38,37,1,39,3,39,0,1,6,36,34,33,0,32,39,33,34,33,35,38,7,0]

theorem envBound56209 : H12AffineFastState.Bounded env56209 := by
  intro p hp
  have h : env56209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56208_56209 : H12AffineEnvironment.transform 7 35 env56208 = env56209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env56208 == env56209) = true)

theorem identity56209 : scanCanonicalize (H12AffineFastState.compose env56209 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56209 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56210 : List Nat := [2,2,3,1,32,32,3,35,0,2,33,1,35,33,32,35,1,33,3,33,0,1,0,34,34,33,0,32,33,33,34,33,35,32,1,0]

theorem envBound56210 : H12AffineFastState.Bounded env56210 := by
  intro p hp
  have h : env56210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56209_56210 : H12AffineEnvironment.transform 1 2 env56209 = env56210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56209 == env56210) = true)

def env56211 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,161,1280,1197,392,1351,265,320,1196,0,460,7,393,1385,1287,302,1286,1280,3171,173,1287,256,169,1344,1028]

theorem envBound56211 : H12AffineFastState.Bounded env56211 := by
  intro p hp
  have h : env56211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56202_56211 : H12AffineEnvironment.transform 12 161 env56202 = env56211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env56202 == env56211) = true)

theorem identity56211 : scanCanonicalize (H12AffineFastState.compose env56211 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound56211 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56212 : List Nat := [2,4,8,1,32,64,128,256,325,236,2048,1,161,492,65,392,427,265,320,64,0,460,7,393,389,491,302,490,492,2191,173,491,256,169,428,232]

theorem envBound56212 : H12AffineFastState.Bounded env56212 := by
  intro p hp
  have h : env56212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56211_56212 : H12AffineEnvironment.transform 9 236 env56211 = env56212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env56211 == env56212) = true)

def env56213 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,0,477,74047,65552,9672,74798,319,74814,1297,77130,8204,74798,256,8200,1344,1044]

theorem envBound56213 : H12AffineFastState.Bounded env56213 := by
  intro p hp
  have h : env56213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56182_56213 : H12AffineEnvironment.transform 8 341 env56182 = env56213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env56182 == env56213) = true)

def env56214 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9229,65536,74862,65665,320,9228,0,461,74031,65536,9672,74798,303,74798,1281,77130,8204,74798,256,8200,1344,1028]

theorem envBound56214 : H12AffineFastState.Bounded env56214 := by
  intro p hp
  have h : env56214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56213_56214 : H12AffineEnvironment.transform 3 0 env56213 = env56214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56213 == env56214) = true)

theorem identity56214 : scanCanonicalize (H12AffineFastState.compose env56214 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 430) := by decide +kernel

theorem selectedBound56214 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56215 : List Nat := [2,4,8,0,32,64,128,256,325,430,2048,1,8192,175,8611,65536,74176,65665,320,8610,0,461,74031,65536,8294,74112,303,74112,175,76004,8204,74112,256,8200,238,426]

theorem envBound56215 : H12AffineFastState.Bounded env56215 := by
  intro p hp
  have h : env56215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56214_56215 : H12AffineEnvironment.transform 9 430 env56214 = env56215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 430 env56214 == env56215) = true)

def env56216 : List Nat := [2,4,8,0,32,64,128,256,325,430,2048,1,160,175,259,65536,65888,65665,320,258,0,461,65935,65536,198,65824,303,65824,175,67652,172,65824,256,168,238,426]

theorem envBound56216 : H12AffineFastState.Bounded env56216 := by
  intro p hp
  have h : env56216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56215_56216 : H12AffineEnvironment.transform 12 160 env56215 = env56216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env56215 == env56216) = true)

theorem identity56216 : scanCanonicalize (H12AffineFastState.compose env56216 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound56216 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56217 : List Nat := [2,4,8,0,32,64,128,256,325,430,2048,1,160,175,259,204,428,77,320,258,0,461,323,204,198,492,303,492,175,2184,172,492,256,168,238,426]

theorem envBound56217 : H12AffineFastState.Bounded env56217 := by
  intro p hp
  have h : env56217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56216_56217 : H12AffineEnvironment.transform 15 204 env56216 = env56217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env56216 == env56217) = true)

theorem identity56217 : scanCanonicalize (H12AffineFastState.compose env56217 (packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 202) := by decide +kernel

theorem selectedBound56217 : packedSelected [1,2,3,4,5,8,9,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env56218 : List Nat := [2,4,8,0,32,64,128,202,143,100,2048,1,160,175,201,204,102,77,138,200,0,7,137,204,198,38,229,38,175,2184,172,38,202,168,238,96]

theorem envBound56218 : H12AffineFastState.Bounded env56218 := by
  intro p hp
  have h : env56218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56217_56218 : H12AffineEnvironment.transform 7 202 env56217 = env56218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 202 env56217 == env56218) = true)

theorem identity56218 : scanCanonicalize (H12AffineFastState.compose env56218 (packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound56218 : packedSelected [0,1,2,4,7,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56219 : List Nat := [2,4,8,0,32,64,128,202,143,100,194,1,160,175,201,204,102,77,138,200,0,7,137,204,198,38,229,38,175,74,172,38,202,168,238,96]

theorem envBound56219 : H12AffineFastState.Bounded env56219 := by
  intro p hp
  have h : env56219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56218_56219 : H12AffineEnvironment.transform 10 194 env56218 = env56219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env56218 == env56219) = true)

theorem identity56219 : scanCanonicalize (H12AffineFastState.compose env56219 (packedSelected [2,3,7,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56219 : packedSelected [2,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env56220 : List Nat := [2,4,8,0,32,0,128,138,143,36,130,1,160,175,137,140,38,13,138,136,0,7,137,140,134,38,165,38,175,10,172,38,138,168,174,32]

theorem envBound56220 : H12AffineFastState.Bounded env56220 := by
  intro p hp
  have h : env56220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56219_56220 : H12AffineEnvironment.transform 5 0 env56219 = env56220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56219 == env56220) = true)

theorem identity56220 : scanCanonicalize (H12AffineFastState.compose env56220 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound56220 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env56221 : List Nat := [2,4,8,0,13,0,128,138,143,9,130,1,141,130,137,140,11,13,138,136,0,7,137,140,134,11,136,11,130,10,129,11,138,133,131,13]

theorem envBound56221 : H12AffineFastState.Bounded env56221 := by
  intro p hp
  have h : env56221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56220_56221 : H12AffineEnvironment.transform 4 13 env56220 = env56221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env56220 == env56221) = true)

theorem identity56221 : scanCanonicalize (H12AffineFastState.compose env56221 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56221 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env56222 : List Nat := [2,3,8,0,10,0,128,138,136,9,130,1,138,130,137,139,11,10,138,136,0,0,137,139,129,11,136,11,130,10,129,11,138,130,131,10]

theorem envBound56222 : H12AffineFastState.Bounded env56222 := by
  intro p hp
  have h : env56222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56221_56222 : H12AffineEnvironment.transform 1 3 env56221 = env56222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56221 == env56222) = true)

theorem identity56222 : scanCanonicalize (H12AffineFastState.compose env56222 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56223 : List Nat := [2,3,8,0,10,0,9,3,1,9,11,1,3,11,0,2,11,10,3,1,0,0,0,2,8,11,1,11,11,10,8,11,3,11,10,10]

theorem envBound56223 : H12AffineFastState.Bounded env56223 := by
  intro p hp
  have h : env56223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56222_56223 : H12AffineEnvironment.transform 6 9 env56222 = env56223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56222 == env56223) = true)

theorem identity56223 : scanCanonicalize (H12AffineFastState.compose env56223 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56223 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56224 : List Nat := [2,3,2,0,0,0,3,3,1,3,1,1,3,1,0,2,1,0,3,1,0,0,0,2,2,1,1,1,1,0,2,1,3,1,0,0]

theorem envBound56224 : H12AffineFastState.Bounded env56224 := by
  intro p hp
  have h : env56224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56223_56224 : H12AffineEnvironment.transform 2 2 env56223 = env56224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56223 == env56224) = true)

theorem identity56224 : scanCanonicalize (H12AffineFastState.compose env56224 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56225 : List Nat := [0,1,0,0,0,0,1,1,1,1,1,1,1,1,0,0,1,0,1,1,0,0,0,0,0,1,1,1,1,0,0,1,1,1,0,0]

theorem envBound56225 : H12AffineFastState.Bounded env56225 := by
  intro p hp
  have h : env56225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56224_56225 : H12AffineEnvironment.transform 0 0 env56224 = env56225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56224 == env56225) = true)

def env56226 : List Nat := [2,4,8,0,32,64,128,256,325,430,2048,1,161,175,258,65536,65889,65665,320,259,0,461,65934,65536,199,65825,303,65825,175,67653,173,65825,256,169,238,426]

theorem envBound56226 : H12AffineFastState.Bounded env56226 := by
  intro p hp
  have h : env56226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56215_56226 : H12AffineEnvironment.transform 12 161 env56215 = env56226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env56215 == env56226) = true)

theorem identity56226 : scanCanonicalize (H12AffineFastState.compose env56226 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound56226 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56227 : List Nat := [2,4,8,0,32,64,128,66,7,236,2048,1,161,175,64,65536,65571,65665,2,65,0,143,65740,65536,199,65635,109,65635,175,67653,173,65635,66,169,238,232]

theorem envBound56227 : H12AffineFastState.Bounded env56227 := by
  intro p hp
  have h : env56227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56226_56227 : H12AffineEnvironment.transform 7 66 env56226 = env56227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env56226 == env56227) = true)

def env56228 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9228,65536,74862,65665,320,9229,0,460,74030,65537,9672,74798,302,74799,1280,77130,8204,74798,256,8200,1344,1029]

theorem envBound56228 : H12AffineFastState.Bounded env56228 := by
  intro p hp
  have h : env56228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56213_56228 : H12AffineEnvironment.transform 3 1 env56213 = env56228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56213 == env56228) = true)

theorem identity56228 : scanCanonicalize (H12AffineFastState.compose env56228 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound56228 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56229 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,167,1280,1195,65536,66761,65665,320,1194,0,460,65929,65537,1391,66697,302,66696,1280,69101,171,66697,256,175,1344,1029]

theorem envBound56229 : H12AffineFastState.Bounded env56229 := by
  intro p hp
  have h : env56229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56228_56229 : H12AffineEnvironment.transform 12 167 env56228 = env56229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env56228 == env56229) = true)

def env56230 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,167,1280,1195,392,1345,265,320,1194,0,460,1,393,1391,1281,302,1280,1280,3173,171,1281,256,175,1344,1029]

theorem envBound56230 : H12AffineFastState.Bounded env56230 := by
  intro p hp
  have h : env56230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56229_56230 : H12AffineEnvironment.transform 15 392 env56229 = env56230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env56229 == env56230) = true)

theorem identity56230 : scanCanonicalize (H12AffineFastState.compose env56230 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound56230 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56231 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,1,167,490,65,392,427,265,320,64,0,460,1,393,389,491,302,490,490,2191,171,491,256,175,426,239]

theorem envBound56231 : H12AffineFastState.Bounded env56231 := by
  intro p hp
  have h : env56231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56230_56231 : H12AffineEnvironment.transform 9 234 env56230 = env56231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env56230 == env56231) = true)

theorem identity56231 : scanCanonicalize (H12AffineFastState.compose env56231 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56231 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env56232 : List Nat := [2,2,8,1,32,64,128,256,322,234,2048,1,161,490,65,392,427,265,320,64,0,458,1,393,387,491,296,490,490,2185,171,491,256,169,426,233]

theorem envBound56232 : H12AffineFastState.Bounded env56232 := by
  intro p hp
  have h : env56232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56231_56232 : H12AffineEnvironment.transform 1 2 env56231 = env56232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56231 == env56232) = true)

theorem identity56232 : scanCanonicalize (H12AffineFastState.compose env56232 (packedSelected [0,2,4,5,7,8,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound56232 : packedSelected [0,2,4,5,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56233 : List Nat := [2,2,8,1,32,64,128,35,97,234,2048,1,161,201,65,171,136,42,99,64,0,233,1,170,160,200,11,201,201,2185,171,200,35,169,137,233]

theorem envBound56233 : H12AffineFastState.Bounded env56233 := by
  intro p hp
  have h : env56233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56232_56233 : H12AffineEnvironment.transform 7 35 env56232 = env56233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env56232 == env56233) = true)

theorem identity56233 : scanCanonicalize (H12AffineFastState.compose env56233 (packedSelected [1,4,5,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56233 : packedSelected [1,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env56234 : List Nat := [2,2,8,1,32,64,40,35,97,66,2048,1,9,97,65,3,32,42,99,64,0,65,1,2,8,96,11,97,97,2081,3,96,35,1,33,65]

theorem envBound56234 : H12AffineFastState.Bounded env56234 := by
  intro p hp
  have h : env56234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56233_56234 : H12AffineEnvironment.transform 6 40 env56233 = env56234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56233 == env56234) = true)

theorem identity56234 : scanCanonicalize (H12AffineFastState.compose env56234 (packedSelected [2,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound56234 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env56235 : List Nat := [2,2,8,1,32,33,40,35,0,35,2048,1,9,0,32,3,32,42,2,33,0,32,1,2,8,1,11,0,0,2081,3,1,35,1,33,32]

theorem envBound56235 : H12AffineFastState.Bounded env56235 := by
  intro p hp
  have h : env56235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56234_56235 : H12AffineEnvironment.transform 5 33 env56234 = env56235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56234 == env56235) = true)

theorem identity56235 : scanCanonicalize (H12AffineFastState.compose env56235 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56235 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56236 : List Nat := [2,2,2,1,32,33,34,35,0,35,2048,1,3,0,32,3,32,32,2,33,0,32,1,2,2,1,1,0,0,2081,3,1,35,1,33,32]

theorem envBound56236 : H12AffineFastState.Bounded env56236 := by
  intro p hp
  have h : env56236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56235_56236 : H12AffineEnvironment.transform 2 2 env56235 = env56236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56235 == env56236) = true)

theorem identity56236 : scanCanonicalize (H12AffineFastState.compose env56236 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56236 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56237 : List Nat := [2,2,2,1,1,0,3,2,0,2,2048,1,3,0,1,3,1,1,2,0,0,1,1,2,2,1,1,0,0,2048,3,1,2,1,0,1]

theorem envBound56237 : H12AffineFastState.Bounded env56237 := by
  intro p hp
  have h : env56237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56236_56237 : H12AffineEnvironment.transform 4 1 env56236 = env56237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56236 == env56237) = true)

theorem identity56237 : scanCanonicalize (H12AffineFastState.compose env56237 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound56237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56238 : List Nat := [2,2,2,1,1,0,3,2,0,2,2,1,3,0,1,3,1,1,2,0,0,1,1,2,2,1,1,0,0,2,3,1,2,1,0,1]

theorem envBound56238 : H12AffineFastState.Bounded env56238 := by
  intro p hp
  have h : env56238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56237_56238 : H12AffineEnvironment.transform 10 2 env56237 = env56238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env56237 == env56238) = true)

theorem identity56238 : scanCanonicalize (H12AffineFastState.compose env56238 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56238 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56239 : List Nat := [1,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,1,1,0,0,1,1,1,1,1,1,0,0,1,0,1,1,1,0,1]

theorem envBound56239 : H12AffineFastState.Bounded env56239 := by
  intro p hp
  have h : env56239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56238_56239 : H12AffineEnvironment.transform 0 1 env56238 = env56239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56238 == env56239) = true)

def env56240 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,167,1280,1195,393,1344,264,320,1194,0,460,0,392,1391,1280,302,1281,1280,3172,171,1280,256,175,1344,1029]

theorem envBound56240 : H12AffineFastState.Bounded env56240 := by
  intro p hp
  have h : env56240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56229_56240 : H12AffineEnvironment.transform 15 393 env56229 = env56240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env56229 == env56240) = true)

theorem identity56240 : scanCanonicalize (H12AffineFastState.compose env56240 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 494) := by decide +kernel

theorem selectedBound56240 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56241 : List Nat := [2,4,8,1,32,64,128,256,324,494,2048,1,167,238,325,393,174,264,320,324,0,460,0,392,129,238,302,239,238,2442,171,238,256,175,174,491]

theorem envBound56241 : H12AffineFastState.Bounded env56241 := by
  intro p hp
  have h : env56241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56240_56241 : H12AffineEnvironment.transform 9 494 env56240 = env56241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 494 env56240 == env56241) = true)

theorem identity56241 : scanCanonicalize (H12AffineFastState.compose env56241 (packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound56241 : packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env56242 : List Nat := [2,4,8,1,32,64,128,140,200,98,2048,1,167,238,201,5,174,132,204,200,0,64,0,4,129,238,162,239,238,2054,171,238,140,175,174,103]

theorem envBound56242 : H12AffineFastState.Bounded env56242 := by
  intro p hp
  have h : env56242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56241_56242 : H12AffineEnvironment.transform 7 140 env56241 = env56242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env56241 == env56242) = true)

theorem identity56242 : scanCanonicalize (H12AffineFastState.compose env56242 (packedSelected [1,4,8,9,10,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound56242 : packedSelected [1,4,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env56243 : List Nat := [2,4,8,1,32,38,128,140,174,4,2048,1,167,136,175,5,174,132,170,174,0,38,0,4,129,136,162,137,136,2054,171,136,140,175,174,1]

theorem envBound56243 : H12AffineFastState.Bounded env56243 := by
  intro p hp
  have h : env56243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56242_56243 : H12AffineEnvironment.transform 5 38 env56242 = env56243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env56242 == env56243) = true)

theorem identity56243 : scanCanonicalize (H12AffineFastState.compose env56243 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56243 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env56244 : List Nat := [2,4,5,1,32,38,128,129,163,4,2048,1,167,133,162,5,163,132,167,163,0,38,0,4,129,133,162,132,133,2054,166,133,129,162,163,1]

theorem envBound56244 : H12AffineFastState.Bounded env56244 := by
  intro p hp
  have h : env56244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56243_56244 : H12AffineEnvironment.transform 2 5 env56243 = env56244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56243 == env56244) = true)

theorem identity56244 : scanCanonicalize (H12AffineFastState.compose env56244 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56244 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env56245 : List Nat := [2,4,5,1,32,38,128,129,163,4,1,1,167,133,162,5,163,132,167,163,0,38,0,4,129,133,162,132,133,7,166,133,129,162,163,1]

theorem envBound56245 : H12AffineFastState.Bounded env56245 := by
  intro p hp
  have h : env56245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56244_56245 : H12AffineEnvironment.transform 10 1 env56244 = env56245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56244 == env56245) = true)

theorem identity56245 : scanCanonicalize (H12AffineFastState.compose env56245 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56245 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56246 : List Nat := [2,2,3,1,32,32,128,129,163,2,1,1,161,131,162,3,163,130,161,163,0,32,0,2,129,131,162,130,131,1,160,131,129,162,163,1]

theorem envBound56246 : H12AffineFastState.Bounded env56246 := by
  intro p hp
  have h : env56246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56245_56246 : H12AffineEnvironment.transform 1 2 env56245 = env56246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56245 == env56246) = true)

theorem identity56246 : scanCanonicalize (H12AffineFastState.compose env56246 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56247 : List Nat := [2,2,3,1,0,0,128,129,131,2,1,1,129,131,130,3,131,130,129,131,0,0,0,2,129,131,130,130,131,1,128,131,129,130,131,1]

theorem envBound56247 : H12AffineFastState.Bounded env56247 := by
  intro p hp
  have h : env56247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56246_56247 : H12AffineEnvironment.transform 4 0 env56246 = env56247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56246 == env56247) = true)

def env56248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123164,28889,78894,385202,90415,1296,96346,25885,74799,256,25881,1344,21072]

theorem envBound56248 : H12AffineFastState.Bounded env56248 := by
  intro p hp
  have h : env56248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56005_56248 : H12AffineEnvironment.transform 18 21585 env56005 = env56248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env56005 == env56248) = true)

theorem identity56248 : scanCanonicalize (H12AffineFastState.compose env56248 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound56248 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4097,5277,91182,66897,28889,78894,328959,90415,1296,96346,25885,74799,256,25881,1344,21072]

theorem envBound56249 : H12AffineFastState.Bounded env56249 := by
  intro p hp
  have h : env56249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56248_56249 : H12AffineEnvironment.transform 14 25677 env56248 = env56249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env56248 == env56249) = true)

def env56250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4097,5277,74046,66897,13769,78894,328959,74815,1296,81226,8205,74799,256,8201,1344,5952]

theorem envBound56250 : H12AffineFastState.Bounded env56250 := by
  intro p hp
  have h : env56250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2