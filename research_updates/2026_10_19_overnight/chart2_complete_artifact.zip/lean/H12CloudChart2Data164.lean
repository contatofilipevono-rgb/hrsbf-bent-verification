import H12CloudChart2Data163

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env40992 : List Nat := [2,4,8,16,12,16,19,18,0,5,2048,2049,24,6,7,2063,6,29,2050,6,2049,2058,17,24,2052,2070,2049,7,7,2075,2069,23,18,22,6,2054]

theorem envBound40992 : H12AffineFastState.Bounded env40992 := by
  intro p hp
  have h : env40992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40991_40992 : H12AffineEnvironment.transform 4 12 env40991 = env40992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env40991 == env40992) = true)

theorem identity40992 : scanCanonicalize (H12AffineFastState.compose env40992 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound40992 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40993 : List Nat := [2,4,8,16,12,16,19,18,0,5,6,7,24,6,7,9,6,29,4,6,7,12,17,24,2,16,7,7,7,29,19,23,18,22,6,0]

theorem envBound40993 : H12AffineFastState.Bounded env40993 := by
  intro p hp
  have h : env40993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40992_40993 : H12AffineEnvironment.transform 10 6 env40992 = env40993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env40992 == env40993) = true)

theorem identity40993 : scanCanonicalize (H12AffineFastState.compose env40993 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40994 : List Nat := [2,4,8,11,12,11,8,9,0,5,6,7,3,6,7,9,6,6,4,6,7,12,10,3,2,11,7,7,7,6,8,12,9,13,6,0]

theorem envBound40994 : H12AffineFastState.Bounded env40994 := by
  intro p hp
  have h : env40994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40993_40994 : H12AffineEnvironment.transform 3 11 env40993 = env40994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40993 == env40994) = true)

def env40995 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143496,20497,492566,148668,148668,96266,74795,1197,173,148653,1213,135681]

theorem envBound40995 : H12AffineFastState.Bounded env40995 := by
  intro p hp
  have h : env40995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40980_40995 : H12AffineEnvironment.transform 5 17 env40980 = env40995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40980 == env40995) = true)

theorem identity40995 : scanCanonicalize (H12AffineFastState.compose env40995 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound40995 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env40996 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,41003,32809,20497,341175,62493,62493,96266,74795,1197,173,62476,1213,41632]

theorem envBound40996 : H12AffineFastState.Bounded env40996 := by
  intro p hp
  have h : env40996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40995_40996 : H12AffineEnvironment.transform 16 45217 env40995 = env40996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env40995 == env40996) = true)

theorem identity40996 : scanCanonicalize (H12AffineFastState.compose env40996 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound40996 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env40997 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4096,46140,46093,41003,32809,5293,341175,45217,45217,81078,74795,1197,173,45232,1213,41632]

theorem envBound40997 : H12AffineFastState.Bounded env40997 := by
  intro p hp
  have h : env40997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40996_40997 : H12AffineEnvironment.transform 13 1212 env40996 = env40997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env40996 == env40997) = true)

theorem identity40997 : scanCanonicalize (H12AffineFastState.compose env40997 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound40997 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40998 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,9351,45217,262144,42145,32769,4096,46140,46093,41003,32809,5293,266288,45217,45217,6193,172,1197,173,45232,1213,41632]

theorem envBound40998 : H12AffineFastState.Bounded env40998 := by
  intro p hp
  have h : env40998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40997_40998 : H12AffineEnvironment.transform 15 9351 env40997 = env40998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env40997 == env40998) = true)

theorem identity40998 : scanCanonicalize (H12AffineFastState.compose env40998 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound40998 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env40999 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,9351,185,262144,5305,12313,4096,1060,1045,4147,12337,5293,266288,185,185,6193,172,1197,173,168,1213,4792]

theorem envBound40999 : H12AffineFastState.Bounded env40999 := by
  intro p hp
  have h : env40999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40998_40999 : H12AffineEnvironment.transform 14 12312 env40998 = env40999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env40998 == env40999) = true)

theorem identity40999 : scanCanonicalize (H12AffineFastState.compose env40999 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound40999 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env41000 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1212,3223,6152,185,262144,5305,3222,4096,1060,1045,4147,3262,5293,266288,185,185,6193,172,1197,173,168,1213,4792]

theorem envBound41000 : H12AffineFastState.Bounded env41000 := by
  intro p hp
  have h : env41000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40999_41000 : H12AffineEnvironment.transform 12 7311 env40999 = env41000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env40999 == env41000) = true)

theorem identity41000 : scanCanonicalize (H12AffineFastState.compose env41000 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound41000 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env41001 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,561,3774,1212,3223,2617,185,262144,1672,3222,561,1060,1045,514,3262,1692,262657,185,185,2560,172,1197,173,168,1213,137]

theorem envBound41001 : H12AffineFastState.Bounded env41001 := by
  intro p hp
  have h : env41001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41000_41001 : H12AffineEnvironment.transform 11 561 env41000 = env41001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env41000 == env41001) = true)

theorem identity41001 : scanCanonicalize (H12AffineFastState.compose env41001 (packedSelected [10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound41001 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env41002 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,561,3774,1212,3223,2617,185,555,1672,3222,561,1060,1045,514,3262,1692,42,185,185,2560,172,1197,173,168,1213,137]

theorem envBound41002 : H12AffineFastState.Bounded env41002 := by
  intro p hp
  have h : env41002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41001_41002 : H12AffineEnvironment.transform 17 555 env41001 = env41002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env41001 == env41002) = true)

theorem identity41002 : scanCanonicalize (H12AffineFastState.compose env41002 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound41002 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41003 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,561,1053,1212,1588,154,185,555,1672,1589,561,1060,1045,514,1565,1692,42,185,185,163,172,1197,173,168,1213,137]

theorem envBound41003 : H12AffineFastState.Bounded env41003 := by
  intro p hp
  have h : env41003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41002_41003 : H12AffineEnvironment.transform 10 675 env41002 = env41003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env41002 == env41003) = true)

theorem identity41003 : scanCanonicalize (H12AffineFastState.compose env41003 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41003 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41004 : List Nat := [2,4,8,16,17,17,128,156,512,1024,658,512,1053,1165,1541,154,136,538,1672,1540,512,1045,1045,514,1565,1692,27,136,136,146,157,1180,156,153,1164,137]

theorem envBound41004 : H12AffineFastState.Bounded env41004 := by
  intro p hp
  have h : env41004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41003_41004 : H12AffineEnvironment.transform 4 17 env41003 = env41004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41003 == env41004) = true)

theorem identity41004 : scanCanonicalize (H12AffineFastState.compose env41004 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound41004 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env41005 : List Nat := [2,4,8,16,17,17,128,156,512,30,658,512,3,147,539,154,136,538,662,538,512,11,11,514,515,642,27,136,136,146,157,130,156,153,146,137]

theorem envBound41005 : H12AffineFastState.Bounded env41005 := by
  intro p hp
  have h : env41005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41004_41005 : H12AffineEnvironment.transform 9 30 env41004 = env41005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env41004 == env41005) = true)

theorem identity41005 : scanCanonicalize (H12AffineFastState.compose env41005 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound41005 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41006 : List Nat := [2,4,8,16,17,17,128,156,26,30,136,26,3,147,1,154,136,0,140,0,26,11,11,24,25,152,27,136,136,146,157,130,156,153,146,137]

theorem envBound41006 : H12AffineFastState.Bounded env41006 := by
  intro p hp
  have h : env41006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41005_41006 : H12AffineEnvironment.transform 8 26 env41005 = env41006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env41005 == env41006) = true)

theorem identity41006 : scanCanonicalize (H12AffineFastState.compose env41006 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41006 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41007 : List Nat := [2,4,8,6,7,7,128,138,12,8,136,12,3,133,1,140,136,0,140,0,12,11,11,14,15,142,13,136,136,132,139,130,138,143,132,137]

theorem envBound41007 : H12AffineFastState.Bounded env41007 := by
  intro p hp
  have h : env41007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41006_41007 : H12AffineEnvironment.transform 3 6 env41006 = env41007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41006 == env41007) = true)

theorem identity41007 : scanCanonicalize (H12AffineFastState.compose env41007 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound41007 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41008 : List Nat := [2,4,8,6,7,7,4,14,12,8,12,12,3,1,1,8,12,0,8,0,12,11,11,14,15,10,13,12,12,0,15,6,14,11,0,13]

theorem envBound41008 : H12AffineFastState.Bounded env41008 := by
  intro p hp
  have h : env41008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41007_41008 : H12AffineEnvironment.transform 6 4 env41007 = env41008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env41007 == env41008) = true)

theorem identity41008 : scanCanonicalize (H12AffineFastState.compose env41008 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41009 : List Nat := [2,0,8,2,3,3,0,10,8,8,8,8,3,1,1,8,8,0,8,0,8,11,11,10,11,10,9,8,8,0,11,2,10,11,0,9]

theorem envBound41009 : H12AffineFastState.Bounded env41009 := by
  intro p hp
  have h : env41009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41008_41009 : H12AffineEnvironment.transform 1 0 env41008 = env41009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41008 == env41009) = true)

def env41010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,493034,148800,148801,96347,74795,1280,256,148816,1345,135680]

theorem envBound41010 : H12AffineFastState.Bounded env41010 := by
  intro p hp
  have h : env41010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40951_41010 : H12AffineEnvironment.transform 18 136193 env40951 = env41010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env40951 == env41010) = true)

def env41011 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,492614,148716,148717,96347,74795,1196,172,148732,1261,135680]

theorem envBound41011 : H12AffineFastState.Bounded env41011 := by
  intro p hp
  have h : env41011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41010_41011 : H12AffineEnvironment.transform 7 172 env41010 = env41011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env41010 == env41011) = true)

def env41012 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143497,20496,492566,148668,148669,96267,74795,1196,172,148652,1213,135680]

theorem envBound41012 : H12AffineFastState.Bounded env41012 := by
  intro p hp
  have h : env41012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_41012 : H12AffineEnvironment.transform 5 16 env41011 = env41012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41011 == env41012) = true)

theorem identity41012 : scanCanonicalize (H12AffineFastState.compose env41012 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound41012 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env41013 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61569,98355,41003,127147,20496,279604,99486,99487,96267,74795,1196,172,99470,1213,119330]

theorem envBound41013 : H12AffineFastState.Bounded env41013 := by
  intro p hp
  have h : env41013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41012_41013 : H12AffineEnvironment.transform 16 114722 env41012 = env41013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env41012 == env41013) = true)

theorem identity41013 : scanCanonicalize (H12AffineFastState.compose env41013 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64556) := by decide +kernel

theorem selectedBound41013 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env41014 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,64556,119843,32769,4096,61569,98355,41003,127147,20496,47128,99486,99487,96267,74795,1196,172,99470,1213,119330]

theorem envBound41014 : H12AffineFastState.Bounded env41014 := by
  intro p hp
  have h : env41014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41013_41014 : H12AffineEnvironment.transform 17 64556 env41013 = env41014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64556 env41013 == env41014) = true)

theorem identity41014 : scanCanonicalize (H12AffineFastState.compose env41014 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound41014 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env41015 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,64556,1025,32769,4096,61569,20497,41003,8329,20496,47128,21692,21693,43049,62473,1196,172,21676,1213,512]

theorem envBound41015 : H12AffineFastState.Bounded env41015 := by
  intro p hp
  have h : env41015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41014_41015 : H12AffineEnvironment.transform 15 53282 env41014 = env41015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env41014 == env41015) = true)

theorem identity41015 : scanCanonicalize (H12AffineFastState.compose env41015 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound41015 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41016 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,49306,184,60564,1025,32769,184,57401,16553,41003,8329,16552,43168,17412,17413,43049,58545,1196,172,17428,1213,512]

theorem envBound41016 : H12AffineFastState.Bounded env41016 := by
  intro p hp
  have h : env41016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41015_41016 : H12AffineEnvironment.transform 11 184 env41015 = env41016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env41015 == env41016) = true)

theorem identity41016 : scanCanonicalize (H12AffineFastState.compose env41016 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound41016 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41017 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,8744,32768,41650,184,36540,1025,32769,184,33297,8833,41003,8329,8832,43168,9772,9773,43049,34457,1196,172,9788,1213,512]

theorem envBound41017 : H12AffineFastState.Bounded env41017 := by
  intro p hp
  have h : env41017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41016_41017 : H12AffineEnvironment.transform 13 8744 env41016 = env41017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env41016 == env41017) = true)

theorem identity41017 : scanCanonicalize (H12AffineFastState.compose env41017 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound41017 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41018 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,8744,1070,9884,184,2706,1025,1071,184,1599,8833,9221,8329,8832,11406,9772,9773,11271,695,1196,172,9788,1213,512]

theorem envBound41018 : H12AffineFastState.Bounded env41018 := by
  intro p hp
  have h : env41018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41017_41018 : H12AffineEnvironment.transform 14 1070 env41017 = env41018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env41017 == env41018) = true)

def env41019 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143497,20496,492567,148669,148668,96266,74795,1196,172,148653,1212,135680]

theorem envBound41019 : H12AffineFastState.Bounded env41019 := by
  intro p hp
  have h : env41019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_41019 : H12AffineEnvironment.transform 5 17 env41011 = env41019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41011 == env41019) = true)

theorem identity41019 : scanCanonicalize (H12AffineFastState.compose env41019 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound41019 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env41020 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61568,147472,41003,143497,20496,60444,148669,148668,96266,74795,1196,172,148653,1212,135680]

theorem envBound41020 : H12AffineFastState.Bounded env41020 := by
  intro p hp
  have h : env41020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41019_41020 : H12AffineEnvironment.transform 17 223243 env41019 = env41020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env41019 == env41020) = true)

theorem identity41020 : scanCanonicalize (H12AffineFastState.compose env41020 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound41020 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env41021 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4096,61568,147472,41003,143497,20496,60444,148669,148668,2184,21673,1196,172,148653,1212,135680]

theorem envBound41021 : H12AffineFastState.Bounded env41021 := by
  intro p hp
  have h : env41021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41020_41021 : H12AffineEnvironment.transform 15 28802 env41020 = env41021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env41020 == env41021) = true)

theorem identity41021 : scanCanonicalize (H12AffineFastState.compose env41021 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58532) := by decide +kernel

theorem selectedBound41021 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41022 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,58532,64557,61605,32769,4096,61568,42164,41003,54317,20496,60444,40985,40984,2184,21673,1196,172,40969,1212,63140]

theorem envBound41022 : H12AffineFastState.Bounded env41022 := by
  intro p hp
  have h : env41022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41021_41022 : H12AffineEnvironment.transform 16 58532 env41021 = env41022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58532 env41021 == env41022) = true)

theorem identity41022 : scanCanonicalize (H12AffineFastState.compose env41022 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound41022 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41023 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,40984,47249,46105,32769,4096,46140,42164,41003,37009,5292,43168,40985,40984,2184,4117,1196,172,40969,1212,45592]

theorem envBound41023 : H12AffineFastState.Bounded env41023 := by
  intro p hp
  have h : env41023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41022_41023 : H12AffineEnvironment.transform 13 1212 env41022 = env41023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env41022 == env41023) = true)

theorem identity41023 : scanCanonicalize (H12AffineFastState.compose env41023 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound41023 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env41024 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,6187,13374,14387,8378,11314,6186,4096,11287,15519,14336,2234,5292,12427,14386,14387,2184,4117,1196,172,14370,1212,10803]

theorem envBound41024 : H12AffineFastState.Bounded env41024 := by
  intro p hp
  have h : env41024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41023_41024 : H12AffineEnvironment.transform 14 6187 env41023 = env41024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env41023 == env41024) = true)

theorem identity41024 : scanCanonicalize (H12AffineFastState.compose env41024 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41024 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env41025 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,185,6187,12347,14387,8378,10295,6186,4096,10258,14490,14336,2234,4265,12427,14386,14387,2184,4117,169,172,14370,185,10803]

theorem envBound41025 : H12AffineFastState.Bounded env41025 := by
  intro p hp
  have h : env41025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41024_41025 : H12AffineEnvironment.transform 9 5 env41024 = env41025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41024 == env41025) = true)

theorem identity41025 : scanCanonicalize (H12AffineFastState.compose env41025 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41025 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env41026 : List Nat := [2,4,8,16,32,17,128,172,1,5,2048,4096,8192,185,6187,12347,14387,8378,10295,6186,4096,10258,14490,14336,2234,4265,12427,14386,14387,2184,4117,169,172,14370,185,10290]

theorem envBound41026 : H12AffineFastState.Bounded env41026 := by
  intro p hp
  have h : env41026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41025_41026 : H12AffineEnvironment.transform 8 1 env41025 = env41026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41025 == env41026) = true)

theorem identity41026 : scanCanonicalize (H12AffineFastState.compose env41026 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound41026 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41027 : List Nat := [2,4,8,16,32,17,128,172,1,5,163,4096,8192,185,4232,12347,12432,8378,8340,4233,4096,8369,12345,12451,25,4265,12427,12433,12432,43,4117,169,172,12417,185,8337]

theorem envBound41027 : H12AffineFastState.Bounded env41027 := by
  intro p hp
  have h : env41027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41026_41027 : H12AffineEnvironment.transform 10 163 env41026 = env41027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env41026 == env41027) = true)

theorem identity41027 : scanCanonicalize (H12AffineFastState.compose env41027 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41027 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env41028 : List Nat := [2,4,8,16,32,17,18,62,1,5,49,4096,8192,43,4122,12347,12290,8232,8198,4123,4096,8227,12345,12337,25,4155,12313,12291,12290,43,4117,59,62,12307,43,8195]

theorem envBound41028 : H12AffineFastState.Bounded env41028 := by
  intro p hp
  have h : env41028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41027_41028 : H12AffineEnvironment.transform 6 18 env41027 = env41028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41027 == env41028) = true)

theorem identity41028 : scanCanonicalize (H12AffineFastState.compose env41028 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound41028 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41029 : List Nat := [2,4,8,16,32,17,18,62,1,5,49,4096,3,43,4122,4152,4097,43,5,4123,4096,32,4154,4146,25,4155,4122,4096,4097,43,4117,59,62,4112,43,0]

theorem envBound41029 : H12AffineFastState.Bounded env41029 := by
  intro p hp
  have h : env41029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41028_41029 : H12AffineEnvironment.transform 12 3 env41028 = env41029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env41028 == env41029) = true)

theorem identity41029 : scanCanonicalize (H12AffineFastState.compose env41029 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 9) := by decide +kernel

theorem selectedBound41029 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41030 : List Nat := [2,4,8,16,32,17,18,62,1,5,49,9,3,43,19,49,8,43,5,18,9,32,51,59,25,50,19,9,8,43,28,59,62,25,43,0]

theorem envBound41030 : H12AffineFastState.Bounded env41030 := by
  intro p hp
  have h : env41030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41029_41030 : H12AffineEnvironment.transform 11 9 env41029 = env41030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 9 env41029 == env41030) = true)

theorem identity41030 : scanCanonicalize (H12AffineFastState.compose env41030 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41030 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env41031 : List Nat := [2,4,1,16,32,17,18,55,1,5,49,0,3,34,19,49,1,34,5,18,0,32,51,50,16,50,19,0,1,34,21,50,55,16,34,0]

theorem envBound41031 : H12AffineFastState.Bounded env41031 := by
  intro p hp
  have h : env41031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41030_41031 : H12AffineEnvironment.transform 2 1 env41030 = env41031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41030 == env41031) = true)

theorem identity41031 : scanCanonicalize (H12AffineFastState.compose env41031 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound41031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41032 : List Nat := [2,4,1,3,32,2,1,36,1,5,34,0,3,34,0,34,1,34,5,1,0,32,32,33,3,33,0,0,1,34,6,33,36,3,34,0]

theorem envBound41032 : H12AffineFastState.Bounded env41032 := by
  intro p hp
  have h : env41032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41031_41032 : H12AffineEnvironment.transform 3 3 env41031 = env41032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env41031 == env41032) = true)

theorem identity41032 : scanCanonicalize (H12AffineFastState.compose env41032 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41032 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41033 : List Nat := [2,3,1,3,32,2,1,35,1,2,34,0,3,34,0,34,1,34,2,1,0,32,32,33,3,33,0,0,1,34,1,33,35,3,34,0]

theorem envBound41033 : H12AffineFastState.Bounded env41033 := by
  intro p hp
  have h : env41033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41032_41033 : H12AffineEnvironment.transform 1 3 env41032 = env41033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41032 == env41033) = true)

theorem identity41033 : scanCanonicalize (H12AffineFastState.compose env41033 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41033 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41034 : List Nat := [2,3,1,3,1,2,1,2,1,2,3,0,3,3,0,3,1,3,2,1,0,1,1,0,3,0,0,0,1,3,1,0,2,3,3,0]

theorem envBound41034 : H12AffineFastState.Bounded env41034 := by
  intro p hp
  have h : env41034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41033_41034 : H12AffineEnvironment.transform 4 1 env41033 = env41034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41033 == env41034) = true)

theorem identity41034 : scanCanonicalize (H12AffineFastState.compose env41034 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41034 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env41035 : List Nat := [1,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,1,0,1,1,0,1,1,0,0,0,0,0,1,0,1,0,1,0,0,0]

theorem envBound41035 : H12AffineFastState.Bounded env41035 := by
  intro p hp
  have h : env41035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41034_41035 : H12AffineEnvironment.transform 0 1 env41034 = env41035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41034 == env41035) = true)

def env41036 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,492615,148717,148716,96347,74795,1197,173,148733,1260,135680]

theorem envBound41036 : H12AffineFastState.Bounded env41036 := by
  intro p hp
  have h : env41036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41010_41036 : H12AffineEnvironment.transform 7 173 env41010 = env41036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41010 == env41036) = true)

def env41037 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143497,20496,492567,148669,148668,96267,74795,1197,173,148653,1212,135680]

theorem envBound41037 : H12AffineFastState.Bounded env41037 := by
  intro p hp
  have h : env41037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41036_41037 : H12AffineEnvironment.transform 5 16 env41036 = env41037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41036 == env41037) = true)

theorem identity41037 : scanCanonicalize (H12AffineFastState.compose env41037 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound41037 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env41038 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,41003,32809,20496,341175,62493,62492,96267,74795,1197,173,62477,1212,41632]

theorem envBound41038 : H12AffineFastState.Bounded env41038 := by
  intro p hp
  have h : env41038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41037_41038 : H12AffineEnvironment.transform 16 45216 env41037 = env41038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env41037 == env41038) = true)

theorem identity41038 : scanCanonicalize (H12AffineFastState.compose env41038 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound41038 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env41039 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4096,46140,46092,41003,32809,5293,341175,45216,45217,81078,74795,1197,173,45232,1212,41632]

theorem envBound41039 : H12AffineFastState.Bounded env41039 := by
  intro p hp
  have h : env41039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41038_41039 : H12AffineEnvironment.transform 13 1213 env41038 = env41039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env41038 == env41039) = true)

theorem identity41039 : scanCanonicalize (H12AffineFastState.compose env41039 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound41039 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41040 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,9350,45216,262144,42145,32769,4096,46140,46092,41003,32809,5293,266289,45216,45217,6192,173,1197,173,45232,1212,41632]

theorem envBound41040 : H12AffineFastState.Bounded env41040 := by
  intro p hp
  have h : env41040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41039_41040 : H12AffineEnvironment.transform 15 9350 env41039 = env41040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env41039 == env41040) = true)

theorem identity41040 : scanCanonicalize (H12AffineFastState.compose env41040 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound41040 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env41041 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,9350,185,262144,5304,12312,4096,1061,1045,4146,12336,5293,266289,185,184,6192,173,1197,173,169,1212,4793]

theorem envBound41041 : H12AffineFastState.Bounded env41041 := by
  intro p hp
  have h : env41041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41040_41041 : H12AffineEnvironment.transform 14 12313 env41040 = env41041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env41040 == env41041) = true)

theorem identity41041 : scanCanonicalize (H12AffineFastState.compose env41041 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound41041 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env41042 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,8352,9350,185,262144,1025,8353,185,1061,1045,139,8329,1044,262280,185,184,2185,173,1197,173,169,1212,512]

theorem envBound41042 : H12AffineFastState.Bounded env41042 := by
  intro p hp
  have h : env41042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41041_41042 : H12AffineEnvironment.transform 11 185 env41041 = env41042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env41041 == env41042) = true)

theorem identity41042 : scanCanonicalize (H12AffineFastState.compose env41042 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound41042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41043 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2601,1213,2697,3759,185,262144,1025,2696,185,1061,1045,139,2720,1044,262280,185,184,2185,173,1197,173,169,1212,512]

theorem envBound41043 : H12AffineFastState.Bounded env41043 := by
  intro p hp
  have h : env41043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41042_41043 : H12AffineEnvironment.transform 12 2601 env41042 = env41043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env41042 == env41043) = true)

theorem identity41043 : scanCanonicalize (H12AffineFastState.compose env41043 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound41043 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41044 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2601,1213,2697,3759,185,2707,1025,2696,185,1061,1045,139,2720,1044,2587,185,184,2185,173,1197,173,169,1212,512]

theorem envBound41044 : H12AffineFastState.Bounded env41044 := by
  intro p hp
  have h : env41044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41043_41044 : H12AffineEnvironment.transform 17 2707 env41043 = env41044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env41043 == env41044) = true)

theorem identity41044 : scanCanonicalize (H12AffineFastState.compose env41044 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound41044 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41045 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1212,185,1685,1213,1589,531,185,1583,1025,1588,185,1061,1045,139,1564,1044,1703,185,184,1077,173,1197,173,169,1212,512]

theorem envBound41045 : H12AffineFastState.Bounded env41045 := by
  intro p hp
  have h : env41045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41044_41045 : H12AffineEnvironment.transform 10 1212 env41044 = env41045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env41044 == env41045) = true)

theorem identity41045 : scanCanonicalize (H12AffineFastState.compose env41045 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41045 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env41046 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1212,185,1173,1213,1077,19,185,1071,1025,1076,185,1061,1045,139,1052,1044,1191,185,184,1077,173,1197,173,169,1212,0]

theorem envBound41046 : H12AffineFastState.Bounded env41046 := by
  intro p hp
  have h : env41046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41045_41046 : H12AffineEnvironment.transform 8 0 env41045 = env41046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41045 == env41046) = true)

theorem identity41046 : scanCanonicalize (H12AffineFastState.compose env41046 (packedSelected [3,4] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound41046 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env41047 : List Nat := [2,4,8,16,32,16,128,173,0,31,163,185,138,162,42,19,185,48,30,43,185,58,10,139,3,11,184,185,184,42,173,178,173,169,163,0]

theorem envBound41047 : H12AffineFastState.Bounded env41047 := by
  intro p hp
  have h : env41047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41046_41047 : H12AffineEnvironment.transform 9 31 env41046 = env41047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env41046 == env41047) = true)

theorem identity41047 : scanCanonicalize (H12AffineFastState.compose env41047 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41047 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41048 : List Nat := [2,4,8,16,32,16,18,63,0,31,49,43,24,48,42,19,43,48,30,43,43,58,10,25,3,11,42,43,42,42,63,32,63,59,49,0]

theorem envBound41048 : H12AffineFastState.Bounded env41048 := by
  intro p hp
  have h : env41048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41047_41048 : H12AffineEnvironment.transform 6 18 env41047 = env41048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41047 == env41048) = true)

theorem identity41048 : scanCanonicalize (H12AffineFastState.compose env41048 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound41048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41049 : List Nat := [2,4,8,16,29,16,18,2,0,31,12,22,24,13,23,19,22,13,30,22,22,7,10,25,3,11,23,22,23,23,2,29,2,6,12,0]

theorem envBound41049 : H12AffineFastState.Bounded env41049 := by
  intro p hp
  have h : env41049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41048_41049 : H12AffineEnvironment.transform 4 29 env41048 = env41049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env41048 == env41049) = true)

def env41050 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143497,20496,492566,148668,148669,96266,74795,1197,173,148652,1213,135680]

theorem envBound41050 : H12AffineFastState.Bounded env41050 := by
  intro p hp
  have h : env41050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41036_41050 : H12AffineEnvironment.transform 5 17 env41036 = env41050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41036 == env41050) = true)

theorem identity41050 : scanCanonicalize (H12AffineFastState.compose env41050 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound41050 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env41051 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,41003,143497,20496,105630,148668,148669,96266,74795,1197,173,148652,1213,135680]

theorem envBound41051 : H12AffineFastState.Bounded env41051 := by
  intro p hp
  have h : env41051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41050_41051 : H12AffineEnvironment.transform 17 137352 env41050 = env41051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env41050 == env41051) = true)

theorem identity41051 : scanCanonicalize (H12AffineFastState.compose env41051 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound41051 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41052 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4096,61568,147472,41003,143497,20496,43169,148668,148669,19509,4116,1197,173,148652,1213,135680]

theorem envBound41052 : H12AffineFastState.Bounded env41052 := by
  intro p hp
  have h : env41052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41051_41052 : H12AffineEnvironment.transform 15 13375 env41051 = env41052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env41051 == env41052) = true)

theorem identity41052 : scanCanonicalize (H12AffineFastState.compose env41052 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound41052 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env41053 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136193,32769,4096,46141,132269,41003,143497,5293,43169,131073,131072,2184,4116,1197,173,131089,1213,135680]

theorem envBound41053 : H12AffineFastState.Bounded env41053 := by
  intro p hp
  have h : env41053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41052_41053 : H12AffineEnvironment.transform 13 1213 env41052 = env41053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env41052 == env41053) = true)

theorem identity41053 : scanCanonicalize (H12AffineFastState.compose env41053 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound41053 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env41054 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,46245,44077,41124,32769,4096,46141,45064,41003,33836,5293,43169,46244,46245,2184,4116,1197,173,46260,1213,42661]

theorem envBound41054 : H12AffineFastState.Bounded env41054 := by
  intro p hp
  have h : env41054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41053_41054 : H12AffineEnvironment.transform 16 46245 env41053 = env41054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env41053 == env41054) = true)

theorem identity41054 : scanCanonicalize (H12AffineFastState.compose env41054 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound41054 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41055 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2074,8192,1213,32768,11301,44223,44077,41124,32769,2074,44071,43026,41003,33836,3255,43169,44222,44223,2184,2062,1197,173,44206,1213,42661]

theorem envBound41055 : H12AffineFastState.Bounded env41055 := by
  intro p hp
  have h : env41055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41054_41055 : H12AffineEnvironment.transform 11 2074 env41054 = env41055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env41054 == env41055) = true)

theorem identity41055 : scanCanonicalize (H12AffineFastState.compose env41055 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 3262) := by decide +kernel

theorem selectedBound41055 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41056 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2074,3262,1213,32768,155,32769,32915,35866,32769,2074,32921,33964,35989,33836,3255,33823,32768,32769,2184,2062,1197,173,32784,1213,35355]

theorem envBound41056 : H12AffineFastState.Bounded env41056 := by
  intro p hp
  have h : env41056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41055_41056 : H12AffineEnvironment.transform 12 3262 env41055 = env41056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3262 env41055 == env41056) = true)

theorem identity41056 : scanCanonicalize (H12AffineFastState.compose env41056 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound41056 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env41057 : List Nat := [2,4,8,16,32,17,128,173,136,1024,2048,2074,3262,1213,32768,155,32769,32915,35866,32769,2074,32921,33964,35989,33836,3255,33823,32768,32769,2184,2062,1197,173,32784,1213,34963]

theorem envBound41057 : H12AffineFastState.Bounded env41057 := by
  intro p hp
  have h : env41057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41056_41057 : H12AffineEnvironment.transform 8 136 env41056 = env41057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env41056 == env41057) = true)

theorem identity41057 : scanCanonicalize (H12AffineFastState.compose env41057 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41057 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env41058 : List Nat := [2,4,8,16,32,17,128,173,136,4,2048,2074,2234,185,32768,155,32769,32915,34846,32769,2074,32921,32936,34961,32808,2227,32795,32768,32769,2184,2062,169,173,32784,185,34963]

theorem envBound41058 : H12AffineFastState.Bounded env41058 := by
  intro p hp
  have h : env41058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41057_41058 : H12AffineEnvironment.transform 9 4 env41057 = env41058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41057 == env41058) = true)

theorem identity41058 : scanCanonicalize (H12AffineFastState.compose env41058 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound41058 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41059 : List Nat := [2,4,8,16,32,17,128,173,136,4,147,137,41,185,32768,155,32769,32915,32909,32769,137,32921,32936,32770,32808,32,32795,32768,32769,27,157,169,173,32784,185,32768]

theorem envBound41059 : H12AffineFastState.Bounded env41059 := by
  intro p hp
  have h : env41059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41058_41059 : H12AffineEnvironment.transform 10 147 env41058 = env41059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env41058 == env41059) = true)

theorem identity41059 : scanCanonicalize (H12AffineFastState.compose env41059 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 49) := by decide +kernel

theorem selectedBound41059 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41060 : List Nat := [2,4,8,16,32,17,128,173,136,4,147,137,41,185,49,155,48,162,188,48,137,168,153,51,25,32,42,49,48,27,157,169,173,33,185,49]

theorem envBound41060 : H12AffineFastState.Bounded env41060 := by
  intro p hp
  have h : env41060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41059_41060 : H12AffineEnvironment.transform 14 49 env41059 = env41060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 49 env41059 == env41060) = true)

theorem identity41060 : scanCanonicalize (H12AffineFastState.compose env41060 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound41060 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41061 : List Nat := [2,4,8,16,32,17,62,19,54,4,45,55,41,7,49,37,48,28,2,48,55,22,39,51,25,32,42,49,48,27,35,23,19,33,7,49]

theorem envBound41061 : H12AffineFastState.Bounded env41061 := by
  intro p hp
  have h : env41061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41060_41061 : H12AffineEnvironment.transform 6 62 env41060 = env41061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env41060 == env41061) = true)

theorem identity41061 : scanCanonicalize (H12AffineFastState.compose env41061 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41061 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41062 : List Nat := [2,4,8,16,16,17,14,19,6,4,29,7,25,7,1,21,0,28,2,0,7,22,23,3,25,16,26,1,0,27,19,23,19,17,7,1]

theorem envBound41062 : H12AffineFastState.Bounded env41062 := by
  intro p hp
  have h : env41062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41061_41062 : H12AffineEnvironment.transform 4 16 env41061 = env41062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41061 == env41062) = true)

theorem identity41062 : scanCanonicalize (H12AffineFastState.compose env41062 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41062 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41063 : List Nat := [2,4,8,10,10,11,14,9,6,4,7,7,3,7,1,15,0,6,2,0,7,12,13,3,3,10,0,1,0,1,9,13,9,11,7,1]

theorem envBound41063 : H12AffineFastState.Bounded env41063 := by
  intro p hp
  have h : env41063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41062_41063 : H12AffineEnvironment.transform 3 10 env41062 = env41063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41062 == env41063) = true)

def env41064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,134217728,148800,545089,96347,16876545,16819498,257,545105,151462016,525824]

theorem envBound41064 : H12AffineFastState.Bounded env41064 := by
  intro p hp
  have h : env41064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40823_41064 : H12AffineEnvironment.transform 24 533641 env40823 = env41064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env40823 == env41064) = true)

def env41065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245632,148800,545089,96347,16876545,16819498,257,545105,1344,525824]

theorem envBound41065 : H12AffineFastState.Bounded env41065 := by
  intro p hp
  have h : env41065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41064_41065 : H12AffineEnvironment.transform 26 17245632 env41064 = env41065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env41064 == env41065) = true)

theorem identity41065 : scanCanonicalize (H12AffineFastState.compose env41065 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound41065 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env41066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86518,209262,17245632,148800,74814,96347,16876545,16819498,257,74798,1344,95103]

theorem envBound41066 : H12AffineFastState.Bounded env41066 := by
  intro p hp
  have h : env41066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41065_41066 : H12AffineEnvironment.transform 18 95615 env41065 = env41066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env41065 == env41066) = true)

def env41067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86518,209262,225344,148800,74814,96347,381313,323754,257,74798,1344,95103]

theorem envBound41067 : H12AffineFastState.Bounded env41067 := by
  intro p hp
  have h : env41067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41066_41067 : H12AffineEnvironment.transform 23 284032 env41066 = env41067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env41066 == env41067) = true)

def env41068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86518,94526,77840,1296,74814,96347,381313,323754,257,74798,1344,95103]

theorem envBound41068 : H12AffineFastState.Bounded env41068 := by
  intro p hp
  have h : env41068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41067_41068 : H12AffineEnvironment.transform 16 16464 env41067 = env41068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env41067 == env41068) = true)

def env41069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70886,78894,77840,1296,74814,81227,365713,308666,257,74798,1344,79471]

theorem envBound41069 : H12AffineFastState.Bounded env41069 := by
  intro p hp
  have h : env41069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41068_41069 : H12AffineEnvironment.transform 13 1296 env41068 = env41069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41068 == env41069) = true)

theorem identity41069 : scanCanonicalize (H12AffineFastState.compose env41069 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound41069 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,17,266384,38036,46172,45154,1296,42060,48441,267491,308666,257,42076,1344,46621]

theorem envBound41070 : H12AffineFastState.Bounded env41070 := by
  intro p hp
  have h : env41070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41069_41070 : H12AffineEnvironment.transform 15 32882 env41069 = env41070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env41069 == env41070) = true)

def env41071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263632,33236,41244,42274,1296,42060,43129,262563,303354,257,42076,1344,41821]

theorem envBound41071 : H12AffineFastState.Bounded env41071 := by
  intro p hp
  have h : env41071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41070_41071 : H12AffineEnvironment.transform 11 1344 env41070 = env41071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env41070 == env41071) = true)

theorem identity41071 : scanCanonicalize (H12AffineFastState.compose env41071 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound41071 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9292,9278,1344,262144,273,9293,1344,1229,17,263632,9624,1360,366,1296,0,3125,262563,263350,257,16,1344,1809]

theorem envBound41072 : H12AffineFastState.Bounded env41072 := by
  intro p hp
  have h : env41072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41071_41072 : H12AffineEnvironment.transform 14 9292 env41071 = env41072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env41071 == env41072) = true)

theorem identity41072 : scanCanonicalize (H12AffineFastState.compose env41072 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41072 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41073 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8495,81,262144,273,8540,81,476,17,262337,8329,65,366,1,0,2340,262563,262567,257,16,81,512]

theorem envBound41073 : H12AffineFastState.Bounded env41073 := by
  intro p hp
  have h : env41073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41072_41073 : H12AffineEnvironment.transform 9 273 env41072 = env41073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41072 == env41073) = true)

theorem identity41073 : scanCanonicalize (H12AffineFastState.compose env41073 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound41073 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41074 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,81,8192,1,8216,8298,81,262144,84,8217,81,153,17,262337,8329,65,43,1,0,2145,262374,262370,68,16,81,512]

theorem envBound41074 : H12AffineFastState.Bounded env41074 := by
  intro p hp
  have h : env41074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41073_41074 : H12AffineEnvironment.transform 7 69 env41073 = env41074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env41073 == env41074) = true)

theorem identity41074 : scanCanonicalize (H12AffineFastState.compose env41074 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound41074 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41075 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,81,657,1,649,763,81,262144,84,648,81,153,17,262337,536,65,43,1,0,2145,262374,262370,68,16,81,512]

theorem envBound41075 : H12AffineFastState.Bounded env41075 := by
  intro p hp
  have h : env41075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41074_41075 : H12AffineEnvironment.transform 12 657 env41074 = env41075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env41074 == env41075) = true)

theorem identity41075 : scanCanonicalize (H12AffineFastState.compose env41075 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41075 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41076 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,657,1,649,682,0,262144,5,648,0,153,17,262288,536,16,43,1,0,2096,262327,262323,21,16,0,512]

theorem envBound41076 : H12AffineFastState.Bounded env41076 := by
  intro p hp
  have h : env41076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41075_41076 : H12AffineEnvironment.transform 5 17 env41075 = env41076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41075 == env41076) = true)

def env41077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263633,33237,41245,42275,1296,42060,43128,262562,303355,257,42076,1344,41820]

theorem envBound41077 : H12AffineFastState.Bounded env41077 := by
  intro p hp
  have h : env41077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41070_41077 : H12AffineEnvironment.transform 11 1345 env41070 = env41077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env41070 == env41077) = true)

theorem identity41077 : scanCanonicalize (H12AffineFastState.compose env41077 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound41077 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,9407,42332,32769,1345,41088,17,8558,33237,41245,42275,1296,42060,43128,9501,33860,257,42076,1344,41820]

theorem envBound41078 : H12AffineFastState.Bounded env41078 := by
  intro p hp
  have h : env41078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41077_41078 : H12AffineEnvironment.transform 17 9407 env41077 = env41078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env41077 == env41078) = true)

theorem identity41078 : scanCanonicalize (H12AffineFastState.compose env41078 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound41078 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env41079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1345,8192,1296,32768,32882,1344,9407,42332,32769,1345,41088,17,8558,33237,41245,42275,1296,42060,42787,9501,33860,257,42076,1344,41820]

theorem envBound41079 : H12AffineFastState.Bounded env41079 := by
  intro p hp
  have h : env41079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41078_41079 : H12AffineEnvironment.transform 10 1883 env41078 = env41079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env41078 == env41079) = true)

def env41080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70887,78895,77840,1296,74814,81226,365712,308667,257,74798,1344,79470]

theorem envBound41080 : H12AffineFastState.Bounded env41080 := by
  intro p hp
  have h : env41080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41068_41080 : H12AffineEnvironment.transform 13 1297 env41068 = env41080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41068 == env41080) = true)

theorem identity41080 : scanCanonicalize (H12AffineFastState.compose env41080 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound41080 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,17,266385,70887,78895,77840,1296,74814,81226,336012,262567,257,74798,1344,79470]

theorem envBound41081 : H12AffineFastState.Bounded env41081 := by
  intro p hp
  have h : env41081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41080_41081 : H12AffineEnvironment.transform 14 13340 env41080 = env41081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41080 == env41081) = true)

def env41082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,17,69649,70887,78895,77840,1296,74814,81226,8204,65831,257,74798,1344,79470]

theorem envBound41082 : H12AffineFastState.Bounded env41082 := by
  intro p hp
  have h : env41082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41081_41082 : H12AffineEnvironment.transform 17 65664 env41081 = env41082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41081 == env41082) = true)

theorem identity41082 : scanCanonicalize (H12AffineFastState.compose env41082 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound41082 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,310,1345,438,12632,13341,4096,476,17,4391,5585,13593,12582,1296,9480,15484,8204,17,257,9496,1344,14168]

theorem envBound41083 : H12AffineFastState.Bounded env41083 := by
  intro p hp
  have h : env41083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41082_41083 : H12AffineEnvironment.transform 15 310 env41082 = env41083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env41082 == env41083) = true)

def env41084 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,310,1297,438,12552,13341,4096,396,17,4391,5505,13593,12582,1296,9480,15404,8204,17,257,9496,1296,14088]

theorem envBound41084 : H12AffineFastState.Bounded env41084 := by
  intro p hp
  have h : env41084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41083_41084 : H12AffineEnvironment.transform 5 16 env41083 = env41084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41083 == env41084) = true)

theorem identity41084 : scanCanonicalize (H12AffineFastState.compose env41084 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41084 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41085 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,8192,276,12313,310,276,438,12552,12312,4096,396,17,4391,4484,12572,12582,277,8461,14377,8204,17,257,8477,277,13069]

theorem envBound41085 : H12AffineFastState.Bounded env41085 := by
  intro p hp
  have h : env41085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41084_41085 : H12AffineEnvironment.transform 9 5 env41084 = env41085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41084 == env41085) = true)

theorem identity41085 : scanCanonicalize (H12AffineFastState.compose env41085 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound41085 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41086 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,8192,276,8461,310,276,438,8220,8460,276,396,17,51,144,8200,8242,277,8461,10557,8204,17,257,8477,277,8729]

theorem envBound41086 : H12AffineFastState.Bounded env41086 := by
  intro p hp
  have h : env41086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41085_41086 : H12AffineEnvironment.transform 11 276 env41085 = env41086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env41085 == env41086) = true)

theorem identity41086 : scanCanonicalize (H12AffineFastState.compose env41086 (packedSelected [0,1,2,3,7,10,13,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2343) := by decide +kernel

theorem selectedBound41086 : packedSelected [0,1,2,3,7,10,13,18,19] rootPS < 2^1333 := by decide +kernel

def env41087 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,2343,276,2090,310,276,438,2363,2091,276,396,17,51,144,2351,2325,277,2090,26,2347,17,257,2106,277,2878]

theorem envBound41087 : H12AffineFastState.Bounded env41087 := by
  intro p hp
  have h : env41087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41086_41087 : H12AffineEnvironment.transform 12 2343 env41086 = env41087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2343 env41086 == env41087) = true)

theorem identity41087 : scanCanonicalize (H12AffineFastState.compose env41087 (packedSelected [0,5,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound41087 : packedSelected [0,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env41088 : List Nat := [2,4,8,16,32,16,128,256,293,5,2048,276,2343,276,2090,310,276,438,2363,2091,276,396,17,51,144,2351,2325,277,2090,26,2347,17,257,2106,277,2075]

theorem envBound41088 : H12AffineFastState.Bounded env41088 := by
  intro p hp
  have h : env41088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41087_41088 : H12AffineEnvironment.transform 8 293 env41087 = env41088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env41087 == env41088) = true)

theorem identity41088 : scanCanonicalize (H12AffineFastState.compose env41088 (packedSelected [1,2,3,4,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41088 : packedSelected [1,2,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41089 : List Nat := [2,4,8,16,32,16,128,20,49,5,2048,0,2099,0,2090,34,0,162,2095,2091,0,152,17,51,144,2107,2049,1,2090,26,2111,17,21,2106,1,2075]

theorem envBound41089 : H12AffineFastState.Bounded env41089 := by
  intro p hp
  have h : env41089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41088_41089 : H12AffineEnvironment.transform 7 20 env41088 = env41089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41088 == env41089) = true)

theorem identity41089 : scanCanonicalize (H12AffineFastState.compose env41089 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41089 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41090 : List Nat := [2,4,8,16,32,16,128,20,49,5,1,0,50,0,43,34,0,162,46,42,0,152,17,51,144,58,0,1,43,26,62,17,21,59,1,26]

theorem envBound41090 : H12AffineFastState.Bounded env41090 := by
  intro p hp
  have h : env41090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41089_41090 : H12AffineEnvironment.transform 10 1 env41089 = env41090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41089 == env41090) = true)

theorem identity41090 : scanCanonicalize (H12AffineFastState.compose env41090 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41090 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41091 : List Nat := [2,4,8,16,16,16,128,20,1,5,1,0,2,0,27,18,0,146,30,26,0,152,17,3,144,10,0,1,27,26,14,17,21,11,1,26]

theorem envBound41091 : H12AffineFastState.Bounded env41091 := by
  intro p hp
  have h : env41091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41090_41091 : H12AffineEnvironment.transform 4 16 env41090 = env41091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41090 == env41091) = true)

def env41092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,310,1296,438,12553,13341,4096,397,17,4391,5504,13593,12582,1296,9480,15405,8204,17,257,9496,1297,14089]

theorem envBound41092 : H12AffineFastState.Bounded env41092 := by
  intro p hp
  have h : env41092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41083_41092 : H12AffineEnvironment.transform 5 17 env41083 = env41092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41083 == env41092) = true)

theorem identity41092 : scanCanonicalize (H12AffineFastState.compose env41092 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound41092 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4365,1297,1297,310,1296,438,4,1296,4096,397,17,4391,5504,1044,43,1296,5125,3360,4353,17,257,5141,1297,1540]

theorem envBound41093 : H12AffineFastState.Bounded env41093 := by
  intro p hp
  have h : env41093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41092_41093 : H12AffineEnvironment.transform 12 4365 env41092 = env41093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env41092 == env41093) = true)

theorem identity41093 : scanCanonicalize (H12AffineFastState.compose env41093 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound41093 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,1052,1297,1297,310,1296,438,4,1296,1297,397,17,1078,145,1044,43,1296,276,3360,1040,17,257,260,1297,1540]

theorem envBound41094 : H12AffineFastState.Bounded env41094 := by
  intro p hp
  have h : env41094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41093_41094 : H12AffineEnvironment.transform 11 1297 env41093 = env41094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env41093 == env41094) = true)

theorem identity41094 : scanCanonicalize (H12AffineFastState.compose env41094 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41094 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env41095 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,293,40,293,293,310,292,438,4,292,293,397,17,2,145,32,43,292,276,2324,36,17,257,260,293,560]

theorem envBound41095 : H12AffineFastState.Bounded env41095 := by
  intro p hp
  have h : env41095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41094_41095 : H12AffineEnvironment.transform 9 52 env41094 = env41095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41094 == env41095) = true)

theorem identity41095 : scanCanonicalize (H12AffineFastState.compose env41095 (packedSelected [0,2,7,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound41095 : packedSelected [0,2,7,11,17] rootPS < 2^1333 := by decide +kernel

def env41096 : List Nat := [2,4,8,16,32,17,128,256,512,52,561,293,40,293,293,310,292,438,4,292,293,397,17,2,145,32,43,292,276,805,36,17,257,260,293,560]

theorem envBound41096 : H12AffineFastState.Bounded env41096 := by
  intro p hp
  have h : env41096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41095_41096 : H12AffineEnvironment.transform 10 561 env41095 = env41096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env41095 == env41096) = true)

theorem identity41096 : scanCanonicalize (H12AffineFastState.compose env41096 (packedSelected [1,2,5,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound41096 : packedSelected [1,2,5,12,15] rootPS < 2^1333 := by decide +kernel

def env41097 : List Nat := [2,4,8,16,32,17,128,135,512,52,561,162,40,162,162,177,163,49,4,163,162,10,17,2,145,32,43,163,147,674,36,17,134,131,162,560]

theorem envBound41097 : H12AffineFastState.Bounded env41097 := by
  intro p hp
  have h : env41097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41096_41097 : H12AffineEnvironment.transform 7 135 env41096 = env41097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env41096 == env41097) = true)

theorem identity41097 : scanCanonicalize (H12AffineFastState.compose env41097 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound41097 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41098 : List Nat := [2,4,8,16,32,17,128,135,43,52,26,162,40,162,162,177,163,49,4,163,162,10,17,2,145,32,43,163,147,137,36,17,134,131,162,27]

theorem envBound41098 : H12AffineFastState.Bounded env41098 := by
  intro p hp
  have h : env41098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41097_41098 : H12AffineEnvironment.transform 8 43 env41097 = env41098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env41097 == env41098) = true)

theorem identity41098 : scanCanonicalize (H12AffineFastState.compose env41098 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41098 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41099 : List Nat := [2,4,8,16,32,17,19,20,43,52,26,49,40,49,49,34,48,49,4,48,49,10,17,2,2,32,43,48,0,26,36,17,21,16,49,27]

theorem envBound41099 : H12AffineFastState.Bounded env41099 := by
  intro p hp
  have h : env41099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41098_41099 : H12AffineEnvironment.transform 6 19 env41098 = env41099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41098 == env41099) = true)

theorem identity41099 : scanCanonicalize (H12AffineFastState.compose env41099 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41099 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41100 : List Nat := [2,3,8,16,32,17,19,19,43,51,26,49,40,49,49,34,48,49,3,48,49,10,17,2,2,32,43,48,0,26,35,17,18,16,49,27]

theorem envBound41100 : H12AffineFastState.Bounded env41100 := by
  intro p hp
  have h : env41100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41099_41100 : H12AffineEnvironment.transform 1 3 env41099 = env41100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41099 == env41100) = true)

theorem identity41100 : scanCanonicalize (H12AffineFastState.compose env41100 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41101 : List Nat := [2,3,8,16,16,17,19,19,27,3,26,1,24,1,1,18,0,1,3,0,1,10,17,2,2,16,27,0,0,26,19,17,18,16,1,27]

theorem envBound41101 : H12AffineFastState.Bounded env41101 := by
  intro p hp
  have h : env41101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41100_41101 : H12AffineEnvironment.transform 4 16 env41100 = env41101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41100 == env41101) = true)

theorem identity41101 : scanCanonicalize (H12AffineFastState.compose env41101 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41102 : List Nat := [2,3,8,11,11,10,8,8,0,3,1,1,3,1,1,9,0,1,3,0,1,10,10,2,2,11,0,0,0,1,8,10,9,11,1,0]

theorem envBound41102 : H12AffineFastState.Bounded env41102 := by
  intro p hp
  have h : env41102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41101_41102 : H12AffineEnvironment.transform 3 11 env41101 = env41102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41101 == env41102) = true)

def env41103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,17,69648,70887,78895,77840,1296,74814,81226,8205,65830,257,74798,1344,79470]

theorem envBound41103 : H12AffineFastState.Bounded env41103 := by
  intro p hp
  have h : env41103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41081_41103 : H12AffineEnvironment.transform 17 65665 env41081 = env41103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41081 == env41103) = true)

theorem identity41103 : scanCanonicalize (H12AffineFastState.compose env41103 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound41103 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5239,1345,5366,9241,13341,4096,476,17,1127,144,8280,9319,1296,12361,10557,8205,5457,257,12377,1344,8729]

theorem envBound41104 : H12AffineFastState.Bounded env41104 := by
  intro p hp
  have h : env41104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41103_41104 : H12AffineEnvironment.transform 15 5239 env41103 = env41104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env41103 == env41104) = true)

def env41105 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5159,1297,5286,9241,13341,4096,396,17,1079,144,8200,9271,1296,12313,10557,8205,5377,257,12297,1296,8729]

theorem envBound41105 : H12AffineFastState.Bounded env41105 := by
  intro p hp
  have h : env41105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41104_41105 : H12AffineEnvironment.transform 5 16 env41104 = env41105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41104 == env41105) = true)

theorem identity41105 : scanCanonicalize (H12AffineFastState.compose env41105 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41105 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41106 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,8192,276,12313,4130,276,4259,8220,12312,4096,396,17,50,144,8200,8242,277,12313,10557,8205,4356,257,12297,277,8729]

theorem envBound41106 : H12AffineFastState.Bounded env41106 := by
  intro p hp
  have h : env41106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41105_41106 : H12AffineEnvironment.transform 9 5 env41105 = env41106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41105 == env41106) = true)

theorem identity41106 : scanCanonicalize (H12AffineFastState.compose env41106 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound41106 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41107 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4365,276,276,4130,276,4259,4369,277,4096,396,17,50,144,4357,4415,277,276,6192,4352,4356,257,260,277,4884]

theorem envBound41107 : H12AffineFastState.Bounded env41107 := by
  intro p hp
  have h : env41107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41106_41107 : H12AffineEnvironment.transform 12 4365 env41106 = env41107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env41106 == env41107) = true)

theorem identity41107 : scanCanonicalize (H12AffineFastState.compose env41107 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound41107 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41108 : List Nat := [2,4,8,16,32,16,128,256,270,5,2048,4096,4365,276,276,4130,276,4259,4369,277,4096,396,17,50,144,4357,4415,277,276,6192,4352,4356,257,260,277,4122]

theorem envBound41108 : H12AffineFastState.Bounded env41108 := by
  intro p hp
  have h : env41108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41107_41108 : H12AffineEnvironment.transform 8 270 env41107 = env41108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env41107 == env41108) = true)

theorem identity41108 : scanCanonicalize (H12AffineFastState.compose env41108 (packedSelected [1,8,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound41108 : packedSelected [1,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env41109 : List Nat := [2,4,8,16,32,16,57,256,270,5,2048,4096,4365,276,276,4130,276,4122,4369,277,4096,309,17,50,41,4357,4415,277,276,6192,4352,4356,257,260,277,4122]

theorem envBound41109 : H12AffineFastState.Bounded env41109 := by
  intro p hp
  have h : env41109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41108_41109 : H12AffineEnvironment.transform 6 57 env41108 = env41109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env41108 == env41109) = true)

theorem identity41109 : scanCanonicalize (H12AffineFastState.compose env41109 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound41109 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41110 : List Nat := [2,4,8,16,32,16,57,256,270,5,2048,2097,2364,276,276,2067,276,2091,2336,277,2097,309,17,50,41,2356,2318,277,276,1,2353,2357,257,260,277,2091]

theorem envBound41110 : H12AffineFastState.Bounded env41110 := by
  intro p hp
  have h : env41110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41109_41110 : H12AffineEnvironment.transform 11 2097 env41109 = env41110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env41109 == env41110) = true)

theorem identity41110 : scanCanonicalize (H12AffineFastState.compose env41110 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound41110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41111 : List Nat := [2,4,8,16,32,16,57,256,270,5,43,26,279,276,276,56,276,0,267,277,26,309,17,50,41,287,293,277,276,1,282,286,257,260,277,0]

theorem envBound41111 : H12AffineFastState.Bounded env41111 := by
  intro p hp
  have h : env41111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41110_41111 : H12AffineEnvironment.transform 10 43 env41110 = env41111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env41110 == env41111) = true)

theorem identity41111 : scanCanonicalize (H12AffineFastState.compose env41111 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41111 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env41112 : List Nat := [2,4,8,16,10,16,19,256,270,5,1,26,279,276,276,18,276,0,267,277,26,287,17,24,3,287,271,277,276,1,282,286,257,260,277,0]

theorem envBound41112 : H12AffineFastState.Bounded env41112 := by
  intro p hp
  have h : env41112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41111_41112 : H12AffineEnvironment.transform 4 10 env41111 = env41112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41111 == env41112) = true)

theorem identity41112 : scanCanonicalize (H12AffineFastState.compose env41112 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound41112 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41113 : List Nat := [2,4,8,16,10,16,19,14,0,5,1,26,25,26,26,18,26,0,5,27,26,17,17,24,3,17,1,27,26,1,20,16,15,10,27,0]

theorem envBound41113 : H12AffineFastState.Bounded env41113 := by
  intro p hp
  have h : env41113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41112_41113 : H12AffineEnvironment.transform 7 14 env41112 = env41113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env41112 == env41113) = true)

theorem identity41113 : scanCanonicalize (H12AffineFastState.compose env41113 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41113 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41114 : List Nat := [2,4,8,10,10,10,9,14,0,5,1,0,3,0,0,8,0,0,5,1,0,11,11,2,3,11,1,1,0,1,14,10,15,10,1,0]

theorem envBound41114 : H12AffineFastState.Bounded env41114 := by
  intro p hp
  have h : env41114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41113_41114 : H12AffineEnvironment.transform 3 10 env41113 = env41114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41113 == env41114) = true)

theorem identity41114 : scanCanonicalize (H12AffineFastState.compose env41114 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41115 : List Nat := [2,4,4,6,6,6,5,2,0,5,1,0,3,0,0,4,0,0,5,1,0,7,7,2,3,7,1,1,0,1,2,6,3,6,1,0]

theorem envBound41115 : H12AffineFastState.Bounded env41115 := by
  intro p hp
  have h : env41115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41114_41115 : H12AffineEnvironment.transform 2 4 env41114 = env41115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41114 == env41115) = true)

def env41116 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5287,9241,13341,4096,397,17,1078,144,8201,9270,1296,12312,10557,8205,5376,257,12296,1297,8729]

theorem envBound41116 : H12AffineFastState.Bounded env41116 := by
  intro p hp
  have h : env41116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41104_41116 : H12AffineEnvironment.transform 5 17 env41104 = env41116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41104 == env41116) = true)

theorem identity41116 : scanCanonicalize (H12AffineFastState.compose env41116 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound41116 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41117 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1053,1297,4097,5158,1296,5287,4,4096,4096,397,17,1078,144,1044,43,1296,5125,3360,1040,5376,257,5141,1297,1540]

theorem envBound41117 : H12AffineFastState.Bounded env41117 := by
  intro p hp
  have h : env41117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41116_41117 : H12AffineEnvironment.transform 12 1053 env41116 = env41117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env41116 == env41117) = true)

theorem identity41117 : scanCanonicalize (H12AffineFastState.compose env41117 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound41117 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41118 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,1053,1297,276,1331,1296,1458,4,277,277,397,17,1078,144,1044,43,1296,1296,3360,1040,1045,257,1280,1297,1540]

theorem envBound41118 : H12AffineFastState.Bounded env41118 := by
  intro p hp
  have h : env41118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41117_41118 : H12AffineEnvironment.transform 11 277 env41117 = env41118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env41117 == env41118) = true)

theorem identity41118 : scanCanonicalize (H12AffineFastState.compose env41118 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 387) := by decide +kernel

theorem selectedBound41118 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env41119 : List Nat := [2,4,8,16,32,17,128,256,512,387,2048,277,414,146,276,176,147,49,4,277,277,397,17,437,144,407,43,147,147,2211,403,406,257,131,146,903]

theorem envBound41119 : H12AffineFastState.Bounded env41119 := by
  intro p hp
  have h : env41119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41118_41119 : H12AffineEnvironment.transform 9 387 env41118 = env41119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 387 env41118 == env41119) = true)

theorem identity41119 : scanCanonicalize (H12AffineFastState.compose env41119 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41119 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env41120 : List Nat := [2,4,8,16,32,17,128,36,512,167,2048,49,186,146,48,176,147,49,4,49,49,169,17,145,144,179,43,147,147,2211,183,178,37,131,146,675]

theorem envBound41120 : H12AffineFastState.Bounded env41120 := by
  intro p hp
  have h : env41120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41119_41120 : H12AffineEnvironment.transform 7 36 env41119 = env41120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41119 == env41120) = true)

theorem identity41120 : scanCanonicalize (H12AffineFastState.compose env41120 (packedSelected [1,2,3,4,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41120 : packedSelected [1,2,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env41121 : List Nat := [2,4,8,16,32,17,18,36,512,53,2048,49,40,0,48,34,1,49,4,49,49,59,17,3,2,33,43,1,1,2097,37,32,37,17,0,561]

theorem envBound41121 : H12AffineFastState.Bounded env41121 := by
  intro p hp
  have h : env41121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41120_41121 : H12AffineEnvironment.transform 6 18 env41120 = env41121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41120 == env41121) = true)

theorem identity41121 : scanCanonicalize (H12AffineFastState.compose env41121 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 60) := by decide +kernel

theorem selectedBound41121 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41122 : List Nat := [2,4,8,16,32,17,18,36,512,53,60,49,40,0,48,34,1,49,4,49,49,59,17,3,2,33,43,1,1,13,37,32,37,17,0,561]

theorem envBound41122 : H12AffineFastState.Bounded env41122 := by
  intro p hp
  have h : env41122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41121_41122 : H12AffineEnvironment.transform 10 60 env41121 = env41122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 60 env41121 == env41122) = true)

theorem identity41122 : scanCanonicalize (H12AffineFastState.compose env41122 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound41122 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env41123 : List Nat := [2,4,8,16,32,17,18,36,60,53,60,49,40,0,48,34,1,49,4,49,49,59,17,3,2,33,43,1,1,13,37,32,37,17,0,13]

theorem envBound41123 : H12AffineFastState.Bounded env41123 := by
  intro p hp
  have h : env41123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41122_41123 : H12AffineEnvironment.transform 8 60 env41122 = env41123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env41122 == env41123) = true)

theorem identity41123 : scanCanonicalize (H12AffineFastState.compose env41123 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41123 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41124 : List Nat := [2,4,8,6,32,7,4,36,42,35,42,39,40,0,38,34,1,39,4,39,39,45,7,3,2,33,43,1,1,13,37,32,37,7,0,13]

theorem envBound41124 : H12AffineFastState.Bounded env41124 := by
  intro p hp
  have h : env41124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41123_41124 : H12AffineEnvironment.transform 3 6 env41123 = env41124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41123 == env41124) = true)

theorem identity41124 : scanCanonicalize (H12AffineFastState.compose env41124 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41125 : List Nat := [2,4,5,6,32,7,4,36,39,35,39,39,37,0,38,34,1,39,4,39,39,32,7,3,2,33,38,1,1,0,37,32,37,7,0,0]

theorem envBound41125 : H12AffineFastState.Bounded env41125 := by
  intro p hp
  have h : env41125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41124_41125 : H12AffineEnvironment.transform 2 5 env41124 = env41125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41124 == env41125) = true)

def env41126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86518,94527,77841,1297,74814,96347,381313,323754,257,74798,1344,95103]

theorem envBound41126 : H12AffineFastState.Bounded env41126 := by
  intro p hp
  have h : env41126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41067_41126 : H12AffineEnvironment.transform 16 16465 env41067 = env41126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env41067 == env41126) = true)

def env41127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70886,78895,77841,1297,74814,81227,365713,308666,257,74798,1344,79471]

theorem envBound41127 : H12AffineFastState.Bounded env41127 := by
  intro p hp
  have h : env41127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41126_41127 : H12AffineEnvironment.transform 13 1296 env41126 = env41127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41126 == env41127) = true)

theorem identity41127 : scanCanonicalize (H12AffineFastState.compose env41127 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound41127 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,16,266384,70886,78895,77841,1297,74814,81227,336013,262566,257,74798,1344,79471]

theorem envBound41128 : H12AffineFastState.Bounded env41128 := by
  intro p hp
  have h : env41128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41127_41128 : H12AffineEnvironment.transform 14 13340 env41127 = env41128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41127 == env41128) = true)

def env41129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,16,69648,70886,78895,77841,1297,74814,81227,8205,65830,257,74798,1344,79471]

theorem envBound41129 : H12AffineFastState.Bounded env41129 := by
  intro p hp
  have h : env41129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41128_41129 : H12AffineEnvironment.transform 17 65664 env41128 = env41129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41128 == env41129) = true)

theorem identity41129 : scanCanonicalize (H12AffineFastState.compose env41129 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound41129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12671,1345,12799,272,13341,4096,477,16,8559,9625,1360,366,1297,5441,3124,8205,12377,257,5457,1344,1808]

theorem envBound41130 : H12AffineFastState.Bounded env41130 := by
  intro p hp
  have h : env41130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41129_41130 : H12AffineEnvironment.transform 15 12671 env41129 = env41130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env41129 == env41130) = true)

def env41131 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12671,1,12799,272,12637,4096,477,16,8559,8409,16,366,81,4097,2420,8205,12377,257,4113,0,592]

theorem envBound41131 : H12AffineFastState.Bounded env41131 := by
  intro p hp
  have h : env41131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41130_41131 : H12AffineEnvironment.transform 9 320 env41130 = env41131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41130 == env41131) = true)

theorem identity41131 : scanCanonicalize (H12AffineFastState.compose env41131 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41131 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41132 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,4096,8192,80,12361,12394,1,12522,5,12360,4096,200,16,8314,8409,16,123,81,4097,2145,8205,12377,20,4113,0,592]

theorem envBound41132 : H12AffineFastState.Bounded env41132 := by
  intro p hp
  have h : env41132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41131_41132 : H12AffineEnvironment.transform 7 21 env41131 = env41132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41131 == env41132) = true)

theorem identity41132 : scanCanonicalize (H12AffineFastState.compose env41132 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41132 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41133 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,8192,80,8265,8298,1,8426,5,8264,0,200,16,8314,8409,16,123,81,1,2145,8205,8281,20,17,0,592]

theorem envBound41133 : H12AffineFastState.Bounded env41133 := by
  intro p hp
  have h : env41133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41132_41133 : H12AffineEnvironment.transform 11 0 env41132 = env41133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41132 == env41133) = true)

theorem identity41133 : scanCanonicalize (H12AffineFastState.compose env41133 (packedSelected [5,8,17] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound41133 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env41134 : List Nat := [2,4,8,16,32,64,128,21,27,85,2048,0,8192,80,8265,8298,1,8426,5,8264,0,200,16,8314,8409,16,123,81,1,2145,8205,8281,20,17,0,75]

theorem envBound41134 : H12AffineFastState.Bounded env41134 := by
  intro p hp
  have h : env41134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41133_41134 : H12AffineEnvironment.transform 8 27 env41133 = env41134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env41133 == env41134) = true)

theorem identity41134 : scanCanonicalize (H12AffineFastState.compose env41134 (packedSelected [2,5,8,10,11,13,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2146) := by decide +kernel

theorem selectedBound41134 : packedSelected [2,5,8,10,11,13,18,19] rootPS < 2^1333 := by decide +kernel

def env41135 : List Nat := [2,4,8,16,32,64,128,21,27,85,2048,0,2146,80,2091,2056,1,2184,5,2090,0,200,16,2072,2235,16,123,81,1,2145,2159,2107,20,17,0,75]

theorem envBound41135 : H12AffineFastState.Bounded env41135 := by
  intro p hp
  have h : env41135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41134_41135 : H12AffineEnvironment.transform 12 2146 env41134 = env41135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2146 env41134 == env41135) = true)

theorem identity41135 : scanCanonicalize (H12AffineFastState.compose env41135 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41135 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41136 : List Nat := [2,4,8,16,10,64,128,21,27,85,2048,0,2120,80,2049,2056,1,2184,5,2048,0,200,16,2072,2193,16,81,81,1,2123,2117,2065,20,17,0,75]

theorem envBound41136 : H12AffineFastState.Bounded env41136 := by
  intro p hp
  have h : env41136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41135_41136 : H12AffineEnvironment.transform 4 10 env41135 = env41136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41135 == env41136) = true)

theorem identity41136 : scanCanonicalize (H12AffineFastState.compose env41136 (packedSelected [0,4,5,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound41136 : packedSelected [0,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env41137 : List Nat := [2,4,8,16,10,64,128,21,27,85,136,0,192,80,137,128,1,0,5,136,0,200,16,144,25,16,81,81,1,195,205,153,20,17,0,75]

theorem envBound41137 : H12AffineFastState.Bounded env41137 := by
  intro p hp
  have h : env41137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41136_41137 : H12AffineEnvironment.transform 10 136 env41136 = env41137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env41136 == env41137) = true)

theorem identity41137 : scanCanonicalize (H12AffineFastState.compose env41137 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound41137 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env41138 : List Nat := [2,4,8,16,10,10,128,21,27,31,136,0,138,26,137,128,1,0,5,136,0,130,16,144,25,16,27,27,1,137,135,153,20,17,0,1]

theorem envBound41138 : H12AffineFastState.Bounded env41138 := by
  intro p hp
  have h : env41138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41137_41138 : H12AffineEnvironment.transform 5 10 env41137 = env41138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env41137 == env41138) = true)

theorem identity41138 : scanCanonicalize (H12AffineFastState.compose env41138 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41138 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41139 : List Nat := [2,4,8,16,10,10,9,21,27,31,1,0,3,26,0,9,1,0,5,1,0,11,16,25,25,16,27,27,1,0,14,16,20,17,0,1]

theorem envBound41139 : H12AffineFastState.Bounded env41139 := by
  intro p hp
  have h : env41139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41138_41139 : H12AffineEnvironment.transform 6 9 env41138 = env41139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41138 == env41139) = true)

theorem identity41139 : scanCanonicalize (H12AffineFastState.compose env41139 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound41139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41140 : List Nat := [2,4,8,13,10,10,9,8,6,2,1,0,3,7,0,9,1,0,5,1,0,11,13,4,4,13,6,6,1,0,14,13,9,12,0,1]

theorem envBound41140 : H12AffineFastState.Bounded env41140 := by
  intro p hp
  have h : env41140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41139_41140 : H12AffineEnvironment.transform 3 13 env41139 = env41140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env41139 == env41140) = true)

theorem identity41140 : scanCanonicalize (H12AffineFastState.compose env41140 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41140 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41141 : List Nat := [2,2,8,11,10,10,9,8,0,2,1,0,3,1,0,9,1,0,3,1,0,11,11,2,2,11,0,0,1,0,8,11,9,10,0,1]

theorem envBound41141 : H12AffineFastState.Bounded env41141 := by
  intro p hp
  have h : env41141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41140_41141 : H12AffineEnvironment.transform 1 2 env41140 = env41141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41140 == env41141) = true)

theorem identity41141 : scanCanonicalize (H12AffineFastState.compose env41141 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41142 : List Nat := [2,2,1,2,3,3,0,1,0,2,1,0,3,1,0,0,1,0,3,1,0,2,2,2,2,2,0,0,1,0,1,2,0,3,0,1]

theorem envBound41142 : H12AffineFastState.Bounded env41142 := by
  intro p hp
  have h : env41142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41141_41142 : H12AffineEnvironment.transform 2 1 env41141 = env41142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41141 == env41142) = true)

theorem identity41142 : scanCanonicalize (H12AffineFastState.compose env41142 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41142 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41143 : List Nat := [1,1,1,1,0,0,0,1,0,1,1,0,0,1,0,0,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,0,0,0,1]

theorem envBound41143 : H12AffineFastState.Bounded env41143 := by
  intro p hp
  have h : env41143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41142_41143 : H12AffineEnvironment.transform 0 1 env41142 = env41143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41142 == env41143) = true)

def env41144 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12671,0,12799,272,12636,4096,477,16,8559,8408,17,366,80,4096,2421,8205,12377,257,4112,1,593]

theorem envBound41144 : H12AffineFastState.Bounded env41144 := by
  intro p hp
  have h : env41144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41130_41144 : H12AffineEnvironment.transform 9 321 env41130 = env41144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env41130 == env41144) = true)

theorem identity41144 : scanCanonicalize (H12AffineFastState.compose env41144 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound41144 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41145 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,4096,8192,81,12312,12346,0,12474,85,12313,4096,152,16,8234,8408,17,43,80,4096,2096,8205,12377,68,4112,1,593]

theorem envBound41145 : H12AffineFastState.Bounded env41145 := by
  intro p hp
  have h : env41145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41144_41145 : H12AffineEnvironment.transform 7 69 env41144 = env41145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env41144 == env41145) = true)

theorem identity41145 : scanCanonicalize (H12AffineFastState.compose env41145 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41145 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41146 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8216,8250,0,8378,85,8217,0,152,16,8234,8408,17,43,80,0,2096,8205,8281,68,16,1,593]

theorem envBound41146 : H12AffineFastState.Bounded env41146 := by
  intro p hp
  have h : env41146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41145_41146 : H12AffineEnvironment.transform 11 0 env41145 = env41146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41145 == env41146) = true)

theorem identity41146 : scanCanonicalize (H12AffineFastState.compose env41146 (packedSelected [5,8,17] rootPS)) = affineNative (2^(10+1) ^^^ 242) := by decide +kernel

theorem selectedBound41146 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env41147 : List Nat := [2,4,8,16,32,64,128,69,512,4,242,0,8192,81,8216,8250,0,8378,85,8217,0,152,16,8234,8408,17,43,80,0,194,8205,8281,68,16,1,593]

theorem envBound41147 : H12AffineFastState.Bounded env41147 := by
  intro p hp
  have h : env41147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41146_41147 : H12AffineEnvironment.transform 10 242 env41146 = env41147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 242 env41146 == env41147) = true)

theorem identity41147 : scanCanonicalize (H12AffineFastState.compose env41147 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound41147 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env41148 : List Nat := [2,4,8,16,32,64,128,69,512,4,242,0,673,81,697,667,0,539,85,696,0,152,16,651,633,17,43,80,0,194,684,760,68,16,1,593]

theorem envBound41148 : H12AffineFastState.Bounded env41148 := by
  intro p hp
  have h : env41148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41147_41148 : H12AffineEnvironment.transform 12 673 env41147 = env41148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env41147 == env41148) = true)

theorem identity41148 : scanCanonicalize (H12AffineFastState.compose env41148 (packedSelected [1,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound41148 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env41149 : List Nat := [2,4,8,16,32,64,128,69,146,4,242,0,51,81,43,9,0,137,85,42,0,152,16,25,235,17,43,80,0,194,62,106,68,16,1,195]

theorem envBound41149 : H12AffineFastState.Bounded env41149 := by
  intro p hp
  have h : env41149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41148_41149 : H12AffineEnvironment.transform 8 146 env41148 = env41149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env41148 == env41149) = true)

theorem identity41149 : scanCanonicalize (H12AffineFastState.compose env41149 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41149 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env41150 : List Nat := [2,4,8,16,10,64,128,69,146,4,216,0,25,81,1,9,0,137,85,0,0,152,16,25,193,17,1,80,0,194,20,64,68,16,1,195]

theorem envBound41150 : H12AffineFastState.Bounded env41150 := by
  intro p hp
  have h : env41150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41149_41150 : H12AffineEnvironment.transform 4 10 env41149 = env41150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41149 == env41150) = true)

theorem identity41150 : scanCanonicalize (H12AffineFastState.compose env41150 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41150 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41151 : List Nat := [2,3,8,16,10,64,128,66,146,3,216,0,25,81,1,9,0,137,82,0,0,152,16,25,193,17,1,80,0,194,19,64,67,16,1,195]

theorem envBound41151 : H12AffineFastState.Bounded env41151 := by
  intro p hp
  have h : env41151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41150_41151 : H12AffineEnvironment.transform 1 3 env41150 = env41151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41150 == env41151) = true)

theorem identity41151 : scanCanonicalize (H12AffineFastState.compose env41151 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41151 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41152 : List Nat := [2,3,8,16,10,17,128,19,146,3,137,0,25,0,1,9,0,137,3,0,0,152,16,25,144,17,1,1,0,147,19,17,18,16,1,146]

theorem envBound41152 : H12AffineFastState.Bounded env41152 := by
  intro p hp
  have h : env41152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41151_41152 : H12AffineEnvironment.transform 5 17 env41151 = env41152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41151 == env41152) = true)

theorem identity41152 : scanCanonicalize (H12AffineFastState.compose env41152 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41152 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41153 : List Nat := [2,3,8,10,10,11,128,9,136,3,137,0,3,0,1,9,0,137,3,0,0,130,10,3,138,11,1,1,0,137,9,11,8,10,1,136]

theorem envBound41153 : H12AffineFastState.Bounded env41153 := by
  intro p hp
  have h : env41153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41152_41153 : H12AffineEnvironment.transform 3 10 env41152 = env41153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41152 == env41153) = true)

theorem identity41153 : scanCanonicalize (H12AffineFastState.compose env41153 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41154 : List Nat := [2,3,8,10,10,11,9,9,1,3,0,0,3,0,1,9,0,0,3,0,0,11,10,3,3,11,1,1,0,0,9,11,8,10,1,1]

theorem envBound41154 : H12AffineFastState.Bounded env41154 := by
  intro p hp
  have h : env41154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41153_41154 : H12AffineEnvironment.transform 6 9 env41153 = env41154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41153 == env41154) = true)

def env41155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,16,69649,70886,78895,77841,1297,74814,81227,8204,65831,257,74798,1344,79471]

theorem envBound41155 : H12AffineFastState.Bounded env41155 := by
  intro p hp
  have h : env41155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41128_41155 : H12AffineEnvironment.transform 17 65665 env41128 = env41155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41128 == env41155) = true)

theorem identity41155 : scanCanonicalize (H12AffineFastState.compose env41155 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound41155 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9278,1345,9407,5201,13341,4096,477,16,13359,12504,4113,5167,1297,0,6517,8204,9497,257,16,1344,4689]

theorem envBound41156 : H12AffineFastState.Bounded env41156 := by
  intro p hp
  have h : env41156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41155_41156 : H12AffineEnvironment.transform 15 9278 env41155 = env41156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env41155 == env41156) = true)

def env41157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9278,1345,9407,1105,9245,0,477,16,9263,8408,17,1071,1297,0,2421,8204,9497,257,16,1344,593]

theorem envBound41157 : H12AffineFastState.Bounded env41157 := by
  intro p hp
  have h : env41157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41156_41157 : H12AffineEnvironment.transform 11 0 env41156 = env41157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41156 == env41157) = true)

theorem identity41157 : scanCanonicalize (H12AffineFastState.compose env41157 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41157 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41158 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,276,8216,8250,325,8379,85,8217,0,477,16,8235,8408,17,43,277,0,2421,8204,8477,257,16,324,593]

theorem envBound41158 : H12AffineFastState.Bounded env41158 := by
  intro p hp
  have h : env41158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41157_41158 : H12AffineEnvironment.transform 9 4 env41157 = env41158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41157 == env41158) = true)

theorem identity41158 : scanCanonicalize (H12AffineFastState.compose env41158 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41158 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41159 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,0,8192,0,8216,8250,81,8379,85,8217,0,201,16,8235,8408,17,43,1,0,2145,8204,8201,21,16,80,593]

theorem envBound41159 : H12AffineFastState.Bounded env41159 := by
  intro p hp
  have h : env41159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41158_41159 : H12AffineEnvironment.transform 7 20 env41158 = env41159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41158 == env41159) = true)

theorem identity41159 : scanCanonicalize (H12AffineFastState.compose env41159 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(12+1) ^^^ 218) := by decide +kernel

theorem selectedBound41159 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env41160 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,0,218,0,194,224,81,97,85,195,0,201,16,241,2,17,43,1,0,2145,214,211,21,16,80,593]

theorem envBound41160 : H12AffineFastState.Bounded env41160 := by
  intro p hp
  have h : env41160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41159_41160 : H12AffineEnvironment.transform 12 218 env41159 = env41160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 218 env41159 == env41160) = true)

theorem identity41160 : scanCanonicalize (H12AffineFastState.compose env41160 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound41160 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env41161 : List Nat := [2,4,8,16,32,64,128,20,75,4,2048,0,218,0,194,224,81,97,85,195,0,201,16,241,2,17,43,1,0,2145,214,211,21,16,80,26]

theorem envBound41161 : H12AffineFastState.Bounded env41161 := by
  intro p hp
  have h : env41161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41160_41161 : H12AffineEnvironment.transform 8 75 env41160 = env41161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env41160 == env41161) = true)

theorem identity41161 : scanCanonicalize (H12AffineFastState.compose env41161 (packedSelected [2,10,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound41161 : packedSelected [2,10,13,15] rootPS < 2^1333 := by decide +kernel

def env41162 : List Nat := [2,4,8,16,32,64,35,20,75,4,2048,0,121,0,97,67,81,97,85,96,0,106,16,82,2,17,43,1,0,2145,117,112,21,16,80,26]

theorem envBound41162 : H12AffineFastState.Bounded env41162 := by
  intro p hp
  have h : env41162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41161_41162 : H12AffineEnvironment.transform 6 35 env41161 = env41162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env41161 == env41162) = true)

theorem identity41162 : scanCanonicalize (H12AffineFastState.compose env41162 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound41162 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env41163 : List Nat := [2,4,8,16,32,64,35,20,75,4,75,0,121,0,97,67,81,97,85,96,0,106,16,82,2,17,43,1,0,42,117,112,21,16,80,26]

theorem envBound41163 : H12AffineFastState.Bounded env41163 := by
  intro p hp
  have h : env41163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41162_41163 : H12AffineEnvironment.transform 10 75 env41162 = env41163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env41162 == env41163) = true)

theorem identity41163 : scanCanonicalize (H12AffineFastState.compose env41163 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41164 : List Nat := [2,4,8,10,32,64,35,14,75,4,75,0,99,0,97,67,75,97,79,96,0,106,10,72,2,11,43,1,0,42,111,106,15,10,74,0]

theorem envBound41164 : H12AffineFastState.Bounded env41164 := by
  intro p hp
  have h : env41164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41163_41164 : H12AffineEnvironment.transform 3 10 env41163 = env41164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41163 == env41164) = true)

def env41165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9278,1345,9407,1104,9244,1,477,16,9262,8409,16,1070,1297,0,2420,8204,9497,257,16,1344,592]

theorem envBound41165 : H12AffineFastState.Bounded env41165 := by
  intro p hp
  have h : env41165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41156_41165 : H12AffineEnvironment.transform 11 1 env41156 = env41165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env41156 == env41165) = true)

theorem identity41165 : scanCanonicalize (H12AffineFastState.compose env41165 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound41165 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41166 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,1,8192,325,8264,8299,276,8426,5,8265,1,477,16,8315,8409,16,123,324,0,2420,8204,8524,257,16,277,592]

theorem envBound41166 : H12AffineFastState.Bounded env41166 := by
  intro p hp
  have h : env41166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41165_41166 : H12AffineEnvironment.transform 9 85 env41165 = env41166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env41165 == env41166) = true)

theorem identity41166 : scanCanonicalize (H12AffineFastState.compose env41166 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41166 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41167 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,1,8192,1,8264,8299,80,8426,5,8265,1,153,16,8315,8409,16,123,0,0,2096,8204,8200,69,16,81,592]

theorem envBound41167 : H12AffineFastState.Bounded env41167 := by
  intro p hp
  have h : env41167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41166_41167 : H12AffineEnvironment.transform 7 68 env41166 = env41167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41166 == env41167) = true)

theorem identity41167 : scanCanonicalize (H12AffineFastState.compose env41167 (packedSelected [1,2,3,5,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 634) := by decide +kernel

theorem selectedBound41167 : packedSelected [1,2,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env41168 : List Nat := [2,4,8,16,32,64,128,68,512,85,634,1,8192,1,8264,8299,80,8426,5,8265,1,153,16,8315,8409,16,123,0,0,586,8204,8200,69,16,81,592]

theorem envBound41168 : H12AffineFastState.Bounded env41168 := by
  intro p hp
  have h : env41168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41167_41168 : H12AffineEnvironment.transform 10 634 env41167 = env41168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 634 env41167 == env41168) = true)

theorem identity41168 : scanCanonicalize (H12AffineFastState.compose env41168 (packedSelected [0,3,7,8,18] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound41168 : packedSelected [0,3,7,8,18] rootPS < 2^1333 := by decide +kernel

def env41169 : List Nat := [2,4,8,16,32,64,128,68,74,85,48,1,8192,1,8264,8299,80,8426,5,8265,1,153,16,8315,8409,16,123,0,0,0,8204,8200,69,16,81,26]

theorem envBound41169 : H12AffineFastState.Bounded env41169 := by
  intro p hp
  have h : env41169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41168_41169 : H12AffineEnvironment.transform 8 74 env41168 = env41169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env41168 == env41169) = true)

theorem identity41169 : scanCanonicalize (H12AffineFastState.compose env41169 (packedSelected [2,5,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound41169 : packedSelected [2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41170 : List Nat := [2,4,8,16,32,64,128,68,74,85,48,1,50,1,122,89,80,216,5,123,1,153,16,73,235,16,123,0,0,0,62,58,69,16,81,26]

theorem envBound41170 : H12AffineFastState.Bounded env41170 := by
  intro p hp
  have h : env41170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41169_41170 : H12AffineEnvironment.transform 12 50 env41169 = env41170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env41169 == env41170) = true)

theorem identity41170 : scanCanonicalize (H12AffineFastState.compose env41170 (packedSelected [0,2,3,7,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41170 : packedSelected [0,2,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env41171 : List Nat := [2,4,8,10,32,64,128,68,74,79,42,1,40,1,96,67,74,194,5,97,1,131,10,73,235,10,97,0,0,0,36,32,69,10,75,0]

theorem envBound41171 : H12AffineFastState.Bounded env41171 := by
  intro p hp
  have h : env41171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41170_41171 : H12AffineEnvironment.transform 3 10 env41170 = env41171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41170 == env41171) = true)

theorem identity41171 : scanCanonicalize (H12AffineFastState.compose env41171 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound41171 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41172 : List Nat := [2,4,8,10,32,32,128,36,42,47,42,1,40,1,0,35,42,162,5,1,1,131,10,41,139,10,1,0,0,0,36,32,37,10,43,0]

theorem envBound41172 : H12AffineFastState.Bounded env41172 := by
  intro p hp
  have h : env41172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41171_41172 : H12AffineEnvironment.transform 5 32 env41171 = env41172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env41171 == env41172) = true)

def env41173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70887,78894,77841,1297,74814,81226,365712,308667,257,74798,1344,79470]

theorem envBound41173 : H12AffineFastState.Bounded env41173 := by
  intro p hp
  have h : env41173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41126_41173 : H12AffineEnvironment.transform 13 1297 env41126 = env41173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41126 == env41173) = true)

theorem identity41173 : scanCanonicalize (H12AffineFastState.compose env41173 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound41173 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,16,266385,38036,46173,45154,1297,42061,48441,267491,308667,257,42077,1344,46621]

theorem envBound41174 : H12AffineFastState.Bounded env41174 := by
  intro p hp
  have h : env41174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41173_41174 : H12AffineEnvironment.transform 15 32883 env41173 = env41174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env41173 == env41174) = true)

def env41175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263633,33236,41245,42274,1297,42061,43129,262563,303355,257,42077,1344,41821]

theorem envBound41175 : H12AffineFastState.Bounded env41175 := by
  intro p hp
  have h : env41175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41174_41175 : H12AffineEnvironment.transform 11 1344 env41174 = env41175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env41174 == env41175) = true)

theorem identity41175 : scanCanonicalize (H12AffineFastState.compose env41175 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound41175 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1297,32768,32883,1344,262144,34117,32769,1344,32920,16,263633,33236,33029,34106,1297,33877,34913,262563,295139,257,33861,1344,33605]

theorem envBound41176 : H12AffineFastState.Bounded env41176 := by
  intro p hp
  have h : env41176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41175_41176 : H12AffineEnvironment.transform 12 24 env41175 = env41176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env41175 == env41176) = true)

theorem identity41176 : scanCanonicalize (H12AffineFastState.compose env41176 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound41176 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env41177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1344,24,1297,32768,32883,1344,262144,34117,32769,1344,32920,16,263633,33236,33029,34106,1297,33877,34618,262563,295139,257,33861,1344,33605]

theorem envBound41177 : H12AffineFastState.Bounded env41177 := by
  intro p hp
  have h : env41177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41176_41177 : H12AffineEnvironment.transform 10 1883 env41176 = env41177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env41176 == env41177) = true)

def env41178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263632,33237,41244,42275,1297,42061,43128,262562,303354,257,42077,1344,41820]

theorem envBound41178 : H12AffineFastState.Bounded env41178 := by
  intro p hp
  have h : env41178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41174_41178 : H12AffineEnvironment.transform 11 1345 env41174 = env41178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env41174 == env41178) = true)

theorem identity41178 : scanCanonicalize (H12AffineFastState.compose env41178 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound41178 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,41194,42332,32769,1345,41089,16,42298,33237,41244,42275,1297,42061,43128,41288,16,257,42077,1344,41820]

theorem envBound41179 : H12AffineFastState.Bounded env41179 := by
  intro p hp
  have h : env41179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41178_41179 : H12AffineEnvironment.transform 17 41194 env41178 = env41179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env41178 == env41179) = true)

theorem identity41179 : scanCanonicalize (H12AffineFastState.compose env41179 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41179 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1344,438,1024,8541,1345,477,16,1126,8329,64,1151,1297,1297,2340,20,16,257,1281,1344,512]

theorem envBound41180 : H12AffineFastState.Bounded env41180 := by
  intro p hp
  have h : env41180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41179_41180 : H12AffineEnvironment.transform 14 8540 env41179 = env41180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41179 == env41180) = true)

theorem identity41180 : scanCanonicalize (H12AffineFastState.compose env41180 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound41180 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41181 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,325,8540,8495,276,438,84,8541,277,477,16,50,8329,64,43,325,325,2340,20,16,257,341,276,512]

theorem envBound41181 : H12AffineFastState.Bounded env41181 := by
  intro p hp
  have h : env41181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41180_41181 : H12AffineEnvironment.transform 9 84 env41180 = env41181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env41180 == env41181) = true)

theorem identity41181 : scanCanonicalize (H12AffineFastState.compose env41181 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound41181 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41182 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,980,325,648,763,276,438,84,649,277,477,16,50,861,64,43,325,325,2340,20,16,257,341,276,512]

theorem envBound41182 : H12AffineFastState.Bounded env41182 := by
  intro p hp
  have h : env41182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41181_41182 : H12AffineEnvironment.transform 12 980 env41181 = env41182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env41181 == env41182) = true)

theorem identity41182 : scanCanonicalize (H12AffineFastState.compose env41182 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41182 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41183 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,901,276,648,682,276,438,5,649,277,396,16,50,780,17,43,276,276,2340,20,16,257,260,276,512]

theorem envBound41183 : H12AffineFastState.Bounded env41183 := by
  intro p hp
  have h : env41183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41182_41183 : H12AffineEnvironment.transform 5 17 env41182 = env41183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41182 == env41183) = true)

theorem identity41183 : scanCanonicalize (H12AffineFastState.compose env41183 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound41183 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41184 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,553,184,648,682,184,26,5,649,185,32,16,50,672,17,43,184,184,2184,20,16,173,168,184,512]

theorem envBound41184 : H12AffineFastState.Bounded env41184 := by
  intro p hp
  have h : env41184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41183_41184 : H12AffineEnvironment.transform 7 172 env41183 = env41184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env41183 == env41184) = true)

theorem identity41184 : scanCanonicalize (H12AffineFastState.compose env41184 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41184 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41185 : List Nat := [2,4,8,11,32,10,128,172,512,5,2048,162,553,163,648,682,163,1,5,649,162,32,11,41,672,10,43,163,163,2184,15,11,173,168,163,512]

theorem envBound41185 : H12AffineFastState.Bounded env41185 := by
  intro p hp
  have h : env41185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41184_41185 : H12AffineEnvironment.transform 3 11 env41184 = env41185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41184 == env41185) = true)

theorem identity41185 : scanCanonicalize (H12AffineFastState.compose env41185 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41185 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41186 : List Nat := [2,4,8,11,32,10,8,36,512,5,2048,42,553,43,512,546,43,1,5,513,42,32,11,41,552,10,43,43,43,2048,15,11,37,32,43,512]

theorem envBound41186 : H12AffineFastState.Bounded env41186 := by
  intro p hp
  have h : env41186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41185_41186 : H12AffineEnvironment.transform 6 8 env41185 = env41186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41185 == env41186) = true)

def env41187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86518,209262,225345,148800,74814,96347,381312,323755,257,74798,1344,95103]

theorem envBound41187 : H12AffineFastState.Bounded env41187 := by
  intro p hp
  have h : env41187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41066_41187 : H12AffineEnvironment.transform 23 284033 env41066 = env41187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env41066 == env41187) = true)

def env41188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86518,94526,77841,1296,74814,96347,381312,323755,257,74798,1344,95103]

theorem envBound41188 : H12AffineFastState.Bounded env41188 := by
  intro p hp
  have h : env41188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41187_41188 : H12AffineEnvironment.transform 16 16464 env41187 = env41188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env41187 == env41188) = true)

def env41189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70886,78894,77841,1296,74814,81227,365712,308667,257,74798,1344,79471]

theorem envBound41189 : H12AffineFastState.Bounded env41189 := by
  intro p hp
  have h : env41189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41188_41189 : H12AffineEnvironment.transform 13 1296 env41188 = env41189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41188 == env41189) = true)

theorem identity41189 : scanCanonicalize (H12AffineFastState.compose env41189 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound41189 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,17,266385,38036,46172,45155,1296,42060,48441,267490,308667,257,42076,1344,46621]

theorem envBound41190 : H12AffineFastState.Bounded env41190 := by
  intro p hp
  have h : env41190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41189_41190 : H12AffineEnvironment.transform 15 32882 env41189 = env41190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env41189 == env41190) = true)

def env41191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263633,33236,41244,42275,1296,42060,43129,262562,303355,257,42076,1344,41821]

theorem envBound41191 : H12AffineFastState.Bounded env41191 := by
  intro p hp
  have h : env41191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41190_41191 : H12AffineEnvironment.transform 11 1344 env41190 = env41191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env41190 == env41191) = true)

theorem identity41191 : scanCanonicalize (H12AffineFastState.compose env41191 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41191 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41192 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,32768,32882,80,262144,41037,32769,80,41089,17,262337,33236,41244,41011,0,41308,43129,262562,303355,257,41292,80,41821]

theorem envBound41192 : H12AffineFastState.Bounded env41192 := by
  intro p hp
  have h : env41192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41191_41192 : H12AffineEnvironment.transform 9 272 env41191 = env41192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41191 == env41192) = true)

theorem identity41192 : scanCanonicalize (H12AffineFastState.compose env41192 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41192 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41193 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8495,80,262144,272,8540,80,476,17,262337,8329,65,366,0,1,2340,262562,262566,257,17,80,512]

theorem envBound41193 : H12AffineFastState.Bounded env41193 := by
  intro p hp
  have h : env41193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41192_41193 : H12AffineEnvironment.transform 14 8541 env41192 = env41193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41192 == env41193) = true)

theorem identity41193 : scanCanonicalize (H12AffineFastState.compose env41193 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41193 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41194 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,80,8192,0,8217,8299,80,262144,84,8216,80,152,17,262337,8329,65,42,0,1,2144,262374,262370,69,17,80,512]

theorem envBound41194 : H12AffineFastState.Bounded env41194 := by
  intro p hp
  have h : env41194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41193_41194 : H12AffineEnvironment.transform 7 68 env41193 = env41194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41193 == env41194) = true)

theorem identity41194 : scanCanonicalize (H12AffineFastState.compose env41194 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound41194 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41195 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,80,657,0,648,762,80,262144,84,649,80,152,17,262337,536,65,42,0,1,2144,262374,262370,69,17,80,512]

theorem envBound41195 : H12AffineFastState.Bounded env41195 := by
  intro p hp
  have h : env41195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41194_41195 : H12AffineEnvironment.transform 12 657 env41194 = env41195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env41194 == env41195) = true)

theorem identity41195 : scanCanonicalize (H12AffineFastState.compose env41195 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41195 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41196 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,657,0,648,683,1,262144,5,649,1,152,17,262288,536,16,42,0,1,2097,262327,262323,20,17,1,512]

theorem envBound41196 : H12AffineFastState.Bounded env41196 := by
  intro p hp
  have h : env41196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41195_41196 : H12AffineEnvironment.transform 5 17 env41195 = env41196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41195 == env41196) = true)

def env41197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263632,33237,41245,42274,1296,42060,43128,262563,303354,257,42076,1344,41820]

theorem envBound41197 : H12AffineFastState.Bounded env41197 := by
  intro p hp
  have h : env41197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41190_41197 : H12AffineEnvironment.transform 11 1345 env41190 = env41197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env41190 == env41197) = true)

theorem identity41197 : scanCanonicalize (H12AffineFastState.compose env41197 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34275) := by decide +kernel

theorem selectedBound41197 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,34275,42332,32769,1345,41088,17,32819,33237,41245,42274,1296,42060,43128,33856,9497,257,42076,1344,41820]

theorem envBound41198 : H12AffineFastState.Bounded env41198 := by
  intro p hp
  have h : env41198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41197_41198 : H12AffineEnvironment.transform 17 34275 env41197 = env41198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34275 env41197 == env41198) = true)

theorem identity41198 : scanCanonicalize (H12AffineFastState.compose env41198 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound41198 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env41199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1345,8192,1296,32768,32882,1344,34275,42332,32769,1345,41088,17,32819,33237,41245,42274,1296,42060,42787,33856,9497,257,42076,1344,41820]

theorem envBound41199 : H12AffineFastState.Bounded env41199 := by
  intro p hp
  have h : env41199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41198_41199 : H12AffineEnvironment.transform 10 1883 env41198 = env41199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env41198 == env41199) = true)

def env41200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70887,78895,77841,1296,74814,81226,365713,308666,257,74798,1344,79470]

theorem envBound41200 : H12AffineFastState.Bounded env41200 := by
  intro p hp
  have h : env41200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41188_41200 : H12AffineEnvironment.transform 13 1297 env41188 = env41200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41188 == env41200) = true)

theorem identity41200 : scanCanonicalize (H12AffineFastState.compose env41200 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound41200 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,17,266384,70887,78895,77841,1296,74814,81226,336013,262566,257,74798,1344,79470]

theorem envBound41201 : H12AffineFastState.Bounded env41201 := by
  intro p hp
  have h : env41201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41200_41201 : H12AffineEnvironment.transform 14 13340 env41200 = env41201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41200 == env41201) = true)

def env41202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,17,69648,70887,78895,77841,1296,74814,81226,8205,65830,257,74798,1344,79470]

theorem envBound41202 : H12AffineFastState.Bounded env41202 := by
  intro p hp
  have h : env41202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41201_41202 : H12AffineEnvironment.transform 17 65664 env41201 = env41202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41201 == env41202) = true)

theorem identity41202 : scanCanonicalize (H12AffineFastState.compose env41202 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound41202 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,65536,1345,65664,69750,5125,4096,476,17,69648,70887,70711,69641,1296,66598,73042,21,65830,257,66614,1344,71286]

theorem envBound41203 : H12AffineFastState.Bounded env41203 := by
  intro p hp
  have h : env41203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41202_41203 : H12AffineEnvironment.transform 12 24 env41202 = env41203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env41202 == env41203) = true)

def env41204 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,65536,1297,65664,69670,5125,4096,396,17,69648,70839,70711,69641,1296,66598,72962,21,65830,257,66614,1296,71206]

theorem envBound41204 : H12AffineFastState.Bounded env41204 := by
  intro p hp
  have h : env41204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41203_41204 : H12AffineEnvironment.transform 5 16 env41203 = env41204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41203 == env41204) = true)

theorem identity41204 : scanCanonicalize (H12AffineFastState.compose env41204 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41204 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41205 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,24,276,4097,65536,276,65664,69670,4096,4096,396,17,69648,69810,69682,69641,277,65571,71943,21,65830,257,65587,277,70179]

theorem envBound41205 : H12AffineFastState.Bounded env41205 := by
  intro p hp
  have h : env41205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41204_41205 : H12AffineEnvironment.transform 9 5 env41204 = env41205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41204 == env41205) = true)

theorem identity41205 : scanCanonicalize (H12AffineFastState.compose env41205 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound41205 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41206 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,24,276,4097,311,276,439,4369,4096,4096,396,17,4391,4485,4357,4414,277,276,6192,21,17,257,260,277,4884]

theorem envBound41206 : H12AffineFastState.Bounded env41206 := by
  intro p hp
  have h : env41206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41205_41206 : H12AffineEnvironment.transform 15 311 env41205 = env41206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env41205 == env41206) = true)

theorem identity41206 : scanCanonicalize (H12AffineFastState.compose env41206 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound41206 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41207 : List Nat := [2,4,8,16,32,16,128,256,512,5,555,4096,24,276,4097,311,276,439,4369,4096,4096,396,17,4391,4485,4357,4414,277,276,4635,21,17,257,260,277,4884]

theorem envBound41207 : H12AffineFastState.Bounded env41207 := by
  intro p hp
  have h : env41207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41206_41207 : H12AffineEnvironment.transform 10 555 env41206 = env41207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env41206 == env41207) = true)

theorem identity41207 : scanCanonicalize (H12AffineFastState.compose env41207 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41207 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env41208 : List Nat := [2,4,8,16,11,16,128,256,512,5,512,4096,24,276,4097,284,276,412,4369,4096,4096,396,17,4364,4485,4357,4373,277,276,4635,21,17,257,260,277,4884]

theorem envBound41208 : H12AffineFastState.Bounded env41208 := by
  intro p hp
  have h : env41208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41207_41208 : H12AffineEnvironment.transform 4 11 env41207 = env41208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41207 == env41208) = true)

theorem identity41208 : scanCanonicalize (H12AffineFastState.compose env41208 (packedSelected [10,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 413) := by decide +kernel

theorem selectedBound41208 : packedSelected [10,13,15] rootPS < 2^1333 := by decide +kernel

def env41209 : List Nat := [2,4,8,16,11,16,128,256,512,5,512,413,24,276,412,284,276,412,140,413,413,396,17,145,24,152,136,277,276,902,21,17,257,260,277,649]

theorem envBound41209 : H12AffineFastState.Bounded env41209 := by
  intro p hp
  have h : env41209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41208_41209 : H12AffineEnvironment.transform 11 413 env41208 = env41209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 413 env41208 == env41209) = true)

theorem identity41209 : scanCanonicalize (H12AffineFastState.compose env41209 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41209 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41210 : List Nat := [2,4,8,16,11,16,8,256,512,5,512,277,24,276,276,284,276,276,4,277,277,260,17,25,24,16,0,277,276,782,21,17,257,260,277,513]

theorem envBound41210 : H12AffineFastState.Bounded env41210 := by
  intro p hp
  have h : env41210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41209_41210 : H12AffineEnvironment.transform 6 8 env41209 = env41210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41209 == env41210) = true)

theorem identity41210 : scanCanonicalize (H12AffineFastState.compose env41210 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41211 : List Nat := [2,4,8,16,11,16,8,256,1,5,1,277,24,276,276,284,276,276,4,277,277,260,17,25,24,16,0,277,276,271,21,17,257,260,277,0]

theorem envBound41211 : H12AffineFastState.Bounded env41211 := by
  intro p hp
  have h : env41211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41210_41211 : H12AffineEnvironment.transform 8 1 env41210 = env41211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41210 == env41211) = true)

theorem identity41211 : scanCanonicalize (H12AffineFastState.compose env41211 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41211 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41212 : List Nat := [2,4,1,16,2,16,1,256,1,5,1,277,17,276,276,277,276,276,4,277,277,260,17,16,17,16,0,277,276,262,21,17,257,260,277,0]

theorem envBound41212 : H12AffineFastState.Bounded env41212 := by
  intro p hp
  have h : env41212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41211_41212 : H12AffineEnvironment.transform 2 1 env41211 = env41212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41211 == env41212) = true)

theorem identity41212 : scanCanonicalize (H12AffineFastState.compose env41212 (packedSelected [4,5] rootPS)) = affineNative (2^(7+1) ^^^ 23) := by decide +kernel

theorem selectedBound41212 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env41213 : List Nat := [2,4,1,16,2,16,1,23,1,5,1,2,17,3,3,2,3,3,4,2,2,19,17,16,17,16,0,2,3,17,21,17,22,19,2,0]

theorem envBound41213 : H12AffineFastState.Bounded env41213 := by
  intro p hp
  have h : env41213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41212_41213 : H12AffineEnvironment.transform 7 23 env41212 = env41213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 23 env41212 == env41213) = true)

theorem identity41213 : scanCanonicalize (H12AffineFastState.compose env41213 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41213 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41214 : List Nat := [2,3,1,16,2,16,1,16,1,2,1,2,17,3,3,2,3,3,3,2,2,19,17,16,17,16,0,2,3,17,18,17,17,19,2,0]

theorem envBound41214 : H12AffineFastState.Bounded env41214 := by
  intro p hp
  have h : env41214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41213_41214 : H12AffineEnvironment.transform 1 3 env41213 = env41214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41213 == env41214) = true)

theorem identity41214 : scanCanonicalize (H12AffineFastState.compose env41214 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound41214 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env41215 : List Nat := [2,3,1,3,2,3,1,3,1,2,1,2,2,3,3,2,3,3,3,2,2,0,2,3,2,3,0,2,3,2,1,2,2,0,2,0]

theorem envBound41215 : H12AffineFastState.Bounded env41215 := by
  intro p hp
  have h : env41215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41214_41215 : H12AffineEnvironment.transform 3 3 env41214 = env41215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env41214 == env41215) = true)

theorem identity41215 : scanCanonicalize (H12AffineFastState.compose env41215 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41216 : List Nat := [0,1,1,1,0,1,1,1,1,0,1,0,0,1,1,0,1,1,1,0,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,0]

theorem envBound41216 : H12AffineFastState.Bounded env41216 := by
  intro p hp
  have h : env41216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41215_41216 : H12AffineEnvironment.transform 0 0 env41215 = env41216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41215 == env41216) = true)

def env41217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,65536,1296,65664,69671,5125,4096,397,17,69648,70838,70711,69641,1296,66598,72963,21,65830,257,66614,1297,71207]

theorem envBound41217 : H12AffineFastState.Bounded env41217 := by
  intro p hp
  have h : env41217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41203_41217 : H12AffineEnvironment.transform 5 17 env41203 = env41217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41203 == env41217) = true)

theorem identity41217 : scanCanonicalize (H12AffineFastState.compose env41217 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound41217 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,4131,1296,4259,4,5125,4096,397,17,51,1173,1044,42,1296,5125,3360,21,4357,257,5141,1297,1540]

theorem envBound41218 : H12AffineFastState.Bounded env41218 := by
  intro p hp
  have h : env41218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41217_41218 : H12AffineEnvironment.transform 15 4131 env41217 = env41218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env41217 == env41218) = true)

theorem identity41218 : scanCanonicalize (H12AffineFastState.compose env41218 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound41218 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,24,1297,1297,310,1296,438,4,1296,277,397,17,51,1173,1044,42,1296,1296,3360,21,16,257,1280,1297,1540]

theorem envBound41219 : H12AffineFastState.Bounded env41219 := by
  intro p hp
  have h : env41219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41218_41219 : H12AffineEnvironment.transform 11 277 env41218 = env41219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env41218 == env41219) = true)

theorem identity41219 : scanCanonicalize (H12AffineFastState.compose env41219 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41219 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41220 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,277,24,1297,1297,262,1296,390,4,1296,277,397,17,3,1173,1044,26,1296,1296,3344,21,16,257,1280,1297,1540]

theorem envBound41220 : H12AffineFastState.Bounded env41220 := by
  intro p hp
  have h : env41220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41219_41220 : H12AffineEnvironment.transform 4 16 env41219 = env41220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41219 == env41220) = true)

theorem identity41220 : scanCanonicalize (H12AffineFastState.compose env41220 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound41220 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41221 : List Nat := [2,4,8,16,16,17,128,256,512,1024,789,277,24,1297,1297,262,1296,390,4,1296,277,397,17,3,1173,1044,26,1296,1296,1541,21,16,257,1280,1297,1540]

theorem envBound41221 : H12AffineFastState.Bounded env41221 := by
  intro p hp
  have h : env41221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41220_41221 : H12AffineEnvironment.transform 10 789 env41220 = env41221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env41220 == env41221) = true)

theorem identity41221 : scanCanonicalize (H12AffineFastState.compose env41221 (packedSelected [3,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound41221 : packedSelected [3,8,12,15] rootPS < 2^1333 := by decide +kernel

def env41222 : List Nat := [2,4,8,16,16,17,128,256,512,267,789,277,24,26,26,262,27,390,4,27,277,397,17,3,414,287,26,27,27,782,21,16,257,11,26,783]

theorem envBound41222 : H12AffineFastState.Bounded env41222 := by
  intro p hp
  have h : env41222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41221_41222 : H12AffineEnvironment.transform 9 267 env41221 = env41222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env41221 == env41222) = true)

theorem identity41222 : scanCanonicalize (H12AffineFastState.compose env41222 (packedSelected [0,2,5,7,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound41222 : packedSelected [0,2,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env41223 : List Nat := [2,4,8,16,16,17,128,256,27,267,270,277,24,26,26,262,27,390,4,27,277,397,17,3,414,287,26,27,27,277,21,16,257,11,26,276]

theorem envBound41223 : H12AffineFastState.Bounded env41223 := by
  intro p hp
  have h : env41223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41222_41223 : H12AffineEnvironment.transform 8 27 env41222 = env41223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env41222 == env41223) = true)

theorem identity41223 : scanCanonicalize (H12AffineFastState.compose env41223 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound41223 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41224 : List Nat := [2,4,8,16,16,17,128,134,27,141,136,147,24,26,26,128,27,0,4,27,147,11,17,3,24,153,26,27,27,147,21,16,135,11,26,146]

theorem envBound41224 : H12AffineFastState.Bounded env41224 := by
  intro p hp
  have h : env41224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41223_41224 : H12AffineEnvironment.transform 7 134 env41223 = env41224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env41223 == env41224) = true)

theorem identity41224 : scanCanonicalize (H12AffineFastState.compose env41224 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41225 : List Nat := [2,4,8,16,16,17,18,20,27,31,26,1,24,26,26,18,27,0,4,27,1,11,17,3,24,11,26,27,27,1,21,16,21,11,26,0]

theorem envBound41225 : H12AffineFastState.Bounded env41225 := by
  intro p hp
  have h : env41225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41224_41225 : H12AffineEnvironment.transform 6 18 env41224 = env41225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41224 == env41225) = true)

def env41226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,17,69649,70887,78895,77841,1296,74814,81226,8204,65831,257,74798,1344,79470]

theorem envBound41226 : H12AffineFastState.Bounded env41226 := by
  intro p hp
  have h : env41226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41201_41226 : H12AffineEnvironment.transform 17 65665 env41201 = env41226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41201 == env41226) = true)

theorem identity41226 : scanCanonicalize (H12AffineFastState.compose env41226 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound41226 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,1345,65665,66871,324,4096,476,17,69649,70887,65910,66888,1296,69991,67603,5461,65831,257,70007,1344,66359]

theorem envBound41227 : H12AffineFastState.Bounded env41227 := by
  intro p hp
  have h : env41227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41226_41227 : H12AffineEnvironment.transform 12 5465 env41226 = env41227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env41226 == env41227) = true)

def env41228 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65665,66871,276,4096,396,17,69649,70839,65830,66840,1296,69943,67603,5381,65831,257,69927,1296,66359]

theorem envBound41228 : H12AffineFastState.Bounded env41228 := by
  intro p hp
  have h : env41228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41227_41228 : H12AffineEnvironment.transform 5 16 env41227 = env41228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41227 == env41228) = true)

theorem identity41228 : scanCanonicalize (H12AffineFastState.compose env41228 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41228 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41229 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4364,276,277,65536,276,65665,65842,276,4096,396,17,69649,69810,65830,65821,277,69943,67603,4352,65831,257,69927,277,66359]

theorem envBound41229 : H12AffineFastState.Bounded env41229 := by
  intro p hp
  have h : env41229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41228_41229 : H12AffineEnvironment.transform 9 5 env41228 = env41229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41228 == env41229) = true)

theorem identity41229 : scanCanonicalize (H12AffineFastState.compose env41229 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound41229 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41230 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,24,276,277,65536,276,65665,65842,276,276,396,17,65797,65958,65830,65821,277,65571,67603,20,65831,257,65587,277,66359]

theorem envBound41230 : H12AffineFastState.Bounded env41230 := by
  intro p hp
  have h : env41230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41229_41230 : H12AffineEnvironment.transform 11 276 env41229 = env41230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env41229 == env41230) = true)

theorem identity41230 : scanCanonicalize (H12AffineFastState.compose env41230 (packedSelected [0,1,2,3,5,7,8,18] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound41230 : packedSelected [0,1,2,3,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env41231 : List Nat := [2,4,8,16,32,16,128,256,48,5,2048,276,24,276,277,65536,276,65665,65842,276,276,396,17,65797,65958,65830,65821,277,65571,67603,20,65831,257,65587,277,65799]

theorem envBound41231 : H12AffineFastState.Bounded env41231 := by
  intro p hp
  have h : env41231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41230_41231 : H12AffineEnvironment.transform 8 48 env41230 = env41231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env41230 == env41231) = true)

theorem identity41231 : scanCanonicalize (H12AffineFastState.compose env41231 (packedSelected [0,1,2,7,8,10,11,12,13,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound41231 : packedSelected [0,1,2,7,8,10,11,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env41232 : List Nat := [2,4,8,16,32,16,128,256,48,5,2048,276,24,276,277,34,276,163,272,276,276,396,17,295,388,260,319,277,1,2097,20,261,257,17,277,293]

theorem envBound41232 : H12AffineFastState.Bounded env41232 := by
  intro p hp
  have h : env41232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41231_41232 : H12AffineEnvironment.transform 15 34 env41231 = env41232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env41231 == env41232) = true)

theorem identity41232 : scanCanonicalize (H12AffineFastState.compose env41232 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound41232 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41233 : List Nat := [2,4,8,16,32,16,128,63,48,5,2048,43,24,43,42,34,43,163,47,43,43,179,17,24,187,59,0,42,1,2097,20,58,62,17,42,26]

theorem envBound41233 : H12AffineFastState.Bounded env41233 := by
  intro p hp
  have h : env41233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41232_41233 : H12AffineEnvironment.transform 7 63 env41232 = env41233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env41232 == env41233) = true)

theorem identity41233 : scanCanonicalize (H12AffineFastState.compose env41233 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound41233 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41234 : List Nat := [2,4,8,16,32,16,128,63,48,5,49,43,24,43,42,34,43,163,47,43,43,179,17,24,187,59,0,42,1,0,20,58,62,17,42,26]

theorem envBound41234 : H12AffineFastState.Bounded env41234 := by
  intro p hp
  have h : env41234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41233_41234 : H12AffineEnvironment.transform 10 49 env41233 = env41234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env41233 == env41234) = true)

theorem identity41234 : scanCanonicalize (H12AffineFastState.compose env41234 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41234 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env41235 : List Nat := [2,4,8,16,23,16,128,8,7,5,6,28,24,28,29,21,28,148,24,28,28,132,17,24,140,12,0,29,1,0,20,13,9,17,29,26]

theorem envBound41235 : H12AffineFastState.Bounded env41235 := by
  intro p hp
  have h : env41235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41234_41235 : H12AffineEnvironment.transform 4 23 env41234 = env41235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41234 == env41235) = true)

theorem identity41235 : scanCanonicalize (H12AffineFastState.compose env41235 (packedSelected [0,1,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41235 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env41236 : List Nat := [2,4,8,16,23,16,18,8,7,5,6,28,24,28,29,21,28,6,24,28,28,22,17,24,30,12,0,29,1,0,20,13,9,17,29,26]

theorem envBound41236 : H12AffineFastState.Bounded env41236 := by
  intro p hp
  have h : env41236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41235_41236 : H12AffineEnvironment.transform 6 18 env41235 = env41236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41235 == env41236) = true)

theorem identity41236 : scanCanonicalize (H12AffineFastState.compose env41236 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41237 : List Nat := [2,2,8,16,17,16,18,8,1,3,0,26,24,26,27,19,26,0,24,26,26,16,17,24,24,10,0,27,1,0,18,11,9,17,27,26]

theorem envBound41237 : H12AffineFastState.Bounded env41237 := by
  intro p hp
  have h : env41237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41236_41237 : H12AffineEnvironment.transform 1 2 env41236 = env41237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41236 == env41237) = true)

def env41238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65665,66871,277,4096,397,17,69649,70838,65831,66841,1296,69942,67603,5380,65831,257,69926,1297,66359]

theorem envBound41238 : H12AffineFastState.Bounded env41238 := by
  intro p hp
  have h : env41238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41227_41238 : H12AffineEnvironment.transform 5 17 env41227 = env41238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41227 == env41238) = true)

theorem identity41238 : scanCanonicalize (H12AffineFastState.compose env41238 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound41238 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,1331,1296,1458,4,277,4096,397,17,5410,4485,1044,42,1296,5125,3360,5380,1044,257,5141,1297,1540]

theorem envBound41239 : H12AffineFastState.Bounded env41239 := by
  intro p hp
  have h : env41239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41238_41239 : H12AffineEnvironment.transform 15 1331 env41238 = env41239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env41238 == env41239) = true)

theorem identity41239 : scanCanonicalize (H12AffineFastState.compose env41239 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound41239 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41240 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,25,1297,276,1331,1296,1458,4,277,1297,397,17,51,1172,1044,42,1296,276,3360,21,1044,257,260,1297,1540]

theorem envBound41240 : H12AffineFastState.Bounded env41240 := by
  intro p hp
  have h : env41240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41239_41240 : H12AffineEnvironment.transform 11 1297 env41239 = env41240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env41239 == env41240) = true)

theorem identity41240 : scanCanonicalize (H12AffineFastState.compose env41240 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound41240 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41241 : List Nat := [2,4,8,16,32,17,128,256,512,1024,439,1297,25,1297,276,1331,1296,1458,4,277,1297,397,17,51,1172,1044,42,1296,276,1175,21,1044,257,260,1297,1540]

theorem envBound41241 : H12AffineFastState.Bounded env41241 := by
  intro p hp
  have h : env41241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41240_41241 : H12AffineEnvironment.transform 10 439 env41240 = env41241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env41240 == env41241) = true)

theorem identity41241 : scanCanonicalize (H12AffineFastState.compose env41241 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41241 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41242 : List Nat := [2,4,8,16,32,17,8,256,512,1024,319,1297,25,1297,276,1331,1296,1338,4,277,1297,261,17,51,1052,1044,42,1296,276,1055,21,1044,257,260,1297,1540]

theorem envBound41242 : H12AffineFastState.Bounded env41242 := by
  intro p hp
  have h : env41242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41241_41242 : H12AffineEnvironment.transform 6 8 env41241 = env41242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41241 == env41242) = true)

theorem identity41242 : scanCanonicalize (H12AffineFastState.compose env41242 (packedSelected [0,1,2,5,9,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41242 : packedSelected [0,1,2,5,9,12] rootPS < 2^1333 := by decide +kernel

def env41243 : List Nat := [2,4,8,16,17,17,8,256,512,1024,270,1297,25,1297,276,1282,1296,1291,4,277,1297,261,17,2,1052,1044,27,1296,276,1055,21,1044,257,260,1297,1540]

theorem envBound41243 : H12AffineFastState.Bounded env41243 := by
  intro p hp
  have h : env41243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41242_41243 : H12AffineEnvironment.transform 4 17 env41242 = env41243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41242 == env41243) = true)

theorem identity41243 : scanCanonicalize (H12AffineFastState.compose env41243 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound41243 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41244 : List Nat := [2,4,8,16,17,17,8,256,27,1024,270,1297,25,1297,276,1282,1296,1291,4,277,1297,261,17,2,1052,1044,27,1296,276,1055,21,1044,257,260,1297,1055]

theorem envBound41244 : H12AffineFastState.Bounded env41244 := by
  intro p hp
  have h : env41244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41243_41244 : H12AffineEnvironment.transform 8 27 env41243 = env41244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env41243 == env41244) = true)

theorem identity41244 : scanCanonicalize (H12AffineFastState.compose env41244 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound41244 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41245 : List Nat := [2,4,8,16,17,17,8,256,27,31,270,270,25,270,276,285,271,276,4,277,270,261,17,2,3,11,27,271,276,0,21,11,257,260,270,0]

theorem envBound41245 : H12AffineFastState.Bounded env41245 := by
  intro p hp
  have h : env41245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41244_41245 : H12AffineEnvironment.transform 9 31 env41244 = env41245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env41244 == env41245) = true)

theorem identity41245 : scanCanonicalize (H12AffineFastState.compose env41245 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound41245 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41246 : List Nat := [2,4,8,16,17,17,8,14,27,31,0,0,25,0,26,19,1,26,4,27,0,11,17,2,3,11,27,1,26,0,21,11,15,10,0,0]

theorem envBound41246 : H12AffineFastState.Bounded env41246 := by
  intro p hp
  have h : env41246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41245_41246 : H12AffineEnvironment.transform 7 14 env41245 = env41246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env41245 == env41246) = true)

theorem identity41246 : scanCanonicalize (H12AffineFastState.compose env41246 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound41246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41247 : List Nat := [2,4,8,13,12,12,8,14,6,2,0,0,4,0,7,14,1,7,4,6,0,11,12,2,3,11,6,1,7,0,8,11,15,10,0,0]

theorem envBound41247 : H12AffineFastState.Bounded env41247 := by
  intro p hp
  have h : env41247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41246_41247 : H12AffineEnvironment.transform 3 13 env41246 = env41247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env41246 == env41247) = true)

theorem identity41247 : scanCanonicalize (H12AffineFastState.compose env41247 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41247 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41248 : List Nat := [2,2,8,11,10,10,8,8,0,2,0,0,2,0,1,8,1,1,2,0,0,11,10,2,3,11,0,1,1,0,8,11,9,10,0,0]

theorem envBound41248 : H12AffineFastState.Bounded env41248 := by
  intro p hp
  have h : env41248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41247_41248 : H12AffineEnvironment.transform 1 2 env41247 = env41248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41247 == env41248) = true)

def env41249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86518,94527,77840,1297,74814,96347,381312,323755,257,74798,1344,95103]

theorem envBound41249 : H12AffineFastState.Bounded env41249 := by
  intro p hp
  have h : env41249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41187_41249 : H12AffineEnvironment.transform 16 16465 env41187 = env41249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env41187 == env41249) = true)

def env41250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70886,78895,77840,1297,74814,81227,365712,308667,257,74798,1344,79471]

theorem envBound41250 : H12AffineFastState.Bounded env41250 := by
  intro p hp
  have h : env41250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41249_41250 : H12AffineEnvironment.transform 13 1296 env41249 = env41250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41249 == env41250) = true)

theorem identity41250 : scanCanonicalize (H12AffineFastState.compose env41250 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

end H12CloudChart2