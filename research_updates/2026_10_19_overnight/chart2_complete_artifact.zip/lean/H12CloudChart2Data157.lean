import H12CloudChart2Data156

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env39186 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,499,80,190,65536,65757,65665,337,191,16,476,65741,65537,363,65676,303,65676,81,68072,510,65831,257,65,0,325]

theorem envBound39186 : H12AffineFastState.Bounded env39186 := by
  intro p hp
  have h : env39186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39185_39186 : H12AffineEnvironment.transform 12 499 env39185 = env39186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 499 env39185 == env39186) = true)

def env39187 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,483,64,174,65536,65741,65665,321,175,0,460,65741,65537,363,65676,303,65676,65,68072,494,65831,257,65,0,325]

theorem envBound39187 : H12AffineFastState.Bounded env39187 := by
  intro p hp
  have h : env39187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39186_39187 : H12AffineEnvironment.transform 3 0 env39186 = env39187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39186 == env39187) = true)

theorem identity39187 : scanCanonicalize (H12AffineFastState.compose env39187 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39187 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39188 : List Nat := [2,4,8,0,32,64,128,68,0,4,2048,0,167,64,174,65536,65741,65665,5,175,0,136,65741,65537,47,65676,107,65676,65,67756,170,65635,69,65,0,1]

theorem envBound39188 : H12AffineFastState.Bounded env39188 := by
  intro p hp
  have h : env39188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39187_39188 : H12AffineEnvironment.transform 7 68 env39187 = env39188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39187 == env39188) = true)

theorem identity39188 : scanCanonicalize (H12AffineFastState.compose env39188 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound39188 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39189 : List Nat := [2,4,8,0,32,64,128,68,0,4,2048,0,167,64,174,99,174,226,5,175,0,136,174,98,47,239,107,239,65,2255,170,0,69,65,0,1]

theorem envBound39189 : H12AffineFastState.Bounded env39189 := by
  intro p hp
  have h : env39189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39188_39189 : H12AffineEnvironment.transform 15 99 env39188 = env39189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env39188 == env39189) = true)

theorem identity39189 : scanCanonicalize (H12AffineFastState.compose env39189 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound39189 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39190 : List Nat := [2,4,8,0,32,64,110,68,0,4,2048,0,73,64,64,99,64,12,5,65,0,102,64,98,47,1,107,1,65,2081,68,0,69,65,0,1]

theorem envBound39190 : H12AffineFastState.Bounded env39190 := by
  intro p hp
  have h : env39190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39189_39190 : H12AffineEnvironment.transform 6 110 env39189 = env39190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env39189 == env39190) = true)

theorem identity39190 : scanCanonicalize (H12AffineFastState.compose env39190 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39190 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39191 : List Nat := [2,4,8,0,32,1,47,5,0,4,2048,0,8,1,1,34,1,12,5,0,0,39,1,35,47,1,42,1,0,2081,5,0,4,0,0,1]

theorem envBound39191 : H12AffineFastState.Bounded env39191 := by
  intro p hp
  have h : env39191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39190_39191 : H12AffineEnvironment.transform 5 1 env39190 = env39191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39190 == env39191) = true)

theorem identity39191 : scanCanonicalize (H12AffineFastState.compose env39191 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39192 : List Nat := [2,4,8,0,32,1,47,5,0,4,0,0,8,1,1,34,1,12,5,0,0,39,1,35,47,1,42,1,0,33,5,0,4,0,0,1]

theorem envBound39192 : H12AffineFastState.Bounded env39192 := by
  intro p hp
  have h : env39192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39191_39192 : H12AffineEnvironment.transform 10 0 env39191 = env39192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39191 == env39192) = true)

theorem identity39192 : scanCanonicalize (H12AffineFastState.compose env39192 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39193 : List Nat := [2,1,8,0,32,1,42,0,0,1,0,0,8,1,1,34,1,9,0,0,0,34,1,35,42,1,42,1,0,33,0,0,1,0,0,1]

theorem envBound39193 : H12AffineFastState.Bounded env39193 := by
  intro p hp
  have h : env39193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39192_39193 : H12AffineEnvironment.transform 1 1 env39192 = env39193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39192 == env39193) = true)

theorem identity39193 : scanCanonicalize (H12AffineFastState.compose env39193 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39194 : List Nat := [2,1,8,0,0,1,10,0,0,1,0,0,8,1,1,2,1,9,0,0,0,2,1,3,10,1,10,1,0,1,0,0,1,0,0,1]

theorem envBound39194 : H12AffineFastState.Bounded env39194 := by
  intro p hp
  have h : env39194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39193_39194 : H12AffineEnvironment.transform 4 0 env39193 = env39194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39193 == env39194) = true)

theorem identity39194 : scanCanonicalize (H12AffineFastState.compose env39194 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39194 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39195 : List Nat := [2,1,3,0,0,1,1,0,0,1,0,0,3,1,1,2,1,2,0,0,0,2,1,3,1,1,1,1,0,1,0,0,1,0,0,1]

theorem envBound39195 : H12AffineFastState.Bounded env39195 := by
  intro p hp
  have h : env39195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39194_39195 : H12AffineEnvironment.transform 2 3 env39194 = env39195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39194 == env39195) = true)

def env39196 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,482,65,175,65536,65740,65665,320,174,1,461,65741,65537,363,65676,303,65676,64,68072,495,65831,257,65,0,325]

theorem envBound39196 : H12AffineFastState.Bounded env39196 := by
  intro p hp
  have h : env39196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39186_39196 : H12AffineEnvironment.transform 3 1 env39186 = env39196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39186 == env39196) = true)

theorem identity39196 : scanCanonicalize (H12AffineFastState.compose env39196 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 456) := by decide +kernel

theorem selectedBound39196 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39197 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,482,65,175,456,260,329,320,174,1,461,261,457,363,324,303,324,64,2080,495,239,257,65,0,325]

theorem envBound39197 : H12AffineFastState.Bounded env39197 := by
  intro p hp
  have h : env39197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39196_39197 : H12AffineEnvironment.transform 15 456 env39196 = env39197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 456 env39196 == env39197) = true)

theorem identity39197 : scanCanonicalize (H12AffineFastState.compose env39197 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39197 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39198 : List Nat := [2,4,8,1,32,1,128,256,260,257,2048,1,419,0,175,393,260,264,257,174,1,396,261,392,298,261,303,261,1,2080,430,174,257,0,0,260]

theorem envBound39198 : H12AffineFastState.Bounded env39198 := by
  intro p hp
  have h : env39198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39197_39198 : H12AffineEnvironment.transform 5 1 env39197 = env39198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39197 == env39198) = true)

theorem identity39198 : scanCanonicalize (H12AffineFastState.compose env39198 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound39198 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env39199 : List Nat := [2,4,8,1,32,1,128,256,260,257,175,1,419,0,175,393,260,264,257,174,1,396,261,392,298,261,303,261,1,143,430,174,257,0,0,260]

theorem envBound39199 : H12AffineFastState.Bounded env39199 := by
  intro p hp
  have h : env39199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39198_39199 : H12AffineEnvironment.transform 10 175 env39198 = env39199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env39198 == env39199) = true)

theorem identity39199 : scanCanonicalize (H12AffineFastState.compose env39199 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound39199 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39200 : List Nat := [2,4,8,1,7,1,128,256,260,257,136,1,388,0,136,393,260,264,257,137,1,396,261,392,269,261,264,261,1,143,393,137,257,0,0,260]

theorem envBound39200 : H12AffineFastState.Bounded env39200 := by
  intro p hp
  have h : env39200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39199_39200 : H12AffineEnvironment.transform 4 7 env39199 = env39200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env39199 == env39200) = true)

theorem identity39200 : scanCanonicalize (H12AffineFastState.compose env39200 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound39200 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39201 : List Nat := [2,4,8,1,7,1,128,128,132,129,136,1,4,0,136,9,132,136,129,137,1,12,133,8,141,133,136,133,1,143,9,137,129,0,0,132]

theorem envBound39201 : H12AffineFastState.Bounded env39201 := by
  intro p hp
  have h : env39201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39200_39201 : H12AffineEnvironment.transform 7 128 env39200 = env39201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env39200 == env39201) = true)

theorem identity39201 : scanCanonicalize (H12AffineFastState.compose env39201 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39201 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39202 : List Nat := [2,4,8,1,7,1,8,8,12,9,0,1,4,0,0,9,12,0,9,1,1,12,13,8,5,13,0,13,1,7,9,1,9,0,0,12]

theorem envBound39202 : H12AffineFastState.Bounded env39202 := by
  intro p hp
  have h : env39202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39201_39202 : H12AffineEnvironment.transform 6 8 env39201 = env39202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39201 == env39202) = true)

theorem identity39202 : scanCanonicalize (H12AffineFastState.compose env39202 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39203 : List Nat := [2,4,5,1,7,1,5,5,1,4,0,1,4,0,0,4,1,0,4,1,1,1,0,5,5,0,0,0,1,7,4,1,4,0,0,1]

theorem envBound39203 : H12AffineFastState.Bounded env39203 := by
  intro p hp
  have h : env39203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39202_39203 : H12AffineEnvironment.transform 2 5 env39202 = env39203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39202 == env39203) = true)

theorem identity39203 : scanCanonicalize (H12AffineFastState.compose env39203 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39203 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39204 : List Nat := [2,3,2,1,0,1,2,2,1,3,0,1,3,0,0,3,1,0,3,1,1,1,0,2,2,0,0,0,1,0,3,1,3,0,0,1]

theorem envBound39204 : H12AffineFastState.Bounded env39204 := by
  intro p hp
  have h : env39204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39203_39204 : H12AffineEnvironment.transform 1 3 env39203 = env39204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39203 == env39204) = true)

def env39205 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,80,8524,65536,74030,65665,336,8525,17,476,74046,65536,8345,74110,302,74111,81,75802,8205,65831,257,65,0,324]

theorem envBound39205 : H12AffineFastState.Bounded env39205 := by
  intro p hp
  have h : env39205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39184_39205 : H12AffineEnvironment.transform 11 17 env39184 = env39205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env39184 == env39205) = true)

theorem identity39205 : scanCanonicalize (H12AffineFastState.compose env39205 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound39205 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39206 : List Nat := [2,4,8,16,32,64,128,186,238,250,2048,17,8192,80,8438,65536,73876,65665,234,8439,17,102,73860,65536,8345,73924,148,73925,81,75802,8205,65693,187,65,0,254]

theorem envBound39206 : H12AffineFastState.Bounded env39206 := by
  intro p hp
  have h : env39206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39205_39206 : H12AffineEnvironment.transform 7 186 env39205 = env39206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env39205 == env39206) = true)

def env39207 : List Nat := [2,4,8,0,32,64,128,170,238,234,2048,1,8192,64,8422,65536,73860,65665,234,8423,1,102,73860,65536,8329,73924,132,73925,65,75786,8205,65677,171,65,0,238]

theorem envBound39207 : H12AffineFastState.Bounded env39207 := by
  intro p hp
  have h : env39207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39206_39207 : H12AffineEnvironment.transform 3 0 env39206 = env39207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39206 == env39207) = true)

theorem identity39207 : scanCanonicalize (H12AffineFastState.compose env39207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound39207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39208 : List Nat := [2,4,8,0,32,64,128,170,238,234,2048,1,8192,64,8422,8235,175,8362,234,8423,1,102,175,8235,8329,239,132,238,65,2081,8205,8358,171,65,0,238]

theorem envBound39208 : H12AffineFastState.Bounded env39208 := by
  intro p hp
  have h : env39208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39207_39208 : H12AffineEnvironment.transform 15 8235 env39207 = env39208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env39207 == env39208) = true)

theorem identity39208 : scanCanonicalize (H12AffineFastState.compose env39208 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39208 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39209 : List Nat := [2,4,8,0,32,0,128,170,174,170,2048,1,8192,0,8358,8235,175,8362,170,8359,1,38,175,8235,8329,175,132,174,1,2081,8205,8358,171,1,0,174]

theorem envBound39209 : H12AffineFastState.Bounded env39209 := by
  intro p hp
  have h : env39209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39208_39209 : H12AffineEnvironment.transform 5 0 env39208 = env39209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39208 == env39209) = true)

theorem identity39209 : scanCanonicalize (H12AffineFastState.compose env39209 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2214) := by decide +kernel

theorem selectedBound39209 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env39210 : List Nat := [2,4,8,0,32,0,128,170,174,170,2048,1,2214,0,2048,2189,175,2060,170,2049,1,38,175,2189,2095,175,132,174,1,2081,2219,2048,171,1,0,174]

theorem envBound39210 : H12AffineFastState.Bounded env39210 := by
  intro p hp
  have h : env39210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39209_39210 : H12AffineEnvironment.transform 12 2214 env39209 = env39210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2214 env39209 == env39210) = true)

theorem identity39210 : scanCanonicalize (H12AffineFastState.compose env39210 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound39210 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39211 : List Nat := [2,4,8,0,32,0,128,170,174,170,38,1,128,0,38,171,175,42,170,39,1,38,175,171,9,175,132,174,1,7,141,38,171,1,0,174]

theorem envBound39211 : H12AffineFastState.Bounded env39211 := by
  intro p hp
  have h : env39211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39210_39211 : H12AffineEnvironment.transform 10 38 env39210 = env39211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env39210 == env39211) = true)

theorem identity39211 : scanCanonicalize (H12AffineFastState.compose env39211 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound39211 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env39212 : List Nat := [2,4,8,0,32,0,5,47,43,47,38,1,5,0,38,46,42,42,47,39,1,38,42,46,9,42,1,43,1,7,8,38,46,1,0,43]

theorem envBound39212 : H12AffineFastState.Bounded env39212 := by
  intro p hp
  have h : env39212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39211_39212 : H12AffineEnvironment.transform 6 5 env39211 = env39212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env39211 == env39212) = true)

theorem identity39212 : scanCanonicalize (H12AffineFastState.compose env39212 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39212 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39213 : List Nat := [2,4,8,0,0,0,5,15,11,15,6,1,5,0,6,14,10,10,15,7,1,6,10,14,9,10,1,11,1,7,8,6,14,1,0,11]

theorem envBound39213 : H12AffineFastState.Bounded env39213 := by
  intro p hp
  have h : env39213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39212_39213 : H12AffineEnvironment.transform 4 0 env39212 = env39213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39212 == env39213) = true)

def env39214 : List Nat := [2,4,8,1,32,64,128,171,238,235,2048,0,8192,65,8423,65536,73861,65665,234,8422,0,102,73860,65536,8328,73924,133,73925,64,75787,8205,65676,170,65,0,239]

theorem envBound39214 : H12AffineFastState.Bounded env39214 := by
  intro p hp
  have h : env39214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39206_39214 : H12AffineEnvironment.transform 3 1 env39206 = env39214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39206 == env39214) = true)

theorem identity39214 : scanCanonicalize (H12AffineFastState.compose env39214 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound39214 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39215 : List Nat := [2,4,8,1,32,64,111,68,1,4,2048,0,8192,65,8200,65536,73834,65646,5,8201,0,102,73835,65536,8295,73771,106,73770,64,75787,8205,65635,69,65,0,0]

theorem envBound39215 : H12AffineFastState.Bounded env39215 := by
  intro p hp
  have h : env39215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39214_39215 : H12AffineEnvironment.transform 6 111 env39214 = env39215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env39214 == env39215) = true)

theorem identity39215 : scanCanonicalize (H12AffineFastState.compose env39215 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound39215 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39216 : List Nat := [2,4,8,1,32,64,111,68,1,4,2048,0,8192,65,8200,98,8200,12,5,8201,0,102,8201,98,8295,8265,106,8264,64,10345,8205,1,69,65,0,0]

theorem envBound39216 : H12AffineFastState.Bounded env39216 := by
  intro p hp
  have h : env39216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39215_39216 : H12AffineEnvironment.transform 15 98 env39215 = env39216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env39215 == env39216) = true)

theorem identity39216 : scanCanonicalize (H12AffineFastState.compose env39216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound39216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39217 : List Nat := [2,4,8,1,32,64,111,68,1,4,2048,0,72,65,64,98,64,12,5,65,0,102,65,98,47,1,106,0,64,2081,69,1,69,65,0,0]

theorem envBound39217 : H12AffineFastState.Bounded env39217 := by
  intro p hp
  have h : env39217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39216_39217 : H12AffineEnvironment.transform 12 72 env39216 = env39217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env39216 == env39217) = true)

theorem identity39217 : scanCanonicalize (H12AffineFastState.compose env39217 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39217 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39218 : List Nat := [2,4,8,1,32,64,111,68,1,4,1,0,72,65,64,98,64,12,5,65,0,102,65,98,47,1,106,0,64,32,69,1,69,65,0,0]

theorem envBound39218 : H12AffineFastState.Bounded env39218 := by
  intro p hp
  have h : env39218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39217_39218 : H12AffineEnvironment.transform 10 1 env39217 = env39218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39217 == env39218) = true)

theorem identity39218 : scanCanonicalize (H12AffineFastState.compose env39218 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39218 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39219 : List Nat := [2,4,4,1,32,64,99,68,1,4,1,0,68,65,64,98,64,0,5,65,0,102,65,98,35,1,102,0,64,32,69,1,69,65,0,0]

theorem envBound39219 : H12AffineFastState.Bounded env39219 := by
  intro p hp
  have h : env39219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39218_39219 : H12AffineEnvironment.transform 2 4 env39218 = env39219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39218 == env39219) = true)

theorem identity39219 : scanCanonicalize (H12AffineFastState.compose env39219 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound39219 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39220 : List Nat := [2,4,4,1,7,64,68,68,1,4,1,0,68,65,64,69,64,0,5,65,0,65,65,69,4,1,65,0,64,7,69,1,69,65,0,0]

theorem envBound39220 : H12AffineFastState.Bounded env39220 := by
  intro p hp
  have h : env39220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39219_39220 : H12AffineEnvironment.transform 4 7 env39219 = env39220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env39219 == env39220) = true)

theorem identity39220 : scanCanonicalize (H12AffineFastState.compose env39220 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39221 : List Nat := [0,4,4,1,5,64,68,68,1,4,1,0,68,65,64,69,64,0,5,65,0,65,65,69,4,1,65,0,64,5,69,1,69,65,0,0]

theorem envBound39221 : H12AffineFastState.Bounded env39221 := by
  intro p hp
  have h : env39221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39220_39221 : H12AffineEnvironment.transform 0 0 env39220 = env39221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39220 == env39221) = true)

theorem identity39221 : scanCanonicalize (H12AffineFastState.compose env39221 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound39221 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39222 : List Nat := [0,4,4,1,5,5,1,1,1,4,1,0,1,4,5,0,5,0,5,4,0,4,4,0,4,1,4,0,5,5,0,1,0,4,0,0]

theorem envBound39222 : H12AffineFastState.Bounded env39222 := by
  intro p hp
  have h : env39222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39221_39222 : H12AffineEnvironment.transform 5 5 env39221 = env39222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env39221 == env39222) = true)

theorem identity39222 : scanCanonicalize (H12AffineFastState.compose env39222 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39223 : List Nat := [0,0,0,1,1,1,1,1,1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,1,0,0,1,1,0,1,0,0,0,0]

theorem envBound39223 : H12AffineFastState.Bounded env39223 := by
  intro p hp
  have h : env39223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39222_39223 : H12AffineEnvironment.transform 1 0 env39222 = env39223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39222 == env39223) = true)

def env39224 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4096,476,74046,69649,12424,78191,4415,74111,81,79883,8205,65831,257,65,0,4436]

theorem envBound39224 : H12AffineFastState.Bounded env39224 := by
  intro p hp
  have h : env39224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39183_39224 : H12AffineEnvironment.transform 8 341 env39183 = env39224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39183 == env39224) = true)

def env39225 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8525,65536,74030,65665,337,8524,16,476,74046,65537,8344,74111,303,74111,81,75803,8205,65831,257,65,0,324]

theorem envBound39225 : H12AffineFastState.Bounded env39225 := by
  intro p hp
  have h : env39225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39224_39225 : H12AffineEnvironment.transform 11 16 env39224 = env39225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env39224 == env39225) = true)

theorem identity39225 : scanCanonicalize (H12AffineFastState.compose env39225 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 221) := by decide +kernel

theorem selectedBound39225 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39226 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8525,221,8691,92,337,8524,16,476,8675,220,8344,8610,303,8610,81,10438,8205,506,257,65,0,324]

theorem envBound39226 : H12AffineFastState.Bounded env39226 := by
  intro p hp
  have h : env39226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39225_39226 : H12AffineEnvironment.transform 15 221 env39225 = env39226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 221 env39225 == env39226) = true)

def env39227 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,8192,64,8525,205,8675,76,321,8524,0,460,8675,204,8328,8610,303,8610,65,10438,8205,490,257,65,0,324]

theorem envBound39227 : H12AffineFastState.Bounded env39227 := by
  intro p hp
  have h : env39227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39226_39227 : H12AffineEnvironment.transform 3 0 env39226 = env39227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39226 == env39227) = true)

theorem identity39227 : scanCanonicalize (H12AffineFastState.compose env39227 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39227 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39228 : List Nat := [2,4,8,0,32,64,128,68,1,4,2048,0,8192,64,8201,205,8359,76,5,8200,0,136,8359,204,8328,8422,107,8422,65,10438,8205,174,69,65,0,0]

theorem envBound39228 : H12AffineFastState.Bounded env39228 := by
  intro p hp
  have h : env39228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39227_39228 : H12AffineEnvironment.transform 7 68 env39227 = env39228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39227 == env39228) = true)

theorem identity39228 : scanCanonicalize (H12AffineFastState.compose env39228 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound39228 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39229 : List Nat := [2,4,8,0,32,64,46,68,1,4,2048,0,8192,64,8201,99,8201,76,5,8200,0,38,8201,98,8230,8264,107,8264,65,10344,8205,0,69,65,0,0]

theorem envBound39229 : H12AffineFastState.Bounded env39229 := by
  intro p hp
  have h : env39229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39228_39229 : H12AffineEnvironment.transform 6 46 env39228 = env39229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env39228 == env39229) = true)

theorem identity39229 : scanCanonicalize (H12AffineFastState.compose env39229 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound39229 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39230 : List Nat := [2,4,8,0,32,64,46,68,1,4,2048,0,73,64,64,99,64,76,5,65,0,38,64,98,111,1,107,1,65,2081,68,0,69,65,0,0]

theorem envBound39230 : H12AffineFastState.Bounded env39230 := by
  intro p hp
  have h : env39230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39229_39230 : H12AffineEnvironment.transform 12 73 env39229 = env39230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env39229 == env39230) = true)

theorem identity39230 : scanCanonicalize (H12AffineFastState.compose env39230 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound39230 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39231 : List Nat := [2,4,8,0,32,64,46,68,1,4,42,0,73,64,64,99,64,76,5,65,0,38,64,98,111,1,107,1,65,11,68,0,69,65,0,0]

theorem envBound39231 : H12AffineFastState.Bounded env39231 := by
  intro p hp
  have h : env39231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39230_39231 : H12AffineEnvironment.transform 10 42 env39230 = env39231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env39230 == env39231) = true)

theorem identity39231 : scanCanonicalize (H12AffineFastState.compose env39231 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound39231 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39232 : List Nat := [2,4,8,0,32,44,46,40,1,4,42,0,37,44,44,15,44,32,5,45,0,38,44,14,3,1,7,1,45,11,40,0,41,45,0,0]

theorem envBound39232 : H12AffineFastState.Bounded env39232 := by
  intro p hp
  have h : env39232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39231_39232 : H12AffineEnvironment.transform 5 44 env39231 = env39232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env39231 == env39232) = true)

theorem identity39232 : scanCanonicalize (H12AffineFastState.compose env39232 (packedSelected [1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound39232 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env39233 : List Nat := [2,4,8,0,2,14,12,10,1,4,8,0,7,14,14,15,14,2,5,15,0,4,14,14,3,1,7,1,15,11,10,0,11,15,0,0]

theorem envBound39233 : H12AffineFastState.Bounded env39233 := by
  intro p hp
  have h : env39233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39232_39233 : H12AffineEnvironment.transform 4 2 env39232 = env39233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env39232 == env39233) = true)

theorem identity39233 : scanCanonicalize (H12AffineFastState.compose env39233 (packedSelected [0,2,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39233 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39234 : List Nat := [2,4,5,0,2,3,1,7,1,4,5,0,7,3,3,2,3,2,5,2,0,4,3,3,3,1,7,1,2,6,7,0,6,2,0,0]

theorem envBound39234 : H12AffineFastState.Bounded env39234 := by
  intro p hp
  have h : env39234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39233_39234 : H12AffineEnvironment.transform 2 5 env39233 = env39234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39233 == env39234) = true)

theorem identity39234 : scanCanonicalize (H12AffineFastState.compose env39234 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39235 : List Nat := [2,0,1,0,2,3,1,3,1,0,1,0,3,3,3,2,3,2,1,2,0,0,3,3,3,1,3,1,2,2,3,0,2,2,0,0]

theorem envBound39235 : H12AffineFastState.Bounded env39235 := by
  intro p hp
  have h : env39235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39234_39235 : H12AffineEnvironment.transform 1 0 env39234 = env39235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39234 == env39235) = true)

theorem identity39235 : scanCanonicalize (H12AffineFastState.compose env39235 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39236 : List Nat := [1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,1,0,1,1,1,0,0,0,0,0,1,0,1,1,1,0,0,1,1,0,0]

theorem envBound39236 : H12AffineFastState.Bounded env39236 := by
  intro p hp
  have h : env39236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39235_39236 : H12AffineEnvironment.transform 0 1 env39235 = env39236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39235 == env39236) = true)

def env39237 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,8192,65,8525,204,8674,77,320,8524,1,461,8675,205,8329,8610,303,8610,64,10438,8205,491,257,65,0,324]

theorem envBound39237 : H12AffineFastState.Bounded env39237 := by
  intro p hp
  have h : env39237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39226_39237 : H12AffineEnvironment.transform 3 1 env39226 = env39237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39226 == env39237) = true)

theorem identity39237 : scanCanonicalize (H12AffineFastState.compose env39237 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 230) := by decide +kernel

theorem selectedBound39237 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39238 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,230,65,427,204,260,77,320,426,1,461,261,205,111,324,303,324,64,2080,235,491,257,65,0,324]

theorem envBound39238 : H12AffineFastState.Bounded env39238 := by
  intro p hp
  have h : env39238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39237_39238 : H12AffineEnvironment.transform 12 230 env39237 = env39238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 230 env39237 == env39238) = true)

theorem identity39238 : scanCanonicalize (H12AffineFastState.compose env39238 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39238 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39239 : List Nat := [2,4,8,1,32,1,128,256,261,257,2048,1,167,0,427,141,260,12,257,426,1,396,261,140,46,261,303,261,1,2080,170,426,257,0,0,261]

theorem envBound39239 : H12AffineFastState.Bounded env39239 := by
  intro p hp
  have h : env39239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39238_39239 : H12AffineEnvironment.transform 5 1 env39238 = env39239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39238 == env39239) = true)

theorem identity39239 : scanCanonicalize (H12AffineFastState.compose env39239 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 427) := by decide +kernel

theorem selectedBound39239 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env39240 : List Nat := [2,4,8,1,32,1,128,256,261,257,427,1,167,0,427,141,260,12,257,426,1,396,261,140,46,261,303,261,1,395,170,426,257,0,0,261]

theorem envBound39240 : H12AffineFastState.Bounded env39240 := by
  intro p hp
  have h : env39240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39239_39240 : H12AffineEnvironment.transform 10 427 env39239 = env39240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 427 env39239 == env39240) = true)

theorem identity39240 : scanCanonicalize (H12AffineFastState.compose env39240 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39240 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39241 : List Nat := [2,4,8,1,6,1,128,256,261,257,397,1,129,0,397,141,260,12,257,396,1,396,261,140,8,261,265,261,1,395,140,396,257,0,0,261]

theorem envBound39241 : H12AffineFastState.Bounded env39241 := by
  intro p hp
  have h : env39241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39240_39241 : H12AffineEnvironment.transform 4 6 env39240 = env39241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39240 == env39241) = true)

theorem identity39241 : scanCanonicalize (H12AffineFastState.compose env39241 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound39241 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env39242 : List Nat := [2,4,8,1,6,1,128,8,13,9,133,1,129,0,133,141,12,12,9,132,1,132,13,140,8,13,1,13,1,131,140,132,9,0,0,13]

theorem envBound39242 : H12AffineFastState.Bounded env39242 := by
  intro p hp
  have h : env39242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39241_39242 : H12AffineEnvironment.transform 7 8 env39241 = env39242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env39241 == env39242) = true)

theorem identity39242 : scanCanonicalize (H12AffineFastState.compose env39242 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39242 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39243 : List Nat := [2,3,8,1,1,1,128,8,10,9,130,1,129,0,130,138,11,11,9,131,1,131,10,139,8,10,1,10,1,131,139,131,9,0,0,10]

theorem envBound39243 : H12AffineFastState.Bounded env39243 := by
  intro p hp
  have h : env39243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39242_39243 : H12AffineEnvironment.transform 1 3 env39242 = env39243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39242 == env39243) = true)

def env39244 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8524,65536,74030,65665,336,8525,17,476,74046,65536,8345,74110,302,74111,81,75802,8205,65831,257,65,0,325]

theorem envBound39244 : H12AffineFastState.Bounded env39244 := by
  intro p hp
  have h : env39244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39224_39244 : H12AffineEnvironment.transform 11 17 env39224 = env39244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env39224 == env39244) = true)

theorem identity39244 : scanCanonicalize (H12AffineFastState.compose env39244 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8340) := by decide +kernel

theorem selectedBound39244 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39245 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8524,8340,442,8213,336,8525,17,476,426,8340,8345,490,302,491,81,2190,8205,8627,257,65,0,325]

theorem envBound39245 : H12AffineFastState.Bounded env39245 := by
  intro p hp
  have h : env39245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39244_39245 : H12AffineEnvironment.transform 15 8340 env39244 = env39245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8340 env39244 == env39245) = true)

def env39246 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,8192,64,8524,8324,426,8197,320,8525,1,460,426,8324,8329,490,302,491,65,2190,8205,8611,257,65,0,325]

theorem envBound39246 : H12AffineFastState.Bounded env39246 := by
  intro p hp
  have h : env39246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39245_39246 : H12AffineEnvironment.transform 3 0 env39245 = env39246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39245 == env39246) = true)

theorem identity39246 : scanCanonicalize (H12AffineFastState.compose env39246 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound39246 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39247 : List Nat := [2,4,8,0,32,64,47,256,325,320,2048,1,8192,64,8524,8235,261,8197,320,8525,1,355,261,8235,8230,325,302,324,65,2081,8205,8460,257,65,0,325]

theorem envBound39247 : H12AffineFastState.Bounded env39247 := by
  intro p hp
  have h : env39247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39246_39247 : H12AffineEnvironment.transform 6 47 env39246 = env39247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env39246 == env39247) = true)

theorem identity39247 : scanCanonicalize (H12AffineFastState.compose env39247 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39247 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39248 : List Nat := [2,4,8,0,32,0,47,256,261,256,2048,1,8192,0,8460,8235,261,8197,256,8461,1,291,261,8235,8230,261,302,260,1,2081,8205,8460,257,1,0,261]

theorem envBound39248 : H12AffineFastState.Bounded env39248 := by
  intro p hp
  have h : env39248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39247_39248 : H12AffineEnvironment.transform 5 0 env39247 = env39248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39247 == env39248) = true)

theorem identity39248 : scanCanonicalize (H12AffineFastState.compose env39248 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound39248 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env39249 : List Nat := [2,4,8,0,32,0,47,256,261,256,2048,1,2316,0,2048,2343,261,2313,256,2049,1,291,261,2343,2346,261,302,260,1,2081,2305,2048,257,1,0,261]

theorem envBound39249 : H12AffineFastState.Bounded env39249 := by
  intro p hp
  have h : env39249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39248_39249 : H12AffineEnvironment.transform 12 2316 env39248 = env39249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env39248 == env39249) = true)

theorem identity39249 : scanCanonicalize (H12AffineFastState.compose env39249 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound39249 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39250 : List Nat := [2,4,8,0,32,0,47,256,261,256,39,1,299,0,39,256,261,302,256,38,1,291,261,256,269,261,302,260,1,6,294,39,257,1,0,261]

theorem envBound39250 : H12AffineFastState.Bounded env39250 := by
  intro p hp
  have h : env39250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39249_39250 : H12AffineEnvironment.transform 10 39 env39249 = env39250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env39249 == env39250) = true)

theorem identity39250 : scanCanonicalize (H12AffineFastState.compose env39250 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound39250 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39251 : List Nat := [2,4,8,0,32,0,47,9,12,9,39,1,34,0,39,9,12,39,9,38,1,42,12,9,4,12,39,13,1,6,47,39,8,1,0,12]

theorem envBound39251 : H12AffineFastState.Bounded env39251 := by
  intro p hp
  have h : env39251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39250_39251 : H12AffineEnvironment.transform 7 9 env39250 = env39251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env39250 == env39251) = true)

theorem identity39251 : scanCanonicalize (H12AffineFastState.compose env39251 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound39251 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39252 : List Nat := [2,4,8,0,7,0,8,9,12,9,0,1,5,0,0,9,12,0,9,1,1,13,12,9,4,12,0,13,1,6,8,0,8,1,0,12]

theorem envBound39252 : H12AffineFastState.Bounded env39252 := by
  intro p hp
  have h : env39252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39251_39252 : H12AffineEnvironment.transform 4 7 env39251 = env39252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env39251 == env39252) = true)

theorem identity39252 : scanCanonicalize (H12AffineFastState.compose env39252 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39253 : List Nat := [2,4,5,0,7,0,5,4,1,4,0,1,5,0,0,4,1,0,4,1,1,0,1,4,4,1,0,0,1,6,5,0,5,1,0,1]

theorem envBound39253 : H12AffineFastState.Bounded env39253 := by
  intro p hp
  have h : env39253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39252_39253 : H12AffineEnvironment.transform 2 5 env39252 = env39253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39252 == env39253) = true)

theorem identity39253 : scanCanonicalize (H12AffineFastState.compose env39253 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39253 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39254 : List Nat := [2,2,3,0,1,0,3,2,1,2,0,1,3,0,0,2,1,0,2,1,1,0,1,2,2,1,0,0,1,0,3,0,3,1,0,1]

theorem envBound39254 : H12AffineFastState.Bounded env39254 := by
  intro p hp
  have h : env39254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39253_39254 : H12AffineEnvironment.transform 1 2 env39253 = env39254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39253 == env39254) = true)

def env39255 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,8192,65,8524,8325,427,8196,321,8525,0,461,426,8325,8328,490,302,491,64,2190,8205,8610,257,65,0,325]

theorem envBound39255 : H12AffineFastState.Bounded env39255 := by
  intro p hp
  have h : env39255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39245_39255 : H12AffineEnvironment.transform 3 1 env39245 = env39255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39245 == env39255) = true)

theorem identity39255 : scanCanonicalize (H12AffineFastState.compose env39255 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39255 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39256 : List Nat := [2,4,8,1,32,64,128,68,0,4,2048,0,8192,65,8200,8325,239,8196,5,8201,0,137,238,8325,8328,174,106,175,64,2190,8205,8422,69,65,0,1]

theorem envBound39256 : H12AffineFastState.Bounded env39256 := by
  intro p hp
  have h : env39256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39255_39256 : H12AffineEnvironment.transform 7 68 env39255 = env39256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39255 == env39256) = true)

theorem identity39256 : scanCanonicalize (H12AffineFastState.compose env39256 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 231) := by decide +kernel

theorem selectedBound39256 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39257 : List Nat := [2,4,8,1,32,64,128,68,0,4,2048,0,231,65,239,98,239,227,5,238,0,137,238,98,111,174,106,175,64,2190,234,1,69,65,0,1]

theorem envBound39257 : H12AffineFastState.Bounded env39257 := by
  intro p hp
  have h : env39257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39256_39257 : H12AffineEnvironment.transform 12 231 env39256 = env39257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 231 env39256 == env39257) = true)

theorem identity39257 : scanCanonicalize (H12AffineFastState.compose env39257 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound39257 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39258 : List Nat := [2,4,8,1,32,64,47,68,0,4,2048,0,72,65,64,98,64,76,5,65,0,38,65,98,111,1,106,0,64,2081,69,1,69,65,0,1]

theorem envBound39258 : H12AffineFastState.Bounded env39258 := by
  intro p hp
  have h : env39258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39257_39258 : H12AffineEnvironment.transform 6 47 env39257 = env39258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env39257 == env39258) = true)

theorem identity39258 : scanCanonicalize (H12AffineFastState.compose env39258 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound39258 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39259 : List Nat := [2,4,8,1,32,64,47,68,0,4,64,0,72,65,64,98,64,76,5,65,0,38,65,98,111,1,106,0,64,97,69,1,69,65,0,1]

theorem envBound39259 : H12AffineFastState.Bounded env39259 := by
  intro p hp
  have h : env39259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39258_39259 : H12AffineEnvironment.transform 10 64 env39258 = env39259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env39258 == env39259) = true)

theorem identity39259 : scanCanonicalize (H12AffineFastState.compose env39259 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound39259 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39260 : List Nat := [2,4,8,1,32,13,47,9,0,4,13,0,5,12,13,47,13,1,5,12,0,38,12,47,34,1,39,0,13,44,8,1,8,12,0,1]

theorem envBound39260 : H12AffineFastState.Bounded env39260 := by
  intro p hp
  have h : env39260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39259_39260 : H12AffineEnvironment.transform 5 13 env39259 = env39260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env39259 == env39260) = true)

theorem identity39260 : scanCanonicalize (H12AffineFastState.compose env39260 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39260 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39261 : List Nat := [2,4,8,1,6,13,9,9,0,4,13,0,5,12,13,9,13,1,5,12,0,0,12,9,4,1,1,0,13,10,8,1,8,12,0,1]

theorem envBound39261 : H12AffineFastState.Bounded env39261 := by
  intro p hp
  have h : env39261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39260_39261 : H12AffineEnvironment.transform 4 6 env39260 = env39261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39260 == env39261) = true)

theorem identity39261 : scanCanonicalize (H12AffineFastState.compose env39261 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39261 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39262 : List Nat := [2,0,8,1,2,9,9,9,0,0,9,0,1,8,9,9,9,1,1,8,0,0,8,9,0,1,1,0,9,10,8,1,8,8,0,1]

theorem envBound39262 : H12AffineFastState.Bounded env39262 := by
  intro p hp
  have h : env39262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39261_39262 : H12AffineEnvironment.transform 1 0 env39261 = env39262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39261 == env39262) = true)

def env39263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4096,477,74047,69648,13769,78895,332223,74814,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound39263 : H12AffineFastState.Bounded env39263 := by
  intro p hp
  have h : env39263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39103_39263 : H12AffineEnvironment.transform 13 1297 env39103 = env39263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39103 == env39263) = true)

def env39264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4096,477,74047,69648,13769,78895,4415,74814,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound39264 : H12AffineFastState.Bounded env39264 := by
  intro p hp
  have h : env39264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39263_39264 : H12AffineEnvironment.transform 17 65664 env39263 = env39264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39263 == env39264) = true)

theorem identity39264 : scanCanonicalize (H12AffineFastState.compose env39264 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound39264 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4096,477,65910,69648,5504,70758,4415,66679,1297,72963,69,65830,257,1281,1344,5952]

theorem envBound39265 : H12AffineFastState.Bounded env39265 := by
  intro p hp
  have h : env39265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39264_39265 : H12AffineEnvironment.transform 12 73 env39264 = env39265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env39264 == env39265) = true)

def env39266 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4096,477,65910,69648,5504,70758,4415,66679,1297,72963,69,65830,257,1281,1344,5140]

theorem envBound39266 : H12AffineFastState.Bounded env39266 := by
  intro p hp
  have h : env39266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39265_39266 : H12AffineEnvironment.transform 8 340 env39265 = env39266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env39265 == env39266) = true)

def env39267 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4372,65536,65895,65664,4416,4373,4096,477,65910,69648,4288,69926,4415,65847,81,71747,69,65830,257,65,0,4436]

theorem envBound39267 : H12AffineFastState.Bounded env39267 := by
  intro p hp
  have h : env39267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39266_39267 : H12AffineEnvironment.transform 9 320 env39266 = env39267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39266 == env39267) = true)

theorem identity39267 : scanCanonicalize (H12AffineFastState.compose env39267 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39267 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39268 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4372,114,277,242,4416,4373,4096,477,260,4194,4288,4436,4415,325,81,6193,69,340,257,65,0,4436]

theorem envBound39268 : H12AffineFastState.Bounded env39268 := by
  intro p hp
  have h : env39268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39267_39268 : H12AffineEnvironment.transform 15 114 env39267 = env39268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39267 == env39268) = true)

theorem identity39268 : scanCanonicalize (H12AffineFastState.compose env39268 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 335) := by decide +kernel

theorem selectedBound39268 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env39269 : List Nat := [2,4,8,16,32,64,128,256,340,320,335,4096,73,81,4372,114,277,242,4416,4373,4096,477,260,4194,4288,4436,4415,325,81,4478,69,340,257,65,0,4436]

theorem envBound39269 : H12AffineFastState.Bounded env39269 := by
  intro p hp
  have h : env39269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39268_39269 : H12AffineEnvironment.transform 10 335 env39268 = env39269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 335 env39268 == env39269) = true)

theorem identity39269 : scanCanonicalize (H12AffineFastState.compose env39269 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39269 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env39270 : List Nat := [2,4,8,16,32,64,128,256,340,320,335,0,73,81,276,114,277,242,320,277,0,477,260,98,192,340,319,325,81,382,69,340,257,65,0,340]

theorem envBound39270 : H12AffineFastState.Bounded env39270 := by
  intro p hp
  have h : env39270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39269_39270 : H12AffineEnvironment.transform 11 0 env39269 = env39270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39269 == env39270) = true)

theorem identity39270 : scanCanonicalize (H12AffineFastState.compose env39270 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound39270 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39271 : List Nat := [2,4,8,16,32,64,128,140,216,204,195,0,73,81,152,114,153,242,204,153,0,81,136,98,192,216,179,201,81,242,69,216,141,65,0,216]

theorem envBound39271 : H12AffineFastState.Bounded env39271 := by
  intro p hp
  have h : env39271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39270_39271 : H12AffineEnvironment.transform 7 140 env39270 = env39271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env39270 == env39271) = true)

theorem identity39271 : scanCanonicalize (H12AffineFastState.compose env39271 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound39271 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env39272 : List Nat := [2,4,8,16,32,64,78,66,22,2,13,0,73,81,86,114,87,60,2,87,0,81,70,98,14,22,125,7,81,60,69,22,67,65,0,22]

theorem envBound39272 : H12AffineFastState.Bounded env39272 := by
  intro p hp
  have h : env39272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39271_39272 : H12AffineEnvironment.transform 6 78 env39271 = env39272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env39271 == env39272) = true)

theorem identity39272 : scanCanonicalize (H12AffineFastState.compose env39272 (packedSelected [1,2,3,4,8,9,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound39272 : packedSelected [1,2,3,4,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env39273 : List Nat := [2,4,8,16,32,60,50,62,22,2,13,0,53,45,42,14,43,60,2,43,0,45,58,30,14,22,1,7,45,60,57,22,63,61,0,22]

theorem envBound39273 : H12AffineFastState.Bounded env39273 := by
  intro p hp
  have h : env39273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39272_39273 : H12AffineEnvironment.transform 5 60 env39272 = env39273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env39272 == env39273) = true)

theorem identity39273 : scanCanonicalize (H12AffineFastState.compose env39273 (packedSelected [1,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39273 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env39274 : List Nat := [2,4,8,1,32,45,35,47,7,2,13,0,36,45,42,14,43,45,2,43,0,45,43,15,14,7,1,7,45,45,40,7,46,44,0,7]

theorem envBound39274 : H12AffineFastState.Bounded env39274 := by
  intro p hp
  have h : env39274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39273_39274 : H12AffineEnvironment.transform 3 1 env39273 = env39274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39273 == env39274) = true)

theorem identity39274 : scanCanonicalize (H12AffineFastState.compose env39274 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39274 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39275 : List Nat := [2,4,8,1,6,11,5,9,7,2,13,0,2,11,12,14,13,11,2,13,0,11,13,15,14,7,1,7,11,11,14,7,8,10,0,7]

theorem envBound39275 : H12AffineFastState.Bounded env39275 := by
  intro p hp
  have h : env39275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39274_39275 : H12AffineEnvironment.transform 4 6 env39274 = env39275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39274 == env39275) = true)

theorem identity39275 : scanCanonicalize (H12AffineFastState.compose env39275 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39276 : List Nat := [2,4,4,1,6,7,5,5,7,2,1,0,2,7,0,2,1,7,2,1,0,7,1,3,2,7,1,7,7,7,2,7,4,6,0,7]

theorem envBound39276 : H12AffineFastState.Bounded env39276 := by
  intro p hp
  have h : env39276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39275_39276 : H12AffineEnvironment.transform 2 4 env39275 = env39276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39275 == env39276) = true)

def env39277 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4373,65536,65894,65664,4416,4372,4096,477,65910,69648,4289,69927,4415,65846,80,71746,69,65830,257,64,1,4437]

theorem envBound39277 : H12AffineFastState.Bounded env39277 := by
  intro p hp
  have h : env39277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39266_39277 : H12AffineEnvironment.transform 9 321 env39266 = env39277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39266 == env39277) = true)

theorem identity39277 : scanCanonicalize (H12AffineFastState.compose env39277 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound39277 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39278 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4373,4210,4372,4338,4416,4372,4096,477,4356,98,4289,341,4415,4420,80,2096,69,4436,257,64,1,4437]

theorem envBound39278 : H12AffineFastState.Bounded env39278 := by
  intro p hp
  have h : env39278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39277_39278 : H12AffineEnvironment.transform 15 4210 env39277 = env39278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env39277 == env39278) = true)

theorem identity39278 : scanCanonicalize (H12AffineFastState.compose env39278 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound39278 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39279 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,81,73,80,324,35,325,163,273,325,81,477,341,98,144,341,366,277,80,2096,69,261,257,64,1,260]

theorem envBound39279 : H12AffineFastState.Bounded env39279 := by
  intro p hp
  have h : env39279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39278_39279 : H12AffineEnvironment.transform 11 81 env39278 = env39279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env39278 == env39279) = true)

theorem identity39279 : scanCanonicalize (H12AffineFastState.compose env39279 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 212) := by decide +kernel

theorem selectedBound39279 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env39280 : List Nat := [2,4,8,16,32,64,128,256,340,321,212,81,73,80,324,35,325,163,273,325,81,477,341,98,144,341,366,277,80,228,69,261,257,64,1,260]

theorem envBound39280 : H12AffineFastState.Bounded env39280 := by
  intro p hp
  have h : env39280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39279_39280 : H12AffineEnvironment.transform 10 212 env39279 = env39280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 212 env39279 == env39280) = true)

theorem identity39280 : scanCanonicalize (H12AffineFastState.compose env39280 (packedSelected [1,2,3,4,5,8,9,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound39280 : packedSelected [1,2,3,4,5,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env39281 : List Nat := [2,4,8,16,32,64,128,138,222,203,212,81,73,80,206,35,207,163,155,207,81,87,223,98,144,223,228,159,80,228,69,143,139,64,1,142]

theorem envBound39281 : H12AffineFastState.Bounded env39281 := by
  intro p hp
  have h : env39281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39280_39281 : H12AffineEnvironment.transform 7 138 env39280 = env39281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env39280 == env39281) = true)

theorem identity39281 : scanCanonicalize (H12AffineFastState.compose env39281 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39281 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env39282 : List Nat := [2,4,2,16,32,64,128,128,212,193,212,81,67,80,196,35,197,163,145,197,81,87,213,98,144,213,228,149,80,228,69,133,129,64,1,132]

theorem envBound39282 : H12AffineFastState.Bounded env39282 := by
  intro p hp
  have h : env39282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39281_39282 : H12AffineEnvironment.transform 2 2 env39281 = env39282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39281 == env39282) = true)

theorem identity39282 : scanCanonicalize (H12AffineFastState.compose env39282 (packedSelected [0,1,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound39282 : packedSelected [0,1,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39283 : List Nat := [2,4,2,16,32,7,128,128,147,134,147,22,4,23,131,35,130,163,145,130,22,16,146,37,144,146,163,149,23,163,2,133,129,7,1,132]

theorem envBound39283 : H12AffineFastState.Bounded env39283 := by
  intro p hp
  have h : env39283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39282_39283 : H12AffineEnvironment.transform 5 7 env39282 = env39283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env39282 == env39283) = true)

theorem identity39283 : scanCanonicalize (H12AffineFastState.compose env39283 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound39283 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env39284 : List Nat := [2,4,2,16,32,7,20,20,7,18,7,22,4,23,23,35,22,55,5,22,22,16,6,37,4,6,55,1,23,55,2,17,21,7,1,16]

theorem envBound39284 : H12AffineFastState.Bounded env39284 := by
  intro p hp
  have h : env39284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39283_39284 : H12AffineEnvironment.transform 6 20 env39283 = env39284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env39283 == env39284) = true)

theorem identity39284 : scanCanonicalize (H12AffineFastState.compose env39284 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound39284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39285 : List Nat := [2,4,2,16,23,7,20,20,7,18,7,22,4,23,23,20,22,0,5,22,22,16,6,18,4,6,0,1,23,0,2,17,21,7,1,16]

theorem envBound39285 : H12AffineFastState.Bounded env39285 := by
  intro p hp
  have h : env39285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39284_39285 : H12AffineEnvironment.transform 4 23 env39284 = env39285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env39284 == env39285) = true)

theorem identity39285 : scanCanonicalize (H12AffineFastState.compose env39285 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39286 : List Nat := [2,4,2,1,6,7,5,5,7,3,7,7,4,6,6,5,7,0,5,7,7,1,6,3,4,6,0,1,6,0,2,0,4,7,1,1]

theorem envBound39286 : H12AffineFastState.Bounded env39286 := by
  intro p hp
  have h : env39286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39285_39286 : H12AffineEnvironment.transform 3 1 env39285 = env39286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39285 == env39286) = true)

theorem identity39286 : scanCanonicalize (H12AffineFastState.compose env39286 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39286 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39287 : List Nat := [2,2,2,1,0,1,3,3,1,3,1,1,2,0,0,3,1,0,3,1,1,1,0,3,2,0,0,1,0,0,2,0,2,1,1,1]

theorem envBound39287 : H12AffineFastState.Bounded env39287 := by
  intro p hp
  have h : env39287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39286_39287 : H12AffineEnvironment.transform 1 2 env39286 = env39287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39286 == env39287) = true)

def env39288 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4096,477,65910,69648,5504,70758,4415,66679,1297,72963,69,65830,257,1281,1344,5141]

theorem envBound39288 : H12AffineFastState.Bounded env39288 := by
  intro p hp
  have h : env39288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39265_39288 : H12AffineEnvironment.transform 8 341 env39265 = env39288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39265 == env39288) = true)

def env39289 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4372,65536,65895,65664,4416,4373,4096,477,65910,69648,4288,69926,4415,65847,81,71747,69,65830,257,65,0,4437]

theorem envBound39289 : H12AffineFastState.Bounded env39289 := by
  intro p hp
  have h : env39289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39288_39289 : H12AffineEnvironment.transform 9 320 env39288 = env39289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39288 == env39289) = true)

theorem identity39289 : scanCanonicalize (H12AffineFastState.compose env39289 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39289 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39290 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4372,114,277,242,4416,4373,4096,477,260,4194,4288,4436,4415,325,81,6193,69,340,257,65,0,4437]

theorem envBound39290 : H12AffineFastState.Bounded env39290 := by
  intro p hp
  have h : env39290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39289_39290 : H12AffineEnvironment.transform 15 114 env39289 = env39290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39289 == env39290) = true)

theorem identity39290 : scanCanonicalize (H12AffineFastState.compose env39290 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 334) := by decide +kernel

theorem selectedBound39290 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env39291 : List Nat := [2,4,8,16,32,64,128,256,341,320,334,4096,73,81,4372,114,277,242,4416,4373,4096,477,260,4194,4288,4436,4415,325,81,4479,69,340,257,65,0,4437]

theorem envBound39291 : H12AffineFastState.Bounded env39291 := by
  intro p hp
  have h : env39291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39290_39291 : H12AffineEnvironment.transform 10 334 env39290 = env39291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 334 env39290 == env39291) = true)

theorem identity39291 : scanCanonicalize (H12AffineFastState.compose env39291 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39291 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env39292 : List Nat := [2,4,8,16,32,64,128,256,341,320,334,0,73,81,276,114,277,242,320,277,0,477,260,98,192,340,319,325,81,383,69,340,257,65,0,341]

theorem envBound39292 : H12AffineFastState.Bounded env39292 := by
  intro p hp
  have h : env39292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39291_39292 : H12AffineEnvironment.transform 11 0 env39291 = env39292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39291 == env39292) = true)

theorem identity39292 : scanCanonicalize (H12AffineFastState.compose env39292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound39292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39293 : List Nat := [2,4,8,16,32,64,128,141,216,205,195,0,73,81,153,114,152,242,205,152,0,80,137,98,192,217,178,200,81,242,69,217,140,65,0,216]

theorem envBound39293 : H12AffineFastState.Bounded env39293 := by
  intro p hp
  have h : env39293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39292_39293 : H12AffineEnvironment.transform 7 141 env39292 = env39293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env39292 == env39293) = true)

theorem identity39293 : scanCanonicalize (H12AffineFastState.compose env39293 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound39293 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env39294 : List Nat := [2,4,8,16,32,23,128,141,143,154,148,0,30,6,153,37,152,165,154,152,0,7,137,53,151,142,178,159,6,165,18,142,140,22,0,143]

theorem envBound39294 : H12AffineFastState.Bounded env39294 := by
  intro p hp
  have h : env39294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39293_39294 : H12AffineEnvironment.transform 5 23 env39293 = env39294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env39293 == env39294) = true)

theorem identity39294 : scanCanonicalize (H12AffineFastState.compose env39294 (packedSelected [1,2,3,4,8,9,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound39294 : packedSelected [1,2,3,4,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env39295 : List Nat := [2,4,8,16,32,23,51,62,60,41,39,0,30,6,42,37,43,22,41,43,0,7,58,53,36,61,1,44,6,22,18,61,63,22,0,60]

theorem envBound39295 : H12AffineFastState.Bounded env39295 := by
  intro p hp
  have h : env39295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39294_39295 : H12AffineEnvironment.transform 6 51 env39294 = env39295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env39294 == env39295) = true)

theorem identity39295 : scanCanonicalize (H12AffineFastState.compose env39295 (packedSelected [1,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39295 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env39296 : List Nat := [2,4,8,0,32,7,35,46,44,41,39,0,14,6,42,37,43,6,41,43,0,7,42,37,36,45,1,44,6,6,2,45,47,6,0,44]

theorem envBound39296 : H12AffineFastState.Bounded env39296 := by
  intro p hp
  have h : env39296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39295_39296 : H12AffineEnvironment.transform 3 0 env39295 = env39296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39295 == env39296) = true)

theorem identity39296 : scanCanonicalize (H12AffineFastState.compose env39296 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39297 : List Nat := [2,4,4,0,32,7,35,34,32,37,39,0,2,6,38,37,39,6,37,39,0,7,38,37,36,33,1,32,6,6,2,33,35,6,0,32]

theorem envBound39297 : H12AffineFastState.Bounded env39297 := by
  intro p hp
  have h : env39297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39296_39297 : H12AffineEnvironment.transform 2 4 env39296 = env39297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39296 == env39297) = true)

theorem identity39297 : scanCanonicalize (H12AffineFastState.compose env39297 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39298 : List Nat := [2,4,4,0,6,7,5,4,6,3,1,0,2,6,0,3,1,6,3,1,0,7,0,3,2,7,1,6,6,6,2,7,5,6,0,6]

theorem envBound39298 : H12AffineFastState.Bounded env39298 := by
  intro p hp
  have h : env39298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39297_39298 : H12AffineEnvironment.transform 4 6 env39297 = env39298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39297 == env39298) = true)

def env39299 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4373,65536,65894,65664,4416,4372,4096,477,65910,69648,4289,69927,4415,65846,80,71746,69,65830,257,64,1,4436]

theorem envBound39299 : H12AffineFastState.Bounded env39299 := by
  intro p hp
  have h : env39299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39288_39299 : H12AffineEnvironment.transform 9 321 env39288 = env39299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39288 == env39299) = true)

theorem identity39299 : scanCanonicalize (H12AffineFastState.compose env39299 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound39299 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39300 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4373,4210,4372,4338,4416,4372,4096,477,4356,98,4289,341,4415,4420,80,2096,69,4436,257,64,1,4436]

theorem envBound39300 : H12AffineFastState.Bounded env39300 := by
  intro p hp
  have h : env39300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39299_39300 : H12AffineEnvironment.transform 15 4210 env39299 = env39300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env39299 == env39300) = true)

theorem identity39300 : scanCanonicalize (H12AffineFastState.compose env39300 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound39300 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39301 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,81,73,80,324,35,325,163,273,325,81,477,341,98,144,341,366,277,80,2096,69,261,257,64,1,261]

theorem envBound39301 : H12AffineFastState.Bounded env39301 := by
  intro p hp
  have h : env39301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39300_39301 : H12AffineEnvironment.transform 11 81 env39300 = env39301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env39300 == env39301) = true)

theorem identity39301 : scanCanonicalize (H12AffineFastState.compose env39301 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 448) := by decide +kernel

theorem selectedBound39301 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env39302 : List Nat := [2,4,8,16,32,64,128,256,341,321,448,81,73,80,324,35,325,163,273,325,81,477,341,98,144,341,366,277,80,496,69,261,257,64,1,261]

theorem envBound39302 : H12AffineFastState.Bounded env39302 := by
  intro p hp
  have h : env39302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39301_39302 : H12AffineEnvironment.transform 10 448 env39301 = env39302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 448 env39301 == env39302) = true)

theorem identity39302 : scanCanonicalize (H12AffineFastState.compose env39302 (packedSelected [1,2,3,4,5,8,9,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound39302 : packedSelected [1,2,3,4,5,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env39303 : List Nat := [2,4,8,16,32,64,78,256,341,321,270,81,73,80,324,35,325,109,273,325,81,275,341,98,94,341,366,277,80,318,69,261,257,64,1,261]

theorem envBound39303 : H12AffineFastState.Bounded env39303 := by
  intro p hp
  have h : env39303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39302_39303 : H12AffineEnvironment.transform 6 78 env39302 = env39303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env39302 == env39303) = true)

theorem identity39303 : scanCanonicalize (H12AffineFastState.compose env39303 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound39303 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env39304 : List Nat := [2,4,8,16,32,27,21,256,270,282,270,10,18,11,287,35,286,54,273,286,10,275,270,57,5,270,309,277,11,318,30,261,257,27,1,261]

theorem envBound39304 : H12AffineFastState.Bounded env39304 := by
  intro p hp
  have h : env39304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39303_39304 : H12AffineEnvironment.transform 5 27 env39303 = env39304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env39303 == env39304) = true)

theorem identity39304 : scanCanonicalize (H12AffineFastState.compose env39304 (packedSelected [1,2,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound39304 : packedSelected [1,2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env39305 : List Nat := [2,4,8,16,32,27,21,8,6,18,6,10,18,11,23,35,22,54,25,22,10,27,6,57,5,6,61,29,11,54,30,13,9,27,1,13]

theorem envBound39305 : H12AffineFastState.Bounded env39305 := by
  intro p hp
  have h : env39305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39304_39305 : H12AffineEnvironment.transform 7 8 env39304 = env39305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env39304 == env39305) = true)

theorem identity39305 : scanCanonicalize (H12AffineFastState.compose env39305 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39305 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env39306 : List Nat := [2,4,8,12,32,7,9,8,6,14,6,10,14,11,11,35,10,42,5,10,10,7,6,37,5,6,33,1,11,42,2,13,9,7,1,13]

theorem envBound39306 : H12AffineFastState.Bounded env39306 := by
  intro p hp
  have h : env39306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39305_39306 : H12AffineEnvironment.transform 3 12 env39305 = env39306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39305 == env39306) = true)

theorem identity39306 : scanCanonicalize (H12AffineFastState.compose env39306 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39307 : List Nat := [2,4,8,12,10,7,9,8,6,14,6,10,14,11,11,9,10,0,5,10,10,7,6,15,5,6,11,1,11,0,2,13,9,7,1,13]

theorem envBound39307 : H12AffineFastState.Bounded env39307 := by
  intro p hp
  have h : env39307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39306_39307 : H12AffineEnvironment.transform 4 10 env39306 = env39307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39306 == env39307) = true)

theorem identity39307 : scanCanonicalize (H12AffineFastState.compose env39307 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39308 : List Nat := [2,4,4,0,6,7,5,4,6,2,6,6,2,7,7,5,6,0,5,6,6,7,6,3,5,6,7,1,7,0,2,1,5,7,1,1]

theorem envBound39308 : H12AffineFastState.Bounded env39308 := by
  intro p hp
  have h : env39308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39307_39308 : H12AffineEnvironment.transform 2 4 env39307 = env39308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39307 == env39308) = true)

theorem identity39308 : scanCanonicalize (H12AffineFastState.compose env39308 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39308 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39309 : List Nat := [2,3,3,0,1,0,2,3,1,2,1,1,2,0,0,2,1,0,2,1,1,0,1,3,2,1,0,1,0,0,2,1,2,0,1,1]

theorem envBound39309 : H12AffineFastState.Bounded env39309 := by
  intro p hp
  have h : env39309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39308_39309 : H12AffineEnvironment.transform 1 3 env39308 = env39309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39308 == env39309) = true)

def env39310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4096,477,74047,69648,13769,78895,4414,74814,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound39310 : H12AffineFastState.Bounded env39310 := by
  intro p hp
  have h : env39310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39263_39310 : H12AffineEnvironment.transform 17 65665 env39263 = env39310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39263 == env39310) = true)

theorem identity39310 : scanCanonicalize (H12AffineFastState.compose env39310 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound39310 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4096,477,70711,69648,193,65831,4414,69942,1297,67650,5380,65830,257,1281,1344,5952]

theorem envBound39311 : H12AffineFastState.Bounded env39311 := by
  intro p hp
  have h : env39311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39310_39311 : H12AffineEnvironment.transform 12 5384 env39310 = env39311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env39310 == env39311) = true)

def env39312 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4096,477,70711,69648,193,65831,4414,69942,1297,67650,5380,65830,257,1281,1344,5140]

theorem envBound39312 : H12AffineFastState.Bounded env39312 := by
  intro p hp
  have h : env39312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39311_39312 : H12AffineEnvironment.transform 8 340 env39311 = env39312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env39311 == env39312) = true)

def env39313 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1297,277,65536,65894,65665,320,276,0,477,66615,65552,193,65831,318,65846,1297,67650,1284,65830,257,1281,1344,1044]

theorem envBound39313 : H12AffineFastState.Bounded env39313 := by
  intro p hp
  have h : env39313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39312_39313 : H12AffineEnvironment.transform 11 0 env39312 = env39313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39312 == env39313) = true)

theorem identity39313 : scanCanonicalize (H12AffineFastState.compose env39313 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound39313 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39314 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1297,277,1331,1109,1458,320,276,0,477,260,1315,193,1044,318,1029,1297,3441,1284,1045,257,1281,1344,1044]

theorem envBound39314 : H12AffineFastState.Bounded env39314 := by
  intro p hp
  have h : env39314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39313_39314 : H12AffineEnvironment.transform 15 1331 env39313 = env39314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env39313 == env39314) = true)

theorem identity39314 : scanCanonicalize (H12AffineFastState.compose env39314 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound39314 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env39315 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1442,0,1288,1297,277,1331,1109,1458,320,276,0,477,260,1315,193,1044,318,1029,1297,211,1284,1045,257,1281,1344,1044]

theorem envBound39315 : H12AffineFastState.Bounded env39315 := by
  intro p hp
  have h : env39315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39314_39315 : H12AffineEnvironment.transform 10 1442 env39314 = env39315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env39314 == env39315) = true)

theorem identity39315 : scanCanonicalize (H12AffineFastState.compose env39315 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39315 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39316 : List Nat := [2,4,8,16,32,64,128,256,340,272,178,0,24,1,277,35,325,162,320,276,0,477,260,51,193,260,318,277,1,211,20,261,257,17,80,260]

theorem envBound39316 : H12AffineFastState.Bounded env39316 := by
  intro p hp
  have h : env39316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39315_39316 : H12AffineEnvironment.transform 9 272 env39315 = env39316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39315 == env39316) = true)

theorem identity39316 : scanCanonicalize (H12AffineFastState.compose env39316 (packedSelected [8,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound39316 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env39317 : List Nat := [2,4,8,16,32,61,128,256,297,272,178,0,24,1,277,35,312,162,317,276,0,416,260,51,188,260,318,277,1,174,20,261,257,17,45,260]

theorem envBound39317 : H12AffineFastState.Bounded env39317 := by
  intro p hp
  have h : env39317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39316_39317 : H12AffineEnvironment.transform 5 61 env39316 = env39317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env39316 == env39317) = true)

theorem identity39317 : scanCanonicalize (H12AffineFastState.compose env39317 (packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39317 : packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env39318 : List Nat := [2,2,8,16,32,59,128,256,297,272,178,0,24,1,275,35,312,162,315,274,0,416,258,51,186,258,312,275,1,168,18,259,257,17,43,258]

theorem envBound39318 : H12AffineFastState.Bounded env39318 := by
  intro p hp
  have h : env39318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39317_39318 : H12AffineEnvironment.transform 1 2 env39317 = env39318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39317 == env39318) = true)

theorem identity39318 : scanCanonicalize (H12AffineFastState.compose env39318 (packedSelected [0,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound39318 : packedSelected [0,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39319 : List Nat := [2,2,8,16,32,59,128,19,58,3,178,0,24,1,0,35,43,162,40,1,0,179,17,51,186,17,43,0,1,168,18,16,18,17,43,17]

theorem envBound39319 : H12AffineFastState.Bounded env39319 := by
  intro p hp
  have h : env39319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39318_39319 : H12AffineEnvironment.transform 7 19 env39318 = env39319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env39318 == env39319) = true)

theorem identity39319 : scanCanonicalize (H12AffineFastState.compose env39319 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound39319 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39320 : List Nat := [2,2,8,16,32,59,35,19,58,3,17,0,24,1,0,35,43,1,40,1,0,16,17,51,25,17,43,0,1,11,18,16,18,17,43,17]

theorem envBound39320 : H12AffineFastState.Bounded env39320 := by
  intro p hp
  have h : env39320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39319_39320 : H12AffineEnvironment.transform 6 35 env39319 = env39320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env39319 == env39320) = true)

theorem identity39320 : scanCanonicalize (H12AffineFastState.compose env39320 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound39320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39321 : List Nat := [2,2,8,16,27,0,24,19,1,3,17,0,24,1,0,24,16,1,19,1,0,16,17,8,25,17,16,0,1,11,18,16,18,17,16,17]

theorem envBound39321 : H12AffineFastState.Bounded env39321 := by
  intro p hp
  have h : env39321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39320_39321 : H12AffineEnvironment.transform 4 27 env39320 = env39321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env39320 == env39321) = true)

theorem identity39321 : scanCanonicalize (H12AffineFastState.compose env39321 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39321 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39322 : List Nat := [2,2,8,0,11,0,8,3,1,3,1,0,8,1,0,8,0,1,3,1,0,0,1,8,9,1,0,0,1,11,2,0,2,1,0,1]

theorem envBound39322 : H12AffineFastState.Bounded env39322 := by
  intro p hp
  have h : env39322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39321_39322 : H12AffineEnvironment.transform 3 0 env39321 = env39322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39321 == env39322) = true)

theorem identity39322 : scanCanonicalize (H12AffineFastState.compose env39322 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39323 : List Nat := [2,2,3,0,0,0,3,3,1,3,1,0,3,1,0,3,0,1,3,1,0,0,1,3,2,1,0,0,1,0,2,0,2,1,0,1]

theorem envBound39323 : H12AffineFastState.Bounded env39323 := by
  intro p hp
  have h : env39323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39322_39323 : H12AffineEnvironment.transform 2 3 env39322 = env39323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39322 == env39323) = true)

def env39324 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1297,277,65536,65895,65665,321,276,1,477,66614,65553,193,65831,319,65847,1297,67650,1285,65830,257,1281,1344,1045]

theorem envBound39324 : H12AffineFastState.Bounded env39324 := by
  intro p hp
  have h : env39324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39312_39324 : H12AffineEnvironment.transform 11 1 env39312 = env39324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39312 == env39324) = true)

theorem identity39324 : scanCanonicalize (H12AffineFastState.compose env39324 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39324 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39325 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1297,277,114,277,243,321,276,1,477,1092,99,193,341,319,325,1297,2096,1285,340,257,1281,1344,1045]

theorem envBound39325 : H12AffineFastState.Bounded env39325 := by
  intro p hp
  have h : env39325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39324_39325 : H12AffineEnvironment.transform 15 114 env39324 = env39325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39324 == env39325) = true)

theorem identity39325 : scanCanonicalize (H12AffineFastState.compose env39325 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound39325 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env39326 : List Nat := [2,4,8,16,32,64,128,256,340,1024,10,1,1289,1297,277,114,277,243,321,276,1,477,1092,99,193,341,319,325,1297,58,1285,340,257,1281,1344,1045]

theorem envBound39326 : H12AffineFastState.Bounded env39326 := by
  intro p hp
  have h : env39326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39325_39326 : H12AffineEnvironment.transform 10 10 env39325 = env39326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env39325 == env39326) = true)

theorem identity39326 : scanCanonicalize (H12AffineFastState.compose env39326 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound39326 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env39327 : List Nat := [2,4,8,16,32,64,128,256,340,321,10,1,72,80,277,114,277,243,321,276,1,477,261,99,193,341,319,325,80,58,68,340,257,64,1,340]

theorem envBound39327 : H12AffineFastState.Bounded env39327 := by
  intro p hp
  have h : env39327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39326_39327 : H12AffineEnvironment.transform 9 321 env39326 = env39327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39326 == env39327) = true)

theorem identity39327 : scanCanonicalize (H12AffineFastState.compose env39327 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound39327 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39328 : List Nat := [2,4,8,16,32,64,128,141,217,204,10,1,72,80,152,114,152,243,204,153,1,80,136,99,193,216,178,200,80,58,68,217,140,64,1,217]

theorem envBound39328 : H12AffineFastState.Bounded env39328 := by
  intro p hp
  have h : env39328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39327_39328 : H12AffineEnvironment.transform 7 141 env39327 = env39328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env39327 == env39328) = true)

theorem identity39328 : scanCanonicalize (H12AffineFastState.compose env39328 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39328 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env39329 : List Nat := [2,2,8,16,32,64,128,139,217,202,10,1,72,80,152,114,152,243,202,153,1,80,136,99,193,216,178,200,80,58,66,217,138,64,1,217]

theorem envBound39329 : H12AffineFastState.Bounded env39329 := by
  intro p hp
  have h : env39329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39328_39329 : H12AffineEnvironment.transform 1 2 env39328 = env39329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39328 == env39329) = true)

theorem identity39329 : scanCanonicalize (H12AffineFastState.compose env39329 (packedSelected [0,1,2,3,7,8,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39329 : packedSelected [0,1,2,3,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env39330 : List Nat := [2,2,8,16,32,64,18,25,75,88,10,1,72,80,10,114,10,97,88,11,1,80,26,99,83,74,32,90,80,58,66,75,24,64,1,75]

theorem envBound39330 : H12AffineFastState.Bounded env39330 := by
  intro p hp
  have h : env39330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39329_39330 : H12AffineEnvironment.transform 6 18 env39329 = env39330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39329 == env39330) = true)

theorem identity39330 : scanCanonicalize (H12AffineFastState.compose env39330 (packedSelected [1,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39330 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env39331 : List Nat := [2,2,8,16,32,1,18,25,10,25,10,1,9,17,10,51,10,32,25,11,1,17,26,34,18,11,32,27,17,58,3,10,24,1,1,10]

theorem envBound39331 : H12AffineFastState.Bounded env39331 := by
  intro p hp
  have h : env39331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39330_39331 : H12AffineEnvironment.transform 5 1 env39330 = env39331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39330 == env39331) = true)

theorem identity39331 : scanCanonicalize (H12AffineFastState.compose env39331 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39331 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env39332 : List Nat := [2,2,8,11,32,1,9,2,10,2,10,1,9,10,10,40,10,32,2,11,1,10,1,34,9,11,32,0,10,33,3,10,3,1,1,10]

theorem envBound39332 : H12AffineFastState.Bounded env39332 := by
  intro p hp
  have h : env39332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39331_39332 : H12AffineEnvironment.transform 3 11 env39331 = env39332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39331 == env39332) = true)

theorem identity39332 : scanCanonicalize (H12AffineFastState.compose env39332 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39333 : List Nat := [2,2,8,11,1,1,9,2,10,2,10,1,9,10,10,9,10,1,2,11,1,10,1,3,9,11,1,0,10,0,3,10,3,1,1,10]

theorem envBound39333 : H12AffineFastState.Bounded env39333 := by
  intro p hp
  have h : env39333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39332_39333 : H12AffineEnvironment.transform 4 1 env39332 = env39333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39332 == env39333) = true)

def env39334 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4096,477,70711,69648,193,65831,4414,69942,1297,67650,5380,65830,257,1281,1344,5141]

theorem envBound39334 : H12AffineFastState.Bounded env39334 := by
  intro p hp
  have h : env39334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39311_39334 : H12AffineEnvironment.transform 8 341 env39311 = env39334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39311 == env39334) = true)

def env39335 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1297,277,65536,65894,65665,320,276,0,477,66615,65552,193,65831,318,65846,1297,67650,1284,65830,257,1281,1344,1045]

theorem envBound39335 : H12AffineFastState.Bounded env39335 := by
  intro p hp
  have h : env39335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39334_39335 : H12AffineEnvironment.transform 11 0 env39334 = env39335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39334 == env39335) = true)

theorem identity39335 : scanCanonicalize (H12AffineFastState.compose env39335 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound39335 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39336 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1297,277,1331,1109,1458,320,276,0,477,260,1315,193,1044,318,1029,1297,3441,1284,1045,257,1281,1344,1045]

theorem envBound39336 : H12AffineFastState.Bounded env39336 := by
  intro p hp
  have h : env39336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39335_39336 : H12AffineEnvironment.transform 15 1331 env39335 = env39336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env39335 == env39336) = true)

theorem identity39336 : scanCanonicalize (H12AffineFastState.compose env39336 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1443) := by decide +kernel

theorem selectedBound39336 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env39337 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1443,0,1288,1297,277,1331,1109,1458,320,276,0,477,260,1315,193,1044,318,1029,1297,210,1284,1045,257,1281,1344,1045]

theorem envBound39337 : H12AffineFastState.Bounded env39337 := by
  intro p hp
  have h : env39337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39336_39337 : H12AffineEnvironment.transform 10 1443 env39336 = env39337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1443 env39336 == env39337) = true)

theorem identity39337 : scanCanonicalize (H12AffineFastState.compose env39337 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39337 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39338 : List Nat := [2,4,8,16,32,64,128,256,341,272,179,0,24,1,277,35,325,162,320,276,0,477,260,51,193,260,318,277,1,210,20,261,257,17,80,261]

theorem envBound39338 : H12AffineFastState.Bounded env39338 := by
  intro p hp
  have h : env39338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39337_39338 : H12AffineEnvironment.transform 9 272 env39337 = env39338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39337 == env39338) = true)

theorem identity39338 : scanCanonicalize (H12AffineFastState.compose env39338 (packedSelected [8,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 57) := by decide +kernel

theorem selectedBound39338 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env39339 : List Nat := [2,4,8,16,32,64,128,57,108,41,179,0,24,1,44,35,124,162,121,45,0,228,61,51,193,61,7,44,1,210,20,60,56,17,80,60]

theorem envBound39339 : H12AffineFastState.Bounded env39339 := by
  intro p hp
  have h : env39339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39338_39339 : H12AffineEnvironment.transform 7 57 env39338 = env39339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 57 env39338 == env39339) = true)

theorem identity39339 : scanCanonicalize (H12AffineFastState.compose env39339 (packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39339 : packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env39340 : List Nat := [2,4,8,16,11,64,128,18,71,2,152,0,24,1,7,8,87,137,82,6,0,207,22,24,193,22,7,7,1,210,20,23,19,17,80,23]

theorem envBound39340 : H12AffineFastState.Bounded env39340 := by
  intro p hp
  have h : env39340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39339_39340 : H12AffineEnvironment.transform 4 11 env39339 = env39340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39339 == env39340) = true)

theorem identity39340 : scanCanonicalize (H12AffineFastState.compose env39340 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound39340 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env39341 : List Nat := [2,4,8,16,11,64,89,18,71,2,65,0,24,1,7,8,87,80,82,6,0,22,22,24,24,22,7,7,1,11,20,23,19,17,80,23]

theorem envBound39341 : H12AffineFastState.Bounded env39341 := by
  intro p hp
  have h : env39341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39340_39341 : H12AffineEnvironment.transform 6 89 env39340 = env39341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env39340 == env39341) = true)

theorem identity39341 : scanCanonicalize (H12AffineFastState.compose env39341 (packedSelected [1,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound39341 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env39342 : List Nat := [2,4,8,16,11,27,2,18,28,2,26,0,24,1,7,8,12,11,9,6,0,22,22,24,24,22,7,7,1,11,20,23,19,17,11,23]

theorem envBound39342 : H12AffineFastState.Bounded env39342 := by
  intro p hp
  have h : env39342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39341_39342 : H12AffineEnvironment.transform 5 27 env39341 = env39342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env39341 == env39342) = true)

theorem identity39342 : scanCanonicalize (H12AffineFastState.compose env39342 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39343 : List Nat := [2,4,8,11,11,0,2,9,7,2,1,0,3,1,7,8,12,11,9,6,0,13,13,3,3,13,7,7,1,11,15,12,8,10,11,12]

theorem envBound39343 : H12AffineFastState.Bounded env39343 := by
  intro p hp
  have h : env39343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39342_39343 : H12AffineEnvironment.transform 3 11 env39342 = env39343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39342 == env39343) = true)

theorem identity39343 : scanCanonicalize (H12AffineFastState.compose env39343 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39343 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env39344 : List Nat := [2,2,8,11,11,0,2,9,1,2,1,0,3,1,1,8,10,11,9,0,0,11,11,3,3,11,1,1,1,11,9,10,8,10,11,10]

theorem envBound39344 : H12AffineFastState.Bounded env39344 := by
  intro p hp
  have h : env39344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39343_39344 : H12AffineEnvironment.transform 1 2 env39343 = env39344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39343 == env39344) = true)

def env39345 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1297,277,65536,65895,65665,321,276,1,477,66614,65553,193,65831,319,65847,1297,67650,1285,65830,257,1281,1344,1044]

theorem envBound39345 : H12AffineFastState.Bounded env39345 := by
  intro p hp
  have h : env39345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39334_39345 : H12AffineEnvironment.transform 11 1 env39334 = env39345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39334 == env39345) = true)

theorem identity39345 : scanCanonicalize (H12AffineFastState.compose env39345 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39345 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39346 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1297,277,114,277,243,321,276,1,477,1092,99,193,341,319,325,1297,2096,1285,340,257,1281,1344,1044]

theorem envBound39346 : H12AffineFastState.Bounded env39346 := by
  intro p hp
  have h : env39346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39345_39346 : H12AffineEnvironment.transform 15 114 env39345 = env39346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39345 == env39346) = true)

theorem identity39346 : scanCanonicalize (H12AffineFastState.compose env39346 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound39346 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env39347 : List Nat := [2,4,8,16,32,64,128,256,341,1024,11,1,1289,1297,277,114,277,243,321,276,1,477,1092,99,193,341,319,325,1297,59,1285,340,257,1281,1344,1044]

theorem envBound39347 : H12AffineFastState.Bounded env39347 := by
  intro p hp
  have h : env39347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39346_39347 : H12AffineEnvironment.transform 10 11 env39346 = env39347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env39346 == env39347) = true)

theorem identity39347 : scanCanonicalize (H12AffineFastState.compose env39347 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound39347 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env39348 : List Nat := [2,4,8,16,32,64,128,256,341,321,11,1,72,80,277,114,277,243,321,276,1,477,261,99,193,341,319,325,80,59,68,340,257,64,1,341]

theorem envBound39348 : H12AffineFastState.Bounded env39348 := by
  intro p hp
  have h : env39348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39347_39348 : H12AffineEnvironment.transform 9 321 env39347 = env39348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39347 == env39348) = true)

theorem identity39348 : scanCanonicalize (H12AffineFastState.compose env39348 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound39348 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39349 : List Nat := [2,4,8,16,32,64,128,140,217,205,11,1,72,80,153,114,153,243,205,152,1,81,137,99,193,217,179,201,80,59,68,216,141,64,1,217]

theorem envBound39349 : H12AffineFastState.Bounded env39349 := by
  intro p hp
  have h : env39349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39348_39349 : H12AffineEnvironment.transform 7 140 env39348 = env39349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env39348 == env39349) = true)

theorem identity39349 : scanCanonicalize (H12AffineFastState.compose env39349 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound39349 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env39350 : List Nat := [2,4,8,16,32,64,30,18,71,83,11,1,72,80,7,114,7,109,83,6,1,81,23,99,95,71,45,87,80,59,68,70,19,64,1,71]

theorem envBound39350 : H12AffineFastState.Bounded env39350 := by
  intro p hp
  have h : env39350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39349_39350 : H12AffineEnvironment.transform 6 30 env39349 = env39350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env39349 == env39350) = true)

theorem identity39350 : scanCanonicalize (H12AffineFastState.compose env39350 (packedSelected [0,1,2,3,7,8,11,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39350 : packedSelected [0,1,2,3,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env39351 : List Nat := [2,4,4,16,32,64,18,18,71,83,7,1,68,80,7,114,7,97,83,6,1,81,23,99,83,71,33,87,80,55,68,70,19,64,1,71]

theorem envBound39351 : H12AffineFastState.Bounded env39351 := by
  intro p hp
  have h : env39351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39350_39351 : H12AffineEnvironment.transform 2 4 env39350 = env39351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39350 == env39351) = true)

theorem identity39351 : scanCanonicalize (H12AffineFastState.compose env39351 (packedSelected [1,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39351 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env39352 : List Nat := [2,4,4,16,32,0,18,18,7,19,7,1,4,16,7,50,7,33,19,6,1,17,23,35,19,7,33,23,16,55,4,6,19,0,1,7]

theorem envBound39352 : H12AffineFastState.Bounded env39352 := by
  intro p hp
  have h : env39352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39351_39352 : H12AffineEnvironment.transform 5 0 env39351 = env39352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39351 == env39352) = true)

theorem identity39352 : scanCanonicalize (H12AffineFastState.compose env39352 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39352 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env39353 : List Nat := [2,4,4,7,32,0,5,5,7,4,7,1,4,7,7,37,7,33,4,6,1,6,0,35,4,7,33,0,7,32,4,6,4,0,1,7]

theorem envBound39353 : H12AffineFastState.Bounded env39353 := by
  intro p hp
  have h : env39353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39352_39353 : H12AffineEnvironment.transform 3 7 env39352 = env39353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39352 == env39353) = true)

theorem identity39353 : scanCanonicalize (H12AffineFastState.compose env39353 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39354 : List Nat := [2,4,4,7,0,0,5,5,7,4,7,1,4,7,7,5,7,1,4,6,1,6,0,3,4,7,1,0,7,0,4,6,4,0,1,7]

theorem envBound39354 : H12AffineFastState.Bounded env39354 := by
  intro p hp
  have h : env39354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39353_39354 : H12AffineEnvironment.transform 4 0 env39353 = env39354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39353 == env39354) = true)

def env39355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123165,533641,614526,385202,90415,545088,96347,25884,594023,257,1281,1344,525824]

theorem envBound39355 : H12AffineFastState.Bounded env39355 := by
  intro p hp
  have h : env39355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38881_39355 : H12AffineEnvironment.transform 23 123165 env38881 = env39355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env38881 == env39355) = true)

def env39356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123165,28889,78894,385202,90415,1296,96347,25884,82999,257,1281,1344,21072]

theorem envBound39356 : H12AffineFastState.Bounded env39356 := by
  intro p hp
  have h : env39356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39355_39356 : H12AffineEnvironment.transform 18 21584 env39355 = env39356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env39355 == env39356) = true)

theorem identity39356 : scanCanonicalize (H12AffineFastState.compose env39356 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound39356 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4096,5277,91182,66897,28889,78894,328958,90415,1296,96347,25884,82999,257,1281,1344,21072]

theorem envBound39357 : H12AffineFastState.Bounded env39357 := by
  intro p hp
  have h : env39357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39356_39357 : H12AffineEnvironment.transform 14 25676 env39356 = env39357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env39356 == env39357) = true)

def env39358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4096,5277,74046,66897,13769,78894,328958,74815,1296,81227,8204,65831,257,1281,1344,5952]

theorem envBound39358 : H12AffineFastState.Bounded env39358 := by
  intro p hp
  have h : env39358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39357_39358 : H12AffineEnvironment.transform 13 1296 env39357 = env39358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39357 == env39358) = true)

def env39359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4096,5277,74046,66897,13769,78894,1150,74815,1296,81227,8204,65831,257,1281,1344,5952]

theorem envBound39359 : H12AffineFastState.Bounded env39359 := by
  intro p hp
  have h : env39359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39358_39359 : H12AffineEnvironment.transform 17 65664 env39358 = env39359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39358 == env39359) = true)

theorem identity39359 : scanCanonicalize (H12AffineFastState.compose env39359 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound39359 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9327,1,9455,4416,8541,4096,5277,1361,8510,13769,4161,1150,80,1296,6436,8204,9544,257,1281,1344,5952]

theorem envBound39360 : H12AffineFastState.Bounded env39360 := by
  intro p hp
  have h : env39360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39359_39360 : H12AffineEnvironment.transform 15 9327 env39359 = env39360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env39359 == env39360) = true)

def env39361 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8495,1,8623,4416,8541,4096,4573,17,8510,12425,4161,318,80,80,6436,8204,8200,257,65,0,4608]

theorem envBound39361 : H12AffineFastState.Bounded env39361 := by
  intro p hp
  have h : env39361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39360_39361 : H12AffineEnvironment.transform 9 320 env39360 = env39361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39360 == env39361) = true)

theorem identity39361 : scanCanonicalize (H12AffineFastState.compose env39361 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound39361 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39362 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,80,324,311,1,439,4416,325,4096,4573,17,294,4241,4161,318,80,80,6436,20,16,257,65,0,4608]

theorem envBound39362 : H12AffineFastState.Bounded env39362 := by
  intro p hp
  have h : env39362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39361_39362 : H12AffineEnvironment.transform 12 24 env39361 = env39362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env39361 == env39362) = true)

theorem identity39362 : scanCanonicalize (H12AffineFastState.compose env39362 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound39362 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env39363 : List Nat := [2,4,8,16,32,64,128,256,512,320,950,4096,24,80,324,311,1,439,4416,325,4096,4573,17,294,4241,4161,318,80,80,4754,20,16,257,65,0,4608]

theorem envBound39363 : H12AffineFastState.Bounded env39363 := by
  intro p hp
  have h : env39363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39362_39363 : H12AffineEnvironment.transform 10 950 env39362 = env39363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env39362 == env39363) = true)

theorem identity39363 : scanCanonicalize (H12AffineFastState.compose env39363 (packedSelected [0,2,7,8,10,12,15,16,17,18,28,32] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound39363 : packedSelected [0,2,7,8,10,12,15,16,17,18,28,32] rootPS < 2^1333 := by decide +kernel

def env39364 : List Nat := [2,4,8,16,32,64,128,256,49,320,391,4096,24,80,324,311,1,439,4416,325,4096,4573,17,294,4241,4161,318,80,80,4259,20,16,257,65,0,4145]

theorem envBound39364 : H12AffineFastState.Bounded env39364 := by
  intro p hp
  have h : env39364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39363_39364 : H12AffineEnvironment.transform 8 49 env39363 = env39364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39363 == env39364) = true)

theorem identity39364 : scanCanonicalize (H12AffineFastState.compose env39364 (packedSelected [1,2,3,11,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound39364 : packedSelected [1,2,3,11,17,18] rootPS < 2^1333 := by decide +kernel

def env39365 : List Nat := [2,4,8,16,32,64,128,256,49,320,391,508,24,80,324,311,1,439,188,325,508,33,17,294,365,445,318,80,80,351,20,16,257,65,0,461]

theorem envBound39365 : H12AffineFastState.Bounded env39365 := by
  intro p hp
  have h : env39365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39364_39365 : H12AffineEnvironment.transform 11 508 env39364 = env39365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env39364 == env39365) = true)

theorem identity39365 : scanCanonicalize (H12AffineFastState.compose env39365 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound39365 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env39366 : List Nat := [2,4,8,16,32,64,104,256,49,320,367,276,24,80,324,311,1,351,84,325,276,33,17,294,365,341,318,80,80,351,20,16,257,65,0,293]

theorem envBound39366 : H12AffineFastState.Bounded env39366 := by
  intro p hp
  have h : env39366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39365_39366 : H12AffineEnvironment.transform 6 104 env39365 = env39366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env39365 == env39366) = true)

theorem identity39366 : scanCanonicalize (H12AffineFastState.compose env39366 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39366 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env39367 : List Nat := [2,4,8,16,32,64,104,36,49,100,75,48,24,80,96,19,1,123,84,97,48,33,17,2,73,113,26,80,80,123,20,16,37,65,0,1]

theorem envBound39367 : H12AffineFastState.Bounded env39367 := by
  intro p hp
  have h : env39367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39366_39367 : H12AffineEnvironment.transform 7 36 env39366 = env39367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39366 == env39367) = true)

theorem identity39367 : scanCanonicalize (H12AffineFastState.compose env39367 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound39367 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39368 : List Nat := [2,4,8,16,32,11,35,36,49,47,0,48,24,27,43,19,1,48,31,42,48,33,17,2,2,58,26,27,27,48,20,16,37,10,0,1]

theorem envBound39368 : H12AffineFastState.Bounded env39368 := by
  intro p hp
  have h : env39368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39367_39368 : H12AffineEnvironment.transform 5 11 env39367 = env39368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env39367 == env39368) = true)

theorem identity39368 : scanCanonicalize (H12AffineFastState.compose env39368 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39369 : List Nat := [2,4,8,16,16,11,19,20,1,31,0,0,24,27,27,19,1,0,31,26,0,17,17,2,2,10,26,27,27,0,20,16,21,10,0,1]

theorem envBound39369 : H12AffineFastState.Bounded env39369 := by
  intro p hp
  have h : env39369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39368_39369 : H12AffineEnvironment.transform 4 16 env39368 = env39369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39368 == env39369) = true)

theorem identity39369 : scanCanonicalize (H12AffineFastState.compose env39369 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39369 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env39370 : List Nat := [2,4,8,10,10,11,9,14,1,5,0,0,2,1,1,9,1,0,5,0,0,11,11,2,2,10,0,1,1,0,14,10,15,10,0,1]

theorem envBound39370 : H12AffineFastState.Bounded env39370 := by
  intro p hp
  have h : env39370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39369_39370 : H12AffineEnvironment.transform 3 10 env39369 = env39370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39369 == env39370) = true)

theorem identity39370 : scanCanonicalize (H12AffineFastState.compose env39370 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39371 : List Nat := [2,4,4,6,6,7,5,2,1,5,0,0,2,1,1,5,1,0,5,0,0,7,7,2,2,6,0,1,1,0,2,6,3,6,0,1]

theorem envBound39371 : H12AffineFastState.Bounded env39371 := by
  intro p hp
  have h : env39371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39370_39371 : H12AffineEnvironment.transform 2 4 env39370 = env39371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39370 == env39371) = true)

def env39372 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8494,1,8622,4416,8541,4096,4572,16,8510,12424,4161,319,80,81,6436,8204,8201,257,64,1,4609]

theorem envBound39372 : H12AffineFastState.Bounded env39372 := by
  intro p hp
  have h : env39372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39360_39372 : H12AffineEnvironment.transform 9 321 env39360 = env39372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39360 == env39372) = true)

theorem identity39372 : scanCanonicalize (H12AffineFastState.compose env39372 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39372 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39373 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,8192,81,8216,8298,1,8426,4100,8217,4096,4248,16,8314,12424,4161,123,80,81,6240,8204,8201,69,64,1,4609]

theorem envBound39373 : H12AffineFastState.Bounded env39373 := by
  intro p hp
  have h : env39373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39372_39373 : H12AffineEnvironment.transform 7 68 env39372 = env39373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39372 == env39373) = true)

theorem identity39373 : scanCanonicalize (H12AffineFastState.compose env39373 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound39373 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39374 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,81,8216,8298,1,8426,5,8217,1,153,16,8314,8329,64,123,80,81,2145,8204,8201,69,64,1,512]

theorem envBound39374 : H12AffineFastState.Bounded env39374 := by
  intro p hp
  have h : env39374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39373_39374 : H12AffineEnvironment.transform 11 1 env39373 = env39374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39373 == env39374) = true)

theorem identity39374 : scanCanonicalize (H12AffineFastState.compose env39374 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound39374 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39375 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,241,81,233,155,1,27,5,232,1,153,16,139,120,64,123,80,81,2145,253,248,69,64,1,512]

theorem envBound39375 : H12AffineFastState.Bounded env39375 := by
  intro p hp
  have h : env39375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39374_39375 : H12AffineEnvironment.transform 12 241 env39374 = env39375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env39374 == env39375) = true)

theorem identity39375 : scanCanonicalize (H12AffineFastState.compose env39375 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound39375 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39376 : List Nat := [2,4,8,16,32,64,128,68,137,5,2048,1,241,81,233,155,1,27,5,232,1,153,16,139,120,64,123,80,81,2145,253,248,69,64,1,137]

theorem envBound39376 : H12AffineFastState.Bounded env39376 := by
  intro p hp
  have h : env39376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39375_39376 : H12AffineEnvironment.transform 8 137 env39375 = env39376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env39375 == env39376) = true)

theorem identity39376 : scanCanonicalize (H12AffineFastState.compose env39376 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound39376 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env39377 : List Nat := [2,4,8,16,32,64,128,68,137,5,195,1,241,81,233,155,1,27,5,232,1,153,16,139,120,64,123,80,81,162,253,248,69,64,1,137]

theorem envBound39377 : H12AffineFastState.Bounded env39377 := by
  intro p hp
  have h : env39377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39376_39377 : H12AffineEnvironment.transform 10 195 env39376 = env39377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env39376 == env39377) = true)

theorem identity39377 : scanCanonicalize (H12AffineFastState.compose env39377 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound39377 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env39378 : List Nat := [2,4,8,16,32,64,105,68,96,5,42,1,24,81,0,114,1,27,5,1,1,112,16,98,120,64,123,80,81,75,20,17,69,64,1,96]

theorem envBound39378 : H12AffineFastState.Bounded env39378 := by
  intro p hp
  have h : env39378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39377_39378 : H12AffineEnvironment.transform 6 105 env39377 = env39378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env39377 == env39378) = true)

def env39379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4096,5277,74046,66897,13769,78894,1151,74815,1296,81227,8204,65831,257,1281,1344,5952]

theorem envBound39379 : H12AffineFastState.Bounded env39379 := by
  intro p hp
  have h : env39379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39358_39379 : H12AffineEnvironment.transform 17 65665 env39358 = env39379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39358 == env39379) = true)

theorem identity39379 : scanCanonicalize (H12AffineFastState.compose env39379 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound39379 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12590,5440,12719,4416,8541,4096,5277,4112,13439,13769,1280,1151,5393,1296,3173,8204,12297,257,1281,1344,5952]

theorem envBound39380 : H12AffineFastState.Bounded env39380 := by
  intro p hp
  have h : env39380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39379_39380 : H12AffineEnvironment.transform 15 12590 env39379 = env39380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env39379 == env39380) = true)

def env39381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8494,1344,8623,320,8541,0,1181,16,9343,9673,1280,1151,1297,1296,3173,8204,8201,257,1281,1344,1856]

theorem envBound39381 : H12AffineFastState.Bounded env39381 := by
  intro p hp
  have h : env39381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39380_39381 : H12AffineEnvironment.transform 11 0 env39380 = env39381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39380 == env39381) = true)

theorem identity39381 : scanCanonicalize (H12AffineFastState.compose env39381 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39381 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39382 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,277,8540,8494,325,8623,320,8541,0,152,16,8314,8652,261,122,276,277,2144,8204,8201,257,260,325,837]

theorem envBound39382 : H12AffineFastState.Bounded env39382 := by
  intro p hp
  have h : env39382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39381_39382 : H12AffineEnvironment.transform 9 5 env39381 = env39382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39381 == env39382) = true)

theorem identity39382 : scanCanonicalize (H12AffineFastState.compose env39382 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39382 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39383 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,80,8217,8299,0,8426,5,8216,0,152,16,8314,8329,64,122,81,80,2144,8204,8201,68,65,0,512]

theorem envBound39383 : H12AffineFastState.Bounded env39383 := by
  intro p hp
  have h : env39383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39382_39383 : H12AffineEnvironment.transform 7 69 env39382 = env39383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39382 == env39383) = true)

theorem identity39383 : scanCanonicalize (H12AffineFastState.compose env39383 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2146) := by decide +kernel

theorem selectedBound39383 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39384 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,2146,80,2171,2057,0,2184,5,2170,0,152,16,2072,2283,64,122,81,80,2144,2158,2155,68,65,0,512]

theorem envBound39384 : H12AffineFastState.Bounded env39384 := by
  intro p hp
  have h : env39384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39383_39384 : H12AffineEnvironment.transform 12 2146 env39383 = env39384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2146 env39383 == env39384) = true)

theorem identity39384 : scanCanonicalize (H12AffineFastState.compose env39384 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound39384 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env39385 : List Nat := [2,4,8,16,32,64,104,69,512,5,2048,0,2146,80,2171,2057,0,2144,5,2170,0,112,16,2072,2051,64,122,81,80,2144,2158,2155,68,65,0,512]

theorem envBound39385 : H12AffineFastState.Bounded env39385 := by
  intro p hp
  have h : env39385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39384_39385 : H12AffineEnvironment.transform 6 104 env39384 = env39385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env39384 == env39385) = true)

theorem identity39385 : scanCanonicalize (H12AffineFastState.compose env39385 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound39385 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39386 : List Nat := [2,4,8,16,32,64,104,69,42,5,2048,0,2146,80,2171,2057,0,2144,5,2170,0,112,16,2072,2051,64,122,81,80,2144,2158,2155,68,65,0,42]

theorem envBound39386 : H12AffineFastState.Bounded env39386 := by
  intro p hp
  have h : env39386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39385_39386 : H12AffineEnvironment.transform 8 42 env39385 = env39386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env39385 == env39386) = true)

theorem identity39386 : scanCanonicalize (H12AffineFastState.compose env39386 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39386 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39387 : List Nat := [2,4,8,16,32,64,104,69,42,5,49,0,83,80,74,56,0,81,5,75,0,112,16,41,50,64,122,81,80,81,95,90,68,65,0,42]

theorem envBound39387 : H12AffineFastState.Bounded env39387 := by
  intro p hp
  have h : env39387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39386_39387 : H12AffineEnvironment.transform 10 49 env39386 = env39387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39386 == env39387) = true)

theorem identity39387 : scanCanonicalize (H12AffineFastState.compose env39387 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39387 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39388 : List Nat := [2,4,8,16,32,59,19,62,42,5,49,0,40,43,49,56,0,42,5,48,0,11,16,41,50,59,1,42,43,42,36,33,63,58,0,42]

theorem envBound39388 : H12AffineFastState.Bounded env39388 := by
  intro p hp
  have h : env39388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39387_39388 : H12AffineEnvironment.transform 5 59 env39387 = env39388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39387 == env39388) = true)

def env39389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8495,1345,8622,321,8541,1,1180,17,9342,9672,1280,1151,1296,1296,3173,8204,8200,257,1281,1344,1857]

theorem envBound39389 : H12AffineFastState.Bounded env39389 := by
  intro p hp
  have h : env39389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39380_39389 : H12AffineEnvironment.transform 11 1 env39380 = env39389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39380 == env39389) = true)

theorem identity39389 : scanCanonicalize (H12AffineFastState.compose env39389 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound39389 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1296,1028,1143,1345,1270,321,1029,1,1180,17,294,144,1280,1151,1296,1296,3173,1364,1360,257,1281,1344,1857]

theorem envBound39390 : H12AffineFastState.Bounded env39390 := by
  intro p hp
  have h : env39390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39389_39390 : H12AffineEnvironment.transform 12 1368 env39389 = env39390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env39389 == env39390) = true)

theorem identity39390 : scanCanonicalize (H12AffineFastState.compose env39390 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound39390 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env39391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,1,1368,1296,1028,1143,1345,1270,321,1029,1,1180,17,294,144,1280,1151,1296,1296,658,1364,1360,257,1281,1344,1857]

theorem envBound39391 : H12AffineFastState.Bounded env39391 := by
  intro p hp
  have h : env39391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39390_39391 : H12AffineEnvironment.transform 10 1783 env39390 = env39391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env39390 == env39391) = true)

def env39392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4096,5277,74047,66897,13768,78894,328958,74814,1296,81226,8205,65830,257,1281,1344,5953]

theorem envBound39392 : H12AffineFastState.Bounded env39392 := by
  intro p hp
  have h : env39392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39357_39392 : H12AffineEnvironment.transform 13 1297 env39357 = env39392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39357 == env39392) = true)

def env39393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4096,5277,74047,66897,13768,78894,1150,74814,1296,81226,8205,65830,257,1281,1344,5953]

theorem envBound39393 : H12AffineFastState.Bounded env39393 := by
  intro p hp
  have h : env39393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39392_39393 : H12AffineEnvironment.transform 17 65664 env39392 = env39393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39392 == env39393) = true)

theorem identity39393 : scanCanonicalize (H12AffineFastState.compose env39393 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound39393 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5158,12360,5286,4417,8540,4096,5277,13593,4471,13768,8200,1150,12312,1296,10604,8205,5376,257,1281,1344,5953]

theorem envBound39394 : H12AffineFastState.Bounded env39394 := by
  intro p hp
  have h : env39394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39393_39394 : H12AffineEnvironment.transform 15 5158 env39393 = env39394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env39393 == env39394) = true)

def env39395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5158,1344,5286,4417,5204,4096,5277,17,4471,192,5376,1150,1296,1296,7268,5381,5376,257,1281,1344,5953]

theorem envBound39395 : H12AffineFastState.Bounded env39395 := by
  intro p hp
  have h : env39395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39394_39395 : H12AffineEnvironment.transform 12 5384 env39394 = env39395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env39394 == env39395) = true)

theorem identity39395 : scanCanonicalize (H12AffineFastState.compose env39395 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound39395 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1100,1297,1297,1378,1344,1506,5,1296,324,1497,17,51,192,1092,1150,1296,1296,3360,1089,1092,257,1281,1344,1541]

theorem envBound39396 : H12AffineFastState.Bounded env39396 := by
  intro p hp
  have h : env39396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39395_39396 : H12AffineEnvironment.transform 11 324 env39395 = env39396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env39395 == env39396) = true)

theorem identity39396 : scanCanonicalize (H12AffineFastState.compose env39396 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39396 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39397 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,73,276,276,359,325,487,5,277,324,476,17,51,192,65,123,277,277,2341,68,65,257,260,325,512]

theorem envBound39397 : H12AffineFastState.Bounded env39397 := by
  intro p hp
  have h : env39397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39396_39397 : H12AffineEnvironment.transform 9 5 env39396 = env39397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39396 == env39397) = true)

theorem identity39397 : scanCanonicalize (H12AffineFastState.compose env39397 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39397 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39398 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,24,276,276,310,276,438,5,277,277,397,17,51,145,16,42,277,277,2341,21,16,257,260,276,512]

theorem envBound39398 : H12AffineFastState.Bounded env39398 := by
  intro p hp
  have h : env39398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39397_39398 : H12AffineEnvironment.transform 5 17 env39397 = env39398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39397 == env39398) = true)

theorem identity39398 : scanCanonicalize (H12AffineFastState.compose env39398 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound39398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39399 : List Nat := [2,4,8,16,32,17,128,256,512,5,561,277,24,276,276,310,276,438,5,277,277,397,17,51,145,16,42,277,277,788,21,16,257,260,276,512]

theorem envBound39399 : H12AffineFastState.Bounded env39399 := by
  intro p hp
  have h : env39399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39398_39399 : H12AffineEnvironment.transform 10 561 env39398 = env39399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env39398 == env39399) = true)

theorem identity39399 : scanCanonicalize (H12AffineFastState.compose env39399 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound39399 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39400 : List Nat := [2,4,8,16,32,17,128,256,48,5,1,277,24,276,276,310,276,438,5,277,277,397,17,51,145,16,42,277,277,292,21,16,257,260,276,48]

theorem envBound39400 : H12AffineFastState.Bounded env39400 := by
  intro p hp
  have h : env39400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39399_39400 : H12AffineEnvironment.transform 8 48 env39399 = env39400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39399 == env39400) = true)

theorem identity39400 : scanCanonicalize (H12AffineFastState.compose env39400 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound39400 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env39401 : List Nat := [2,4,8,16,32,17,128,14,48,5,1,27,24,26,26,56,26,184,5,27,27,131,17,51,145,16,42,27,27,42,21,16,15,10,26,48]

theorem envBound39401 : H12AffineFastState.Bounded env39401 := by
  intro p hp
  have h : env39401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39400_39401 : H12AffineEnvironment.transform 7 14 env39400 = env39401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env39400 == env39401) = true)

theorem identity39401 : scanCanonicalize (H12AffineFastState.compose env39401 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39401 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39402 : List Nat := [2,4,8,16,32,17,18,14,48,5,1,27,24,26,26,56,26,42,5,27,27,17,17,51,3,16,42,27,27,42,21,16,15,10,26,48]

theorem envBound39402 : H12AffineFastState.Bounded env39402 := by
  intro p hp
  have h : env39402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39401_39402 : H12AffineEnvironment.transform 6 18 env39401 = env39402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39401 == env39402) = true)

theorem identity39402 : scanCanonicalize (H12AffineFastState.compose env39402 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39402 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39403 : List Nat := [2,4,8,11,32,10,9,14,43,5,1,0,3,1,1,35,1,42,5,0,0,10,10,40,3,11,42,0,0,42,14,11,15,10,1,43]

theorem envBound39403 : H12AffineFastState.Bounded env39403 := by
  intro p hp
  have h : env39403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39402_39403 : H12AffineEnvironment.transform 3 11 env39402 = env39403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39402 == env39403) = true)

theorem identity39403 : scanCanonicalize (H12AffineFastState.compose env39403 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39404 : List Nat := [2,2,8,11,32,10,9,8,43,3,1,0,3,1,1,35,1,42,3,0,0,10,10,40,3,11,42,0,0,42,8,11,9,10,1,43]

theorem envBound39404 : H12AffineFastState.Bounded env39404 := by
  intro p hp
  have h : env39404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39403_39404 : H12AffineEnvironment.transform 1 2 env39403 = env39404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39403 == env39404) = true)

theorem identity39404 : scanCanonicalize (H12AffineFastState.compose env39404 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39404 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39405 : List Nat := [2,2,8,11,10,10,9,8,1,3,1,0,3,1,1,9,1,0,3,0,0,10,10,2,3,11,0,0,0,0,8,11,9,10,1,1]

theorem envBound39405 : H12AffineFastState.Bounded env39405 := by
  intro p hp
  have h : env39405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39404_39405 : H12AffineEnvironment.transform 4 10 env39404 = env39405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39404 == env39405) = true)

def env39406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5158,1345,5286,4417,5205,4096,5277,16,4471,193,5377,1150,1297,1296,7269,5380,5376,257,1281,1344,5953]

theorem envBound39406 : H12AffineFastState.Bounded env39406 := by
  intro p hp
  have h : env39406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39394_39406 : H12AffineEnvironment.transform 12 5385 env39394 = env39406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env39394 == env39406) = true)

theorem identity39406 : scanCanonicalize (H12AffineFastState.compose env39406 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39406 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39407 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,0,4421,4407,80,4535,4417,4420,4096,4492,16,4471,193,4112,367,0,1,6516,4117,4113,257,16,81,4688]

theorem envBound39407 : H12AffineFastState.Bounded env39407 := by
  intro p hp
  have h : env39407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39406_39407 : H12AffineEnvironment.transform 9 273 env39406 = env39407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39406 == env39407) = true)

theorem identity39407 : scanCanonicalize (H12AffineFastState.compose env39407 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound39407 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env39408 : List Nat := [2,4,8,16,32,64,128,256,460,273,2048,4096,4120,0,4421,4407,80,4535,4417,4420,4096,4492,16,4471,193,4112,367,0,1,6516,4117,4113,257,16,81,4508]

theorem envBound39408 : H12AffineFastState.Bounded env39408 := by
  intro p hp
  have h : env39408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39407_39408 : H12AffineEnvironment.transform 8 460 env39407 = env39408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env39407 == env39408) = true)

theorem identity39408 : scanCanonicalize (H12AffineFastState.compose env39408 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39408 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env39409 : List Nat := [2,4,8,16,32,64,128,68,136,85,2048,4096,4120,0,4097,4211,80,4339,4101,4096,4096,4296,16,4147,193,4112,43,0,1,6192,4117,4113,69,16,81,4312]

theorem envBound39409 : H12AffineFastState.Bounded env39409 := by
  intro p hp
  have h : env39409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39408_39409 : H12AffineEnvironment.transform 7 68 env39408 = env39409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39408 == env39409) = true)

theorem identity39409 : scanCanonicalize (H12AffineFastState.compose env39409 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound39409 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env39410 : List Nat := [2,4,8,16,32,64,114,68,122,85,2048,4096,4120,0,4097,4211,80,4097,4101,4096,4096,4154,16,4147,51,4112,43,0,1,6192,4117,4113,69,16,81,4138]

theorem envBound39410 : H12AffineFastState.Bounded env39410 := by
  intro p hp
  have h : env39410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39409_39410 : H12AffineEnvironment.transform 6 114 env39409 = env39410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env39409 == env39410) = true)

theorem identity39410 : scanCanonicalize (H12AffineFastState.compose env39410 (packedSelected [10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound39410 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env39411 : List Nat := [2,4,8,16,32,64,114,68,122,85,2048,2097,2089,0,2096,2114,80,2096,2100,2097,2097,2059,16,2050,51,2081,43,0,1,1,2084,2080,69,16,81,2075]

theorem envBound39411 : H12AffineFastState.Bounded env39411 := by
  intro p hp
  have h : env39411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39410_39411 : H12AffineEnvironment.transform 11 2097 env39410 = env39411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env39410 == env39411) = true)

theorem identity39411 : scanCanonicalize (H12AffineFastState.compose env39411 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound39411 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env39412 : List Nat := [2,4,8,16,32,64,114,68,122,85,42,27,3,0,26,104,80,26,30,27,27,33,16,40,51,11,43,0,1,1,14,10,69,16,81,49]

theorem envBound39412 : H12AffineFastState.Bounded env39412 := by
  intro p hp
  have h : env39412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39411_39412 : H12AffineEnvironment.transform 10 42 env39411 = env39412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env39411 == env39412) = true)

theorem identity39412 : scanCanonicalize (H12AffineFastState.compose env39412 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39412 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39413 : List Nat := [2,4,8,16,32,16,34,20,42,5,42,27,3,0,26,56,0,26,30,27,27,33,16,40,51,11,43,0,1,1,14,10,21,16,1,49]

theorem envBound39413 : H12AffineFastState.Bounded env39413 := by
  intro p hp
  have h : env39413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39412_39413 : H12AffineEnvironment.transform 5 16 env39412 = env39413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39412 == env39413) = true)

theorem identity39413 : scanCanonicalize (H12AffineFastState.compose env39413 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39413 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39414 : List Nat := [2,4,8,10,32,10,34,14,42,5,42,1,3,0,0,34,0,0,4,1,1,33,10,40,41,11,43,0,1,1,14,10,15,10,1,43]

theorem envBound39414 : H12AffineFastState.Bounded env39414 := by
  intro p hp
  have h : env39414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39413_39414 : H12AffineEnvironment.transform 3 10 env39413 = env39414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39413 == env39414) = true)

theorem identity39414 : scanCanonicalize (H12AffineFastState.compose env39414 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39415 : List Nat := [2,0,8,10,32,10,34,10,42,1,42,1,3,0,0,34,0,0,0,1,1,33,10,40,41,11,43,0,1,1,10,10,11,10,1,43]

theorem envBound39415 : H12AffineFastState.Bounded env39415 := by
  intro p hp
  have h : env39415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39414_39415 : H12AffineEnvironment.transform 1 0 env39414 = env39415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39414 == env39415) = true)

theorem identity39415 : scanCanonicalize (H12AffineFastState.compose env39415 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound39415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39416 : List Nat := [2,0,8,10,2,10,0,10,8,1,8,1,3,0,0,0,0,0,0,1,1,3,10,10,11,11,9,0,1,1,10,10,11,10,1,9]

theorem envBound39416 : H12AffineFastState.Bounded env39416 := by
  intro p hp
  have h : env39416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39415_39416 : H12AffineEnvironment.transform 4 2 env39415 = env39416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env39415 == env39416) = true)

theorem identity39416 : scanCanonicalize (H12AffineFastState.compose env39416 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39417 : List Nat := [2,0,0,2,2,2,0,2,0,1,0,1,3,0,0,0,0,0,0,1,1,3,2,2,3,3,1,0,1,1,2,2,3,2,1,1]

theorem envBound39417 : H12AffineFastState.Bounded env39417 := by
  intro p hp
  have h : env39417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39416_39417 : H12AffineEnvironment.transform 2 0 env39416 = env39417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39416 == env39417) = true)

theorem identity39417 : scanCanonicalize (H12AffineFastState.compose env39417 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39417 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39418 : List Nat := [0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,1,1,0,0,1,1,1,0,1,1,0,0,1,0,1,1]

theorem envBound39418 : H12AffineFastState.Bounded env39418 := by
  intro p hp
  have h : env39418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39417_39418 : H12AffineEnvironment.transform 0 0 env39417 = env39418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39417 == env39418) = true)

def env39419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4096,5277,74047,66897,13768,78894,1151,74814,1296,81226,8205,65830,257,1281,1344,5953]

theorem envBound39419 : H12AffineFastState.Bounded env39419 := by
  intro p hp
  have h : env39419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39392_39419 : H12AffineEnvironment.transform 17 65665 env39392 = env39419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39392 == env39419) = true)

theorem identity39419 : scanCanonicalize (H12AffineFastState.compose env39419 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound39419 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,358,9480,487,4417,8540,4096,5277,8281,1079,13768,13640,1151,9560,1296,15404,8205,64,257,1281,1344,5953]

theorem envBound39420 : H12AffineFastState.Bounded env39420 := by
  intro p hp
  have h : env39420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39419_39420 : H12AffineEnvironment.transform 15 358 env39419 = env39420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env39419 == env39420) = true)

def env39421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,358,1344,487,4417,276,4096,5277,17,1079,5504,5376,1151,1296,1296,7268,69,64,257,1281,1344,5953]

theorem envBound39421 : H12AffineFastState.Bounded env39421 := by
  intro p hp
  have h : env39421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39420_39421 : H12AffineEnvironment.transform 12 72 env39420 = env39421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env39420 == env39421) = true)

theorem identity39421 : scanCanonicalize (H12AffineFastState.compose env39421 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound39421 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,72,1297,277,358,1344,487,5,276,324,1497,17,1079,1220,1092,1151,1296,1296,3360,69,64,257,1281,1344,1541]

theorem envBound39422 : H12AffineFastState.Bounded env39422 := by
  intro p hp
  have h : env39422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39421_39422 : H12AffineEnvironment.transform 11 324 env39421 = env39422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env39421 == env39422) = true)

theorem identity39422 : scanCanonicalize (H12AffineFastState.compose env39422 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39422 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39423 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,276,277,358,325,487,5,276,324,476,17,50,193,65,122,277,277,2341,69,64,257,260,325,512]

theorem envBound39423 : H12AffineFastState.Bounded env39423 := by
  intro p hp
  have h : env39423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39422_39423 : H12AffineEnvironment.transform 9 5 env39422 = env39423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39422 == env39423) = true)

theorem identity39423 : scanCanonicalize (H12AffineFastState.compose env39423 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39423 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39424 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,25,276,277,311,276,438,5,276,277,397,17,50,144,16,43,277,277,2341,20,17,257,260,276,512]

theorem envBound39424 : H12AffineFastState.Bounded env39424 := by
  intro p hp
  have h : env39424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39423_39424 : H12AffineEnvironment.transform 5 17 env39423 = env39424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39423 == env39424) = true)

theorem identity39424 : scanCanonicalize (H12AffineFastState.compose env39424 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound39424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39425 : List Nat := [2,4,8,16,32,17,128,256,512,5,561,277,25,276,277,311,276,438,5,276,277,397,17,50,144,16,43,277,277,788,20,17,257,260,276,512]

theorem envBound39425 : H12AffineFastState.Bounded env39425 := by
  intro p hp
  have h : env39425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39424_39425 : H12AffineEnvironment.transform 10 561 env39424 = env39425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env39424 == env39425) = true)

theorem identity39425 : scanCanonicalize (H12AffineFastState.compose env39425 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound39425 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39426 : List Nat := [2,4,8,16,32,17,128,256,137,5,184,277,25,276,277,311,276,438,5,276,277,397,17,50,144,16,43,277,277,413,20,17,257,260,276,137]

theorem envBound39426 : H12AffineFastState.Bounded env39426 := by
  intro p hp
  have h : env39426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39425_39426 : H12AffineEnvironment.transform 8 137 env39425 = env39426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env39425 == env39426) = true)

theorem identity39426 : scanCanonicalize (H12AffineFastState.compose env39426 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39426 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39427 : List Nat := [2,4,8,16,32,17,128,20,137,5,184,1,25,0,1,35,0,162,5,0,1,153,17,50,144,16,43,1,1,137,20,17,21,16,0,137]

theorem envBound39427 : H12AffineFastState.Bounded env39427 := by
  intro p hp
  have h : env39427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39426_39427 : H12AffineEnvironment.transform 7 20 env39426 = env39427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39426 == env39427) = true)

theorem identity39427 : scanCanonicalize (H12AffineFastState.compose env39427 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound39427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39428 : List Nat := [2,4,8,16,32,17,20,20,29,5,44,1,25,0,1,35,0,54,5,0,1,13,17,50,4,16,43,1,1,29,20,17,21,16,0,29]

theorem envBound39428 : H12AffineFastState.Bounded env39428 := by
  intro p hp
  have h : env39428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39427_39428 : H12AffineEnvironment.transform 6 20 env39427 = env39428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env39427 == env39428) = true)

theorem identity39428 : scanCanonicalize (H12AffineFastState.compose env39428 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound39428 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39429 : List Nat := [2,4,8,16,22,17,20,20,29,5,26,1,25,0,1,21,0,0,5,0,1,13,17,4,4,16,29,1,1,29,20,17,21,16,0,29]

theorem envBound39429 : H12AffineFastState.Bounded env39429 := by
  intro p hp
  have h : env39429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39428_39429 : H12AffineEnvironment.transform 4 22 env39428 = env39429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env39428 == env39429) = true)

theorem identity39429 : scanCanonicalize (H12AffineFastState.compose env39429 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39429 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39430 : List Nat := [2,3,8,16,17,17,19,19,26,2,26,1,25,0,1,18,0,0,2,0,1,10,17,3,3,16,26,1,1,26,19,17,18,16,0,26]

theorem envBound39430 : H12AffineFastState.Bounded env39430 := by
  intro p hp
  have h : env39430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39429_39430 : H12AffineEnvironment.transform 1 3 env39429 = env39430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39429 == env39430) = true)

def env39431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,358,1345,487,4417,277,4096,5277,16,1079,5505,5377,1151,1297,1296,7269,68,64,257,1281,1344,5953]

theorem envBound39431 : H12AffineFastState.Bounded env39431 := by
  intro p hp
  have h : env39431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39420_39431 : H12AffineEnvironment.transform 12 73 env39420 = env39431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env39420 == env39431) = true)

theorem identity39431 : scanCanonicalize (H12AffineFastState.compose env39431 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound39431 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1297,276,358,1345,487,272,277,81,1228,16,1079,1488,1360,1151,1297,1296,3124,68,64,257,1281,1344,1808]

theorem envBound39432 : H12AffineFastState.Bounded env39432 := by
  intro p hp
  have h : env39432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39431_39432 : H12AffineEnvironment.transform 11 81 env39431 = env39432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env39431 == env39432) = true)

theorem identity39432 : scanCanonicalize (H12AffineFastState.compose env39432 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 733) := by decide +kernel

theorem selectedBound39432 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env39433 : List Nat := [2,4,8,16,32,64,128,256,512,733,2048,81,73,972,276,358,924,487,272,277,81,529,16,746,781,909,674,972,973,2793,68,64,257,988,925,461]

theorem envBound39433 : H12AffineFastState.Bounded env39433 := by
  intro p hp
  have h : env39433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39432_39433 : H12AffineEnvironment.transform 9 733 env39432 = env39433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 733 env39432 == env39433) = true)

theorem identity39433 : scanCanonicalize (H12AffineFastState.compose env39433 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound39433 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env39434 : List Nat := [2,4,8,16,32,64,128,256,136,85,2048,81,73,324,276,358,276,487,272,277,81,153,16,98,389,261,42,324,325,2145,68,64,257,340,277,461]

theorem envBound39434 : H12AffineFastState.Bounded env39434 := by
  intro p hp
  have h : env39434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39433_39434 : H12AffineEnvironment.transform 8 136 env39433 = env39434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env39433 == env39434) = true)

theorem identity39434 : scanCanonicalize (H12AffineFastState.compose env39434 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 413) := by decide +kernel

theorem selectedBound39434 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env39435 : List Nat := [2,4,8,16,32,64,128,256,136,85,413,81,73,324,276,358,276,487,272,277,81,153,16,98,389,261,42,324,325,508,68,64,257,340,277,461]

theorem envBound39435 : H12AffineFastState.Bounded env39435 := by
  intro p hp
  have h : env39435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39434_39435 : H12AffineEnvironment.transform 10 413 env39434 = env39435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env39434 == env39435) = true)

theorem identity39435 : scanCanonicalize (H12AffineFastState.compose env39435 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39435 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env39436 : List Nat := [2,4,8,16,32,64,128,20,136,85,137,81,73,80,0,114,0,243,4,1,81,153,16,98,145,17,42,80,81,232,68,64,21,64,1,217]

theorem envBound39436 : H12AffineFastState.Bounded env39436 := by
  intro p hp
  have h : env39436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39435_39436 : H12AffineEnvironment.transform 7 20 env39435 = env39436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39435 == env39436) = true)

theorem identity39436 : scanCanonicalize (H12AffineFastState.compose env39436 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound39436 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39437 : List Nat := [2,4,8,16,32,32,128,20,136,53,137,49,41,48,0,18,0,147,4,1,49,153,16,2,145,17,42,48,49,136,36,32,21,32,1,185]

theorem envBound39437 : H12AffineFastState.Bounded env39437 := by
  intro p hp
  have h : env39437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39436_39437 : H12AffineEnvironment.transform 5 32 env39436 = env39437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env39436 == env39437) = true)

theorem identity39437 : scanCanonicalize (H12AffineFastState.compose env39437 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound39437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39438 : List Nat := [2,4,8,16,32,32,46,20,38,53,39,49,41,48,0,18,0,61,4,1,49,55,16,2,63,17,42,48,49,38,36,32,21,32,1,23]

theorem envBound39438 : H12AffineFastState.Bounded env39438 := by
  intro p hp
  have h : env39438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39437_39438 : H12AffineEnvironment.transform 6 46 env39437 = env39438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env39437 == env39438) = true)

def env39439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123165,28888,78895,385202,90415,1297,96347,25884,82998,257,1281,1344,21073]

theorem envBound39439 : H12AffineFastState.Bounded env39439 := by
  intro p hp
  have h : env39439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39355_39439 : H12AffineEnvironment.transform 18 21585 env39355 = env39439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env39355 == env39439) = true)

theorem identity39439 : scanCanonicalize (H12AffineFastState.compose env39439 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound39439 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4096,17612,91182,87296,28888,78895,349359,90415,1297,96347,25884,82998,257,1281,1344,21073]

theorem envBound39440 : H12AffineFastState.Bounded env39440 := by
  intro p hp
  have h : env39440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39439_39440 : H12AffineEnvironment.transform 14 13341 env39439 = env39440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env39439 == env39440) = true)

def env39441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4096,476,74046,69648,13768,78895,332223,74815,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound39441 : H12AffineFastState.Bounded env39441 := by
  intro p hp
  have h : env39441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39440_39441 : H12AffineEnvironment.transform 13 1296 env39440 = env39441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39440 == env39441) = true)

def env39442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4096,476,74046,69648,13768,78895,4415,74815,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound39442 : H12AffineFastState.Bounded env39442 := by
  intro p hp
  have h : env39442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39441_39442 : H12AffineEnvironment.transform 17 65664 env39441 = env39442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39441 == env39442) = true)

theorem identity39442 : scanCanonicalize (H12AffineFastState.compose env39442 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound39442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12591,5441,12719,4417,13340,4096,476,4113,8511,13768,1280,4415,5392,1297,3172,8204,12297,257,1281,1344,5953]

theorem envBound39443 : H12AffineFastState.Bounded env39443 := by
  intro p hp
  have h : env39443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39442_39443 : H12AffineEnvironment.transform 15 12591 env39442 = env39443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env39442 == env39443) = true)

def env39444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,8495,1345,8623,321,9244,0,476,17,8511,9672,1280,319,1296,1297,3172,8204,8201,257,1281,1344,1857]

theorem envBound39444 : H12AffineFastState.Bounded env39444 := by
  intro p hp
  have h : env39444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39443_39444 : H12AffineEnvironment.transform 11 0 env39443 = env39444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39443 == env39444) = true)

theorem identity39444 : scanCanonicalize (H12AffineFastState.compose env39444 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

end H12CloudChart2