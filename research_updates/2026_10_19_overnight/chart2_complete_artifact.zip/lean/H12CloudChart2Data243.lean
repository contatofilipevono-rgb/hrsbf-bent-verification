import H12CloudChart2Data242

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity61415 : scanCanonicalize (H12AffineFastState.compose env61415 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61416 : List Nat := [2,2,2,1,1,1,2,3,0,3,0,0,2,0,0,2,0,0,2,1,1,0,0,2,3,0,0,1,0,0,2,0,3,1,0,0]

theorem envBound61416 : H12AffineFastState.Bounded env61416 := by
  intro p hp
  have h : env61416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61415_61416 : H12AffineEnvironment.transform 2 2 env61415 = env61416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61415 == env61416) = true)

def env61417 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,25,1297,260,65536,66678,65664,1089,261,1280,477,65830,66832,208,65846,1086,66599,1297,67667,21,1280,256,65831,1345,277]

theorem envBound61417 : H12AffineFastState.Bounded env61417 := by
  intro p hp
  have h : env61417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61395_61417 : H12AffineEnvironment.transform 11 1281 env61395 = env61417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env61395 == env61417) = true)

theorem identity61417 : scanCanonicalize (H12AffineFastState.compose env61417 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 389) := by decide +kernel

theorem selectedBound61417 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61418 : List Nat := [2,4,8,16,32,64,128,256,341,389,2048,132,25,148,260,65536,66035,65664,452,261,133,477,65830,65685,208,65846,443,65954,148,67667,21,133,256,65831,196,277]

theorem envBound61418 : H12AffineFastState.Bounded env61418 := by
  intro p hp
  have h : env61418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61417_61418 : H12AffineEnvironment.transform 9 389 env61417 = env61418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env61417 == env61418) = true)

def env61419 : List Nat := [2,4,8,16,32,64,20,256,341,273,2048,16,25,0,260,65536,65895,65556,336,261,17,329,65830,65537,68,65846,303,65846,0,67667,21,17,256,65831,80,277]

theorem envBound61419 : H12AffineFastState.Bounded env61419 := by
  intro p hp
  have h : env61419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61418_61419 : H12AffineEnvironment.transform 6 20 env61418 = env61419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env61418 == env61419) = true)

theorem identity61419 : scanCanonicalize (H12AffineFastState.compose env61419 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound61419 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61420 : List Nat := [2,4,8,16,32,64,20,68,17,85,2048,16,25,0,64,65536,65571,65556,20,65,17,13,65634,65537,68,65650,107,65650,0,67667,21,17,68,65635,80,81]

theorem envBound61420 : H12AffineFastState.Bounded env61420 := by
  intro p hp
  have h : env61420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61419_61420 : H12AffineEnvironment.transform 7 68 env61419 = env61420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env61419 == env61420) = true)

theorem identity61420 : scanCanonicalize (H12AffineFastState.compose env61420 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound61420 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61421 : List Nat := [2,4,8,16,32,0,20,4,17,21,2048,16,25,0,0,65536,65571,65556,20,1,17,13,65570,65537,4,65586,43,65586,0,67603,21,17,4,65571,16,17]

theorem envBound61421 : H12AffineFastState.Bounded env61421 := by
  intro p hp
  have h : env61421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61420_61421 : H12AffineEnvironment.transform 5 0 env61420 = env61421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61420 == env61421) = true)

theorem identity61421 : scanCanonicalize (H12AffineFastState.compose env61421 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61421 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61422 : List Nat := [2,4,8,13,32,0,9,4,12,8,2048,13,4,0,0,65536,65571,65545,9,1,12,13,65570,65537,4,65583,43,65583,0,67598,8,12,4,65571,13,12]

theorem envBound61422 : H12AffineFastState.Bounded env61422 := by
  intro p hp
  have h : env61422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61421_61422 : H12AffineEnvironment.transform 3 13 env61421 = env61422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61421 == env61422) = true)

theorem identity61422 : scanCanonicalize (H12AffineFastState.compose env61422 (packedSelected [1,2,12] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound61422 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61423 : List Nat := [2,4,8,13,32,0,9,4,12,8,2048,13,4,0,0,3,32,10,9,1,12,13,33,2,4,44,43,44,0,2061,8,12,4,32,13,12]

theorem envBound61423 : H12AffineFastState.Bounded env61423 := by
  intro p hp
  have h : env61423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61422_61423 : H12AffineEnvironment.transform 15 3 env61422 = env61423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env61422 == env61423) = true)

theorem identity61423 : scanCanonicalize (H12AffineFastState.compose env61423 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound61423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61424 : List Nat := [2,4,8,13,32,0,9,4,12,8,45,13,4,0,0,3,32,10,9,1,12,13,33,2,4,44,43,44,0,32,8,12,4,32,13,12]

theorem envBound61424 : H12AffineFastState.Bounded env61424 := by
  intro p hp
  have h : env61424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61423_61424 : H12AffineEnvironment.transform 10 45 env61423 = env61424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env61423 == env61424) = true)

theorem identity61424 : scanCanonicalize (H12AffineFastState.compose env61424 (packedSelected [4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61424 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env61425 : List Nat := [2,4,3,6,32,0,2,4,7,3,38,6,4,0,0,3,32,1,2,1,7,6,33,2,4,39,32,39,0,32,3,7,4,32,6,7]

theorem envBound61425 : H12AffineFastState.Bounded env61425 := by
  intro p hp
  have h : env61425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61424_61425 : H12AffineEnvironment.transform 2 3 env61424 = env61425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61424 == env61425) = true)

theorem identity61425 : scanCanonicalize (H12AffineFastState.compose env61425 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound61425 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61426 : List Nat := [2,4,3,6,6,0,2,4,7,3,0,6,4,0,0,3,6,1,2,1,7,6,7,2,4,1,6,1,0,6,3,7,4,6,6,7]

theorem envBound61426 : H12AffineFastState.Bounded env61426 := by
  intro p hp
  have h : env61426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61425_61426 : H12AffineEnvironment.transform 4 6 env61425 = env61426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env61425 == env61426) = true)

theorem identity61426 : scanCanonicalize (H12AffineFastState.compose env61426 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61427 : List Nat := [2,2,3,0,0,0,2,2,1,3,0,0,2,0,0,3,0,1,2,1,1,0,1,2,2,1,0,1,0,0,3,1,2,0,0,1]

theorem envBound61427 : H12AffineFastState.Bounded env61427 := by
  intro p hp
  have h : env61427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61426_61427 : H12AffineEnvironment.transform 1 2 env61426 = env61427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61426 == env61427) = true)

def env61428 : List Nat := [2,4,8,16,32,64,21,256,341,272,2048,17,25,1,260,65536,65894,65557,337,261,16,328,65830,65536,69,65846,302,65847,1,67667,21,16,256,65831,81,277]

theorem envBound61428 : H12AffineFastState.Bounded env61428 := by
  intro p hp
  have h : env61428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61418_61428 : H12AffineEnvironment.transform 6 21 env61418 = env61428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env61418 == env61428) = true)

theorem identity61428 : scanCanonicalize (H12AffineFastState.compose env61428 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound61428 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61429 : List Nat := [2,4,8,16,32,64,21,4,81,20,2048,17,25,1,0,65536,65634,65557,85,1,16,76,65570,65536,69,65586,42,65587,1,67667,21,16,4,65571,81,17]

theorem envBound61429 : H12AffineFastState.Bounded env61429 := by
  intro p hp
  have h : env61429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61428_61429 : H12AffineEnvironment.transform 7 4 env61428 = env61429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env61428 == env61429) = true)

theorem identity61429 : scanCanonicalize (H12AffineFastState.compose env61429 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound61429 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61430 : List Nat := [2,4,8,16,32,64,21,4,81,20,81,17,25,1,0,65536,65634,65557,85,1,16,76,65570,65536,69,65586,42,65587,1,65538,21,16,4,65571,81,17]

theorem envBound61430 : H12AffineFastState.Bounded env61430 := by
  intro p hp
  have h : env61430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61429_61430 : H12AffineEnvironment.transform 10 81 env61429 = env61430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env61429 == env61430) = true)

theorem identity61430 : scanCanonicalize (H12AffineFastState.compose env61430 (packedSelected [1,2,3,8,10,12,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 78) := by decide +kernel

theorem selectedBound61430 : packedSelected [1,2,3,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env61431 : List Nat := [2,4,8,16,32,64,21,4,81,20,81,17,25,1,0,78,44,91,85,1,16,76,108,78,69,124,42,125,1,76,21,16,4,109,81,17]

theorem envBound61431 : H12AffineFastState.Bounded env61431 := by
  intro p hp
  have h : env61431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61430_61431 : H12AffineEnvironment.transform 15 78 env61430 = env61431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 78 env61430 == env61431) = true)

theorem identity61431 : scanCanonicalize (H12AffineFastState.compose env61431 (packedSelected [0,2,3,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound61431 : packedSelected [0,2,3,9,11,12] rootPS < 2^1333 := by decide +kernel

def env61432 : List Nat := [2,4,8,16,26,64,21,4,81,20,81,17,25,1,0,78,22,91,85,1,16,76,86,78,69,70,16,71,1,76,21,16,4,87,81,17]

theorem envBound61432 : H12AffineFastState.Bounded env61432 := by
  intro p hp
  have h : env61432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61431_61432 : H12AffineEnvironment.transform 4 26 env61431 = env61432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env61431 == env61432) = true)

theorem identity61432 : scanCanonicalize (H12AffineFastState.compose env61432 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61432 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env61433 : List Nat := [2,4,8,13,7,64,8,4,76,9,76,12,4,1,0,78,11,70,72,1,13,76,75,78,69,70,13,71,1,76,8,13,4,74,76,12]

theorem envBound61433 : H12AffineFastState.Bounded env61433 := by
  intro p hp
  have h : env61433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61432_61433 : H12AffineEnvironment.transform 3 13 env61432 = env61433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61432 == env61433) = true)

theorem identity61433 : scanCanonicalize (H12AffineFastState.compose env61433 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound61433 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61434 : List Nat := [2,4,8,13,7,6,8,4,10,9,10,12,4,1,0,8,11,0,14,1,13,10,13,8,3,0,13,1,1,10,8,13,4,12,10,12]

theorem envBound61434 : H12AffineFastState.Bounded env61434 := by
  intro p hp
  have h : env61434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61433_61434 : H12AffineEnvironment.transform 5 6 env61433 = env61434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env61433 == env61434) = true)

theorem identity61434 : scanCanonicalize (H12AffineFastState.compose env61434 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61435 : List Nat := [2,4,3,6,7,6,3,4,1,2,1,7,4,1,0,3,0,0,5,1,6,1,6,3,3,0,6,1,1,1,3,6,4,7,1,7]

theorem envBound61435 : H12AffineFastState.Bounded env61435 := by
  intro p hp
  have h : env61435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61434_61435 : H12AffineEnvironment.transform 2 3 env61434 = env61435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61434 == env61435) = true)

theorem identity61435 : scanCanonicalize (H12AffineFastState.compose env61435 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61436 : List Nat := [2,2,3,0,1,0,3,2,1,2,1,1,2,1,0,3,0,0,3,1,0,1,0,3,3,0,0,1,1,1,3,0,2,1,1,1]

theorem envBound61436 : H12AffineFastState.Bounded env61436 := by
  intro p hp
  have h : env61436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61435_61436 : H12AffineEnvironment.transform 1 2 env61435 = env61436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61435 == env61436) = true)

def env61437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4097,477,74047,69649,13768,78894,4414,74814,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound61437 : H12AffineFastState.Bounded env61437 := by
  intro p hp
  have h : env61437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61339_61437 : H12AffineEnvironment.transform 17 65665 env61339 = env61437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61339 == env61437) = true)

theorem identity61437 : scanCanonicalize (H12AffineFastState.compose env61437 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound61437 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4097,477,70758,69649,145,65911,4414,69991,1297,67602,5461,1280,256,65831,1345,5953]

theorem envBound61438 : H12AffineFastState.Bounded env61438 := by
  intro p hp
  have h : env61438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61437_61438 : H12AffineEnvironment.transform 12 5465 env61437 = env61438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env61437 == env61438) = true)

def env61439 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4097,477,70758,69649,145,65911,4414,69991,1297,67602,5461,1280,256,65831,1345,5141]

theorem envBound61439 : H12AffineFastState.Bounded env61439 := by
  intro p hp
  have h : env61439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61438_61439 : H12AffineEnvironment.transform 8 340 env61438 = env61439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env61438 == env61439) = true)

def env61440 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1297,261,65536,69942,65665,4352,260,4097,413,70694,69649,145,65847,4414,69927,1297,67602,5397,1280,256,65831,1281,5141]

theorem envBound61440 : H12AffineFastState.Bounded env61440 := by
  intro p hp
  have h : env61440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61439_61440 : H12AffineEnvironment.transform 5 0 env61439 = env61440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61439 == env61440) = true)

theorem identity61440 : scanCanonicalize (H12AffineFastState.compose env61440 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5283) := by decide +kernel

theorem selectedBound61440 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61441 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1297,261,5283,1429,5154,4352,260,4097,413,133,1202,145,5524,4414,1412,1297,7345,5397,1280,256,5508,1281,5141]

theorem envBound61441 : H12AffineFastState.Bounded env61441 := by
  intro p hp
  have h : env61441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61440_61441 : H12AffineEnvironment.transform 15 5283 env61440 = env61441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5283 env61440 == env61441) = true)

def env61442 : List Nat := [2,4,8,16,32,0,20,256,276,1024,2048,4096,5401,1297,261,5175,1281,5154,4352,260,4097,265,17,1062,5,5376,4414,1296,1297,7205,5397,1280,256,5392,1281,5141]

theorem envBound61442 : H12AffineFastState.Bounded env61442 := by
  intro p hp
  have h : env61442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61441_61442 : H12AffineEnvironment.transform 6 20 env61441 = env61442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env61441 == env61442) = true)

theorem identity61442 : scanCanonicalize (H12AffineFastState.compose env61442 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound61442 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61443 : List Nat := [2,4,8,16,32,0,20,256,276,1024,2048,1045,268,1297,261,34,1281,55,1301,260,1044,265,17,1062,5,277,1323,1296,1297,2096,256,1280,256,261,1281,0]

theorem envBound61443 : H12AffineFastState.Bounded env61443 := by
  intro p hp
  have h : env61443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61442_61443 : H12AffineEnvironment.transform 11 1045 env61442 = env61443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env61442 == env61443) = true)

theorem identity61443 : scanCanonicalize (H12AffineFastState.compose env61443 (packedSelected [0,5,7,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 1303) := by decide +kernel

theorem selectedBound61443 : packedSelected [0,5,7,17,20] rootPS < 2^1333 := by decide +kernel

def env61444 : List Nat := [2,4,8,16,32,0,20,256,276,1024,1303,1045,268,1297,261,34,1281,55,1301,260,1044,265,17,1062,5,277,1323,1296,1297,1319,256,1280,256,261,1281,0]

theorem envBound61444 : H12AffineFastState.Bounded env61444 := by
  intro p hp
  have h : env61444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61443_61444 : H12AffineEnvironment.transform 10 1303 env61443 = env61444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1303 env61443 == env61444) = true)

theorem identity61444 : scanCanonicalize (H12AffineFastState.compose env61444 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound61444 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env61445 : List Nat := [2,4,8,16,32,0,20,256,276,8,287,29,268,281,261,34,265,55,285,260,28,265,17,46,5,277,291,280,281,303,256,264,256,261,265,0]

theorem envBound61445 : H12AffineFastState.Bounded env61445 := by
  intro p hp
  have h : env61445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61444_61445 : H12AffineEnvironment.transform 9 8 env61444 = env61445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env61444 == env61445) = true)

theorem identity61445 : scanCanonicalize (H12AffineFastState.compose env61445 (packedSelected [3,5,7,9,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound61445 : packedSelected [3,5,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env61446 : List Nat := [2,4,8,16,29,0,20,256,276,8,287,29,268,281,261,31,265,10,285,260,28,265,17,19,5,277,286,280,281,274,256,264,256,261,265,0]

theorem envBound61446 : H12AffineFastState.Bounded env61446 := by
  intro p hp
  have h : env61446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61445_61446 : H12AffineEnvironment.transform 4 29 env61445 = env61446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env61445 == env61446) = true)

theorem identity61446 : scanCanonicalize (H12AffineFastState.compose env61446 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound61446 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61447 : List Nat := [2,4,8,16,29,0,20,18,6,8,13,29,30,11,23,31,27,10,15,22,28,27,17,19,5,7,12,10,11,0,18,26,18,23,27,0]

theorem envBound61447 : H12AffineFastState.Bounded env61447 := by
  intro p hp
  have h : env61447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61446_61447 : H12AffineEnvironment.transform 7 18 env61446 = env61447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env61446 == env61447) = true)

theorem identity61447 : scanCanonicalize (H12AffineFastState.compose env61447 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61448 : List Nat := [2,4,2,16,23,0,20,18,6,2,7,23,20,1,23,21,17,0,5,22,22,17,17,19,5,7,6,0,1,0,18,16,18,23,17,0]

theorem envBound61448 : H12AffineFastState.Bounded env61448 := by
  intro p hp
  have h : env61448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61447_61448 : H12AffineEnvironment.transform 2 2 env61447 = env61448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61447 == env61448) = true)

def env61449 : List Nat := [2,4,8,16,32,0,21,256,276,1024,2048,4096,5401,1297,261,5174,1280,5154,4352,260,4097,264,16,1063,4,5377,4414,1297,1297,7204,5397,1280,256,5393,1281,5141]

theorem envBound61449 : H12AffineFastState.Bounded env61449 := by
  intro p hp
  have h : env61449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61441_61449 : H12AffineEnvironment.transform 6 21 env61441 = env61449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env61441 == env61449) = true)

theorem identity61449 : scanCanonicalize (H12AffineFastState.compose env61449 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound61449 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61450 : List Nat := [2,4,8,16,32,0,21,256,276,256,2048,4096,4121,17,261,4406,0,4386,4352,260,4097,264,16,295,4,4097,4414,17,17,6436,4117,0,256,4113,1,4373]

theorem envBound61450 : H12AffineFastState.Bounded env61450 := by
  intro p hp
  have h : env61450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61449_61450 : H12AffineEnvironment.transform 9 256 env61449 = env61450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env61449 == env61450) = true)

theorem identity61450 : scanCanonicalize (H12AffineFastState.compose env61450 (packedSelected [1,2,3,4,5,8,9,11,12,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound61450 : packedSelected [1,2,3,4,5,8,9,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env61451 : List Nat := [2,4,8,16,32,0,21,256,276,256,264,4096,4121,17,261,4406,0,4386,4352,260,4097,264,16,295,4,4097,4414,17,17,4140,4117,0,256,4113,1,4373]

theorem envBound61451 : H12AffineFastState.Bounded env61451 := by
  intro p hp
  have h : env61451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61450_61451 : H12AffineEnvironment.transform 10 264 env61450 = env61451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env61450 == env61451) = true)

theorem identity61451 : scanCanonicalize (H12AffineFastState.compose env61451 (packedSelected [1,3,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound61451 : packedSelected [1,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env61452 : List Nat := [2,4,8,16,32,0,21,40,60,40,32,4096,4121,17,45,4126,0,4106,4136,44,4097,32,16,15,4,4097,4118,17,17,4140,4117,0,40,4113,1,4157]

theorem envBound61452 : H12AffineFastState.Bounded env61452 := by
  intro p hp
  have h : env61452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61451_61452 : H12AffineEnvironment.transform 7 40 env61451 = env61452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env61451 == env61452) = true)

theorem identity61452 : scanCanonicalize (H12AffineFastState.compose env61452 (packedSelected [2,8] rootPS)) = affineNative (2^(11+1) ^^^ 54) := by decide +kernel

theorem selectedBound61452 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env61453 : List Nat := [2,4,8,16,32,0,21,40,60,40,32,54,47,17,45,40,0,60,30,44,55,32,16,15,4,55,32,17,17,26,35,0,40,39,1,11]

theorem envBound61453 : H12AffineFastState.Bounded env61453 := by
  intro p hp
  have h : env61453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61452_61453 : H12AffineEnvironment.transform 11 54 env61452 = env61453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 54 env61452 == env61453) = true)

theorem identity61453 : scanCanonicalize (H12AffineFastState.compose env61453 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61453 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env61454 : List Nat := [2,4,8,1,32,0,4,40,45,40,32,39,47,0,45,40,0,45,15,44,38,32,1,15,4,38,32,0,0,11,35,0,40,39,1,11]

theorem envBound61454 : H12AffineFastState.Bounded env61454 := by
  intro p hp
  have h : env61454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61453_61454 : H12AffineEnvironment.transform 3 1 env61453 = env61454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61453 == env61454) = true)

theorem identity61454 : scanCanonicalize (H12AffineFastState.compose env61454 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61455 : List Nat := [2,4,8,1,10,0,4,2,7,2,10,13,5,0,7,2,0,7,15,6,12,10,1,15,4,12,10,0,0,11,9,0,2,13,1,11]

theorem envBound61455 : H12AffineFastState.Bounded env61455 := by
  intro p hp
  have h : env61455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61454_61455 : H12AffineEnvironment.transform 4 10 env61454 = env61455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61454 == env61455) = true)

theorem identity61455 : scanCanonicalize (H12AffineFastState.compose env61455 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61455 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61456 : List Nat := [2,3,8,1,10,0,3,2,0,2,10,10,2,0,0,2,0,0,8,1,11,10,1,8,3,11,10,0,0,11,9,0,2,10,1,11]

theorem envBound61456 : H12AffineFastState.Bounded env61456 := by
  intro p hp
  have h : env61456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61455_61456 : H12AffineEnvironment.transform 1 3 env61455 = env61456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61455 == env61456) = true)

def env61457 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1297,260,65536,69942,65665,4353,261,4097,412,70695,69649,145,65846,4414,69926,1297,67602,5396,1280,256,65831,1280,5141]

theorem envBound61457 : H12AffineFastState.Bounded env61457 := by
  intro p hp
  have h : env61457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61439_61457 : H12AffineEnvironment.transform 5 1 env61439 = env61457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61439 == env61457) = true)

theorem identity61457 : scanCanonicalize (H12AffineFastState.compose env61457 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1203) := by decide +kernel

theorem selectedBound61457 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61458 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1297,260,1203,5509,1074,4353,261,4097,412,4244,5282,145,1413,4414,5525,1297,3233,5396,1280,256,1428,1280,5141]

theorem envBound61458 : H12AffineFastState.Bounded env61458 := by
  intro p hp
  have h : env61458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61457_61458 : H12AffineEnvironment.transform 15 1203 env61457 = env61458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1203 env61457 == env61458) = true)

def env61459 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,4096,4104,1,260,419,4245,290,4353,261,4097,412,4244,4530,145,149,4414,4229,1,2481,4100,16,256,132,16,4357]

theorem envBound61459 : H12AffineFastState.Bounded env61459 := by
  intro p hp
  have h : env61459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61458_61459 : H12AffineEnvironment.transform 9 272 env61458 = env61459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61458 == env61459) = true)

theorem identity61459 : scanCanonicalize (H12AffineFastState.compose env61459 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound61459 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61460 : List Nat := [2,4,8,16,32,1,128,4,17,20,2048,4096,4104,1,0,167,4245,38,4101,1,4097,152,4244,4278,145,149,4154,4229,1,2229,4100,16,4,132,16,4097]

theorem envBound61460 : H12AffineFastState.Bounded env61460 := by
  intro p hp
  have h : env61460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61459_61460 : H12AffineEnvironment.transform 7 4 env61459 = env61460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env61459 == env61460) = true)

theorem identity61460 : scanCanonicalize (H12AffineFastState.compose env61460 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound61460 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env61461 : List Nat := [2,4,8,16,16,1,128,4,17,20,2048,4096,4104,1,0,151,4245,22,4101,1,4097,152,4244,4230,145,149,4106,4229,1,2181,4100,16,4,132,16,4097]

theorem envBound61461 : H12AffineFastState.Bounded env61461 := by
  intro p hp
  have h : env61461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61460_61461 : H12AffineEnvironment.transform 4 16 env61460 = env61461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env61460 == env61461) = true)

theorem identity61461 : scanCanonicalize (H12AffineFastState.compose env61461 (packedSelected [1,2,4,9,11,12,13,16,17,18] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61461 : packedSelected [1,2,4,9,11,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env61462 : List Nat := [2,3,8,16,16,1,128,3,17,19,2048,4096,4104,1,0,144,4242,17,4098,1,4097,152,4243,4225,145,146,4106,4226,1,2178,4099,16,3,131,16,4097]

theorem envBound61462 : H12AffineFastState.Bounded env61462 := by
  intro p hp
  have h : env61462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61461_61462 : H12AffineEnvironment.transform 1 3 env61461 = env61462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61461 == env61462) = true)

theorem identity61462 : scanCanonicalize (H12AffineFastState.compose env61462 (packedSelected [0,1,2,3,4,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound61462 : packedSelected [0,1,2,3,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env61463 : List Nat := [2,3,8,16,16,1,128,3,17,19,146,4096,4104,1,0,144,4242,17,4098,1,4097,152,4243,4225,145,146,4106,4226,1,16,4099,16,3,131,16,4097]

theorem envBound61463 : H12AffineFastState.Bounded env61463 := by
  intro p hp
  have h : env61463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61462_61463 : H12AffineEnvironment.transform 10 146 env61462 = env61463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env61462 == env61463) = true)

theorem identity61463 : scanCanonicalize (H12AffineFastState.compose env61463 (packedSelected [0,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound61463 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env61464 : List Nat := [2,3,8,16,16,1,128,3,17,19,146,137,129,1,0,144,27,17,139,1,136,152,26,8,145,146,131,11,1,16,138,16,3,131,16,136]

theorem envBound61464 : H12AffineFastState.Bounded env61464 := by
  intro p hp
  have h : env61464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61463_61464 : H12AffineEnvironment.transform 11 137 env61463 = env61464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env61463 == env61464) = true)

theorem identity61464 : scanCanonicalize (H12AffineFastState.compose env61464 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound61464 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61465 : List Nat := [2,3,8,16,16,1,19,3,17,19,1,26,18,1,0,3,27,17,24,1,27,11,26,8,2,1,16,11,1,16,25,16,3,16,16,27]

theorem envBound61465 : H12AffineFastState.Bounded env61465 := by
  intro p hp
  have h : env61465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61464_61465 : H12AffineEnvironment.transform 6 19 env61464 = env61465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env61464 == env61465) = true)

theorem identity61465 : scanCanonicalize (H12AffineFastState.compose env61465 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61465 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61466 : List Nat := [2,3,2,16,16,1,19,3,17,19,1,16,18,1,0,3,17,17,18,1,17,1,16,2,2,1,16,1,1,16,19,16,3,16,16,17]

theorem envBound61466 : H12AffineFastState.Bounded env61466 := by
  intro p hp
  have h : env61466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61465_61466 : H12AffineEnvironment.transform 2 2 env61465 = env61466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61465 == env61466) = true)

theorem identity61466 : scanCanonicalize (H12AffineFastState.compose env61466 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61467 : List Nat := [2,3,2,1,1,1,2,3,0,2,1,1,3,1,0,3,0,0,3,1,0,1,1,2,2,1,1,1,1,1,2,1,3,1,1,0]

theorem envBound61467 : H12AffineFastState.Bounded env61467 := by
  intro p hp
  have h : env61467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61466_61467 : H12AffineEnvironment.transform 3 1 env61466 = env61467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61466 == env61467) = true)

def env61468 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,4096,4105,0,260,418,4244,291,4353,261,4097,412,4244,4531,145,148,4414,4228,0,2480,4101,17,256,133,17,4356]

theorem envBound61468 : H12AffineFastState.Bounded env61468 := by
  intro p hp
  have h : env61468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61458_61468 : H12AffineEnvironment.transform 9 273 env61458 = env61468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61458 == env61468) = true)

theorem identity61468 : scanCanonicalize (H12AffineFastState.compose env61468 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound61468 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61469 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,277,284,0,260,418,385,291,20,261,276,412,385,166,145,148,43,401,0,2480,272,17,256,133,17,17]

theorem envBound61469 : H12AffineFastState.Bounded env61469 := by
  intro p hp
  have h : env61469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61468_61469 : H12AffineEnvironment.transform 11 277 env61468 = env61469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env61468 == env61469) = true)

theorem identity61469 : scanCanonicalize (H12AffineFastState.compose env61469 (packedSelected [13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61469 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61470 : List Nat := [2,4,8,0,32,1,128,256,261,257,2048,261,268,0,260,418,385,291,4,261,260,396,385,166,129,132,43,385,0,2464,256,1,256,133,1,1]

theorem envBound61470 : H12AffineFastState.Bounded env61470 := by
  intro p hp
  have h : env61470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61469_61470 : H12AffineEnvironment.transform 3 0 env61469 = env61470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61469 == env61470) = true)

theorem identity61470 : scanCanonicalize (H12AffineFastState.compose env61470 (packedSelected [0,2,7,8,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound61470 : packedSelected [0,2,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env61471 : List Nat := [2,4,8,0,13,1,128,256,261,257,2048,261,268,0,260,399,385,270,4,261,260,396,385,139,129,132,6,385,0,2445,256,1,256,133,1,1]

theorem envBound61471 : H12AffineFastState.Bounded env61471 := by
  intro p hp
  have h : env61471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61470_61471 : H12AffineEnvironment.transform 4 13 env61470 = env61471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env61470 == env61471) = true)

theorem identity61471 : scanCanonicalize (H12AffineFastState.compose env61471 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 395) := by decide +kernel

theorem selectedBound61471 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env61472 : List Nat := [2,4,8,0,13,1,128,256,261,257,395,261,268,0,260,399,385,270,4,261,260,396,385,139,129,132,6,385,0,6,256,1,256,133,1,1]

theorem envBound61472 : H12AffineFastState.Bounded env61472 := by
  intro p hp
  have h : env61472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61471_61472 : H12AffineEnvironment.transform 10 395 env61471 = env61472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 395 env61471 == env61472) = true)

theorem identity61472 : scanCanonicalize (H12AffineFastState.compose env61472 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound61472 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env61473 : List Nat := [2,4,8,0,13,1,14,256,261,257,261,261,268,0,260,257,271,270,4,261,260,258,271,5,15,10,6,271,0,6,256,1,256,11,1,1]

theorem envBound61473 : H12AffineFastState.Bounded env61473 := by
  intro p hp
  have h : env61473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61472_61473 : H12AffineEnvironment.transform 6 14 env61472 = env61473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env61472 == env61473) = true)

theorem identity61473 : scanCanonicalize (H12AffineFastState.compose env61473 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound61473 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env61474 : List Nat := [2,4,8,0,13,1,14,3,6,2,6,6,15,0,7,2,12,13,4,6,7,1,12,5,15,10,6,12,0,6,3,1,3,11,1,1]

theorem envBound61474 : H12AffineFastState.Bounded env61474 := by
  intro p hp
  have h : env61474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61473_61474 : H12AffineEnvironment.transform 7 3 env61473 = env61474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env61473 == env61474) = true)

def env61475 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4097,477,70758,69649,145,65911,4414,69991,1297,67602,5461,1280,256,65831,1345,5140]

theorem envBound61475 : H12AffineFastState.Bounded env61475 := by
  intro p hp
  have h : env61475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61438_61475 : H12AffineEnvironment.transform 8 341 env61438 = env61475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env61438 == env61475) = true)

def env61476 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5401,1297,261,65536,69942,65665,4352,260,4097,413,70694,69649,145,65847,4414,69927,1297,67602,5397,1280,256,65831,1281,5140]

theorem envBound61476 : H12AffineFastState.Bounded env61476 := by
  intro p hp
  have h : env61476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61475_61476 : H12AffineEnvironment.transform 5 0 env61475 = env61476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61475 == env61476) = true)

theorem identity61476 : scanCanonicalize (H12AffineFastState.compose env61476 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound61476 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61477 : List Nat := [2,4,8,16,32,0,20,256,277,1024,2048,4096,5401,1297,261,65536,69942,65557,4352,260,4097,265,70694,69649,5,65847,4414,69927,1297,67602,5397,1280,256,65831,1281,5140]

theorem envBound61477 : H12AffineFastState.Bounded env61477 := by
  intro p hp
  have h : env61477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61476_61477 : H12AffineEnvironment.transform 6 20 env61476 = env61477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env61476 == env61477) = true)

def env61478 : List Nat := [2,4,8,16,32,0,20,256,277,284,2048,4096,4101,13,261,65536,69942,65557,4352,260,4097,265,69946,69649,5,65847,4414,69927,13,67602,4105,28,256,65831,29,4360]

theorem envBound61478 : H12AffineFastState.Bounded env61478 := by
  intro p hp
  have h : env61478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61477_61478 : H12AffineEnvironment.transform 9 284 env61477 = env61478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 284 env61477 == env61478) = true)

theorem identity61478 : scanCanonicalize (H12AffineFastState.compose env61478 (packedSelected [0,1,7,8,15,16,17,18,21,23,24,41] rootPS)) = affineNative (2^(15+1) ^^^ 2352) := by decide +kernel

theorem selectedBound61478 : packedSelected [0,1,7,8,15,16,17,18,21,23,24,41] rootPS < 2^1333 := by decide +kernel

def env61479 : List Nat := [2,4,8,16,32,0,20,256,277,284,2048,4096,4101,13,261,2352,6150,2341,4352,260,4097,265,6154,6433,5,2055,4414,6167,13,290,4105,28,256,2071,29,4360]

theorem envBound61479 : H12AffineFastState.Bounded env61479 := by
  intro p hp
  have h : env61479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61478_61479 : H12AffineEnvironment.transform 15 2352 env61478 = env61479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2352 env61478 == env61479) = true)

theorem identity61479 : scanCanonicalize (H12AffineFastState.compose env61479 (packedSelected [0,2,3,4,7,9,10,11,12,13,15,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 2087) := by decide +kernel

theorem selectedBound61479 : packedSelected [0,2,3,4,7,9,10,11,12,13,15,21,23] rootPS < 2^1333 := by decide +kernel

def env61480 : List Nat := [2,4,8,16,32,0,20,256,277,284,2048,2087,2082,13,261,2352,33,2341,2343,260,2086,265,45,262,5,2055,2329,48,13,290,2094,28,256,2071,29,2351]

theorem envBound61480 : H12AffineFastState.Bounded env61480 := by
  intro p hp
  have h : env61480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61479_61480 : H12AffineEnvironment.transform 11 2087 env61479 = env61480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2087 env61479 == env61480) = true)

theorem identity61480 : scanCanonicalize (H12AffineFastState.compose env61480 (packedSelected [0,4,5,10,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound61480 : packedSelected [0,4,5,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env61481 : List Nat := [2,4,8,16,32,0,20,35,54,63,2048,2087,2082,13,38,2067,33,2054,2052,39,2086,42,45,37,5,2055,2106,48,13,1,2094,28,35,2071,29,2060]

theorem envBound61481 : H12AffineFastState.Bounded env61481 := by
  intro p hp
  have h : env61481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61480_61481 : H12AffineEnvironment.transform 7 35 env61480 = env61481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env61480 == env61481) = true)

theorem identity61481 : scanCanonicalize (H12AffineFastState.compose env61481 (packedSelected [0,1,2,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound61481 : packedSelected [0,1,2,9,10,11] rootPS < 2^1333 := by decide +kernel

def env61482 : List Nat := [2,4,8,16,13,0,20,14,27,18,2048,2058,2063,13,11,2067,12,2054,2052,10,2059,7,0,8,5,2055,2071,29,13,1,2051,28,14,2071,29,2060]

theorem envBound61482 : H12AffineFastState.Bounded env61482 := by
  intro p hp
  have h : env61482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61481_61482 : H12AffineEnvironment.transform 4 13 env61481 = env61482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env61481 == env61482) = true)

theorem identity61482 : scanCanonicalize (H12AffineFastState.compose env61482 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61482 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61483 : List Nat := [2,4,3,16,6,0,20,5,16,18,2048,2049,2052,6,0,2067,7,2054,2052,1,2048,7,0,3,5,2055,2071,22,6,1,2051,23,5,2071,22,2055]

theorem envBound61483 : H12AffineFastState.Bounded env61483 := by
  intro p hp
  have h : env61483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61482_61483 : H12AffineEnvironment.transform 2 3 env61482 = env61483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61482 == env61483) = true)

theorem identity61483 : scanCanonicalize (H12AffineFastState.compose env61483 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound61483 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env61484 : List Nat := [2,4,3,16,6,0,20,5,16,18,17,16,21,6,0,2,7,23,21,1,17,7,0,3,5,22,6,22,6,1,18,23,5,6,22,22]

theorem envBound61484 : H12AffineFastState.Bounded env61484 := by
  intro p hp
  have h : env61484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61483_61484 : H12AffineEnvironment.transform 10 17 env61483 = env61484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env61483 == env61484) = true)

theorem identity61484 : scanCanonicalize (H12AffineFastState.compose env61484 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61484 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env61485 : List Nat := [2,2,3,16,0,0,18,3,16,18,17,16,19,0,0,2,1,17,19,1,17,1,0,3,3,16,0,16,0,1,18,17,3,0,16,16]

theorem envBound61485 : H12AffineFastState.Bounded env61485 := by
  intro p hp
  have h : env61485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61484_61485 : H12AffineEnvironment.transform 1 2 env61484 = env61485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61484 == env61485) = true)

theorem identity61485 : scanCanonicalize (H12AffineFastState.compose env61485 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61485 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61486 : List Nat := [2,2,3,1,0,0,3,3,1,3,0,1,2,0,0,2,1,0,2,1,0,1,0,3,3,1,0,1,0,1,3,0,3,0,1,1]

theorem envBound61486 : H12AffineFastState.Bounded env61486 := by
  intro p hp
  have h : env61486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61485_61486 : H12AffineEnvironment.transform 3 1 env61485 = env61486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61485 == env61486) = true)

def env61487 : List Nat := [2,4,8,16,32,0,20,256,277,285,2048,4096,4100,12,261,65536,69942,65557,4352,260,4097,265,69947,69649,5,65847,4414,69927,12,67602,4104,29,256,65831,28,4361]

theorem envBound61487 : H12AffineFastState.Bounded env61487 := by
  intro p hp
  have h : env61487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61477_61487 : H12AffineEnvironment.transform 9 285 env61477 = env61487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 285 env61477 == env61487) = true)

theorem identity61487 : scanCanonicalize (H12AffineFastState.compose env61487 (packedSelected [0,1,7,8,15,16,17,18,21,23,24,41] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound61487 : packedSelected [0,1,7,8,15,16,17,18,21,23,24,41] rootPS < 2^1333 := by decide +kernel

def env61488 : List Nat := [2,4,8,16,32,0,20,256,277,285,2048,2074,2078,12,261,65536,67884,65557,2330,260,2075,265,67873,67595,5,65847,2340,67901,12,67602,2066,29,256,65831,28,2323]

theorem envBound61488 : H12AffineFastState.Bounded env61488 := by
  intro p hp
  have h : env61488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61487_61488 : H12AffineEnvironment.transform 11 2074 env61487 = env61488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env61487 == env61488) = true)

theorem identity61488 : scanCanonicalize (H12AffineFastState.compose env61488 (packedSelected [3,4,5,7,8,11,12,13,15,18,19,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 268) := by decide +kernel

theorem selectedBound61488 : packedSelected [3,4,5,7,8,11,12,13,15,18,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env61489 : List Nat := [2,4,8,16,32,0,20,256,277,285,2048,2074,2078,12,261,268,2080,281,2330,260,2075,265,2093,2311,5,59,2340,2097,12,2334,2066,29,256,43,28,2323]

theorem envBound61489 : H12AffineFastState.Bounded env61489 := by
  intro p hp
  have h : env61489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61488_61489 : H12AffineEnvironment.transform 15 268 env61488 = env61489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 268 env61488 == env61489) = true)

theorem identity61489 : scanCanonicalize (H12AffineFastState.compose env61489 (packedSelected [0,2,3,5,9,10,12,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound61489 : packedSelected [0,2,3,5,9,10,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env61490 : List Nat := [2,4,8,16,32,0,20,256,277,285,261,287,283,12,261,268,293,281,31,260,286,265,296,2,5,59,33,308,12,27,279,29,256,43,28,22]

theorem envBound61490 : H12AffineFastState.Bounded env61490 := by
  intro p hp
  have h : env61490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61489_61490 : H12AffineEnvironment.transform 10 261 env61489 = env61490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env61489 == env61490) = true)

theorem identity61490 : scanCanonicalize (H12AffineFastState.compose env61490 (packedSelected [0,2,3,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound61490 : packedSelected [0,2,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env61491 : List Nat := [2,4,8,16,32,0,20,37,48,56,32,58,62,12,32,41,0,60,31,33,59,44,13,2,5,59,33,17,12,27,50,29,37,43,28,22]

theorem envBound61491 : H12AffineFastState.Bounded env61491 := by
  intro p hp
  have h : env61491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61490_61491 : H12AffineEnvironment.transform 7 37 env61490 = env61491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env61490 == env61491) = true)

theorem identity61491 : scanCanonicalize (H12AffineFastState.compose env61491 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound61491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61492 : List Nat := [2,4,8,7,32,0,3,37,39,47,32,45,41,12,32,41,0,43,8,33,44,44,13,2,5,44,33,6,12,12,37,10,37,43,11,1]

theorem envBound61492 : H12AffineFastState.Bounded env61492 := by
  intro p hp
  have h : env61492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61491_61492 : H12AffineEnvironment.transform 3 7 env61491 = env61492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env61491 == env61492) = true)

theorem identity61492 : scanCanonicalize (H12AffineFastState.compose env61492 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound61492 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env61493 : List Nat := [2,4,8,7,13,0,3,8,10,2,13,0,4,12,13,4,0,6,8,12,1,1,13,2,5,1,12,6,12,12,8,10,8,6,11,1]

theorem envBound61493 : H12AffineFastState.Bounded env61493 := by
  intro p hp
  have h : env61493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61492_61493 : H12AffineEnvironment.transform 4 13 env61492 = env61493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env61492 == env61493) = true)

theorem identity61493 : scanCanonicalize (H12AffineFastState.compose env61493 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61493 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env61494 : List Nat := [2,4,5,7,0,0,3,5,7,2,0,0,4,1,0,4,0,6,5,1,1,1,0,2,5,1,1,6,1,1,5,7,5,6,6,1]

theorem envBound61494 : H12AffineFastState.Bounded env61494 := by
  intro p hp
  have h : env61494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61493_61494 : H12AffineEnvironment.transform 2 5 env61493 = env61494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61493 == env61494) = true)

def env61495 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5400,1297,260,65536,69942,65665,4353,261,4097,412,70695,69649,145,65846,4414,69926,1297,67602,5396,1280,256,65831,1280,5140]

theorem envBound61495 : H12AffineFastState.Bounded env61495 := by
  intro p hp
  have h : env61495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61475_61495 : H12AffineEnvironment.transform 5 1 env61475 = env61495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61475 == env61495) = true)

theorem identity61495 : scanCanonicalize (H12AffineFastState.compose env61495 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 133) := by decide +kernel

theorem selectedBound61495 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61496 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,133,1437,1297,260,65536,65971,65665,388,261,132,412,66722,65684,145,65846,443,65955,1297,67602,1425,1280,256,65831,1280,1169]

theorem envBound61496 : H12AffineFastState.Bounded env61496 := by
  intro p hp
  have h : env61496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61495_61496 : H12AffineEnvironment.transform 11 133 env61495 = env61496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 133 env61495 == env61496) = true)

def env61497 : List Nat := [2,4,8,16,32,1,20,256,276,1024,2048,17,1289,1297,260,65536,65831,65557,272,261,16,264,66614,65536,5,65846,303,65847,1297,67602,1285,1280,256,65831,1280,1029]

theorem envBound61497 : H12AffineFastState.Bounded env61497 := by
  intro p hp
  have h : env61497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61496_61497 : H12AffineEnvironment.transform 6 20 env61496 = env61497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env61496 == env61497) = true)

theorem identity61497 : scanCanonicalize (H12AffineFastState.compose env61497 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound61497 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61498 : List Nat := [2,4,8,16,32,1,20,4,16,1024,2048,17,1037,1045,0,65536,65571,65557,20,1,16,12,66614,65536,5,65586,43,65587,1045,67602,1025,1028,4,65571,1028,1029]

theorem envBound61498 : H12AffineFastState.Bounded env61498 := by
  intro p hp
  have h : env61498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61497_61498 : H12AffineEnvironment.transform 7 4 env61497 = env61498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env61497 == env61498) = true)

theorem identity61498 : scanCanonicalize (H12AffineFastState.compose env61498 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1079) := by decide +kernel

theorem selectedBound61498 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61499 : List Nat := [2,4,8,16,32,1,20,4,16,1024,2048,17,1037,1045,0,1079,1044,1058,20,1,16,12,1,1079,5,1029,43,1028,1045,3109,1025,1028,4,1044,1028,1029]

theorem envBound61499 : H12AffineFastState.Bounded env61499 := by
  intro p hp
  have h : env61499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61498_61499 : H12AffineEnvironment.transform 15 1079 env61498 = env61499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1079 env61498 == env61499) = true)

theorem identity61499 : scanCanonicalize (H12AffineFastState.compose env61499 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound61499 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61500 : List Nat := [2,4,8,16,32,1,20,4,16,47,2048,17,34,58,0,24,59,13,20,1,16,12,1,24,5,42,43,43,58,2058,46,43,4,59,43,42]

theorem envBound61500 : H12AffineFastState.Bounded env61500 := by
  intro p hp
  have h : env61500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61499_61500 : H12AffineEnvironment.transform 9 47 env61499 = env61500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env61499 == env61500) = true)

theorem identity61500 : scanCanonicalize (H12AffineFastState.compose env61500 (packedSelected [0,1,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 60) := by decide +kernel

theorem selectedBound61500 : packedSelected [0,1,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env61501 : List Nat := [2,4,8,16,32,1,20,4,16,47,60,17,34,58,0,24,59,13,20,1,16,12,1,24,5,42,43,43,58,54,46,43,4,59,43,42]

theorem envBound61501 : H12AffineFastState.Bounded env61501 := by
  intro p hp
  have h : env61501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61500_61501 : H12AffineEnvironment.transform 10 60 env61500 = env61501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 60 env61500 == env61501) = true)

theorem identity61501 : scanCanonicalize (H12AffineFastState.compose env61501 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound61501 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env61502 : List Nat := [2,4,8,16,23,1,20,4,16,24,11,17,21,13,0,24,12,13,20,1,16,12,1,24,5,29,28,28,13,1,25,28,4,12,28,29]

theorem envBound61502 : H12AffineFastState.Bounded env61502 := by
  intro p hp
  have h : env61502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61501_61502 : H12AffineEnvironment.transform 4 23 env61501 = env61502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env61501 == env61502) = true)

theorem identity61502 : scanCanonicalize (H12AffineFastState.compose env61502 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61502 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61503 : List Nat := [2,3,8,16,16,1,19,3,16,24,11,17,18,10,0,24,11,10,19,1,16,11,1,24,2,26,27,27,10,1,25,27,3,11,27,26]

theorem envBound61503 : H12AffineFastState.Bounded env61503 := by
  intro p hp
  have h : env61503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61502_61503 : H12AffineEnvironment.transform 1 3 env61502 = env61503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61502 == env61503) = true)

theorem identity61503 : scanCanonicalize (H12AffineFastState.compose env61503 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound61503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61504 : List Nat := [2,3,8,10,10,1,9,3,10,2,11,11,8,10,0,2,11,10,9,1,10,11,1,2,2,0,1,1,10,1,3,1,3,11,1,0]

theorem envBound61504 : H12AffineFastState.Bounded env61504 := by
  intro p hp
  have h : env61504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61503_61504 : H12AffineEnvironment.transform 3 10 env61503 = env61504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env61503 == env61504) = true)

theorem identity61504 : scanCanonicalize (H12AffineFastState.compose env61504 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61504 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61505 : List Nat := [2,3,3,1,1,1,2,3,1,2,0,0,3,1,0,2,0,1,2,1,1,0,1,2,2,0,1,1,1,1,3,1,3,0,1,0]

theorem envBound61505 : H12AffineFastState.Bounded env61505 := by
  intro p hp
  have h : env61505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61504_61505 : H12AffineEnvironment.transform 2 3 env61504 = env61505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61504 == env61505) = true)

theorem identity61505 : scanCanonicalize (H12AffineFastState.compose env61505 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61506 : List Nat := [1,0,0,1,1,1,1,0,1,1,0,0,0,1,0,1,0,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1,0,0,1,0]

theorem envBound61506 : H12AffineFastState.Bounded env61506 := by
  intro p hp
  have h : env61506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61505_61506 : H12AffineEnvironment.transform 0 1 env61505 = env61506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61505 == env61506) = true)

def env61507 : List Nat := [2,4,8,16,32,1,21,256,276,1024,2048,16,1288,1297,260,65536,65830,65556,273,261,17,265,66615,65537,4,65846,302,65846,1297,67602,1284,1280,256,65831,1280,1028]

theorem envBound61507 : H12AffineFastState.Bounded env61507 := by
  intro p hp
  have h : env61507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61496_61507 : H12AffineEnvironment.transform 6 21 env61496 = env61507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env61496 == env61507) = true)

theorem identity61507 : scanCanonicalize (H12AffineFastState.compose env61507 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound61507 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61508 : List Nat := [2,4,8,16,32,1,21,256,276,20,2048,16,284,261,260,65536,65830,65556,273,261,17,265,65571,65537,4,65846,302,65846,261,67602,272,276,256,65831,276,16]

theorem envBound61508 : H12AffineFastState.Bounded env61508 := by
  intro p hp
  have h : env61508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61507_61508 : H12AffineEnvironment.transform 9 20 env61507 = env61508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env61507 == env61508) = true)

theorem identity61508 : scanCanonicalize (H12AffineFastState.compose env61508 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound61508 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61509 : List Nat := [2,4,8,16,32,1,21,256,276,20,7,16,284,261,260,65536,65830,65556,273,261,17,265,65571,65537,4,65846,302,65846,261,65557,272,276,256,65831,276,16]

theorem envBound61509 : H12AffineFastState.Bounded env61509 := by
  intro p hp
  have h : env61509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61508_61509 : H12AffineEnvironment.transform 10 7 env61508 = env61509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env61508 == env61509) = true)

theorem identity61509 : scanCanonicalize (H12AffineFastState.compose env61509 (packedSelected [4,5,8,9,10,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound61509 : packedSelected [4,5,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env61510 : List Nat := [2,4,8,16,32,1,21,256,276,20,7,16,284,261,260,21,307,1,273,261,17,265,54,20,4,291,302,291,261,0,272,276,256,306,276,16]

theorem envBound61510 : H12AffineFastState.Bounded env61510 := by
  intro p hp
  have h : env61510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61509_61510 : H12AffineEnvironment.transform 15 21 env61509 = env61510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env61509 == env61510) = true)

theorem identity61510 : scanCanonicalize (H12AffineFastState.compose env61510 (packedSelected [4,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61510 : packedSelected [4,9,10] rootPS < 2^1333 := by decide +kernel

def env61511 : List Nat := [2,4,8,16,10,1,21,256,276,20,7,16,284,261,260,21,281,1,273,261,17,265,28,20,4,265,260,265,261,0,272,276,256,280,276,16]

theorem envBound61511 : H12AffineFastState.Bounded env61511 := by
  intro p hp
  have h : env61511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61510_61511 : H12AffineEnvironment.transform 4 10 env61510 = env61511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61510 == env61511) = true)

theorem identity61511 : scanCanonicalize (H12AffineFastState.compose env61511 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound61511 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env61512 : List Nat := [2,4,8,16,10,1,21,25,13,20,7,16,5,28,29,21,0,1,8,28,17,16,28,20,4,16,29,16,28,0,9,13,25,1,13,16]

theorem envBound61512 : H12AffineFastState.Bounded env61512 := by
  intro p hp
  have h : env61512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61511_61512 : H12AffineEnvironment.transform 7 25 env61511 = env61512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env61511 == env61512) = true)

theorem identity61512 : scanCanonicalize (H12AffineFastState.compose env61512 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound61512 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61513 : List Nat := [2,4,8,11,10,1,14,2,13,15,7,11,5,7,6,14,0,1,8,7,10,11,7,15,4,11,6,11,7,0,9,13,2,1,13,11]

theorem envBound61513 : H12AffineFastState.Bounded env61513 := by
  intro p hp
  have h : env61513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61512_61513 : H12AffineEnvironment.transform 3 11 env61512 = env61513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env61512 == env61513) = true)

theorem identity61513 : scanCanonicalize (H12AffineFastState.compose env61513 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61514 : List Nat := [2,4,2,1,0,1,4,2,7,5,7,1,5,7,6,4,0,1,2,7,0,1,7,5,4,1,6,1,7,0,3,7,2,1,7,1]

theorem envBound61514 : H12AffineFastState.Bounded env61514 := by
  intro p hp
  have h : env61514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61513_61514 : H12AffineEnvironment.transform 2 2 env61513 = env61514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61513 == env61514) = true)

def env61515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123165,533640,614527,385203,90415,545088,96346,25884,1280,256,594022,1345,525825]

theorem envBound61515 : H12AffineFastState.Bounded env61515 := by
  intro p hp
  have h : env61515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60919_61515 : H12AffineEnvironment.transform 23 123165 env60919 = env61515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env60919 == env61515) = true)

def env61516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123165,28888,78895,385203,90415,1296,96346,25884,1280,256,82998,1345,21073]

theorem envBound61516 : H12AffineFastState.Bounded env61516 := by
  intro p hp
  have h : env61516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61515_61516 : H12AffineEnvironment.transform 18 21584 env61515 = env61516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env61515 == env61516) = true)

theorem identity61516 : scanCanonicalize (H12AffineFastState.compose env61516 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound61516 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env61517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4097,5276,91182,66897,28888,78895,328959,90415,1296,96346,25884,1280,256,82998,1345,21073]

theorem envBound61517 : H12AffineFastState.Bounded env61517 := by
  intro p hp
  have h : env61517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61516_61517 : H12AffineEnvironment.transform 14 25676 env61516 = env61517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env61516 == env61517) = true)

def env61518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4097,5276,74046,66897,13768,78895,328959,74815,1296,81226,8204,1280,256,65830,1345,5953]

theorem envBound61518 : H12AffineFastState.Bounded env61518 := by
  intro p hp
  have h : env61518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61517_61518 : H12AffineEnvironment.transform 13 1296 env61517 = env61518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env61517 == env61518) = true)

def env61519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4097,5276,74046,66897,13768,78895,1151,74815,1296,81226,8204,1280,256,65830,1345,5953]

theorem envBound61519 : H12AffineFastState.Bounded env61519 := by
  intro p hp
  have h : env61519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61518_61519 : H12AffineEnvironment.transform 17 65664 env61518 = env61519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61518 == env61519) = true)

theorem identity61519 : scanCanonicalize (H12AffineFastState.compose env61519 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound61519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9279,80,9407,4416,8541,4097,5276,1281,8558,13768,4112,1151,0,1296,6517,8204,1280,256,9497,1345,5953]

theorem envBound61520 : H12AffineFastState.Bounded env61520 := by
  intro p hp
  have h : env61520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61519_61520 : H12AffineEnvironment.transform 15 9279 env61519 = env61520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env61519 == env61520) = true)

def env61521 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8495,80,8623,4416,8541,4097,4492,17,8558,12504,4112,367,0,0,6517,8204,16,256,8201,81,4689]

theorem envBound61521 : H12AffineFastState.Bounded env61521 := by
  intro p hp
  have h : env61521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61520_61521 : H12AffineEnvironment.transform 9 272 env61520 = env61521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61520 == env61521) = true)

theorem identity61521 : scanCanonicalize (H12AffineFastState.compose env61521 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound61521 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61522 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4444,0,4096,4211,80,4339,4416,4097,4097,4492,17,4146,388,4112,367,0,0,6517,4432,16,256,4437,81,4689]

theorem envBound61522 : H12AffineFastState.Bounded env61522 := by
  intro p hp
  have h : env61522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61521_61522 : H12AffineEnvironment.transform 12 4444 env61521 = env61522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env61521 == env61522) = true)

theorem identity61522 : scanCanonicalize (H12AffineFastState.compose env61522 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound61522 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61523 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,269,0,81,34,80,162,273,80,80,477,17,99,388,65,367,0,0,2340,257,16,256,260,81,512]

theorem envBound61523 : H12AffineFastState.Bounded env61523 := by
  intro p hp
  have h : env61523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61522_61523 : H12AffineEnvironment.transform 11 81 env61522 = env61523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env61522 == env61523) = true)

theorem identity61523 : scanCanonicalize (H12AffineFastState.compose env61523 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound61523 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env61524 : List Nat := [2,4,8,16,32,64,128,256,512,272,367,81,269,0,81,34,80,162,273,80,80,477,17,99,388,65,367,0,0,75,257,16,256,260,81,512]

theorem envBound61524 : H12AffineFastState.Bounded env61524 := by
  intro p hp
  have h : env61524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61523_61524 : H12AffineEnvironment.transform 10 367 env61523 = env61524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env61523 == env61524) = true)

theorem identity61524 : scanCanonicalize (H12AffineFastState.compose env61524 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound61524 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env61525 : List Nat := [2,4,8,16,32,64,128,256,96,272,367,81,269,0,81,34,80,162,273,80,80,477,17,99,388,65,367,0,0,75,257,16,256,260,81,96]

theorem envBound61525 : H12AffineFastState.Bounded env61525 := by
  intro p hp
  have h : env61525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61524_61525 : H12AffineEnvironment.transform 8 96 env61524 = env61525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env61524 == env61525) = true)

theorem identity61525 : scanCanonicalize (H12AffineFastState.compose env61525 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound61525 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env61526 : List Nat := [2,4,8,16,32,64,128,20,96,4,123,81,25,0,81,34,80,162,5,80,80,201,17,99,144,65,123,0,0,75,21,16,20,16,81,96]

theorem envBound61526 : H12AffineFastState.Bounded env61526 := by
  intro p hp
  have h : env61526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61525_61526 : H12AffineEnvironment.transform 7 20 env61525 = env61526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env61525 == env61526) = true)

theorem identity61526 : scanCanonicalize (H12AffineFastState.compose env61526 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound61526 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env61527 : List Nat := [2,4,8,16,32,54,128,20,22,4,13,39,25,0,39,34,38,162,5,38,38,191,17,21,144,55,13,0,0,61,21,16,20,16,39,22]

theorem envBound61527 : H12AffineFastState.Bounded env61527 := by
  intro p hp
  have h : env61527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61526_61527 : H12AffineEnvironment.transform 5 54 env61526 = env61527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env61526 == env61527) = true)

theorem identity61527 : scanCanonicalize (H12AffineFastState.compose env61527 (packedSelected [1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound61527 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env61528 : List Nat := [2,4,8,16,32,54,31,20,22,4,13,39,25,0,39,34,38,61,5,38,38,32,17,21,15,55,13,0,0,61,21,16,20,16,39,22]

theorem envBound61528 : H12AffineFastState.Bounded env61528 := by
  intro p hp
  have h : env61528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61527_61528 : H12AffineEnvironment.transform 6 31 env61527 = env61528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env61527 == env61528) = true)

theorem identity61528 : scanCanonicalize (H12AffineFastState.compose env61528 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound61528 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61529 : List Nat := [2,4,8,16,29,11,31,20,22,4,13,26,25,0,26,31,27,0,5,27,27,29,17,21,15,10,13,0,0,0,21,16,20,16,26,22]

theorem envBound61529 : H12AffineFastState.Bounded env61529 := by
  intro p hp
  have h : env61529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61528_61529 : H12AffineEnvironment.transform 4 29 env61528 = env61529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env61528 == env61529) = true)

theorem identity61529 : scanCanonicalize (H12AffineFastState.compose env61529 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61530 : List Nat := [2,4,8,6,11,11,9,2,0,4,13,12,15,0,12,9,13,0,5,13,13,11,7,3,15,10,13,0,0,0,3,6,2,6,12,0]

theorem envBound61530 : H12AffineFastState.Bounded env61530 := by
  intro p hp
  have h : env61530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61529_61530 : H12AffineEnvironment.transform 3 6 env61529 = env61530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61529 == env61530) = true)

theorem identity61530 : scanCanonicalize (H12AffineFastState.compose env61530 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61531 : List Nat := [2,4,5,6,6,6,4,2,0,4,0,1,2,0,1,4,0,0,5,0,0,6,7,3,2,7,0,0,0,0,3,6,2,6,1,0]

theorem envBound61531 : H12AffineFastState.Bounded env61531 := by
  intro p hp
  have h : env61531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61530_61531 : H12AffineEnvironment.transform 2 5 env61530 = env61531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61530 == env61531) = true)

def env61532 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8494,80,8622,4416,8541,4097,4493,16,8558,12505,4112,366,0,1,6517,8204,17,256,8200,80,4688]

theorem envBound61532 : H12AffineFastState.Bounded env61532 := by
  intro p hp
  have h : env61532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61520_61532 : H12AffineEnvironment.transform 9 273 env61520 = env61532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61520 == env61532) = true)

theorem identity61532 : scanCanonicalize (H12AffineFastState.compose env61532 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound61532 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61533 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,1,4420,4406,80,4534,4416,4421,4097,4493,16,4470,193,4112,366,0,1,6517,4116,17,256,4112,80,4688]

theorem envBound61533 : H12AffineFastState.Bounded env61533 := by
  intro p hp
  have h : env61533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61532_61533 : H12AffineEnvironment.transform 12 4120 env61532 = env61533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env61532 == env61533) = true)

theorem identity61533 : scanCanonicalize (H12AffineFastState.compose env61533 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound61533 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env61534 : List Nat := [2,4,8,16,32,64,128,256,412,273,2048,4096,4120,1,4420,4406,80,4534,4416,4421,4097,4493,16,4470,193,4112,366,0,1,6517,4116,17,256,4112,80,4556]

theorem envBound61534 : H12AffineFastState.Bounded env61534 := by
  intro p hp
  have h : env61534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61533_61534 : H12AffineEnvironment.transform 8 412 env61533 = env61534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env61533 == env61534) = true)

theorem identity61534 : scanCanonicalize (H12AffineFastState.compose env61534 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound61534 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env61535 : List Nat := [2,4,8,16,32,64,128,256,412,273,2048,325,349,1,1,115,80,243,5,0,324,200,16,51,193,341,366,0,1,2096,337,17,256,341,80,137]

theorem envBound61535 : H12AffineFastState.Bounded env61535 := by
  intro p hp
  have h : env61535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61534_61535 : H12AffineEnvironment.transform 11 325 env61534 = env61535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env61534 == env61535) = true)

theorem identity61535 : scanCanonicalize (H12AffineFastState.compose env61535 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound61535 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env61536 : List Nat := [2,4,8,16,32,64,128,157,1,140,2048,216,192,1,1,115,80,243,5,0,217,200,16,51,193,200,243,0,1,2096,204,17,157,200,80,137]

theorem envBound61536 : H12AffineFastState.Bounded env61536 := by
  intro p hp
  have h : env61536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61535_61536 : H12AffineEnvironment.transform 7 157 env61535 = env61536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env61535 == env61536) = true)

theorem identity61536 : scanCanonicalize (H12AffineFastState.compose env61536 (packedSelected [2,3,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 233) := by decide +kernel

theorem selectedBound61536 : packedSelected [2,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env61537 : List Nat := [2,4,8,16,32,64,128,157,1,140,233,216,192,1,1,115,80,243,5,0,217,200,16,51,193,200,243,0,1,217,204,17,157,200,80,137]

theorem envBound61537 : H12AffineFastState.Bounded env61537 := by
  intro p hp
  have h : env61537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61536_61537 : H12AffineEnvironment.transform 10 233 env61536 = env61537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 233 env61536 == env61537) = true)

theorem identity61537 : scanCanonicalize (H12AffineFastState.compose env61537 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound61537 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env61538 : List Nat := [2,4,8,16,32,64,34,63,1,46,75,122,98,1,1,115,80,81,5,0,123,106,16,51,99,106,81,0,1,123,110,17,63,106,80,43]

theorem envBound61538 : H12AffineFastState.Bounded env61538 := by
  intro p hp
  have h : env61538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61537_61538 : H12AffineEnvironment.transform 6 34 env61537 = env61538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env61537 == env61538) = true)

theorem identity61538 : scanCanonicalize (H12AffineFastState.compose env61538 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound61538 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env61539 : List Nat := [2,4,8,16,32,58,34,63,1,46,49,0,24,1,1,9,42,43,5,0,1,16,16,51,25,16,43,0,1,1,20,17,63,16,42,43]

theorem envBound61539 : H12AffineFastState.Bounded env61539 := by
  intro p hp
  have h : env61539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61538_61539 : H12AffineEnvironment.transform 5 58 env61538 = env61539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env61538 == env61539) = true)

theorem identity61539 : scanCanonicalize (H12AffineFastState.compose env61539 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61539 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61540 : List Nat := [2,4,8,13,32,39,34,34,1,46,44,0,5,1,1,9,42,43,5,0,1,13,13,46,4,13,43,0,1,1,9,12,34,13,42,43]

theorem envBound61540 : H12AffineFastState.Bounded env61540 := by
  intro p hp
  have h : env61540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61539_61540 : H12AffineEnvironment.transform 3 13 env61539 = env61540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61539 == env61540) = true)

theorem identity61540 : scanCanonicalize (H12AffineFastState.compose env61540 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61540 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61541 : List Nat := [2,2,8,11,32,33,34,34,1,40,42,0,3,1,1,9,42,43,3,0,1,11,11,40,2,11,43,0,1,1,9,10,34,11,42,43]

theorem envBound61541 : H12AffineFastState.Bounded env61541 := by
  intro p hp
  have h : env61541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61540_61541 : H12AffineEnvironment.transform 1 2 env61540 = env61541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61540 == env61541) = true)

theorem identity61541 : scanCanonicalize (H12AffineFastState.compose env61541 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61541 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61542 : List Nat := [2,2,8,11,11,10,9,9,1,3,1,0,3,1,1,9,1,0,3,0,1,11,11,3,2,11,0,0,1,1,9,10,9,11,1,0]

theorem envBound61542 : H12AffineFastState.Bounded env61542 := by
  intro p hp
  have h : env61542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61541_61542 : H12AffineEnvironment.transform 4 11 env61541 = env61542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61541 == env61542) = true)

theorem identity61542 : scanCanonicalize (H12AffineFastState.compose env61542 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound61542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61543 : List Nat := [2,2,0,3,3,2,1,1,1,3,1,0,3,1,1,1,1,0,3,0,1,3,3,3,2,3,0,0,1,1,1,2,1,3,1,0]

theorem envBound61543 : H12AffineFastState.Bounded env61543 := by
  intro p hp
  have h : env61543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61542_61543 : H12AffineEnvironment.transform 2 0 env61542 = env61543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env61542 == env61543) = true)

theorem identity61543 : scanCanonicalize (H12AffineFastState.compose env61543 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61543 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env61544 : List Nat := [1,1,0,0,0,1,1,1,1,0,1,0,0,1,1,1,1,0,0,0,1,0,0,0,1,0,0,0,1,1,1,1,1,0,1,0]

theorem envBound61544 : H12AffineFastState.Bounded env61544 := by
  intro p hp
  have h : env61544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61543_61544 : H12AffineEnvironment.transform 0 1 env61543 = env61544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61543 == env61544) = true)

def env61545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4097,5276,74046,66897,13768,78895,1150,74815,1296,81226,8204,1280,256,65830,1345,5953]

theorem envBound61545 : H12AffineFastState.Bounded env61545 := by
  intro p hp
  have h : env61545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61518_61545 : H12AffineEnvironment.transform 17 65665 env61518 = env61545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61518 == env61545) = true)

theorem identity61545 : scanCanonicalize (H12AffineFastState.compose env61545 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound61545 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12671,5392,12798,4416,8541,4097,5276,4161,13358,13768,1360,1150,5440,1296,3125,8204,1280,256,12377,1345,5953]

theorem envBound61546 : H12AffineFastState.Bounded env61546 := by
  intro p hp
  have h : env61546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61545_61546 : H12AffineEnvironment.transform 15 12671 env61545 = env61546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env61545 == env61546) = true)

def env61547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8495,1344,8622,272,8541,81,1228,17,9342,9624,1360,1150,1296,1296,3125,8204,1280,256,8201,1345,1809]

theorem envBound61547 : H12AffineFastState.Bounded env61547 := by
  intro p hp
  have h : env61547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61546_61547 : H12AffineEnvironment.transform 11 80 env61546 = env61547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env61546 == env61547) = true)

theorem identity61547 : scanCanonicalize (H12AffineFastState.compose env61547 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound61547 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1052,1296,1344,1331,1344,1458,272,1345,81,1228,17,98,388,1360,1150,1296,1296,3125,1040,1280,256,1045,1345,1809]

theorem envBound61548 : H12AffineFastState.Bounded env61548 := by
  intro p hp
  have h : env61548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61547_61548 : H12AffineEnvironment.transform 12 1052 env61547 = env61548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env61547 == env61548) = true)

theorem identity61548 : scanCanonicalize (H12AffineFastState.compose env61548 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound61548 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61549 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,269,1,81,34,81,163,272,80,81,477,17,98,388,65,367,1,1,2340,257,17,256,260,80,512]

theorem envBound61549 : H12AffineFastState.Bounded env61549 := by
  intro p hp
  have h : env61549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61548_61549 : H12AffineEnvironment.transform 9 273 env61548 = env61549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61548 == env61549) = true)

theorem identity61549 : scanCanonicalize (H12AffineFastState.compose env61549 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound61549 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env61550 : List Nat := [2,4,8,16,32,64,128,256,512,273,390,80,269,1,81,34,81,163,272,80,81,477,17,98,388,65,367,1,1,162,257,17,256,260,80,512]

theorem envBound61550 : H12AffineFastState.Bounded env61550 := by
  intro p hp
  have h : env61550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61549_61550 : H12AffineEnvironment.transform 10 390 env61549 = env61550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env61549 == env61550) = true)

theorem identity61550 : scanCanonicalize (H12AffineFastState.compose env61550 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound61550 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env61551 : List Nat := [2,4,8,16,32,64,128,256,137,273,390,80,269,1,81,34,81,163,272,80,81,477,17,98,388,65,367,1,1,162,257,17,256,260,80,137]

theorem envBound61551 : H12AffineFastState.Bounded env61551 := by
  intro p hp
  have h : env61551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61550_61551 : H12AffineEnvironment.transform 8 137 env61550 = env61551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env61550 == env61551) = true)

def env61552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8494,1345,8623,273,8541,80,1229,16,9343,9625,1360,1150,1297,1296,3125,8204,1280,256,8200,1345,1808]

theorem envBound61552 : H12AffineFastState.Bounded env61552 := by
  intro p hp
  have h : env61552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61546_61552 : H12AffineEnvironment.transform 11 81 env61546 = env61552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env61546 == env61552) = true)

theorem identity61552 : scanCanonicalize (H12AffineFastState.compose env61552 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound61552 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1296,277,359,1345,486,273,276,80,1229,16,1078,1488,1360,1150,1297,1296,3125,69,1280,256,65,1345,1808]

theorem envBound61553 : H12AffineFastState.Bounded env61553 := by
  intro p hp
  have h : env61553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61552_61553 : H12AffineEnvironment.transform 12 73 env61552 = env61553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env61552 == env61553) = true)

theorem identity61553 : scanCanonicalize (H12AffineFastState.compose env61553 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound61553 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env61554 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,81,73,925,277,359,972,486,273,276,80,576,16,699,861,989,755,924,925,2744,69,909,256,65,972,413]

theorem envBound61554 : H12AffineFastState.Bounded env61554 := by
  intro p hp
  have h : env61554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61553_61554 : H12AffineEnvironment.transform 9 653 env61553 = env61554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env61553 == env61554) = true)

theorem identity61554 : scanCanonicalize (H12AffineFastState.compose env61554 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound61554 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env61555 : List Nat := [2,4,8,16,32,64,128,20,512,653,2048,81,73,649,1,115,728,242,5,0,80,576,16,699,585,713,755,648,649,2744,69,665,20,65,728,137]

theorem envBound61555 : H12AffineFastState.Bounded env61555 := by
  intro p hp
  have h : env61555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61554_61555 : H12AffineEnvironment.transform 7 20 env61554 = env61555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env61554 == env61555) = true)

theorem identity61555 : scanCanonicalize (H12AffineFastState.compose env61555 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 729) := by decide +kernel

theorem selectedBound61555 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env61556 : List Nat := [2,4,8,16,32,64,128,20,512,653,729,81,73,649,1,115,728,242,5,0,80,576,16,699,585,713,755,648,649,97,69,665,20,65,728,137]

theorem envBound61556 : H12AffineFastState.Bounded env61556 := by
  intro p hp
  have h : env61556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61555_61556 : H12AffineEnvironment.transform 10 729 env61555 = env61556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 729 env61555 == env61556) = true)

theorem identity61556 : scanCanonicalize (H12AffineFastState.compose env61556 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound61556 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env61557 : List Nat := [2,4,8,16,32,64,66,20,512,591,539,81,73,587,1,115,538,48,5,0,80,576,16,633,585,523,561,586,587,97,69,603,20,65,538,75]

theorem envBound61557 : H12AffineFastState.Bounded env61557 := by
  intro p hp
  have h : env61557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61556_61557 : H12AffineEnvironment.transform 6 66 env61556 = env61557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env61556 == env61557) = true)

theorem identity61557 : scanCanonicalize (H12AffineFastState.compose env61557 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound61557 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env61558 : List Nat := [2,4,8,16,16,64,66,20,512,591,539,81,73,587,1,67,538,0,5,0,80,576,16,585,585,523,513,586,587,81,69,603,20,65,538,75]

theorem envBound61558 : H12AffineFastState.Bounded env61558 := by
  intro p hp
  have h : env61558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61557_61558 : H12AffineEnvironment.transform 4 16 env61557 = env61558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env61557 == env61558) = true)

theorem identity61558 : scanCanonicalize (H12AffineFastState.compose env61558 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound61558 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61559 : List Nat := [2,4,8,16,16,64,66,20,26,85,1,81,73,81,1,67,0,0,5,0,80,90,16,83,83,17,27,80,81,81,69,65,20,65,0,75]

theorem envBound61559 : H12AffineFastState.Bounded env61559 := by
  intro p hp
  have h : env61559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61558_61559 : H12AffineEnvironment.transform 8 26 env61558 = env61559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env61558 == env61559) = true)

theorem identity61559 : scanCanonicalize (H12AffineFastState.compose env61559 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61559 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61560 : List Nat := [2,4,4,16,16,64,66,20,22,85,1,81,69,81,1,67,0,0,5,0,80,86,16,83,83,17,23,80,81,81,69,65,20,65,0,71]

theorem envBound61560 : H12AffineFastState.Bounded env61560 := by
  intro p hp
  have h : env61560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61559_61560 : H12AffineEnvironment.transform 2 4 env61559 = env61560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61559 == env61560) = true)

theorem identity61560 : scanCanonicalize (H12AffineFastState.compose env61560 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound61560 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env61561 : List Nat := [2,4,4,16,16,7,5,20,22,18,1,22,2,22,1,4,0,0,5,0,23,17,16,20,20,17,23,23,22,22,2,6,20,6,0,0]

theorem envBound61561 : H12AffineFastState.Bounded env61561 := by
  intro p hp
  have h : env61561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61560_61561 : H12AffineEnvironment.transform 5 7 env61560 = env61561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env61560 == env61561) = true)

theorem identity61561 : scanCanonicalize (H12AffineFastState.compose env61561 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61561 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env61562 : List Nat := [2,4,4,6,6,7,5,2,0,4,1,0,2,0,1,4,0,0,5,0,1,7,6,2,2,7,1,1,0,0,2,6,2,6,0,0]

theorem envBound61562 : H12AffineFastState.Bounded env61562 := by
  intro p hp
  have h : env61562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61561_61562 : H12AffineEnvironment.transform 3 6 env61561 = env61562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61561 == env61562) = true)

def env61563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4097,5276,74047,66897,13769,78895,328959,74814,1296,81227,8205,1280,256,65831,1345,5952]

theorem envBound61563 : H12AffineFastState.Bounded env61563 := by
  intro p hp
  have h : env61563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61517_61563 : H12AffineEnvironment.transform 13 1297 env61517 = env61563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env61517 == env61563) = true)

def env61564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4097,5276,74047,66897,13769,78895,1151,74814,1296,81227,8205,1280,256,65831,1345,5952]

theorem envBound61564 : H12AffineFastState.Bounded env61564 := by
  intro p hp
  have h : env61564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61563_61564 : H12AffineEnvironment.transform 17 65664 env61563 = env61564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61563 == env61564) = true)

theorem identity61564 : scanCanonicalize (H12AffineFastState.compose env61564 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound61564 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5239,12312,5367,4417,8540,4097,5276,13640,4390,13769,8280,1151,12361,1296,10556,8205,1280,256,5456,1345,5952]

theorem envBound61565 : H12AffineFastState.Bounded env61565 := by
  intro p hp
  have h : env61565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61564_61565 : H12AffineEnvironment.transform 15 5239 env61564 = env61565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env61564 == env61565) = true)

def env61566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5239,1344,5367,4417,5124,4097,5276,16,4390,145,5376,1151,1297,1296,7268,5461,1280,256,5456,1345,5952]

theorem envBound61566 : H12AffineFastState.Bounded env61566 := by
  intro p hp
  have h : env61566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61565_61566 : H12AffineEnvironment.transform 12 5464 env61565 = env61566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env61565 == env61566) = true)

theorem identity61566 : scanCanonicalize (H12AffineFastState.compose env61566 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound61566 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1108,268,1297,81,35,1344,163,1301,80,1109,200,16,1394,145,340,1151,1297,1296,2096,257,1280,256,260,1345,788]

theorem envBound61567 : H12AffineFastState.Bounded env61567 := by
  intro p hp
  have h : env61567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61566_61567 : H12AffineEnvironment.transform 11 1108 env61566 = env61567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env61566 == env61567) = true)

theorem identity61567 : scanCanonicalize (H12AffineFastState.compose env61567 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound61567 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61568 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,24,1029,81,35,1108,163,1025,80,1109,200,16,1126,145,64,1151,1029,1028,2096,21,1044,20,16,1109,512]

theorem envBound61568 : H12AffineFastState.Bounded env61568 := by
  intro p hp
  have h : env61568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61567_61568 : H12AffineEnvironment.transform 7 20 env61567 = env61568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env61567 == env61568) = true)

theorem identity61568 : scanCanonicalize (H12AffineFastState.compose env61568 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound61568 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env61569 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,24,1029,1,35,1028,163,1025,0,1029,152,16,1078,145,16,1071,1029,1028,2096,21,1044,20,16,1029,512]

theorem envBound61569 : H12AffineFastState.Bounded env61569 := by
  intro p hp
  have h : env61569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61568_61569 : H12AffineEnvironment.transform 5 16 env61568 = env61569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env61568 == env61569) = true)

theorem identity61569 : scanCanonicalize (H12AffineFastState.compose env61569 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound61569 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env61570 : List Nat := [2,4,8,16,32,16,128,20,512,46,2048,42,24,43,1,35,42,163,47,0,43,152,16,24,145,16,1,43,42,2096,21,58,20,16,43,512]

theorem envBound61570 : H12AffineFastState.Bounded env61570 := by
  intro p hp
  have h : env61570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61569_61570 : H12AffineEnvironment.transform 9 46 env61569 = env61570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env61569 == env61570) = true)

theorem identity61570 : scanCanonicalize (H12AffineFastState.compose env61570 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound61570 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61571 : List Nat := [2,4,8,16,32,16,128,20,162,46,2048,42,24,43,1,35,42,163,47,0,43,152,16,24,145,16,1,43,42,2096,21,58,20,16,43,162]

theorem envBound61571 : H12AffineFastState.Bounded env61571 := by
  intro p hp
  have h : env61571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61570_61571 : H12AffineEnvironment.transform 8 162 env61570 = env61571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env61570 == env61571) = true)

theorem identity61571 : scanCanonicalize (H12AffineFastState.compose env61571 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound61571 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env61572 : List Nat := [2,4,8,16,32,16,35,20,1,46,2048,42,24,43,1,35,42,0,47,0,43,59,16,24,50,16,1,43,42,2096,21,58,20,16,43,1]

theorem envBound61572 : H12AffineFastState.Bounded env61572 := by
  intro p hp
  have h : env61572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61571_61572 : H12AffineEnvironment.transform 6 35 env61571 = env61572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env61571 == env61572) = true)

theorem identity61572 : scanCanonicalize (H12AffineFastState.compose env61572 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound61572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61573 : List Nat := [2,4,8,16,32,16,35,20,1,46,48,42,24,43,1,35,42,0,47,0,43,59,16,24,50,16,1,43,42,0,21,58,20,16,43,1]

theorem envBound61573 : H12AffineFastState.Bounded env61573 := by
  intro p hp
  have h : env61573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61572_61573 : H12AffineEnvironment.transform 10 48 env61572 = env61573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env61572 == env61573) = true)

theorem identity61573 : scanCanonicalize (H12AffineFastState.compose env61573 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound61573 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env61574 : List Nat := [2,4,8,11,32,11,35,15,1,46,43,42,3,43,1,35,42,0,47,0,43,32,11,3,41,11,1,43,42,0,14,33,15,11,43,1]

theorem envBound61574 : H12AffineFastState.Bounded env61574 := by
  intro p hp
  have h : env61574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61573_61574 : H12AffineEnvironment.transform 3 11 env61573 = env61574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env61573 == env61574) = true)

theorem identity61574 : scanCanonicalize (H12AffineFastState.compose env61574 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61574 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61575 : List Nat := [2,4,8,11,11,11,8,15,1,5,0,1,3,0,1,8,1,0,4,0,0,11,11,3,2,11,1,0,1,0,14,10,15,11,0,1]

theorem envBound61575 : H12AffineFastState.Bounded env61575 := by
  intro p hp
  have h : env61575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61574_61575 : H12AffineEnvironment.transform 4 11 env61574 = env61575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61574 == env61575) = true)

theorem identity61575 : scanCanonicalize (H12AffineFastState.compose env61575 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61576 : List Nat := [2,2,8,11,11,11,8,9,1,3,0,1,3,0,1,8,1,0,2,0,0,11,11,3,2,11,1,0,1,0,8,10,9,11,0,1]

theorem envBound61576 : H12AffineFastState.Bounded env61576 := by
  intro p hp
  have h : env61576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61575_61576 : H12AffineEnvironment.transform 1 2 env61575 = env61576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61575 == env61576) = true)

def env61577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5239,1345,5367,4417,5125,4097,5276,17,4390,144,5377,1151,1296,1296,7269,5460,1280,256,5456,1345,5952]

theorem envBound61577 : H12AffineFastState.Bounded env61577 := by
  intro p hp
  have h : env61577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61565_61577 : H12AffineEnvironment.transform 12 5465 env61565 = env61577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env61565 == env61577) = true)

theorem identity61577 : scanCanonicalize (H12AffineFastState.compose env61577 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound61577 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1297,1029,1142,1345,1270,320,1028,0,1181,17,295,144,1280,1151,1296,1296,3172,1365,1280,256,1361,1345,1857]

theorem envBound61578 : H12AffineFastState.Bounded env61578 := by
  intro p hp
  have h : env61578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61577_61578 : H12AffineEnvironment.transform 11 1 env61577 = env61578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env61577 == env61578) = true)

theorem identity61578 : scanCanonicalize (H12AffineFastState.compose env61578 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound61578 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env61579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,951,1,1368,1297,1029,1142,1345,1270,320,1028,0,1181,17,295,144,1280,1151,1296,1296,2003,1365,1280,256,1361,1345,1857]

theorem envBound61579 : H12AffineFastState.Bounded env61579 := by
  intro p hp
  have h : env61579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61578_61579 : H12AffineEnvironment.transform 10 951 env61578 = env61579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env61578 == env61579) = true)

theorem identity61579 : scanCanonicalize (H12AffineFastState.compose env61579 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound61579 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env61580 : List Nat := [2,4,8,16,32,64,128,256,512,612,951,1,828,885,609,530,805,658,320,608,0,761,17,295,144,868,539,884,884,439,817,868,256,821,805,293]

theorem envBound61580 : H12AffineFastState.Bounded env61580 := by
  intro p hp
  have h : env61580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61579_61580 : H12AffineEnvironment.transform 9 612 env61579 = env61580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env61579 == env61580) = true)

theorem identity61580 : scanCanonicalize (H12AffineFastState.compose env61580 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound61580 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env61581 : List Nat := [2,4,8,16,32,64,57,256,512,612,782,1,828,885,609,530,805,555,320,608,0,576,17,295,41,868,539,884,884,270,817,868,256,821,805,293]

theorem envBound61581 : H12AffineFastState.Bounded env61581 := by
  intro p hp
  have h : env61581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61580_61581 : H12AffineEnvironment.transform 6 57 env61580 = env61581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env61580 == env61581) = true)

theorem identity61581 : scanCanonicalize (H12AffineFastState.compose env61581 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound61581 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env61582 : List Nat := [2,4,8,16,32,64,57,256,372,272,122,1,72,1,277,358,81,351,320,276,0,308,17,295,41,16,367,0,0,270,69,16,256,65,81,293]

theorem envBound61582 : H12AffineFastState.Bounded env61582 := by
  intro p hp
  have h : env61582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61581_61582 : H12AffineEnvironment.transform 8 372 env61581 = env61582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env61581 == env61582) = true)

theorem identity61582 : scanCanonicalize (H12AffineFastState.compose env61582 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound61582 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env61583 : List Nat := [2,4,8,16,32,64,57,14,122,30,122,1,72,1,27,104,81,81,78,26,0,58,17,41,41,16,97,0,0,0,69,16,14,65,81,43]

theorem envBound61583 : H12AffineFastState.Bounded env61583 := by
  intro p hp
  have h : env61583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61582_61583 : H12AffineEnvironment.transform 7 14 env61582 = env61583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env61582 == env61583) = true)

theorem identity61583 : scanCanonicalize (H12AffineFastState.compose env61583 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound61583 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61584 : List Nat := [2,4,8,16,32,59,57,14,1,30,1,1,51,1,27,19,42,42,53,26,0,58,17,41,41,16,26,0,0,0,62,16,14,58,42,43]

theorem envBound61584 : H12AffineFastState.Bounded env61584 := by
  intro p hp
  have h : env61584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61583_61584 : H12AffineEnvironment.transform 5 59 env61583 = env61584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env61583 == env61584) = true)

theorem identity61584 : scanCanonicalize (H12AffineFastState.compose env61584 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound61584 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61585 : List Nat := [2,4,8,7,32,44,46,14,1,9,1,1,36,1,12,4,42,42,34,13,0,45,6,41,41,7,13,0,0,0,41,7,14,45,42,43]

theorem envBound61585 : H12AffineFastState.Bounded env61585 := by
  intro p hp
  have h : env61585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61584_61585 : H12AffineEnvironment.transform 3 7 env61584 = env61585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env61584 == env61585) = true)

theorem identity61585 : scanCanonicalize (H12AffineFastState.compose env61585 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61585 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env61586 : List Nat := [2,4,5,7,32,33,35,3,1,4,1,1,36,1,1,4,39,39,34,0,0,32,6,36,36,7,0,0,0,0,36,7,3,32,39,38]

theorem envBound61586 : H12AffineFastState.Bounded env61586 := by
  intro p hp
  have h : env61586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61585_61586 : H12AffineEnvironment.transform 2 5 env61585 = env61586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61585 == env61586) = true)

def env61587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4097,5276,74047,66897,13769,78895,1150,74814,1296,81227,8205,1280,256,65831,1345,5952]

theorem envBound61587 : H12AffineFastState.Bounded env61587 := by
  intro p hp
  have h : env61587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61563_61587 : H12AffineEnvironment.transform 17 65665 env61563 = env61587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61563 == env61587) = true)

theorem identity61587 : scanCanonicalize (H12AffineFastState.compose env61587 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound61587 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,310,9561,439,4417,8540,4097,5276,8201,1127,13769,13593,1150,9480,1296,15485,8205,1280,256,17,1345,5952]

theorem envBound61588 : H12AffineFastState.Bounded env61588 := by
  intro p hp
  have h : env61588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61587_61588 : H12AffineEnvironment.transform 15 310 env61587 = env61588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env61587 == env61588) = true)

def env61589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,310,1345,439,4417,324,4097,5276,17,1127,5585,5377,1150,1296,1296,7269,21,1280,256,17,1345,5952]

theorem envBound61589 : H12AffineFastState.Bounded env61589 := by
  intro p hp
  have h : env61589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61588_61589 : H12AffineEnvironment.transform 12 24 env61588 = env61589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env61588 == env61589) = true)

theorem identity61589 : scanCanonicalize (H12AffineFastState.compose env61589 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound61589 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61590 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,81,325,310,1,439,4417,324,4097,4572,17,295,4241,4161,318,80,80,6437,21,64,256,17,1,4608]

theorem envBound61590 : H12AffineFastState.Bounded env61590 := by
  intro p hp
  have h : env61590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61589_61590 : H12AffineEnvironment.transform 9 320 env61589 = env61590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env61589 == env61590) = true)

theorem identity61590 : scanCanonicalize (H12AffineFastState.compose env61590 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2999) := by decide +kernel

theorem selectedBound61590 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env61591 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2999,24,81,325,310,1,439,2806,324,2998,2667,17,295,2854,3062,318,80,80,658,21,64,256,17,1,2487]

theorem envBound61591 : H12AffineFastState.Bounded env61591 := by
  intro p hp
  have h : env61591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61590_61591 : H12AffineEnvironment.transform 11 2999 env61590 = env61591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2999 env61590 == env61591) = true)

theorem identity61591 : scanCanonicalize (H12AffineFastState.compose env61591 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound61591 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env61592 : List Nat := [2,4,8,16,32,64,128,256,512,320,147,804,24,81,325,310,1,439,613,324,805,760,17,295,949,869,318,80,80,658,21,64,256,17,1,292]

theorem envBound61592 : H12AffineFastState.Bounded env61592 := by
  intro p hp
  have h : env61592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61591_61592 : H12AffineEnvironment.transform 10 147 env61591 = env61592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env61591 == env61592) = true)

theorem identity61592 : scanCanonicalize (H12AffineFastState.compose env61592 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound61592 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env61593 : List Nat := [2,4,8,16,32,64,128,256,461,320,147,233,24,81,325,310,1,439,424,324,232,309,17,295,120,168,318,80,80,351,21,64,256,17,1,292]

theorem envBound61593 : H12AffineFastState.Bounded env61593 := by
  intro p hp
  have h : env61593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61592_61593 : H12AffineEnvironment.transform 8 461 env61592 = env61593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env61592 == env61593) = true)

theorem identity61593 : scanCanonicalize (H12AffineFastState.compose env61593 (packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound61593 : packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env61594 : List Nat := [2,4,8,16,32,17,128,256,412,273,147,184,24,0,276,310,1,439,424,277,185,309,17,295,41,168,318,1,1,270,21,17,256,17,1,292]

theorem envBound61594 : H12AffineFastState.Bounded env61594 := by
  intro p hp
  have h : env61594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61593_61594 : H12AffineEnvironment.transform 5 17 env61593 = env61594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env61593 == env61594) = true)

theorem identity61594 : scanCanonicalize (H12AffineFastState.compose env61594 (packedSelected [2,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound61594 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env61595 : List Nat := [2,4,8,16,32,17,128,21,137,4,147,184,24,0,1,35,1,162,189,0,185,32,17,50,41,168,43,1,1,27,21,17,21,17,1,49]

theorem envBound61595 : H12AffineFastState.Bounded env61595 := by
  intro p hp
  have h : env61595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61594_61595 : H12AffineEnvironment.transform 7 21 env61594 = env61595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env61594 == env61595) = true)

theorem identity61595 : scanCanonicalize (H12AffineFastState.compose env61595 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61595 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61596 : List Nat := [2,4,4,16,32,17,128,21,133,4,147,180,20,0,1,35,1,162,177,0,181,32,17,50,37,164,39,1,1,23,21,17,21,17,1,49]

theorem envBound61596 : H12AffineFastState.Bounded env61596 := by
  intro p hp
  have h : env61596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61595_61596 : H12AffineEnvironment.transform 2 4 env61595 = env61596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61595 == env61596) = true)

theorem identity61596 : scanCanonicalize (H12AffineFastState.compose env61596 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound61596 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env61597 : List Nat := [2,4,4,16,6,17,128,21,133,4,147,146,20,0,1,5,1,132,151,0,147,6,17,20,3,130,1,1,1,23,21,17,21,17,1,23]

theorem envBound61597 : H12AffineFastState.Bounded env61597 := by
  intro p hp
  have h : env61597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61596_61597 : H12AffineEnvironment.transform 4 6 env61596 = env61597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env61596 == env61597) = true)

theorem identity61597 : scanCanonicalize (H12AffineFastState.compose env61597 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61598 : List Nat := [2,4,4,6,6,7,128,3,133,4,133,132,2,0,1,5,1,132,129,0,133,6,7,2,3,130,1,1,1,1,3,7,3,7,1,1]

theorem envBound61598 : H12AffineFastState.Bounded env61598 := by
  intro p hp
  have h : env61598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61597_61598 : H12AffineEnvironment.transform 3 6 env61597 = env61598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61597 == env61598) = true)

theorem identity61598 : scanCanonicalize (H12AffineFastState.compose env61598 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound61598 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env61599 : List Nat := [2,4,4,6,6,7,5,3,0,4,0,1,2,0,1,5,1,1,4,0,0,6,7,2,3,7,1,1,1,1,3,7,3,7,1,1]

theorem envBound61599 : H12AffineFastState.Bounded env61599 := by
  intro p hp
  have h : env61599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61598_61599 : H12AffineEnvironment.transform 6 5 env61598 = env61599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env61598 == env61599) = true)

theorem identity61599 : scanCanonicalize (H12AffineFastState.compose env61599 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound61599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61600 : List Nat := [2,0,0,2,2,3,1,3,0,0,0,1,2,0,1,1,1,1,0,0,0,2,3,2,3,3,1,1,1,1,3,3,3,3,1,1]

theorem envBound61600 : H12AffineFastState.Bounded env61600 := by
  intro p hp
  have h : env61600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61599_61600 : H12AffineEnvironment.transform 1 0 env61599 = env61600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env61599 == env61600) = true)

theorem identity61600 : scanCanonicalize (H12AffineFastState.compose env61600 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61600 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env61601 : List Nat := [1,0,0,1,1,0,1,0,0,0,0,1,1,0,1,1,1,1,0,0,0,1,0,1,0,0,1,1,1,1,0,0,0,0,1,1]

theorem envBound61601 : H12AffineFastState.Bounded env61601 := by
  intro p hp
  have h : env61601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61600_61601 : H12AffineEnvironment.transform 0 1 env61600 = env61601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61600 == env61601) = true)

def env61602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,324,310,1344,439,4417,325,4097,5276,16,1127,5584,5376,1150,1297,1296,7268,20,1280,256,17,1345,5952]

theorem envBound61602 : H12AffineFastState.Bounded env61602 := by
  intro p hp
  have h : env61602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61588_61602 : H12AffineEnvironment.transform 12 25 env61588 = env61602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env61588 == env61602) = true)

theorem identity61602 : scanCanonicalize (H12AffineFastState.compose env61602 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound61602 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61603 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,25,1028,81,35,1109,162,4180,80,4097,5276,16,1127,5317,5141,1150,1028,1029,7268,20,1045,21,17,1108,5717]

theorem envBound61603 : H12AffineFastState.Bounded env61603 := by
  intro p hp
  have h : env61603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61602_61603 : H12AffineEnvironment.transform 7 21 env61602 = env61603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env61602 == env61603) = true)

theorem identity61603 : scanCanonicalize (H12AffineFastState.compose env61603 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound61603 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61604 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,25,1028,81,35,1109,162,1025,80,1108,201,16,1127,144,64,1150,1028,1029,2097,20,1045,21,17,1108,512]

theorem envBound61604 : H12AffineFastState.Bounded env61604 := by
  intro p hp
  have h : env61604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61603_61604 : H12AffineEnvironment.transform 11 1109 env61603 = env61604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env61603 == env61604) = true)

theorem identity61604 : scanCanonicalize (H12AffineFastState.compose env61604 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound61604 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env61605 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,25,1028,1,35,1029,162,1025,0,1028,153,16,1079,144,16,1070,1028,1029,2097,20,1045,21,17,1028,512]

theorem envBound61605 : H12AffineFastState.Bounded env61605 := by
  intro p hp
  have h : env61605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61604_61605 : H12AffineEnvironment.transform 5 16 env61604 = env61605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env61604 == env61605) = true)

theorem identity61605 : scanCanonicalize (H12AffineFastState.compose env61605 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound61605 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env61606 : List Nat := [2,4,8,16,32,16,19,21,512,1024,2048,1029,25,1028,1,35,1029,49,1025,0,1028,10,16,1079,3,16,1070,1028,1029,2097,20,1045,21,17,1028,512]

theorem envBound61606 : H12AffineFastState.Bounded env61606 := by
  intro p hp
  have h : env61606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61605_61606 : H12AffineEnvironment.transform 6 19 env61605 = env61606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env61605 == env61606) = true)

theorem identity61606 : scanCanonicalize (H12AffineFastState.compose env61606 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound61606 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61607 : List Nat := [2,4,8,16,32,16,19,21,512,542,2048,539,25,538,1,35,539,49,543,0,538,10,16,553,3,16,560,538,539,2097,20,523,21,17,538,512]

theorem envBound61607 : H12AffineFastState.Bounded env61607 := by
  intro p hp
  have h : env61607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61606_61607 : H12AffineEnvironment.transform 9 542 env61606 = env61607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env61606 == env61607) = true)

theorem identity61607 : scanCanonicalize (H12AffineFastState.compose env61607 (packedSelected [1,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound61607 : packedSelected [1,2,4,11] rootPS < 2^1333 := by decide +kernel

def env61608 : List Nat := [2,4,8,16,32,16,19,21,512,542,42,539,25,538,1,35,539,49,543,0,538,10,16,553,3,16,560,538,539,27,20,523,21,17,538,512]

theorem envBound61608 : H12AffineFastState.Bounded env61608 := by
  intro p hp
  have h : env61608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61607_61608 : H12AffineEnvironment.transform 10 42 env61607 = env61608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env61607 == env61608) = true)

theorem identity61608 : scanCanonicalize (H12AffineFastState.compose env61608 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound61608 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env61609 : List Nat := [2,4,8,16,16,16,19,21,512,542,26,539,25,538,1,19,539,1,543,0,538,10,16,537,3,16,512,538,539,27,20,523,21,17,538,512]

theorem envBound61609 : H12AffineFastState.Bounded env61609 := by
  intro p hp
  have h : env61609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61608_61609 : H12AffineEnvironment.transform 4 16 env61608 = env61609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env61608 == env61609) = true)

theorem identity61609 : scanCanonicalize (H12AffineFastState.compose env61609 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound61609 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61610 : List Nat := [2,4,8,11,11,11,8,14,512,517,1,512,2,513,1,8,512,1,516,0,513,10,11,514,3,11,512,513,512,0,15,523,14,10,513,512]

theorem envBound61610 : H12AffineFastState.Bounded env61610 := by
  intro p hp
  have h : env61610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61609_61610 : H12AffineEnvironment.transform 3 11 env61609 = env61610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env61609 == env61610) = true)

theorem identity61610 : scanCanonicalize (H12AffineFastState.compose env61610 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound61610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61611 : List Nat := [2,4,8,11,11,11,8,14,0,5,1,0,2,1,1,8,0,1,4,0,1,10,11,2,3,11,0,1,0,0,15,11,14,10,1,0]

theorem envBound61611 : H12AffineFastState.Bounded env61611 := by
  intro p hp
  have h : env61611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61610_61611 : H12AffineEnvironment.transform 8 0 env61610 = env61611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env61610 == env61611) = true)

theorem identity61611 : scanCanonicalize (H12AffineFastState.compose env61611 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61611 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61612 : List Nat := [2,2,8,11,11,11,8,8,0,3,1,0,2,1,1,8,0,1,2,0,1,10,11,2,3,11,0,1,0,0,9,11,8,10,1,0]

theorem envBound61612 : H12AffineFastState.Bounded env61612 := by
  intro p hp
  have h : env61612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61611_61612 : H12AffineEnvironment.transform 1 2 env61611 = env61612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61611 == env61612) = true)

def env61613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123165,28889,78894,385203,90415,1297,96346,25884,1280,256,82999,1345,21072]

theorem envBound61613 : H12AffineFastState.Bounded env61613 := by
  intro p hp
  have h : env61613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61515_61613 : H12AffineEnvironment.transform 18 21585 env61515 = env61613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env61515 == env61613) = true)

theorem identity61613 : scanCanonicalize (H12AffineFastState.compose env61613 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound61613 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env61614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4097,17612,91182,87297,28889,78894,349359,90415,1297,96346,25884,1280,256,82999,1345,21072]

theorem envBound61614 : H12AffineFastState.Bounded env61614 := by
  intro p hp
  have h : env61614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61613_61614 : H12AffineEnvironment.transform 14 13340 env61613 = env61614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env61613 == env61614) = true)

def env61615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4097,476,74046,69649,13769,78894,332223,74815,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound61615 : H12AffineFastState.Bounded env61615 := by
  intro p hp
  have h : env61615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61614_61615 : H12AffineEnvironment.transform 13 1296 env61614 = env61615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env61614 == env61615) = true)

def env61616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4097,476,74046,69649,13769,78894,4415,74815,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound61616 : H12AffineFastState.Bounded env61616 := by
  intro p hp
  have h : env61616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61615_61616 : H12AffineEnvironment.transform 17 65664 env61615 = env61616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61615 == env61616) = true)

theorem identity61616 : scanCanonicalize (H12AffineFastState.compose env61616 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound61616 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12671,5392,12799,4417,13341,4097,476,4161,8558,13769,1361,4415,5440,1297,3125,8204,1280,256,12376,1345,5952]

theorem envBound61617 : H12AffineFastState.Bounded env61617 := by
  intro p hp
  have h : env61617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61616_61617 : H12AffineEnvironment.transform 15 12671 env61616 = env61617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env61616 == env61617) = true)

def env61618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,8495,1344,8623,273,9293,81,476,17,8558,9625,1361,367,1296,1297,3125,8204,1280,256,8200,1345,1808]

theorem envBound61618 : H12AffineFastState.Bounded env61618 := by
  intro p hp
  have h : env61618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61617_61618 : H12AffineEnvironment.transform 11 80 env61617 = env61618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env61617 == env61618) = true)

theorem identity61618 : scanCanonicalize (H12AffineFastState.compose env61618 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound61618 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1296,276,1143,1344,1271,273,277,81,476,17,1078,193,1361,367,1296,1297,3125,1364,1280,256,1360,1345,1808]

theorem envBound61619 : H12AffineFastState.Bounded env61619 := by
  intro p hp
  have h : env61619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61618_61619 : H12AffineEnvironment.transform 12 1368 env61618 = env61619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env61618 == env61619) = true)

theorem identity61619 : scanCanonicalize (H12AffineFastState.compose env61619 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound61619 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env61620 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,484,428,276,203,508,75,273,277,81,476,17,138,193,493,367,428,429,2185,488,444,256,492,509,940]

theorem envBound61620 : H12AffineFastState.Bounded env61620 := by
  intro p hp
  have h : env61620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61619_61620 : H12AffineEnvironment.transform 9 188 env61619 = env61620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env61619 == env61620) = true)

theorem identity61620 : scanCanonicalize (H12AffineFastState.compose env61620 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound61620 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env61621 : List Nat := [2,4,8,16,32,64,128,256,217,188,2048,80,484,428,276,203,508,75,273,277,81,476,17,138,193,493,367,428,429,2185,488,444,256,492,509,373]

theorem envBound61621 : H12AffineFastState.Bounded env61621 := by
  intro p hp
  have h : env61621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61620_61621 : H12AffineEnvironment.transform 8 217 env61620 = env61621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env61620 == env61621) = true)

theorem identity61621 : scanCanonicalize (H12AffineFastState.compose env61621 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound61621 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env61622 : List Nat := [2,4,8,16,32,64,66,256,27,126,2048,80,294,366,276,9,318,75,273,277,81,286,17,72,3,303,367,366,367,2123,298,382,256,302,319,373]

theorem envBound61622 : H12AffineFastState.Bounded env61622 := by
  intro p hp
  have h : env61622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61621_61622 : H12AffineEnvironment.transform 6 66 env61621 = env61622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env61621 == env61622) = true)

theorem identity61622 : scanCanonicalize (H12AffineFastState.compose env61622 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound61622 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env61623 : List Nat := [2,4,8,16,32,64,66,256,27,126,318,80,294,366,276,9,318,75,273,277,81,286,17,72,3,303,367,366,367,373,298,382,256,302,319,373]

theorem envBound61623 : H12AffineFastState.Bounded env61623 := by
  intro p hp
  have h : env61623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61622_61623 : H12AffineEnvironment.transform 10 318 env61622 = env61623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env61622 == env61623) = true)

theorem identity61623 : scanCanonicalize (H12AffineFastState.compose env61623 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound61623 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env61624 : List Nat := [2,4,8,16,32,64,66,110,27,126,80,80,72,0,122,9,80,75,127,123,81,112,17,72,3,65,1,0,1,27,68,16,110,64,81,27]

theorem envBound61624 : H12AffineFastState.Bounded env61624 := by
  intro p hp
  have h : env61624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61623_61624 : H12AffineEnvironment.transform 7 110 env61623 = env61624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env61623 == env61624) = true)

theorem identity61624 : scanCanonicalize (H12AffineFastState.compose env61624 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61625 : List Nat := [2,4,8,16,11,64,66,69,27,85,80,80,72,0,81,9,80,75,84,80,81,91,17,72,3,65,1,0,1,27,68,16,69,64,81,27]

theorem envBound61625 : H12AffineFastState.Bounded env61625 := by
  intro p hp
  have h : env61625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61624_61625 : H12AffineEnvironment.transform 4 11 env61624 = env61625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61624 == env61625) = true)

theorem identity61625 : scanCanonicalize (H12AffineFastState.compose env61625 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound61625 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env61626 : List Nat := [2,4,8,16,11,11,9,14,27,30,27,27,3,0,26,9,27,0,31,27,26,16,17,3,3,10,1,0,1,27,15,16,14,11,26,27]

theorem envBound61626 : H12AffineFastState.Bounded env61626 := by
  intro p hp
  have h : env61626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61625_61626 : H12AffineEnvironment.transform 5 11 env61625 = env61626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env61625 == env61626) = true)

theorem identity61626 : scanCanonicalize (H12AffineFastState.compose env61626 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound61626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61627 : List Nat := [2,4,8,10,11,11,9,14,1,4,1,1,3,0,0,9,1,0,5,1,0,10,11,3,3,10,1,0,1,1,15,10,14,11,0,1]

theorem envBound61627 : H12AffineFastState.Bounded env61627 := by
  intro p hp
  have h : env61627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61626_61627 : H12AffineEnvironment.transform 3 10 env61626 = env61627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env61626 == env61627) = true)

theorem identity61627 : scanCanonicalize (H12AffineFastState.compose env61627 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61628 : List Nat := [2,4,5,7,6,6,4,3,1,4,1,1,3,0,0,4,1,0,5,1,0,7,6,3,3,7,1,0,1,1,2,7,3,6,0,1]

theorem envBound61628 : H12AffineFastState.Bounded env61628 := by
  intro p hp
  have h : env61628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61627_61628 : H12AffineEnvironment.transform 2 5 env61627 = env61628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61627 == env61628) = true)

def env61629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,8494,1345,8622,272,9292,80,476,16,8558,9624,1361,366,1297,1297,3125,8204,1280,256,8201,1345,1809]

theorem envBound61629 : H12AffineFastState.Bounded env61629 := by
  intro p hp
  have h : env61629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61617_61629 : H12AffineEnvironment.transform 11 81 env61617 = env61629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env61617 == env61629) = true)

theorem identity61629 : scanCanonicalize (H12AffineFastState.compose env61629 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound61629 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1053,1296,80,1331,1345,1459,272,81,80,476,16,1395,389,1361,366,1297,1297,3125,1041,1280,256,1044,1345,1809]

theorem envBound61630 : H12AffineFastState.Bounded env61630 := by
  intro p hp
  have h : env61630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61629_61630 : H12AffineEnvironment.transform 12 1053 env61629 = env61630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env61629 == env61630) = true)

theorem identity61630 : scanCanonicalize (H12AffineFastState.compose env61630 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound61630 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61631 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,268,1,80,34,80,162,272,81,80,476,16,98,389,64,366,0,0,2340,256,17,256,261,80,512]

theorem envBound61631 : H12AffineFastState.Bounded env61631 := by
  intro p hp
  have h : env61631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61630_61631 : H12AffineEnvironment.transform 9 273 env61630 = env61631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61630 == env61631) = true)

def env61632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4097,476,74046,69649,13769,78894,4414,74815,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound61632 : H12AffineFastState.Bounded env61632 := by
  intro p hp
  have h : env61632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61615_61632 : H12AffineEnvironment.transform 17 65665 env61615 = env61632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61615 == env61632) = true)

theorem identity61632 : scanCanonicalize (H12AffineFastState.compose env61632 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound61632 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9278,81,9407,4417,13341,4097,476,1280,13359,13769,4112,4414,1,1297,6516,8204,1280,256,9497,1345,5952]

theorem envBound61633 : H12AffineFastState.Bounded env61633 := by
  intro p hp
  have h : env61633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61632_61633 : H12AffineEnvironment.transform 15 9278 env61632 = env61633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env61632 == env61633) = true)

def env61634 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,8494,81,8623,4417,12557,4097,476,16,12607,12505,4112,4414,1,1,6516,8204,16,256,8201,81,4688]

theorem envBound61634 : H12AffineFastState.Bounded env61634 := by
  intro p hp
  have h : env61634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61633_61634 : H12AffineEnvironment.transform 9 272 env61633 = env61634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61633 == env61634) = true)

theorem identity61634 : scanCanonicalize (H12AffineFastState.compose env61634 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound61634 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61635 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4444,0,80,4210,81,4339,4417,81,4097,476,16,99,389,4112,4414,1,1,6516,4432,16,256,4437,81,4688]

theorem envBound61635 : H12AffineFastState.Bounded env61635 := by
  intro p hp
  have h : env61635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61634_61635 : H12AffineEnvironment.transform 12 4444 env61634 = env61635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env61634 == env61635) = true)

theorem identity61635 : scanCanonicalize (H12AffineFastState.compose env61635 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound61635 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61636 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,268,0,80,34,81,163,273,81,81,476,16,99,389,64,366,1,1,2340,256,16,256,261,81,512]

theorem envBound61636 : H12AffineFastState.Bounded env61636 := by
  intro p hp
  have h : env61636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61635_61636 : H12AffineEnvironment.transform 11 80 env61635 = env61636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env61635 == env61636) = true)

theorem identity61636 : scanCanonicalize (H12AffineFastState.compose env61636 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound61636 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env61637 : List Nat := [2,4,8,16,32,64,105,256,512,272,2048,80,268,0,80,34,81,74,273,81,81,309,16,99,364,64,366,1,1,2340,256,16,256,261,81,512]

theorem envBound61637 : H12AffineFastState.Bounded env61637 := by
  intro p hp
  have h : env61637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61636_61637 : H12AffineEnvironment.transform 6 105 env61636 = env61637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env61636 == env61637) = true)

theorem identity61637 : scanCanonicalize (H12AffineFastState.compose env61637 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound61637 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env61638 : List Nat := [2,4,8,16,32,64,105,256,512,272,862,80,268,0,80,34,81,74,273,81,81,309,16,99,364,64,366,1,1,634,256,16,256,261,81,512]

theorem envBound61638 : H12AffineFastState.Bounded env61638 := by
  intro p hp
  have h : env61638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61637_61638 : H12AffineEnvironment.transform 10 862 env61637 = env61638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env61637 == env61638) = true)

theorem identity61638 : scanCanonicalize (H12AffineFastState.compose env61638 (packedSelected [0,7,10,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound61638 : packedSelected [0,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61639 : List Nat := [2,4,8,16,32,16,57,256,512,272,782,0,268,0,0,34,1,26,273,1,1,309,16,51,316,16,318,1,1,554,256,16,256,261,1,512]

theorem envBound61639 : H12AffineFastState.Bounded env61639 := by
  intro p hp
  have h : env61639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61638_61639 : H12AffineEnvironment.transform 5 16 env61638 = env61639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env61638 == env61639) = true)

theorem identity61639 : scanCanonicalize (H12AffineFastState.compose env61639 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound61639 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61640 : List Nat := [2,4,8,11,32,11,34,256,512,267,782,0,268,0,0,34,1,1,266,1,1,302,11,40,295,11,293,1,1,554,256,11,256,261,1,512]

theorem envBound61640 : H12AffineFastState.Bounded env61640 := by
  intro p hp
  have h : env61640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61639_61640 : H12AffineEnvironment.transform 3 11 env61639 = env61640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env61639 == env61640) = true)

theorem identity61640 : scanCanonicalize (H12AffineFastState.compose env61640 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound61640 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env61641 : List Nat := [2,4,8,11,32,11,34,256,270,267,0,0,268,0,0,34,1,1,266,1,1,302,11,40,295,11,293,1,1,292,256,11,256,261,1,270]

theorem envBound61641 : H12AffineFastState.Bounded env61641 := by
  intro p hp
  have h : env61641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61640_61641 : H12AffineEnvironment.transform 8 270 env61640 = env61641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env61640 == env61641) = true)

def env61642 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,8495,81,8622,4417,12556,4097,476,17,12606,12504,4112,4414,1,0,6516,8204,17,256,8200,80,4689]

theorem envBound61642 : H12AffineFastState.Bounded env61642 := by
  intro p hp
  have h : env61642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61633_61642 : H12AffineEnvironment.transform 9 273 env61633 = env61642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61633 == env61642) = true)

theorem identity61642 : scanCanonicalize (H12AffineFastState.compose env61642 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound61642 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61643 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,1,4420,358,81,487,4417,4421,4097,476,17,4471,4241,4112,4414,1,0,6516,69,17,256,65,80,4689]

theorem envBound61643 : H12AffineFastState.Bounded env61643 := by
  intro p hp
  have h : env61643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61642_61643 : H12AffineEnvironment.transform 12 73 env61642 = env61643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env61642 == env61643) = true)

theorem identity61643 : scanCanonicalize (H12AffineFastState.compose env61643 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound61643 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env61644 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,509,73,1,185,358,81,487,188,184,508,476,17,138,364,493,195,1,0,2185,69,17,256,65,80,940]

theorem envBound61644 : H12AffineFastState.Bounded env61644 := by
  intro p hp
  have h : env61644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61643_61644 : H12AffineEnvironment.transform 11 509 env61643 = env61644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env61643 == env61644) = true)

theorem identity61644 : scanCanonicalize (H12AffineFastState.compose env61644 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound61644 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env61645 : List Nat := [2,4,8,16,32,64,128,256,217,273,2048,509,73,1,185,358,81,487,188,184,508,476,17,138,364,493,195,1,0,2185,69,17,256,65,80,373]

theorem envBound61645 : H12AffineFastState.Bounded env61645 := by
  intro p hp
  have h : env61645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61644_61645 : H12AffineEnvironment.transform 8 217 env61644 = env61645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env61644 == env61645) = true)

theorem identity61645 : scanCanonicalize (H12AffineFastState.compose env61645 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound61645 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env61646 : List Nat := [2,4,8,16,32,64,128,111,217,126,2048,146,73,1,185,9,81,136,188,184,147,179,17,138,3,130,195,1,0,2185,69,17,111,65,80,26]

theorem envBound61646 : H12AffineFastState.Bounded env61646 := by
  intro p hp
  have h : env61646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61645_61646 : H12AffineEnvironment.transform 7 111 env61645 = env61646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env61645 == env61646) = true)

theorem identity61646 : scanCanonicalize (H12AffineFastState.compose env61646 (packedSelected [2,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound61646 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env61647 : List Nat := [2,4,8,16,32,64,128,111,217,126,195,146,73,1,185,9,81,136,188,184,147,179,17,138,3,130,195,1,0,74,69,17,111,65,80,26]

theorem envBound61647 : H12AffineFastState.Bounded env61647 := by
  intro p hp
  have h : env61647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61646_61647 : H12AffineEnvironment.transform 10 195 env61646 = env61647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env61646 == env61647) = true)

theorem identity61647 : scanCanonicalize (H12AffineFastState.compose env61647 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61647 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env61648 : List Nat := [2,4,8,16,11,64,128,68,217,85,195,146,73,1,146,9,81,136,151,147,147,152,17,138,3,130,195,1,0,74,69,17,68,65,80,26]

theorem envBound61648 : H12AffineFastState.Bounded env61648 := by
  intro p hp
  have h : env61648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61647_61648 : H12AffineEnvironment.transform 4 11 env61647 = env61648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61647 == env61648) = true)

theorem identity61648 : scanCanonicalize (H12AffineFastState.compose env61648 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound61648 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env61649 : List Nat := [2,4,8,16,11,17,128,21,136,4,146,146,24,1,146,9,0,136,151,147,147,152,17,138,3,130,146,1,0,27,20,17,21,16,1,26]

theorem envBound61649 : H12AffineFastState.Bounded env61649 := by
  intro p hp
  have h : env61649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61648_61649 : H12AffineEnvironment.transform 5 17 env61648 = env61649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env61648 == env61649) = true)

theorem identity61649 : scanCanonicalize (H12AffineFastState.compose env61649 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound61649 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61650 : List Nat := [2,4,8,16,11,17,30,21,22,4,12,12,24,1,12,9,0,22,9,13,13,6,17,20,3,28,12,1,0,27,20,17,21,16,1,26]

theorem envBound61650 : H12AffineFastState.Bounded env61650 := by
  intro p hp
  have h : env61650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61649_61650 : H12AffineEnvironment.transform 6 30 env61649 = env61650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env61649 == env61650) = true)

theorem identity61650 : scanCanonicalize (H12AffineFastState.compose env61650 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61650 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env61651 : List Nat := [2,4,5,16,6,17,19,21,22,4,1,1,21,1,1,4,0,22,4,0,0,6,17,20,3,17,1,1,0,22,20,17,21,16,1,23]

theorem envBound61651 : H12AffineFastState.Bounded env61651 := by
  intro p hp
  have h : env61651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61650_61651 : H12AffineEnvironment.transform 2 5 env61650 = env61651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61650 == env61651) = true)

theorem identity61651 : scanCanonicalize (H12AffineFastState.compose env61651 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound61651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61652 : List Nat := [2,1,0,16,3,17,19,16,19,1,1,1,16,1,1,1,0,19,1,0,0,3,17,17,3,17,1,1,0,19,17,17,16,16,1,18]

theorem envBound61652 : H12AffineFastState.Bounded env61652 := by
  intro p hp
  have h : env61652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61651_61652 : H12AffineEnvironment.transform 1 1 env61651 = env61652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env61651 == env61652) = true)

theorem identity61652 : scanCanonicalize (H12AffineFastState.compose env61652 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound61652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61653 : List Nat := [2,1,0,2,3,3,1,2,1,1,1,1,2,1,1,1,0,1,1,0,0,3,3,3,3,3,1,1,0,1,3,3,2,2,1,0]

theorem envBound61653 : H12AffineFastState.Bounded env61653 := by
  intro p hp
  have h : env61653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61652_61653 : H12AffineEnvironment.transform 3 2 env61652 = env61653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env61652 == env61653) = true)

theorem identity61653 : scanCanonicalize (H12AffineFastState.compose env61653 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61653 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env61654 : List Nat := [1,1,0,1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,0,0,0,0,0,0,1,1,0,1,0,0,1,1,1,0]

theorem envBound61654 : H12AffineFastState.Bounded env61654 := by
  intro p hp
  have h : env61654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61653_61654 : H12AffineEnvironment.transform 0 1 env61653 = env61654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61653 == env61654) = true)

def env61655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4097,477,74047,69648,13768,78894,332222,74814,1297,81227,8205,1280,256,65830,1345,5953]

theorem envBound61655 : H12AffineFastState.Bounded env61655 := by
  intro p hp
  have h : env61655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61614_61655 : H12AffineEnvironment.transform 13 1297 env61614 = env61655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env61614 == env61655) = true)

def env61656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4097,477,74047,69648,13768,78894,4414,74814,1297,81227,8205,1280,256,65830,1345,5953]

theorem envBound61656 : H12AffineFastState.Bounded env61656 := by
  intro p hp
  have h : env61656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61655_61656 : H12AffineEnvironment.transform 17 65664 env61655 = env61656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61655 == env61656) = true)

theorem identity61656 : scanCanonicalize (H12AffineFastState.compose env61656 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound61656 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,310,9561,438,4416,13341,4097,477,8201,4390,13768,13592,4414,9480,1297,15485,8205,1280,256,16,1345,5953]

theorem envBound61657 : H12AffineFastState.Bounded env61657 := by
  intro p hp
  have h : env61657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61656_61657 : H12AffineEnvironment.transform 15 310 env61656 = env61657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env61656 == env61657) = true)

def env61658 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,310,8265,438,4416,12557,4097,477,8201,4390,12504,12296,4414,8216,1,14701,8205,16,256,16,81,4689]

theorem envBound61658 : H12AffineFastState.Bounded env61658 := by
  intro p hp
  have h : env61658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61657_61658 : H12AffineEnvironment.transform 9 272 env61657 = env61658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61657 == env61658) = true)

theorem identity61658 : scanCanonicalize (H12AffineFastState.compose env61658 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound61658 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61659 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,1,276,310,4177,438,4416,277,4097,477,4113,4390,192,16,4414,4096,1,2421,4117,16,256,16,81,4689]

theorem envBound61659 : H12AffineFastState.Bounded env61659 := by
  intro p hp
  have h : env61659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61658_61659 : H12AffineEnvironment.transform 12 4120 env61658 = env61659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env61658 == env61659) = true)

theorem identity61659 : scanCanonicalize (H12AffineFastState.compose env61659 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound61659 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env61660 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,324,348,1,276,310,277,438,4,277,325,477,341,98,192,16,122,324,1,2421,337,16,256,16,81,789]

theorem envBound61660 : H12AffineFastState.Bounded env61660 := by
  intro p hp
  have h : env61660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61659_61660 : H12AffineEnvironment.transform 11 324 env61659 = env61660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env61659 == env61660) = true)

theorem identity61660 : scanCanonicalize (H12AffineFastState.compose env61660 (packedSelected [0,2,3,7,10,11,12,15,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 803) := by decide +kernel

theorem selectedBound61660 : packedSelected [0,2,3,7,10,11,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env61661 : List Nat := [2,4,8,16,32,64,128,256,512,272,803,324,348,1,276,310,277,438,4,277,325,477,341,98,192,16,122,324,1,598,337,16,256,16,81,789]

theorem envBound61661 : H12AffineFastState.Bounded env61661 := by
  intro p hp
  have h : env61661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61660_61661 : H12AffineEnvironment.transform 10 803 env61660 = env61661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 803 env61660 == env61661) = true)

theorem identity61661 : scanCanonicalize (H12AffineFastState.compose env61661 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(8+1) ^^^ 432) := by decide +kernel

theorem selectedBound61661 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env61662 : List Nat := [2,4,8,16,32,64,128,256,432,272,147,324,348,1,276,310,277,438,4,277,325,477,341,98,192,16,122,324,1,486,337,16,256,16,81,165]

theorem envBound61662 : H12AffineFastState.Bounded env61662 := by
  intro p hp
  have h : env61662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61661_61662 : H12AffineEnvironment.transform 8 432 env61661 = env61662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 432 env61661 == env61662) = true)

theorem identity61662 : scanCanonicalize (H12AffineFastState.compose env61662 (packedSelected [0,1,4,5,7,8,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 114) := by decide +kernel

theorem selectedBound61662 : packedSelected [0,1,4,5,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env61663 : List Nat := [2,4,8,16,32,64,128,114,194,98,147,54,46,1,102,68,103,196,4,103,55,175,39,98,192,16,122,54,1,148,35,16,114,16,81,165]

theorem envBound61663 : H12AffineFastState.Bounded env61663 := by
  intro p hp
  have h : env61663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61662_61663 : H12AffineEnvironment.transform 7 114 env61662 = env61663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 114 env61662 == env61663) = true)

theorem identity61663 : scanCanonicalize (H12AffineFastState.compose env61663 (packedSelected [1,4,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound61663 : packedSelected [1,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env61664 : List Nat := [2,4,8,16,32,10,128,56,136,40,147,54,46,1,44,14,45,142,4,45,55,175,39,40,138,16,48,54,1,148,35,16,56,16,27,165]

theorem envBound61664 : H12AffineFastState.Bounded env61664 := by
  intro p hp
  have h : env61664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61663_61664 : H12AffineEnvironment.transform 5 10 env61663 = env61664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env61663 == env61664) = true)

theorem identity61664 : scanCanonicalize (H12AffineFastState.compose env61664 (packedSelected [2,3,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61664 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env61665 : List Nat := [2,2,8,16,32,10,128,56,136,40,147,48,40,1,42,8,43,136,2,43,49,169,33,40,138,16,48,48,1,146,35,16,56,16,27,163]

theorem envBound61665 : H12AffineFastState.Bounded env61665 := by
  intro p hp
  have h : env61665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61664_61665 : H12AffineEnvironment.transform 1 2 env61664 = env61665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61664 == env61665) = true)

theorem identity61665 : scanCanonicalize (H12AffineFastState.compose env61665 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound61665 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env61666 : List Nat := [2,2,8,16,32,10,34,56,42,40,49,48,40,1,42,8,43,42,2,43,49,11,33,40,40,16,48,48,1,48,35,16,56,16,27,1]

theorem envBound61666 : H12AffineFastState.Bounded env61666 := by
  intro p hp
  have h : env61666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61665_61666 : H12AffineEnvironment.transform 6 34 env61665 = env61666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env61665 == env61666) = true)

theorem identity61666 : scanCanonicalize (H12AffineFastState.compose env61666 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound61666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61667 : List Nat := [2,2,8,11,32,10,34,35,42,40,42,43,40,1,42,8,43,42,2,43,42,11,33,40,40,11,43,43,1,43,35,11,35,11,0,1]

theorem envBound61667 : H12AffineFastState.Bounded env61667 := by
  intro p hp
  have h : env61667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61666_61667 : H12AffineEnvironment.transform 3 11 env61666 = env61667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env61666 == env61667) = true)

theorem identity61667 : scanCanonicalize (H12AffineFastState.compose env61667 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61668 : List Nat := [2,2,8,11,11,10,9,8,1,3,1,0,3,1,1,8,0,1,2,0,1,11,10,3,3,11,0,0,1,0,8,11,8,11,0,1]

theorem envBound61668 : H12AffineFastState.Bounded env61668 := by
  intro p hp
  have h : env61668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61667_61668 : H12AffineEnvironment.transform 4 11 env61667 = env61668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61667 == env61668) = true)

def env61669 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,310,8264,438,4416,12556,4097,477,8201,4390,12505,12297,4414,8217,0,14700,8205,17,256,16,80,4688]

theorem envBound61669 : H12AffineFastState.Bounded env61669 := by
  intro p hp
  have h : env61669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61657_61669 : H12AffineEnvironment.transform 9 273 env61657 = env61669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61657 == env61669) = true)

theorem identity61669 : scanCanonicalize (H12AffineFastState.compose env61669 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound61669 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61670 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,4096,8192,0,12312,35,8264,163,4181,12313,4097,200,8201,4147,12505,12297,4139,8217,0,14457,8205,17,21,16,80,4688]

theorem envBound61670 : H12AffineFastState.Bounded env61670 := by
  intro p hp
  have h : env61670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61669_61670 : H12AffineEnvironment.transform 7 21 env61669 = env61670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env61669 == env61670) = true)

theorem identity61670 : scanCanonicalize (H12AffineFastState.compose env61670 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound61670 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env61671 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,4096,4257,0,185,35,4329,163,4181,184,4097,200,4264,4147,120,168,4139,4280,0,2264,4268,17,21,16,80,4688]

theorem envBound61671 : H12AffineFastState.Bounded env61671 := by
  intro p hp
  have h : env61671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61670_61671 : H12AffineEnvironment.transform 12 4257 env61670 = env61671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env61670 == env61671) = true)

theorem identity61671 : scanCanonicalize (H12AffineFastState.compose env61671 (packedSelected [0,3,5,7,10,12,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound61671 : packedSelected [0,3,5,7,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env61672 : List Nat := [2,4,8,16,17,64,128,21,512,4,2048,4096,4240,0,136,18,4312,146,4181,137,4097,200,4249,4098,73,153,4122,4233,0,2264,4253,17,21,16,80,4688]

theorem envBound61672 : H12AffineFastState.Bounded env61672 := by
  intro p hp
  have h : env61672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61671_61672 : H12AffineEnvironment.transform 4 17 env61671 = env61672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env61671 == env61672) = true)

theorem identity61672 : scanCanonicalize (H12AffineFastState.compose env61672 (packedSelected [0,3,5,7,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound61672 : packedSelected [0,3,5,7,10,13] rootPS < 2^1333 := by decide +kernel

def env61673 : List Nat := [2,4,8,16,17,64,128,21,512,4,2048,0,144,0,136,18,216,146,85,137,1,200,153,2,73,153,26,137,0,2264,157,17,21,16,80,592]

theorem envBound61673 : H12AffineFastState.Bounded env61673 := by
  intro p hp
  have h : env61673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61672_61673 : H12AffineEnvironment.transform 11 0 env61672 = env61673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env61672 == env61673) = true)

theorem identity61673 : scanCanonicalize (H12AffineFastState.compose env61673 (packedSelected [1,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound61673 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2