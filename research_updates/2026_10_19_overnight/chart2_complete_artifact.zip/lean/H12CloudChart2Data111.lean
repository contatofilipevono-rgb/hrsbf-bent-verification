import H12CloudChart2Data110

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound27291 : H12AffineFastState.Bounded env27291 := by
  intro p hp
  have h : env27291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27290_27291 : H12AffineEnvironment.transform 7 4 env27290 = env27291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27290 == env27291) = true)

theorem identity27291 : scanCanonicalize (H12AffineFastState.compose env27291 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2053) := by decide +kernel

theorem selectedBound27291 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27292 : List Nat := [2,4,8,1,32,64,128,4,132,69,2048,197,140,64,196,2053,2210,2180,128,197,197,13,2210,2052,192,2086,43,2275,64,70,129,132,5,2274,0,65]

theorem envBound27292 : H12AffineFastState.Bounded env27292 := by
  intro p hp
  have h : env27292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27291_27292 : H12AffineEnvironment.transform 15 2053 env27291 = env27292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2053 env27291 == env27292) = true)

theorem identity27292 : scanCanonicalize (H12AffineFastState.compose env27292 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27292 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27293 : List Nat := [2,4,8,1,32,0,128,4,132,5,2048,133,140,0,132,2053,2210,2180,128,133,133,13,2210,2052,128,2086,43,2211,0,6,129,132,5,2210,0,1]

theorem envBound27293 : H12AffineFastState.Bounded env27293 := by
  intro p hp
  have h : env27293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27292_27293 : H12AffineEnvironment.transform 5 0 env27292 = env27293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27292 == env27293) = true)

theorem identity27293 : scanCanonicalize (H12AffineFastState.compose env27293 (packedSelected [10,12] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound27293 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env27294 : List Nat := [2,4,8,1,32,0,128,4,132,5,175,133,140,0,132,170,13,43,128,133,133,13,13,171,128,137,43,12,0,6,129,132,5,13,0,1]

theorem envBound27294 : H12AffineFastState.Bounded env27294 := by
  intro p hp
  have h : env27294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27293_27294 : H12AffineEnvironment.transform 10 175 env27293 = env27294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env27293 == env27294) = true)

theorem identity27294 : scanCanonicalize (H12AffineFastState.compose env27294 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27294 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27295 : List Nat := [2,4,8,1,7,0,128,4,132,5,136,133,140,0,132,141,13,12,128,133,133,13,13,140,128,137,12,12,0,6,129,132,5,13,0,1]

theorem envBound27295 : H12AffineFastState.Bounded env27295 := by
  intro p hp
  have h : env27295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27294_27295 : H12AffineEnvironment.transform 4 7 env27294 = env27295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27294 == env27295) = true)

theorem identity27295 : scanCanonicalize (H12AffineFastState.compose env27295 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27295 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27296 : List Nat := [2,4,2,1,7,0,128,4,132,5,130,133,134,0,132,135,7,6,128,133,133,7,7,134,128,131,6,6,0,6,129,132,5,7,0,1]

theorem envBound27296 : H12AffineFastState.Bounded env27296 := by
  intro p hp
  have h : env27296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27295_27296 : H12AffineEnvironment.transform 2 2 env27295 = env27296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27295 == env27296) = true)

theorem identity27296 : scanCanonicalize (H12AffineFastState.compose env27296 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27297 : List Nat := [2,2,2,1,1,0,128,2,130,3,130,131,128,0,130,129,1,0,128,131,131,1,1,128,128,131,0,0,0,0,129,130,3,1,0,1]

theorem envBound27297 : H12AffineFastState.Bounded env27297 := by
  intro p hp
  have h : env27297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27296_27297 : H12AffineEnvironment.transform 1 2 env27296 = env27297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27296 == env27297) = true)

def env27298 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,65536,66082,65665,517,577,836,649,66083,65536,192,65831,302,66162,65,67651,784,789,257,66146,16,340]

theorem envBound27298 : H12AffineFastState.Bounded env27298 := by
  intro p hp
  have h : env27298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27278_27298 : H12AffineEnvironment.transform 9 337 env27278 = env27298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env27278 == env27298) = true)

theorem identity27298 : scanCanonicalize (H12AffineFastState.compose env27298 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound27298 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27299 : List Nat := [2,4,8,16,32,64,85,256,512,337,2048,836,797,65,576,65536,66082,65620,517,577,836,604,66083,65536,21,65831,302,66162,65,67651,784,789,257,66146,16,340]

theorem envBound27299 : H12AffineFastState.Bounded env27299 := by
  intro p hp
  have h : env27299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27298_27299 : H12AffineEnvironment.transform 6 85 env27298 = env27299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env27298 == env27299) = true)

def env27300 : List Nat := [2,4,8,16,32,64,85,256,324,337,2048,0,89,65,260,65536,65894,65620,321,261,0,280,65895,65536,21,65831,302,65846,65,67651,84,81,257,65830,16,340]

theorem envBound27300 : H12AffineFastState.Bounded env27300 := by
  intro p hp
  have h : env27300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27299_27300 : H12AffineEnvironment.transform 8 324 env27299 = env27300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env27299 == env27300) = true)

theorem identity27300 : scanCanonicalize (H12AffineFastState.compose env27300 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27300 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27301 : List Nat := [2,4,8,16,32,64,85,21,81,68,2048,0,89,65,17,65536,65651,65620,84,16,0,13,65650,65536,21,65586,59,65571,65,67651,84,81,20,65587,16,65]

theorem envBound27301 : H12AffineFastState.Bounded env27301 := by
  intro p hp
  have h : env27301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27300_27301 : H12AffineEnvironment.transform 7 21 env27300 = env27301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27300 == env27301) = true)

theorem identity27301 : scanCanonicalize (H12AffineFastState.compose env27301 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound27301 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27302 : List Nat := [2,4,8,16,32,64,85,21,81,68,2048,0,89,65,17,115,0,39,84,16,0,13,1,115,21,65,59,80,65,2096,84,81,20,64,16,65]

theorem envBound27302 : H12AffineFastState.Bounded env27302 := by
  intro p hp
  have h : env27302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27301_27302 : H12AffineEnvironment.transform 15 115 env27301 = env27302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env27301 == env27302) = true)

theorem identity27302 : scanCanonicalize (H12AffineFastState.compose env27302 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27302 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27303 : List Nat := [2,4,8,16,1,64,85,21,81,68,2048,0,89,65,17,82,0,6,84,16,0,13,1,82,21,65,26,80,65,2065,84,81,20,64,16,65]

theorem envBound27303 : H12AffineFastState.Bounded env27303 := by
  intro p hp
  have h : env27303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27302_27303 : H12AffineEnvironment.transform 4 1 env27302 = env27303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27302 == env27303) = true)

theorem identity27303 : scanCanonicalize (H12AffineFastState.compose env27303 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound27303 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27304 : List Nat := [2,4,8,16,1,64,85,21,81,68,71,0,89,65,17,82,0,6,84,16,0,13,1,82,21,65,26,80,65,86,84,81,20,64,16,65]

theorem envBound27304 : H12AffineFastState.Bounded env27304 := by
  intro p hp
  have h : env27304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27303_27304 : H12AffineEnvironment.transform 10 71 env27303 = env27304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env27303 == env27304) = true)

theorem identity27304 : scanCanonicalize (H12AffineFastState.compose env27304 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27304 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27305 : List Nat := [2,4,8,16,1,10,31,21,27,14,13,0,19,11,17,24,0,6,30,16,0,13,1,24,21,11,26,26,11,28,30,27,20,10,16,11]

theorem envBound27305 : H12AffineFastState.Bounded env27305 := by
  intro p hp
  have h : env27305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27304_27305 : H12AffineEnvironment.transform 5 10 env27304 = env27305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27304 == env27305) = true)

theorem identity27305 : scanCanonicalize (H12AffineFastState.compose env27305 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound27305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27306 : List Nat := [2,4,8,6,1,10,9,3,13,14,13,0,5,11,7,14,0,6,8,6,0,13,1,14,3,11,12,12,11,10,8,13,2,10,6,11]

theorem envBound27306 : H12AffineFastState.Bounded env27306 := by
  intro p hp
  have h : env27306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27305_27306 : H12AffineEnvironment.transform 3 6 env27305 = env27306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env27305 == env27306) = true)

def env27307 : List Nat := [2,4,8,16,32,64,85,256,325,337,2048,1,88,65,261,65536,65895,65620,320,260,1,281,65894,65536,21,65831,302,65847,65,67651,85,80,257,65831,16,340]

theorem envBound27307 : H12AffineFastState.Bounded env27307 := by
  intro p hp
  have h : env27307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27299_27307 : H12AffineEnvironment.transform 8 325 env27299 = env27307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env27299 == env27307) = true)

theorem identity27307 : scanCanonicalize (H12AffineFastState.compose env27307 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27307 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27308 : List Nat := [2,4,8,16,32,64,85,5,64,84,2048,1,88,65,0,65536,65634,65620,69,1,1,28,65635,65536,21,65570,43,65586,65,67651,85,80,4,65570,16,81]

theorem envBound27308 : H12AffineFastState.Bounded env27308 := by
  intro p hp
  have h : env27308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27307_27308 : H12AffineEnvironment.transform 7 5 env27307 = env27308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27307 == env27308) = true)

theorem identity27308 : scanCanonicalize (H12AffineFastState.compose env27308 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27308 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27309 : List Nat := [2,4,8,16,32,17,4,5,17,5,2048,1,9,16,0,65536,65587,65541,20,1,1,28,65586,65536,21,65570,43,65586,16,67602,4,1,4,65570,16,0]

theorem envBound27309 : H12AffineFastState.Bounded env27309 := by
  intro p hp
  have h : env27309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27308_27309 : H12AffineEnvironment.transform 5 17 env27308 = env27309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27308 == env27309) = true)

theorem identity27309 : scanCanonicalize (H12AffineFastState.compose env27309 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound27309 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27310 : List Nat := [2,4,8,16,32,17,4,5,17,5,2048,1,9,16,0,50,1,55,20,1,1,28,0,50,21,16,43,0,16,2080,4,1,4,16,16,0]

theorem envBound27310 : H12AffineFastState.Bounded env27310 := by
  intro p hp
  have h : env27310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27309_27310 : H12AffineEnvironment.transform 15 50 env27309 = env27310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env27309 == env27310) = true)

theorem identity27310 : scanCanonicalize (H12AffineFastState.compose env27310 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27310 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env27311 : List Nat := [2,4,8,16,17,17,4,5,17,5,2048,1,9,16,0,3,1,6,20,1,1,28,0,3,21,16,26,0,16,2065,4,1,4,16,16,0]

theorem envBound27311 : H12AffineFastState.Bounded env27311 := by
  intro p hp
  have h : env27311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27310_27311 : H12AffineEnvironment.transform 4 17 env27310 = env27311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27310 == env27311) = true)

theorem identity27311 : scanCanonicalize (H12AffineFastState.compose env27311 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27311 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env27312 : List Nat := [2,4,2,16,17,17,4,5,17,5,2048,1,3,16,0,3,1,6,20,1,1,22,0,3,21,16,16,0,16,2065,4,1,4,16,16,0]

theorem envBound27312 : H12AffineFastState.Bounded env27312 := by
  intro p hp
  have h : env27312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27311_27312 : H12AffineEnvironment.transform 2 2 env27311 = env27312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27311 == env27312) = true)

theorem identity27312 : scanCanonicalize (H12AffineFastState.compose env27312 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound27312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27313 : List Nat := [2,4,2,16,17,17,4,5,17,5,23,1,3,16,0,3,1,6,20,1,1,22,0,3,21,16,16,0,16,6,4,1,4,16,16,0]

theorem envBound27313 : H12AffineFastState.Bounded env27313 := by
  intro p hp
  have h : env27313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27312_27313 : H12AffineEnvironment.transform 10 23 env27312 = env27313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env27312 == env27313) = true)

theorem identity27313 : scanCanonicalize (H12AffineFastState.compose env27313 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27313 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27314 : List Nat := [2,4,2,0,1,1,4,5,1,5,7,1,3,0,0,3,1,6,4,1,1,6,0,3,5,0,0,0,0,6,4,1,4,0,0,0]

theorem envBound27314 : H12AffineFastState.Bounded env27314 := by
  intro p hp
  have h : env27314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27313_27314 : H12AffineEnvironment.transform 3 0 env27313 = env27314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27313 == env27314) = true)

theorem identity27314 : scanCanonicalize (H12AffineFastState.compose env27314 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27315 : List Nat := [1,4,1,0,1,1,4,5,1,5,4,1,0,0,0,0,1,5,4,1,1,5,0,0,5,0,0,0,0,5,4,1,4,0,0,0]

theorem envBound27315 : H12AffineFastState.Bounded env27315 := by
  intro p hp
  have h : env27315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27314_27315 : H12AffineEnvironment.transform 0 1 env27314 = env27315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27314 == env27315) = true)

def env27316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4096,5276,74047,66897,13769,78895,328958,74815,1296,81226,8204,8201,257,74798,1345,5952]

theorem envBound27316 : H12AffineFastState.Bounded env27316 := by
  intro p hp
  have h : env27316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27195_27316 : H12AffineEnvironment.transform 13 1297 env27195 = env27316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27195 == env27316) = true)

def env27317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4096,5276,74047,66897,13769,78895,1150,74815,1296,81226,8204,8201,257,74798,1345,5952]

theorem envBound27317 : H12AffineFastState.Bounded env27317 := by
  intro p hp
  have h : env27317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27316_27317 : H12AffineEnvironment.transform 17 65664 env27316 = env27317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27316 == env27317) = true)

theorem identity27317 : scanCanonicalize (H12AffineFastState.compose env27317 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound27317 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,65536,74862,65664,320,8541,0,1180,74047,66897,9673,74799,1150,74815,1296,77130,8204,8201,257,74798,1345,1856]

theorem envBound27318 : H12AffineFastState.Bounded env27318 := by
  intro p hp
  have h : env27318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27317_27318 : H12AffineEnvironment.transform 11 0 env27317 = env27318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27317 == env27318) = true)

def env27319 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8540,65536,74030,65664,320,8541,0,476,74047,65553,8329,74095,318,74111,80,75786,8204,8201,257,74094,1,512]

theorem envBound27319 : H12AffineFastState.Bounded env27319 := by
  intro p hp
  have h : env27319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27318_27319 : H12AffineEnvironment.transform 9 320 env27318 = env27319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27318 == env27319) = true)

theorem identity27319 : scanCanonicalize (H12AffineFastState.compose env27319 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27319 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27320 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,81,8264,65536,73786,65664,84,8265,0,200,73771,65553,8329,73851,42,73835,80,75786,8204,8201,21,73850,1,512]

theorem envBound27320 : H12AffineFastState.Bounded env27320 := by
  intro p hp
  have h : env27320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27319_27320 : H12AffineEnvironment.transform 7 20 env27319 = env27320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27319 == env27320) = true)

theorem identity27320 : scanCanonicalize (H12AffineFastState.compose env27320 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27320 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27321 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,0,8217,65536,73786,65664,5,8216,0,153,73771,65553,8329,73770,42,73786,1,75786,8204,8201,21,73771,1,512]

theorem envBound27321 : H12AffineFastState.Bounded env27321 := by
  intro p hp
  have h : env27321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27320_27321 : H12AffineEnvironment.transform 5 17 env27320 = env27321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27320 == env27321) = true)

theorem identity27321 : scanCanonicalize (H12AffineFastState.compose env27321 (packedSelected [2,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2746) := by decide +kernel

theorem selectedBound27321 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env27322 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,2746,0,2723,65536,68224,65664,5,2722,0,153,68241,65553,2611,68240,42,68224,1,66224,2742,2739,21,68241,1,512]

theorem envBound27322 : H12AffineFastState.Bounded env27322 := by
  intro p hp
  have h : env27322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27321_27322 : H12AffineEnvironment.transform 12 2746 env27321 = env27322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2746 env27321 == env27322) = true)

theorem identity27322 : scanCanonicalize (H12AffineFastState.compose env27322 (packedSelected [1,3,13] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound27322 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env27323 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,2746,0,2723,682,2090,554,5,2722,0,153,2107,699,2611,2106,42,2090,1,26,2742,2739,21,2107,1,512]

theorem envBound27323 : H12AffineFastState.Bounded env27323 := by
  intro p hp
  have h : env27323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27322_27323 : H12AffineEnvironment.transform 15 682 env27322 = env27323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env27322 == env27323) = true)

theorem identity27323 : scanCanonicalize (H12AffineFastState.compose env27323 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound27323 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27324 : List Nat := [2,4,8,16,32,17,128,20,512,5,513,0,187,0,162,682,555,554,5,163,0,153,570,699,50,571,42,555,1,26,183,178,21,570,1,512]

theorem envBound27324 : H12AffineFastState.Bounded env27324 := by
  intro p hp
  have h : env27324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27323_27324 : H12AffineEnvironment.transform 10 513 env27323 = env27324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env27323 == env27324) = true)

theorem identity27324 : scanCanonicalize (H12AffineFastState.compose env27324 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27324 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env27325 : List Nat := [2,4,8,16,17,17,128,20,512,5,513,0,138,0,147,667,538,539,5,146,0,153,523,650,3,522,27,538,1,26,134,131,21,523,1,512]

theorem envBound27325 : H12AffineFastState.Bounded env27325 := by
  intro p hp
  have h : env27325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27324_27325 : H12AffineEnvironment.transform 4 17 env27324 = env27325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27324 == env27325) = true)

theorem identity27325 : scanCanonicalize (H12AffineFastState.compose env27325 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound27325 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27326 : List Nat := [2,4,8,16,17,17,18,20,512,5,513,0,24,0,1,521,538,539,5,0,0,11,523,536,3,522,27,538,1,26,20,17,21,523,1,512]

theorem envBound27326 : H12AffineFastState.Bounded env27326 := by
  intro p hp
  have h : env27326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27325_27326 : H12AffineEnvironment.transform 6 18 env27325 = env27326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env27325 == env27326) = true)

theorem identity27326 : scanCanonicalize (H12AffineFastState.compose env27326 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27326 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env27327 : List Nat := [2,4,8,11,10,10,9,15,512,5,513,0,3,0,1,521,513,512,5,0,0,11,523,515,3,522,0,513,1,1,15,10,14,523,1,512]

theorem envBound27327 : H12AffineFastState.Bounded env27327 := by
  intro p hp
  have h : env27327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27326_27327 : H12AffineEnvironment.transform 3 11 env27326 = env27327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27326 == env27327) = true)

def env27328 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,65536,74031,65664,320,8541,0,477,74047,65552,8328,74094,319,74110,81,75787,8204,8201,257,74095,0,513]

theorem envBound27328 : H12AffineFastState.Bounded env27328 := by
  intro p hp
  have h : env27328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27318_27328 : H12AffineEnvironment.transform 9 321 env27318 = env27328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27318 == env27328) = true)

theorem identity27328 : scanCanonicalize (H12AffineFastState.compose env27328 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound27328 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27329 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,8299,324,8427,320,8541,0,477,340,8315,8328,261,319,277,81,2144,8204,8201,257,260,0,513]

theorem envBound27329 : H12AffineFastState.Bounded env27329 := by
  intro p hp
  have h : env27329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27328_27329 : H12AffineEnvironment.transform 15 8299 env27328 = env27329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env27328 == env27329) = true)

theorem identity27329 : scanCanonicalize (H12AffineFastState.compose env27329 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27329 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27330 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,348,80,0,311,324,439,320,1,0,477,340,295,468,261,319,277,81,2144,336,341,257,260,0,513]

theorem envBound27330 : H12AffineFastState.Bounded env27330 := by
  intro p hp
  have h : env27330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27329_27330 : H12AffineEnvironment.transform 12 348 env27329 = env27330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27329 == env27330) = true)

theorem identity27330 : scanCanonicalize (H12AffineFastState.compose env27330 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27330 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27331 : List Nat := [2,4,8,16,32,64,128,5,512,68,2048,0,89,80,0,50,65,178,69,1,0,216,81,34,209,0,58,16,81,2144,85,80,4,1,0,513]

theorem envBound27331 : H12AffineFastState.Bounded env27331 := by
  intro p hp
  have h : env27331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27330_27331 : H12AffineEnvironment.transform 7 5 env27330 = env27331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27330 == env27331) = true)

theorem identity27331 : scanCanonicalize (H12AffineFastState.compose env27331 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound27331 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env27332 : List Nat := [2,4,8,16,32,64,128,5,512,68,123,0,89,80,0,50,65,178,69,1,0,216,81,34,209,0,58,16,81,27,85,80,4,1,0,513]

theorem envBound27332 : H12AffineFastState.Bounded env27332 := by
  intro p hp
  have h : env27332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27331_27332 : H12AffineEnvironment.transform 10 123 env27331 = env27332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env27331 == env27332) = true)

theorem identity27332 : scanCanonicalize (H12AffineFastState.compose env27332 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound27332 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env27333 : List Nat := [2,4,8,16,32,64,15,5,512,68,123,0,89,80,0,50,65,61,69,1,0,87,81,34,94,0,58,16,81,27,85,80,4,1,0,513]

theorem envBound27333 : H12AffineFastState.Bounded env27333 := by
  intro p hp
  have h : env27333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27332_27333 : H12AffineEnvironment.transform 6 15 env27332 = env27333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env27332 == env27333) = true)

def env27334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4096,5276,74047,66897,13769,78895,1151,74815,1296,81226,8204,8201,257,74798,1345,5952]

theorem envBound27334 : H12AffineFastState.Bounded env27334 := by
  intro p hp
  have h : env27334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27316_27334 : H12AffineEnvironment.transform 17 65665 env27316 = env27334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27316 == env27334) = true)

theorem identity27334 : scanCanonicalize (H12AffineFastState.compose env27334 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound27334 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27335 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,65536,74031,65665,4416,8541,4096,4573,74047,65552,12424,78190,318,74110,81,79883,8204,8201,257,74095,0,4609]

theorem envBound27335 : H12AffineFastState.Bounded env27335 := by
  intro p hp
  have h : env27335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27334_27335 : H12AffineEnvironment.transform 9 321 env27334 = env27335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27334 == env27335) = true)

def env27336 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,80,8540,65536,74031,65665,532,8541,852,649,74047,65552,9180,74298,318,74110,81,76639,8204,8201,257,74095,0,341]

theorem envBound27336 : H12AffineFastState.Bounded env27336 := by
  intro p hp
  have h : env27336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27335_27336 : H12AffineEnvironment.transform 11 852 env27335 = env27336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env27335 == env27336) = true)

def env27337 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,65536,74031,65665,516,8525,836,649,74031,65536,9164,74282,302,74094,65,76623,8204,8201,257,74095,0,325]

theorem envBound27337 : H12AffineFastState.Bounded env27337 := by
  intro p hp
  have h : env27337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27336_27337 : H12AffineEnvironment.transform 3 0 env27336 = env27337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27336 == env27337) = true)

theorem identity27337 : scanCanonicalize (H12AffineFastState.compose env27337 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 111) := by decide +kernel

theorem selectedBound27337 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27338 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,111,8512,238,516,8525,836,649,8512,111,9164,8773,302,8449,65,11040,8204,8201,257,8448,0,325]

theorem envBound27338 : H12AffineFastState.Bounded env27338 := by
  intro p hp
  have h : env27338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27337_27338 : H12AffineEnvironment.transform 15 111 env27337 = env27338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 111 env27337 == env27338) = true)

def env27339 : List Nat := [2,4,8,0,32,64,128,8,512,73,2048,588,8192,64,8260,111,8264,238,516,8261,588,649,8264,111,8900,8773,38,8201,65,10792,8204,8201,9,8200,0,77]

theorem envBound27339 : H12AffineFastState.Bounded env27339 := by
  intro p hp
  have h : env27339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27338_27339 : H12AffineEnvironment.transform 7 8 env27338 = env27339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env27338 == env27339) = true)

theorem identity27339 : scanCanonicalize (H12AffineFastState.compose env27339 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound27339 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27340 : List Nat := [2,4,8,0,32,64,128,8,12,73,2048,64,8192,64,8260,111,8264,238,8,8261,64,133,8264,111,8392,8265,38,8201,65,10276,8204,8201,9,8200,0,77]

theorem envBound27340 : H12AffineFastState.Bounded env27340 := by
  intro p hp
  have h : env27340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27339_27340 : H12AffineEnvironment.transform 8 12 env27339 = env27340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env27339 == env27340) = true)

theorem identity27340 : scanCanonicalize (H12AffineFastState.compose env27340 (packedSelected [1,3,4,5,9,12,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound27340 : packedSelected [1,3,4,5,9,12,16,17] rootPS < 2^1333 := by decide +kernel

def env27341 : List Nat := [2,4,8,0,32,64,128,8,12,73,2048,64,73,64,13,111,1,238,8,12,64,133,1,111,129,0,38,64,65,2157,69,64,9,65,0,77]

theorem envBound27341 : H12AffineFastState.Bounded env27341 := by
  intro p hp
  have h : env27341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27340_27341 : H12AffineEnvironment.transform 12 73 env27340 = env27341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env27340 == env27341) = true)

theorem identity27341 : scanCanonicalize (H12AffineFastState.compose env27341 (packedSelected [5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound27341 : packedSelected [5,8,10] rootPS < 2^1333 := by decide +kernel

def env27342 : List Nat := [2,4,8,0,32,64,128,8,12,73,44,64,73,64,13,111,1,238,8,12,64,133,1,111,129,0,38,64,65,65,69,64,9,65,0,77]

theorem envBound27342 : H12AffineFastState.Bounded env27342 := by
  intro p hp
  have h : env27342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27341_27342 : H12AffineEnvironment.transform 10 44 env27341 = env27342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env27341 == env27342) = true)

theorem identity27342 : scanCanonicalize (H12AffineFastState.compose env27342 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound27342 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27343 : List Nat := [2,4,8,0,32,64,34,8,12,73,44,64,73,64,13,111,1,76,8,12,64,39,1,111,35,0,38,64,65,65,69,64,9,65,0,77]

theorem envBound27343 : H12AffineFastState.Bounded env27343 := by
  intro p hp
  have h : env27343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27342_27343 : H12AffineEnvironment.transform 6 34 env27342 = env27343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env27342 == env27343) = true)

theorem identity27343 : scanCanonicalize (H12AffineFastState.compose env27343 (packedSelected [0,1,2,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound27343 : packedSelected [0,1,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27344 : List Nat := [2,4,8,0,32,38,34,8,12,47,44,38,47,38,13,9,1,42,8,12,38,39,1,9,35,0,38,38,39,39,35,38,9,39,0,43]

theorem envBound27344 : H12AffineFastState.Bounded env27344 := by
  intro p hp
  have h : env27344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27343_27344 : H12AffineEnvironment.transform 5 38 env27343 = env27344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env27343 == env27344) = true)

theorem identity27344 : scanCanonicalize (H12AffineFastState.compose env27344 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27344 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27345 : List Nat := [2,4,4,0,32,38,34,4,0,35,32,38,35,38,1,5,1,38,4,0,38,39,1,5,35,0,38,38,39,39,35,38,5,39,0,39]

theorem envBound27345 : H12AffineFastState.Bounded env27345 := by
  intro p hp
  have h : env27345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27344_27345 : H12AffineEnvironment.transform 2 4 env27344 = env27345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27344 == env27345) = true)

theorem identity27345 : scanCanonicalize (H12AffineFastState.compose env27345 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27345 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27346 : List Nat := [2,4,4,0,7,1,5,4,0,4,7,1,4,1,1,5,1,1,4,0,1,0,1,5,4,0,1,1,0,0,4,1,5,0,0,0]

theorem envBound27346 : H12AffineFastState.Bounded env27346 := by
  intro p hp
  have h : env27346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27345_27346 : H12AffineEnvironment.transform 4 7 env27345 = env27346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27345 == env27346) = true)

theorem identity27346 : scanCanonicalize (H12AffineFastState.compose env27346 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27347 : List Nat := [2,3,3,0,0,1,2,3,0,3,0,1,3,1,1,2,1,1,3,0,1,0,1,2,3,0,1,1,0,0,3,1,2,0,0,0]

theorem envBound27347 : H12AffineFastState.Bounded env27347 := by
  intro p hp
  have h : env27347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27346_27347 : H12AffineEnvironment.transform 1 3 env27346 = env27347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27346 == env27347) = true)

def env27348 : List Nat := [2,4,8,0,32,64,128,9,512,72,2048,589,8192,64,8261,111,8265,238,516,8260,589,649,8265,111,8901,8773,39,8200,65,10793,8204,8201,8,8201,0,76]

theorem envBound27348 : H12AffineFastState.Bounded env27348 := by
  intro p hp
  have h : env27348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27338_27348 : H12AffineEnvironment.transform 7 9 env27338 = env27348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env27338 == env27348) = true)

theorem identity27348 : scanCanonicalize (H12AffineFastState.compose env27348 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27348 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27349 : List Nat := [2,4,8,0,32,64,128,9,1,72,2048,76,8192,64,8261,111,8265,238,5,8260,76,136,8265,111,8388,8260,39,8200,65,10280,8204,8201,8,8201,0,76]

theorem envBound27349 : H12AffineFastState.Bounded env27349 := by
  intro p hp
  have h : env27349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27348_27349 : H12AffineEnvironment.transform 8 1 env27348 = env27349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27348 == env27349) = true)

theorem identity27349 : scanCanonicalize (H12AffineFastState.compose env27349 (packedSelected [2,5,8,10,12,15,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound27349 : packedSelected [2,5,8,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env27350 : List Nat := [2,4,8,0,32,64,128,9,1,72,2048,76,15,64,74,111,70,238,5,75,76,136,70,111,203,75,39,7,65,2087,3,6,8,6,0,76]

theorem envBound27350 : H12AffineFastState.Bounded env27350 := by
  intro p hp
  have h : env27350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27349_27350 : H12AffineEnvironment.transform 12 15 env27349 = env27350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env27349 == env27350) = true)

theorem identity27350 : scanCanonicalize (H12AffineFastState.compose env27350 (packedSelected [0,2,3,4,7,9,10,12,13,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound27350 : packedSelected [0,2,3,4,7,9,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27351 : List Nat := [2,4,8,0,32,64,128,9,1,72,96,76,15,64,74,111,70,238,5,75,76,136,70,111,203,75,39,7,65,71,3,6,8,6,0,76]

theorem envBound27351 : H12AffineFastState.Bounded env27351 := by
  intro p hp
  have h : env27351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27350_27351 : H12AffineEnvironment.transform 10 96 env27350 = env27351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env27350 == env27351) = true)

theorem identity27351 : scanCanonicalize (H12AffineFastState.compose env27351 (packedSelected [1,2,4,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27351 : packedSelected [1,2,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env27352 : List Nat := [2,4,8,0,7,64,128,9,1,72,71,76,15,64,74,72,70,201,5,75,76,136,70,72,203,75,0,7,65,71,3,6,8,6,0,76]

theorem envBound27352 : H12AffineFastState.Bounded env27352 := by
  intro p hp
  have h : env27352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27351_27352 : H12AffineEnvironment.transform 4 7 env27351 = env27352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27351 == env27352) = true)

theorem identity27352 : scanCanonicalize (H12AffineFastState.compose env27352 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound27352 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27353 : List Nat := [2,4,8,0,7,64,15,9,1,72,71,76,15,64,74,72,70,70,5,75,76,7,70,72,68,75,0,7,65,71,3,6,8,6,0,76]

theorem envBound27353 : H12AffineFastState.Bounded env27353 := by
  intro p hp
  have h : env27353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27352_27353 : H12AffineEnvironment.transform 6 15 env27352 = env27353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env27352 == env27353) = true)

theorem identity27353 : scanCanonicalize (H12AffineFastState.compose env27353 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27353 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27354 : List Nat := [2,4,2,0,7,64,5,3,1,66,71,70,5,64,64,66,70,70,5,65,70,7,70,66,68,65,0,7,65,71,3,6,2,6,0,70]

theorem envBound27354 : H12AffineFastState.Bounded env27354 := by
  intro p hp
  have h : env27354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27353_27354 : H12AffineEnvironment.transform 2 2 env27353 = env27354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27353 == env27354) = true)

theorem identity27354 : scanCanonicalize (H12AffineFastState.compose env27354 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27355 : List Nat := [2,4,2,0,7,0,5,3,1,2,7,6,5,0,0,2,6,6,5,1,6,7,6,2,4,1,0,7,1,7,3,6,2,6,0,6]

theorem envBound27355 : H12AffineFastState.Bounded env27355 := by
  intro p hp
  have h : env27355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27354_27355 : H12AffineEnvironment.transform 5 0 env27354 = env27355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27354 == env27355) = true)

def env27356 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,65536,74031,65665,517,8524,837,649,74030,65537,9165,74283,303,74095,64,76622,8204,8201,257,74095,0,324]

theorem envBound27356 : H12AffineFastState.Bounded env27356 := by
  intro p hp
  have h : env27356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27336_27356 : H12AffineEnvironment.transform 3 1 env27336 = env27356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27336 == env27356) = true)

theorem identity27356 : scanCanonicalize (H12AffineFastState.compose env27356 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound27356 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27357 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,8230,265,8359,517,8524,837,649,264,8231,9165,525,303,329,64,2920,8204,8201,257,329,0,324]

theorem envBound27357 : H12AffineFastState.Bounded env27357 := by
  intro p hp
  have h : env27357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27356_27357 : H12AffineEnvironment.transform 15 8230 env27356 = env27357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env27356 == env27357) = true)

def env27358 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,72,65,261,110,265,239,517,260,837,649,264,111,901,525,303,329,64,2920,68,65,257,329,0,324]

theorem envBound27358 : H12AffineFastState.Bounded env27358 := by
  intro p hp
  have h : env27358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27357_27358 : H12AffineEnvironment.transform 12 72 env27357 = env27358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env27357 == env27358) = true)

theorem identity27358 : scanCanonicalize (H12AffineFastState.compose env27358 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound27358 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27359 : List Nat := [2,4,8,1,32,64,128,256,64,321,2048,261,72,65,261,110,265,239,69,260,261,201,264,111,453,77,303,329,64,2344,68,65,257,329,0,324]

theorem envBound27359 : H12AffineFastState.Bounded env27359 := by
  intro p hp
  have h : env27359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27358_27359 : H12AffineEnvironment.transform 8 64 env27358 = env27359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env27358 == env27359) = true)

theorem identity27359 : scanCanonicalize (H12AffineFastState.compose env27359 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27359 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27360 : List Nat := [2,4,5,1,32,64,128,256,64,321,2048,261,69,65,261,99,260,226,69,260,261,196,261,98,453,64,290,324,64,2341,68,65,257,324,0,324]

theorem envBound27360 : H12AffineFastState.Bounded env27360 := by
  intro p hp
  have h : env27360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27359_27360 : H12AffineEnvironment.transform 2 5 env27359 = env27360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27359 == env27360) = true)

theorem identity27360 : scanCanonicalize (H12AffineFastState.compose env27360 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound27360 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env27361 : List Nat := [2,4,5,1,32,64,128,256,64,321,324,261,69,65,261,99,260,226,69,260,261,196,261,98,453,64,290,324,64,97,68,65,257,324,0,324]

theorem envBound27361 : H12AffineFastState.Bounded env27361 := by
  intro p hp
  have h : env27361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27360_27361 : H12AffineEnvironment.transform 10 324 env27360 = env27361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env27360 == env27361) = true)

theorem identity27361 : scanCanonicalize (H12AffineFastState.compose env27361 (packedSelected [2,3,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound27361 : packedSelected [2,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env27362 : List Nat := [2,4,5,1,32,64,128,2,64,67,70,7,69,65,7,99,6,226,69,6,7,196,7,98,199,64,32,70,64,97,68,65,3,70,0,70]

theorem envBound27362 : H12AffineFastState.Bounded env27362 := by
  intro p hp
  have h : env27362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27361_27362 : H12AffineEnvironment.transform 7 2 env27361 = env27362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env27361 == env27362) = true)

theorem identity27362 : scanCanonicalize (H12AffineFastState.compose env27362 (packedSelected [3,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27362 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env27363 : List Nat := [2,2,3,1,32,64,128,2,64,67,64,1,67,65,1,99,0,226,67,0,1,194,1,98,193,64,32,64,64,97,66,65,3,64,0,64]

theorem envBound27363 : H12AffineFastState.Bounded env27363 := by
  intro p hp
  have h : env27363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27362_27363 : H12AffineEnvironment.transform 1 2 env27362 = env27363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27362 == env27363) = true)

theorem identity27363 : scanCanonicalize (H12AffineFastState.compose env27363 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound27363 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27364 : List Nat := [2,2,3,1,32,1,128,2,1,2,1,1,2,0,1,34,0,163,2,0,1,131,1,35,128,1,32,1,1,32,3,0,3,1,0,1]

theorem envBound27364 : H12AffineFastState.Bounded env27364 := by
  intro p hp
  have h : env27364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27363_27364 : H12AffineEnvironment.transform 5 1 env27363 = env27364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27363 == env27364) = true)

theorem identity27364 : scanCanonicalize (H12AffineFastState.compose env27364 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27365 : List Nat := [2,2,3,1,0,1,128,2,1,2,1,1,2,0,1,2,0,131,2,0,1,131,1,3,128,1,0,1,1,0,3,0,3,1,0,1]

theorem envBound27365 : H12AffineFastState.Bounded env27365 := by
  intro p hp
  have h : env27365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27364_27365 : H12AffineEnvironment.transform 4 0 env27364 = env27365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27364 == env27365) = true)

def env27366 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,73,65,260,111,265,238,517,261,837,649,264,110,900,525,303,329,64,2920,69,64,257,329,0,324]

theorem envBound27366 : H12AffineFastState.Bounded env27366 := by
  intro p hp
  have h : env27366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27357_27366 : H12AffineEnvironment.transform 12 73 env27357 = env27366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env27357 == env27366) = true)

theorem identity27366 : scanCanonicalize (H12AffineFastState.compose env27366 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27366 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27367 : List Nat := [2,4,8,1,32,64,128,4,512,69,2048,577,73,65,0,111,13,238,517,1,577,649,12,110,640,525,43,77,64,2668,69,64,5,77,0,64]

theorem envBound27367 : H12AffineFastState.Bounded env27367 := by
  intro p hp
  have h : env27367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27366_27367 : H12AffineEnvironment.transform 7 4 env27366 = env27367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27366 == env27367) = true)

theorem identity27367 : scanCanonicalize (H12AffineFastState.compose env27367 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27367 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27368 : List Nat := [2,4,8,1,32,64,128,4,0,69,2048,65,73,65,0,111,13,238,5,1,65,137,12,110,128,13,43,77,64,2156,69,64,5,77,0,64]

theorem envBound27368 : H12AffineFastState.Bounded env27368 := by
  intro p hp
  have h : env27368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27367_27368 : H12AffineEnvironment.transform 8 0 env27367 = env27368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27367 == env27368) = true)

theorem identity27368 : scanCanonicalize (H12AffineFastState.compose env27368 (packedSelected [2,3,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound27368 : packedSelected [2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env27369 : List Nat := [2,4,8,1,32,64,100,4,0,69,2048,65,73,65,0,111,13,10,5,1,65,109,12,110,100,13,43,77,64,2156,69,64,5,77,0,64]

theorem envBound27369 : H12AffineFastState.Bounded env27369 := by
  intro p hp
  have h : env27369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27368_27369 : H12AffineEnvironment.transform 6 100 env27368 = env27369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env27368 == env27369) = true)

theorem identity27369 : scanCanonicalize (H12AffineFastState.compose env27369 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound27369 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27370 : List Nat := [2,4,8,1,32,12,40,4,0,9,2048,13,5,13,0,35,13,10,5,1,13,33,12,34,40,13,43,1,12,2080,9,12,5,1,0,12]

theorem envBound27370 : H12AffineFastState.Bounded env27370 := by
  intro p hp
  have h : env27370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27369_27370 : H12AffineEnvironment.transform 5 12 env27369 = env27370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env27369 == env27370) = true)

theorem identity27370 : scanCanonicalize (H12AffineFastState.compose env27370 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27370 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27371 : List Nat := [2,4,8,1,12,12,4,4,0,9,2048,13,5,13,0,15,13,10,5,1,13,13,12,14,4,13,7,1,12,2060,9,12,5,1,0,12]

theorem envBound27371 : H12AffineFastState.Bounded env27371 := by
  intro p hp
  have h : env27371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27370_27371 : H12AffineEnvironment.transform 4 12 env27370 = env27371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27370 == env27371) = true)

theorem identity27371 : scanCanonicalize (H12AffineFastState.compose env27371 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27371 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27372 : List Nat := [2,3,8,1,11,11,3,3,0,9,2048,10,2,10,0,8,10,10,2,1,10,10,11,9,3,10,0,1,11,2059,9,11,2,1,0,11]

theorem envBound27372 : H12AffineFastState.Bounded env27372 := by
  intro p hp
  have h : env27372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27371_27372 : H12AffineEnvironment.transform 1 3 env27371 = env27372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27371 == env27372) = true)

theorem identity27372 : scanCanonicalize (H12AffineFastState.compose env27372 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound27372 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env27373 : List Nat := [2,3,8,1,11,11,3,3,0,9,10,10,2,10,0,8,10,10,2,1,10,10,11,9,3,10,0,1,11,1,9,11,2,1,0,11]

theorem envBound27373 : H12AffineFastState.Bounded env27373 := by
  intro p hp
  have h : env27373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27372_27373 : H12AffineEnvironment.transform 10 10 env27372 = env27373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env27372 == env27373) = true)

def env27374 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,80,8540,65536,74031,65665,533,8541,853,648,74047,65552,9181,74299,318,74110,81,76638,8204,8201,257,74095,0,340]

theorem envBound27374 : H12AffineFastState.Bounded env27374 := by
  intro p hp
  have h : env27374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27335_27374 : H12AffineEnvironment.transform 11 853 env27335 = env27374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env27335 == env27374) = true)

def env27375 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,65536,74031,65665,517,8525,837,648,74031,65536,9165,74283,302,74094,65,76622,8204,8201,257,74095,0,324]

theorem envBound27375 : H12AffineFastState.Bounded env27375 := by
  intro p hp
  have h : env27375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27374_27375 : H12AffineEnvironment.transform 3 0 env27374 = env27375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27374 == env27375) = true)

theorem identity27375 : scanCanonicalize (H12AffineFastState.compose env27375 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 321) := by decide +kernel

theorem selectedBound27375 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27376 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,321,64,13,65536,65646,65665,517,12,837,648,65646,65536,652,66410,302,65583,65,68111,333,328,257,65582,0,324]

theorem envBound27376 : H12AffineFastState.Bounded env27376 := by
  intro p hp
  have h : env27376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27375_27376 : H12AffineEnvironment.transform 12 321 env27375 = env27376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env27375 == env27376) = true)

def env27377 : List Nat := [2,4,8,0,32,64,128,256,260,321,2048,65,321,64,13,65536,65646,65665,257,12,65,396,65646,65536,392,65646,302,65583,65,67851,333,328,257,65582,0,324]

theorem envBound27377 : H12AffineFastState.Bounded env27377 := by
  intro p hp
  have h : env27377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27376_27377 : H12AffineEnvironment.transform 8 260 env27376 = env27377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env27376 == env27377) = true)

theorem identity27377 : scanCanonicalize (H12AffineFastState.compose env27377 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound27377 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env27378 : List Nat := [2,4,8,0,32,64,128,69,65,4,2048,65,4,64,13,65536,65646,65665,68,12,65,201,65646,65536,205,65646,107,65583,65,67662,8,13,68,65582,0,1]

theorem envBound27378 : H12AffineFastState.Bounded env27378 := by
  intro p hp
  have h : env27378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27377_27378 : H12AffineEnvironment.transform 7 69 env27377 = env27378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env27377 == env27378) = true)

theorem identity27378 : scanCanonicalize (H12AffineFastState.compose env27378 (packedSelected [0,1,2,5,7,10,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound27378 : packedSelected [0,1,2,5,7,10,18,19] rootPS < 2^1333 := by decide +kernel

def env27379 : List Nat := [2,4,8,0,32,64,99,69,65,4,2048,65,4,64,13,65536,65646,65634,68,12,65,42,65646,65536,46,65646,107,65583,65,67662,8,13,68,65582,0,1]

theorem envBound27379 : H12AffineFastState.Bounded env27379 := by
  intro p hp
  have h : env27379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27378_27379 : H12AffineEnvironment.transform 6 99 env27378 = env27379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env27378 == env27379) = true)

theorem identity27379 : scanCanonicalize (H12AffineFastState.compose env27379 (packedSelected [0,1,2,7,10,11,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 2146) := by decide +kernel

theorem selectedBound27379 : packedSelected [0,1,2,7,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env27380 : List Nat := [2,4,8,0,32,64,99,69,65,4,2048,65,4,64,13,2146,2060,2048,68,12,65,42,2060,2146,46,2060,107,2125,65,44,8,13,68,2124,0,1]

theorem envBound27380 : H12AffineFastState.Bounded env27380 := by
  intro p hp
  have h : env27380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27379_27380 : H12AffineEnvironment.transform 15 2146 env27379 = env27380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2146 env27379 == env27380) = true)

theorem identity27380 : scanCanonicalize (H12AffineFastState.compose env27380 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27380 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env27381 : List Nat := [2,4,8,0,12,64,79,69,65,4,2048,65,4,64,13,2126,2060,2048,68,12,65,6,2060,2126,2,2060,71,2125,65,0,8,13,68,2124,0,1]

theorem envBound27381 : H12AffineFastState.Bounded env27381 := by
  intro p hp
  have h : env27381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27380_27381 : H12AffineEnvironment.transform 4 12 env27380 = env27381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27380 == env27381) = true)

theorem identity27381 : scanCanonicalize (H12AffineFastState.compose env27381 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound27381 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27382 : List Nat := [2,4,8,0,12,64,79,69,65,4,74,65,4,64,13,4,70,74,68,12,65,6,70,4,2,70,71,7,65,0,8,13,68,6,0,1]

theorem envBound27382 : H12AffineFastState.Bounded env27382 := by
  intro p hp
  have h : env27382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27381_27382 : H12AffineEnvironment.transform 10 74 env27381 = env27382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env27381 == env27382) = true)

def env27383 : List Nat := [2,4,8,0,32,64,128,256,261,321,2048,64,321,64,13,65536,65646,65665,256,12,64,397,65646,65536,393,65647,302,65583,65,67850,333,328,257,65582,0,324]

theorem envBound27383 : H12AffineFastState.Bounded env27383 := by
  intro p hp
  have h : env27383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27376_27383 : H12AffineEnvironment.transform 8 261 env27376 = env27383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env27376 == env27383) = true)

theorem identity27383 : scanCanonicalize (H12AffineFastState.compose env27383 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27383 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env27384 : List Nat := [2,4,8,0,32,64,128,5,0,68,2048,64,68,64,13,65536,65646,65665,5,12,64,136,65646,65536,140,65647,43,65583,65,67599,72,77,4,65582,0,65]

theorem envBound27384 : H12AffineFastState.Bounded env27384 := by
  intro p hp
  have h : env27384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27383_27384 : H12AffineEnvironment.transform 7 5 env27383 = env27384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27383 == env27384) = true)

theorem identity27384 : scanCanonicalize (H12AffineFastState.compose env27384 (packedSelected [0,3,4,7,8,9,11,16] rootPS)) = affineNative (2^(15+1) ^^^ 41) := by decide +kernel

theorem selectedBound27384 : packedSelected [0,3,4,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env27385 : List Nat := [2,4,8,0,32,64,128,5,0,68,2048,64,68,64,13,41,71,168,5,12,64,136,71,41,140,70,43,6,65,2086,72,77,4,7,0,65]

theorem envBound27385 : H12AffineFastState.Bounded env27385 := by
  intro p hp
  have h : env27385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27384_27385 : H12AffineEnvironment.transform 15 41 env27384 = env27385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env27384 == env27385) = true)

theorem identity27385 : scanCanonicalize (H12AffineFastState.compose env27385 (packedSelected [1,3,8,10,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound27385 : packedSelected [1,3,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27386 : List Nat := [2,4,8,0,32,64,128,5,0,68,106,64,68,64,13,41,71,168,5,12,64,136,71,41,140,70,43,6,65,76,72,77,4,7,0,65]

theorem envBound27386 : H12AffineFastState.Bounded env27386 := by
  intro p hp
  have h : env27386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27385_27386 : H12AffineEnvironment.transform 10 106 env27385 = env27386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env27385 == env27386) = true)

theorem identity27386 : scanCanonicalize (H12AffineFastState.compose env27386 (packedSelected [4,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound27386 : packedSelected [4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27387 : List Nat := [2,4,8,0,32,64,15,5,0,68,106,64,68,64,13,41,71,39,5,12,64,7,71,41,3,70,43,6,65,76,72,77,4,7,0,65]

theorem envBound27387 : H12AffineFastState.Bounded env27387 := by
  intro p hp
  have h : env27387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27386_27387 : H12AffineEnvironment.transform 6 15 env27386 = env27387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env27386 == env27387) = true)

theorem identity27387 : scanCanonicalize (H12AffineFastState.compose env27387 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27387 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env27388 : List Nat := [2,4,4,0,32,64,3,5,0,68,102,64,68,64,1,37,71,39,5,0,64,7,71,37,3,70,39,6,65,64,68,65,4,7,0,65]

theorem envBound27388 : H12AffineFastState.Bounded env27388 := by
  intro p hp
  have h : env27388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27387_27388 : H12AffineEnvironment.transform 2 4 env27387 = env27388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27387 == env27388) = true)

theorem identity27388 : scanCanonicalize (H12AffineFastState.compose env27388 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27388 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27389 : List Nat := [2,2,2,0,32,64,3,3,0,66,96,64,66,64,1,35,65,33,3,0,64,1,65,35,3,64,33,0,65,64,66,65,2,1,0,65]

theorem envBound27389 : H12AffineFastState.Bounded env27389 := by
  intro p hp
  have h : env27389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27388_27389 : H12AffineEnvironment.transform 1 2 env27388 = env27389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27388 == env27389) = true)

theorem identity27389 : scanCanonicalize (H12AffineFastState.compose env27389 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27390 : List Nat := [2,2,2,0,0,64,3,3,0,66,64,64,66,64,1,3,65,1,3,0,64,1,65,3,3,64,1,0,65,64,66,65,2,1,0,65]

theorem envBound27390 : H12AffineFastState.Bounded env27390 := by
  intro p hp
  have h : env27390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27389_27390 : H12AffineEnvironment.transform 4 0 env27389 = env27390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27389 == env27390) = true)

def env27391 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,65536,74031,65665,516,8524,836,648,74030,65537,9164,74282,303,74095,64,76623,8204,8201,257,74095,0,325]

theorem envBound27391 : H12AffineFastState.Bounded env27391 := by
  intro p hp
  have h : env27391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27374_27391 : H12AffineEnvironment.transform 3 1 env27374 = env27391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27374 == env27391) = true)

theorem identity27391 : scanCanonicalize (H12AffineFastState.compose env27391 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound27391 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27392 : List Nat := [2,4,8,1,32,64,128,8,512,73,2048,588,8192,65,8261,65536,73767,65665,516,8260,588,648,73766,65537,8900,74282,39,73831,64,76359,8204,8201,9,73831,0,77]

theorem envBound27392 : H12AffineFastState.Bounded env27392 := by
  intro p hp
  have h : env27392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27391_27392 : H12AffineEnvironment.transform 7 8 env27391 = env27392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env27391 == env27392) = true)

def env27393 : List Nat := [2,4,4,1,32,64,128,4,512,69,2048,576,8192,65,8261,65536,73767,65665,516,8260,576,644,73766,65537,8900,74278,39,73831,64,76359,8192,8197,5,73831,0,65]

theorem envBound27393 : H12AffineFastState.Bounded env27393 := by
  intro p hp
  have h : env27393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27392_27393 : H12AffineEnvironment.transform 2 4 env27392 = env27393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27392 == env27393) = true)

theorem identity27393 : scanCanonicalize (H12AffineFastState.compose env27393 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27393 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27394 : List Nat := [2,4,4,1,32,64,128,4,1,69,2048,65,8192,65,8261,65536,73767,65665,5,8260,65,133,73766,65537,8389,73767,39,73831,64,75846,8192,8197,5,73831,0,65]

theorem envBound27394 : H12AffineFastState.Bounded env27394 := by
  intro p hp
  have h : env27394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27393_27394 : H12AffineEnvironment.transform 8 1 env27393 = env27394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27393 == env27394) = true)

theorem identity27394 : scanCanonicalize (H12AffineFastState.compose env27394 (packedSelected [0,3,4,7,8,9,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound27394 : packedSelected [0,3,4,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env27395 : List Nat := [2,4,4,1,32,64,128,4,1,69,2048,65,3,65,70,65536,65572,65665,5,71,65,133,65573,65537,198,65572,39,65636,64,67653,3,6,5,65636,0,65]

theorem envBound27395 : H12AffineFastState.Bounded env27395 := by
  intro p hp
  have h : env27395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27394_27395 : H12AffineEnvironment.transform 12 3 env27394 = env27395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env27394 == env27395) = true)

theorem identity27395 : scanCanonicalize (H12AffineFastState.compose env27395 (packedSelected [0,1,7,10,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2050) := by decide +kernel

theorem selectedBound27395 : packedSelected [0,1,7,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27396 : List Nat := [2,4,4,1,32,64,128,4,1,69,2048,65,3,65,70,2050,2086,2179,5,71,65,133,2087,2051,198,2086,39,2150,64,71,3,6,5,2150,0,65]

theorem envBound27396 : H12AffineFastState.Bounded env27396 := by
  intro p hp
  have h : env27396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27395_27396 : H12AffineEnvironment.transform 15 2050 env27395 = env27396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2050 env27395 == env27396) = true)

theorem identity27396 : scanCanonicalize (H12AffineFastState.compose env27396 (packedSelected [1,2,4,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound27396 : packedSelected [1,2,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env27397 : List Nat := [2,4,4,1,32,64,128,4,1,69,71,65,3,65,70,69,97,196,5,71,65,133,96,68,198,97,39,33,64,71,3,6,5,33,0,65]

theorem envBound27397 : H12AffineFastState.Bounded env27397 := by
  intro p hp
  have h : env27397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27396_27397 : H12AffineEnvironment.transform 10 71 env27396 = env27397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env27396 == env27397) = true)

theorem identity27397 : scanCanonicalize (H12AffineFastState.compose env27397 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27397 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27398 : List Nat := [2,4,4,1,0,64,128,4,1,69,71,65,3,65,70,69,65,196,5,71,65,133,64,68,198,65,7,1,64,71,3,6,5,1,0,65]

theorem envBound27398 : H12AffineFastState.Bounded env27398 := by
  intro p hp
  have h : env27398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27397_27398 : H12AffineEnvironment.transform 4 0 env27397 = env27398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27397 == env27398) = true)

theorem identity27398 : scanCanonicalize (H12AffineFastState.compose env27398 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound27398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27399 : List Nat := [2,4,4,1,0,64,3,4,1,69,71,65,3,65,70,69,65,71,5,71,65,6,64,68,69,65,7,1,64,71,3,6,5,1,0,65]

theorem envBound27399 : H12AffineFastState.Bounded env27399 := by
  intro p hp
  have h : env27399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27398_27399 : H12AffineEnvironment.transform 6 3 env27398 = env27399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env27398 == env27399) = true)

theorem identity27399 : scanCanonicalize (H12AffineFastState.compose env27399 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound27399 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27400 : List Nat := [2,4,4,1,0,1,3,4,1,4,6,0,3,0,7,4,0,6,5,6,0,6,1,5,4,0,7,1,1,6,3,6,5,1,0,0]

theorem envBound27400 : H12AffineFastState.Bounded env27400 := by
  intro p hp
  have h : env27400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27399_27400 : H12AffineEnvironment.transform 5 1 env27399 = env27400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27399 == env27400) = true)

theorem identity27400 : scanCanonicalize (H12AffineFastState.compose env27400 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27401 : List Nat := [2,0,0,1,0,1,3,0,1,0,2,0,3,0,3,0,0,2,1,2,0,2,1,1,0,0,3,1,1,2,3,2,1,1,0,0]

theorem envBound27401 : H12AffineFastState.Bounded env27401 := by
  intro p hp
  have h : env27401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27400_27401 : H12AffineEnvironment.transform 1 0 env27400 = env27401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27400 == env27401) = true)

theorem identity27401 : scanCanonicalize (H12AffineFastState.compose env27401 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27401 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27402 : List Nat := [1,0,0,1,0,1,0,0,1,0,1,0,0,0,0,0,0,1,1,1,0,1,1,1,0,0,0,1,1,1,0,1,1,1,0,0]

theorem envBound27402 : H12AffineFastState.Bounded env27402 := by
  intro p hp
  have h : env27402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27401_27402 : H12AffineEnvironment.transform 0 1 env27401 = env27402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27401 == env27402) = true)

def env27403 : List Nat := [2,4,5,1,32,64,128,5,512,68,2048,577,8192,65,8261,65536,73767,65665,516,8260,577,645,73766,65537,8900,74279,39,73831,64,76359,8193,8196,4,73831,0,64]

theorem envBound27403 : H12AffineFastState.Bounded env27403 := by
  intro p hp
  have h : env27403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27392_27403 : H12AffineEnvironment.transform 2 5 env27392 = env27403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27392 == env27403) = true)

theorem identity27403 : scanCanonicalize (H12AffineFastState.compose env27403 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 610) := by decide +kernel

theorem selectedBound27403 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27404 : List Nat := [2,4,5,1,32,64,128,5,512,68,2048,577,8192,65,8261,610,8773,739,516,8260,577,645,8772,611,8900,8261,39,8709,64,10277,8193,8196,4,8709,0,64]

theorem envBound27404 : H12AffineFastState.Bounded env27404 := by
  intro p hp
  have h : env27404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27403_27404 : H12AffineEnvironment.transform 15 610 env27403 = env27404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 610 env27403 == env27404) = true)

theorem identity27404 : scanCanonicalize (H12AffineFastState.compose env27404 (packedSelected [2,4,9,11,12,15,16,18,21] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound27404 : packedSelected [2,4,9,11,12,15,16,18,21] rootPS < 2^1333 := by decide +kernel

def env27405 : List Nat := [2,4,5,1,32,64,68,5,512,68,2048,577,8192,65,8261,610,8773,551,516,8260,577,577,8772,611,8704,8261,39,8709,64,10277,8193,8196,4,8709,0,64]

theorem envBound27405 : H12AffineFastState.Bounded env27405 := by
  intro p hp
  have h : env27405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27404_27405 : H12AffineEnvironment.transform 6 68 env27404 = env27405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env27404 == env27405) = true)

theorem identity27405 : scanCanonicalize (H12AffineFastState.compose env27405 (packedSelected [2,3,5,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27405 : packedSelected [2,3,5,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env27406 : List Nat := [2,4,5,1,32,64,68,5,1,68,2048,64,8192,65,8261,99,8260,38,5,8260,64,64,8261,98,8193,8261,39,8196,64,10277,8193,8196,4,8196,0,64]

theorem envBound27406 : H12AffineFastState.Bounded env27406 := by
  intro p hp
  have h : env27406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27405_27406 : H12AffineEnvironment.transform 8 1 env27405 = env27406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27405 == env27406) = true)

theorem identity27406 : scanCanonicalize (H12AffineFastState.compose env27406 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 66) := by decide +kernel

theorem selectedBound27406 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27407 : List Nat := [2,4,5,1,32,64,68,5,1,68,2048,64,66,65,7,99,6,38,5,6,64,64,7,98,67,7,39,70,64,2151,67,70,4,70,0,64]

theorem envBound27407 : H12AffineFastState.Bounded env27407 := by
  intro p hp
  have h : env27407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27406_27407 : H12AffineEnvironment.transform 12 66 env27406 = env27407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 66 env27406 == env27407) = true)

theorem identity27407 : scanCanonicalize (H12AffineFastState.compose env27407 (packedSelected [3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound27407 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env27408 : List Nat := [2,4,5,1,32,64,68,5,1,68,33,64,66,65,7,99,6,38,5,6,64,64,7,98,67,7,39,70,64,70,67,70,4,70,0,64]

theorem envBound27408 : H12AffineFastState.Bounded env27408 := by
  intro p hp
  have h : env27408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27407_27408 : H12AffineEnvironment.transform 10 33 env27407 = env27408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env27407 == env27408) = true)

theorem identity27408 : scanCanonicalize (H12AffineFastState.compose env27408 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27408 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27409 : List Nat := [2,4,5,1,1,64,68,5,1,68,0,64,66,65,7,66,6,7,5,6,64,64,7,67,67,7,6,70,64,70,67,70,4,70,0,64]

theorem envBound27409 : H12AffineFastState.Bounded env27409 := by
  intro p hp
  have h : env27409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27408_27409 : H12AffineEnvironment.transform 4 1 env27408 = env27409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27408 == env27409) = true)

def env27410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123165,533641,614526,385202,90414,545089,96347,25884,536904,257,74798,1345,525824]

theorem envBound27410 : H12AffineFastState.Bounded env27410 := by
  intro p hp
  have h : env27410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26948_27410 : H12AffineEnvironment.transform 23 123165 env26948 = env27410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env26948 == env27410) = true)

def env27411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123165,28889,78894,385202,90414,1297,96347,25884,25880,257,74798,1345,21072]

theorem envBound27411 : H12AffineFastState.Bounded env27411 := by
  intro p hp
  have h : env27411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27410_27411 : H12AffineEnvironment.transform 18 21584 env27410 = env27411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env27410 == env27411) = true)

theorem identity27411 : scanCanonicalize (H12AffineFastState.compose env27411 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound27411 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4096,17612,91182,87296,28889,78894,349359,90414,1297,96347,25884,25880,257,74798,1345,21072]

theorem envBound27412 : H12AffineFastState.Bounded env27412 := by
  intro p hp
  have h : env27412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27411_27412 : H12AffineEnvironment.transform 14 13341 env27411 = env27412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env27411 == env27412) = true)

def env27413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4096,476,74046,69648,13769,78894,332223,74814,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound27413 : H12AffineFastState.Bounded env27413 := by
  intro p hp
  have h : env27413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27412_27413 : H12AffineEnvironment.transform 13 1296 env27412 = env27413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27412 == env27413) = true)

def env27414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4096,476,74046,69648,13769,78894,4415,74814,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound27414 : H12AffineFastState.Bounded env27414 := by
  intro p hp
  have h : env27414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27413_27414 : H12AffineEnvironment.transform 17 65664 env27413 = env27414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27413 == env27414) = true)

theorem identity27414 : scanCanonicalize (H12AffineFastState.compose env27414 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound27414 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,359,9481,487,4416,13340,4096,476,8281,4471,13769,13641,4415,9561,1297,15404,8204,8200,257,9545,1345,5952]

theorem envBound27415 : H12AffineFastState.Bounded env27415 := by
  intro p hp
  have h : env27415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27414_27415 : H12AffineEnvironment.transform 15 359 env27414 = env27415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env27414 == env27415) = true)

def env27416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,359,1345,487,4416,5204,4096,476,17,4471,5505,5377,4415,1297,1297,7268,68,64,257,1281,1345,5952]

theorem envBound27416 : H12AffineFastState.Bounded env27416 := by
  intro p hp
  have h : env27416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27415_27416 : H12AffineEnvironment.transform 12 72 env27415 = env27416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env27415 == env27416) = true)

theorem identity27416 : scanCanonicalize (H12AffineFastState.compose env27416 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound27416 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1296,1029,359,1345,487,272,1028,80,476,17,295,1489,1361,367,1297,1297,3124,68,64,257,1281,1345,1808]

theorem envBound27417 : H12AffineFastState.Bounded env27417 := by
  intro p hp
  have h : env27417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27416_27417 : H12AffineEnvironment.transform 11 80 env27416 = env27417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env27416 == env27417) = true)

theorem identity27417 : scanCanonicalize (H12AffineFastState.compose env27417 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27417 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27418 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,72,1213,1029,202,1260,74,189,1028,80,113,17,138,1148,1276,194,1212,1212,3124,68,64,172,1196,1260,1725]

theorem envBound27418 : H12AffineFastState.Bounded env27418 := by
  intro p hp
  have h : env27418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27417_27418 : H12AffineEnvironment.transform 7 173 env27417 = env27418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27417 == env27418) = true)

theorem identity27418 : scanCanonicalize (H12AffineFastState.compose env27418 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound27418 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env27419 : List Nat := [2,4,8,16,32,64,128,173,512,1024,538,80,72,1213,1029,202,1260,74,189,1028,80,113,17,138,1148,1276,194,1212,1212,1582,68,64,172,1196,1260,1725]

theorem envBound27419 : H12AffineFastState.Bounded env27419 := by
  intro p hp
  have h : env27419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27418_27419 : H12AffineEnvironment.transform 10 538 env27418 = env27419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env27418 == env27419) = true)

theorem identity27419 : scanCanonicalize (H12AffineFastState.compose env27419 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound27419 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env27420 : List Nat := [2,4,8,16,32,64,18,63,512,1024,538,80,72,1071,1029,88,1150,74,47,1028,80,113,17,24,1148,1134,80,1070,1070,1582,68,64,62,1086,1150,1583]

theorem envBound27420 : H12AffineFastState.Bounded env27420 := by
  intro p hp
  have h : env27420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27419_27420 : H12AffineEnvironment.transform 6 18 env27419 = env27420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env27419 == env27420) = true)

theorem identity27420 : scanCanonicalize (H12AffineFastState.compose env27420 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27420 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27421 : List Nat := [2,4,8,16,32,64,18,63,512,52,538,80,72,27,49,88,74,74,47,48,80,113,17,24,72,90,80,26,26,538,68,64,62,10,74,539]

theorem envBound27421 : H12AffineFastState.Bounded env27421 := by
  intro p hp
  have h : env27421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27420_27421 : H12AffineEnvironment.transform 9 52 env27420 = env27421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27420 == env27421) = true)

theorem identity27421 : scanCanonicalize (H12AffineFastState.compose env27421 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound27421 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env27422 : List Nat := [2,4,8,16,32,64,18,63,48,52,42,80,72,27,49,88,74,74,47,48,80,113,17,24,72,90,80,26,26,42,68,64,62,10,74,43]

theorem envBound27422 : H12AffineFastState.Bounded env27422 := by
  intro p hp
  have h : env27422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27421_27422 : H12AffineEnvironment.transform 8 48 env27421 = env27422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env27421 == env27422) = true)

theorem identity27422 : scanCanonicalize (H12AffineFastState.compose env27422 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27422 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27423 : List Nat := [2,4,8,16,11,64,18,20,27,31,1,80,72,27,26,88,74,74,4,27,80,90,17,24,72,90,80,26,26,1,68,64,21,10,74,0]

theorem envBound27423 : H12AffineFastState.Bounded env27423 := by
  intro p hp
  have h : env27423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27422_27423 : H12AffineEnvironment.transform 4 11 env27422 = env27423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27422 == env27423) = true)

theorem identity27423 : scanCanonicalize (H12AffineFastState.compose env27423 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27424 : List Nat := [2,4,8,16,11,16,18,20,27,31,1,0,24,27,26,8,26,26,4,27,0,10,17,24,24,10,0,26,26,1,20,16,21,10,26,0]

theorem envBound27424 : H12AffineFastState.Bounded env27424 := by
  intro p hp
  have h : env27424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27423_27424 : H12AffineEnvironment.transform 5 16 env27423 = env27424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27423 == env27424) = true)

theorem identity27424 : scanCanonicalize (H12AffineFastState.compose env27424 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound27424 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env27425 : List Nat := [2,4,8,7,11,7,5,3,12,8,1,0,15,12,13,8,13,13,4,12,0,10,6,15,15,10,0,13,13,1,3,7,2,10,13,0]

theorem envBound27425 : H12AffineFastState.Bounded env27425 := by
  intro p hp
  have h : env27425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27424_27425 : H12AffineEnvironment.transform 3 7 env27424 = env27425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env27424 == env27425) = true)

theorem identity27425 : scanCanonicalize (H12AffineFastState.compose env27425 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27425 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27426 : List Nat := [2,4,4,7,7,7,5,3,0,4,1,0,3,0,1,4,1,1,4,0,0,6,6,3,3,6,0,1,1,1,3,7,2,6,1,0]

theorem envBound27426 : H12AffineFastState.Bounded env27426 := by
  intro p hp
  have h : env27426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27425_27426 : H12AffineEnvironment.transform 2 4 env27425 = env27426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27425 == env27426) = true)

def env27427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,359,1344,487,4416,5205,4096,476,16,4471,5504,5376,4415,1296,1297,7269,69,65,257,1280,1345,5952]

theorem envBound27427 : H12AffineFastState.Bounded env27427 := by
  intro p hp
  have h : env27427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27415_27427 : H12AffineEnvironment.transform 12 73 env27415 = env27427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env27415 == env27427) = true)

theorem identity27427 : scanCanonicalize (H12AffineFastState.compose env27427 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27427 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27428 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,73,277,4177,359,325,487,4416,4176,4096,476,16,4471,4485,4357,4415,277,276,6240,69,65,257,261,324,4933]

theorem envBound27428 : H12AffineFastState.Bounded env27428 := by
  intro p hp
  have h : env27428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27427_27428 : H12AffineEnvironment.transform 9 5 env27427 = env27428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27427 == env27428) = true)

theorem identity27428 : scanCanonicalize (H12AffineFastState.compose env27428 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound27428 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27429 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,325,73,277,276,359,325,487,5,277,325,476,16,50,192,64,122,277,276,2341,69,65,257,261,324,512]

theorem envBound27429 : H12AffineFastState.Bounded env27429 := by
  intro p hp
  have h : env27429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27428_27429 : H12AffineEnvironment.transform 11 325 env27428 = env27429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env27428 == env27429) = true)

theorem identity27429 : scanCanonicalize (H12AffineFastState.compose env27429 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27429 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27430 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,25,277,276,311,277,439,5,277,277,396,16,50,144,16,42,277,276,2341,21,17,257,261,276,512]

theorem envBound27430 : H12AffineFastState.Bounded env27430 := by
  intro p hp
  have h : env27430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27429_27430 : H12AffineEnvironment.transform 5 16 env27429 = env27430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27429 == env27430) = true)

theorem identity27430 : scanCanonicalize (H12AffineFastState.compose env27430 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound27430 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27431 : List Nat := [2,4,8,16,32,16,128,256,512,5,513,277,25,277,276,311,277,439,5,277,277,396,16,50,144,16,42,277,276,804,21,17,257,261,276,512]

theorem envBound27431 : H12AffineFastState.Bounded env27431 := by
  intro p hp
  have h : env27431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27430_27431 : H12AffineEnvironment.transform 10 513 env27430 = env27431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env27430 == env27431) = true)

theorem identity27431 : scanCanonicalize (H12AffineFastState.compose env27431 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound27431 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27432 : List Nat := [2,4,8,16,32,16,34,256,512,5,513,277,25,277,276,311,277,277,5,277,277,302,16,50,50,16,42,277,276,804,21,17,257,261,276,512]

theorem envBound27432 : H12AffineFastState.Bounded env27432 := by
  intro p hp
  have h : env27432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27431_27432 : H12AffineEnvironment.transform 6 34 env27431 = env27432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env27431 == env27432) = true)

theorem identity27432 : scanCanonicalize (H12AffineFastState.compose env27432 (packedSelected [1,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound27432 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env27433 : List Nat := [2,4,8,16,32,16,34,256,48,5,49,277,25,277,276,311,277,277,5,277,277,302,16,50,50,16,42,277,276,276,21,17,257,261,276,48]

theorem envBound27433 : H12AffineFastState.Bounded env27433 := by
  intro p hp
  have h : env27433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27432_27433 : H12AffineEnvironment.transform 8 48 env27432 = env27433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env27432 == env27433) = true)

theorem identity27433 : scanCanonicalize (H12AffineFastState.compose env27433 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27433 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27434 : List Nat := [2,4,8,16,16,16,18,256,0,5,1,277,25,277,276,263,277,277,5,277,277,286,16,2,2,16,26,277,276,276,21,17,257,261,276,0]

theorem envBound27434 : H12AffineFastState.Bounded env27434 := by
  intro p hp
  have h : env27434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27433_27434 : H12AffineEnvironment.transform 4 16 env27433 = env27434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27433 == env27434) = true)

theorem identity27434 : scanCanonicalize (H12AffineFastState.compose env27434 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27434 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env27435 : List Nat := [2,4,8,16,16,16,18,20,0,5,1,1,25,1,0,19,1,1,5,1,1,10,16,2,2,16,26,1,0,0,21,17,21,17,0,0]

theorem envBound27435 : H12AffineFastState.Bounded env27435 := by
  intro p hp
  have h : env27435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27434_27435 : H12AffineEnvironment.transform 7 20 env27434 = env27435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27434 == env27435) = true)

theorem identity27435 : scanCanonicalize (H12AffineFastState.compose env27435 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound27435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27436 : List Nat := [2,4,8,13,13,13,15,9,0,5,1,1,4,1,0,14,1,1,5,1,1,10,13,2,2,13,7,1,0,0,8,12,8,12,0,0]

theorem envBound27436 : H12AffineFastState.Bounded env27436 := by
  intro p hp
  have h : env27436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27435_27436 : H12AffineEnvironment.transform 3 13 env27435 = env27436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env27435 == env27436) = true)

theorem identity27436 : scanCanonicalize (H12AffineFastState.compose env27436 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27437 : List Nat := [2,3,8,10,10,10,8,9,0,2,1,1,3,1,0,9,1,1,2,1,1,10,10,2,2,10,0,1,0,0,8,11,8,11,0,0]

theorem envBound27437 : H12AffineFastState.Bounded env27437 := by
  intro p hp
  have h : env27437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27436_27437 : H12AffineEnvironment.transform 1 3 env27436 = env27437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27436 == env27437) = true)

def env27438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4096,476,74046,69648,13769,78894,4414,74814,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound27438 : H12AffineFastState.Bounded env27438 := by
  intro p hp
  have h : env27438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27413_27438 : H12AffineEnvironment.transform 17 65665 env27413 = env27438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27413 == env27438) = true)

theorem identity27438 : scanCanonicalize (H12AffineFastState.compose env27438 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound27438 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,12360,5287,4416,13340,4096,476,13592,1078,13769,8200,4414,12312,1297,10605,8204,8200,257,12296,1345,5952]

theorem envBound27439 : H12AffineFastState.Bounded env27439 := by
  intro p hp
  have h : env27439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27438_27439 : H12AffineEnvironment.transform 15 5158 env27438 = env27439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env27438 == env27439) = true)

def env27440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,5158,1344,5287,4416,276,4096,476,16,1078,193,5376,4414,1296,1297,7269,5380,5376,257,1280,1345,5952]

theorem envBound27440 : H12AffineFastState.Bounded env27440 := by
  intro p hp
  have h : env27440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27439_27440 : H12AffineEnvironment.transform 12 5384 env27439 = env27440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env27439 == env27440) = true)

theorem identity27440 : scanCanonicalize (H12AffineFastState.compose env27440 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27440 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27441 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4365,277,277,4131,325,4258,4416,276,4096,476,16,51,193,4357,4414,277,276,6240,4353,4357,257,261,324,4933]

theorem envBound27441 : H12AffineFastState.Bounded env27441 := by
  intro p hp
  have h : env27441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27440_27441 : H12AffineEnvironment.transform 9 5 env27440 = env27441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27440 == env27441) = true)

theorem identity27441 : scanCanonicalize (H12AffineFastState.compose env27441 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 973) := by decide +kernel

theorem selectedBound27441 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27442 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,973,704,277,277,1006,325,879,653,276,973,476,16,51,193,712,755,277,276,2989,716,712,257,261,324,136]

theorem envBound27442 : H12AffineFastState.Bounded env27442 := by
  intro p hp
  have h : env27442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27441_27442 : H12AffineEnvironment.transform 11 973 env27441 = env27442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 973 env27441 == env27442) = true)

theorem identity27442 : scanCanonicalize (H12AffineFastState.compose env27442 (packedSelected [1,3,10,11,13,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27442 : packedSelected [1,3,10,11,13,18,19] rootPS < 2^1333 := by decide +kernel

def env27443 : List Nat := [2,4,8,16,32,64,128,173,512,5,2048,608,704,184,184,579,232,706,653,185,608,113,16,51,193,712,755,184,185,2560,716,712,172,168,233,136]

theorem envBound27443 : H12AffineFastState.Bounded env27443 := by
  intro p hp
  have h : env27443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27442_27443 : H12AffineEnvironment.transform 7 173 env27442 = env27443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27442 == env27443) = true)

theorem identity27443 : scanCanonicalize (H12AffineFastState.compose env27443 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound27443 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27444 : List Nat := [2,4,8,16,32,64,128,173,512,5,586,608,704,184,184,579,232,706,653,185,608,113,16,51,193,712,755,184,185,74,716,712,172,168,233,136]

theorem envBound27444 : H12AffineFastState.Bounded env27444 := by
  intro p hp
  have h : env27444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27443_27444 : H12AffineEnvironment.transform 10 586 env27443 = env27444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env27443 == env27444) = true)

theorem identity27444 : scanCanonicalize (H12AffineFastState.compose env27444 (packedSelected [4,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound27444 : packedSelected [4,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env27445 : List Nat := [2,4,8,16,32,64,128,173,217,5,147,185,25,184,184,154,232,27,84,185,185,113,16,51,193,17,42,184,185,74,21,17,172,168,233,136]

theorem envBound27445 : H12AffineFastState.Bounded env27445 := by
  intro p hp
  have h : env27445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27444_27445 : H12AffineEnvironment.transform 8 217 env27444 = env27445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env27444 == env27445) = true)

theorem identity27445 : scanCanonicalize (H12AffineFastState.compose env27445 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound27445 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27446 : List Nat := [2,4,8,16,32,64,104,69,49,5,123,81,25,80,80,114,0,27,84,81,81,113,16,51,41,17,42,80,81,74,21,17,68,64,1,96]

theorem envBound27446 : H12AffineFastState.Bounded env27446 := by
  intro p hp
  have h : env27446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27445_27446 : H12AffineEnvironment.transform 6 104 env27445 = env27446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env27445 == env27446) = true)

theorem identity27446 : scanCanonicalize (H12AffineFastState.compose env27446 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound27446 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env27447 : List Nat := [2,4,8,13,32,64,104,69,44,5,102,76,4,77,77,111,0,6,73,76,76,108,13,46,41,12,42,77,76,74,8,12,68,64,1,96]

theorem envBound27447 : H12AffineFastState.Bounded env27447 := by
  intro p hp
  have h : env27447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27446_27447 : H12AffineEnvironment.transform 3 13 env27446 = env27447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env27446 == env27447) = true)

theorem identity27447 : scanCanonicalize (H12AffineFastState.compose env27447 (packedSelected [3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27447 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27448 : List Nat := [2,2,8,11,32,64,104,67,42,3,96,74,2,75,75,105,0,0,73,74,74,106,11,40,41,10,42,75,74,74,8,10,66,64,1,96]

theorem envBound27448 : H12AffineFastState.Bounded env27448 := by
  intro p hp
  have h : env27448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27447_27448 : H12AffineEnvironment.transform 1 2 env27447 = env27448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27447 == env27448) = true)

theorem identity27448 : scanCanonicalize (H12AffineFastState.compose env27448 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound27448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27449 : List Nat := [2,2,8,11,32,11,35,8,42,3,43,1,2,0,0,34,0,0,2,1,1,33,11,40,41,10,42,0,1,1,8,10,9,11,1,43]

theorem envBound27449 : H12AffineFastState.Bounded env27449 := by
  intro p hp
  have h : env27449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27448_27449 : H12AffineEnvironment.transform 5 11 env27448 = env27449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env27448 == env27449) = true)

theorem identity27449 : scanCanonicalize (H12AffineFastState.compose env27449 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27450 : List Nat := [0,0,8,9,32,9,33,8,40,1,41,1,0,0,0,32,0,0,0,1,1,33,9,40,41,8,40,0,1,1,8,8,9,9,1,41]

theorem envBound27450 : H12AffineFastState.Bounded env27450 := by
  intro p hp
  have h : env27450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27449_27450 : H12AffineEnvironment.transform 0 0 env27449 = env27450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27449 == env27450) = true)

theorem identity27450 : scanCanonicalize (H12AffineFastState.compose env27450 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27451 : List Nat := [0,0,8,9,1,9,0,8,9,1,8,1,0,0,0,1,0,0,0,1,1,0,9,9,8,8,9,0,1,1,8,8,9,9,1,8]

theorem envBound27451 : H12AffineFastState.Bounded env27451 := by
  intro p hp
  have h : env27451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27450_27451 : H12AffineEnvironment.transform 4 1 env27450 = env27451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27450 == env27451) = true)

def env27452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,5158,1345,5287,4416,277,4096,476,17,1078,192,5377,4414,1297,1297,7268,5381,5377,257,1281,1345,5952]

theorem envBound27452 : H12AffineFastState.Bounded env27452 := by
  intro p hp
  have h : env27452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27439_27452 : H12AffineEnvironment.transform 12 5385 env27439 = env27452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env27439 == env27452) = true)

theorem identity27452 : scanCanonicalize (H12AffineFastState.compose env27452 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27452 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27453 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,1,276,4407,80,4534,4416,277,4096,476,17,295,192,4112,4414,0,0,6517,4116,4112,257,16,80,4689]

theorem envBound27453 : H12AffineFastState.Bounded env27453 := by
  intro p hp
  have h : env27453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27452_27453 : H12AffineEnvironment.transform 9 273 env27452 = env27453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27452 == env27453) = true)

theorem identity27453 : scanCanonicalize (H12AffineFastState.compose env27453 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27453 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27454 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,4096,4120,1,185,4250,80,4123,4333,184,4096,113,17,138,192,4112,4243,0,0,6360,4116,4112,172,16,80,4689]

theorem envBound27454 : H12AffineFastState.Bounded env27454 := by
  intro p hp
  have h : env27454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27453_27454 : H12AffineEnvironment.transform 7 173 env27453 = env27454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27453 == env27454) = true)

theorem identity27454 : scanCanonicalize (H12AffineFastState.compose env27454 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound27454 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env27455 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,2635,2643,1,185,2769,80,2640,2726,184,2635,113,17,138,192,2651,2776,0,0,659,2655,2651,172,16,80,2074]

theorem envBound27455 : H12AffineFastState.Bounded env27455 := by
  intro p hp
  have h : env27455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27454_27455 : H12AffineEnvironment.transform 11 2635 env27454 = env27455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env27454 == env27455) = true)

theorem identity27455 : scanCanonicalize (H12AffineFastState.compose env27455 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound27455 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env27456 : List Nat := [2,4,8,16,32,64,128,173,512,188,649,194,218,1,185,88,80,217,47,184,194,113,17,138,192,210,81,0,0,659,214,210,172,16,80,659]

theorem envBound27456 : H12AffineFastState.Bounded env27456 := by
  intro p hp
  have h : env27456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27455_27456 : H12AffineEnvironment.transform 10 649 env27455 = env27456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env27455 == env27456) = true)

theorem identity27456 : scanCanonicalize (H12AffineFastState.compose env27456 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 243) := by decide +kernel

theorem selectedBound27456 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27457 : List Nat := [2,4,8,16,32,64,128,173,243,188,122,194,218,1,185,88,80,217,47,184,194,113,17,138,192,210,81,0,0,96,214,210,172,16,80,96]

theorem envBound27457 : H12AffineFastState.Bounded env27457 := by
  intro p hp
  have h : env27457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27456_27457 : H12AffineEnvironment.transform 8 243 env27456 = env27457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 243 env27456 == env27457) = true)

theorem identity27457 : scanCanonicalize (H12AffineFastState.compose env27457 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27457 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env27458 : List Nat := [2,4,8,11,32,64,128,173,232,167,97,194,193,1,162,67,75,194,47,163,194,106,10,138,192,201,74,0,0,96,205,201,172,11,75,96]

theorem envBound27458 : H12AffineFastState.Bounded env27458 := by
  intro p hp
  have h : env27458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27457_27458 : H12AffineEnvironment.transform 3 11 env27457 = env27458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27457 == env27458) = true)

theorem identity27458 : scanCanonicalize (H12AffineFastState.compose env27458 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27458 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27459 : List Nat := [2,4,8,11,11,64,128,134,195,140,74,194,193,1,137,67,75,194,4,136,194,65,10,138,192,201,74,0,0,75,205,201,135,11,75,75]

theorem envBound27459 : H12AffineFastState.Bounded env27459 := by
  intro p hp
  have h : env27459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27458_27459 : H12AffineEnvironment.transform 4 11 env27458 = env27459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27458 == env27459) = true)

theorem identity27459 : scanCanonicalize (H12AffineFastState.compose env27459 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound27459 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27460 : List Nat := [2,4,8,11,11,64,67,69,0,79,74,1,2,1,74,67,75,1,4,75,1,65,10,73,3,10,74,0,0,75,14,10,68,11,75,75]

theorem envBound27460 : H12AffineFastState.Bounded env27460 := by
  intro p hp
  have h : env27460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27459_27460 : H12AffineEnvironment.transform 6 67 env27459 = env27460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env27459 == env27460) = true)

theorem identity27460 : scanCanonicalize (H12AffineFastState.compose env27460 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound27460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27461 : List Nat := [2,4,8,11,11,7,4,2,0,8,13,1,2,1,13,4,12,1,4,12,1,6,10,14,3,10,13,0,0,12,14,10,3,11,12,12]

theorem envBound27461 : H12AffineFastState.Bounded env27461 := by
  intro p hp
  have h : env27461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27460_27461 : H12AffineEnvironment.transform 5 7 env27460 = env27461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env27460 == env27461) = true)

theorem identity27461 : scanCanonicalize (H12AffineFastState.compose env27461 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27462 : List Nat := [2,4,5,6,6,7,4,2,0,5,0,1,2,1,0,4,1,1,4,1,1,6,7,3,3,7,0,0,0,1,3,7,3,6,1,1]

theorem envBound27462 : H12AffineFastState.Bounded env27462 := by
  intro p hp
  have h : env27462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27461_27462 : H12AffineEnvironment.transform 2 5 env27461 = env27462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27461 == env27462) = true)

theorem identity27462 : scanCanonicalize (H12AffineFastState.compose env27462 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27463 : List Nat := [2,1,0,3,3,2,1,2,0,0,0,1,2,1,0,1,1,1,1,1,1,3,2,3,3,2,0,0,0,1,3,2,3,3,1,1]

theorem envBound27463 : H12AffineFastState.Bounded env27463 := by
  intro p hp
  have h : env27463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27462_27463 : H12AffineEnvironment.transform 1 1 env27462 = env27463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27462 == env27463) = true)

theorem identity27463 : scanCanonicalize (H12AffineFastState.compose env27463 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27463 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27464 : List Nat := [1,1,0,0,0,1,1,1,0,0,0,1,1,1,0,1,1,1,1,1,1,0,1,0,0,1,0,0,0,1,0,1,0,0,1,1]

theorem envBound27464 : H12AffineFastState.Bounded env27464 := by
  intro p hp
  have h : env27464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27463_27464 : H12AffineEnvironment.transform 0 1 env27463 = env27464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27463 == env27464) = true)

def env27465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4096,477,74047,69649,13768,78894,332222,74815,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound27465 : H12AffineFastState.Bounded env27465 := by
  intro p hp
  have h : env27465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27412_27465 : H12AffineEnvironment.transform 13 1297 env27412 = env27465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27412 == env27465) = true)

def env27466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4096,477,74047,69649,13768,78894,4414,74815,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound27466 : H12AffineFastState.Bounded env27466 := by
  intro p hp
  have h : env27466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27465_27466 : H12AffineEnvironment.transform 17 65664 env27465 = env27466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27465 == env27466) = true)

theorem identity27466 : scanCanonicalize (H12AffineFastState.compose env27466 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound27466 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,5440,12718,4417,13340,4096,477,4113,8511,13768,1280,4414,5393,1297,3172,8205,8201,257,5376,1345,5953]

theorem envBound27467 : H12AffineFastState.Bounded env27467 := by
  intro p hp
  have h : env27467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27466_27467 : H12AffineEnvironment.transform 15 12590 env27466 = env27467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env27466 == env27467) = true)

def env27468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,8494,1344,8622,321,9244,0,477,17,8511,9672,1280,318,1297,1297,3172,8205,8201,257,1280,1345,1857]

theorem envBound27468 : H12AffineFastState.Bounded env27468 := by
  intro p hp
  have h : env27468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27467_27468 : H12AffineEnvironment.transform 11 0 env27467 = env27468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27467 == env27468) = true)

theorem identity27468 : scanCanonicalize (H12AffineFastState.compose env27468 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound27468 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27469 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,0,8192,1109,9245,8298,1028,8426,5,9244,0,153,17,8315,9356,1092,122,1109,1109,3172,8205,8201,69,1092,1029,1541]

theorem envBound27469 : H12AffineFastState.Bounded env27469 := by
  intro p hp
  have h : env27469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27468_27469 : H12AffineEnvironment.transform 7 68 env27468 = env27469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env27468 == env27469) = true)

theorem identity27469 : scanCanonicalize (H12AffineFastState.compose env27469 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27469 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27470 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8192,80,8216,8298,1,8426,5,8217,0,153,17,8315,8329,65,122,80,80,2145,8205,8201,69,65,0,512]

theorem envBound27470 : H12AffineFastState.Bounded env27470 := by
  intro p hp
  have h : env27470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27469_27470 : H12AffineEnvironment.transform 9 5 env27469 = env27470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27469 == env27470) = true)

theorem identity27470 : scanCanonicalize (H12AffineFastState.compose env27470 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2147) := by decide +kernel

theorem selectedBound27470 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27471 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,2147,80,2171,2057,1,2185,5,2170,0,153,17,2072,2282,65,122,80,80,2145,2158,2154,69,65,0,512]

theorem envBound27471 : H12AffineFastState.Bounded env27471 := by
  intro p hp
  have h : env27471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27470_27471 : H12AffineEnvironment.transform 12 2147 env27470 = env27471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2147 env27470 == env27471) = true)

theorem identity27471 : scanCanonicalize (H12AffineFastState.compose env27471 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound27471 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27472 : List Nat := [2,4,8,16,32,64,128,68,512,5,122,0,25,80,1,115,1,243,5,0,0,153,17,98,144,65,122,80,80,27,20,16,69,65,0,512]

theorem envBound27472 : H12AffineFastState.Bounded env27472 := by
  intro p hp
  have h : env27472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27471_27472 : H12AffineEnvironment.transform 10 122 env27471 = env27472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env27471 == env27472) = true)

theorem identity27472 : scanCanonicalize (H12AffineFastState.compose env27472 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound27472 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27473 : List Nat := [2,4,8,16,32,64,128,68,48,5,122,0,25,80,1,115,1,243,5,0,0,153,17,98,144,65,122,80,80,27,20,16,69,65,0,48]

theorem envBound27473 : H12AffineFastState.Bounded env27473 := by
  intro p hp
  have h : env27473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27472_27473 : H12AffineEnvironment.transform 8 48 env27472 = env27473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env27472 == env27473) = true)

theorem identity27473 : scanCanonicalize (H12AffineFastState.compose env27473 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound27473 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27474 : List Nat := [2,4,8,16,32,64,105,68,48,5,122,0,25,80,1,115,1,26,5,0,0,112,17,98,121,65,122,80,80,27,20,16,69,65,0,48]

theorem envBound27474 : H12AffineFastState.Bounded env27474 := by
  intro p hp
  have h : env27474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27473_27474 : H12AffineEnvironment.transform 6 105 env27473 = env27474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env27473 == env27474) = true)

theorem identity27474 : scanCanonicalize (H12AffineFastState.compose env27474 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound27474 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27475 : List Nat := [2,4,8,16,32,32,9,36,48,5,26,0,25,48,1,19,1,26,5,0,0,16,17,2,25,33,26,48,48,27,20,16,37,33,0,48]

theorem envBound27475 : H12AffineFastState.Bounded env27475 := by
  intro p hp
  have h : env27475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27474_27475 : H12AffineEnvironment.transform 5 32 env27474 = env27475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env27474 == env27475) = true)

theorem identity27475 : scanCanonicalize (H12AffineFastState.compose env27475 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27476 : List Nat := [2,4,8,10,32,32,9,36,42,5,0,0,3,42,1,9,1,0,5,0,0,10,11,2,3,33,0,42,42,1,14,10,37,33,0,42]

theorem envBound27476 : H12AffineFastState.Bounded env27476 := by
  intro p hp
  have h : env27476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27475_27476 : H12AffineEnvironment.transform 3 10 env27475 = env27476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27475 == env27476) = true)

theorem identity27476 : scanCanonicalize (H12AffineFastState.compose env27476 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27476 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27477 : List Nat := [2,4,8,10,10,10,9,14,0,5,0,0,3,0,1,9,1,0,5,0,0,10,11,2,3,11,0,0,0,1,14,10,15,11,0,0]

theorem envBound27477 : H12AffineFastState.Bounded env27477 := by
  intro p hp
  have h : env27477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27476_27477 : H12AffineEnvironment.transform 4 10 env27476 = env27477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27476 == env27477) = true)

theorem identity27477 : scanCanonicalize (H12AffineFastState.compose env27477 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27478 : List Nat := [2,4,5,7,7,7,4,3,0,5,0,0,3,0,1,4,1,0,5,0,0,7,6,2,3,6,0,0,0,1,3,7,2,6,0,0]

theorem envBound27478 : H12AffineFastState.Bounded env27478 := by
  intro p hp
  have h : env27478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27477_27478 : H12AffineEnvironment.transform 2 5 env27477 = env27478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27477 == env27478) = true)

def env27479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,8495,1345,8623,320,9245,1,477,16,8511,9673,1280,319,1296,1297,3172,8205,8201,257,1281,1345,1856]

theorem envBound27479 : H12AffineFastState.Bounded env27479 := by
  intro p hp
  have h : env27479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27467_27479 : H12AffineEnvironment.transform 11 1 env27467 = env27479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27467 == env27479) = true)

theorem identity27479 : scanCanonicalize (H12AffineFastState.compose env27479 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound27479 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1297,325,1142,1345,1270,320,324,1,477,16,1126,144,1280,319,1296,1297,3172,1364,1360,257,1281,1345,1856]

theorem envBound27480 : H12AffineFastState.Bounded env27480 := by
  intro p hp
  have h : env27480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27479_27480 : H12AffineEnvironment.transform 12 1369 env27479 = env27480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env27479 == env27480) = true)

theorem identity27480 : scanCanonicalize (H12AffineFastState.compose env27480 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound27480 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27481 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,1,437,509,325,154,429,26,320,324,1,477,16,138,144,492,319,508,509,2184,440,444,257,493,429,940]

theorem envBound27481 : H12AffineFastState.Bounded env27481 := by
  intro p hp
  have h : env27481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27480_27481 : H12AffineEnvironment.transform 9 236 env27480 = env27481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env27480 == env27481) = true)

theorem identity27481 : scanCanonicalize (H12AffineFastState.compose env27481 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound27481 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27482 : List Nat := [2,4,8,16,32,64,128,256,97,236,2048,1,437,509,325,154,429,26,320,324,1,477,16,138,144,492,319,508,509,2184,440,444,257,493,429,461]

theorem envBound27482 : H12AffineFastState.Bounded env27482 := by
  intro p hp
  have h : env27482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27481_27482 : H12AffineEnvironment.transform 8 97 env27481 = env27482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env27481 == env27482) = true)

theorem identity27482 : scanCanonicalize (H12AffineFastState.compose env27482 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound27482 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27483 : List Nat := [2,4,8,16,32,64,128,256,97,236,80,1,437,509,325,154,429,26,320,324,1,477,16,138,144,492,319,508,509,216,440,444,257,493,429,461]

theorem envBound27483 : H12AffineFastState.Bounded env27483 := by
  intro p hp
  have h : env27483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27482_27483 : H12AffineEnvironment.transform 10 80 env27482 = env27483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env27482 == env27483) = true)

theorem identity27483 : scanCanonicalize (H12AffineFastState.compose env27483 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound27483 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env27484 : List Nat := [2,4,8,16,32,64,128,231,97,236,80,1,82,26,162,154,74,26,167,163,1,58,16,138,144,11,216,27,26,216,95,91,230,10,74,42]

theorem envBound27484 : H12AffineFastState.Bounded env27484 := by
  intro p hp
  have h : env27484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27483_27484 : H12AffineEnvironment.transform 7 231 env27483 = env27484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env27483 == env27484) = true)

theorem identity27484 : scanCanonicalize (H12AffineFastState.compose env27484 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27484 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env27485 : List Nat := [2,4,8,10,32,64,128,231,97,236,74,1,72,0,162,128,74,0,167,163,1,32,10,138,138,11,194,1,0,194,69,65,230,10,74,42]

theorem envBound27485 : H12AffineFastState.Bounded env27485 := by
  intro p hp
  have h : env27485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27484_27485 : H12AffineEnvironment.transform 3 10 env27484 = env27485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27484 == env27485) = true)

theorem identity27485 : scanCanonicalize (H12AffineFastState.compose env27485 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound27485 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27486 : List Nat := [2,4,8,10,32,64,14,105,97,98,74,1,72,0,44,14,74,0,41,45,1,32,10,4,4,11,76,1,0,76,69,65,104,10,74,42]

theorem envBound27486 : H12AffineFastState.Bounded env27486 := by
  intro p hp
  have h : env27486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27485_27486 : H12AffineEnvironment.transform 6 14 env27485 = env27486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env27485 == env27486) = true)

theorem identity27486 : scanCanonicalize (H12AffineFastState.compose env27486 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27486 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27487 : List Nat := [2,4,8,10,32,10,14,35,43,40,0,1,2,0,44,14,0,0,41,45,1,32,10,4,4,11,6,1,0,6,15,11,34,10,0,42]

theorem envBound27487 : H12AffineFastState.Bounded env27487 := by
  intro p hp
  have h : env27487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27486_27487 : H12AffineEnvironment.transform 5 10 env27486 = env27487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27486 == env27487) = true)

theorem identity27487 : scanCanonicalize (H12AffineFastState.compose env27487 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27487 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27488 : List Nat := [2,4,2,0,32,0,4,35,33,34,0,1,2,0,38,4,0,0,35,39,1,32,0,4,4,1,6,1,0,6,5,1,34,0,0,32]

theorem envBound27488 : H12AffineFastState.Bounded env27488 := by
  intro p hp
  have h : env27488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27487_27488 : H12AffineEnvironment.transform 2 2 env27487 = env27488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27487 == env27488) = true)

theorem identity27488 : scanCanonicalize (H12AffineFastState.compose env27488 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27488 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27489 : List Nat := [2,3,2,0,32,0,3,35,33,34,0,1,2,0,33,3,0,0,35,32,1,32,0,3,3,1,1,1,0,1,2,1,34,0,0,32]

theorem envBound27489 : H12AffineFastState.Bounded env27489 := by
  intro p hp
  have h : env27489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27488_27489 : H12AffineEnvironment.transform 1 3 env27488 = env27489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27488 == env27489) = true)

theorem identity27489 : scanCanonicalize (H12AffineFastState.compose env27489 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27490 : List Nat := [0,1,0,0,32,0,1,33,33,32,0,1,0,0,33,1,0,0,33,32,1,32,0,1,1,1,1,1,0,1,0,1,32,0,0,32]

theorem envBound27490 : H12AffineFastState.Bounded env27490 := by
  intro p hp
  have h : env27490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27489_27490 : H12AffineEnvironment.transform 0 0 env27489 = env27490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27489 == env27490) = true)

theorem identity27490 : scanCanonicalize (H12AffineFastState.compose env27490 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27491 : List Nat := [0,1,0,0,1,0,1,0,0,1,0,1,0,0,0,1,0,0,0,1,1,1,0,1,1,1,1,1,0,1,0,1,1,0,0,1]

theorem envBound27491 : H12AffineFastState.Bounded env27491 := by
  intro p hp
  have h : env27491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27490_27491 : H12AffineEnvironment.transform 4 1 env27490 = env27491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27490 == env27491) = true)

def env27492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4096,477,74047,69649,13768,78894,4415,74815,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound27492 : H12AffineFastState.Bounded env27492 := by
  intro p hp
  have h : env27492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27465_27492 : H12AffineEnvironment.transform 17 65665 env27465 = env27492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27465 == env27492) = true)

theorem identity27492 : scanCanonicalize (H12AffineFastState.compose env27492 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound27492 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,0,9455,4417,13340,4096,477,1361,13439,13768,4160,4415,81,1297,6436,8205,8201,257,64,1345,5953]

theorem envBound27493 : H12AffineFastState.Bounded env27493 := by
  intro p hp
  have h : env27493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27492_27493 : H12AffineEnvironment.transform 15 9326 env27492 = env27493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env27492 == env27493) = true)

def env27494 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,8494,0,8623,4417,12636,4096,477,17,12607,12424,4160,4415,81,81,6436,8205,8201,257,64,1,4609]

theorem envBound27494 : H12AffineFastState.Bounded env27494 := by
  intro p hp
  have h : env27494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27493_27494 : H12AffineEnvironment.transform 9 320 env27493 = env27494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27493 == env27494) = true)

theorem identity27494 : scanCanonicalize (H12AffineFastState.compose env27494 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound27494 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27495 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,324,8192,81,8217,8494,0,8623,5,8216,324,477,17,8315,8652,260,123,81,81,2144,8205,8201,257,64,1,837]

theorem envBound27495 : H12AffineFastState.Bounded env27495 := by
  intro p hp
  have h : env27495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27494_27495 : H12AffineEnvironment.transform 11 324 env27494 = env27495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env27494 == env27495) = true)

theorem identity27495 : scanCanonicalize (H12AffineFastState.compose env27495 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(12+1) ^^^ 829) := by decide +kernel

theorem selectedBound27495 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env27496 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,324,829,81,804,531,0,658,5,805,324,477,17,838,753,260,123,81,81,2144,816,820,257,64,1,837]

theorem envBound27496 : H12AffineFastState.Bounded env27496 := by
  intro p hp
  have h : env27496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27495_27496 : H12AffineEnvironment.transform 12 829 env27495 = env27496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 829 env27495 == env27496) = true)

theorem identity27496 : scanCanonicalize (H12AffineFastState.compose env27496 (packedSelected [1,2,3,4,9,10,13,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 999) := by decide +kernel

theorem selectedBound27496 : packedSelected [1,2,3,4,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env27497 : List Nat := [2,4,8,16,32,64,128,256,512,320,999,324,829,81,804,531,0,658,5,805,324,477,17,838,753,260,123,81,81,903,816,820,257,64,1,837]

theorem envBound27497 : H12AffineFastState.Bounded env27497 := by
  intro p hp
  have h : env27497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27496_27497 : H12AffineEnvironment.transform 10 999 env27496 = env27497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 999 env27496 == env27497) = true)

theorem identity27497 : scanCanonicalize (H12AffineFastState.compose env27497 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27497 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env27498 : List Nat := [2,4,8,16,32,64,128,173,512,237,586,233,656,81,649,531,0,658,5,648,233,112,17,747,753,169,123,81,81,554,669,665,172,64,1,744]

theorem envBound27498 : H12AffineFastState.Bounded env27498 := by
  intro p hp
  have h : env27498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27497_27498 : H12AffineEnvironment.transform 7 173 env27497 = env27498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27497 == env27498) = true)

theorem identity27498 : scanCanonicalize (H12AffineFastState.compose env27498 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound27498 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27499 : List Nat := [2,4,8,16,32,64,105,68,512,4,586,0,633,81,608,531,0,635,5,609,0,112,17,514,536,64,123,81,81,554,628,624,69,64,1,513]

theorem envBound27499 : H12AffineFastState.Bounded env27499 := by
  intro p hp
  have h : env27499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27498_27499 : H12AffineEnvironment.transform 6 105 env27498 = env27499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env27498 == env27499) = true)

theorem identity27499 : scanCanonicalize (H12AffineFastState.compose env27499 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 106) := by decide +kernel

theorem selectedBound27499 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27500 : List Nat := [2,4,8,16,32,64,105,68,106,4,32,0,19,81,10,121,0,17,5,11,0,112,17,104,114,64,123,81,81,64,30,26,69,64,1,107]

theorem envBound27500 : H12AffineFastState.Bounded env27500 := by
  intro p hp
  have h : env27500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27499_27500 : H12AffineEnvironment.transform 8 106 env27499 = env27500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 106 env27499 == env27500) = true)

theorem identity27500 : scanCanonicalize (H12AffineFastState.compose env27500 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound27500 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env27501 : List Nat := [2,4,8,16,13,64,68,68,71,4,13,0,19,81,10,84,0,17,5,11,0,93,17,69,95,64,86,81,81,64,30,26,69,64,1,70]

theorem envBound27501 : H12AffineFastState.Bounded env27501 := by
  intro p hp
  have h : env27501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27500_27501 : H12AffineEnvironment.transform 4 13 env27500 = env27501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env27500 == env27501) = true)

theorem identity27501 : scanCanonicalize (H12AffineFastState.compose env27501 (packedSelected [0,3,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27501 : packedSelected [0,3,9,10] rootPS < 2^1333 := by decide +kernel

def env27502 : List Nat := [2,4,8,16,13,17,21,21,22,4,13,0,19,0,10,5,0,17,5,11,0,12,17,20,14,17,7,0,0,17,30,26,20,17,1,23]

theorem envBound27502 : H12AffineFastState.Bounded env27502 := by
  intro p hp
  have h : env27502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27501_27502 : H12AffineEnvironment.transform 5 17 env27501 = env27502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27501 == env27502) = true)

theorem identity27502 : scanCanonicalize (H12AffineFastState.compose env27502 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27503 : List Nat := [2,4,3,16,6,17,21,21,22,4,6,0,19,0,1,5,0,17,5,0,0,7,17,20,5,17,7,0,0,17,21,17,20,17,1,23]

theorem envBound27503 : H12AffineFastState.Bounded env27503 := by
  intro p hp
  have h : env27503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27502_27503 : H12AffineEnvironment.transform 2 3 env27502 = env27503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27502 == env27503) = true)

theorem identity27503 : scanCanonicalize (H12AffineFastState.compose env27503 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27504 : List Nat := [2,2,3,16,0,17,19,19,16,2,0,0,19,0,1,3,0,17,3,0,0,1,17,18,3,17,1,0,0,17,19,17,18,17,1,17]

theorem envBound27504 : H12AffineFastState.Bounded env27504 := by
  intro p hp
  have h : env27504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27503_27504 : H12AffineEnvironment.transform 1 2 env27503 = env27504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27503 == env27504) = true)

theorem identity27504 : scanCanonicalize (H12AffineFastState.compose env27504 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27505 : List Nat := [0,0,1,16,0,17,17,17,16,0,0,0,17,0,1,1,0,17,1,0,0,1,17,16,1,17,1,0,0,17,17,17,16,17,1,17]

theorem envBound27505 : H12AffineFastState.Bounded env27505 := by
  intro p hp
  have h : env27505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27504_27505 : H12AffineEnvironment.transform 0 0 env27504 = env27505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27504 == env27505) = true)

def env27506 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,8495,0,8622,4417,12637,4096,477,16,12606,12425,4160,4415,81,80,6436,8205,8201,257,64,0,4608]

theorem envBound27506 : H12AffineFastState.Bounded env27506 := by
  intro p hp
  have h : env27506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27493_27506 : H12AffineEnvironment.transform 9 321 env27493 = env27506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27493 == env27506) = true)

theorem identity27506 : scanCanonicalize (H12AffineFastState.compose env27506 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound27506 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27507 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,4420,311,0,438,4417,4421,4096,477,16,4390,4241,4160,4415,81,80,6436,21,17,257,64,0,4608]

theorem envBound27507 : H12AffineFastState.Bounded env27507 := by
  intro p hp
  have h : env27507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27506_27507 : H12AffineEnvironment.transform 12 24 env27506 = env27507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env27506 == env27507) = true)

theorem identity27507 : scanCanonicalize (H12AffineFastState.compose env27507 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound27507 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27508 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,428,24,80,232,311,0,438,237,233,428,477,16,138,317,492,147,81,80,2184,21,17,257,64,0,940]

theorem envBound27508 : H12AffineFastState.Bounded env27508 := by
  intro p hp
  have h : env27508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27507_27508 : H12AffineEnvironment.transform 11 428 env27507 = env27508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env27507 == env27508) = true)

theorem identity27508 : scanCanonicalize (H12AffineFastState.compose env27508 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound27508 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27509 : List Nat := [2,4,8,16,32,64,128,256,460,321,2048,428,24,80,232,311,0,438,237,233,428,477,16,138,317,492,147,81,80,2184,21,17,257,64,0,96]

theorem envBound27509 : H12AffineFastState.Bounded env27509 := by
  intro p hp
  have h : env27509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27508_27509 : H12AffineEnvironment.transform 8 460 env27508 = env27509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env27508 == env27509) = true)

theorem identity27509 : scanCanonicalize (H12AffineFastState.compose env27509 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound27509 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27510 : List Nat := [2,4,8,16,32,64,128,256,460,321,508,428,24,80,232,311,0,438,237,233,428,477,16,138,317,492,147,81,80,372,21,17,257,64,0,96]

theorem envBound27510 : H12AffineFastState.Bounded env27510 := by
  intro p hp
  have h : env27510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27509_27510 : H12AffineEnvironment.transform 10 508 env27509 = env27510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env27509 == env27510) = true)

theorem identity27510 : scanCanonicalize (H12AffineFastState.compose env27510 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27510 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env27511 : List Nat := [2,4,8,16,32,64,9,256,325,321,373,293,24,80,97,311,0,319,100,96,293,340,16,3,317,357,26,81,80,372,21,17,257,64,0,96]

theorem envBound27511 : H12AffineFastState.Bounded env27511 := by
  intro p hp
  have h : env27511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27510_27511 : H12AffineEnvironment.transform 6 9 env27510 = env27511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27510 == env27511) = true)

theorem identity27511 : scanCanonicalize (H12AffineFastState.compose env27511 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27511 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env27512 : List Nat := [2,4,8,16,32,10,9,256,271,267,319,293,24,26,43,311,0,319,46,42,293,286,16,3,317,303,26,27,26,318,21,17,257,10,0,42]

theorem envBound27512 : H12AffineFastState.Bounded env27512 := by
  intro p hp
  have h : env27512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27511_27512 : H12AffineEnvironment.transform 5 10 env27511 = env27512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27511 == env27512) = true)

theorem identity27512 : scanCanonicalize (H12AffineFastState.compose env27512 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound27512 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27513 : List Nat := [2,4,8,16,32,10,9,15,0,4,48,42,24,26,43,56,0,48,46,42,42,17,16,3,50,32,26,27,26,49,21,17,14,10,0,42]

theorem envBound27513 : H12AffineFastState.Bounded env27513 := by
  intro p hp
  have h : env27513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27512_27513 : H12AffineEnvironment.transform 7 15 env27512 = env27513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env27512 == env27513) = true)

theorem identity27513 : scanCanonicalize (H12AffineFastState.compose env27513 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27513 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27514 : List Nat := [2,4,8,16,10,10,9,15,0,4,26,0,24,26,1,18,0,26,4,0,0,17,16,3,24,10,26,27,26,27,21,17,14,10,0,0]

theorem envBound27514 : H12AffineFastState.Bounded env27514 := by
  intro p hp
  have h : env27514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27513_27514 : H12AffineEnvironment.transform 4 10 env27513 = env27514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27513 == env27514) = true)

theorem identity27514 : scanCanonicalize (H12AffineFastState.compose env27514 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27514 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27515 : List Nat := [2,4,8,11,10,10,9,15,0,4,1,0,3,1,1,9,0,1,4,0,0,10,11,3,3,10,1,0,1,0,14,10,14,10,0,0]

theorem envBound27515 : H12AffineFastState.Bounded env27515 := by
  intro p hp
  have h : env27515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27514_27515 : H12AffineEnvironment.transform 3 11 env27514 = env27515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27514 == env27515) = true)

theorem identity27515 : scanCanonicalize (H12AffineFastState.compose env27515 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27516 : List Nat := [2,2,8,11,10,10,9,9,0,2,1,0,3,1,1,9,0,1,2,0,0,10,11,3,3,10,1,0,1,0,8,10,8,10,0,0]

theorem envBound27516 : H12AffineFastState.Bounded env27516 := by
  intro p hp
  have h : env27516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27515_27516 : H12AffineEnvironment.transform 1 2 env27515 = env27516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27515 == env27516) = true)

def env27517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123165,28888,78895,385202,90414,1296,96347,25884,25881,257,74798,1345,21073]

theorem envBound27517 : H12AffineFastState.Bounded env27517 := by
  intro p hp
  have h : env27517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27410_27517 : H12AffineEnvironment.transform 18 21585 env27410 = env27517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env27410 == env27517) = true)

theorem identity27517 : scanCanonicalize (H12AffineFastState.compose env27517 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound27517 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4096,5276,91182,66896,28888,78895,328959,90414,1296,96347,25884,25881,257,74798,1345,21073]

theorem envBound27518 : H12AffineFastState.Bounded env27518 := by
  intro p hp
  have h : env27518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27517_27518 : H12AffineEnvironment.transform 14 25677 env27517 = env27518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env27517 == env27518) = true)

def env27519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4096,5276,74046,66896,13768,78895,328959,74814,1296,81227,8204,8201,257,74798,1345,5953]

theorem envBound27519 : H12AffineFastState.Bounded env27519 := by
  intro p hp
  have h : env27519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27518_27519 : H12AffineEnvironment.transform 13 1296 env27518 = env27519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27518 == env27519) = true)

def env27520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4096,5276,74046,66896,13768,78895,1151,74814,1296,81227,8204,8201,257,74798,1345,5953]

theorem envBound27520 : H12AffineFastState.Bounded env27520 := by
  intro p hp
  have h : env27520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27519_27520 : H12AffineEnvironment.transform 17 65664 env27519 = env27520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27519 == env27520) = true)

theorem identity27520 : scanCanonicalize (H12AffineFastState.compose env27520 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound27520 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,358,9480,486,4417,8540,4096,5276,8280,1078,13768,13641,1151,9560,1296,15405,8204,8201,257,9544,1345,5953]

theorem envBound27521 : H12AffineFastState.Bounded env27521 := by
  intro p hp
  have h : env27521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27520_27521 : H12AffineEnvironment.transform 15 358 env27520 = env27521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env27520 == env27521) = true)

def env27522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,358,1344,486,4417,276,4096,5276,16,1078,5504,5377,1151,1296,1296,7269,68,65,257,1280,1345,5953]

theorem envBound27522 : H12AffineFastState.Bounded env27522 := by
  intro p hp
  have h : env27522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27521_27522 : H12AffineEnvironment.transform 12 72 env27521 = env27522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env27521 == env27522) = true)

theorem identity27522 : scanCanonicalize (H12AffineFastState.compose env27522 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27522 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27523 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,1,277,358,81,486,4417,276,4096,4493,16,295,4241,4112,366,1,1,6516,68,65,257,17,80,4688]

theorem envBound27523 : H12AffineFastState.Bounded env27523 := by
  intro p hp
  have h : env27523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27522_27523 : H12AffineEnvironment.transform 9 273 env27522 = env27523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27522 == env27523) = true)

theorem identity27523 : scanCanonicalize (H12AffineFastState.compose env27523 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound27523 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27524 : List Nat := [2,4,8,16,32,64,128,256,512,273,674,4096,72,1,277,358,81,486,4417,276,4096,4493,16,295,4241,4112,366,1,1,5078,68,65,257,17,80,4688]

theorem envBound27524 : H12AffineFastState.Bounded env27524 := by
  intro p hp
  have h : env27524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27523_27524 : H12AffineEnvironment.transform 10 674 env27523 = env27524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env27523 == env27524) = true)

theorem identity27524 : scanCanonicalize (H12AffineFastState.compose env27524 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(11+1) ^^^ 924) := by decide +kernel

theorem selectedBound27524 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env27525 : List Nat := [2,4,8,16,32,64,128,256,512,273,674,924,72,1,277,358,81,486,733,276,924,529,16,295,781,908,366,1,1,74,68,65,257,17,80,460]

theorem envBound27525 : H12AffineFastState.Bounded env27525 := by
  intro p hp
  have h : env27525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27524_27525 : H12AffineEnvironment.transform 11 924 env27524 = env27525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 924 env27524 == env27525) = true)

theorem identity27525 : scanCanonicalize (H12AffineFastState.compose env27525 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound27525 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env27526 : List Nat := [2,4,8,16,32,64,128,69,512,84,674,729,72,1,80,35,81,163,733,81,729,529,16,98,584,713,43,1,1,74,68,65,68,17,80,137]

theorem envBound27526 : H12AffineFastState.Bounded env27526 := by
  intro p hp
  have h : env27526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27525_27526 : H12AffineEnvironment.transform 7 69 env27525 = env27526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env27525 == env27526) = true)

def env27527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,358,1345,486,4417,277,4096,5276,17,1078,5505,5376,1151,1297,1296,7268,69,64,257,1281,1345,5953]

theorem envBound27527 : H12AffineFastState.Bounded env27527 := by
  intro p hp
  have h : env27527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27521_27527 : H12AffineEnvironment.transform 12 73 env27521 = env27527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env27521 == env27527) = true)

theorem identity27527 : scanCanonicalize (H12AffineFastState.compose env27527 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27527 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27528 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,73,277,276,358,324,486,4417,277,4096,4249,17,51,4484,4357,122,276,277,6241,69,64,257,260,324,4932]

theorem envBound27528 : H12AffineFastState.Bounded env27528 := by
  intro p hp
  have h : env27528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27527_27528 : H12AffineEnvironment.transform 9 5 env27527 = env27528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27527 == env27528) = true)

theorem identity27528 : scanCanonicalize (H12AffineFastState.compose env27528 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound27528 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27529 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,73,277,276,358,324,486,5,277,324,477,17,51,192,65,122,276,277,2341,69,64,257,260,324,512]

theorem envBound27529 : H12AffineFastState.Bounded env27529 := by
  intro p hp
  have h : env27529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27528_27529 : H12AffineEnvironment.transform 11 324 env27528 = env27529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env27528 == env27529) = true)

theorem identity27529 : scanCanonicalize (H12AffineFastState.compose env27529 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27529 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27530 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,24,277,276,311,277,439,5,277,277,396,17,51,145,16,43,276,277,2341,20,17,257,260,277,512]

theorem envBound27530 : H12AffineFastState.Bounded env27530 := by
  intro p hp
  have h : env27530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27529_27530 : H12AffineEnvironment.transform 5 17 env27529 = env27530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27529 == env27530) = true)

theorem identity27530 : scanCanonicalize (H12AffineFastState.compose env27530 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 924) := by decide +kernel

theorem selectedBound27530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27531 : List Nat := [2,4,8,16,32,17,128,256,512,5,924,277,24,277,276,311,277,439,5,277,277,396,17,51,145,16,43,276,277,697,20,17,257,260,277,512]

theorem envBound27531 : H12AffineFastState.Bounded env27531 := by
  intro p hp
  have h : env27531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27530_27531 : H12AffineEnvironment.transform 10 924 env27530 = env27531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 924 env27530 == env27531) = true)

theorem identity27531 : scanCanonicalize (H12AffineFastState.compose env27531 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound27531 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27532 : List Nat := [2,4,8,16,32,17,18,256,512,5,782,277,24,277,276,311,277,293,5,277,277,286,17,51,3,16,43,276,277,555,20,17,257,260,277,512]

theorem envBound27532 : H12AffineFastState.Bounded env27532 := by
  intro p hp
  have h : env27532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27531_27532 : H12AffineEnvironment.transform 6 18 env27531 = env27532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env27531 == env27532) = true)

theorem identity27532 : scanCanonicalize (H12AffineFastState.compose env27532 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound27532 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27533 : List Nat := [2,4,8,16,32,17,18,256,27,5,277,277,24,277,276,311,277,293,5,277,277,286,17,51,3,16,43,276,277,48,20,17,257,260,277,27]

theorem envBound27533 : H12AffineFastState.Bounded env27533 := by
  intro p hp
  have h : env27533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27532_27533 : H12AffineEnvironment.transform 8 27 env27532 = env27533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env27532 == env27533) = true)

theorem identity27533 : scanCanonicalize (H12AffineFastState.compose env27533 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27533 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27534 : List Nat := [2,4,8,16,11,17,18,256,27,5,277,277,24,277,276,284,277,270,5,277,277,286,17,24,3,16,0,276,277,27,20,17,257,260,277,27]

theorem envBound27534 : H12AffineFastState.Bounded env27534 := by
  intro p hp
  have h : env27534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27533_27534 : H12AffineEnvironment.transform 4 11 env27533 = env27534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27533 == env27534) = true)

theorem identity27534 : scanCanonicalize (H12AffineFastState.compose env27534 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27534 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27535 : List Nat := [2,4,8,16,11,17,18,21,27,5,0,0,24,0,1,9,0,27,5,0,0,11,17,24,3,16,0,1,0,27,20,17,20,17,0,27]

theorem envBound27535 : H12AffineFastState.Bounded env27535 := by
  intro p hp
  have h : env27535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27534_27535 : H12AffineEnvironment.transform 7 21 env27534 = env27535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27534 == env27535) = true)

theorem identity27535 : scanCanonicalize (H12AffineFastState.compose env27535 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound27535 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27536 : List Nat := [2,4,8,6,11,7,4,3,13,5,0,0,14,0,1,9,0,13,5,0,0,11,7,14,3,6,0,1,0,13,2,7,2,7,0,13]

theorem envBound27536 : H12AffineFastState.Bounded env27536 := by
  intro p hp
  have h : env27536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27535_27536 : H12AffineEnvironment.transform 3 6 env27535 = env27536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env27535 == env27536) = true)

theorem identity27536 : scanCanonicalize (H12AffineFastState.compose env27536 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27537 : List Nat := [2,4,5,6,6,7,4,3,0,5,0,0,3,0,1,4,0,0,5,0,0,6,7,3,3,6,0,1,0,0,2,7,2,7,0,0]

theorem envBound27537 : H12AffineFastState.Bounded env27537 := by
  intro p hp
  have h : env27537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27536_27537 : H12AffineEnvironment.transform 2 5 env27536 = env27537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27536 == env27537) = true)

def env27538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4096,5276,74046,66896,13768,78895,1150,74814,1296,81227,8204,8201,257,74798,1345,5953]

theorem envBound27538 : H12AffineFastState.Bounded env27538 := by
  intro p hp
  have h : env27538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27519_27538 : H12AffineEnvironment.transform 17 65665 env27519 = env27538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27519 == env27538) = true)

theorem identity27538 : scanCanonicalize (H12AffineFastState.compose env27538 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound27538 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5158,12360,5287,4417,8540,4096,5276,13592,4470,13768,8201,1150,12312,1296,10605,8204,8201,257,12296,1345,5953]

theorem envBound27539 : H12AffineFastState.Bounded env27539 := by
  intro p hp
  have h : env27539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27538_27539 : H12AffineEnvironment.transform 15 5158 env27538 = env27539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env27538 == env27539) = true)

def env27540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5158,1344,5287,4417,5204,4096,5276,16,4470,192,5377,1150,1296,1296,7269,5380,5377,257,1280,1345,5953]

theorem envBound27540 : H12AffineFastState.Bounded env27540 := by
  intro p hp
  have h : env27540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27539_27540 : H12AffineEnvironment.transform 12 5384 env27539 = env27540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env27539 == env27540) = true)

theorem identity27540 : scanCanonicalize (H12AffineFastState.compose env27540 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound27540 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1296,1028,1143,1344,1270,272,1029,81,1229,16,295,192,1360,1150,1296,1296,3124,1365,1360,257,1280,1345,1808]

theorem envBound27541 : H12AffineFastState.Bounded env27541 := by
  intro p hp
  have h : env27541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27540_27541 : H12AffineEnvironment.transform 11 81 env27540 = env27541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env27540 == env27541) = true)

theorem identity27541 : scanCanonicalize (H12AffineFastState.compose env27541 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound27541 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,675,81,1369,1296,1028,1143,1344,1270,272,1029,81,1229,16,295,192,1360,1150,1296,1296,1687,1365,1360,257,1280,1345,1808]

theorem envBound27542 : H12AffineFastState.Bounded env27542 := by
  intro p hp
  have h : env27542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27541_27542 : H12AffineEnvironment.transform 10 675 env27541 = env27542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env27541 == env27542) = true)

theorem identity27542 : scanCanonicalize (H12AffineFastState.compose env27542 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 733) := by decide +kernel

theorem selectedBound27542 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env27543 : List Nat := [2,4,8,16,32,64,128,256,512,733,675,81,900,973,729,682,925,555,272,728,81,528,16,295,192,909,675,973,973,74,904,909,257,989,924,461]

theorem envBound27543 : H12AffineFastState.Bounded env27543 := by
  intro p hp
  have h : env27543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27542_27543 : H12AffineEnvironment.transform 9 733 env27542 = env27543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 733 env27542 == env27543) = true)

theorem identity27543 : scanCanonicalize (H12AffineFastState.compose env27543 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound27543 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27544 : List Nat := [2,4,8,16,32,64,57,256,512,612,538,81,829,884,608,531,804,555,272,609,81,528,16,295,121,820,538,884,884,74,817,820,257,868,805,372]

theorem envBound27544 : H12AffineFastState.Bounded env27544 := by
  intro p hp
  have h : env27544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27543_27544 : H12AffineEnvironment.transform 6 57 env27543 = env27544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env27543 == env27544) = true)

theorem identity27544 : scanCanonicalize (H12AffineFastState.compose env27544 (packedSelected [2,4,5,8,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound27544 : packedSelected [2,4,5,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env27545 : List Nat := [2,4,8,16,32,64,57,256,372,272,366,81,73,0,276,359,80,351,272,277,81,356,16,295,121,64,366,0,0,74,69,64,257,16,81,372]

theorem envBound27545 : H12AffineFastState.Bounded env27545 := by
  intro p hp
  have h : env27545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27544_27545 : H12AffineEnvironment.transform 8 372 env27544 = env27545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env27544 == env27545) = true)

theorem identity27545 : scanCanonicalize (H12AffineFastState.compose env27545 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27545 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27546 : List Nat := [2,4,8,16,17,64,8,256,325,272,351,81,73,0,276,342,80,351,272,277,81,341,16,278,72,64,351,0,0,74,69,64,257,16,81,325]

theorem envBound27546 : H12AffineFastState.Bounded env27546 := by
  intro p hp
  have h : env27546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27545_27546 : H12AffineEnvironment.transform 4 17 env27545 = env27546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27545 == env27546) = true)

def env27547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5158,1345,5287,4417,5205,4096,5276,17,4470,193,5376,1150,1297,1296,7268,5381,5376,257,1281,1345,5953]

theorem envBound27547 : H12AffineFastState.Bounded env27547 := by
  intro p hp
  have h : env27547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27539_27547 : H12AffineEnvironment.transform 12 5385 env27539 = env27547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env27539 == env27547) = true)

theorem identity27547 : scanCanonicalize (H12AffineFastState.compose env27547 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27547 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27548 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4364,277,4177,4131,324,4258,4417,4176,4096,4249,17,4470,193,4357,123,276,277,6241,4352,4357,257,260,324,4932]

theorem envBound27548 : H12AffineFastState.Bounded env27548 := by
  intro p hp
  have h : env27548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27547_27548 : H12AffineEnvironment.transform 9 5 env27547 = env27548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27547 == env27548) = true)

theorem identity27548 : scanCanonicalize (H12AffineFastState.compose env27548 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound27548 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27549 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,277,277,359,324,486,5,276,324,477,17,50,193,65,123,276,277,2341,68,65,257,260,324,512]

theorem envBound27549 : H12AffineFastState.Bounded env27549 := by
  intro p hp
  have h : env27549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27548_27549 : H12AffineEnvironment.transform 11 324 env27548 = env27549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env27548 == env27549) = true)

end H12CloudChart2