import H12CloudChart2Data171

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env43066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5159,1345,5287,4417,5204,4097,5277,16,4471,192,5377,1151,1297,1296,7269,5380,5377,257,1280,1345,5953]

theorem envBound43066 : H12AffineFastState.Bounded env43066 := by
  intro p hp
  have h : env43066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43065_43066 : H12AffineEnvironment.transform 12 5384 env43065 = env43066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env43065 == env43066) = true)

theorem identity43066 : scanCanonicalize (H12AffineFastState.compose env43066 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43066 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43067 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,1,4420,4406,80,4534,4417,4421,4097,4492,16,4471,192,4112,366,0,1,6516,4117,4112,257,17,80,4688]

theorem envBound43067 : H12AffineFastState.Bounded env43067 := by
  intro p hp
  have h : env43067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43066_43067 : H12AffineEnvironment.transform 9 273 env43066 = env43067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43066 == env43067) = true)

theorem identity43067 : scanCanonicalize (H12AffineFastState.compose env43067 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound43067 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env43068 : List Nat := [2,4,8,16,32,64,128,256,461,273,2048,4096,4121,1,4420,4406,80,4534,4417,4421,4097,4492,16,4471,192,4112,366,0,1,6516,4117,4112,257,17,80,4509]

theorem envBound43068 : H12AffineFastState.Bounded env43068 := by
  intro p hp
  have h : env43068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43067_43068 : H12AffineEnvironment.transform 8 461 env43067 = env43068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env43067 == env43068) = true)

theorem identity43068 : scanCanonicalize (H12AffineFastState.compose env43068 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound43068 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env43069 : List Nat := [2,4,8,16,32,64,128,69,136,84,2048,4096,4121,1,4097,4211,80,4339,4100,4096,4097,4297,16,4146,192,4112,43,0,1,6193,4117,4112,68,17,80,4312]

theorem envBound43069 : H12AffineFastState.Bounded env43069 := by
  intro p hp
  have h : env43069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43068_43069 : H12AffineEnvironment.transform 7 69 env43068 = env43069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env43068 == env43069) = true)

theorem identity43069 : scanCanonicalize (H12AffineFastState.compose env43069 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound43069 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env43070 : List Nat := [2,4,8,16,32,64,128,69,136,84,2048,2184,2193,1,2185,2299,80,2171,2188,2184,2185,2113,16,2234,192,2200,43,0,1,185,2205,2200,68,17,80,2128]

theorem envBound43070 : H12AffineFastState.Bounded env43070 := by
  intro p hp
  have h : env43070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43069_43070 : H12AffineEnvironment.transform 11 2184 env43069 = env43070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env43069 == env43070) = true)

theorem identity43070 : scanCanonicalize (H12AffineFastState.compose env43070 (packedSelected [3,4,8,9,10,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound43070 : packedSelected [3,4,8,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env43071 : List Nat := [2,4,8,16,32,64,114,69,122,84,2048,2170,2147,1,2171,2057,80,2171,2174,2170,2171,2113,16,2120,50,2154,43,0,1,75,2159,2154,68,17,80,2128]

theorem envBound43071 : H12AffineFastState.Bounded env43071 := by
  intro p hp
  have h : env43071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43070_43071 : H12AffineEnvironment.transform 6 114 env43070 = env43071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env43070 == env43071) = true)

theorem identity43071 : scanCanonicalize (H12AffineFastState.compose env43071 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound43071 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env43072 : List Nat := [2,4,8,16,32,58,8,63,0,46,2048,2048,2073,1,2049,2057,42,2049,2052,2048,2049,2107,16,2098,50,2064,43,0,1,49,2069,2064,62,17,42,2090]

theorem envBound43072 : H12AffineFastState.Bounded env43072 := by
  intro p hp
  have h : env43072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43071_43072 : H12AffineEnvironment.transform 5 58 env43071 = env43072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env43071 == env43072) = true)

theorem identity43072 : scanCanonicalize (H12AffineFastState.compose env43072 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound43072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43073 : List Nat := [2,4,8,16,32,58,8,63,0,46,42,42,51,1,43,35,42,43,46,42,43,17,16,24,50,58,43,0,1,49,63,58,62,17,42,0]

theorem envBound43073 : H12AffineFastState.Bounded env43073 := by
  intro p hp
  have h : env43073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43072_43073 : H12AffineEnvironment.transform 10 42 env43072 = env43073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env43072 == env43073) = true)

theorem identity43073 : scanCanonicalize (H12AffineFastState.compose env43073 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43073 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43074 : List Nat := [2,4,8,16,17,11,8,14,0,31,27,27,2,1,26,18,27,26,31,27,26,17,16,24,3,11,26,0,1,0,14,11,15,17,27,0]

theorem envBound43074 : H12AffineFastState.Bounded env43074 := by
  intro p hp
  have h : env43074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43073_43074 : H12AffineEnvironment.transform 4 17 env43073 = env43074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43073 == env43074) = true)

theorem identity43074 : scanCanonicalize (H12AffineFastState.compose env43074 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43074 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43075 : List Nat := [2,4,8,11,10,11,8,14,0,4,0,0,2,1,1,9,0,1,4,0,1,10,11,3,3,11,1,0,1,0,14,11,15,10,0,0]

theorem envBound43075 : H12AffineFastState.Bounded env43075 := by
  intro p hp
  have h : env43075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43074_43075 : H12AffineEnvironment.transform 3 11 env43074 = env43075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43074 == env43075) = true)

theorem identity43075 : scanCanonicalize (H12AffineFastState.compose env43075 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43076 : List Nat := [2,2,8,11,10,11,8,8,0,2,0,0,2,1,1,9,0,1,2,0,1,10,11,3,3,11,1,0,1,0,8,11,9,10,0,0]

theorem envBound43076 : H12AffineFastState.Bounded env43076 := by
  intro p hp
  have h : env43076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43075_43076 : H12AffineEnvironment.transform 1 2 env43075 = env43076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43075 == env43076) = true)

def env43077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5159,1344,5287,4417,5205,4097,5277,17,4471,193,5376,1151,1296,1296,7268,5381,5376,257,1281,1345,5953]

theorem envBound43077 : H12AffineFastState.Bounded env43077 := by
  intro p hp
  have h : env43077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43065_43077 : H12AffineEnvironment.transform 12 5385 env43065 = env43077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env43065 == env43077) = true)

theorem identity43077 : scanCanonicalize (H12AffineFastState.compose env43077 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound43077 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1101,1296,1296,1379,1344,1507,5,1297,325,1497,17,51,193,1092,1151,1296,1296,3360,1089,1092,257,1281,1345,1541]

theorem envBound43078 : H12AffineFastState.Bounded env43078 := by
  intro p hp
  have h : env43078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43077_43078 : H12AffineEnvironment.transform 11 324 env43077 = env43078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env43077 == env43078) = true)

theorem identity43078 : scanCanonicalize (H12AffineFastState.compose env43078 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43078 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43079 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,277,277,358,325,486,5,276,325,476,17,51,193,65,122,277,277,2341,68,65,257,260,324,512]

theorem envBound43079 : H12AffineFastState.Bounded env43079 := by
  intro p hp
  have h : env43079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43078_43079 : H12AffineEnvironment.transform 9 5 env43078 = env43079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43078 == env43079) = true)

theorem identity43079 : scanCanonicalize (H12AffineFastState.compose env43079 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43079 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43080 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,25,277,277,311,276,439,5,276,276,397,17,51,144,16,43,277,277,2341,21,16,257,260,277,512]

theorem envBound43080 : H12AffineFastState.Bounded env43080 := by
  intro p hp
  have h : env43080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43079_43080 : H12AffineEnvironment.transform 5 17 env43079 = env43080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43079 == env43080) = true)

theorem identity43080 : scanCanonicalize (H12AffineFastState.compose env43080 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound43080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43081 : List Nat := [2,4,8,16,32,17,128,256,512,5,648,277,25,277,277,311,276,439,5,276,276,397,17,51,144,16,43,277,277,941,21,16,257,260,277,512]

theorem envBound43081 : H12AffineFastState.Bounded env43081 := by
  intro p hp
  have h : env43081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43080_43081 : H12AffineEnvironment.transform 10 648 env43080 = env43081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env43080 == env43081) = true)

theorem identity43081 : scanCanonicalize (H12AffineFastState.compose env43081 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound43081 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43082 : List Nat := [2,4,8,16,32,17,128,256,48,5,184,277,25,277,277,311,276,439,5,276,276,397,17,51,144,16,43,277,277,413,21,16,257,260,277,48]

theorem envBound43082 : H12AffineFastState.Bounded env43082 := by
  intro p hp
  have h : env43082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43081_43082 : H12AffineEnvironment.transform 8 48 env43081 = env43082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env43081 == env43082) = true)

theorem identity43082 : scanCanonicalize (H12AffineFastState.compose env43082 (packedSelected [0,1,3,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43082 : packedSelected [0,1,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43083 : List Nat := [2,4,8,16,32,17,128,37,48,5,184,48,25,48,48,18,49,146,5,49,49,168,17,51,144,16,43,48,48,184,21,16,36,33,48,48]

theorem envBound43083 : H12AffineFastState.Bounded env43083 := by
  intro p hp
  have h : env43083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43082_43083 : H12AffineEnvironment.transform 7 37 env43082 = env43083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43082 == env43083) = true)

theorem identity43083 : scanCanonicalize (H12AffineFastState.compose env43083 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound43083 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env43084 : List Nat := [2,4,8,16,32,17,35,37,48,5,27,48,25,48,48,18,49,49,5,49,49,11,17,51,51,16,43,48,48,27,21,16,36,33,48,48]

theorem envBound43084 : H12AffineFastState.Bounded env43084 := by
  intro p hp
  have h : env43084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43083_43084 : H12AffineEnvironment.transform 6 35 env43083 = env43084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env43083 == env43084) = true)

theorem identity43084 : scanCanonicalize (H12AffineFastState.compose env43084 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43084 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43085 : List Nat := [2,4,8,16,16,17,19,21,0,5,27,0,25,0,0,18,1,1,5,1,1,11,17,3,3,16,27,0,0,27,21,16,20,17,0,0]

theorem envBound43085 : H12AffineFastState.Bounded env43085 := by
  intro p hp
  have h : env43085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43084_43085 : H12AffineEnvironment.transform 4 16 env43084 = env43085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43084 == env43085) = true)

theorem identity43085 : scanCanonicalize (H12AffineFastState.compose env43085 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43086 : List Nat := [2,3,8,16,16,17,19,18,0,2,27,0,25,0,0,18,1,1,2,1,1,11,17,3,3,16,27,0,0,27,18,16,19,17,0,0]

theorem envBound43086 : H12AffineFastState.Bounded env43086 := by
  intro p hp
  have h : env43086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43085_43086 : H12AffineEnvironment.transform 1 3 env43085 = env43086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43085 == env43086) = true)

theorem identity43086 : scanCanonicalize (H12AffineFastState.compose env43086 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43086 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43087 : List Nat := [2,3,8,10,10,11,9,8,0,2,1,0,3,0,0,8,1,1,2,1,1,11,11,3,3,10,1,0,0,1,8,10,9,11,0,0]

theorem envBound43087 : H12AffineFastState.Bounded env43087 := by
  intro p hp
  have h : env43087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43086_43087 : H12AffineEnvironment.transform 3 10 env43086 = env43087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43086 == env43087) = true)

def env43088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4097,5277,74047,66896,13768,78894,1150,74814,1296,81226,8204,8201,257,74799,1345,5953]

theorem envBound43088 : H12AffineFastState.Bounded env43088 := by
  intro p hp
  have h : env43088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43063_43088 : H12AffineEnvironment.transform 17 65665 env43063 = env43088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43063 == env43088) = true)

theorem identity43088 : scanCanonicalize (H12AffineFastState.compose env43088 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound43088 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,359,9481,486,4417,8540,4097,5277,8280,1079,13768,13641,1150,9561,1296,15405,8204,8201,257,9544,1345,5953]

theorem envBound43089 : H12AffineFastState.Bounded env43089 := by
  intro p hp
  have h : env43089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43088_43089 : H12AffineEnvironment.transform 15 359 env43088 = env43089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env43088 == env43089) = true)

def env43090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,359,1345,486,4417,276,4097,5277,16,1079,5504,5377,1150,1297,1296,7269,68,65,257,1280,1345,5953]

theorem envBound43090 : H12AffineFastState.Bounded env43090 := by
  intro p hp
  have h : env43090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43089_43090 : H12AffineEnvironment.transform 12 72 env43089 = env43090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env43089 == env43090) = true)

theorem identity43090 : scanCanonicalize (H12AffineFastState.compose env43090 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound43090 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1296,277,359,1345,486,272,276,80,1228,16,1079,1489,1360,1150,1297,1296,3124,68,65,257,1280,1345,1808]

theorem envBound43091 : H12AffineFastState.Bounded env43091 := by
  intro p hp
  have h : env43091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43090_43091 : H12AffineEnvironment.transform 11 81 env43090 = env43091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env43090 == env43091) = true)

theorem identity43091 : scanCanonicalize (H12AffineFastState.compose env43091 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 732) := by decide +kernel

theorem selectedBound43091 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env43092 : List Nat := [2,4,8,16,32,64,128,256,512,732,2048,81,72,972,277,359,925,486,272,276,80,528,16,747,781,908,674,973,972,2792,68,65,257,988,925,460]

theorem envBound43092 : H12AffineFastState.Bounded env43092 := by
  intro p hp
  have h : env43092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43091_43092 : H12AffineEnvironment.transform 9 732 env43091 = env43092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 732 env43091 == env43092) = true)

theorem identity43092 : scanCanonicalize (H12AffineFastState.compose env43092 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound43092 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env43093 : List Nat := [2,4,8,16,32,64,128,256,136,84,2048,81,72,324,277,359,277,486,272,276,80,152,16,99,389,260,42,325,324,2144,68,65,257,340,277,460]

theorem envBound43093 : H12AffineFastState.Bounded env43093 := by
  intro p hp
  have h : env43093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43092_43093 : H12AffineEnvironment.transform 8 136 env43092 = env43093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env43092 == env43093) = true)

theorem identity43093 : scanCanonicalize (H12AffineFastState.compose env43093 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound43093 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env43094 : List Nat := [2,4,8,16,32,64,115,256,123,84,2048,81,72,324,277,359,277,277,272,276,80,107,16,99,374,260,42,325,324,2144,68,65,257,340,277,319]

theorem envBound43094 : H12AffineFastState.Bounded env43094 := by
  intro p hp
  have h : env43094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43093_43094 : H12AffineEnvironment.transform 6 115 env43093 = env43094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env43093 == env43094) = true)

theorem identity43094 : scanCanonicalize (H12AffineFastState.compose env43094 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound43094 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43095 : List Nat := [2,4,8,16,32,64,115,20,123,84,2048,81,72,80,1,115,1,1,4,0,80,107,16,99,98,16,42,81,80,2144,68,65,21,64,1,43]

theorem envBound43095 : H12AffineFastState.Bounded env43095 := by
  intro p hp
  have h : env43095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43094_43095 : H12AffineEnvironment.transform 7 20 env43094 = env43095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env43094 == env43095) = true)

theorem identity43095 : scanCanonicalize (H12AffineFastState.compose env43095 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound43095 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43096 : List Nat := [2,4,8,16,32,22,37,20,45,2,2048,7,30,6,1,37,1,1,4,0,6,61,16,53,52,16,42,7,6,2102,18,23,21,22,1,43]

theorem envBound43096 : H12AffineFastState.Bounded env43096 := by
  intro p hp
  have h : env43096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43095_43096 : H12AffineEnvironment.transform 5 22 env43095 = env43096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env43095 == env43096) = true)

theorem identity43096 : scanCanonicalize (H12AffineFastState.compose env43096 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43096 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43097 : List Nat := [2,4,8,16,32,22,37,20,45,2,0,7,30,6,1,37,1,1,4,0,6,61,16,53,52,16,42,7,6,54,18,23,21,22,1,43]

theorem envBound43097 : H12AffineFastState.Bounded env43097 := by
  intro p hp
  have h : env43097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43096_43097 : H12AffineEnvironment.transform 10 0 env43096 = env43097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43096 == env43097) = true)

theorem identity43097 : scanCanonicalize (H12AffineFastState.compose env43097 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound43097 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env43098 : List Nat := [2,4,8,16,23,22,18,20,26,2,0,7,30,6,1,18,1,1,4,0,6,10,16,2,3,16,29,7,6,1,18,23,21,22,1,28]

theorem envBound43098 : H12AffineFastState.Bounded env43098 := by
  intro p hp
  have h : env43098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43097_43098 : H12AffineEnvironment.transform 4 23 env43097 = env43098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env43097 == env43098) = true)

theorem identity43098 : scanCanonicalize (H12AffineFastState.compose env43098 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound43098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43099 : List Nat := [2,4,8,12,11,10,14,8,6,2,0,7,2,6,1,14,1,1,4,0,6,10,12,2,3,12,1,7,6,1,14,11,9,10,1,0]

theorem envBound43099 : H12AffineFastState.Bounded env43099 := by
  intro p hp
  have h : env43099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43098_43099 : H12AffineEnvironment.transform 3 12 env43098 = env43099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43098 == env43099) = true)

def env43100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,359,1344,486,4417,277,4097,5277,17,1079,5505,5376,1150,1296,1296,7268,69,64,257,1281,1345,5953]

theorem envBound43100 : H12AffineFastState.Bounded env43100 := by
  intro p hp
  have h : env43100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43089_43100 : H12AffineEnvironment.transform 12 73 env43089 = env43100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env43089 == env43100) = true)

theorem identity43100 : scanCanonicalize (H12AffineFastState.compose env43100 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound43100 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,73,1296,276,359,1344,486,5,277,325,1497,17,1079,1221,1092,1150,1296,1296,3360,69,64,257,1281,1345,1541]

theorem envBound43101 : H12AffineFastState.Bounded env43101 := by
  intro p hp
  have h : env43101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43100_43101 : H12AffineEnvironment.transform 11 324 env43100 = env43101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env43100 == env43101) = true)

theorem identity43101 : scanCanonicalize (H12AffineFastState.compose env43101 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43101 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43102 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,73,277,276,359,325,486,5,277,325,476,17,50,192,65,123,277,277,2341,69,64,257,260,324,512]

theorem envBound43102 : H12AffineFastState.Bounded env43102 := by
  intro p hp
  have h : env43102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43101_43102 : H12AffineEnvironment.transform 9 5 env43101 = env43102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43101 == env43102) = true)

theorem identity43102 : scanCanonicalize (H12AffineFastState.compose env43102 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43102 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43103 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,24,277,276,310,276,439,5,277,276,397,17,50,145,16,42,277,277,2341,20,17,257,260,277,512]

theorem envBound43103 : H12AffineFastState.Bounded env43103 := by
  intro p hp
  have h : env43103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43102_43103 : H12AffineEnvironment.transform 5 17 env43102 = env43103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43102 == env43103) = true)

theorem identity43103 : scanCanonicalize (H12AffineFastState.compose env43103 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound43103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43104 : List Nat := [2,4,8,16,32,17,128,256,512,5,649,277,24,277,276,310,276,439,5,277,276,397,17,50,145,16,42,277,277,940,20,17,257,260,277,512]

theorem envBound43104 : H12AffineFastState.Bounded env43104 := by
  intro p hp
  have h : env43104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43103_43104 : H12AffineEnvironment.transform 10 649 env43103 = env43104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env43103 == env43104) = true)

theorem identity43104 : scanCanonicalize (H12AffineFastState.compose env43104 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound43104 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43105 : List Nat := [2,4,8,16,32,17,128,256,137,5,0,277,24,277,276,310,276,439,5,277,276,397,17,50,145,16,42,277,277,293,20,17,257,260,277,137]

theorem envBound43105 : H12AffineFastState.Bounded env43105 := by
  intro p hp
  have h : env43105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43104_43105 : H12AffineEnvironment.transform 8 137 env43104 = env43105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env43104 == env43105) = true)

theorem identity43105 : scanCanonicalize (H12AffineFastState.compose env43105 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound43105 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43106 : List Nat := [2,4,8,16,32,17,128,21,137,5,0,0,24,0,1,35,1,162,5,0,1,152,17,50,145,16,42,0,0,48,20,17,20,17,0,137]

theorem envBound43106 : H12AffineFastState.Bounded env43106 := by
  intro p hp
  have h : env43106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43105_43106 : H12AffineEnvironment.transform 7 21 env43105 = env43106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env43105 == env43106) = true)

theorem identity43106 : scanCanonicalize (H12AffineFastState.compose env43106 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound43106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43107 : List Nat := [2,4,8,16,32,17,5,21,12,5,0,0,24,0,1,35,1,39,5,0,1,29,17,50,20,16,42,0,0,48,20,17,20,17,0,12]

theorem envBound43107 : H12AffineFastState.Bounded env43107 := by
  intro p hp
  have h : env43107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43106_43107 : H12AffineEnvironment.transform 6 5 env43106 = env43107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env43106 == env43107) = true)

theorem identity43107 : scanCanonicalize (H12AffineFastState.compose env43107 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43107 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43108 : List Nat := [2,4,8,16,17,17,5,21,12,5,0,0,24,0,1,18,1,22,5,0,1,29,17,3,20,16,27,0,0,1,20,17,20,17,0,12]

theorem envBound43108 : H12AffineFastState.Bounded env43108 := by
  intro p hp
  have h : env43108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43107_43108 : H12AffineEnvironment.transform 4 17 env43107 = env43108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43107 == env43108) = true)

theorem identity43108 : scanCanonicalize (H12AffineFastState.compose env43108 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43108 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43109 : List Nat := [2,4,8,11,10,10,5,14,12,5,0,0,3,0,1,9,1,13,5,0,1,6,10,3,15,11,0,0,0,1,15,10,15,10,0,12]

theorem envBound43109 : H12AffineFastState.Bounded env43109 := by
  intro p hp
  have h : env43109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43108_43109 : H12AffineEnvironment.transform 3 11 env43108 = env43109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43108 == env43109) = true)

theorem identity43109 : scanCanonicalize (H12AffineFastState.compose env43109 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43109 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43110 : List Nat := [2,4,5,6,7,7,5,3,1,5,0,0,3,0,1,4,1,0,5,0,1,6,7,3,2,6,0,0,0,1,2,7,2,7,0,1]

theorem envBound43110 : H12AffineFastState.Bounded env43110 := by
  intro p hp
  have h : env43110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43109_43110 : H12AffineEnvironment.transform 2 5 env43109 = env43110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43109 == env43110) = true)

def env43111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4097,5277,74046,66896,13769,78894,328959,74815,1296,81227,8205,8200,257,74799,1345,5952]

theorem envBound43111 : H12AffineFastState.Bounded env43111 := by
  intro p hp
  have h : env43111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43062_43111 : H12AffineEnvironment.transform 13 1297 env43062 = env43111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env43062 == env43111) = true)

def env43112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4097,5277,74046,66896,13769,78894,1151,74815,1296,81227,8205,8200,257,74799,1345,5952]

theorem envBound43112 : H12AffineFastState.Bounded env43112 := by
  intro p hp
  have h : env43112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43111_43112 : H12AffineEnvironment.transform 17 65664 env43111 = env43112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43111 == env43112) = true)

theorem identity43112 : scanCanonicalize (H12AffineFastState.compose env43112 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound43112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9327,1,9455,4416,8541,4097,5277,1361,8511,13769,4161,1151,80,1296,6436,8205,8200,257,64,1345,5952]

theorem envBound43113 : H12AffineFastState.Bounded env43113 := by
  intro p hp
  have h : env43113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43112_43113 : H12AffineEnvironment.transform 15 9327 env43112 = env43113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env43112 == env43113) = true)

def env43114 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8495,1,8623,4416,8541,4097,4573,17,8511,12425,4161,319,80,80,6436,8205,8200,257,64,1,4608]

theorem envBound43114 : H12AffineFastState.Bounded env43114 := by
  intro p hp
  have h : env43114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43113_43114 : H12AffineEnvironment.transform 9 320 env43113 = env43114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43113 == env43114) = true)

theorem identity43114 : scanCanonicalize (H12AffineFastState.compose env43114 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound43114 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43115 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,81,325,310,1,438,4416,324,4097,4573,17,294,4240,4161,319,80,80,6436,20,17,257,64,1,4608]

theorem envBound43115 : H12AffineFastState.Bounded env43115 := by
  intro p hp
  have h : env43115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43114_43115 : H12AffineEnvironment.transform 12 25 env43114 = env43115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43114 == env43115) = true)

theorem identity43115 : scanCanonicalize (H12AffineFastState.compose env43115 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound43115 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env43116 : List Nat := [2,4,8,16,32,64,128,256,512,320,951,4096,25,81,325,310,1,438,4416,324,4097,4573,17,294,4240,4161,319,80,80,4755,20,17,257,64,1,4608]

theorem envBound43116 : H12AffineFastState.Bounded env43116 := by
  intro p hp
  have h : env43116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43115_43116 : H12AffineEnvironment.transform 10 951 env43115 = env43116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env43115 == env43116) = true)

theorem identity43116 : scanCanonicalize (H12AffineFastState.compose env43116 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43116 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env43117 : List Nat := [2,4,8,16,32,64,128,172,512,236,539,4096,25,81,233,154,1,26,4332,232,4097,4209,17,138,4240,4161,147,80,80,4755,20,17,173,64,1,4608]

theorem envBound43117 : H12AffineFastState.Bounded env43117 := by
  intro p hp
  have h : env43117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43116_43117 : H12AffineEnvironment.transform 7 172 env43116 = env43117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43116 == env43117) = true)

theorem identity43117 : scanCanonicalize (H12AffineFastState.compose env43117 (packedSelected [0,1,2,3,4,7,9,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43117 : packedSelected [0,1,2,3,4,7,9,13,15] rootPS < 2^1333 := by decide +kernel

def env43118 : List Nat := [2,4,8,16,32,17,128,172,512,189,539,4096,25,0,184,154,1,26,4285,185,4097,4128,17,138,4240,4112,147,1,1,4755,20,17,173,17,1,4608]

theorem envBound43118 : H12AffineFastState.Bounded env43118 := by
  intro p hp
  have h : env43118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43117_43118 : H12AffineEnvironment.transform 5 17 env43117 = env43118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43117 == env43118) = true)

theorem identity43118 : scanCanonicalize (H12AffineFastState.compose env43118 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 158) := by decide +kernel

theorem selectedBound43118 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43119 : List Nat := [2,4,8,16,32,17,128,172,512,189,539,158,25,0,184,154,1,26,35,185,159,190,17,138,14,142,147,1,1,525,20,17,173,17,1,670]

theorem envBound43119 : H12AffineFastState.Bounded env43119 := by
  intro p hp
  have h : env43119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43118_43119 : H12AffineEnvironment.transform 11 158 env43118 = env43119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 158 env43118 == env43119) = true)

theorem identity43119 : scanCanonicalize (H12AffineFastState.compose env43119 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound43119 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env43120 : List Nat := [2,4,8,16,32,17,128,172,137,189,146,158,25,0,184,154,1,26,35,185,159,190,17,138,14,142,147,1,1,132,20,17,173,17,1,23]

theorem envBound43120 : H12AffineFastState.Bounded env43120 := by
  intro p hp
  have h : env43120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43119_43120 : H12AffineEnvironment.transform 8 137 env43119 = env43120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env43119 == env43120) = true)

theorem identity43120 : scanCanonicalize (H12AffineFastState.compose env43120 (packedSelected [1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound43120 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env43121 : List Nat := [2,4,8,16,32,17,56,20,49,5,42,38,25,0,0,34,1,26,35,1,39,6,17,50,14,54,43,1,1,60,20,17,21,17,1,23]

theorem envBound43121 : H12AffineFastState.Bounded env43121 := by
  intro p hp
  have h : env43121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43120_43121 : H12AffineEnvironment.transform 6 56 env43120 = env43121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env43120 == env43121) = true)

theorem identity43121 : scanCanonicalize (H12AffineFastState.compose env43121 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43121 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env43122 : List Nat := [2,4,8,16,10,17,18,20,27,5,0,12,25,0,0,8,1,26,9,1,13,6,17,24,14,28,1,1,1,22,20,17,21,17,1,23]

theorem envBound43122 : H12AffineFastState.Bounded env43122 := by
  intro p hp
  have h : env43122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43121_43122 : H12AffineEnvironment.transform 4 10 env43121 = env43122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43121 == env43122) = true)

theorem identity43122 : scanCanonicalize (H12AffineFastState.compose env43122 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43122 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43123 : List Nat := [2,4,8,11,10,10,9,15,0,5,0,12,2,0,0,8,1,1,9,1,13,6,10,3,14,7,1,1,1,13,15,10,14,10,1,12]

theorem envBound43123 : H12AffineFastState.Bounded env43123 := by
  intro p hp
  have h : env43123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43122_43123 : H12AffineEnvironment.transform 3 11 env43122 = env43123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43122 == env43123) = true)

def env43124 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8494,1,8622,4416,8541,4097,4572,16,8511,12424,4161,318,80,81,6436,8205,8200,257,64,0,4609]

theorem envBound43124 : H12AffineFastState.Bounded env43124 := by
  intro p hp
  have h : env43124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43113_43124 : H12AffineEnvironment.transform 9 321 env43113 = env43124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43113 == env43124) = true)

theorem identity43124 : scanCanonicalize (H12AffineFastState.compose env43124 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43124 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43125 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,8192,80,8216,8298,1,8426,4100,8217,4097,4248,16,8315,12424,4161,122,80,81,6240,8205,8200,69,64,0,4609]

theorem envBound43125 : H12AffineFastState.Bounded env43125 := by
  intro p hp
  have h : env43125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43124_43125 : H12AffineEnvironment.transform 7 68 env43124 = env43125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43124 == env43125) = true)

theorem identity43125 : scanCanonicalize (H12AffineFastState.compose env43125 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43125 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43126 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,80,8216,8298,1,8426,5,8217,0,153,16,8315,8329,64,122,80,81,2145,8205,8200,69,64,0,512]

theorem envBound43126 : H12AffineFastState.Bounded env43126 := by
  intro p hp
  have h : env43126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43125_43126 : H12AffineEnvironment.transform 11 1 env43125 = env43126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43125 == env43126) = true)

def env43127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4097,5277,74046,66896,13769,78894,1150,74815,1296,81227,8205,8200,257,74799,1345,5952]

theorem envBound43127 : H12AffineFastState.Bounded env43127 := by
  intro p hp
  have h : env43127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43111_43127 : H12AffineEnvironment.transform 17 65665 env43111 = env43127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43111 == env43127) = true)

theorem identity43127 : scanCanonicalize (H12AffineFastState.compose env43127 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound43127 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12590,5440,12719,4416,8541,4097,5277,4112,13438,13769,1280,1150,5393,1296,3173,8205,8200,257,5377,1345,5952]

theorem envBound43128 : H12AffineFastState.Bounded env43128 := by
  intro p hp
  have h : env43128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43127_43128 : H12AffineEnvironment.transform 15 12590 env43127 = env43128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env43127 == env43128) = true)

def env43129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8494,1344,8623,320,8541,1,1181,16,9342,9673,1280,1150,1297,1296,3173,8205,8200,257,1281,1345,1856]

theorem envBound43129 : H12AffineFastState.Bounded env43129 := by
  intro p hp
  have h : env43129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43128_43129 : H12AffineEnvironment.transform 11 0 env43128 = env43129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43128 == env43129) = true)

theorem identity43129 : scanCanonicalize (H12AffineFastState.compose env43129 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43129 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43130 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,276,8540,8494,325,8623,320,8541,1,152,16,8315,8652,261,123,276,277,2144,8205,8200,257,260,324,837]

theorem envBound43130 : H12AffineFastState.Bounded env43130 := by
  intro p hp
  have h : env43130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43129_43130 : H12AffineEnvironment.transform 9 5 env43129 = env43130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43129 == env43130) = true)

theorem identity43130 : scanCanonicalize (H12AffineFastState.compose env43130 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound43130 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43131 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8217,8299,0,8426,5,8216,1,152,16,8315,8329,64,123,81,80,2144,8205,8200,68,65,1,512]

theorem envBound43131 : H12AffineFastState.Bounded env43131 := by
  intro p hp
  have h : env43131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43130_43131 : H12AffineEnvironment.transform 7 69 env43130 = env43131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env43130 == env43131) = true)

theorem identity43131 : scanCanonicalize (H12AffineFastState.compose env43131 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound43131 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43132 : List Nat := [2,4,8,16,32,64,128,69,512,5,147,0,8192,81,8217,8299,0,8426,5,8216,1,152,16,8315,8329,64,123,81,80,243,8205,8200,68,65,1,512]

theorem envBound43132 : H12AffineFastState.Bounded env43132 := by
  intro p hp
  have h : env43132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43131_43132 : H12AffineEnvironment.transform 10 147 env43131 = env43132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env43131 == env43132) = true)

theorem identity43132 : scanCanonicalize (H12AffineFastState.compose env43132 (packedSelected [0,2,4,5,7,8,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound43132 : packedSelected [0,2,4,5,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env43133 : List Nat := [2,4,8,16,32,64,128,69,217,5,147,0,8192,81,8217,8299,0,8426,5,8216,1,152,16,8315,8329,64,123,81,80,243,8205,8200,68,65,1,217]

theorem envBound43133 : H12AffineFastState.Bounded env43133 := by
  intro p hp
  have h : env43133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43132_43133 : H12AffineEnvironment.transform 8 217 env43132 = env43133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env43132 == env43133) = true)

theorem identity43133 : scanCanonicalize (H12AffineFastState.compose env43133 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound43133 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env43134 : List Nat := [2,4,8,16,32,64,128,69,217,5,147,0,160,81,185,203,0,74,5,184,1,152,16,219,41,64,123,81,80,243,173,168,68,65,1,217]

theorem envBound43134 : H12AffineFastState.Bounded env43134 := by
  intro p hp
  have h : env43134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43133_43134 : H12AffineEnvironment.transform 12 160 env43133 = env43134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env43133 == env43134) = true)

theorem identity43134 : scanCanonicalize (H12AffineFastState.compose env43134 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43134 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43135 : List Nat := [2,4,8,16,32,64,19,69,74,5,0,0,51,81,42,88,0,74,5,43,1,11,16,72,41,64,123,81,80,96,62,59,68,65,1,74]

theorem envBound43135 : H12AffineFastState.Bounded env43135 := by
  intro p hp
  have h : env43135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43134_43135 : H12AffineEnvironment.transform 6 19 env43134 = env43135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43134 == env43135) = true)

theorem identity43135 : scanCanonicalize (H12AffineFastState.compose env43135 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43135 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env43136 : List Nat := [2,4,8,10,32,64,9,69,74,5,0,0,41,75,42,66,0,74,5,43,1,11,10,72,41,64,97,75,74,96,36,33,68,65,1,74]

theorem envBound43136 : H12AffineFastState.Bounded env43136 := by
  intro p hp
  have h : env43136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43135_43136 : H12AffineEnvironment.transform 3 10 env43135 = env43136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43135 == env43136) = true)

theorem identity43136 : scanCanonicalize (H12AffineFastState.compose env43136 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43136 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43137 : List Nat := [2,4,8,10,10,64,9,69,74,5,0,0,3,75,0,66,0,74,5,1,1,11,10,72,3,64,75,75,74,74,14,11,68,65,1,74]

theorem envBound43137 : H12AffineFastState.Bounded env43137 := by
  intro p hp
  have h : env43137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43136_43137 : H12AffineEnvironment.transform 4 10 env43136 = env43137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43136 == env43137) = true)

theorem identity43137 : scanCanonicalize (H12AffineFastState.compose env43137 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound43137 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env43138 : List Nat := [2,4,8,10,10,11,9,14,1,5,0,0,3,0,0,9,0,1,5,1,1,11,10,3,3,11,0,0,1,1,14,11,15,10,1,1]

theorem envBound43138 : H12AffineFastState.Bounded env43138 := by
  intro p hp
  have h : env43138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43137_43138 : H12AffineEnvironment.transform 5 11 env43137 = env43138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env43137 == env43138) = true)

theorem identity43138 : scanCanonicalize (H12AffineFastState.compose env43138 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43138 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43139 : List Nat := [2,3,8,10,10,11,9,9,1,2,0,0,3,0,0,9,0,1,2,1,1,11,10,3,3,11,0,0,1,1,9,11,8,10,1,1]

theorem envBound43139 : H12AffineFastState.Bounded env43139 := by
  intro p hp
  have h : env43139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43138_43139 : H12AffineEnvironment.transform 1 3 env43138 = env43139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43138 == env43139) = true)

def env43140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8495,1345,8622,321,8541,0,1180,17,9343,9672,1280,1150,1296,1296,3173,8205,8200,257,1280,1345,1857]

theorem envBound43140 : H12AffineFastState.Bounded env43140 := by
  intro p hp
  have h : env43140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43128_43140 : H12AffineEnvironment.transform 11 1 env43128 = env43140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43128 == env43140) = true)

theorem identity43140 : scanCanonicalize (H12AffineFastState.compose env43140 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound43140 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1297,1029,1142,1345,1271,321,1028,0,1180,17,294,145,1280,1150,1296,1296,3173,1364,1361,257,1280,1345,1857]

theorem envBound43141 : H12AffineFastState.Bounded env43141 := by
  intro p hp
  have h : env43141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43140_43141 : H12AffineEnvironment.transform 12 1369 env43140 = env43141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env43140 == env43141) = true)

theorem identity43141 : scanCanonicalize (H12AffineFastState.compose env43141 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound43141 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env43142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1,1369,1297,1029,1142,1345,1271,321,1028,0,1180,17,294,145,1280,1150,1296,1296,659,1364,1361,257,1280,1345,1857]

theorem envBound43142 : H12AffineFastState.Bounded env43142 := by
  intro p hp
  have h : env43142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43141_43142 : H12AffineEnvironment.transform 10 1782 env43141 = env43142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env43141 == env43142) = true)

theorem identity43142 : scanCanonicalize (H12AffineFastState.compose env43142 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound43142 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env43143 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1782,1,1268,1212,1029,1142,1260,1271,236,1028,0,1180,17,139,145,1197,1150,1213,1213,659,1273,1276,172,1197,1260,1772]

theorem envBound43143 : H12AffineFastState.Bounded env43143 := by
  intro p hp
  have h : env43143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43142_43143 : H12AffineEnvironment.transform 7 173 env43142 = env43143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43142 == env43143) = true)

theorem identity43143 : scanCanonicalize (H12AffineFastState.compose env43143 (packedSelected [0,1,2,3,4,7,9,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound43143 : packedSelected [0,1,2,3,4,7,9,15,17] rootPS < 2^1333 := by decide +kernel

def env43144 : List Nat := [2,4,8,16,32,64,57,20,512,1024,1615,1,1101,1029,1029,1142,1109,1102,85,1028,0,1061,17,50,40,1044,1150,1028,1028,554,1088,1093,21,1044,1109,1621]

theorem envBound43144 : H12AffineFastState.Bounded env43144 := by
  intro p hp
  have h : env43144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43143_43144 : H12AffineEnvironment.transform 6 57 env43143 = env43144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env43143 == env43144) = true)

theorem identity43144 : scanCanonicalize (H12AffineFastState.compose env43144 (packedSelected [1,2,3,4,5,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43144 : packedSelected [1,2,3,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43145 : List Nat := [2,4,8,16,32,64,57,20,512,4,587,1,73,1,1,114,81,74,85,0,0,33,17,50,40,16,122,0,0,554,68,65,21,16,81,593]

theorem envBound43145 : H12AffineFastState.Bounded env43145 := by
  intro p hp
  have h : env43145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43144_43145 : H12AffineEnvironment.transform 9 4 env43144 = env43145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43144 == env43145) = true)

theorem identity43145 : scanCanonicalize (H12AffineFastState.compose env43145 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43145 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env43146 : List Nat := [2,4,8,16,16,64,9,20,512,4,587,1,73,1,1,66,81,74,85,0,0,17,17,2,24,16,74,0,0,538,68,65,21,16,81,593]

theorem envBound43146 : H12AffineFastState.Bounded env43146 := by
  intro p hp
  have h : env43146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43145_43146 : H12AffineEnvironment.transform 4 16 env43145 = env43146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43145 == env43146) = true)

theorem identity43146 : scanCanonicalize (H12AffineFastState.compose env43146 (packedSelected [0,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound43146 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env43147 : List Nat := [2,4,8,16,16,64,9,20,13,4,70,1,73,1,1,66,81,74,85,0,0,17,17,2,24,16,74,0,0,23,68,65,21,16,81,92]

theorem envBound43147 : H12AffineFastState.Bounded env43147 := by
  intro p hp
  have h : env43147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43146_43147 : H12AffineEnvironment.transform 8 13 env43146 = env43147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env43146 == env43147) = true)

theorem identity43147 : scanCanonicalize (H12AffineFastState.compose env43147 (packedSelected [1,10] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound43147 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env43148 : List Nat := [2,4,8,16,16,7,9,20,13,4,1,1,14,1,1,5,22,13,18,0,0,17,17,2,24,16,13,0,0,23,3,6,21,16,22,27]

theorem envBound43148 : H12AffineFastState.Bounded env43148 := by
  intro p hp
  have h : env43148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43147_43148 : H12AffineEnvironment.transform 5 7 env43147 = env43148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env43147 == env43148) = true)

theorem identity43148 : scanCanonicalize (H12AffineFastState.compose env43148 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43149 : List Nat := [2,4,8,10,10,7,9,14,13,4,1,1,14,1,1,5,12,13,8,0,0,11,11,2,2,10,13,0,0,13,3,6,15,10,12,1]

theorem envBound43149 : H12AffineFastState.Bounded env43149 := by
  intro p hp
  have h : env43149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43148_43149 : H12AffineEnvironment.transform 3 10 env43148 = env43149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43148 == env43149) = true)

theorem identity43149 : scanCanonicalize (H12AffineFastState.compose env43149 (packedSelected [1,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43149 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env43150 : List Nat := [2,4,4,6,6,7,5,2,1,4,1,1,2,1,1,5,0,1,4,0,0,7,7,2,2,6,1,0,0,1,3,6,3,6,0,1]

theorem envBound43150 : H12AffineFastState.Bounded env43150 := by
  intro p hp
  have h : env43150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43149_43150 : H12AffineEnvironment.transform 2 4 env43149 = env43150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43149 == env43150) = true)

def env43151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound43151 : H12AffineFastState.Bounded env43151 := by
  intro p hp
  have h : env43151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40820_43151 : H12AffineEnvironment.transform 34 151462017 env40820 = env43151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env40820 == env43151) = true)

def env43152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148800,33584584,96347,50962568,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound43152 : H12AffineFastState.Bounded env43152 := by
  intro p hp
  have h : env43152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43151_43152 : H12AffineEnvironment.transform 20 4096 env43151 = env43152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env43151 == env43152) = true)

theorem identity43152 : scanCanonicalize (H12AffineFastState.compose env43152 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 51021027) := by decide +kernel

theorem selectedBound43152 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env43153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148800,33584584,96347,50962568,51021027,34088328,676881,151462017,33563273]

theorem envBound43153 : H12AffineFastState.Bounded env43153 := by
  intro p hp
  have h : env43153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43152_43153 : H12AffineEnvironment.transform 31 51021027 env43152 = env43153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 51021027 env43152 == env43153) = true)

def env43154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,134217728,148800,545088,96347,16876544,16949355,256,676881,151462017,525825]

theorem envBound43154 : H12AffineFastState.Bounded env43154 := by
  intro p hp
  have h : env43154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43153_43154 : H12AffineEnvironment.transform 24 533640 env43153 = env43154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env43153 == env43154) = true)

def env43155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245632,148800,545088,96347,16876544,16949355,256,676881,1345,525825]

theorem envBound43155 : H12AffineFastState.Bounded env43155 := by
  intro p hp
  have h : env43155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43154_43155 : H12AffineEnvironment.transform 26 17245632 env43154 = env43155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env43154 == env43155) = true)

theorem identity43155 : scanCanonicalize (H12AffineFastState.compose env43155 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound43155 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41002,533640,672785,493034,148800,545088,96347,74794,131137,256,676881,1345,525825]

theorem envBound43156 : H12AffineFastState.Bounded env43156 := by
  intro p hp
  have h : env43156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43155_43156 : H12AffineEnvironment.transform 23 41002 env43155 = env43156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env43155 == env43156) = true)

def env43157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,493034,148800,148800,96347,74794,131137,256,16401,1345,135681]

theorem envBound43157 : H12AffineFastState.Bounded env43157 := by
  intro p hp
  have h : env43157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43156_43157 : H12AffineEnvironment.transform 18 136192 env43156 = env43157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env43156 == env43157) = true)

def env43158 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,492614,148716,148716,96347,74794,131137,172,16401,1261,135681]

theorem envBound43158 : H12AffineFastState.Bounded env43158 := by
  intro p hp
  have h : env43158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43157_43158 : H12AffineEnvironment.transform 7 172 env43157 = env43158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43157 == env43158) = true)

def env43159 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143496,20497,492566,148668,148668,96267,74794,131089,172,16401,1213,135681]

theorem envBound43159 : H12AffineFastState.Bounded env43159 := by
  intro p hp
  have h : env43159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43158_43159 : H12AffineEnvironment.transform 5 16 env43158 = env43159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43158 == env43159) = true)

theorem identity43159 : scanCanonicalize (H12AffineFastState.compose env43159 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound43159 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43160 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,41002,32808,20497,341174,62492,62492,96267,74794,45233,172,16401,1213,41633]

theorem envBound43160 : H12AffineFastState.Bounded env43160 := by
  intro p hp
  have h : env43160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43159_43160 : H12AffineEnvironment.transform 16 45216 env43159 = env43160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env43159 == env43160) = true)

theorem identity43160 : scanCanonicalize (H12AffineFastState.compose env43160 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound43160 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env43161 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4096,46141,46093,41002,32808,5293,341174,45216,45216,81079,74794,45233,172,1197,1213,41633]

theorem envBound43161 : H12AffineFastState.Bounded env43161 := by
  intro p hp
  have h : env43161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43160_43161 : H12AffineEnvironment.transform 13 1212 env43160 = env43161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env43160 == env43161) = true)

theorem identity43161 : scanCanonicalize (H12AffineFastState.compose env43161 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound43161 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43162 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,12346,45216,262144,42144,32769,4096,46141,46093,41002,32808,5293,263308,45216,45216,3213,5136,45233,172,1197,1213,41633]

theorem envBound43162 : H12AffineFastState.Bounded env43162 := by
  intro p hp
  have h : env43162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43161_43162 : H12AffineEnvironment.transform 15 12346 env43161 = env43162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env43161 == env43162) = true)

theorem identity43162 : scanCanonicalize (H12AffineFastState.compose env43162 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound43162 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env43163 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,12346,5124,262144,4,9381,4096,4249,4265,1166,9356,5293,263308,5124,5124,3213,5136,5141,172,1197,1213,1541]

theorem envBound43163 : H12AffineFastState.Bounded env43163 := by
  intro p hp
  have h : env43163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43162_43163 : H12AffineEnvironment.transform 14 9380 env43162 = env43163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env43162 == env43163) = true)

theorem identity43163 : scanCanonicalize (H12AffineFastState.compose env43163 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound43163 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env43164 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,12346,5124,3213,4,9381,4096,4249,4265,1166,9356,5293,2049,5124,5124,3213,5136,5141,172,1197,1213,1541]

theorem envBound43164 : H12AffineFastState.Bounded env43164 := by
  intro p hp
  have h : env43164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43163_43164 : H12AffineEnvironment.transform 17 3213 env43163 = env43164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env43163 == env43164) = true)

theorem identity43164 : scanCanonicalize (H12AffineFastState.compose env43164 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound43164 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env43165 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,4096,8192,554,8754,12346,4754,2587,4,8755,4096,4249,4265,536,8730,4667,2049,4754,4754,2587,4742,4739,172,571,555,147]

theorem envBound43165 : H12AffineFastState.Bounded env43165 := by
  intro p hp
  have h : env43165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43164_43165 : H12AffineEnvironment.transform 9 662 env43164 = env43165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env43164 == env43165) = true)

theorem identity43165 : scanCanonicalize (H12AffineFastState.compose env43165 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound43165 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env43166 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,2075,8192,554,8754,10273,2697,2587,4,8755,2075,2178,2226,536,8730,2592,2049,2697,2697,2587,2717,2712,172,571,555,147]

theorem envBound43166 : H12AffineFastState.Bounded env43166 := by
  intro p hp
  have h : env43166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43165_43166 : H12AffineEnvironment.transform 11 2075 env43165 = env43166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env43165 == env43166) = true)

theorem identity43166 : scanCanonicalize (H12AffineFastState.compose env43166 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound43166 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env43167 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,2075,25,554,555,2104,2697,2587,4,554,2075,2178,2226,536,515,2592,2049,2697,2697,2587,2717,2712,172,571,555,147]

theorem envBound43167 : H12AffineFastState.Bounded env43167 := by
  intro p hp
  have h : env43167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43166_43167 : H12AffineEnvironment.transform 12 25 env43166 = env43167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43166 == env43167) = true)

theorem identity43167 : scanCanonicalize (H12AffineFastState.compose env43167 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43167 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env43168 : List Nat := [2,4,8,16,32,16,8,36,512,542,2048,2075,25,554,555,2104,2561,2587,4,554,2075,2058,2106,536,515,2592,2049,2561,2561,2587,2581,2576,36,571,555,27]

theorem envBound43168 : H12AffineFastState.Bounded env43168 := by
  intro p hp
  have h : env43168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43167_43168 : H12AffineEnvironment.transform 6 8 env43167 = env43168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43167 == env43168) = true)

def env43169 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143496,20497,492567,148669,148669,96266,74794,131088,172,16401,1212,135681]

theorem envBound43169 : H12AffineFastState.Bounded env43169 := by
  intro p hp
  have h : env43169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43158_43169 : H12AffineEnvironment.transform 5 17 env43158 = env43169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43158 == env43169) = true)

theorem identity43169 : scanCanonicalize (H12AffineFastState.compose env43169 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound43169 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43170 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,41002,143496,20497,105631,148669,148669,96266,74794,131088,172,16401,1212,135681]

theorem envBound43170 : H12AffineFastState.Bounded env43170 := by
  intro p hp
  have h : env43170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43169_43170 : H12AffineEnvironment.transform 17 137352 env43169 = env43170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env43169 == env43170) = true)

theorem identity43170 : scanCanonicalize (H12AffineFastState.compose env43170 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound43170 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43171 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4096,61568,147472,41002,143496,20497,43168,148669,148669,19509,4117,131088,172,16401,1212,135681]

theorem envBound43171 : H12AffineFastState.Bounded env43171 := by
  intro p hp
  have h : env43171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43170_43171 : H12AffineEnvironment.transform 15 13375 env43170 = env43171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env43170 == env43171) = true)

theorem identity43171 : scanCanonicalize (H12AffineFastState.compose env43171 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound43171 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43172 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136192,32769,4096,46140,132268,41002,143496,5293,43168,131073,131073,2185,4117,131088,172,1197,1212,135681]

theorem envBound43172 : H12AffineFastState.Bounded env43172 := by
  intro p hp
  have h : env43172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43171_43172 : H12AffineEnvironment.transform 13 1212 env43171 = env43172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env43171 == env43172) = true)

theorem identity43172 : scanCanonicalize (H12AffineFastState.compose env43172 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound43172 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env43173 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,40984,47248,46104,32769,4096,46140,42164,41002,37008,5293,43168,40985,40985,2185,4117,40968,172,1197,1212,45593]

theorem envBound43173 : H12AffineFastState.Bounded env43173 := by
  intro p hp
  have h : env43173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43172_43173 : H12AffineEnvironment.transform 16 40984 env43172 = env43173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env43172 == env43173) = true)

theorem identity43173 : scanCanonicalize (H12AffineFastState.compose env43173 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 15551) := by decide +kernel

theorem selectedBound43173 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env43174 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,15551,13375,7335,1071,2215,15550,4096,2179,6155,7317,11311,5293,5151,7334,7334,2185,4117,7351,172,1197,1212,3750]

theorem envBound43174 : H12AffineFastState.Bounded env43174 := by
  intro p hp
  have h : env43174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43173_43174 : H12AffineEnvironment.transform 14 15551 env43173 = env43174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15551 env43173 == env43174) = true)

theorem identity43174 : scanCanonicalize (H12AffineFastState.compose env43174 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 3263) := by decide +kernel

theorem selectedBound43174 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43175 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3263,1212,4096,6272,7335,1071,2215,4097,4096,2179,6155,7317,144,5293,5151,7334,7334,2185,4117,7351,172,1197,1212,3750]

theorem envBound43175 : H12AffineFastState.Bounded env43175 := by
  intro p hp
  have h : env43175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43174_43175 : H12AffineEnvironment.transform 12 3263 env43174 = env43175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3263 env43174 == env43175) = true)

theorem identity43175 : scanCanonicalize (H12AffineFastState.compose env43175 (packedSelected [1,4,7,8,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound43175 : packedSelected [1,4,7,8,10,11,16] rootPS < 2^1333 := by decide +kernel

def env43176 : List Nat := [2,4,8,16,32,17,128,172,137,1024,2048,4096,3263,1212,4096,6272,7335,1071,2215,4097,4096,2179,6155,7317,144,5293,5151,7334,7334,2185,4117,7351,172,1197,1212,3119]

theorem envBound43176 : H12AffineFastState.Bounded env43176 := by
  intro p hp
  have h : env43176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43175_43176 : H12AffineEnvironment.transform 8 137 env43175 = env43176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env43175 == env43176) = true)

theorem identity43176 : scanCanonicalize (H12AffineFastState.compose env43176 (packedSelected [2,6,10,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound43176 : packedSelected [2,6,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env43177 : List Nat := [2,4,8,16,32,17,128,172,137,1024,2048,2075,3263,1212,2075,155,1212,1071,2215,2074,2075,2179,16,1166,144,3254,3076,1213,1213,2185,2062,1196,172,1197,1212,3119]

theorem envBound43177 : H12AffineFastState.Bounded env43177 := by
  intro p hp
  have h : env43177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43176_43177 : H12AffineEnvironment.transform 11 2075 env43176 = env43177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env43176 == env43177) = true)

theorem identity43177 : scanCanonicalize (H12AffineFastState.compose env43177 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound43177 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43178 : List Nat := [2,4,8,16,32,17,128,172,137,140,2048,2075,2099,48,2075,155,48,163,2215,2074,2075,2179,16,2,144,2106,2184,49,49,2185,2062,32,172,33,48,2211]

theorem envBound43178 : H12AffineFastState.Bounded env43178 := by
  intro p hp
  have h : env43178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43177_43178 : H12AffineEnvironment.transform 9 140 env43177 = env43178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env43177 == env43178) = true)

theorem identity43178 : scanCanonicalize (H12AffineFastState.compose env43178 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound43178 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env43179 : List Nat := [2,4,8,16,32,17,128,172,137,140,185,162,138,48,162,155,48,163,30,163,162,58,16,2,144,131,49,49,49,48,183,32,172,33,48,26]

theorem envBound43179 : H12AffineFastState.Bounded env43179 := by
  intro p hp
  have h : env43179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43178_43179 : H12AffineEnvironment.transform 10 185 env43178 = env43179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env43178 == env43179) = true)

theorem identity43179 : scanCanonicalize (H12AffineFastState.compose env43179 (packedSelected [0,1,7] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43179 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env43180 : List Nat := [2,4,8,16,32,17,14,34,7,2,55,44,4,48,44,21,48,45,30,45,44,58,16,2,30,13,49,49,49,48,57,32,34,33,48,26]

theorem envBound43180 : H12AffineFastState.Bounded env43180 := by
  intro p hp
  have h : env43180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43179_43180 : H12AffineEnvironment.transform 6 14 env43179 = env43180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43179 == env43180) = true)

theorem identity43180 : scanCanonicalize (H12AffineFastState.compose env43180 (packedSelected [2,3,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43180 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env43181 : List Nat := [2,4,8,11,32,10,14,34,7,2,44,44,4,43,44,14,43,45,5,45,44,33,11,2,5,13,42,42,42,43,34,32,34,33,43,1]

theorem envBound43181 : H12AffineFastState.Bounded env43181 := by
  intro p hp
  have h : env43181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43180_43181 : H12AffineEnvironment.transform 3 11 env43180 = env43181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43180 == env43181) = true)

theorem identity43181 : scanCanonicalize (H12AffineFastState.compose env43181 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound43181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43182 : List Nat := [2,4,8,11,13,10,14,15,7,2,1,1,4,6,1,14,6,0,5,0,1,12,11,2,5,13,7,7,7,6,15,13,15,12,6,1]

theorem envBound43182 : H12AffineFastState.Bounded env43182 := by
  intro p hp
  have h : env43182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43181_43182 : H12AffineEnvironment.transform 4 13 env43181 = env43182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env43181 == env43182) = true)

theorem identity43182 : scanCanonicalize (H12AffineFastState.compose env43182 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43182 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43183 : List Nat := [2,2,8,11,11,10,8,9,1,2,1,1,2,0,1,8,0,0,3,0,1,10,11,2,3,11,1,1,1,0,9,11,9,10,0,1]

theorem envBound43183 : H12AffineFastState.Bounded env43183 := by
  intro p hp
  have h : env43183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43182_43183 : H12AffineEnvironment.transform 1 2 env43182 = env43183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43182 == env43183) = true)

def env43184 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,492615,148717,148717,96347,74794,131137,173,16401,1260,135681]

theorem envBound43184 : H12AffineFastState.Bounded env43184 := by
  intro p hp
  have h : env43184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43157_43184 : H12AffineEnvironment.transform 7 173 env43157 = env43184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43157 == env43184) = true)

def env43185 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143496,20497,492567,148669,148669,96267,74794,131089,173,16401,1212,135681]

theorem envBound43185 : H12AffineFastState.Bounded env43185 := by
  intro p hp
  have h : env43185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43184_43185 : H12AffineEnvironment.transform 5 16 env43184 = env43185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43184 == env43185) = true)

theorem identity43185 : scanCanonicalize (H12AffineFastState.compose env43185 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound43185 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43186 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61569,98354,41002,127147,20497,279604,99486,99486,96267,74794,114738,173,16401,1212,119330]

theorem envBound43186 : H12AffineFastState.Bounded env43186 := by
  intro p hp
  have h : env43186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43185_43186 : H12AffineEnvironment.transform 16 114723 env43185 = env43186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env43185 == env43186) = true)

theorem identity43186 : scanCanonicalize (H12AffineFastState.compose env43186 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 59536) := by decide +kernel

theorem selectedBound43186 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43187 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,59536,119843,32769,4096,61569,98354,41002,127147,20497,44196,99486,99486,96267,74794,114738,173,16401,1212,119330]

theorem envBound43187 : H12AffineFastState.Bounded env43187 := by
  intro p hp
  have h : env43187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43186_43187 : H12AffineEnvironment.transform 17 59536 env43186 = env43187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 59536 env43186 == env43187) = true)

theorem identity43187 : scanCanonicalize (H12AffineFastState.compose env43187 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound43187 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env43188 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,59536,1025,32769,4096,61569,20496,41002,8329,20497,44196,21692,21692,43049,62472,4112,173,16401,1212,512]

theorem envBound43188 : H12AffineFastState.Bounded env43188 := by
  intro p hp
  have h : env43188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43187_43188 : H12AffineEnvironment.transform 15 53282 env43187 = env43188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env43187 == env43188) = true)

theorem identity43188 : scanCanonicalize (H12AffineFastState.compose env43188 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43188 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43189 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,53282,4097,59536,4,32769,4096,61569,20496,41002,8329,20497,43169,20665,20665,43049,61453,4112,173,16401,185,512]

theorem envBound43189 : H12AffineFastState.Bounded env43189 := by
  intro p hp
  have h : env43189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43188_43189 : H12AffineEnvironment.transform 9 5 env43188 = env43189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43188 == env43189) = true)

theorem identity43189 : scanCanonicalize (H12AffineFastState.compose env43189 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17033) := by decide +kernel

theorem selectedBound43189 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43190 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,17033,4779,4097,10777,4,17032,4096,12808,20496,25251,8329,20497,27176,20665,20665,27296,12932,4112,173,16401,185,512]

theorem envBound43190 : H12AffineFastState.Bounded env43190 := by
  intro p hp
  have h : env43190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43189_43190 : H12AffineEnvironment.transform 14 17033 env43189 = env43190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17033 env43189 == env43190) = true)

theorem identity43190 : scanCanonicalize (H12AffineFastState.compose env43190 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 8243) := by decide +kernel

theorem selectedBound43190 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env43191 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,8243,8890,4779,4097,10777,4,8891,4096,12808,12323,656,8329,12322,2587,12426,12426,2707,12932,4112,173,8226,185,512]

theorem envBound43191 : H12AffineFastState.Bounded env43191 := by
  intro p hp
  have h : env43191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43190_43191 : H12AffineEnvironment.transform 13 8243 env43190 = env43191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8243 env43190 == env43191) = true)

theorem identity43191 : scanCanonicalize (H12AffineFastState.compose env43191 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound43191 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env43192 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,2048,8192,8243,8890,2731,2049,10777,4,8891,2048,10760,10275,656,8329,10274,2587,10378,10378,2707,10884,2064,173,8226,185,512]

theorem envBound43192 : H12AffineFastState.Bounded env43192 := by
  intro p hp
  have h : env43192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43191_43192 : H12AffineEnvironment.transform 11 2048 env43191 = env43192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env43191 == env43192) = true)

theorem identity43192 : scanCanonicalize (H12AffineFastState.compose env43192 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound43192 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env43193 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,2048,2600,2587,2194,2731,2049,49,4,2195,2048,32,523,656,2721,522,2587,674,674,2707,172,2064,173,2570,185,512]

theorem envBound43193 : H12AffineFastState.Bounded env43193 := by
  intro p hp
  have h : env43193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43192_43193 : H12AffineEnvironment.transform 12 2600 env43192 = env43193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env43192 == env43193) = true)

theorem identity43193 : scanCanonicalize (H12AffineFastState.compose env43193 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound43193 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43194 : List Nat := [2,4,8,16,32,16,128,173,26,5,2048,2048,2098,2049,2194,2225,2049,49,4,2195,2048,32,17,138,2235,16,2049,184,184,2185,172,2064,173,2064,185,26]

theorem envBound43194 : H12AffineFastState.Bounded env43194 := by
  intro p hp
  have h : env43194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43193_43194 : H12AffineEnvironment.transform 8 26 env43193 = env43194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env43193 == env43194) = true)

def env43195 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143496,20497,492566,148668,148668,96266,74794,131088,173,16401,1213,135681]

theorem envBound43195 : H12AffineFastState.Bounded env43195 := by
  intro p hp
  have h : env43195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43184_43195 : H12AffineEnvironment.transform 5 17 env43184 = env43195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43184 == env43195) = true)

theorem identity43195 : scanCanonicalize (H12AffineFastState.compose env43195 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound43195 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43196 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61568,147472,41002,143496,20497,60444,148668,148668,96266,74794,131088,173,16401,1213,135681]

theorem envBound43196 : H12AffineFastState.Bounded env43196 := by
  intro p hp
  have h : env43196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43195_43196 : H12AffineEnvironment.transform 17 223242 env43195 = env43196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env43195 == env43196) = true)

theorem identity43196 : scanCanonicalize (H12AffineFastState.compose env43196 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound43196 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43197 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4096,61568,147472,41002,143496,20497,60444,148668,148668,2185,21673,131088,173,16401,1213,135681]

theorem envBound43197 : H12AffineFastState.Bounded env43197 := by
  intro p hp
  have h : env43197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43196_43197 : H12AffineEnvironment.transform 15 28803 env43196 = env43197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env43196 == env43197) = true)

theorem identity43197 : scanCanonicalize (H12AffineFastState.compose env43197 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61465) := by decide +kernel

theorem selectedBound43197 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env43198 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,61465,59536,58393,32769,4096,61568,45065,41002,49297,20497,60444,46245,46245,2185,21673,61449,173,16401,1213,57880]

theorem envBound43198 : H12AffineFastState.Bounded env43198 := by
  intro p hp
  have h : env43198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43197_43198 : H12AffineEnvironment.transform 16 61465 env43197 = env43198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61465 env43197 == env43198) = true)

theorem identity43198 : scanCanonicalize (H12AffineFastState.compose env43198 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound43198 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env43199 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,46244,44077,41124,32769,4096,46141,45065,41002,33836,5292,43169,46245,46245,2185,4116,46260,173,1196,1213,42661]

theorem envBound43199 : H12AffineFastState.Bounded env43199 := by
  intro p hp
  have h : env43199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43198_43199 : H12AffineEnvironment.transform 13 1213 env43198 = env43199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env43198 == env43199) = true)

theorem identity43199 : scanCanonicalize (H12AffineFastState.compose env43199 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound43199 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43200 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1213,32768,2225,34859,37026,39979,32769,4096,34994,35974,40101,33836,5292,37934,34858,34858,2185,4116,34875,173,1196,1213,39466]

theorem envBound43200 : H12AffineFastState.Bounded env43200 := by
  intro p hp
  have h : env43200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43199_43200 : H12AffineEnvironment.transform 12 7311 env43199 = env43200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env43199 == env43200) = true)

theorem identity43200 : scanCanonicalize (H12AffineFastState.compose env43200 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound43200 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env43201 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,3126,1213,32768,2225,34859,32795,35986,32769,185,34994,35974,35868,33836,1045,33943,34858,34858,2185,173,34875,173,1196,1213,35475]

theorem envBound43201 : H12AffineFastState.Bounded env43201 := by
  intro p hp
  have h : env43201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43200_43201 : H12AffineEnvironment.transform 11 185 env43200 = env43201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env43200 == env43201) = true)

theorem identity43201 : scanCanonicalize (H12AffineFastState.compose env43201 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43201 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env43202 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,185,3126,1213,32768,2225,34859,32795,35986,32769,185,34994,35974,35868,33836,1045,33943,34858,34858,2185,173,34875,173,1196,1213,34962]

theorem envBound43202 : H12AffineFastState.Bounded env43202 := by
  intro p hp
  have h : env43202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43201_43202 : H12AffineEnvironment.transform 8 1 env43201 = env43202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43201 == env43202) = true)

theorem identity43202 : scanCanonicalize (H12AffineFastState.compose env43202 (packedSelected [0,1,3,4,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1179) := by decide +kernel

theorem selectedBound43202 : packedSelected [0,1,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43203 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1179,185,173,1213,32768,1066,33968,32795,32777,32769,185,33833,32797,32903,33836,1045,33943,33969,33969,1042,173,33952,173,1196,1213,33801]

theorem envBound43203 : H12AffineFastState.Bounded env43203 := by
  intro p hp
  have h : env43203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43202_43203 : H12AffineEnvironment.transform 10 1179 env43202 = env43203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1179 env43202 == env43203) = true)

theorem identity43203 : scanCanonicalize (H12AffineFastState.compose env43203 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 56) := by decide +kernel

theorem selectedBound43203 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env43204 : List Nat := [2,4,8,16,32,17,128,173,1,56,163,185,173,133,32768,18,32904,32795,32777,32769,185,32785,32797,32903,32788,45,32943,32905,32905,42,173,32920,173,148,133,32817]

theorem envBound43204 : H12AffineFastState.Bounded env43204 := by
  intro p hp
  have h : env43204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43203_43204 : H12AffineEnvironment.transform 9 56 env43203 = env43204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env43203 == env43204) = true)

theorem identity43204 : scanCanonicalize (H12AffineFastState.compose env43204 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound43204 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env43205 : List Nat := [2,4,8,16,32,17,46,3,1,56,13,23,3,43,32768,18,32806,32795,32777,32769,23,32785,32797,32809,32788,45,32769,32807,32807,42,3,32822,3,58,43,32817]

theorem envBound43205 : H12AffineFastState.Bounded env43205 := by
  intro p hp
  have h : env43205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43204_43205 : H12AffineEnvironment.transform 6 46 env43204 = env43205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env43204 == env43205) = true)

theorem identity43205 : scanCanonicalize (H12AffineFastState.compose env43205 (packedSelected [1,8] rootPS)) = affineNative (2^(14+1) ^^^ 48) := by decide +kernel

theorem selectedBound43205 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43206 : List Nat := [2,4,8,16,32,17,46,3,1,56,13,23,3,43,48,18,22,43,57,49,23,33,45,25,36,45,49,23,23,42,3,6,3,58,43,1]

theorem envBound43206 : H12AffineFastState.Bounded env43206 := by
  intro p hp
  have h : env43206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43205_43206 : H12AffineEnvironment.transform 14 48 env43205 = env43206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 48 env43205 == env43206) = true)

def env43207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,493034,148800,148801,96347,74794,131137,256,16400,1345,135680]

theorem envBound43207 : H12AffineFastState.Bounded env43207 := by
  intro p hp
  have h : env43207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43156_43207 : H12AffineEnvironment.transform 18 136193 env43156 = env43207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env43156 == env43207) = true)

def env43208 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,492614,148716,148717,96347,74794,131137,172,16400,1261,135680]

theorem envBound43208 : H12AffineFastState.Bounded env43208 := by
  intro p hp
  have h : env43208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43207_43208 : H12AffineEnvironment.transform 7 172 env43207 = env43208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43207 == env43208) = true)

def env43209 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143497,20496,492566,148668,148669,96267,74794,131089,172,16400,1213,135680]

theorem envBound43209 : H12AffineFastState.Bounded env43209 := by
  intro p hp
  have h : env43209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43208_43209 : H12AffineEnvironment.transform 5 16 env43208 = env43209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43208 == env43209) = true)

theorem identity43209 : scanCanonicalize (H12AffineFastState.compose env43209 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound43209 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43210 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,41002,143497,20496,105631,148668,148669,96267,74794,131089,172,16400,1213,135680]

theorem envBound43210 : H12AffineFastState.Bounded env43210 := by
  intro p hp
  have h : env43210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43209_43210 : H12AffineEnvironment.transform 17 137353 env43209 = env43210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env43209 == env43210) = true)

theorem identity43210 : scanCanonicalize (H12AffineFastState.compose env43210 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound43210 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43211 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4096,61569,147473,41002,143497,20496,43168,148668,148669,19508,4117,131089,172,16400,1213,135680]

theorem envBound43211 : H12AffineFastState.Bounded env43211 := by
  intro p hp
  have h : env43211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43210_43211 : H12AffineEnvironment.transform 15 13375 env43210 = env43211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env43210 == env43211) = true)

theorem identity43211 : scanCanonicalize (H12AffineFastState.compose env43211 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound43211 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43212 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136193,32769,4096,46140,132268,41002,143497,5293,43168,131073,131072,2185,4117,131089,172,1197,1213,135680]

theorem envBound43212 : H12AffineFastState.Bounded env43212 := by
  intro p hp
  have h : env43212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43211_43212 : H12AffineEnvironment.transform 13 1213 env43211 = env43212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env43211 == env43212) = true)

theorem identity43212 : scanCanonicalize (H12AffineFastState.compose env43212 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound43212 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env43213 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,13375,131072,137353,136193,12312,4096,1061,132268,4147,143497,5293,6329,131073,131072,2185,4117,131089,172,1197,1213,135680]

theorem envBound43213 : H12AffineFastState.Bounded env43213 := by
  intro p hp
  have h : env43213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43212_43213 : H12AffineEnvironment.transform 14 12313 env43212 = env43213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env43212 == env43213) = true)

theorem identity43213 : scanCanonicalize (H12AffineFastState.compose env43213 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound43213 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env43214 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,13375,3102,5271,6175,12312,4096,1061,2226,4147,15511,5293,6329,3103,3102,2185,4117,3087,172,1197,1213,7710]

theorem envBound43214 : H12AffineFastState.Bounded env43214 := by
  intro p hp
  have h : env43214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43213_43214 : H12AffineEnvironment.transform 16 3102 env43213 = env43214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env43213 == env43214) = true)

theorem identity43214 : scanCanonicalize (H12AffineFastState.compose env43214 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound43214 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43215 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1213,8353,9351,3102,1071,2215,8352,184,1061,2226,139,11311,1045,2049,3103,3102,2185,173,3087,172,1197,1213,3750]

theorem envBound43215 : H12AffineFastState.Bounded env43215 := by
  intro p hp
  have h : env43215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43214_43215 : H12AffineEnvironment.transform 11 184 env43214 = env43215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env43214 == env43215) = true)

theorem identity43215 : scanCanonicalize (H12AffineFastState.compose env43215 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound43215 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43216 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,3,1213,162,1156,3102,1071,2215,163,184,1061,2226,139,3116,1045,2049,3103,3102,2185,173,3087,172,1197,1213,3750]

theorem envBound43216 : H12AffineFastState.Bounded env43216 := by
  intro p hp
  have h : env43216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43215_43216 : H12AffineEnvironment.transform 12 3 env43215 = env43216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env43215 == env43216) = true)

theorem identity43216 : scanCanonicalize (H12AffineFastState.compose env43216 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound43216 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env43217 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,184,3,1213,162,1156,3102,1071,2215,163,184,1061,2226,139,3116,1045,2049,3103,3102,2185,173,3087,172,1197,1213,3260]

theorem envBound43217 : H12AffineFastState.Bounded env43217 := by
  intro p hp
  have h : env43217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43216_43217 : H12AffineEnvironment.transform 8 26 env43216 = env43217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env43216 == env43217) = true)

theorem identity43217 : scanCanonicalize (H12AffineFastState.compose env43217 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43217 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env43218 : List Nat := [2,4,8,11,32,11,128,172,1,1024,2048,163,3,1190,162,1156,3077,1071,2215,163,163,1061,2217,139,3116,1038,2049,3076,3077,2185,173,3087,172,1197,1190,3239]

theorem envBound43218 : H12AffineFastState.Bounded env43218 := by
  intro p hp
  have h : env43218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43217_43218 : H12AffineEnvironment.transform 3 11 env43217 = env43218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43217 == env43218) = true)

theorem identity43218 : scanCanonicalize (H12AffineFastState.compose env43218 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound43218 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43219 : List Nat := [2,4,8,11,32,11,128,172,1,1024,42,163,3,1190,162,1156,1071,1071,141,163,163,1061,131,139,1030,1038,43,1070,1071,163,173,1061,172,1197,1190,1165]

theorem envBound43219 : H12AffineFastState.Bounded env43219 := by
  intro p hp
  have h : env43219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43218_43219 : H12AffineEnvironment.transform 10 42 env43218 = env43219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env43218 == env43219) = true)

theorem identity43219 : scanCanonicalize (H12AffineFastState.compose env43219 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound43219 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43220 : List Nat := [2,4,8,11,32,11,128,172,1,141,42,163,3,43,162,9,162,162,141,163,163,168,131,139,139,131,43,163,162,163,173,168,172,32,43,0]

theorem envBound43220 : H12AffineFastState.Bounded env43220 := by
  intro p hp
  have h : env43220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43219_43220 : H12AffineEnvironment.transform 9 141 env43219 = env43220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env43219 == env43220) = true)

theorem identity43220 : scanCanonicalize (H12AffineFastState.compose env43220 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound43220 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43221 : List Nat := [2,4,8,11,3,11,128,143,1,141,9,128,3,8,129,9,129,129,141,128,128,139,131,139,139,131,8,128,129,128,142,139,143,3,8,0]

theorem envBound43221 : H12AffineFastState.Bounded env43221 := by
  intro p hp
  have h : env43221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43220_43221 : H12AffineEnvironment.transform 4 3 env43220 = env43221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env43220 == env43221) = true)

theorem identity43221 : scanCanonicalize (H12AffineFastState.compose env43221 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound43221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43222 : List Nat := [2,4,8,11,3,11,1,14,1,12,9,1,3,8,0,9,0,0,12,1,1,10,2,10,10,2,8,1,0,1,15,10,14,3,8,0]

theorem envBound43222 : H12AffineFastState.Bounded env43222 := by
  intro p hp
  have h : env43222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43221_43222 : H12AffineEnvironment.transform 6 1 env43221 = env43222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env43221 == env43222) = true)

theorem identity43222 : scanCanonicalize (H12AffineFastState.compose env43222 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43223 : List Nat := [2,1,8,11,3,11,1,11,1,9,9,1,3,8,0,9,0,0,9,1,1,10,2,10,10,2,8,1,0,1,10,10,11,3,8,0]

theorem envBound43223 : H12AffineFastState.Bounded env43223 := by
  intro p hp
  have h : env43223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43222_43223 : H12AffineEnvironment.transform 1 1 env43222 = env43223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43222 == env43223) = true)

theorem identity43223 : scanCanonicalize (H12AffineFastState.compose env43223 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43223 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43224 : List Nat := [2,1,2,1,3,1,1,1,1,3,3,1,3,2,0,3,0,0,3,1,1,0,2,0,0,2,2,1,0,1,0,0,1,3,2,0]

theorem envBound43224 : H12AffineFastState.Bounded env43224 := by
  intro p hp
  have h : env43224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43223_43224 : H12AffineEnvironment.transform 2 2 env43223 = env43224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43223 == env43224) = true)

def env43225 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143497,20496,492567,148669,148668,96266,74794,131088,172,16400,1212,135680]

theorem envBound43225 : H12AffineFastState.Bounded env43225 := by
  intro p hp
  have h : env43225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43208_43225 : H12AffineEnvironment.transform 5 17 env43208 = env43225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43208 == env43225) = true)

theorem identity43225 : scanCanonicalize (H12AffineFastState.compose env43225 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound43225 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43226 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,41002,32808,20496,341174,62492,62493,96266,74794,45233,172,16400,1212,41633]

theorem envBound43226 : H12AffineFastState.Bounded env43226 := by
  intro p hp
  have h : env43226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43225_43226 : H12AffineEnvironment.transform 16 45217 env43225 = env43226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env43225 == env43226) = true)

theorem identity43226 : scanCanonicalize (H12AffineFastState.compose env43226 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound43226 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env43227 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4096,46141,46092,41002,32808,5293,341174,45217,45216,81079,74794,45233,172,1197,1212,41633]

theorem envBound43227 : H12AffineFastState.Bounded env43227 := by
  intro p hp
  have h : env43227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43226_43227 : H12AffineEnvironment.transform 13 1213 env43226 = env43227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env43226 == env43227) = true)

theorem identity43227 : scanCanonicalize (H12AffineFastState.compose env43227 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound43227 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43228 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,12347,45217,262144,42144,32769,4096,46141,46092,41002,32808,5293,263309,45217,45216,3212,5137,45233,172,1197,1212,41633]

theorem envBound43228 : H12AffineFastState.Bounded env43228 := by
  intro p hp
  have h : env43228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43227_43228 : H12AffineEnvironment.transform 15 12347 env43227 = env43228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env43227 == env43228) = true)

theorem identity43228 : scanCanonicalize (H12AffineFastState.compose env43228 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound43228 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env43229 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,12347,5124,262144,5,9380,4096,4248,4265,1167,9357,5293,263309,5124,5125,3212,5137,5140,172,1197,1212,1540]

theorem envBound43229 : H12AffineFastState.Bounded env43229 := by
  intro p hp
  have h : env43229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43228_43229 : H12AffineEnvironment.transform 14 9381 env43228 = env43229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env43228 == env43229) = true)

theorem identity43229 : scanCanonicalize (H12AffineFastState.compose env43229 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound43229 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env43230 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,12347,5124,2184,5,9380,4096,4248,4265,1167,9357,5293,3077,5124,5125,3212,5137,5140,172,1197,1212,1540]

theorem envBound43230 : H12AffineFastState.Bounded env43230 := by
  intro p hp
  have h : env43230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43229_43230 : H12AffineEnvironment.transform 17 2184 env43229 = env43230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env43229 == env43230) = true)

theorem identity43230 : scanCanonicalize (H12AffineFastState.compose env43230 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43230 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43231 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,4096,8192,1213,9381,12347,5124,2184,5,9380,4096,4248,4265,1167,9357,5293,3077,5124,5125,3212,5137,5140,172,1197,1212,1028]

theorem envBound43231 : H12AffineFastState.Bounded env43231 := by
  intro p hp
  have h : env43231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43230_43231 : H12AffineEnvironment.transform 8 0 env43230 = env43231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43230 == env43231) = true)

theorem identity43231 : scanCanonicalize (H12AffineFastState.compose env43231 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound43231 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env43232 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,3212,8192,1213,9381,11447,2184,2184,5,9380,3212,3092,3109,1167,9357,2081,3077,2184,2185,3212,2205,2200,172,1197,1212,1028]

theorem envBound43232 : H12AffineFastState.Bounded env43232 := by
  intro p hp
  have h : env43232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43231_43232 : H12AffineEnvironment.transform 11 3212 env43231 = env43232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env43231 == env43232) = true)

theorem identity43232 : scanCanonicalize (H12AffineFastState.compose env43232 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound43232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43233 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,3212,2088,1213,3213,1183,2184,2184,5,3212,3212,3092,3109,1167,3237,2081,3077,2184,2185,3212,2205,2200,172,1197,1212,1028]

theorem envBound43233 : H12AffineFastState.Bounded env43233 := by
  intro p hp
  have h : env43233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43232_43233 : H12AffineEnvironment.transform 12 2088 env43232 = env43233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env43232 == env43233) = true)

theorem identity43233 : scanCanonicalize (H12AffineFastState.compose env43233 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound43233 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env43234 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1213,49,1173,1213,48,1183,1077,1077,5,49,49,169,152,1167,24,1180,184,1077,1076,49,1056,1061,172,1197,1212,1028]

theorem envBound43234 : H12AffineFastState.Bounded env43234 := by
  intro p hp
  have h : env43234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43233_43234 : H12AffineEnvironment.transform 10 1213 env43233 = env43234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env43233 == env43234) = true)

theorem identity43234 : scanCanonicalize (H12AffineFastState.compose env43234 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43234 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43235 : List Nat := [2,4,8,11,32,10,128,172,0,1024,1190,42,1166,1190,43,1156,1070,1070,5,42,42,169,131,1167,3,1159,163,1070,1071,42,1056,1061,172,1197,1191,1028]

theorem envBound43235 : H12AffineFastState.Bounded env43235 := by
  intro p hp
  have h : env43235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43234_43235 : H12AffineEnvironment.transform 3 11 env43234 = env43235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43234 == env43235) = true)

theorem identity43235 : scanCanonicalize (H12AffineFastState.compose env43235 (packedSelected [0,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43235 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env43236 : List Nat := [2,4,8,11,32,10,8,36,0,1024,1070,42,1030,1070,43,1036,1070,1070,5,42,42,33,11,1031,3,1039,43,1070,1071,42,1056,1061,36,1061,1071,1028]

theorem envBound43236 : H12AffineFastState.Bounded env43236 := by
  intro p hp
  have h : env43236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43235_43236 : H12AffineEnvironment.transform 6 8 env43235 = env43236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43235 == env43236) = true)

theorem identity43236 : scanCanonicalize (H12AffineFastState.compose env43236 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound43236 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43237 : List Nat := [2,4,8,11,32,10,8,36,0,34,12,42,36,12,43,46,12,12,5,42,42,33,11,37,3,45,43,12,13,42,2,7,36,7,13,38]

theorem envBound43237 : H12AffineFastState.Bounded env43237 := by
  intro p hp
  have h : env43237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43236_43237 : H12AffineEnvironment.transform 9 34 env43236 = env43237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env43236 == env43237) = true)

def env43238 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,492615,148717,148716,96347,74794,131137,173,16400,1260,135680]

theorem envBound43238 : H12AffineFastState.Bounded env43238 := by
  intro p hp
  have h : env43238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43207_43238 : H12AffineEnvironment.transform 7 173 env43207 = env43238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43207 == env43238) = true)

def env43239 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143497,20496,492567,148669,148668,96267,74794,131089,173,16400,1212,135680]

theorem envBound43239 : H12AffineFastState.Bounded env43239 := by
  intro p hp
  have h : env43239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43238_43239 : H12AffineEnvironment.transform 5 16 env43238 = env43239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43238 == env43239) = true)

theorem identity43239 : scanCanonicalize (H12AffineFastState.compose env43239 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound43239 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43240 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61569,147473,41002,143497,20496,60445,148669,148668,96267,74794,131089,173,16400,1212,135680]

theorem envBound43240 : H12AffineFastState.Bounded env43240 := by
  intro p hp
  have h : env43240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43239_43240 : H12AffineEnvironment.transform 17 223242 env43239 = env43240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env43239 == env43240) = true)

theorem identity43240 : scanCanonicalize (H12AffineFastState.compose env43240 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound43240 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43241 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4096,61569,147473,41002,143497,20496,60445,148669,148668,2185,21672,131089,173,16400,1212,135680]

theorem envBound43241 : H12AffineFastState.Bounded env43241 := by
  intro p hp
  have h : env43241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43240_43241 : H12AffineEnvironment.transform 15 28802 env43240 = env43241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env43240 == env43241) = true)

theorem identity43241 : scanCanonicalize (H12AffineFastState.compose env43241 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61464) := by decide +kernel

theorem selectedBound43241 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env43242 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,61464,59536,58393,32769,4096,61569,45065,41002,49297,20496,60445,46245,46244,2185,21672,61449,173,16400,1212,57880]

theorem envBound43242 : H12AffineFastState.Bounded env43242 := by
  intro p hp
  have h : env43242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43241_43242 : H12AffineEnvironment.transform 16 61464 env43241 = env43242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61464 env43241 == env43242) = true)

theorem identity43242 : scanCanonicalize (H12AffineFastState.compose env43242 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound43242 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env43243 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13374,46244,44076,41125,32769,4096,46141,45065,41002,33837,5292,43169,46245,46244,2185,4116,46261,173,1196,1212,42660]

theorem envBound43243 : H12AffineFastState.Bounded env43243 := by
  intro p hp
  have h : env43243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43242_43243 : H12AffineEnvironment.transform 13 1212 env43242 = env43243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env43242 == env43243) = true)

theorem identity43243 : scanCanonicalize (H12AffineFastState.compose env43243 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound43243 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43244 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,6187,13374,11407,13319,14478,6186,4096,11286,10274,14337,7174,5292,12426,11406,11407,2185,4116,11422,173,1196,1212,16015]

theorem envBound43244 : H12AffineFastState.Bounded env43244 := by
  intro p hp
  have h : env43244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43243_43244 : H12AffineEnvironment.transform 14 6187 env43243 = env43244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env43243 == env43244) = true)

theorem identity43244 : scanCanonicalize (H12AffineFastState.compose env43244 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3126) := by decide +kernel

theorem selectedBound43244 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env43245 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3126,1212,6187,6152,185,6193,5304,6186,4096,32,1044,5175,7174,5292,7356,184,185,2185,4116,168,173,1196,1212,4793]

theorem envBound43245 : H12AffineFastState.Bounded env43245 := by
  intro p hp
  have h : env43245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43244_43245 : H12AffineEnvironment.transform 12 3126 env43244 = env43245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3126 env43244 == env43245) = true)

theorem identity43245 : scanCanonicalize (H12AffineFastState.compose env43245 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound43245 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env43246 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1725,3126,1212,3734,3765,185,3724,517,3735,1725,32,1044,650,2747,529,2561,184,185,2185,1705,168,173,1196,1212,1028]

theorem envBound43246 : H12AffineFastState.Bounded env43246 := by
  intro p hp
  have h : env43246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43245_43246 : H12AffineEnvironment.transform 11 1725 env43245 = env43246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env43245 == env43246) = true)

theorem identity43246 : scanCanonicalize (H12AffineFastState.compose env43246 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound43246 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43247 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1190,1725,144,1212,560,531,185,554,517,561,1725,32,1044,650,1565,529,1703,184,185,1071,1705,168,173,1196,1212,1028]

theorem envBound43247 : H12AffineFastState.Bounded env43247 := by
  intro p hp
  have h : env43247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43246_43247 : H12AffineEnvironment.transform 10 1190 env43246 = env43247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env43246 == env43247) = true)

theorem identity43247 : scanCanonicalize (H12AffineFastState.compose env43247 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43247 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43248 : List Nat := [2,4,8,16,32,16,128,173,512,5,163,696,144,185,560,531,185,554,517,561,696,32,17,650,536,529,674,184,185,42,684,168,173,169,185,1]

theorem envBound43248 : H12AffineFastState.Bounded env43248 := by
  intro p hp
  have h : env43248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43247_43248 : H12AffineEnvironment.transform 9 5 env43247 = env43248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43247 == env43248) = true)

theorem identity43248 : scanCanonicalize (H12AffineFastState.compose env43248 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound43248 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env43249 : List Nat := [2,4,8,16,32,16,18,63,512,5,49,554,2,43,560,531,43,554,517,561,554,32,17,536,536,529,560,42,43,42,574,58,63,59,43,1]

theorem envBound43249 : H12AffineFastState.Bounded env43249 := by
  intro p hp
  have h : env43249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43248_43249 : H12AffineEnvironment.transform 6 18 env43248 = env43249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env43248 == env43249) = true)

theorem identity43249 : scanCanonicalize (H12AffineFastState.compose env43249 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound43249 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env43250 : List Nat := [2,4,8,6,32,6,4,41,512,5,39,554,2,43,550,517,43,554,517,551,554,32,7,526,526,519,550,42,43,42,552,44,41,45,43,1]

theorem envBound43250 : H12AffineFastState.Bounded env43250 := by
  intro p hp
  have h : env43250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43249_43250 : H12AffineEnvironment.transform 3 6 env43249 = env43250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env43249 == env43250) = true)

theorem identity43250 : scanCanonicalize (H12AffineFastState.compose env43250 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43250 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env43251 : List Nat := [2,4,4,6,32,6,4,37,512,5,39,550,2,39,550,517,39,550,517,551,550,32,7,514,514,519,550,38,39,38,548,32,37,33,39,1]

theorem envBound43251 : H12AffineFastState.Bounded env43251 := by
  intro p hp
  have h : env43251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43250_43251 : H12AffineEnvironment.transform 2 4 env43250 = env43251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43250 == env43251) = true)

theorem identity43251 : scanCanonicalize (H12AffineFastState.compose env43251 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43251 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43252 : List Nat := [2,4,4,6,32,6,4,37,1,5,39,39,2,39,39,4,39,39,4,38,39,32,7,3,3,6,39,38,39,38,37,32,37,33,39,1]

theorem envBound43252 : H12AffineFastState.Bounded env43252 := by
  intro p hp
  have h : env43252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43251_43252 : H12AffineEnvironment.transform 8 1 env43251 = env43252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43251 == env43252) = true)

def env43253 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143497,20496,492566,148668,148669,96266,74794,131088,173,16400,1213,135680]

theorem envBound43253 : H12AffineFastState.Bounded env43253 := by
  intro p hp
  have h : env43253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43238_43253 : H12AffineEnvironment.transform 5 17 env43238 = env43253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43238 == env43253) = true)

theorem identity43253 : scanCanonicalize (H12AffineFastState.compose env43253 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound43253 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43254 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61568,98355,41002,127146,20496,279605,99487,99486,96266,74794,114739,173,16400,1213,119331]

theorem envBound43254 : H12AffineFastState.Bounded env43254 := by
  intro p hp
  have h : env43254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43253_43254 : H12AffineEnvironment.transform 16 114723 env43253 = env43254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env43253 == env43254) = true)

theorem identity43254 : scanCanonicalize (H12AffineFastState.compose env43254 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 59536) := by decide +kernel

theorem selectedBound43254 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43255 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,59536,119842,32769,4096,61568,98355,41002,127146,20496,44197,99487,99486,96266,74794,114739,173,16400,1213,119331]

theorem envBound43255 : H12AffineFastState.Bounded env43255 := by
  intro p hp
  have h : env43255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43254_43255 : H12AffineEnvironment.transform 17 59536 env43254 = env43255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 59536 env43254 == env43255) = true)

theorem identity43255 : scanCanonicalize (H12AffineFastState.compose env43255 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound43255 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env43256 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,59536,1025,32769,4096,61568,20496,41002,8329,20496,44197,21692,21693,43049,62473,4112,173,16400,1213,512]

theorem envBound43256 : H12AffineFastState.Bounded env43256 := by
  intro p hp
  have h : env43256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43255_43256 : H12AffineEnvironment.transform 15 53283 env43255 = env43256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env43255 == env43256) = true)

theorem identity43256 : scanCanonicalize (H12AffineFastState.compose env43256 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43256 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43257 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,53283,4096,59536,5,32769,4096,61568,20496,41002,8329,20496,43169,20664,20665,43049,61453,4112,173,16400,185,512]

theorem envBound43257 : H12AffineFastState.Bounded env43257 := by
  intro p hp
  have h : env43257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43256_43257 : H12AffineEnvironment.transform 9 4 env43256 = env43257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43256 == env43257) = true)

theorem identity43257 : scanCanonicalize (H12AffineFastState.compose env43257 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound43257 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43258 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,8745,32768,45578,4096,35513,5,32769,4096,37545,12857,41002,8329,12857,43169,12945,12944,43049,37412,4112,173,8761,185,512]

theorem envBound43258 : H12AffineFastState.Bounded env43258 := by
  intro p hp
  have h : env43258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43257_43258 : H12AffineEnvironment.transform 13 8745 env43257 = env43258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env43257 == env43258) = true)

theorem identity43258 : scanCanonicalize (H12AffineFastState.compose env43258 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound43258 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env43259 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,138,675,32768,37504,4096,35513,5,32769,4096,37545,4787,32928,3,4787,34859,4635,4634,34979,37412,4112,173,691,185,512]

theorem envBound43259 : H12AffineFastState.Bounded env43259 := by
  intro p hp
  have h : env43259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43258_43259 : H12AffineEnvironment.transform 12 138 env43258 = env43259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env43258 == env43259) = true)

theorem identity43259 : scanCanonicalize (H12AffineFastState.compose env43259 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound43259 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env43260 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,138,675,560,4272,4096,2185,5,561,4096,4249,4787,656,3,4787,2587,4635,4634,2707,4116,4112,173,691,185,512]

theorem envBound43260 : H12AffineFastState.Bounded env43260 := by
  intro p hp
  have h : env43260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43259_43260 : H12AffineEnvironment.transform 14 560 env43259 = env43260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env43259 == env43260) = true)

theorem identity43260 : scanCanonicalize (H12AffineFastState.compose env43260 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound43260 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env43261 : List Nat := [2,4,8,16,32,17,128,173,512,4,674,4096,138,675,560,4272,4096,555,5,561,4096,4249,4787,656,3,4787,185,4635,4634,49,4116,4112,173,691,185,512]

theorem envBound43261 : H12AffineFastState.Bounded env43261 := by
  intro p hp
  have h : env43261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43260_43261 : H12AffineEnvironment.transform 10 674 env43260 = env43261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env43260 == env43261) = true)

theorem identity43261 : scanCanonicalize (H12AffineFastState.compose env43261 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound43261 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43262 : List Nat := [2,4,8,16,32,17,128,173,512,4,674,555,138,675,560,667,555,555,5,561,555,690,152,656,3,152,185,48,49,49,575,571,173,691,185,512]

theorem envBound43262 : H12AffineFastState.Bounded env43262 := by
  intro p hp
  have h : env43262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43261_43262 : H12AffineEnvironment.transform 11 555 env43261 = env43262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env43261 == env43262) = true)

theorem identity43262 : scanCanonicalize (H12AffineFastState.compose env43262 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound43262 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env43263 : List Nat := [2,4,8,16,32,17,128,173,137,4,43,162,138,42,185,18,162,162,5,184,162,59,152,25,3,152,185,48,49,49,182,178,173,58,185,137]

theorem envBound43263 : H12AffineFastState.Bounded env43263 := by
  intro p hp
  have h : env43263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43262_43263 : H12AffineEnvironment.transform 8 137 env43262 = env43263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env43262 == env43263) = true)

theorem identity43263 : scanCanonicalize (H12AffineFastState.compose env43263 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43263 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43264 : List Nat := [2,4,8,16,32,17,9,36,0,4,43,43,3,42,48,18,43,43,5,49,43,59,17,25,3,17,48,48,49,49,63,59,36,58,48,0]

theorem envBound43264 : H12AffineFastState.Bounded env43264 := by
  intro p hp
  have h : env43264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43263_43264 : H12AffineEnvironment.transform 6 9 env43263 = env43264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43263 == env43264) = true)

theorem identity43264 : scanCanonicalize (H12AffineFastState.compose env43264 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43264 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43265 : List Nat := [2,4,8,10,32,11,9,36,0,4,43,43,3,42,42,8,43,43,5,43,43,33,11,3,3,11,42,42,43,43,37,33,36,32,42,0]

theorem envBound43265 : H12AffineFastState.Bounded env43265 := by
  intro p hp
  have h : env43265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43264_43265 : H12AffineEnvironment.transform 3 10 env43264 = env43265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43264 == env43265) = true)

theorem identity43265 : scanCanonicalize (H12AffineFastState.compose env43265 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound43265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43266 : List Nat := [2,4,8,10,12,11,9,8,0,4,7,7,3,6,6,8,7,7,5,7,7,13,11,3,3,11,6,6,7,7,9,13,8,12,6,0]

theorem envBound43266 : H12AffineFastState.Bounded env43266 := by
  intro p hp
  have h : env43266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43265_43266 : H12AffineEnvironment.transform 4 12 env43265 = env43266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env43265 == env43266) = true)

theorem identity43266 : scanCanonicalize (H12AffineFastState.compose env43266 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43266 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43267 : List Nat := [2,2,8,10,10,11,9,8,0,2,1,1,3,0,0,8,1,1,3,1,1,11,11,3,3,11,0,0,1,1,9,11,8,10,0,0]

theorem envBound43267 : H12AffineFastState.Bounded env43267 := by
  intro p hp
  have h : env43267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43266_43267 : H12AffineEnvironment.transform 1 2 env43266 = env43267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43266 == env43267) = true)

def env43268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245633,148800,545088,96347,16876544,16949355,256,676881,1344,525825]

theorem envBound43268 : H12AffineFastState.Bounded env43268 := by
  intro p hp
  have h : env43268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43154_43268 : H12AffineEnvironment.transform 26 17245633 env43154 = env43268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env43154 == env43268) = true)

theorem identity43268 : scanCanonicalize (H12AffineFastState.compose env43268 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound43268 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717114,533640,672785,906491,148800,545088,96347,750906,545105,256,676881,1344,525825]

theorem envBound43269 : H12AffineFastState.Bounded env43269 := by
  intro p hp
  have h : env43269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43268_43269 : H12AffineEnvironment.transform 23 717114 env43268 = env43269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env43268 == env43269) = true)

def env43270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58682,143496,20497,508155,148800,148800,96347,90426,148817,256,16401,1344,135681]

theorem envBound43270 : H12AffineFastState.Bounded env43270 := by
  intro p hp
  have h : env43270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43269_43270 : H12AffineEnvironment.transform 18 136192 env43269 = env43270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env43269 == env43270) = true)

def env43271 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143496,20497,508155,148716,148716,96347,90262,148733,172,16401,1260,135681]

theorem envBound43271 : H12AffineFastState.Bounded env43271 := by
  intro p hp
  have h : env43271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43270_43271 : H12AffineEnvironment.transform 7 172 env43270 = env43271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43270 == env43271) = true)

def env43272 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143496,20497,508075,148668,148668,96267,90262,148653,172,16401,1212,135681]

theorem envBound43272 : H12AffineFastState.Bounded env43272 := by
  intro p hp
  have h : env43272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43271_43272 : H12AffineEnvironment.transform 5 16 env43271 = env43272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43271 == env43272) = true)

theorem identity43272 : scanCanonicalize (H12AffineFastState.compose env43272 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound43272 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43273 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,58518,32808,20497,356363,62492,62492,96267,90262,62477,172,16401,1212,41633]

theorem envBound43273 : H12AffineFastState.Bounded env43273 := by
  intro p hp
  have h : env43273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43272_43273 : H12AffineEnvironment.transform 16 45216 env43272 = env43273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env43272 == env43273) = true)

theorem identity43273 : scanCanonicalize (H12AffineFastState.compose env43273 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound43273 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43274 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4096,61569,61617,58518,32808,20497,96387,62492,62492,96267,90262,62477,172,16401,1212,41633]

theorem envBound43274 : H12AffineFastState.Bounded env43274 := by
  intro p hp
  have h : env43274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43273_43274 : H12AffineEnvironment.transform 17 2184 env43273 = env43274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env43273 == env43274) = true)

theorem identity43274 : scanCanonicalize (H12AffineFastState.compose env43274 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound43274 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43275 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,65536,20665,2184,17593,24600,4096,4248,4264,1167,24625,20497,96387,5125,5125,96267,90262,5140,172,16401,1212,17080]

theorem envBound43275 : H12AffineFastState.Bounded env43275 := by
  intro p hp
  have h : env43275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43274_43275 : H12AffineEnvironment.transform 14 24601 env43274 = env43275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env43274 == env43275) = true)

theorem identity43275 : scanCanonicalize (H12AffineFastState.compose env43275 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound43275 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env43276 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,13374,20665,2184,17593,24600,4096,4248,4264,1167,24625,20497,19645,5125,5125,19509,21672,5140,172,16401,1212,17080]

theorem envBound43276 : H12AffineFastState.Bounded env43276 := by
  intro p hp
  have h : env43276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43275_43276 : H12AffineEnvironment.transform 15 13374 env43275 = env43276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env43275 == env43276) = true)

theorem identity43276 : scanCanonicalize (H12AffineFastState.compose env43276 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound43276 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env43277 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3613,16384,19972,6691,20665,2184,17593,19973,4096,4248,4264,1167,20012,20497,19645,5125,5125,19509,21672,5140,172,16401,1212,17080]

theorem envBound43277 : H12AffineFastState.Bounded env43277 := by
  intro p hp
  have h : env43277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43276_43277 : H12AffineEnvironment.transform 12 3613 env43276 = env43277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env43276 == env43277) = true)

theorem identity43277 : scanCanonicalize (H12AffineFastState.compose env43277 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 3772) := by decide +kernel

theorem selectedBound43277 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env43278 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3772,3613,16384,19972,1183,19973,2184,17593,19973,3772,3620,3604,1167,20012,20141,19645,2745,2745,19509,18964,2728,172,16401,1212,17080]

theorem envBound43278 : H12AffineFastState.Bounded env43278 := by
  intro p hp
  have h : env43278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43277_43278 : H12AffineEnvironment.transform 11 3772 env43277 = env43278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3772 env43277 == env43278) = true)

theorem identity43278 : scanCanonicalize (H12AffineFastState.compose env43278 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound43278 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env43279 : List Nat := [2,4,8,16,32,16,128,172,162,1024,2048,3102,3263,16384,19622,1183,19623,2184,17593,19623,3102,3206,3254,1167,19598,19471,19645,2075,2075,19509,18614,2058,172,16401,1212,16410]

theorem envBound43279 : H12AffineFastState.Bounded env43279 := by
  intro p hp
  have h : env43279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43278_43279 : H12AffineEnvironment.transform 8 162 env43278 = env43279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env43278 == env43279) = true)

theorem identity43279 : scanCanonicalize (H12AffineFastState.compose env43279 (packedSelected [6,7,9,13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43279 : packedSelected [6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env43280 : List Nat := [2,4,8,16,32,16,8,36,42,1024,2048,3102,3127,16384,19502,1047,19503,2048,17457,19503,3102,3086,3134,1031,19462,19471,19509,2075,2075,19509,18494,2058,36,16401,1076,16410]

theorem envBound43280 : H12AffineFastState.Bounded env43280 := by
  intro p hp
  have h : env43280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43279_43280 : H12AffineEnvironment.transform 6 8 env43279 = env43280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43279 == env43280) = true)

theorem identity43280 : scanCanonicalize (H12AffineFastState.compose env43280 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1070) := by decide +kernel

theorem selectedBound43280 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43281 : List Nat := [2,4,8,16,32,16,8,36,42,1024,2048,3102,3127,1070,2048,1047,2049,2048,31,2049,3102,3086,3134,1031,2088,2081,2075,2075,2075,2075,3088,2058,36,1087,1076,1076]

theorem envBound43281 : H12AffineFastState.Bounded env43281 := by
  intro p hp
  have h : env43281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43280_43281 : H12AffineEnvironment.transform 13 1070 env43280 = env43281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1070 env43280 == env43281) = true)

theorem identity43281 : scanCanonicalize (H12AffineFastState.compose env43281 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound43281 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env43282 : List Nat := [2,4,8,16,32,16,8,36,42,1024,1071,49,24,1070,1071,1047,1070,1071,31,1070,49,33,17,1031,1031,1038,1076,1076,1076,1076,63,1061,36,1087,1076,1076]

theorem envBound43282 : H12AffineFastState.Bounded env43282 := by
  intro p hp
  have h : env43282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43281_43282 : H12AffineEnvironment.transform 10 1071 env43281 = env43282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env43281 == env43282) = true)

theorem identity43282 : scanCanonicalize (H12AffineFastState.compose env43282 (packedSelected [5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43282 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env43283 : List Nat := [2,4,8,16,17,16,8,21,27,1024,1054,0,24,1055,1054,1047,1055,1054,31,1055,0,16,17,1031,1031,1038,1029,1029,1029,1029,14,1044,21,1038,1029,1029]

theorem envBound43283 : H12AffineFastState.Bounded env43283 := by
  intro p hp
  have h : env43283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43282_43283 : H12AffineEnvironment.transform 4 17 env43282 = env43283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43282 == env43283) = true)

theorem identity43283 : scanCanonicalize (H12AffineFastState.compose env43283 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43283 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43284 : List Nat := [2,4,8,16,17,16,8,21,27,4,26,0,24,27,26,19,27,26,31,27,0,16,17,3,3,10,1,1,1,1,14,16,21,10,1,1]

theorem envBound43284 : H12AffineFastState.Bounded env43284 := by
  intro p hp
  have h : env43284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43283_43284 : H12AffineEnvironment.transform 9 4 env43283 = env43284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43283 == env43284) = true)

theorem identity43284 : scanCanonicalize (H12AffineFastState.compose env43284 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound43284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43285 : List Nat := [2,4,8,13,12,13,8,8,6,4,7,0,5,6,7,14,6,7,2,6,0,13,12,3,3,10,1,1,1,1,14,13,8,10,1,1]

theorem envBound43285 : H12AffineFastState.Bounded env43285 := by
  intro p hp
  have h : env43285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43284_43285 : H12AffineEnvironment.transform 3 13 env43284 = env43285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env43284 == env43285) = true)

def env43286 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143496,20497,508074,148669,148669,96266,90262,148652,172,16401,1213,135681]

theorem envBound43286 : H12AffineFastState.Bounded env43286 := by
  intro p hp
  have h : env43286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43271_43286 : H12AffineEnvironment.transform 5 17 env43271 = env43286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43271 == env43286) = true)

theorem identity43286 : scanCanonicalize (H12AffineFastState.compose env43286 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound43286 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43287 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,58518,143496,20497,120866,148669,148669,96266,90262,148652,172,16401,1213,135681]

theorem envBound43287 : H12AffineFastState.Bounded env43287 := by
  intro p hp
  have h : env43287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43286_43287 : H12AffineEnvironment.transform 17 137352 env43286 = env43287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env43286 == env43287) = true)

theorem identity43287 : scanCanonicalize (H12AffineFastState.compose env43287 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound43287 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env43288 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4096,61568,46092,58518,50324,20497,120866,45217,45217,96266,90262,45232,172,16401,1213,58909]

theorem envBound43288 : H12AffineFastState.Bounded env43288 := by
  intro p hp
  have h : env43288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43287_43288 : H12AffineEnvironment.transform 16 62492 env43287 = env43288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env43287 == env43288) = true)

theorem identity43288 : scanCanonicalize (H12AffineFastState.compose env43288 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound43288 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43289 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,12347,62492,60564,57372,32769,4096,61568,46092,58518,50324,20497,59417,45217,45217,18481,20653,45232,172,16401,1213,58909]

theorem envBound43289 : H12AffineFastState.Bounded env43289 := by
  intro p hp
  have h : env43289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43288_43289 : H12AffineEnvironment.transform 15 12347 env43288 = env43289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env43288 == env43289) = true)

theorem identity43289 : scanCanonicalize (H12AffineFastState.compose env43289 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 7732) := by decide +kernel

theorem selectedBound43289 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env43290 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,7732,12347,27176,29344,32296,7733,4096,28340,10808,31394,23200,20497,30253,11925,11925,18481,20653,11908,172,16401,1213,30761]

theorem envBound43290 : H12AffineFastState.Bounded env43290 := by
  intro p hp
  have h : env43290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43289_43290 : H12AffineEnvironment.transform 14 7732 env43289 = env43290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7732 env43289 == env43290) = true)

theorem identity43290 : scanCanonicalize (H12AffineFastState.compose env43290 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 15916) := by decide +kernel

theorem selectedBound43290 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env43291 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,15916,7732,12347,5124,3212,4,7733,4096,4248,10808,1166,9356,11837,2049,11925,11925,13853,11905,11908,172,15933,1213,1541]

theorem envBound43291 : H12AffineFastState.Bounded env43291 := by
  intro p hp
  have h : env43291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43290_43291 : H12AffineEnvironment.transform 13 15916 env43290 = env43291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15916 env43290 == env43291) = true)

theorem identity43291 : scanCanonicalize (H12AffineFastState.compose env43291 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound43291 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env43292 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,697,8192,11413,3213,8834,1725,3212,4,3212,697,545,10808,1166,9356,11837,2049,11925,11925,9380,11905,11908,172,11396,1213,1541]

theorem envBound43292 : H12AffineFastState.Bounded env43292 := by
  intro p hp
  have h : env43292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43291_43292 : H12AffineEnvironment.transform 11 697 env43291 = env43292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env43291 == env43292) = true)

theorem identity43292 : scanCanonicalize (H12AffineFastState.compose env43292 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound43292 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env43293 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,697,2,3223,3213,640,1725,3212,4,3212,697,545,2618,1166,1166,3647,2049,3735,3735,1190,3715,3718,172,3206,1213,1541]

theorem envBound43293 : H12AffineFastState.Bounded env43293 := by
  intro p hp
  have h : env43293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43292_43293 : H12AffineEnvironment.transform 12 2 env43292 = env43293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env43292 == env43293) = true)

theorem identity43293 : scanCanonicalize (H12AffineFastState.compose env43293 (packedSelected [3,4,6,8,9,17] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound43293 : packedSelected [3,4,6,8,9,17] rootPS < 2^1333 := by decide +kernel

def env43294 : List Nat := [2,4,8,16,32,17,128,172,512,653,2048,697,2,2586,2560,640,48,2561,4,2561,697,545,2618,515,515,2226,2049,2074,2074,555,2062,2059,172,2571,560,136]

theorem envBound43294 : H12AffineFastState.Bounded env43294 := by
  intro p hp
  have h : env43294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43293_43294 : H12AffineEnvironment.transform 9 653 env43293 = env43294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env43293 == env43294) = true)

theorem identity43294 : scanCanonicalize (H12AffineFastState.compose env43294 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound43294 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env43295 : List Nat := [2,4,8,16,32,17,128,172,512,653,554,697,2,48,42,640,48,43,4,43,697,545,16,515,515,664,555,560,560,555,548,545,172,33,560,136]

theorem envBound43295 : H12AffineFastState.Bounded env43295 := by
  intro p hp
  have h : env43295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43294_43295 : H12AffineEnvironment.transform 10 554 env43294 = env43295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env43294 == env43295) = true)

theorem identity43295 : scanCanonicalize (H12AffineFastState.compose env43295 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43295 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env43296 : List Nat := [2,4,8,16,32,17,8,36,512,517,554,561,2,48,42,520,48,43,4,43,561,545,16,515,515,528,555,560,560,555,548,545,36,33,560,0]

theorem envBound43296 : H12AffineFastState.Bounded env43296 := by
  intro p hp
  have h : env43296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43295_43296 : H12AffineEnvironment.transform 6 8 env43295 = env43296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43295 == env43296) = true)

theorem identity43296 : scanCanonicalize (H12AffineFastState.compose env43296 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43296 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43297 : List Nat := [2,2,8,16,32,17,8,34,512,515,554,561,2,48,42,520,48,43,2,43,561,545,16,515,515,528,555,560,560,555,546,545,34,33,560,0]

theorem envBound43297 : H12AffineFastState.Bounded env43297 := by
  intro p hp
  have h : env43297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43296_43297 : H12AffineEnvironment.transform 1 2 env43296 = env43297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43296 == env43297) = true)

def env43298 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143496,20497,508155,148717,148717,96347,90263,148732,173,16401,1261,135681]

theorem envBound43298 : H12AffineFastState.Bounded env43298 := by
  intro p hp
  have h : env43298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43270_43298 : H12AffineEnvironment.transform 7 173 env43270 = env43298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43270 == env43298) = true)

def env43299 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143496,20497,508075,148669,148669,96267,90263,148652,173,16401,1213,135681]

theorem envBound43299 : H12AffineFastState.Bounded env43299 := by
  intro p hp
  have h : env43299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43298_43299 : H12AffineEnvironment.transform 5 16 env43298 = env43299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43298 == env43299) = true)

theorem identity43299 : scanCanonicalize (H12AffineFastState.compose env43299 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound43299 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43300 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61569,115855,58519,111638,20497,279605,114723,114723,96267,90263,114738,173,16401,1213,104095]

theorem envBound43300 : H12AffineFastState.Bounded env43300 := by
  intro p hp
  have h : env43300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43299_43300 : H12AffineEnvironment.transform 16 99486 env43299 = env43300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env43299 == env43300) = true)

theorem identity43300 : scanCanonicalize (H12AffineFastState.compose env43300 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43300 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env43301 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,65536,98458,262144,102558,32769,4096,61569,114827,57491,110610,20497,278577,114723,114723,96267,90263,114738,173,16401,185,103067]

theorem envBound43301 : H12AffineFastState.Bounded env43301 := by
  intro p hp
  have h : env43301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43300_43301 : H12AffineEnvironment.transform 9 4 env43300 = env43301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43300 == env43301) = true)

theorem identity43301 : scanCanonicalize (H12AffineFastState.compose env43301 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound43301 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43302 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,37019,4097,262144,5,32769,4096,61569,20496,57491,8329,20497,278577,20664,20664,59536,61452,20649,173,16401,185,512]

theorem envBound43302 : H12AffineFastState.Bounded env43302 := by
  intro p hp
  have h : env43302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43301_43302 : H12AffineEnvironment.transform 15 37019 env43301 = env43302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env43301 == env43302) = true)

theorem identity43302 : scanCanonicalize (H12AffineFastState.compose env43302 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound43302 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43303 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,32768,37019,4097,262144,5,32769,4096,45113,4264,41003,8329,4265,262281,4096,4096,43048,45236,4113,173,169,185,512]

theorem envBound43303 : H12AffineFastState.Bounded env43303 := by
  intro p hp
  have h : env43303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43302_43303 : H12AffineEnvironment.transform 13 184 env43302 = env43303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env43302 == env43303) = true)

theorem identity43303 : scanCanonicalize (H12AffineFastState.compose env43303 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4744) := by decide +kernel

theorem selectedBound43303 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43304 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,4744,531,4097,262144,5,4745,4096,8881,4264,12963,8329,4265,262281,4096,4096,15008,8764,4113,173,169,185,512]

theorem envBound43304 : H12AffineFastState.Bounded env43304 := by
  intro p hp
  have h : env43304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43303_43304 : H12AffineEnvironment.transform 14 4744 env43303 = env43304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4744 env43303 == env43304) = true)

theorem identity43304 : scanCanonicalize (H12AffineFastState.compose env43304 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 10776) := by decide +kernel

theorem selectedBound43304 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env43305 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,4744,531,4097,10776,5,4745,4096,8881,4264,12963,8329,4265,10897,4096,4096,15008,8764,4113,173,169,185,512]

theorem envBound43305 : H12AffineFastState.Bounded env43305 := by
  intro p hp
  have h : env43305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43304_43305 : H12AffineEnvironment.transform 17 10776 env43304 = env43305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10776 env43304 == env43305) = true)

theorem identity43305 : scanCanonicalize (H12AffineFastState.compose env43305 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound43305 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43306 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2099,184,4744,531,4097,555,5,4745,4096,2690,4264,6800,2234,4265,674,4096,4096,4755,2575,4113,173,169,185,512]

theorem envBound43306 : H12AffineFastState.Bounded env43306 := by
  intro p hp
  have h : env43306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43305_43306 : H12AffineEnvironment.transform 12 2099 env43305 = env43306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env43305 == env43306) = true)

theorem identity43306 : scanCanonicalize (H12AffineFastState.compose env43306 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound43306 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env43307 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,2586,2099,184,2194,531,2587,555,5,2195,2586,2690,2738,138,2234,2739,674,2586,2586,2185,2575,2571,173,169,185,512]

theorem envBound43307 : H12AffineFastState.Bounded env43307 := by
  intro p hp
  have h : env43307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43306_43307 : H12AffineEnvironment.transform 11 2586 env43306 = env43307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env43306 == env43307) = true)

theorem identity43307 : scanCanonicalize (H12AffineFastState.compose env43307 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound43307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43308 : List Nat := [2,4,8,16,32,16,128,173,512,4,513,27,562,184,659,531,26,555,5,658,27,131,179,138,699,178,674,27,27,648,14,10,173,169,185,512]

theorem envBound43308 : H12AffineFastState.Bounded env43308 := by
  intro p hp
  have h : env43308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43307_43308 : H12AffineEnvironment.transform 10 513 env43307 = env43308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env43307 == env43308) = true)

theorem identity43308 : scanCanonicalize (H12AffineFastState.compose env43308 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43308 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43309 : List Nat := [2,4,8,10,32,10,128,173,512,4,513,1,552,162,649,521,0,555,5,648,1,131,169,138,673,168,674,1,1,648,14,10,173,169,163,512]

theorem envBound43309 : H12AffineFastState.Bounded env43309 := by
  intro p hp
  have h : env43309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43308_43309 : H12AffineEnvironment.transform 3 10 env43308 = env43309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43308 == env43309) = true)

theorem identity43309 : scanCanonicalize (H12AffineFastState.compose env43309 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound43309 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43310 : List Nat := [2,4,8,10,32,10,34,15,512,4,513,1,552,0,555,521,0,555,5,554,1,33,11,40,515,10,512,1,1,554,14,10,15,11,1,512]

theorem envBound43310 : H12AffineFastState.Bounded env43310 := by
  intro p hp
  have h : env43310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43309_43310 : H12AffineEnvironment.transform 6 34 env43309 = env43310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env43309 == env43310) = true)

theorem identity43310 : scanCanonicalize (H12AffineFastState.compose env43310 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound43310 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43311 : List Nat := [2,4,8,10,32,10,34,15,12,4,13,1,36,0,39,5,0,39,5,38,1,33,11,40,15,10,12,1,1,38,14,10,15,11,1,12]

theorem envBound43311 : H12AffineFastState.Bounded env43311 := by
  intro p hp
  have h : env43311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43310_43311 : H12AffineEnvironment.transform 8 12 env43310 = env43311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env43310 == env43311) = true)

theorem identity43311 : scanCanonicalize (H12AffineFastState.compose env43311 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43311 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43312 : List Nat := [2,4,5,7,32,7,34,2,1,4,0,1,36,0,39,5,0,39,5,38,1,33,6,37,2,7,1,1,1,38,3,7,2,6,1,1]

theorem envBound43312 : H12AffineFastState.Bounded env43312 := by
  intro p hp
  have h : env43312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43311_43312 : H12AffineEnvironment.transform 2 5 env43311 = env43312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43311 == env43312) = true)

def env43313 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143496,20497,508074,148668,148668,96266,90263,148653,173,16401,1212,135681]

theorem envBound43313 : H12AffineFastState.Bounded env43313 := by
  intro p hp
  have h : env43313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43298_43313 : H12AffineEnvironment.transform 5 17 env43298 = env43313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43298 == env43313) = true)

theorem identity43313 : scanCanonicalize (H12AffineFastState.compose env43313 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound43313 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43314 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61568,147472,58519,143496,20497,60445,148668,148668,96266,90263,148653,173,16401,1212,135681]

theorem envBound43314 : H12AffineFastState.Bounded env43314 := by
  intro p hp
  have h : env43314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43313_43314 : H12AffineEnvironment.transform 17 208055 env43313 = env43314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env43313 == env43314) = true)

theorem identity43314 : scanCanonicalize (H12AffineFastState.compose env43314 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound43314 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env43315 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4096,61568,147472,58519,143496,20497,60445,148668,148668,43048,45237,148653,173,16401,1212,135681]

theorem envBound43315 : H12AffineFastState.Bounded env43315 := by
  intro p hp
  have h : env43315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43314_43315 : H12AffineEnvironment.transform 15 53282 env43314 = env43315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env43314 == env43315) = true)

theorem identity43315 : scanCanonicalize (H12AffineFastState.compose env43315 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound43315 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43316 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4096,61568,5293,58519,25653,20497,60445,4097,4097,43048,45237,4112,173,16401,1212,18108]

theorem envBound43316 : H12AffineFastState.Bounded env43316 := by
  intro p hp
  have h : env43316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43315_43316 : H12AffineEnvironment.transform 16 21693 env43315 = env43316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env43315 == env43316) = true)

theorem identity43316 : scanCanonicalize (H12AffineFastState.compose env43316 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound43316 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env43317 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,37018,5125,43048,5,32769,4096,45112,5293,42031,9357,4265,44197,4097,4097,43048,45237,4112,173,169,1212,1540]

theorem envBound43317 : H12AffineFastState.Bounded env43317 := by
  intro p hp
  have h : env43317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43316_43317 : H12AffineEnvironment.transform 13 184 env43316 = env43317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env43316 == env43317) = true)

theorem identity43317 : scanCanonicalize (H12AffineFastState.compose env43317 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(14+1) ^^^ 4793) := by decide +kernel

theorem selectedBound43317 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env43318 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,4793,547,5125,14993,5,4792,4096,8833,5293,13974,9357,4265,15900,4097,4097,14993,8716,4112,173,169,1212,1540]

theorem envBound43318 : H12AffineFastState.Bounded env43318 := by
  intro p hp
  have h : env43318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43317_43318 : H12AffineEnvironment.transform 14 4793 env43317 = env43318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4793 env43317 == env43318) = true)

theorem identity43318 : scanCanonicalize (H12AffineFastState.compose env43318 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound43318 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env43319 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1175,4096,8192,184,4793,547,5125,13830,5,4792,4096,8833,5293,13974,9357,4265,12939,4097,4097,13830,8716,4112,173,169,1212,1540]

theorem envBound43319 : H12AffineFastState.Bounded env43319 := by
  intro p hp
  have h : env43319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43318_43319 : H12AffineEnvironment.transform 10 1175 env43318 = env43319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env43318 == env43319) = true)

theorem identity43319 : scanCanonicalize (H12AffineFastState.compose env43319 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound43319 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env43320 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1175,4096,5677,184,4793,547,5125,43,5,4792,4096,5292,5293,187,4768,4265,1190,4097,4097,43,5153,4112,173,169,1212,1540]

theorem envBound43320 : H12AffineFastState.Bounded env43320 := by
  intro p hp
  have h : env43320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43319_43320 : H12AffineEnvironment.transform 12 5677 env43319 = env43320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env43319 == env43320) = true)

theorem identity43320 : scanCanonicalize (H12AffineFastState.compose env43320 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

end H12CloudChart2