import H12CloudChart2Data153

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound38409 : H12AffineFastState.Bounded env38409 := by
  intro p hp
  have h : env38409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38394_38409 : H12AffineEnvironment.transform 5 17 env38394 = env38409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38394 == env38409) = true)

theorem identity38409 : scanCanonicalize (H12AffineFastState.compose env38409 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound38409 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38410 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61568,147473,58518,143496,20496,60444,148668,148668,96266,90262,131088,172,1197,1212,135681]

theorem envBound38410 : H12AffineFastState.Bounded env38410 := by
  intro p hp
  have h : env38410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38409_38410 : H12AffineEnvironment.transform 17 208055 env38409 = env38410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env38409 == env38410) = true)

theorem identity38410 : scanCanonicalize (H12AffineFastState.compose env38410 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound38410 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env38411 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4096,61568,147473,58518,143496,20496,60444,148668,148668,43048,45236,131088,172,1197,1212,135681]

theorem envBound38411 : H12AffineFastState.Bounded env38411 := by
  intro p hp
  have h : env38411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38410_38411 : H12AffineEnvironment.transform 15 53282 env38410 = env38411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env38410 == env38411) = true)

theorem identity38411 : scanCanonicalize (H12AffineFastState.compose env38411 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound38411 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38412 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4096,61568,5292,58518,25653,20496,60444,4097,4097,43048,45236,21677,172,1197,1212,18108]

theorem envBound38412 : H12AffineFastState.Bounded env38412 := by
  intro p hp
  have h : env38412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38411_38412 : H12AffineEnvironment.transform 16 21693 env38411 = env38412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env38411 == env38412) = true)

theorem identity38412 : scanCanonicalize (H12AffineFastState.compose env38412 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38412 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env38413 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,184,32768,37018,5125,43048,5,32769,4096,45112,5292,42030,9357,4264,44196,4097,4097,43048,45236,5141,172,1197,1212,1540]

theorem envBound38413 : H12AffineFastState.Bounded env38413 := by
  intro p hp
  have h : env38413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38412_38413 : H12AffineEnvironment.transform 13 184 env38412 = env38413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38412 == env38413) = true)

theorem identity38413 : scanCanonicalize (H12AffineFastState.compose env38413 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound38413 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env38414 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,672,184,32768,37018,5125,35464,5,32769,4096,37528,5292,34446,1581,4264,36356,4097,4097,35464,37396,5141,172,1197,1212,1540]

theorem envBound38414 : H12AffineFastState.Bounded env38414 := by
  intro p hp
  have h : env38414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38413_38414 : H12AffineEnvironment.transform 12 672 env38413 = env38414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env38413 == env38414) = true)

theorem identity38414 : scanCanonicalize (H12AffineFastState.compose env38414 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound38414 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env38415 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2091,672,184,32768,34993,3118,35464,5,32769,2091,35507,3207,34446,1581,2179,36356,2090,2090,35464,35391,3134,172,1197,1212,1540]

theorem envBound38415 : H12AffineFastState.Bounded env38415 := by
  intro p hp
  have h : env38415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38414_38415 : H12AffineEnvironment.transform 11 2091 env38414 = env38415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env38414 == env38415) = true)

theorem identity38415 : scanCanonicalize (H12AffineFastState.compose env38415 (packedSelected [0,1,2,4,5,6,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound38415 : packedSelected [0,1,2,4,5,6,11,13,16] rootPS < 2^1333 := by decide +kernel

def env38416 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2091,672,184,2723,530,3118,43,5,2722,2091,16,3207,3117,1581,2179,1191,2090,2090,43,156,3134,172,1197,1212,1540]

theorem envBound38416 : H12AffineFastState.Bounded env38416 := by
  intro p hp
  have h : env38416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38415_38416 : H12AffineEnvironment.transform 14 2723 env38415 = env38416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env38415 == env38416) = true)

theorem identity38416 : scanCanonicalize (H12AffineFastState.compose env38416 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound38416 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38417 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1191,1164,672,184,1540,530,137,43,5,1541,1164,16,32,138,1581,1060,1191,1165,1165,43,156,153,172,1197,1212,1540]

theorem envBound38417 : H12AffineFastState.Bounded env38417 := by
  intro p hp
  have h : env38417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38416_38417 : H12AffineEnvironment.transform 10 1191 env38416 = env38417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env38416 == env38417) = true)

theorem identity38417 : scanCanonicalize (H12AffineFastState.compose env38417 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound38417 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env38418 : List Nat := [2,4,8,16,32,17,128,172,512,663,560,539,672,184,147,530,137,43,5,146,539,16,32,138,186,691,560,538,538,43,156,153,172,570,555,147]

theorem envBound38418 : H12AffineFastState.Bounded env38418 := by
  intro p hp
  have h : env38418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38417_38418 : H12AffineEnvironment.transform 9 663 env38417 = env38418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env38417 == env38418) = true)

theorem identity38418 : scanCanonicalize (H12AffineFastState.compose env38418 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound38418 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env38419 : List Nat := [2,4,8,16,32,17,30,50,512,521,560,539,574,38,13,530,23,43,5,12,539,16,32,20,36,557,560,538,538,43,2,7,50,570,555,13]

theorem envBound38419 : H12AffineFastState.Bounded env38419 := by
  intro p hp
  have h : env38419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38418_38419 : H12AffineEnvironment.transform 6 30 env38418 = env38419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env38418 == env38419) = true)

theorem identity38419 : scanCanonicalize (H12AffineFastState.compose env38419 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38419 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38420 : List Nat := [2,4,8,16,7,17,30,21,512,521,535,539,537,1,13,530,23,12,5,12,539,16,7,20,3,522,535,538,538,12,2,7,21,541,524,13]

theorem envBound38420 : H12AffineFastState.Bounded env38420 := by
  intro p hp
  have h : env38420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38419_38420 : H12AffineEnvironment.transform 4 7 env38419 = env38420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38419 == env38420) = true)

theorem identity38420 : scanCanonicalize (H12AffineFastState.compose env38420 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound38420 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38421 : List Nat := [2,4,8,16,7,17,30,21,23,30,0,12,14,1,13,5,23,12,5,12,12,16,7,20,3,29,0,13,13,12,2,7,21,10,27,13]

theorem envBound38421 : H12AffineFastState.Bounded env38421 := by
  intro p hp
  have h : env38421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38420_38421 : H12AffineEnvironment.transform 8 23 env38420 = env38421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env38420 == env38421) = true)

theorem identity38421 : scanCanonicalize (H12AffineFastState.compose env38421 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38421 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env38422 : List Nat := [2,4,4,16,7,17,18,21,23,18,0,0,2,1,1,5,23,0,5,0,0,16,7,20,3,17,0,1,1,0,2,7,21,6,23,1]

theorem envBound38422 : H12AffineFastState.Bounded env38422 := by
  intro p hp
  have h : env38422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38421_38422 : H12AffineEnvironment.transform 2 4 env38421 = env38422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38421 == env38422) = true)

theorem identity38422 : scanCanonicalize (H12AffineFastState.compose env38422 (packedSelected [0,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound38422 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env38423 : List Nat := [2,4,4,7,7,6,5,2,0,5,0,0,2,1,1,5,0,0,5,0,0,7,7,3,3,6,0,1,1,0,2,7,2,6,0,1]

theorem envBound38423 : H12AffineFastState.Bounded env38423 := by
  intro p hp
  have h : env38423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38422_38423 : H12AffineEnvironment.transform 3 7 env38422 = env38423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env38422 == env38423) = true)

theorem identity38423 : scanCanonicalize (H12AffineFastState.compose env38423 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38424 : List Nat := [2,1,1,2,2,3,0,2,0,0,0,0,2,1,1,0,0,0,0,0,0,2,2,3,3,3,0,1,1,0,2,2,2,3,0,1]

theorem envBound38424 : H12AffineFastState.Bounded env38424 := by
  intro p hp
  have h : env38424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38423_38424 : H12AffineEnvironment.transform 1 1 env38423 = env38424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38423 == env38424) = true)

theorem identity38424 : scanCanonicalize (H12AffineFastState.compose env38424 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38424 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38425 : List Nat := [1,1,1,1,1,0,0,1,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,1,1,1,0,0,1]

theorem envBound38425 : H12AffineFastState.Bounded env38425 := by
  intro p hp
  have h : env38425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38424_38425 : H12AffineEnvironment.transform 0 1 env38424 = env38425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38424 == env38425) = true)

def env38426 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143496,20496,508154,148716,148716,96347,90263,131137,173,1196,1260,135681]

theorem envBound38426 : H12AffineFastState.Bounded env38426 := by
  intro p hp
  have h : env38426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38393_38426 : H12AffineEnvironment.transform 7 173 env38393 = env38426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38393 == env38426) = true)

def env38427 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143496,20496,508074,148668,148668,96267,90263,131089,173,1196,1212,135681]

theorem envBound38427 : H12AffineFastState.Bounded env38427 := by
  intro p hp
  have h : env38427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38426_38427 : H12AffineEnvironment.transform 5 16 env38426 = env38427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38426 == env38427) = true)

theorem identity38427 : scanCanonicalize (H12AffineFastState.compose env38427 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound38427 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38428 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,58519,32809,20496,356363,62493,62493,96267,90263,45232,173,1196,1212,41632]

theorem envBound38428 : H12AffineFastState.Bounded env38428 := by
  intro p hp
  have h : env38428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38427_38428 : H12AffineEnvironment.transform 16 45217 env38427 = env38428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env38427 == env38428) = true)

theorem identity38428 : scanCanonicalize (H12AffineFastState.compose env38428 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound38428 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38429 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4096,61569,61617,58519,32809,20496,96386,62493,62493,96267,90263,45232,173,1196,1212,41632]

theorem envBound38429 : H12AffineFastState.Bounded env38429 := by
  intro p hp
  have h : env38429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38428_38429 : H12AffineEnvironment.transform 17 2185 env38428 = env38429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env38428 == env38429) = true)

theorem identity38429 : scanCanonicalize (H12AffineFastState.compose env38429 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38429 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38430 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,65536,45217,2185,41124,32769,4096,61569,61617,57490,32809,20496,96386,61464,61464,96267,90263,45232,173,169,185,41632]

theorem envBound38430 : H12AffineFastState.Bounded env38430 := by
  intro p hp
  have h : env38430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38429_38430 : H12AffineEnvironment.transform 9 5 env38429 = env38430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38429 == env38430) = true)

theorem identity38430 : scanCanonicalize (H12AffineFastState.compose env38430 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound38430 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env38431 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,12346,45217,2185,41124,32769,4096,61569,61617,57490,32809,20496,18616,61464,61464,18481,20653,45232,173,169,185,41632]

theorem envBound38431 : H12AffineFastState.Bounded env38431 := by
  intro p hp
  have h : env38431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38430_38431 : H12AffineEnvironment.transform 15 12346 env38430 = env38431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env38430 == env38431) = true)

theorem identity38431 : scanCanonicalize (H12AffineFastState.compose env38431 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 25248) := by decide +kernel

theorem selectedBound38431 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env38432 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,25248,12346,20993,2185,16900,25249,4096,4641,4625,562,25225,20496,18616,4792,4792,18481,20653,21008,173,169,185,16384]

theorem envBound38432 : H12AffineFastState.Bounded env38432 := by
  intro p hp
  have h : env38432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38431_38432 : H12AffineEnvironment.transform 14 25248 env38431 = env38432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25248 env38431 == env38432) = true)

theorem identity38432 : scanCanonicalize (H12AffineFastState.compose env38432 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 6187) := by decide +kernel

theorem selectedBound38432 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env38433 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,6187,14987,12346,2602,2185,6703,14986,4096,4641,4625,562,15010,2107,4243,4792,4792,4122,2182,2619,173,169,185,6187]

theorem envBound38433 : H12AffineFastState.Bounded env38433 := by
  intro p hp
  have h : env38433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38432_38433 : H12AffineEnvironment.transform 13 6187 env38432 = env38433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6187 env38432 == env38433) = true)

theorem identity38433 : scanCanonicalize (H12AffineFastState.compose env38433 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound38433 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env38434 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2584,6187,4243,6690,2602,2185,6703,4242,4096,4641,4625,562,4282,2107,4243,4792,4792,4122,2182,2619,173,169,185,6187]

theorem envBound38434 : H12AffineFastState.Bounded env38434 := by
  intro p hp
  have h : env38434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38433_38434 : H12AffineEnvironment.transform 12 2584 env38433 = env38434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env38433 == env38434) = true)

theorem identity38434 : scanCanonicalize (H12AffineFastState.compose env38434 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound38434 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env38435 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,163,2584,2184,48,2689,2602,2185,2700,49,163,642,690,562,25,2107,48,539,539,185,2182,2619,173,169,185,2184]

theorem envBound38435 : H12AffineFastState.Bounded env38435 := by
  intro p hp
  have h : env38435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38434_38435 : H12AffineEnvironment.transform 11 163 env38434 = env38435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env38434 == env38435) = true)

theorem identity38435 : scanCanonicalize (H12AffineFastState.compose env38435 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound38435 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38436 : List Nat := [2,4,8,16,32,16,128,173,512,5,42,163,562,162,48,683,512,163,678,49,163,642,690,562,25,17,48,539,539,185,172,529,173,169,185,162]

theorem envBound38436 : H12AffineFastState.Bounded env38436 := by
  intro p hp
  have h : env38436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38435_38436 : H12AffineEnvironment.transform 10 42 env38435 = env38436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env38435 == env38436) = true)

theorem identity38436 : scanCanonicalize (H12AffineFastState.compose env38436 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38436 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env38437 : List Nat := [2,4,8,16,17,16,128,156,512,5,27,146,515,147,1,666,512,146,663,0,146,642,643,515,25,17,1,539,539,136,157,529,156,152,136,147]

theorem envBound38437 : H12AffineFastState.Bounded env38437 := by
  intro p hp
  have h : env38437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38436_38437 : H12AffineEnvironment.transform 4 17 env38436 = env38437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38436 == env38437) = true)

theorem identity38437 : scanCanonicalize (H12AffineFastState.compose env38437 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound38437 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env38438 : List Nat := [2,4,8,16,17,16,128,156,27,5,27,146,24,147,1,129,27,146,140,0,146,153,152,24,25,17,1,0,0,136,157,10,156,152,136,147]

theorem envBound38438 : H12AffineFastState.Bounded env38438 := by
  intro p hp
  have h : env38438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38437_38438 : H12AffineEnvironment.transform 8 27 env38437 = env38438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env38437 == env38438) = true)

theorem identity38438 : scanCanonicalize (H12AffineFastState.compose env38438 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38439 : List Nat := [2,4,8,16,17,16,18,14,27,5,27,0,24,1,1,19,27,0,30,0,0,11,10,24,25,17,1,0,0,26,15,10,14,10,26,1]

theorem envBound38439 : H12AffineFastState.Bounded env38439 := by
  intro p hp
  have h : env38439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38438_38439 : H12AffineEnvironment.transform 6 18 env38438 = env38439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38438 == env38439) = true)

theorem identity38439 : scanCanonicalize (H12AffineFastState.compose env38439 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38440 : List Nat := [2,4,5,16,17,16,18,3,22,5,22,0,21,1,1,19,22,0,19,0,0,6,7,21,20,17,1,0,0,23,2,7,3,7,23,1]

theorem envBound38440 : H12AffineFastState.Bounded env38440 := by
  intro p hp
  have h : env38440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38439_38440 : H12AffineEnvironment.transform 2 5 env38439 = env38440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38439 == env38440) = true)

theorem identity38440 : scanCanonicalize (H12AffineFastState.compose env38440 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound38440 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38441 : List Nat := [2,4,5,7,6,7,5,3,1,5,1,0,2,1,1,4,1,0,4,0,0,6,7,2,3,6,1,0,0,0,2,7,3,7,0,1]

theorem envBound38441 : H12AffineFastState.Bounded env38441 := by
  intro p hp
  have h : env38441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38440_38441 : H12AffineEnvironment.transform 3 7 env38440 = env38441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env38440 == env38441) = true)

def env38442 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143496,20496,508075,148669,148669,96266,90263,131088,173,1196,1213,135681]

theorem envBound38442 : H12AffineFastState.Bounded env38442 := by
  intro p hp
  have h : env38442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38426_38442 : H12AffineEnvironment.transform 5 17 env38426 = env38442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38426 == env38442) = true)

theorem identity38442 : scanCanonicalize (H12AffineFastState.compose env38442 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound38442 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38443 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,58519,143496,20496,120866,148669,148669,96266,90263,131088,173,1196,1213,135681]

theorem envBound38443 : H12AffineFastState.Bounded env38443 := by
  intro p hp
  have h : env38443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38442_38443 : H12AffineEnvironment.transform 17 137353 env38442 = env38443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env38442 == env38443) = true)

theorem identity38443 : scanCanonicalize (H12AffineFastState.compose env38443 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound38443 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env38444 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4096,61568,46092,58519,50325,20496,120866,45216,45216,96266,90263,62477,173,1196,1213,58908]

theorem envBound38444 : H12AffineFastState.Bounded env38444 := by
  intro p hp
  have h : env38444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38443_38444 : H12AffineEnvironment.transform 16 62493 env38443 = env38444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env38443 == env38444) = true)

theorem identity38444 : scanCanonicalize (H12AffineFastState.compose env38444 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound38444 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38445 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,37019,62493,60564,57373,32769,4096,61568,46092,58519,50325,20496,18617,45216,45216,59537,61452,62477,173,1196,1213,58908]

theorem envBound38445 : H12AffineFastState.Bounded env38445 := by
  intro p hp
  have h : env38445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38444_38445 : H12AffineEnvironment.transform 15 37019 env38444 = env38445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env38444 == env38445) = true)

theorem identity38445 : scanCanonicalize (H12AffineFastState.compose env38445 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 6800) := by decide +kernel

theorem selectedBound38445 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env38446 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6800,16384,32768,37019,52877,54788,55949,32769,4096,51728,36508,56839,50325,20496,18617,35376,35376,53761,51868,52893,173,1196,1213,56460]

theorem envBound38446 : H12AffineFastState.Bounded env38446 := by
  intro p hp
  have h : env38446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38445_38446 : H12AffineEnvironment.transform 12 6800 env38445 = env38446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6800 env38445 == env38446) = true)

theorem identity38446 : scanCanonicalize (H12AffineFastState.compose env38446 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38446 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env38447 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6800,184,32768,37019,36405,38588,39477,32769,4096,35496,36508,40639,33837,4264,2049,35376,35376,37561,35364,36389,173,1196,1213,39988]

theorem envBound38447 : H12AffineFastState.Bounded env38447 := by
  intro p hp
  have h : env38447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38446_38447 : H12AffineEnvironment.transform 13 184 env38446 = env38447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38446 == env38447) = true)

theorem identity38447 : scanCanonicalize (H12AffineFastState.compose env38447 (packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound38447 : packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env38448 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1076,3748,184,32768,33967,36405,33416,36353,32769,1076,35496,36508,35467,33837,1180,2049,35376,35376,34445,35364,36389,173,1196,1213,34816]

theorem envBound38448 : H12AffineFastState.Bounded env38448 := by
  intro p hp
  have h : env38448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38447_38448 : H12AffineEnvironment.transform 11 1076 env38447 = env38448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env38447 == env38448) = true)

theorem identity38448 : scanCanonicalize (H12AffineFastState.compose env38448 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound38448 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env38449 : List Nat := [2,4,8,16,32,17,128,173,512,31,2048,43,2747,184,32768,32944,35370,33416,35358,32769,43,35496,35459,35467,32818,131,2049,35376,35376,33426,35364,35386,173,179,162,34816]

theorem envBound38449 : H12AffineFastState.Bounded env38449 := by
  intro p hp
  have h : env38449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38448_38449 : H12AffineEnvironment.transform 9 31 env38448 = env38449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env38448 == env38449) = true)

theorem identity38449 : scanCanonicalize (H12AffineFastState.compose env38449 (packedSelected [5,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound38449 : packedSelected [5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env38450 : List Nat := [2,4,8,16,32,17,19,62,512,31,2048,43,2600,43,32768,32803,35370,33307,35358,32769,43,35387,35344,35352,32818,16,2049,35376,35376,33281,35364,35386,62,32,49,34816]

theorem envBound38450 : H12AffineFastState.Bounded env38450 := by
  intro p hp
  have h : env38450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38449_38450 : H12AffineEnvironment.transform 6 19 env38449 = env38450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env38449 == env38450) = true)

theorem identity38450 : scanCanonicalize (H12AffineFastState.compose env38450 (packedSelected [0,1,3,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 2075) := by decide +kernel

theorem selectedBound38450 : packedSelected [0,1,3,9,10] rootPS < 2^1333 := by decide +kernel

def env38451 : List Nat := [2,4,8,16,32,17,19,62,512,31,2048,43,2600,43,2075,2104,561,2560,517,2074,43,544,523,515,2089,16,2049,555,555,2586,575,545,62,32,49,27]

theorem envBound38451 : H12AffineFastState.Bounded env38451 := by
  intro p hp
  have h : env38451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38450_38451 : H12AffineEnvironment.transform 14 2075 env38450 = env38451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2075 env38450 == env38451) = true)

theorem identity38451 : scanCanonicalize (H12AffineFastState.compose env38451 (packedSelected [1,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound38451 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env38452 : List Nat := [2,4,8,16,32,17,19,62,512,31,49,43,537,43,42,9,561,561,517,43,43,544,523,515,24,16,48,555,555,555,575,545,62,32,49,27]

theorem envBound38452 : H12AffineFastState.Bounded env38452 := by
  intro p hp
  have h : env38452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38451_38452 : H12AffineEnvironment.transform 10 49 env38451 = env38452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env38451 == env38452) = true)

def env38453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58683,143497,20497,508155,148801,148800,96347,90427,131137,256,1281,1345,135680]

theorem envBound38453 : H12AffineFastState.Bounded env38453 := by
  intro p hp
  have h : env38453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38392_38453 : H12AffineEnvironment.transform 18 136193 env38392 = env38453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env38392 == env38453) = true)

def env38454 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143497,20497,508155,148717,148716,96347,90263,131137,172,1197,1261,135680]

theorem envBound38454 : H12AffineFastState.Bounded env38454 := by
  intro p hp
  have h : env38454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38453_38454 : H12AffineEnvironment.transform 7 172 env38453 = env38454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38453 == env38454) = true)

def env38455 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143497,20497,508075,148669,148668,96267,90263,131089,172,1197,1213,135680]

theorem envBound38455 : H12AffineFastState.Bounded env38455 := by
  intro p hp
  have h : env38455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38454_38455 : H12AffineEnvironment.transform 5 16 env38454 = env38455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38454 == env38455) = true)

theorem identity38455 : scanCanonicalize (H12AffineFastState.compose env38455 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound38455 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38456 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61569,147472,58519,143497,20497,60445,148669,148668,96267,90263,131089,172,1197,1213,135680]

theorem envBound38456 : H12AffineFastState.Bounded env38456 := by
  intro p hp
  have h : env38456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38455_38456 : H12AffineEnvironment.transform 17 208054 env38455 = env38456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env38455 == env38456) = true)

theorem identity38456 : scanCanonicalize (H12AffineFastState.compose env38456 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound38456 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env38457 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4096,61569,147472,58519,143497,20497,60445,148669,148668,43048,45236,131089,172,1197,1213,135680]

theorem envBound38457 : H12AffineFastState.Bounded env38457 := by
  intro p hp
  have h : env38457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38456_38457 : H12AffineEnvironment.transform 15 53283 env38456 = env38457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env38456 == env38457) = true)

theorem identity38457 : scanCanonicalize (H12AffineFastState.compose env38457 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound38457 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38458 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4096,61569,5293,58519,25652,20497,60445,4096,4097,43048,45236,21676,172,1197,1213,18109]

theorem envBound38458 : H12AffineFastState.Bounded env38458 := by
  intro p hp
  have h : env38458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38457_38458 : H12AffineEnvironment.transform 16 21693 env38457 = env38458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env38457 == env38458) = true)

theorem identity38458 : scanCanonicalize (H12AffineFastState.compose env38458 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38458 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env38459 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,32768,37019,5125,43048,4,32769,4096,45113,5293,42031,9356,4265,44197,4096,4097,43048,45236,5140,172,1197,1213,1541]

theorem envBound38459 : H12AffineFastState.Bounded env38459 := by
  intro p hp
  have h : env38459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38458_38459 : H12AffineEnvironment.transform 13 184 env38458 = env38459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38458 == env38459) = true)

theorem identity38459 : scanCanonicalize (H12AffineFastState.compose env38459 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound38459 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env38460 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,512,4763,5125,10792,4,513,4096,12857,5293,9775,9356,4265,11941,4096,4097,10792,12980,5140,172,1197,1213,1541]

theorem envBound38460 : H12AffineFastState.Bounded env38460 := by
  intro p hp
  have h : env38460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38459_38460 : H12AffineEnvironment.transform 14 512 env38459 = env38460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env38459 == env38460) = true)

theorem identity38460 : scanCanonicalize (H12AffineFastState.compose env38460 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 7823) := by decide +kernel

theorem selectedBound38460 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env38461 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7823,184,512,4763,5125,5287,4,513,4096,3254,5293,6304,6659,4265,4138,4096,4097,5287,3131,5140,172,1197,1213,1541]

theorem envBound38461 : H12AffineFastState.Bounded env38461 := by
  intro p hp
  have h : env38461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38460_38461 : H12AffineEnvironment.transform 12 7823 env38460 = env38461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7823 env38460 == env38461) = true)

theorem identity38461 : scanCanonicalize (H12AffineFastState.compose env38461 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound38461 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env38462 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,136,3591,184,512,531,1165,1071,4,513,136,3254,1061,2088,2699,33,162,136,137,1071,3131,1180,172,1197,1213,1541]

theorem envBound38462 : H12AffineFastState.Bounded env38462 := by
  intro p hp
  have h : env38462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38461_38462 : H12AffineEnvironment.transform 11 136 env38461 = env38462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env38461 == env38462) = true)

theorem identity38462 : scanCanonicalize (H12AffineFastState.compose env38462 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38462 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38463 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,136,2562,184,512,531,136,42,4,513,136,2227,32,2088,2699,33,162,136,137,42,2110,153,172,168,184,512]

theorem envBound38463 : H12AffineFastState.Bounded env38463 := by
  intro p hp
  have h : env38463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38462_38463 : H12AffineEnvironment.transform 9 5 env38462 = env38463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38462 == env38463) = true)

theorem identity38463 : scanCanonicalize (H12AffineFastState.compose env38463 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound38463 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38464 : List Nat := [2,4,8,16,32,16,128,172,512,5,674,136,160,184,512,531,136,42,4,513,136,529,32,650,41,33,162,136,137,42,668,153,172,168,184,512]

theorem envBound38464 : H12AffineFastState.Bounded env38464 := by
  intro p hp
  have h : env38464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38463_38464 : H12AffineEnvironment.transform 10 674 env38463 = env38464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env38463 == env38464) = true)

theorem identity38464 : scanCanonicalize (H12AffineFastState.compose env38464 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound38464 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38465 : List Nat := [2,4,8,16,32,16,19,63,512,5,561,27,51,43,512,531,27,42,4,513,27,529,32,537,41,33,49,27,26,42,527,10,63,59,43,512]

theorem envBound38465 : H12AffineFastState.Bounded env38465 := by
  intro p hp
  have h : env38465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38464_38465 : H12AffineEnvironment.transform 6 19 env38464 = env38465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env38464 == env38465) = true)

def env38466 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143497,20497,508074,148668,148669,96266,90263,131088,172,1197,1212,135680]

theorem envBound38466 : H12AffineFastState.Bounded env38466 := by
  intro p hp
  have h : env38466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38454_38466 : H12AffineEnvironment.transform 5 17 env38454 = env38466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38454 == env38466) = true)

theorem identity38466 : scanCanonicalize (H12AffineFastState.compose env38466 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound38466 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38467 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61568,115854,58519,111638,20497,279605,114723,114722,96266,90263,99471,172,1197,1212,104095]

theorem envBound38467 : H12AffineFastState.Bounded env38467 := by
  intro p hp
  have h : env38467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38466_38467 : H12AffineEnvironment.transform 16 99487 env38466 = env38467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env38466 == env38467) = true)

theorem identity38467 : scanCanonicalize (H12AffineFastState.compose env38467 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54311) := by decide +kernel

theorem selectedBound38467 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env38468 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,54311,20664,262144,17593,32769,4096,61568,4265,58519,24625,20497,279605,5124,5125,44077,46256,20648,172,1197,1212,17080]

theorem envBound38468 : H12AffineFastState.Bounded env38468 := by
  intro p hp
  have h : env38468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38467_38468 : H12AffineEnvironment.transform 15 54311 env38467 = env38468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54311 env38467 == env38468) = true)

theorem identity38468 : scanCanonicalize (H12AffineFastState.compose env38468 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38468 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38469 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,184,32768,38047,4096,262144,1025,32769,4096,45112,4265,42031,8329,4265,263309,5124,5125,44077,46256,4112,172,1197,1212,512]

theorem envBound38469 : H12AffineFastState.Bounded env38469 := by
  intro p hp
  have h : env38469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38468_38469 : H12AffineEnvironment.transform 13 184 env38468 = env38469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38468 == env38469) = true)

theorem identity38469 : scanCanonicalize (H12AffineFastState.compose env38469 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38469 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38470 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,32768,37018,4096,262144,4,32769,4096,45112,4265,41002,8329,4265,262280,4097,4096,43048,45237,4112,172,168,185,512]

theorem envBound38470 : H12AffineFastState.Bounded env38470 := by
  intro p hp
  have h : env38470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38469_38470 : H12AffineEnvironment.transform 9 5 env38469 = env38470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38469 == env38470) = true)

theorem identity38470 : scanCanonicalize (H12AffineFastState.compose env38470 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound38470 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38471 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4648,184,32768,37018,4096,262144,4,32769,4096,33296,4265,37378,4769,4265,262280,4097,4096,39424,33437,4112,172,168,185,512]

theorem envBound38471 : H12AffineFastState.Bounded env38471 := by
  intro p hp
  have h : env38471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38470_38471 : H12AffineEnvironment.transform 12 4648 env38470 = env38471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env38470 == env38471) = true)

theorem identity38471 : scanCanonicalize (H12AffineFastState.compose env38471 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound38471 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38472 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,184,656,184,32768,32802,184,262144,4,32769,184,33296,17,33466,537,17,262280,185,184,35512,33437,168,172,168,185,512]

theorem envBound38472 : H12AffineFastState.Bounded env38472 := by
  intro p hp
  have h : env38472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38471_38472 : H12AffineEnvironment.transform 11 184 env38471 = env38472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env38471 == env38472) = true)

theorem identity38472 : scanCanonicalize (H12AffineFastState.compose env38472 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound38472 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38473 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,184,656,184,32768,32802,184,554,4,32769,184,33296,17,33466,537,17,674,185,184,35512,33437,168,172,168,185,512]

theorem envBound38473 : H12AffineFastState.Bounded env38473 := by
  intro p hp
  have h : env38473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38472_38473 : H12AffineEnvironment.transform 17 554 env38472 = env38473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env38472 == env38473) = true)

def env38474 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143497,20497,508155,148716,148717,96347,90262,131137,173,1196,1260,135680]

theorem envBound38474 : H12AffineFastState.Bounded env38474 := by
  intro p hp
  have h : env38474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38453_38474 : H12AffineEnvironment.transform 7 173 env38453 = env38474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38453 == env38474) = true)

def env38475 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143497,20497,508075,148668,148669,96267,90262,131089,173,1196,1212,135680]

theorem envBound38475 : H12AffineFastState.Bounded env38475 := by
  intro p hp
  have h : env38475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38474_38475 : H12AffineEnvironment.transform 5 16 env38474 = env38475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38474 == env38475) = true)

theorem identity38475 : scanCanonicalize (H12AffineFastState.compose env38475 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound38475 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38476 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,58518,143497,20497,120867,148668,148669,96267,90262,131089,173,1196,1212,135680]

theorem envBound38476 : H12AffineFastState.Bounded env38476 := by
  intro p hp
  have h : env38476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38475_38476 : H12AffineEnvironment.transform 17 137352 env38475 = env38476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env38475 == env38476) = true)

theorem identity38476 : scanCanonicalize (H12AffineFastState.compose env38476 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound38476 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env38477 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4096,61569,46093,58518,50324,20497,120867,45217,45216,96267,90262,62476,173,1196,1212,58909]

theorem envBound38477 : H12AffineFastState.Bounded env38477 := by
  intro p hp
  have h : env38477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38476_38477 : H12AffineEnvironment.transform 16 62493 env38476 = env38477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env38476 == env38477) = true)

theorem identity38477 : scanCanonicalize (H12AffineFastState.compose env38477 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound38477 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38478 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,37018,62493,60565,57372,32769,4096,61569,46093,58518,50324,20497,18617,45217,45216,59537,61452,62476,173,1196,1212,58909]

theorem envBound38478 : H12AffineFastState.Bounded env38478 := by
  intro p hp
  have h : env38478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38477_38478 : H12AffineEnvironment.transform 15 37018 env38477 = env38478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env38477 == env38478) = true)

theorem identity38478 : scanCanonicalize (H12AffineFastState.compose env38478 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 23177) := by decide +kernel

theorem selectedBound38478 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env38479 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,23177,18963,11924,13852,14997,23176,4096,10760,28292,15903,7709,20497,18617,27176,27177,12824,10885,11909,173,1196,1212,15508]

theorem envBound38479 : H12AffineFastState.Bounded env38479 := by
  intro p hp
  have h : env38479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38478_38479 : H12AffineEnvironment.transform 14 23177 env38478 = env38479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23177 env38478 == env38479) = true)

theorem identity38479 : scanCanonicalize (H12AffineFastState.compose env38479 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38479 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env38480 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,6705,2731,11924,13852,14997,6704,4096,10760,11836,15903,7709,4265,2049,10896,10897,12824,10885,11909,173,1196,1212,15508]

theorem envBound38480 : H12AffineFastState.Bounded env38480 := by
  intro p hp
  have h : env38480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38479_38480 : H12AffineEnvironment.transform 13 184 env38479 = env38480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38479 == env38480) = true)

theorem identity38480 : scanCanonicalize (H12AffineFastState.compose env38480 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound38480 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38481 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1724,8192,184,3213,2731,11924,8352,11305,3212,1724,10760,11836,10403,2209,1557,2049,10896,10897,9380,10885,11909,173,1196,1212,10792]

theorem envBound38481 : H12AffineFastState.Bounded env38481 := by
  intro p hp
  have h : env38481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38480_38481 : H12AffineEnvironment.transform 11 1724 env38480 = env38481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env38480 == env38481) = true)

theorem identity38481 : scanCanonicalize (H12AffineFastState.compose env38481 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound38481 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env38482 : List Nat := [2,4,8,16,32,16,128,173,512,1024,43,1724,8192,184,1190,640,9919,8352,9218,1191,1724,8739,9751,8328,138,1557,42,8891,8890,9380,8878,9902,173,1196,1212,8707]

theorem envBound38482 : H12AffineFastState.Bounded env38482 := by
  intro p hp
  have h : env38482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38481_38482 : H12AffineEnvironment.transform 10 43 env38481 = env38482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env38481 == env38482) = true)

theorem identity38482 : scanCanonicalize (H12AffineFastState.compose env38482 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound38482 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env38483 : List Nat := [2,4,8,16,32,16,128,173,512,1024,43,1724,536,184,1190,640,1191,696,1562,1191,1724,59,1039,656,138,1557,42,163,162,1724,182,1206,173,1196,1212,27]

theorem envBound38483 : H12AffineFastState.Bounded env38483 := by
  intro p hp
  have h : env38483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38482_38483 : H12AffineEnvironment.transform 12 536 env38482 = env38483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env38482 == env38483) = true)

theorem identity38483 : scanCanonicalize (H12AffineFastState.compose env38483 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38483 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38484 : List Nat := [2,4,8,16,32,16,18,63,512,1024,43,1582,536,42,1076,530,1077,554,1562,1077,1582,59,1039,514,24,1557,42,49,48,1582,36,1060,63,1086,1070,27]

theorem envBound38484 : H12AffineFastState.Bounded env38484 := by
  intro p hp
  have h : env38484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38483_38484 : H12AffineEnvironment.transform 6 18 env38483 = env38484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38483 == env38484) = true)

theorem identity38484 : scanCanonicalize (H12AffineFastState.compose env38484 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38484 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env38485 : List Nat := [2,4,8,16,32,16,18,63,512,5,43,555,536,42,49,530,48,554,543,48,555,59,10,514,24,528,42,49,48,555,36,33,63,59,43,27]

theorem envBound38485 : H12AffineFastState.Bounded env38485 := by
  intro p hp
  have h : env38485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38484_38485 : H12AffineEnvironment.transform 9 5 env38484 = env38485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38484 == env38485) = true)

theorem identity38485 : scanCanonicalize (H12AffineFastState.compose env38485 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38485 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38486 : List Nat := [2,4,8,10,32,10,8,37,512,5,43,555,514,42,43,520,42,554,517,42,555,33,10,514,2,522,42,43,42,555,36,33,37,33,43,1]

theorem envBound38486 : H12AffineFastState.Bounded env38486 := by
  intro p hp
  have h : env38486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38485_38486 : H12AffineEnvironment.transform 3 10 env38485 = env38486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38485 == env38486) = true)

theorem identity38486 : scanCanonicalize (H12AffineFastState.compose env38486 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38486 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38487 : List Nat := [2,4,8,10,7,10,8,2,512,5,12,524,514,13,12,520,13,525,517,13,524,6,10,514,2,522,13,12,13,524,3,6,2,6,12,1]

theorem envBound38487 : H12AffineFastState.Bounded env38487 := by
  intro p hp
  have h : env38487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38486_38487 : H12AffineEnvironment.transform 4 7 env38486 = env38487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38486 == env38487) = true)

theorem identity38487 : scanCanonicalize (H12AffineFastState.compose env38487 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38488 : List Nat := [2,4,5,7,7,7,5,2,512,5,1,513,514,0,1,517,0,512,517,0,513,6,7,514,2,519,0,1,0,513,3,6,2,6,1,1]

theorem envBound38488 : H12AffineFastState.Bounded env38488 := by
  intro p hp
  have h : env38488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38487_38488 : H12AffineEnvironment.transform 2 5 env38487 = env38488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38487 == env38488) = true)

theorem identity38488 : scanCanonicalize (H12AffineFastState.compose env38488 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38488 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38489 : List Nat := [2,4,5,7,7,7,5,2,1,5,1,0,3,0,1,4,0,1,4,0,0,6,7,3,2,6,0,1,0,0,3,6,2,6,1,1]

theorem envBound38489 : H12AffineFastState.Bounded env38489 := by
  intro p hp
  have h : env38489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38488_38489 : H12AffineEnvironment.transform 8 1 env38488 = env38489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38488 == env38489) = true)

def env38490 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143497,20497,508074,148669,148668,96266,90262,131088,173,1196,1213,135680]

theorem envBound38490 : H12AffineFastState.Bounded env38490 := by
  intro p hp
  have h : env38490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38474_38490 : H12AffineEnvironment.transform 5 17 env38474 = env38490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38474 == env38490) = true)

theorem identity38490 : scanCanonicalize (H12AffineFastState.compose env38490 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound38490 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38491 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,58518,32809,20497,356362,62493,62492,96266,90262,45232,173,1196,1213,41632]

theorem envBound38491 : H12AffineFastState.Bounded env38491 := by
  intro p hp
  have h : env38491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38490_38491 : H12AffineEnvironment.transform 16 45216 env38490 = env38491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env38490 == env38491) = true)

theorem identity38491 : scanCanonicalize (H12AffineFastState.compose env38491 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound38491 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38492 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4096,61568,61617,58518,32809,20497,96387,62493,62492,96266,90262,45232,173,1196,1213,41632]

theorem envBound38492 : H12AffineFastState.Bounded env38492 := by
  intro p hp
  have h : env38492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38491_38492 : H12AffineEnvironment.transform 17 2185 env38491 = env38492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env38491 == env38492) = true)

theorem identity38492 : scanCanonicalize (H12AffineFastState.compose env38492 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38492 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38493 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,65536,45216,2185,41125,32769,4096,61568,61617,57490,32809,20497,96387,61465,61464,96266,90262,45232,173,168,185,41632]

theorem envBound38493 : H12AffineFastState.Bounded env38493 := by
  intro p hp
  have h : env38493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38492_38493 : H12AffineEnvironment.transform 9 4 env38492 = env38493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38492 == env38493) = true)

theorem identity38493 : scanCanonicalize (H12AffineFastState.compose env38493 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound38493 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env38494 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,12347,45216,2185,41125,32769,4096,61568,61617,57490,32809,20497,18616,61465,61464,18481,20653,45232,173,168,185,41632]

theorem envBound38494 : H12AffineFastState.Bounded env38494 := by
  intro p hp
  have h : env38494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38493_38494 : H12AffineEnvironment.transform 15 12347 env38493 = env38494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env38493 == env38494) = true)

theorem identity38494 : scanCanonicalize (H12AffineFastState.compose env38494 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 25249) := by decide +kernel

theorem selectedBound38494 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env38495 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,25249,12347,20993,2185,16900,25248,4096,4641,4624,563,25224,20497,18616,4792,4793,18481,20653,21009,173,168,185,16385]

theorem envBound38495 : H12AffineFastState.Bounded env38495 := by
  intro p hp
  have h : env38495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38494_38495 : H12AffineEnvironment.transform 14 25249 env38494 = env38495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25249 env38494 == env38495) = true)

theorem identity38495 : scanCanonicalize (H12AffineFastState.compose env38495 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound38495 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env38496 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2195,8192,16384,25249,10408,19090,2185,16900,25248,2195,2738,2691,563,25224,18562,18616,2603,2602,18481,18494,19074,173,168,185,16385]

theorem envBound38496 : H12AffineFastState.Bounded env38496 := by
  intro p hp
  have h : env38496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38495_38496 : H12AffineEnvironment.transform 11 2195 env38495 = env38496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env38495 == env38496) = true)

theorem identity38496 : scanCanonicalize (H12AffineFastState.compose env38496 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound38496 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env38497 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2195,2209,16384,18944,9,19090,2185,16900,18945,2195,2738,2691,563,18985,18562,18616,2603,2602,18481,18494,19074,173,168,185,16385]

theorem envBound38497 : H12AffineFastState.Bounded env38497 := by
  intro p hp
  have h : env38497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38496_38497 : H12AffineEnvironment.transform 12 2209 env38496 = env38497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env38496 == env38497) = true)

theorem identity38497 : scanCanonicalize (H12AffineFastState.compose env38497 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound38497 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env38498 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2195,2209,2184,648,9,538,2185,2700,649,2195,2738,2691,563,673,10,48,2603,2602,185,182,522,173,168,185,2185]

theorem envBound38498 : H12AffineFastState.Bounded env38498 := by
  intro p hp
  have h : env38498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38497_38498 : H12AffineEnvironment.transform 13 2184 env38497 = env38498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env38497 == env38498) = true)

theorem identity38498 : scanCanonicalize (H12AffineFastState.compose env38498 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38498 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env38499 : List Nat := [2,4,8,16,32,17,9,36,512,4,2048,2074,2088,2049,513,9,538,2048,2565,512,2074,2619,2570,563,552,10,48,2603,2602,48,63,522,36,33,48,2048]

theorem envBound38499 : H12AffineFastState.Bounded env38499 := by
  intro p hp
  have h : env38499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38498_38499 : H12AffineEnvironment.transform 6 9 env38498 = env38499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38498 == env38499) = true)

theorem identity38499 : scanCanonicalize (H12AffineFastState.compose env38499 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38500 : List Nat := [2,4,8,10,32,11,9,36,512,4,2048,2048,2088,2049,513,9,512,2048,2565,512,2048,2593,2570,553,552,10,42,2603,2602,42,37,522,36,33,42,2048]

theorem envBound38500 : H12AffineFastState.Bounded env38500 := by
  intro p hp
  have h : env38500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38499_38500 : H12AffineEnvironment.transform 3 10 env38499 = env38500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38499 == env38500) = true)

theorem identity38500 : scanCanonicalize (H12AffineFastState.compose env38500 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38500 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38501 : List Nat := [2,4,8,10,32,11,9,36,43,4,2048,2048,2088,2049,42,9,43,2048,2094,43,2048,2058,2081,2,3,10,42,2048,2049,42,37,33,36,33,42,2048]

theorem envBound38501 : H12AffineFastState.Bounded env38501 := by
  intro p hp
  have h : env38501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38500_38501 : H12AffineEnvironment.transform 8 43 env38500 = env38501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38500 == env38501) = true)

theorem identity38501 : scanCanonicalize (H12AffineFastState.compose env38501 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38501 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38502 : List Nat := [2,2,8,10,32,11,9,34,43,2,2048,2048,2088,2049,42,9,43,2048,2088,43,2048,2058,2081,2,3,10,42,2048,2049,42,35,33,34,33,42,2048]

theorem envBound38502 : H12AffineFastState.Bounded env38502 := by
  intro p hp
  have h : env38502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38501_38502 : H12AffineEnvironment.transform 1 2 env38501 = env38502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38501 == env38502) = true)

theorem identity38502 : scanCanonicalize (H12AffineFastState.compose env38502 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38502 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38503 : List Nat := [2,2,8,10,32,11,9,34,43,2,0,0,40,1,42,9,43,0,40,43,0,10,33,2,3,10,42,0,1,42,35,33,34,33,42,0]

theorem envBound38503 : H12AffineFastState.Bounded env38503 := by
  intro p hp
  have h : env38503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38502_38503 : H12AffineEnvironment.transform 10 0 env38502 = env38503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38502 == env38503) = true)

def env38504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245633,148801,545089,96347,16876544,17363323,256,1281,1344,525825]

theorem envBound38504 : H12AffineFastState.Bounded env38504 := by
  intro p hp
  have h : env38504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38390_38504 : H12AffineEnvironment.transform 26 17245633 env38390 = env38504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env38390 == env38504) = true)

theorem identity38504 : scanCanonicalize (H12AffineFastState.compose env38504 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound38504 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41003,533640,672784,493034,148801,545089,96347,74795,545104,256,1281,1344,525825]

theorem envBound38505 : H12AffineFastState.Bounded env38505 := by
  intro p hp
  have h : env38505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38504_38505 : H12AffineEnvironment.transform 23 41003 env38504 = env38505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env38504 == env38505) = true)

def env38506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,493034,148801,148801,96347,74795,148816,256,1281,1344,135681]

theorem envBound38506 : H12AffineFastState.Bounded env38506 := by
  intro p hp
  have h : env38506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38505_38506 : H12AffineEnvironment.transform 18 136192 env38505 = env38506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env38505 == env38506) = true)

def env38507 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,492614,148717,148717,96347,74795,148732,172,1197,1260,135681]

theorem envBound38507 : H12AffineFastState.Bounded env38507 := by
  intro p hp
  have h : env38507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38506_38507 : H12AffineEnvironment.transform 7 172 env38506 = env38507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38506 == env38507) = true)

def env38508 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143496,20496,492566,148669,148669,96267,74795,148652,172,1197,1212,135681]

theorem envBound38508 : H12AffineFastState.Bounded env38508 := by
  intro p hp
  have h : env38508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38507_38508 : H12AffineEnvironment.transform 5 16 env38507 = env38508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38507 == env38508) = true)

theorem identity38508 : scanCanonicalize (H12AffineFastState.compose env38508 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound38508 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38509 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61569,98355,41003,127147,20496,279605,99486,99486,96267,74795,99471,172,1197,1212,119330]

theorem envBound38509 : H12AffineFastState.Bounded env38509 := by
  intro p hp
  have h : env38509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38508_38509 : H12AffineEnvironment.transform 16 114723 env38508 = env38509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env38508 == env38509) = true)

theorem identity38509 : scanCanonicalize (H12AffineFastState.compose env38509 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 97294) := by decide +kernel

theorem selectedBound38509 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38510 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,97294,119843,32769,4096,61569,98355,41003,127147,20496,79931,99486,99486,96267,74795,99471,172,1197,1212,119330]

theorem envBound38510 : H12AffineFastState.Bounded env38510 := by
  intro p hp
  have h : env38510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38509_38510 : H12AffineEnvironment.transform 17 97294 env38509 = env38510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97294 env38509 == env38510) = true)

theorem identity38510 : scanCanonicalize (H12AffineFastState.compose env38510 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound38510 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env38511 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,44076,1025,32769,4096,61569,20497,41003,8329,20496,59417,21692,21692,43049,62473,21677,172,1197,1212,512]

theorem envBound38511 : H12AffineFastState.Bounded env38511 := by
  intro p hp
  have h : env38511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38510_38511 : H12AffineEnvironment.transform 15 53282 env38510 = env38511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env38510 == env38511) = true)

theorem identity38511 : scanCanonicalize (H12AffineFastState.compose env38511 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound38511 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38512 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,32768,37019,4097,44076,1025,32769,4096,45112,4264,41003,8329,4265,43168,5125,5125,43049,46256,5140,172,1197,1212,512]

theorem envBound38512 : H12AffineFastState.Bounded env38512 := by
  intro p hp
  have h : env38512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38511_38512 : H12AffineEnvironment.transform 13 185 env38511 = env38512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env38511 == env38512) = true)

theorem identity38512 : scanCanonicalize (H12AffineFastState.compose env38512 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound38512 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38513 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,560,4779,4097,11804,1025,561,4096,12808,4264,8731,8329,4265,10896,5125,5125,10777,13952,5140,172,1197,1212,512]

theorem envBound38513 : H12AffineFastState.Bounded env38513 := by
  intro p hp
  have h : env38513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38512_38513 : H12AffineEnvironment.transform 14 560 env38512 = env38513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env38512 == env38513) = true)

theorem identity38513 : scanCanonicalize (H12AffineFastState.compose env38513 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound38513 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env38514 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,8192,185,42,4273,4097,11270,1025,43,4096,12306,4264,8193,8329,4265,10378,5125,5125,10243,13466,5140,172,1197,1212,26]

theorem envBound38514 : H12AffineFastState.Bounded env38514 := by
  intro p hp
  have h : env38514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38513_38514 : H12AffineEnvironment.transform 8 26 env38513 = env38514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env38513 == env38514) = true)

theorem identity38514 : scanCanonicalize (H12AffineFastState.compose env38514 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound38514 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env38515 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,3076,8192,185,42,3253,3077,11270,1025,43,3076,11286,3244,8193,8329,3245,10378,2049,2049,10243,10398,2064,172,1197,1212,26]

theorem envBound38515 : H12AffineFastState.Bounded env38515 := by
  intro p hp
  have h : env38515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38514_38515 : H12AffineEnvironment.transform 11 3076 env38514 = env38515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env38514 == env38515) = true)

theorem identity38515 : scanCanonicalize (H12AffineFastState.compose env38515 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38515 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env38516 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1212,184,8192,185,42,9,185,8378,1025,43,184,8362,16,8193,8329,17,9270,1213,1213,9407,9250,1196,172,1197,1212,26]

theorem envBound38516 : H12AffineFastState.Bounded env38516 := by
  intro p hp
  have h : env38516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38515_38516 : H12AffineEnvironment.transform 10 1212 env38515 = env38516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env38515 == env38516) = true)

theorem identity38516 : scanCanonicalize (H12AffineFastState.compose env38516 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound38516 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38517 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1212,184,139,185,42,9,185,49,1025,43,184,33,16,138,2,17,1213,1213,1213,1076,1193,1196,172,1197,1212,26]

theorem envBound38517 : H12AffineFastState.Bounded env38517 := by
  intro p hp
  have h : env38517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38516_38517 : H12AffineEnvironment.transform 12 139 env38516 = env38517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env38516 == env38517) = true)

theorem identity38517 : scanCanonicalize (H12AffineFastState.compose env38517 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38517 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38518 : List Nat := [2,4,8,16,32,16,128,172,26,4,184,184,139,185,42,9,185,49,5,43,184,33,16,138,2,17,185,185,185,48,173,168,172,169,184,26]

theorem envBound38518 : H12AffineFastState.Bounded env38518 := by
  intro p hp
  have h : env38518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38517_38518 : H12AffineEnvironment.transform 9 4 env38517 = env38518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38517 == env38518) = true)

theorem identity38518 : scanCanonicalize (H12AffineFastState.compose env38518 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound38518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38519 : List Nat := [2,4,8,16,32,16,52,24,26,4,12,12,63,13,42,9,13,49,5,43,12,33,16,62,2,17,13,13,13,48,25,28,24,29,12,26]

theorem envBound38519 : H12AffineFastState.Bounded env38519 := by
  intro p hp
  have h : env38519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38518_38519 : H12AffineEnvironment.transform 6 52 env38518 = env38519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env38518 == env38519) = true)

theorem identity38519 : scanCanonicalize (H12AffineFastState.compose env38519 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38520 : List Nat := [2,4,8,16,11,16,31,24,26,4,12,12,20,13,1,9,13,26,5,0,12,10,16,21,2,17,13,13,13,27,25,28,24,29,12,26]

theorem envBound38520 : H12AffineFastState.Bounded env38520 := by
  intro p hp
  have h : env38520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38519_38520 : H12AffineEnvironment.transform 4 11 env38519 = env38520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38519 == env38520) = true)

theorem identity38520 : scanCanonicalize (H12AffineFastState.compose env38520 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38520 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38521 : List Nat := [2,4,8,11,11,11,4,3,1,4,12,12,15,13,1,9,13,1,5,0,12,10,11,14,2,10,13,13,13,0,2,7,3,6,12,1]

theorem envBound38521 : H12AffineFastState.Bounded env38521 := by
  intro p hp
  have h : env38521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38520_38521 : H12AffineEnvironment.transform 3 11 env38520 = env38521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38520 == env38521) = true)

def env38522 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143496,20496,492567,148668,148668,96266,74795,148653,172,1197,1213,135681]

theorem envBound38522 : H12AffineFastState.Bounded env38522 := by
  intro p hp
  have h : env38522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38507_38522 : H12AffineEnvironment.transform 5 17 env38507 = env38522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38507 == env38522) = true)

theorem identity38522 : scanCanonicalize (H12AffineFastState.compose env38522 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound38522 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38523 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61568,147473,41003,143496,20496,60445,148668,148668,96266,74795,148653,172,1197,1213,135681]

theorem envBound38523 : H12AffineFastState.Bounded env38523 := by
  intro p hp
  have h : env38523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38522_38523 : H12AffineEnvironment.transform 17 223242 env38522 = env38523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env38522 == env38523) = true)

theorem identity38523 : scanCanonicalize (H12AffineFastState.compose env38523 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound38523 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38524 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4096,61568,147473,41003,143496,20496,60445,148668,148668,2184,21673,148653,172,1197,1213,135681]

theorem envBound38524 : H12AffineFastState.Bounded env38524 := by
  intro p hp
  have h : env38524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38523_38524 : H12AffineEnvironment.transform 15 28802 env38523 = env38524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env38523 == env38524) = true)

theorem identity38524 : scanCanonicalize (H12AffineFastState.compose env38524 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound38524 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env38525 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,28802,131072,137352,136192,9380,4096,21541,147473,1166,143496,20496,18616,148668,148668,2184,21673,148653,172,1197,1213,135681]

theorem envBound38525 : H12AffineFastState.Bounded env38525 := by
  intro p hp
  have h : env38525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38524_38525 : H12AffineEnvironment.transform 14 9381 env38524 = env38525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env38524 == env38525) = true)

theorem identity38525 : scanCanonicalize (H12AffineFastState.compose env38525 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound38525 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env38526 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,13375,131072,137352,136192,9380,4096,4248,132268,1166,143496,5293,3077,131073,131073,2184,4116,131088,172,1197,1213,135681]

theorem envBound38526 : H12AffineFastState.Bounded env38526 := by
  intro p hp
  have h : env38526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38525_38526 : H12AffineEnvironment.transform 13 1213 env38525 = env38526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env38525 == env38526) = true)

theorem identity38526 : scanCanonicalize (H12AffineFastState.compose env38526 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38526 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38527 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9381,13375,1212,7220,4284,9380,4096,4248,16,1166,13364,5293,3077,1213,1213,2184,4116,1196,172,1197,1213,5821]

theorem envBound38527 : H12AffineFastState.Bounded env38527 := by
  intro p hp
  have h : env38527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38526_38527 : H12AffineEnvironment.transform 16 1212 env38526 = env38527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env38526 == env38527) = true)

theorem identity38527 : scanCanonicalize (H12AffineFastState.compose env38527 (packedSelected [6,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound38527 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env38528 : List Nat := [2,4,8,6,32,7,128,172,512,1024,2048,4096,8192,1195,9381,13353,1194,7202,4266,9380,4096,4238,6,1166,13346,5293,3077,1195,1195,2184,4098,1196,172,1197,1195,5803]

theorem envBound38528 : H12AffineFastState.Bounded env38528 := by
  intro p hp
  have h : env38528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38527_38528 : H12AffineEnvironment.transform 3 6 env38527 = env38528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env38527 == env38528) = true)

theorem identity38528 : scanCanonicalize (H12AffineFastState.compose env38528 (packedSelected [0,4,5,6,7,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound38528 : packedSelected [0,4,5,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env38529 : List Nat := [2,4,8,6,32,7,128,172,512,1024,2048,4096,6283,1195,7214,3234,1194,7202,4266,7215,4096,4238,6,1166,3241,5293,3077,1195,1195,2184,4098,1196,172,1197,1195,5803]

theorem envBound38529 : H12AffineFastState.Bounded env38529 := by
  intro p hp
  have h : env38529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38528_38529 : H12AffineEnvironment.transform 12 6283 env38528 = env38529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env38528 == env38529) = true)

theorem identity38529 : scanCanonicalize (H12AffineFastState.compose env38529 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound38529 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env38530 : List Nat := [2,4,8,6,32,7,128,172,512,516,2048,4096,6283,687,6698,2726,686,6694,4266,6699,4096,4238,6,650,2733,4777,2561,687,687,2184,4098,680,172,681,687,4271]

theorem envBound38530 : H12AffineFastState.Bounded env38530 := by
  intro p hp
  have h : env38530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38529_38530 : H12AffineEnvironment.transform 9 516 env38529 = env38530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env38529 == env38530) = true)

theorem identity38530 : scanCanonicalize (H12AffineFastState.compose env38530 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2060) := by decide +kernel

theorem selectedBound38530 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38531 : List Nat := [2,4,8,6,32,7,128,172,512,516,2048,2060,135,687,550,2726,686,554,2214,551,2060,2178,6,650,2733,2725,2561,687,687,2184,2062,680,172,681,687,2211]

theorem envBound38531 : H12AffineFastState.Bounded env38531 := by
  intro p hp
  have h : env38531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38530_38531 : H12AffineEnvironment.transform 11 2060 env38530 = env38531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2060 env38530 == env38531) = true)

theorem identity38531 : scanCanonicalize (H12AffineFastState.compose env38531 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38531 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38532 : List Nat := [2,4,8,6,32,7,128,172,0,4,2048,2060,135,175,38,2214,174,42,2214,39,2060,2178,6,138,2221,2213,2049,175,175,2184,2062,168,172,169,175,2211]

theorem envBound38532 : H12AffineFastState.Bounded env38532 := by
  intro p hp
  have h : env38532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38531_38532 : H12AffineEnvironment.transform 8 0 env38531 = env38532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38531 == env38532) = true)

theorem identity38532 : scanCanonicalize (H12AffineFastState.compose env38532 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound38532 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env38533 : List Nat := [2,4,8,6,32,7,128,172,0,4,43,39,135,175,38,141,174,42,141,39,39,169,6,138,134,142,42,175,175,163,37,168,172,169,175,136]

theorem envBound38533 : H12AffineFastState.Bounded env38533 := by
  intro p hp
  have h : env38533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38532_38533 : H12AffineEnvironment.transform 10 43 env38532 = env38533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env38532 == env38533) = true)

theorem identity38533 : scanCanonicalize (H12AffineFastState.compose env38533 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38533 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env38534 : List Nat := [2,4,4,6,32,7,128,160,0,4,39,39,135,163,38,129,162,38,129,39,39,165,6,134,134,130,38,163,163,163,37,164,160,165,163,132]

theorem envBound38534 : H12AffineFastState.Bounded env38534 := by
  intro p hp
  have h : env38534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38533_38534 : H12AffineEnvironment.transform 2 4 env38533 = env38534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38533 == env38534) = true)

theorem identity38534 : scanCanonicalize (H12AffineFastState.compose env38534 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound38534 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38535 : List Nat := [2,4,4,6,32,7,34,2,0,4,39,39,37,1,38,35,0,38,35,39,39,7,6,36,36,32,38,1,1,1,37,6,2,7,1,38]

theorem envBound38535 : H12AffineFastState.Bounded env38535 := by
  intro p hp
  have h : env38535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38534_38535 : H12AffineEnvironment.transform 6 34 env38534 = env38535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env38534 == env38535) = true)

def env38536 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,492615,148716,148716,96347,74795,148733,173,1196,1261,135681]

theorem envBound38536 : H12AffineFastState.Bounded env38536 := by
  intro p hp
  have h : env38536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38506_38536 : H12AffineEnvironment.transform 7 173 env38506 = env38536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38506 == env38536) = true)

def env38537 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143496,20496,492567,148668,148668,96267,74795,148653,173,1196,1213,135681]

theorem envBound38537 : H12AffineFastState.Bounded env38537 := by
  intro p hp
  have h : env38537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38536_38537 : H12AffineEnvironment.transform 5 16 env38536 = env38537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38536 == env38537) = true)

theorem identity38537 : scanCanonicalize (H12AffineFastState.compose env38537 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound38537 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38538 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,41003,32809,20496,341174,62493,62493,96267,74795,62476,173,1196,1213,41632]

theorem envBound38538 : H12AffineFastState.Bounded env38538 := by
  intro p hp
  have h : env38538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38537_38538 : H12AffineEnvironment.transform 16 45217 env38537 = env38538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env38537 == env38538) = true)

theorem identity38538 : scanCanonicalize (H12AffineFastState.compose env38538 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38538 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env38539 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4096,46141,46093,41003,32809,5292,341174,45217,45217,81079,74795,45232,173,1196,1213,41632]

theorem envBound38539 : H12AffineFastState.Bounded env38539 := by
  intro p hp
  have h : env38539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38538_38539 : H12AffineEnvironment.transform 13 1212 env38538 = env38539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env38538 == env38539) = true)

theorem identity38539 : scanCanonicalize (H12AffineFastState.compose env38539 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound38539 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38540 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,37018,45217,262144,42145,32769,4096,46141,46093,41003,32809,5292,304172,45217,45217,44077,46257,45232,173,1196,1213,41632]

theorem envBound38540 : H12AffineFastState.Bounded env38540 := by
  intro p hp
  have h : env38540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38539_38540 : H12AffineEnvironment.transform 15 37018 env38539 = env38540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env38539 == env38540) = true)

theorem identity38540 : scanCanonicalize (H12AffineFastState.compose env38540 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38540 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env38541 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,32768,37018,45217,262144,41125,32769,4096,45113,45065,41003,32809,4264,303144,45217,45217,43049,45237,45232,173,168,185,41632]

theorem envBound38541 : H12AffineFastState.Bounded env38541 := by
  intro p hp
  have h : env38541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38540_38541 : H12AffineEnvironment.transform 9 4 env38540 = env38541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38540 == env38541) = true)

theorem identity38541 : scanCanonicalize (H12AffineFastState.compose env38541 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound38541 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env38542 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,8353,12347,4096,262144,4,8352,4096,4248,4264,138,8328,4264,262281,4096,4096,2184,4116,4113,173,168,185,513]

theorem envBound38542 : H12AffineFastState.Bounded env38542 := by
  intro p hp
  have h : env38542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38541_38542 : H12AffineEnvironment.transform 14 8353 env38541 = env38542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env38541 == env38542) = true)

theorem identity38542 : scanCanonicalize (H12AffineFastState.compose env38542 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound38542 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38543 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,537,184,696,4642,4096,262144,4,697,4096,4248,4264,138,657,4264,262281,4096,4096,2184,4116,4113,173,168,185,513]

theorem envBound38543 : H12AffineFastState.Bounded env38543 := by
  intro p hp
  have h : env38543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38542_38543 : H12AffineEnvironment.transform 12 537 env38542 = env38543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env38542 == env38543) = true)

theorem identity38543 : scanCanonicalize (H12AffineFastState.compose env38543 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38543 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38544 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,0,537,184,696,546,0,262144,4,697,0,152,168,138,657,168,262281,0,0,2184,20,17,173,168,185,513]

theorem envBound38544 : H12AffineFastState.Bounded env38544 := by
  intro p hp
  have h : env38544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38543_38544 : H12AffineEnvironment.transform 11 0 env38543 = env38544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38543 == env38544) = true)

theorem identity38544 : scanCanonicalize (H12AffineFastState.compose env38544 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound38544 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38545 : List Nat := [2,4,8,16,32,16,128,173,48,4,2048,0,41,184,136,18,0,262144,4,137,0,152,168,138,161,168,262281,0,0,2184,20,17,173,168,185,49]

theorem envBound38545 : H12AffineFastState.Bounded env38545 := by
  intro p hp
  have h : env38545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38544_38545 : H12AffineEnvironment.transform 8 48 env38544 = env38545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38544 == env38545) = true)

theorem identity38545 : scanCanonicalize (H12AffineFastState.compose env38545 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound38545 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env38546 : List Nat := [2,4,8,16,32,16,128,173,48,4,146,0,41,184,136,18,0,262144,4,137,0,152,168,138,161,168,262281,0,0,26,20,17,173,168,185,49]

theorem envBound38546 : H12AffineFastState.Bounded env38546 := by
  intro p hp
  have h : env38546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38545_38546 : H12AffineEnvironment.transform 10 146 env38545 = env38546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env38545 == env38546) = true)

theorem identity38546 : scanCanonicalize (H12AffineFastState.compose env38546 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound38546 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38547 : List Nat := [2,4,8,16,32,16,41,4,48,4,59,0,41,17,33,18,0,262144,4,32,0,49,1,35,8,1,262176,0,0,26,20,17,4,1,16,49]

theorem envBound38547 : H12AffineFastState.Bounded env38547 := by
  intro p hp
  have h : env38547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38546_38547 : H12AffineEnvironment.transform 6 41 env38546 = env38547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env38546 == env38547) = true)

theorem identity38547 : scanCanonicalize (H12AffineFastState.compose env38547 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38547 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env38548 : List Nat := [2,4,8,16,16,16,25,4,0,4,11,0,25,17,17,18,0,262144,4,16,0,1,1,19,8,1,262160,0,0,26,20,17,4,1,16,1]

theorem envBound38548 : H12AffineFastState.Bounded env38548 := by
  intro p hp
  have h : env38548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38547_38548 : H12AffineEnvironment.transform 4 16 env38547 = env38548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38547 == env38548) = true)

theorem identity38548 : scanCanonicalize (H12AffineFastState.compose env38548 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound38548 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38549 : List Nat := [2,4,8,12,12,12,5,4,0,4,11,0,5,13,13,14,0,262144,4,12,0,1,1,15,8,1,262156,0,0,6,8,13,4,1,12,1]

theorem envBound38549 : H12AffineFastState.Bounded env38549 := by
  intro p hp
  have h : env38549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38548_38549 : H12AffineEnvironment.transform 3 12 env38548 = env38549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env38548 == env38549) = true)

theorem identity38549 : scanCanonicalize (H12AffineFastState.compose env38549 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38549 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env38550 : List Nat := [2,4,4,0,0,0,5,4,0,4,7,0,5,1,1,2,0,262144,4,0,0,1,1,3,4,1,262144,0,0,6,4,1,4,1,0,1]

theorem envBound38550 : H12AffineFastState.Bounded env38550 := by
  intro p hp
  have h : env38550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38549_38550 : H12AffineEnvironment.transform 2 4 env38549 = env38550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38549 == env38550) = true)

theorem identity38550 : scanCanonicalize (H12AffineFastState.compose env38550 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38551 : List Nat := [2,0,0,0,0,0,1,0,0,0,3,0,1,1,1,2,0,262144,0,0,0,1,1,3,0,1,262144,0,0,2,0,1,0,1,0,1]

theorem envBound38551 : H12AffineFastState.Bounded env38551 := by
  intro p hp
  have h : env38551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38550_38551 : H12AffineEnvironment.transform 1 0 env38550 = env38551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38550 == env38551) = true)

theorem identity38551 : scanCanonicalize (H12AffineFastState.compose env38551 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound38551 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38552 : List Nat := [2,0,0,0,0,0,1,0,0,0,3,0,1,1,1,2,0,0,0,0,0,1,1,3,0,1,0,0,0,2,0,1,0,1,0,1]

theorem envBound38552 : H12AffineFastState.Bounded env38552 := by
  intro p hp
  have h : env38552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38551_38552 : H12AffineEnvironment.transform 17 0 env38551 = env38552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env38551 == env38552) = true)

theorem identity38552 : scanCanonicalize (H12AffineFastState.compose env38552 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38552 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38553 : List Nat := [0,0,0,0,0,0,1,0,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,1,0,1,0,0,0,0,0,1,0,1,0,1]

theorem envBound38553 : H12AffineFastState.Bounded env38553 := by
  intro p hp
  have h : env38553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38552_38553 : H12AffineEnvironment.transform 0 0 env38552 = env38553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38552 == env38553) = true)

def env38554 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143496,20496,492566,148669,148669,96266,74795,148652,173,1196,1212,135681]

theorem envBound38554 : H12AffineFastState.Bounded env38554 := by
  intro p hp
  have h : env38554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38536_38554 : H12AffineEnvironment.transform 5 17 env38536 = env38554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38536 == env38554) = true)

theorem identity38554 : scanCanonicalize (H12AffineFastState.compose env38554 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound38554 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38555 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,41003,143496,20496,105631,148669,148669,96266,74795,148652,173,1196,1212,135681]

theorem envBound38555 : H12AffineFastState.Bounded env38555 := by
  intro p hp
  have h : env38555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38554_38555 : H12AffineEnvironment.transform 17 137353 env38554 = env38555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env38554 == env38555) = true)

theorem identity38555 : scanCanonicalize (H12AffineFastState.compose env38555 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound38555 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38556 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4096,61568,147473,41003,143496,20496,43169,148669,148669,19508,4117,148652,173,1196,1212,135681]

theorem envBound38556 : H12AffineFastState.Bounded env38556 := by
  intro p hp
  have h : env38556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38555_38556 : H12AffineEnvironment.transform 15 13374 env38555 = env38556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env38555 == env38556) = true)

theorem identity38556 : scanCanonicalize (H12AffineFastState.compose env38556 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38556 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38557 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136192,32769,4096,46140,132269,41003,143496,5292,43169,131073,131073,2184,4117,131088,173,1196,1212,135681]

theorem envBound38557 : H12AffineFastState.Bounded env38557 := by
  intro p hp
  have h : env38557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38556_38557 : H12AffineEnvironment.transform 13 1212 env38556 = env38557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env38556 == env38557) = true)

theorem identity38557 : scanCanonicalize (H12AffineFastState.compose env38557 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound38557 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env38558 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,40985,47248,46105,32769,4096,46140,42164,41003,37009,5292,43169,40984,40984,2184,4117,40969,173,1196,1212,45592]

theorem envBound38558 : H12AffineFastState.Bounded env38558 := by
  intro p hp
  have h : env38558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38557_38558 : H12AffineEnvironment.transform 16 40985 env38557 = env38558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env38557 == env38558) = true)

theorem identity38558 : scanCanonicalize (H12AffineFastState.compose env38558 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound38558 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env38559 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,8192,1212,32768,10272,40985,42126,43015,32769,3102,43042,42164,41003,35983,2226,43169,40984,40984,2184,3083,40969,173,1196,1212,44550]

theorem envBound38559 : H12AffineFastState.Bounded env38559 := by
  intro p hp
  have h : env38559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38558_38559 : H12AffineEnvironment.transform 11 3102 env38558 = env38559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env38558 == env38559) = true)

theorem identity38559 : scanCanonicalize (H12AffineFastState.compose env38559 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 2234) := by decide +kernel

theorem selectedBound38559 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env38560 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,2234,1212,32768,154,34979,35892,32957,32769,3102,32920,35854,34961,35983,2226,32795,34978,34978,2184,3083,34995,173,1196,1212,34492]

theorem envBound38560 : H12AffineFastState.Bounded env38560 := by
  intro p hp
  have h : env38560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38559_38560 : H12AffineEnvironment.transform 12 2234 env38559 = env38560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2234 env38559 == env38560) = true)

theorem identity38560 : scanCanonicalize (H12AffineFastState.compose env38560 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 3223) := by decide +kernel

theorem selectedBound38560 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38561 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,2234,1212,3223,154,1076,163,3114,3222,3102,3087,153,1030,24,2226,3212,1077,1077,2184,3083,1060,173,1196,1212,2603]

theorem envBound38561 : H12AffineFastState.Bounded env38561 := by
  intro p hp
  have h : env38561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38560_38561 : H12AffineEnvironment.transform 14 3223 env38560 = env38561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3223 env38560 == env38561) = true)

theorem identity38561 : scanCanonicalize (H12AffineFastState.compose env38561 (packedSelected [0,1,3,4,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound38561 : packedSelected [0,1,3,4,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38562 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1190,184,1052,1212,49,154,1076,163,140,48,184,169,153,1030,24,1044,42,1077,1077,1070,173,1060,173,1196,1212,1677]

theorem envBound38562 : H12AffineFastState.Bounded env38562 := by
  intro p hp
  have h : env38562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38561_38562 : H12AffineEnvironment.transform 10 1190 env38561 = env38562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env38561 == env38562) = true)

theorem identity38562 : scanCanonicalize (H12AffineFastState.compose env38562 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38562 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38563 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1070,48,1052,1076,49,18,1076,43,4,48,48,33,17,1030,24,1044,42,1077,1077,1070,37,1060,37,1060,1076,1541]

theorem envBound38563 : H12AffineFastState.Bounded env38563 := by
  intro p hp
  have h : env38563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38562_38563 : H12AffineEnvironment.transform 6 8 env38562 = env38563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38562 == env38563) = true)

theorem identity38563 : scanCanonicalize (H12AffineFastState.compose env38563 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 55) := by decide +kernel

theorem selectedBound38563 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env38564 : List Nat := [2,4,8,16,32,17,8,37,55,1024,1070,48,1052,1076,49,18,1076,43,4,48,48,33,17,1030,24,1044,42,1077,1077,1070,37,1060,37,1060,1076,1074]

theorem envBound38564 : H12AffineFastState.Bounded env38564 := by
  intro p hp
  have h : env38564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38563_38564 : H12AffineEnvironment.transform 8 55 env38563 = env38564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 55 env38563 == env38564) = true)

theorem identity38564 : scanCanonicalize (H12AffineFastState.compose env38564 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound38564 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env38565 : List Nat := [2,4,8,16,22,17,8,19,1,1024,1048,6,1052,1026,7,18,1026,29,4,6,6,23,17,1030,24,1044,28,1027,1027,1048,19,1042,19,1042,1026,1028]

theorem envBound38565 : H12AffineFastState.Bounded env38565 := by
  intro p hp
  have h : env38565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38564_38565 : H12AffineEnvironment.transform 4 22 env38564 = env38565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env38564 == env38565) = true)

theorem identity38565 : scanCanonicalize (H12AffineFastState.compose env38565 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38565 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env38566 : List Nat := [2,4,8,11,13,10,8,8,1,1024,1027,6,1031,1026,7,9,1026,6,4,6,6,12,10,1030,3,1039,7,1027,1027,1027,8,1033,8,1033,1026,1028]

theorem envBound38566 : H12AffineFastState.Bounded env38566 := by
  intro p hp
  have h : env38566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38565_38566 : H12AffineEnvironment.transform 3 11 env38565 = env38566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38565 == env38566) = true)

def env38567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,493034,148801,148800,96347,74795,148817,256,1281,1344,135680]

theorem envBound38567 : H12AffineFastState.Bounded env38567 := by
  intro p hp
  have h : env38567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38505_38567 : H12AffineEnvironment.transform 18 136193 env38505 = env38567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env38505 == env38567) = true)

def env38568 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,492614,148717,148716,96347,74795,148733,172,1197,1260,135680]

theorem envBound38568 : H12AffineFastState.Bounded env38568 := by
  intro p hp
  have h : env38568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38567_38568 : H12AffineEnvironment.transform 7 172 env38567 = env38568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38567 == env38568) = true)

def env38569 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143497,20497,492566,148669,148668,96267,74795,148653,172,1197,1212,135680]

theorem envBound38569 : H12AffineFastState.Bounded env38569 := by
  intro p hp
  have h : env38569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38568_38569 : H12AffineEnvironment.transform 5 16 env38568 = env38569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38568 == env38569) = true)

theorem identity38569 : scanCanonicalize (H12AffineFastState.compose env38569 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound38569 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38570 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61569,147472,41003,143497,20497,60444,148669,148668,96267,74795,148653,172,1197,1212,135680]

theorem envBound38570 : H12AffineFastState.Bounded env38570 := by
  intro p hp
  have h : env38570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38569_38570 : H12AffineEnvironment.transform 17 223242 env38569 = env38570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env38569 == env38570) = true)

theorem identity38570 : scanCanonicalize (H12AffineFastState.compose env38570 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound38570 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38571 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4096,61569,147472,41003,143497,20497,60444,148669,148668,2184,21672,148653,172,1197,1212,135680]

theorem envBound38571 : H12AffineFastState.Bounded env38571 := by
  intro p hp
  have h : env38571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38570_38571 : H12AffineEnvironment.transform 15 28803 env38570 = env38571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env38570 == env38571) = true)

theorem identity38571 : scanCanonicalize (H12AffineFastState.compose env38571 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound38571 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env38572 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,28803,131072,137353,136193,9381,4096,21541,147472,1167,143497,20497,18616,148669,148668,2184,21672,148653,172,1197,1212,135680]

theorem envBound38572 : H12AffineFastState.Bounded env38572 := by
  intro p hp
  have h : env38572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38571_38572 : H12AffineEnvironment.transform 14 9380 env38571 = env38572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env38571 == env38572) = true)

theorem identity38572 : scanCanonicalize (H12AffineFastState.compose env38572 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38572 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env38573 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13375,131072,137353,136193,9381,4096,4249,132268,1167,143497,5293,3076,131073,131072,2184,4116,131089,172,1197,1212,135680]

theorem envBound38573 : H12AffineFastState.Bounded env38573 := by
  intro p hp
  have h : env38573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38572_38573 : H12AffineEnvironment.transform 13 1212 env38572 = env38573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env38572 == env38573) = true)

theorem identity38573 : scanCanonicalize (H12AffineFastState.compose env38573 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound38573 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38574 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,9380,9351,131072,133169,132281,9381,184,33,132268,1167,139313,1045,3076,131073,131072,2184,172,131089,172,1197,1212,131768]

theorem envBound38574 : H12AffineFastState.Bounded env38574 := by
  intro p hp
  have h : env38574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38573_38574 : H12AffineEnvironment.transform 11 184 env38573 = env38574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env38573 == env38574) = true)

theorem identity38574 : scanCanonicalize (H12AffineFastState.compose env38574 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38574 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env38575 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,184,8192,1212,9380,9351,131072,133169,132281,9381,184,33,132268,1167,139313,1045,3076,131073,131072,2184,172,131089,172,1197,1212,131257]

theorem envBound38575 : H12AffineFastState.Bounded env38575 := by
  intro p hp
  have h : env38575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38574_38575 : H12AffineEnvironment.transform 8 1 env38574 = env38575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38574 == env38575) = true)

theorem identity38575 : scanCanonicalize (H12AffineFastState.compose env38575 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound38575 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38576 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1190,184,8192,1212,9380,9351,131072,132247,132281,9381,184,33,132268,1167,139313,1045,162,131073,131072,1070,172,131089,172,1197,1212,131257]

theorem envBound38576 : H12AffineFastState.Bounded env38576 := by
  intro p hp
  have h : env38576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38575_38576 : H12AffineEnvironment.transform 10 1190 env38575 = env38576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env38575 == env38576) = true)

theorem identity38576 : scanCanonicalize (H12AffineFastState.compose env38576 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 8233) := by decide +kernel

theorem selectedBound38576 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env38577 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1190,184,8192,1212,9380,9351,8233,9406,9360,9381,184,33,9349,1167,24,1045,162,8232,8233,1070,172,8248,172,1197,1212,8336]

theorem envBound38577 : H12AffineFastState.Bounded env38577 := by
  intro p hp
  have h : env38577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38576_38577 : H12AffineEnvironment.transform 16 8233 env38576 = env38577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8233 env38576 == env38577) = true)

theorem identity38577 : scanCanonicalize (H12AffineFastState.compose env38577 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound38577 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env38578 : List Nat := [2,4,8,16,32,16,128,172,1,151,49,184,8192,43,8243,8208,8233,8233,8199,8242,184,33,8210,24,24,130,162,8232,8233,185,172,8248,172,58,43,8336]

theorem envBound38578 : H12AffineFastState.Bounded env38578 := by
  intro p hp
  have h : env38578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38577_38578 : H12AffineEnvironment.transform 9 151 env38577 = env38578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env38577 == env38578) = true)

theorem identity38578 : scanCanonicalize (H12AffineFastState.compose env38578 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 63) := by decide +kernel

theorem selectedBound38578 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38579 : List Nat := [2,4,8,16,32,16,128,172,1,151,49,184,63,43,12,47,22,22,56,13,184,33,45,24,24,130,162,23,22,185,172,7,172,58,43,175]

theorem envBound38579 : H12AffineFastState.Bounded env38579 := by
  intro p hp
  have h : env38579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38578_38579 : H12AffineEnvironment.transform 12 63 env38578 = env38579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 63 env38578 == env38579) = true)

theorem identity38579 : scanCanonicalize (H12AffineFastState.compose env38579 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38579 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env38580 : List Nat := [2,4,8,16,7,16,128,139,1,151,22,159,24,12,12,8,22,22,31,13,159,6,10,24,24,130,133,23,22,158,139,7,139,29,12,136]

theorem envBound38580 : H12AffineFastState.Bounded env38580 := by
  intro p hp
  have h : env38580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38579_38580 : H12AffineEnvironment.transform 4 7 env38579 = env38580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38579 == env38580) = true)

theorem identity38580 : scanCanonicalize (H12AffineFastState.compose env38580 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38580 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env38581 : List Nat := [2,4,8,16,7,16,8,3,1,31,22,23,24,12,12,8,22,22,31,13,23,6,10,24,24,10,13,23,22,22,3,7,3,29,12,0]

theorem envBound38581 : H12AffineFastState.Bounded env38581 := by
  intro p hp
  have h : env38581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38580_38581 : H12AffineEnvironment.transform 6 8 env38580 = env38581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38580 == env38581) = true)

theorem identity38581 : scanCanonicalize (H12AffineFastState.compose env38581 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38582 : List Nat := [0,4,8,16,5,16,8,1,1,29,20,21,24,12,12,8,20,20,29,13,21,4,8,24,24,8,13,21,20,20,1,5,1,29,12,0]

theorem envBound38582 : H12AffineFastState.Bounded env38582 := by
  intro p hp
  have h : env38582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38581_38582 : H12AffineEnvironment.transform 0 0 env38581 = env38582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38581 == env38582) = true)

theorem identity38582 : scanCanonicalize (H12AffineFastState.compose env38582 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound38582 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38583 : List Nat := [0,4,8,13,5,13,8,1,1,0,9,8,5,12,12,8,9,9,0,13,8,4,8,5,5,8,13,8,9,9,1,5,1,0,12,0]

theorem envBound38583 : H12AffineFastState.Bounded env38583 := by
  intro p hp
  have h : env38583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38582_38583 : H12AffineEnvironment.transform 3 13 env38582 = env38583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env38582 == env38583) = true)

theorem identity38583 : scanCanonicalize (H12AffineFastState.compose env38583 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38583 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38584 : List Nat := [0,4,1,4,5,4,1,1,1,0,0,1,5,5,5,1,0,0,0,4,1,4,1,5,5,1,4,1,0,0,1,5,1,0,5,0]

theorem envBound38584 : H12AffineFastState.Bounded env38584 := by
  intro p hp
  have h : env38584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38583_38584 : H12AffineEnvironment.transform 2 1 env38583 = env38584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38583 == env38584) = true)

theorem identity38584 : scanCanonicalize (H12AffineFastState.compose env38584 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38585 : List Nat := [0,0,1,0,1,0,1,1,1,0,0,1,1,1,1,1,0,0,0,0,1,0,1,1,1,1,0,1,0,0,1,1,1,0,1,0]

theorem envBound38585 : H12AffineFastState.Bounded env38585 := by
  intro p hp
  have h : env38585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38584_38585 : H12AffineEnvironment.transform 1 0 env38584 = env38585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38584 == env38585) = true)

def env38586 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143497,20497,492567,148668,148669,96266,74795,148652,172,1197,1213,135680]

theorem envBound38586 : H12AffineFastState.Bounded env38586 := by
  intro p hp
  have h : env38586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38568_38586 : H12AffineEnvironment.transform 5 17 env38568 = env38586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38568 == env38586) = true)

theorem identity38586 : scanCanonicalize (H12AffineFastState.compose env38586 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound38586 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38587 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61568,98354,41003,127146,20497,279604,99487,99486,96266,74795,99471,172,1197,1213,119331]

theorem envBound38587 : H12AffineFastState.Bounded env38587 := by
  intro p hp
  have h : env38587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38586_38587 : H12AffineEnvironment.transform 16 114723 env38586 = env38587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env38586 == env38587) = true)

theorem identity38587 : scanCanonicalize (H12AffineFastState.compose env38587 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 97294) := by decide +kernel

theorem selectedBound38587 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38588 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,97294,119842,32769,4096,61568,98354,41003,127146,20497,79930,99487,99486,96266,74795,99471,172,1197,1213,119331]

theorem envBound38588 : H12AffineFastState.Bounded env38588 := by
  intro p hp
  have h : env38588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38587_38588 : H12AffineEnvironment.transform 17 97294 env38587 = env38588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97294 env38587 == env38588) = true)

theorem identity38588 : scanCanonicalize (H12AffineFastState.compose env38588 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound38588 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env38589 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,44077,1025,32769,4096,61568,20497,41003,8329,20497,59417,21692,21693,43049,62472,21676,172,1197,1213,512]

theorem envBound38589 : H12AffineFastState.Bounded env38589 := by
  intro p hp
  have h : env38589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38588_38589 : H12AffineEnvironment.transform 15 53283 env38588 = env38589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env38588 == env38589) = true)

theorem identity38589 : scanCanonicalize (H12AffineFastState.compose env38589 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound38589 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38590 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,185,32768,37018,4096,44077,1025,32769,4096,45113,4264,41003,8329,4264,43168,5125,5124,43049,46257,5141,172,1197,1213,512]

theorem envBound38590 : H12AffineFastState.Bounded env38590 := by
  intro p hp
  have h : env38590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38589_38590 : H12AffineEnvironment.transform 13 185 env38589 = env38590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env38589 == env38590) = true)

theorem identity38590 : scanCanonicalize (H12AffineFastState.compose env38590 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound38590 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38591 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,657,185,32768,37018,4096,36540,1025,32769,4096,37544,4264,33466,536,4264,35377,5125,5124,35512,38432,5141,172,1197,1213,512]

theorem envBound38591 : H12AffineFastState.Bounded env38591 := by
  intro p hp
  have h : env38591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38590_38591 : H12AffineEnvironment.transform 12 657 env38590 = env38591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env38590 == env38591) = true)

theorem identity38591 : scanCanonicalize (H12AffineFastState.compose env38591 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound38591 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env38592 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,4096,138,185,32768,37018,4096,36007,1025,32769,4096,37043,4264,32929,3,4264,34858,5125,5124,34979,37947,5141,172,1197,1213,27]

theorem envBound38592 : H12AffineFastState.Bounded env38592 := by
  intro p hp
  have h : env38592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38591_38592 : H12AffineEnvironment.transform 8 27 env38591 = env38592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env38591 == env38592) = true)

def env38593 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,492615,148716,148717,96347,74795,148732,173,1196,1261,135680]

theorem envBound38593 : H12AffineFastState.Bounded env38593 := by
  intro p hp
  have h : env38593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38567_38593 : H12AffineEnvironment.transform 7 173 env38567 = env38593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38567 == env38593) = true)

def env38594 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143497,20497,492567,148668,148669,96267,74795,148652,173,1196,1213,135680]

theorem envBound38594 : H12AffineFastState.Bounded env38594 := by
  intro p hp
  have h : env38594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38593_38594 : H12AffineEnvironment.transform 5 16 env38593 = env38594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38593 == env38594) = true)

theorem identity38594 : scanCanonicalize (H12AffineFastState.compose env38594 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound38594 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38595 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,41003,143497,20497,105631,148668,148669,96267,74795,148652,173,1196,1213,135680]

theorem envBound38595 : H12AffineFastState.Bounded env38595 := by
  intro p hp
  have h : env38595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38594_38595 : H12AffineEnvironment.transform 17 137352 env38594 = env38595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env38594 == env38595) = true)

theorem identity38595 : scanCanonicalize (H12AffineFastState.compose env38595 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound38595 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38596 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4096,61569,147472,41003,143497,20497,43169,148668,148669,19509,4117,148652,173,1196,1213,135680]

theorem envBound38596 : H12AffineFastState.Bounded env38596 := by
  intro p hp
  have h : env38596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38595_38596 : H12AffineEnvironment.transform 15 13374 env38595 = env38596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env38595 == env38596) = true)

theorem identity38596 : scanCanonicalize (H12AffineFastState.compose env38596 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound38596 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38597 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136193,32769,4096,46140,132269,41003,143497,5292,43169,131073,131072,2184,4117,131089,173,1196,1213,135680]

theorem envBound38597 : H12AffineFastState.Bounded env38597 := by
  intro p hp
  have h : env38597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38596_38597 : H12AffineEnvironment.transform 13 1213 env38596 = env38597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env38596 == env38597) = true)

theorem identity38597 : scanCanonicalize (H12AffineFastState.compose env38597 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound38597 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env38598 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13374,131072,137352,136193,12313,4096,1060,132269,4147,143497,5292,6329,131073,131072,2184,4117,131089,173,1196,1213,135680]

theorem envBound38598 : H12AffineFastState.Bounded env38598 := by
  intro p hp
  have h : env38598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38597_38598 : H12AffineEnvironment.transform 14 12312 env38597 = env38598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env38597 == env38598) = true)

theorem identity38598 : scanCanonicalize (H12AffineFastState.compose env38598 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 7334) := by decide +kernel

theorem selectedBound38598 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env38599 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13374,7334,1070,2215,12313,4096,1060,6155,4147,11311,5292,6329,7335,7334,2184,4117,7351,173,1196,1213,3750]

theorem envBound38599 : H12AffineFastState.Bounded env38599 := by
  intro p hp
  have h : env38599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38598_38599 : H12AffineEnvironment.transform 16 7334 env38598 = env38599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 7334 env38598 == env38599) = true)

theorem identity38599 : scanCanonicalize (H12AffineFastState.compose env38599 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound38599 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38600 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,8353,9351,3103,1070,2215,8352,185,1060,2226,138,11311,1045,2048,3102,3103,2184,172,3086,173,1196,1213,3750]

theorem envBound38600 : H12AffineFastState.Bounded env38600 := by
  intro p hp
  have h : env38600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38599_38600 : H12AffineEnvironment.transform 11 185 env38599 = env38600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env38599 == env38600) = true)

theorem identity38600 : scanCanonicalize (H12AffineFastState.compose env38600 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound38600 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38601 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2098,1213,2195,3253,3103,1070,2215,2194,185,1060,2226,138,1053,1045,2048,3102,3103,2184,172,3086,173,1196,1213,3750]

theorem envBound38601 : H12AffineFastState.Bounded env38601 := by
  intro p hp
  have h : env38601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38600_38601 : H12AffineEnvironment.transform 12 2098 env38600 = env38601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env38600 == env38601) = true)

theorem identity38601 : scanCanonicalize (H12AffineFastState.compose env38601 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound38601 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env38602 : List Nat := [2,4,8,16,32,16,128,173,512,1024,561,185,515,1213,674,1668,1582,1070,662,675,185,1060,643,138,1053,1045,561,1583,1582,697,172,1599,173,1196,1213,1175]

theorem envBound38602 : H12AffineFastState.Bounded env38602 := by
  intro p hp
  have h : env38602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38601_38602 : H12AffineEnvironment.transform 10 561 env38601 = env38602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env38601 == env38602) = true)

theorem identity38602 : scanCanonicalize (H12AffineFastState.compose env38602 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound38602 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env38603 : List Nat := [2,4,8,16,32,16,35,14,512,1024,561,26,515,1054,513,1575,1582,1070,565,512,26,1060,544,41,1053,1045,561,1583,1582,538,15,1599,14,1039,1054,1076]

theorem envBound38603 : H12AffineFastState.Bounded env38603 := by
  intro p hp
  have h : env38603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38602_38603 : H12AffineEnvironment.transform 6 35 env38602 = env38603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env38602 == env38603) = true)

theorem identity38603 : scanCanonicalize (H12AffineFastState.compose env38603 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38604 : List Nat := [2,4,8,16,32,16,35,14,43,1024,26,26,40,1054,42,1036,1029,1070,30,43,26,1060,11,41,1053,1045,26,1028,1029,49,15,1044,14,1039,1054,1076]

theorem envBound38604 : H12AffineFastState.Bounded env38604 := by
  intro p hp
  have h : env38604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38603_38604 : H12AffineEnvironment.transform 8 43 env38603 = env38604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38603 == env38604) = true)

theorem identity38604 : scanCanonicalize (H12AffineFastState.compose env38604 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound38604 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38605 : List Nat := [2,4,8,16,12,16,15,14,7,1024,26,26,4,1054,6,1036,1029,1026,30,7,26,1032,11,5,1053,1045,26,1028,1029,29,15,1044,14,1039,1054,1048]

theorem envBound38605 : H12AffineFastState.Bounded env38605 := by
  intro p hp
  have h : env38605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38604_38605 : H12AffineEnvironment.transform 4 12 env38604 = env38605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env38604 == env38605) = true)

theorem identity38605 : scanCanonicalize (H12AffineFastState.compose env38605 (packedSelected [1,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound38605 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env38606 : List Nat := [2,4,8,13,12,13,15,14,7,1024,7,7,4,1027,6,1036,1029,1026,3,7,7,1032,11,5,1024,1032,7,1028,1029,0,15,1033,14,1039,1027,1029]

theorem envBound38606 : H12AffineFastState.Bounded env38606 := by
  intro p hp
  have h : env38606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38605_38606 : H12AffineEnvironment.transform 3 13 env38605 = env38606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env38605 == env38606) = true)

theorem identity38606 : scanCanonicalize (H12AffineFastState.compose env38606 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38606 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38607 : List Nat := [2,3,8,10,11,10,8,9,0,1024,0,0,3,1027,1,1035,1026,1026,3,0,0,1032,11,2,1024,1032,0,1027,1026,0,8,1033,9,1032,1027,1026]

theorem envBound38607 : H12AffineFastState.Bounded env38607 := by
  intro p hp
  have h : env38607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38606_38607 : H12AffineEnvironment.transform 1 3 env38606 = env38607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38606 == env38607) = true)

theorem identity38607 : scanCanonicalize (H12AffineFastState.compose env38607 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound38607 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38608 : List Nat := [2,3,8,10,11,10,8,9,0,3,0,0,3,0,1,8,1,1,3,0,0,11,11,2,3,11,0,0,1,0,8,10,9,11,0,1]

theorem envBound38608 : H12AffineFastState.Bounded env38608 := by
  intro p hp
  have h : env38608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38607_38608 : H12AffineEnvironment.transform 9 3 env38607 = env38608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env38607 == env38608) = true)

theorem identity38608 : scanCanonicalize (H12AffineFastState.compose env38608 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38609 : List Nat := [0,1,8,8,9,8,8,9,0,1,0,0,1,0,1,8,1,1,1,0,0,9,9,0,1,9,0,0,1,0,8,8,9,9,0,1]

theorem envBound38609 : H12AffineFastState.Bounded env38609 := by
  intro p hp
  have h : env38609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38608_38609 : H12AffineEnvironment.transform 0 0 env38608 = env38609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38608 == env38609) = true)

theorem identity38609 : scanCanonicalize (H12AffineFastState.compose env38609 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38610 : List Nat := [0,1,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,1,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,1]

theorem envBound38610 : H12AffineFastState.Bounded env38610 := by
  intro p hp
  have h : env38610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38609_38610 : H12AffineEnvironment.transform 2 0 env38609 = env38610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38609 == env38610) = true)

def env38611 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143497,20497,492566,148669,148668,96266,74795,148653,173,1196,1212,135680]

theorem envBound38611 : H12AffineFastState.Bounded env38611 := by
  intro p hp
  have h : env38611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38593_38611 : H12AffineEnvironment.transform 5 17 env38593 = env38611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38593 == env38611) = true)

theorem identity38611 : scanCanonicalize (H12AffineFastState.compose env38611 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound38611 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38612 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,41003,32809,20497,341174,62493,62492,96266,74795,62477,173,1196,1212,41632]

theorem envBound38612 : H12AffineFastState.Bounded env38612 := by
  intro p hp
  have h : env38612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38611_38612 : H12AffineEnvironment.transform 16 45216 env38611 = env38612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env38611 == env38612) = true)

theorem identity38612 : scanCanonicalize (H12AffineFastState.compose env38612 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound38612 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env38613 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4096,46141,46092,41003,32809,5292,341174,45216,45217,81079,74795,45232,173,1196,1212,41632]

theorem envBound38613 : H12AffineFastState.Bounded env38613 := by
  intro p hp
  have h : env38613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38612_38613 : H12AffineEnvironment.transform 13 1213 env38612 = env38613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env38612 == env38613) = true)

theorem identity38613 : scanCanonicalize (H12AffineFastState.compose env38613 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound38613 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38614 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,37019,45216,262144,42145,32769,4096,46141,46092,41003,32809,5292,304173,45216,45217,44076,46256,45232,173,1196,1212,41632]

theorem envBound38614 : H12AffineFastState.Bounded env38614 := by
  intro p hp
  have h : env38614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38613_38614 : H12AffineEnvironment.transform 15 37019 env38613 = env38614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env38613 == env38614) = true)

theorem identity38614 : scanCanonicalize (H12AffineFastState.compose env38614 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38614 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env38615 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,184,32768,37019,45216,262144,41124,32769,4096,45112,45065,41003,32809,4265,303144,45216,45217,43049,45237,45232,173,169,185,41632]

theorem envBound38615 : H12AffineFastState.Bounded env38615 := by
  intro p hp
  have h : env38615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38614_38615 : H12AffineEnvironment.transform 9 5 env38614 = env38615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38614 == env38615) = true)

def env38616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,134217728,148801,545088,96347,16876545,17363322,257,1281,151462017,525824]

theorem envBound38616 : H12AffineFastState.Bounded env38616 := by
  intro p hp
  have h : env38616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38389_38616 : H12AffineEnvironment.transform 24 533641 env38389 = env38616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env38389 == env38616) = true)

def env38617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245632,148801,545088,96347,16876545,17363322,257,1281,1345,525824]

theorem envBound38617 : H12AffineFastState.Bounded env38617 := by
  intro p hp
  have h : env38617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38616_38617 : H12AffineEnvironment.transform 26 17245632 env38616 = env38617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env38616 == env38617) = true)

theorem identity38617 : scanCanonicalize (H12AffineFastState.compose env38617 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound38617 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86518,209263,17245632,148801,74815,96347,16876545,16876549,257,1281,1345,95103]

theorem envBound38618 : H12AffineFastState.Bounded env38618 := by
  intro p hp
  have h : env38618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38617_38618 : H12AffineEnvironment.transform 18 95615 env38617 = env38618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env38617 == env38618) = true)

def env38619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86518,209263,225344,148801,74815,96347,381313,381317,257,1281,1345,95103]

theorem envBound38619 : H12AffineFastState.Bounded env38619 := by
  intro p hp
  have h : env38619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38618_38619 : H12AffineEnvironment.transform 23 284032 env38618 = env38619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env38618 == env38619) = true)

def env38620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86518,94527,77840,1297,74815,96347,381313,381317,257,1281,1345,95103]

theorem envBound38620 : H12AffineFastState.Bounded env38620 := by
  intro p hp
  have h : env38620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38619_38620 : H12AffineEnvironment.transform 16 16464 env38619 = env38620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env38619 == env38620) = true)

def env38621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70886,78895,77840,1297,74815,81227,365713,365717,257,1281,1345,79471]

theorem envBound38621 : H12AffineFastState.Bounded env38621 := by
  intro p hp
  have h : env38621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38620_38621 : H12AffineEnvironment.transform 13 1296 env38620 = env38621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38620 == env38621) = true)

theorem identity38621 : scanCanonicalize (H12AffineFastState.compose env38621 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound38621 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,16,266384,38037,46172,45155,1297,42060,48440,267490,267494,257,1281,1345,46620]

theorem envBound38622 : H12AffineFastState.Bounded env38622 := by
  intro p hp
  have h : env38622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38621_38622 : H12AffineEnvironment.transform 15 32883 env38621 = env38622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env38621 == env38622) = true)

def env38623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263632,33237,41244,42275,1297,42060,43128,262562,262566,257,1281,1345,41820]

theorem envBound38623 : H12AffineFastState.Bounded env38623 := by
  intro p hp
  have h : env38623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38622_38623 : H12AffineEnvironment.transform 11 1344 env38622 = env38623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38622 == env38623) = true)

theorem identity38623 : scanCanonicalize (H12AffineFastState.compose env38623 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound38623 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,487,42332,32769,1344,41089,16,1079,33237,41244,42275,1297,42060,43128,69,65,257,1281,1345,41820]

theorem envBound38624 : H12AffineFastState.Bounded env38624 := by
  intro p hp
  have h : env38624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38623_38624 : H12AffineEnvironment.transform 17 487 env38623 = env38624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env38623 == env38624) = true)

theorem identity38624 : scanCanonicalize (H12AffineFastState.compose env38624 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38624 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1344,487,1024,8541,1344,477,16,1079,8329,64,1151,1297,1296,2340,69,65,257,1281,1345,512]

theorem envBound38625 : H12AffineFastState.Bounded env38625 := by
  intro p hp
  have h : env38625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38624_38625 : H12AffineEnvironment.transform 14 8540 env38624 = env38625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38624 == env38625) = true)

theorem identity38625 : scanCanonicalize (H12AffineFastState.compose env38625 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound38625 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38626 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,325,8540,8495,277,487,85,8541,277,477,16,98,8329,64,42,324,325,2340,69,65,257,340,276,512]

theorem envBound38626 : H12AffineFastState.Bounded env38626 := by
  intro p hp
  have h : env38626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38625_38626 : H12AffineEnvironment.transform 9 85 env38625 = env38626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env38625 == env38626) = true)

theorem identity38626 : scanCanonicalize (H12AffineFastState.compose env38626 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound38626 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38627 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,704,325,924,1007,277,487,85,925,277,477,16,98,585,64,42,324,325,2340,69,65,257,340,276,512]

theorem envBound38627 : H12AffineFastState.Bounded env38627 := by
  intro p hp
  have h : env38627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38626_38627 : H12AffineEnvironment.transform 12 704 env38626 = env38627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env38626 == env38627) = true)

theorem identity38627 : scanCanonicalize (H12AffineFastState.compose env38627 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38627 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38628 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,656,277,924,959,277,439,5,925,277,397,16,50,537,16,42,276,277,2340,21,17,257,260,276,512]

theorem envBound38628 : H12AffineFastState.Bounded env38628 := by
  intro p hp
  have h : env38628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38627_38628 : H12AffineEnvironment.transform 5 16 env38627 = env38628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38627 == env38628) = true)

theorem identity38628 : scanCanonicalize (H12AffineFastState.compose env38628 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound38628 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38629 : List Nat := [2,4,8,16,32,16,128,256,512,5,439,277,656,277,924,959,277,439,5,925,277,397,16,50,537,16,42,276,277,147,21,17,257,260,276,512]

theorem envBound38629 : H12AffineFastState.Bounded env38629 := by
  intro p hp
  have h : env38629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38628_38629 : H12AffineEnvironment.transform 10 439 env38628 = env38629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env38628 == env38629) = true)

def env38630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263633,33236,41245,42274,1297,42060,43129,262563,262567,257,1281,1345,41821]

theorem envBound38630 : H12AffineFastState.Bounded env38630 := by
  intro p hp
  have h : env38630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38622_38630 : H12AffineEnvironment.transform 11 1345 env38622 = env38630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38622 == env38630) = true)

theorem identity38630 : scanCanonicalize (H12AffineFastState.compose env38630 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound38630 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,277,358,1344,262144,9288,276,1345,8597,16,263633,193,8200,9271,1297,9561,10604,262563,262567,257,1281,1345,8776]

theorem envBound38631 : H12AffineFastState.Bounded env38631 := by
  intro p hp
  have h : env38631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38630_38631 : H12AffineEnvironment.transform 14 277 env38630 = env38631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env38630 == env38631) = true)

theorem identity38631 : scanCanonicalize (H12AffineFastState.compose env38631 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2988) := by decide +kernel

theorem selectedBound38631 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,277,358,1344,2988,9288,276,1345,8597,16,3709,193,8200,9271,1297,9561,10604,2575,2571,257,1281,1345,8776]

theorem envBound38632 : H12AffineFastState.Bounded env38632 := by
  intro p hp
  have h : env38632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38631_38632 : H12AffineEnvironment.transform 17 2988 env38631 = env38632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2988 env38631 == env38632) = true)

def env38633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70887,78894,77840,1297,74815,81226,365712,365716,257,1281,1345,79470]

theorem envBound38633 : H12AffineFastState.Bounded env38633 := by
  intro p hp
  have h : env38633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38620_38633 : H12AffineEnvironment.transform 13 1297 env38620 = env38633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38620 == env38633) = true)

theorem identity38633 : scanCanonicalize (H12AffineFastState.compose env38633 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38633 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,16,266385,70887,78894,77840,1297,74815,81226,336013,336009,257,1281,1345,79470]

theorem envBound38634 : H12AffineFastState.Bounded env38634 := by
  intro p hp
  have h : env38634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38633_38634 : H12AffineEnvironment.transform 14 13341 env38633 = env38634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38633 == env38634) = true)

def env38635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,16,69649,70887,78894,77840,1297,74815,81226,8205,8201,257,1281,1345,79470]

theorem envBound38635 : H12AffineFastState.Bounded env38635 := by
  intro p hp
  have h : env38635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38634_38635 : H12AffineEnvironment.transform 17 65664 env38634 = env38635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38634 == env38635) = true)

theorem identity38635 : scanCanonicalize (H12AffineFastState.compose env38635 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound38635 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,65536,1345,65664,73839,9245,1,477,16,65552,66790,74799,73745,1297,74815,77131,8205,8201,257,1281,1345,75375]

theorem envBound38636 : H12AffineFastState.Bounded env38636 := by
  intro p hp
  have h : env38636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38635_38636 : H12AffineEnvironment.transform 11 1 env38635 = env38636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38635 == env38636) = true)

def env38637 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1297,9244,65536,1297,65664,73791,9245,1,397,16,65552,66742,74799,73745,1297,74815,77083,8205,8201,257,1281,1297,75327]

theorem envBound38637 : H12AffineFastState.Bounded env38637 := by
  intro p hp
  have h : env38637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38636_38637 : H12AffineEnvironment.transform 5 16 env38636 = env38637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38636 == env38637) = true)

theorem identity38637 : scanCanonicalize (H12AffineFastState.compose env38637 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound38637 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38638 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1,8192,1029,9244,65536,1029,65664,73791,9245,1,153,16,65552,66742,74799,73745,1029,74815,76815,8205,8201,21,1045,1029,75327]

theorem envBound38638 : H12AffineFastState.Bounded env38638 := by
  intro p hp
  have h : env38638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38637_38638 : H12AffineEnvironment.transform 7 20 env38637 = env38638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env38637 == env38638) = true)

theorem identity38638 : scanCanonicalize (H12AffineFastState.compose env38638 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound38638 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38639 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1,8192,1029,9244,9279,1029,9407,1024,9245,1,153,16,9263,8329,16,1070,1029,0,2096,8205,8201,21,1045,1029,512]

theorem envBound38639 : H12AffineFastState.Bounded env38639 := by
  intro p hp
  have h : env38639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38638_38639 : H12AffineEnvironment.transform 15 9279 env38638 = env38639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env38638 == env38639) = true)

theorem identity38639 : scanCanonicalize (H12AffineFastState.compose env38639 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1164) := by decide +kernel

theorem selectedBound38639 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38640 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1164,1,8192,1029,9244,9279,1029,9407,1024,9245,1,153,16,9263,8329,16,1070,1029,0,1212,8205,8201,21,1045,1029,512]

theorem envBound38640 : H12AffineFastState.Bounded env38640 := by
  intro p hp
  have h : env38640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38639_38640 : H12AffineEnvironment.transform 10 1164 env38639 = env38640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1164 env38639 == env38640) = true)

theorem identity38640 : scanCanonicalize (H12AffineFastState.compose env38640 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38640 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38641 : List Nat := [2,4,8,16,32,16,8,20,512,1024,1028,1,8192,1029,9244,9279,1029,9271,1024,9245,1,17,16,9263,8193,16,1070,1029,0,1076,8205,8201,21,1045,1029,512]

theorem envBound38641 : H12AffineFastState.Bounded env38641 := by
  intro p hp
  have h : env38641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38640_38641 : H12AffineEnvironment.transform 6 8 env38640 = env38641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38640 == env38641) = true)

theorem identity38641 : scanCanonicalize (H12AffineFastState.compose env38641 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound38641 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38642 : List Nat := [2,4,8,16,32,16,8,20,512,1024,1028,1,25,1029,1029,1062,1029,1070,1024,1028,1,17,16,1078,24,16,1070,1029,0,1076,20,16,21,1045,1029,512]

theorem envBound38642 : H12AffineFastState.Bounded env38642 := by
  intro p hp
  have h : env38642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38641_38642 : H12AffineEnvironment.transform 12 25 env38641 = env38642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env38641 == env38642) = true)

theorem identity38642 : scanCanonicalize (H12AffineFastState.compose env38642 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38643 : List Nat := [2,4,8,16,32,16,8,20,1,1024,1028,1,25,1029,1029,1062,1029,1070,1024,1028,1,17,16,1078,24,16,1070,1029,0,1076,20,16,21,1045,1029,1]

theorem envBound38643 : H12AffineFastState.Bounded env38643 := by
  intro p hp
  have h : env38643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38642_38643 : H12AffineEnvironment.transform 8 1 env38642 = env38643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38642 == env38643) = true)

theorem identity38643 : scanCanonicalize (H12AffineFastState.compose env38643 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38643 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38644 : List Nat := [2,4,8,10,32,10,8,14,1,1024,1028,1,3,1029,1029,1062,1029,1070,1024,1028,1,11,10,1068,2,10,1070,1029,0,1070,14,10,15,1039,1029,1]

theorem envBound38644 : H12AffineFastState.Bounded env38644 := by
  intro p hp
  have h : env38644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38643_38644 : H12AffineEnvironment.transform 3 10 env38643 = env38644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38643 == env38644) = true)

theorem identity38644 : scanCanonicalize (H12AffineFastState.compose env38644 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound38644 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38645 : List Nat := [2,4,8,10,32,10,8,14,1,47,43,1,3,42,42,9,42,1,47,43,1,11,10,3,2,10,1,42,0,1,14,10,15,32,42,1]

theorem envBound38645 : H12AffineFastState.Bounded env38645 := by
  intro p hp
  have h : env38645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38644_38645 : H12AffineEnvironment.transform 9 47 env38644 = env38645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env38644 == env38645) = true)

theorem identity38645 : scanCanonicalize (H12AffineFastState.compose env38645 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38645 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38646 : List Nat := [2,4,8,10,10,10,8,14,1,5,1,1,3,0,0,9,0,1,5,1,1,11,10,3,2,10,1,0,0,1,14,10,15,10,0,1]

theorem envBound38646 : H12AffineFastState.Bounded env38646 := by
  intro p hp
  have h : env38646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38645_38646 : H12AffineEnvironment.transform 4 10 env38645 = env38646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38645 == env38646) = true)

theorem identity38646 : scanCanonicalize (H12AffineFastState.compose env38646 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38647 : List Nat := [2,4,4,6,6,6,4,2,1,5,1,1,3,0,0,5,0,1,5,1,1,7,6,3,2,6,1,0,0,1,2,6,3,6,0,1]

theorem envBound38647 : H12AffineFastState.Bounded env38647 := by
  intro p hp
  have h : env38647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38646_38647 : H12AffineEnvironment.transform 2 4 env38646 = env38647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38646 == env38647) = true)

def env38648 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9244,65536,1296,65664,73790,9245,1,396,16,65552,66743,74799,73745,1297,74815,77082,8205,8201,257,1281,1296,75326]

theorem envBound38648 : H12AffineFastState.Bounded env38648 := by
  intro p hp
  have h : env38648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38636_38648 : H12AffineEnvironment.transform 5 17 env38636 = env38648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38636 == env38648) = true)

theorem identity38648 : scanCanonicalize (H12AffineFastState.compose env38648 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9514) := by decide +kernel

theorem selectedBound38648 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38649 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9244,9514,1296,9642,1300,9245,1,396,16,9530,8605,261,1339,1297,277,2096,8205,8201,257,1281,1296,788]

theorem envBound38649 : H12AffineFastState.Bounded env38649 := by
  intro p hp
  have h : env38649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38648_38649 : H12AffineEnvironment.transform 15 9514 env38648 = env38649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9514 env38648 == env38649) = true)

theorem identity38649 : scanCanonicalize (H12AffineFastState.compose env38649 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38649 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38650 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1,8192,1028,9244,9279,1029,9407,1025,9245,1,153,16,9263,8328,16,1070,1028,0,2096,8205,8201,20,1044,1029,513]

theorem envBound38650 : H12AffineFastState.Bounded env38650 := by
  intro p hp
  have h : env38650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38649_38650 : H12AffineEnvironment.transform 7 21 env38649 = env38650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38649 == env38650) = true)

theorem identity38650 : scanCanonicalize (H12AffineFastState.compose env38650 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1549) := by decide +kernel

theorem selectedBound38650 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38651 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1,1549,1028,529,562,1029,690,1025,528,1,153,16,546,1669,16,1070,1028,0,2096,1536,1540,20,1044,1029,513]

theorem envBound38651 : H12AffineFastState.Bounded env38651 := by
  intro p hp
  have h : env38651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38650_38651 : H12AffineEnvironment.transform 12 1549 env38650 = env38651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1549 env38650 == env38651) = true)

theorem identity38651 : scanCanonicalize (H12AffineFastState.compose env38651 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound38651 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38652 : List Nat := [2,4,8,16,32,17,128,21,512,1024,1557,1,1549,1028,529,562,1029,690,1025,528,1,153,16,546,1669,16,1070,1028,0,1573,1536,1540,20,1044,1029,513]

theorem envBound38652 : H12AffineFastState.Bounded env38652 := by
  intro p hp
  have h : env38652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38651_38652 : H12AffineEnvironment.transform 10 1557 env38651 = env38652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env38651 == env38652) = true)

theorem identity38652 : scanCanonicalize (H12AffineFastState.compose env38652 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 179) := by decide +kernel

theorem selectedBound38652 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env38653 : List Nat := [2,4,8,16,32,17,128,21,512,179,678,1,702,183,529,562,182,690,178,528,1,153,16,546,566,16,157,183,0,662,691,695,20,167,182,513]

theorem envBound38653 : H12AffineFastState.Bounded env38653 := by
  intro p hp
  have h : env38653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38652_38653 : H12AffineEnvironment.transform 9 179 env38652 = env38653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 179 env38652 == env38653) = true)

theorem identity38653 : scanCanonicalize (H12AffineFastState.compose env38653 (packedSelected [0,7,18] rootPS)) = affineNative (2^(8+1) ^^^ 150) := by decide +kernel

theorem selectedBound38653 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env38654 : List Nat := [2,4,8,16,32,17,128,21,150,179,48,1,40,183,135,164,182,36,178,134,1,153,16,180,160,16,157,183,0,0,37,33,20,167,182,151]

theorem envBound38654 : H12AffineFastState.Bounded env38654 := by
  intro p hp
  have h : env38654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38653_38654 : H12AffineEnvironment.transform 8 150 env38653 = env38654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 150 env38653 == env38654) = true)

theorem identity38654 : scanCanonicalize (H12AffineFastState.compose env38654 (packedSelected [1,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38654 : packedSelected [1,8,9] rootPS < 2^1333 := by decide +kernel

def env38655 : List Nat := [2,4,8,16,32,17,57,21,47,10,48,1,40,14,62,29,15,36,11,63,1,32,16,13,25,16,36,14,0,0,37,33,20,30,15,46]

theorem envBound38655 : H12AffineFastState.Bounded env38655 := by
  intro p hp
  have h : env38655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38654_38655 : H12AffineEnvironment.transform 6 57 env38654 = env38655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38654 == env38655) = true)

theorem identity38655 : scanCanonicalize (H12AffineFastState.compose env38655 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound38655 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38656 : List Nat := [2,4,8,16,4,17,29,21,11,10,20,1,12,14,26,29,15,0,11,27,1,4,16,13,25,16,0,14,0,0,1,5,20,30,15,10]

theorem envBound38656 : H12AffineFastState.Bounded env38656 := by
  intro p hp
  have h : env38656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38655_38656 : H12AffineEnvironment.transform 4 4 env38655 = env38656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env38655 == env38656) = true)

theorem identity38656 : scanCanonicalize (H12AffineFastState.compose env38656 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38656 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env38657 : List Nat := [2,1,8,16,1,17,24,16,11,10,17,1,9,11,26,24,10,0,11,27,1,1,16,8,25,16,0,11,0,0,1,0,17,27,10,10]

theorem envBound38657 : H12AffineFastState.Bounded env38657 := by
  intro p hp
  have h : env38657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38656_38657 : H12AffineEnvironment.transform 1 1 env38656 = env38657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38656 == env38657) = true)

theorem identity38657 : scanCanonicalize (H12AffineFastState.compose env38657 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38657 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38658 : List Nat := [1,1,8,16,1,17,24,16,8,9,17,1,9,8,25,24,9,0,8,24,1,1,16,8,25,16,0,8,0,0,1,0,17,24,9,9]

theorem envBound38658 : H12AffineFastState.Bounded env38658 := by
  intro p hp
  have h : env38658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38657_38658 : H12AffineEnvironment.transform 0 1 env38657 = env38658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38657 == env38658) = true)

theorem identity38658 : scanCanonicalize (H12AffineFastState.compose env38658 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound38658 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env38659 : List Nat := [1,1,8,8,1,9,0,8,8,9,9,1,9,8,1,0,9,0,8,0,1,1,8,8,1,8,0,8,0,0,1,0,9,0,9,9]

theorem envBound38659 : H12AffineFastState.Bounded env38659 := by
  intro p hp
  have h : env38659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38658_38659 : H12AffineEnvironment.transform 3 8 env38658 = env38659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env38658 == env38659) = true)

def env38660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,16,69648,70887,78894,77840,1297,74815,81226,8204,8200,257,1281,1345,79470]

theorem envBound38660 : H12AffineFastState.Bounded env38660 := by
  intro p hp
  have h : env38660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38634_38660 : H12AffineEnvironment.transform 17 65665 env38634 = env38660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38634 == env38660) = true)

theorem identity38660 : scanCanonicalize (H12AffineFastState.compose env38660 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound38660 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38661 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,65536,0,65665,77934,12637,4096,477,16,69648,70054,78191,77840,80,74110,79883,8204,8200,257,64,0,78639]

theorem envBound38661 : H12AffineFastState.Bounded env38661 := by
  intro p hp
  have h : env38661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38660_38661 : H12AffineEnvironment.transform 9 321 env38660 = env38661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38660 == env38661) = true)

def env38662 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12556,65536,0,65665,77886,12557,4096,397,16,69648,70054,78143,77840,0,74030,79883,8204,8200,257,16,0,78639]

theorem envBound38662 : H12AffineFastState.Bounded env38662 := by
  intro p hp
  have h : env38662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38661_38662 : H12AffineEnvironment.transform 5 16 env38661 = env38662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38661 == env38662) = true)

theorem identity38662 : scanCanonicalize (H12AffineFastState.compose env38662 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound38662 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38663 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,8192,0,8217,65536,0,65665,74027,8216,277,397,16,65797,65715,73770,73989,0,74030,76062,8204,8200,257,16,0,74298]

theorem envBound38663 : H12AffineFastState.Bounded env38663 := by
  intro p hp
  have h : env38663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38662_38663 : H12AffineEnvironment.transform 11 277 env38662 = env38663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env38662 == env38663) = true)

theorem identity38663 : scanCanonicalize (H12AffineFastState.compose env38663 (packedSelected [1,2,3,5,8,10,19,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound38663 : packedSelected [1,2,3,5,8,10,19,23,32] rootPS < 2^1333 := by decide +kernel

def env38664 : List Nat := [2,4,8,16,32,16,128,256,413,273,2048,277,8192,0,8217,65536,0,65665,74027,8216,277,397,16,65797,65715,73770,73989,0,74030,76062,8204,8200,257,16,0,74151]

theorem envBound38664 : H12AffineFastState.Bounded env38664 := by
  intro p hp
  have h : env38664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2