import H12CloudChart2Data123

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans30651_30652 : H12AffineEnvironment.transform 10 27 env30651 = env30652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env30651 == env30652) = true)

def env30653 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,65536,74047,65665,517,8476,773,648,74046,65537,9117,74299,303,74031,1,76575,8204,8200,257,74047,17,276]

theorem envBound30653 : H12AffineFastState.Bounded env30653 := by
  intro p hp
  have h : env30653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30637_30653 : H12AffineEnvironment.transform 5 1 env30637 = env30653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30637 == env30653) = true)

theorem identity30653 : scanCanonicalize (H12AffineFastState.compose env30653 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 62) := by decide +kernel

theorem selectedBound30653 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30654 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,62,0,291,65536,65793,65665,517,290,773,648,65792,65537,931,66053,303,65809,1,68385,50,54,257,65793,17,276]

theorem envBound30654 : H12AffineFastState.Bounded env30654 := by
  intro p hp
  have h : env30654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30653_30654 : H12AffineEnvironment.transform 12 62 env30653 = env30654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 62 env30653 == env30654) = true)

def env30655 : List Nat := [2,4,8,16,12,1,128,256,512,273,2048,772,18,0,271,65536,65793,65665,517,270,773,648,65792,65537,911,66053,259,65809,1,68365,30,26,257,65793,17,276]

theorem envBound30655 : H12AffineFastState.Bounded env30655 := by
  intro p hp
  have h : env30655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30654_30655 : H12AffineEnvironment.transform 4 12 env30654 = env30655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30654 == env30655) = true)

theorem identity30655 : scanCanonicalize (H12AffineFastState.compose env30655 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2698) := by decide +kernel

theorem selectedBound30655 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30656 : List Nat := [2,4,8,16,12,1,128,256,512,273,2048,772,18,0,271,2698,2955,2571,517,270,773,648,2954,2699,911,2191,259,2971,1,391,30,26,257,2955,17,276]

theorem envBound30656 : H12AffineFastState.Bounded env30656 := by
  intro p hp
  have h : env30656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30655_30656 : H12AffineEnvironment.transform 15 2698 env30655 = env30656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2698 env30655 == env30656) = true)

theorem identity30656 : scanCanonicalize (H12AffineFastState.compose env30656 (packedSelected [1,2,4,5,9,10,12,15,20,32] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30656 : packedSelected [1,2,4,5,9,10,12,15,20,32] rootPS < 2^1333 := by decide +kernel

def env30657 : List Nat := [2,4,8,12,12,1,128,256,512,269,2048,772,14,0,271,2698,2955,2571,517,270,773,648,2954,2699,911,2191,259,2951,1,391,2,6,257,2955,13,264]

theorem envBound30657 : H12AffineFastState.Bounded env30657 := by
  intro p hp
  have h : env30657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30656_30657 : H12AffineEnvironment.transform 3 12 env30656 = env30657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30656 == env30657) = true)

theorem identity30657 : scanCanonicalize (H12AffineFastState.compose env30657 (packedSelected [2,3,4,5,8,9,11,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 777) := by decide +kernel

theorem selectedBound30657 : packedSelected [2,3,4,5,8,9,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env30658 : List Nat := [2,4,8,12,12,1,128,256,512,269,777,772,14,0,271,387,130,258,517,270,773,648,131,386,911,902,259,142,1,391,2,6,257,130,13,264]

theorem envBound30658 : H12AffineFastState.Bounded env30658 := by
  intro p hp
  have h : env30658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30657_30658 : H12AffineEnvironment.transform 10 777 env30657 = env30658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 777 env30657 == env30658) = true)

theorem identity30658 : scanCanonicalize (H12AffineFastState.compose env30658 (packedSelected [1,3,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound30658 : packedSelected [1,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30659 : List Nat := [2,4,8,12,12,1,128,134,512,139,655,642,14,0,137,5,130,132,517,136,643,648,131,4,521,512,133,142,1,1,2,6,135,130,13,142]

theorem envBound30659 : H12AffineFastState.Bounded env30659 := by
  intro p hp
  have h : env30659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30658_30659 : H12AffineEnvironment.transform 7 134 env30658 = env30659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env30658 == env30659) = true)

theorem identity30659 : scanCanonicalize (H12AffineFastState.compose env30659 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound30659 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30660 : List Nat := [2,4,8,12,12,1,128,134,143,139,0,13,14,0,137,5,130,132,138,136,12,7,131,4,134,143,133,142,1,1,2,6,135,130,13,142]

theorem envBound30660 : H12AffineFastState.Bounded env30660 := by
  intro p hp
  have h : env30660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30659_30660 : H12AffineEnvironment.transform 8 143 env30659 = env30660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env30659 == env30660) = true)

theorem identity30660 : scanCanonicalize (H12AffineFastState.compose env30660 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound30660 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30661 : List Nat := [2,4,7,3,3,1,128,134,128,132,0,2,1,0,134,5,130,132,133,135,3,7,131,4,134,128,133,129,1,1,2,6,135,130,2,129]

theorem envBound30661 : H12AffineFastState.Bounded env30661 := by
  intro p hp
  have h : env30661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30660_30661 : H12AffineEnvironment.transform 2 7 env30660 = env30661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env30660 == env30661) = true)

theorem identity30661 : scanCanonicalize (H12AffineFastState.compose env30661 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound30661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30662 : List Nat := [2,4,7,3,3,1,1,7,1,5,0,2,1,0,7,5,3,5,4,6,3,7,2,4,7,1,4,0,1,1,2,6,6,3,2,0]

theorem envBound30662 : H12AffineFastState.Bounded env30662 := by
  intro p hp
  have h : env30662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30661_30662 : H12AffineEnvironment.transform 6 1 env30661 = env30662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env30661 == env30662) = true)

theorem identity30662 : scanCanonicalize (H12AffineFastState.compose env30662 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30662 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30663 : List Nat := [0,4,5,1,1,1,1,5,1,5,0,0,1,0,5,5,1,5,4,4,1,5,0,4,5,1,4,0,1,1,0,4,4,1,0,0]

theorem envBound30663 : H12AffineFastState.Bounded env30663 := by
  intro p hp
  have h : env30663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30662_30663 : H12AffineEnvironment.transform 0 0 env30662 = env30663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30662 == env30663) = true)

def env30664 : List Nat := [2,4,8,16,13,1,128,256,512,273,2048,772,19,0,270,65536,65793,65665,517,271,773,648,65792,65537,910,66053,258,65809,1,68364,31,27,257,65793,17,276]

theorem envBound30664 : H12AffineFastState.Bounded env30664 := by
  intro p hp
  have h : env30664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30654_30664 : H12AffineEnvironment.transform 4 13 env30654 = env30664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env30654 == env30664) = true)

theorem identity30664 : scanCanonicalize (H12AffineFastState.compose env30664 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2688) := by decide +kernel

theorem selectedBound30664 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30665 : List Nat := [2,4,8,16,13,1,128,256,512,273,2048,772,19,0,270,2688,2945,2561,517,271,773,648,2944,2689,910,2181,258,2961,1,396,31,27,257,2945,17,276]

theorem envBound30665 : H12AffineFastState.Bounded env30665 := by
  intro p hp
  have h : env30665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30664_30665 : H12AffineEnvironment.transform 15 2688 env30664 = env30665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2688 env30664 == env30665) = true)

theorem identity30665 : scanCanonicalize (H12AffineFastState.compose env30665 (packedSelected [0,2,5,8,9,11,12,13,17,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound30665 : packedSelected [0,2,5,8,9,11,12,13,17,21,23] rootPS < 2^1333 := by decide +kernel

def env30666 : List Nat := [2,4,8,16,13,1,128,256,512,273,148,772,19,0,270,532,789,661,517,271,773,648,788,533,910,17,258,773,1,396,31,27,257,789,17,276]

theorem envBound30666 : H12AffineFastState.Bounded env30666 := by
  intro p hp
  have h : env30666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30665_30666 : H12AffineEnvironment.transform 10 148 env30665 = env30666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env30665 == env30666) = true)

theorem identity30666 : scanCanonicalize (H12AffineFastState.compose env30666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30667 : List Nat := [2,4,8,16,13,1,128,4,512,21,148,512,19,0,10,532,529,661,517,11,513,648,528,533,650,17,6,513,1,136,31,27,5,529,17,16]

theorem envBound30667 : H12AffineFastState.Bounded env30667 := by
  intro p hp
  have h : env30667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30666_30667 : H12AffineEnvironment.transform 7 4 env30666 = env30667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30666 == env30667) = true)

theorem identity30667 : scanCanonicalize (H12AffineFastState.compose env30667 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 159) := by decide +kernel

theorem selectedBound30667 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30668 : List Nat := [2,4,8,16,13,1,128,4,159,21,148,159,19,0,10,139,142,10,154,11,158,23,143,138,21,17,6,158,1,136,31,27,5,142,17,16]

theorem envBound30668 : H12AffineFastState.Bounded env30668 := by
  intro p hp
  have h : env30668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30667_30668 : H12AffineEnvironment.transform 8 159 env30667 = env30668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 159 env30667 == env30668) = true)

def env30669 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,0,8540,65536,74110,65665,581,8541,772,649,74046,65600,9181,74298,366,74031,1,76639,8204,8200,257,74047,80,340]

theorem envBound30669 : H12AffineFastState.Bounded env30669 := by
  intro p hp
  have h : env30669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30636_30669 : H12AffineEnvironment.transform 11 773 env30636 = env30669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env30636 == env30669) = true)

def env30670 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,65536,74046,65665,517,8477,772,649,74046,65536,9117,74298,302,74031,1,76575,8204,8200,257,74047,16,276]

theorem envBound30670 : H12AffineFastState.Bounded env30670 := by
  intro p hp
  have h : env30670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30669_30670 : H12AffineEnvironment.transform 5 0 env30669 = env30670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30669 == env30670) = true)

theorem identity30670 : scanCanonicalize (H12AffineFastState.compose env30670 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8457) := by decide +kernel

theorem selectedBound30670 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30671 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,8457,55,8584,517,8477,772,649,55,8457,9117,819,302,38,1,2582,8204,8200,257,54,16,276]

theorem envBound30671 : H12AffineFastState.Bounded env30671 := by
  intro p hp
  have h : env30671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30670_30671 : H12AffineEnvironment.transform 15 8457 env30670 = env30671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8457 env30670 == env30671) = true)

def env30672 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,8192,0,8476,8457,55,8584,273,8477,16,413,55,8457,8329,39,302,38,1,2306,8204,8200,257,54,16,276]

theorem envBound30672 : H12AffineFastState.Bounded env30672 := by
  intro p hp
  have h : env30672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30671_30672 : H12AffineEnvironment.transform 8 276 env30671 = env30672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env30671 == env30672) = true)

theorem identity30672 : scanCanonicalize (H12AffineFastState.compose env30672 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30672 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30673 : List Nat := [2,4,8,16,32,0,128,5,17,20,2048,17,8192,0,8217,8204,55,8333,20,8216,16,152,55,8204,8329,39,43,38,1,2055,8204,8200,4,54,16,17]

theorem envBound30673 : H12AffineFastState.Bounded env30673 := by
  intro p hp
  have h : env30673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30672_30673 : H12AffineEnvironment.transform 7 5 env30672 = env30673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30672 == env30673) = true)

theorem identity30673 : scanCanonicalize (H12AffineFastState.compose env30673 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30673 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30674 : List Nat := [2,4,8,1,32,0,128,5,0,5,2048,0,8192,0,8200,8204,38,8333,5,8201,1,137,38,8204,8329,39,43,38,1,2055,8204,8200,4,39,1,0]

theorem envBound30674 : H12AffineFastState.Bounded env30674 := by
  intro p hp
  have h : env30674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30673_30674 : H12AffineEnvironment.transform 3 1 env30673 = env30674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30673 == env30674) = true)

theorem identity30674 : scanCanonicalize (H12AffineFastState.compose env30674 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30674 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env30675 : List Nat := [2,4,8,1,32,0,4,5,0,5,2048,0,8192,0,8200,8204,38,8201,5,8201,1,13,38,8204,8205,39,43,38,1,2055,8204,8200,4,39,1,0]

theorem envBound30675 : H12AffineFastState.Bounded env30675 := by
  intro p hp
  have h : env30675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30674_30675 : H12AffineEnvironment.transform 6 4 env30674 = env30675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30674 == env30675) = true)

theorem identity30675 : scanCanonicalize (H12AffineFastState.compose env30675 (packedSelected [3,5,7,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30675 : packedSelected [3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env30676 : List Nat := [2,4,4,1,32,0,4,5,0,5,2048,0,8192,0,8196,8192,38,8197,5,8197,1,1,38,8192,8193,39,39,38,1,2055,8192,8196,4,39,1,0]

theorem envBound30676 : H12AffineFastState.Bounded env30676 := by
  intro p hp
  have h : env30676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30675_30676 : H12AffineEnvironment.transform 2 4 env30675 = env30676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30675 == env30676) = true)

theorem identity30676 : scanCanonicalize (H12AffineFastState.compose env30676 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2052) := by decide +kernel

theorem selectedBound30676 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30677 : List Nat := [2,4,4,1,32,0,4,5,0,5,2048,0,2052,0,2048,2052,38,2049,5,2049,1,1,38,2052,2053,39,39,38,1,2055,2052,2048,4,39,1,0]

theorem envBound30677 : H12AffineFastState.Bounded env30677 := by
  intro p hp
  have h : env30677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30676_30677 : H12AffineEnvironment.transform 12 2052 env30676 = env30677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2052 env30676 == env30677) = true)

theorem identity30677 : scanCanonicalize (H12AffineFastState.compose env30677 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound30677 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env30678 : List Nat := [2,4,4,1,32,0,4,5,0,5,7,0,3,0,7,3,38,6,5,6,1,1,38,3,2,39,39,38,1,0,3,7,4,39,1,0]

theorem envBound30678 : H12AffineFastState.Bounded env30678 := by
  intro p hp
  have h : env30678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30677_30678 : H12AffineEnvironment.transform 10 7 env30677 = env30678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env30677 == env30678) = true)

def env30679 : List Nat := [2,4,8,16,32,0,128,256,277,273,2048,16,8192,0,8476,8457,55,8584,272,8477,17,412,55,8457,8328,38,302,38,1,2307,8204,8200,257,54,16,276]

theorem envBound30679 : H12AffineFastState.Bounded env30679 := by
  intro p hp
  have h : env30679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30671_30679 : H12AffineEnvironment.transform 8 277 env30671 = env30679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env30671 == env30679) = true)

theorem identity30679 : scanCanonicalize (H12AffineFastState.compose env30679 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound30679 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30680 : List Nat := [2,4,8,16,32,0,128,50,39,35,2048,16,8192,0,8238,8251,55,8378,34,8239,17,174,55,8251,8328,38,28,38,1,2097,8204,8200,51,54,16,38]

theorem envBound30680 : H12AffineFastState.Bounded env30680 := by
  intro p hp
  have h : env30680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30679_30680 : H12AffineEnvironment.transform 7 50 env30679 = env30680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env30679 == env30680) = true)

theorem identity30680 : scanCanonicalize (H12AffineFastState.compose env30680 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound30680 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30681 : List Nat := [2,4,8,16,32,0,128,50,39,35,2048,16,47,0,1,20,55,149,34,0,17,174,55,20,167,38,28,38,1,2097,35,39,51,54,16,38]

theorem envBound30681 : H12AffineFastState.Bounded env30681 := by
  intro p hp
  have h : env30681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30680_30681 : H12AffineEnvironment.transform 12 47 env30680 = env30681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env30680 == env30681) = true)

theorem identity30681 : scanCanonicalize (H12AffineFastState.compose env30681 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound30681 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30682 : List Nat := [2,4,8,16,23,0,128,5,16,20,2048,16,24,0,1,20,0,149,21,0,17,153,0,20,144,17,28,17,1,2054,20,16,4,1,16,17]

theorem envBound30682 : H12AffineFastState.Bounded env30682 := by
  intro p hp
  have h : env30682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30681_30682 : H12AffineEnvironment.transform 4 23 env30681 = env30682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env30681 == env30682) = true)

theorem identity30682 : scanCanonicalize (H12AffineFastState.compose env30682 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound30682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30683 : List Nat := [2,4,8,16,23,0,128,5,16,20,11,16,24,0,1,20,0,149,21,0,17,153,0,20,144,17,28,17,1,13,20,16,4,1,16,17]

theorem envBound30683 : H12AffineFastState.Bounded env30683 := by
  intro p hp
  have h : env30683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30682_30683 : H12AffineEnvironment.transform 10 11 env30682 = env30683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env30682 == env30683) = true)

theorem identity30683 : scanCanonicalize (H12AffineFastState.compose env30683 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound30683 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30684 : List Nat := [2,4,8,16,23,0,31,5,16,20,11,16,24,0,1,20,0,10,21,0,17,6,0,20,15,17,28,17,1,13,20,16,4,1,16,17]

theorem envBound30684 : H12AffineFastState.Bounded env30684 := by
  intro p hp
  have h : env30684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30683_30684 : H12AffineEnvironment.transform 6 31 env30683 = env30684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env30683 == env30684) = true)

theorem identity30684 : scanCanonicalize (H12AffineFastState.compose env30684 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30684 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30685 : List Nat := [2,4,8,10,13,0,5,5,10,14,11,10,2,0,1,14,0,10,15,0,11,6,0,14,15,11,6,11,1,13,14,10,4,1,10,11]

theorem envBound30685 : H12AffineFastState.Bounded env30685 := by
  intro p hp
  have h : env30685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30684_30685 : H12AffineEnvironment.transform 3 10 env30684 = env30685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30684 == env30685) = true)

theorem identity30685 : scanCanonicalize (H12AffineFastState.compose env30685 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound30685 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30686 : List Nat := [2,4,0,2,5,0,5,5,2,6,3,2,2,0,1,6,0,2,7,0,3,6,0,6,7,3,6,3,1,5,6,2,4,1,2,3]

theorem envBound30686 : H12AffineFastState.Bounded env30686 := by
  intro p hp
  have h : env30686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30685_30686 : H12AffineEnvironment.transform 2 0 env30685 = env30686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env30685 == env30686) = true)

theorem identity30686 : scanCanonicalize (H12AffineFastState.compose env30686 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30686 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30687 : List Nat := [1,4,0,1,5,0,5,5,1,5,0,1,1,0,1,5,0,1,4,0,0,5,0,5,4,0,5,0,1,5,5,1,4,1,1,0]

theorem envBound30687 : H12AffineFastState.Bounded env30687 := by
  intro p hp
  have h : env30687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30686_30687 : H12AffineEnvironment.transform 0 1 env30686 = env30687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30686 == env30687) = true)

theorem identity30687 : scanCanonicalize (H12AffineFastState.compose env30687 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30687 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30688 : List Nat := [1,1,0,1,0,0,0,0,1,0,0,1,1,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,0,0,1,1,1,1,0]

theorem envBound30688 : H12AffineFastState.Bounded env30688 := by
  intro p hp
  have h : env30688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30687_30688 : H12AffineEnvironment.transform 1 1 env30687 = env30688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30687 == env30688) = true)

def env30689 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,65536,74047,65665,516,8476,772,649,74046,65537,9116,74298,303,74031,1,76574,8204,8200,257,74047,17,277]

theorem envBound30689 : H12AffineFastState.Bounded env30689 := by
  intro p hp
  have h : env30689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30669_30689 : H12AffineEnvironment.transform 5 1 env30669 = env30689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30669 == env30689) = true)

theorem identity30689 : scanCanonicalize (H12AffineFastState.compose env30689 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 272) := by decide +kernel

theorem selectedBound30689 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30690 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,272,8239,401,516,8476,772,649,8238,273,9116,9002,303,8255,1,10766,8204,8200,257,8239,17,277]

theorem envBound30690 : H12AffineFastState.Bounded env30690 := by
  intro p hp
  have h : env30690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30689_30690 : H12AffineEnvironment.transform 15 272 env30689 = env30690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 272 env30689 == env30690) = true)

def env30691 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,24,0,261,272,55,401,516,260,772,649,54,273,900,818,303,39,1,2582,20,16,257,55,17,277]

theorem envBound30691 : H12AffineFastState.Bounded env30691 := by
  intro p hp
  have h : env30691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30690_30691 : H12AffineEnvironment.transform 12 24 env30690 = env30691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30690 == env30691) = true)

theorem identity30691 : scanCanonicalize (H12AffineFastState.compose env30691 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30691 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30692 : List Nat := [2,4,8,16,32,1,128,4,512,21,2048,513,24,0,1,20,55,149,516,0,512,649,54,21,640,566,43,39,1,2582,20,16,5,55,17,17]

theorem envBound30692 : H12AffineFastState.Bounded env30692 := by
  intro p hp
  have h : env30692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30691_30692 : H12AffineEnvironment.transform 7 4 env30691 = env30692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30691 == env30692) = true)

theorem identity30692 : scanCanonicalize (H12AffineFastState.compose env30692 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound30692 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env30693 : List Nat := [2,4,8,16,32,1,128,4,512,21,697,513,24,0,1,20,55,149,516,0,512,649,54,21,640,566,43,39,1,175,20,16,5,55,17,17]

theorem envBound30693 : H12AffineFastState.Bounded env30693 := by
  intro p hp
  have h : env30693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30692_30693 : H12AffineEnvironment.transform 10 697 env30692 = env30693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env30692 == env30693) = true)

theorem identity30693 : scanCanonicalize (H12AffineFastState.compose env30693 (packedSelected [8,13] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound30693 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env30694 : List Nat := [2,4,8,16,32,1,128,4,142,21,55,143,24,0,1,20,55,149,138,0,142,7,54,21,14,184,43,39,1,175,20,16,5,55,17,17]

theorem envBound30694 : H12AffineFastState.Bounded env30694 := by
  intro p hp
  have h : env30694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30693_30694 : H12AffineEnvironment.transform 8 142 env30693 = env30694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env30693 == env30694) = true)

theorem identity30694 : scanCanonicalize (H12AffineFastState.compose env30694 (packedSelected [4,5,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound30694 : packedSelected [4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30695 : List Nat := [2,4,8,16,32,1,62,4,48,21,55,49,24,0,1,20,55,43,52,0,48,7,54,21,14,6,43,39,1,17,20,16,5,55,17,17]

theorem envBound30695 : H12AffineFastState.Bounded env30695 := by
  intro p hp
  have h : env30695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30694_30695 : H12AffineEnvironment.transform 6 62 env30694 = env30695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env30694 == env30695) = true)

theorem identity30695 : scanCanonicalize (H12AffineFastState.compose env30695 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30695 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30696 : List Nat := [2,4,8,1,32,1,47,4,33,4,38,32,9,0,1,5,38,43,37,0,33,7,39,4,14,6,43,39,1,0,5,1,5,38,0,0]

theorem envBound30696 : H12AffineFastState.Bounded env30696 := by
  intro p hp
  have h : env30696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30695_30696 : H12AffineEnvironment.transform 3 1 env30695 = env30696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30695 == env30696) = true)

theorem identity30696 : scanCanonicalize (H12AffineFastState.compose env30696 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30697 : List Nat := [2,4,8,1,7,1,8,4,6,4,1,7,9,0,1,5,1,12,2,0,6,7,0,4,14,6,12,0,1,0,5,1,5,1,0,0]

theorem envBound30697 : H12AffineFastState.Bounded env30697 := by
  intro p hp
  have h : env30697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30696_30697 : H12AffineEnvironment.transform 4 7 env30696 = env30697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30696 == env30697) = true)

theorem identity30697 : scanCanonicalize (H12AffineFastState.compose env30697 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30697 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30698 : List Nat := [2,4,3,1,7,1,3,4,6,4,1,7,2,0,1,5,1,7,2,0,6,7,0,4,5,6,7,0,1,0,5,1,5,1,0,0]

theorem envBound30698 : H12AffineFastState.Bounded env30698 := by
  intro p hp
  have h : env30698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30697_30698 : H12AffineEnvironment.transform 2 3 env30697 = env30698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30697 == env30698) = true)

theorem identity30698 : scanCanonicalize (H12AffineFastState.compose env30698 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30699 : List Nat := [2,3,3,1,0,1,3,3,1,3,1,0,2,0,1,2,1,0,2,0,1,0,0,3,2,1,0,0,1,0,2,1,2,1,0,0]

theorem envBound30699 : H12AffineFastState.Bounded env30699 := by
  intro p hp
  have h : env30699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30698_30699 : H12AffineEnvironment.transform 1 3 env30698 = env30699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30698 == env30699) = true)

theorem identity30699 : scanCanonicalize (H12AffineFastState.compose env30699 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30700 : List Nat := [0,1,1,1,0,1,1,1,1,1,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0,1,0,0,1,0,0,1,0,1,0,0]

theorem envBound30700 : H12AffineFastState.Bounded env30700 := by
  intro p hp
  have h : env30700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30699_30700 : H12AffineEnvironment.transform 0 0 env30699 = env30700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30699 == env30700) = true)

def env30701 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,25,0,260,272,54,401,516,261,772,649,55,273,901,819,303,38,1,2583,21,17,257,54,17,277]

theorem envBound30701 : H12AffineFastState.Bounded env30701 := by
  intro p hp
  have h : env30701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30690_30701 : H12AffineEnvironment.transform 12 25 env30690 = env30701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30690 == env30701) = true)

theorem identity30701 : scanCanonicalize (H12AffineFastState.compose env30701 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30701 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30702 : List Nat := [2,4,8,16,32,1,128,256,17,273,2048,276,25,0,260,272,54,401,21,261,277,152,55,273,404,290,303,38,1,2054,21,17,257,54,17,277]

theorem envBound30702 : H12AffineFastState.Bounded env30702 := by
  intro p hp
  have h : env30702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30701_30702 : H12AffineEnvironment.transform 8 17 env30701 = env30702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30701 == env30702) = true)

theorem identity30702 : scanCanonicalize (H12AffineFastState.compose env30702 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30702 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env30703 : List Nat := [2,4,8,16,32,1,128,4,17,21,2048,16,25,0,0,20,54,149,21,1,17,152,55,21,144,38,43,38,1,2054,21,17,5,54,17,17]

theorem envBound30703 : H12AffineFastState.Bounded env30703 := by
  intro p hp
  have h : env30703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30702_30703 : H12AffineEnvironment.transform 7 4 env30702 = env30703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30702 == env30703) = true)

theorem identity30703 : scanCanonicalize (H12AffineFastState.compose env30703 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound30703 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30704 : List Nat := [2,4,8,16,32,1,63,4,17,21,2048,16,25,0,0,20,54,42,21,1,17,39,55,21,47,38,43,38,1,2054,21,17,5,54,17,17]

theorem envBound30704 : H12AffineFastState.Bounded env30704 := by
  intro p hp
  have h : env30704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30703_30704 : H12AffineEnvironment.transform 6 63 env30703 = env30704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env30703 == env30704) = true)

theorem identity30704 : scanCanonicalize (H12AffineFastState.compose env30704 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound30704 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30705 : List Nat := [2,4,8,13,32,1,34,4,12,8,2048,13,4,0,0,9,43,42,8,1,12,39,42,8,47,38,43,38,1,2054,8,12,5,43,12,12]

theorem envBound30705 : H12AffineFastState.Bounded env30705 := by
  intro p hp
  have h : env30705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30704_30705 : H12AffineEnvironment.transform 3 13 env30704 = env30705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env30704 == env30705) = true)

theorem identity30705 : scanCanonicalize (H12AffineFastState.compose env30705 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound30705 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30706 : List Nat := [2,4,8,13,32,1,34,4,12,8,6,13,4,0,0,9,43,42,8,1,12,39,42,8,47,38,43,38,1,0,8,12,5,43,12,12]

theorem envBound30706 : H12AffineFastState.Bounded env30706 := by
  intro p hp
  have h : env30706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30705_30706 : H12AffineEnvironment.transform 10 6 env30705 = env30706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env30705 == env30706) = true)

def env30707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123165,533641,614527,385202,90415,545089,96346,25884,536905,257,74798,1345,525824]

theorem envBound30707 : H12AffineFastState.Bounded env30707 := by
  intro p hp
  have h : env30707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30206_30707 : H12AffineEnvironment.transform 23 123165 env30206 = env30707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env30206 == env30707) = true)

def env30708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123165,28889,78895,385202,90415,1297,96346,25884,25881,257,74798,1345,21072]

theorem envBound30708 : H12AffineFastState.Bounded env30708 := by
  intro p hp
  have h : env30708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30707_30708 : H12AffineEnvironment.transform 18 21584 env30707 = env30708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env30707 == env30708) = true)

theorem identity30708 : scanCanonicalize (H12AffineFastState.compose env30708 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound30708 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4097,17613,91183,87296,28889,78895,349359,90415,1297,96346,25884,25881,257,74798,1345,21072]

theorem envBound30709 : H12AffineFastState.Bounded env30709 := by
  intro p hp
  have h : env30709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30708_30709 : H12AffineEnvironment.transform 14 13341 env30708 = env30709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env30708 == env30709) = true)

def env30710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4097,477,74047,69648,13769,78895,332223,74815,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound30710 : H12AffineFastState.Bounded env30710 := by
  intro p hp
  have h : env30710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30709_30710 : H12AffineEnvironment.transform 13 1296 env30709 = env30710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env30709 == env30710) = true)

def env30711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4097,477,74047,69648,13769,78895,4415,74815,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound30711 : H12AffineFastState.Bounded env30711 := by
  intro p hp
  have h : env30711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30710_30711 : H12AffineEnvironment.transform 17 65664 env30710 = env30711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30710 == env30711) = true)

theorem identity30711 : scanCanonicalize (H12AffineFastState.compose env30711 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound30711 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5239,12312,5367,4416,13340,4097,477,13640,1127,13769,8280,4415,12360,1297,10557,8204,8201,257,12377,1345,5952]

theorem envBound30712 : H12AffineFastState.Bounded env30712 := by
  intro p hp
  have h : env30712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30711_30712 : H12AffineEnvironment.transform 15 5239 env30711 = env30712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env30711 == env30712) = true)

def env30713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,325,5239,1344,5367,4416,324,4097,477,16,1127,145,5376,4415,1296,1297,7269,5460,5457,257,1281,1345,5952]

theorem envBound30713 : H12AffineFastState.Bounded env30713 := by
  intro p hp
  have h : env30713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30712_30713 : H12AffineEnvironment.transform 12 5464 env30712 = env30713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env30712 == env30713) = true)

theorem identity30713 : scanCanonicalize (H12AffineFastState.compose env30713 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30713 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30714 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4445,277,325,4210,325,4338,4416,324,4097,477,16,98,145,4357,4415,277,276,6240,4433,4436,257,260,324,4933]

theorem envBound30714 : H12AffineFastState.Bounded env30714 := by
  intro p hp
  have h : env30714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30713_30714 : H12AffineEnvironment.transform 9 5 env30713 = env30714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30713 == env30714) = true)

theorem identity30714 : scanCanonicalize (H12AffineFastState.compose env30714 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound30714 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30715 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,325,24,277,325,311,325,439,5,324,324,477,16,98,145,64,122,277,276,2341,20,17,257,260,324,512]

theorem envBound30715 : H12AffineFastState.Bounded env30715 := by
  intro p hp
  have h : env30715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30714_30715 : H12AffineEnvironment.transform 11 325 env30714 = env30715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env30714 == env30715) = true)

theorem identity30715 : scanCanonicalize (H12AffineFastState.compose env30715 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound30715 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env30716 : List Nat := [2,4,8,16,32,64,128,256,512,5,319,325,24,277,325,311,325,439,5,324,324,477,16,98,145,64,122,277,276,26,20,17,257,260,324,512]

theorem envBound30716 : H12AffineFastState.Bounded env30716 := by
  intro p hp
  have h : env30716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30715_30716 : H12AffineEnvironment.transform 10 319 env30715 = env30716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env30715 == env30716) = true)

theorem identity30716 : scanCanonicalize (H12AffineFastState.compose env30716 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound30716 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30717 : List Nat := [2,4,8,16,32,64,128,256,97,5,319,325,24,277,325,311,325,439,5,324,324,477,16,98,145,64,122,277,276,26,20,17,257,260,324,97]

theorem envBound30717 : H12AffineFastState.Bounded env30717 := by
  intro p hp
  have h : env30717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30716_30717 : H12AffineEnvironment.transform 8 97 env30716 = env30717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env30716 == env30717) = true)

theorem identity30717 : scanCanonicalize (H12AffineFastState.compose env30717 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound30717 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30718 : List Nat := [2,4,8,16,32,64,128,253,97,5,194,184,24,232,184,202,184,74,5,185,185,32,16,98,145,64,122,232,233,26,20,17,252,249,185,97]

theorem envBound30718 : H12AffineFastState.Bounded env30718 := by
  intro p hp
  have h : env30718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30717_30718 : H12AffineEnvironment.transform 7 253 env30717 = env30718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env30717 == env30718) = true)

theorem identity30718 : scanCanonicalize (H12AffineFastState.compose env30718 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound30718 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env30719 : List Nat := [2,4,8,16,32,33,128,156,0,5,163,184,24,137,184,171,184,43,5,185,185,32,16,3,145,33,27,137,136,26,20,17,157,152,185,0]

theorem envBound30719 : H12AffineFastState.Bounded env30719 := by
  intro p hp
  have h : env30719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30718_30719 : H12AffineEnvironment.transform 5 33 env30718 = env30719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env30718 == env30719) = true)

theorem identity30719 : scanCanonicalize (H12AffineFastState.compose env30719 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound30719 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30720 : List Nat := [2,4,8,16,32,33,18,14,0,5,49,42,24,27,42,57,42,43,5,43,43,32,16,3,3,33,27,27,26,26,20,17,15,10,43,0]

theorem envBound30720 : H12AffineFastState.Bounded env30720 := by
  intro p hp
  have h : env30720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30719_30720 : H12AffineEnvironment.transform 6 18 env30719 = env30720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env30719 == env30720) = true)

theorem identity30720 : scanCanonicalize (H12AffineFastState.compose env30720 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30720 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30721 : List Nat := [2,4,8,16,10,11,18,14,0,5,27,0,24,27,0,19,0,1,5,1,1,10,16,3,3,11,27,27,26,26,20,17,15,10,1,0]

theorem envBound30721 : H12AffineFastState.Bounded env30721 := by
  intro p hp
  have h : env30721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30720_30721 : H12AffineEnvironment.transform 4 10 env30720 = env30721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30720 == env30721) = true)

def env30722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,5239,1345,5367,4416,325,4097,477,17,1127,144,5377,4415,1297,1297,7268,5461,5456,257,1280,1345,5952]

theorem envBound30722 : H12AffineFastState.Bounded env30722 := by
  intro p hp
  have h : env30722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30712_30722 : H12AffineEnvironment.transform 12 5465 env30712 = env30722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env30712 == env30722) = true)

theorem identity30722 : scanCanonicalize (H12AffineFastState.compose env30722 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound30722 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30723 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,81,324,4406,0,4534,4416,325,4097,477,17,294,144,4160,4415,80,80,6437,4116,4113,257,65,0,4609]

theorem envBound30723 : H12AffineFastState.Bounded env30723 := by
  intro p hp
  have h : env30723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30722_30723 : H12AffineEnvironment.transform 9 321 env30722 = env30723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env30722 == env30723) = true)

theorem identity30723 : scanCanonicalize (H12AffineFastState.compose env30723 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound30723 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30724 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,4096,4120,81,232,4250,0,4122,4332,233,4097,113,17,138,144,4160,4243,80,80,6281,4116,4113,173,65,0,4609]

theorem envBound30724 : H12AffineFastState.Bounded env30724 := by
  intro p hp
  have h : env30724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30723_30724 : H12AffineEnvironment.transform 7 172 env30723 = env30724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30723 == env30724) = true)

theorem identity30724 : scanCanonicalize (H12AffineFastState.compose env30724 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2802) := by decide +kernel

theorem selectedBound30724 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30725 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,2802,2794,81,232,2664,0,2792,2590,233,2803,113,17,138,144,2738,2657,80,80,635,2790,2787,173,65,0,2291]

theorem envBound30725 : H12AffineFastState.Bounded env30725 := by
  intro p hp
  have h : env30725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30724_30725 : H12AffineEnvironment.transform 11 2802 env30724 = env30725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2802 env30724 == env30725) = true)

theorem identity30725 : scanCanonicalize (H12AffineFastState.compose env30725 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30725 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env30726 : List Nat := [2,4,8,16,11,64,128,135,512,198,2048,2777,2753,81,195,2627,0,2755,2590,194,2776,90,17,138,144,2713,2634,80,80,592,2765,2760,134,65,0,2264]

theorem envBound30726 : H12AffineFastState.Bounded env30726 := by
  intro p hp
  have h : env30726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30725_30726 : H12AffineEnvironment.transform 4 11 env30725 = env30726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30725 == env30726) = true)

theorem identity30726 : scanCanonicalize (H12AffineFastState.compose env30726 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30726 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30727 : List Nat := [2,4,8,16,11,64,89,94,512,31,2048,2560,2584,81,26,2627,0,2586,2590,27,2561,90,17,83,73,2624,2634,80,80,592,2580,2577,95,65,0,2049]

theorem envBound30727 : H12AffineFastState.Bounded env30727 := by
  intro p hp
  have h : env30727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30726_30727 : H12AffineEnvironment.transform 6 89 env30726 = env30727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30726 == env30727) = true)

theorem identity30727 : scanCanonicalize (H12AffineFastState.compose env30727 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound30727 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30728 : List Nat := [2,4,8,16,11,64,89,94,512,31,587,75,83,81,26,8,0,81,85,27,74,90,17,83,73,11,1,80,80,592,95,90,95,65,0,586]

theorem envBound30728 : H12AffineFastState.Bounded env30728 := by
  intro p hp
  have h : env30728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30727_30728 : H12AffineEnvironment.transform 10 587 env30727 = env30728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env30727 == env30728) = true)

theorem identity30728 : scanCanonicalize (H12AffineFastState.compose env30728 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound30728 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30729 : List Nat := [2,4,8,16,11,64,89,94,74,31,1,75,83,81,26,8,0,81,85,27,74,90,17,83,73,11,1,80,80,26,95,90,95,65,0,0]

theorem envBound30729 : H12AffineFastState.Bounded env30729 := by
  intro p hp
  have h : env30729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30728_30729 : H12AffineEnvironment.transform 8 74 env30728 = env30729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env30728 == env30729) = true)

theorem identity30729 : scanCanonicalize (H12AffineFastState.compose env30729 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30729 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30730 : List Nat := [2,4,8,16,11,16,9,14,26,31,1,27,3,1,26,8,0,1,5,27,26,10,17,3,25,11,1,0,0,26,15,10,15,17,0,0]

theorem envBound30730 : H12AffineFastState.Bounded env30730 := by
  intro p hp
  have h : env30730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30729_30730 : H12AffineEnvironment.transform 5 16 env30729 = env30730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30729 == env30730) = true)

theorem identity30730 : scanCanonicalize (H12AffineFastState.compose env30730 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30730 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30731 : List Nat := [2,4,8,11,11,11,9,14,1,4,1,0,3,1,1,8,0,1,5,0,1,10,10,3,2,11,1,0,0,1,15,10,15,10,0,0]

theorem envBound30731 : H12AffineFastState.Bounded env30731 := by
  intro p hp
  have h : env30731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30730_30731 : H12AffineEnvironment.transform 3 11 env30730 = env30731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30730 == env30731) = true)

theorem identity30731 : scanCanonicalize (H12AffineFastState.compose env30731 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound30731 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30732 : List Nat := [2,4,6,5,5,5,7,0,1,4,1,0,3,1,1,6,0,1,5,0,1,4,4,3,2,5,1,0,0,1,1,4,1,4,0,0]

theorem envBound30732 : H12AffineFastState.Bounded env30732 := by
  intro p hp
  have h : env30732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30731_30732 : H12AffineEnvironment.transform 2 6 env30731 = env30732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env30731 == env30732) = true)

theorem identity30732 : scanCanonicalize (H12AffineFastState.compose env30732 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30733 : List Nat := [2,2,0,3,3,3,1,0,1,2,1,0,3,1,1,0,0,1,3,0,1,2,2,3,2,3,1,0,0,1,1,2,1,2,0,0]

theorem envBound30733 : H12AffineFastState.Bounded env30733 := by
  intro p hp
  have h : env30733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30732_30733 : H12AffineEnvironment.transform 1 2 env30732 = env30733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30732 == env30733) = true)

theorem identity30733 : scanCanonicalize (H12AffineFastState.compose env30733 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30733 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30734 : List Nat := [0,0,0,1,1,1,1,0,1,0,1,0,1,1,1,0,0,1,1,0,1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,0]

theorem envBound30734 : H12AffineFastState.Bounded env30734 := by
  intro p hp
  have h : env30734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30733_30734 : H12AffineEnvironment.transform 0 0 env30733 = env30734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30733 == env30734) = true)

def env30735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4097,477,74047,69648,13769,78895,4414,74815,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound30735 : H12AffineFastState.Bounded env30735 := by
  intro p hp
  have h : env30735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30710_30735 : H12AffineEnvironment.transform 17 65665 env30710 = env30735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30710 == env30735) = true)

theorem identity30735 : scanCanonicalize (H12AffineFastState.compose env30735 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound30735 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,310,9561,439,4416,13340,4097,477,8201,4390,13769,13593,4414,9481,1297,15484,8204,8201,257,9496,1345,5952]

theorem envBound30736 : H12AffineFastState.Bounded env30736 := by
  intro p hp
  have h : env30736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30735_30736 : H12AffineEnvironment.transform 15 310 env30735 = env30736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env30735 == env30736) = true)

def env30737 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,310,8265,439,4416,12556,4097,477,8201,4390,12505,12297,4414,8217,1,14700,8204,8201,257,8200,81,4688]

theorem envBound30737 : H12AffineFastState.Bounded env30737 := by
  intro p hp
  have h : env30737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30736_30737 : H12AffineEnvironment.transform 9 272 env30736 = env30737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30736 == env30737) = true)

theorem identity30737 : scanCanonicalize (H12AffineFastState.compose env30737 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound30737 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30738 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4444,0,81,310,4373,439,4416,80,4097,477,4437,4390,389,341,4414,4421,1,2096,4432,4437,257,4436,81,4688]

theorem envBound30738 : H12AffineFastState.Bounded env30738 := by
  intro p hp
  have h : env30738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30737_30738 : H12AffineEnvironment.transform 12 4444 env30737 = env30738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env30737 == env30738) = true)

theorem identity30738 : scanCanonicalize (H12AffineFastState.compose env30738 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound30738 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30739 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,184,484,0,81,310,429,439,504,80,185,477,493,414,389,341,390,509,1,2096,488,493,257,492,81,744]

theorem envBound30739 : H12AffineFastState.Bounded env30739 := by
  intro p hp
  have h : env30739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30738_30739 : H12AffineEnvironment.transform 11 184 env30738 = env30739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env30738 == env30739) = true)

theorem identity30739 : scanCanonicalize (H12AffineFastState.compose env30739 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 645) := by decide +kernel

theorem selectedBound30739 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env30740 : List Nat := [2,4,8,16,32,64,128,256,512,272,645,184,484,0,81,310,429,439,504,80,185,477,493,414,389,341,390,509,1,693,488,493,257,492,81,744]

theorem envBound30740 : H12AffineFastState.Bounded env30740 := by
  intro p hp
  have h : env30740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30739_30740 : H12AffineEnvironment.transform 10 645 env30739 = env30740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 645 env30739 == env30740) = true)

theorem identity30740 : scanCanonicalize (H12AffineFastState.compose env30740 (packedSelected [0,3,7,10,13,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 218) := by decide +kernel

theorem selectedBound30740 : packedSelected [0,3,7,10,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env30741 : List Nat := [2,4,8,16,32,64,128,218,512,202,645,184,62,0,81,236,119,109,34,80,185,7,55,68,95,143,92,39,1,693,50,55,219,54,81,744]

theorem envBound30741 : H12AffineFastState.Bounded env30741 := by
  intro p hp
  have h : env30741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30740_30741 : H12AffineEnvironment.transform 7 218 env30740 = env30741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 218 env30740 == env30741) = true)

theorem identity30741 : scanCanonicalize (H12AffineFastState.compose env30741 (packedSelected [0,1,2,4,7,8,9,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound30741 : packedSelected [0,1,2,4,7,8,9,12,17] rootPS < 2^1333 := by decide +kernel

def env30742 : List Nat := [2,4,8,16,32,58,128,160,512,176,645,184,62,0,43,150,13,23,34,42,185,7,55,62,37,143,38,39,1,693,50,55,161,54,43,658]

theorem envBound30742 : H12AffineFastState.Bounded env30742 := by
  intro p hp
  have h : env30742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30741_30742 : H12AffineEnvironment.transform 5 58 env30741 = env30742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env30741 == env30742) = true)

theorem identity30742 : scanCanonicalize (H12AffineFastState.compose env30742 (packedSelected [1,2,3,5,7,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30742 : packedSelected [1,2,3,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env30743 : List Nat := [2,4,8,16,32,58,128,160,136,176,13,184,62,0,43,150,13,23,34,42,185,7,55,62,37,143,38,39,1,61,50,55,161,54,43,26]

theorem envBound30743 : H12AffineFastState.Bounded env30743 := by
  intro p hp
  have h : env30743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30742_30743 : H12AffineEnvironment.transform 8 136 env30742 = env30743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30742 == env30743) = true)

theorem identity30743 : scanCanonicalize (H12AffineFastState.compose env30743 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30743 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30744 : List Nat := [2,4,8,16,17,11,128,145,136,129,13,137,15,0,26,150,13,23,19,27,136,7,6,15,20,143,23,22,1,12,3,6,144,7,26,26]

theorem envBound30744 : H12AffineFastState.Bounded env30744 := by
  intro p hp
  have h : env30744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30743_30744 : H12AffineEnvironment.transform 4 17 env30743 = env30744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30743 == env30744) = true)

theorem identity30744 : scanCanonicalize (H12AffineFastState.compose env30744 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30744 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30745 : List Nat := [2,4,4,16,17,7,128,145,132,129,1,133,3,0,22,150,1,23,19,23,132,7,6,3,20,131,23,22,1,0,3,6,144,7,22,22]

theorem envBound30745 : H12AffineFastState.Bounded env30745 := by
  intro p hp
  have h : env30745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30744_30745 : H12AffineEnvironment.transform 2 4 env30744 = env30745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30744 == env30745) = true)

theorem identity30745 : scanCanonicalize (H12AffineFastState.compose env30745 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30745 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30746 : List Nat := [2,4,4,16,17,7,4,21,0,5,1,1,3,0,22,18,1,23,19,23,0,7,6,3,20,7,23,22,1,0,3,6,20,7,22,22]

theorem envBound30746 : H12AffineFastState.Bounded env30746 := by
  intro p hp
  have h : env30746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30745_30746 : H12AffineEnvironment.transform 6 4 env30745 = env30746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30745 == env30746) = true)

theorem identity30746 : scanCanonicalize (H12AffineFastState.compose env30746 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30747 : List Nat := [2,4,4,7,6,7,4,2,0,5,1,1,3,0,1,5,1,0,4,0,0,7,6,3,3,7,0,1,1,0,3,6,3,7,1,1]

theorem envBound30747 : H12AffineFastState.Bounded env30747 := by
  intro p hp
  have h : env30747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30746_30747 : H12AffineEnvironment.transform 3 7 env30746 = env30747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30746 == env30747) = true)

theorem identity30747 : scanCanonicalize (H12AffineFastState.compose env30747 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30748 : List Nat := [2,0,0,3,2,3,0,2,0,1,1,1,3,0,1,1,1,0,0,0,0,3,2,3,3,3,0,1,1,0,3,2,3,3,1,1]

theorem envBound30748 : H12AffineFastState.Bounded env30748 := by
  intro p hp
  have h : env30748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30747_30748 : H12AffineEnvironment.transform 1 0 env30747 = env30748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30747 == env30748) = true)

def env30749 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,310,8264,439,4416,12557,4097,477,8201,4390,12504,12296,4414,8216,0,14701,8204,8201,257,8201,80,4689]

theorem envBound30749 : H12AffineFastState.Bounded env30749 := by
  intro p hp
  have h : env30749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30736_30749 : H12AffineEnvironment.transform 9 273 env30736 = env30749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30736 == env30749) = true)

theorem identity30749 : scanCanonicalize (H12AffineFastState.compose env30749 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound30749 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30750 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,1,4421,310,1,439,4416,4420,4097,477,64,4390,4241,4161,4414,81,0,6436,69,64,257,64,80,4689]

theorem envBound30750 : H12AffineFastState.Bounded env30750 := by
  intro p hp
  have h : env30750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30749_30750 : H12AffineEnvironment.transform 12 73 env30749 = env30750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env30749 == env30750) = true)

theorem identity30750 : scanCanonicalize (H12AffineFastState.compose env30750 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound30750 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30751 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,277,73,1,80,310,1,439,85,81,276,477,64,51,388,340,43,81,0,2097,69,64,257,64,80,836]

theorem envBound30751 : H12AffineFastState.Bounded env30751 := by
  intro p hp
  have h : env30751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30750_30751 : H12AffineEnvironment.transform 11 277 env30750 = env30751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env30750 == env30751) = true)

theorem identity30751 : scanCanonicalize (H12AffineFastState.compose env30751 (packedSelected [0,1,7,8,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound30751 : packedSelected [0,1,7,8,15,18,19] rootPS < 2^1333 := by decide +kernel

def env30752 : List Nat := [2,4,8,16,32,64,128,256,512,273,412,277,73,1,80,310,1,439,85,81,276,477,64,51,388,340,43,81,0,429,69,64,257,64,80,836]

theorem envBound30752 : H12AffineFastState.Bounded env30752 := by
  intro p hp
  have h : env30752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30751_30752 : H12AffineEnvironment.transform 10 412 env30751 = env30752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env30751 == env30752) = true)

theorem identity30752 : scanCanonicalize (H12AffineFastState.compose env30752 (packedSelected [0,1,2,7,8,10,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound30752 : packedSelected [0,1,2,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env30753 : List Nat := [2,4,8,16,32,64,128,256,461,273,412,277,73,1,80,310,1,439,85,81,276,477,64,51,388,340,43,81,0,429,69,64,257,64,80,137]

theorem envBound30753 : H12AffineFastState.Bounded env30753 := by
  intro p hp
  have h : env30753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30752_30753 : H12AffineEnvironment.transform 8 461 env30752 = env30753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env30752 == env30753) = true)

theorem identity30753 : scanCanonicalize (H12AffineFastState.compose env30753 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound30753 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env30754 : List Nat := [2,4,8,16,32,58,128,256,439,273,412,277,51,1,42,310,1,439,47,43,276,423,58,51,388,302,43,43,0,429,63,58,257,58,42,137]

theorem envBound30754 : H12AffineFastState.Bounded env30754 := by
  intro p hp
  have h : env30754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30753_30754 : H12AffineEnvironment.transform 5 58 env30753 = env30754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env30753 == env30754) = true)

theorem identity30754 : scanCanonicalize (H12AffineFastState.compose env30754 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound30754 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30755 : List Nat := [2,4,8,16,32,58,128,182,1,167,42,163,51,1,42,128,1,1,47,43,162,17,58,51,50,152,43,43,0,27,63,58,183,58,42,137]

theorem envBound30755 : H12AffineFastState.Bounded env30755 := by
  intro p hp
  have h : env30755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30754_30755 : H12AffineEnvironment.transform 7 182 env30754 = env30755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env30754 == env30755) = true)

theorem identity30755 : scanCanonicalize (H12AffineFastState.compose env30755 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound30755 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30756 : List Nat := [2,4,8,16,32,58,37,19,1,2,42,6,51,1,42,37,1,1,47,43,7,17,58,51,50,61,43,43,0,27,63,58,18,58,42,44]

theorem envBound30756 : H12AffineFastState.Bounded env30756 := by
  intro p hp
  have h : env30756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30755_30756 : H12AffineEnvironment.transform 6 37 env30755 = env30756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env30755 == env30756) = true)

theorem identity30756 : scanCanonicalize (H12AffineFastState.compose env30756 (packedSelected [2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30756 : packedSelected [2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30757 : List Nat := [2,4,8,16,12,22,9,19,1,2,6,6,31,1,6,9,1,1,3,7,7,17,22,31,30,17,7,7,0,27,19,22,18,22,6,0]

theorem envBound30757 : H12AffineFastState.Bounded env30757 := by
  intro p hp
  have h : env30757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30756_30757 : H12AffineEnvironment.transform 4 12 env30756 = env30757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30756 == env30757) = true)

theorem identity30757 : scanCanonicalize (H12AffineFastState.compose env30757 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound30757 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30758 : List Nat := [2,4,7,16,3,22,6,19,1,2,6,6,16,1,6,6,1,1,3,7,7,17,22,16,17,17,7,7,0,20,19,22,18,22,6,0]

theorem envBound30758 : H12AffineFastState.Bounded env30758 := by
  intro p hp
  have h : env30758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30757_30758 : H12AffineEnvironment.transform 2 7 env30757 = env30758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env30757 == env30758) = true)

theorem identity30758 : scanCanonicalize (H12AffineFastState.compose env30758 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30758 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30759 : List Nat := [2,4,7,7,3,1,6,4,1,2,6,6,7,1,6,6,1,1,3,7,7,6,1,7,6,6,7,7,0,3,4,1,5,1,6,0]

theorem envBound30759 : H12AffineFastState.Bounded env30759 := by
  intro p hp
  have h : env30759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30758_30759 : H12AffineEnvironment.transform 3 7 env30758 = env30759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30758 == env30759) = true)

theorem identity30759 : scanCanonicalize (H12AffineFastState.compose env30759 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30759 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30760 : List Nat := [0,4,5,5,1,1,4,4,1,0,4,4,5,1,4,4,1,1,1,5,5,4,1,5,4,4,5,5,0,1,4,1,5,1,4,0]

theorem envBound30760 : H12AffineFastState.Bounded env30760 := by
  intro p hp
  have h : env30760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30759_30760 : H12AffineEnvironment.transform 0 0 env30759 = env30760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30759 == env30760) = true)

theorem identity30760 : scanCanonicalize (H12AffineFastState.compose env30760 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30760 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env30761 : List Nat := [0,1,0,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0,0,1,1,0,1,1,0,0,0,1,1,1,0,1,1,0]

theorem envBound30761 : H12AffineFastState.Bounded env30761 := by
  intro p hp
  have h : env30761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30760_30761 : H12AffineEnvironment.transform 1 1 env30760 = env30761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30760 == env30761) = true)

def env30762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4097,476,74046,69649,13768,78895,332222,74814,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound30762 : H12AffineFastState.Bounded env30762 := by
  intro p hp
  have h : env30762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30709_30762 : H12AffineEnvironment.transform 13 1297 env30709 = env30762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env30709 == env30762) = true)

def env30763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4097,476,74046,69649,13768,78895,4414,74814,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound30763 : H12AffineFastState.Bounded env30763 := by
  intro p hp
  have h : env30763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30762_30763 : H12AffineEnvironment.transform 17 65664 env30762 = env30763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30762 == env30763) = true)

theorem identity30763 : scanCanonicalize (H12AffineFastState.compose env30763 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound30763 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9278,81,9406,4417,13340,4097,476,1280,13359,13768,4113,4414,0,1297,6517,8205,8200,257,16,1345,5953]

theorem envBound30764 : H12AffineFastState.Bounded env30764 := by
  intro p hp
  have h : env30764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30763_30764 : H12AffineEnvironment.transform 15 9278 env30763 = env30764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env30763 == env30764) = true)

def env30765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5125,1062,81,1190,4417,5124,4097,476,1280,5175,5584,4113,4414,0,1297,6517,21,16,257,16,1345,5953]

theorem envBound30765 : H12AffineFastState.Bounded env30765 := by
  intro p hp
  have h : env30765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30764_30765 : H12AffineEnvironment.transform 12 24 env30764 = env30765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30764 == env30765) = true)

theorem identity30765 : scanCanonicalize (H12AffineFastState.compose env30765 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound30765 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1297,1029,1062,81,1190,321,1028,1,476,1280,1079,1488,17,318,0,1297,2421,21,16,257,16,1345,1857]

theorem envBound30766 : H12AffineFastState.Bounded env30766 := by
  intro p hp
  have h : env30766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30765_30766 : H12AffineEnvironment.transform 11 0 env30765 = env30766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env30765 == env30766) = true)

theorem identity30766 : scanCanonicalize (H12AffineFastState.compose env30766 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30766 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30767 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,0,24,1029,1029,1062,81,1190,85,1028,1,200,1044,1079,1220,17,42,0,1029,2145,21,16,21,16,1109,1621]

theorem envBound30767 : H12AffineFastState.Bounded env30767 := by
  intro p hp
  have h : env30767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30766_30767 : H12AffineEnvironment.transform 7 20 env30766 = env30767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30766 == env30767) = true)

theorem identity30767 : scanCanonicalize (H12AffineFastState.compose env30767 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30767 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env30768 : List Nat := [2,4,8,16,32,64,15,20,512,1024,2048,0,24,1029,1029,1062,81,1065,85,1028,1,71,1044,1079,1099,17,42,0,1029,2145,21,16,21,16,1109,1621]

theorem envBound30768 : H12AffineFastState.Bounded env30768 := by
  intro p hp
  have h : env30768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30767_30768 : H12AffineEnvironment.transform 6 15 env30767 = env30768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30767 == env30768) = true)

theorem identity30768 : scanCanonicalize (H12AffineFastState.compose env30768 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound30768 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30769 : List Nat := [2,4,8,16,32,64,15,20,512,85,2048,0,24,80,80,115,81,124,85,81,1,71,65,98,30,17,42,0,80,2145,21,16,21,16,0,512]

theorem envBound30769 : H12AffineFastState.Bounded env30769 := by
  intro p hp
  have h : env30769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30768_30769 : H12AffineEnvironment.transform 9 85 env30768 = env30769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env30768 == env30769) = true)

theorem identity30769 : scanCanonicalize (H12AffineFastState.compose env30769 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound30769 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30770 : List Nat := [2,4,8,16,32,64,15,20,77,85,2048,0,24,80,80,115,81,124,85,81,1,71,65,98,30,17,42,0,80,2145,21,16,21,16,0,77]

theorem envBound30770 : H12AffineFastState.Bounded env30770 := by
  intro p hp
  have h : env30770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30769_30770 : H12AffineEnvironment.transform 8 77 env30769 = env30770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env30769 == env30770) = true)

theorem identity30770 : scanCanonicalize (H12AffineFastState.compose env30770 (packedSelected [5,10] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound30770 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env30771 : List Nat := [2,4,8,16,32,10,15,20,7,31,2048,0,24,26,26,57,27,54,31,27,1,13,11,40,30,17,42,0,26,2091,21,16,21,16,0,7]

theorem envBound30771 : H12AffineFastState.Bounded env30771 := by
  intro p hp
  have h : env30771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30770_30771 : H12AffineEnvironment.transform 5 10 env30770 = env30771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env30770 == env30771) = true)

theorem identity30771 : scanCanonicalize (H12AffineFastState.compose env30771 (packedSelected [1,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 55) := by decide +kernel

theorem selectedBound30771 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env30772 : List Nat := [2,4,8,16,32,10,15,20,7,31,55,0,24,26,26,57,27,54,31,27,1,13,11,40,30,17,42,0,26,28,21,16,21,16,0,7]

theorem envBound30772 : H12AffineFastState.Bounded env30772 := by
  intro p hp
  have h : env30772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30771_30772 : H12AffineEnvironment.transform 10 55 env30771 = env30772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 55 env30771 == env30772) = true)

theorem identity30772 : scanCanonicalize (H12AffineFastState.compose env30772 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound30772 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30773 : List Nat := [2,4,8,13,32,10,15,9,7,2,42,0,5,7,7,36,6,43,2,6,1,13,11,40,3,12,42,0,7,1,8,13,8,13,0,7]

theorem envBound30773 : H12AffineFastState.Bounded env30773 := by
  intro p hp
  have h : env30773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30772_30773 : H12AffineEnvironment.transform 3 13 env30772 = env30773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env30772 == env30773) = true)

theorem identity30773 : scanCanonicalize (H12AffineFastState.compose env30773 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30774 : List Nat := [2,4,8,13,11,10,15,9,7,2,1,0,5,7,7,15,6,0,2,6,1,13,11,3,3,12,1,0,7,1,8,13,8,13,0,7]

theorem envBound30774 : H12AffineFastState.Bounded env30774 := by
  intro p hp
  have h : env30774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30773_30774 : H12AffineEnvironment.transform 4 11 env30773 = env30774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30773 == env30774) = true)

def env30775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1063,81,1191,4417,5125,4097,476,1280,5174,5585,4113,4414,0,1297,6517,20,17,257,16,1345,5953]

theorem envBound30775 : H12AffineFastState.Bounded env30775 := by
  intro p hp
  have h : env30775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30764_30775 : H12AffineEnvironment.transform 12 25 env30764 = env30775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30764 == env30775) = true)

theorem identity30775 : scanCanonicalize (H12AffineFastState.compose env30775 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30775 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30776 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,25,1029,5124,1063,81,1191,4181,5125,4097,200,1044,5174,5317,4113,4138,0,1029,6241,20,17,21,16,1109,5717]

theorem envBound30776 : H12AffineFastState.Bounded env30776 := by
  intro p hp
  have h : env30776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30775_30776 : H12AffineEnvironment.transform 7 20 env30775 = env30776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30775 == env30776) = true)

theorem identity30776 : scanCanonicalize (H12AffineFastState.compose env30776 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound30776 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env30777 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,184,25,1029,1212,1063,81,1191,237,1213,185,200,1044,1166,1149,169,146,0,1029,2265,20,17,21,16,1109,1773]

theorem envBound30777 : H12AffineFastState.Bounded env30777 := by
  intro p hp
  have h : env30777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30776_30777 : H12AffineEnvironment.transform 11 184 env30776 = env30777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env30776 == env30777) = true)

theorem identity30777 : scanCanonicalize (H12AffineFastState.compose env30777 (packedSelected [0,2,3,5,7,10,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound30777 : packedSelected [0,2,3,5,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env30778 : List Nat := [2,4,8,16,32,64,128,20,185,1024,2048,184,25,1029,1212,1063,81,1191,237,1213,185,200,1044,1166,1149,169,146,0,1029,2265,20,17,21,16,1109,1108]

theorem envBound30778 : H12AffineFastState.Bounded env30778 := by
  intro p hp
  have h : env30778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30777_30778 : H12AffineEnvironment.transform 8 185 env30777 = env30778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env30777 == env30778) = true)

theorem identity30778 : scanCanonicalize (H12AffineFastState.compose env30778 (packedSelected [4,5,8,9,10,12,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30778 : packedSelected [4,5,8,9,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env30779 : List Nat := [2,4,8,16,32,64,128,20,185,5,2048,184,25,0,185,34,81,162,237,184,185,200,17,139,120,169,146,0,0,2265,20,17,21,16,80,81]

theorem envBound30779 : H12AffineFastState.Bounded env30779 := by
  intro p hp
  have h : env30779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30778_30779 : H12AffineEnvironment.transform 9 5 env30778 = env30779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30778 == env30779) = true)

theorem identity30779 : scanCanonicalize (H12AffineFastState.compose env30779 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound30779 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30780 : List Nat := [2,4,8,16,32,64,56,20,1,5,2048,0,25,0,1,34,81,26,85,0,1,112,17,51,120,17,42,0,0,2145,20,17,21,16,80,81]

theorem envBound30780 : H12AffineFastState.Bounded env30780 := by
  intro p hp
  have h : env30780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30779_30780 : H12AffineEnvironment.transform 6 56 env30779 = env30780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env30779 == env30780) = true)

theorem identity30780 : scanCanonicalize (H12AffineFastState.compose env30780 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30780 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30781 : List Nat := [2,4,8,10,32,64,34,14,1,5,2048,0,3,0,1,34,75,0,79,0,1,106,11,41,98,11,42,0,0,2145,14,11,15,10,74,75]

theorem envBound30781 : H12AffineFastState.Bounded env30781 := by
  intro p hp
  have h : env30781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30780_30781 : H12AffineEnvironment.transform 3 10 env30780 = env30781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30780 == env30781) = true)

theorem identity30781 : scanCanonicalize (H12AffineFastState.compose env30781 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound30781 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30782 : List Nat := [2,4,8,10,32,6,34,14,1,5,2048,0,3,0,1,34,13,0,9,0,1,44,11,41,36,11,42,0,0,2087,14,11,15,10,12,13]

theorem envBound30782 : H12AffineFastState.Bounded env30782 := by
  intro p hp
  have h : env30782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30781_30782 : H12AffineEnvironment.transform 5 6 env30781 = env30782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env30781 == env30782) = true)

theorem identity30782 : scanCanonicalize (H12AffineFastState.compose env30782 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound30782 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env30783 : List Nat := [2,4,8,10,32,6,34,14,1,5,38,0,3,0,1,34,13,0,9,0,1,44,11,41,36,11,42,0,0,1,14,11,15,10,12,13]

theorem envBound30783 : H12AffineFastState.Bounded env30783 := by
  intro p hp
  have h : env30783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30782_30783 : H12AffineEnvironment.transform 10 38 env30782 = env30783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env30782 == env30783) = true)

theorem identity30783 : scanCanonicalize (H12AffineFastState.compose env30783 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30783 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30784 : List Nat := [2,4,5,7,32,6,34,3,1,5,38,0,3,0,1,34,0,0,4,0,1,33,6,36,36,6,39,0,0,1,3,6,2,7,1,0]

theorem envBound30784 : H12AffineFastState.Bounded env30784 := by
  intro p hp
  have h : env30784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30783_30784 : H12AffineEnvironment.transform 2 5 env30783 = env30784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30783 == env30784) = true)

theorem identity30784 : scanCanonicalize (H12AffineFastState.compose env30784 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound30784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30785 : List Nat := [2,4,5,7,3,6,1,3,1,5,5,0,3,0,1,1,0,0,4,0,1,2,6,7,7,6,4,0,0,1,3,6,2,7,1,0]

theorem envBound30785 : H12AffineFastState.Bounded env30785 := by
  intro p hp
  have h : env30785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30784_30785 : H12AffineEnvironment.transform 4 3 env30784 = env30785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env30784 == env30785) = true)

theorem identity30785 : scanCanonicalize (H12AffineFastState.compose env30785 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30785 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30786 : List Nat := [2,0,1,3,3,2,1,3,1,1,1,0,3,0,1,1,0,0,0,0,1,2,2,3,3,2,0,0,0,1,3,2,2,3,1,0]

theorem envBound30786 : H12AffineFastState.Bounded env30786 := by
  intro p hp
  have h : env30786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30785_30786 : H12AffineEnvironment.transform 1 0 env30785 = env30786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30785 == env30786) = true)

theorem identity30786 : scanCanonicalize (H12AffineFastState.compose env30786 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30786 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30787 : List Nat := [1,0,1,0,0,1,1,0,1,1,1,0,0,0,1,1,0,0,0,0,1,1,1,0,0,1,0,0,0,1,0,1,1,0,1,0]

theorem envBound30787 : H12AffineFastState.Bounded env30787 := by
  intro p hp
  have h : env30787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30786_30787 : H12AffineEnvironment.transform 0 1 env30786 = env30787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30786 == env30787) = true)

def env30788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4097,476,74046,69649,13768,78895,4415,74814,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound30788 : H12AffineFastState.Bounded env30788 := by
  intro p hp
  have h : env30788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30762_30788 : H12AffineEnvironment.transform 17 65665 env30762 = env30788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30762 == env30788) = true)

theorem identity30788 : scanCanonicalize (H12AffineFastState.compose env30788 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound30788 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12670,5393,12799,4417,13340,4097,476,4160,8559,13768,1361,4415,5440,1297,3125,8205,8200,257,5456,1345,5953]

theorem envBound30789 : H12AffineFastState.Bounded env30789 := by
  intro p hp
  have h : env30789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30788_30789 : H12AffineEnvironment.transform 15 12670 env30788 = env30789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env30788 == env30789) = true)

def env30790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,8494,1345,8623,273,9292,81,476,16,8559,9624,1361,367,1296,1297,3125,8205,8200,257,1280,1345,1809]

theorem envBound30790 : H12AffineFastState.Bounded env30790 := by
  intro p hp
  have h : env30790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30789_30790 : H12AffineEnvironment.transform 11 80 env30789 = env30790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env30789 == env30790) = true)

theorem identity30790 : scanCanonicalize (H12AffineFastState.compose env30790 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound30790 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1297,276,1143,1345,1270,273,277,81,476,16,1078,193,1361,367,1296,1297,3125,1364,1361,257,1280,1345,1809]

theorem envBound30791 : H12AffineFastState.Bounded env30791 := by
  intro p hp
  have h : env30791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30790_30791 : H12AffineEnvironment.transform 12 1369 env30790 = env30791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env30790 == env30791) = true)

theorem identity30791 : scanCanonicalize (H12AffineFastState.compose env30791 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound30791 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30792 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,485,429,276,203,509,74,273,277,81,476,16,138,193,493,367,428,429,2185,488,493,257,444,509,941]

theorem envBound30792 : H12AffineFastState.Bounded env30792 := by
  intro p hp
  have h : env30792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30791_30792 : H12AffineEnvironment.transform 9 188 env30791 = env30792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env30791 == env30792) = true)

theorem identity30792 : scanCanonicalize (H12AffineFastState.compose env30792 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound30792 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env30793 : List Nat := [2,4,8,16,32,64,128,256,372,188,2048,80,485,429,276,203,509,74,273,277,81,476,16,138,193,493,367,428,429,2185,488,493,257,444,509,217]

theorem envBound30793 : H12AffineFastState.Bounded env30793 := by
  intro p hp
  have h : env30793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30792_30793 : H12AffineEnvironment.transform 8 372 env30792 = env30793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env30792 == env30793) = true)

theorem identity30793 : scanCanonicalize (H12AffineFastState.compose env30793 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound30793 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env30794 : List Nat := [2,4,8,16,32,64,18,256,372,46,2048,80,375,319,276,89,367,74,273,277,81,334,16,24,83,383,367,318,319,2075,378,383,257,302,367,75]

theorem envBound30794 : H12AffineFastState.Bounded env30794 := by
  intro p hp
  have h : env30794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30793_30794 : H12AffineEnvironment.transform 6 18 env30793 = env30794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env30793 == env30794) = true)

theorem identity30794 : scanCanonicalize (H12AffineFastState.compose env30794 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound30794 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env30795 : List Nat := [2,4,8,16,32,32,18,256,276,46,2048,48,279,319,276,57,271,42,273,277,49,302,16,24,51,287,271,318,319,2075,282,287,257,302,271,43]

theorem envBound30795 : H12AffineFastState.Bounded env30795 := by
  intro p hp
  have h : env30795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30794_30795 : H12AffineEnvironment.transform 5 32 env30794 = env30795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env30794 == env30795) = true)

theorem identity30795 : scanCanonicalize (H12AffineFastState.compose env30795 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30795 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30796 : List Nat := [2,4,8,16,32,32,18,37,49,46,2048,48,50,26,49,57,42,42,52,48,49,11,16,24,51,58,42,27,26,2075,63,58,36,11,42,43]

theorem envBound30796 : H12AffineFastState.Bounded env30796 := by
  intro p hp
  have h : env30796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30795_30796 : H12AffineEnvironment.transform 7 37 env30795 = env30796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30795 == env30796) = true)

theorem identity30796 : scanCanonicalize (H12AffineFastState.compose env30796 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound30796 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30797 : List Nat := [2,4,8,16,32,32,18,37,49,46,49,48,50,26,49,57,42,42,52,48,49,11,16,24,51,58,42,27,26,42,63,58,36,11,42,43]

theorem envBound30797 : H12AffineFastState.Bounded env30797 := by
  intro p hp
  have h : env30797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30796_30797 : H12AffineEnvironment.transform 10 49 env30796 = env30797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env30796 == env30797) = true)

theorem identity30797 : scanCanonicalize (H12AffineFastState.compose env30797 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30798 : List Nat := [2,4,8,11,32,32,9,37,42,46,42,43,41,1,42,34,42,42,47,43,42,11,11,3,40,33,42,0,1,42,36,33,36,11,42,43]

theorem envBound30798 : H12AffineFastState.Bounded env30798 := by
  intro p hp
  have h : env30798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30797_30798 : H12AffineEnvironment.transform 3 11 env30797 = env30798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30797 == env30798) = true)

theorem identity30798 : scanCanonicalize (H12AffineFastState.compose env30798 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound30798 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30799 : List Nat := [2,4,0,3,32,32,1,37,34,38,34,35,33,1,34,34,34,34,39,35,34,3,3,3,32,33,34,0,1,34,36,33,36,3,34,35]

theorem envBound30799 : H12AffineFastState.Bounded env30799 := by
  intro p hp
  have h : env30799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30798_30799 : H12AffineEnvironment.transform 2 0 env30798 = env30799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env30798 == env30799) = true)

theorem identity30799 : scanCanonicalize (H12AffineFastState.compose env30799 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound30799 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30800 : List Nat := [2,4,0,3,3,3,1,6,1,5,1,0,2,1,1,1,1,1,4,0,1,3,3,3,3,2,1,0,1,1,7,2,7,3,1,0]

theorem envBound30800 : H12AffineFastState.Bounded env30800 := by
  intro p hp
  have h : env30800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30799_30800 : H12AffineEnvironment.transform 4 3 env30799 = env30800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env30799 == env30800) = true)

theorem identity30800 : scanCanonicalize (H12AffineFastState.compose env30800 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30801 : List Nat := [2,0,0,3,3,3,1,2,1,1,1,0,2,1,1,1,1,1,0,0,1,3,3,3,3,2,1,0,1,1,3,2,3,3,1,0]

theorem envBound30801 : H12AffineFastState.Bounded env30801 := by
  intro p hp
  have h : env30801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30800_30801 : H12AffineEnvironment.transform 1 0 env30800 = env30801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30800 == env30801) = true)

theorem identity30801 : scanCanonicalize (H12AffineFastState.compose env30801 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30801 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30802 : List Nat := [0,0,0,1,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,0,1,1,1,1,1,0,1,0,1,1,1,0,1,1,1,0]

theorem envBound30802 : H12AffineFastState.Bounded env30802 := by
  intro p hp
  have h : env30802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30801_30802 : H12AffineEnvironment.transform 0 0 env30801 = env30802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30801 == env30802) = true)

def env30803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,8495,1344,8622,272,9293,80,476,17,8559,9625,1361,366,1297,1297,3125,8205,8200,257,1281,1345,1808]

theorem envBound30803 : H12AffineFastState.Bounded env30803 := by
  intro p hp
  have h : env30803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30789_30803 : H12AffineEnvironment.transform 11 81 env30789 = env30803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env30789 == env30803) = true)

theorem identity30803 : scanCanonicalize (H12AffineFastState.compose env30803 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30803 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30804 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,8192,1028,9292,8250,1109,8379,5,9293,80,201,17,8314,9356,1092,123,1028,1028,3125,8205,8200,20,1044,1108,1541]

theorem envBound30804 : H12AffineFastState.Bounded env30804 := by
  intro p hp
  have h : env30804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30803_30804 : H12AffineEnvironment.transform 7 21 env30803 = env30804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30803 == env30804) = true)

theorem identity30804 : scanCanonicalize (H12AffineFastState.compose env30804 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30804 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30805 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,81,8192,1,8265,8250,80,8379,5,8264,80,201,17,8314,8329,65,123,1,1,2096,8205,8200,20,17,81,512]

theorem envBound30805 : H12AffineFastState.Bounded env30805 := by
  intro p hp
  have h : env30805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30804_30805 : H12AffineEnvironment.transform 9 5 env30804 = env30805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30804 == env30805) = true)

theorem identity30805 : scanCanonicalize (H12AffineFastState.compose env30805 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30805 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30806 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,8192,1,8217,8250,0,8379,5,8216,0,153,17,8234,8329,17,43,1,1,2096,8205,8200,20,17,1,512]

theorem envBound30806 : H12AffineFastState.Bounded env30806 := by
  intro p hp
  have h : env30806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30805_30806 : H12AffineEnvironment.transform 5 16 env30805 = env30806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30805 == env30806) = true)

theorem identity30806 : scanCanonicalize (H12AffineFastState.compose env30806 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound30806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30807 : List Nat := [2,4,8,16,32,16,128,21,512,5,560,1,8192,1,8217,8250,0,8379,5,8216,0,153,17,8234,8329,17,43,1,1,512,8205,8200,20,17,1,512]

theorem envBound30807 : H12AffineFastState.Bounded env30807 := by
  intro p hp
  have h : env30807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30806_30807 : H12AffineEnvironment.transform 10 560 env30806 = env30807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env30806 == env30807) = true)

theorem identity30807 : scanCanonicalize (H12AffineFastState.compose env30807 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30807 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30808 : List Nat := [2,4,8,16,32,16,9,21,512,5,560,1,8192,1,8217,8250,0,8242,5,8216,0,16,17,8234,8192,17,43,1,1,512,8205,8200,20,17,1,512]

theorem envBound30808 : H12AffineFastState.Bounded env30808 := by
  intro p hp
  have h : env30808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30807_30808 : H12AffineEnvironment.transform 6 9 env30807 = env30808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30807 == env30808) = true)

theorem identity30808 : scanCanonicalize (H12AffineFastState.compose env30808 (packedSelected [10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30808 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env30809 : List Nat := [2,4,8,16,32,16,9,21,0,5,48,1,8192,1,8217,8250,0,8242,5,8216,0,16,17,8234,8192,17,43,1,1,0,8205,8200,20,17,1,0]

theorem envBound30809 : H12AffineFastState.Bounded env30809 := by
  intro p hp
  have h : env30809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30808_30809 : H12AffineEnvironment.transform 8 0 env30808 = env30809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30808 == env30809) = true)

theorem identity30809 : scanCanonicalize (H12AffineFastState.compose env30809 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30809 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30810 : List Nat := [2,4,8,11,32,11,9,14,0,5,43,1,8192,1,8194,8225,0,8233,5,8195,0,11,10,8234,8192,10,43,1,1,0,8205,8200,15,10,1,0]

theorem envBound30810 : H12AffineFastState.Bounded env30810 := by
  intro p hp
  have h : env30810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30809_30810 : H12AffineEnvironment.transform 3 11 env30809 = env30810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30809 == env30810) = true)

theorem identity30810 : scanCanonicalize (H12AffineFastState.compose env30810 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30810 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30811 : List Nat := [2,4,8,11,32,11,9,14,0,5,43,1,40,1,42,9,0,1,5,43,0,11,10,2,40,10,43,1,1,0,37,32,15,10,1,0]

theorem envBound30811 : H12AffineFastState.Bounded env30811 := by
  intro p hp
  have h : env30811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30810_30811 : H12AffineEnvironment.transform 12 40 env30810 = env30811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30810 == env30811) = true)

theorem identity30811 : scanCanonicalize (H12AffineFastState.compose env30811 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30811 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30812 : List Nat := [2,4,8,11,10,11,9,14,0,5,1,1,2,1,0,9,0,1,5,1,0,11,10,2,2,10,1,1,1,0,15,10,15,10,1,0]

theorem envBound30812 : H12AffineFastState.Bounded env30812 := by
  intro p hp
  have h : env30812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30811_30812 : H12AffineEnvironment.transform 4 10 env30811 = env30812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30811 == env30812) = true)

theorem identity30812 : scanCanonicalize (H12AffineFastState.compose env30812 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30813 : List Nat := [2,2,8,11,10,11,9,8,0,3,1,1,2,1,0,9,0,1,3,1,0,11,10,2,2,10,1,1,1,0,9,10,9,10,1,0]

theorem envBound30813 : H12AffineFastState.Bounded env30813 := by
  intro p hp
  have h : env30813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30812_30813 : H12AffineEnvironment.transform 1 2 env30812 = env30813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30812 == env30813) = true)

def env30814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123165,28888,78894,385202,90415,1296,96346,25884,25880,257,74798,1345,21073]

theorem envBound30814 : H12AffineFastState.Bounded env30814 := by
  intro p hp
  have h : env30814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30707_30814 : H12AffineEnvironment.transform 18 21585 env30707 = env30814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env30707 == env30814) = true)

theorem identity30814 : scanCanonicalize (H12AffineFastState.compose env30814 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound30814 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4097,5277,91183,66896,28888,78894,328959,90415,1296,96346,25884,25880,257,74798,1345,21073]

theorem envBound30815 : H12AffineFastState.Bounded env30815 := by
  intro p hp
  have h : env30815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30814_30815 : H12AffineEnvironment.transform 14 25677 env30814 = env30815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env30814 == env30815) = true)

def env30816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4097,5277,74047,66896,13768,78894,328959,74815,1296,81226,8204,8200,257,74798,1345,5953]

theorem envBound30816 : H12AffineFastState.Bounded env30816 := by
  intro p hp
  have h : env30816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30815_30816 : H12AffineEnvironment.transform 13 1296 env30815 = env30816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env30815 == env30816) = true)

def env30817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4097,5277,74047,66896,13768,78894,1151,74815,1296,81226,8204,8200,257,74798,1345,5953]

theorem envBound30817 : H12AffineFastState.Bounded env30817 := by
  intro p hp
  have h : env30817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30816_30817 : H12AffineEnvironment.transform 17 65664 env30816 = env30817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30816 == env30817) = true)

theorem identity30817 : scanCanonicalize (H12AffineFastState.compose env30817 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound30817 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,310,9561,438,4417,8540,4097,5277,8201,1126,13768,13592,1151,9481,1296,15484,8204,8200,257,9496,1345,5953]

theorem envBound30818 : H12AffineFastState.Bounded env30818 := by
  intro p hp
  have h : env30818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30817_30818 : H12AffineEnvironment.transform 15 310 env30817 = env30818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env30817 == env30818) = true)

def env30819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,310,1345,438,4417,324,4097,5277,17,1126,5584,5376,1151,1297,1296,7268,20,16,257,1280,1345,5953]

theorem envBound30819 : H12AffineFastState.Bounded env30819 := by
  intro p hp
  have h : env30819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30818_30819 : H12AffineEnvironment.transform 12 24 env30818 = env30819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30818 == env30819) = true)

theorem identity30819 : scanCanonicalize (H12AffineFastState.compose env30819 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30819 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30820 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,24,277,325,310,324,438,4417,324,4097,4248,17,99,4565,4357,122,276,277,6241,20,16,257,261,324,4932]

theorem envBound30820 : H12AffineFastState.Bounded env30820 := by
  intro p hp
  have h : env30820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30819_30820 : H12AffineEnvironment.transform 9 5 env30819 = env30820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30819 == env30820) = true)

theorem identity30820 : scanCanonicalize (H12AffineFastState.compose env30820 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound30820 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30821 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,24,277,325,310,324,438,5,324,325,476,17,99,145,65,122,276,277,2341,20,16,257,261,324,512]

theorem envBound30821 : H12AffineFastState.Bounded env30821 := by
  intro p hp
  have h : env30821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30820_30821 : H12AffineEnvironment.transform 11 324 env30820 = env30821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env30820 == env30821) = true)

theorem identity30821 : scanCanonicalize (H12AffineFastState.compose env30821 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound30821 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env30822 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,1,24,80,0,115,1,243,5,1,0,153,17,99,145,65,122,81,80,2144,20,16,68,64,1,512]

theorem envBound30822 : H12AffineFastState.Bounded env30822 := by
  intro p hp
  have h : env30822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30821_30822 : H12AffineEnvironment.transform 7 69 env30821 = env30822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env30821 == env30822) = true)

theorem identity30822 : scanCanonicalize (H12AffineFastState.compose env30822 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30822 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30823 : List Nat := [2,4,8,16,32,64,128,69,136,5,2048,1,24,80,0,115,1,243,5,1,0,153,17,99,145,65,122,81,80,2144,20,16,68,64,1,136]

theorem envBound30823 : H12AffineFastState.Bounded env30823 := by
  intro p hp
  have h : env30823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30822_30823 : H12AffineEnvironment.transform 8 136 env30822 = env30823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30822 == env30823) = true)

theorem identity30823 : scanCanonicalize (H12AffineFastState.compose env30823 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound30823 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env30824 : List Nat := [2,4,8,16,32,64,128,69,136,5,194,1,24,80,0,115,1,243,5,1,0,153,17,99,145,65,122,81,80,162,20,16,68,64,1,136]

theorem envBound30824 : H12AffineFastState.Bounded env30824 := by
  intro p hp
  have h : env30824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30823_30824 : H12AffineEnvironment.transform 10 194 env30823 = env30824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env30823 == env30824) = true)

theorem identity30824 : scanCanonicalize (H12AffineFastState.compose env30824 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30824 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30825 : List Nat := [2,4,8,16,32,17,128,20,136,5,147,1,24,1,0,34,1,162,5,1,0,153,17,50,145,16,43,0,1,162,20,16,21,17,1,136]

theorem envBound30825 : H12AffineFastState.Bounded env30825 := by
  intro p hp
  have h : env30825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30824_30825 : H12AffineEnvironment.transform 5 17 env30824 = env30825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30824 == env30825) = true)

theorem identity30825 : scanCanonicalize (H12AffineFastState.compose env30825 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound30825 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30826 : List Nat := [2,4,8,16,32,17,20,20,28,5,7,1,24,1,0,34,1,54,5,1,0,13,17,50,5,16,43,0,1,54,20,16,21,17,1,28]

theorem envBound30826 : H12AffineFastState.Bounded env30826 := by
  intro p hp
  have h : env30826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30825_30826 : H12AffineEnvironment.transform 6 20 env30825 = env30826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env30825 == env30826) = true)

theorem identity30826 : scanCanonicalize (H12AffineFastState.compose env30826 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30826 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30827 : List Nat := [2,2,8,16,32,17,18,18,26,3,1,1,24,1,0,34,1,48,3,1,0,11,17,50,3,16,43,0,1,48,18,16,19,17,1,26]

theorem envBound30827 : H12AffineFastState.Bounded env30827 := by
  intro p hp
  have h : env30827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30826_30827 : H12AffineEnvironment.transform 1 2 env30826 = env30827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30826 == env30827) = true)

theorem identity30827 : scanCanonicalize (H12AffineFastState.compose env30827 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30827 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30828 : List Nat := [2,2,8,16,17,17,18,18,26,3,1,1,24,1,0,19,1,1,3,1,0,11,17,3,3,16,26,0,1,1,18,16,19,17,1,26]

theorem envBound30828 : H12AffineFastState.Bounded env30828 := by
  intro p hp
  have h : env30828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30827_30828 : H12AffineEnvironment.transform 4 17 env30827 = env30828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30827 == env30828) = true)

def env30829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,310,1344,438,4417,325,4097,5277,16,1126,5585,5377,1151,1296,1296,7269,21,17,257,1281,1345,5953]

theorem envBound30829 : H12AffineFastState.Bounded env30829 := by
  intro p hp
  have h : env30829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30818_30829 : H12AffineEnvironment.transform 12 25 env30818 = env30829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30818 == env30829) = true)

theorem identity30829 : scanCanonicalize (H12AffineFastState.compose env30829 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30829 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30830 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,324,310,0,438,4417,325,4097,4573,16,294,4241,4161,319,80,80,6437,21,17,257,65,1,4609]

theorem envBound30830 : H12AffineFastState.Bounded env30830 := by
  intro p hp
  have h : env30830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30829_30830 : H12AffineEnvironment.transform 9 320 env30829 = env30830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30829 == env30830) = true)

theorem identity30830 : scanCanonicalize (H12AffineFastState.compose env30830 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound30830 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env30831 : List Nat := [2,4,8,16,32,64,128,256,512,320,951,4096,25,80,324,310,0,438,4417,325,4097,4573,16,294,4241,4161,319,80,80,4754,21,17,257,65,1,4609]

theorem envBound30831 : H12AffineFastState.Bounded env30831 := by
  intro p hp
  have h : env30831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30830_30831 : H12AffineEnvironment.transform 10 951 env30830 = env30831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env30830 == env30831) = true)

def env30832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4097,5277,74047,66896,13768,78894,1150,74815,1296,81226,8204,8200,257,74798,1345,5953]

theorem envBound30832 : H12AffineFastState.Bounded env30832 := by
  intro p hp
  have h : env30832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30816_30832 : H12AffineEnvironment.transform 17 65665 env30816 = env30832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30816 == env30832) = true)

theorem identity30832 : scanCanonicalize (H12AffineFastState.compose env30832 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound30832 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5238,12313,5367,4417,8540,4097,5277,13641,4390,13768,8280,1150,12361,1296,10556,8204,8200,257,12376,1345,5953]

theorem envBound30833 : H12AffineFastState.Bounded env30833 := by
  intro p hp
  have h : env30833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30832_30833 : H12AffineEnvironment.transform 15 5238 env30832 = env30833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env30832 == env30833) = true)

def env30834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5238,1345,5367,4417,5124,4097,5277,17,4390,144,5376,1150,1297,1296,7268,5460,5456,257,1280,1345,5953]

theorem envBound30834 : H12AffineFastState.Bounded env30834 := by
  intro p hp
  have h : env30834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30833_30834 : H12AffineEnvironment.transform 12 5464 env30833 = env30834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env30833 == env30834) = true)

theorem identity30834 : scanCanonicalize (H12AffineFastState.compose env30834 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30834 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30835 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4445,277,4096,4211,324,4338,4417,4097,4097,4248,17,4390,144,4357,123,276,277,6241,4433,4437,257,261,324,4932]

theorem envBound30835 : H12AffineFastState.Bounded env30835 := by
  intro p hp
  have h : env30835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30834_30835 : H12AffineEnvironment.transform 9 5 env30834 = env30835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30834 == env30835) = true)

theorem identity30835 : scanCanonicalize (H12AffineFastState.compose env30835 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound30835 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30836 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,25,277,324,311,324,438,5,325,325,476,17,98,144,65,123,276,277,2341,21,17,257,261,324,512]

theorem envBound30836 : H12AffineFastState.Bounded env30836 := by
  intro p hp
  have h : env30836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30835_30836 : H12AffineEnvironment.transform 11 324 env30835 = env30836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env30835 == env30836) = true)

theorem identity30836 : scanCanonicalize (H12AffineFastState.compose env30836 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound30836 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env30837 : List Nat := [2,4,8,16,32,64,128,173,512,5,2048,233,25,184,233,154,233,27,5,232,232,113,17,98,144,65,123,185,184,2184,21,17,172,168,233,512]

theorem envBound30837 : H12AffineFastState.Bounded env30837 := by
  intro p hp
  have h : env30837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30836_30837 : H12AffineEnvironment.transform 7 173 env30836 = env30837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env30836 == env30837) = true)

theorem identity30837 : scanCanonicalize (H12AffineFastState.compose env30837 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30837 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30838 : List Nat := [2,4,8,16,32,64,128,173,136,5,2048,233,25,184,233,154,233,27,5,232,232,113,17,98,144,65,123,185,184,2184,21,17,172,168,233,136]

theorem envBound30838 : H12AffineFastState.Bounded env30838 := by
  intro p hp
  have h : env30838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30837_30838 : H12AffineEnvironment.transform 8 136 env30837 = env30838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30837 == env30838) = true)

theorem identity30838 : scanCanonicalize (H12AffineFastState.compose env30838 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound30838 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30839 : List Nat := [2,4,8,16,32,64,104,69,96,5,2048,1,25,80,1,114,1,27,5,0,0,113,17,98,120,65,123,81,80,2144,21,17,68,64,1,96]

theorem envBound30839 : H12AffineFastState.Bounded env30839 := by
  intro p hp
  have h : env30839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30838_30839 : H12AffineEnvironment.transform 6 104 env30838 = env30839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env30838 == env30839) = true)

theorem identity30839 : scanCanonicalize (H12AffineFastState.compose env30839 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30839 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env30840 : List Nat := [2,4,8,16,16,64,88,69,80,5,2048,1,25,80,1,66,1,27,5,0,0,65,17,82,72,65,75,81,80,2128,21,17,68,64,1,80]

theorem envBound30840 : H12AffineFastState.Bounded env30840 := by
  intro p hp
  have h : env30840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30839_30840 : H12AffineEnvironment.transform 4 16 env30839 = env30840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30839 == env30840) = true)

theorem identity30840 : scanCanonicalize (H12AffineFastState.compose env30840 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound30840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30841 : List Nat := [2,4,8,16,16,64,88,69,80,5,80,1,25,80,1,66,1,27,5,0,0,65,17,82,72,65,75,81,80,0,21,17,68,64,1,80]

theorem envBound30841 : H12AffineFastState.Bounded env30841 := by
  intro p hp
  have h : env30841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30840_30841 : H12AffineEnvironment.transform 10 80 env30840 = env30841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env30840 == env30841) = true)

theorem identity30841 : scanCanonicalize (H12AffineFastState.compose env30841 (packedSelected [0,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound30841 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env30842 : List Nat := [2,4,8,16,16,10,18,15,26,5,26,1,25,26,1,8,1,27,5,0,0,11,17,24,2,11,1,27,26,0,21,17,14,10,1,26]

theorem envBound30842 : H12AffineFastState.Bounded env30842 := by
  intro p hp
  have h : env30842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30841_30842 : H12AffineEnvironment.transform 5 10 env30841 = env30842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env30841 == env30842) = true)

def env30843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5238,1344,5367,4417,5125,4097,5277,16,4390,145,5377,1150,1296,1296,7269,5461,5457,257,1281,1345,5953]

theorem envBound30843 : H12AffineFastState.Bounded env30843 := by
  intro p hp
  have h : env30843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30833_30843 : H12AffineEnvironment.transform 12 5465 env30833 = env30843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env30833 == env30843) = true)

theorem identity30843 : scanCanonicalize (H12AffineFastState.compose env30843 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound30843 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1296,1028,1142,1344,1271,321,1029,1,1181,16,294,145,1281,1150,1296,1296,3173,1365,1361,257,1281,1345,1857]

theorem envBound30844 : H12AffineFastState.Bounded env30844 := by
  intro p hp
  have h : env30844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30843_30844 : H12AffineEnvironment.transform 11 0 env30843 = env30844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env30843 == env30844) = true)

theorem identity30844 : scanCanonicalize (H12AffineFastState.compose env30844 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound30844 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env30845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,0,1369,1296,1028,1142,1344,1271,321,1029,1,1181,16,294,145,1281,1150,1296,1296,659,1365,1361,257,1281,1345,1857]

theorem envBound30845 : H12AffineFastState.Bounded env30845 := by
  intro p hp
  have h : env30845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30844_30845 : H12AffineEnvironment.transform 10 1782 env30844 = env30845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env30844 == env30845) = true)

theorem identity30845 : scanCanonicalize (H12AffineFastState.compose env30845 (packedSelected [0,2,7,8,10,12,15,16,17,18,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound30845 : packedSelected [0,2,7,8,10,12,15,16,17,18,28,32] rootPS < 2^1333 := by decide +kernel

def env30846 : List Nat := [2,4,8,16,32,64,128,256,512,880,390,0,553,608,884,774,560,903,321,885,1,1005,16,294,145,625,782,608,608,659,549,545,257,625,561,49]

theorem envBound30846 : H12AffineFastState.Bounded env30846 := by
  intro p hp
  have h : env30846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30845_30846 : H12AffineEnvironment.transform 9 880 env30845 = env30846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env30845 == env30846) = true)

theorem identity30846 : scanCanonicalize (H12AffineFastState.compose env30846 (packedSelected [3,8,11,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound30846 : packedSelected [3,8,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env30847 : List Nat := [2,4,8,16,32,64,128,172,512,732,42,0,553,608,728,682,560,555,237,729,1,577,16,138,145,625,674,608,608,659,549,545,173,625,561,49]

theorem envBound30847 : H12AffineFastState.Bounded env30847 := by
  intro p hp
  have h : env30847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30846_30847 : H12AffineEnvironment.transform 7 172 env30846 = env30847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30846 == env30847) = true)

theorem identity30847 : scanCanonicalize (H12AffineFastState.compose env30847 (packedSelected [0,1,3,5,7,8,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound30847 : packedSelected [0,1,3,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env30848 : List Nat := [2,4,8,16,32,64,128,172,48,236,42,0,25,80,232,154,0,27,237,233,1,113,16,138,145,65,146,80,80,163,21,17,173,65,1,49]

theorem envBound30848 : H12AffineFastState.Bounded env30848 := by
  intro p hp
  have h : env30848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30847_30848 : H12AffineEnvironment.transform 8 48 env30847 = env30848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env30847 == env30848) = true)

theorem identity30848 : scanCanonicalize (H12AffineFastState.compose env30848 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30848 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30849 : List Nat := [2,4,8,11,32,64,128,172,43,236,42,0,2,75,232,129,0,0,237,233,1,106,11,138,138,65,137,75,75,163,14,10,173,65,1,42]

theorem envBound30849 : H12AffineFastState.Bounded env30849 := by
  intro p hp
  have h : env30849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30848_30849 : H12AffineEnvironment.transform 3 11 env30848 = env30849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30848 == env30849) = true)

theorem identity30849 : scanCanonicalize (H12AffineFastState.compose env30849 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound30849 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30850 : List Nat := [2,4,8,11,2,64,128,142,9,206,8,0,2,75,202,129,0,0,207,203,1,72,11,138,138,65,137,75,75,129,14,10,143,65,1,8]

theorem envBound30850 : H12AffineFastState.Bounded env30850 := by
  intro p hp
  have h : env30850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30849_30850 : H12AffineEnvironment.transform 4 2 env30849 = env30850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env30849 == env30850) = true)

theorem identity30850 : scanCanonicalize (H12AffineFastState.compose env30850 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30850 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30851 : List Nat := [2,4,8,11,2,64,9,7,9,71,8,0,2,75,67,8,0,0,70,66,1,72,11,3,3,65,0,75,75,8,14,10,6,65,1,8]

theorem envBound30851 : H12AffineFastState.Bounded env30851 := by
  intro p hp
  have h : env30851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30850_30851 : H12AffineEnvironment.transform 6 9 env30850 = env30851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30850 == env30851) = true)

theorem identity30851 : scanCanonicalize (H12AffineFastState.compose env30851 (packedSelected [0,1,2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30851 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env30852 : List Nat := [2,4,1,2,2,64,0,7,0,71,1,0,2,66,67,1,0,0,70,66,1,65,2,3,3,65,0,66,66,1,7,3,6,65,1,1]

theorem envBound30852 : H12AffineFastState.Bounded env30852 := by
  intro p hp
  have h : env30852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30851_30852 : H12AffineEnvironment.transform 2 1 env30851 = env30852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30851 == env30852) = true)

theorem identity30852 : scanCanonicalize (H12AffineFastState.compose env30852 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30852 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30853 : List Nat := [2,4,1,2,2,0,0,7,0,7,1,0,2,2,3,1,0,0,6,2,1,1,2,3,3,1,0,2,2,1,7,3,6,1,1,1]

theorem envBound30853 : H12AffineFastState.Bounded env30853 := by
  intro p hp
  have h : env30853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30852_30853 : H12AffineEnvironment.transform 5 0 env30852 = env30853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30852 == env30853) = true)

theorem identity30853 : scanCanonicalize (H12AffineFastState.compose env30853 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30854 : List Nat := [2,1,1,2,2,0,0,2,0,2,1,0,2,2,3,1,0,0,3,2,1,1,2,3,3,1,0,2,2,1,2,3,3,1,1,1]

theorem envBound30854 : H12AffineFastState.Bounded env30854 := by
  intro p hp
  have h : env30854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30853_30854 : H12AffineEnvironment.transform 1 1 env30853 = env30854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30853 == env30854) = true)

theorem identity30854 : scanCanonicalize (H12AffineFastState.compose env30854 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30854 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30855 : List Nat := [1,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,0,0,1,0,1,1,1,1,0,0,1,1,1]

theorem envBound30855 : H12AffineFastState.Bounded env30855 := by
  intro p hp
  have h : env30855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30854_30855 : H12AffineEnvironment.transform 0 1 env30854 = env30855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30854 == env30855) = true)

def env30856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4097,5277,74046,66896,13769,78894,328959,74814,1296,81227,8205,8201,257,74798,1345,5952]

theorem envBound30856 : H12AffineFastState.Bounded env30856 := by
  intro p hp
  have h : env30856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30815_30856 : H12AffineEnvironment.transform 13 1297 env30815 = env30856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env30815 == env30856) = true)

def env30857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4097,5277,74046,66896,13769,78894,1151,74814,1296,81227,8205,8201,257,74798,1345,5952]

theorem envBound30857 : H12AffineFastState.Bounded env30857 := by
  intro p hp
  have h : env30857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30856_30857 : H12AffineEnvironment.transform 17 65664 env30856 = env30857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30856 == env30857) = true)

theorem identity30857 : scanCanonicalize (H12AffineFastState.compose env30857 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound30857 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12670,5393,12798,4416,8541,4097,5277,4160,13358,13769,1360,1151,5440,1296,3125,8205,8201,257,5456,1345,5952]

theorem envBound30858 : H12AffineFastState.Bounded env30858 := by
  intro p hp
  have h : env30858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30857_30858 : H12AffineEnvironment.transform 15 12670 env30857 = env30858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env30857 == env30858) = true)

def env30859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8494,1345,8622,272,8541,81,1229,16,9342,9625,1360,1151,1296,1296,3125,8205,8201,257,1280,1345,1808]

theorem envBound30859 : H12AffineFastState.Bounded env30859 := by
  intro p hp
  have h : env30859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30858_30859 : H12AffineEnvironment.transform 11 80 env30858 = env30859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env30858 == env30859) = true)

theorem identity30859 : scanCanonicalize (H12AffineFastState.compose env30859 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30859 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30860 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,80,8192,1028,8265,8251,1108,8379,5,8264,81,1229,16,9342,9356,1093,1151,1029,1029,3125,8205,8201,20,1045,1108,1541]

theorem envBound30860 : H12AffineFastState.Bounded env30860 := by
  intro p hp
  have h : env30860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30859_30860 : H12AffineEnvironment.transform 7 21 env30859 = env30860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30859 == env30860) = true)

theorem identity30860 : scanCanonicalize (H12AffineFastState.compose env30860 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30860 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30861 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,80,8192,1,8265,8251,81,8379,5,8264,81,200,16,8315,8329,64,122,0,0,2096,8205,8201,20,16,81,512]

theorem envBound30861 : H12AffineFastState.Bounded env30861 := by
  intro p hp
  have h : env30861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30860_30861 : H12AffineEnvironment.transform 9 5 env30860 = env30861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30860 == env30861) = true)

theorem identity30861 : scanCanonicalize (H12AffineFastState.compose env30861 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30861 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30862 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,1,8216,8251,0,8379,5,8217,0,153,16,8234,8329,17,43,0,0,2096,8205,8201,20,16,0,512]

theorem envBound30862 : H12AffineFastState.Bounded env30862 := by
  intro p hp
  have h : env30862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30861_30862 : H12AffineEnvironment.transform 5 17 env30861 = env30862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30861 == env30862) = true)

theorem identity30862 : scanCanonicalize (H12AffineFastState.compose env30862 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound30862 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30863 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,2721,1,2745,2714,0,2586,5,2744,0,153,16,2699,2600,17,43,0,0,2096,2732,2728,20,16,0,512]

theorem envBound30863 : H12AffineFastState.Bounded env30863 := by
  intro p hp
  have h : env30863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30862_30863 : H12AffineEnvironment.transform 12 2721 env30862 = env30863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env30862 == env30863) = true)

theorem identity30863 : scanCanonicalize (H12AffineFastState.compose env30863 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound30863 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30864 : List Nat := [2,4,8,16,32,17,128,21,512,5,185,1,536,1,512,547,0,675,5,513,0,153,16,562,657,17,43,0,0,137,533,529,20,16,0,512]

theorem envBound30864 : H12AffineFastState.Bounded env30864 := by
  intro p hp
  have h : env30864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30863_30864 : H12AffineEnvironment.transform 10 185 env30863 = env30864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env30863 == env30864) = true)

theorem identity30864 : scanCanonicalize (H12AffineFastState.compose env30864 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound30864 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30865 : List Nat := [2,4,8,16,32,17,128,21,137,5,185,1,145,1,137,170,0,42,5,136,0,153,16,187,24,17,43,0,0,137,156,152,20,16,0,137]

theorem envBound30865 : H12AffineFastState.Bounded env30865 := by
  intro p hp
  have h : env30865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30864_30865 : H12AffineEnvironment.transform 8 137 env30864 = env30865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env30864 == env30865) = true)

theorem identity30865 : scanCanonicalize (H12AffineFastState.compose env30865 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound30865 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30866 : List Nat := [2,4,8,16,32,17,57,21,48,5,0,1,40,1,48,19,0,42,5,49,0,32,16,2,24,17,43,0,0,48,37,33,20,16,0,48]

theorem envBound30866 : H12AffineFastState.Bounded env30866 := by
  intro p hp
  have h : env30866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30865_30866 : H12AffineEnvironment.transform 6 57 env30865 = env30866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env30865 == env30866) = true)

def env30867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8495,1344,8623,273,8541,80,1228,17,9343,9624,1360,1151,1297,1296,3125,8205,8201,257,1281,1345,1809]

theorem envBound30867 : H12AffineFastState.Bounded env30867 := by
  intro p hp
  have h : env30867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30858_30867 : H12AffineEnvironment.transform 11 81 env30858 = env30867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env30858 == env30867) = true)

theorem identity30867 : scanCanonicalize (H12AffineFastState.compose env30867 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound30867 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1297,277,358,1344,486,273,276,80,1228,17,1078,1489,1360,1151,1297,1296,3125,68,64,257,1281,1345,1809]

theorem envBound30868 : H12AffineFastState.Bounded env30868 := by
  intro p hp
  have h : env30868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30867_30868 : H12AffineEnvironment.transform 12 73 env30867 = env30868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env30867 == env30868) = true)

theorem identity30868 : scanCanonicalize (H12AffineFastState.compose env30868 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 732) := by decide +kernel

theorem selectedBound30868 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env30869 : List Nat := [2,4,8,16,32,64,128,256,512,732,2048,81,73,973,277,358,924,486,273,276,80,528,17,746,781,908,675,973,972,2793,68,64,257,989,925,461]

theorem envBound30869 : H12AffineFastState.Bounded env30869 := by
  intro p hp
  have h : env30869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30868_30869 : H12AffineEnvironment.transform 9 732 env30868 = env30869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 732 env30868 == env30869) = true)

theorem identity30869 : scanCanonicalize (H12AffineFastState.compose env30869 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30869 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env30870 : List Nat := [2,4,8,16,32,64,128,256,136,84,2048,81,73,325,277,358,276,486,273,276,80,152,17,98,389,260,43,325,324,2145,68,64,257,341,277,461]

theorem envBound30870 : H12AffineFastState.Bounded env30870 := by
  intro p hp
  have h : env30870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30869_30870 : H12AffineEnvironment.transform 8 136 env30869 = env30870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30869 == env30870) = true)

theorem identity30870 : scanCanonicalize (H12AffineFastState.compose env30870 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound30870 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env30871 : List Nat := [2,4,8,16,32,64,128,256,136,84,373,81,73,325,277,358,276,486,273,276,80,152,17,98,389,260,43,325,324,276,68,64,257,341,277,461]

theorem envBound30871 : H12AffineFastState.Bounded env30871 := by
  intro p hp
  have h : env30871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30870_30871 : H12AffineEnvironment.transform 10 373 env30870 = env30871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env30870 == env30871) = true)

theorem identity30871 : scanCanonicalize (H12AffineFastState.compose env30871 (packedSelected [0,5,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound30871 : packedSelected [0,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30872 : List Nat := [2,4,8,16,32,64,128,231,136,84,146,81,73,162,242,129,243,1,246,243,80,152,17,98,98,227,43,162,163,243,68,64,230,178,242,42]

theorem envBound30872 : H12AffineFastState.Bounded env30872 := by
  intro p hp
  have h : env30872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30871_30872 : H12AffineEnvironment.transform 7 231 env30871 = env30872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env30871 == env30872) = true)

theorem identity30872 : scanCanonicalize (H12AffineFastState.compose env30872 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30872 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30873 : List Nat := [2,4,8,16,32,64,8,111,0,84,26,81,73,42,122,9,123,1,126,123,80,16,17,98,98,107,43,42,43,123,68,64,110,58,122,42]

theorem envBound30873 : H12AffineFastState.Bounded env30873 := by
  intro p hp
  have h : env30873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30872_30873 : H12AffineEnvironment.transform 6 8 env30872 = env30873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30872 == env30873) = true)

theorem identity30873 : scanCanonicalize (H12AffineFastState.compose env30873 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30873 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30874 : List Nat := [2,4,8,16,17,64,8,94,0,84,26,81,73,27,75,9,74,1,79,74,80,16,17,83,83,90,26,27,26,74,68,64,95,11,75,27]

theorem envBound30874 : H12AffineFastState.Bounded env30874 := by
  intro p hp
  have h : env30874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30873_30874 : H12AffineEnvironment.transform 4 17 env30873 = env30874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30873 == env30874) = true)

theorem identity30874 : scanCanonicalize (H12AffineFastState.compose env30874 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30874 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30875 : List Nat := [2,4,8,11,10,64,8,69,0,79,1,74,73,0,75,9,74,1,79,74,75,11,10,72,72,65,1,0,1,74,68,64,68,11,75,0]

theorem envBound30875 : H12AffineFastState.Bounded env30875 := by
  intro p hp
  have h : env30875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30874_30875 : H12AffineEnvironment.transform 3 11 env30874 = env30875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30874 == env30875) = true)

theorem identity30875 : scanCanonicalize (H12AffineFastState.compose env30875 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound30875 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30876 : List Nat := [2,4,8,11,10,11,8,14,0,4,1,1,2,0,0,9,1,1,4,1,0,11,10,3,3,10,1,0,1,1,15,11,15,11,0,0]

theorem envBound30876 : H12AffineFastState.Bounded env30876 := by
  intro p hp
  have h : env30876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30875_30876 : H12AffineEnvironment.transform 5 11 env30875 = env30876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env30875 == env30876) = true)

theorem identity30876 : scanCanonicalize (H12AffineFastState.compose env30876 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30877 : List Nat := [2,4,5,6,7,6,5,3,0,4,1,1,2,0,0,4,1,1,4,1,0,6,7,3,3,7,1,0,1,1,2,6,2,6,0,0]

theorem envBound30877 : H12AffineFastState.Bounded env30877 := by
  intro p hp
  have h : env30877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30876_30877 : H12AffineEnvironment.transform 2 5 env30876 = env30877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30876 == env30877) = true)

def env30878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4097,5277,74046,66896,13769,78894,1150,74814,1296,81227,8205,8201,257,74798,1345,5952]

theorem envBound30878 : H12AffineFastState.Bounded env30878 := by
  intro p hp
  have h : env30878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30856_30878 : H12AffineEnvironment.transform 17 65665 env30856 = env30878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30856 == env30878) = true)

theorem identity30878 : scanCanonicalize (H12AffineFastState.compose env30878 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound30878 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9279,80,9406,4416,8541,4097,5277,1281,8559,13769,4113,1150,1,1296,6516,8205,8201,257,17,1345,5952]

theorem envBound30879 : H12AffineFastState.Bounded env30879 := by
  intro p hp
  have h : env30879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30878_30879 : H12AffineEnvironment.transform 15 9279 env30878 = env30879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env30878 == env30879) = true)

def env30880 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8495,80,8622,4416,8541,4097,4493,17,8559,12505,4113,366,1,0,6516,8205,8201,257,17,81,4688]

theorem envBound30880 : H12AffineFastState.Bounded env30880 := by
  intro p hp
  have h : env30880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30879_30880 : H12AffineEnvironment.transform 9 272 env30879 = env30880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30879 == env30880) = true)

theorem identity30880 : scanCanonicalize (H12AffineFastState.compose env30880 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound30880 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30881 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,1,4420,4407,80,4534,4416,4421,4097,4493,17,4471,193,4113,366,1,0,6516,4117,4113,257,17,81,4688]

theorem envBound30881 : H12AffineFastState.Bounded env30881 := by
  intro p hp
  have h : env30881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30880_30881 : H12AffineEnvironment.transform 12 4120 env30880 = env30881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env30880 == env30881) = true)

theorem identity30881 : scanCanonicalize (H12AffineFastState.compose env30881 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound30881 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env30882 : List Nat := [2,4,8,16,32,64,128,256,460,272,2048,4096,4120,1,4420,4407,80,4534,4416,4421,4097,4493,17,4471,193,4113,366,1,0,6516,4117,4113,257,17,81,4508]

theorem envBound30882 : H12AffineFastState.Bounded env30882 := by
  intro p hp
  have h : env30882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30881_30882 : H12AffineEnvironment.transform 8 460 env30881 = env30882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env30881 == env30882) = true)

theorem identity30882 : scanCanonicalize (H12AffineFastState.compose env30882 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound30882 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env30883 : List Nat := [2,4,8,16,32,64,128,68,136,84,2048,4096,4120,1,4096,4211,80,4338,4100,4097,4097,4297,17,4147,193,4113,42,1,0,6192,4117,4113,69,17,81,4312]

theorem envBound30883 : H12AffineFastState.Bounded env30883 := by
  intro p hp
  have h : env30883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30882_30883 : H12AffineEnvironment.transform 7 68 env30882 = env30883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env30882 == env30883) = true)

theorem identity30883 : scanCanonicalize (H12AffineFastState.compose env30883 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 74) := by decide +kernel

theorem selectedBound30883 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env30884 : List Nat := [2,4,8,16,32,64,128,68,136,84,2048,74,82,1,74,57,80,184,78,75,75,131,17,121,193,91,42,1,0,2170,95,91,69,17,81,146]

theorem envBound30884 : H12AffineFastState.Bounded env30884 := by
  intro p hp
  have h : env30884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30883_30884 : H12AffineEnvironment.transform 11 74 env30883 = env30884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 74 env30883 == env30884) = true)

theorem identity30884 : scanCanonicalize (H12AffineFastState.compose env30884 (packedSelected [2,4,5,8,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound30884 : packedSelected [2,4,5,8,9,16] rootPS < 2^1333 := by decide +kernel

def env30885 : List Nat := [2,4,8,16,32,64,128,68,136,84,26,74,82,1,74,57,80,184,78,75,75,131,17,121,193,91,42,1,0,96,95,91,69,17,81,146]

theorem envBound30885 : H12AffineFastState.Bounded env30885 := by
  intro p hp
  have h : env30885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30884_30885 : H12AffineEnvironment.transform 10 26 env30884 = env30885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env30884 == env30885) = true)

theorem identity30885 : scanCanonicalize (H12AffineFastState.compose env30885 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30885 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30886 : List Nat := [2,4,8,16,32,16,128,20,136,4,26,26,2,1,26,57,0,184,30,27,27,131,17,41,145,11,42,1,0,48,15,11,21,17,1,146]

theorem envBound30886 : H12AffineFastState.Bounded env30886 := by
  intro p hp
  have h : env30886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30885_30886 : H12AffineEnvironment.transform 5 16 env30885 = env30886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30885 == env30886) = true)

theorem identity30886 : scanCanonicalize (H12AffineFastState.compose env30886 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound30886 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30887 : List Nat := [2,4,8,16,32,16,19,20,27,4,26,26,2,1,26,57,0,43,30,27,27,16,17,41,2,11,42,1,0,48,15,11,21,17,1,1]

theorem envBound30887 : H12AffineFastState.Bounded env30887 := by
  intro p hp
  have h : env30887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30886_30887 : H12AffineEnvironment.transform 6 19 env30886 = env30887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env30886 == env30887) = true)

theorem identity30887 : scanCanonicalize (H12AffineFastState.compose env30887 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30887 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30888 : List Nat := [2,4,8,16,16,16,19,20,27,4,26,26,2,1,26,9,0,27,30,27,27,16,17,25,2,11,26,1,0,0,15,11,21,17,1,1]

theorem envBound30888 : H12AffineFastState.Bounded env30888 := by
  intro p hp
  have h : env30888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30887_30888 : H12AffineEnvironment.transform 4 16 env30887 = env30888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30887 == env30888) = true)

theorem identity30888 : scanCanonicalize (H12AffineFastState.compose env30888 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30889 : List Nat := [2,4,8,11,11,11,8,15,0,4,1,1,2,1,1,9,0,0,5,0,0,11,10,2,2,11,1,1,0,0,15,11,14,10,1,1]

theorem envBound30889 : H12AffineFastState.Bounded env30889 := by
  intro p hp
  have h : env30889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30888_30889 : H12AffineEnvironment.transform 3 11 env30888 = env30889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30888 == env30889) = true)

theorem identity30889 : scanCanonicalize (H12AffineFastState.compose env30889 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound30889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30890 : List Nat := [2,4,6,5,5,5,6,1,0,4,1,1,2,1,1,7,0,0,5,0,0,5,4,2,2,5,1,1,0,0,1,5,0,4,1,1]

theorem envBound30890 : H12AffineFastState.Bounded env30890 := by
  intro p hp
  have h : env30890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30889_30890 : H12AffineEnvironment.transform 2 6 env30889 = env30890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env30889 == env30890) = true)

theorem identity30890 : scanCanonicalize (H12AffineFastState.compose env30890 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30891 : List Nat := [2,3,1,2,2,2,1,1,0,3,1,1,2,1,1,0,0,0,2,0,0,2,3,2,2,2,1,1,0,0,1,2,0,3,1,1]

theorem envBound30891 : H12AffineFastState.Bounded env30891 := by
  intro p hp
  have h : env30891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30890_30891 : H12AffineEnvironment.transform 1 3 env30890 = env30891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30890 == env30891) = true)

theorem identity30891 : scanCanonicalize (H12AffineFastState.compose env30891 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30891 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30892 : List Nat := [1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,1,0,0,1,0,1,1,1,1,1,0,0,1,1,0,0,1,1]

theorem envBound30892 : H12AffineFastState.Bounded env30892 := by
  intro p hp
  have h : env30892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30891_30892 : H12AffineEnvironment.transform 0 1 env30891 = env30892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30891 == env30892) = true)

def env30893 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8494,80,8623,4416,8541,4097,4492,16,8559,12504,4113,367,1,1,6516,8205,8201,257,17,80,4689]

theorem envBound30893 : H12AffineFastState.Bounded env30893 := by
  intro p hp
  have h : env30893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30879_30893 : H12AffineEnvironment.transform 9 273 env30879 = env30893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30879 == env30893) = true)

theorem identity30893 : scanCanonicalize (H12AffineFastState.compose env30893 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound30893 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30894 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,325,8192,0,8540,8494,80,8623,5,8541,324,201,16,8559,8605,340,367,1,1,2097,8205,8201,257,17,80,788]

theorem envBound30894 : H12AffineFastState.Bounded env30894 := by
  intro p hp
  have h : env30894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30893_30894 : H12AffineEnvironment.transform 11 325 env30893 = env30894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env30893 == env30894) = true)

theorem identity30894 : scanCanonicalize (H12AffineFastState.compose env30894 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30894 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30895 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,0,8264,8250,80,8379,5,8265,80,201,16,8315,8329,64,123,1,1,2097,8205,8201,21,17,80,512]

theorem envBound30895 : H12AffineFastState.Bounded env30895 := by
  intro p hp
  have h : env30895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30894_30895 : H12AffineEnvironment.transform 7 20 env30894 = env30895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30894 == env30895) = true)

theorem identity30895 : scanCanonicalize (H12AffineFastState.compose env30895 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30895 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30896 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,0,8217,8250,1,8379,5,8216,1,152,16,8234,8329,17,42,1,1,2097,8205,8201,21,17,1,512]

theorem envBound30896 : H12AffineFastState.Bounded env30896 := by
  intro p hp
  have h : env30896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30895_30896 : H12AffineEnvironment.transform 5 17 env30895 = env30896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30895 == env30896) = true)

theorem identity30896 : scanCanonicalize (H12AffineFastState.compose env30896 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound30896 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30897 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,2720,0,2745,2714,1,2587,5,2744,1,152,16,2698,2601,17,42,1,1,2097,2733,2729,21,17,1,512]

theorem envBound30897 : H12AffineFastState.Bounded env30897 := by
  intro p hp
  have h : env30897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30896_30897 : H12AffineEnvironment.transform 12 2720 env30896 = env30897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env30896 == env30897) = true)

theorem identity30897 : scanCanonicalize (H12AffineFastState.compose env30897 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound30897 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30898 : List Nat := [2,4,8,16,32,17,128,20,512,5,659,0,51,0,42,9,1,136,5,43,1,152,16,25,186,17,42,1,1,674,62,58,21,17,1,512]

theorem envBound30898 : H12AffineFastState.Bounded env30898 := by
  intro p hp
  have h : env30898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30897_30898 : H12AffineEnvironment.transform 10 659 env30897 = env30898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env30897 == env30898) = true)

theorem identity30898 : scanCanonicalize (H12AffineFastState.compose env30898 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30898 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30899 : List Nat := [2,4,8,16,32,17,128,20,136,5,27,0,51,0,42,9,1,136,5,43,1,152,16,25,186,17,42,1,1,42,62,58,21,17,1,136]

theorem envBound30899 : H12AffineFastState.Bounded env30899 := by
  intro p hp
  have h : env30899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30898_30899 : H12AffineEnvironment.transform 8 136 env30898 = env30899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30898 == env30899) = true)

theorem identity30899 : scanCanonicalize (H12AffineFastState.compose env30899 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound30899 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30900 : List Nat := [2,4,8,16,32,17,57,20,49,5,27,0,51,0,42,9,1,49,5,43,1,33,16,25,3,17,42,1,1,42,62,58,21,17,1,49]

theorem envBound30900 : H12AffineFastState.Bounded env30900 := by
  intro p hp
  have h : env30900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30899_30900 : H12AffineEnvironment.transform 6 57 env30899 = env30900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env30899 == env30900) = true)

theorem identity30900 : scanCanonicalize (H12AffineFastState.compose env30900 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30900 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env30901 : List Nat := [2,4,8,16,11,17,18,20,26,5,27,0,24,0,1,9,1,26,5,0,1,10,16,25,3,17,1,1,1,1,21,17,21,17,1,26]

theorem envBound30901 : H12AffineFastState.Bounded env30901 := by
  intro p hp
  have h : env30901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30900_30901 : H12AffineEnvironment.transform 4 11 env30900 = env30901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30900 == env30901) = true)

theorem identity30901 : scanCanonicalize (H12AffineFastState.compose env30901 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound30901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30902 : List Nat := [2,4,8,6,11,7,4,2,12,5,13,0,14,0,1,9,1,12,5,0,1,10,6,15,3,7,1,1,1,1,3,7,3,7,1,12]

theorem envBound30902 : H12AffineFastState.Bounded env30902 := by
  intro p hp
  have h : env30902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30901_30902 : H12AffineEnvironment.transform 3 6 env30901 = env30902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env30901 == env30902) = true)

def env30903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245633,148800,545089,96346,16876545,17495098,257,131136,1344,525824]

theorem envBound30903 : H12AffineFastState.Bounded env30903 := by
  intro p hp
  have h : env30903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30204_30903 : H12AffineEnvironment.transform 26 17245633 env30204 = env30903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env30204 == env30903) = true)

theorem identity30903 : scanCanonicalize (H12AffineFastState.compose env30903 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound30903 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86519,209262,17245633,148800,74815,96346,16876545,17006916,257,131136,1344,95102]

theorem envBound30904 : H12AffineFastState.Bounded env30904 := by
  intro p hp
  have h : env30904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30903_30904 : H12AffineEnvironment.transform 18 95614 env30903 = env30904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env30903 == env30904) = true)

def env30905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86519,209262,225345,148800,74815,96346,381313,513220,257,131136,1344,95102]

theorem envBound30905 : H12AffineFastState.Bounded env30905 := by
  intro p hp
  have h : env30905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30904_30905 : H12AffineEnvironment.transform 23 284032 env30904 = env30905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env30904 == env30905) = true)

def env30906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86519,94526,77841,1296,74815,96346,381313,365716,257,16400,1344,95102]

theorem envBound30906 : H12AffineFastState.Bounded env30906 := by
  intro p hp
  have h : env30906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30905_30906 : H12AffineEnvironment.transform 16 16464 env30905 = env30906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env30905 == env30906) = true)

def env30907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70887,78894,77841,1296,74815,81226,365713,365716,257,1280,1344,79470]

theorem envBound30907 : H12AffineFastState.Bounded env30907 := by
  intro p hp
  have h : env30907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30906_30907 : H12AffineEnvironment.transform 13 1296 env30906 = env30907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env30906 == env30907) = true)

theorem identity30907 : scanCanonicalize (H12AffineFastState.compose env30907 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound30907 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,16,266384,70887,78894,77841,1296,74815,81226,336012,336009,257,1280,1344,79470]

theorem envBound30908 : H12AffineFastState.Bounded env30908 := by
  intro p hp
  have h : env30908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30907_30908 : H12AffineEnvironment.transform 14 13341 env30907 = env30908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env30907 == env30908) = true)

def env30909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,16,69648,70887,78894,77841,1296,74815,81226,8204,8201,257,1280,1344,79470]

theorem envBound30909 : H12AffineFastState.Bounded env30909 := by
  intro p hp
  have h : env30909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30908_30909 : H12AffineEnvironment.transform 17 65664 env30908 = env30909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30908 == env30909) = true)

theorem identity30909 : scanCanonicalize (H12AffineFastState.compose env30909 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30909 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30910 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,65536,80,65664,77934,12556,4097,477,16,69648,70135,78142,77841,0,74031,79962,8204,8201,257,16,80,78718]

theorem envBound30910 : H12AffineFastState.Bounded env30910 := by
  intro p hp
  have h : env30910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30909_30910 : H12AffineEnvironment.transform 9 272 env30909 = env30910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30909 == env30910) = true)

def env30911 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12557,65536,0,65664,77886,12556,4097,397,16,69648,70055,78142,77841,0,74031,79882,8204,8201,257,16,0,78638]

end H12CloudChart2