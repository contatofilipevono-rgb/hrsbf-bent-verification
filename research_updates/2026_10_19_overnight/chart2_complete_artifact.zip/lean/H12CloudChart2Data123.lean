import H12CloudChart2Data122

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity30393 : scanCanonicalize (H12AffineFastState.compose env30393 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30393 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30394 : List Nat := [0,1,0,0,1,1,0,256,257,257,256,0,1,0,256,0,256,0,256,257,1,256,257,0,1,257,257,256,0,256,0,0,257,256,1,256]

theorem envBound30394 : H12AffineFastState.Bounded env30394 := by
  intro p hp
  have h : env30394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30393_30394 : H12AffineEnvironment.transform 0 0 env30393 = env30394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30393 == env30394) = true)

theorem identity30394 : scanCanonicalize (H12AffineFastState.compose env30394 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound30394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30395 : List Nat := [0,1,0,0,1,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,0,0,1,0,1,0,0,0,1,1,1]

theorem envBound30395 : H12AffineFastState.Bounded env30395 := by
  intro p hp
  have h : env30395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30394_30395 : H12AffineEnvironment.transform 7 1 env30394 = env30395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env30394 == env30395) = true)

def env30396 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,65536,74110,65664,336,8476,16,476,74046,65537,8392,74031,302,74031,0,75851,8204,8201,257,74047,80,276]

theorem envBound30396 : H12AffineFastState.Bounded env30396 := by
  intro p hp
  have h : env30396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30373_30396 : H12AffineEnvironment.transform 11 17 env30373 = env30396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30373 == env30396) = true)

theorem identity30396 : scanCanonicalize (H12AffineFastState.compose env30396 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8325) := by decide +kernel

theorem selectedBound30396 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30397 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,8325,507,8197,336,8476,16,476,443,8324,8392,426,302,426,0,2254,8204,8201,257,442,80,276]

theorem envBound30397 : H12AffineFastState.Bounded env30397 := by
  intro p hp
  have h : env30397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30396_30397 : H12AffineEnvironment.transform 15 8325 env30396 = env30397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8325 env30396 == env30397) = true)

def env30398 : List Nat := [2,4,8,16,32,64,128,256,341,273,312,17,8192,0,8477,8325,507,8197,336,8476,16,476,443,8324,8392,426,302,426,0,502,8204,8201,257,442,80,276]

theorem envBound30398 : H12AffineFastState.Bounded env30398 := by
  intro p hp
  have h : env30398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30397_30398 : H12AffineEnvironment.transform 10 312 env30397 = env30398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 312 env30397 == env30398) = true)

theorem identity30398 : scanCanonicalize (H12AffineFastState.compose env30398 (packedSelected [0,2,3,4,5,9,10,12,13,15,20,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 198) := by decide +kernel

theorem selectedBound30398 : packedSelected [0,2,3,4,5,9,10,12,13,15,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30399 : List Nat := [2,4,8,16,32,64,128,256,341,273,312,17,198,0,475,67,507,195,336,474,16,476,443,66,14,426,302,426,0,502,202,207,257,442,80,276]

theorem envBound30399 : H12AffineFastState.Bounded env30399 := by
  intro p hp
  have h : env30399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30398_30399 : H12AffineEnvironment.transform 12 198 env30398 = env30399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 198 env30398 == env30399) = true)

theorem identity30399 : scanCanonicalize (H12AffineFastState.compose env30399 (packedSelected [0,2,3,4,10,12,13,16,17,18,21] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound30399 : packedSelected [0,2,3,4,10,12,13,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env30400 : List Nat := [2,4,8,16,32,54,128,256,291,273,312,17,176,0,429,53,397,181,294,428,16,426,443,52,14,426,302,426,0,384,188,185,257,442,38,276]

theorem envBound30400 : H12AffineFastState.Bounded env30400 := by
  intro p hp
  have h : env30400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30399_30400 : H12AffineEnvironment.transform 5 54 env30399 = env30400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env30399 == env30400) = true)

theorem identity30400 : scanCanonicalize (H12AffineFastState.compose env30400 (packedSelected [0,1,7,10,12,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30400 : packedSelected [0,1,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env30401 : List Nat := [2,4,8,16,32,54,15,256,291,273,312,17,63,0,290,53,258,58,294,291,16,293,308,52,14,293,302,293,0,271,51,54,257,309,38,276]

theorem envBound30401 : H12AffineFastState.Bounded env30401 := by
  intro p hp
  have h : env30401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30400_30401 : H12AffineEnvironment.transform 6 15 env30400 = env30401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30400 == env30401) = true)

theorem identity30401 : scanCanonicalize (H12AffineFastState.compose env30401 (packedSelected [0,2,4,8,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30401 : packedSelected [0,2,4,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env30402 : List Nat := [2,4,8,16,32,54,15,21,54,4,45,17,63,0,55,53,23,58,51,54,16,48,33,52,14,48,59,48,0,26,51,54,20,32,38,1]

theorem envBound30402 : H12AffineFastState.Bounded env30402 := by
  intro p hp
  have h : env30402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30401_30402 : H12AffineEnvironment.transform 7 21 env30401 = env30402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30401 == env30402) = true)

theorem identity30402 : scanCanonicalize (H12AffineFastState.compose env30402 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30402 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30403 : List Nat := [2,4,8,16,10,28,15,21,28,4,7,17,21,0,29,31,23,16,25,28,16,26,11,30,14,26,17,26,0,26,25,28,20,10,12,1]

theorem envBound30403 : H12AffineFastState.Bounded env30403 := by
  intro p hp
  have h : env30403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30402_30403 : H12AffineEnvironment.transform 4 10 env30402 = env30403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30402 == env30403) = true)

theorem identity30403 : scanCanonicalize (H12AffineFastState.compose env30403 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30403 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30404 : List Nat := [2,4,8,10,10,6,15,15,6,4,7,11,15,0,7,5,13,10,3,6,10,0,11,4,14,0,11,0,0,0,3,6,14,10,12,1]

theorem envBound30404 : H12AffineFastState.Bounded env30404 := by
  intro p hp
  have h : env30404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30403_30404 : H12AffineEnvironment.transform 3 10 env30403 = env30404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30403 == env30404) = true)

def env30405 : List Nat := [2,4,8,16,32,64,128,256,341,273,313,17,8192,0,8477,8325,507,8197,336,8476,16,476,443,8324,8392,426,302,426,0,503,8204,8201,257,442,80,276]

theorem envBound30405 : H12AffineFastState.Bounded env30405 := by
  intro p hp
  have h : env30405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30397_30405 : H12AffineEnvironment.transform 10 313 env30397 = env30405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 313 env30397 == env30405) = true)

theorem identity30405 : scanCanonicalize (H12AffineFastState.compose env30405 (packedSelected [0,2,3,4,5,9,10,12,13,15,20,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 193) := by decide +kernel

theorem selectedBound30405 : packedSelected [0,2,3,4,5,9,10,12,13,15,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30406 : List Nat := [2,4,8,16,32,64,128,256,341,273,313,17,193,0,476,68,507,196,336,477,16,476,443,69,9,426,302,426,0,503,205,200,257,442,80,276]

theorem envBound30406 : H12AffineFastState.Bounded env30406 := by
  intro p hp
  have h : env30406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30405_30406 : H12AffineEnvironment.transform 12 193 env30405 = env30406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 193 env30405 == env30406) = true)

theorem identity30406 : scanCanonicalize (H12AffineFastState.compose env30406 (packedSelected [0,4,5,8,10,11,12,17,19,20] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30406 : packedSelected [0,4,5,8,10,11,12,17,19,20] rootPS < 2^1333 := by decide +kernel

def env30407 : List Nat := [2,4,8,16,11,64,128,256,341,273,274,17,193,0,476,68,464,196,336,477,16,476,400,69,9,385,261,385,0,476,205,200,257,401,80,276]

theorem envBound30407 : H12AffineFastState.Bounded env30407 := by
  intro p hp
  have h : env30407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30406_30407 : H12AffineEnvironment.transform 4 11 env30406 = env30407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30406 == env30407) = true)

theorem identity30407 : scanCanonicalize (H12AffineFastState.compose env30407 (packedSelected [4,5,7,8,10,12,13,15,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30407 : packedSelected [4,5,7,8,10,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30408 : List Nat := [2,4,8,16,11,64,9,256,341,273,274,17,72,0,341,68,345,77,336,340,16,341,281,69,9,264,261,264,0,341,68,65,257,280,80,276]

theorem envBound30408 : H12AffineFastState.Bounded env30408 := by
  intro p hp
  have h : env30408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30407_30408 : H12AffineEnvironment.transform 6 9 env30407 = env30408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30407 == env30408) = true)

theorem identity30408 : scanCanonicalize (H12AffineFastState.compose env30408 (packedSelected [0,1,2,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound30408 : packedSelected [0,1,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env30409 : List Nat := [2,4,8,16,11,64,9,78,27,95,92,17,72,0,27,68,23,77,30,26,16,27,87,69,9,70,75,70,0,27,68,65,79,86,80,90]

theorem envBound30409 : H12AffineFastState.Bounded env30409 := by
  intro p hp
  have h : env30409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30408_30409 : H12AffineEnvironment.transform 7 78 env30408 = env30409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env30408 == env30409) = true)

theorem identity30409 : scanCanonicalize (H12AffineFastState.compose env30409 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30409 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env30410 : List Nat := [2,4,8,0,11,64,9,78,11,79,76,1,72,0,11,68,7,77,14,10,0,11,71,69,9,70,75,70,0,11,68,65,79,70,64,74]

theorem envBound30410 : H12AffineFastState.Bounded env30410 := by
  intro p hp
  have h : env30410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30409_30410 : H12AffineEnvironment.transform 3 0 env30409 = env30410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30409 == env30410) = true)

theorem identity30410 : scanCanonicalize (H12AffineFastState.compose env30410 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound30410 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30411 : List Nat := [2,4,8,0,11,13,9,3,11,2,1,1,5,0,11,9,7,0,14,10,0,11,10,8,9,11,6,11,0,11,9,12,2,11,13,7]

theorem envBound30411 : H12AffineFastState.Bounded env30411 := by
  intro p hp
  have h : env30411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30410_30411 : H12AffineEnvironment.transform 5 13 env30410 = env30411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env30410 == env30411) = true)

theorem identity30411 : scanCanonicalize (H12AffineFastState.compose env30411 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30411 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30412 : List Nat := [2,2,8,0,11,11,9,3,11,2,1,1,3,0,11,9,1,0,8,10,0,11,10,8,9,11,0,11,0,11,9,10,2,11,11,1]

theorem envBound30412 : H12AffineFastState.Bounded env30412 := by
  intro p hp
  have h : env30412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30411_30412 : H12AffineEnvironment.transform 1 2 env30411 = env30412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30411 == env30412) = true)

def env30413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4097,476,74046,69648,13768,78895,4414,74814,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound30413 : H12AffineFastState.Bounded env30413 := by
  intro p hp
  have h : env30413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30329_30413 : H12AffineEnvironment.transform 17 65665 env30329 = env30413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30329 == env30413) = true)

theorem identity30413 : scanCanonicalize (H12AffineFastState.compose env30413 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound30413 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,65536,74863,65665,272,9293,80,476,74046,65601,9625,74878,367,74814,1297,77082,8204,8201,257,74798,1345,1808]

theorem envBound30414 : H12AffineFastState.Bounded env30414 := by
  intro p hp
  have h : env30414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30413_30414 : H12AffineEnvironment.transform 11 81 env30413 = env30414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env30413 == env30414) = true)

def env30415 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8460,65536,74031,65665,272,8461,80,476,74046,65601,8409,74046,367,74110,81,75866,8204,8201,257,74094,1,592]

theorem envBound30415 : H12AffineFastState.Bounded env30415 := by
  intro p hp
  have h : env30415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30414_30415 : H12AffineEnvironment.transform 9 320 env30414 = env30415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30414 == env30415) = true)

theorem identity30415 : scanCanonicalize (H12AffineFastState.compose env30415 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30415 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env30416 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,81,8192,81,8217,65536,73786,65665,5,8216,80,201,73771,65601,8409,73771,122,73835,81,75866,8204,8201,20,73851,1,592]

theorem envBound30416 : H12AffineFastState.Bounded env30416 := by
  intro p hp
  have h : env30416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30415_30416 : H12AffineEnvironment.transform 7 21 env30415 = env30416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30415 == env30416) = true)

theorem identity30416 : scanCanonicalize (H12AffineFastState.compose env30416 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound30416 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30417 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,81,8192,81,8217,8298,80,8427,5,8216,80,201,65,8235,8409,65,122,1,81,2096,8204,8201,20,17,1,592]

theorem envBound30417 : H12AffineFastState.Bounded env30417 := by
  intro p hp
  have h : env30417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30416_30417 : H12AffineEnvironment.transform 15 8298 env30416 = env30417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env30416 == env30417) = true)

theorem identity30417 : scanCanonicalize (H12AffineFastState.compose env30417 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound30417 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env30418 : List Nat := [2,4,8,16,32,64,128,21,512,85,184,81,8192,81,8217,8298,80,8427,5,8216,80,201,65,8235,8409,65,122,1,81,136,8204,8201,20,17,1,592]

theorem envBound30418 : H12AffineFastState.Bounded env30418 := by
  intro p hp
  have h : env30418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30417_30418 : H12AffineEnvironment.transform 10 184 env30417 = env30418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env30417 == env30418) = true)

theorem identity30418 : scanCanonicalize (H12AffineFastState.compose env30418 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 633) := by decide +kernel

theorem selectedBound30418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30419 : List Nat := [2,4,8,16,32,64,128,21,512,85,184,81,633,81,608,531,80,658,5,609,80,201,65,594,672,65,122,1,81,136,629,624,20,17,1,592]

theorem envBound30419 : H12AffineFastState.Bounded env30419 := by
  intro p hp
  have h : env30419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30418_30419 : H12AffineEnvironment.transform 12 633 env30418 = env30419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 633 env30418 == env30419) = true)

theorem identity30419 : scanCanonicalize (H12AffineFastState.compose env30419 (packedSelected [1,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound30419 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env30420 : List Nat := [2,4,8,16,32,64,128,21,184,85,184,81,193,81,216,171,80,42,5,217,80,201,65,234,24,65,122,1,81,136,205,200,20,17,1,232]

theorem envBound30420 : H12AffineFastState.Bounded env30420 := by
  intro p hp
  have h : env30420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30419_30420 : H12AffineEnvironment.transform 8 184 env30419 = env30420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env30419 == env30420) = true)

theorem identity30420 : scanCanonicalize (H12AffineFastState.compose env30420 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound30420 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env30421 : List Nat := [2,4,8,16,32,64,35,21,27,85,27,81,98,81,123,8,80,42,5,122,80,106,65,73,24,65,122,1,81,43,110,107,20,17,1,75]

theorem envBound30421 : H12AffineFastState.Bounded env30421 := by
  intro p hp
  have h : env30421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30420_30421 : H12AffineEnvironment.transform 6 35 env30420 = env30421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env30420 == env30421) = true)

theorem identity30421 : scanCanonicalize (H12AffineFastState.compose env30421 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound30421 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30422 : List Nat := [2,4,8,16,32,58,35,21,27,47,27,43,24,43,1,8,42,42,5,0,42,16,59,51,24,59,0,1,43,43,20,17,20,17,1,49]

theorem envBound30422 : H12AffineFastState.Bounded env30422 := by
  intro p hp
  have h : env30422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30421_30422 : H12AffineEnvironment.transform 5 58 env30421 = env30422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env30421 == env30422) = true)

theorem identity30422 : scanCanonicalize (H12AffineFastState.compose env30422 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound30422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30423 : List Nat := [2,4,8,16,22,12,21,21,27,25,27,29,24,29,1,8,28,28,5,0,28,16,13,5,24,13,0,1,29,29,20,17,20,17,1,7]

theorem envBound30423 : H12AffineFastState.Bounded env30423 := by
  intro p hp
  have h : env30423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30422_30423 : H12AffineEnvironment.transform 4 22 env30422 = env30423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env30422 == env30423) = true)

theorem identity30423 : scanCanonicalize (H12AffineFastState.compose env30423 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30423 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30424 : List Nat := [2,4,8,12,10,12,9,9,7,5,7,1,4,1,1,8,0,0,5,0,0,12,13,5,4,13,0,1,1,1,8,13,8,13,1,7]

theorem envBound30424 : H12AffineFastState.Bounded env30424 := by
  intro p hp
  have h : env30424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30423_30424 : H12AffineEnvironment.transform 3 12 env30423 = env30424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30423 == env30424) = true)

theorem identity30424 : scanCanonicalize (H12AffineFastState.compose env30424 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30424 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30425 : List Nat := [2,3,8,11,10,11,9,9,0,2,0,1,3,1,1,8,0,0,2,0,0,11,10,2,3,10,0,1,1,1,8,10,8,10,1,0]

theorem envBound30425 : H12AffineFastState.Bounded env30425 := by
  intro p hp
  have h : env30425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30424_30425 : H12AffineEnvironment.transform 1 3 env30424 = env30425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30424 == env30425) = true)

def env30426 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8461,65536,74030,65665,272,8460,80,476,74046,65601,8408,74047,367,74111,80,75867,8204,8201,257,74095,0,593]

theorem envBound30426 : H12AffineFastState.Bounded env30426 := by
  intro p hp
  have h : env30426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30414_30426 : H12AffineEnvironment.transform 9 321 env30414 = env30426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env30414 == env30426) = true)

theorem identity30426 : scanCanonicalize (H12AffineFastState.compose env30426 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound30426 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env30427 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,81,8192,80,8264,65536,73835,65665,85,8265,80,153,73851,65601,8408,73850,42,73786,80,75867,8204,8201,68,73770,0,593]

theorem envBound30427 : H12AffineFastState.Bounded env30427 := by
  intro p hp
  have h : env30427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30426_30427 : H12AffineEnvironment.transform 7 69 env30426 = env30427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env30426 == env30427) = true)

theorem identity30427 : scanCanonicalize (H12AffineFastState.compose env30427 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound30427 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30428 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,81,8192,80,8264,8250,81,8379,85,8265,80,153,65,8315,8408,64,42,0,80,2145,8204,8201,68,16,0,593]

theorem envBound30428 : H12AffineFastState.Bounded env30428 := by
  intro p hp
  have h : env30428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30427_30428 : H12AffineEnvironment.transform 15 8250 env30427 = env30428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env30427 == env30428) = true)

theorem identity30428 : scanCanonicalize (H12AffineFastState.compose env30428 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30428 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30429 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,1,8217,8250,0,8379,4,8216,1,153,16,8234,8329,17,42,0,1,2096,8204,8201,21,16,0,512]

theorem envBound30429 : H12AffineFastState.Bounded env30429 := by
  intro p hp
  have h : env30429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30428_30429 : H12AffineEnvironment.transform 5 17 env30428 = env30429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30428 == env30429) = true)

theorem identity30429 : scanCanonicalize (H12AffineFastState.compose env30429 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound30429 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30430 : List Nat := [2,4,8,16,32,17,128,20,512,4,513,0,8192,1,8217,8250,0,8379,4,8216,1,153,16,8234,8329,17,42,0,1,561,8204,8201,21,16,0,512]

theorem envBound30430 : H12AffineFastState.Bounded env30430 := by
  intro p hp
  have h : env30430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30429_30430 : H12AffineEnvironment.transform 10 513 env30429 = env30430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env30429 == env30430) = true)

theorem identity30430 : scanCanonicalize (H12AffineFastState.compose env30430 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound30430 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30431 : List Nat := [2,4,8,16,32,17,128,20,512,4,513,0,160,1,185,154,0,27,4,184,1,153,16,138,41,17,42,0,1,561,172,169,21,16,0,512]

theorem envBound30431 : H12AffineFastState.Bounded env30431 := by
  intro p hp
  have h : env30431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30430_30431 : H12AffineEnvironment.transform 12 160 env30430 = env30431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env30430 == env30431) = true)

theorem identity30431 : scanCanonicalize (H12AffineFastState.compose env30431 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound30431 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30432 : List Nat := [2,4,8,16,32,17,128,20,162,4,163,0,160,1,185,154,0,27,4,184,1,153,16,138,41,17,42,0,1,147,172,169,21,16,0,162]

theorem envBound30432 : H12AffineFastState.Bounded env30432 := by
  intro p hp
  have h : env30432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30431_30432 : H12AffineEnvironment.transform 8 162 env30431 = env30432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env30431 == env30432) = true)

theorem identity30432 : scanCanonicalize (H12AffineFastState.compose env30432 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound30432 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env30433 : List Nat := [2,4,8,16,32,17,18,20,48,4,49,0,50,1,43,8,0,27,4,42,1,11,16,24,41,17,42,0,1,1,62,59,21,16,0,48]

theorem envBound30433 : H12AffineFastState.Bounded env30433 := by
  intro p hp
  have h : env30433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30432_30433 : H12AffineEnvironment.transform 6 18 env30432 = env30433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env30432 == env30433) = true)

theorem identity30433 : scanCanonicalize (H12AffineFastState.compose env30433 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30433 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30434 : List Nat := [2,4,8,10,32,11,8,14,42,4,43,0,40,1,43,8,0,1,4,42,1,11,10,2,41,11,42,0,1,1,36,33,15,10,0,42]

theorem envBound30434 : H12AffineFastState.Bounded env30434 := by
  intro p hp
  have h : env30434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30433_30434 : H12AffineEnvironment.transform 3 10 env30433 = env30434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30433 == env30434) = true)

theorem identity30434 : scanCanonicalize (H12AffineFastState.compose env30434 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30434 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30435 : List Nat := [2,4,8,10,10,11,8,14,0,4,1,0,2,1,1,8,0,1,4,0,1,11,10,2,3,11,0,0,1,1,14,11,15,10,0,0]

theorem envBound30435 : H12AffineFastState.Bounded env30435 := by
  intro p hp
  have h : env30435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30434_30435 : H12AffineEnvironment.transform 4 10 env30434 = env30435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30434 == env30435) = true)

theorem identity30435 : scanCanonicalize (H12AffineFastState.compose env30435 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30436 : List Nat := [2,4,5,7,7,6,5,3,0,4,1,0,2,1,1,5,0,1,4,0,1,6,7,2,3,6,0,0,1,1,3,6,2,7,0,0]

theorem envBound30436 : H12AffineFastState.Bounded env30436 := by
  intro p hp
  have h : env30436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30435_30436 : H12AffineEnvironment.transform 2 5 env30435 = env30436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30435 == env30436) = true)

def env30437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123164,28888,78894,385203,90415,1296,96346,25885,25881,257,74798,1345,21073]

theorem envBound30437 : H12AffineFastState.Bounded env30437 := by
  intro p hp
  have h : env30437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30207_30437 : H12AffineEnvironment.transform 18 21585 env30207 = env30437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env30207 == env30437) = true)

theorem identity30437 : scanCanonicalize (H12AffineFastState.compose env30437 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound30437 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4097,5277,91183,66897,28888,78894,328958,90415,1296,96346,25885,25881,257,74798,1345,21073]

theorem envBound30438 : H12AffineFastState.Bounded env30438 := by
  intro p hp
  have h : env30438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30437_30438 : H12AffineEnvironment.transform 14 25677 env30437 = env30438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env30437 == env30438) = true)

def env30439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4097,5277,74047,66897,13768,78894,328958,74815,1296,81226,8205,8201,257,74798,1345,5953]

theorem envBound30439 : H12AffineFastState.Bounded env30439 := by
  intro p hp
  have h : env30439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30438_30439 : H12AffineEnvironment.transform 13 1296 env30438 = env30439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env30438 == env30439) = true)

def env30440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4097,5277,74047,66897,13768,78894,1150,74815,1296,81226,8205,8201,257,74798,1345,5953]

theorem envBound30440 : H12AffineFastState.Bounded env30440 := by
  intro p hp
  have h : env30440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30439_30440 : H12AffineEnvironment.transform 17 65664 env30439 = env30440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30439 == env30440) = true)

theorem identity30440 : scanCanonicalize (H12AffineFastState.compose env30440 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound30440 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66678,65664,4417,325,4097,5277,65830,66897,5585,70711,1150,66598,1296,73043,20,16,257,66615,1345,5953]

theorem envBound30441 : H12AffineFastState.Bounded env30441 := by
  intro p hp
  have h : env30441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30440_30441 : H12AffineEnvironment.transform 12 25 env30440 = env30441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30440 == env30441) = true)

def env30442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66678,65664,1877,325,1557,649,65830,66897,965,66083,1150,66598,1296,68423,20,16,257,66615,1345,341]

theorem envBound30442 : H12AffineFastState.Bounded env30442 := by
  intro p hp
  have h : env30442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30441_30442 : H12AffineEnvironment.transform 11 1556 env30441 = env30442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env30441 == env30442) = true)

def env30443 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66614,65664,1813,261,1557,649,65830,66833,901,66083,1086,66598,1296,68359,20,16,257,66615,1281,277]

theorem envBound30443 : H12AffineFastState.Bounded env30443 := by
  intro p hp
  have h : env30443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30442_30443 : H12AffineEnvironment.transform 5 0 env30442 = env30443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30442 == env30443) = true)

theorem identity30443 : scanCanonicalize (H12AffineFastState.compose env30443 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 959) := by decide +kernel

theorem selectedBound30443 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30444 : List Nat := [2,4,8,16,32,0,128,256,512,959,2048,427,25,687,260,65536,66441,65664,170,261,426,649,65830,66222,901,66083,897,66457,687,68359,20,16,257,66440,702,277]

theorem envBound30444 : H12AffineFastState.Bounded env30444 := by
  intro p hp
  have h : env30444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30443_30444 : H12AffineEnvironment.transform 9 959 env30443 = env30444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 959 env30443 == env30444) = true)

def env30445 : List Nat := [2,4,8,16,32,0,128,188,512,515,2048,23,25,687,184,65536,66101,65664,170,185,22,649,65690,66222,569,66083,573,66085,687,68283,20,16,189,66100,702,169]

theorem envBound30445 : H12AffineFastState.Bounded env30445 := by
  intro p hp
  have h : env30445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30444_30445 : H12AffineEnvironment.transform 7 188 env30444 = env30445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env30444 == env30445) = true)

theorem identity30445 : scanCanonicalize (H12AffineFastState.compose env30445 (packedSelected [1,3,5,7,8,10,11,17,18,19,20,21,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 2057) := by decide +kernel

theorem selectedBound30445 : packedSelected [1,3,5,7,8,10,11,17,18,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30446 : List Nat := [2,4,8,16,32,0,128,188,512,515,2048,23,25,687,184,2057,2620,2185,170,185,22,649,2195,2727,569,2602,573,2604,687,690,20,16,189,2621,702,169]

theorem envBound30446 : H12AffineFastState.Bounded env30446 := by
  intro p hp
  have h : env30446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30445_30446 : H12AffineEnvironment.transform 15 2057 env30445 = env30446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2057 env30445 == env30446) = true)

theorem identity30446 : scanCanonicalize (H12AffineFastState.compose env30446 (packedSelected [0,4,13,15,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30446 : packedSelected [0,4,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env30447 : List Nat := [2,4,8,16,16,0,128,140,512,515,2048,23,25,671,136,2057,2572,2185,154,137,22,649,2195,2711,521,2586,525,2588,671,642,20,16,141,2573,654,153]

theorem envBound30447 : H12AffineFastState.Bounded env30447 := by
  intro p hp
  have h : env30447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30446_30447 : H12AffineEnvironment.transform 4 16 env30446 = env30447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30446 == env30447) = true)

theorem identity30447 : scanCanonicalize (H12AffineFastState.compose env30447 (packedSelected [0,1,3,4,7,9,11,12,13,15,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30447 : packedSelected [0,1,3,4,7,9,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env30448 : List Nat := [2,4,8,10,10,0,128,140,512,515,2048,13,3,645,136,2057,2572,2185,128,137,12,649,2185,2701,521,2560,525,2566,645,642,14,10,141,2573,654,131]

theorem envBound30448 : H12AffineFastState.Bounded env30448 := by
  intro p hp
  have h : env30448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30447_30448 : H12AffineEnvironment.transform 3 10 env30447 = env30448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30447 == env30448) = true)

theorem identity30448 : scanCanonicalize (H12AffineFastState.compose env30448 (packedSelected [2,3,4,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound30448 : packedSelected [2,3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30449 : List Nat := [2,4,8,10,10,0,14,2,512,515,2048,13,3,523,6,2057,2572,2055,14,7,12,519,2055,2563,521,2560,525,2566,523,524,14,10,3,2573,512,13]

theorem envBound30449 : H12AffineFastState.Bounded env30449 := by
  intro p hp
  have h : env30449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30448_30449 : H12AffineEnvironment.transform 6 14 env30448 = env30449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env30448 == env30449) = true)

theorem identity30449 : scanCanonicalize (H12AffineFastState.compose env30449 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound30449 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30450 : List Nat := [2,4,8,10,10,0,14,2,512,515,11,13,3,523,6,2,519,12,14,7,12,519,12,520,521,523,525,525,523,524,14,10,3,518,512,13]

theorem envBound30450 : H12AffineFastState.Bounded env30450 := by
  intro p hp
  have h : env30450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30449_30450 : H12AffineEnvironment.transform 10 11 env30449 = env30450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env30449 == env30450) = true)

theorem identity30450 : scanCanonicalize (H12AffineFastState.compose env30450 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound30450 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env30451 : List Nat := [2,4,8,10,10,0,14,2,7,4,11,13,3,12,6,2,0,12,14,7,12,0,12,15,14,12,10,10,12,11,14,10,3,1,7,13]

theorem envBound30451 : H12AffineFastState.Bounded env30451 := by
  intro p hp
  have h : env30451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30450_30451 : H12AffineEnvironment.transform 8 7 env30450 = env30451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env30450 == env30451) = true)

theorem identity30451 : scanCanonicalize (H12AffineFastState.compose env30451 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30451 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30452 : List Nat := [2,2,8,10,10,0,8,2,1,2,11,11,3,10,0,2,0,10,8,1,10,0,10,9,8,10,10,10,10,11,8,10,3,1,1,11]

theorem envBound30452 : H12AffineFastState.Bounded env30452 := by
  intro p hp
  have h : env30452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30451_30452 : H12AffineEnvironment.transform 1 2 env30451 = env30452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30451 == env30452) = true)

theorem identity30452 : scanCanonicalize (H12AffineFastState.compose env30452 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30453 : List Nat := [2,2,2,0,0,0,2,2,1,2,1,1,3,0,0,2,0,0,2,1,0,0,0,3,2,0,0,0,0,1,2,0,3,1,1,1]

theorem envBound30453 : H12AffineFastState.Bounded env30453 := by
  intro p hp
  have h : env30453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30452_30453 : H12AffineEnvironment.transform 2 2 env30452 = env30453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30452 == env30453) = true)

def env30454 : List Nat := [2,4,8,16,32,0,128,189,512,514,2048,22,25,687,185,65536,66100,65664,170,184,23,649,65691,66222,568,66083,572,66084,687,68282,20,16,188,66101,702,168]

theorem envBound30454 : H12AffineFastState.Bounded env30454 := by
  intro p hp
  have h : env30454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30444_30454 : H12AffineEnvironment.transform 7 189 env30444 = env30454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env30444 == env30454) = true)

theorem identity30454 : scanCanonicalize (H12AffineFastState.compose env30454 (packedSelected [1,3,5,7,8,10,11,17,18,19,20,21,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 2063) := by decide +kernel

theorem selectedBound30454 : packedSelected [1,3,5,7,8,10,11,17,18,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30455 : List Nat := [2,4,8,16,32,0,128,189,512,514,2048,22,25,687,185,2063,2619,2191,170,184,23,649,2196,2721,568,2604,572,2603,687,693,20,16,188,2618,702,168]

theorem envBound30455 : H12AffineFastState.Bounded env30455 := by
  intro p hp
  have h : env30455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30454_30455 : H12AffineEnvironment.transform 15 2063 env30454 = env30455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2063 env30454 == env30455) = true)

theorem identity30455 : scanCanonicalize (H12AffineFastState.compose env30455 (packedSelected [2,10,11,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound30455 : packedSelected [2,10,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30456 : List Nat := [2,4,8,16,32,0,128,189,512,514,132,22,25,687,185,139,703,11,170,184,23,649,16,549,568,680,572,687,687,693,20,16,188,702,702,168]

theorem envBound30456 : H12AffineFastState.Bounded env30456 := by
  intro p hp
  have h : env30456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30455_30456 : H12AffineEnvironment.transform 10 132 env30455 = env30456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env30455 == env30456) = true)

theorem identity30456 : scanCanonicalize (H12AffineFastState.compose env30456 (packedSelected [0,2,4,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30456 : packedSelected [0,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30457 : List Nat := [2,4,8,16,12,0,128,145,512,514,132,22,25,643,149,139,659,11,134,148,23,649,16,521,532,644,528,643,643,665,20,16,144,658,658,132]

theorem envBound30457 : H12AffineFastState.Bounded env30457 := by
  intro p hp
  have h : env30457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30456_30457 : H12AffineEnvironment.transform 4 12 env30456 = env30457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30456 == env30457) = true)

theorem identity30457 : scanCanonicalize (H12AffineFastState.compose env30457 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30457 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env30458 : List Nat := [2,4,8,7,12,0,128,134,512,514,132,1,14,643,130,139,644,11,134,131,0,649,7,521,515,644,519,643,643,654,3,7,135,645,645,132]

theorem envBound30458 : H12AffineFastState.Bounded env30458 := by
  intro p hp
  have h : env30458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30457_30458 : H12AffineEnvironment.transform 3 7 env30457 = env30458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30457 == env30458) = true)

theorem identity30458 : scanCanonicalize (H12AffineFastState.compose env30458 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound30458 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30459 : List Nat := [2,4,8,7,12,0,128,134,10,8,132,1,14,137,130,139,142,11,134,131,0,131,7,3,9,142,13,137,137,132,3,7,135,143,143,132]

theorem envBound30459 : H12AffineFastState.Bounded env30459 := by
  intro p hp
  have h : env30459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30458_30459 : H12AffineEnvironment.transform 8 10 env30458 = env30459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env30458 == env30459) = true)

theorem identity30459 : scanCanonicalize (H12AffineFastState.compose env30459 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30459 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30460 : List Nat := [2,3,8,0,11,0,128,129,10,8,131,1,9,137,130,139,137,11,129,131,0,131,0,3,9,137,10,137,137,131,3,0,128,136,136,131]

theorem envBound30460 : H12AffineFastState.Bounded env30460 := by
  intro p hp
  have h : env30460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30459_30460 : H12AffineEnvironment.transform 1 3 env30459 = env30460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30459 == env30460) = true)

theorem identity30460 : scanCanonicalize (H12AffineFastState.compose env30460 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30461 : List Nat := [2,3,8,0,11,0,8,9,10,8,11,1,9,1,10,3,1,11,9,11,0,11,0,3,9,1,10,1,1,11,3,0,8,0,0,11]

theorem envBound30461 : H12AffineFastState.Bounded env30461 := by
  intro p hp
  have h : env30461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30460_30461 : H12AffineEnvironment.transform 6 8 env30460 = env30461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30460 == env30461) = true)

theorem identity30461 : scanCanonicalize (H12AffineFastState.compose env30461 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30461 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30462 : List Nat := [2,3,1,0,2,0,1,0,3,1,2,1,0,1,3,3,1,2,0,2,0,2,0,3,0,1,3,1,1,2,3,0,1,0,0,2]

theorem envBound30462 : H12AffineFastState.Bounded env30462 := by
  intro p hp
  have h : env30462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30461_30462 : H12AffineEnvironment.transform 2 1 env30461 = env30462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30461 == env30462) = true)

def env30463 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66615,65664,1812,260,1557,649,65830,66832,900,66083,1087,66598,1296,68358,20,16,257,66615,1280,276]

theorem envBound30463 : H12AffineFastState.Bounded env30463 := by
  intro p hp
  have h : env30463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30442_30463 : H12AffineEnvironment.transform 5 1 env30442 = env30463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30442 == env30463) = true)

theorem identity30463 : scanCanonicalize (H12AffineFastState.compose env30463 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound30463 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30464 : List Nat := [2,4,8,16,32,1,128,256,175,1024,2048,1211,25,1296,261,65536,66615,65664,1467,260,1210,38,65830,66832,299,65676,1087,66598,1296,68009,20,16,257,66615,1280,276]

theorem envBound30464 : H12AffineFastState.Bounded env30464 := by
  intro p hp
  have h : env30464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30463_30464 : H12AffineEnvironment.transform 8 175 env30463 = env30464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env30463 == env30464) = true)

def env30465 : List Nat := [2,4,8,16,32,1,128,256,175,172,2048,23,25,444,261,65536,65691,65664,279,260,22,38,65830,65980,299,65676,147,65674,444,68009,20,16,257,65691,428,276]

theorem envBound30465 : H12AffineFastState.Bounded env30465 := by
  intro p hp
  have h : env30465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30464_30465 : H12AffineEnvironment.transform 9 172 env30464 = env30465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env30464 == env30465) = true)

theorem identity30465 : scanCanonicalize (H12AffineFastState.compose env30465 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 2317) := by decide +kernel

theorem selectedBound30465 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30466 : List Nat := [2,4,8,16,32,1,128,256,175,172,2048,23,25,444,261,2317,2454,2445,279,260,22,38,2091,2225,299,2433,147,2439,444,164,20,16,257,2454,428,276]

theorem envBound30466 : H12AffineFastState.Bounded env30466 := by
  intro p hp
  have h : env30466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30465_30466 : H12AffineEnvironment.transform 15 2317 env30465 = env30466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2317 env30465 == env30466) = true)

theorem identity30466 : scanCanonicalize (H12AffineFastState.compose env30466 (packedSelected [0,1,7,10,12,13,15,17,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound30466 : packedSelected [0,1,7,10,12,13,15,17,20,21] rootPS < 2^1333 := by decide +kernel

def env30467 : List Nat := [2,4,8,16,32,1,128,256,175,172,391,23,25,444,261,138,17,10,279,260,22,38,428,310,299,6,147,0,444,164,20,16,257,17,428,276]

theorem envBound30467 : H12AffineFastState.Bounded env30467 := by
  intro p hp
  have h : env30467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30466_30467 : H12AffineEnvironment.transform 10 391 env30466 = env30467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env30466 == env30467) = true)

theorem identity30467 : scanCanonicalize (H12AffineFastState.compose env30467 (packedSelected [0,1,2,4,7,8,9,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30467 : packedSelected [0,1,2,4,7,8,9,12,17] rootPS < 2^1333 := by decide +kernel

def env30468 : List Nat := [2,4,8,16,6,1,128,256,137,138,391,23,25,410,261,138,17,10,279,260,22,0,394,272,269,6,147,0,410,130,20,16,257,17,394,276]

theorem envBound30468 : H12AffineFastState.Bounded env30468 := by
  intro p hp
  have h : env30468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30467_30468 : H12AffineEnvironment.transform 4 6 env30467 = env30468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30467 == env30468) = true)

theorem identity30468 : scanCanonicalize (H12AffineFastState.compose env30468 (packedSelected [1,4,5,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound30468 : packedSelected [1,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env30469 : List Nat := [2,4,8,16,6,1,128,156,137,138,27,23,25,6,153,138,17,10,139,152,22,0,22,140,145,6,147,0,6,130,20,16,157,17,22,136]

theorem envBound30469 : H12AffineFastState.Bounded env30469 := by
  intro p hp
  have h : env30469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30468_30469 : H12AffineEnvironment.transform 7 156 env30468 = env30469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env30468 == env30469) = true)

theorem identity30469 : scanCanonicalize (H12AffineFastState.compose env30469 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound30469 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env30470 : List Nat := [2,4,8,16,6,1,3,31,10,9,27,23,25,6,26,9,17,10,8,27,22,0,22,15,18,6,16,0,6,1,20,16,30,17,22,11]

theorem envBound30470 : H12AffineFastState.Bounded env30470 := by
  intro p hp
  have h : env30470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30469_30470 : H12AffineEnvironment.transform 6 3 env30469 = env30470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env30469 == env30470) = true)

theorem identity30470 : scanCanonicalize (H12AffineFastState.compose env30470 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30470 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30471 : List Nat := [2,4,8,10,6,1,3,5,10,9,1,13,3,6,0,9,11,10,8,1,12,0,12,15,8,6,10,0,6,1,14,10,4,11,12,11]

theorem envBound30471 : H12AffineFastState.Bounded env30471 := by
  intro p hp
  have h : env30471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30470_30471 : H12AffineEnvironment.transform 3 10 env30470 = env30471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30470 == env30471) = true)

theorem identity30471 : scanCanonicalize (H12AffineFastState.compose env30471 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30472 : List Nat := [2,4,1,3,6,1,3,5,3,0,1,4,3,6,0,0,2,3,1,1,5,0,5,6,1,6,3,0,6,1,7,3,4,2,5,2]

theorem envBound30472 : H12AffineFastState.Bounded env30472 := by
  intro p hp
  have h : env30472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30471_30472 : H12AffineEnvironment.transform 2 1 env30471 = env30472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30471 == env30472) = true)

theorem identity30472 : scanCanonicalize (H12AffineFastState.compose env30472 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30472 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30473 : List Nat := [1,4,1,0,5,1,0,5,0,0,1,4,0,5,0,0,1,0,1,1,5,0,5,5,1,5,0,0,5,1,4,0,4,1,5,1]

theorem envBound30473 : H12AffineFastState.Bounded env30473 := by
  intro p hp
  have h : env30473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30472_30473 : H12AffineEnvironment.transform 0 1 env30472 = env30473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30472 == env30473) = true)

theorem identity30473 : scanCanonicalize (H12AffineFastState.compose env30473 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30474 : List Nat := [1,0,1,0,1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,1,1,1,0,0,1,1,0,0,0,1,1,1]

theorem envBound30474 : H12AffineFastState.Bounded env30474 := by
  intro p hp
  have h : env30474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30473_30474 : H12AffineEnvironment.transform 1 0 env30473 = env30474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30473 == env30474) = true)

def env30475 : List Nat := [2,4,8,16,32,1,128,256,175,173,2048,22,25,445,261,65536,65690,65664,278,260,23,38,65830,65981,299,65676,146,65675,445,68009,20,16,257,65690,429,276]

theorem envBound30475 : H12AffineFastState.Bounded env30475 := by
  intro p hp
  have h : env30475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30464_30475 : H12AffineEnvironment.transform 9 173 env30464 = env30475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env30464 == env30475) = true)

theorem identity30475 : scanCanonicalize (H12AffineFastState.compose env30475 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 2314) := by decide +kernel

theorem selectedBound30475 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30476 : List Nat := [2,4,8,16,32,1,128,256,175,173,2048,22,25,445,261,2314,2448,2442,278,260,23,38,2092,2231,299,2438,146,2433,445,163,20,16,257,2448,429,276]

theorem envBound30476 : H12AffineFastState.Bounded env30476 := by
  intro p hp
  have h : env30476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30475_30476 : H12AffineEnvironment.transform 15 2314 env30475 = env30476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2314 env30475 == env30476) = true)

theorem identity30476 : scanCanonicalize (H12AffineFastState.compose env30476 (packedSelected [0,1,7,10,12,13,15,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound30476 : packedSelected [0,1,7,10,12,13,15,17,20,21] rootPS < 2^1333 := by decide +kernel

def env30477 : List Nat := [2,4,8,16,32,1,128,171,175,173,2048,22,25,22,174,2209,2107,2081,189,175,23,38,2092,2231,128,2093,146,2090,22,163,20,16,170,2107,6,191]

theorem envBound30477 : H12AffineFastState.Bounded env30477 := by
  intro p hp
  have h : env30477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30476_30477 : H12AffineEnvironment.transform 7 171 env30476 = env30477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env30476 == env30477) = true)

theorem identity30477 : scanCanonicalize (H12AffineFastState.compose env30477 (packedSelected [1,3,4,8,9,10,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound30477 : packedSelected [1,3,4,8,9,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env30478 : List Nat := [2,4,8,16,29,1,128,150,146,144,2048,22,25,22,147,2204,2054,2076,128,146,23,27,2065,2186,128,2064,146,2071,22,158,20,16,151,2054,6,130]

theorem envBound30478 : H12AffineFastState.Bounded env30478 := by
  intro p hp
  have h : env30478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30477_30478 : H12AffineEnvironment.transform 4 29 env30477 = env30478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env30477 == env30478) = true)

theorem identity30478 : scanCanonicalize (H12AffineFastState.compose env30478 (packedSelected [0,2,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound30478 : packedSelected [0,2,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env30479 : List Nat := [2,4,8,16,29,1,128,150,146,144,16,22,25,22,147,140,22,12,128,146,23,27,1,154,128,0,146,7,22,158,20,16,151,22,6,130]

theorem envBound30479 : H12AffineFastState.Bounded env30479 := by
  intro p hp
  have h : env30479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30478_30479 : H12AffineEnvironment.transform 10 16 env30478 = env30479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env30478 == env30479) = true)

theorem identity30479 : scanCanonicalize (H12AffineFastState.compose env30479 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound30479 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env30480 : List Nat := [2,4,8,16,29,1,14,24,28,30,16,22,25,22,29,2,22,12,14,28,23,27,1,20,14,0,28,7,22,16,20,16,25,22,6,12]

theorem envBound30480 : H12AffineFastState.Bounded env30480 := by
  intro p hp
  have h : env30480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30479_30480 : H12AffineEnvironment.transform 6 14 env30479 = env30480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env30479 == env30480) = true)

theorem identity30480 : scanCanonicalize (H12AffineFastState.compose env30480 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30480 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30481 : List Nat := [2,4,2,16,23,1,4,18,22,20,16,22,19,22,23,2,22,6,4,22,23,17,1,20,4,0,22,7,22,16,20,16,19,22,6,6]

theorem envBound30481 : H12AffineFastState.Bounded env30481 := by
  intro p hp
  have h : env30481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30480_30481 : H12AffineEnvironment.transform 2 2 env30480 = env30481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30480 == env30481) = true)

theorem identity30481 : scanCanonicalize (H12AffineFastState.compose env30481 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30481 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30482 : List Nat := [2,2,2,16,17,1,2,18,16,18,16,16,19,16,17,2,16,0,2,16,17,17,1,18,2,0,16,1,16,16,18,16,19,16,0,0]

theorem envBound30482 : H12AffineFastState.Bounded env30482 := by
  intro p hp
  have h : env30482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30481_30482 : H12AffineEnvironment.transform 1 2 env30481 = env30482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30481 == env30482) = true)

def env30483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66678,65664,1876,325,1556,648,65830,66897,964,66082,1150,66598,1296,68422,20,16,257,66615,1345,340]

theorem envBound30483 : H12AffineFastState.Bounded env30483 := by
  intro p hp
  have h : env30483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30441_30483 : H12AffineEnvironment.transform 11 1557 env30441 = env30483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env30441 == env30483) = true)

def env30484 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66614,65664,1812,261,1556,648,65830,66833,900,66082,1086,66598,1296,68358,20,16,257,66615,1281,276]

theorem envBound30484 : H12AffineFastState.Bounded env30484 := by
  intro p hp
  have h : env30484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30483_30484 : H12AffineEnvironment.transform 5 0 env30483 = env30484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30483 == env30484) = true)

theorem identity30484 : scanCanonicalize (H12AffineFastState.compose env30484 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1672) := by decide +kernel

theorem selectedBound30484 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30485 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,1672,702,1544,1812,261,1556,648,1966,921,900,1194,1086,686,1296,3470,20,16,257,703,1281,276]

theorem envBound30485 : H12AffineFastState.Bounded env30485 := by
  intro p hp
  have h : env30485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30484_30485 : H12AffineEnvironment.transform 15 1672 env30484 = env30485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1672 env30484 == env30485) = true)

def env30486 : List Nat := [2,4,8,16,32,0,128,256,512,1024,132,1557,25,1296,260,1672,702,1544,1812,261,1556,648,1966,921,900,1194,1086,686,1296,1290,20,16,257,703,1281,276]

theorem envBound30486 : H12AffineFastState.Bounded env30486 := by
  intro p hp
  have h : env30486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30485_30486 : H12AffineEnvironment.transform 10 132 env30485 = env30486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env30485 == env30486) = true)

theorem identity30486 : scanCanonicalize (H12AffineFastState.compose env30486 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30486 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env30487 : List Nat := [2,4,8,16,32,0,128,256,512,20,132,513,25,260,260,668,702,540,768,261,512,648,954,921,900,190,42,686,260,286,20,16,257,703,277,276]

theorem envBound30487 : H12AffineFastState.Bounded env30487 := by
  intro p hp
  have h : env30487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30486_30487 : H12AffineEnvironment.transform 9 20 env30486 = env30487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30486 == env30487) = true)

theorem identity30487 : scanCanonicalize (H12AffineFastState.compose env30487 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound30487 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30488 : List Nat := [2,4,8,16,32,0,128,256,261,20,132,260,25,260,260,409,443,281,5,261,261,397,191,156,129,190,42,427,260,286,20,16,257,442,277,276]

theorem envBound30488 : H12AffineFastState.Bounded env30488 := by
  intro p hp
  have h : env30488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30487_30488 : H12AffineEnvironment.transform 8 261 env30487 = env30488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env30487 == env30488) = true)

theorem identity30488 : scanCanonicalize (H12AffineFastState.compose env30488 (packedSelected [0,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound30488 : packedSelected [0,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env30489 : List Nat := [2,4,8,16,32,0,128,150,147,20,132,146,25,146,146,15,45,143,5,147,147,27,191,156,129,190,42,61,146,136,20,16,151,44,131,130]

theorem envBound30489 : H12AffineFastState.Bounded env30489 := by
  intro p hp
  have h : env30489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30488_30489 : H12AffineEnvironment.transform 7 150 env30488 = env30489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env30488 == env30489) = true)

theorem identity30489 : scanCanonicalize (H12AffineFastState.compose env30489 (packedSelected [1,2,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30489 : packedSelected [1,2,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30490 : List Nat := [2,4,8,16,16,0,128,150,147,20,132,146,25,146,146,15,29,143,5,147,147,27,143,156,129,142,26,13,146,136,20,16,151,28,131,130]

theorem envBound30490 : H12AffineFastState.Bounded env30490 := by
  intro p hp
  have h : env30490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30489_30490 : H12AffineEnvironment.transform 4 16 env30489 = env30490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30489 == env30490) = true)

theorem identity30490 : scanCanonicalize (H12AffineFastState.compose env30490 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound30490 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30491 : List Nat := [2,4,8,16,16,0,3,21,16,20,7,17,25,17,17,15,29,12,5,16,16,27,12,31,2,13,26,13,17,11,20,16,20,28,0,1]

theorem envBound30491 : H12AffineFastState.Bounded env30491 := by
  intro p hp
  have h : env30491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30490_30491 : H12AffineEnvironment.transform 6 3 env30490 = env30491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env30490 == env30491) = true)

theorem identity30491 : scanCanonicalize (H12AffineFastState.compose env30491 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30491 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30492 : List Nat := [2,4,8,11,11,0,3,14,11,15,7,10,2,10,10,15,6,12,5,11,11,0,12,4,2,13,1,13,10,11,15,11,15,7,0,1]

theorem envBound30492 : H12AffineFastState.Bounded env30492 := by
  intro p hp
  have h : env30492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30491_30492 : H12AffineEnvironment.transform 3 11 env30491 = env30492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30491 == env30492) = true)

theorem identity30492 : scanCanonicalize (H12AffineFastState.compose env30492 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30492 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30493 : List Nat := [2,3,8,11,11,0,3,9,11,8,0,10,2,10,10,8,1,11,2,11,11,0,11,3,2,10,1,10,10,11,8,11,8,0,0,1]

theorem envBound30493 : H12AffineFastState.Bounded env30493 := by
  intro p hp
  have h : env30493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30492_30493 : H12AffineEnvironment.transform 1 3 env30492 = env30493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30492 == env30493) = true)

theorem identity30493 : scanCanonicalize (H12AffineFastState.compose env30493 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30494 : List Nat := [2,3,3,0,0,0,3,2,0,3,0,1,2,1,1,3,1,0,2,0,0,0,0,3,2,1,1,1,1,0,3,0,3,0,0,1]

theorem envBound30494 : H12AffineFastState.Bounded env30494 := by
  intro p hp
  have h : env30494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30493_30494 : H12AffineEnvironment.transform 2 3 env30493 = env30494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30493 == env30494) = true)

theorem identity30494 : scanCanonicalize (H12AffineFastState.compose env30494 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30495 : List Nat := [1,0,0,0,0,0,0,1,0,0,0,1,1,1,1,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1]

theorem envBound30495 : H12AffineFastState.Bounded env30495 := by
  intro p hp
  have h : env30495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30494_30495 : H12AffineEnvironment.transform 0 1 env30494 = env30495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30494 == env30495) = true)

def env30496 : List Nat := [2,4,8,16,32,0,128,256,512,1024,133,1557,25,1296,260,1672,702,1544,1812,261,1556,648,1966,921,900,1194,1086,686,1296,1291,20,16,257,703,1281,276]

theorem envBound30496 : H12AffineFastState.Bounded env30496 := by
  intro p hp
  have h : env30496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30485_30496 : H12AffineEnvironment.transform 10 133 env30485 = env30496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env30485 == env30496) = true)

theorem identity30496 : scanCanonicalize (H12AffineFastState.compose env30496 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound30496 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env30497 : List Nat := [2,4,8,16,32,0,128,256,512,19,133,518,25,259,260,667,702,539,775,261,519,648,957,921,900,185,45,686,259,280,20,16,257,703,274,276]

theorem envBound30497 : H12AffineFastState.Bounded env30497 := by
  intro p hp
  have h : env30497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30496_30497 : H12AffineEnvironment.transform 9 19 env30496 = env30497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env30496 == env30497) = true)

theorem identity30497 : scanCanonicalize (H12AffineFastState.compose env30497 (packedSelected [1,2,5,7,8,11,16,18,24,27] rootPS)) = affineNative (2^(8+1) ^^^ 307) := by decide +kernel

theorem selectedBound30497 : packedSelected [1,2,5,7,8,11,16,18,24,27] rootPS < 2^1333 := by decide +kernel

def env30498 : List Nat := [2,4,8,16,32,0,128,256,307,19,133,309,25,259,260,424,397,296,52,261,308,443,142,170,183,185,45,413,259,280,20,16,257,396,274,276]

theorem envBound30498 : H12AffineFastState.Bounded env30498 := by
  intro p hp
  have h : env30498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30497_30498 : H12AffineEnvironment.transform 8 307 env30497 = env30498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 307 env30497 == env30498) = true)

theorem identity30498 : scanCanonicalize (H12AffineFastState.compose env30498 (packedSelected [1,3,4,5,7,8,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30498 : packedSelected [1,3,4,5,7,8,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30499 : List Nat := [2,4,8,16,12,0,128,256,287,19,133,281,25,259,260,388,397,260,24,261,280,407,142,134,155,149,1,413,259,280,20,16,257,396,274,276]

theorem envBound30499 : H12AffineFastState.Bounded env30499 := by
  intro p hp
  have h : env30499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30498_30499 : H12AffineEnvironment.transform 4 12 env30498 = env30499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30498 == env30499) = true)

theorem identity30499 : scanCanonicalize (H12AffineFastState.compose env30499 (packedSelected [0,2,3,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound30499 : packedSelected [0,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env30500 : List Nat := [2,4,8,16,12,0,128,134,153,19,133,159,25,133,130,2,11,130,24,131,158,17,142,134,155,149,1,27,133,158,20,16,135,10,148,146]

theorem envBound30500 : H12AffineFastState.Bounded env30500 := by
  intro p hp
  have h : env30500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30499_30500 : H12AffineEnvironment.transform 7 134 env30499 = env30500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env30499 == env30500) = true)

theorem identity30500 : scanCanonicalize (H12AffineFastState.compose env30500 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound30500 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30501 : List Nat := [2,4,8,16,12,0,30,24,7,19,27,1,25,27,28,2,11,28,24,29,0,17,16,24,5,11,1,27,27,0,20,16,25,10,10,12]

theorem envBound30501 : H12AffineFastState.Bounded env30501 := by
  intro p hp
  have h : env30501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30500_30501 : H12AffineEnvironment.transform 6 30 env30500 = env30501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env30500 == env30501) = true)

theorem identity30501 : scanCanonicalize (H12AffineFastState.compose env30501 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30501 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30502 : List Nat := [2,4,8,1,12,0,15,9,7,2,10,1,8,10,13,2,11,13,9,12,0,0,1,9,5,11,1,10,10,0,5,1,8,10,10,12]

theorem envBound30502 : H12AffineFastState.Bounded env30502 := by
  intro p hp
  have h : env30502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30501_30502 : H12AffineEnvironment.transform 3 1 env30501 = env30502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30501 == env30502) = true)

theorem identity30502 : scanCanonicalize (H12AffineFastState.compose env30502 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30503 : List Nat := [2,4,3,1,7,0,4,2,7,2,1,1,3,1,6,2,0,6,2,7,0,0,1,2,5,0,1,1,1,0,5,1,3,1,1,7]

theorem envBound30503 : H12AffineFastState.Bounded env30503 := by
  intro p hp
  have h : env30503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30502_30503 : H12AffineEnvironment.transform 2 3 env30502 = env30503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30502 == env30503) = true)

theorem identity30503 : scanCanonicalize (H12AffineFastState.compose env30503 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30504 : List Nat := [2,2,3,1,1,0,2,2,1,2,1,1,3,1,0,2,0,0,2,1,0,0,1,2,3,0,1,1,1,0,3,1,3,1,1,1]

theorem envBound30504 : H12AffineFastState.Bounded env30504 := by
  intro p hp
  have h : env30504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30503_30504 : H12AffineEnvironment.transform 1 2 env30503 = env30504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30503 == env30504) = true)

def env30505 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66615,65664,1813,260,1556,648,65830,66832,901,66082,1087,66598,1296,68359,20,16,257,66615,1280,277]

theorem envBound30505 : H12AffineFastState.Bounded env30505 := by
  intro p hp
  have h : env30505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30483_30505 : H12AffineEnvironment.transform 5 1 env30483 = env30505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30483 == env30505) = true)

theorem identity30505 : scanCanonicalize (H12AffineFastState.compose env30505 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 920) := by decide +kernel

theorem selectedBound30505 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30506 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,920,1967,792,1813,260,1556,648,702,1672,901,442,1087,1982,1296,2207,20,16,257,1967,1280,277]

theorem envBound30506 : H12AffineFastState.Bounded env30506 := by
  intro p hp
  have h : env30506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30505_30506 : H12AffineEnvironment.transform 15 920 env30505 = env30506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 920 env30505 == env30506) = true)

def env30507 : List Nat := [2,4,8,16,32,1,128,256,512,1024,1680,1557,25,1296,261,920,1967,792,1813,260,1556,648,702,1672,901,442,1087,1982,1296,1551,20,16,257,1967,1280,277]

theorem envBound30507 : H12AffineFastState.Bounded env30507 := by
  intro p hp
  have h : env30507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30506_30507 : H12AffineEnvironment.transform 10 1680 env30506 = env30507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1680 env30506 == env30507) = true)

theorem identity30507 : scanCanonicalize (H12AffineFastState.compose env30507 (packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound30507 : packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env30508 : List Nat := [2,4,8,16,32,1,128,256,512,409,777,908,25,137,261,920,566,792,652,260,909,648,702,785,901,442,422,551,137,918,20,16,257,566,153,277]

theorem envBound30508 : H12AffineFastState.Bounded env30508 := by
  intro p hp
  have h : env30508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30507_30508 : H12AffineEnvironment.transform 9 409 env30507 = env30508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env30507 == env30508) = true)

theorem identity30508 : scanCanonicalize (H12AffineFastState.compose env30508 (packedSelected [0,1,5,8,9,10,16,18,24] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound30508 : packedSelected [0,1,5,8,9,10,16,18,24] rootPS < 2^1333 := by decide +kernel

def env30509 : List Nat := [2,4,8,16,32,1,128,2,512,155,523,654,25,137,7,666,566,538,652,6,655,648,702,531,647,184,164,551,137,660,20,16,3,566,153,23]

theorem envBound30509 : H12AffineFastState.Bounded env30509 := by
  intro p hp
  have h : env30509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30508_30509 : H12AffineEnvironment.transform 7 2 env30508 = env30509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env30508 == env30509) = true)

theorem identity30509 : scanCanonicalize (H12AffineFastState.compose env30509 (packedSelected [1,2,8,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound30509 : packedSelected [1,2,8,11,16] rootPS < 2^1333 := by decide +kernel

def env30510 : List Nat := [2,4,8,16,32,1,57,2,512,34,523,567,25,48,7,547,566,538,565,6,566,561,519,531,574,1,29,551,48,557,20,16,3,566,32,23]

theorem envBound30510 : H12AffineFastState.Bounded env30510 := by
  intro p hp
  have h : env30510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30509_30510 : H12AffineEnvironment.transform 6 57 env30509 = env30510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env30509 == env30510) = true)

theorem identity30510 : scanCanonicalize (H12AffineFastState.compose env30510 (packedSelected [0,4,5,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound30510 : packedSelected [0,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env30511 : List Nat := [2,4,8,16,32,1,57,2,12,34,7,59,25,48,7,47,58,22,57,6,58,61,11,31,50,1,29,43,48,33,20,16,3,58,32,23]

theorem envBound30511 : H12AffineFastState.Bounded env30511 := by
  intro p hp
  have h : env30511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30510_30511 : H12AffineEnvironment.transform 8 12 env30510 = env30511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env30510 == env30511) = true)

theorem identity30511 : scanCanonicalize (H12AffineFastState.compose env30511 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound30511 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30512 : List Nat := [2,4,8,16,22,1,15,2,12,20,7,13,25,6,7,25,12,22,15,6,12,11,11,31,4,1,29,29,6,23,20,16,3,12,22,23]

theorem envBound30512 : H12AffineFastState.Bounded env30512 := by
  intro p hp
  have h : env30512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30511_30512 : H12AffineEnvironment.transform 4 22 env30511 = env30512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env30511 == env30512) = true)

theorem identity30512 : scanCanonicalize (H12AffineFastState.compose env30512 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound30512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30513 : List Nat := [2,4,8,13,11,1,15,2,12,9,7,13,4,6,7,4,12,11,15,6,12,11,11,2,4,1,0,0,6,10,9,13,3,12,11,10]

theorem envBound30513 : H12AffineFastState.Bounded env30513 := by
  intro p hp
  have h : env30513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30512_30513 : H12AffineEnvironment.transform 3 13 env30512 = env30513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env30512 == env30513) = true)

def env30514 : List Nat := [2,4,8,16,32,1,128,256,512,1024,1681,1557,25,1296,261,920,1967,792,1813,260,1556,648,702,1672,901,442,1087,1982,1296,1550,20,16,257,1967,1280,277]

theorem envBound30514 : H12AffineFastState.Bounded env30514 := by
  intro p hp
  have h : env30514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30506_30514 : H12AffineEnvironment.transform 10 1681 env30506 = env30514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1681 env30506 == env30514) = true)

theorem identity30514 : scanCanonicalize (H12AffineFastState.compose env30514 (packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS)) = affineNative (2^(9+1) ^^^ 415) := by decide +kernel

theorem selectedBound30514 : packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env30515 : List Nat := [2,4,8,16,32,1,128,256,512,415,782,906,25,143,261,920,560,792,650,260,907,648,702,791,901,442,416,545,143,913,20,16,257,560,159,277]

theorem envBound30515 : H12AffineFastState.Bounded env30515 := by
  intro p hp
  have h : env30515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30514_30515 : H12AffineEnvironment.transform 9 415 env30514 = env30515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 415 env30514 == env30515) = true)

theorem identity30515 : scanCanonicalize (H12AffineFastState.compose env30515 (packedSelected [1,2,8,11,13,16,19,20,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound30515 : packedSelected [1,2,8,11,13,16,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env30516 : List Nat := [2,4,8,16,32,1,128,256,38,415,296,428,25,143,261,446,22,318,172,260,429,174,152,305,419,442,416,7,143,439,20,16,257,22,159,277]

theorem envBound30516 : H12AffineFastState.Bounded env30516 := by
  intro p hp
  have h : env30516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30515_30516 : H12AffineEnvironment.transform 8 38 env30515 = env30516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env30515 == env30516) = true)

theorem identity30516 : scanCanonicalize (H12AffineFastState.compose env30516 (packedSelected [2,3,5,7,9,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30516 : packedSelected [2,3,5,7,9,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env30517 : List Nat := [2,4,8,16,32,1,4,256,38,283,296,296,25,11,261,314,22,318,40,260,297,42,28,305,295,318,292,7,11,307,20,16,257,22,27,277]

theorem envBound30517 : H12AffineFastState.Bounded env30517 := by
  intro p hp
  have h : env30517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30516_30517 : H12AffineEnvironment.transform 6 4 env30516 = env30517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30516 == env30517) = true)

theorem identity30517 : scanCanonicalize (H12AffineFastState.compose env30517 (packedSelected [1,2,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound30517 : packedSelected [1,2,10,11] rootPS < 2^1333 := by decide +kernel

def env30518 : List Nat := [2,4,8,16,32,1,4,19,38,8,59,59,25,11,22,41,22,45,40,23,58,42,28,34,52,45,55,7,11,32,20,16,18,22,27,6]

theorem envBound30518 : H12AffineFastState.Bounded env30518 := by
  intro p hp
  have h : env30518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30517_30518 : H12AffineEnvironment.transform 7 19 env30517 = env30518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env30517 == env30518) = true)

theorem identity30518 : scanCanonicalize (H12AffineFastState.compose env30518 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30518 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30519 : List Nat := [2,4,3,16,32,1,4,19,38,3,48,48,18,0,22,34,22,38,35,23,49,33,23,34,52,38,55,7,0,32,20,16,18,22,16,6]

theorem envBound30519 : H12AffineFastState.Bounded env30519 := by
  intro p hp
  have h : env30519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30518_30519 : H12AffineEnvironment.transform 2 3 env30518 = env30519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30518 == env30519) = true)

theorem identity30519 : scanCanonicalize (H12AffineFastState.compose env30519 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30520 : List Nat := [2,4,3,16,0,1,4,19,6,3,16,16,18,0,22,2,22,6,3,23,17,1,23,2,20,6,23,7,0,0,20,16,18,22,16,6]

theorem envBound30520 : H12AffineFastState.Bounded env30520 := by
  intro p hp
  have h : env30520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30519_30520 : H12AffineEnvironment.transform 4 0 env30519 = env30520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30519 == env30520) = true)

theorem identity30520 : scanCanonicalize (H12AffineFastState.compose env30520 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30521 : List Nat := [2,4,3,7,0,1,4,4,6,3,7,7,5,0,1,2,1,6,3,0,6,1,0,2,3,6,0,7,0,0,3,7,5,1,7,6]

theorem envBound30521 : H12AffineFastState.Bounded env30521 := by
  intro p hp
  have h : env30521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30520_30521 : H12AffineEnvironment.transform 3 7 env30520 = env30521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30520 == env30521) = true)

def env30522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4097,5277,74047,66897,13768,78894,1151,74815,1296,81226,8205,8201,257,74798,1345,5953]

theorem envBound30522 : H12AffineFastState.Bounded env30522 := by
  intro p hp
  have h : env30522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30439_30522 : H12AffineEnvironment.transform 17 65665 env30439 = env30522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30439 == env30522) = true)

theorem identity30522 : scanCanonicalize (H12AffineFastState.compose env30522 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound30522 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,65536,69942,65665,4417,5125,4097,5277,70758,66897,145,65911,1151,69990,1296,67603,5460,5456,257,70007,1345,5953]

theorem envBound30523 : H12AffineFastState.Bounded env30523 := by
  intro p hp
  have h : env30523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30522_30523 : H12AffineEnvironment.transform 12 5465 env30522 = env30523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env30522 == env30523) = true)

def env30524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1296,528,65536,67362,65665,1877,529,1557,649,66162,66897,145,65911,1151,67442,1296,67603,832,836,257,67427,1345,341]

theorem envBound30524 : H12AffineFastState.Bounded env30524 := by
  intro p hp
  have h : env30524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30523_30524 : H12AffineEnvironment.transform 11 1556 env30523 = env30524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env30523 == env30524) = true)

def env30525 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,65536,66162,65665,517,529,837,649,66162,65537,145,65911,303,66082,64,67603,832,836,257,66099,17,341]

theorem envBound30525 : H12AffineFastState.Bounded env30525 := by
  intro p hp
  have h : env30525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30524_30525 : H12AffineEnvironment.transform 9 336 env30524 = env30525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env30524 == env30525) = true)

theorem identity30525 : scanCanonicalize (H12AffineFastState.compose env30525 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 250) := by decide +kernel

theorem selectedBound30525 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30526 : List Nat := [2,4,8,16,32,64,128,250,512,170,2048,702,695,64,528,65536,66162,65665,517,529,703,649,66162,65537,145,65677,213,66082,64,67603,698,702,251,66099,17,175]

theorem envBound30526 : H12AffineFastState.Bounded env30526 := by
  intro p hp
  have h : env30526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30525_30526 : H12AffineEnvironment.transform 7 250 env30525 = env30526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 250 env30525 == env30526) = true)

def env30527 : List Nat := [2,4,8,16,32,64,128,250,228,170,2048,90,83,64,244,65536,65686,65665,225,245,91,109,65686,65537,145,65677,213,65734,64,67603,94,90,251,65751,17,175]

theorem envBound30527 : H12AffineFastState.Bounded env30527 := by
  intro p hp
  have h : env30527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30526_30527 : H12AffineEnvironment.transform 8 228 env30526 = env30527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 228 env30526 == env30527) = true)

theorem identity30527 : scanCanonicalize (H12AffineFastState.compose env30527 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound30527 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30528 : List Nat := [2,4,8,16,32,64,128,250,228,170,162,90,83,64,244,65536,65686,65665,225,245,91,109,65686,65537,145,65677,213,65734,64,65713,94,90,251,65751,17,175]

theorem envBound30528 : H12AffineFastState.Bounded env30528 := by
  intro p hp
  have h : env30528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30527_30528 : H12AffineEnvironment.transform 10 162 env30527 = env30528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env30527 == env30528) = true)

theorem identity30528 : scanCanonicalize (H12AffineFastState.compose env30528 (packedSelected [0,2,10,11,15,18,19,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30528 : packedSelected [0,2,10,11,15,18,19,27] rootPS < 2^1333 := by decide +kernel

def env30529 : List Nat := [2,4,8,16,32,17,128,171,181,170,162,11,2,17,165,65536,65686,65665,176,164,10,60,65686,65537,145,65677,132,65687,17,65713,15,11,170,65670,17,175]

theorem envBound30529 : H12AffineFastState.Bounded env30529 := by
  intro p hp
  have h : env30529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30528_30529 : H12AffineEnvironment.transform 5 17 env30528 = env30529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30528 == env30529) = true)

theorem identity30529 : scanCanonicalize (H12AffineFastState.compose env30529 (packedSelected [2,3,4,7,11,12,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound30529 : packedSelected [2,3,4,7,11,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env30530 : List Nat := [2,4,8,16,32,17,128,171,181,170,162,11,2,17,165,50,164,179,176,164,10,60,164,51,145,191,132,165,17,131,15,11,170,180,17,175]

theorem envBound30530 : H12AffineFastState.Bounded env30530 := by
  intro p hp
  have h : env30530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30529_30530 : H12AffineEnvironment.transform 15 50 env30529 = env30530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env30529 == env30530) = true)

theorem identity30530 : scanCanonicalize (H12AffineFastState.compose env30530 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound30530 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env30531 : List Nat := [2,4,8,13,32,12,128,171,168,170,162,11,2,12,165,47,164,174,173,164,10,33,164,46,140,162,132,165,12,131,15,11,170,169,12,175]

theorem envBound30531 : H12AffineFastState.Bounded env30531 := by
  intro p hp
  have h : env30531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30530_30531 : H12AffineEnvironment.transform 3 13 env30530 = env30531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env30530 == env30531) = true)

theorem identity30531 : scanCanonicalize (H12AffineFastState.compose env30531 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound30531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30532 : List Nat := [2,4,8,13,32,12,2,41,42,40,32,11,2,12,39,47,38,44,47,38,10,33,38,46,14,32,6,39,12,1,15,11,40,43,12,45]

theorem envBound30532 : H12AffineFastState.Bounded env30532 := by
  intro p hp
  have h : env30532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30531_30532 : H12AffineEnvironment.transform 6 2 env30531 = env30532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env30531 == env30532) = true)

theorem identity30532 : scanCanonicalize (H12AffineFastState.compose env30532 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30532 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env30533 : List Nat := [2,4,8,13,6,12,2,15,12,14,6,11,2,12,1,9,0,10,9,0,10,7,0,8,14,6,6,1,12,1,15,11,14,13,12,11]

theorem envBound30533 : H12AffineFastState.Bounded env30533 := by
  intro p hp
  have h : env30533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30532_30533 : H12AffineEnvironment.transform 4 6 env30532 = env30533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30532 == env30533) = true)

theorem identity30533 : scanCanonicalize (H12AffineFastState.compose env30533 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30533 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30534 : List Nat := [2,2,8,11,0,10,2,9,10,8,0,11,2,10,1,9,0,10,9,0,10,1,0,8,8,0,0,1,10,1,9,11,8,11,10,11]

theorem envBound30534 : H12AffineFastState.Bounded env30534 := by
  intro p hp
  have h : env30534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30533_30534 : H12AffineEnvironment.transform 1 2 env30533 = env30534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30533 == env30534) = true)

theorem identity30534 : scanCanonicalize (H12AffineFastState.compose env30534 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30535 : List Nat := [2,2,1,2,0,3,2,0,3,1,0,2,2,3,1,0,0,3,0,0,3,1,0,1,1,0,0,1,3,1,0,2,1,2,3,2]

theorem envBound30535 : H12AffineFastState.Bounded env30535 := by
  intro p hp
  have h : env30535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30534_30535 : H12AffineEnvironment.transform 2 1 env30534 = env30535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30534 == env30535) = true)

theorem identity30535 : scanCanonicalize (H12AffineFastState.compose env30535 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30536 : List Nat := [0,0,1,0,0,1,0,0,1,1,0,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,1,1,0,0,1,0,1,0]

theorem envBound30536 : H12AffineFastState.Bounded env30536 := by
  intro p hp
  have h : env30536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30535_30536 : H12AffineEnvironment.transform 0 0 env30535 = env30536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30535 == env30536) = true)

def env30537 : List Nat := [2,4,8,16,32,64,128,250,229,170,2048,91,82,64,245,65536,65687,65665,224,244,90,108,65687,65537,145,65677,213,65735,64,67603,95,91,251,65750,17,175]

theorem envBound30537 : H12AffineFastState.Bounded env30537 := by
  intro p hp
  have h : env30537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30526_30537 : H12AffineEnvironment.transform 8 229 env30526 = env30537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 229 env30526 == env30537) = true)

theorem identity30537 : scanCanonicalize (H12AffineFastState.compose env30537 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound30537 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30538 : List Nat := [2,4,8,16,32,64,128,250,229,170,168,91,82,64,245,65536,65687,65665,224,244,90,108,65687,65537,145,65677,213,65735,64,65723,95,91,251,65750,17,175]

theorem envBound30538 : H12AffineFastState.Bounded env30538 := by
  intro p hp
  have h : env30538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30537_30538 : H12AffineEnvironment.transform 10 168 env30537 = env30538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env30537 == env30538) = true)

theorem identity30538 : scanCanonicalize (H12AffineFastState.compose env30538 (packedSelected [1,4,5,9,15,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound30538 : packedSelected [1,4,5,9,15,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env30539 : List Nat := [2,4,8,16,32,64,128,250,229,170,168,91,82,64,245,114,229,243,224,244,90,108,229,115,145,255,213,181,64,201,95,91,251,164,17,175]

theorem envBound30539 : H12AffineFastState.Bounded env30539 := by
  intro p hp
  have h : env30539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30538_30539 : H12AffineEnvironment.transform 15 114 env30538 = env30539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env30538 == env30539) = true)

theorem identity30539 : scanCanonicalize (H12AffineFastState.compose env30539 (packedSelected [0,3,5,7,8,11,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound30539 : packedSelected [0,3,5,7,8,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env30540 : List Nat := [2,4,8,16,32,10,128,176,175,170,168,17,24,10,191,56,175,185,170,190,16,38,175,57,145,181,159,181,10,131,21,17,177,164,17,175]

theorem envBound30540 : H12AffineFastState.Bounded env30540 := by
  intro p hp
  have h : env30540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30539_30540 : H12AffineEnvironment.transform 5 10 env30539 = env30540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env30539 == env30540) = true)

theorem identity30540 : scanCanonicalize (H12AffineFastState.compose env30540 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30540 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30541 : List Nat := [2,4,5,16,32,7,128,176,162,167,165,17,21,7,178,53,162,180,167,179,16,38,162,52,145,181,146,181,7,131,21,17,177,164,17,162]

theorem envBound30541 : H12AffineFastState.Bounded env30541 := by
  intro p hp
  have h : env30541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30540_30541 : H12AffineEnvironment.transform 2 5 env30540 = env30541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30540 == env30541) = true)

theorem identity30541 : scanCanonicalize (H12AffineFastState.compose env30541 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound30541 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env30542 : List Nat := [2,4,5,16,32,7,51,3,17,20,22,17,21,7,1,53,17,7,20,0,16,38,17,52,34,6,33,6,7,48,21,17,2,23,17,17]

theorem envBound30542 : H12AffineFastState.Bounded env30542 := by
  intro p hp
  have h : env30542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30541_30542 : H12AffineEnvironment.transform 6 51 env30541 = env30542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env30541 == env30542) = true)

theorem identity30542 : scanCanonicalize (H12AffineFastState.compose env30542 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30542 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30543 : List Nat := [2,3,2,16,32,0,51,3,17,19,17,17,18,0,1,50,17,0,19,0,16,33,17,51,34,1,33,1,0,48,18,17,2,16,17,17]

theorem envBound30543 : H12AffineFastState.Bounded env30543 := by
  intro p hp
  have h : env30543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30542_30543 : H12AffineEnvironment.transform 1 3 env30542 = env30543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30542 == env30543) = true)

theorem identity30543 : scanCanonicalize (H12AffineFastState.compose env30543 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30543 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30544 : List Nat := [2,3,2,16,16,0,3,3,17,19,17,17,18,0,1,2,17,0,19,0,16,17,17,3,18,1,17,1,0,0,18,17,2,16,17,17]

theorem envBound30544 : H12AffineFastState.Bounded env30544 := by
  intro p hp
  have h : env30544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30543_30544 : H12AffineEnvironment.transform 4 16 env30543 = env30544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30543 == env30544) = true)

def env30545 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,65536,66163,65665,516,529,836,649,66162,65536,145,65911,302,66083,65,67603,832,836,257,66098,16,341]

theorem envBound30545 : H12AffineFastState.Bounded env30545 := by
  intro p hp
  have h : env30545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30524_30545 : H12AffineEnvironment.transform 9 337 env30524 = env30545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env30524 == env30545) = true)

theorem identity30545 : scanCanonicalize (H12AffineFastState.compose env30545 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 239) := by decide +kernel

theorem selectedBound30545 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30546 : List Nat := [2,4,8,16,32,64,128,256,239,337,2048,426,418,65,255,65536,65692,65665,235,254,427,102,65693,65536,145,65911,302,65740,65,67603,431,427,257,65757,16,341]

theorem envBound30546 : H12AffineFastState.Bounded env30546 := by
  intro p hp
  have h : env30546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30545_30546 : H12AffineEnvironment.transform 8 239 env30545 = env30546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 239 env30545 == env30546) = true)

def env30547 : List Nat := [2,4,8,16,32,64,128,240,239,161,2048,90,82,65,255,65536,65692,65665,235,254,91,102,65693,65536,145,65671,222,65740,65,67603,95,91,241,65757,16,165]

theorem envBound30547 : H12AffineFastState.Bounded env30547 := by
  intro p hp
  have h : env30547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30546_30547 : H12AffineEnvironment.transform 7 240 env30546 = env30547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 240 env30546 == env30547) = true)

theorem identity30547 : scanCanonicalize (H12AffineFastState.compose env30547 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2085) := by decide +kernel

theorem selectedBound30547 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30548 : List Nat := [2,4,8,16,32,64,128,240,239,161,2048,90,82,65,255,2085,2233,2212,235,254,91,102,2232,2085,145,2210,222,2281,65,54,95,91,241,2296,16,165]

theorem envBound30548 : H12AffineFastState.Bounded env30548 := by
  intro p hp
  have h : env30548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30547_30548 : H12AffineEnvironment.transform 15 2085 env30547 = env30548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2085 env30547 == env30548) = true)

theorem identity30548 : scanCanonicalize (H12AffineFastState.compose env30548 (packedSelected [1,7,15,17,18,20,21,27] rootPS)) = affineNative (2^(10+1) ^^^ 178) := by decide +kernel

theorem selectedBound30548 : packedSelected [1,7,15,17,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env30549 : List Nat := [2,4,8,16,32,64,128,240,239,161,178,90,82,65,255,151,11,22,235,254,91,102,10,151,145,16,222,91,65,54,95,91,241,74,16,165]

theorem envBound30549 : H12AffineFastState.Bounded env30549 := by
  intro p hp
  have h : env30549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30548_30549 : H12AffineEnvironment.transform 10 178 env30548 = env30549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 178 env30548 == env30549) = true)

theorem identity30549 : scanCanonicalize (H12AffineFastState.compose env30549 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound30549 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30550 : List Nat := [2,4,8,16,32,64,63,79,80,30,13,90,82,65,64,40,11,22,84,65,91,102,10,40,46,16,97,91,65,54,95,91,78,74,16,26]

theorem envBound30550 : H12AffineFastState.Bounded env30550 := by
  intro p hp
  have h : env30550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30549_30550 : H12AffineEnvironment.transform 6 63 env30549 = env30550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env30549 == env30550) = true)

theorem identity30550 : scanCanonicalize (H12AffineFastState.compose env30550 (packedSelected [0,1,2,3,4,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound30550 : packedSelected [0,1,2,3,4,8,10,11] rootPS < 2^1333 := by decide +kernel

def env30551 : List Nat := [2,4,8,16,32,13,63,2,29,30,13,23,31,12,13,40,11,22,25,12,22,43,10,40,46,16,44,22,12,54,18,22,3,7,16,26]

theorem envBound30551 : H12AffineFastState.Bounded env30551 := by
  intro p hp
  have h : env30551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30550_30551 : H12AffineEnvironment.transform 5 13 env30550 = env30551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env30550 == env30551) = true)

theorem identity30551 : scanCanonicalize (H12AffineFastState.compose env30551 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30551 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30552 : List Nat := [2,4,8,16,12,13,19,2,29,30,13,23,31,12,13,4,11,22,25,12,22,7,10,4,2,16,0,22,12,26,18,22,3,7,16,26]

theorem envBound30552 : H12AffineFastState.Bounded env30552 := by
  intro p hp
  have h : env30552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30551_30552 : H12AffineEnvironment.transform 4 12 env30551 = env30552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30551 == env30552) = true)

theorem identity30552 : scanCanonicalize (H12AffineFastState.compose env30552 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30552 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30553 : List Nat := [2,2,8,16,10,11,19,2,27,24,11,17,25,10,11,2,11,16,25,10,16,1,10,2,2,16,0,16,10,26,18,16,3,1,16,26]

theorem envBound30553 : H12AffineFastState.Bounded env30553 := by
  intro p hp
  have h : env30553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30552_30553 : H12AffineEnvironment.transform 1 2 env30552 = env30553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30552 == env30553) = true)

theorem identity30553 : scanCanonicalize (H12AffineFastState.compose env30553 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30554 : List Nat := [1,1,8,16,9,8,16,1,24,24,8,17,25,9,8,1,8,16,25,9,16,1,9,1,1,16,0,16,9,25,17,16,0,1,16,25]

theorem envBound30554 : H12AffineFastState.Bounded env30554 := by
  intro p hp
  have h : env30554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30553_30554 : H12AffineEnvironment.transform 0 1 env30553 = env30554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30553 == env30554) = true)

theorem identity30554 : scanCanonicalize (H12AffineFastState.compose env30554 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30555 : List Nat := [1,1,8,0,9,8,0,1,8,8,8,1,9,9,8,1,8,0,9,9,0,1,9,1,1,0,0,0,9,9,1,0,0,1,0,9]

theorem envBound30555 : H12AffineFastState.Bounded env30555 := by
  intro p hp
  have h : env30555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30554_30555 : H12AffineEnvironment.transform 3 0 env30554 = env30555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30554 == env30555) = true)

theorem identity30555 : scanCanonicalize (H12AffineFastState.compose env30555 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound30555 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30556 : List Nat := [1,1,0,0,1,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1,0,1,1,1,1,0,0,0,1,1,1,0,0,1,0,1]

theorem envBound30556 : H12AffineFastState.Bounded env30556 := by
  intro p hp
  have h : env30556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30555_30556 : H12AffineEnvironment.transform 2 0 env30555 = env30556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env30555 == env30556) = true)

def env30557 : List Nat := [2,4,8,16,32,64,128,241,239,160,2048,91,83,65,255,65536,65692,65665,235,254,90,102,65693,65536,145,65670,223,65740,65,67603,94,90,240,65757,16,164]

theorem envBound30557 : H12AffineFastState.Bounded env30557 := by
  intro p hp
  have h : env30557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30546_30557 : H12AffineEnvironment.transform 7 241 env30546 = env30557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 241 env30546 == env30557) = true)

theorem identity30557 : scanCanonicalize (H12AffineFastState.compose env30557 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2094) := by decide +kernel

theorem selectedBound30557 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env30558 : List Nat := [2,4,8,16,32,64,128,241,239,160,2048,91,83,65,255,2094,2226,2223,235,254,90,102,2227,2094,145,2216,223,2274,65,61,94,90,240,2291,16,164]

theorem envBound30558 : H12AffineFastState.Bounded env30558 := by
  intro p hp
  have h : env30558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30557_30558 : H12AffineEnvironment.transform 15 2094 env30557 = env30558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2094 env30557 == env30558) = true)

theorem identity30558 : scanCanonicalize (H12AffineFastState.compose env30558 (packedSelected [0,2,5,9,10,19,21,32] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound30558 : packedSelected [0,2,5,9,10,19,21,32] rootPS < 2^1333 := by decide +kernel

def env30559 : List Nat := [2,4,8,16,29,64,128,204,210,157,2048,91,83,65,194,2067,2191,2194,214,195,90,91,2190,2067,145,2197,223,2271,65,0,94,90,205,2254,16,153]

theorem envBound30559 : H12AffineFastState.Bounded env30559 := by
  intro p hp
  have h : env30559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30558_30559 : H12AffineEnvironment.transform 4 29 env30558 = env30559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env30558 == env30559) = true)

theorem identity30559 : scanCanonicalize (H12AffineFastState.compose env30559 (packedSelected [0,4,5,8,10,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound30559 : packedSelected [0,4,5,8,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env30560 : List Nat := [2,4,8,16,29,64,128,204,210,157,12,91,83,65,194,31,131,158,214,195,90,91,130,31,145,153,223,211,65,0,94,90,205,194,16,153]

theorem envBound30560 : H12AffineFastState.Bounded env30560 := by
  intro p hp
  have h : env30560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30559_30560 : H12AffineEnvironment.transform 10 12 env30559 = env30560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env30559 == env30560) = true)

theorem identity30560 : scanCanonicalize (H12AffineFastState.compose env30560 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30560 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env30561 : List Nat := [2,4,8,16,29,0,128,140,146,157,12,27,19,1,130,31,131,158,150,131,26,27,130,31,145,153,159,147,1,0,30,26,141,130,16,153]

theorem envBound30561 : H12AffineFastState.Bounded env30561 := by
  intro p hp
  have h : env30561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30560_30561 : H12AffineEnvironment.transform 5 0 env30560 = env30561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30560 == env30561) = true)

theorem identity30561 : scanCanonicalize (H12AffineFastState.compose env30561 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound30561 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30562 : List Nat := [2,4,8,16,29,0,20,24,6,9,12,27,19,1,22,31,23,10,2,23,26,27,22,31,5,13,11,7,1,0,30,26,25,22,16,13]

theorem envBound30562 : H12AffineFastState.Bounded env30562 := by
  intro p hp
  have h : env30562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30561_30562 : H12AffineEnvironment.transform 6 20 env30561 = env30562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env30561 == env30562) = true)

theorem identity30562 : scanCanonicalize (H12AffineFastState.compose env30562 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30562 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30563 : List Nat := [2,4,4,16,17,0,20,20,6,5,0,23,19,1,22,19,23,6,2,23,22,23,22,19,5,1,7,7,1,0,18,22,21,22,16,1]

theorem envBound30563 : H12AffineFastState.Bounded env30563 := by
  intro p hp
  have h : env30563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30562_30563 : H12AffineEnvironment.transform 2 4 env30562 = env30563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30562 == env30563) = true)

theorem identity30563 : scanCanonicalize (H12AffineFastState.compose env30563 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30563 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30564 : List Nat := [2,4,4,1,0,0,5,5,6,5,0,6,2,1,7,2,6,6,2,6,7,6,7,2,5,1,7,7,1,0,3,7,4,7,1,1]

theorem envBound30564 : H12AffineFastState.Bounded env30564 := by
  intro p hp
  have h : env30564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30563_30564 : H12AffineEnvironment.transform 3 1 env30563 = env30564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30563 == env30564) = true)

theorem identity30564 : scanCanonicalize (H12AffineFastState.compose env30564 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30564 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30565 : List Nat := [2,2,2,1,0,0,3,3,0,3,0,0,2,1,1,2,0,0,2,0,1,0,1,2,3,1,1,1,1,0,3,1,2,1,1,1]

theorem envBound30565 : H12AffineFastState.Bounded env30565 := by
  intro p hp
  have h : env30565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30564_30565 : H12AffineEnvironment.transform 1 2 env30564 = env30565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30564 == env30565) = true)

theorem identity30565 : scanCanonicalize (H12AffineFastState.compose env30565 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30566 : List Nat := [0,0,0,1,0,0,1,1,0,1,0,0,0,1,1,0,0,0,0,0,1,0,1,0,1,1,1,1,1,0,1,1,0,1,1,1]

theorem envBound30566 : H12AffineFastState.Bounded env30566 := by
  intro p hp
  have h : env30566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30565_30566 : H12AffineEnvironment.transform 0 0 env30565 = env30566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30565 == env30566) = true)

def env30567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1296,529,65536,67363,65665,1876,528,1556,648,66163,66897,145,65911,1151,67443,1296,67603,833,837,257,67426,1345,340]

theorem envBound30567 : H12AffineFastState.Bounded env30567 := by
  intro p hp
  have h : env30567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30523_30567 : H12AffineEnvironment.transform 11 1557 env30523 = env30567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env30523 == env30567) = true)

def env30568 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,65536,66163,65665,516,528,836,648,66163,65537,145,65911,303,66083,64,67603,833,837,257,66098,17,340]

theorem envBound30568 : H12AffineFastState.Bounded env30568 := by
  intro p hp
  have h : env30568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30567_30568 : H12AffineEnvironment.transform 9 336 env30567 = env30568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env30567 == env30568) = true)

theorem identity30568 : scanCanonicalize (H12AffineFastState.compose env30568 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 921) := by decide +kernel

theorem selectedBound30568 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30569 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,921,490,792,516,528,836,648,490,920,145,750,303,442,64,2954,833,837,257,427,17,340]

theorem envBound30569 : H12AffineFastState.Bounded env30569 := by
  intro p hp
  have h : env30569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30568_30569 : H12AffineEnvironment.transform 15 921 env30568 = env30569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 921 env30568 == env30569) = true)

def env30570 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,81,88,64,261,141,490,12,272,260,80,412,490,140,145,506,303,442,64,2206,85,81,257,427,17,340]

theorem envBound30570 : H12AffineFastState.Bounded env30570 := by
  intro p hp
  have h : env30570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30570 : H12AffineEnvironment.transform 8 276 env30569 = env30570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env30569 == env30570) = true)

theorem identity30570 : scanCanonicalize (H12AffineFastState.compose env30570 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30570 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30571 : List Nat := [2,4,8,16,32,64,128,4,16,84,2048,81,88,64,1,141,238,12,20,0,80,152,238,140,145,254,43,190,64,2206,85,81,5,175,17,80]

theorem envBound30571 : H12AffineFastState.Bounded env30571 := by
  intro p hp
  have h : env30571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30570_30571 : H12AffineEnvironment.transform 7 4 env30570 = env30571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30570 == env30571) = true)

theorem identity30571 : scanCanonicalize (H12AffineFastState.compose env30571 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30571 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30572 : List Nat := [2,4,8,1,32,64,128,4,1,69,2048,64,73,64,1,141,238,12,5,0,65,137,238,140,128,239,43,175,64,2191,68,64,5,175,0,65]

theorem envBound30572 : H12AffineFastState.Bounded env30572 := by
  intro p hp
  have h : env30572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30571_30572 : H12AffineEnvironment.transform 3 1 env30571 = env30572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30571 == env30572) = true)

theorem identity30572 : scanCanonicalize (H12AffineFastState.compose env30572 (packedSelected [2,3,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 233) := by decide +kernel

theorem selectedBound30572 : packedSelected [2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env30573 : List Nat := [2,4,8,1,32,64,128,4,1,69,233,64,73,64,1,141,238,12,5,0,65,137,238,140,128,239,43,175,64,102,68,64,5,175,0,65]

theorem envBound30573 : H12AffineFastState.Bounded env30573 := by
  intro p hp
  have h : env30573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30572_30573 : H12AffineEnvironment.transform 10 233 env30572 = env30573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 233 env30572 == env30573) = true)

theorem identity30573 : scanCanonicalize (H12AffineFastState.compose env30573 (packedSelected [0,2,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound30573 : packedSelected [0,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env30574 : List Nat := [2,4,8,1,13,64,128,4,1,69,196,64,73,64,1,141,195,12,5,0,65,137,195,140,128,194,6,130,64,75,68,64,5,130,0,65]

theorem envBound30574 : H12AffineFastState.Bounded env30574 := by
  intro p hp
  have h : env30574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30573_30574 : H12AffineEnvironment.transform 4 13 env30573 = env30574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env30573 == env30574) = true)

theorem identity30574 : scanCanonicalize (H12AffineFastState.compose env30574 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30574 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env30575 : List Nat := [2,4,8,1,13,64,15,4,1,69,75,64,73,64,1,2,76,12,5,0,65,6,76,3,15,77,6,13,64,75,68,64,5,13,0,65]

theorem envBound30575 : H12AffineFastState.Bounded env30575 := by
  intro p hp
  have h : env30575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30574_30575 : H12AffineEnvironment.transform 6 15 env30574 = env30575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30574 == env30575) = true)

theorem identity30575 : scanCanonicalize (H12AffineFastState.compose env30575 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound30575 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30576 : List Nat := [2,4,8,1,13,12,15,4,1,9,7,12,5,12,1,2,0,12,5,0,13,6,0,3,15,1,6,13,12,7,8,12,5,13,0,13]

theorem envBound30576 : H12AffineFastState.Bounded env30576 := by
  intro p hp
  have h : env30576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30575_30576 : H12AffineEnvironment.transform 5 12 env30575 = env30576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env30575 == env30576) = true)

theorem identity30576 : scanCanonicalize (H12AffineFastState.compose env30576 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30576 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30577 : List Nat := [2,4,3,1,6,7,4,4,1,2,7,7,5,7,1,2,0,7,5,0,6,6,0,3,4,1,6,6,7,7,3,7,5,6,0,6]

theorem envBound30577 : H12AffineFastState.Bounded env30577 := by
  intro p hp
  have h : env30577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30576_30577 : H12AffineEnvironment.transform 2 3 env30576 = env30577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30576 == env30577) = true)

theorem identity30577 : scanCanonicalize (H12AffineFastState.compose env30577 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30578 : List Nat := [2,2,3,1,0,1,2,2,1,2,1,1,3,1,1,2,0,1,3,0,0,0,0,3,2,1,0,0,1,1,3,1,3,0,0,0]

theorem envBound30578 : H12AffineFastState.Bounded env30578 := by
  intro p hp
  have h : env30578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30577_30578 : H12AffineEnvironment.transform 1 2 env30577 = env30578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30577 == env30578) = true)

theorem identity30578 : scanCanonicalize (H12AffineFastState.compose env30578 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30579 : List Nat := [1,1,0,1,0,1,1,1,1,1,1,1,0,1,1,1,0,1,0,0,0,0,0,0,1,1,0,0,1,1,0,1,0,0,0,0]

theorem envBound30579 : H12AffineFastState.Bounded env30579 := by
  intro p hp
  have h : env30579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30578_30579 : H12AffineEnvironment.transform 0 1 env30578 = env30579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30578 == env30579) = true)

def env30580 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,80,89,64,260,140,490,13,273,261,81,413,490,141,145,507,303,442,64,2207,84,80,257,427,17,340]

theorem envBound30580 : H12AffineFastState.Bounded env30580 := by
  intro p hp
  have h : env30580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30580 : H12AffineEnvironment.transform 8 277 env30569 = env30580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env30569 == env30580) = true)

theorem identity30580 : scanCanonicalize (H12AffineFastState.compose env30580 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound30580 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30581 : List Nat := [2,4,8,16,32,64,128,69,80,21,2048,80,89,64,65,140,175,13,84,64,81,216,175,141,145,190,106,255,64,2207,84,80,68,238,17,17]

theorem envBound30581 : H12AffineFastState.Bounded env30581 := by
  intro p hp
  have h : env30581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30580_30581 : H12AffineEnvironment.transform 7 69 env30580 = env30581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env30580 == env30581) = true)

theorem identity30581 : scanCanonicalize (H12AffineFastState.compose env30581 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 126) := by decide +kernel

theorem selectedBound30581 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env30582 : List Nat := [2,4,8,16,32,64,126,69,80,21,2048,80,89,64,65,114,81,13,84,64,81,38,81,115,111,64,106,1,64,2145,84,80,68,16,17,17]

theorem envBound30582 : H12AffineFastState.Bounded env30582 := by
  intro p hp
  have h : env30582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30581_30582 : H12AffineEnvironment.transform 6 126 env30581 = env30582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 126 env30581 == env30582) = true)

theorem identity30582 : scanCanonicalize (H12AffineFastState.compose env30582 (packedSelected [2,3,5,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 92) := by decide +kernel

theorem selectedBound30582 : packedSelected [2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env30583 : List Nat := [2,4,8,16,32,64,126,69,80,21,92,80,89,64,65,114,81,13,84,64,81,38,81,115,111,64,106,1,64,61,84,80,68,16,17,17]

theorem envBound30583 : H12AffineFastState.Bounded env30583 := by
  intro p hp
  have h : env30583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30582_30583 : H12AffineEnvironment.transform 10 92 env30582 = env30583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 92 env30582 == env30583) = true)

theorem identity30583 : scanCanonicalize (H12AffineFastState.compose env30583 (packedSelected [0,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30583 : packedSelected [0,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30584 : List Nat := [2,4,8,16,11,64,85,69,80,21,92,80,89,64,65,89,81,13,84,64,81,13,81,88,68,64,65,1,64,22,84,80,68,16,17,17]

theorem envBound30584 : H12AffineFastState.Bounded env30584 := by
  intro p hp
  have h : env30584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30583_30584 : H12AffineEnvironment.transform 4 11 env30583 = env30584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30583 == env30584) = true)

theorem identity30584 : scanCanonicalize (H12AffineFastState.compose env30584 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30584 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env30585 : List Nat := [2,4,2,16,1,64,85,69,80,21,86,80,83,64,65,83,81,7,84,64,81,7,81,82,68,64,65,1,64,22,84,80,68,16,17,17]

theorem envBound30585 : H12AffineFastState.Bounded env30585 := by
  intro p hp
  have h : env30585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30584_30585 : H12AffineEnvironment.transform 2 2 env30584 = env30585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30584 == env30585) = true)

theorem identity30585 : scanCanonicalize (H12AffineFastState.compose env30585 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30586 : List Nat := [2,4,2,16,1,0,21,5,16,21,22,16,19,0,1,19,17,7,20,0,17,7,17,18,4,0,1,1,0,22,20,16,4,16,17,17]

theorem envBound30586 : H12AffineFastState.Bounded env30586 := by
  intro p hp
  have h : env30586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30585_30586 : H12AffineEnvironment.transform 5 0 env30585 = env30586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30585 == env30586) = true)

theorem identity30586 : scanCanonicalize (H12AffineFastState.compose env30586 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound30586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30587 : List Nat := [2,4,2,5,1,0,0,5,5,0,3,5,6,0,1,6,4,7,1,0,4,7,4,7,4,0,1,1,0,3,1,5,4,5,4,4]

theorem envBound30587 : H12AffineFastState.Bounded env30587 := by
  intro p hp
  have h : env30587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30586_30587 : H12AffineEnvironment.transform 3 5 env30586 = env30587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env30586 == env30587) = true)

theorem identity30587 : scanCanonicalize (H12AffineFastState.compose env30587 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30588 : List Nat := [2,3,2,2,1,0,0,2,2,0,3,2,1,0,1,1,3,0,1,0,3,0,3,0,3,0,1,1,0,3,1,2,3,2,3,3]

theorem envBound30588 : H12AffineFastState.Bounded env30588 := by
  intro p hp
  have h : env30588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30587_30588 : H12AffineEnvironment.transform 1 3 env30587 = env30588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30587 == env30588) = true)

theorem identity30588 : scanCanonicalize (H12AffineFastState.compose env30588 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30588 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30589 : List Nat := [0,1,0,0,1,0,0,0,0,0,1,0,1,0,1,1,1,0,1,0,1,0,1,0,1,0,1,1,0,1,1,0,1,0,1,1]

theorem envBound30589 : H12AffineFastState.Bounded env30589 := by
  intro p hp
  have h : env30589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30588_30589 : H12AffineEnvironment.transform 0 0 env30588 = env30589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30588 == env30589) = true)

def env30590 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,65536,66162,65665,517,528,837,648,66163,65536,145,65911,302,66082,65,67603,833,837,257,66099,16,340]

theorem envBound30590 : H12AffineFastState.Bounded env30590 := by
  intro p hp
  have h : env30590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30567_30590 : H12AffineEnvironment.transform 9 337 env30567 = env30590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env30567 == env30590) = true)

theorem identity30590 : scanCanonicalize (H12AffineFastState.compose env30590 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound30590 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30591 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,141,767,12,517,528,837,648,766,141,145,506,302,687,65,2206,833,837,257,702,16,340]

theorem envBound30591 : H12AffineFastState.Bounded env30591 := by
  intro p hp
  have h : env30591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30590_30591 : H12AffineEnvironment.transform 15 141 env30590 = env30591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env30590 == env30591) = true)

def env30592 : List Nat := [2,4,8,16,32,64,128,256,512,337,896,836,844,65,529,141,767,12,517,528,837,648,766,141,145,506,302,687,65,798,833,837,257,702,16,340]

theorem envBound30592 : H12AffineFastState.Bounded env30592 := by
  intro p hp
  have h : env30592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30591_30592 : H12AffineEnvironment.transform 10 896 env30591 = env30592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 896 env30591 == env30592) = true)

theorem identity30592 : scanCanonicalize (H12AffineFastState.compose env30592 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound30592 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30593 : List Nat := [2,4,8,16,32,64,128,256,86,337,470,274,282,65,71,141,169,12,83,70,275,222,168,141,145,506,302,249,65,328,279,275,257,232,16,340]

theorem envBound30593 : H12AffineFastState.Bounded env30593 := by
  intro p hp
  have h : env30593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30592_30593 : H12AffineEnvironment.transform 8 86 env30592 = env30593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env30592 == env30593) = true)

theorem identity30593 : scanCanonicalize (H12AffineFastState.compose env30593 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 251) := by decide +kernel

theorem selectedBound30593 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env30594 : List Nat := [2,4,8,16,32,64,128,251,86,170,45,233,225,65,71,141,169,12,83,70,232,222,168,141,145,1,213,249,65,179,236,232,250,232,16,175]

theorem envBound30594 : H12AffineFastState.Bounded env30594 := by
  intro p hp
  have h : env30594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30593_30594 : H12AffineEnvironment.transform 7 251 env30593 = env30594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 251 env30593 == env30594) = true)

theorem identity30594 : scanCanonicalize (H12AffineFastState.compose env30594 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound30594 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30595 : List Nat := [2,4,8,16,32,64,114,9,86,88,45,27,19,65,71,127,91,12,83,70,26,44,90,127,99,1,39,11,65,65,30,26,8,26,16,93]

theorem envBound30595 : H12AffineFastState.Bounded env30595 := by
  intro p hp
  have h : env30595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30594_30595 : H12AffineEnvironment.transform 6 114 env30594 = env30595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env30594 == env30595) = true)

theorem identity30595 : scanCanonicalize (H12AffineFastState.compose env30595 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound30595 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30596 : List Nat := [2,4,8,16,32,38,20,9,48,62,45,27,19,39,33,25,61,12,53,32,26,44,60,25,5,1,39,11,39,39,30,26,8,26,16,59]

theorem envBound30596 : H12AffineFastState.Bounded env30596 := by
  intro p hp
  have h : env30596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30595_30596 : H12AffineEnvironment.transform 5 38 env30595 = env30596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env30595 == env30596) = true)

theorem identity30596 : scanCanonicalize (H12AffineFastState.compose env30596 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30596 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30597 : List Nat := [2,4,8,16,16,22,20,9,0,14,29,27,19,23,17,25,13,12,5,16,26,28,12,25,5,1,23,11,23,23,30,26,8,26,16,11]

theorem envBound30597 : H12AffineFastState.Bounded env30597 := by
  intro p hp
  have h : env30597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30596_30597 : H12AffineEnvironment.transform 4 16 env30596 = env30597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30596 == env30597) = true)

theorem identity30597 : scanCanonicalize (H12AffineFastState.compose env30597 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30597 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env30598 : List Nat := [2,4,8,12,12,10,8,9,0,14,1,7,15,11,13,5,13,12,5,12,6,0,12,5,5,1,11,11,11,11,2,6,8,6,12,11]

theorem envBound30598 : H12AffineFastState.Bounded env30598 := by
  intro p hp
  have h : env30598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30597_30598 : H12AffineEnvironment.transform 3 12 env30597 = env30598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30597 == env30598) = true)

theorem identity30598 : scanCanonicalize (H12AffineFastState.compose env30598 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30599 : List Nat := [2,4,2,6,6,0,2,3,0,4,1,7,5,1,7,5,7,6,5,6,6,0,6,5,5,1,1,1,1,1,2,6,2,6,6,1]

theorem envBound30599 : H12AffineFastState.Bounded env30599 := by
  intro p hp
  have h : env30599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30598_30599 : H12AffineEnvironment.transform 2 2 env30598 = env30599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30598 == env30599) = true)

theorem identity30599 : scanCanonicalize (H12AffineFastState.compose env30599 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30600 : List Nat := [1,4,1,5,5,0,1,0,0,4,1,4,5,1,4,5,4,5,5,5,5,0,5,5,5,1,1,1,1,1,1,5,1,5,5,1]

theorem envBound30600 : H12AffineFastState.Bounded env30600 := by
  intro p hp
  have h : env30600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30599_30600 : H12AffineEnvironment.transform 0 1 env30599 = env30600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30599 == env30600) = true)

theorem identity30600 : scanCanonicalize (H12AffineFastState.compose env30600 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30600 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30601 : List Nat := [1,0,1,1,1,0,1,0,0,0,1,0,1,1,0,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1]

theorem envBound30601 : H12AffineFastState.Bounded env30601 := by
  intro p hp
  have h : env30601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30600_30601 : H12AffineEnvironment.transform 1 0 env30600 = env30601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30600 == env30601) = true)

def env30602 : List Nat := [2,4,8,16,32,64,128,256,512,337,897,836,844,65,529,141,767,12,517,528,837,648,766,141,145,506,302,687,65,799,833,837,257,702,16,340]

theorem envBound30602 : H12AffineFastState.Bounded env30602 := by
  intro p hp
  have h : env30602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30591_30602 : H12AffineEnvironment.transform 10 897 env30591 = env30602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 897 env30591 == env30602) = true)

theorem identity30602 : scanCanonicalize (H12AffineFastState.compose env30602 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound30602 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30603 : List Nat := [2,4,8,16,32,64,128,256,81,337,464,277,285,65,64,141,174,12,84,65,276,217,175,141,145,506,302,254,65,334,272,276,257,239,16,340]

theorem envBound30603 : H12AffineFastState.Bounded env30603 := by
  intro p hp
  have h : env30603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30602_30603 : H12AffineEnvironment.transform 8 81 env30602 = env30603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env30602 == env30603) = true)

theorem identity30603 : scanCanonicalize (H12AffineFastState.compose env30603 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound30603 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS < 2^1333 := by decide +kernel

def env30604 : List Nat := [2,4,8,16,32,64,128,34,81,115,242,55,63,65,64,141,174,12,84,65,54,217,175,141,145,216,12,254,65,108,50,54,35,239,16,118]

theorem envBound30604 : H12AffineFastState.Bounded env30604 := by
  intro p hp
  have h : env30604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30603_30604 : H12AffineEnvironment.transform 7 34 env30603 = env30604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env30603 == env30604) = true)

theorem identity30604 : scanCanonicalize (H12AffineFastState.compose env30604 (packedSelected [0,2,4,5,7,8,9,10,11,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30604 : packedSelected [0,2,4,5,7,8,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env30605 : List Nat := [2,4,8,16,32,16,128,34,1,35,162,55,63,17,16,141,174,12,4,17,54,137,175,141,145,136,12,174,17,60,50,54,35,191,16,38]

theorem envBound30605 : H12AffineFastState.Bounded env30605 := by
  intro p hp
  have h : env30605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30604_30605 : H12AffineEnvironment.transform 5 16 env30604 = env30605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30604 == env30605) = true)

theorem identity30605 : scanCanonicalize (H12AffineFastState.compose env30605 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound30605 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30606 : List Nat := [2,4,8,16,32,16,3,34,1,35,33,55,63,17,16,14,45,12,4,17,54,10,44,14,18,11,12,45,17,60,50,54,35,60,16,38]

theorem envBound30606 : H12AffineFastState.Bounded env30606 := by
  intro p hp
  have h : env30606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30605_30606 : H12AffineEnvironment.transform 6 3 env30605 = env30606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env30605 == env30606) = true)

theorem identity30606 : scanCanonicalize (H12AffineFastState.compose env30606 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30606 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30607 : List Nat := [2,4,2,16,32,16,3,34,1,35,33,55,53,17,16,4,39,6,4,17,54,0,38,4,18,1,6,39,17,54,50,54,35,54,16,38]

theorem envBound30607 : H12AffineFastState.Bounded env30607 := by
  intro p hp
  have h : env30607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30606_30607 : H12AffineEnvironment.transform 2 2 env30606 = env30607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30606 == env30607) = true)

theorem identity30607 : scanCanonicalize (H12AffineFastState.compose env30607 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30607 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30608 : List Nat := [2,2,2,16,32,16,3,34,1,35,33,49,51,17,16,2,33,0,2,17,48,0,32,2,18,1,0,33,17,48,50,48,35,48,16,32]

theorem envBound30608 : H12AffineFastState.Bounded env30608 := by
  intro p hp
  have h : env30608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30607_30608 : H12AffineEnvironment.transform 1 2 env30607 = env30608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30607 == env30608) = true)

theorem identity30608 : scanCanonicalize (H12AffineFastState.compose env30608 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30608 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30609 : List Nat := [2,2,2,16,17,16,3,19,1,18,16,0,2,17,16,2,16,0,2,17,1,0,17,2,18,1,0,16,17,1,3,1,18,1,16,17]

theorem envBound30609 : H12AffineFastState.Bounded env30609 := by
  intro p hp
  have h : env30609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30608_30609 : H12AffineEnvironment.transform 4 17 env30608 = env30609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30608 == env30609) = true)

def env30610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4097,5277,74046,66897,13769,78894,328958,74814,1296,81227,8204,8200,257,74798,1345,5952]

theorem envBound30610 : H12AffineFastState.Bounded env30610 := by
  intro p hp
  have h : env30610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30438_30610 : H12AffineEnvironment.transform 13 1297 env30438 = env30610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env30438 == env30610) = true)

def env30611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4097,5277,74046,66897,13769,78894,1150,74814,1296,81227,8204,8200,257,74798,1345,5952]

theorem envBound30611 : H12AffineFastState.Bounded env30611 := by
  intro p hp
  have h : env30611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30611 : H12AffineEnvironment.transform 17 65664 env30610 = env30611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30610 == env30611) = true)

theorem identity30611 : scanCanonicalize (H12AffineFastState.compose env30611 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound30611 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74863,65664,272,8541,81,1229,74046,66897,9625,74878,1150,74814,1296,77083,8204,8200,257,74798,1345,1808]

theorem envBound30612 : H12AffineFastState.Bounded env30612 := by
  intro p hp
  have h : env30612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30611_30612 : H12AffineEnvironment.transform 11 80 env30611 = env30612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env30611 == env30612) = true)

def env30613 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74031,65664,272,8541,81,397,74046,65553,8409,74046,318,74110,80,75867,8204,8200,257,74094,1,592]

theorem envBound30613 : H12AffineFastState.Bounded env30613 := by
  intro p hp
  have h : env30613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30612_30613 : H12AffineEnvironment.transform 9 320 env30612 = env30613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30612 == env30613) = true)

theorem identity30613 : scanCanonicalize (H12AffineFastState.compose env30613 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30613 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env30614 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,80,8192,81,8264,65536,73787,65664,4,8265,81,153,73770,65553,8409,73770,42,73834,80,75867,8204,8200,21,73850,1,592]

theorem envBound30614 : H12AffineFastState.Bounded env30614 := by
  intro p hp
  have h : env30614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30613_30614 : H12AffineEnvironment.transform 7 20 env30613 = env30614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30613 == env30614) = true)

theorem identity30614 : scanCanonicalize (H12AffineFastState.compose env30614 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30614 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30615 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,1,8192,0,8217,65536,73787,65664,4,8216,0,153,73770,65553,8328,73770,42,73787,1,75786,8204,8200,21,73771,1,513]

theorem envBound30615 : H12AffineFastState.Bounded env30615 := by
  intro p hp
  have h : env30615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30614_30615 : H12AffineEnvironment.transform 5 17 env30614 = env30615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30614 == env30615) = true)

theorem identity30615 : scanCanonicalize (H12AffineFastState.compose env30615 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound30615 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30616 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,1,8192,0,8217,8251,0,8379,4,8216,0,153,17,8234,8328,17,42,0,1,2097,8204,8200,21,16,1,513]

theorem envBound30616 : H12AffineFastState.Bounded env30616 := by
  intro p hp
  have h : env30616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30615_30616 : H12AffineEnvironment.transform 15 8251 env30615 = env30616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env30615 == env30616) = true)

theorem identity30616 : scanCanonicalize (H12AffineFastState.compose env30616 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30617 : List Nat := [2,4,8,16,32,17,128,20,1,5,2048,1,8192,0,8217,8251,0,8379,4,8216,0,153,17,8234,8328,17,42,0,1,2097,8204,8200,21,16,1,0]

theorem envBound30617 : H12AffineFastState.Bounded env30617 := by
  intro p hp
  have h : env30617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30616_30617 : H12AffineEnvironment.transform 8 1 env30616 = env30617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30616 == env30617) = true)

theorem identity30617 : scanCanonicalize (H12AffineFastState.compose env30617 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound30617 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30618 : List Nat := [2,4,8,16,32,17,128,20,1,5,2048,1,25,0,0,34,0,162,4,1,0,153,17,51,145,17,42,0,1,2097,21,17,21,16,1,0]

theorem envBound30618 : H12AffineFastState.Bounded env30618 := by
  intro p hp
  have h : env30618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30617_30618 : H12AffineEnvironment.transform 12 25 env30617 = env30618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30617 == env30618) = true)

theorem identity30618 : scanCanonicalize (H12AffineFastState.compose env30618 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound30618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30619 : List Nat := [2,4,8,16,32,17,128,20,1,5,29,1,25,0,0,34,0,162,4,1,0,153,17,51,145,17,42,0,1,44,21,17,21,16,1,0]

theorem envBound30619 : H12AffineFastState.Bounded env30619 := by
  intro p hp
  have h : env30619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30618_30619 : H12AffineEnvironment.transform 10 29 env30618 = env30619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env30618 == env30619) = true)

theorem identity30619 : scanCanonicalize (H12AffineFastState.compose env30619 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound30619 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30620 : List Nat := [2,4,8,16,32,17,19,20,1,5,29,1,25,0,0,34,0,49,4,1,0,10,17,51,2,17,42,0,1,44,21,17,21,16,1,0]

theorem envBound30620 : H12AffineFastState.Bounded env30620 := by
  intro p hp
  have h : env30620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30619_30620 : H12AffineEnvironment.transform 6 19 env30619 = env30620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env30619 == env30620) = true)

theorem identity30620 : scanCanonicalize (H12AffineFastState.compose env30620 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound30620 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30621 : List Nat := [2,4,8,16,23,17,19,20,1,5,29,1,25,0,0,21,0,6,4,1,0,10,17,4,2,17,29,0,1,27,21,17,21,16,1,0]

theorem envBound30621 : H12AffineFastState.Bounded env30621 := by
  intro p hp
  have h : env30621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30620_30621 : H12AffineEnvironment.transform 4 23 env30620 = env30621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env30620 == env30621) = true)

theorem identity30621 : scanCanonicalize (H12AffineFastState.compose env30621 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound30621 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30622 : List Nat := [2,4,8,9,14,8,10,13,1,5,4,1,0,0,0,12,0,6,4,1,0,10,8,4,2,8,4,0,1,2,12,8,12,9,1,0]

theorem envBound30622 : H12AffineFastState.Bounded env30622 := by
  intro p hp
  have h : env30622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30621_30622 : H12AffineEnvironment.transform 3 9 env30621 = env30622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env30621 == env30622) = true)

theorem identity30622 : scanCanonicalize (H12AffineFastState.compose env30622 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30622 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30623 : List Nat := [2,4,5,4,3,5,7,0,1,5,4,1,0,0,0,1,0,6,4,1,0,7,5,4,2,5,4,0,1,2,1,5,1,4,1,0]

theorem envBound30623 : H12AffineFastState.Bounded env30623 := by
  intro p hp
  have h : env30623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30622_30623 : H12AffineEnvironment.transform 2 5 env30622 = env30623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30622 == env30623) = true)

def env30624 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74030,65664,272,8541,81,396,74046,65552,8408,74047,319,74111,81,75866,8204,8200,257,74095,0,593]

theorem envBound30624 : H12AffineFastState.Bounded env30624 := by
  intro p hp
  have h : env30624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30612_30624 : H12AffineEnvironment.transform 9 321 env30612 = env30624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env30612 == env30624) = true)

theorem identity30624 : scanCanonicalize (H12AffineFastState.compose env30624 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound30624 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env30625 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,8192,80,8216,65536,73834,65664,84,8217,81,200,73850,65552,8408,73851,123,73787,81,75866,8204,8200,69,73771,0,593]

theorem envBound30625 : H12AffineFastState.Bounded env30625 := by
  intro p hp
  have h : env30625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30624_30625 : H12AffineEnvironment.transform 7 68 env30624 = env30625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env30624 == env30625) = true)

theorem identity30625 : scanCanonicalize (H12AffineFastState.compose env30625 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30625 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30626 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,1,8216,65536,73787,65664,5,8217,0,153,73771,65552,8329,73770,42,73787,0,75787,8204,8200,20,73771,0,512]

theorem envBound30626 : H12AffineFastState.Bounded env30626 := by
  intro p hp
  have h : env30626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30625_30626 : H12AffineEnvironment.transform 5 17 env30625 = env30626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30625 == env30626) = true)

theorem identity30626 : scanCanonicalize (H12AffineFastState.compose env30626 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound30626 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env30627 : List Nat := [2,4,8,16,32,17,128,21,512,5,674,1,8192,1,8216,65536,73787,65664,5,8217,0,153,73771,65552,8329,73770,42,73787,0,74409,8204,8200,20,73771,0,512]

theorem envBound30627 : H12AffineFastState.Bounded env30627 := by
  intro p hp
  have h : env30627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30626_30627 : H12AffineEnvironment.transform 10 674 env30626 = env30627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env30626 == env30627) = true)

theorem identity30627 : scanCanonicalize (H12AffineFastState.compose env30627 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound30627 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env30628 : List Nat := [2,4,8,16,32,17,128,21,512,5,674,1,8192,1,8216,8715,560,8843,5,8217,0,153,544,8731,8329,545,42,560,0,162,8204,8200,20,544,0,512]

theorem envBound30628 : H12AffineFastState.Bounded env30628 := by
  intro p hp
  have h : env30628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30627_30628 : H12AffineEnvironment.transform 15 8715 env30627 = env30628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env30627 == env30628) = true)

theorem identity30628 : scanCanonicalize (H12AffineFastState.compose env30628 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound30628 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env30629 : List Nat := [2,4,8,16,32,17,128,21,512,5,674,1,514,1,538,9,560,137,5,539,0,153,544,25,651,545,42,560,0,162,526,522,20,544,0,512]

theorem envBound30629 : H12AffineFastState.Bounded env30629 := by
  intro p hp
  have h : env30629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30628_30629 : H12AffineEnvironment.transform 12 514 env30628 = env30629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env30628 == env30629) = true)

theorem identity30629 : scanCanonicalize (H12AffineFastState.compose env30629 (packedSelected [2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound30629 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env30630 : List Nat := [2,4,8,16,32,17,128,21,136,5,42,1,138,1,146,9,184,137,5,147,0,153,168,25,3,169,42,184,0,162,134,130,20,168,0,136]

theorem envBound30630 : H12AffineFastState.Bounded env30630 := by
  intro p hp
  have h : env30630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30629_30630 : H12AffineEnvironment.transform 8 136 env30629 = env30630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env30629 == env30630) = true)

theorem identity30630 : scanCanonicalize (H12AffineFastState.compose env30630 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30630 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30631 : List Nat := [2,4,8,11,32,10,128,14,136,5,42,1,138,1,137,9,163,137,5,136,0,130,168,2,3,169,42,163,0,162,134,130,15,168,0,136]

theorem envBound30631 : H12AffineFastState.Bounded env30631 := by
  intro p hp
  have h : env30631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30630_30631 : H12AffineEnvironment.transform 3 11 env30630 = env30631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30630 == env30631) = true)

theorem identity30631 : scanCanonicalize (H12AffineFastState.compose env30631 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30631 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30632 : List Nat := [2,4,8,11,11,10,128,14,136,5,1,1,138,1,137,9,136,137,5,136,0,130,131,2,3,130,1,136,0,137,134,130,15,131,0,136]

theorem envBound30632 : H12AffineFastState.Bounded env30632 := by
  intro p hp
  have h : env30632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30631_30632 : H12AffineEnvironment.transform 4 11 env30631 = env30632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30631 == env30632) = true)

theorem identity30632 : scanCanonicalize (H12AffineFastState.compose env30632 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30633 : List Nat := [2,4,8,11,11,10,15,14,7,5,1,1,5,1,6,9,7,6,5,7,0,13,12,2,3,13,1,7,0,6,9,13,15,12,0,7]

theorem envBound30633 : H12AffineFastState.Bounded env30633 := by
  intro p hp
  have h : env30633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30632_30633 : H12AffineEnvironment.transform 6 15 env30632 = env30633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30632 == env30633) = true)

theorem identity30633 : scanCanonicalize (H12AffineFastState.compose env30633 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30634 : List Nat := [2,3,8,11,11,10,8,9,0,2,1,1,2,1,1,9,0,1,2,0,0,10,11,2,3,10,1,0,0,1,9,10,8,11,0,0]

theorem envBound30634 : H12AffineFastState.Bounded env30634 := by
  intro p hp
  have h : env30634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30633_30634 : H12AffineEnvironment.transform 1 3 env30633 = env30634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30633 == env30634) = true)

def env30635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4097,5277,74046,66897,13769,78894,1151,74814,1296,81227,8204,8200,257,74798,1345,5952]

theorem envBound30635 : H12AffineFastState.Bounded env30635 := by
  intro p hp
  have h : env30635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30635 : H12AffineEnvironment.transform 17 65665 env30610 = env30635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30610 == env30635) = true)

theorem identity30635 : scanCanonicalize (H12AffineFastState.compose env30635 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30635 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30636 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,65536,74110,65665,4416,8541,4097,4492,74046,65600,12504,78143,366,74031,1,79962,8204,8200,257,74047,80,4689]

theorem envBound30636 : H12AffineFastState.Bounded env30636 := by
  intro p hp
  have h : env30636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30635_30636 : H12AffineEnvironment.transform 9 273 env30635 = env30636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30635 == env30636) = true)

def env30637 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,0,8540,65536,74110,65665,580,8541,773,648,74046,65600,9180,74299,366,74031,1,76638,8204,8200,257,74047,80,341]

theorem envBound30637 : H12AffineFastState.Bounded env30637 := by
  intro p hp
  have h : env30637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30636_30637 : H12AffineEnvironment.transform 11 772 env30636 = env30637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env30636 == env30637) = true)

def env30638 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,65536,74046,65665,516,8477,773,648,74046,65536,9116,74299,302,74031,1,76574,8204,8200,257,74047,16,277]

theorem envBound30638 : H12AffineFastState.Bounded env30638 := by
  intro p hp
  have h : env30638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30637_30638 : H12AffineEnvironment.transform 5 0 env30637 = env30638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30637 == env30638) = true)

theorem identity30638 : scanCanonicalize (H12AffineFastState.compose env30638 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30638 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30639 : List Nat := [2,4,8,16,7,0,128,256,512,273,2048,772,8192,0,8476,65536,74009,65665,516,8477,773,648,74009,65536,9116,74268,265,73992,1,76574,8204,8200,257,74008,16,277]

theorem envBound30639 : H12AffineFastState.Bounded env30639 := by
  intro p hp
  have h : env30639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30638_30639 : H12AffineEnvironment.transform 4 7 env30638 = env30639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30638 == env30639) = true)

def env30640 : List Nat := [2,4,8,16,7,0,128,256,512,273,2048,772,24,0,260,65536,65793,65665,516,261,773,648,65793,65536,900,66052,265,65808,1,68358,20,16,257,65792,16,277]

theorem envBound30640 : H12AffineFastState.Bounded env30640 := by
  intro p hp
  have h : env30640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30639_30640 : H12AffineEnvironment.transform 12 24 env30639 = env30640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30639 == env30640) = true)

theorem identity30640 : scanCanonicalize (H12AffineFastState.compose env30640 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30640 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30641 : List Nat := [2,4,8,16,7,0,128,5,512,20,2048,513,24,0,1,65536,65540,65665,516,0,512,648,65540,65536,641,66052,12,65557,1,68099,20,16,4,65541,16,16]

theorem envBound30641 : H12AffineFastState.Bounded env30641 := by
  intro p hp
  have h : env30641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30640_30641 : H12AffineEnvironment.transform 7 5 env30640 = env30641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30640 == env30641) = true)

theorem identity30641 : scanCanonicalize (H12AffineFastState.compose env30641 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound30641 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env30642 : List Nat := [2,4,8,16,7,0,128,5,512,20,142,513,24,0,1,65536,65540,65665,516,0,512,648,65540,65536,641,66052,12,65557,1,66189,20,16,4,65541,16,16]

theorem envBound30642 : H12AffineFastState.Bounded env30642 := by
  intro p hp
  have h : env30642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30641_30642 : H12AffineEnvironment.transform 10 142 env30641 = env30642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env30641 == env30642) = true)

theorem identity30642 : scanCanonicalize (H12AffineFastState.compose env30642 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 666) := by decide +kernel

theorem selectedBound30642 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env30643 : List Nat := [2,4,8,16,7,0,128,5,512,20,142,513,24,0,1,666,670,539,516,0,512,648,670,666,641,158,12,655,1,23,20,16,4,671,16,16]

theorem envBound30643 : H12AffineFastState.Bounded env30643 := by
  intro p hp
  have h : env30643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30642_30643 : H12AffineEnvironment.transform 15 666 env30642 = env30643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 666 env30642 == env30643) = true)

theorem identity30643 : scanCanonicalize (H12AffineFastState.compose env30643 (packedSelected [4,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound30643 : packedSelected [4,7,11] rootPS < 2^1333 := by decide +kernel

def env30644 : List Nat := [2,4,8,16,7,0,128,5,7,20,142,6,24,0,1,157,153,28,3,0,7,143,153,157,134,158,12,136,1,23,20,16,4,152,16,16]

theorem envBound30644 : H12AffineFastState.Bounded env30644 := by
  intro p hp
  have h : env30644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30643_30644 : H12AffineEnvironment.transform 8 7 env30643 = env30644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env30643 == env30644) = true)

theorem identity30644 : scanCanonicalize (H12AffineFastState.compose env30644 (packedSelected [0,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30644 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env30645 : List Nat := [2,4,8,7,7,0,128,5,7,3,142,6,15,0,1,138,142,11,3,0,7,143,142,138,134,137,12,136,1,0,3,7,4,143,7,7]

theorem envBound30645 : H12AffineFastState.Bounded env30645 := by
  intro p hp
  have h : env30645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30644_30645 : H12AffineEnvironment.transform 3 7 env30644 = env30645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30644 == env30645) = true)

theorem identity30645 : scanCanonicalize (H12AffineFastState.compose env30645 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30645 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30646 : List Nat := [2,4,4,7,7,0,128,5,7,3,130,6,3,0,1,134,130,7,3,0,7,131,130,134,134,133,0,132,1,0,3,7,4,131,7,7]

theorem envBound30646 : H12AffineFastState.Bounded env30646 := by
  intro p hp
  have h : env30646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30645_30646 : H12AffineEnvironment.transform 2 4 env30645 = env30646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30645 == env30646) = true)

def env30647 : List Nat := [2,4,8,16,7,0,128,256,512,273,2048,772,25,0,261,65536,65792,65665,516,260,773,648,65792,65536,901,66053,265,65809,1,68359,21,17,257,65793,16,277]

theorem envBound30647 : H12AffineFastState.Bounded env30647 := by
  intro p hp
  have h : env30647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30639_30647 : H12AffineEnvironment.transform 12 25 env30639 = env30647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30639 == env30647) = true)

theorem identity30647 : scanCanonicalize (H12AffineFastState.compose env30647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30648 : List Nat := [2,4,8,16,7,0,128,256,16,273,2048,276,25,0,261,65536,65792,65665,20,260,277,152,65792,65536,405,65557,265,65809,1,67863,21,17,257,65793,16,277]

theorem envBound30648 : H12AffineFastState.Bounded env30648 := by
  intro p hp
  have h : env30648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30647_30648 : H12AffineEnvironment.transform 8 16 env30647 = env30648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30647 == env30648) = true)

theorem identity30648 : scanCanonicalize (H12AffineFastState.compose env30648 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30648 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env30649 : List Nat := [2,4,8,16,7,0,128,5,16,20,2048,17,25,0,0,65536,65541,65665,20,1,16,152,65541,65536,144,65557,12,65556,1,67602,21,17,4,65540,16,16]

theorem envBound30649 : H12AffineFastState.Bounded env30649 := by
  intro p hp
  have h : env30649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30648_30649 : H12AffineEnvironment.transform 7 5 env30648 = env30649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30648 == env30649) = true)

theorem identity30649 : scanCanonicalize (H12AffineFastState.compose env30649 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound30649 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30650 : List Nat := [2,4,8,16,7,0,128,5,16,20,2048,17,25,0,0,140,137,13,20,1,16,152,137,140,144,153,12,152,1,2206,21,17,4,136,16,16]

theorem envBound30650 : H12AffineFastState.Bounded env30650 := by
  intro p hp
  have h : env30650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30649_30650 : H12AffineEnvironment.transform 15 140 env30649 = env30650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env30649 == env30650) = true)

theorem identity30650 : scanCanonicalize (H12AffineFastState.compose env30650 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound30650 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30651 : List Nat := [2,4,8,16,7,0,5,5,16,20,2048,17,25,0,0,9,12,13,20,1,16,29,12,9,21,28,12,29,1,2075,21,17,4,13,16,16]

theorem envBound30651 : H12AffineFastState.Bounded env30651 := by
  intro p hp
  have h : env30651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30650_30651 : H12AffineEnvironment.transform 6 5 env30650 = env30651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env30650 == env30651) = true)

theorem identity30651 : scanCanonicalize (H12AffineFastState.compose env30651 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound30651 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30652 : List Nat := [2,4,8,16,7,0,5,5,16,20,27,17,25,0,0,9,12,13,20,1,16,29,12,9,21,28,12,29,1,0,21,17,4,13,16,16]

theorem envBound30652 : H12AffineFastState.Bounded env30652 := by
  intro p hp
  have h : env30652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2