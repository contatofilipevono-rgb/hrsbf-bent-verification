import H12CloudChart2Data223

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env56510 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,72,1108,5204,35,1029,162,4100,5205,4097,152,17,4146,5316,5188,4218,1108,1109,7269,68,1093,68,64,1028,5637]

theorem envBound56510 : H12AffineFastState.Bounded env56510 := by
  intro p hp
  have h : env56510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56509_56510 : H12AffineEnvironment.transform 7 68 env56509 = env56510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56509 == env56510) = true)

theorem identity56510 : scanCanonicalize (H12AffineFastState.compose env56510 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound56510 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56511 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,72,1108,81,35,1029,162,1025,80,1028,152,17,1079,193,65,1151,1108,1109,2144,68,1093,68,64,1028,512]

theorem envBound56511 : H12AffineFastState.Bounded env56511 := by
  intro p hp
  have h : env56511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56510_56511 : H12AffineEnvironment.transform 11 1029 env56510 = env56511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env56510 == env56511) = true)

theorem identity56511 : scanCanonicalize (H12AffineFastState.compose env56511 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound56511 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56512 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,72,81,81,35,0,162,4,80,1,152,17,50,193,65,122,81,80,2144,68,64,68,64,1,512]

theorem envBound56512 : H12AffineFastState.Bounded env56512 := by
  intro p hp
  have h : env56512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56511_56512 : H12AffineEnvironment.transform 9 5 env56511 = env56512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env56511 == env56512) = true)

theorem identity56512 : scanCanonicalize (H12AffineFastState.compose env56512 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound56512 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env56513 : List Nat := [2,4,8,16,32,64,128,68,512,5,148,0,72,81,81,35,0,162,4,80,1,152,17,50,193,65,122,81,80,244,68,64,68,64,1,512]

theorem envBound56513 : H12AffineFastState.Bounded env56513 := by
  intro p hp
  have h : env56513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56512_56513 : H12AffineEnvironment.transform 10 148 env56512 = env56513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env56512 == env56513) = true)

theorem identity56513 : scanCanonicalize (H12AffineFastState.compose env56513 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound56513 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56514 : List Nat := [2,4,8,16,32,64,128,68,216,5,148,0,72,81,81,35,0,162,4,80,1,152,17,50,193,65,122,81,80,244,68,64,68,64,1,216]

theorem envBound56514 : H12AffineFastState.Bounded env56514 := by
  intro p hp
  have h : env56514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56513_56514 : H12AffineEnvironment.transform 8 216 env56513 = env56514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env56513 == env56514) = true)

theorem identity56514 : scanCanonicalize (H12AffineFastState.compose env56514 (packedSelected [1,2,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56514 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env56515 : List Nat := [2,4,8,11,32,64,128,68,195,5,143,0,72,74,74,35,0,162,4,75,1,131,10,41,193,65,97,74,75,239,68,64,68,64,1,195]

theorem envBound56515 : H12AffineFastState.Bounded env56515 := by
  intro p hp
  have h : env56515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56514_56515 : H12AffineEnvironment.transform 3 11 env56514 = env56515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56514 == env56515) = true)

theorem identity56515 : scanCanonicalize (H12AffineFastState.compose env56515 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound56515 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56516 : List Nat := [2,4,8,11,32,38,128,34,165,5,143,0,46,44,44,35,0,162,4,45,1,131,10,41,167,39,7,44,45,137,34,38,34,38,1,165]

theorem envBound56516 : H12AffineFastState.Bounded env56516 := by
  intro p hp
  have h : env56516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56515_56516 : H12AffineEnvironment.transform 5 38 env56515 = env56516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env56515 == env56516) = true)

theorem identity56516 : scanCanonicalize (H12AffineFastState.compose env56516 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56516 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56517 : List Nat := [2,2,8,11,32,32,128,34,163,3,137,0,40,42,42,35,0,162,2,43,1,131,10,41,161,33,1,42,43,137,34,32,34,32,1,163]

theorem envBound56517 : H12AffineFastState.Bounded env56517 := by
  intro p hp
  have h : env56517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56516_56517 : H12AffineEnvironment.transform 1 2 env56516 = env56517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56516 == env56517) = true)

theorem identity56517 : scanCanonicalize (H12AffineFastState.compose env56517 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56518 : List Nat := [2,2,8,11,11,11,128,9,136,3,137,0,3,1,1,8,0,137,2,0,1,131,10,2,138,10,1,1,0,137,9,11,9,11,1,136]

theorem envBound56518 : H12AffineFastState.Bounded env56518 := by
  intro p hp
  have h : env56518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56517_56518 : H12AffineEnvironment.transform 4 11 env56517 = env56518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56517 == env56518) = true)

def env56519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,359,1344,486,4416,5204,4097,476,16,4470,5505,5377,4414,1297,1297,7268,69,1280,256,65,1344,5953]

theorem envBound56519 : H12AffineFastState.Bounded env56519 := by
  intro p hp
  have h : env56519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56508_56519 : H12AffineEnvironment.transform 12 73 env56508 = env56519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56508 == env56519) = true)

theorem identity56519 : scanCanonicalize (H12AffineFastState.compose env56519 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound56519 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1296,1029,359,1344,486,272,1028,81,476,16,294,1489,1361,366,1297,1297,3124,69,1280,256,65,1344,1809]

theorem envBound56520 : H12AffineFastState.Bounded env56520 := by
  intro p hp
  have h : env56520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56519_56520 : H12AffineEnvironment.transform 11 80 env56519 = env56520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env56519 == env56520) = true)

theorem identity56520 : scanCanonicalize (H12AffineFastState.compose env56520 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound56520 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56521 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,73,1212,1029,203,1260,74,188,1028,81,112,16,138,1149,1277,194,1213,1213,3124,69,1196,172,65,1260,1725]

theorem envBound56521 : H12AffineFastState.Bounded env56521 := by
  intro p hp
  have h : env56521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56520_56521 : H12AffineEnvironment.transform 7 172 env56520 = env56521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56520 == env56521) = true)

theorem identity56521 : scanCanonicalize (H12AffineFastState.compose env56521 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound56521 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56522 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1703,80,73,1212,1029,203,1260,74,188,1028,81,112,16,138,1149,1277,194,1213,1213,659,69,1196,172,65,1260,1725]

theorem envBound56522 : H12AffineFastState.Bounded env56522 := by
  intro p hp
  have h : env56522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56521_56522 : H12AffineEnvironment.transform 10 1703 env56521 = env56522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env56521 == env56522) = true)

theorem identity56522 : scanCanonicalize (H12AffineFastState.compose env56522 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound56522 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env56523 : List Nat := [2,4,8,16,32,64,128,172,512,127,728,80,73,195,122,203,147,74,188,123,81,112,16,138,2,130,194,194,194,659,69,211,172,65,147,706]

theorem envBound56523 : H12AffineFastState.Bounded env56523 := by
  intro p hp
  have h : env56523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56522_56523 : H12AffineEnvironment.transform 9 127 env56522 = env56523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env56522 == env56523) = true)

theorem identity56523 : scanCanonicalize (H12AffineFastState.compose env56523 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound56523 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env56524 : List Nat := [2,4,8,16,32,64,128,172,81,127,137,80,73,195,122,203,147,74,188,123,81,112,16,138,2,130,194,194,194,194,69,211,172,65,147,147]

theorem envBound56524 : H12AffineFastState.Bounded env56524 := by
  intro p hp
  have h : env56524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56523_56524 : H12AffineEnvironment.transform 8 81 env56523 = env56524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env56523 == env56524) = true)

theorem identity56524 : scanCanonicalize (H12AffineFastState.compose env56524 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound56524 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56525 : List Nat := [2,4,8,16,32,64,56,20,81,127,49,80,73,123,122,115,43,74,4,123,81,112,16,50,2,58,122,122,122,122,69,107,20,65,43,43]

theorem envBound56525 : H12AffineFastState.Bounded env56525 := by
  intro p hp
  have h : env56525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56524_56525 : H12AffineEnvironment.transform 6 56 env56524 = env56525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env56524 == env56525) = true)

theorem identity56525 : scanCanonicalize (H12AffineFastState.compose env56525 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound56525 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56526 : List Nat := [2,4,8,16,32,33,56,20,48,30,49,49,40,26,27,18,43,43,4,26,48,17,16,50,2,58,27,27,27,27,36,10,20,32,43,43]

theorem envBound56526 : H12AffineFastState.Bounded env56526 := by
  intro p hp
  have h : env56526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56525_56526 : H12AffineEnvironment.transform 5 33 env56525 = env56526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56525 == env56526) = true)

theorem identity56526 : scanCanonicalize (H12AffineFastState.compose env56526 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56526 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56527 : List Nat := [2,4,8,16,10,11,18,20,26,30,27,27,2,26,27,18,1,1,4,26,26,17,16,24,2,16,27,27,27,27,14,10,20,10,1,1]

theorem envBound56527 : H12AffineFastState.Bounded env56527 := by
  intro p hp
  have h : env56527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56526_56527 : H12AffineEnvironment.transform 4 10 env56526 = env56527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56526 == env56527) = true)

theorem identity56527 : scanCanonicalize (H12AffineFastState.compose env56527 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound56527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56528 : List Nat := [2,4,8,13,10,11,15,9,7,3,6,6,2,7,6,15,1,1,4,7,7,12,13,5,2,13,6,6,6,6,14,10,9,10,1,1]

theorem envBound56528 : H12AffineFastState.Bounded env56528 := by
  intro p hp
  have h : env56528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56527_56528 : H12AffineEnvironment.transform 3 13 env56527 = env56528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env56527 == env56528) = true)

theorem identity56528 : scanCanonicalize (H12AffineFastState.compose env56528 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56528 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56529 : List Nat := [2,2,8,11,10,11,9,9,1,3,0,0,2,1,0,9,1,1,2,1,1,10,11,3,2,11,0,0,0,0,8,10,9,10,1,1]

theorem envBound56529 : H12AffineFastState.Bounded env56529 := by
  intro p hp
  have h : env56529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56528_56529 : H12AffineEnvironment.transform 1 2 env56528 = env56529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56528 == env56529) = true)

def env56530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4097,477,74047,69648,13769,78895,332222,74814,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound56530 : H12AffineFastState.Bounded env56530 := by
  intro p hp
  have h : env56530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56487_56530 : H12AffineEnvironment.transform 13 1297 env56487 = env56530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56487 == env56530) = true)

def env56531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4097,477,74047,69648,13769,78895,4414,74814,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound56531 : H12AffineFastState.Bounded env56531 := by
  intro p hp
  have h : env56531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56530_56531 : H12AffineEnvironment.transform 17 65664 env56530 = env56531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56530 == env56531) = true)

theorem identity56531 : scanCanonicalize (H12AffineFastState.compose env56531 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound56531 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9327,1,9455,4417,13341,4097,477,1360,13439,13769,4160,4414,81,1297,6436,8205,65,256,8201,1344,5952]

theorem envBound56532 : H12AffineFastState.Bounded env56532 := by
  intro p hp
  have h : env56532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56531_56532 : H12AffineEnvironment.transform 15 9327 env56531 = env56532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env56531 == env56532) = true)

def env56533 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,8495,1,8623,4417,12637,4097,477,16,12607,12425,4160,4414,81,81,6436,8205,65,256,8201,0,4608]

theorem envBound56533 : H12AffineFastState.Bounded env56533 := by
  intro p hp
  have h : env56533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56532_56533 : H12AffineEnvironment.transform 9 320 env56532 = env56533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56532 == env56533) = true)

theorem identity56533 : scanCanonicalize (H12AffineFastState.compose env56533 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound56533 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56534 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4365,81,81,4130,1,4258,4417,80,4097,477,16,50,388,4160,4414,81,81,6436,4352,65,256,4356,0,4608]

theorem envBound56534 : H12AffineFastState.Bounded env56534 := by
  intro p hp
  have h : env56534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56533_56534 : H12AffineEnvironment.transform 12 4365 env56533 = env56534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env56533 == env56534) = true)

theorem identity56534 : scanCanonicalize (H12AffineFastState.compose env56534 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 2722) := by decide +kernel

theorem selectedBound56534 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env56535 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2722,2991,81,81,2688,1,2560,3043,80,2723,477,16,50,388,2786,2972,81,81,902,2978,65,256,2982,0,2210]

theorem envBound56535 : H12AffineFastState.Bounded env56535 := by
  intro p hp
  have h : env56535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56534_56535 : H12AffineEnvironment.transform 11 2722 env56534 = env56535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2722 env56534 == env56535) = true)

theorem identity56535 : scanCanonicalize (H12AffineFastState.compose env56535 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound56535 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env56536 : List Nat := [2,4,8,16,32,64,128,256,512,320,674,0,269,81,81,34,1,162,321,80,1,477,16,50,388,64,318,81,81,902,256,65,256,260,0,512]

theorem envBound56536 : H12AffineFastState.Bounded env56536 := by
  intro p hp
  have h : env56536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56535_56536 : H12AffineEnvironment.transform 10 674 env56535 = env56536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env56535 == env56536) = true)

theorem identity56536 : scanCanonicalize (H12AffineFastState.compose env56536 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56536 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56537 : List Nat := [2,4,8,16,32,17,128,256,512,273,674,0,269,0,0,34,1,162,272,1,1,396,16,50,388,17,318,0,0,902,256,16,256,260,0,512]

theorem envBound56537 : H12AffineFastState.Bounded env56537 := by
  intro p hp
  have h : env56537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56536_56537 : H12AffineEnvironment.transform 5 17 env56536 = env56537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56536 == env56537) = true)

theorem identity56537 : scanCanonicalize (H12AffineFastState.compose env56537 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56537 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56538 : List Nat := [2,4,8,16,32,17,8,256,512,273,554,0,269,0,0,34,1,42,272,1,1,260,16,50,268,17,318,0,0,782,256,16,256,260,0,512]

theorem envBound56538 : H12AffineFastState.Bounded env56538 := by
  intro p hp
  have h : env56538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56537_56538 : H12AffineEnvironment.transform 6 8 env56537 = env56538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56537 == env56538) = true)

theorem identity56538 : scanCanonicalize (H12AffineFastState.compose env56538 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound56538 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56539 : List Nat := [2,4,8,16,32,17,8,256,271,273,293,0,269,0,0,34,1,42,272,1,1,260,16,50,268,17,318,0,0,1,256,16,256,260,0,271]

theorem envBound56539 : H12AffineFastState.Bounded env56539 := by
  intro p hp
  have h : env56539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56538_56539 : H12AffineEnvironment.transform 8 271 env56538 = env56539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env56538 == env56539) = true)

theorem identity56539 : scanCanonicalize (H12AffineFastState.compose env56539 (packedSelected [1,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56539 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env56540 : List Nat := [2,4,8,16,32,17,8,14,1,31,43,0,3,0,0,34,1,42,30,1,1,10,16,50,2,17,48,0,0,1,14,16,14,10,0,1]

theorem envBound56540 : H12AffineFastState.Bounded env56540 := by
  intro p hp
  have h : env56540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56539_56540 : H12AffineEnvironment.transform 7 14 env56539 = env56540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56539 == env56540) = true)

theorem identity56540 : scanCanonicalize (H12AffineFastState.compose env56540 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56540 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56541 : List Nat := [2,4,8,10,32,11,8,14,1,5,43,0,3,0,0,34,1,42,4,1,1,10,10,40,2,11,42,0,0,1,14,10,14,10,0,1]

theorem envBound56541 : H12AffineFastState.Bounded env56541 := by
  intro p hp
  have h : env56541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56540_56541 : H12AffineEnvironment.transform 3 10 env56540 = env56541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56540 == env56541) = true)

theorem identity56541 : scanCanonicalize (H12AffineFastState.compose env56541 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56542 : List Nat := [2,4,8,10,12,11,8,14,1,5,7,0,3,0,0,14,1,6,4,1,1,10,10,4,2,11,6,0,0,1,14,10,14,10,0,1]

theorem envBound56542 : H12AffineFastState.Bounded env56542 := by
  intro p hp
  have h : env56542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56541_56542 : H12AffineEnvironment.transform 4 12 env56541 = env56542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56541 == env56542) = true)

theorem identity56542 : scanCanonicalize (H12AffineFastState.compose env56542 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56542 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56543 : List Nat := [2,3,8,10,11,11,8,9,1,2,0,0,3,0,0,9,1,1,3,1,1,10,10,3,2,11,1,0,0,1,9,10,9,10,0,1]

theorem envBound56543 : H12AffineFastState.Bounded env56543 := by
  intro p hp
  have h : env56543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56542_56543 : H12AffineEnvironment.transform 1 3 env56542 = env56543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56542 == env56543) = true)

def env56544 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,8494,1,8622,4417,12636,4097,477,17,12606,12424,4160,4414,81,80,6436,8205,65,256,8201,1,4609]

theorem envBound56544 : H12AffineFastState.Bounded env56544 := by
  intro p hp
  have h : env56544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56532_56544 : H12AffineEnvironment.transform 9 321 env56532 = env56544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56532 == env56544) = true)

theorem identity56544 : scanCanonicalize (H12AffineFastState.compose env56544 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound56544 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56545 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,4421,310,1,438,4417,4420,4097,477,17,4390,4240,4160,4414,81,80,6436,21,65,256,17,1,4609]

theorem envBound56545 : H12AffineFastState.Bounded env56545 := by
  intro p hp
  have h : env56545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56544_56545 : H12AffineEnvironment.transform 12 24 env56544 = env56545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env56544 == env56545) = true)

theorem identity56545 : scanCanonicalize (H12AffineFastState.compose env56545 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound56545 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56546 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,428,24,80,233,310,1,438,237,232,429,477,17,138,316,492,146,81,80,2184,21,65,256,17,1,941]

theorem envBound56546 : H12AffineFastState.Bounded env56546 := by
  intro p hp
  have h : env56546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56545_56546 : H12AffineEnvironment.transform 11 428 env56545 = env56546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env56545 == env56546) = true)

theorem identity56546 : scanCanonicalize (H12AffineFastState.compose env56546 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56546 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56547 : List Nat := [2,4,8,16,32,64,128,256,48,321,2048,428,24,80,233,310,1,438,237,232,429,477,17,138,316,492,146,81,80,2184,21,65,256,17,1,413]

theorem envBound56547 : H12AffineFastState.Bounded env56547 := by
  intro p hp
  have h : env56547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56546_56547 : H12AffineEnvironment.transform 8 48 env56546 = env56547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56546 == env56547) = true)

theorem identity56547 : scanCanonicalize (H12AffineFastState.compose env56547 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound56547 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env56548 : List Nat := [2,4,8,16,32,64,128,256,48,321,184,428,24,80,233,310,1,438,237,232,429,477,17,138,316,492,146,81,80,48,21,65,256,17,1,413]

theorem envBound56548 : H12AffineFastState.Bounded env56548 := by
  intro p hp
  have h : env56548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56547_56548 : H12AffineEnvironment.transform 10 184 env56547 = env56548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env56547 == env56548) = true)

theorem identity56548 : scanCanonicalize (H12AffineFastState.compose env56548 (packedSelected [0,1,2,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound56548 : packedSelected [0,1,2,8,9,11] rootPS < 2^1333 := by decide +kernel

def env56549 : List Nat := [2,4,8,16,32,64,128,173,48,236,184,1,24,80,233,155,1,27,237,232,0,112,17,138,145,65,146,81,80,48,21,65,173,17,1,48]

theorem envBound56549 : H12AffineFastState.Bounded env56549 := by
  intro p hp
  have h : env56549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56548_56549 : H12AffineEnvironment.transform 7 173 env56548 = env56549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env56548 == env56549) = true)

theorem identity56549 : scanCanonicalize (H12AffineFastState.compose env56549 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound56549 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56550 : List Nat := [2,4,8,16,32,64,66,111,48,46,122,1,24,80,43,89,1,27,47,42,0,112,17,72,83,65,80,81,80,48,21,65,111,17,1,48]

theorem envBound56550 : H12AffineFastState.Bounded env56550 := by
  intro p hp
  have h : env56550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56549_56550 : H12AffineEnvironment.transform 6 66 env56549 = env56550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env56549 == env56550) = true)

theorem identity56550 : scanCanonicalize (H12AffineFastState.compose env56550 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound56550 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56551 : List Nat := [2,4,8,16,32,33,35,14,48,46,27,1,24,49,43,56,1,27,47,42,0,17,17,41,50,32,49,48,49,48,21,32,14,17,1,48]

theorem envBound56551 : H12AffineFastState.Bounded env56551 := by
  intro p hp
  have h : env56551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56550_56551 : H12AffineEnvironment.transform 5 33 env56550 = env56551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env56550 == env56551) = true)

theorem identity56551 : scanCanonicalize (H12AffineFastState.compose env56551 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56551 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56552 : List Nat := [2,4,8,16,11,10,8,14,27,5,27,1,24,26,0,19,1,27,4,1,0,17,17,2,25,11,26,27,26,27,21,11,14,17,1,27]

theorem envBound56552 : H12AffineFastState.Bounded env56552 := by
  intro p hp
  have h : env56552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56551_56552 : H12AffineEnvironment.transform 4 11 env56551 = env56552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56551 == env56552) = true)

theorem identity56552 : scanCanonicalize (H12AffineFastState.compose env56552 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56552 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56553 : List Nat := [2,4,8,10,11,10,8,14,1,5,1,1,2,0,0,9,1,1,4,1,0,11,11,2,3,11,0,1,0,1,15,11,14,11,1,1]

theorem envBound56553 : H12AffineFastState.Bounded env56553 := by
  intro p hp
  have h : env56553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56552_56553 : H12AffineEnvironment.transform 3 10 env56552 = env56553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56552 == env56553) = true)

theorem identity56553 : scanCanonicalize (H12AffineFastState.compose env56553 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56554 : List Nat := [2,3,8,10,11,10,8,9,1,2,1,1,2,0,0,9,1,1,3,1,0,11,11,2,3,11,0,1,0,1,8,11,9,11,1,1]

theorem envBound56554 : H12AffineFastState.Bounded env56554 := by
  intro p hp
  have h : env56554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56553_56554 : H12AffineEnvironment.transform 1 3 env56553 = env56554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56553 == env56554) = true)

def env56555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4097,477,74047,69648,13769,78895,4415,74814,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound56555 : H12AffineFastState.Bounded env56555 := by
  intro p hp
  have h : env56555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56530_56555 : H12AffineEnvironment.transform 17 65665 env56530 = env56555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56530 == env56555) = true)

theorem identity56555 : scanCanonicalize (H12AffineFastState.compose env56555 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound56555 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12590,5440,12719,4417,13341,4097,477,4113,8510,13769,1281,4415,5392,1297,3173,8205,5376,256,8201,1344,5952]

theorem envBound56556 : H12AffineFastState.Bounded env56556 := by
  intro p hp
  have h : env56556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56555_56556 : H12AffineEnvironment.transform 15 12590 env56555 = env56556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env56555 == env56556) = true)

def env56557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,8494,1344,8623,321,9245,1,477,17,8510,9673,1281,319,1296,1297,3173,8205,1280,256,8201,1344,1856]

theorem envBound56557 : H12AffineFastState.Bounded env56557 := by
  intro p hp
  have h : env56557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56556_56557 : H12AffineEnvironment.transform 11 0 env56556 = env56557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56556 == env56557) = true)

theorem identity56557 : scanCanonicalize (H12AffineFastState.compose env56557 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound56557 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1297,325,1143,1344,1270,321,324,1,477,17,1127,144,1281,319,1296,1297,3173,1364,1280,256,1360,1344,1856]

theorem envBound56558 : H12AffineFastState.Bounded env56558 := by
  intro p hp
  have h : env56558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56557_56558 : H12AffineEnvironment.transform 12 1369 env56557 = env56558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env56557 == env56558) = true)

theorem identity56558 : scanCanonicalize (H12AffineFastState.compose env56558 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound56558 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56559 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,0,436,508,325,154,429,27,321,324,1,477,17,138,144,492,319,509,508,2184,441,493,256,445,429,941]

theorem envBound56559 : H12AffineFastState.Bounded env56559 := by
  intro p hp
  have h : env56559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56558_56559 : H12AffineEnvironment.transform 9 237 env56558 = env56559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env56558 == env56559) = true)

theorem identity56559 : scanCanonicalize (H12AffineFastState.compose env56559 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound56559 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56560 : List Nat := [2,4,8,16,32,64,128,256,412,237,2048,0,436,508,325,154,429,27,321,324,1,477,17,138,144,492,319,509,508,2184,441,493,256,445,429,49]

theorem envBound56560 : H12AffineFastState.Bounded env56560 := by
  intro p hp
  have h : env56560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56559_56560 : H12AffineEnvironment.transform 8 412 env56559 = env56560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env56559 == env56560) = true)

theorem identity56560 : scanCanonicalize (H12AffineFastState.compose env56560 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound56560 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env56561 : List Nat := [2,4,8,16,32,64,128,256,412,237,185,0,436,508,325,154,429,27,321,324,1,477,17,138,144,492,319,509,508,49,441,493,256,445,429,49]

theorem envBound56561 : H12AffineFastState.Bounded env56561 := by
  intro p hp
  have h : env56561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56560_56561 : H12AffineEnvironment.transform 10 185 env56560 = env56561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env56560 == env56561) = true)

theorem identity56561 : scanCanonicalize (H12AffineFastState.compose env56561 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56561 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56562 : List Nat := [2,4,8,16,32,64,128,20,136,237,185,0,160,232,81,154,185,27,85,80,1,201,17,138,144,248,43,233,232,49,173,249,20,169,185,49]

theorem envBound56562 : H12AffineFastState.Bounded env56562 := by
  intro p hp
  have h : env56562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56561_56562 : H12AffineEnvironment.transform 7 20 env56561 = env56562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56561 == env56562) = true)

theorem identity56562 : scanCanonicalize (H12AffineFastState.compose env56562 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56562 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env56563 : List Nat := [2,4,8,11,32,64,128,15,136,237,162,0,160,232,74,129,162,0,78,75,1,201,10,138,139,227,43,233,232,42,173,226,15,169,162,42]

theorem envBound56563 : H12AffineFastState.Bounded env56563 := by
  intro p hp
  have h : env56563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56562_56563 : H12AffineEnvironment.transform 3 11 env56562 = env56563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56562 == env56563) = true)

theorem identity56563 : scanCanonicalize (H12AffineFastState.compose env56563 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound56563 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env56564 : List Nat := [2,4,8,11,32,32,128,15,136,141,162,0,160,136,42,129,162,0,46,43,1,169,10,138,139,131,43,137,136,42,173,130,15,169,162,42]

theorem envBound56564 : H12AffineFastState.Bounded env56564 := by
  intro p hp
  have h : env56564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56563_56564 : H12AffineEnvironment.transform 5 32 env56563 = env56564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56563 == env56564) = true)

theorem identity56564 : scanCanonicalize (H12AffineFastState.compose env56564 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56564 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56565 : List Nat := [2,4,8,11,32,32,8,15,0,5,42,0,40,0,42,9,42,0,46,43,1,33,10,2,3,11,43,1,0,42,37,10,15,33,42,42]

theorem envBound56565 : H12AffineFastState.Bounded env56565 := by
  intro p hp
  have h : env56565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56564_56565 : H12AffineEnvironment.transform 6 8 env56564 = env56565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56564 == env56565) = true)

theorem identity56565 : scanCanonicalize (H12AffineFastState.compose env56565 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56565 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56566 : List Nat := [2,4,8,11,11,11,8,15,0,5,1,0,3,0,1,9,1,0,5,0,1,10,10,2,3,11,0,1,0,1,14,10,15,10,1,1]

theorem envBound56566 : H12AffineFastState.Bounded env56566 := by
  intro p hp
  have h : env56566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56565_56566 : H12AffineEnvironment.transform 4 11 env56565 = env56566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56565 == env56566) = true)

theorem identity56566 : scanCanonicalize (H12AffineFastState.compose env56566 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound56566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56567 : List Nat := [2,4,7,4,4,4,7,0,0,5,1,0,3,0,1,6,1,0,5,0,1,5,5,2,3,4,0,1,0,1,1,5,0,5,1,1]

theorem envBound56567 : H12AffineFastState.Bounded env56567 := by
  intro p hp
  have h : env56567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56566_56567 : H12AffineEnvironment.transform 2 7 env56566 = env56567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env56566 == env56567) = true)

theorem identity56567 : scanCanonicalize (H12AffineFastState.compose env56567 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56568 : List Nat := [2,2,1,2,2,2,1,0,0,3,1,0,3,0,1,0,1,0,3,0,1,3,3,2,3,2,0,1,0,1,1,3,0,3,1,1]

theorem envBound56568 : H12AffineFastState.Bounded env56568 := by
  intro p hp
  have h : env56568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56567_56568 : H12AffineEnvironment.transform 1 2 env56567 = env56568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56567 == env56568) = true)

theorem identity56568 : scanCanonicalize (H12AffineFastState.compose env56568 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56568 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56569 : List Nat := [1,1,1,1,1,1,1,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0,1,0,1,0,1,1,0,0,0,1,1]

theorem envBound56569 : H12AffineFastState.Bounded env56569 := by
  intro p hp
  have h : env56569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56568_56569 : H12AffineEnvironment.transform 0 1 env56568 = env56569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56568 == env56569) = true)

def env56570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,8495,1345,8622,320,9244,0,477,16,8510,9672,1281,318,1297,1297,3173,8205,1281,256,8201,1344,1857]

theorem envBound56570 : H12AffineFastState.Bounded env56570 := by
  intro p hp
  have h : env56570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56556_56570 : H12AffineEnvironment.transform 11 1 env56556 = env56570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56556 == env56570) = true)

theorem identity56570 : scanCanonicalize (H12AffineFastState.compose env56570 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound56570 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1100,1297,81,1379,1345,1506,320,80,0,477,16,1394,388,1281,318,1297,1297,3173,1089,1281,256,1093,1344,1857]

theorem envBound56571 : H12AffineFastState.Bounded env56571 := by
  intro p hp
  have h : env56571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56570_56571 : H12AffineEnvironment.transform 12 1100 env56570 = env56571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env56570 == env56571) = true)

theorem identity56571 : scanCanonicalize (H12AffineFastState.compose env56571 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound56571 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56572 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,269,80,81,34,0,163,320,80,0,477,16,51,388,64,318,80,80,2340,256,64,256,260,1,512]

theorem envBound56572 : H12AffineFastState.Bounded env56572 := by
  intro p hp
  have h : env56572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56571_56572 : H12AffineEnvironment.transform 9 321 env56571 = env56572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56571 == env56572) = true)

theorem identity56572 : scanCanonicalize (H12AffineFastState.compose env56572 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56572 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56573 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,269,1,0,34,0,163,273,1,0,396,16,51,388,17,318,1,1,2340,256,17,256,260,1,512]

theorem envBound56573 : H12AffineFastState.Bounded env56573 := by
  intro p hp
  have h : env56573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56572_56573 : H12AffineEnvironment.transform 5 17 env56572 = env56573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56572 == env56573) = true)

theorem identity56573 : scanCanonicalize (H12AffineFastState.compose env56573 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound56573 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56574 : List Nat := [2,4,8,16,32,17,128,256,277,272,2048,1,269,1,0,34,0,163,273,1,0,396,16,51,388,17,318,1,1,2340,256,17,256,260,1,277]

theorem envBound56574 : H12AffineFastState.Bounded env56574 := by
  intro p hp
  have h : env56574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56573_56574 : H12AffineEnvironment.transform 8 277 env56573 = env56574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env56573 == env56574) = true)

theorem identity56574 : scanCanonicalize (H12AffineFastState.compose env56574 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56574 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env56575 : List Nat := [2,4,8,16,16,17,128,256,277,272,2048,1,269,1,0,18,0,147,273,1,0,396,16,3,388,17,270,1,1,2324,256,17,256,260,1,277]

theorem envBound56575 : H12AffineFastState.Bounded env56575 := by
  intro p hp
  have h : env56575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56574_56575 : H12AffineEnvironment.transform 4 16 env56574 = env56575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56574 == env56575) = true)

theorem identity56575 : scanCanonicalize (H12AffineFastState.compose env56575 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56575 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56576 : List Nat := [2,4,8,16,16,17,128,21,0,5,2048,1,24,1,0,18,0,147,4,1,0,153,16,3,145,17,27,1,1,2049,21,17,21,17,1,0]

theorem envBound56576 : H12AffineFastState.Bounded env56576 := by
  intro p hp
  have h : env56576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56575_56576 : H12AffineEnvironment.transform 7 21 env56575 = env56576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56575 == env56576) = true)

theorem identity56576 : scanCanonicalize (H12AffineFastState.compose env56576 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound56576 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56577 : List Nat := [2,4,8,13,13,12,128,8,0,5,2048,1,5,1,0,15,0,142,4,1,0,132,13,3,140,12,6,1,1,2049,8,12,8,12,1,0]

theorem envBound56577 : H12AffineFastState.Bounded env56577 := by
  intro p hp
  have h : env56577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56576_56577 : H12AffineEnvironment.transform 3 13 env56576 = env56577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env56576 == env56577) = true)

theorem identity56577 : scanCanonicalize (H12AffineFastState.compose env56577 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound56577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56578 : List Nat := [2,4,8,13,13,12,128,8,0,5,142,1,5,1,0,15,0,142,4,1,0,132,13,3,140,12,6,1,1,143,8,12,8,12,1,0]

theorem envBound56578 : H12AffineFastState.Bounded env56578 := by
  intro p hp
  have h : env56578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56577_56578 : H12AffineEnvironment.transform 10 142 env56577 = env56578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env56577 == env56578) = true)

theorem identity56578 : scanCanonicalize (H12AffineFastState.compose env56578 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound56578 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56579 : List Nat := [2,4,8,13,13,12,14,8,0,5,0,1,5,1,0,15,0,0,4,1,0,10,13,3,2,12,6,1,1,1,8,12,8,12,1,0]

theorem envBound56579 : H12AffineFastState.Bounded env56579 := by
  intro p hp
  have h : env56579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56578_56579 : H12AffineEnvironment.transform 6 14 env56578 = env56579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env56578 == env56579) = true)

theorem identity56579 : scanCanonicalize (H12AffineFastState.compose env56579 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56579 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env56580 : List Nat := [2,3,8,10,10,11,9,8,0,2,0,1,2,1,0,8,0,0,3,1,0,10,10,3,2,11,1,1,1,1,8,11,8,11,1,0]

theorem envBound56580 : H12AffineFastState.Bounded env56580 := by
  intro p hp
  have h : env56580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56579_56580 : H12AffineEnvironment.transform 1 3 env56579 = env56580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56579 == env56580) = true)

def env56581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123165,28889,78894,385203,90415,1296,96346,25884,74799,256,25880,1344,21072]

theorem envBound56581 : H12AffineFastState.Bounded env56581 := by
  intro p hp
  have h : env56581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56485_56581 : H12AffineEnvironment.transform 18 21585 env56485 = env56581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env56485 == env56581) = true)

theorem identity56581 : scanCanonicalize (H12AffineFastState.compose env56581 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound56581 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4097,5277,91182,66896,28889,78894,328958,90415,1296,96346,25884,74799,256,25880,1344,21072]

theorem envBound56582 : H12AffineFastState.Bounded env56582 := by
  intro p hp
  have h : env56582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56581_56582 : H12AffineEnvironment.transform 14 25677 env56581 = env56582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env56581 == env56582) = true)

def env56583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4097,5277,74046,66896,13769,78894,328958,74815,1296,81226,8204,74799,256,8200,1344,5952]

theorem envBound56583 : H12AffineFastState.Bounded env56583 := by
  intro p hp
  have h : env56583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56582_56583 : H12AffineEnvironment.transform 13 1296 env56582 = env56583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56582 == env56583) = true)

def env56584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4097,5277,74046,66896,13769,78894,1150,74815,1296,81226,8204,74799,256,8200,1344,5952]

theorem envBound56584 : H12AffineFastState.Bounded env56584 := by
  intro p hp
  have h : env56584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56583_56584 : H12AffineEnvironment.transform 17 65664 env56583 = env56584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56583 == env56584) = true)

theorem identity56584 : scanCanonicalize (H12AffineFastState.compose env56584 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound56584 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5159,12361,5287,4417,8540,4097,5277,13593,4471,13769,8201,1150,12312,1296,10605,8204,12296,256,8200,1344,5952]

theorem envBound56585 : H12AffineFastState.Bounded env56585 := by
  intro p hp
  have h : env56585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56584_56585 : H12AffineEnvironment.transform 15 5159 env56584 = env56585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env56584 == env56585) = true)

def env56586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5159,1345,5287,4417,5204,4097,5277,17,4471,193,5377,1150,1296,1296,7269,5380,1280,256,5376,1344,5952]

theorem envBound56586 : H12AffineFastState.Bounded env56586 := by
  intro p hp
  have h : env56586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56585_56586 : H12AffineEnvironment.transform 12 5384 env56585 = env56586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env56585 == env56586) = true)

theorem identity56586 : scanCanonicalize (H12AffineFastState.compose env56586 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound56586 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1296,1028,1142,1345,1270,272,1029,80,1228,17,294,193,1360,1150,1296,1296,3124,1365,1280,256,1361,1344,1809]

theorem envBound56587 : H12AffineFastState.Bounded env56587 := by
  intro p hp
  have h : env56587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56586_56587 : H12AffineEnvironment.transform 11 81 env56586 = env56587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env56586 == env56587) = true)

theorem identity56587 : scanCanonicalize (H12AffineFastState.compose env56587 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 2018) := by decide +kernel

theorem selectedBound56587 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2018,81,1369,1296,1028,1142,1345,1270,272,1029,80,1228,17,294,193,1360,1150,1296,1296,982,1365,1280,256,1361,1344,1809]

theorem envBound56588 : H12AffineFastState.Bounded env56588 := by
  intro p hp
  have h : env56588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56587_56588 : H12AffineEnvironment.transform 10 2018 env56587 = env56588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2018 env56587 == env56588) = true)

theorem identity56588 : scanCanonicalize (H12AffineFastState.compose env56588 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound56588 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env56589 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1703,81,1052,1109,1028,1142,1028,1270,85,1029,80,1228,17,99,193,1045,1150,1109,1109,659,1040,1093,69,1044,1029,1620]

theorem envBound56589 : H12AffineFastState.Bounded env56589 := by
  intro p hp
  have h : env56589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56588_56589 : H12AffineEnvironment.transform 7 69 env56588 = env56589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env56588 == env56589) = true)

theorem identity56589 : scanCanonicalize (H12AffineFastState.compose env56589 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56589 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env56590 : List Nat := [2,4,8,16,32,64,128,69,512,4,675,81,24,81,0,114,0,242,85,1,80,200,17,99,193,17,122,81,81,659,20,65,69,16,1,592]

theorem envBound56590 : H12AffineFastState.Bounded env56590 := by
  intro p hp
  have h : env56590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56589_56590 : H12AffineEnvironment.transform 9 4 env56589 = env56590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56589 == env56590) = true)

theorem identity56590 : scanCanonicalize (H12AffineFastState.compose env56590 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound56590 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env56591 : List Nat := [2,4,8,16,32,23,128,18,512,4,675,6,24,6,0,37,0,165,2,1,7,159,17,52,150,17,45,6,6,659,20,22,18,16,1,519]

theorem envBound56591 : H12AffineFastState.Bounded env56591 := by
  intro p hp
  have h : env56591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56590_56591 : H12AffineEnvironment.transform 5 23 env56590 = env56591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env56590 == env56591) = true)

theorem identity56591 : scanCanonicalize (H12AffineFastState.compose env56591 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound56591 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env56592 : List Nat := [2,4,8,16,32,23,128,18,190,4,29,6,24,6,0,37,0,165,2,1,7,159,17,52,150,17,45,6,6,45,20,22,18,16,1,185]

theorem envBound56592 : H12AffineFastState.Bounded env56592 := by
  intro p hp
  have h : env56592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56591_56592 : H12AffineEnvironment.transform 8 190 env56591 = env56592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env56591 == env56592) = true)

theorem identity56592 : scanCanonicalize (H12AffineFastState.compose env56592 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound56592 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env56593 : List Nat := [2,4,8,16,32,23,18,18,44,4,29,6,24,6,0,37,0,55,2,1,7,13,17,52,4,17,45,6,6,45,20,22,18,16,1,43]

theorem envBound56593 : H12AffineFastState.Bounded env56593 := by
  intro p hp
  have h : env56593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56592_56593 : H12AffineEnvironment.transform 6 18 env56592 = env56593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env56592 == env56593) = true)

theorem identity56593 : scanCanonicalize (H12AffineFastState.compose env56593 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56593 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56594 : List Nat := [2,4,8,16,12,23,18,18,0,4,29,6,24,6,0,9,0,27,2,1,7,13,17,24,4,17,1,6,6,1,20,22,18,16,1,7]

theorem envBound56594 : H12AffineFastState.Bounded env56594 := by
  intro p hp
  have h : env56594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56593_56594 : H12AffineEnvironment.transform 4 12 env56593 = env56594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56593 == env56594) = true)

theorem identity56594 : scanCanonicalize (H12AffineFastState.compose env56594 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56595 : List Nat := [2,3,8,16,11,16,18,18,0,3,26,1,24,1,0,9,0,27,2,1,0,10,17,24,3,17,1,1,1,1,19,17,18,16,1,0]

theorem envBound56595 : H12AffineFastState.Bounded env56595 := by
  intro p hp
  have h : env56595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56594_56595 : H12AffineEnvironment.transform 1 3 env56594 = env56595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56594 == env56595) = true)

theorem identity56595 : scanCanonicalize (H12AffineFastState.compose env56595 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56596 : List Nat := [2,3,8,10,11,10,8,8,0,3,0,1,2,1,0,9,0,1,2,1,0,10,11,2,3,11,1,1,1,1,9,11,8,10,1,0]

theorem envBound56596 : H12AffineFastState.Bounded env56596 := by
  intro p hp
  have h : env56596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56595_56596 : H12AffineEnvironment.transform 3 10 env56595 = env56596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56595 == env56596) = true)

def env56597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5159,1344,5287,4417,5205,4097,5277,16,4471,192,5376,1150,1297,1296,7268,5381,1281,256,5377,1344,5952]

theorem envBound56597 : H12AffineFastState.Bounded env56597 := by
  intro p hp
  have h : env56597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56585_56597 : H12AffineEnvironment.transform 12 5385 env56585 = env56597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env56585 == env56597) = true)

theorem identity56597 : scanCanonicalize (H12AffineFastState.compose env56597 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56597 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,269,1296,80,35,1344,163,1349,81,1029,153,16,1395,192,260,1150,1297,1296,2144,257,1281,256,261,1344,836]

theorem envBound56598 : H12AffineFastState.Bounded env56598 := by
  intro p hp
  have h : env56598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56597_56598 : H12AffineEnvironment.transform 11 1028 env56597 = env56598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56597 == env56598) = true)

theorem identity56598 : scanCanonicalize (H12AffineFastState.compose env56598 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56598 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56599 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,73,1108,80,35,1028,163,1025,81,1029,153,16,1079,192,64,1150,1109,1108,2144,69,1093,68,65,1028,512]

theorem envBound56599 : H12AffineFastState.Bounded env56599 := by
  intro p hp
  have h : env56599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56598_56599 : H12AffineEnvironment.transform 7 68 env56598 = env56599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56598 == env56599) = true)

theorem identity56599 : scanCanonicalize (H12AffineFastState.compose env56599 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound56599 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56600 : List Nat := [2,4,8,16,32,64,128,68,512,1024,122,1028,73,1108,80,35,1028,163,1025,81,1029,153,16,1079,192,64,1150,1109,1108,26,69,1093,68,65,1028,512]

theorem envBound56600 : H12AffineFastState.Bounded env56600 := by
  intro p hp
  have h : env56600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56599_56600 : H12AffineEnvironment.transform 10 122 env56599 = env56600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env56599 == env56600) = true)

theorem identity56600 : scanCanonicalize (H12AffineFastState.compose env56600 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 733) := by decide +kernel

theorem selectedBound56600 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env56601 : List Nat := [2,4,8,16,32,64,128,68,512,733,122,729,73,649,80,35,729,163,732,81,728,153,16,746,192,64,675,648,649,26,69,664,68,65,729,512]

theorem envBound56601 : H12AffineFastState.Bounded env56601 := by
  intro p hp
  have h : env56601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56600_56601 : H12AffineEnvironment.transform 9 733 env56600 = env56601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 733 env56600 == env56601) = true)

theorem identity56601 : scanCanonicalize (H12AffineFastState.compose env56601 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56601 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56602 : List Nat := [2,4,8,16,32,16,128,20,512,653,42,649,25,649,0,35,649,163,652,1,648,153,16,698,144,16,675,648,649,26,21,664,20,17,649,512]

theorem envBound56602 : H12AffineFastState.Bounded env56602 := by
  intro p hp
  have h : env56602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56601_56602 : H12AffineEnvironment.transform 5 16 env56601 = env56602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56601 == env56602) = true)

theorem identity56602 : scanCanonicalize (H12AffineFastState.compose env56602 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound56602 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56603 : List Nat := [2,4,8,16,32,16,128,20,185,52,42,48,25,48,0,35,48,163,53,1,49,153,16,3,144,16,26,49,48,26,21,33,20,17,48,185]

theorem envBound56603 : H12AffineFastState.Bounded env56603 := by
  intro p hp
  have h : env56603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56602_56603 : H12AffineEnvironment.transform 8 185 env56602 = env56603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env56602 == env56603) = true)

theorem identity56603 : scanCanonicalize (H12AffineFastState.compose env56603 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56603 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56604 : List Nat := [2,4,8,11,32,11,128,15,162,47,42,43,2,43,0,35,43,163,46,1,42,130,11,3,139,11,1,42,43,1,14,33,15,10,43,162]

theorem envBound56604 : H12AffineFastState.Bounded env56604 := by
  intro p hp
  have h : env56604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56603_56604 : H12AffineEnvironment.transform 3 11 env56603 = env56604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56603 == env56604) = true)

theorem identity56604 : scanCanonicalize (H12AffineFastState.compose env56604 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56604 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56605 : List Nat := [2,4,8,11,10,11,128,15,136,5,0,1,2,1,0,9,1,137,4,1,0,130,11,3,139,11,1,0,1,1,14,11,15,10,1,136]

theorem envBound56605 : H12AffineFastState.Bounded env56605 := by
  intro p hp
  have h : env56605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56604_56605 : H12AffineEnvironment.transform 4 10 env56604 = env56605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56604 == env56605) = true)

theorem identity56605 : scanCanonicalize (H12AffineFastState.compose env56605 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound56605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56606 : List Nat := [2,4,8,11,10,11,15,15,7,5,0,1,2,1,0,9,1,6,4,1,0,13,11,3,4,11,1,0,1,1,14,11,15,10,1,7]

theorem envBound56606 : H12AffineFastState.Bounded env56606 := by
  intro p hp
  have h : env56606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56605_56606 : H12AffineEnvironment.transform 6 15 env56605 = env56606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env56605 == env56606) = true)

def env56607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4097,5277,74046,66896,13769,78894,1151,74815,1296,81226,8204,74799,256,8200,1344,5952]

theorem envBound56607 : H12AffineFastState.Bounded env56607 := by
  intro p hp
  have h : env56607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56583_56607 : H12AffineEnvironment.transform 17 65665 env56583 = env56607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56583 == env56607) = true)

theorem identity56607 : scanCanonicalize (H12AffineFastState.compose env56607 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound56607 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,358,9480,487,4417,8540,4097,5277,8280,1078,13769,13640,1151,9561,1296,15404,8204,9545,256,8200,1344,5952]

theorem envBound56608 : H12AffineFastState.Bounded env56608 := by
  intro p hp
  have h : env56608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56607_56608 : H12AffineEnvironment.transform 15 358 env56607 = env56608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env56607 == env56608) = true)

def env56609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,358,1344,487,4417,276,4097,5277,16,1078,5505,5376,1151,1297,1296,7268,68,1281,256,64,1344,5952]

theorem envBound56609 : H12AffineFastState.Bounded env56609 := by
  intro p hp
  have h : env56609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56608_56609 : H12AffineEnvironment.transform 12 72 env56608 = env56609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56608 == env56609) = true)

theorem identity56609 : scanCanonicalize (H12AffineFastState.compose env56609 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound56609 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56610 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,4096,72,1109,80,35,1029,162,4100,81,4097,5277,16,1078,5316,5189,1151,1108,1109,7268,68,1092,69,64,1029,5637]

theorem envBound56610 : H12AffineFastState.Bounded env56610 := by
  intro p hp
  have h : env56610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56609_56610 : H12AffineEnvironment.transform 7 69 env56609 = env56610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env56609 == env56610) = true)

theorem identity56610 : scanCanonicalize (H12AffineFastState.compose env56610 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound56610 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56611 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,72,1109,80,35,1029,162,1025,81,1028,152,16,1078,193,64,1151,1108,1109,2145,68,1092,69,64,1029,512]

theorem envBound56611 : H12AffineFastState.Bounded env56611 := by
  intro p hp
  have h : env56611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56610_56611 : H12AffineEnvironment.transform 11 1029 env56610 = env56611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env56610 == env56611) = true)

theorem identity56611 : scanCanonicalize (H12AffineFastState.compose env56611 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound56611 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56612 : List Nat := [2,4,8,16,32,64,128,69,512,237,2048,232,72,184,80,35,232,162,236,81,233,152,16,219,193,64,146,185,184,2145,68,169,69,64,232,512]

theorem envBound56612 : H12AffineFastState.Bounded env56612 := by
  intro p hp
  have h : env56612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56611_56612 : H12AffineEnvironment.transform 9 237 env56611 = env56612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env56611 == env56612) = true)

theorem identity56612 : scanCanonicalize (H12AffineFastState.compose env56612 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound56612 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56613 : List Nat := [2,4,8,16,32,64,56,69,512,85,2048,80,72,0,80,35,80,26,84,81,81,32,16,99,121,64,42,1,0,2145,68,17,69,64,80,512]

theorem envBound56613 : H12AffineFastState.Bounded env56613 := by
  intro p hp
  have h : env56613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56612_56613 : H12AffineEnvironment.transform 6 56 env56612 = env56613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env56612 == env56613) = true)

def env56614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,358,1345,487,4417,277,4097,5277,17,1078,5504,5377,1151,1296,1296,7269,69,1280,256,65,1344,5952]

theorem envBound56614 : H12AffineFastState.Bounded env56614 := by
  intro p hp
  have h : env56614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56608_56614 : H12AffineEnvironment.transform 12 73 env56608 = env56614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56608 == env56614) = true)

theorem identity56614 : scanCanonicalize (H12AffineFastState.compose env56614 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56614 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56615 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,0,276,358,81,487,4417,277,4097,4493,17,294,4240,4113,367,0,0,6517,69,16,256,65,80,4688]

theorem envBound56615 : H12AffineFastState.Bounded env56615 := by
  intro p hp
  have h : env56615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56614_56615 : H12AffineEnvironment.transform 9 272 env56614 = env56615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56614 == env56615) = true)

theorem identity56615 : scanCanonicalize (H12AffineFastState.compose env56615 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2722) := by decide +kernel

theorem selectedBound56615 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56616 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2722,73,0,276,358,81,487,3043,277,2723,2863,17,294,2610,2739,367,0,0,983,69,16,256,65,80,2290]

theorem envBound56616 : H12AffineFastState.Bounded env56616 := by
  intro p hp
  have h : env56616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56615_56616 : H12AffineEnvironment.transform 11 2722 env56615 = env56616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2722 env56615 == env56616) = true)

theorem identity56616 : scanCanonicalize (H12AffineFastState.compose env56616 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56616 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env56617 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,2722,73,0,80,34,81,163,2727,81,2723,2667,17,98,2610,2739,43,0,0,659,69,16,68,65,80,2290]

theorem envBound56617 : H12AffineFastState.Bounded env56617 := by
  intro p hp
  have h : env56617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56616_56617 : H12AffineEnvironment.transform 7 68 env56616 = env56617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56616 == env56617) = true)

theorem identity56617 : scanCanonicalize (H12AffineFastState.compose env56617 (packedSelected [2,3,4,5,9,10,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound56617 : packedSelected [2,3,4,5,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env56618 : List Nat := [2,4,8,16,32,64,128,68,97,84,2048,2243,73,0,80,34,81,163,2246,81,2242,2058,17,98,2131,2258,43,0,0,242,69,16,68,65,80,2290]

theorem envBound56618 : H12AffineFastState.Bounded env56618 := by
  intro p hp
  have h : env56618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56617_56618 : H12AffineEnvironment.transform 8 97 env56617 = env56618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env56617 == env56618) = true)

theorem identity56618 : scanCanonicalize (H12AffineFastState.compose env56618 (packedSelected [1,4,8,9,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound56618 : packedSelected [1,4,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env56619 : List Nat := [2,4,8,16,32,64,128,68,97,84,43,232,73,0,80,34,81,163,237,81,233,33,17,98,120,249,43,0,0,242,69,16,68,65,80,217]

theorem envBound56619 : H12AffineFastState.Bounded env56619 := by
  intro p hp
  have h : env56619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56618_56619 : H12AffineEnvironment.transform 10 43 env56618 = env56619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env56618 == env56619) = true)

theorem identity56619 : scanCanonicalize (H12AffineFastState.compose env56619 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56619 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56620 : List Nat := [2,4,8,16,32,64,9,68,97,84,43,97,73,0,80,34,81,42,100,81,96,33,17,98,120,112,43,0,0,123,69,16,68,65,80,80]

theorem envBound56620 : H12AffineFastState.Bounded env56620 := by
  intro p hp
  have h : env56620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56619_56620 : H12AffineEnvironment.transform 6 9 env56619 = env56620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56619 == env56620) = true)

theorem identity56620 : scanCanonicalize (H12AffineFastState.compose env56620 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56620 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56621 : List Nat := [2,4,8,16,11,64,9,68,74,84,0,74,73,0,80,9,81,1,79,81,75,10,17,73,83,91,0,0,0,80,69,16,68,65,80,80]

theorem envBound56621 : H12AffineFastState.Bounded env56621 := by
  intro p hp
  have h : env56621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56620_56621 : H12AffineEnvironment.transform 4 11 env56620 = env56621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56620 == env56621) = true)

theorem identity56621 : scanCanonicalize (H12AffineFastState.compose env56621 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56622 : List Nat := [2,4,8,16,11,16,9,20,26,4,0,26,25,0,0,9,1,1,31,1,27,10,17,25,3,11,0,0,0,0,21,16,20,17,0,0]

theorem envBound56622 : H12AffineFastState.Bounded env56622 := by
  intro p hp
  have h : env56622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56621_56622 : H12AffineEnvironment.transform 5 16 env56621 = env56622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56621 == env56622) = true)

theorem identity56622 : scanCanonicalize (H12AffineFastState.compose env56622 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound56622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56623 : List Nat := [2,4,8,13,11,13,9,9,7,4,0,7,4,0,0,9,1,1,2,1,6,10,12,4,3,11,0,0,0,0,8,13,9,12,0,0]

theorem envBound56623 : H12AffineFastState.Bounded env56623 := by
  intro p hp
  have h : env56623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56622_56623 : H12AffineEnvironment.transform 3 13 env56622 = env56623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env56622 == env56623) = true)

def env56624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4097,5277,74047,66896,13768,78894,328958,74814,1296,81227,8205,74799,256,8201,1344,5953]

theorem envBound56624 : H12AffineFastState.Bounded env56624 := by
  intro p hp
  have h : env56624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56582_56624 : H12AffineEnvironment.transform 13 1297 env56582 = env56624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56582 == env56624) = true)

def env56625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4097,5277,74047,66896,13768,78894,1150,74814,1296,81227,8205,74799,256,8201,1344,5953]

theorem envBound56625 : H12AffineFastState.Bounded env56625 := by
  intro p hp
  have h : env56625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56624_56625 : H12AffineEnvironment.transform 17 65664 env56624 = env56625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56624 == env56625) = true)

theorem identity56625 : scanCanonicalize (H12AffineFastState.compose env56625 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound56625 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9327,1,9455,4416,8541,4097,5277,1360,8511,13768,4161,1150,81,1296,6436,8205,64,256,8201,1344,5953]

theorem envBound56626 : H12AffineFastState.Bounded env56626 := by
  intro p hp
  have h : env56626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56625_56626 : H12AffineEnvironment.transform 15 9327 env56625 = env56626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env56625 == env56626) = true)

def env56627 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8495,1,8623,4416,8541,4097,4573,16,8511,12424,4161,318,81,80,6436,8205,64,256,8201,0,4609]

theorem envBound56627 : H12AffineFastState.Bounded env56627 := by
  intro p hp
  have h : env56627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56626_56627 : H12AffineEnvironment.transform 9 320 env56626 = env56627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56626 == env56627) = true)

theorem identity56627 : scanCanonicalize (H12AffineFastState.compose env56627 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound56627 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56628 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,81,4421,4406,1,4534,4416,4420,4097,4573,16,4390,145,4161,318,81,80,6436,4116,64,256,4112,0,4609]

theorem envBound56628 : H12AffineFastState.Bounded env56628 := by
  intro p hp
  have h : env56628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56627_56628 : H12AffineEnvironment.transform 12 4121 env56627 = env56628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env56627 == env56628) = true)

theorem identity56628 : scanCanonicalize (H12AffineFastState.compose env56628 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound56628 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env56629 : List Nat := [2,4,8,16,32,64,128,256,136,320,2048,4096,4121,81,4421,4406,1,4534,4416,4420,4097,4573,16,4390,145,4161,318,81,80,6436,4116,64,256,4112,0,4233]

theorem envBound56629 : H12AffineFastState.Bounded env56629 := by
  intro p hp
  have h : env56629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56628_56629 : H12AffineEnvironment.transform 8 136 env56628 = env56629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env56628 == env56629) = true)

theorem identity56629 : scanCanonicalize (H12AffineFastState.compose env56629 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound56629 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env56630 : List Nat := [2,4,8,16,32,64,128,69,136,5,2048,4096,4121,81,4096,4211,1,4339,4101,4097,4097,4248,16,4195,145,4161,123,81,80,6241,4116,64,69,4112,0,4233]

theorem envBound56630 : H12AffineFastState.Bounded env56630 := by
  intro p hp
  have h : env56630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56629_56630 : H12AffineEnvironment.transform 7 69 env56629 = env56630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env56629 == env56630) = true)

theorem identity56630 : scanCanonicalize (H12AffineFastState.compose env56630 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56630 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env56631 : List Nat := [2,4,8,16,16,64,128,69,136,5,2048,4096,4121,81,4096,4163,1,4291,4101,4097,4097,4248,16,4179,145,4161,75,81,80,6225,4116,64,69,4112,0,4233]

theorem envBound56631 : H12AffineFastState.Bounded env56631 := by
  intro p hp
  have h : env56631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56630_56631 : H12AffineEnvironment.transform 4 16 env56630 = env56631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56630 == env56631) = true)

theorem identity56631 : scanCanonicalize (H12AffineFastState.compose env56631 (packedSelected [0,1,3,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56631 : packedSelected [0,1,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56632 : List Nat := [2,4,8,16,16,64,128,69,136,5,1,4096,4121,81,4096,4163,1,4291,4101,4097,4097,4248,16,4179,145,4161,75,81,80,4176,4116,64,69,4112,0,4233]

theorem envBound56632 : H12AffineFastState.Bounded env56632 := by
  intro p hp
  have h : env56632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56631_56632 : H12AffineEnvironment.transform 10 1 env56631 = env56632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56631 == env56632) = true)

theorem identity56632 : scanCanonicalize (H12AffineFastState.compose env56632 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56632 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56633 : List Nat := [2,4,8,16,16,64,8,69,0,5,1,4096,4121,81,4096,4163,1,4171,4101,4097,4097,4112,16,4179,25,4161,75,81,80,4176,4116,64,69,4112,0,4097]

theorem envBound56633 : H12AffineFastState.Bounded env56633 := by
  intro p hp
  have h : env56633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56632_56633 : H12AffineEnvironment.transform 6 8 env56632 = env56633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56632 == env56633) = true)

theorem identity56633 : scanCanonicalize (H12AffineFastState.compose env56633 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56633 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56634 : List Nat := [2,4,8,11,11,64,8,69,0,5,1,4096,4098,74,4096,4163,1,4171,4101,4097,4097,4107,11,4168,2,4161,75,74,75,4171,4111,64,69,4107,0,4097]

theorem envBound56634 : H12AffineFastState.Bounded env56634 := by
  intro p hp
  have h : env56634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56633_56634 : H12AffineEnvironment.transform 3 11 env56633 = env56634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56633 == env56634) = true)

theorem identity56634 : scanCanonicalize (H12AffineFastState.compose env56634 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56634 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56635 : List Nat := [2,4,8,11,11,11,8,14,0,5,1,4096,4098,1,4096,4104,1,4096,4101,4097,4097,4107,11,4099,2,4106,0,1,0,4096,4111,11,14,4107,0,4097]

theorem envBound56635 : H12AffineFastState.Bounded env56635 := by
  intro p hp
  have h : env56635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56634_56635 : H12AffineEnvironment.transform 5 11 env56634 = env56635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56634 == env56635) = true)

theorem identity56635 : scanCanonicalize (H12AffineFastState.compose env56635 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound56635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56636 : List Nat := [2,4,8,11,11,11,8,14,0,5,1,1,3,1,1,9,1,1,4,0,0,10,11,2,2,11,0,1,0,1,14,11,14,10,0,0]

theorem envBound56636 : H12AffineFastState.Bounded env56636 := by
  intro p hp
  have h : env56636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56635_56636 : H12AffineEnvironment.transform 11 1 env56635 = env56636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56635 == env56636) = true)

theorem identity56636 : scanCanonicalize (H12AffineFastState.compose env56636 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56637 : List Nat := [2,2,8,11,11,11,8,8,0,3,1,1,3,1,1,9,1,1,2,0,0,10,11,2,2,11,0,1,0,1,8,11,8,10,0,0]

theorem envBound56637 : H12AffineFastState.Bounded env56637 := by
  intro p hp
  have h : env56637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56636_56637 : H12AffineEnvironment.transform 1 2 env56636 = env56637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56636 == env56637) = true)

def env56638 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8494,1,8622,4416,8541,4097,4572,17,8511,12425,4161,319,81,81,6436,8205,64,256,8201,1,4608]

theorem envBound56638 : H12AffineFastState.Bounded env56638 := by
  intro p hp
  have h : env56638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56626_56638 : H12AffineEnvironment.transform 9 321 env56626 = env56638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56626 == env56638) = true)

theorem identity56638 : scanCanonicalize (H12AffineFastState.compose env56638 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound56638 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56639 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4364,80,4176,4130,1,4258,4416,4177,4097,4572,17,4147,389,4161,319,81,81,6436,4353,64,256,4357,1,4608]

theorem envBound56639 : H12AffineFastState.Bounded env56639 := by
  intro p hp
  have h : env56639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56638_56639 : H12AffineEnvironment.transform 12 4364 env56638 = env56639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env56638 == env56639) = true)

theorem identity56639 : scanCanonicalize (H12AffineFastState.compose env56639 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound56639 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56640 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,268,80,80,34,1,162,320,81,1,476,17,51,389,65,319,81,81,2340,257,64,256,261,1,512]

theorem envBound56640 : H12AffineFastState.Bounded env56640 := by
  intro p hp
  have h : env56640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56639_56640 : H12AffineEnvironment.transform 11 0 env56639 = env56640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56639 == env56640) = true)

theorem identity56640 : scanCanonicalize (H12AffineFastState.compose env56640 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56640 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56641 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,268,0,0,34,1,162,272,1,1,396,17,51,389,17,319,1,1,2340,257,16,256,261,1,512]

theorem envBound56641 : H12AffineFastState.Bounded env56641 := by
  intro p hp
  have h : env56641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56640_56641 : H12AffineEnvironment.transform 5 16 env56640 = env56641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56640 == env56641) = true)

theorem identity56641 : scanCanonicalize (H12AffineFastState.compose env56641 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound56641 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56642 : List Nat := [2,4,8,16,32,16,128,256,438,273,2048,0,268,0,0,34,1,162,272,1,1,396,17,51,389,17,319,1,1,2340,257,16,256,261,1,438]

theorem envBound56642 : H12AffineFastState.Bounded env56642 := by
  intro p hp
  have h : env56642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56641_56642 : H12AffineEnvironment.transform 8 438 env56641 = env56642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env56641 == env56642) = true)

theorem identity56642 : scanCanonicalize (H12AffineFastState.compose env56642 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound56642 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env56643 : List Nat := [2,4,8,16,32,16,128,134,48,151,2048,0,138,0,0,34,1,162,150,1,1,10,17,51,3,17,185,1,1,2210,135,16,134,131,1,48]

theorem envBound56643 : H12AffineFastState.Bounded env56643 := by
  intro p hp
  have h : env56643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56642_56643 : H12AffineEnvironment.transform 7 134 env56642 = env56643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env56642 == env56643) = true)

theorem identity56643 : scanCanonicalize (H12AffineFastState.compose env56643 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56643 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env56644 : List Nat := [2,4,8,16,32,16,8,14,48,31,2048,0,2,0,0,34,1,42,30,1,1,10,17,51,3,17,49,1,1,2090,15,16,14,11,1,48]

theorem envBound56644 : H12AffineFastState.Bounded env56644 := by
  intro p hp
  have h : env56644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56643_56644 : H12AffineEnvironment.transform 6 8 env56643 = env56644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56643 == env56644) = true)

theorem identity56644 : scanCanonicalize (H12AffineFastState.compose env56644 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound56644 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56645 : List Nat := [2,4,8,16,32,16,8,14,48,31,42,0,2,0,0,34,1,42,30,1,1,10,17,51,3,17,49,1,1,0,15,16,14,11,1,48]

theorem envBound56645 : H12AffineFastState.Bounded env56645 := by
  intro p hp
  have h : env56645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56644_56645 : H12AffineEnvironment.transform 10 42 env56644 = env56645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env56644 == env56645) = true)

theorem identity56645 : scanCanonicalize (H12AffineFastState.compose env56645 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56645 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56646 : List Nat := [2,4,8,11,32,11,8,14,43,4,42,0,2,0,0,34,1,42,5,1,1,10,10,40,3,10,42,1,1,0,15,11,14,11,1,43]

theorem envBound56646 : H12AffineFastState.Bounded env56646 := by
  intro p hp
  have h : env56646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56645_56646 : H12AffineEnvironment.transform 3 11 env56645 = env56646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56645 == env56646) = true)

theorem identity56646 : scanCanonicalize (H12AffineFastState.compose env56646 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56647 : List Nat := [2,4,4,7,32,7,4,2,39,4,38,0,2,0,0,34,1,38,5,1,1,6,6,36,3,6,38,1,1,0,3,7,2,7,1,39]

theorem envBound56647 : H12AffineFastState.Bounded env56647 := by
  intro p hp
  have h : env56647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56646_56647 : H12AffineEnvironment.transform 2 4 env56646 = env56647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56646 == env56647) = true)

def env56648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4097,5277,74047,66896,13768,78894,1151,74814,1296,81227,8205,74799,256,8201,1344,5953]

theorem envBound56648 : H12AffineFastState.Bounded env56648 := by
  intro p hp
  have h : env56648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56624_56648 : H12AffineEnvironment.transform 17 65665 env56624 = env56648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56624 == env56648) = true)

theorem identity56648 : scanCanonicalize (H12AffineFastState.compose env56648 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound56648 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12591,5441,12718,4416,8541,4097,5277,4112,13439,13768,1281,1151,5393,1296,3172,8205,5376,256,8201,1344,5953]

theorem envBound56649 : H12AffineFastState.Bounded env56649 := by
  intro p hp
  have h : env56649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56648_56649 : H12AffineEnvironment.transform 15 12591 env56648 = env56649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env56648 == env56649) = true)

def env56650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8495,1345,8622,320,8541,1,1181,16,9343,9672,1281,1151,1297,1296,3172,8205,1280,256,8201,1344,1857]

theorem envBound56650 : H12AffineFastState.Bounded env56650 := by
  intro p hp
  have h : env56650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56649_56650 : H12AffineEnvironment.transform 11 0 env56649 = env56650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56649 == env56650) = true)

theorem identity56650 : scanCanonicalize (H12AffineFastState.compose env56650 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound56650 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1297,325,310,1345,439,320,324,1,1181,16,1126,1489,1281,1151,1297,1296,3172,20,1280,256,16,1344,1857]

theorem envBound56651 : H12AffineFastState.Bounded env56651 := by
  intro p hp
  have h : env56651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56650_56651 : H12AffineEnvironment.transform 12 25 env56650 = env56651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env56650 == env56651) = true)

theorem identity56651 : scanCanonicalize (H12AffineFastState.compose env56651 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound56651 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env56652 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,0,25,1297,325,310,1345,439,320,324,1,1181,16,1126,1489,1281,1151,1297,1296,3172,20,1280,256,16,1344,1481]

theorem envBound56652 : H12AffineFastState.Bounded env56652 := by
  intro p hp
  have h : env56652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56651_56652 : H12AffineEnvironment.transform 8 136 env56651 = env56652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env56651 == env56652) = true)

theorem identity56652 : scanCanonicalize (H12AffineFastState.compose env56652 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound56652 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env56653 : List Nat := [2,4,8,16,32,64,128,256,136,5,2048,0,25,276,325,310,324,439,320,324,1,152,16,99,468,260,122,276,277,2145,20,261,256,16,325,460]

theorem envBound56653 : H12AffineFastState.Bounded env56653 := by
  intro p hp
  have h : env56653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56652_56653 : H12AffineEnvironment.transform 9 5 env56652 = env56653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env56652 == env56653) = true)

theorem identity56653 : scanCanonicalize (H12AffineFastState.compose env56653 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound56653 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56654 : List Nat := [2,4,8,16,32,64,128,95,136,5,2048,0,25,75,26,105,27,232,31,27,1,152,16,99,139,91,122,75,74,2145,20,90,95,16,26,147]

theorem envBound56654 : H12AffineFastState.Bounded env56654 := by
  intro p hp
  have h : env56654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56653_56654 : H12AffineEnvironment.transform 7 95 env56653 = env56654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env56653 == env56654) = true)

theorem identity56654 : scanCanonicalize (H12AffineFastState.compose env56654 (packedSelected [1,4,8,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound56654 : packedSelected [1,4,8,9,16] rootPS < 2^1333 := by decide +kernel

def env56655 : List Nat := [2,4,8,16,32,64,128,95,136,5,43,0,25,75,26,105,27,232,31,27,1,152,16,99,139,91,122,75,74,74,20,90,95,16,26,147]

theorem envBound56655 : H12AffineFastState.Bounded env56655 := by
  intro p hp
  have h : env56655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56654_56655 : H12AffineEnvironment.transform 10 43 env56654 = env56655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env56654 == env56655) = true)

theorem identity56655 : scanCanonicalize (H12AffineFastState.compose env56655 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound56655 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56656 : List Nat := [2,4,8,16,32,58,128,37,136,5,43,0,25,49,26,19,27,146,31,27,1,152,16,25,139,33,0,49,48,48,20,32,37,16,26,147]

theorem envBound56656 : H12AffineFastState.Bounded env56656 := by
  intro p hp
  have h : env56656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56655_56656 : H12AffineEnvironment.transform 5 58 env56655 = env56656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env56655 == env56656) = true)

theorem identity56656 : scanCanonicalize (H12AffineFastState.compose env56656 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56656 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56657 : List Nat := [2,4,8,16,11,17,128,14,136,5,0,0,25,26,26,19,27,146,31,27,1,152,16,25,139,10,0,26,27,27,20,11,14,16,26,147]

theorem envBound56657 : H12AffineFastState.Bounded env56657 := by
  intro p hp
  have h : env56657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56656_56657 : H12AffineEnvironment.transform 4 11 env56656 = env56657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56656 == env56657) = true)

theorem identity56657 : scanCanonicalize (H12AffineFastState.compose env56657 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56657 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56658 : List Nat := [2,4,8,16,11,17,8,14,0,5,0,0,25,26,26,19,27,26,31,27,1,16,16,25,3,10,0,26,27,27,20,11,14,16,26,27]

theorem envBound56658 : H12AffineFastState.Bounded env56658 := by
  intro p hp
  have h : env56658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56657_56658 : H12AffineEnvironment.transform 6 8 env56657 = env56658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56657 == env56658) = true)

theorem identity56658 : scanCanonicalize (H12AffineFastState.compose env56658 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56659 : List Nat := [2,4,8,10,11,11,8,14,0,5,0,0,3,0,0,9,1,0,5,1,1,10,10,3,3,10,0,0,1,1,14,11,14,10,0,1]

theorem envBound56659 : H12AffineFastState.Bounded env56659 := by
  intro p hp
  have h : env56659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56658_56659 : H12AffineEnvironment.transform 3 10 env56658 = env56659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56658 == env56659) = true)

theorem identity56659 : scanCanonicalize (H12AffineFastState.compose env56659 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound56659 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56660 : List Nat := [2,4,7,5,4,4,7,1,0,5,0,0,3,0,0,6,1,0,5,1,1,5,5,3,3,5,0,0,1,1,1,4,1,5,0,1]

theorem envBound56660 : H12AffineFastState.Bounded env56660 := by
  intro p hp
  have h : env56660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56659_56660 : H12AffineEnvironment.transform 2 7 env56659 = env56660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env56659 == env56660) = true)

theorem identity56660 : scanCanonicalize (H12AffineFastState.compose env56660 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56660 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56661 : List Nat := [2,2,1,3,2,2,1,1,0,3,0,0,3,0,0,0,1,0,3,1,1,3,3,3,3,3,0,0,1,1,1,2,1,3,0,1]

theorem envBound56661 : H12AffineFastState.Bounded env56661 := by
  intro p hp
  have h : env56661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56660_56661 : H12AffineEnvironment.transform 1 2 env56660 = env56661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56660 == env56661) = true)

theorem identity56661 : scanCanonicalize (H12AffineFastState.compose env56661 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56661 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56662 : List Nat := [0,0,1,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,0,1,1,0,1]

theorem envBound56662 : H12AffineFastState.Bounded env56662 := by
  intro p hp
  have h : env56662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56661_56662 : H12AffineEnvironment.transform 0 0 env56661 = env56662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56661 == env56662) = true)

def env56663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8494,1344,8623,321,8541,0,1180,17,9342,9673,1281,1151,1296,1296,3172,8205,1281,256,8201,1344,1856]

theorem envBound56663 : H12AffineFastState.Bounded env56663 := by
  intro p hp
  have h : env56663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56649_56663 : H12AffineEnvironment.transform 11 1 env56649 = env56663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56649 == env56663) = true)

theorem identity56663 : scanCanonicalize (H12AffineFastState.compose env56663 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound56663 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1100,1297,1296,1378,1344,1507,321,1297,0,1180,17,50,389,1281,1151,1296,1296,3172,1089,1281,256,1093,1344,1856]

theorem envBound56664 : H12AffineFastState.Bounded env56664 := by
  intro p hp
  have h : env56664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56663_56664 : H12AffineEnvironment.transform 12 1100 env56663 = env56664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env56663 == env56664) = true)

theorem identity56664 : scanCanonicalize (H12AffineFastState.compose env56664 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound56664 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env56665 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,81,80,34,0,163,321,81,0,476,17,50,389,65,319,80,80,2340,257,65,256,261,0,512]

theorem envBound56665 : H12AffineFastState.Bounded env56665 := by
  intro p hp
  have h : env56665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56664_56665 : H12AffineEnvironment.transform 9 320 env56664 = env56665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56664 == env56665) = true)

theorem identity56665 : scanCanonicalize (H12AffineFastState.compose env56665 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56665 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56666 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,268,1,0,34,0,163,273,1,0,396,17,50,389,17,319,0,0,2340,257,17,256,261,0,512]

theorem envBound56666 : H12AffineFastState.Bounded env56666 := by
  intro p hp
  have h : env56666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56665_56666 : H12AffineEnvironment.transform 5 16 env56665 = env56666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56665 == env56666) = true)

theorem identity56666 : scanCanonicalize (H12AffineFastState.compose env56666 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound56666 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56667 : List Nat := [2,4,8,16,32,16,128,256,512,272,648,1,268,1,0,34,0,163,273,1,0,396,17,50,389,17,319,0,0,940,257,17,256,261,0,512]

theorem envBound56667 : H12AffineFastState.Bounded env56667 := by
  intro p hp
  have h : env56667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56666_56667 : H12AffineEnvironment.transform 10 648 env56666 = env56667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env56666 == env56667) = true)

theorem identity56667 : scanCanonicalize (H12AffineFastState.compose env56667 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound56667 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env56668 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,1,268,1,0,34,0,163,273,1,0,396,17,50,389,17,319,0,0,293,257,17,256,261,0,137]

theorem envBound56668 : H12AffineFastState.Bounded env56668 := by
  intro p hp
  have h : env56668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56667_56668 : H12AffineEnvironment.transform 8 137 env56667 = env56668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env56667 == env56668) = true)

theorem identity56668 : scanCanonicalize (H12AffineFastState.compose env56668 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56668 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56669 : List Nat := [2,4,8,16,16,16,128,256,137,272,1,1,268,1,0,18,0,147,273,1,0,396,17,2,389,17,271,0,0,277,257,17,256,261,0,137]

theorem envBound56669 : H12AffineFastState.Bounded env56669 := by
  intro p hp
  have h : env56669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56668_56669 : H12AffineEnvironment.transform 4 16 env56668 = env56669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56668 == env56669) = true)

theorem identity56669 : scanCanonicalize (H12AffineFastState.compose env56669 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56669 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56670 : List Nat := [2,4,8,16,16,16,128,20,137,4,1,1,24,1,0,18,0,147,5,1,0,152,17,2,145,17,27,0,0,1,21,17,20,17,0,137]

theorem envBound56670 : H12AffineFastState.Bounded env56670 := by
  intro p hp
  have h : env56670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56669_56670 : H12AffineEnvironment.transform 7 20 env56669 = env56670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56669 == env56670) = true)

theorem identity56670 : scanCanonicalize (H12AffineFastState.compose env56670 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound56670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56671 : List Nat := [2,4,8,16,16,16,4,20,13,4,1,1,24,1,0,18,0,23,5,1,0,28,17,2,21,17,27,0,0,1,21,17,20,17,0,13]

theorem envBound56671 : H12AffineFastState.Bounded env56671 := by
  intro p hp
  have h : env56671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56670_56671 : H12AffineEnvironment.transform 6 4 env56670 = env56671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env56670 == env56671) = true)

theorem identity56671 : scanCanonicalize (H12AffineFastState.compose env56671 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56672 : List Nat := [2,4,4,16,16,16,4,20,1,4,1,1,20,1,0,18,0,23,5,1,0,16,17,2,21,17,23,0,0,1,21,17,20,17,0,1]

theorem envBound56672 : H12AffineFastState.Bounded env56672 := by
  intro p hp
  have h : env56672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56671_56672 : H12AffineEnvironment.transform 2 4 env56671 = env56672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56671 == env56672) = true)

theorem identity56672 : scanCanonicalize (H12AffineFastState.compose env56672 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound56672 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56673 : List Nat := [2,4,4,7,7,7,4,3,1,4,1,1,3,1,0,5,0,0,5,1,0,7,6,2,2,6,0,0,0,1,2,6,3,6,0,1]

theorem envBound56673 : H12AffineFastState.Bounded env56673 := by
  intro p hp
  have h : env56673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56672_56673 : H12AffineEnvironment.transform 3 7 env56672 = env56673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env56672 == env56673) = true)

def env56674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245633,148801,545089,96346,16876545,618623,256,16876548,1345,525825]

theorem envBound56674 : H12AffineFastState.Bounded env56674 := by
  intro p hp
  have h : env56674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56002_56674 : H12AffineEnvironment.transform 26 17245633 env56002 = env56674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env56002 == env56674) = true)

theorem identity56674 : scanCanonicalize (H12AffineFastState.compose env56674 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound56674 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86518,209263,17245633,148801,74815,96346,16876545,1281,256,16876548,1345,95103]

theorem envBound56675 : H12AffineFastState.Bounded env56675 := by
  intro p hp
  have h : env56675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56674_56675 : H12AffineEnvironment.transform 18 95614 env56674 = env56675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env56674 == env56675) = true)

def env56676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86518,209263,225345,148801,74815,96346,381313,1281,256,381316,1345,95103]

theorem envBound56676 : H12AffineFastState.Bounded env56676 := by
  intro p hp
  have h : env56676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56675_56676 : H12AffineEnvironment.transform 23 284032 env56675 = env56676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env56675 == env56676) = true)

def env56677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86518,94527,77841,1297,74815,96346,381313,1281,256,381316,1345,95103]

theorem envBound56677 : H12AffineFastState.Bounded env56677 := by
  intro p hp
  have h : env56677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56676_56677 : H12AffineEnvironment.transform 16 16464 env56676 = env56677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env56676 == env56677) = true)

def env56678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70886,78895,77841,1297,74815,81226,365713,1281,256,365716,1345,79471]

theorem envBound56678 : H12AffineFastState.Bounded env56678 := by
  intro p hp
  have h : env56678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56677_56678 : H12AffineEnvironment.transform 13 1296 env56677 = env56678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56677 == env56678) = true)

theorem identity56678 : scanCanonicalize (H12AffineFastState.compose env56678 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound56678 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,16,266384,38036,46173,45155,1297,42061,48440,267491,1281,256,267494,1345,46621]

theorem envBound56679 : H12AffineFastState.Bounded env56679 := by
  intro p hp
  have h : env56679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56678_56679 : H12AffineEnvironment.transform 15 32882 env56678 = env56679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env56678 == env56679) = true)

def env56680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263632,33236,41245,42275,1297,42061,43128,262563,1281,256,262566,1345,41821]

theorem envBound56680 : H12AffineFastState.Bounded env56680 := by
  intro p hp
  have h : env56680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56679_56680 : H12AffineEnvironment.transform 11 1344 env56679 = env56680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env56679 == env56680) = true)

theorem identity56680 : scanCanonicalize (H12AffineFastState.compose env56680 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound56680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9244,9326,1344,262144,320,9245,1345,1180,16,263632,9672,1281,319,1297,81,3172,262563,1281,256,262566,1345,1857]

theorem envBound56681 : H12AffineFastState.Bounded env56681 := by
  intro p hp
  have h : env56681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56680_56681 : H12AffineEnvironment.transform 14 9244 env56680 = env56681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env56680 == env56681) = true)

theorem identity56681 : scanCanonicalize (H12AffineFastState.compose env56681 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound56681 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56682 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8495,1,262144,320,8540,0,477,16,262289,8329,64,319,80,81,2341,262563,64,256,262566,0,512]

theorem envBound56682 : H12AffineFastState.Bounded env56682 := by
  intro p hp
  have h : env56682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56681_56682 : H12AffineEnvironment.transform 9 321 env56681 = env56682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56681 == env56682) = true)

theorem identity56682 : scanCanonicalize (H12AffineFastState.compose env56682 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound56682 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56683 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8495,1,242,320,8540,0,477,16,99,8329,64,319,80,81,2341,337,64,256,340,0,512]

theorem envBound56683 : H12AffineFastState.Bounded env56683 := by
  intro p hp
  have h : env56683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56682_56683 : H12AffineEnvironment.transform 17 242 env56682 = env56683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env56682 == env56683) = true)

theorem identity56683 : scanCanonicalize (H12AffineFastState.compose env56683 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound56683 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56684 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,901,81,728,682,1,242,320,729,0,477,16,99,780,64,319,80,81,2341,337,64,256,340,0,512]

theorem envBound56684 : H12AffineFastState.Bounded env56684 := by
  intro p hp
  have h : env56684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56683_56684 : H12AffineEnvironment.transform 12 901 env56683 = env56684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env56683 == env56684) = true)

theorem identity56684 : scanCanonicalize (H12AffineFastState.compose env56684 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56684 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56685 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,901,1,648,682,1,162,272,649,0,397,16,51,780,16,319,0,1,2341,257,16,256,260,0,512]

theorem envBound56685 : H12AffineFastState.Bounded env56685 := by
  intro p hp
  have h : env56685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56684_56685 : H12AffineEnvironment.transform 5 16 env56684 = env56685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56684 == env56685) = true)

theorem identity56685 : scanCanonicalize (H12AffineFastState.compose env56685 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound56685 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env56686 : List Nat := [2,4,8,16,32,16,56,256,512,273,2048,1,829,1,560,530,1,26,272,561,0,309,16,51,780,16,319,0,1,2341,257,16,256,260,0,512]

theorem envBound56686 : H12AffineFastState.Bounded env56686 := by
  intro p hp
  have h : env56686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56685_56686 : H12AffineEnvironment.transform 6 56 env56685 = env56686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env56685 == env56686) = true)

theorem identity56686 : scanCanonicalize (H12AffineFastState.compose env56686 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound56686 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56687 : List Nat := [2,4,8,16,32,16,56,256,512,273,561,1,829,1,560,530,1,26,272,561,0,309,16,51,780,16,319,0,1,788,257,16,256,260,0,512]

theorem envBound56687 : H12AffineFastState.Bounded env56687 := by
  intro p hp
  have h : env56687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56686_56687 : H12AffineEnvironment.transform 10 561 env56686 = env56687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env56686 == env56687) = true)

theorem identity56687 : scanCanonicalize (H12AffineFastState.compose env56687 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound56687 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56688 : List Nat := [2,4,8,16,32,16,56,256,319,273,270,1,2,1,271,301,1,26,272,270,0,309,16,51,51,16,319,0,1,43,257,16,256,260,0,319]

theorem envBound56688 : H12AffineFastState.Bounded env56688 := by
  intro p hp
  have h : env56688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56687_56688 : H12AffineEnvironment.transform 8 319 env56687 = env56688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env56687 == env56688) = true)

theorem identity56688 : scanCanonicalize (H12AffineFastState.compose env56688 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56688 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env56689 : List Nat := [2,4,8,16,32,16,56,14,49,31,0,1,2,1,1,35,1,26,30,0,0,59,16,51,51,16,49,0,1,43,15,16,14,10,0,49]

theorem envBound56689 : H12AffineFastState.Bounded env56689 := by
  intro p hp
  have h : env56689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56688_56689 : H12AffineEnvironment.transform 7 14 env56688 = env56689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56688 == env56689) = true)

theorem identity56689 : scanCanonicalize (H12AffineFastState.compose env56689 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56689 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56690 : List Nat := [2,4,8,16,17,16,9,14,0,31,0,1,2,1,1,18,1,26,30,0,0,10,16,2,2,16,0,0,1,26,15,16,14,10,0,0]

theorem envBound56690 : H12AffineFastState.Bounded env56690 := by
  intro p hp
  have h : env56690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56689_56690 : H12AffineEnvironment.transform 4 17 env56689 = env56690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56689 == env56690) = true)

theorem identity56690 : scanCanonicalize (H12AffineFastState.compose env56690 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56690 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56691 : List Nat := [2,4,8,11,10,11,9,14,0,4,0,1,2,1,1,9,1,1,5,0,0,10,11,2,2,11,0,0,1,1,15,11,14,10,0,0]

theorem envBound56691 : H12AffineFastState.Bounded env56691 := by
  intro p hp
  have h : env56691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56690_56691 : H12AffineEnvironment.transform 3 11 env56690 = env56691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56690 == env56691) = true)

theorem identity56691 : scanCanonicalize (H12AffineFastState.compose env56691 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56691 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56692 : List Nat := [2,4,4,7,6,7,5,2,0,4,0,1,2,1,1,5,1,1,5,0,0,6,7,2,2,7,0,0,1,1,3,7,2,6,0,0]

theorem envBound56692 : H12AffineFastState.Bounded env56692 := by
  intro p hp
  have h : env56692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56691_56692 : H12AffineEnvironment.transform 2 4 env56691 = env56692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56691 == env56692) = true)

def env56693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263633,33237,41244,42274,1297,42061,43129,262562,1281,256,262567,1345,41820]

theorem envBound56693 : H12AffineFastState.Bounded env56693 := by
  intro p hp
  have h : env56693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56679_56693 : H12AffineEnvironment.transform 11 1345 env56679 = env56693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env56679 == env56693) = true)

theorem identity56693 : scanCanonicalize (H12AffineFastState.compose env56693 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound56693 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,9455,42333,32769,1344,41089,16,8510,33237,41244,42274,1297,42061,43129,9549,1281,256,9544,1345,41820]

theorem envBound56694 : H12AffineFastState.Bounded env56694 := by
  intro p hp
  have h : env56694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56693_56694 : H12AffineEnvironment.transform 17 9455 env56693 = env56694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env56693 == env56694) = true)

theorem identity56694 : scanCanonicalize (H12AffineFastState.compose env56694 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 4019) := by decide +kernel

theorem selectedBound56694 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env56695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,4019,4033,1344,9455,10990,4018,1344,12082,16,8510,3686,11951,10897,1297,11262,10186,9549,1281,256,9544,1345,11503]

theorem envBound56695 : H12AffineFastState.Bounded env56695 := by
  intro p hp
  have h : env56695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56694_56695 : H12AffineEnvironment.transform 14 4019 env56694 = env56695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4019 env56694 == env56695) = true)

def env56696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70887,78894,77841,1297,74815,81227,365712,1281,256,365717,1345,79470]

theorem envBound56696 : H12AffineFastState.Bounded env56696 := by
  intro p hp
  have h : env56696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56677_56696 : H12AffineEnvironment.transform 13 1297 env56677 = env56696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56677 == env56696) = true)

theorem identity56696 : scanCanonicalize (H12AffineFastState.compose env56696 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56696 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,16,266385,70887,78894,77841,1297,74815,81227,336012,1281,256,336009,1345,79470]

theorem envBound56697 : H12AffineFastState.Bounded env56697 := by
  intro p hp
  have h : env56697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56696_56697 : H12AffineEnvironment.transform 14 13340 env56696 = env56697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56696 == env56697) = true)

def env56698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,16,69649,70887,78894,77841,1297,74815,81227,8204,1281,256,8201,1345,79470]

theorem envBound56698 : H12AffineFastState.Bounded env56698 := by
  intro p hp
  have h : env56698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56697_56698 : H12AffineEnvironment.transform 17 65664 env56697 = env56698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56697 == env56698) = true)

theorem identity56698 : scanCanonicalize (H12AffineFastState.compose env56698 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound56698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,65536,1345,65664,66919,277,4097,477,16,69649,70887,65830,66841,1297,69943,67651,5380,1281,256,5377,1345,66406]

theorem envBound56699 : H12AffineFastState.Bounded env56699 := by
  intro p hp
  have h : env56699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56698_56699 : H12AffineEnvironment.transform 12 5384 env56698 = env56699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env56698 == env56699) = true)

def env56700 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,65536,1297,65664,66871,277,4097,397,16,69649,70839,65830,66841,1297,69943,67603,5380,1281,256,5377,1297,66358]

theorem envBound56700 : H12AffineFastState.Bounded env56700 := by
  intro p hp
  have h : env56700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56699_56700 : H12AffineEnvironment.transform 5 16 env56699 = env56700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56699 == env56700) = true)

theorem identity56700 : scanCanonicalize (H12AffineFastState.compose env56700 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound56700 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56701 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,35,1297,163,1300,277,4097,397,16,4146,5268,261,1338,1297,4372,2096,5380,1281,256,5377,1297,789]

theorem envBound56701 : H12AffineFastState.Bounded env56701 := by
  intro p hp
  have h : env56701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56700_56701 : H12AffineEnvironment.transform 15 35 env56700 = env56701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env56700 == env56701) = true)

theorem identity56701 : scanCanonicalize (H12AffineFastState.compose env56701 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound56701 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env56702 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,269,1297,276,35,1297,163,1300,277,1028,397,16,1079,145,261,1338,1297,1297,2096,257,1281,256,260,1297,789]

theorem envBound56702 : H12AffineFastState.Bounded env56702 := by
  intro p hp
  have h : env56702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56701_56702 : H12AffineEnvironment.transform 11 1029 env56701 = env56702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env56701 == env56702) = true)

theorem identity56702 : scanCanonicalize (H12AffineFastState.compose env56702 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound56702 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env56703 : List Nat := [2,4,8,16,32,16,128,256,512,1024,277,1029,269,1297,276,35,1297,163,1300,277,1028,397,16,1079,145,261,1338,1297,1297,293,257,1281,256,260,1297,789]

theorem envBound56703 : H12AffineFastState.Bounded env56703 := by
  intro p hp
  have h : env56703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56702_56703 : H12AffineEnvironment.transform 10 277 env56702 = env56703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env56702 == env56703) = true)

theorem identity56703 : scanCanonicalize (H12AffineFastState.compose env56703 (packedSelected [1,2,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound56703 : packedSelected [1,2,8,10,15] rootPS < 2^1333 := by decide +kernel

def env56704 : List Nat := [2,4,8,16,32,16,128,256,512,784,277,789,269,513,276,35,513,163,516,277,788,397,16,807,145,261,554,513,513,293,257,529,256,260,513,789]

theorem envBound56704 : H12AffineFastState.Bounded env56704 := by
  intro p hp
  have h : env56704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56703_56704 : H12AffineEnvironment.transform 9 784 env56703 = env56704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env56703 == env56704) = true)

theorem identity56704 : scanCanonicalize (H12AffineFastState.compose env56704 (packedSelected [10,12] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound56704 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env56705 : List Nat := [2,4,8,16,32,16,128,256,413,141,277,136,269,412,276,35,412,163,409,277,137,397,16,186,145,261,439,412,412,293,257,396,256,260,412,136]

theorem envBound56705 : H12AffineFastState.Bounded env56705 := by
  intro p hp
  have h : env56705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56704_56705 : H12AffineEnvironment.transform 8 413 env56704 = env56705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env56704 == env56705) = true)

theorem identity56705 : scanCanonicalize (H12AffineFastState.compose env56705 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56705 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env56706 : List Nat := [2,4,8,16,10,16,128,256,413,141,277,136,269,412,276,9,412,137,409,277,137,397,16,144,145,261,413,412,412,271,257,396,256,260,412,136]

theorem envBound56706 : H12AffineFastState.Bounded env56706 := by
  intro p hp
  have h : env56706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56705_56706 : H12AffineEnvironment.transform 4 10 env56705 = env56706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56705 == env56706) = true)

theorem identity56706 : scanCanonicalize (H12AffineFastState.compose env56706 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound56706 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56707 : List Nat := [2,4,8,16,10,16,128,157,0,141,136,136,144,1,137,9,1,137,4,136,137,16,16,144,145,152,0,1,1,146,156,17,157,153,1,136]

theorem envBound56707 : H12AffineFastState.Bounded env56707 := by
  intro p hp
  have h : env56707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56706_56707 : H12AffineEnvironment.transform 7 157 env56706 = env56707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env56706 == env56707) = true)

theorem identity56707 : scanCanonicalize (H12AffineFastState.compose env56707 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56708 : List Nat := [2,4,8,10,10,10,128,135,0,141,136,136,138,1,137,9,1,137,4,136,137,10,10,138,139,130,0,1,1,136,134,11,135,131,1,136]

theorem envBound56708 : H12AffineFastState.Bounded env56708 := by
  intro p hp
  have h : env56708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56707_56708 : H12AffineEnvironment.transform 3 10 env56707 = env56708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56707 == env56708) = true)

def env56709 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65664,66870,277,4097,396,16,69649,70838,65830,66841,1297,69943,67602,5380,1281,256,5377,1296,66359]

theorem envBound56709 : H12AffineFastState.Bounded env56709 := by
  intro p hp
  have h : env56709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56699_56709 : H12AffineEnvironment.transform 5 17 env56699 = env56709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56699 == env56709) = true)

theorem identity56709 : scanCanonicalize (H12AffineFastState.compose env56709 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56709 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56710 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,5149,1028,1,65536,1029,65664,66595,0,4097,153,16,69649,70838,65587,66572,1028,69666,67602,5137,1044,21,5140,1029,66082]

theorem envBound56710 : H12AffineFastState.Bounded env56710 := by
  intro p hp
  have h : env56710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56709_56710 : H12AffineEnvironment.transform 7 21 env56709 = env56710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56709 == env56710) = true)

theorem identity56710 : scanCanonicalize (H12AffineFastState.compose env56710 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound56710 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56711 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,24,1028,1,65536,1029,65664,66595,0,1028,153,16,66580,65715,65587,66572,1028,66599,67602,20,1044,21,17,1029,66082]

theorem envBound56711 : H12AffineFastState.Bounded env56711 := by
  intro p hp
  have h : env56711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56710_56711 : H12AffineEnvironment.transform 11 1029 env56710 = env56711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env56710 == env56711) = true)

theorem identity56711 : scanCanonicalize (H12AffineFastState.compose env56711 (packedSelected [0,2,5,7,8,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound56711 : packedSelected [0,2,5,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env56712 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,24,1028,1,1183,1029,1055,188,0,1028,153,16,139,1068,1196,147,1028,184,3213,20,1044,21,17,1029,1725]

theorem envBound56712 : H12AffineFastState.Bounded env56712 := by
  intro p hp
  have h : env56712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56711_56712 : H12AffineEnvironment.transform 15 1183 env56711 = env56712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env56711 == env56712) = true)

theorem identity56712 : scanCanonicalize (H12AffineFastState.compose env56712 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound56712 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env56713 : List Nat := [2,4,8,16,32,17,128,21,512,1024,675,1029,24,1028,1,1183,1029,1055,188,0,1028,153,16,139,1068,1196,147,1028,184,1582,20,1044,21,17,1029,1725]

theorem envBound56713 : H12AffineFastState.Bounded env56713 := by
  intro p hp
  have h : env56713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56712_56713 : H12AffineEnvironment.transform 10 675 env56712 = env56713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env56712 == env56713) = true)

theorem identity56713 : scanCanonicalize (H12AffineFastState.compose env56713 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56713 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env56714 : List Nat := [2,4,8,16,32,17,128,21,512,4,675,1,24,0,1,155,1,27,188,0,0,153,16,139,40,168,147,0,184,554,20,16,21,17,1,697]

theorem envBound56714 : H12AffineFastState.Bounded env56714 := by
  intro p hp
  have h : env56714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56713_56714 : H12AffineEnvironment.transform 9 4 env56713 = env56714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56713 == env56714) = true)

theorem identity56714 : scanCanonicalize (H12AffineFastState.compose env56714 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56714 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56715 : List Nat := [2,4,8,16,32,17,9,21,512,4,554,1,24,0,1,18,1,27,53,0,0,16,16,2,40,33,26,0,49,554,20,16,21,17,1,560]

theorem envBound56715 : H12AffineFastState.Bounded env56715 := by
  intro p hp
  have h : env56715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56714_56715 : H12AffineEnvironment.transform 6 9 env56714 = env56715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56714 == env56715) = true)

theorem identity56715 : scanCanonicalize (H12AffineFastState.compose env56715 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56715 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56716 : List Nat := [2,4,8,16,11,17,9,21,512,4,513,1,24,0,1,18,1,27,30,0,0,16,16,2,3,10,26,0,26,513,20,16,21,17,1,539]

theorem envBound56716 : H12AffineFastState.Bounded env56716 := by
  intro p hp
  have h : env56716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56715_56716 : H12AffineEnvironment.transform 4 11 env56715 = env56716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56715 == env56716) = true)

theorem identity56716 : scanCanonicalize (H12AffineFastState.compose env56716 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound56716 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56717 : List Nat := [2,4,8,16,11,17,9,21,28,4,29,1,24,0,1,18,1,27,30,0,0,16,16,2,3,10,26,0,26,29,20,16,21,17,1,7]

theorem envBound56717 : H12AffineFastState.Bounded env56717 := by
  intro p hp
  have h : env56717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56716_56717 : H12AffineEnvironment.transform 8 28 env56716 = env56717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env56716 == env56717) = true)

theorem identity56717 : scanCanonicalize (H12AffineFastState.compose env56717 (packedSelected [1,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56717 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env56718 : List Nat := [2,3,8,16,11,17,9,18,27,3,26,1,24,0,1,18,1,27,25,0,0,16,16,2,3,10,26,0,26,26,19,16,18,17,1,0]

theorem envBound56718 : H12AffineFastState.Bounded env56718 := by
  intro p hp
  have h : env56718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56717_56718 : H12AffineEnvironment.transform 1 3 env56717 = env56718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56717 == env56718) = true)

theorem identity56718 : scanCanonicalize (H12AffineFastState.compose env56718 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56718 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56719 : List Nat := [2,3,8,11,11,10,9,9,0,3,1,1,3,0,1,9,1,0,2,0,0,11,11,2,3,10,1,0,1,1,8,11,9,10,1,0]

theorem envBound56719 : H12AffineFastState.Bounded env56719 := by
  intro p hp
  have h : env56719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56718_56719 : H12AffineEnvironment.transform 3 11 env56718 = env56719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56718 == env56719) = true)

def env56720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,16,69648,70887,78894,77841,1297,74815,81227,8205,1281,256,8200,1345,79470]

theorem envBound56720 : H12AffineFastState.Bounded env56720 := by
  intro p hp
  have h : env56720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56697_56720 : H12AffineEnvironment.transform 17 65665 env56697 = env56720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56697 == env56720) = true)

theorem identity56720 : scanCanonicalize (H12AffineFastState.compose env56720 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound56720 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,65536,1345,65665,69670,5204,4097,477,16,69648,70887,70759,69720,1297,66678,72962,68,1281,256,65,1345,71207]

theorem envBound56721 : H12AffineFastState.Bounded env56721 := by
  intro p hp
  have h : env56721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56720_56721 : H12AffineEnvironment.transform 12 73 env56720 = env56721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56720 == env56721) = true)

def env56722 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,65536,1297,65665,69670,5124,4097,397,16,69648,70839,70711,69640,1297,66598,72962,20,1281,256,17,1297,71207]

theorem envBound56722 : H12AffineFastState.Bounded env56722 := by
  intro p hp
  have h : env56722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56721_56722 : H12AffineEnvironment.transform 5 16 env56721 = env56722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56721 == env56722) = true)

theorem identity56722 : scanCanonicalize (H12AffineFastState.compose env56722 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound56722 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56723 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,34,1297,163,4100,5124,4097,397,16,4146,5269,5141,4138,1297,1028,7456,20,1281,256,17,1297,5637]

theorem envBound56723 : H12AffineFastState.Bounded env56723 := by
  intro p hp
  have h : env56723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56722_56723 : H12AffineEnvironment.transform 15 34 env56722 = env56723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env56722 == env56723) = true)

theorem identity56723 : scanCanonicalize (H12AffineFastState.compose env56723 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound56723 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env56724 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,25,1297,277,34,1297,163,1300,276,1297,397,16,1314,389,261,1338,1297,1028,2096,20,1281,256,17,1297,789]

theorem envBound56724 : H12AffineFastState.Bounded env56724 := by
  intro p hp
  have h : env56724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56723_56724 : H12AffineEnvironment.transform 11 1296 env56723 = env56724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env56723 == env56724) = true)

theorem identity56724 : scanCanonicalize (H12AffineFastState.compose env56724 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound56724 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env56725 : List Nat := [2,4,8,16,32,16,128,157,512,1024,2048,1165,25,1164,136,34,1164,163,1161,137,1164,16,16,1215,24,152,1191,1164,1028,2096,20,1180,157,17,1164,648]

theorem envBound56725 : H12AffineFastState.Bounded env56725 := by
  intro p hp
  have h : env56725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56724_56725 : H12AffineEnvironment.transform 7 157 env56724 = env56725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env56724 == env56725) = true)

theorem identity56725 : scanCanonicalize (H12AffineFastState.compose env56725 (packedSelected [2,5,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1725) := by decide +kernel

theorem selectedBound56725 : packedSelected [2,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env56726 : List Nat := [2,4,8,16,32,16,128,157,512,1024,1725,1165,25,1164,136,34,1164,163,1161,137,1164,16,16,1215,24,152,1191,1164,1028,1677,20,1180,157,17,1164,648]

theorem envBound56726 : H12AffineFastState.Bounded env56726 := by
  intro p hp
  have h : env56726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56725_56726 : H12AffineEnvironment.transform 10 1725 env56725 = env56726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1725 env56725 == env56726) = true)

theorem identity56726 : scanCanonicalize (H12AffineFastState.compose env56726 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56726 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env56727 : List Nat := [2,4,8,16,10,16,128,157,512,1024,1687,1165,25,1164,136,8,1164,137,1161,137,1164,16,16,1173,24,152,1165,1164,1028,1677,20,1180,157,17,1164,648]

theorem envBound56727 : H12AffineFastState.Bounded env56727 := by
  intro p hp
  have h : env56727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56726_56727 : H12AffineEnvironment.transform 4 10 env56726 = env56727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56726 == env56727) = true)

def env56728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,65536,1296,65665,69670,5125,4097,396,16,69648,70838,70710,69641,1297,66599,72962,21,1281,256,16,1296,71207]

theorem envBound56728 : H12AffineFastState.Bounded env56728 := by
  intro p hp
  have h : env56728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56721_56728 : H12AffineEnvironment.transform 5 17 env56721 = env56728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56721 == env56728) = true)

theorem identity56728 : scanCanonicalize (H12AffineFastState.compose env56728 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56728 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56729 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,24,1297,0,65536,1296,65665,66594,1,1029,396,16,66580,65714,65586,66573,1297,66599,67846,21,1281,256,16,1296,66083]

theorem envBound56729 : H12AffineFastState.Bounded env56729 := by
  intro p hp
  have h : env56729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56728_56729 : H12AffineEnvironment.transform 11 1028 env56728 = env56729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56728 == env56729) = true)

theorem identity56729 : scanCanonicalize (H12AffineFastState.compose env56729 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound56729 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56730 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,24,1297,0,311,1296,438,1301,1,1029,396,16,1315,389,261,1338,1297,1296,2097,21,1281,256,16,1296,788]

theorem envBound56730 : H12AffineFastState.Bounded env56730 := by
  intro p hp
  have h : env56730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56729_56730 : H12AffineEnvironment.transform 15 311 env56729 = env56730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env56729 == env56730) = true)

theorem identity56730 : scanCanonicalize (H12AffineFastState.compose env56730 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound56730 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env56731 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1541,1028,24,1297,0,311,1296,438,1301,1,1029,396,16,1315,389,261,1338,1297,1296,1588,21,1281,256,16,1296,788]

theorem envBound56731 : H12AffineFastState.Bounded env56731 := by
  intro p hp
  have h : env56731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56730_56731 : H12AffineEnvironment.transform 10 1541 env56730 = env56731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env56730 == env56731) = true)

theorem identity56731 : scanCanonicalize (H12AffineFastState.compose env56731 (packedSelected [0,3,5,7,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound56731 : packedSelected [0,3,5,7,13,18] rootPS < 2^1333 := by decide +kernel

def env56732 : List Nat := [2,4,8,16,32,17,35,256,512,1024,1541,1028,24,1297,0,311,1296,277,1301,1,1029,303,16,1315,294,261,1338,1297,1296,1588,21,1281,256,16,1296,788]

theorem envBound56732 : H12AffineFastState.Bounded env56732 := by
  intro p hp
  have h : env56732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56731_56732 : H12AffineEnvironment.transform 6 35 env56731 = env56732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env56731 == env56732) = true)

theorem identity56732 : scanCanonicalize (H12AffineFastState.compose env56732 (packedSelected [0,2,3,5,7,10,11,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound56732 : packedSelected [0,2,3,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env56733 : List Nat := [2,4,8,16,32,17,35,256,271,1024,1290,1028,24,1297,0,311,1296,277,1301,1,1029,303,16,1315,294,261,1338,1297,1296,1339,21,1281,256,16,1296,27]

theorem envBound56733 : H12AffineFastState.Bounded env56733 := by
  intro p hp
  have h : env56733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56732_56733 : H12AffineEnvironment.transform 8 271 env56732 = env56733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env56732 == env56733) = true)

theorem identity56733 : scanCanonicalize (H12AffineFastState.compose env56733 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound56733 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env56734 : List Nat := [2,4,8,16,32,17,35,256,271,289,43,293,24,48,0,311,49,277,52,1,292,303,16,2,294,261,27,48,49,26,21,32,256,16,49,27]

theorem envBound56734 : H12AffineFastState.Bounded env56734 := by
  intro p hp
  have h : env56734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56733_56734 : H12AffineEnvironment.transform 9 289 env56733 = env56734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env56733 == env56734) = true)

theorem identity56734 : scanCanonicalize (H12AffineFastState.compose env56734 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56734 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56735 : List Nat := [2,4,8,16,32,17,35,36,43,5,43,1,24,48,0,19,49,49,52,1,0,11,16,2,2,33,27,48,49,26,21,32,36,16,49,27]

theorem envBound56735 : H12AffineFastState.Bounded env56735 := by
  intro p hp
  have h : env56735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56734_56735 : H12AffineEnvironment.transform 7 36 env56734 = env56735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56734 == env56735) = true)

theorem identity56735 : scanCanonicalize (H12AffineFastState.compose env56735 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56735 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56736 : List Nat := [2,4,8,16,11,17,8,15,0,5,0,1,24,27,0,19,26,26,31,1,0,11,16,2,2,10,27,27,26,26,21,11,15,16,26,27]

theorem envBound56736 : H12AffineFastState.Bounded env56736 := by
  intro p hp
  have h : env56736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56735_56736 : H12AffineEnvironment.transform 4 11 env56735 = env56736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56735 == env56736) = true)

theorem identity56736 : scanCanonicalize (H12AffineFastState.compose env56736 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56736 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56737 : List Nat := [2,4,8,11,11,10,8,15,0,5,0,1,3,0,0,8,1,1,4,1,0,11,11,2,2,10,0,0,1,1,14,11,15,11,1,0]

theorem envBound56737 : H12AffineFastState.Bounded env56737 := by
  intro p hp
  have h : env56737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56736_56737 : H12AffineEnvironment.transform 3 11 env56736 = env56737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56736 == env56737) = true)

theorem identity56737 : scanCanonicalize (H12AffineFastState.compose env56737 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56738 : List Nat := [2,4,5,6,6,7,5,2,0,5,0,1,3,0,0,5,1,1,4,1,0,6,6,2,2,7,0,0,1,1,3,6,2,6,1,0]

theorem envBound56738 : H12AffineFastState.Bounded env56738 := by
  intro p hp
  have h : env56738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56737_56738 : H12AffineEnvironment.transform 2 5 env56737 = env56738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56737 == env56738) = true)

def env56739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86518,94526,77840,1296,74815,96346,381313,1281,256,381316,1345,95103]

theorem envBound56739 : H12AffineFastState.Bounded env56739 := by
  intro p hp
  have h : env56739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56676_56739 : H12AffineEnvironment.transform 16 16465 env56676 = env56739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env56676 == env56739) = true)

def env56740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70886,78894,77840,1296,74815,81226,365713,1281,256,365716,1345,79471]

theorem envBound56740 : H12AffineFastState.Bounded env56740 := by
  intro p hp
  have h : env56740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56739_56740 : H12AffineEnvironment.transform 13 1296 env56739 = env56740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56739 == env56740) = true)

theorem identity56740 : scanCanonicalize (H12AffineFastState.compose env56740 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56740 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,17,266384,70886,78894,77840,1296,74815,81226,336013,1281,256,336008,1345,79471]

theorem envBound56741 : H12AffineFastState.Bounded env56741 := by
  intro p hp
  have h : env56741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56740_56741 : H12AffineEnvironment.transform 14 13340 env56740 = env56741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56740 == env56741) = true)

def env56742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,17,69648,70886,78894,77840,1296,74815,81226,8205,1281,256,8200,1345,79471]

theorem envBound56742 : H12AffineFastState.Bounded env56742 := by
  intro p hp
  have h : env56742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56741_56742 : H12AffineEnvironment.transform 17 65664 env56741 = env56742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56741 == env56742) = true)

theorem identity56742 : scanCanonicalize (H12AffineFastState.compose env56742 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound56742 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56743 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,65536,1,65664,77934,12637,4097,476,17,69648,70054,78190,77840,80,74111,79882,8205,65,256,8200,1,78639]

theorem envBound56743 : H12AffineFastState.Bounded env56743 := by
  intro p hp
  have h : env56743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56742_56743 : H12AffineEnvironment.transform 9 320 env56742 = env56743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56742 == env56743) = true)

def env56744 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,65536,1,65664,77886,12557,4097,396,17,69648,70054,78142,77840,0,74031,79882,8205,17,256,8200,1,78639]

theorem envBound56744 : H12AffineFastState.Bounded env56744 := by
  intro p hp
  have h : env56744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56743_56744 : H12AffineEnvironment.transform 5 16 env56743 = env56744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56743 == env56744) = true)

theorem identity56744 : scanCanonicalize (H12AffineFastState.compose env56744 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound56744 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56745 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,4365,0,1,65536,1,65664,65843,0,4097,396,17,69648,70054,65587,65821,0,69666,67847,4352,17,256,4357,1,66082]

theorem envBound56745 : H12AffineFastState.Bounded env56745 := by
  intro p hp
  have h : env56745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56744_56745 : H12AffineEnvironment.transform 12 4365 env56744 = env56745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env56744 == env56745) = true)

theorem identity56745 : scanCanonicalize (H12AffineFastState.compose env56745 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound56745 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56746 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,4365,0,1,4131,1,4259,4368,0,4097,396,17,51,389,4112,4414,0,1,6436,4352,17,256,4357,1,4609]

theorem envBound56746 : H12AffineFastState.Bounded env56746 := by
  intro p hp
  have h : env56746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56745_56746 : H12AffineEnvironment.transform 15 4131 env56745 = env56746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env56745 == env56746) = true)

theorem identity56746 : scanCanonicalize (H12AffineFastState.compose env56746 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound56746 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env56747 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,292,41,0,1,263,1,391,52,0,293,396,17,51,389,308,26,0,1,2048,36,17,256,33,1,805]

theorem envBound56747 : H12AffineFastState.Bounded env56747 := by
  intro p hp
  have h : env56747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56746_56747 : H12AffineEnvironment.transform 11 292 env56746 = env56747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env56746 == env56747) = true)

theorem identity56747 : scanCanonicalize (H12AffineFastState.compose env56747 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound56747 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56748 : List Nat := [2,4,8,16,32,16,128,134,512,150,2048,162,41,0,1,129,1,1,52,0,163,10,17,51,3,178,26,0,1,2048,36,17,134,33,1,675]

theorem envBound56748 : H12AffineFastState.Bounded env56748 := by
  intro p hp
  have h : env56748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56747_56748 : H12AffineEnvironment.transform 7 134 env56747 = env56748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env56747 == env56748) = true)

theorem identity56748 : scanCanonicalize (H12AffineFastState.compose env56748 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound56748 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env56749 : List Nat := [2,4,8,16,32,16,128,134,512,150,560,162,41,0,1,129,1,1,52,0,163,10,17,51,3,178,26,0,1,560,36,17,134,33,1,675]

theorem envBound56749 : H12AffineFastState.Bounded env56749 := by
  intro p hp
  have h : env56749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56748_56749 : H12AffineEnvironment.transform 10 560 env56748 = env56749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env56748 == env56749) = true)

theorem identity56749 : scanCanonicalize (H12AffineFastState.compose env56749 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56749 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56750 : List Nat := [2,4,8,16,32,16,8,14,512,30,560,42,41,0,1,9,1,1,52,0,43,10,17,51,3,58,26,0,1,560,36,17,14,33,1,555]

theorem envBound56750 : H12AffineFastState.Bounded env56750 := by
  intro p hp
  have h : env56750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56749_56750 : H12AffineEnvironment.transform 6 8 env56749 = env56750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56749 == env56750) = true)

theorem identity56750 : scanCanonicalize (H12AffineFastState.compose env56750 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56750 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56751 : List Nat := [2,4,8,16,32,16,8,14,48,30,0,42,41,0,1,9,1,1,52,0,43,10,17,51,3,58,26,0,1,0,36,17,14,33,1,27]

theorem envBound56751 : H12AffineFastState.Bounded env56751 := by
  intro p hp
  have h : env56751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56750_56751 : H12AffineEnvironment.transform 8 48 env56750 = env56751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56750 == env56751) = true)

theorem identity56751 : scanCanonicalize (H12AffineFastState.compose env56751 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56751 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56752 : List Nat := [2,4,8,16,10,16,8,14,26,30,0,0,3,0,1,9,1,1,30,0,1,10,17,25,3,16,26,0,1,0,14,17,14,11,1,27]

theorem envBound56752 : H12AffineFastState.Bounded env56752 := by
  intro p hp
  have h : env56752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56751_56752 : H12AffineEnvironment.transform 4 10 env56751 = env56752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56751 == env56752) = true)

theorem identity56752 : scanCanonicalize (H12AffineFastState.compose env56752 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56752 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56753 : List Nat := [2,4,0,16,2,16,0,6,18,22,0,0,3,0,1,1,1,1,22,0,1,2,17,17,3,16,18,0,1,0,6,17,6,3,1,19]

theorem envBound56753 : H12AffineFastState.Bounded env56753 := by
  intro p hp
  have h : env56753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56752_56753 : H12AffineEnvironment.transform 2 0 env56752 = env56753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56752 == env56753) = true)

theorem identity56753 : scanCanonicalize (H12AffineFastState.compose env56753 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56753 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56754 : List Nat := [0,4,0,16,0,16,0,4,16,20,0,0,1,0,1,1,1,1,20,0,1,0,17,17,1,16,16,0,1,0,4,17,4,1,1,17]

theorem envBound56754 : H12AffineFastState.Bounded env56754 := by
  intro p hp
  have h : env56754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56753_56754 : H12AffineEnvironment.transform 0 0 env56753 = env56754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56753 == env56754) = true)

theorem identity56754 : scanCanonicalize (H12AffineFastState.compose env56754 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound56754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56755 : List Nat := [0,1,0,16,0,16,0,1,16,17,0,0,1,0,1,1,1,1,17,0,1,0,17,17,1,16,16,0,1,0,1,17,1,1,1,17]

theorem envBound56755 : H12AffineFastState.Bounded env56755 := by
  intro p hp
  have h : env56755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56754_56755 : H12AffineEnvironment.transform 1 1 env56754 = env56755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env56754 == env56755) = true)

theorem identity56755 : scanCanonicalize (H12AffineFastState.compose env56755 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56755 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56756 : List Nat := [0,1,0,1,0,1,0,1,1,0,0,0,1,0,1,1,1,1,0,0,1,0,0,0,1,1,1,0,1,0,1,0,1,1,1,0]

theorem envBound56756 : H12AffineFastState.Bounded env56756 := by
  intro p hp
  have h : env56756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56755_56756 : H12AffineEnvironment.transform 3 1 env56755 = env56756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56755 == env56756) = true)

def env56757 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,65536,1,65664,77887,12556,4097,397,17,69648,70054,78143,77840,1,74030,79882,8205,16,256,8200,1,78639]

theorem envBound56757 : H12AffineFastState.Bounded env56757 := by
  intro p hp
  have h : env56757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56743_56757 : H12AffineEnvironment.transform 5 17 env56743 = env56757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56743 == env56757) = true)

theorem identity56757 : scanCanonicalize (H12AffineFastState.compose env56757 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound56757 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56758 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,35,1,163,12316,12556,4097,397,17,4147,4485,12572,12339,1,8461,14377,8205,16,256,8200,1,13068]

theorem envBound56758 : H12AffineFastState.Bounded env56758 := by
  intro p hp
  have h : env56758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56757_56758 : H12AffineEnvironment.transform 15 35 env56757 = env56758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env56757 == env56758) = true)

theorem identity56758 : scanCanonicalize (H12AffineFastState.compose env56758 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound56758 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env56759 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,8461,35,1,163,8220,8460,1,397,17,51,389,8476,8243,1,8461,10281,8205,16,256,8200,1,8972]

theorem envBound56759 : H12AffineFastState.Bounded env56759 := by
  intro p hp
  have h : env56759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56758_56759 : H12AffineEnvironment.transform 11 0 env56758 = env56759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56758 == env56759) = true)

theorem identity56759 : scanCanonicalize (H12AffineFastState.compose env56759 (packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound56759 : packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56760 : List Nat := [2,4,8,16,32,17,128,256,146,273,2048,0,8192,1,8461,35,1,163,8220,8460,1,397,17,51,389,8476,8243,1,8461,10281,8205,16,256,8200,1,8606]

theorem envBound56760 : H12AffineFastState.Bounded env56760 := by
  intro p hp
  have h : env56760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56759_56760 : H12AffineEnvironment.transform 8 146 env56759 = env56760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env56759 == env56760) = true)

theorem identity56760 : scanCanonicalize (H12AffineFastState.compose env56760 (packedSelected [0,1,7,8,10,11,12,13,15,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56760 : packedSelected [0,1,7,8,10,11,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env56761 : List Nat := [2,4,8,16,16,17,128,256,146,273,2048,0,8192,1,8461,19,1,147,8220,8460,1,397,17,3,389,8476,8195,1,8461,10265,8205,16,256,8200,1,8606]

theorem envBound56761 : H12AffineFastState.Bounded env56761 := by
  intro p hp
  have h : env56761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56760_56761 : H12AffineEnvironment.transform 4 16 env56760 = env56761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56760 == env56761) = true)

theorem identity56761 : scanCanonicalize (H12AffineFastState.compose env56761 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound56761 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56762 : List Nat := [2,4,8,16,16,17,128,256,146,273,27,0,8192,1,8461,19,1,147,8220,8460,1,397,17,3,389,8476,8195,1,8461,8194,8205,16,256,8200,1,8606]

theorem envBound56762 : H12AffineFastState.Bounded env56762 := by
  intro p hp
  have h : env56762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56761_56762 : H12AffineEnvironment.transform 10 27 env56761 = env56762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env56761 == env56762) = true)

theorem identity56762 : scanCanonicalize (H12AffineFastState.compose env56762 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56762 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env56763 : List Nat := [2,4,8,16,16,17,128,20,146,5,27,0,8192,1,8217,19,1,147,8220,8216,1,153,17,3,145,8200,8195,1,8217,8194,8205,16,20,8200,1,8330]

theorem envBound56763 : H12AffineFastState.Bounded env56763 := by
  intro p hp
  have h : env56763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56762_56763 : H12AffineEnvironment.transform 7 20 env56762 = env56763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56762 == env56763) = true)

theorem identity56763 : scanCanonicalize (H12AffineFastState.compose env56763 (packedSelected [2,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound56763 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56764 : List Nat := [2,4,8,16,16,17,128,20,146,5,27,0,25,1,0,19,1,147,5,1,1,153,17,3,145,17,26,1,0,27,20,16,20,17,1,147]

theorem envBound56764 : H12AffineFastState.Bounded env56764 := by
  intro p hp
  have h : env56764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56763_56764 : H12AffineEnvironment.transform 12 25 env56763 = env56764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env56763 == env56764) = true)

theorem identity56764 : scanCanonicalize (H12AffineFastState.compose env56764 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 28) := by decide +kernel

theorem selectedBound56764 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56765 : List Nat := [2,4,8,16,16,17,28,20,14,5,27,0,25,1,0,19,1,15,5,1,1,5,17,3,13,17,26,1,0,27,20,16,20,17,1,15]

theorem envBound56765 : H12AffineFastState.Bounded env56765 := by
  intro p hp
  have h : env56765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56764_56765 : H12AffineEnvironment.transform 6 28 env56764 = env56765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 28 env56764 == env56765) = true)

theorem identity56765 : scanCanonicalize (H12AffineFastState.compose env56765 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56766 : List Nat := [2,2,8,16,16,17,26,18,8,3,27,0,25,1,0,19,1,9,3,1,1,3,17,3,11,17,26,1,0,27,18,16,18,17,1,9]

theorem envBound56766 : H12AffineFastState.Bounded env56766 := by
  intro p hp
  have h : env56766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2