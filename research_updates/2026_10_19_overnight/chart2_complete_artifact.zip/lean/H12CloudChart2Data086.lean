import H12CloudChart2Data085

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity21103 : scanCanonicalize (H12AffineFastState.compose env21103 (packedSelected [14] rootPS)) = affineNative (2^(18+1) ^^^ 151825) := by decide +kernel

theorem selectedBound21103 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env21104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4096,4194304,8388608,16777216,8328,8541504,134217728,8519745,1297,1073741824,25412673,4294967296,8536385,4315938986,163942417,512]

theorem envBound21104 : H12AffineFastState.Bounded env21104 := by
  intro p hp
  have h : env21104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21103_21104 : H12AffineEnvironment.transform 18 151825 env21103 = env21104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 151825 env21103 == env21104) = true)

def env21105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4096,4194304,147520,16777216,8328,5376,134217728,16385,1297,1073741824,16876545,4294967296,257,4315938986,155701329,512]

theorem envBound21105 : H12AffineFastState.Bounded env21105 := by
  intro p hp
  have h : env21105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21104_21105 : H12AffineEnvironment.transform 22 147520 env21104 = env21105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env21104 == env21105) = true)

def env21106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17664,16777216,8328,5376,134217728,16385,1297,1073741824,16876545,4294967296,257,4315938986,155571473,512]

theorem envBound21106 : H12AffineFastState.Bounded env21106 := by
  intro p hp
  have h : env21106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21105_21106 : H12AffineEnvironment.transform 16 1344 env21105 = env21106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env21105 == env21106) = true)

theorem identity21106 : scanCanonicalize (H12AffineFastState.compose env21106 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477269) := by decide +kernel

theorem selectedBound21106 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17664,16777216,8328,5376,4477269,16385,1297,1073741824,16876545,4294967296,257,4315938986,16876612,512]

theorem envBound21107 : H12AffineFastState.Bounded env21107 := by
  intro p hp
  have h : env21107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21106_21107 : H12AffineEnvironment.transform 26 4477269 env21106 = env21107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477269 env21106 == env21107) = true)

theorem identity21107 : scanCanonicalize (H12AffineFastState.compose env21107 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21107 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env21108 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21504,32769,4096,4194304,17664,16777216,8328,5376,4477188,16385,1297,1073741824,16876545,4294967296,257,4315938986,16876565,512]

theorem envBound21108 : H12AffineFastState.Bounded env21108 := by
  intro p hp
  have h : env21108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21107_21108 : H12AffineEnvironment.transform 5 17 env21107 = env21108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21107 == env21108) = true)

theorem identity21108 : scanCanonicalize (H12AffineFastState.compose env21108 (packedSelected [4,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound21108 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env21109 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,16777216,8328,5376,4456709,4096,1297,1073741824,16876545,4294967296,257,4315938986,16876565,512]

theorem envBound21109 : H12AffineFastState.Bounded env21109 := by
  intro p hp
  have h : env21109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21108_21109 : H12AffineEnvironment.transform 13 4097 env21108 = env21109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env21108 == env21109) = true)

theorem identity21109 : scanCanonicalize (H12AffineFastState.compose env21109 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1094789540) := by decide +kernel

theorem selectedBound21109 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env21110 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,16777216,8328,5376,4456709,4096,1297,1073741824,16876545,1094789540,257,1073817870,16876565,512]

theorem envBound21110 : H12AffineFastState.Bounded env21110 := by
  intro p hp
  have h : env21110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21109_21110 : H12AffineEnvironment.transform 31 1094789540 env21109 = env21110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1094789540 env21109 == env21110) = true)

def env21111 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,16777216,8328,5376,4456709,4096,1297,1073741824,16876545,1094789540,257,1073817870,16876565,136]

theorem envBound21111 : H12AffineFastState.Bounded env21111 := by
  intro p hp
  have h : env21111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21110_21111 : H12AffineEnvironment.transform 8 136 env21110 = env21111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21110 == env21111) = true)

theorem identity21111 : scanCanonicalize (H12AffineFastState.compose env21111 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(23+1) ^^^ 4499759) := by decide +kernel

theorem selectedBound21111 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env21112 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,4499759,8328,5376,4456709,4096,1297,1073741824,4533550,1074102411,257,1073817870,4533562,136]

theorem envBound21112 : H12AffineFastState.Bounded env21112 := by
  intro p hp
  have h : env21112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21111_21112 : H12AffineEnvironment.transform 23 4499759 env21111 = env21112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4499759 env21111 == env21112) = true)

def env21113 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13592,1025,32769,4096,4194304,5377,4234295,8328,5376,4207645,4096,1297,1073741824,4266038,1073853843,257,1073817870,4266018,136]

theorem envBound21113 : H12AffineFastState.Bounded env21113 := by
  intro p hp
  have h : env21113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21112_21113 : H12AffineEnvironment.transform 17 13592 env21112 = env21113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env21112 == env21113) = true)

theorem identity21113 : scanCanonicalize (H12AffineFastState.compose env21113 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 269) := by decide +kernel

theorem selectedBound21113 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21114 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,269,1297,13592,1025,32769,4096,4194304,5377,4234295,8328,5376,4207645,4096,1297,1073741824,4200763,1073788062,257,1073752067,4200751,136]

theorem envBound21114 : H12AffineFastState.Bounded env21114 := by
  intro p hp
  have h : env21114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21113_21114 : H12AffineEnvironment.transform 15 269 env21113 = env21114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 269 env21113 == env21114) = true)

def env21115 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,32768,269,1297,8460,1025,32769,1044,4194304,277,4229155,8328,276,4202505,1044,1297,1073741824,4197679,1073782922,257,1073752067,4197691,136]

theorem envBound21115 : H12AffineFastState.Bounded env21115 := by
  intro p hp
  have h : env21115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21114_21115 : H12AffineEnvironment.transform 11 1044 env21114 = env21115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env21114 == env21115) = true)

theorem identity21115 : scanCanonicalize (H12AffineFastState.compose env21115 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound21115 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21116 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,32768,269,1297,8460,1025,32769,1044,397,277,35246,8328,276,8580,1044,1297,1073741824,3234,1073782922,257,1073752067,3254,136]

theorem envBound21116 : H12AffineFastState.Bounded env21116 := by
  intro p hp
  have h : env21116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21115_21116 : H12AffineEnvironment.transform 21 397 env21115 = env21116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env21115 == env21116) = true)

def env21117 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,32,269,1297,8460,1025,33,1044,397,277,2446,8328,276,8580,1044,1297,1073741824,3234,1073750186,257,1073752067,3254,136]

theorem envBound21117 : H12AffineFastState.Bounded env21117 := by
  intro p hp
  have h : env21117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21116_21117 : H12AffineEnvironment.transform 14 32 env21116 = env21117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env21116 == env21117) = true)

theorem identity21117 : scanCanonicalize (H12AffineFastState.compose env21117 (packedSelected [3,8,10,11] rootPS)) = affineNative (2^(29+1) ^^^ 8362) := by decide +kernel

theorem selectedBound21117 : packedSelected [3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env21118 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,32,269,1297,8460,1025,33,1044,397,277,2446,8328,276,8580,1044,1297,8362,3234,0,257,2217,3254,136]

theorem envBound21118 : H12AffineFastState.Bounded env21118 := by
  intro p hp
  have h : env21118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21117_21118 : H12AffineEnvironment.transform 29 8362 env21117 = env21118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8362 env21117 == env21118) = true)

theorem identity21118 : scanCanonicalize (H12AffineFastState.compose env21118 (packedSelected [1,5,6,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound21118 : packedSelected [1,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21119 : List Nat := [2,4,8,16,32,17,128,256,136,1024,162,1044,8192,1045,32,269,1297,8460,1025,33,1044,397,277,300,8328,276,8580,1044,1297,8362,1024,0,257,11,1044,136]

theorem envBound21119 : H12AffineFastState.Bounded env21119 := by
  intro p hp
  have h : env21119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21118_21119 : H12AffineEnvironment.transform 10 162 env21118 = env21119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env21118 == env21119) = true)

theorem identity21119 : scanCanonicalize (H12AffineFastState.compose env21119 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound21119 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env21120 : List Nat := [2,4,8,16,32,17,35,256,43,1024,1,1044,8192,1045,32,269,1297,8460,1025,33,1044,302,277,300,8235,276,8487,1044,1297,8201,1024,0,257,11,1044,43]

theorem envBound21120 : H12AffineFastState.Bounded env21120 := by
  intro p hp
  have h : env21120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21119_21120 : H12AffineEnvironment.transform 6 35 env21119 = env21120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env21119 == env21120) = true)

theorem identity21120 : scanCanonicalize (H12AffineFastState.compose env21120 (packedSelected [0,1,3,4,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 295) := by decide +kernel

theorem selectedBound21120 : packedSelected [0,1,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env21121 : List Nat := [2,4,8,16,32,17,35,256,43,1024,1,1044,295,1045,32,269,1297,43,1025,33,1044,302,277,300,268,276,0,1044,1297,302,1024,0,257,11,1044,43]

theorem envBound21121 : H12AffineFastState.Bounded env21121 := by
  intro p hp
  have h : env21121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21120_21121 : H12AffineEnvironment.transform 12 295 env21120 = env21121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 295 env21120 == env21121) = true)

theorem identity21121 : scanCanonicalize (H12AffineFastState.compose env21121 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21121 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env21122 : List Nat := [2,4,2,16,32,17,35,256,33,1024,1,1044,295,1045,32,263,1297,33,1025,33,1044,292,277,294,262,276,0,1044,1297,292,1024,0,257,1,1044,33]

theorem envBound21122 : H12AffineFastState.Bounded env21122 := by
  intro p hp
  have h : env21122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21121_21122 : H12AffineEnvironment.transform 2 2 env21121 = env21122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21121 == env21122) = true)

theorem identity21122 : scanCanonicalize (H12AffineFastState.compose env21122 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21122 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21123 : List Nat := [2,4,2,16,32,17,35,256,33,273,1,261,295,260,32,263,0,33,272,33,261,292,277,294,262,276,0,261,0,292,273,0,257,1,261,33]

theorem envBound21123 : H12AffineFastState.Bounded env21123 := by
  intro p hp
  have h : env21123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21122_21123 : H12AffineEnvironment.transform 9 273 env21122 = env21123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21122 == env21123) = true)

theorem identity21123 : scanCanonicalize (H12AffineFastState.compose env21123 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21123 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21124 : List Nat := [2,4,2,16,0,17,3,256,1,273,1,261,263,260,0,263,0,1,272,1,261,260,277,262,262,276,0,261,0,260,273,0,257,1,261,1]

theorem envBound21124 : H12AffineFastState.Bounded env21124 := by
  intro p hp
  have h : env21124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21123_21124 : H12AffineEnvironment.transform 4 0 env21123 = env21124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21123 == env21124) = true)

def env21125 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,33,269,1297,8460,1025,32,1044,397,277,2447,8328,276,8580,1044,1297,1073741824,3234,1073750187,257,1073752067,3254,136]

theorem envBound21125 : H12AffineFastState.Bounded env21125 := by
  intro p hp
  have h : env21125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21116_21125 : H12AffineEnvironment.transform 14 33 env21116 = env21125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env21116 == env21125) = true)

theorem identity21125 : scanCanonicalize (H12AffineFastState.compose env21125 (packedSelected [3,8,10,11] rootPS)) = affineNative (2^(29+1) ^^^ 8200) := by decide +kernel

theorem selectedBound21125 : packedSelected [3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env21126 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1044,8192,1045,33,269,1297,8460,1025,32,1044,397,277,2447,8328,276,8580,1044,1297,8200,3234,163,257,2059,3254,136]

theorem envBound21126 : H12AffineFastState.Bounded env21126 := by
  intro p hp
  have h : env21126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21125_21126 : H12AffineEnvironment.transform 29 8200 env21125 = env21126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8200 env21125 == env21126) = true)

theorem identity21126 : scanCanonicalize (H12AffineFastState.compose env21126 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound21126 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env21127 : List Nat := [2,4,8,16,32,17,35,256,43,1024,2048,1044,8192,1045,33,269,1297,8460,1025,32,1044,302,277,2348,8235,276,8487,1044,1297,8200,3073,0,257,2059,3093,43]

theorem envBound21127 : H12AffineFastState.Bounded env21127 := by
  intro p hp
  have h : env21127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21126_21127 : H12AffineEnvironment.transform 6 35 env21126 = env21127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env21126 == env21127) = true)

theorem identity21127 : scanCanonicalize (H12AffineFastState.compose env21127 (packedSelected [1,5,6,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21127 : packedSelected [1,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21128 : List Nat := [2,4,8,16,32,17,35,256,43,1024,1,1044,8192,1045,33,269,1297,8460,1025,32,1044,302,277,301,8235,276,8487,1044,1297,8200,1024,0,257,10,1044,43]

theorem envBound21128 : H12AffineFastState.Bounded env21128 := by
  intro p hp
  have h : env21128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21127_21128 : H12AffineEnvironment.transform 10 1 env21127 = env21128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21127 == env21128) = true)

def env21129 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1045,8192,1044,32768,269,1297,8461,1025,32769,1045,4194304,276,4229154,8328,277,4202504,1045,1297,1073741824,4197678,1073782923,257,1073752067,4197690,136]

theorem envBound21129 : H12AffineFastState.Bounded env21129 := by
  intro p hp
  have h : env21129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21114_21129 : H12AffineEnvironment.transform 11 1045 env21114 = env21129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env21114 == env21129) = true)

theorem identity21129 : scanCanonicalize (H12AffineFastState.compose env21129 (packedSelected [1,8,28] rootPS)) = affineNative (2^(10+1) ^^^ 422) := by decide +kernel

theorem selectedBound21129 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21130 : List Nat := [2,4,8,16,32,17,128,256,136,1024,422,1045,8192,1044,32768,269,1297,8461,1025,32769,1045,4194304,276,4227460,8328,277,4202504,1045,1297,1073741824,4195464,1073782923,257,1073750437,4195484,136]

theorem envBound21130 : H12AffineFastState.Bounded env21130 := by
  intro p hp
  have h : env21130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21129_21130 : H12AffineEnvironment.transform 10 422 env21129 = env21130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 422 env21129 == env21130) = true)

def env21131 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13593,1025,32769,4096,4194304,5377,4234294,8328,5376,4207644,4096,1297,1073741824,4266039,1073853842,257,1073817870,4266019,136]

theorem envBound21131 : H12AffineFastState.Bounded env21131 := by
  intro p hp
  have h : env21131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21112_21131 : H12AffineEnvironment.transform 17 13593 env21112 = env21131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env21112 == env21131) = true)

theorem identity21131 : scanCanonicalize (H12AffineFastState.compose env21131 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 7231) := by decide +kernel

theorem selectedBound21131 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21132 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13593,1025,32769,4096,7231,5377,32777,8328,5376,10275,4096,1297,1073741824,66568,1073853842,257,1073817870,66588,136]

theorem envBound21132 : H12AffineFastState.Bounded env21132 := by
  intro p hp
  have h : env21132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21131_21132 : H12AffineEnvironment.transform 21 7231 env21131 = env21132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7231 env21131 == env21132) = true)

def env21133 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,5400,1297,13593,1025,32769,4096,7231,5377,32777,8328,5376,10275,4096,1297,1073741824,4368,1073782922,257,1073757206,4356,136]

theorem envBound21133 : H12AffineFastState.Bounded env21133 := by
  intro p hp
  have h : env21133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21132_21133 : H12AffineEnvironment.transform 15 5400 env21132 = env21133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5400 env21132 == env21133) = true)

theorem identity21133 : scanCanonicalize (H12AffineFastState.compose env21133 (packedSelected [1,8,28] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound21133 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21134 : List Nat := [2,4,8,16,32,17,128,256,136,1024,423,4096,8192,4097,32768,5400,1297,13593,1025,32769,4096,5528,5377,32777,8328,5376,8580,4096,1297,1073741824,4368,1073782922,257,1073755569,4356,136]

theorem envBound21134 : H12AffineFastState.Bounded env21134 := by
  intro p hp
  have h : env21134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21133_21134 : H12AffineEnvironment.transform 10 423 env21133 = env21134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env21133 == env21134) = true)

def env21135 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,32768,5401,1297,13593,1025,32769,4096,7231,5377,32777,8328,5376,10275,4096,1297,1073741824,4369,1073782923,257,1073757207,4357,136]

theorem envBound21135 : H12AffineFastState.Bounded env21135 := by
  intro p hp
  have h : env21135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21132_21135 : H12AffineEnvironment.transform 15 5401 env21132 = env21135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5401 env21132 == env21135) = true)

theorem identity21135 : scanCanonicalize (H12AffineFastState.compose env21135 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 3506) := by decide +kernel

theorem selectedBound21135 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21136 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,3506,8192,3507,32768,2219,1297,10411,1025,32769,3506,397,2227,32777,8328,2226,10275,3506,1297,1073741824,3235,1073782923,257,1073750437,3255,136]

theorem envBound21136 : H12AffineFastState.Bounded env21136 := by
  intro p hp
  have h : env21136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21135_21136 : H12AffineEnvironment.transform 11 3506 env21135 = env21136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3506 env21135 == env21136) = true)

def env21137 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,3386,8192,3387,32768,2083,1297,10275,1025,32769,3386,261,2107,32777,8192,2106,10275,3386,1297,1073741824,3115,1073782787,257,1073750317,3135,0]

theorem envBound21137 : H12AffineFastState.Bounded env21137 := by
  intro p hp
  have h : env21137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21136_21137 : H12AffineEnvironment.transform 6 8 env21136 = env21137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21136 == env21137) = true)

theorem identity21137 : scanCanonicalize (H12AffineFastState.compose env21137 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 262) := by decide +kernel

theorem selectedBound21137 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21138 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,3386,262,3387,32768,2083,1297,2341,1025,32769,3386,261,2107,32777,262,2106,2341,3386,1297,1073741824,3115,1073774853,257,1073741867,3135,0]

theorem envBound21138 : H12AffineFastState.Bounded env21138 := by
  intro p hp
  have h : env21138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21137_21138 : H12AffineEnvironment.transform 12 262 env21137 = env21138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 262 env21137 == env21138) = true)

theorem identity21138 : scanCanonicalize (H12AffineFastState.compose env21138 (packedSelected [1,2,3,4,5,6,7,8,12,15,23] rootPS)) = affineNative (2^(29+1) ^^^ 32801) := by decide +kernel

theorem selectedBound21138 : packedSelected [1,2,3,4,5,6,7,8,12,15,23] rootPS < 2^1333 := by decide +kernel

def env21139 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,3386,262,3387,32768,2083,1297,2341,1025,32769,3386,261,2107,32777,262,2106,2341,3386,1297,32801,3115,292,257,32778,3135,0]

theorem envBound21139 : H12AffineFastState.Bounded env21139 := by
  intro p hp
  have h : env21139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21138_21139 : H12AffineEnvironment.transform 29 32801 env21138 = env21139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 32801 env21138 == env21139) = true)

theorem identity21139 : scanCanonicalize (H12AffineFastState.compose env21139 (packedSelected [6,7] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound21139 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env21140 : List Nat := [2,4,8,16,32,17,8,256,0,1024,303,1045,262,1044,32768,268,1297,10,1025,32769,1045,261,276,32777,262,277,10,1045,1297,32801,1284,292,257,32778,1296,0]

theorem envBound21140 : H12AffineFastState.Bounded env21140 := by
  intro p hp
  have h : env21140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21139_21140 : H12AffineEnvironment.transform 10 303 env21139 = env21140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env21139 == env21140) = true)

theorem identity21140 : scanCanonicalize (H12AffineFastState.compose env21140 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound21140 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21141 : List Nat := [2,4,8,16,32,17,8,256,0,305,303,292,262,293,32768,268,32,10,304,32769,292,261,276,32777,262,277,10,292,32,32801,53,292,257,32778,33,0]

theorem envBound21141 : H12AffineFastState.Bounded env21141 := by
  intro p hp
  have h : env21141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21140_21141 : H12AffineEnvironment.transform 9 305 env21140 = env21141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env21140 == env21141) = true)

theorem identity21141 : scanCanonicalize (H12AffineFastState.compose env21141 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound21141 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21142 : List Nat := [2,4,8,16,32,17,8,14,0,63,33,42,8,43,32768,2,32,10,62,32769,42,11,26,32777,8,27,10,42,32,32801,53,42,15,32778,33,0]

theorem envBound21142 : H12AffineFastState.Bounded env21142 := by
  intro p hp
  have h : env21142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21141_21142 : H12AffineEnvironment.transform 7 14 env21141 = env21142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env21141 == env21142) = true)

theorem identity21142 : scanCanonicalize (H12AffineFastState.compose env21142 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21142 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21143 : List Nat := [2,4,3,16,32,17,3,5,0,52,33,33,3,32,32768,2,32,1,53,32769,33,0,17,32770,3,16,1,33,32,32801,53,33,4,32769,33,0]

theorem envBound21143 : H12AffineFastState.Bounded env21143 := by
  intro p hp
  have h : env21143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21142_21143 : H12AffineEnvironment.transform 2 3 env21142 = env21143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21142 == env21143) = true)

theorem identity21143 : scanCanonicalize (H12AffineFastState.compose env21143 (packedSelected [0,1] rootPS)) = affineNative (2^(14+1) ^^^ 17) := by decide +kernel

theorem selectedBound21143 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21144 : List Nat := [2,4,3,16,32,17,3,5,0,52,33,33,3,32,17,2,32,1,53,16,33,0,17,19,3,16,1,33,32,48,53,33,4,16,33,0]

theorem envBound21144 : H12AffineFastState.Bounded env21144 := by
  intro p hp
  have h : env21144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21143_21144 : H12AffineEnvironment.transform 14 17 env21143 = env21144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17 env21143 == env21144) = true)

theorem identity21144 : scanCanonicalize (H12AffineFastState.compose env21144 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21144 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env21145 : List Nat := [2,4,3,16,16,17,3,5,0,4,17,17,3,16,17,2,16,1,5,16,17,0,17,19,3,16,1,17,16,0,5,17,4,16,17,0]

theorem envBound21145 : H12AffineFastState.Bounded env21145 := by
  intro p hp
  have h : env21145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21144_21145 : H12AffineEnvironment.transform 4 16 env21144 = env21145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21144 == env21145) = true)

def env21146 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,3387,8192,3386,32768,2082,1297,10274,1025,32769,3387,260,2106,32777,8193,2107,10275,3387,1297,1073741824,3114,1073782786,257,1073750316,3134,1]

theorem envBound21146 : H12AffineFastState.Bounded env21146 := by
  intro p hp
  have h : env21146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21136_21146 : H12AffineEnvironment.transform 6 9 env21136 = env21146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21136 == env21146) = true)

theorem identity21146 : scanCanonicalize (H12AffineFastState.compose env21146 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound21146 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21147 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,3387,2088,3386,32768,2082,1297,10,1025,32769,3387,260,2106,32777,2089,2107,11,3387,1297,1073741824,3114,1073776682,257,1073744132,3134,1]

theorem envBound21147 : H12AffineFastState.Bounded env21147 := by
  intro p hp
  have h : env21147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21146_21147 : H12AffineEnvironment.transform 12 2088 env21146 = env21147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env21146 == env21147) = true)

theorem identity21147 : scanCanonicalize (H12AffineFastState.compose env21147 (packedSelected [1,2,3,4,5,6,7,8,12,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21147 : packedSelected [1,2,3,4,5,6,7,8,12,15,23] rootPS < 2^1333 := by decide +kernel

def env21148 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,3134,2088,3135,32768,2082,1044,10,1025,32769,3134,1,2106,32777,2089,2107,11,3134,1044,1073741824,3114,1073776682,4,1073743873,3134,1]

theorem envBound21148 : H12AffineFastState.Bounded env21148 := by
  intro p hp
  have h : env21148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21147_21148 : H12AffineEnvironment.transform 7 5 env21147 = env21148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21147 == env21148) = true)

theorem identity21148 : scanCanonicalize (H12AffineFastState.compose env21148 (packedSelected [1,3,6,7,8] rootPS)) = affineNative (2^(29+1) ^^^ 34827) := by decide +kernel

theorem selectedBound21148 : packedSelected [1,3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21149 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,3134,2088,3135,32768,2082,1044,10,1025,32769,3134,1,2106,32777,2089,2107,11,3134,1044,34827,3114,33,4,32778,3134,1]

theorem envBound21149 : H12AffineFastState.Bounded env21149 := by
  intro p hp
  have h : env21149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21148_21149 : H12AffineEnvironment.transform 29 34827 env21148 = env21149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34827 env21148 == env21149) = true)

theorem identity21149 : scanCanonicalize (H12AffineFastState.compose env21149 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21149 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env21150 : List Nat := [2,4,3,16,32,17,2,5,1,1024,2048,3125,2083,3124,32768,2082,1044,1,1025,32769,3125,1,2097,32770,2082,2096,0,3125,1044,34816,3105,33,4,32769,3125,1]

theorem envBound21150 : H12AffineFastState.Bounded env21150 := by
  intro p hp
  have h : env21150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21149_21150 : H12AffineEnvironment.transform 2 3 env21149 = env21150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21149 == env21150) = true)

theorem identity21150 : scanCanonicalize (H12AffineFastState.compose env21150 (packedSelected [2,3,4] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound21150 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env21151 : List Nat := [2,4,3,16,32,17,2,5,1,1024,2048,3125,2083,3124,2048,2082,1044,1,1025,2049,3125,1,2097,2050,2082,2096,0,3125,1044,0,3105,33,4,2049,3125,1]

theorem envBound21151 : H12AffineFastState.Bounded env21151 := by
  intro p hp
  have h : env21151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21150_21151 : H12AffineEnvironment.transform 14 2048 env21150 = env21151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env21150 == env21151) = true)

def env21152 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,16777216,8328,5376,4456709,4096,1297,1073741824,16876545,1094789540,257,1073817870,16876565,137]

theorem envBound21152 : H12AffineFastState.Bounded env21152 := by
  intro p hp
  have h : env21152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21110_21152 : H12AffineEnvironment.transform 8 137 env21110 = env21152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21110 == env21152) = true)

theorem identity21152 : scanCanonicalize (H12AffineFastState.compose env21152 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(21+1) ^^^ 337963) := by decide +kernel

theorem selectedBound21152 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env21153 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,337963,5377,16777216,8328,5376,76078,4096,1297,1073741824,16876545,1090781583,257,1073817870,16876565,137]

theorem envBound21153 : H12AffineFastState.Bounded env21153 := by
  intro p hp
  have h : env21153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21152_21153 : H12AffineEnvironment.transform 21 337963 env21152 = env21153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 337963 env21152 == env21153) = true)

def env21154 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13592,1025,32769,4096,73011,5377,16777216,8328,5376,76078,4096,1297,1073741824,16876545,1090532503,257,1073817870,16876565,137]

theorem envBound21154 : H12AffineFastState.Bounded env21154 := by
  intro p hp
  have h : env21154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21153_21154 : H12AffineEnvironment.transform 17 13592 env21153 = env21154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env21153 == env21154) = true)

theorem identity21154 : scanCanonicalize (H12AffineFastState.compose env21154 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 38169) := by decide +kernel

theorem selectedBound21154 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21155 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13592,1025,32769,4096,73011,5377,38169,8328,5376,76078,4096,1297,1073741824,69912,1073783182,257,1073817870,69900,137]

theorem envBound21155 : H12AffineFastState.Bounded env21155 := by
  intro p hp
  have h : env21155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21154_21155 : H12AffineEnvironment.transform 23 38169 env21154 = env21155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 38169 env21154 == env21155) = true)

def env21156 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,8,1297,13592,1025,32769,4096,7483,5377,38169,8328,5376,10534,4096,1297,1073741824,4368,1073783182,257,1073752326,4356,137]

theorem envBound21156 : H12AffineFastState.Bounded env21156 := by
  intro p hp
  have h : env21156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21155_21156 : H12AffineEnvironment.transform 15 8 env21155 = env21156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env21155 == env21156) = true)

theorem identity21156 : scanCanonicalize (H12AffineFastState.compose env21156 (packedSelected [1,8,28] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound21156 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21157 : List Nat := [2,4,8,16,32,17,128,256,137,1024,163,4096,8192,4097,32768,8,1297,13592,1025,32769,4096,5528,5377,38169,8328,5376,8581,4096,1297,1073741824,4368,1073783182,257,1073750437,4356,137]

theorem envBound21157 : H12AffineFastState.Bounded env21157 := by
  intro p hp
  have h : env21157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21156_21157 : H12AffineEnvironment.transform 10 163 env21156 = env21157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env21156 == env21157) = true)

def env21158 : List Nat := [2,4,8,16,32,17,8,256,1,1024,43,4096,8192,4097,32768,8,1297,13592,1025,32769,4096,5392,5377,38169,8192,5376,8461,4096,1297,1073741824,4368,1073783046,257,1073750317,4356,1]

theorem envBound21158 : H12AffineFastState.Bounded env21158 := by
  intro p hp
  have h : env21158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21157_21158 : H12AffineEnvironment.transform 6 8 env21157 = env21158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21157 == env21158) = true)

theorem identity21158 : scanCanonicalize (H12AffineFastState.compose env21158 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5142) := by decide +kernel

theorem selectedBound21158 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21159 : List Nat := [2,4,8,16,32,17,8,256,1,1024,43,4096,5142,4097,32768,8,1297,270,1025,32769,4096,5392,5377,38169,5142,5376,5403,4096,1297,1073741824,4368,1073779984,257,1073747259,4356,1]

theorem envBound21159 : H12AffineFastState.Bounded env21159 := by
  intro p hp
  have h : env21159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21158_21159 : H12AffineEnvironment.transform 12 5142 env21158 = env21159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5142 env21158 == env21159) = true)

theorem identity21159 : scanCanonicalize (H12AffineFastState.compose env21159 (packedSelected [2,3,4,5,6,7,8,13,15,23] rootPS)) = affineNative (2^(29+1) ^^^ 37941) := by decide +kernel

theorem selectedBound21159 : packedSelected [2,3,4,5,6,7,8,13,15,23] rootPS < 2^1333 := by decide +kernel

def env21160 : List Nat := [2,4,8,16,32,17,8,256,1,1024,43,4096,5142,4097,32768,8,1297,270,1025,32769,4096,5392,5377,38169,5142,5376,5403,4096,1297,37941,4368,293,257,33038,4356,1]

theorem envBound21160 : H12AffineFastState.Bounded env21160 := by
  intro p hp
  have h : env21160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21159_21160 : H12AffineEnvironment.transform 29 37941 env21159 = env21160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 37941 env21159 == env21160) = true)

theorem identity21160 : scanCanonicalize (H12AffineFastState.compose env21160 (packedSelected [6,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21160 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env21161 : List Nat := [2,4,8,16,32,17,8,4,1,1024,43,4096,5142,4097,32768,8,1045,10,1025,32769,4096,5140,5125,37917,5142,5124,5151,4096,1045,37941,4116,33,5,32778,4096,1]

theorem envBound21161 : H12AffineFastState.Bounded env21161 := by
  intro p hp
  have h : env21161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21160_21161 : H12AffineEnvironment.transform 7 4 env21160 = env21161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21160 == env21161) = true)

theorem identity21161 : scanCanonicalize (H12AffineFastState.compose env21161 (packedSelected [1,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound21161 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env21162 : List Nat := [2,4,8,16,32,17,8,4,1,1024,43,1044,2,1045,32768,8,1045,10,1025,32769,1044,0,17,32777,2,16,11,1044,1045,32801,1024,33,5,32778,1044,1]

theorem envBound21162 : H12AffineFastState.Bounded env21162 := by
  intro p hp
  have h : env21162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21161_21162 : H12AffineEnvironment.transform 11 1044 env21161 = env21162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env21161 == env21162) = true)

theorem identity21162 : scanCanonicalize (H12AffineFastState.compose env21162 (packedSelected [0,2] rootPS)) = affineNative (2^(14+1) ^^^ 1045) := by decide +kernel

theorem selectedBound21162 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21163 : List Nat := [2,4,8,16,32,17,8,4,1,1024,43,1044,2,1045,1045,8,1045,10,1025,1044,1044,0,17,1052,2,16,11,1044,1045,1076,1024,33,5,1055,1044,1]

theorem envBound21163 : H12AffineFastState.Bounded env21163 := by
  intro p hp
  have h : env21163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21162_21163 : H12AffineEnvironment.transform 14 1045 env21162 = env21163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1045 env21162 == env21163) = true)

theorem identity21163 : scanCanonicalize (H12AffineFastState.compose env21163 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21163 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21164 : List Nat := [2,4,8,16,32,17,8,4,1,53,43,33,2,32,32,8,32,10,52,33,33,0,17,41,2,16,11,33,32,1,53,33,5,42,33,1]

theorem envBound21164 : H12AffineFastState.Bounded env21164 := by
  intro p hp
  have h : env21164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21163_21164 : H12AffineEnvironment.transform 9 53 env21163 = env21164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21163 == env21164) = true)

theorem identity21164 : scanCanonicalize (H12AffineFastState.compose env21164 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound21164 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21165 : List Nat := [2,4,8,16,26,17,8,4,1,15,17,27,2,26,26,8,26,10,14,27,27,0,17,19,2,16,11,27,26,1,15,27,5,16,27,1]

theorem envBound21165 : H12AffineFastState.Bounded env21165 := by
  intro p hp
  have h : env21165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21164_21165 : H12AffineEnvironment.transform 4 26 env21164 = env21165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env21164 == env21165) = true)

theorem identity21165 : scanCanonicalize (H12AffineFastState.compose env21165 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21165 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21166 : List Nat := [2,4,3,16,17,17,3,4,1,4,17,16,2,17,17,3,17,1,5,16,16,0,17,19,2,16,0,16,17,1,4,16,5,16,16,1]

theorem envBound21166 : H12AffineFastState.Bounded env21166 := by
  intro p hp
  have h : env21166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21165_21166 : H12AffineEnvironment.transform 2 3 env21165 = env21166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21165 == env21166) = true)

theorem identity21166 : scanCanonicalize (H12AffineFastState.compose env21166 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21167 : List Nat := [2,4,3,0,1,1,3,4,1,4,1,0,2,1,1,3,1,1,5,0,0,0,1,3,2,0,0,0,1,1,4,0,5,0,0,1]

theorem envBound21167 : H12AffineFastState.Bounded env21167 := by
  intro p hp
  have h : env21167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21166_21167 : H12AffineEnvironment.transform 3 0 env21166 = env21167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21166 == env21167) = true)

def env21168 : List Nat := [2,4,8,16,32,17,9,256,0,1024,42,4096,8192,4097,32768,8,1297,13592,1025,32769,4096,5393,5377,38169,8193,5376,8460,4096,1297,1073741824,4368,1073783047,257,1073750316,4356,0]

theorem envBound21168 : H12AffineFastState.Bounded env21168 := by
  intro p hp
  have h : env21168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21157_21168 : H12AffineEnvironment.transform 6 9 env21157 = env21168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21157 == env21168) = true)

theorem identity21168 : scanCanonicalize (H12AffineFastState.compose env21168 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound21168 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21169 : List Nat := [2,4,8,16,32,17,9,256,0,1024,42,4096,2,4097,32768,8,1297,5402,1025,32769,4096,5393,5377,38169,3,5376,270,4096,1297,1073741824,4368,1073774853,257,1073742126,4356,0]

theorem envBound21169 : H12AffineFastState.Bounded env21169 := by
  intro p hp
  have h : env21169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21168_21169 : H12AffineEnvironment.transform 12 2 env21168 = env21169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env21168 == env21169) = true)

theorem identity21169 : scanCanonicalize (H12AffineFastState.compose env21169 (packedSelected [2,3,4,5,6,7,8,13,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21169 : packedSelected [2,3,4,5,6,7,8,13,15,23] rootPS < 2^1333 := by decide +kernel

def env21170 : List Nat := [2,4,8,16,32,17,9,4,0,1024,42,4096,2,4097,32768,8,1045,5150,1025,32769,4096,5141,5125,37917,3,5124,10,4096,1045,1073741824,4116,1073774593,5,1073741866,4096,0]

theorem envBound21170 : H12AffineFastState.Bounded env21170 := by
  intro p hp
  have h : env21170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21169_21170 : H12AffineEnvironment.transform 7 4 env21169 = env21170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21169 == env21170) = true)

theorem identity21170 : scanCanonicalize (H12AffineFastState.compose env21170 (packedSelected [1,6,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 11) := by decide +kernel

theorem selectedBound21170 : packedSelected [1,6,7,10] rootPS < 2^1333 := by decide +kernel

def env21171 : List Nat := [2,4,8,16,32,17,9,4,0,1024,42,4096,2,4097,11,8,1045,5150,1025,10,4096,5141,5125,5142,3,5124,10,4096,1045,1073741824,4116,1073741834,5,1073741866,4096,0]

theorem envBound21171 : H12AffineFastState.Bounded env21171 := by
  intro p hp
  have h : env21171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21170_21171 : H12AffineEnvironment.transform 14 11 env21170 = env21171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11 env21170 == env21171) = true)

theorem identity21171 : scanCanonicalize (H12AffineFastState.compose env21171 (packedSelected [1,2,3,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1055) := by decide +kernel

theorem selectedBound21171 : packedSelected [1,2,3,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21172 : List Nat := [2,4,8,16,32,17,9,4,0,1024,42,1055,2,1054,11,8,1045,1,1025,10,1055,10,26,9,3,27,10,1055,1045,1073741824,1035,1073741834,5,1073741866,1055,0]

theorem envBound21172 : H12AffineFastState.Bounded env21172 := by
  intro p hp
  have h : env21172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21171_21172 : H12AffineEnvironment.transform 11 1055 env21171 = env21172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1055 env21171 == env21172) = true)

theorem identity21172 : scanCanonicalize (H12AffineFastState.compose env21172 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound21172 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env21173 : List Nat := [2,4,8,16,10,17,9,4,0,1024,0,1055,2,1054,11,8,1045,1,1025,10,1055,10,26,9,3,27,10,1055,1045,1073741824,1035,1073741834,5,1073741824,1055,0]

theorem envBound21173 : H12AffineFastState.Bounded env21173 := by
  intro p hp
  have h : env21173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21172_21173 : H12AffineEnvironment.transform 4 10 env21172 = env21173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env21172 == env21173) = true)

theorem identity21173 : scanCanonicalize (H12AffineFastState.compose env21173 (packedSelected [0,4] rootPS)) = affineNative (2^(29+1) ^^^ 10) := by decide +kernel

theorem selectedBound21173 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21174 : List Nat := [2,4,8,16,10,17,9,4,0,1024,0,1055,2,1054,11,8,1045,1,1025,10,1055,10,26,9,3,27,10,1055,1045,10,1035,0,5,10,1055,0]

theorem envBound21174 : H12AffineFastState.Bounded env21174 := by
  intro p hp
  have h : env21174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21173_21174 : H12AffineEnvironment.transform 29 10 env21173 = env21174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 10 env21173 == env21174) = true)

theorem identity21174 : scanCanonicalize (H12AffineFastState.compose env21174 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound21174 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env21175 : List Nat := [2,4,8,16,10,17,9,4,0,30,0,1,2,0,11,8,11,1,31,10,1,10,26,9,3,27,10,1,11,10,21,0,5,10,1,0]

theorem envBound21175 : H12AffineFastState.Bounded env21175 := by
  intro p hp
  have h : env21175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21174_21175 : H12AffineEnvironment.transform 9 30 env21174 = env21175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env21174 == env21175) = true)

theorem identity21175 : scanCanonicalize (H12AffineFastState.compose env21175 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21175 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21176 : List Nat := [2,4,3,16,1,17,2,4,0,21,0,1,2,0,0,3,0,1,20,1,1,1,17,2,3,16,1,1,0,1,21,0,5,1,1,0]

theorem envBound21176 : H12AffineFastState.Bounded env21176 := by
  intro p hp
  have h : env21176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21175_21176 : H12AffineEnvironment.transform 2 3 env21175 = env21176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21175 == env21176) = true)

theorem identity21176 : scanCanonicalize (H12AffineFastState.compose env21176 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21177 : List Nat := [2,4,3,0,1,1,2,4,0,5,0,1,2,0,0,3,0,1,4,1,1,1,1,2,3,0,1,1,0,1,5,0,5,1,1,0]

theorem envBound21177 : H12AffineFastState.Bounded env21177 := by
  intro p hp
  have h : env21177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21176_21177 : H12AffineEnvironment.transform 3 0 env21176 = env21177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21176 == env21177) = true)

def env21178 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,9,1297,13592,1025,32769,4096,7482,5377,38169,8328,5376,10535,4096,1297,1073741824,4369,1073783182,257,1073752327,4357,137]

theorem envBound21178 : H12AffineFastState.Bounded env21178 := by
  intro p hp
  have h : env21178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21155_21178 : H12AffineEnvironment.transform 15 9 env21155 = env21178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env21155 == env21178) = true)

theorem identity21178 : scanCanonicalize (H12AffineFastState.compose env21178 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 3255) := by decide +kernel

theorem selectedBound21178 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21179 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,3255,8192,3254,32768,9,1297,10671,1025,32769,3255,397,2486,35246,8328,2487,10535,3255,1297,1073741824,3494,1073783182,257,1073752327,3506,137]

theorem envBound21179 : H12AffineFastState.Bounded env21179 := by
  intro p hp
  have h : env21179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21178_21179 : H12AffineEnvironment.transform 11 3255 env21178 = env21179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3255 env21178 == env21179) = true)

def env21180 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13593,1025,32769,4096,73010,5377,16777216,8328,5376,76078,4096,1297,1073741824,16876545,1090532502,257,1073817870,16876565,137]

theorem envBound21180 : H12AffineFastState.Bounded env21180 := by
  intro p hp
  have h : env21180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21153_21180 : H12AffineEnvironment.transform 17 13593 env21153 = env21180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env21153 == env21180) = true)

theorem identity21180 : scanCanonicalize (H12AffineFastState.compose env21180 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 5149) := by decide +kernel

theorem selectedBound21180 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21181 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,5149,1297,13593,1025,32769,4096,2351,5377,16777216,8328,5376,15667,4096,1297,1073741824,16814108,1090532502,257,1073757459,16814088,137]

theorem envBound21181 : H12AffineFastState.Bounded env21181 := by
  intro p hp
  have h : env21181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21180_21181 : H12AffineEnvironment.transform 15 5149 env21180 = env21181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5149 env21180 == env21181) = true)

def env21182 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,5149,1297,13593,1025,32769,4096,2351,5377,38168,8328,5376,15667,4096,1297,1073741824,1284,1073783182,257,1073757459,1296,137]

theorem envBound21182 : H12AffineFastState.Bounded env21182 := by
  intro p hp
  have h : env21182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21181_21182 : H12AffineEnvironment.transform 23 38168 env21181 = env21182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 38168 env21181 == env21182) = true)

theorem identity21182 : scanCanonicalize (H12AffineFastState.compose env21182 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5142) := by decide +kernel

theorem selectedBound21182 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21183 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,5142,4097,32768,5149,1297,271,1025,32769,4096,2351,5377,38168,5278,5376,2341,4096,1297,1073741824,1284,1073780120,257,1073744133,1296,137]

theorem envBound21183 : H12AffineFastState.Bounded env21183 := by
  intro p hp
  have h : env21183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21182_21183 : H12AffineEnvironment.transform 12 5142 env21182 = env21183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5142 env21182 == env21183) = true)

theorem identity21183 : scanCanonicalize (H12AffineFastState.compose env21183 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound21183 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21184 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,5142,4097,2341,5149,1297,271,1025,2340,4096,2351,5377,7229,5278,5376,2341,4096,1297,1073741824,1284,1073749181,257,1073744133,1296,137]

theorem envBound21184 : H12AffineFastState.Bounded env21184 := by
  intro p hp
  have h : env21184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21183_21184 : H12AffineEnvironment.transform 14 2341 env21183 = env21184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env21183 == env21184) = true)

theorem identity21184 : scanCanonicalize (H12AffineFastState.compose env21184 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound21184 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env21185 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,4096,5142,4097,391,5149,1297,271,1025,390,4096,397,5377,5279,5278,5376,391,4096,1297,1073741824,1284,1073746975,257,1073742247,1296,137]

theorem envBound21185 : H12AffineFastState.Bounded env21185 := by
  intro p hp
  have h : env21185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21184_21185 : H12AffineEnvironment.transform 10 162 env21184 = env21185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env21184 == env21185) = true)

theorem identity21185 : scanCanonicalize (H12AffineFastState.compose env21185 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound21185 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21186 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,1045,3,1044,391,8,1297,271,1025,390,1045,397,276,138,139,277,391,1045,1297,1073741824,1284,1073741834,257,1073742247,1296,137]

theorem envBound21186 : H12AffineFastState.Bounded env21186 := by
  intro p hp
  have h : env21186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21185_21186 : H12AffineEnvironment.transform 11 1045 env21185 = env21186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env21185 == env21186) = true)

theorem identity21186 : scanCanonicalize (H12AffineFastState.compose env21186 (packedSelected [0,4] rootPS)) = affineNative (2^(29+1) ^^^ 391) := by decide +kernel

theorem selectedBound21186 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21187 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,1045,3,1044,391,8,1297,271,1025,390,1045,397,276,138,139,277,391,1045,1297,391,1284,397,257,32,1296,137]

theorem envBound21187 : H12AffineFastState.Bounded env21187 := by
  intro p hp
  have h : env21187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21186_21187 : H12AffineEnvironment.transform 29 391 env21186 = env21187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 391 env21186 == env21187) = true)

theorem identity21187 : scanCanonicalize (H12AffineFastState.compose env21187 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound21187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21188 : List Nat := [2,4,8,16,32,17,128,31,137,1024,162,1045,3,1044,152,8,1038,16,1025,153,1045,146,11,138,139,10,152,1045,1038,152,1051,146,30,32,1039,137]

theorem envBound21188 : H12AffineFastState.Bounded env21188 := by
  intro p hp
  have h : env21188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21187_21188 : H12AffineEnvironment.transform 7 31 env21187 = env21188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env21187 == env21188) = true)

theorem identity21188 : scanCanonicalize (H12AffineFastState.compose env21188 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21188 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21189 : List Nat := [2,4,8,0,32,1,128,15,137,1024,162,1029,3,1028,136,8,1038,0,1025,137,1029,130,11,138,139,10,136,1029,1038,136,1035,130,14,32,1039,137]

theorem envBound21189 : H12AffineFastState.Bounded env21189 := by
  intro p hp
  have h : env21189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21188_21189 : H12AffineEnvironment.transform 3 0 env21188 = env21189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21188 == env21189) = true)

theorem identity21189 : scanCanonicalize (H12AffineFastState.compose env21189 (packedSelected [2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound21189 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env21190 : List Nat := [2,4,8,0,11,1,128,15,137,1024,137,1029,3,1028,136,8,1038,0,1025,137,1029,130,11,138,139,10,136,1029,1038,136,1035,130,14,11,1039,137]

theorem envBound21190 : H12AffineFastState.Bounded env21190 := by
  intro p hp
  have h : env21190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21189_21190 : H12AffineEnvironment.transform 4 11 env21189 = env21190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env21189 == env21190) = true)

theorem identity21190 : scanCanonicalize (H12AffineFastState.compose env21190 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound21190 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env21191 : List Nat := [2,4,8,0,11,1,128,15,137,14,137,11,3,10,136,8,0,0,15,137,11,130,11,138,139,10,136,11,0,136,5,130,14,11,1,137]

theorem envBound21191 : H12AffineFastState.Bounded env21191 := by
  intro p hp
  have h : env21191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21190_21191 : H12AffineEnvironment.transform 9 14 env21190 = env21191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env21190 == env21191) = true)

theorem identity21191 : scanCanonicalize (H12AffineFastState.compose env21191 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21192 : List Nat := [2,4,2,0,1,1,128,5,131,4,131,1,3,0,130,2,0,0,5,131,1,130,1,128,129,0,130,1,0,130,5,130,4,1,1,131]

theorem envBound21192 : H12AffineFastState.Bounded env21192 := by
  intro p hp
  have h : env21192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21191_21192 : H12AffineEnvironment.transform 2 2 env21191 = env21192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21191 == env21192) = true)

theorem identity21192 : scanCanonicalize (H12AffineFastState.compose env21192 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound21192 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21193 : List Nat := [2,4,2,0,1,1,3,5,0,4,0,1,3,0,1,2,0,0,5,0,1,1,1,3,2,0,1,1,0,1,5,1,4,1,1,0]

theorem envBound21193 : H12AffineFastState.Bounded env21193 := by
  intro p hp
  have h : env21193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21192_21193 : H12AffineEnvironment.transform 6 3 env21192 = env21193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env21192 == env21193) = true)

def env21194 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,5149,1297,13593,1025,32769,4096,2351,5377,38169,8328,5376,15667,4096,1297,1073741824,1285,1073783183,257,1073757459,1297,137]

theorem envBound21194 : H12AffineFastState.Bounded env21194 := by
  intro p hp
  have h : env21194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21181_21194 : H12AffineEnvironment.transform 23 38169 env21181 = env21194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 38169 env21181 == env21194) = true)

theorem identity21194 : scanCanonicalize (H12AffineFastState.compose env21194 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 41254) := by decide +kernel

theorem selectedBound21194 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21195 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,5149,1297,13593,1025,32769,4096,2351,5377,38169,8328,5376,15667,4096,1297,41254,1285,169,257,39989,1297,137]

theorem envBound21195 : H12AffineFastState.Bounded env21195 := by
  intro p hp
  have h : env21195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21194_21195 : H12AffineEnvironment.transform 29 41254 env21194 = env21195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41254 env21194 == env21195) = true)

theorem identity21195 : scanCanonicalize (H12AffineFastState.compose env21195 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7228) := by decide +kernel

theorem selectedBound21195 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21196 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,7228,4097,32768,5149,1297,2341,1025,32769,4096,2351,5377,38169,7348,5376,271,4096,1297,40218,1285,169,257,39989,1297,137]

theorem envBound21196 : H12AffineFastState.Bounded env21196 := by
  intro p hp
  have h : env21196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21195_21196 : H12AffineEnvironment.transform 12 7228 env21195 = env21196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7228 env21195 == env21196) = true)

theorem identity21196 : scanCanonicalize (H12AffineFastState.compose env21196 (packedSelected [1,5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound21196 : packedSelected [1,5,8,10] rootPS < 2^1333 := by decide +kernel

def env21197 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,4096,5278,4097,32768,5149,1297,391,1025,32769,4096,397,5377,38169,5142,5376,271,4096,1297,38328,1285,169,257,38039,1297,137]

theorem envBound21197 : H12AffineFastState.Bounded env21197 := by
  intro p hp
  have h : env21197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21196_21197 : H12AffineEnvironment.transform 10 162 env21196 = env21197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env21196 == env21197) = true)

theorem identity21197 : scanCanonicalize (H12AffineFastState.compose env21197 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 390) := by decide +kernel

theorem selectedBound21197 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21198 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,4096,5278,4097,390,5149,1297,391,1025,391,4096,397,5377,5279,5142,5376,271,4096,1297,5182,1285,169,257,5393,1297,137]

theorem envBound21198 : H12AffineFastState.Bounded env21198 := by
  intro p hp
  have h : env21198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21197_21198 : H12AffineEnvironment.transform 14 390 env21197 = env21198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 390 env21197 == env21198) = true)

theorem identity21198 : scanCanonicalize (H12AffineFastState.compose env21198 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 1180) := by decide +kernel

theorem selectedBound21198 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21199 : List Nat := [2,4,8,16,32,17,128,256,137,1024,162,1180,2,1181,390,129,1297,391,1025,391,1180,397,413,3,138,412,271,1180,1297,162,1285,169,257,397,1297,137]

theorem envBound21199 : H12AffineFastState.Bounded env21199 := by
  intro p hp
  have h : env21199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21198_21199 : H12AffineEnvironment.transform 11 1180 env21198 = env21199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1180 env21198 == env21199) = true)

theorem identity21199 : scanCanonicalize (H12AffineFastState.compose env21199 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21199 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21200 : List Nat := [2,4,8,16,32,17,9,256,0,1024,43,1045,2,1044,271,8,1297,270,1025,270,1045,260,276,3,3,277,271,1045,1297,43,1285,32,257,260,1297,0]

theorem envBound21200 : H12AffineFastState.Bounded env21200 := by
  intro p hp
  have h : env21200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21199_21200 : H12AffineEnvironment.transform 6 9 env21199 = env21200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21199 == env21200) = true)

theorem identity21200 : scanCanonicalize (H12AffineFastState.compose env21200 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound21200 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21201 : List Nat := [2,4,8,16,32,17,9,14,0,1024,43,1045,2,1044,1,8,1055,0,1025,0,1045,10,26,3,3,27,1,1045,1055,43,1035,32,15,10,1055,0]

theorem envBound21201 : H12AffineFastState.Bounded env21201 := by
  intro p hp
  have h : env21201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21200_21201 : H12AffineEnvironment.transform 7 14 env21200 = env21201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env21200 == env21201) = true)

theorem identity21201 : scanCanonicalize (H12AffineFastState.compose env21201 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound21201 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21202 : List Nat := [2,4,8,16,32,17,9,14,0,62,43,43,2,42,1,8,33,0,63,0,43,10,26,3,3,27,1,43,33,43,53,32,15,10,33,0]

theorem envBound21202 : H12AffineFastState.Bounded env21202 := by
  intro p hp
  have h : env21202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21201_21202 : H12AffineEnvironment.transform 9 62 env21201 = env21202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env21201 == env21202) = true)

theorem identity21202 : scanCanonicalize (H12AffineFastState.compose env21202 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21202 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21203 : List Nat := [2,4,2,16,32,17,3,4,0,52,33,33,2,32,1,2,33,0,53,0,33,0,16,3,3,17,1,33,33,33,53,32,5,0,33,0]

theorem envBound21203 : H12AffineFastState.Bounded env21203 := by
  intro p hp
  have h : env21203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21202_21203 : H12AffineEnvironment.transform 2 2 env21202 = env21203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21202 == env21203) = true)

def env21204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21584,32769,4096,4194304,17665,16777216,8328,5376,134217728,16385,1297,1073741824,16876545,4294967296,257,4315938986,155571472,512]

theorem envBound21204 : H12AffineFastState.Bounded env21204 := by
  intro p hp
  have h : env21204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21105_21204 : H12AffineEnvironment.transform 16 1345 env21105 = env21204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21105 == env21204) = true)

theorem identity21204 : scanCanonicalize (H12AffineFastState.compose env21204 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound21204 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21584,32769,4096,4194304,17665,98565,8328,5376,134217728,16385,1297,1073741824,1284,4294967296,257,4299260335,138695701,512]

theorem envBound21205 : H12AffineFastState.Bounded env21205 := by
  intro p hp
  have h : env21205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21204_21205 : H12AffineEnvironment.transform 23 98565 env21204 = env21205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env21204 == env21205) = true)

def env21206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,4194304,17665,98565,8328,64,134217728,16385,1297,1073741824,1284,4294967296,257,4299260335,138690901,512]

theorem envBound21206 : H12AffineFastState.Bounded env21206 := by
  intro p hp
  have h : env21206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21205_21206 : H12AffineEnvironment.transform 11 1344 env21205 = env21206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env21205 == env21206) = true)

theorem identity21206 : scanCanonicalize (H12AffineFastState.compose env21206 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4473877) := by decide +kernel

theorem selectedBound21206 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env21207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,4194304,17665,98565,8328,64,4473877,16385,1297,1073741824,1284,4294967296,257,4299260335,1344,512]

theorem envBound21207 : H12AffineFastState.Bounded env21207 := by
  intro p hp
  have h : env21207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21206_21207 : H12AffineEnvironment.transform 26 4473877 env21206 = env21207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4473877 env21206 == env21207) = true)

theorem identity21207 : scanCanonicalize (H12AffineFastState.compose env21207 (packedSelected [3,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 35497) := by decide +kernel

theorem selectedBound21207 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,35497,17665,98565,8328,64,315068,16385,1297,1073741824,1284,4294967296,257,4295035654,1344,512]

theorem envBound21208 : H12AffineFastState.Bounded env21208 := by
  intro p hp
  have h : env21208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21207_21208 : H12AffineEnvironment.transform 21 35497 env21207 = env21208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35497 env21207 == env21208) = true)

theorem identity21208 : scanCanonicalize (H12AffineFastState.compose env21208 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(29+1) ^^^ 273284) := by decide +kernel

theorem selectedBound21208 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env21209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,35497,17665,98565,8328,64,315068,16385,1297,273284,1284,4294967296,257,4295035654,1344,512]

theorem envBound21209 : H12AffineFastState.Bounded env21209 := by
  intro p hp
  have h : env21209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21208_21209 : H12AffineEnvironment.transform 29 273284 env21208 = env21209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 273284 env21208 == env21209) = true)

theorem identity21209 : scanCanonicalize (H12AffineFastState.compose env21209 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 60728) := by decide +kernel

theorem selectedBound21209 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,60728,16656,32769,1344,35497,17665,98565,8328,64,9092,16385,1297,50876,1284,4294967296,257,4295035654,1344,512]

theorem envBound21210 : H12AffineFastState.Bounded env21210 := by
  intro p hp
  have h : env21210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21209_21210 : H12AffineEnvironment.transform 17 60728 env21209 = env21210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60728 env21209 == env21210) = true)

def env21211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,8864,65536,1345,20376,16656,8865,1344,10249,17665,74661,8328,64,9092,16385,1297,25628,1284,4294967296,257,4295035654,1344,512]

theorem envBound21211 : H12AffineFastState.Bounded env21211 := by
  intro p hp
  have h : env21211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21210_21211 : H12AffineEnvironment.transform 14 8864 env21210 = env21211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env21210 == env21211) = true)

theorem identity21211 : scanCanonicalize (H12AffineFastState.compose env21211 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 11973) := by decide +kernel

theorem selectedBound21211 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,11973,8864,65536,1345,8541,12245,8865,1344,10249,11204,74661,8328,64,9092,11972,1297,2777,1284,4294967296,257,4295035654,1344,512]

theorem envBound21212 : H12AffineFastState.Bounded env21212 := by
  intro p hp
  have h : env21212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21211_21212 : H12AffineEnvironment.transform 13 11973 env21211 = env21212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11973 env21211 == env21212) = true)

def env21213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3028,1297,2420,65536,1345,2697,1025,2421,1344,989,16,67697,2908,64,2128,1296,1297,2777,1284,4294967296,257,4295035654,1344,512]

theorem envBound21213 : H12AffineFastState.Bounded env21213 := by
  intro p hp
  have h : env21213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21212_21213 : H12AffineEnvironment.transform 12 3028 env21212 = env21213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3028 env21212 == env21213) = true)

theorem identity21213 : scanCanonicalize (H12AffineFastState.compose env21213 (packedSelected [0,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 2298) := by decide +kernel

theorem selectedBound21213 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env21214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3028,1297,2420,2298,1345,2697,1025,2421,1344,989,16,139,2908,64,2128,1296,1297,2777,1284,4294967296,257,4294968316,1344,512]

theorem envBound21214 : H12AffineFastState.Bounded env21214 := by
  intro p hp
  have h : env21214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21213_21214 : H12AffineEnvironment.transform 15 2298 env21213 = env21214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2298 env21213 == env21214) = true)

def env21215 : List Nat := [2,4,8,16,32,64,128,256,80,1024,2048,1344,2436,1297,2420,2298,1345,2265,1025,2421,1344,397,16,139,2316,64,2128,1296,1297,2185,1284,4294967296,257,4294967724,1344,80]

theorem envBound21215 : H12AffineFastState.Bounded env21215 := by
  intro p hp
  have h : env21215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21214_21215 : H12AffineEnvironment.transform 8 80 env21214 = env21215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env21214 == env21215) = true)

theorem identity21215 : scanCanonicalize (H12AffineFastState.compose env21215 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound21215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21216 : List Nat := [2,4,8,16,32,64,128,256,80,1024,2048,1344,2436,1297,2420,2298,1345,2265,1025,2421,1344,397,16,139,2316,64,2128,1296,1297,2185,1284,1,257,429,1344,80]

theorem envBound21216 : H12AffineFastState.Bounded env21216 := by
  intro p hp
  have h : env21216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21215_21216 : H12AffineEnvironment.transform 31 1 env21215 = env21216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env21215 == env21216) = true)

theorem identity21216 : scanCanonicalize (H12AffineFastState.compose env21216 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound21216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21217 : List Nat := [2,4,8,16,32,64,40,256,80,1024,2048,1344,2348,1297,2420,2130,1345,2161,1025,2421,1344,293,16,35,2316,64,2128,1296,1297,2081,1284,1,257,261,1344,80]

theorem envBound21217 : H12AffineFastState.Bounded env21217 := by
  intro p hp
  have h : env21217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21216_21217 : H12AffineEnvironment.transform 6 40 env21216 = env21217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env21216 == env21217) = true)

theorem identity21217 : scanCanonicalize (H12AffineFastState.compose env21217 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21217 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env21218 : List Nat := [2,4,8,16,0,64,8,256,80,1024,2048,1344,2316,1297,2388,2130,1345,2129,1025,2389,1344,261,16,3,2316,64,2128,1296,1297,2049,1284,1,257,261,1344,80]

theorem envBound21218 : H12AffineFastState.Bounded env21218 := by
  intro p hp
  have h : env21218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21217_21218 : H12AffineEnvironment.transform 4 0 env21217 = env21218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21217 == env21218) = true)

theorem identity21218 : scanCanonicalize (H12AffineFastState.compose env21218 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21218 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21219 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2316,1297,2308,2050,1297,2049,1025,2309,1296,261,16,3,2316,16,2048,1296,1297,2049,1284,1,257,261,1296,0]

theorem envBound21219 : H12AffineFastState.Bounded env21219 := by
  intro p hp
  have h : env21219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21218_21219 : H12AffineEnvironment.transform 5 16 env21218 = env21219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21218 == env21219) = true)

def leafEnv21219 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2316,1297,2308,2050,1297,2049,1025,2309,1296,261,16,3,1285,2316,1,16,2048,1296,1297,2049,1284,1,257,261,5,2051,1296,0,0,1297,1]

def active21219 : List Nat := [0,1,2,3,7,9,10]

def tree21219 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21219 : H12WitnessSearch.Good tree21219 := H12GlobalWitnessIndex.good

theorem leafIdentity21219 : H12AffineFastState.composeSystem env21219 rootObs = leafEnv21219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21219 rootObs == leafEnv21219) = true)

theorem terminalChecked21219 : H12PackedTerminal.terminalCheckFast leafEnv21219 active21219 tree21219 = true := by decide +kernel

def env21220 : List Nat := [2,4,8,16,32,64,128,256,81,1024,2048,1344,2437,1297,2420,2298,1345,2264,1025,2421,1344,396,16,139,2317,64,2128,1296,1297,2184,1284,4294967296,257,4294967725,1344,81]

theorem envBound21220 : H12AffineFastState.Bounded env21220 := by
  intro p hp
  have h : env21220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21214_21220 : H12AffineEnvironment.transform 8 81 env21214 = env21220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env21214 == env21220) = true)

theorem identity21220 : scanCanonicalize (H12AffineFastState.compose env21220 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound21220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21221 : List Nat := [2,4,8,16,32,64,128,256,81,1024,2048,1344,2437,1297,2420,2298,1345,2264,1025,2421,1344,396,16,139,2317,64,2128,1296,1297,2184,1284,293,257,136,1344,81]

theorem envBound21221 : H12AffineFastState.Bounded env21221 := by
  intro p hp
  have h : env21221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21220_21221 : H12AffineEnvironment.transform 31 293 env21220 = env21221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env21220 == env21221) = true)

theorem identity21221 : scanCanonicalize (H12AffineFastState.compose env21221 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound21221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21222 : List Nat := [2,4,8,16,32,64,128,221,81,1024,2048,1181,2136,1228,2217,2298,1180,2264,1025,2216,1181,81,16,139,2256,64,2128,1229,1228,2184,1241,248,220,136,1181,81]

theorem envBound21222 : H12AffineFastState.Bounded env21222 := by
  intro p hp
  have h : env21222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21221_21222 : H12AffineEnvironment.transform 7 221 env21221 = env21222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env21221 == env21222) = true)

theorem identity21222 : scanCanonicalize (H12AffineFastState.compose env21222 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21222 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21223 : List Nat := [2,4,8,16,32,64,9,84,81,1024,2048,1044,2136,1093,2080,2163,1045,2129,1025,2081,1044,81,16,2,2137,64,2128,1092,1093,2049,1104,113,85,1,1044,81]

theorem envBound21223 : H12AffineFastState.Bounded env21223 := by
  intro p hp
  have h : env21223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21222_21223 : H12AffineEnvironment.transform 6 9 env21222 = env21223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21222 == env21223) = true)

def env21224 : List Nat := [2,4,8,16,0,64,9,84,81,1024,2048,1044,2136,1093,2048,2131,1045,2129,1025,2049,1044,81,16,2,2137,64,2128,1092,1093,2049,1104,81,85,1,1044,81]

theorem envBound21224 : H12AffineFastState.Bounded env21224 := by
  intro p hp
  have h : env21224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21223_21224 : H12AffineEnvironment.transform 4 0 env21223 = env21224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21223 == env21224) = true)

def env21225 : List Nat := [2,4,8,16,1,64,9,84,81,1024,2048,1044,2136,1093,2049,2130,1045,2129,1025,2048,1044,81,16,2,2137,64,2128,1092,1093,2049,1104,80,85,1,1044,81]

theorem envBound21225 : H12AffineFastState.Bounded env21225 := by
  intro p hp
  have h : env21225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21223_21225 : H12AffineEnvironment.transform 4 1 env21223 = env21225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21223 == env21225) = true)

theorem identity21225 : scanCanonicalize (H12AffineFastState.compose env21225 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21226 : List Nat := [2,4,8,16,1,16,9,4,1,1024,2048,1044,2056,1045,2049,2050,1045,2049,1025,2048,1044,1,16,2,2057,16,2048,1044,1045,2049,1024,0,5,1,1044,1]

theorem envBound21226 : H12AffineFastState.Bounded env21226 := by
  intro p hp
  have h : env21226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21225_21226 : H12AffineEnvironment.transform 5 16 env21225 = env21226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21225 == env21226) = true)

def leafEnv21226 : List Nat := [2,4,8,16,1,16,9,4,1,1024,2048,1044,2056,1045,2049,2050,1045,2049,1025,2048,1044,1,16,2,1025,2057,1,16,2048,1044,1045,2049,1024,0,5,1,5,2050,1044,1,0,1045,1]

def active21226 : List Nat := [0,1,2,3,9,10]

def tree21226 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21226 : H12WitnessSearch.Good tree21226 := H12GlobalWitnessIndex.good

theorem leafIdentity21226 : H12AffineFastState.composeSystem env21226 rootObs = leafEnv21226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21226 rootObs == leafEnv21226) = true)

theorem terminalChecked21226 : H12PackedTerminal.terminalCheckFast leafEnv21226 active21226 tree21226 = true := by decide +kernel

def env21227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3029,1296,2421,65536,1345,2696,1024,2420,1344,988,17,67696,2909,64,2129,1297,1297,2777,1284,4294967296,257,4295035654,1344,512]

theorem envBound21227 : H12AffineFastState.Bounded env21227 := by
  intro p hp
  have h : env21227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21212_21227 : H12AffineEnvironment.transform 12 3029 env21212 = env21227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3029 env21212 == env21227) = true)

theorem identity21227 : scanCanonicalize (H12AffineFastState.compose env21227 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound21227 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env21228 : List Nat := [2,4,8,16,32,64,128,256,508,1024,2048,1344,2089,1296,2421,65536,1345,2420,1024,2420,1344,32,17,67696,2209,64,2129,1297,1297,2341,1284,4294967296,257,4295035130,1344,508]

theorem envBound21228 : H12AffineFastState.Bounded env21228 := by
  intro p hp
  have h : env21228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21227_21228 : H12AffineEnvironment.transform 8 508 env21227 = env21228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env21227 == env21228) = true)

theorem identity21228 : scanCanonicalize (H12AffineFastState.compose env21228 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 2446) := by decide +kernel

theorem selectedBound21228 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21229 : List Nat := [2,4,8,16,32,64,128,256,508,1024,2048,1344,2089,1296,2421,2446,1345,2420,1024,2420,1344,32,17,510,2209,64,2129,1297,1297,2341,1284,4294967296,257,4294967668,1344,508]

theorem envBound21229 : H12AffineFastState.Bounded env21229 := by
  intro p hp
  have h : env21229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21228_21229 : H12AffineEnvironment.transform 15 2446 env21228 = env21229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2446 env21228 == env21229) = true)

theorem identity21229 : scanCanonicalize (H12AffineFastState.compose env21229 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21229 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21230 : List Nat := [2,4,8,16,32,64,128,116,136,1024,2048,1076,2089,1124,2049,2298,1077,2048,1024,2048,1076,32,17,138,2209,64,2129,1125,1125,2129,1136,4294967296,117,4294967296,1076,136]

theorem envBound21230 : H12AffineFastState.Bounded env21230 := by
  intro p hp
  have h : env21230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21229_21230 : H12AffineEnvironment.transform 7 116 env21229 = env21230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21229 == env21230) = true)

theorem identity21230 : scanCanonicalize (H12AffineFastState.compose env21230 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound21230 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21231 : List Nat := [2,4,8,16,32,64,128,116,136,1024,1087,1076,1046,1124,1086,1221,1077,1087,1024,1087,1076,32,17,138,1182,64,1134,1125,1125,1134,1136,4294967296,117,4294967296,1076,136]

theorem envBound21231 : H12AffineFastState.Bounded env21231 := by
  intro p hp
  have h : env21231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21230_21231 : H12AffineEnvironment.transform 10 1087 env21230 = env21231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env21230 == env21231) = true)

theorem identity21231 : scanCanonicalize (H12AffineFastState.compose env21231 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 64) := by decide +kernel

theorem selectedBound21231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21232 : List Nat := [2,4,8,16,32,64,128,116,136,1024,1087,1076,1046,1124,1086,1221,1077,1087,1024,1087,1076,32,17,138,1182,64,1134,1125,1125,1134,1136,64,117,64,1076,136]

theorem envBound21232 : H12AffineFastState.Bounded env21232 := by
  intro p hp
  have h : env21232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21231_21232 : H12AffineEnvironment.transform 31 64 env21231 = env21232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 64 env21231 == env21232) = true)

theorem identity21232 : scanCanonicalize (H12AffineFastState.compose env21232 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound21232 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21233 : List Nat := [2,4,8,16,32,64,121,116,113,1024,1087,1076,1046,1124,1086,1084,1077,1087,1024,1087,1076,32,17,115,1127,64,1134,1125,1125,1134,1136,64,117,64,1076,113]

theorem envBound21233 : H12AffineFastState.Bounded env21233 := by
  intro p hp
  have h : env21233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21232_21233 : H12AffineEnvironment.transform 6 121 env21232 = env21233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env21232 == env21233) = true)

theorem identity21233 : scanCanonicalize (H12AffineFastState.compose env21233 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21233 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21234 : List Nat := [2,4,8,16,32,17,40,37,32,1024,1087,1076,1046,1077,1086,1084,1077,1087,1024,1087,1076,32,17,34,1078,17,1087,1076,1076,1087,1057,17,36,17,1076,32]

theorem envBound21234 : H12AffineFastState.Bounded env21234 := by
  intro p hp
  have h : env21234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21233_21234 : H12AffineEnvironment.transform 5 17 env21233 = env21234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21233 == env21234) = true)

theorem identity21234 : scanCanonicalize (H12AffineFastState.compose env21234 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound21234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21235 : List Nat := [2,4,8,16,32,17,40,37,32,47,16,27,57,26,17,19,26,16,47,16,27,32,17,34,25,17,16,27,27,16,14,17,36,17,27,32]

theorem envBound21235 : H12AffineFastState.Bounded env21235 := by
  intro p hp
  have h : env21235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21234_21235 : H12AffineEnvironment.transform 9 47 env21234 = env21235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env21234 == env21235) = true)

def env21236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,8865,65536,1345,20377,16656,8864,1344,10248,17665,74660,8328,64,9092,16385,1297,25629,1284,4294967296,257,4295035654,1344,512]

theorem envBound21236 : H12AffineFastState.Bounded env21236 := by
  intro p hp
  have h : env21236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21210_21236 : H12AffineEnvironment.transform 14 8865 env21210 = env21236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8865 env21210 == env21236) = true)

theorem identity21236 : scanCanonicalize (H12AffineFastState.compose env21236 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound21236 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,8865,65536,1345,2777,1104,8864,1344,10248,65,74660,8328,64,9092,1345,1297,8541,1284,4294967296,257,4295035654,1344,512]

theorem envBound21237 : H12AffineFastState.Bounded env21237 := by
  intro p hp
  have h : env21237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21236_21237 : H12AffineEnvironment.transform 13 1344 env21236 = env21237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env21236 == env21237) = true)

theorem identity21237 : scanCanonicalize (H12AffineFastState.compose env21237 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound21237 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2949,1344,2340,65536,1345,2777,1104,2341,1344,909,65,67617,2829,64,2049,1345,1297,2776,1284,4294967296,257,4295035654,1344,512]

theorem envBound21238 : H12AffineFastState.Bounded env21238 := by
  intro p hp
  have h : env21238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21237_21238 : H12AffineEnvironment.transform 12 2949 env21237 = env21238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env21237 == env21238) = true)

theorem identity21238 : scanCanonicalize (H12AffineFastState.compose env21238 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21238 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1297,2340,65536,1296,2696,1025,2341,1297,909,16,67617,2829,17,2049,1296,1297,2697,1284,4294967296,257,4295035654,1297,512]

theorem envBound21239 : H12AffineFastState.Bounded env21239 := by
  intro p hp
  have h : env21239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21238_21239 : H12AffineEnvironment.transform 5 17 env21238 = env21239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21238 == env21239) = true)

theorem identity21239 : scanCanonicalize (H12AffineFastState.compose env21239 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound21239 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21240 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1297,2340,2218,1296,2696,1025,2341,1297,909,16,139,2829,17,2049,1296,1297,2697,1284,4294967296,257,4294968236,1297,512]

theorem envBound21240 : H12AffineFastState.Bounded env21240 := by
  intro p hp
  have h : env21240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21239_21240 : H12AffineEnvironment.transform 15 2218 env21239 = env21240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env21239 == env21240) = true)

theorem identity21240 : scanCanonicalize (H12AffineFastState.compose env21240 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 169) := by decide +kernel

theorem selectedBound21240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21241 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1297,2340,2218,1296,2696,1025,2341,1297,909,16,139,2829,17,2049,1296,1297,2697,1284,169,257,773,1297,512]

theorem envBound21241 : H12AffineFastState.Bounded env21241 := by
  intro p hp
  have h : env21241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21240_21241 : H12AffineEnvironment.transform 31 169 env21240 = env21241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 169 env21240 == env21241) = true)

theorem identity21241 : scanCanonicalize (H12AffineFastState.compose env21241 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound21241 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21242 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2317,1297,2340,2218,1296,2048,1025,2341,1297,261,16,139,2437,17,2049,1296,1297,2049,1284,169,257,397,1297,136]

theorem envBound21242 : H12AffineFastState.Bounded env21242 := by
  intro p hp
  have h : env21242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21241_21242 : H12AffineEnvironment.transform 8 136 env21241 = env21242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21241 == env21242) = true)

def env21243 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1297,2317,1297,2340,2082,1296,2048,1025,2341,1297,261,16,3,2317,17,2049,1296,1297,2049,1284,33,257,261,1297,0]

theorem envBound21243 : H12AffineFastState.Bounded env21243 := by
  intro p hp
  have h : env21243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21242_21243 : H12AffineEnvironment.transform 6 8 env21242 = env21243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21242 == env21243) = true)

theorem identity21243 : scanCanonicalize (H12AffineFastState.compose env21243 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21244 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2317,1297,2309,2051,1296,2048,1025,2308,1297,261,16,3,2317,17,2049,1296,1297,2049,1284,0,257,261,1297,0]

theorem envBound21244 : H12AffineFastState.Bounded env21244 := by
  intro p hp
  have h : env21244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21243_21244 : H12AffineEnvironment.transform 4 1 env21243 = env21244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21243 == env21244) = true)

def leafEnv21244 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2317,1297,2309,2051,1296,2048,1025,2308,1297,261,16,3,1285,2317,1,17,2049,1296,1297,2049,1284,0,257,261,5,2050,1297,0,0,1297,1]

def active21244 : List Nat := [0,1,2,3,7,9,10]

def tree21244 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21244 : H12WitnessSearch.Good tree21244 := H12GlobalWitnessIndex.good

theorem leafIdentity21244 : H12AffineFastState.composeSystem env21244 rootObs = leafEnv21244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21244 rootObs == leafEnv21244) = true)

theorem terminalChecked21244 : H12PackedTerminal.terminalCheckFast leafEnv21244 active21244 tree21244 = true := by decide +kernel

def env21245 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1297,2317,1297,2340,2083,1296,2048,1025,2341,1297,261,16,2,2316,17,2049,1296,1297,2049,1284,32,257,260,1297,1]

theorem envBound21245 : H12AffineFastState.Bounded env21245 := by
  intro p hp
  have h : env21245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21242_21245 : H12AffineEnvironment.transform 6 9 env21242 = env21245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21242 == env21245) = true)

theorem identity21245 : scanCanonicalize (H12AffineFastState.compose env21245 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21245 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21246 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1044,2056,1044,2081,2083,1045,2048,1025,2080,1044,0,16,2,2057,17,2049,1045,1044,2049,1025,32,4,1,1044,1]

theorem envBound21246 : H12AffineFastState.Bounded env21246 := by
  intro p hp
  have h : env21246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21245_21246 : H12AffineEnvironment.transform 7 5 env21245 = env21246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21245 == env21246) = true)

def leafEnv21246 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1044,2056,1044,2081,2083,1045,2048,1025,2080,1044,0,16,2,1024,2057,1,17,2049,1045,1044,2049,1025,32,4,1,5,2083,1044,1,0,1044,1]

def active21246 : List Nat := [0,1,2,3,4,9,10]

def tree21246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21246 : H12WitnessSearch.Good tree21246 := H12GlobalWitnessIndex.good

theorem leafIdentity21246 : H12AffineFastState.composeSystem env21246 rootObs = leafEnv21246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21246 rootObs == leafEnv21246) = true)

theorem terminalChecked21246 : H12PackedTerminal.terminalCheckFast leafEnv21246 active21246 tree21246 = true := by decide +kernel

def env21247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,16657,32769,1345,4194304,17665,98565,8328,65,134217728,16385,1297,1073741824,1284,4294967296,257,4299260335,138690900,512]

theorem envBound21247 : H12AffineFastState.Bounded env21247 := by
  intro p hp
  have h : env21247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21205_21247 : H12AffineEnvironment.transform 11 1345 env21205 = env21247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env21205 == env21247) = true)

def env21248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16657,32769,1345,4194304,17665,98565,8328,65,134217728,16385,1297,1073741824,1284,4294967296,257,4299260335,138429268,512]

theorem envBound21248 : H12AffineFastState.Bounded env21248 := by
  intro p hp
  have h : env21248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21247_21248 : H12AffineEnvironment.transform 17 512 env21247 = env21248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env21247 == env21248) = true)

theorem identity21248 : scanCanonicalize (H12AffineFastState.compose env21248 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 8712) := by decide +kernel

theorem selectedBound21248 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16657,32769,1345,8712,17665,98565,8328,65,134217728,16385,1297,1073741824,1284,4294967296,257,4295074727,134242652,512]

theorem envBound21249 : H12AffineFastState.Bounded env21249 := by
  intro p hp
  have h : env21249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21248_21249 : H12AffineEnvironment.transform 21 8712 env21248 = env21249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8712 env21248 == env21249) = true)

theorem identity21249 : scanCanonicalize (H12AffineFastState.compose env21249 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33061) := by decide +kernel

theorem selectedBound21249 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env21250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16657,32769,1345,8712,17665,98565,8328,65,134217728,16385,1297,33061,1284,4294967296,257,4295074727,134242652,512]

theorem envBound21250 : H12AffineFastState.Bounded env21250 := by
  intro p hp
  have h : env21250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21249_21250 : H12AffineEnvironment.transform 29 33061 env21249 = env21250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33061 env21249 == env21250) = true)

theorem identity21250 : scanCanonicalize (H12AffineFastState.compose env21250 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 52789) := by decide +kernel

theorem selectedBound21250 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env21251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16657,32769,1345,8712,17665,98565,8328,65,52789,16385,1297,33061,1284,4294967296,257,4295074727,44905,512]

theorem envBound21251 : H12AffineFastState.Bounded env21251 := by
  intro p hp
  have h : env21251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21250_21251 : H12AffineEnvironment.transform 26 52789 env21250 = env21251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 52789 env21250 == env21251) = true)

theorem identity21251 : scanCanonicalize (H12AffineFastState.compose env21251 (packedSelected [11,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound21251 : packedSelected [11,20] rootPS < 2^1333 := by decide +kernel

def env21252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,512,1025,32769,1345,8712,17,98565,8328,65,35621,1297,1297,33061,1284,4294967296,257,4295074727,44905,512]

theorem envBound21252 : H12AffineFastState.Bounded env21252 := by
  intro p hp
  have h : env21252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21251_21252 : H12AffineEnvironment.transform 13 1296 env21251 = env21252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env21251 == env21252) = true)

theorem identity21252 : scanCanonicalize (H12AffineFastState.compose env21252 (packedSelected [23] rootPS)) = affineNative (2^(14+1) ^^^ 10793) := by decide +kernel

theorem selectedBound21252 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env21253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,10793,65536,1345,512,1025,10792,1345,8712,17,76588,8328,65,8460,1297,1297,11020,1284,4294967296,257,4295035278,1344,512]

theorem envBound21253 : H12AffineFastState.Bounded env21253 := by
  intro p hp
  have h : env21253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21252_21253 : H12AffineEnvironment.transform 14 10793 env21252 = env21253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10793 env21252 == env21253) = true)

def env21254 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,10793,65536,1297,512,1025,10792,1297,8712,17,76588,8328,17,8460,1297,1297,11020,1284,4294967296,257,4295035278,1296,512]

theorem envBound21254 : H12AffineFastState.Bounded env21254 := by
  intro p hp
  have h : env21254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21253_21254 : H12AffineEnvironment.transform 5 16 env21253 = env21254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21253 == env21254) = true)

theorem identity21254 : scanCanonicalize (H12AffineFastState.compose env21254 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound21254 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1296,804,65536,1297,512,1025,805,1297,2821,17,66081,2437,17,2049,1297,1297,513,1284,4294967296,257,4295035278,1296,512]

theorem envBound21255 : H12AffineFastState.Bounded env21255 := by
  intro p hp
  have h : env21255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21254_21255 : H12AffineEnvironment.transform 12 2317 env21254 = env21255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env21254 == env21255) = true)

def env21256 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2317,1296,0,65536,1297,292,1025,1,1297,2081,17,65797,2437,17,2049,1297,1297,293,1284,4294967296,257,4295035278,1296,292]

theorem envBound21256 : H12AffineFastState.Bounded env21256 := by
  intro p hp
  have h : env21256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21255_21256 : H12AffineEnvironment.transform 8 292 env21255 = env21256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env21255 == env21256) = true)

theorem identity21256 : scanCanonicalize (H12AffineFastState.compose env21256 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2185) := by decide +kernel

theorem selectedBound21256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21257 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2317,1296,0,65536,1297,292,1025,1,1297,2081,17,65797,2437,17,2049,1297,1297,293,1284,2185,257,65799,1296,292]

theorem envBound21257 : H12AffineFastState.Bounded env21257 := by
  intro p hp
  have h : env21257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21256_21257 : H12AffineEnvironment.transform 31 2185 env21256 = env21257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2185 env21256 == env21257) = true)

def env21258 : List Nat := [2,4,8,16,32,16,128,256,292,272,2048,1,2317,0,0,65536,1,292,273,1,1,2081,17,65797,2437,17,2049,1,1,293,20,2185,257,65799,0,292]

theorem envBound21258 : H12AffineFastState.Bounded env21258 := by
  intro p hp
  have h : env21258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21257_21258 : H12AffineEnvironment.transform 9 272 env21257 = env21258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21257 == env21258) = true)

theorem identity21258 : scanCanonicalize (H12AffineFastState.compose env21258 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21259 : List Nat := [2,4,8,16,0,16,128,256,260,272,2048,1,2317,0,0,65536,1,260,273,1,1,2049,17,65797,2437,17,2049,1,1,261,20,2185,257,65799,0,260]

theorem envBound21259 : H12AffineFastState.Bounded env21259 := by
  intro p hp
  have h : env21259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21258_21259 : H12AffineEnvironment.transform 4 0 env21258 = env21259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21258 == env21259) = true)

theorem identity21259 : scanCanonicalize (H12AffineFastState.compose env21259 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound21259 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21260 : List Nat := [2,4,8,16,0,16,128,256,260,272,397,1,128,0,0,65536,1,260,273,1,1,396,17,65797,8,17,396,1,1,261,20,260,257,65799,0,260]

theorem envBound21260 : H12AffineFastState.Bounded env21260 := by
  intro p hp
  have h : env21260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21259_21260 : H12AffineEnvironment.transform 10 397 env21259 = env21260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env21259 == env21260) = true)

def env21261 : List Nat := [2,4,8,16,0,16,128,4,0,20,137,1,128,0,0,65536,1,0,21,1,1,136,17,65537,8,17,136,1,1,1,20,0,5,65539,0,0]

theorem envBound21261 : H12AffineFastState.Bounded env21261 := by
  intro p hp
  have h : env21261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21260_21261 : H12AffineEnvironment.transform 7 4 env21260 = env21261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21260 == env21261) = true)

theorem identity21261 : scanCanonicalize (H12AffineFastState.compose env21261 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21261 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21262 : List Nat := [2,4,8,16,0,16,9,4,0,20,0,1,9,0,0,65536,1,0,21,1,1,1,17,65537,8,17,1,1,1,1,20,0,5,65539,0,0]

theorem envBound21262 : H12AffineFastState.Bounded env21262 := by
  intro p hp
  have h : env21262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21261_21262 : H12AffineEnvironment.transform 6 9 env21261 = env21262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21261 == env21262) = true)

theorem identity21262 : scanCanonicalize (H12AffineFastState.compose env21262 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound21262 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21263 : List Nat := [2,4,8,16,0,16,9,4,0,20,0,1,9,0,0,3,1,0,21,1,1,1,17,2,8,17,1,1,1,1,20,0,5,0,0,0]

theorem envBound21263 : H12AffineFastState.Bounded env21263 := by
  intro p hp
  have h : env21263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21262_21263 : H12AffineEnvironment.transform 15 3 env21262 = env21263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env21262 == env21263) = true)

def leafEnv21263 : List Nat := [2,4,8,16,0,16,9,4,0,20,0,1,9,0,0,3,1,0,21,1,1,1,17,2,21,8,1,17,1,1,1,1,20,0,5,0,5,3,0,0,0,1,1]

def active21263 : List Nat := [0,1,2,3]

def tree21263 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21263 : H12WitnessSearch.Good tree21263 := H12GlobalWitnessIndex.good

theorem leafIdentity21263 : H12AffineFastState.composeSystem env21263 rootObs = leafEnv21263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21263 rootObs == leafEnv21263) = true)

theorem terminalChecked21263 : H12PackedTerminal.terminalCheckFast leafEnv21263 active21263 tree21263 = true := by decide +kernel

def env21264 : List Nat := [2,4,8,16,0,16,128,5,1,21,136,1,128,0,0,65536,1,1,20,1,1,137,17,65536,8,17,137,1,1,0,20,1,4,65538,0,1]

theorem envBound21264 : H12AffineFastState.Bounded env21264 := by
  intro p hp
  have h : env21264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21260_21264 : H12AffineEnvironment.transform 7 5 env21260 = env21264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21260 == env21264) = true)

theorem identity21264 : scanCanonicalize (H12AffineFastState.compose env21264 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound21264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21265 : List Nat := [2,4,8,16,0,16,128,5,1,21,136,1,128,0,0,2,1,1,20,1,1,137,17,2,8,17,137,1,1,0,20,1,4,0,0,1]

theorem envBound21265 : H12AffineFastState.Bounded env21265 := by
  intro p hp
  have h : env21265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21264_21265 : H12AffineEnvironment.transform 15 2 env21264 = env21265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env21264 == env21265) = true)

theorem identity21265 : scanCanonicalize (H12AffineFastState.compose env21265 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21265 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21266 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,1,9,0,0,2,1,1,20,1,1,0,17,2,8,17,0,1,1,0,20,1,4,0,0,1]

theorem envBound21266 : H12AffineFastState.Bounded env21266 := by
  intro p hp
  have h : env21266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21265_21266 : H12AffineEnvironment.transform 6 9 env21265 = env21266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21265 == env21266) = true)

def leafEnv21266 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,1,9,0,0,2,1,1,20,1,1,0,17,2,21,8,1,17,0,1,1,0,20,1,4,0,5,2,0,1,0,1,1]

def active21266 : List Nat := [0,1,2,3]

def tree21266 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21266 : H12WitnessSearch.Good tree21266 := H12GlobalWitnessIndex.good

theorem leafIdentity21266 : H12AffineFastState.composeSystem env21266 rootObs = leafEnv21266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21266 rootObs == leafEnv21266) = true)

theorem terminalChecked21266 : H12PackedTerminal.terminalCheckFast leafEnv21266 active21266 tree21266 = true := by decide +kernel

def env21267 : List Nat := [2,4,8,16,32,16,128,256,292,273,2048,0,2317,1,0,65536,0,292,272,1,0,2081,17,65797,2437,17,2049,0,0,293,21,2185,257,65799,1,292]

theorem envBound21267 : H12AffineFastState.Bounded env21267 := by
  intro p hp
  have h : env21267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21257_21267 : H12AffineEnvironment.transform 9 273 env21257 = env21267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21257 == env21267) = true)

theorem identity21267 : scanCanonicalize (H12AffineFastState.compose env21267 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound21267 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21268 : List Nat := [2,4,8,16,32,16,128,256,292,273,2048,0,2317,1,0,430,0,292,272,1,0,2081,17,171,2437,17,2049,0,0,293,21,2185,257,169,1,292]

theorem envBound21268 : H12AffineFastState.Bounded env21268 := by
  intro p hp
  have h : env21268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21267_21268 : H12AffineEnvironment.transform 15 430 env21267 = env21268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env21267 == env21268) = true)

def env21269 : List Nat := [2,4,8,16,0,16,128,256,260,273,2048,0,2317,1,0,398,0,260,272,1,0,2049,17,139,2437,17,2049,0,0,261,21,2185,257,137,1,260]

theorem envBound21269 : H12AffineFastState.Bounded env21269 := by
  intro p hp
  have h : env21269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21268_21269 : H12AffineEnvironment.transform 4 0 env21268 = env21269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21268 == env21269) = true)

theorem identity21269 : scanCanonicalize (H12AffineFastState.compose env21269 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound21269 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21270 : List Nat := [2,4,8,16,0,16,128,256,260,273,397,0,128,1,0,398,0,260,272,1,0,396,17,139,8,17,396,0,0,261,21,260,257,137,1,260]

theorem envBound21270 : H12AffineFastState.Bounded env21270 := by
  intro p hp
  have h : env21270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21269_21270 : H12AffineEnvironment.transform 10 397 env21269 = env21270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env21269 == env21270) = true)

theorem identity21270 : scanCanonicalize (H12AffineFastState.compose env21270 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21270 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21271 : List Nat := [2,4,8,16,0,16,9,256,260,273,260,0,9,1,0,263,0,260,272,1,0,261,17,2,8,17,261,0,0,261,21,260,257,0,1,260]

theorem envBound21271 : H12AffineFastState.Bounded env21271 := by
  intro p hp
  have h : env21271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21270_21271 : H12AffineEnvironment.transform 6 9 env21270 = env21271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21270 == env21271) = true)

def leafEnv21271 : List Nat := [2,4,8,16,0,16,9,256,260,273,260,0,9,1,0,263,0,260,272,1,0,261,17,2,20,8,1,17,261,0,0,261,21,260,257,0,5,263,1,260,0,0,1]

def active21271 : List Nat := [0,1,2,3,7]

def tree21271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21271 : H12WitnessSearch.Good tree21271 := H12GlobalWitnessIndex.good

theorem leafIdentity21271 : H12AffineFastState.composeSystem env21271 rootObs = leafEnv21271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21271 rootObs == leafEnv21271) = true)

theorem terminalChecked21271 : H12PackedTerminal.terminalCheckFast leafEnv21271 active21271 tree21271 = true := by decide +kernel

def env21272 : List Nat := [2,4,8,16,1,16,128,256,261,273,2048,0,2317,1,0,399,0,261,272,1,0,2048,17,138,2437,17,2049,0,0,260,21,2185,257,136,1,261]

theorem envBound21272 : H12AffineFastState.Bounded env21272 := by
  intro p hp
  have h : env21272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21268_21272 : H12AffineEnvironment.transform 4 1 env21268 = env21272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21268 == env21272) = true)

theorem identity21272 : scanCanonicalize (H12AffineFastState.compose env21272 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound21272 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21273 : List Nat := [2,4,8,16,1,16,128,141,136,156,2048,0,2176,1,0,2,0,136,157,1,0,2048,17,138,2056,17,2049,0,0,137,21,2185,140,136,1,136]

theorem envBound21273 : H12AffineFastState.Bounded env21273 := by
  intro p hp
  have h : env21273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21272_21273 : H12AffineEnvironment.transform 7 141 env21272 = env21273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env21272 == env21273) = true)

theorem identity21273 : scanCanonicalize (H12AffineFastState.compose env21273 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21273 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21274 : List Nat := [2,4,8,16,1,16,128,141,136,156,1,0,129,1,0,2,0,136,157,1,0,1,17,138,9,17,0,0,0,137,21,136,140,136,1,136]

theorem envBound21274 : H12AffineFastState.Bounded env21274 := by
  intro p hp
  have h : env21274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21273_21274 : H12AffineEnvironment.transform 10 1 env21273 = env21274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21273 == env21274) = true)

def leafEnv21274 : List Nat := [2,4,8,16,1,16,128,141,136,156,1,0,129,1,0,2,0,136,157,1,0,1,17,138,20,9,1,17,0,0,0,137,21,136,140,136,5,138,1,136,0,0,1]

def active21274 : List Nat := [0,1,2,3,6]

def tree21274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21274 : H12WitnessSearch.Good tree21274 := H12GlobalWitnessIndex.good

theorem leafIdentity21274 : H12AffineFastState.composeSystem env21274 rootObs = leafEnv21274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21274 rootObs == leafEnv21274) = true)

theorem terminalChecked21274 : H12PackedTerminal.terminalCheckFast leafEnv21274 active21274 tree21274 = true := by decide +kernel

def env21275 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1297,2317,1296,1,65536,1297,293,1025,0,1297,2080,17,65796,2437,17,2049,1297,1297,292,1284,4294967296,257,4295035278,1296,293]

theorem envBound21275 : H12AffineFastState.Bounded env21275 := by
  intro p hp
  have h : env21275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21255_21275 : H12AffineEnvironment.transform 8 293 env21255 = env21275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21255 == env21275) = true)

theorem identity21275 : scanCanonicalize (H12AffineFastState.compose env21275 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound21275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21276 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1297,2317,1296,1,65536,1297,293,1025,0,1297,2080,17,65796,2437,17,2049,1297,1297,292,1284,65707,257,2341,1296,293]

theorem envBound21276 : H12AffineFastState.Bounded env21276 := by
  intro p hp
  have h : env21276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21275_21276 : H12AffineEnvironment.transform 31 65707 env21275 = env21276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env21275 == env21276) = true)

def env21277 : List Nat := [2,4,8,16,32,16,128,256,293,272,2048,1,2317,0,1,65536,1,293,273,0,1,2080,17,65796,2437,17,2049,1,1,292,20,65707,257,2341,0,293]

theorem envBound21277 : H12AffineFastState.Bounded env21277 := by
  intro p hp
  have h : env21277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21276_21277 : H12AffineEnvironment.transform 9 272 env21276 = env21277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21276 == env21277) = true)

theorem identity21277 : scanCanonicalize (H12AffineFastState.compose env21277 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound21277 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21278 : List Nat := [2,4,8,16,32,16,128,256,293,272,2048,1,2317,0,1,2051,1,293,273,0,1,2080,17,2311,2437,17,2049,1,1,292,20,2216,257,2341,0,293]

theorem envBound21278 : H12AffineFastState.Bounded env21278 := by
  intro p hp
  have h : env21278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21277_21278 : H12AffineEnvironment.transform 15 2051 env21277 = env21278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env21277 == env21278) = true)

theorem identity21278 : scanCanonicalize (H12AffineFastState.compose env21278 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21278 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21279 : List Nat := [2,4,8,16,1,16,128,256,260,272,2048,1,2317,0,1,2051,1,260,273,0,1,2049,17,2311,2437,17,2049,1,1,261,20,2185,257,2308,0,260]

theorem envBound21279 : H12AffineFastState.Bounded env21279 := by
  intro p hp
  have h : env21279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21278_21279 : H12AffineEnvironment.transform 4 1 env21278 = env21279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21278 == env21279) = true)

def env21280 : List Nat := [2,4,8,16,1,16,8,256,260,272,2048,1,2317,0,1,2051,1,260,273,0,1,2049,17,2311,2317,17,2049,1,1,261,20,2049,257,2308,0,260]

theorem envBound21280 : H12AffineFastState.Bounded env21280 := by
  intro p hp
  have h : env21280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21279_21280 : H12AffineEnvironment.transform 6 8 env21279 = env21280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21279 == env21280) = true)

theorem identity21280 : scanCanonicalize (H12AffineFastState.compose env21280 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21281 : List Nat := [2,4,8,16,1,16,8,256,260,272,0,1,269,0,1,3,1,260,273,0,1,1,17,263,269,17,1,1,1,261,20,1,257,260,0,260]

theorem envBound21281 : H12AffineFastState.Bounded env21281 := by
  intro p hp
  have h : env21281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21280_21281 : H12AffineEnvironment.transform 10 0 env21280 = env21281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21280 == env21281) = true)

theorem identity21281 : scanCanonicalize (H12AffineFastState.compose env21281 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21281 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21282 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,1,9,0,1,3,1,0,21,0,1,1,17,3,9,17,1,1,1,1,20,1,5,0,0,0]

theorem envBound21282 : H12AffineFastState.Bounded env21282 := by
  intro p hp
  have h : env21282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21281_21282 : H12AffineEnvironment.transform 7 4 env21281 = env21282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21281 == env21282) = true)

def leafEnv21282 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,1,9,0,1,3,1,0,21,0,1,1,17,3,21,9,1,17,1,1,1,1,20,1,5,0,5,2,0,0,0,1,1]

def active21282 : List Nat := [0,1,2,3]

def tree21282 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21282 : H12WitnessSearch.Good tree21282 := H12GlobalWitnessIndex.good

theorem leafIdentity21282 : H12AffineFastState.composeSystem env21282 rootObs = leafEnv21282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21282 rootObs == leafEnv21282) = true)

theorem terminalChecked21282 : H12PackedTerminal.terminalCheckFast leafEnv21282 active21282 tree21282 = true := by decide +kernel

def env21283 : List Nat := [2,4,8,16,1,16,9,256,260,272,2048,1,2317,0,1,2051,1,260,273,0,1,2049,17,2311,2316,17,2049,1,1,261,20,2048,257,2308,0,260]

theorem envBound21283 : H12AffineFastState.Bounded env21283 := by
  intro p hp
  have h : env21283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21279_21283 : H12AffineEnvironment.transform 6 9 env21279 = env21283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21279 == env21283) = true)

theorem identity21283 : scanCanonicalize (H12AffineFastState.compose env21283 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21284 : List Nat := [2,4,8,16,1,16,9,4,0,20,2048,1,2057,0,1,2051,1,0,21,0,1,2049,17,2051,2056,17,2049,1,1,1,20,2048,5,2048,0,0]

theorem envBound21284 : H12AffineFastState.Bounded env21284 := by
  intro p hp
  have h : env21284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21283_21284 : H12AffineEnvironment.transform 7 4 env21283 = env21284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21283 == env21284) = true)

theorem identity21284 : scanCanonicalize (H12AffineFastState.compose env21284 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21284 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21285 : List Nat := [2,4,8,16,1,16,9,4,0,20,1,1,8,0,1,2,1,0,21,0,1,0,17,2,9,17,0,1,1,1,20,1,5,1,0,0]

theorem envBound21285 : H12AffineFastState.Bounded env21285 := by
  intro p hp
  have h : env21285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21284_21285 : H12AffineEnvironment.transform 10 1 env21284 = env21285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21284 == env21285) = true)

def leafEnv21285 : List Nat := [2,4,8,16,1,16,9,4,0,20,1,1,8,0,1,2,1,0,21,0,1,0,17,2,21,9,1,17,0,1,1,1,20,1,5,1,5,2,0,0,0,1,1]

def active21285 : List Nat := [0,1,2,3]

def tree21285 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21285 : H12WitnessSearch.Good tree21285 := H12GlobalWitnessIndex.good

theorem leafIdentity21285 : H12AffineFastState.composeSystem env21285 rootObs = leafEnv21285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21285 rootObs == leafEnv21285) = true)

theorem terminalChecked21285 : H12PackedTerminal.terminalCheckFast leafEnv21285 active21285 tree21285 = true := by decide +kernel

def env21286 : List Nat := [2,4,8,16,32,16,128,256,293,273,2048,0,2317,1,1,65536,0,293,272,0,0,2080,17,65796,2437,17,2049,0,0,292,21,65707,257,2341,1,293]

theorem envBound21286 : H12AffineFastState.Bounded env21286 := by
  intro p hp
  have h : env21286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21276_21286 : H12AffineEnvironment.transform 9 273 env21276 = env21286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21276 == env21286) = true)

theorem identity21286 : scanCanonicalize (H12AffineFastState.compose env21286 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound21286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21287 : List Nat := [2,4,8,16,32,16,128,256,293,273,396,0,129,1,1,65536,0,293,272,0,0,428,17,65796,9,17,397,0,0,292,21,65707,257,169,1,293]

theorem envBound21287 : H12AffineFastState.Bounded env21287 := by
  intro p hp
  have h : env21287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21286_21287 : H12AffineEnvironment.transform 10 396 env21286 = env21287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env21286 == env21287) = true)

def env21288 : List Nat := [2,4,8,16,0,16,128,256,261,273,396,0,129,1,1,65536,0,261,272,0,0,396,17,65796,9,17,397,0,0,260,21,65675,257,137,1,261]

theorem envBound21288 : H12AffineFastState.Bounded env21288 := by
  intro p hp
  have h : env21288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21287_21288 : H12AffineEnvironment.transform 4 0 env21287 = env21288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21287 == env21288) = true)

def env21289 : List Nat := [2,4,8,16,1,16,128,256,260,273,396,0,129,1,1,65536,0,260,272,0,0,397,17,65796,9,17,397,0,0,261,21,65674,257,136,1,260]

theorem envBound21289 : H12AffineFastState.Bounded env21289 := by
  intro p hp
  have h : env21289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21287_21289 : H12AffineEnvironment.transform 4 1 env21287 = env21289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21287 == env21289) = true)

theorem identity21289 : scanCanonicalize (H12AffineFastState.compose env21289 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound21289 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21290 : List Nat := [2,4,8,16,1,16,128,256,260,273,396,0,129,1,1,399,0,260,272,0,0,397,17,139,9,17,397,0,0,261,21,261,257,136,1,260]

theorem envBound21290 : H12AffineFastState.Bounded env21290 := by
  intro p hp
  have h : env21290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21289_21290 : H12AffineEnvironment.transform 15 399 env21289 = env21290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env21289 == env21290) = true)

theorem identity21290 : scanCanonicalize (H12AffineFastState.compose env21290 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21291 : List Nat := [2,4,8,16,1,16,128,4,0,21,136,0,129,1,1,139,0,0,20,0,0,137,17,139,9,17,137,0,0,1,21,1,5,136,1,0]

theorem envBound21291 : H12AffineFastState.Bounded env21291 := by
  intro p hp
  have h : env21291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21290_21291 : H12AffineEnvironment.transform 7 4 env21290 = env21291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21290 == env21291) = true)

def leafEnv21291 : List Nat := [2,4,8,16,1,16,128,4,0,21,136,0,129,1,1,139,0,0,20,0,0,137,17,139,20,9,1,17,137,0,0,1,21,1,5,136,5,2,1,0,0,0,1]

def active21291 : List Nat := [0,1,2,3,6]

def tree21291 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21291 : H12WitnessSearch.Good tree21291 := H12GlobalWitnessIndex.good

theorem leafIdentity21291 : H12AffineFastState.composeSystem env21291 rootObs = leafEnv21291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21291 rootObs == leafEnv21291) = true)

theorem terminalChecked21291 : H12PackedTerminal.terminalCheckFast leafEnv21291 active21291 tree21291 = true := by decide +kernel

def env21292 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,10793,65536,1296,512,1025,10792,1296,8712,17,76588,8328,16,8460,1297,1297,11020,1284,4294967296,257,4295035278,1297,512]

theorem envBound21292 : H12AffineFastState.Bounded env21292 := by
  intro p hp
  have h : env21292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21253_21292 : H12AffineEnvironment.transform 5 17 env21253 = env21292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21253 == env21292) = true)

theorem identity21292 : scanCanonicalize (H12AffineFastState.compose env21292 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound21292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21293 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,10793,8614,1296,512,1025,10792,1296,8712,17,2698,8328,16,8460,1297,1297,11020,1284,4294967296,257,4294977576,1297,512]

theorem envBound21293 : H12AffineFastState.Bounded env21293 := by
  intro p hp
  have h : env21293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21292_21293 : H12AffineEnvironment.transform 15 8614 env21292 = env21293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env21292 == env21293) = true)

theorem identity21293 : scanCanonicalize (H12AffineFastState.compose env21293 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound21293 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21294 : List Nat := [2,4,8,16,32,17,128,256,512,1024,513,1296,8192,1296,8232,8614,1296,512,1025,8233,1296,8712,17,139,8328,16,8460,1297,1297,8461,1284,4294967296,257,4294976041,1297,512]

theorem envBound21294 : H12AffineFastState.Bounded env21294 := by
  intro p hp
  have h : env21294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21293_21294 : H12AffineEnvironment.transform 10 513 env21293 = env21294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env21293 == env21294) = true)

theorem identity21294 : scanCanonicalize (H12AffineFastState.compose env21294 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 260) := by decide +kernel

theorem selectedBound21294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21295 : List Nat := [2,4,8,16,32,17,128,256,512,1024,513,1296,8192,1296,8232,8614,1296,512,1025,8233,1296,8712,17,139,8328,16,8460,1297,1297,8461,1284,260,257,9005,1297,512]

theorem envBound21295 : H12AffineFastState.Bounded env21295 := by
  intro p hp
  have h : env21295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21294_21295 : H12AffineEnvironment.transform 31 260 env21294 = env21295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env21294 == env21295) = true)

theorem identity21295 : scanCanonicalize (H12AffineFastState.compose env21295 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21295 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21296 : List Nat := [2,4,8,16,32,17,128,256,260,1024,261,1296,8192,1296,8232,8614,1296,260,1025,8233,1296,8460,17,139,8328,16,8460,1297,1297,8461,1284,260,257,8233,1297,260]

theorem envBound21296 : H12AffineFastState.Bounded env21296 := by
  intro p hp
  have h : env21296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21295_21296 : H12AffineEnvironment.transform 8 260 env21295 = env21296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21295 == env21296) = true)

theorem identity21296 : scanCanonicalize (H12AffineFastState.compose env21296 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound21296 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env21297 : List Nat := [2,4,8,16,32,17,128,256,260,1024,261,1296,9,1296,33,431,1296,260,1025,32,1296,261,17,139,129,16,261,1297,1297,260,1284,260,257,32,1297,260]

theorem envBound21297 : H12AffineFastState.Bounded env21297 := by
  intro p hp
  have h : env21297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21296_21297 : H12AffineEnvironment.transform 12 9 env21296 = env21297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env21296 == env21297) = true)

def env21298 : List Nat := [2,4,8,16,0,17,128,256,260,1024,261,1296,9,1296,1,399,1296,260,1025,0,1296,261,17,139,129,16,261,1297,1297,260,1284,260,257,0,1297,260]

theorem envBound21298 : H12AffineFastState.Bounded env21298 := by
  intro p hp
  have h : env21298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21297_21298 : H12AffineEnvironment.transform 4 0 env21297 = env21298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21297 == env21298) = true)

def env21299 : List Nat := [2,4,8,16,0,17,8,256,260,1024,261,1296,9,1296,1,263,1296,260,1025,0,1296,261,17,3,9,16,261,1297,1297,260,1284,260,257,0,1297,260]

theorem envBound21299 : H12AffineFastState.Bounded env21299 := by
  intro p hp
  have h : env21299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21298_21299 : H12AffineEnvironment.transform 6 8 env21298 = env21299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21298 == env21299) = true)

theorem identity21299 : scanCanonicalize (H12AffineFastState.compose env21299 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21299 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21300 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1,1044,9,1044,1,3,1044,0,1025,0,1044,1,17,3,9,16,1,1045,1045,0,1024,0,5,0,1045,0]

theorem envBound21300 : H12AffineFastState.Bounded env21300 := by
  intro p hp
  have h : env21300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21299_21300 : H12AffineEnvironment.transform 7 4 env21299 = env21300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21299 == env21300) = true)

def leafEnv21300 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1,1044,9,1044,1,3,1044,0,1025,0,1044,1,17,3,1025,9,1,16,1,1045,1045,0,1024,0,5,0,5,2,1045,0,0,1045,1]

def active21300 : List Nat := [0,1,2,3,9]

def tree21300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21300 : H12WitnessSearch.Good tree21300 := H12GlobalWitnessIndex.good

theorem leafIdentity21300 : H12AffineFastState.composeSystem env21300 rootObs = leafEnv21300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21300 rootObs == leafEnv21300) = true)

theorem terminalChecked21300 : H12PackedTerminal.terminalCheckFast leafEnv21300 active21300 tree21300 = true := by decide +kernel

def env21301 : List Nat := [2,4,8,16,0,17,9,256,260,1024,261,1296,9,1296,1,262,1296,260,1025,0,1296,261,17,2,8,16,261,1297,1297,260,1284,260,257,0,1297,260]

theorem envBound21301 : H12AffineFastState.Bounded env21301 := by
  intro p hp
  have h : env21301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21298_21301 : H12AffineEnvironment.transform 6 9 env21298 = env21301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21298 == env21301) = true)

def leafEnv21301 : List Nat := [2,4,8,16,0,17,9,256,260,1024,261,1296,9,1296,1,262,1296,260,1025,0,1296,261,17,2,1285,8,1,16,261,1297,1297,260,1284,260,257,0,5,262,1297,260,0,1297,1]

def active21301 : List Nat := [0,1,2,3,7,9]

def tree21301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21301 : H12WitnessSearch.Good tree21301 := H12GlobalWitnessIndex.good

theorem leafIdentity21301 : H12AffineFastState.composeSystem env21301 rootObs = leafEnv21301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21301 rootObs == leafEnv21301) = true)

theorem terminalChecked21301 : H12PackedTerminal.terminalCheckFast leafEnv21301 active21301 tree21301 = true := by decide +kernel

def env21302 : List Nat := [2,4,8,16,1,17,128,256,260,1024,261,1296,9,1296,0,398,1296,260,1025,1,1296,261,17,139,129,16,261,1297,1297,260,1284,260,257,1,1297,260]

theorem envBound21302 : H12AffineFastState.Bounded env21302 := by
  intro p hp
  have h : env21302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21297_21302 : H12AffineEnvironment.transform 4 1 env21297 = env21302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21297 == env21302) = true)

theorem identity21302 : scanCanonicalize (H12AffineFastState.compose env21302 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21303 : List Nat := [2,4,8,16,1,17,8,256,260,1024,261,1296,9,1296,0,262,1296,260,1025,1,1296,261,17,3,9,16,261,1297,1297,260,1284,260,257,1,1297,260]

theorem envBound21303 : H12AffineFastState.Bounded env21303 := by
  intro p hp
  have h : env21303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21302_21303 : H12AffineEnvironment.transform 6 8 env21302 = env21303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21302 == env21303) = true)

theorem identity21303 : scanCanonicalize (H12AffineFastState.compose env21303 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21303 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21304 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1044,9,1044,0,2,1044,0,1025,1,1044,1,17,3,9,16,1,1045,1045,0,1024,0,5,1,1045,0]

theorem envBound21304 : H12AffineFastState.Bounded env21304 := by
  intro p hp
  have h : env21304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21303_21304 : H12AffineEnvironment.transform 7 4 env21303 = env21304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21303 == env21304) = true)

def leafEnv21304 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1044,9,1044,0,2,1044,0,1025,1,1044,1,17,3,1025,9,1,16,1,1045,1045,0,1024,0,5,1,5,3,1045,0,0,1045,1]

def active21304 : List Nat := [0,1,2,3,9]

def tree21304 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21304 : H12WitnessSearch.Good tree21304 := H12GlobalWitnessIndex.good

theorem leafIdentity21304 : H12AffineFastState.composeSystem env21304 rootObs = leafEnv21304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21304 rootObs == leafEnv21304) = true)

theorem terminalChecked21304 : H12PackedTerminal.terminalCheckFast leafEnv21304 active21304 tree21304 = true := by decide +kernel

def env21305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16657,32769,1345,4194304,17665,98565,8328,65,134217728,16385,1297,1073741824,1284,4294967296,257,4299260335,138429269,512]

theorem envBound21305 : H12AffineFastState.Bounded env21305 := by
  intro p hp
  have h : env21305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21247_21305 : H12AffineEnvironment.transform 17 513 env21247 = env21305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env21247 == env21305) = true)

theorem identity21305 : scanCanonicalize (H12AffineFastState.compose env21305 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 25628) := by decide +kernel

theorem selectedBound21305 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16657,32769,1345,4194304,17665,98565,8328,65,25628,16385,1297,1073741824,1284,4294967296,257,4299260335,4204361,512]

theorem envBound21306 : H12AffineFastState.Bounded env21306 := by
  intro p hp
  have h : env21306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21305_21306 : H12AffineEnvironment.transform 26 25628 env21305 = env21306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 25628 env21305 == env21306) = true)

theorem identity21306 : scanCanonicalize (H12AffineFastState.compose env21306 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33061) := by decide +kernel

theorem selectedBound21306 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env21307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16657,32769,1345,4194304,17665,98565,8328,65,25628,16385,1297,33061,1284,4294967296,257,4299260335,4204361,512]

theorem envBound21307 : H12AffineFastState.Bounded env21307 := by
  intro p hp
  have h : env21307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21306_21307 : H12AffineEnvironment.transform 29 33061 env21306 = env21307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33061 env21306 == env21307) = true)

theorem identity21307 : scanCanonicalize (H12AffineFastState.compose env21307 (packedSelected [1,12,13,21,28,38] rootPS)) = affineNative (2^(21+1) ^^^ 8713) := by decide +kernel

theorem selectedBound21307 : packedSelected [1,12,13,21,28,38] rootPS < 2^1333 := by decide +kernel

def env21308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16657,32769,1345,8713,17665,98565,8328,65,25628,16385,1297,33061,1284,4294967296,257,4295074726,1344,512]

theorem envBound21308 : H12AffineFastState.Bounded env21308 := by
  intro p hp
  have h : env21308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21307_21308 : H12AffineEnvironment.transform 21 8713 env21307 = env21308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8713 env21307 == env21308) = true)

theorem identity21308 : scanCanonicalize (H12AffineFastState.compose env21308 (packedSelected [0,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound21308 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env21309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,513,1025,32769,1345,8713,17,98565,8328,65,8460,1297,1297,33061,1284,4294967296,257,4295074726,1344,512]

theorem envBound21309 : H12AffineFastState.Bounded env21309 := by
  intro p hp
  have h : env21309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21308_21309 : H12AffineEnvironment.transform 13 1296 env21308 = env21309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env21308 == env21309) = true)

theorem identity21309 : scanCanonicalize (H12AffineFastState.compose env21309 (packedSelected [1,13] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound21309 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env21310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,10792,65536,1345,513,1025,10793,1345,8713,17,76589,8328,65,8460,1297,1297,11021,1284,4294967296,257,4295035278,1344,512]

theorem envBound21310 : H12AffineFastState.Bounded env21310 := by
  intro p hp
  have h : env21310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21309_21310 : H12AffineEnvironment.transform 14 10792 env21309 = env21310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env21309 == env21310) = true)

def env21311 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,10792,65536,1297,513,1025,10793,1297,8713,17,76589,8328,17,8460,1297,1297,11021,1284,4294967296,257,4295035278,1296,512]

theorem envBound21311 : H12AffineFastState.Bounded env21311 := by
  intro p hp
  have h : env21311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21310_21311 : H12AffineEnvironment.transform 5 16 env21310 = env21311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21310 == env21311) = true)

theorem identity21311 : scanCanonicalize (H12AffineFastState.compose env21311 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound21311 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21312 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1296,805,65536,1297,513,1025,804,1297,2820,17,66080,2437,17,2049,1297,1297,512,1284,4294967296,257,4295035278,1296,512]

theorem envBound21312 : H12AffineFastState.Bounded env21312 := by
  intro p hp
  have h : env21312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21311_21312 : H12AffineEnvironment.transform 12 2317 env21311 = env21312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env21311 == env21312) = true)

def env21313 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2317,1296,1,65536,1297,293,1025,0,1297,2080,17,65796,2437,17,2049,1297,1297,292,1284,4294967296,257,4295035278,1296,292]

theorem envBound21313 : H12AffineFastState.Bounded env21313 := by
  intro p hp
  have h : env21313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21312_21313 : H12AffineEnvironment.transform 8 292 env21312 = env21313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env21312 == env21313) = true)

theorem identity21313 : scanCanonicalize (H12AffineFastState.compose env21313 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 67847) := by decide +kernel

theorem selectedBound21313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21314 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2317,1296,1,65536,1297,293,1025,0,1297,2080,17,65796,2437,17,2049,1297,1297,292,1284,67847,257,137,1296,292]

theorem envBound21314 : H12AffineFastState.Bounded env21314 := by
  intro p hp
  have h : env21314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21313_21314 : H12AffineEnvironment.transform 31 67847 env21313 = env21314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67847 env21313 == env21314) = true)

def env21315 : List Nat := [2,4,8,16,32,16,128,256,292,272,2048,1,2317,0,1,65536,1,293,273,0,1,2080,17,65796,2437,17,2049,1,1,292,20,67847,257,137,0,292]

theorem envBound21315 : H12AffineFastState.Bounded env21315 := by
  intro p hp
  have h : env21315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21314_21315 : H12AffineEnvironment.transform 9 272 env21314 = env21315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21314 == env21315) = true)

theorem identity21315 : scanCanonicalize (H12AffineFastState.compose env21315 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound21315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21316 : List Nat := [2,4,8,16,32,16,128,256,292,272,2048,1,2317,0,1,431,1,293,273,0,1,2080,17,171,2437,17,2049,1,1,292,20,2216,257,137,0,292]

theorem envBound21316 : H12AffineFastState.Bounded env21316 := by
  intro p hp
  have h : env21316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21315_21316 : H12AffineEnvironment.transform 15 431 env21315 = env21316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env21315 == env21316) = true)

theorem identity21316 : scanCanonicalize (H12AffineFastState.compose env21316 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound21316 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21317 : List Nat := [2,4,8,16,32,16,128,256,292,272,396,1,129,0,1,431,1,293,273,0,1,428,17,171,9,17,397,1,1,292,20,292,257,137,0,292]

theorem envBound21317 : H12AffineFastState.Bounded env21317 := by
  intro p hp
  have h : env21317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21316_21317 : H12AffineEnvironment.transform 10 396 env21316 = env21317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env21316 == env21317) = true)

def env21318 : List Nat := [2,4,8,16,0,16,128,256,260,272,396,1,129,0,1,399,1,261,273,0,1,396,17,139,9,17,397,1,1,260,20,260,257,137,0,260]

theorem envBound21318 : H12AffineFastState.Bounded env21318 := by
  intro p hp
  have h : env21318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21317_21318 : H12AffineEnvironment.transform 4 0 env21317 = env21318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21317 == env21318) = true)

theorem identity21318 : scanCanonicalize (H12AffineFastState.compose env21318 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21318 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21319 : List Nat := [2,4,8,16,0,16,9,256,260,272,261,1,8,0,1,262,1,261,273,0,1,261,17,2,9,17,260,1,1,260,20,260,257,0,0,260]

theorem envBound21319 : H12AffineFastState.Bounded env21319 := by
  intro p hp
  have h : env21319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21318_21319 : H12AffineEnvironment.transform 6 9 env21318 = env21319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21318 == env21319) = true)

def leafEnv21319 : List Nat := [2,4,8,16,0,16,9,256,260,272,261,1,8,0,1,262,1,261,273,0,1,261,17,2,21,9,1,17,260,1,1,260,20,260,257,0,5,262,0,260,0,1,1]

def active21319 : List Nat := [0,1,2,3,7]

def tree21319 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21319 : H12WitnessSearch.Good tree21319 := H12GlobalWitnessIndex.good

theorem leafIdentity21319 : H12AffineFastState.composeSystem env21319 rootObs = leafEnv21319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21319 rootObs == leafEnv21319) = true)

theorem terminalChecked21319 : H12PackedTerminal.terminalCheckFast leafEnv21319 active21319 tree21319 = true := by decide +kernel

def env21320 : List Nat := [2,4,8,16,1,16,128,256,261,272,396,1,129,0,1,398,1,260,273,0,1,397,17,138,9,17,397,1,1,261,20,261,257,137,0,261]

theorem envBound21320 : H12AffineFastState.Bounded env21320 := by
  intro p hp
  have h : env21320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21317_21320 : H12AffineEnvironment.transform 4 1 env21317 = env21320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21317 == env21320) = true)

def env21321 : List Nat := [2,4,8,16,32,16,128,256,292,273,2048,0,2317,1,1,65536,0,293,272,0,0,2080,17,65796,2437,17,2049,0,0,292,21,67847,257,137,1,292]

theorem envBound21321 : H12AffineFastState.Bounded env21321 := by
  intro p hp
  have h : env21321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21314_21321 : H12AffineEnvironment.transform 9 273 env21314 = env21321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21314 == env21321) = true)

theorem identity21321 : scanCanonicalize (H12AffineFastState.compose env21321 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21322 : List Nat := [2,4,8,16,0,16,128,256,260,273,2048,0,2317,1,1,65536,0,261,272,0,0,2048,17,65796,2437,17,2049,0,0,260,21,67847,257,137,1,260]

theorem envBound21322 : H12AffineFastState.Bounded env21322 := by
  intro p hp
  have h : env21322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21321_21322 : H12AffineEnvironment.transform 4 0 env21321 = env21322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21321 == env21322) = true)

def env21323 : List Nat := [2,4,8,16,0,16,128,256,260,273,396,0,129,1,1,65536,0,261,272,0,0,396,17,65796,9,17,397,0,0,260,21,65675,257,137,1,260]

theorem envBound21323 : H12AffineFastState.Bounded env21323 := by
  intro p hp
  have h : env21323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21322_21323 : H12AffineEnvironment.transform 10 396 env21322 = env21323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env21322 == env21323) = true)

theorem identity21323 : scanCanonicalize (H12AffineFastState.compose env21323 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound21323 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21324 : List Nat := [2,4,8,16,0,16,128,256,260,273,396,0,129,1,1,399,0,261,272,0,0,396,17,139,9,17,397,0,0,260,21,260,257,137,1,260]

theorem envBound21324 : H12AffineFastState.Bounded env21324 := by
  intro p hp
  have h : env21324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21323_21324 : H12AffineEnvironment.transform 15 399 env21323 = env21324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env21323 == env21324) = true)

theorem identity21324 : scanCanonicalize (H12AffineFastState.compose env21324 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21325 : List Nat := [2,4,8,16,0,16,9,256,260,273,261,0,8,1,1,262,0,261,272,0,0,261,17,2,9,17,260,0,0,260,21,260,257,0,1,260]

theorem envBound21325 : H12AffineFastState.Bounded env21325 := by
  intro p hp
  have h : env21325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21324_21325 : H12AffineEnvironment.transform 6 9 env21324 = env21325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21324 == env21325) = true)

def leafEnv21325 : List Nat := [2,4,8,16,0,16,9,256,260,273,261,0,8,1,1,262,0,261,272,0,0,261,17,2,20,9,1,17,260,0,0,260,21,260,257,0,5,262,1,260,0,0,1]

def active21325 : List Nat := [0,1,2,3,7]

def tree21325 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21325 : H12WitnessSearch.Good tree21325 := H12GlobalWitnessIndex.good

theorem leafIdentity21325 : H12AffineFastState.composeSystem env21325 rootObs = leafEnv21325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21325 rootObs == leafEnv21325) = true)

theorem terminalChecked21325 : H12PackedTerminal.terminalCheckFast leafEnv21325 active21325 tree21325 = true := by decide +kernel

def env21326 : List Nat := [2,4,8,16,0,16,128,256,260,273,397,0,128,1,1,65536,0,261,272,0,0,397,17,65796,8,17,396,0,0,260,21,65674,257,137,1,260]

theorem envBound21326 : H12AffineFastState.Bounded env21326 := by
  intro p hp
  have h : env21326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21322_21326 : H12AffineEnvironment.transform 10 397 env21322 = env21326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env21322 == env21326) = true)

def env21327 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1297,2317,1296,0,65536,1297,292,1025,1,1297,2081,17,65797,2437,17,2049,1297,1297,293,1284,4294967296,257,4295035278,1296,293]

theorem envBound21327 : H12AffineFastState.Bounded env21327 := by
  intro p hp
  have h : env21327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21312_21327 : H12AffineEnvironment.transform 8 293 env21312 = env21327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21312 == env21327) = true)

theorem identity21327 : scanCanonicalize (H12AffineFastState.compose env21327 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound21327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21328 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1297,2317,1296,0,65536,1297,292,1025,1,1297,2081,17,65797,2437,17,2049,1297,1297,293,1284,292,257,67754,1296,293]

theorem envBound21328 : H12AffineFastState.Bounded env21328 := by
  intro p hp
  have h : env21328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21327_21328 : H12AffineEnvironment.transform 31 292 env21327 = env21328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env21327 == env21328) = true)

def env21329 : List Nat := [2,4,8,16,32,16,128,256,293,272,2048,1,2317,0,0,65536,1,292,273,1,1,2081,17,65797,2437,17,2049,1,1,293,20,292,257,67754,0,293]

theorem envBound21329 : H12AffineFastState.Bounded env21329 := by
  intro p hp
  have h : env21329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21328_21329 : H12AffineEnvironment.transform 9 272 env21328 = env21329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21328 == env21329) = true)

theorem identity21329 : scanCanonicalize (H12AffineFastState.compose env21329 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound21329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21330 : List Nat := [2,4,8,16,32,16,128,256,293,272,397,1,128,0,0,65536,1,292,273,1,1,428,17,65797,8,17,396,1,1,293,20,292,257,65831,0,293]

theorem envBound21330 : H12AffineFastState.Bounded env21330 := by
  intro p hp
  have h : env21330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21329_21330 : H12AffineEnvironment.transform 10 397 env21329 = env21330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env21329 == env21330) = true)

theorem identity21330 : scanCanonicalize (H12AffineFastState.compose env21330 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21330 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21331 : List Nat := [2,4,8,16,1,16,128,256,260,272,397,1,128,0,0,65536,1,261,273,1,1,397,17,65797,8,17,396,1,1,260,20,261,257,65798,0,260]

theorem envBound21331 : H12AffineFastState.Bounded env21331 := by
  intro p hp
  have h : env21331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21330_21331 : H12AffineEnvironment.transform 4 1 env21330 = env21331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21330 == env21331) = true)

def env21332 : List Nat := [2,4,8,16,1,16,128,4,0,20,137,1,128,0,0,65536,1,1,21,1,1,137,17,65537,8,17,136,1,1,0,20,1,5,65538,0,0]

theorem envBound21332 : H12AffineFastState.Bounded env21332 := by
  intro p hp
  have h : env21332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21331_21332 : H12AffineEnvironment.transform 7 4 env21331 = env21332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21331 == env21332) = true)

def env21333 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,1,8,0,0,65536,1,1,21,1,1,1,17,65537,8,17,0,1,1,0,20,1,5,65538,0,0]

theorem envBound21333 : H12AffineFastState.Bounded env21333 := by
  intro p hp
  have h : env21333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21332_21333 : H12AffineEnvironment.transform 6 8 env21332 = env21333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21332 == env21333) = true)

def leafEnv21333 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,1,8,0,0,65536,1,1,21,1,1,1,17,65537,21,8,1,17,0,1,1,0,20,1,5,65538,5,3,0,0,0,1,1]

def active21333 : List Nat := [0,1,2,3,15]

def tree21333 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21333 : H12WitnessSearch.Good tree21333 := H12GlobalWitnessIndex.good

theorem leafIdentity21333 : H12AffineFastState.composeSystem env21333 rootObs = leafEnv21333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21333 rootObs == leafEnv21333) = true)

theorem terminalChecked21333 : H12PackedTerminal.terminalCheckFast leafEnv21333 active21333 tree21333 = true := by decide +kernel

def env21334 : List Nat := [2,4,8,16,1,16,9,4,0,20,0,1,9,0,0,65536,1,1,21,1,1,0,17,65537,8,17,1,1,1,0,20,1,5,65538,0,0]

theorem envBound21334 : H12AffineFastState.Bounded env21334 := by
  intro p hp
  have h : env21334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21332_21334 : H12AffineEnvironment.transform 6 9 env21332 = env21334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21332 == env21334) = true)

theorem identity21334 : scanCanonicalize (H12AffineFastState.compose env21334 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound21334 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21335 : List Nat := [2,4,8,16,1,16,9,4,0,20,0,1,9,0,0,3,1,1,21,1,1,0,17,2,8,17,1,1,1,0,20,1,5,1,0,0]

theorem envBound21335 : H12AffineFastState.Bounded env21335 := by
  intro p hp
  have h : env21335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21334_21335 : H12AffineEnvironment.transform 15 3 env21334 = env21335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env21334 == env21335) = true)

def leafEnv21335 : List Nat := [2,4,8,16,1,16,9,4,0,20,0,1,9,0,0,3,1,1,21,1,1,0,17,2,21,8,1,17,1,1,1,0,20,1,5,1,5,3,0,0,0,1,1]

def active21335 : List Nat := [0,1,2,3]

def tree21335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21335 : H12WitnessSearch.Good tree21335 := H12GlobalWitnessIndex.good

theorem leafIdentity21335 : H12AffineFastState.composeSystem env21335 rootObs = leafEnv21335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21335 rootObs == leafEnv21335) = true)

theorem terminalChecked21335 : H12PackedTerminal.terminalCheckFast leafEnv21335 active21335 tree21335 = true := by decide +kernel

def env21336 : List Nat := [2,4,8,16,1,16,128,5,1,21,136,1,128,0,0,65536,1,0,20,1,1,136,17,65536,8,17,137,1,1,1,20,0,4,65539,0,1]

theorem envBound21336 : H12AffineFastState.Bounded env21336 := by
  intro p hp
  have h : env21336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21331_21336 : H12AffineEnvironment.transform 7 5 env21331 = env21336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21331 == env21336) = true)

theorem identity21336 : scanCanonicalize (H12AffineFastState.compose env21336 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound21336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21337 : List Nat := [2,4,8,16,1,16,128,5,1,21,136,1,128,0,0,138,1,0,20,1,1,136,17,138,8,17,137,1,1,1,20,0,4,137,0,1]

theorem envBound21337 : H12AffineFastState.Bounded env21337 := by
  intro p hp
  have h : env21337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21336_21337 : H12AffineEnvironment.transform 15 138 env21336 = env21337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env21336 == env21337) = true)

theorem identity21337 : scanCanonicalize (H12AffineFastState.compose env21337 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21337 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21338 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,1,9,0,0,3,1,0,20,1,1,1,17,3,8,17,0,1,1,1,20,0,4,0,0,1]

theorem envBound21338 : H12AffineFastState.Bounded env21338 := by
  intro p hp
  have h : env21338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21337_21338 : H12AffineEnvironment.transform 6 9 env21337 = env21338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21337 == env21338) = true)

def leafEnv21338 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,1,9,0,0,3,1,0,20,1,1,1,17,3,21,8,1,17,0,1,1,1,20,0,4,0,5,2,0,1,0,1,1]

def active21338 : List Nat := [0,1,2,3]

def tree21338 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21338 : H12WitnessSearch.Good tree21338 := H12GlobalWitnessIndex.good

theorem leafIdentity21338 : H12AffineFastState.composeSystem env21338 rootObs = leafEnv21338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21338 rootObs == leafEnv21338) = true)

theorem terminalChecked21338 : H12PackedTerminal.terminalCheckFast leafEnv21338 active21338 tree21338 = true := by decide +kernel

def env21339 : List Nat := [2,4,8,16,32,16,128,256,293,273,2048,0,2317,1,0,65536,0,292,272,1,0,2081,17,65797,2437,17,2049,0,0,293,21,292,257,67754,1,293]

theorem envBound21339 : H12AffineFastState.Bounded env21339 := by
  intro p hp
  have h : env21339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21328_21339 : H12AffineEnvironment.transform 9 273 env21328 = env21339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21328 == env21339) = true)

theorem identity21339 : scanCanonicalize (H12AffineFastState.compose env21339 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound21339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21340 : List Nat := [2,4,8,16,32,16,128,256,293,273,2048,0,2317,1,0,2051,0,292,272,1,0,2081,17,2310,2437,17,2049,0,0,293,21,292,257,169,1,293]

theorem envBound21340 : H12AffineFastState.Bounded env21340 := by
  intro p hp
  have h : env21340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21339_21340 : H12AffineEnvironment.transform 15 2051 env21339 = env21340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env21339 == env21340) = true)

def env21341 : List Nat := [2,4,8,16,0,16,128,256,261,273,2048,0,2317,1,0,2051,0,260,272,1,0,2049,17,2310,2437,17,2049,0,0,261,21,260,257,137,1,261]

theorem envBound21341 : H12AffineFastState.Bounded env21341 := by
  intro p hp
  have h : env21341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21340_21341 : H12AffineEnvironment.transform 4 0 env21340 = env21341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21340 == env21341) = true)

theorem identity21341 : scanCanonicalize (H12AffineFastState.compose env21341 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound21341 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21342 : List Nat := [2,4,8,16,0,16,128,256,261,273,396,0,129,1,0,399,0,260,272,1,0,397,17,138,9,17,397,0,0,261,21,260,257,137,1,261]

theorem envBound21342 : H12AffineFastState.Bounded env21342 := by
  intro p hp
  have h : env21342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21341_21342 : H12AffineEnvironment.transform 10 396 env21341 = env21342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env21341 == env21342) = true)

theorem identity21342 : scanCanonicalize (H12AffineFastState.compose env21342 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound21342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21343 : List Nat := [2,4,8,16,0,16,128,140,137,157,0,0,129,1,0,3,0,136,156,1,0,1,17,138,9,17,1,0,0,137,21,136,141,137,1,137]

theorem envBound21343 : H12AffineFastState.Bounded env21343 := by
  intro p hp
  have h : env21343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21342_21343 : H12AffineEnvironment.transform 7 140 env21342 = env21343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env21342 == env21343) = true)

def env21344 : List Nat := [2,4,8,16,1,16,128,256,260,273,2048,0,2317,1,0,2051,0,261,272,1,0,2048,17,2310,2437,17,2049,0,0,260,21,261,257,136,1,260]

theorem envBound21344 : H12AffineFastState.Bounded env21344 := by
  intro p hp
  have h : env21344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21340_21344 : H12AffineEnvironment.transform 4 1 env21340 = env21344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21340 == env21344) = true)

def env21345 : List Nat := [2,4,8,16,1,16,128,256,260,273,136,0,389,1,0,139,0,261,272,1,0,136,17,398,269,17,137,0,0,260,21,261,257,136,1,260]

theorem envBound21345 : H12AffineFastState.Bounded env21345 := by
  intro p hp
  have h : env21345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21344_21345 : H12AffineEnvironment.transform 10 136 env21344 = env21345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env21344 == env21345) = true)

def env21346 : List Nat := [2,4,8,16,1,16,128,256,260,273,137,0,388,1,0,138,0,261,272,1,0,137,17,399,268,17,136,0,0,260,21,261,257,136,1,260]

theorem envBound21346 : H12AffineFastState.Bounded env21346 := by
  intro p hp
  have h : env21346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21344_21346 : H12AffineEnvironment.transform 10 137 env21344 = env21346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env21344 == env21346) = true)

theorem identity21346 : scanCanonicalize (H12AffineFastState.compose env21346 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21347 : List Nat := [2,4,8,16,1,16,128,4,0,21,137,0,128,1,0,138,0,1,20,1,0,137,17,139,8,17,136,0,0,0,21,1,5,136,1,0]

theorem envBound21347 : H12AffineFastState.Bounded env21347 := by
  intro p hp
  have h : env21347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21346_21347 : H12AffineEnvironment.transform 7 4 env21346 = env21347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21346 == env21347) = true)

def leafEnv21347 : List Nat := [2,4,8,16,1,16,128,4,0,21,137,0,128,1,0,138,0,1,20,1,0,137,17,139,20,8,1,17,136,0,0,0,21,1,5,136,5,3,1,0,0,0,1]

def active21347 : List Nat := [0,1,2,3,6]

def tree21347 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21347 : H12WitnessSearch.Good tree21347 := H12GlobalWitnessIndex.good

theorem leafIdentity21347 : H12AffineFastState.composeSystem env21347 rootObs = leafEnv21347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21347 rootObs == leafEnv21347) = true)

theorem terminalChecked21347 : H12PackedTerminal.terminalCheckFast leafEnv21347 active21347 tree21347 = true := by decide +kernel

def env21348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,10792,65536,1296,513,1025,10793,1296,8713,17,76589,8328,16,8460,1297,1297,11021,1284,4294967296,257,4295035278,1297,512]

theorem envBound21348 : H12AffineFastState.Bounded env21348 := by
  intro p hp
  have h : env21348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21310_21348 : H12AffineEnvironment.transform 5 17 env21310 = env21348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21310 == env21348) = true)

theorem identity21348 : scanCanonicalize (H12AffineFastState.compose env21348 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound21348 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,10792,8614,1296,513,1025,10793,1296,8713,17,2699,8328,16,8460,1297,1297,11021,1284,4294967296,257,4294977576,1297,512]

theorem envBound21349 : H12AffineFastState.Bounded env21349 := by
  intro p hp
  have h : env21349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21348_21349 : H12AffineEnvironment.transform 15 8614 env21348 = env21349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env21348 == env21349) = true)

theorem identity21349 : scanCanonicalize (H12AffineFastState.compose env21349 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound21349 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21350 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1296,8192,1296,8232,8614,1296,513,1025,8233,1296,8713,17,139,8328,16,8460,1297,1297,8461,1284,4294967296,257,4294976040,1297,512]

theorem envBound21350 : H12AffineFastState.Bounded env21350 := by
  intro p hp
  have h : env21350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2