import H12CloudChart2Data166

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound41768 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env41769 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,8250,277,8379,273,8541,80,397,260,8235,8409,260,319,324,80,2145,8205,8476,257,64,0,592]

theorem envBound41769 : H12AffineFastState.Bounded env41769 := by
  intro p hp
  have h : env41769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41768_41769 : H12AffineEnvironment.transform 15 8250 env41768 = env41769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env41768 == env41769) = true)

def env41770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123165,28888,78894,385202,90414,1296,96347,25884,82999,257,1280,1345,21073]

theorem envBound41770 : H12AffineFastState.Bounded env41770 := by
  intro p hp
  have h : env41770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41515_41770 : H12AffineEnvironment.transform 18 21585 env41515 = env41770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env41515 == env41770) = true)

theorem identity41770 : scanCanonicalize (H12AffineFastState.compose env41770 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound41770 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4096,17613,91183,87297,28888,78894,349358,90414,1296,96347,25884,82999,257,1280,1345,21073]

theorem envBound41771 : H12AffineFastState.Bounded env41771 := by
  intro p hp
  have h : env41771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41770_41771 : H12AffineEnvironment.transform 14 13340 env41770 = env41771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41770 == env41771) = true)

def env41772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4096,477,74047,69649,13768,78894,332222,74814,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound41772 : H12AffineFastState.Bounded env41772 := by
  intro p hp
  have h : env41772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41771_41772 : H12AffineEnvironment.transform 13 1296 env41771 = env41772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41771 == env41772) = true)

def env41773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4096,477,74047,69649,13768,78894,4414,74814,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound41773 : H12AffineFastState.Bounded env41773 := by
  intro p hp
  have h : env41773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41772_41773 : H12AffineEnvironment.transform 17 65664 env41772 = env41773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41772 == env41773) = true)

theorem identity41773 : scanCanonicalize (H12AffineFastState.compose env41773 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound41773 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,65536,66678,65664,4417,5125,4096,477,65831,69649,5584,70710,4414,66598,1296,73043,20,65831,257,1280,1345,5953]

theorem envBound41774 : H12AffineFastState.Bounded env41774 := by
  intro p hp
  have h : env41774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41773_41774 : H12AffineEnvironment.transform 12 24 env41773 = env41774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env41773 == env41774) = true)

def env41775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1052,106,1180,4417,5125,4096,477,1339,5133,5584,4138,4414,58,1296,6479,20,1339,257,1280,1345,5953]

theorem envBound41775 : H12AffineFastState.Bounded env41775 := by
  intro p hp
  have h : env41775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41774_41775 : H12AffineEnvironment.transform 15 1052 env41774 = env41775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env41774 == env41775) = true)

theorem identity41775 : scanCanonicalize (H12AffineFastState.compose env41775 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 585) := by decide +kernel

theorem selectedBound41775 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env41776 : List Nat := [2,4,8,16,32,64,128,256,512,585,2048,4096,24,857,4685,597,106,725,4417,4684,4096,477,882,4676,5017,4138,4414,58,857,6479,20,882,257,841,776,4360]

theorem envBound41776 : H12AffineFastState.Bounded env41776 := by
  intro p hp
  have h : env41776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41775_41776 : H12AffineEnvironment.transform 9 585 env41775 = env41776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 585 env41775 == env41776) = true)

def env41777 : List Nat := [2,4,8,16,32,64,128,256,340,285,2048,4096,24,13,4377,257,106,385,4417,4376,4096,477,38,4368,4301,4138,4414,58,13,6479,20,38,257,29,92,4360]

theorem envBound41777 : H12AffineFastState.Bounded env41777 := by
  intro p hp
  have h : env41777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41776_41777 : H12AffineEnvironment.transform 8 340 env41776 = env41777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env41776 == env41777) = true)

def env41778 : List Nat := [2,4,8,16,32,64,128,256,340,285,2048,16,24,13,265,257,106,385,337,264,16,477,38,256,221,58,302,58,13,2399,20,38,257,29,92,280]

theorem envBound41778 : H12AffineFastState.Bounded env41778 := by
  intro p hp
  have h : env41778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41777_41778 : H12AffineEnvironment.transform 11 16 env41777 = env41778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41777 == env41778) = true)

def env41779 : List Nat := [2,4,8,16,32,64,128,256,340,285,2048,17,24,13,264,257,106,385,336,265,17,477,38,257,220,59,303,58,13,2398,20,38,257,29,92,281]

theorem envBound41779 : H12AffineFastState.Bounded env41779 := by
  intro p hp
  have h : env41779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41777_41779 : H12AffineEnvironment.transform 11 17 env41777 = env41779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41777 == env41779) = true)

theorem identity41779 : scanCanonicalize (H12AffineFastState.compose env41779 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41779 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env41780 : List Nat := [2,4,4,16,32,64,128,256,340,273,2048,17,20,1,260,257,102,385,336,261,17,465,38,257,208,55,291,54,1,2386,20,38,257,17,80,277]

theorem envBound41780 : H12AffineFastState.Bounded env41780 := by
  intro p hp
  have h : env41780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41779_41780 : H12AffineEnvironment.transform 2 4 env41779 = env41780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41779 == env41780) = true)

theorem identity41780 : scanCanonicalize (H12AffineFastState.compose env41780 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound41780 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41781 : List Nat := [2,4,4,16,32,64,128,115,39,98,2048,17,20,1,119,114,102,242,35,118,17,162,38,114,208,55,80,54,1,2081,20,38,114,17,80,102]

theorem envBound41781 : H12AffineFastState.Bounded env41781 := by
  intro p hp
  have h : env41781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41780_41781 : H12AffineEnvironment.transform 7 115 env41780 = env41781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env41780 == env41781) = true)

theorem identity41781 : scanCanonicalize (H12AffineFastState.compose env41781 (packedSelected [15,17] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound41781 : packedSelected [15,17] rootPS < 2^1333 := by decide +kernel

def env41782 : List Nat := [2,4,4,16,32,64,36,115,39,98,2048,17,20,1,119,114,102,86,35,118,17,6,38,114,116,55,80,54,1,2081,20,38,114,17,80,102]

theorem envBound41782 : H12AffineFastState.Bounded env41782 := by
  intro p hp
  have h : env41782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41781_41782 : H12AffineEnvironment.transform 6 36 env41781 = env41782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env41781 == env41782) = true)

theorem identity41782 : scanCanonicalize (H12AffineFastState.compose env41782 (packedSelected [1,3,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound41782 : packedSelected [1,3,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env41783 : List Nat := [2,4,4,16,32,64,36,115,39,98,65,17,20,1,119,114,102,86,35,118,17,6,38,114,116,55,80,54,1,96,20,38,114,17,80,102]

theorem envBound41783 : H12AffineFastState.Bounded env41783 := by
  intro p hp
  have h : env41783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41782_41783 : H12AffineEnvironment.transform 10 65 env41782 = env41783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env41782 == env41783) = true)

theorem identity41783 : scanCanonicalize (H12AffineFastState.compose env41783 (packedSelected [0,1,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound41783 : packedSelected [0,1,4,5,8] rootPS < 2^1333 := by decide +kernel

def env41784 : List Nat := [2,4,4,16,32,1,36,50,39,35,0,17,20,1,54,51,39,23,35,55,17,6,38,51,53,55,17,54,1,33,20,38,51,17,17,39]

theorem envBound41784 : H12AffineFastState.Bounded env41784 := by
  intro p hp
  have h : env41784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41783_41784 : H12AffineEnvironment.transform 5 1 env41783 = env41784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41783 == env41784) = true)

theorem identity41784 : scanCanonicalize (H12AffineFastState.compose env41784 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41784 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env41785 : List Nat := [2,4,4,16,0,1,4,18,7,3,0,17,20,1,22,19,7,23,3,23,17,6,6,19,21,23,17,22,1,1,20,6,19,17,17,7]

theorem envBound41785 : H12AffineFastState.Bounded env41785 := by
  intro p hp
  have h : env41785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41784_41785 : H12AffineEnvironment.transform 4 0 env41784 = env41785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41784 == env41785) = true)

theorem identity41785 : scanCanonicalize (H12AffineFastState.compose env41785 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41786 : List Nat := [2,3,3,16,0,1,3,18,0,3,0,17,19,1,17,19,0,16,3,16,17,1,1,19,18,16,17,17,1,1,19,1,19,17,17,0]

theorem envBound41786 : H12AffineFastState.Bounded env41786 := by
  intro p hp
  have h : env41786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41785_41786 : H12AffineEnvironment.transform 1 3 env41785 = env41786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41785 == env41786) = true)

def env41787 : List Nat := [2,4,8,16,32,64,128,256,341,284,2048,4096,24,12,4376,256,106,384,4417,4377,4096,477,39,4369,4300,4138,4414,58,12,6479,20,39,257,28,93,4360]

theorem envBound41787 : H12AffineFastState.Bounded env41787 := by
  intro p hp
  have h : env41787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41776_41787 : H12AffineEnvironment.transform 8 341 env41776 = env41787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env41776 == env41787) = true)

def env41788 : List Nat := [2,4,8,16,32,64,128,256,341,284,2048,16,24,12,264,256,106,384,337,265,16,477,39,257,220,58,302,58,12,2399,20,39,257,28,93,280]

theorem envBound41788 : H12AffineFastState.Bounded env41788 := by
  intro p hp
  have h : env41788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41787_41788 : H12AffineEnvironment.transform 11 16 env41787 = env41788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41787 == env41788) = true)

theorem identity41788 : scanCanonicalize (H12AffineFastState.compose env41788 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41788 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env41789 : List Nat := [2,4,8,16,23,64,128,256,341,284,2048,16,24,12,264,256,93,384,337,265,16,477,16,257,220,13,281,13,12,2399,20,16,257,28,93,280]

theorem envBound41789 : H12AffineFastState.Bounded env41789 := by
  intro p hp
  have h : env41789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41788_41789 : H12AffineEnvironment.transform 4 23 env41788 = env41789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41788 == env41789) = true)

theorem identity41789 : scanCanonicalize (H12AffineFastState.compose env41789 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound41789 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41790 : List Nat := [2,4,8,16,23,64,128,24,77,4,2048,16,24,12,16,24,93,152,73,17,16,197,16,25,220,13,1,13,12,2119,20,16,25,28,93,0]

theorem envBound41790 : H12AffineFastState.Bounded env41790 := by
  intro p hp
  have h : env41790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41789_41790 : H12AffineEnvironment.transform 7 24 env41789 = env41790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env41789 == env41790) = true)

theorem identity41790 : scanCanonicalize (H12AffineFastState.compose env41790 (packedSelected [2,3,5,8,11,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound41790 : packedSelected [2,3,5,8,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41791 : List Nat := [2,4,8,16,23,28,128,24,17,4,2048,16,24,12,16,24,1,152,21,17,16,153,16,25,128,13,1,13,12,2075,20,16,25,28,1,0]

theorem envBound41791 : H12AffineFastState.Bounded env41791 := by
  intro p hp
  have h : env41791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41790_41791 : H12AffineEnvironment.transform 5 28 env41790 = env41791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env41790 == env41791) = true)

theorem identity41791 : scanCanonicalize (H12AffineFastState.compose env41791 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound41791 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env41792 : List Nat := [2,4,8,16,23,28,128,24,17,4,7,16,24,12,16,24,1,152,21,17,16,153,16,25,128,13,1,13,12,28,20,16,25,28,1,0]

theorem envBound41792 : H12AffineFastState.Bounded env41792 := by
  intro p hp
  have h : env41792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41791_41792 : H12AffineEnvironment.transform 10 7 env41791 = env41792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env41791 == env41792) = true)

theorem identity41792 : scanCanonicalize (H12AffineFastState.compose env41792 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound41792 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env41793 : List Nat := [2,4,8,16,23,28,24,24,17,4,7,16,24,12,16,24,1,0,21,17,16,1,16,25,24,13,1,13,12,28,20,16,25,28,1,0]

theorem envBound41793 : H12AffineFastState.Bounded env41793 := by
  intro p hp
  have h : env41793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41792_41793 : H12AffineEnvironment.transform 6 24 env41792 = env41793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env41792 == env41793) = true)

theorem identity41793 : scanCanonicalize (H12AffineFastState.compose env41793 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41794 : List Nat := [2,4,4,16,23,16,20,20,17,4,7,16,20,0,16,20,1,0,21,17,16,1,16,21,20,1,1,1,0,16,20,16,21,16,1,0]

theorem envBound41794 : H12AffineFastState.Bounded env41794 := by
  intro p hp
  have h : env41794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41793_41794 : H12AffineEnvironment.transform 2 4 env41793 = env41794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41793 == env41794) = true)

theorem identity41794 : scanCanonicalize (H12AffineFastState.compose env41794 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41794 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41795 : List Nat := [2,4,4,1,6,1,5,5,0,4,7,1,5,0,1,5,1,0,4,0,1,1,1,4,5,1,1,1,0,1,5,1,4,1,1,0]

theorem envBound41795 : H12AffineFastState.Bounded env41795 := by
  intro p hp
  have h : env41795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41794_41795 : H12AffineEnvironment.transform 3 1 env41794 = env41795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41794 == env41795) = true)

theorem identity41795 : scanCanonicalize (H12AffineFastState.compose env41795 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41796 : List Nat := [2,3,3,1,1,1,2,2,0,3,0,1,2,0,1,2,1,0,3,0,1,1,1,3,2,1,1,1,0,1,2,1,3,1,1,0]

theorem envBound41796 : H12AffineFastState.Bounded env41796 := by
  intro p hp
  have h : env41796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41795_41796 : H12AffineEnvironment.transform 1 3 env41795 = env41796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41795 == env41796) = true)

def env41797 : List Nat := [2,4,8,16,32,64,128,256,341,284,2048,17,24,12,265,256,106,384,336,264,17,477,39,256,221,59,303,58,12,2398,20,39,257,28,93,281]

theorem envBound41797 : H12AffineFastState.Bounded env41797 := by
  intro p hp
  have h : env41797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41787_41797 : H12AffineEnvironment.transform 11 17 env41787 = env41797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41787 == env41797) = true)

theorem identity41797 : scanCanonicalize (H12AffineFastState.compose env41797 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound41797 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env41798 : List Nat := [2,4,8,16,27,64,128,256,341,284,2048,17,24,12,265,256,81,384,336,264,17,477,28,256,221,0,276,1,12,2398,20,28,257,28,93,281]

theorem envBound41798 : H12AffineFastState.Bounded env41798 := by
  intro p hp
  have h : env41798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41797_41798 : H12AffineEnvironment.transform 4 27 env41797 = env41798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env41797 == env41798) = true)

theorem identity41798 : scanCanonicalize (H12AffineFastState.compose env41798 (packedSelected [1,3,8,19] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound41798 : packedSelected [1,3,8,19] rootPS < 2^1333 := by decide +kernel

def env41799 : List Nat := [2,4,8,16,27,64,128,256,341,284,390,17,24,12,265,256,81,384,336,264,17,477,28,256,221,0,276,1,12,216,20,28,257,28,93,281]

theorem envBound41799 : H12AffineFastState.Bounded env41799 := by
  intro p hp
  have h : env41799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41798_41799 : H12AffineEnvironment.transform 10 390 env41798 = env41799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env41798 == env41799) = true)

theorem identity41799 : scanCanonicalize (H12AffineFastState.compose env41799 (packedSelected [0,3,5,7,8,10,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound41799 : packedSelected [0,3,5,7,8,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env41800 : List Nat := [2,4,8,13,6,64,128,256,328,257,390,12,5,12,265,256,76,384,333,264,12,448,1,256,192,0,265,1,12,197,9,1,257,1,64,260]

theorem envBound41800 : H12AffineFastState.Bounded env41800 := by
  intro p hp
  have h : env41800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41799_41800 : H12AffineEnvironment.transform 3 13 env41799 = env41800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env41799 == env41800) = true)

theorem identity41800 : scanCanonicalize (H12AffineFastState.compose env41800 (packedSelected [0,2,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound41800 : packedSelected [0,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env41801 : List Nat := [2,4,8,13,6,64,128,3,75,2,133,12,5,12,10,3,76,131,78,11,12,195,1,3,192,0,10,1,12,197,9,1,2,1,64,7]

theorem envBound41801 : H12AffineFastState.Bounded env41801 := by
  intro p hp
  have h : env41801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41800_41801 : H12AffineEnvironment.transform 7 3 env41800 = env41801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env41800 == env41801) = true)

theorem identity41801 : scanCanonicalize (H12AffineFastState.compose env41801 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound41801 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env41802 : List Nat := [2,4,8,13,6,64,2,3,75,2,7,12,5,12,10,3,76,1,78,11,12,65,1,3,66,0,10,1,12,71,9,1,2,1,64,7]

theorem envBound41802 : H12AffineFastState.Bounded env41802 := by
  intro p hp
  have h : env41802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41801_41802 : H12AffineEnvironment.transform 6 2 env41801 = env41802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env41801 == env41802) = true)

def env41803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1053,107,1181,4417,5125,4096,477,1338,5132,5584,4139,4414,59,1296,6478,20,1338,257,1280,1345,5953]

theorem envBound41803 : H12AffineFastState.Bounded env41803 := by
  intro p hp
  have h : env41803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41774_41803 : H12AffineEnvironment.transform 15 1053 env41774 = env41803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env41774 == env41803) = true)

theorem identity41803 : scanCanonicalize (H12AffineFastState.compose env41803 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 627) := by decide +kernel

theorem selectedBound41803 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env41804 : List Nat := [2,4,8,16,32,64,128,256,512,627,2048,4096,24,867,4727,622,107,750,4417,4726,4096,477,841,4735,5027,4139,4414,59,867,6478,20,841,257,883,818,4402]

theorem envBound41804 : H12AffineFastState.Bounded env41804 := by
  intro p hp
  have h : env41804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41803_41804 : H12AffineEnvironment.transform 9 627 env41803 = env41804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 627 env41803 == env41804) = true)

def env41805 : List Nat := [2,4,8,16,32,64,128,256,512,627,2048,16,24,867,615,622,107,750,337,614,16,477,841,623,947,59,302,59,867,2398,20,841,257,883,818,290]

theorem envBound41805 : H12AffineFastState.Bounded env41805 := by
  intro p hp
  have h : env41805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41804_41805 : H12AffineEnvironment.transform 11 16 env41804 = env41805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41804 == env41805) = true)

def env41806 : List Nat := [2,4,8,16,32,64,128,256,344,299,2048,16,24,59,319,310,107,438,337,318,16,477,17,311,235,59,302,59,59,2398,20,17,257,43,106,290]

theorem envBound41806 : H12AffineFastState.Bounded env41806 := by
  intro p hp
  have h : env41806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41805_41806 : H12AffineEnvironment.transform 8 344 env41805 = env41806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 344 env41805 == env41806) = true)

theorem identity41806 : scanCanonicalize (H12AffineFastState.compose env41806 (packedSelected [0,2,3,7,8,11,15,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound41806 : packedSelected [0,2,3,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41807 : List Nat := [2,4,8,16,32,64,128,135,223,172,2048,16,24,59,184,177,107,49,214,185,16,90,17,176,235,59,169,59,59,2265,20,17,134,43,106,165]

theorem envBound41807 : H12AffineFastState.Bounded env41807 := by
  intro p hp
  have h : env41807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41806_41807 : H12AffineEnvironment.transform 7 135 env41806 = env41807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env41806 == env41807) = true)

theorem identity41807 : scanCanonicalize (H12AffineFastState.compose env41807 (packedSelected [0,1,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound41807 : packedSelected [0,1,9,11,15] rootPS < 2^1333 := by decide +kernel

def env41808 : List Nat := [2,4,8,16,32,64,24,31,71,52,2048,16,24,59,32,41,107,49,78,33,16,90,17,40,115,59,49,59,59,2113,20,17,30,43,106,61]

theorem envBound41808 : H12AffineFastState.Bounded env41808 := by
  intro p hp
  have h : env41808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41807_41808 : H12AffineEnvironment.transform 6 24 env41807 = env41808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env41807 == env41808) = true)

theorem identity41808 : scanCanonicalize (H12AffineFastState.compose env41808 (packedSelected [1,7,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound41808 : packedSelected [1,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env41809 : List Nat := [2,4,8,16,32,26,24,31,29,52,2048,16,24,59,32,41,49,49,20,33,16,0,17,40,41,59,49,59,59,2075,20,17,30,43,48,61]

theorem envBound41809 : H12AffineFastState.Bounded env41809 := by
  intro p hp
  have h : env41809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41808_41809 : H12AffineEnvironment.transform 5 26 env41808 = env41809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env41808 == env41809) = true)

theorem identity41809 : scanCanonicalize (H12AffineFastState.compose env41809 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound41809 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41810 : List Nat := [2,4,8,16,32,26,24,31,29,52,39,16,24,59,32,41,49,49,20,33,16,0,17,40,41,59,49,59,59,60,20,17,30,43,48,61]

theorem envBound41810 : H12AffineFastState.Bounded env41810 := by
  intro p hp
  have h : env41810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41809_41810 : H12AffineEnvironment.transform 10 39 env41809 = env41810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env41809 == env41810) = true)

theorem identity41810 : scanCanonicalize (H12AffineFastState.compose env41810 (packedSelected [0,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41810 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env41811 : List Nat := [2,4,4,16,32,22,20,19,17,52,39,16,20,55,32,37,49,49,20,33,16,0,17,36,37,55,49,55,55,48,20,17,18,39,48,49]

theorem envBound41811 : H12AffineFastState.Bounded env41811 := by
  intro p hp
  have h : env41811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41810_41811 : H12AffineEnvironment.transform 2 4 env41810 = env41811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41810 == env41811) = true)

theorem identity41811 : scanCanonicalize (H12AffineFastState.compose env41811 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41811 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41812 : List Nat := [2,2,2,16,32,16,18,19,17,50,33,16,18,49,32,35,49,49,18,33,16,0,17,34,35,49,49,49,49,48,18,17,18,33,48,49]

theorem envBound41812 : H12AffineFastState.Bounded env41812 := by
  intro p hp
  have h : env41812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41811_41812 : H12AffineEnvironment.transform 1 2 env41811 = env41812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41811 == env41812) = true)

theorem identity41812 : scanCanonicalize (H12AffineFastState.compose env41812 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41812 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41813 : List Nat := [2,2,2,16,1,16,18,19,17,19,0,16,18,16,1,2,16,16,18,0,16,0,17,3,2,16,16,16,16,17,18,17,18,0,17,16]

theorem envBound41813 : H12AffineFastState.Bounded env41813 := by
  intro p hp
  have h : env41813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41812_41813 : H12AffineEnvironment.transform 4 1 env41812 = env41813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41812 == env41813) = true)

theorem identity41813 : scanCanonicalize (H12AffineFastState.compose env41813 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound41813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41814 : List Nat := [2,2,2,2,1,2,0,1,3,1,0,2,0,2,1,2,2,2,0,0,2,0,3,3,2,2,2,2,2,3,0,3,0,0,3,2]

theorem envBound41814 : H12AffineFastState.Bounded env41814 := by
  intro p hp
  have h : env41814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41813_41814 : H12AffineEnvironment.transform 3 2 env41813 = env41814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env41813 == env41814) = true)

def env41815 : List Nat := [2,4,8,16,32,64,128,256,345,298,2048,16,24,58,318,311,107,439,337,319,16,477,16,310,234,59,302,59,58,2398,20,16,257,42,107,290]

theorem envBound41815 : H12AffineFastState.Bounded env41815 := by
  intro p hp
  have h : env41815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41805_41815 : H12AffineEnvironment.transform 8 345 env41805 = env41815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 345 env41805 == env41815) = true)

theorem identity41815 : scanCanonicalize (H12AffineFastState.compose env41815 (packedSelected [0,2,3,7,8,11,15,18,20] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41815 : packedSelected [0,2,3,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41816 : List Nat := [2,4,8,16,23,64,128,256,345,285,2048,16,24,13,265,256,92,384,337,264,16,477,16,257,221,12,281,12,13,2398,20,16,257,29,92,277]

theorem envBound41816 : H12AffineFastState.Bounded env41816 := by
  intro p hp
  have h : env41816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41815_41816 : H12AffineEnvironment.transform 4 23 env41815 = env41816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41815 == env41816) = true)

theorem identity41816 : scanCanonicalize (H12AffineFastState.compose env41816 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound41816 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41817 : List Nat := [2,4,8,16,23,64,128,25,64,4,2048,16,24,13,16,25,92,153,72,17,16,196,16,24,221,12,0,12,13,2119,20,16,24,29,92,12]

theorem envBound41817 : H12AffineFastState.Bounded env41817 := by
  intro p hp
  have h : env41817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41816_41817 : H12AffineEnvironment.transform 7 25 env41816 = env41817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env41816 == env41817) = true)

theorem identity41817 : scanCanonicalize (H12AffineFastState.compose env41817 (packedSelected [1,3,4,5,8,9,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound41817 : packedSelected [1,3,4,5,8,9,12,16,17] rootPS < 2^1333 := by decide +kernel

def env41818 : List Nat := [2,4,8,16,23,64,88,25,64,4,2048,16,24,13,16,25,92,65,72,17,16,28,16,24,5,12,0,12,13,2119,20,16,24,29,92,12]

theorem envBound41818 : H12AffineFastState.Bounded env41818 := by
  intro p hp
  have h : env41818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41817_41818 : H12AffineEnvironment.transform 6 88 env41817 = env41818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env41817 == env41818) = true)

theorem identity41818 : scanCanonicalize (H12AffineFastState.compose env41818 (packedSelected [1,4,5,7,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound41818 : packedSelected [1,4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env41819 : List Nat := [2,4,8,16,23,28,4,25,28,4,2048,16,24,13,16,25,0,29,20,17,16,28,16,24,5,12,0,12,13,2075,20,16,24,29,0,12]

theorem envBound41819 : H12AffineFastState.Bounded env41819 := by
  intro p hp
  have h : env41819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41818_41819 : H12AffineEnvironment.transform 5 28 env41818 = env41819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env41818 == env41819) = true)

theorem identity41819 : scanCanonicalize (H12AffineFastState.compose env41819 (packedSelected [1,2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound41819 : packedSelected [1,2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env41820 : List Nat := [2,4,8,16,23,28,4,25,28,4,29,16,24,13,16,25,0,29,20,17,16,28,16,24,5,12,0,12,13,6,20,16,24,29,0,12]

theorem envBound41820 : H12AffineFastState.Bounded env41820 := by
  intro p hp
  have h : env41820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41819_41820 : H12AffineEnvironment.transform 10 29 env41819 = env41820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env41819 == env41820) = true)

theorem identity41820 : scanCanonicalize (H12AffineFastState.compose env41820 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41820 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41821 : List Nat := [2,4,3,16,23,23,4,18,23,4,22,16,19,6,16,18,0,22,20,17,16,23,16,19,5,7,0,7,6,6,20,16,19,22,0,7]

theorem envBound41821 : H12AffineFastState.Bounded env41821 := by
  intro p hp
  have h : env41821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41820_41821 : H12AffineEnvironment.transform 2 3 env41820 = env41821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41820 == env41821) = true)

theorem identity41821 : scanCanonicalize (H12AffineFastState.compose env41821 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41821 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41822 : List Nat := [2,4,3,7,0,0,4,5,0,4,1,7,4,6,7,5,0,1,3,6,7,0,7,4,5,7,0,7,6,6,3,7,4,1,0,7]

theorem envBound41822 : H12AffineFastState.Bounded env41822 := by
  intro p hp
  have h : env41822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41821_41822 : H12AffineEnvironment.transform 3 7 env41821 = env41822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41821 == env41822) = true)

def env41823 : List Nat := [2,4,8,16,32,64,128,256,512,627,2048,17,24,867,614,622,107,750,336,615,17,477,841,622,946,58,303,59,867,2399,20,841,257,883,818,291]

theorem envBound41823 : H12AffineFastState.Bounded env41823 := by
  intro p hp
  have h : env41823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41804_41823 : H12AffineEnvironment.transform 11 17 env41804 = env41823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41804 == env41823) = true)

def env41824 : List Nat := [2,4,8,16,32,64,128,256,344,299,2048,17,24,59,318,310,107,438,336,319,17,477,17,310,234,58,303,59,59,2399,20,17,257,43,106,291]

theorem envBound41824 : H12AffineFastState.Bounded env41824 := by
  intro p hp
  have h : env41824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41823_41824 : H12AffineEnvironment.transform 8 344 env41823 = env41824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 344 env41823 == env41824) = true)

theorem identity41824 : scanCanonicalize (H12AffineFastState.compose env41824 (packedSelected [0,2,3,7,8,11,15,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound41824 : packedSelected [0,2,3,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41825 : List Nat := [2,4,8,16,32,64,128,189,229,150,2048,17,24,59,131,139,107,11,237,130,17,96,17,139,234,58,146,59,59,2274,20,17,188,43,106,158]

theorem envBound41825 : H12AffineFastState.Bounded env41825 := by
  intro p hp
  have h : env41825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41824_41825 : H12AffineEnvironment.transform 7 189 env41824 = env41825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env41824 == env41825) = true)

theorem identity41825 : scanCanonicalize (H12AffineFastState.compose env41825 (packedSelected [1,2,3,5,7,9,10,11,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 245) := by decide +kernel

theorem selectedBound41825 : packedSelected [1,2,3,5,7,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env41826 : List Nat := [2,4,8,16,32,64,128,189,229,150,245,17,24,59,131,139,107,11,237,130,17,96,17,139,234,58,146,59,59,23,20,17,188,43,106,158]

theorem envBound41826 : H12AffineFastState.Bounded env41826 := by
  intro p hp
  have h : env41826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41825_41826 : H12AffineEnvironment.transform 10 245 env41825 = env41826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 245 env41825 == env41826) = true)

theorem identity41826 : scanCanonicalize (H12AffineFastState.compose env41826 (packedSelected [1,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound41826 : packedSelected [1,12,15] rootPS < 2^1333 := by decide +kernel

def env41827 : List Nat := [2,4,8,16,32,64,85,104,48,67,32,17,24,59,86,94,107,11,56,87,17,96,17,94,63,58,71,59,59,23,20,17,105,43,106,75]

theorem envBound41827 : H12AffineFastState.Bounded env41827 := by
  intro p hp
  have h : env41827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41826_41827 : H12AffineEnvironment.transform 6 85 env41826 = env41827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env41826 == env41827) = true)

theorem identity41827 : scanCanonicalize (H12AffineFastState.compose env41827 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41827 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env41828 : List Nat := [2,4,8,12,32,64,73,104,44,67,32,13,4,39,74,66,107,11,36,75,13,96,13,66,35,38,71,39,39,11,8,13,105,43,106,75]

theorem envBound41828 : H12AffineFastState.Bounded env41828 := by
  intro p hp
  have h : env41828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41827_41828 : H12AffineEnvironment.transform 3 12 env41827 = env41828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41827 == env41828) = true)

theorem identity41828 : scanCanonicalize (H12AffineFastState.compose env41828 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound41828 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env41829 : List Nat := [2,4,8,12,32,45,36,5,44,46,32,13,4,39,39,47,6,11,36,38,13,13,13,47,35,38,42,39,39,11,8,13,4,43,7,38]

theorem envBound41829 : H12AffineFastState.Bounded env41829 := by
  intro p hp
  have h : env41829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41828_41829 : H12AffineEnvironment.transform 5 45 env41828 = env41829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env41828 == env41829) = true)

theorem identity41829 : scanCanonicalize (H12AffineFastState.compose env41829 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41829 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env41830 : List Nat := [2,4,8,12,0,13,4,5,12,14,0,13,4,7,7,15,6,11,4,6,13,13,13,15,3,6,10,7,7,11,8,13,4,11,7,6]

theorem envBound41830 : H12AffineFastState.Bounded env41830 := by
  intro p hp
  have h : env41830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41829_41830 : H12AffineEnvironment.transform 4 0 env41829 = env41830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41829 == env41830) = true)

theorem identity41830 : scanCanonicalize (H12AffineFastState.compose env41830 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41830 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41831 : List Nat := [2,3,8,11,0,10,3,2,11,9,0,10,3,0,0,8,1,11,3,1,10,10,10,8,3,1,10,0,0,11,8,10,3,11,0,1]

theorem envBound41831 : H12AffineFastState.Bounded env41831 := by
  intro p hp
  have h : env41831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41830_41831 : H12AffineEnvironment.transform 1 3 env41830 = env41831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41830 == env41831) = true)

theorem identity41831 : scanCanonicalize (H12AffineFastState.compose env41831 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41832 : List Nat := [2,3,3,0,0,1,3,2,0,2,0,1,3,0,0,3,1,0,3,1,1,1,1,3,3,1,1,0,0,0,3,1,3,0,0,1]

theorem envBound41832 : H12AffineFastState.Bounded env41832 := by
  intro p hp
  have h : env41832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41831_41832 : H12AffineEnvironment.transform 2 3 env41831 = env41832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41831 == env41832) = true)

theorem identity41832 : scanCanonicalize (H12AffineFastState.compose env41832 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41833 : List Nat := [1,0,0,0,0,1,0,1,0,1,0,1,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,0,1,0,0,0,1]

theorem envBound41833 : H12AffineFastState.Bounded env41833 := by
  intro p hp
  have h : env41833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41832_41833 : H12AffineEnvironment.transform 0 1 env41832 = env41833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41832 == env41833) = true)

def env41834 : List Nat := [2,4,8,16,32,64,128,256,345,298,2048,17,24,58,319,311,107,439,336,318,17,477,16,311,235,58,303,59,58,2399,20,16,257,42,107,291]

theorem envBound41834 : H12AffineFastState.Bounded env41834 := by
  intro p hp
  have h : env41834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41823_41834 : H12AffineEnvironment.transform 8 345 env41823 = env41834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 345 env41823 == env41834) = true)

theorem identity41834 : scanCanonicalize (H12AffineFastState.compose env41834 (packedSelected [0,2,3,7,8,11,15,18,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41834 : packedSelected [0,2,3,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41835 : List Nat := [2,4,5,16,32,64,128,256,340,295,2048,17,21,55,306,311,102,439,336,307,17,464,16,311,230,55,290,54,55,2386,20,16,257,39,102,291]

theorem envBound41835 : H12AffineFastState.Bounded env41835 := by
  intro p hp
  have h : env41835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41834_41835 : H12AffineEnvironment.transform 2 5 env41834 = env41835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41834 == env41835) = true)

theorem identity41835 : scanCanonicalize (H12AffineFastState.compose env41835 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound41835 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41836 : List Nat := [2,4,5,16,32,64,128,35,119,4,2048,17,21,55,17,20,102,148,115,16,17,243,16,20,230,55,1,54,55,2161,20,16,34,39,102,0]

theorem envBound41836 : H12AffineFastState.Bounded env41836 := by
  intro p hp
  have h : env41836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41835_41836 : H12AffineEnvironment.transform 7 35 env41835 = env41836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env41835 == env41836) = true)

theorem identity41836 : scanCanonicalize (H12AffineFastState.compose env41836 (packedSelected [2,3,5,8,11,15,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41836 : packedSelected [2,3,5,8,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41837 : List Nat := [2,4,5,0,32,64,128,35,103,4,2048,1,5,39,1,4,102,132,99,0,1,227,0,4,230,39,1,38,39,2145,4,0,34,39,102,0]

theorem envBound41837 : H12AffineFastState.Bounded env41837 := by
  intro p hp
  have h : env41837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41836_41837 : H12AffineEnvironment.transform 3 0 env41836 = env41837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41836 == env41837) = true)

theorem identity41837 : scanCanonicalize (H12AffineFastState.compose env41837 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound41837 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env41838 : List Nat := [2,4,5,0,32,64,67,35,103,4,2048,1,5,39,1,4,102,71,99,0,1,32,0,4,37,39,1,38,39,2145,4,0,34,39,102,0]

theorem envBound41838 : H12AffineFastState.Bounded env41838 := by
  intro p hp
  have h : env41838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41837_41838 : H12AffineEnvironment.transform 6 67 env41837 = env41838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env41837 == env41838) = true)

theorem identity41838 : scanCanonicalize (H12AffineFastState.compose env41838 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound41838 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41839 : List Nat := [2,4,5,0,32,6,5,35,33,4,2048,1,5,39,1,4,32,1,37,0,1,32,0,4,37,39,1,38,39,2087,4,0,34,39,32,0]

theorem envBound41839 : H12AffineFastState.Bounded env41839 := by
  intro p hp
  have h : env41839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41838_41839 : H12AffineEnvironment.transform 5 6 env41838 = env41839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env41838 == env41839) = true)

theorem identity41839 : scanCanonicalize (H12AffineFastState.compose env41839 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41839 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41840 : List Nat := [2,4,5,0,32,6,5,35,33,4,0,1,5,39,1,4,32,1,37,0,1,32,0,4,37,39,1,38,39,39,4,0,34,39,32,0]

theorem envBound41840 : H12AffineFastState.Bounded env41840 := by
  intro p hp
  have h : env41840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41839_41840 : H12AffineEnvironment.transform 10 0 env41839 = env41840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41839 == env41840) = true)

theorem identity41840 : scanCanonicalize (H12AffineFastState.compose env41840 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41841 : List Nat := [2,4,5,0,1,6,5,2,0,4,0,1,5,6,1,4,1,1,4,0,1,1,0,4,4,6,1,7,6,6,4,0,3,6,1,0]

theorem envBound41841 : H12AffineFastState.Bounded env41841 := by
  intro p hp
  have h : env41841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41840_41841 : H12AffineEnvironment.transform 4 1 env41840 = env41841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41840 == env41841) = true)

theorem identity41841 : scanCanonicalize (H12AffineFastState.compose env41841 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41842 : List Nat := [2,3,2,0,1,1,2,2,0,3,0,1,2,1,1,3,1,1,3,0,1,1,0,3,3,1,1,0,1,1,3,0,3,1,1,0]

theorem envBound41842 : H12AffineFastState.Bounded env41842 := by
  intro p hp
  have h : env41842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41841_41842 : H12AffineEnvironment.transform 1 3 env41841 = env41842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41841 == env41842) = true)

def env41843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4096,477,74047,69649,13768,78894,4415,74814,1296,81227,8204,65831,257,1280,1345,5953]

theorem envBound41843 : H12AffineFastState.Bounded env41843 := by
  intro p hp
  have h : env41843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41772_41843 : H12AffineEnvironment.transform 17 65665 env41772 = env41843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41772 == env41843) = true)

theorem identity41843 : scanCanonicalize (H12AffineFastState.compose env41843 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound41843 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,69942,65665,4417,325,4096,477,70759,69649,144,65910,4415,69990,1296,67603,5460,65831,257,1280,1345,5953]

theorem envBound41844 : H12AffineFastState.Bounded env41844 := by
  intro p hp
  have h : env41844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41843_41844 : H12AffineEnvironment.transform 12 5464 env41843 = env41844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env41843 == env41844) = true)

def env41845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,1052,5418,1181,4417,325,4096,477,4219,5133,144,1386,4415,5498,1296,3087,5460,1339,257,1280,1345,5953]

theorem envBound41845 : H12AffineFastState.Bounded env41845 := by
  intro p hp
  have h : env41845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41844_41845 : H12AffineEnvironment.transform 15 1052 env41844 = env41845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env41844 == env41845) = true)

theorem identity41845 : scanCanonicalize (H12AffineFastState.compose env41845 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 822) := by decide +kernel

theorem selectedBound41845 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env41846 : List Nat := [2,4,8,16,32,64,128,256,512,822,2048,4096,4718,550,324,810,4636,939,4417,325,4096,477,4219,4923,144,604,4415,4684,550,2873,4706,525,257,566,631,4215]

theorem envBound41846 : H12AffineFastState.Bounded env41846 := by
  intro p hp
  have h : env41846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41845_41846 : H12AffineEnvironment.transform 9 822 env41845 = env41846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 822 env41845 == env41846) = true)

def env41847 : List Nat := [2,4,8,16,32,64,128,256,340,98,2048,4096,4410,370,324,126,4424,255,4417,325,4096,477,4219,4207,144,264,4415,4376,370,2157,4406,345,257,354,291,4215]

theorem envBound41847 : H12AffineFastState.Bounded env41847 := by
  intro p hp
  have h : env41847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41846_41847 : H12AffineEnvironment.transform 8 340 env41846 = env41847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env41846 == env41847) = true)

def env41848 : List Nat := [2,4,8,16,32,0,128,256,276,34,2048,4096,4410,306,260,62,4360,191,4353,261,4096,413,4155,4143,144,264,4415,4376,306,2093,4406,281,257,290,291,4151]

theorem envBound41848 : H12AffineFastState.Bounded env41848 := by
  intro p hp
  have h : env41848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41847_41848 : H12AffineEnvironment.transform 5 0 env41847 = env41848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41847 == env41848) = true)

theorem identity41848 : scanCanonicalize (H12AffineFastState.compose env41848 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41848 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env41849 : List Nat := [2,4,4,16,32,0,128,256,276,34,2048,4096,4406,306,260,50,4356,179,4353,261,4096,401,4151,4131,144,260,4403,4372,306,2081,4406,277,257,290,291,4151]

theorem envBound41849 : H12AffineFastState.Bounded env41849 := by
  intro p hp
  have h : env41849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41848_41849 : H12AffineEnvironment.transform 2 4 env41848 = env41849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41848 == env41849) = true)

theorem identity41849 : scanCanonicalize (H12AffineFastState.compose env41849 (packedSelected [2,8,10,11,15,16,17,18,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound41849 : packedSelected [2,8,10,11,15,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env41850 : List Nat := [2,4,4,16,32,0,128,256,276,34,2048,2065,2343,306,260,50,2325,179,2320,261,2065,401,2086,2098,144,260,2338,2309,306,2081,2343,277,257,290,291,2086]

theorem envBound41850 : H12AffineFastState.Bounded env41850 := by
  intro p hp
  have h : env41850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41849_41850 : H12AffineEnvironment.transform 11 2065 env41849 = env41850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env41849 == env41850) = true)

theorem identity41850 : scanCanonicalize (H12AffineFastState.compose env41850 (packedSelected [0,2,4,5,7,9,10,12,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound41850 : packedSelected [0,2,4,5,7,9,10,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env41851 : List Nat := [2,4,4,16,32,0,3,256,276,34,2048,2065,2343,306,260,50,2325,48,2320,261,2065,274,2086,2098,19,260,2338,2309,306,2081,2343,277,257,290,291,2086]

theorem envBound41851 : H12AffineFastState.Bounded env41851 := by
  intro p hp
  have h : env41851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41850_41851 : H12AffineEnvironment.transform 6 3 env41850 = env41851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env41850 == env41851) = true)

theorem identity41851 : scanCanonicalize (H12AffineFastState.compose env41851 (packedSelected [0,1,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound41851 : packedSelected [0,1,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41852 : List Nat := [2,4,4,16,32,0,3,256,276,34,258,275,37,306,260,50,23,48,18,261,275,274,292,304,19,260,32,7,306,291,37,277,257,290,291,292]

theorem envBound41852 : H12AffineFastState.Bounded env41852 := by
  intro p hp
  have h : env41852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41851_41852 : H12AffineEnvironment.transform 10 258 env41851 = env41852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env41851 == env41852) = true)

theorem identity41852 : scanCanonicalize (H12AffineFastState.compose env41852 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41852 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41853 : List Nat := [2,4,4,16,17,0,3,256,276,19,258,275,20,259,260,3,23,1,18,261,275,274,277,257,19,260,17,7,259,274,20,277,257,275,274,277]

theorem envBound41853 : H12AffineFastState.Bounded env41853 := by
  intro p hp
  have h : env41853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41852_41853 : H12AffineEnvironment.transform 4 17 env41852 = env41853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41852 == env41853) = true)

theorem identity41853 : scanCanonicalize (H12AffineFastState.compose env41853 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 22) := by decide +kernel

theorem selectedBound41853 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41854 : List Nat := [2,4,4,16,17,0,3,22,2,19,20,5,20,21,18,3,23,1,18,19,5,4,3,23,19,18,17,7,21,4,20,3,23,5,4,3]

theorem envBound41854 : H12AffineFastState.Bounded env41854 := by
  intro p hp
  have h : env41854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41853_41854 : H12AffineEnvironment.transform 7 22 env41853 = env41854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 22 env41853 == env41854) = true)

def env41855 : List Nat := [2,4,8,16,32,1,128,256,277,35,2048,4096,4410,307,261,63,4361,190,4352,260,4096,412,4154,4142,144,264,4415,4376,307,2092,4406,280,257,291,291,4150]

theorem envBound41855 : H12AffineFastState.Bounded env41855 := by
  intro p hp
  have h : env41855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41847_41855 : H12AffineEnvironment.transform 5 1 env41847 = env41855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41847 == env41855) = true)

theorem identity41855 : scanCanonicalize (H12AffineFastState.compose env41855 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 29) := by decide +kernel

theorem selectedBound41855 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env41856 : List Nat := [2,4,8,16,32,1,128,256,277,35,2048,29,295,307,261,63,276,190,285,260,29,412,39,51,144,264,290,261,307,2092,299,280,257,291,291,43]

theorem envBound41856 : H12AffineFastState.Bounded env41856 := by
  intro p hp
  have h : env41856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41855_41856 : H12AffineEnvironment.transform 11 29 env41855 = env41856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 29 env41855 == env41856) = true)

theorem identity41856 : scanCanonicalize (H12AffineFastState.compose env41856 (packedSelected [4,5,9,10,11,12,15,18,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 306) := by decide +kernel

theorem selectedBound41856 : packedSelected [4,5,9,10,11,12,15,18,21,23] rootPS < 2^1333 := by decide +kernel

def env41857 : List Nat := [2,4,8,16,32,1,128,256,277,35,306,29,295,307,261,63,276,190,285,260,29,412,39,51,144,264,290,261,307,286,299,280,257,291,291,43]

theorem envBound41857 : H12AffineFastState.Bounded env41857 := by
  intro p hp
  have h : env41857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41856_41857 : H12AffineEnvironment.transform 10 306 env41856 = env41857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 306 env41856 == env41857) = true)

theorem identity41857 : scanCanonicalize (H12AffineFastState.compose env41857 (packedSelected [1,3,5,8,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound41857 : packedSelected [1,3,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env41858 : List Nat := [2,4,8,16,32,1,21,256,277,35,306,29,295,307,261,63,276,43,285,260,29,265,39,51,5,264,290,261,307,286,299,280,257,291,291,43]

theorem envBound41858 : H12AffineFastState.Bounded env41858 := by
  intro p hp
  have h : env41858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41857_41858 : H12AffineEnvironment.transform 6 21 env41857 = env41858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env41857 == env41858) = true)

theorem identity41858 : scanCanonicalize (H12AffineFastState.compose env41858 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41858 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env41859 : List Nat := [2,4,8,16,32,1,21,4,17,35,54,29,35,55,1,63,16,43,25,0,29,13,39,51,5,12,38,1,55,26,47,28,5,39,39,43]

theorem envBound41859 : H12AffineFastState.Bounded env41859 := by
  intro p hp
  have h : env41859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41858_41859 : H12AffineEnvironment.transform 7 4 env41858 = env41859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41858 == env41859) = true)

theorem identity41859 : scanCanonicalize (H12AffineFastState.compose env41859 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41859 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41860 : List Nat := [2,4,8,0,32,1,5,4,1,35,38,13,35,39,1,47,0,43,9,0,13,13,39,35,5,12,38,1,39,10,47,12,5,39,39,43]

theorem envBound41860 : H12AffineFastState.Bounded env41860 := by
  intro p hp
  have h : env41860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41859_41860 : H12AffineEnvironment.transform 3 0 env41859 = env41860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41859 == env41860) = true)

theorem identity41860 : scanCanonicalize (H12AffineFastState.compose env41860 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41860 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41861 : List Nat := [2,4,8,0,0,1,5,4,1,3,6,13,3,7,1,15,0,11,9,0,13,13,7,3,5,12,6,1,7,10,15,12,5,7,7,11]

theorem envBound41861 : H12AffineFastState.Bounded env41861 := by
  intro p hp
  have h : env41861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41860_41861 : H12AffineEnvironment.transform 4 0 env41860 = env41861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41860 == env41861) = true)

theorem identity41861 : scanCanonicalize (H12AffineFastState.compose env41861 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41861 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41862 : List Nat := [2,2,8,0,0,1,3,2,1,3,0,11,3,1,1,9,0,11,9,0,11,11,1,3,3,10,0,1,1,10,9,10,3,1,1,11]

theorem envBound41862 : H12AffineFastState.Bounded env41862 := by
  intro p hp
  have h : env41862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41861_41862 : H12AffineEnvironment.transform 1 2 env41861 = env41862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41861 == env41862) = true)

theorem identity41862 : scanCanonicalize (H12AffineFastState.compose env41862 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41862 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41863 : List Nat := [2,2,3,0,0,1,3,2,1,3,0,0,3,1,1,2,0,0,2,0,0,0,1,3,3,1,0,1,1,1,2,1,3,1,1,0]

theorem envBound41863 : H12AffineFastState.Bounded env41863 := by
  intro p hp
  have h : env41863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41862_41863 : H12AffineEnvironment.transform 2 3 env41862 = env41863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41862 == env41863) = true)

theorem identity41863 : scanCanonicalize (H12AffineFastState.compose env41863 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41864 : List Nat := [0,0,1,0,0,1,1,0,1,1,0,0,1,1,1,0,0,0,0,0,0,0,1,1,1,1,0,1,1,1,0,1,1,1,1,0]

theorem envBound41864 : H12AffineFastState.Bounded env41864 := by
  intro p hp
  have h : env41864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41863_41864 : H12AffineEnvironment.transform 0 0 env41863 = env41864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41863 == env41864) = true)

def env41865 : List Nat := [2,4,8,16,32,64,128,256,341,99,2048,4096,4411,371,324,127,4425,254,4417,325,4096,477,4219,4206,144,265,4415,4377,371,2156,4407,344,257,355,290,4215]

theorem envBound41865 : H12AffineFastState.Bounded env41865 := by
  intro p hp
  have h : env41865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41846_41865 : H12AffineEnvironment.transform 8 341 env41846 = env41865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env41846 == env41865) = true)

def env41866 : List Nat := [2,4,8,16,32,0,128,256,277,35,2048,4096,4411,307,260,63,4361,190,4353,261,4096,413,4155,4142,144,265,4415,4377,307,2092,4407,280,257,291,290,4151]

theorem envBound41866 : H12AffineFastState.Bounded env41866 := by
  intro p hp
  have h : env41866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41865_41866 : H12AffineEnvironment.transform 5 0 env41865 = env41866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41865 == env41866) = true)

theorem identity41866 : scanCanonicalize (H12AffineFastState.compose env41866 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 39) := by decide +kernel

theorem selectedBound41866 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env41867 : List Nat := [2,4,8,16,32,0,128,256,277,35,2048,39,284,307,260,63,302,190,294,261,39,413,28,9,144,265,280,318,307,2092,272,280,257,291,290,16]

theorem envBound41867 : H12AffineFastState.Bounded env41867 := by
  intro p hp
  have h : env41867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41866_41867 : H12AffineEnvironment.transform 11 39 env41866 = env41867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 39 env41866 == env41867) = true)

theorem identity41867 : scanCanonicalize (H12AffineFastState.compose env41867 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound41867 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env41868 : List Nat := [2,4,8,16,32,0,128,62,43,35,2048,39,34,13,58,63,16,190,24,59,39,163,28,9,144,55,38,0,13,2092,46,38,63,29,28,16]

theorem envBound41868 : H12AffineFastState.Bounded env41868 := by
  intro p hp
  have h : env41868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41867_41868 : H12AffineEnvironment.transform 7 62 env41867 = env41868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env41867 == env41868) = true)

theorem identity41868 : scanCanonicalize (H12AffineFastState.compose env41868 (packedSelected [0,3,5,7,10,15,18] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41868 : packedSelected [0,3,5,7,10,15,18] rootPS < 2^1333 := by decide +kernel

def env41869 : List Nat := [2,4,8,7,32,0,128,41,43,35,2048,39,34,13,45,40,7,169,15,44,39,163,11,9,135,32,38,0,13,2092,46,38,40,10,11,7]

theorem envBound41869 : H12AffineFastState.Bounded env41869 := by
  intro p hp
  have h : env41869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41868_41869 : H12AffineEnvironment.transform 3 7 env41868 = env41869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41868 == env41869) = true)

theorem identity41869 : scanCanonicalize (H12AffineFastState.compose env41869 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound41869 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env41870 : List Nat := [2,4,8,7,32,0,128,41,43,35,162,39,34,13,45,40,7,169,15,44,39,163,11,9,135,32,38,0,13,142,46,38,40,10,11,7]

theorem envBound41870 : H12AffineFastState.Bounded env41870 := by
  intro p hp
  have h : env41870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41869_41870 : H12AffineEnvironment.transform 10 162 env41869 = env41870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env41869 == env41870) = true)

theorem identity41870 : scanCanonicalize (H12AffineFastState.compose env41870 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41870 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41871 : List Nat := [2,4,2,7,32,0,128,35,33,35,162,39,34,7,39,34,7,163,5,38,39,163,1,3,135,32,38,0,7,132,36,38,34,0,1,7]

theorem envBound41871 : H12AffineFastState.Bounded env41871 := by
  intro p hp
  have h : env41871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41870_41871 : H12AffineEnvironment.transform 2 2 env41870 = env41871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41870 == env41871) = true)

theorem identity41871 : scanCanonicalize (H12AffineFastState.compose env41871 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound41871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41872 : List Nat := [2,4,2,7,32,0,4,35,33,35,38,39,34,7,39,34,7,39,5,38,39,39,1,3,3,32,38,0,7,0,36,38,34,0,1,7]

theorem envBound41872 : H12AffineFastState.Bounded env41872 := by
  intro p hp
  have h : env41872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41871_41872 : H12AffineEnvironment.transform 6 4 env41871 = env41872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env41871 == env41872) = true)

theorem identity41872 : scanCanonicalize (H12AffineFastState.compose env41872 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41873 : List Nat := [2,2,2,1,32,0,2,35,33,35,32,33,34,1,33,34,1,33,3,32,33,33,1,3,3,32,32,0,1,0,34,32,34,0,1,1]

theorem envBound41873 : H12AffineFastState.Bounded env41873 := by
  intro p hp
  have h : env41873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41872_41873 : H12AffineEnvironment.transform 1 2 env41872 = env41873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41872 == env41873) = true)

theorem identity41873 : scanCanonicalize (H12AffineFastState.compose env41873 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41873 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41874 : List Nat := [2,2,2,1,0,0,2,3,1,3,0,1,2,1,1,2,1,1,3,0,1,1,1,3,3,0,0,0,1,0,2,0,2,0,1,1]

theorem envBound41874 : H12AffineFastState.Bounded env41874 := by
  intro p hp
  have h : env41874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41873_41874 : H12AffineEnvironment.transform 4 0 env41873 = env41874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41873 == env41874) = true)

def env41875 : List Nat := [2,4,8,16,32,1,128,256,276,34,2048,4096,4411,306,261,62,4360,191,4352,260,4096,412,4154,4143,144,265,4415,4377,306,2093,4407,281,257,290,290,4150]

theorem envBound41875 : H12AffineFastState.Bounded env41875 := by
  intro p hp
  have h : env41875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41865_41875 : H12AffineEnvironment.transform 5 1 env41865 = env41875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41865 == env41875) = true)

theorem identity41875 : scanCanonicalize (H12AffineFastState.compose env41875 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41875 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env41876 : List Nat := [2,4,8,16,23,1,128,256,276,21,2048,4096,4364,261,261,9,4360,136,4352,260,4096,412,4109,4120,144,265,4360,4377,261,2074,4352,281,257,277,277,4097]

theorem envBound41876 : H12AffineFastState.Bounded env41876 := by
  intro p hp
  have h : env41876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41875_41876 : H12AffineEnvironment.transform 4 23 env41875 = env41876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41875 == env41876) = true)

theorem identity41876 : scanCanonicalize (H12AffineFastState.compose env41876 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound41876 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env41877 : List Nat := [2,4,8,16,23,1,128,8,28,21,2048,4096,4100,13,13,9,4096,136,4104,12,4096,148,4109,4120,144,1,4096,4113,13,2074,4104,17,9,29,29,4097]

theorem envBound41877 : H12AffineFastState.Bounded env41877 := by
  intro p hp
  have h : env41877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41876_41877 : H12AffineEnvironment.transform 7 8 env41876 = env41877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env41876 == env41877) = true)

theorem identity41877 : scanCanonicalize (H12AffineFastState.compose env41877 (packedSelected [1,2,3,8,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2197) := by decide +kernel

theorem selectedBound41877 : packedSelected [1,2,3,8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env41878 : List Nat := [2,4,8,16,23,1,128,8,28,21,2048,2197,2193,13,13,9,2197,136,2205,12,2197,148,2200,2189,144,1,2197,2180,13,2074,2205,17,9,29,29,2196]

theorem envBound41878 : H12AffineFastState.Bounded env41878 := by
  intro p hp
  have h : env41878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41877_41878 : H12AffineEnvironment.transform 11 2197 env41877 = env41878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2197 env41877 == env41878) = true)

theorem identity41878 : scanCanonicalize (H12AffineFastState.compose env41878 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound41878 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env41879 : List Nat := [2,4,8,16,23,1,20,8,28,21,2048,2049,2053,13,13,9,2049,28,2057,12,2049,0,2060,2073,4,1,2049,2064,13,2074,2057,17,9,29,29,2048]

theorem envBound41879 : H12AffineFastState.Bounded env41879 := by
  intro p hp
  have h : env41879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41878_41879 : H12AffineEnvironment.transform 6 20 env41878 = env41879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env41878 == env41879) = true)

theorem identity41879 : scanCanonicalize (H12AffineFastState.compose env41879 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41879 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41880 : List Nat := [2,3,8,16,16,1,19,8,27,18,2048,2049,2050,10,10,9,2049,27,2057,11,2049,0,2059,2073,3,1,2049,2064,10,2074,2057,17,9,26,26,2048]

theorem envBound41880 : H12AffineFastState.Bounded env41880 := by
  intro p hp
  have h : env41880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41879_41880 : H12AffineEnvironment.transform 1 3 env41879 = env41880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41879 == env41880) = true)

theorem identity41880 : scanCanonicalize (H12AffineFastState.compose env41880 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41880 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41881 : List Nat := [2,3,3,16,16,1,19,3,16,18,2048,2049,2050,1,1,2,2049,16,2050,0,2049,0,2048,2066,3,1,2049,2064,1,2065,2050,17,2,17,17,2048]

theorem envBound41881 : H12AffineFastState.Bounded env41881 := by
  intro p hp
  have h : env41881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41880_41881 : H12AffineEnvironment.transform 2 3 env41880 = env41881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41880 == env41881) = true)

theorem identity41881 : scanCanonicalize (H12AffineFastState.compose env41881 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41882 : List Nat := [2,3,3,1,1,1,2,3,1,3,2048,2049,2050,1,1,2,2049,1,2050,0,2049,0,2048,2051,3,1,2049,2049,1,2048,2050,0,2,0,0,2048]

theorem envBound41882 : H12AffineFastState.Bounded env41882 := by
  intro p hp
  have h : env41882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41881_41882 : H12AffineEnvironment.transform 3 1 env41881 = env41882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41881 == env41882) = true)

def env41883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,1053,5419,1180,4417,325,4096,477,4218,5132,144,1387,4415,5499,1296,3086,5460,1338,257,1280,1345,5953]

theorem envBound41883 : H12AffineFastState.Bounded env41883 := by
  intro p hp
  have h : env41883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41844_41883 : H12AffineEnvironment.transform 15 1053 env41844 = env41883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env41844 == env41883) = true)

theorem identity41883 : scanCanonicalize (H12AffineFastState.compose env41883 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 781) := by decide +kernel

theorem selectedBound41883 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env41884 : List Nat := [2,4,8,16,32,64,128,256,512,781,2048,4096,4693,541,324,784,4646,913,4417,325,4096,477,4218,4865,144,614,4415,4726,541,2819,4697,567,257,525,588,4172]

theorem envBound41884 : H12AffineFastState.Bounded env41884 := by
  intro p hp
  have h : env41884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41883_41884 : H12AffineEnvironment.transform 9 781 env41883 = env41884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 781 env41883 == env41884) = true)

def env41885 : List Nat := [2,4,8,16,32,64,128,68,512,585,2048,4096,4693,541,0,596,4646,725,4101,1,4096,153,4218,4677,144,614,4219,4726,541,2631,4697,567,69,525,588,4172]

theorem envBound41885 : H12AffineFastState.Bounded env41885 := by
  intro p hp
  have h : env41885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41884_41885 : H12AffineEnvironment.transform 7 68 env41884 = env41885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41884 == env41885) = true)

theorem identity41885 : scanCanonicalize (H12AffineFastState.compose env41885 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 58) := by decide +kernel

theorem selectedBound41885 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41886 : List Nat := [2,4,8,16,32,64,128,68,512,585,2048,58,623,541,0,596,540,725,63,1,58,153,64,639,144,614,65,588,541,2631,611,567,69,525,588,118]

theorem envBound41886 : H12AffineFastState.Bounded env41886 := by
  intro p hp
  have h : env41886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41885_41886 : H12AffineEnvironment.transform 11 58 env41885 = env41886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 58 env41885 == env41886) = true)

theorem identity41886 : scanCanonicalize (H12AffineFastState.compose env41886 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound41886 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41887 : List Nat := [2,4,8,16,27,64,128,68,512,585,2048,1,596,541,0,596,540,725,4,1,1,153,64,580,144,605,65,588,541,2631,600,524,69,525,588,77]

theorem envBound41887 : H12AffineFastState.Bounded env41887 := by
  intro p hp
  have h : env41887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41886_41887 : H12AffineEnvironment.transform 4 27 env41886 = env41887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env41886 == env41887) = true)

theorem identity41887 : scanCanonicalize (H12AffineFastState.compose env41887 (packedSelected [2,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound41887 : packedSelected [2,10,17] rootPS < 2^1333 := by decide +kernel

def env41888 : List Nat := [2,4,8,16,27,64,85,68,512,585,2048,1,596,541,0,596,540,512,4,1,1,76,64,580,69,605,65,588,541,2631,600,524,69,525,588,77]

theorem envBound41888 : H12AffineFastState.Bounded env41888 := by
  intro p hp
  have h : env41888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41887_41888 : H12AffineEnvironment.transform 6 85 env41887 = env41888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env41887 == env41888) = true)

theorem identity41888 : scanCanonicalize (H12AffineFastState.compose env41888 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound41888 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41889 : List Nat := [2,4,8,16,27,0,21,4,512,521,2048,1,532,541,0,532,540,512,4,1,1,12,0,516,5,541,1,524,541,2567,536,524,5,525,524,13]

theorem envBound41889 : H12AffineFastState.Bounded env41889 := by
  intro p hp
  have h : env41889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41888_41889 : H12AffineEnvironment.transform 5 0 env41888 = env41889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41888 == env41889) = true)

theorem identity41889 : scanCanonicalize (H12AffineFastState.compose env41889 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41889 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41890 : List Nat := [2,4,8,16,27,0,21,4,10,3,2048,1,30,23,0,30,22,10,4,1,1,12,0,14,5,23,1,6,23,2061,18,6,5,7,6,13]

theorem envBound41890 : H12AffineFastState.Bounded env41890 := by
  intro p hp
  have h : env41890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41889_41890 : H12AffineEnvironment.transform 8 10 env41889 = env41890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41889 == env41890) = true)

theorem identity41890 : scanCanonicalize (H12AffineFastState.compose env41890 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound41890 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41891 : List Nat := [2,4,8,16,27,0,21,4,10,3,22,1,30,23,0,30,22,10,4,1,1,12,0,14,5,23,1,6,23,27,18,6,5,7,6,13]

theorem envBound41891 : H12AffineFastState.Bounded env41891 := by
  intro p hp
  have h : env41891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41890_41891 : H12AffineEnvironment.transform 10 22 env41890 = env41891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env41890 == env41891) = true)

theorem identity41891 : scanCanonicalize (H12AffineFastState.compose env41891 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41891 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41892 : List Nat := [2,4,4,16,23,0,21,4,6,3,22,1,18,23,0,18,22,6,4,1,1,0,0,2,5,23,1,6,23,23,18,6,5,7,6,1]

theorem envBound41892 : H12AffineFastState.Bounded env41892 := by
  intro p hp
  have h : env41892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41891_41892 : H12AffineEnvironment.transform 2 4 env41891 = env41892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41891 == env41892) = true)

theorem identity41892 : scanCanonicalize (H12AffineFastState.compose env41892 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41893 : List Nat := [2,4,4,7,0,0,2,4,6,3,1,1,5,0,0,5,1,6,4,1,1,0,0,2,5,0,1,6,0,0,5,6,5,7,6,1]

theorem envBound41893 : H12AffineFastState.Bounded env41893 := by
  intro p hp
  have h : env41893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41892_41893 : H12AffineEnvironment.transform 3 7 env41892 = env41893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41892 == env41893) = true)

def env41894 : List Nat := [2,4,8,16,32,64,128,69,512,584,2048,4096,4693,541,1,597,4646,724,4100,0,4096,152,4218,4676,144,614,4218,4726,541,2630,4697,567,68,525,588,4172]

theorem envBound41894 : H12AffineFastState.Bounded env41894 := by
  intro p hp
  have h : env41894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41884_41894 : H12AffineEnvironment.transform 7 69 env41884 = env41894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env41884 == env41894) = true)

theorem identity41894 : scanCanonicalize (H12AffineFastState.compose env41894 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41894 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41895 : List Nat := [2,4,8,16,32,64,128,69,512,584,2048,0,597,541,1,597,550,724,4,0,0,152,122,580,144,614,122,630,541,2630,601,567,68,525,588,76]

theorem envBound41895 : H12AffineFastState.Bounded env41895 := by
  intro p hp
  have h : env41895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41894_41895 : H12AffineEnvironment.transform 11 0 env41894 = env41895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41894 == env41895) = true)

theorem identity41895 : scanCanonicalize (H12AffineFastState.compose env41895 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 76) := by decide +kernel

theorem selectedBound41895 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41896 : List Nat := [2,4,8,16,32,64,128,69,76,4,2048,0,25,81,1,25,106,152,4,0,0,152,122,8,144,42,122,58,81,2058,21,123,68,65,0,76]

theorem envBound41896 : H12AffineFastState.Bounded env41896 := by
  intro p hp
  have h : env41896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41895_41896 : H12AffineEnvironment.transform 8 76 env41895 = env41896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 76 env41895 == env41896) = true)

theorem identity41896 : scanCanonicalize (H12AffineFastState.compose env41896 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound41896 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41897 : List Nat := [2,4,8,16,26,64,128,69,76,4,2048,0,25,81,1,25,80,152,4,0,0,152,64,8,144,16,64,0,81,2058,21,65,68,65,0,76]

theorem envBound41897 : H12AffineFastState.Bounded env41897 := by
  intro p hp
  have h : env41897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41896_41897 : H12AffineEnvironment.transform 4 26 env41896 = env41897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env41896 == env41897) = true)

theorem identity41897 : scanCanonicalize (H12AffineFastState.compose env41897 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound41897 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41898 : List Nat := [2,4,8,16,26,23,128,18,27,4,2048,0,25,6,1,25,7,152,4,0,0,152,23,8,144,16,23,0,6,2058,21,22,19,22,0,27]

theorem envBound41898 : H12AffineFastState.Bounded env41898 := by
  intro p hp
  have h : env41898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41897_41898 : H12AffineEnvironment.transform 5 23 env41897 = env41898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env41897 == env41898) = true)

theorem identity41898 : scanCanonicalize (H12AffineFastState.compose env41898 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41898 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env41899 : List Nat := [2,4,8,16,26,23,19,18,27,4,2048,0,25,6,1,25,7,11,4,0,0,11,23,8,3,16,23,0,6,2058,21,22,19,22,0,27]

theorem envBound41899 : H12AffineFastState.Bounded env41899 := by
  intro p hp
  have h : env41899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41898_41899 : H12AffineEnvironment.transform 6 19 env41898 = env41899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41898 == env41899) = true)

def env41900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4096,476,74046,69648,13769,78894,332223,74815,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound41900 : H12AffineFastState.Bounded env41900 := by
  intro p hp
  have h : env41900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41771_41900 : H12AffineEnvironment.transform 13 1297 env41771 = env41900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41771 == env41900) = true)

def env41901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4096,476,74046,69648,13769,78894,4415,74815,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound41901 : H12AffineFastState.Bounded env41901 := by
  intro p hp
  have h : env41901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41900_41901 : H12AffineEnvironment.transform 17 65664 env41900 = env41901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41900 == env41901) = true)

theorem identity41901 : scanCanonicalize (H12AffineFastState.compose env41901 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound41901 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,65536,74862,65664,273,9292,81,476,74046,65601,9624,74879,366,74815,1296,77083,8205,65830,257,1280,1345,1809]

theorem envBound41902 : H12AffineFastState.Bounded env41902 := by
  intro p hp
  have h : env41902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41901_41902 : H12AffineEnvironment.transform 11 81 env41901 = env41902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env41901 == env41902) = true)

def env41903 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8461,65536,74030,65664,273,8460,81,476,74046,65601,8408,74047,366,74111,80,75867,8205,65830,257,64,1,593]

theorem envBound41903 : H12AffineFastState.Bounded env41903 := by
  intro p hp
  have h : env41903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41902_41903 : H12AffineEnvironment.transform 9 320 env41902 = env41903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41902 == env41903) = true)

theorem identity41903 : scanCanonicalize (H12AffineFastState.compose env41903 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound41903 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env41904 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8461,8298,324,8426,273,8460,81,476,340,8235,8408,341,366,277,80,2097,8205,8524,257,64,1,593]

theorem envBound41904 : H12AffineFastState.Bounded env41904 := by
  intro p hp
  have h : env41904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41903_41904 : H12AffineEnvironment.transform 15 8298 env41903 = env41904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env41903 == env41904) = true)

theorem identity41904 : scanCanonicalize (H12AffineFastState.compose env41904 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41904 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41905 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,81,8192,81,8265,8298,0,8426,85,8264,81,152,16,8235,8408,17,42,81,80,2097,8205,8200,69,64,1,593]

theorem envBound41905 : H12AffineFastState.Bounded env41905 := by
  intro p hp
  have h : env41905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41904_41905 : H12AffineEnvironment.transform 7 68 env41904 = env41905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41904 == env41905) = true)

theorem identity41905 : scanCanonicalize (H12AffineFastState.compose env41905 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2192) := by decide +kernel

theorem selectedBound41905 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env41906 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,81,2192,81,2265,2298,0,2170,85,2264,81,152,16,2235,2120,17,42,81,80,2097,2205,2200,69,64,1,593]

theorem envBound41906 : H12AffineFastState.Bounded env41906 := by
  intro p hp
  have h : env41906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41905_41906 : H12AffineEnvironment.transform 12 2192 env41905 = env41906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2192 env41905 == env41906) = true)

theorem identity41906 : scanCanonicalize (H12AffineFastState.compose env41906 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound41906 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41907 : List Nat := [2,4,8,16,32,64,128,68,26,4,2048,81,2192,81,2265,2298,0,2170,85,2264,81,152,16,2235,2120,17,42,81,80,2097,2205,2200,69,64,1,75]

theorem envBound41907 : H12AffineFastState.Bounded env41907 := by
  intro p hp
  have h : env41907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41906_41907 : H12AffineEnvironment.transform 8 26 env41906 = env41907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env41906 == env41907) = true)

theorem identity41907 : scanCanonicalize (H12AffineFastState.compose env41907 (packedSelected [0,1,7,8,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound41907 : packedSelected [0,1,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env41908 : List Nat := [2,4,8,16,32,64,35,68,26,4,2048,81,2099,81,2170,2137,0,2170,85,2171,81,59,16,2072,2120,17,42,81,80,2097,2110,2107,69,64,1,75]

theorem envBound41908 : H12AffineFastState.Bounded env41908 := by
  intro p hp
  have h : env41908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41907_41908 : H12AffineEnvironment.transform 6 35 env41907 = env41908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env41907 == env41908) = true)

theorem identity41908 : scanCanonicalize (H12AffineFastState.compose env41908 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41908 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41909 : List Nat := [2,4,8,16,17,64,18,68,26,4,2048,81,2050,81,2123,2137,0,2123,85,2122,81,10,16,2072,2120,17,27,81,80,2048,2063,2058,69,64,1,75]

theorem envBound41909 : H12AffineFastState.Bounded env41909 := by
  intro p hp
  have h : env41909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41908_41909 : H12AffineEnvironment.transform 4 17 env41908 = env41909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41908 == env41909) = true)

theorem identity41909 : scanCanonicalize (H12AffineFastState.compose env41909 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound41909 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41910 : List Nat := [2,4,8,16,17,64,18,68,26,4,80,81,82,81,27,9,0,27,85,26,81,10,16,72,24,17,27,81,80,80,95,90,69,64,1,75]

theorem envBound41910 : H12AffineFastState.Bounded env41910 := by
  intro p hp
  have h : env41910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41909_41910 : H12AffineEnvironment.transform 10 80 env41909 = env41910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env41909 == env41910) = true)

theorem identity41910 : scanCanonicalize (H12AffineFastState.compose env41910 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound41910 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41911 : List Nat := [2,4,8,16,17,11,18,15,26,4,27,26,25,26,27,9,0,27,30,26,26,10,16,3,24,17,27,26,27,27,20,17,14,11,1,0]

theorem envBound41911 : H12AffineFastState.Bounded env41911 := by
  intro p hp
  have h : env41911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41910_41911 : H12AffineEnvironment.transform 5 11 env41910 = env41911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env41910 == env41911) = true)

theorem identity41911 : scanCanonicalize (H12AffineFastState.compose env41911 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41912 : List Nat := [2,4,8,10,11,11,8,15,0,4,1,0,3,0,1,9,0,1,4,0,0,10,10,3,2,11,1,0,1,1,14,11,14,11,1,0]

theorem envBound41912 : H12AffineFastState.Bounded env41912 := by
  intro p hp
  have h : env41912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41911_41912 : H12AffineEnvironment.transform 3 10 env41911 = env41912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41911 == env41912) = true)

theorem identity41912 : scanCanonicalize (H12AffineFastState.compose env41912 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41913 : List Nat := [2,2,8,10,11,11,8,9,0,2,1,0,3,0,1,9,0,1,2,0,0,10,10,3,2,11,1,0,1,1,8,11,8,11,1,0]

theorem envBound41913 : H12AffineFastState.Bounded env41913 := by
  intro p hp
  have h : env41913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41912_41913 : H12AffineEnvironment.transform 1 2 env41912 = env41913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41912 == env41913) = true)

def env41914 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8460,65536,74031,65664,273,8461,81,476,74046,65601,8409,74046,366,74110,81,75866,8205,65830,257,65,0,592]

theorem envBound41914 : H12AffineFastState.Bounded env41914 := by
  intro p hp
  have h : env41914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41902_41914 : H12AffineEnvironment.transform 9 321 env41902 = env41914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env41902 == env41914) = true)

theorem identity41914 : scanCanonicalize (H12AffineFastState.compose env41914 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound41914 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env41915 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8460,8250,277,8378,273,8461,81,476,260,8315,8409,260,366,324,81,2144,8205,8476,257,65,0,592]

theorem envBound41915 : H12AffineFastState.Bounded env41915 := by
  intro p hp
  have h : env41915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41914_41915 : H12AffineEnvironment.transform 15 8250 env41914 = env41915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env41914 == env41915) = true)

theorem identity41915 : scanCanonicalize (H12AffineFastState.compose env41915 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41915 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env41916 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,81,8192,80,8217,8250,0,8378,4,8216,81,201,17,8315,8409,17,123,81,81,2144,8205,8201,20,65,0,592]

theorem envBound41916 : H12AffineFastState.Bounded env41916 := by
  intro p hp
  have h : env41916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41915_41916 : H12AffineEnvironment.transform 7 21 env41915 = env41916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41915 == env41916) = true)

theorem identity41916 : scanCanonicalize (H12AffineFastState.compose env41916 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41916 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41917 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,0,8217,8250,0,8378,4,8216,1,153,17,8235,8329,17,43,1,1,2096,8205,8201,20,17,0,512]

theorem envBound41917 : H12AffineFastState.Bounded env41917 := by
  intro p hp
  have h : env41917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41916_41917 : H12AffineEnvironment.transform 5 16 env41916 = env41917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41916 == env41917) = true)

theorem identity41917 : scanCanonicalize (H12AffineFastState.compose env41917 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2704) := by decide +kernel

theorem selectedBound41917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41918 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,2704,0,2697,2730,0,2602,4,2696,1,153,17,2747,2585,17,43,1,1,2096,2717,2713,20,17,0,512]

theorem envBound41918 : H12AffineFastState.Bounded env41918 := by
  intro p hp
  have h : env41918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41917_41918 : H12AffineEnvironment.transform 12 2704 env41917 = env41918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2704 env41917 == env41918) = true)

theorem identity41918 : scanCanonicalize (H12AffineFastState.compose env41918 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41918 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41919 : List Nat := [2,4,8,16,32,16,128,21,512,4,26,1,650,0,659,688,0,560,4,658,1,153,17,673,515,17,43,1,1,42,647,643,20,17,0,512]

theorem envBound41919 : H12AffineFastState.Bounded env41919 := by
  intro p hp
  have h : env41919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41918_41919 : H12AffineEnvironment.transform 10 26 env41918 = env41919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41918 == env41919) = true)

theorem identity41919 : scanCanonicalize (H12AffineFastState.compose env41919 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound41919 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41920 : List Nat := [2,4,8,16,32,16,128,21,137,4,26,1,3,0,26,57,0,185,4,27,1,153,17,40,138,17,43,1,1,42,14,10,20,17,0,137]

theorem envBound41920 : H12AffineFastState.Bounded env41920 := by
  intro p hp
  have h : env41920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41919_41920 : H12AffineEnvironment.transform 8 137 env41919 = env41920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env41919 == env41920) = true)

theorem identity41920 : scanCanonicalize (H12AffineFastState.compose env41920 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41920 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41921 : List Nat := [2,4,8,16,16,16,128,21,137,4,26,1,3,0,26,9,0,137,4,27,1,153,17,24,138,17,27,1,1,26,14,10,20,17,0,137]

theorem envBound41921 : H12AffineFastState.Bounded env41921 := by
  intro p hp
  have h : env41921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41920_41921 : H12AffineEnvironment.transform 4 16 env41920 = env41921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41920 == env41921) = true)

theorem identity41921 : scanCanonicalize (H12AffineFastState.compose env41921 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41921 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41922 : List Nat := [2,4,8,11,11,11,128,14,137,4,1,1,3,0,1,9,0,137,4,0,1,130,10,3,138,10,0,1,1,1,14,10,15,10,0,137]

theorem envBound41922 : H12AffineFastState.Bounded env41922 := by
  intro p hp
  have h : env41922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41921_41922 : H12AffineEnvironment.transform 3 11 env41921 = env41922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41921 == env41922) = true)

theorem identity41922 : scanCanonicalize (H12AffineFastState.compose env41922 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound41922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41923 : List Nat := [2,4,8,11,11,11,14,14,7,4,1,1,3,0,1,9,0,7,4,0,1,12,10,3,4,10,0,1,1,1,14,10,15,10,0,7]

theorem envBound41923 : H12AffineFastState.Bounded env41923 := by
  intro p hp
  have h : env41923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41922_41923 : H12AffineEnvironment.transform 6 14 env41922 = env41923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env41922 == env41923) = true)

def env41924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4096,476,74046,69648,13769,78894,4414,74815,1296,81226,8205,65830,257,1280,1345,5952]

theorem envBound41924 : H12AffineFastState.Bounded env41924 := by
  intro p hp
  have h : env41924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41900_41924 : H12AffineEnvironment.transform 17 65665 env41900 = env41924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41900 == env41924) = true)

theorem identity41924 : scanCanonicalize (H12AffineFastState.compose env41924 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41924 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41925 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,0,79962,8205,65830,257,16,81,4688]

theorem envBound41925 : H12AffineFastState.Bounded env41925 := by
  intro p hp
  have h : env41925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41924_41925 : H12AffineEnvironment.transform 9 272 env41924 = env41925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41924 == env41925) = true)

def env41926 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,0,79962,8205,65830,257,16,81,4356]

theorem envBound41926 : H12AffineFastState.Bounded env41926 := by
  intro p hp
  have h : env41926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41925_41926 : H12AffineEnvironment.transform 8 340 env41925 = env41926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env41925 == env41926) = true)

def env41927 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,65536,74110,65665,336,8477,16,476,74046,65536,8393,74030,302,74031,0,75850,8205,65830,257,16,81,276]

theorem envBound41927 : H12AffineFastState.Bounded env41927 := by
  intro p hp
  have h : env41927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41926_41927 : H12AffineEnvironment.transform 11 16 env41926 = env41927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41926 == env41927) = true)

theorem identity41927 : scanCanonicalize (H12AffineFastState.compose env41927 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 220) := by decide +kernel

theorem selectedBound41927 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41928 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,220,8610,93,336,8477,16,476,8674,220,8393,8690,302,8691,0,10390,8205,506,257,16,81,276]

theorem envBound41928 : H12AffineFastState.Bounded env41928 := by
  intro p hp
  have h : env41928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41927_41928 : H12AffineEnvironment.transform 15 220 env41927 = env41928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 220 env41927 == env41928) = true)

def env41929 : List Nat := [2,4,8,16,32,0,128,256,276,272,2048,16,8192,1,8476,156,8610,29,272,8477,16,412,8610,156,8329,8626,302,8627,0,10390,8205,442,257,16,17,276]

theorem envBound41929 : H12AffineFastState.Bounded env41929 := by
  intro p hp
  have h : env41929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41928_41929 : H12AffineEnvironment.transform 5 0 env41928 = env41929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41928 == env41929) = true)

theorem identity41929 : scanCanonicalize (H12AffineFastState.compose env41929 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 183) := by decide +kernel

theorem selectedBound41929 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41930 : List Nat := [2,4,8,16,32,0,128,256,276,272,2048,16,183,1,427,156,277,29,272,426,16,412,277,156,62,261,302,260,0,2081,186,442,257,16,17,276]

theorem envBound41930 : H12AffineFastState.Bounded env41930 := by
  intro p hp
  have h : env41930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41929_41930 : H12AffineEnvironment.transform 12 183 env41929 = env41930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 183 env41929 == env41930) = true)

theorem identity41930 : scanCanonicalize (H12AffineFastState.compose env41930 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41930 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41931 : List Nat := [2,4,8,16,32,0,128,20,0,4,2048,16,183,1,191,156,1,29,4,190,16,136,1,156,62,17,58,16,0,2081,186,174,21,16,17,0]

theorem envBound41931 : H12AffineFastState.Bounded env41931 := by
  intro p hp
  have h : env41931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41930_41931 : H12AffineEnvironment.transform 7 20 env41930 = env41931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41930 == env41931) = true)

theorem identity41931 : scanCanonicalize (H12AffineFastState.compose env41931 (packedSelected [0,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound41931 : packedSelected [0,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41932 : List Nat := [2,4,8,16,32,0,128,20,0,4,191,16,183,1,191,156,1,29,4,190,16,136,1,156,62,17,58,16,0,158,186,174,21,16,17,0]

theorem envBound41932 : H12AffineFastState.Bounded env41932 := by
  intro p hp
  have h : env41932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41931_41932 : H12AffineEnvironment.transform 10 191 env41931 = env41932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env41931 == env41932) = true)

theorem identity41932 : scanCanonicalize (H12AffineFastState.compose env41932 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound41932 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env41933 : List Nat := [2,4,8,16,32,0,46,20,0,4,17,16,25,1,17,50,1,29,4,16,16,38,1,50,62,17,58,16,0,48,20,0,21,16,17,0]

theorem envBound41933 : H12AffineFastState.Bounded env41933 := by
  intro p hp
  have h : env41933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41932_41933 : H12AffineEnvironment.transform 6 46 env41932 = env41933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env41932 == env41933) = true)

theorem identity41933 : scanCanonicalize (H12AffineFastState.compose env41933 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41934 : List Nat := [2,2,8,16,32,0,40,18,0,2,17,16,25,1,17,50,1,27,2,16,16,32,1,50,56,17,58,16,0,48,18,0,19,16,17,0]

theorem envBound41934 : H12AffineFastState.Bounded env41934 := by
  intro p hp
  have h : env41934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41933_41934 : H12AffineEnvironment.transform 1 2 env41933 = env41934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41933 == env41934) = true)

theorem identity41934 : scanCanonicalize (H12AffineFastState.compose env41934 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41935 : List Nat := [2,2,8,16,11,0,3,18,0,2,17,16,25,1,17,25,1,27,2,16,16,11,1,25,19,17,17,16,0,27,18,0,19,16,17,0]

theorem envBound41935 : H12AffineFastState.Bounded env41935 := by
  intro p hp
  have h : env41935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41934_41935 : H12AffineEnvironment.transform 4 11 env41934 = env41935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41934 == env41935) = true)

theorem identity41935 : scanCanonicalize (H12AffineFastState.compose env41935 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41935 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41936 : List Nat := [2,2,8,10,11,0,3,8,0,2,11,10,3,1,11,3,1,1,2,10,10,11,1,3,9,11,11,10,0,1,8,0,9,10,11,0]

theorem envBound41936 : H12AffineFastState.Bounded env41936 := by
  intro p hp
  have h : env41936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41935_41936 : H12AffineEnvironment.transform 3 10 env41935 = env41936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41935 == env41936) = true)

theorem identity41936 : scanCanonicalize (H12AffineFastState.compose env41936 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41937 : List Nat := [2,2,3,1,0,0,3,3,0,2,0,1,3,1,0,3,1,1,2,1,1,0,1,3,2,0,0,1,0,1,3,0,2,1,0,0]

theorem envBound41937 : H12AffineFastState.Bounded env41937 := by
  intro p hp
  have h : env41937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41936_41937 : H12AffineEnvironment.transform 2 3 env41936 = env41937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41936 == env41937) = true)

def env41938 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,16,8192,1,8476,157,8610,28,273,8477,16,413,8611,157,8328,8627,302,8626,0,10390,8205,443,257,16,16,276]

theorem envBound41938 : H12AffineFastState.Bounded env41938 := by
  intro p hp
  have h : env41938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41928_41938 : H12AffineEnvironment.transform 5 1 env41928 = env41938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41928 == env41938) = true)

theorem identity41938 : scanCanonicalize (H12AffineFastState.compose env41938 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41938 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41939 : List Nat := [2,4,8,16,32,1,128,20,1,4,2048,16,8192,1,8200,157,8374,28,5,8201,16,137,8375,157,8328,8359,58,8358,0,10390,8205,175,21,16,16,0]

theorem envBound41939 : H12AffineFastState.Bounded env41939 := by
  intro p hp
  have h : env41939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41938_41939 : H12AffineEnvironment.transform 7 20 env41938 = env41939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41938 == env41939) = true)

theorem identity41939 : scanCanonicalize (H12AffineFastState.compose env41939 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound41939 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41940 : List Nat := [2,4,8,16,32,1,47,20,1,4,2048,16,8192,1,8200,50,8217,28,5,8201,16,38,8216,50,8231,8200,58,8201,0,10297,8205,0,21,16,16,0]

theorem envBound41940 : H12AffineFastState.Bounded env41940 := by
  intro p hp
  have h : env41940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41939_41940 : H12AffineEnvironment.transform 6 47 env41939 = env41940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env41939 == env41940) = true)

theorem identity41940 : scanCanonicalize (H12AffineFastState.compose env41940 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound41940 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41941 : List Nat := [2,4,8,16,32,1,47,20,1,4,2048,16,8,1,0,50,17,28,5,1,16,38,16,50,47,0,58,1,0,2097,5,0,21,16,16,0]

theorem envBound41941 : H12AffineFastState.Bounded env41941 := by
  intro p hp
  have h : env41941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41940_41941 : H12AffineEnvironment.transform 12 8 env41940 = env41941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env41940 == env41941) = true)

theorem identity41941 : scanCanonicalize (H12AffineFastState.compose env41941 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound41941 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41942 : List Nat := [2,4,8,16,32,1,47,20,1,4,23,16,8,1,0,50,17,28,5,1,16,38,16,50,47,0,58,1,0,38,5,0,21,16,16,0]

theorem envBound41942 : H12AffineFastState.Bounded env41942 := by
  intro p hp
  have h : env41942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41941_41942 : H12AffineEnvironment.transform 10 23 env41941 = env41942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env41941 == env41942) = true)

theorem identity41942 : scanCanonicalize (H12AffineFastState.compose env41942 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41942 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env41943 : List Nat := [2,4,8,16,17,1,30,20,1,4,23,16,8,1,0,3,17,28,5,1,16,23,16,3,30,0,11,1,0,23,5,0,21,16,16,0]

theorem envBound41943 : H12AffineFastState.Bounded env41943 := by
  intro p hp
  have h : env41943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41942_41943 : H12AffineEnvironment.transform 4 17 env41942 = env41943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41942 == env41943) = true)

theorem identity41943 : scanCanonicalize (H12AffineFastState.compose env41943 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41943 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41944 : List Nat := [2,0,8,16,17,1,26,16,1,0,19,16,8,1,0,3,17,24,1,1,16,19,16,3,26,0,11,1,0,19,1,0,17,16,16,0]

theorem envBound41944 : H12AffineFastState.Bounded env41944 := by
  intro p hp
  have h : env41944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41943_41944 : H12AffineEnvironment.transform 1 0 env41943 = env41944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41943 == env41944) = true)

theorem identity41944 : scanCanonicalize (H12AffineFastState.compose env41944 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound41944 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41945 : List Nat := [2,0,8,9,8,1,3,9,1,0,10,9,8,1,0,3,8,1,1,1,9,10,9,3,3,0,11,1,0,10,1,0,8,9,9,0]

theorem envBound41945 : H12AffineFastState.Bounded env41945 := by
  intro p hp
  have h : env41945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41944_41945 : H12AffineEnvironment.transform 3 9 env41944 = env41945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env41944 == env41945) = true)

theorem identity41945 : scanCanonicalize (H12AffineFastState.compose env41945 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41945 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41946 : List Nat := [2,0,2,3,2,1,3,3,1,0,0,3,2,1,0,3,2,1,1,1,3,0,3,3,3,0,1,1,0,0,1,0,2,3,3,0]

theorem envBound41946 : H12AffineFastState.Bounded env41946 := by
  intro p hp
  have h : env41946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41945_41946 : H12AffineEnvironment.transform 2 2 env41945 = env41946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41945 == env41946) = true)

def env41947 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,65536,74110,65665,337,8476,17,476,74046,65537,8392,74031,303,74031,0,75851,8205,65830,257,16,81,277]

theorem envBound41947 : H12AffineFastState.Bounded env41947 := by
  intro p hp
  have h : env41947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41926_41947 : H12AffineEnvironment.transform 11 17 env41926 = env41947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41926 == env41947) = true)

theorem identity41947 : scanCanonicalize (H12AffineFastState.compose env41947 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8389) := by decide +kernel

theorem selectedBound41947 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41948 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,8389,443,8260,337,8476,17,476,507,8388,8392,490,303,490,0,2190,8205,8675,257,16,81,277]

theorem envBound41948 : H12AffineFastState.Bounded env41948 := by
  intro p hp
  have h : env41948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41947_41948 : H12AffineEnvironment.transform 15 8389 env41947 = env41948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8389 env41947 == env41948) = true)

def env41949 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,2416,1,2157,2485,443,2356,337,2156,17,476,507,2484,2488,490,303,490,0,2190,2429,2195,257,16,81,277]

theorem envBound41949 : H12AffineFastState.Bounded env41949 := by
  intro p hp
  have h : env41949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41948_41949 : H12AffineEnvironment.transform 12 2416 env41948 = env41949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2416 env41948 == env41949) = true)

theorem identity41949 : scanCanonicalize (H12AffineFastState.compose env41949 (packedSelected [0,1,3,4,5,7,8,9,10,16,18,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41949 : packedSelected [0,1,3,4,5,7,8,9,10,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env41950 : List Nat := [2,4,8,16,32,17,128,256,261,272,2048,17,2337,1,2108,2485,443,2356,256,2109,17,397,426,2484,2488,443,303,443,0,2190,2348,2195,257,16,0,277]

theorem envBound41950 : H12AffineFastState.Bounded env41950 := by
  intro p hp
  have h : env41950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41949_41950 : H12AffineEnvironment.transform 5 17 env41949 = env41950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41949 == env41950) = true)

theorem identity41950 : scanCanonicalize (H12AffineFastState.compose env41950 (packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound41950 : packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env41951 : List Nat := [2,4,8,16,32,17,128,256,261,272,423,17,134,1,411,18,443,147,256,410,17,397,426,19,31,443,303,443,0,297,139,308,257,16,0,277]

theorem envBound41951 : H12AffineFastState.Bounded env41951 := by
  intro p hp
  have h : env41951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41950_41951 : H12AffineEnvironment.transform 10 423 env41950 = env41951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env41950 == env41951) = true)

theorem identity41951 : scanCanonicalize (H12AffineFastState.compose env41951 (packedSelected [0,4,5,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound41951 : packedSelected [0,4,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env41952 : List Nat := [2,4,8,16,32,17,41,256,261,272,270,17,47,1,306,18,274,58,256,307,17,292,259,19,31,274,303,274,0,297,34,308,257,16,0,277]

theorem envBound41952 : H12AffineFastState.Bounded env41952 := by
  intro p hp
  have h : env41952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41951_41952 : H12AffineEnvironment.transform 6 41 env41951 = env41952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env41951 == env41952) = true)

theorem identity41952 : scanCanonicalize (H12AffineFastState.compose env41952 (packedSelected [1,4,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound41952 : packedSelected [1,4,7,11] rootPS < 2^1333 := by decide +kernel

def env41953 : List Nat := [2,4,8,16,7,17,14,256,261,272,270,17,8,1,277,18,274,29,256,276,17,259,259,19,31,274,264,274,0,270,5,275,257,16,0,277]

theorem envBound41953 : H12AffineFastState.Bounded env41953 := by
  intro p hp
  have h : env41953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41952_41953 : H12AffineEnvironment.transform 4 7 env41952 = env41953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env41952 == env41953) = true)

theorem identity41953 : scanCanonicalize (H12AffineFastState.compose env41953 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41953 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env41954 : List Nat := [2,4,8,16,7,17,14,5,0,21,11,17,8,1,16,18,23,29,5,17,17,6,6,19,31,23,13,23,0,11,5,22,4,16,0,16]

theorem envBound41954 : H12AffineFastState.Bounded env41954 := by
  intro p hp
  have h : env41954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41953_41954 : H12AffineEnvironment.transform 7 5 env41953 = env41954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41953 == env41954) = true)

theorem identity41954 : scanCanonicalize (H12AffineFastState.compose env41954 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41954 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41955 : List Nat := [2,4,8,12,7,13,14,5,0,9,11,13,8,1,12,14,11,1,5,13,13,6,6,15,3,11,13,11,0,11,5,10,4,12,0,12]

theorem envBound41955 : H12AffineFastState.Bounded env41955 := by
  intro p hp
  have h : env41955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41954_41955 : H12AffineEnvironment.transform 3 12 env41954 = env41955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41954 == env41955) = true)

theorem identity41955 : scanCanonicalize (H12AffineFastState.compose env41955 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41955 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41956 : List Nat := [2,3,8,11,0,10,9,2,0,9,11,10,8,1,11,9,11,1,2,10,10,1,1,8,3,11,10,11,0,11,2,10,3,11,0,11]

theorem envBound41956 : H12AffineFastState.Bounded env41956 := by
  intro p hp
  have h : env41956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41955_41956 : H12AffineEnvironment.transform 1 3 env41955 = env41956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41955 == env41956) = true)

theorem identity41956 : scanCanonicalize (H12AffineFastState.compose env41956 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41957 : List Nat := [2,3,2,1,0,0,3,2,0,3,1,0,2,1,1,3,1,1,2,0,0,1,1,2,3,1,0,1,0,1,2,0,3,1,0,1]

theorem envBound41957 : H12AffineFastState.Bounded env41957 := by
  intro p hp
  have h : env41957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41956_41957 : H12AffineEnvironment.transform 2 2 env41956 = env41957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41956 == env41957) = true)

theorem identity41957 : scanCanonicalize (H12AffineFastState.compose env41957 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41958 : List Nat := [0,1,0,1,0,0,1,0,0,1,1,0,0,1,1,1,1,1,0,0,0,1,1,0,1,1,0,1,0,1,0,0,1,1,0,1]

theorem envBound41958 : H12AffineFastState.Bounded env41958 := by
  intro p hp
  have h : env41958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41957_41958 : H12AffineEnvironment.transform 0 0 env41957 = env41958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41957 == env41958) = true)

def env41959 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,2417,1,2156,2484,443,2357,337,2157,17,476,507,2485,2489,490,303,490,0,2190,2428,2194,257,16,81,277]

theorem envBound41959 : H12AffineFastState.Bounded env41959 := by
  intro p hp
  have h : env41959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41948_41959 : H12AffineEnvironment.transform 12 2417 env41948 = env41959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2417 env41948 == env41959) = true)

theorem identity41959 : scanCanonicalize (H12AffineFastState.compose env41959 (packedSelected [0,1,3,4,5,7,8,9,10,16,18,19,24] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound41959 : packedSelected [0,1,3,4,5,7,8,9,10,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env41960 : List Nat := [2,4,8,16,32,64,62,256,340,272,2048,17,2417,1,2156,2314,261,2357,337,2157,17,354,325,2315,2311,340,303,340,0,2096,2428,2092,257,16,81,277]

theorem envBound41960 : H12AffineFastState.Bounded env41960 := by
  intro p hp
  have h : env41960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41959_41960 : H12AffineEnvironment.transform 6 62 env41959 = env41960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env41959 == env41960) = true)

theorem identity41960 : scanCanonicalize (H12AffineFastState.compose env41960 (packedSelected [0,3,5,7,10,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound41960 : packedSelected [0,3,5,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env41961 : List Nat := [2,4,8,16,32,64,62,256,340,272,125,17,268,1,17,375,261,328,337,16,17,354,325,374,378,340,303,340,0,77,257,81,257,16,81,277]

theorem envBound41961 : H12AffineFastState.Bounded env41961 := by
  intro p hp
  have h : env41961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41960_41961 : H12AffineEnvironment.transform 10 125 env41960 = env41961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env41960 == env41961) = true)

theorem identity41961 : scanCanonicalize (H12AffineFastState.compose env41961 (packedSelected [0,3,7,10,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound41961 : packedSelected [0,3,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env41962 : List Nat := [2,4,8,16,32,27,62,256,271,272,38,17,268,1,17,300,261,275,266,16,17,313,286,301,289,271,303,271,0,22,257,10,257,16,10,277]

theorem envBound41962 : H12AffineFastState.Bounded env41962 := by
  intro p hp
  have h : env41962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41961_41962 : H12AffineEnvironment.transform 5 27 env41961 = env41962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env41961 == env41962) = true)

theorem identity41962 : scanCanonicalize (H12AffineFastState.compose env41962 (packedSelected [0,1,2,4,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41962 : packedSelected [0,1,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env41963 : List Nat := [2,4,8,10,32,1,36,256,271,266,38,11,268,1,11,300,261,265,266,10,11,291,260,301,289,271,303,271,0,12,257,10,257,10,10,271]

theorem envBound41963 : H12AffineFastState.Bounded env41963 := by
  intro p hp
  have h : env41963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41962_41963 : H12AffineEnvironment.transform 3 10 env41962 = env41963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41962 == env41963) = true)

theorem identity41963 : scanCanonicalize (H12AffineFastState.compose env41963 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41963 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41964 : List Nat := [2,4,8,10,6,1,2,256,271,266,0,11,268,1,11,266,261,265,266,10,11,261,260,267,263,271,265,271,0,12,257,10,257,10,10,271]

theorem envBound41964 : H12AffineFastState.Bounded env41964 := by
  intro p hp
  have h : env41964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41963_41964 : H12AffineEnvironment.transform 4 6 env41963 = env41964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41963 == env41964) = true)

theorem identity41964 : scanCanonicalize (H12AffineFastState.compose env41964 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41965 : List Nat := [2,3,8,10,1,1,2,256,264,266,0,11,267,1,11,266,258,265,266,10,11,258,259,267,256,264,265,264,0,11,257,10,257,10,10,264]

theorem envBound41965 : H12AffineFastState.Bounded env41965 := by
  intro p hp
  have h : env41965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41964_41965 : H12AffineEnvironment.transform 1 3 env41964 = env41965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41964 == env41965) = true)

theorem identity41965 : scanCanonicalize (H12AffineFastState.compose env41965 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41966 : List Nat := [2,3,3,1,1,1,2,256,259,257,0,0,256,1,0,257,258,258,257,1,0,258,259,256,256,259,258,259,0,0,257,1,257,1,1,259]

theorem envBound41966 : H12AffineFastState.Bounded env41966 := by
  intro p hp
  have h : env41966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41965_41966 : H12AffineEnvironment.transform 2 3 env41965 = env41966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41965 == env41966) = true)

theorem identity41966 : scanCanonicalize (H12AffineFastState.compose env41966 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound41966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41967 : List Nat := [2,3,3,1,1,1,2,3,0,2,0,0,3,1,0,2,1,1,2,1,0,1,0,3,3,0,1,0,0,0,2,1,2,1,1,0]

theorem envBound41967 : H12AffineFastState.Bounded env41967 := by
  intro p hp
  have h : env41967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41966_41967 : H12AffineEnvironment.transform 7 3 env41966 = env41967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env41966 == env41967) = true)

def env41968 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,0,79962,8205,65830,257,16,81,4357]

theorem envBound41968 : H12AffineFastState.Bounded env41968 := by
  intro p hp
  have h : env41968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41925_41968 : H12AffineEnvironment.transform 8 341 env41925 = env41968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env41925 == env41968) = true)

def env41969 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,65536,74110,65665,336,8477,16,476,74046,65536,8393,74030,302,74031,0,75850,8205,65830,257,16,81,277]

theorem envBound41969 : H12AffineFastState.Bounded env41969 := by
  intro p hp
  have h : env41969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41968_41969 : H12AffineEnvironment.transform 11 16 env41968 = env41969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41968 == env41969) = true)

theorem identity41969 : scanCanonicalize (H12AffineFastState.compose env41969 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 498) := by decide +kernel

theorem selectedBound41969 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41970 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,498,1,238,65536,65676,65665,336,239,16,476,65740,65536,315,65756,302,65757,0,68024,511,65830,257,16,81,277]

theorem envBound41970 : H12AffineFastState.Bounded env41970 := by
  intro p hp
  have h : env41970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41969_41970 : H12AffineEnvironment.transform 12 498 env41969 = env41970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 498 env41969 == env41970) = true)

def env41971 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,498,1,238,2136,2260,2265,336,239,16,476,2196,2136,315,2180,302,2181,0,480,511,2430,257,16,81,277]

theorem envBound41971 : H12AffineFastState.Bounded env41971 := by
  intro p hp
  have h : env41971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41970_41971 : H12AffineEnvironment.transform 15 2136 env41970 = env41971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2136 env41970 == env41971) = true)

theorem identity41971 : scanCanonicalize (H12AffineFastState.compose env41971 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound41971 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41972 : List Nat := [2,4,8,16,32,64,128,256,341,272,367,16,498,1,238,311,443,438,336,239,16,476,507,311,315,491,302,490,0,480,511,17,257,16,81,277]

theorem envBound41972 : H12AffineFastState.Bounded env41972 := by
  intro p hp
  have h : env41972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41971_41972 : H12AffineEnvironment.transform 10 367 env41971 = env41972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env41971 == env41972) = true)

theorem identity41972 : scanCanonicalize (H12AffineFastState.compose env41972 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41972 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41973 : List Nat := [2,4,8,16,32,64,128,20,65,4,123,16,230,1,238,35,175,162,68,239,16,200,239,35,47,255,58,254,0,244,235,17,21,16,81,1]

theorem envBound41973 : H12AffineFastState.Bounded env41973 := by
  intro p hp
  have h : env41973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41972_41973 : H12AffineEnvironment.transform 7 20 env41972 = env41973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41972 == env41973) = true)

theorem identity41973 : scanCanonicalize (H12AffineFastState.compose env41973 (packedSelected [2,3,5,8,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 116) := by decide +kernel

theorem selectedBound41973 : packedSelected [2,3,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env41974 : List Nat := [2,4,8,16,32,64,116,20,65,4,123,16,18,1,26,35,91,86,68,27,16,60,27,35,47,11,58,10,0,0,31,17,21,16,81,1]

theorem envBound41974 : H12AffineFastState.Bounded env41974 := by
  intro p hp
  have h : env41974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41973_41974 : H12AffineEnvironment.transform 6 116 env41973 = env41974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 116 env41973 == env41974) = true)

theorem identity41974 : scanCanonicalize (H12AffineFastState.compose env41974 (packedSelected [0,3,4,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41974 : packedSelected [0,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41975 : List Nat := [2,4,8,10,32,64,110,14,65,4,97,10,8,1,0,35,65,76,68,1,10,38,1,35,47,11,32,10,0,0,5,11,15,10,75,1]

theorem envBound41975 : H12AffineFastState.Bounded env41975 := by
  intro p hp
  have h : env41975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41974_41975 : H12AffineEnvironment.transform 3 10 env41974 = env41975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41974 == env41975) = true)

theorem identity41975 : scanCanonicalize (H12AffineFastState.compose env41975 (packedSelected [0,1,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound41975 : packedSelected [0,1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env41976 : List Nat := [2,4,8,10,32,44,2,14,45,4,13,10,8,1,0,35,45,32,40,1,10,38,1,35,47,11,32,10,0,0,5,11,15,10,39,1]

theorem envBound41976 : H12AffineFastState.Bounded env41976 := by
  intro p hp
  have h : env41976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41975_41976 : H12AffineEnvironment.transform 5 44 env41975 = env41976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env41975 == env41976) = true)

theorem identity41976 : scanCanonicalize (H12AffineFastState.compose env41976 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41976 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41977 : List Nat := [2,4,3,1,32,39,2,5,38,4,6,1,3,1,0,35,38,32,35,1,1,38,1,35,36,0,32,1,0,0,5,0,4,1,39,1]

theorem envBound41977 : H12AffineFastState.Bounded env41977 := by
  intro p hp
  have h : env41977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41976_41977 : H12AffineEnvironment.transform 2 3 env41976 = env41977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41976 == env41977) = true)

theorem identity41977 : scanCanonicalize (H12AffineFastState.compose env41977 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41977 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41978 : List Nat := [2,4,3,1,6,1,2,5,0,4,6,1,3,1,0,5,0,6,5,1,1,0,1,5,2,0,6,1,0,0,5,0,4,1,1,1]

theorem envBound41978 : H12AffineFastState.Bounded env41978 := by
  intro p hp
  have h : env41978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41977_41978 : H12AffineEnvironment.transform 4 6 env41977 = env41978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41977 == env41978) = true)

theorem identity41978 : scanCanonicalize (H12AffineFastState.compose env41978 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound41978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41979 : List Nat := [2,1,3,1,3,1,2,0,0,1,3,1,3,1,0,0,0,3,0,1,1,0,1,0,2,0,3,1,0,0,0,0,1,1,1,1]

theorem envBound41979 : H12AffineFastState.Bounded env41979 := by
  intro p hp
  have h : env41979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41978_41979 : H12AffineEnvironment.transform 1 1 env41978 = env41979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env41978 == env41979) = true)

theorem identity41979 : scanCanonicalize (H12AffineFastState.compose env41979 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41980 : List Nat := [0,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,1,0,1,1,0,1,0,0,0,1,1,0,0,0,0,1,1,1,1]

theorem envBound41980 : H12AffineFastState.Bounded env41980 := by
  intro p hp
  have h : env41980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41979_41980 : H12AffineEnvironment.transform 0 0 env41979 = env41980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41979 == env41980) = true)

def env41981 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,498,1,238,2137,2261,2264,336,239,16,476,2197,2137,315,2181,302,2180,0,481,511,2431,257,16,81,277]

theorem envBound41981 : H12AffineFastState.Bounded env41981 := by
  intro p hp
  have h : env41981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41970_41981 : H12AffineEnvironment.transform 15 2137 env41970 = env41981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2137 env41970 == env41981) = true)

theorem identity41981 : scanCanonicalize (H12AffineFastState.compose env41981 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 361) := by decide +kernel

theorem selectedBound41981 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41982 : List Nat := [2,4,8,16,32,64,128,256,341,272,361,16,498,1,238,304,444,433,336,239,16,476,508,304,315,492,302,493,0,481,511,22,257,16,81,277]

theorem envBound41982 : H12AffineFastState.Bounded env41982 := by
  intro p hp
  have h : env41982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41981_41982 : H12AffineEnvironment.transform 10 361 env41981 = env41982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 361 env41981 == env41982) = true)

theorem identity41982 : scanCanonicalize (H12AffineFastState.compose env41982 (packedSelected [2,4,5,9,11,12,15,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound41982 : packedSelected [2,4,5,9,11,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env41983 : List Nat := [2,4,8,16,22,64,128,256,341,272,351,16,452,1,216,262,394,391,336,217,16,476,458,262,269,474,280,475,0,471,457,22,257,16,81,277]

theorem envBound41983 : H12AffineFastState.Bounded env41983 := by
  intro p hp
  have h : env41983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41982_41983 : H12AffineEnvironment.transform 4 22 env41982 = env41983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env41982 == env41983) = true)

theorem identity41983 : scanCanonicalize (H12AffineFastState.compose env41983 (packedSelected [0,1,3,4,5,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 219) := by decide +kernel

theorem selectedBound41983 : packedSelected [0,1,3,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env41984 : List Nat := [2,4,8,16,22,64,128,219,142,203,132,16,31,1,216,221,81,92,139,217,16,7,17,221,214,1,195,0,0,12,18,22,218,16,81,206]

theorem envBound41984 : H12AffineFastState.Bounded env41984 := by
  intro p hp
  have h : env41984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41983_41984 : H12AffineEnvironment.transform 7 219 env41983 = env41984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 219 env41983 == env41984) = true)

theorem identity41984 : scanCanonicalize (H12AffineFastState.compose env41984 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41984 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41985 : List Nat := [2,4,8,11,13,64,128,192,142,203,132,11,4,1,195,198,74,71,139,194,11,7,10,198,205,1,195,0,0,12,9,13,193,11,74,206]

theorem envBound41985 : H12AffineFastState.Bounded env41985 := by
  intro p hp
  have h : env41985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41984_41985 : H12AffineEnvironment.transform 3 11 env41984 = env41985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41984 == env41985) = true)

theorem identity41985 : scanCanonicalize (H12AffineFastState.compose env41985 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound41985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41986 : List Nat := [2,4,8,11,13,10,128,138,142,129,132,11,4,1,137,140,0,13,139,136,11,7,10,140,135,1,137,0,0,12,9,13,139,11,0,132]

theorem envBound41986 : H12AffineFastState.Bounded env41986 := by
  intro p hp
  have h : env41986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41985_41986 : H12AffineEnvironment.transform 5 10 env41985 = env41986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env41985 == env41986) = true)

theorem identity41986 : scanCanonicalize (H12AffineFastState.compose env41986 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound41986 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41987 : List Nat := [2,4,8,11,13,10,2,8,12,3,6,11,4,1,11,14,0,13,9,10,11,7,10,14,5,1,11,0,0,12,9,13,9,11,0,6]

theorem envBound41987 : H12AffineFastState.Bounded env41987 := by
  intro p hp
  have h : env41987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41986_41987 : H12AffineEnvironment.transform 6 2 env41986 = env41987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env41986 == env41987) = true)

theorem identity41987 : scanCanonicalize (H12AffineFastState.compose env41987 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41987 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41988 : List Nat := [2,4,5,6,0,7,2,5,1,3,6,6,4,1,6,3,0,0,4,7,6,7,7,3,5,1,6,0,0,1,4,0,4,6,0,6]

theorem envBound41988 : H12AffineFastState.Bounded env41988 := by
  intro p hp
  have h : env41988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41987_41988 : H12AffineEnvironment.transform 2 5 env41987 = env41988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41987 == env41988) = true)

theorem identity41988 : scanCanonicalize (H12AffineFastState.compose env41988 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41988 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41989 : List Nat := [2,2,3,0,0,1,2,3,1,3,0,0,2,1,0,3,0,0,2,1,0,1,1,3,3,1,0,0,0,1,2,0,2,0,0,0]

theorem envBound41989 : H12AffineFastState.Bounded env41989 := by
  intro p hp
  have h : env41989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41988_41989 : H12AffineEnvironment.transform 1 2 env41988 = env41989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41988 == env41989) = true)

theorem identity41989 : scanCanonicalize (H12AffineFastState.compose env41989 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41990 : List Nat := [1,1,0,0,0,1,1,0,1,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,0,1,0,0,0,1,1,0,1,0,0,0]

theorem envBound41990 : H12AffineFastState.Bounded env41990 := by
  intro p hp
  have h : env41990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41989_41990 : H12AffineEnvironment.transform 0 1 env41989 = env41990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41989 == env41990) = true)

def env41991 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,65536,74110,65665,337,8476,17,476,74046,65537,8392,74031,303,74031,0,75851,8205,65830,257,16,81,276]

theorem envBound41991 : H12AffineFastState.Bounded env41991 := by
  intro p hp
  have h : env41991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41968_41991 : H12AffineEnvironment.transform 11 17 env41968 = env41991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41968 == env41991) = true)

theorem identity41991 : scanCanonicalize (H12AffineFastState.compose env41991 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound41991 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41992 : List Nat := [2,4,8,16,32,64,128,235,190,251,2048,17,8192,1,8438,65536,73877,65665,186,8439,17,55,73941,65537,8392,73924,196,73924,0,75851,8205,65741,234,16,81,255]

theorem envBound41992 : H12AffineFastState.Bounded env41992 := by
  intro p hp
  have h : env41992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41991_41992 : H12AffineEnvironment.transform 7 235 env41991 = env41992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env41991 == env41992) = true)

def env41993 : List Nat := [2,4,8,16,32,64,128,235,190,251,2048,17,24,1,238,65536,65677,65665,186,239,17,55,65741,65537,208,65756,196,65756,0,67667,21,65741,234,16,81,255]

theorem envBound41993 : H12AffineFastState.Bounded env41993 := by
  intro p hp
  have h : env41993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41992_41993 : H12AffineEnvironment.transform 12 24 env41992 = env41993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env41992 == env41993) = true)

theorem identity41993 : scanCanonicalize (H12AffineFastState.compose env41993 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound41993 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41994 : List Nat := [2,4,8,16,32,64,128,235,190,251,2048,17,24,1,238,115,254,242,186,239,17,55,190,114,208,175,196,175,0,2080,21,190,234,16,81,255]

theorem envBound41994 : H12AffineFastState.Bounded env41994 := by
  intro p hp
  have h : env41994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41993_41994 : H12AffineEnvironment.transform 15 115 env41993 = env41994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env41993 == env41994) = true)

theorem identity41994 : scanCanonicalize (H12AffineFastState.compose env41994 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound41994 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env41995 : List Nat := [2,4,8,16,32,1,128,170,190,186,2048,17,24,1,175,50,191,179,186,174,17,55,190,51,145,175,133,175,0,2080,21,190,171,16,16,190]

theorem envBound41995 : H12AffineFastState.Bounded env41995 := by
  intro p hp
  have h : env41995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41994_41995 : H12AffineEnvironment.transform 5 1 env41994 = env41995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41994 == env41995) = true)

theorem identity41995 : scanCanonicalize (H12AffineFastState.compose env41995 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41995 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41996 : List Nat := [2,4,8,16,32,1,8,34,54,50,2048,17,24,1,39,50,55,59,50,38,17,55,54,51,25,39,13,39,0,2080,21,54,35,16,16,54]

theorem envBound41996 : H12AffineFastState.Bounded env41996 := by
  intro p hp
  have h : env41996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41995_41996 : H12AffineEnvironment.transform 6 8 env41995 = env41996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41995 == env41996) = true)

theorem identity41996 : scanCanonicalize (H12AffineFastState.compose env41996 (packedSelected [3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound41996 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env41997 : List Nat := [2,4,8,16,32,1,8,34,54,50,49,17,24,1,39,50,55,59,50,38,17,55,54,51,25,39,13,39,0,17,21,54,35,16,16,54]

theorem envBound41997 : H12AffineFastState.Bounded env41997 := by
  intro p hp
  have h : env41997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41996_41997 : H12AffineEnvironment.transform 10 49 env41996 = env41997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env41996 == env41997) = true)

theorem identity41997 : scanCanonicalize (H12AffineFastState.compose env41997 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41997 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41998 : List Nat := [2,4,8,11,32,1,8,34,45,41,42,10,3,1,39,41,44,32,41,38,10,44,45,40,2,39,13,39,0,10,14,45,35,11,11,45]

theorem envBound41998 : H12AffineFastState.Bounded env41998 := by
  intro p hp
  have h : env41998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41997_41998 : H12AffineEnvironment.transform 3 11 env41997 = env41998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41997 == env41998) = true)

theorem identity41998 : scanCanonicalize (H12AffineFastState.compose env41998 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41998 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env41999 : List Nat := [2,4,8,11,0,1,8,2,13,9,10,10,3,1,7,9,12,0,9,6,10,12,13,8,2,7,13,7,0,10,14,13,3,11,11,13]

theorem envBound41999 : H12AffineFastState.Bounded env41999 := by
  intro p hp
  have h : env41999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41998_41999 : H12AffineEnvironment.transform 4 0 env41998 = env41999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41998 == env41999) = true)

theorem identity41999 : scanCanonicalize (H12AffineFastState.compose env41999 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42000 : List Nat := [2,3,8,11,0,1,8,2,10,9,10,10,3,1,0,9,11,0,9,1,10,11,10,8,2,0,10,0,0,10,9,10,3,11,11,10]

theorem envBound42000 : H12AffineFastState.Bounded env42000 := by
  intro p hp
  have h : env42000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41999_42000 : H12AffineEnvironment.transform 1 3 env41999 = env42000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41999 == env42000) = true)

theorem identity42000 : scanCanonicalize (H12AffineFastState.compose env42000 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42000 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42001 : List Nat := [2,3,3,0,0,1,3,2,1,2,1,1,3,1,0,2,0,0,2,1,1,0,1,3,2,0,1,0,0,1,2,1,3,0,0,1]

theorem envBound42001 : H12AffineFastState.Bounded env42001 := by
  intro p hp
  have h : env42001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42000_42001 : H12AffineEnvironment.transform 2 3 env42000 = env42001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42000 == env42001) = true)

def env42002 : List Nat := [2,4,8,16,32,64,128,235,190,251,2048,17,25,1,239,65536,65676,65665,186,238,17,55,65740,65537,209,65757,196,65757,0,67666,20,65741,234,16,81,255]

theorem envBound42002 : H12AffineFastState.Bounded env42002 := by
  intro p hp
  have h : env42002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41992_42002 : H12AffineEnvironment.transform 12 25 env41992 = env42002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env41992 == env42002) = true)

theorem identity42002 : scanCanonicalize (H12AffineFastState.compose env42002 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound42002 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42003 : List Nat := [2,4,8,16,32,64,128,235,190,251,2048,17,25,1,239,51,191,178,186,238,17,55,255,50,209,238,196,238,0,2145,20,254,234,16,81,255]

theorem envBound42003 : H12AffineFastState.Bounded env42003 := by
  intro p hp
  have h : env42003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42002_42003 : H12AffineEnvironment.transform 15 51 env42002 = env42003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env42002 == env42003) = true)

theorem identity42003 : scanCanonicalize (H12AffineFastState.compose env42003 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound42003 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env42004 : List Nat := [2,4,8,16,32,64,128,235,190,251,169,17,25,1,239,51,191,178,186,238,17,55,255,50,209,238,196,238,0,200,20,254,234,16,81,255]

theorem envBound42004 : H12AffineFastState.Bounded env42004 := by
  intro p hp
  have h : env42004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42003_42004 : H12AffineEnvironment.transform 10 169 env42003 = env42004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env42003 == env42004) = true)

theorem identity42004 : scanCanonicalize (H12AffineFastState.compose env42004 (packedSelected [0,3,4,5,7,9,10,15,16,18] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42004 : packedSelected [0,3,4,5,7,9,10,15,16,18] rootPS < 2^1333 := by decide +kernel

def env42005 : List Nat := [2,4,5,16,32,64,128,230,179,246,164,17,20,1,226,51,178,178,183,227,17,55,242,50,209,227,196,227,0,197,20,243,231,16,81,242]

theorem envBound42005 : H12AffineFastState.Bounded env42005 := by
  intro p hp
  have h : env42005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42004_42005 : H12AffineEnvironment.transform 2 5 env42004 = env42005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42004 == env42005) = true)

theorem identity42005 : scanCanonicalize (H12AffineFastState.compose env42005 (packedSelected [1,2,3,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound42005 : packedSelected [1,2,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env42006 : List Nat := [2,4,5,16,32,64,19,117,32,101,55,17,20,1,113,51,33,33,36,112,17,55,97,50,66,112,87,112,0,86,20,96,116,16,81,97]

theorem envBound42006 : H12AffineFastState.Bounded env42006 := by
  intro p hp
  have h : env42006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42005_42006 : H12AffineEnvironment.transform 6 19 env42005 = env42006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env42005 == env42006) = true)

theorem identity42006 : scanCanonicalize (H12AffineFastState.compose env42006 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42006 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env42007 : List Nat := [2,4,5,16,17,64,19,68,17,84,6,17,20,1,64,2,16,16,21,65,17,6,80,3,66,65,87,65,0,86,20,81,69,16,81,80]

theorem envBound42007 : H12AffineFastState.Bounded env42007 := by
  intro p hp
  have h : env42007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42006_42007 : H12AffineEnvironment.transform 4 17 env42006 = env42007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42006 == env42007) = true)

theorem identity42007 : scanCanonicalize (H12AffineFastState.compose env42007 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42008 : List Nat := [2,4,5,16,17,1,19,5,17,21,6,17,20,1,1,2,16,16,21,0,17,6,17,3,3,0,22,0,0,23,20,16,4,16,16,17]

theorem envBound42008 : H12AffineFastState.Bounded env42008 := by
  intro p hp
  have h : env42008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42007_42008 : H12AffineEnvironment.transform 5 1 env42007 = env42008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42007 == env42008) = true)

theorem identity42008 : scanCanonicalize (H12AffineFastState.compose env42008 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42008 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42009 : List Nat := [2,2,3,16,17,1,19,3,17,19,0,17,18,1,1,2,16,16,19,0,17,0,17,3,3,0,16,0,0,17,18,16,2,16,16,17]

theorem envBound42009 : H12AffineFastState.Bounded env42009 := by
  intro p hp
  have h : env42009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42008_42009 : H12AffineEnvironment.transform 1 2 env42008 = env42009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42008 == env42009) = true)

theorem identity42009 : scanCanonicalize (H12AffineFastState.compose env42009 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42010 : List Nat := [2,2,3,0,1,1,3,3,1,3,0,1,2,1,1,2,0,0,3,0,1,0,1,3,3,0,0,0,0,1,2,0,2,0,0,1]

theorem envBound42010 : H12AffineFastState.Bounded env42010 := by
  intro p hp
  have h : env42010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42009_42010 : H12AffineEnvironment.transform 3 0 env42009 = env42010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42009 == env42010) = true)

def env42011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148800,33584584,96346,50962568,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound42011 : H12AffineFastState.Bounded env42011 := by
  intro p hp
  have h : env42011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40821_42011 : H12AffineEnvironment.transform 20 4097 env40821 = env42011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env40821 == env42011) = true)

theorem identity42011 : scanCanonicalize (H12AffineFastState.compose env42011 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 168665378) := by decide +kernel

theorem selectedBound42011 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env42012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148800,33584584,96346,50962568,168665378,34088328,151876049,151462016,33563273]

theorem envBound42012 : H12AffineFastState.Bounded env42012 := by
  intro p hp
  have h : env42012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42011_42012 : H12AffineEnvironment.transform 31 168665378 env42011 = env42012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 168665378 env42011 == env42012) = true)

def env42013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,134217728,148800,545088,96346,16876544,134579626,256,151876049,151462016,525825]

theorem envBound42013 : H12AffineFastState.Bounded env42013 := by
  intro p hp
  have h : env42013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42012_42013 : H12AffineEnvironment.transform 24 533640 env42012 = env42013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env42012 == env42013) = true)

def env42014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245632,148800,545088,96346,16876544,16949354,256,676881,1344,525825]

theorem envBound42014 : H12AffineFastState.Bounded env42014 := by
  intro p hp
  have h : env42014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42013_42014 : H12AffineEnvironment.transform 26 17245632 env42013 = env42014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env42013 == env42014) = true)

theorem identity42014 : scanCanonicalize (H12AffineFastState.compose env42014 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound42014 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717115,533640,672785,906491,148800,545088,96346,750907,545105,256,676881,1344,525825]

theorem envBound42015 : H12AffineFastState.Bounded env42015 := by
  intro p hp
  have h : env42015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42014_42015 : H12AffineEnvironment.transform 23 717115 env42014 = env42015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env42014 == env42015) = true)

def env42016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58683,143496,20497,508155,148800,148800,96346,90427,148817,256,16401,1344,135681]

theorem envBound42016 : H12AffineFastState.Bounded env42016 := by
  intro p hp
  have h : env42016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42015_42016 : H12AffineEnvironment.transform 18 136192 env42015 = env42016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env42015 == env42016) = true)

def env42017 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143496,20497,508155,148716,148716,96346,90263,148733,172,16401,1260,135681]

theorem envBound42017 : H12AffineFastState.Bounded env42017 := by
  intro p hp
  have h : env42017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42016_42017 : H12AffineEnvironment.transform 7 172 env42016 = env42017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env42016 == env42017) = true)

def env42018 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143496,20497,508075,148668,148668,96266,90263,148653,172,16401,1212,135681]

theorem envBound42018 : H12AffineFastState.Bounded env42018 := by
  intro p hp
  have h : env42018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42017_42018 : H12AffineEnvironment.transform 5 16 env42017 = env42018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42017 == env42018) = true)

theorem identity42018 : scanCanonicalize (H12AffineFastState.compose env42018 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound42018 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42019 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61568,115855,58519,111638,20497,279605,114722,114722,96266,90263,114739,172,16401,1212,104095]

theorem envBound42019 : H12AffineFastState.Bounded env42019 := by
  intro p hp
  have h : env42019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42018_42019 : H12AffineEnvironment.transform 16 99486 env42018 = env42019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env42018 == env42019) = true)

theorem identity42019 : scanCanonicalize (H12AffineFastState.compose env42019 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound42019 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env42020 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,37018,5124,262144,4,32769,4097,61568,21525,58519,9356,20497,279605,20664,20664,59536,61453,20649,172,16401,1212,1541]

theorem envBound42020 : H12AffineFastState.Bounded env42020 := by
  intro p hp
  have h : env42020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42019_42020 : H12AffineEnvironment.transform 15 37018 env42019 = env42020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env42019 == env42020) = true)

theorem identity42020 : scanCanonicalize (H12AffineFastState.compose env42020 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42020 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42021 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,37018,4097,262144,4,32769,4097,61568,20496,57490,8329,20497,278576,20664,20664,59536,61453,20649,172,16401,185,512]

theorem envBound42021 : H12AffineFastState.Bounded env42021 := by
  intro p hp
  have h : env42021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42020_42021 : H12AffineEnvironment.transform 9 5 env42020 = env42021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42020 == env42021) = true)

theorem identity42021 : scanCanonicalize (H12AffineFastState.compose env42021 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound42021 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42022 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,32768,37018,4097,262144,4,32769,4097,45112,4264,41002,8329,4265,262280,4096,4096,43048,45237,4113,172,169,185,512]

theorem envBound42022 : H12AffineFastState.Bounded env42022 := by
  intro p hp
  have h : env42022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42021_42022 : H12AffineEnvironment.transform 13 184 env42021 = env42022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env42021 == env42022) = true)

theorem identity42022 : scanCanonicalize (H12AffineFastState.compose env42022 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4745) := by decide +kernel

theorem selectedBound42022 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42023 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,4745,531,4097,262144,4,4744,4097,8881,4264,12963,8329,4265,262280,4096,4096,15009,8764,4113,172,169,185,512]

theorem envBound42023 : H12AffineFastState.Bounded env42023 := by
  intro p hp
  have h : env42023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42022_42023 : H12AffineEnvironment.transform 14 4745 env42022 = env42023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4745 env42022 == env42023) = true)

theorem identity42023 : scanCanonicalize (H12AffineFastState.compose env42023 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound42023 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42024 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,8192,184,560,531,184,262144,4,561,184,8881,17,8730,8329,16,262280,185,185,10776,8764,168,172,169,185,512]

theorem envBound42024 : H12AffineFastState.Bounded env42024 := by
  intro p hp
  have h : env42024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42023_42024 : H12AffineEnvironment.transform 11 185 env42023 = env42024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env42023 == env42024) = true)

theorem identity42024 : scanCanonicalize (H12AffineFastState.compose env42024 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 8379) := by decide +kernel

theorem selectedBound42024 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42025 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,8192,184,560,531,184,8379,4,561,184,8881,17,8730,8329,16,8243,185,185,10776,8764,168,172,169,185,512]

theorem envBound42025 : H12AffineFastState.Bounded env42025 := by
  intro p hp
  have h : env42025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42024_42025 : H12AffineEnvironment.transform 17 8379 env42024 = env42025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8379 env42024 == env42025) = true)

theorem identity42025 : scanCanonicalize (H12AffineFastState.compose env42025 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound42025 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env42026 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,656,184,560,531,184,555,4,561,184,33,17,138,537,16,675,185,185,2184,172,168,172,169,185,512]

theorem envBound42026 : H12AffineFastState.Bounded env42026 := by
  intro p hp
  have h : env42026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42025_42026 : H12AffineEnvironment.transform 12 656 env42025 = env42026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env42025 == env42026) = true)

theorem identity42026 : scanCanonicalize (H12AffineFastState.compose env42026 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound42026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42027 : List Nat := [2,4,8,16,32,16,128,172,512,5,512,185,656,184,560,531,184,555,4,561,184,33,17,138,537,16,675,185,185,648,172,168,172,169,185,512]

theorem envBound42027 : H12AffineFastState.Bounded env42027 := by
  intro p hp
  have h : env42027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42026_42027 : H12AffineEnvironment.transform 10 512 env42026 = env42027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env42026 == env42027) = true)

theorem identity42027 : scanCanonicalize (H12AffineFastState.compose env42027 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42027 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42028 : List Nat := [2,4,8,11,32,11,128,172,512,5,512,162,651,163,555,520,163,555,4,554,163,33,10,138,514,11,675,162,162,648,172,168,172,169,162,512]

theorem envBound42028 : H12AffineFastState.Bounded env42028 := by
  intro p hp
  have h : env42028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42027_42028 : H12AffineEnvironment.transform 3 11 env42027 = env42028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42027 == env42028) = true)

theorem identity42028 : scanCanonicalize (H12AffineFastState.compose env42028 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42029 : List Nat := [2,4,8,11,7,11,128,139,512,5,512,133,651,132,524,520,132,524,4,525,132,6,10,138,514,11,644,133,133,648,139,143,139,142,133,512]

theorem envBound42029 : H12AffineFastState.Bounded env42029 := by
  intro p hp
  have h : env42029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42028_42029 : H12AffineEnvironment.transform 4 7 env42028 = env42029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42028 == env42029) = true)

theorem identity42029 : scanCanonicalize (H12AffineFastState.compose env42029 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42029 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2