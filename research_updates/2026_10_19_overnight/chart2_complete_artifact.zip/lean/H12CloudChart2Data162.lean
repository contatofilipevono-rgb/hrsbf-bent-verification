import H12CloudChart2Data161

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound40473 : H12AffineFastState.Bounded env40473 := by
  intro p hp
  have h : env40473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40472_40473 : H12AffineEnvironment.transform 5 32 env40472 = env40473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env40472 == env40473) = true)

theorem identity40473 : scanCanonicalize (H12AffineFastState.compose env40473 (packedSelected [1,2,3,4,5,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound40473 : packedSelected [1,2,3,4,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40474 : List Nat := [2,4,8,16,32,32,53,46,27,37,13,11,25,26,43,56,10,13,4,42,10,38,48,35,4,33,26,58,27,7,20,16,47,43,43,58]

theorem envBound40474 : H12AffineFastState.Bounded env40474 := by
  intro p hp
  have h : env40474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40473_40474 : H12AffineEnvironment.transform 7 46 env40473 = env40474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env40473 == env40474) = true)

theorem identity40474 : scanCanonicalize (H12AffineFastState.compose env40474 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40474 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env40475 : List Nat := [2,4,8,0,32,32,37,46,11,37,13,11,9,10,43,40,10,13,4,42,10,38,32,35,4,33,10,42,11,7,4,0,47,43,43,42]

theorem envBound40475 : H12AffineFastState.Bounded env40475 := by
  intro p hp
  have h : env40475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40474_40475 : H12AffineEnvironment.transform 3 0 env40474 = env40475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40474 == env40475) = true)

theorem identity40475 : scanCanonicalize (H12AffineFastState.compose env40475 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40476 : List Nat := [2,2,8,0,32,32,35,40,11,35,11,11,9,10,43,40,10,11,2,42,10,32,32,35,2,33,10,42,11,1,2,0,41,43,43,42]

theorem envBound40476 : H12AffineFastState.Bounded env40476 := by
  intro p hp
  have h : env40476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40475_40476 : H12AffineEnvironment.transform 1 2 env40475 = env40476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40475 == env40476) = true)

def env40477 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1286,1281,25,1297,260,1053,106,1181,1088,261,1280,477,1339,268,208,1323,1086,58,1296,328,20,16,257,43,1344,277]

theorem envBound40477 : H12AffineFastState.Bounded env40477 := by
  intro p hp
  have h : env40477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40469_40477 : H12AffineEnvironment.transform 11 1281 env40469 = env40477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env40469 == env40477) = true)

theorem identity40477 : scanCanonicalize (H12AffineFastState.compose env40477 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 453) := by decide +kernel

theorem selectedBound40477 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40478 : List Nat := [2,4,8,16,32,64,128,256,341,453,195,196,25,212,260,472,106,344,389,261,197,477,254,268,208,238,507,58,213,328,20,16,257,43,133,277]

theorem envBound40478 : H12AffineFastState.Bounded env40478 := by
  intro p hp
  have h : env40478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40477_40478 : H12AffineEnvironment.transform 9 453 env40477 = env40478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 453 env40477 == env40478) = true)

theorem identity40478 : scanCanonicalize (H12AffineFastState.compose env40478 (packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound40478 : packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env40479 : List Nat := [2,4,8,16,32,64,128,204,153,9,195,196,25,212,200,20,106,148,73,201,197,17,254,192,208,238,55,58,213,132,20,16,205,43,133,217]

theorem envBound40479 : H12AffineFastState.Bounded env40479 := by
  intro p hp
  have h : env40479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40478_40479 : H12AffineEnvironment.transform 7 204 env40478 = env40479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env40478 == env40479) = true)

theorem identity40479 : scanCanonicalize (H12AffineFastState.compose env40479 (packedSelected [0,5,7,8,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 94) := by decide +kernel

theorem selectedBound40479 : packedSelected [0,5,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env40480 : List Nat := [2,4,8,16,32,64,94,18,71,9,29,26,25,10,22,20,106,74,73,23,27,17,32,30,14,48,55,58,11,90,20,16,19,43,91,7]

theorem envBound40480 : H12AffineFastState.Bounded env40480 := by
  intro p hp
  have h : env40480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40479_40480 : H12AffineEnvironment.transform 6 94 env40479 = env40480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 94 env40479 == env40480) = true)

theorem identity40480 : scanCanonicalize (H12AffineFastState.compose env40480 (packedSelected [1,2,4,8,9,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40480 : packedSelected [1,2,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40481 : List Nat := [2,4,5,16,32,64,83,18,71,4,16,23,20,7,22,20,103,71,68,23,22,17,32,19,3,48,55,55,6,87,20,16,19,38,86,7]

theorem envBound40481 : H12AffineFastState.Bounded env40481 := by
  intro p hp
  have h : env40481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40480_40481 : H12AffineEnvironment.transform 2 5 env40480 = env40481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40480 == env40481) = true)

theorem identity40481 : scanCanonicalize (H12AffineFastState.compose env40481 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound40481 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40482 : List Nat := [2,4,5,16,32,22,5,18,17,4,16,23,20,7,22,20,49,17,18,23,22,17,32,19,3,48,55,55,6,1,20,16,19,38,0,7]

theorem envBound40482 : H12AffineFastState.Bounded env40482 := by
  intro p hp
  have h : env40482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40481_40482 : H12AffineEnvironment.transform 5 22 env40481 = env40482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env40481 == env40482) = true)

theorem identity40482 : scanCanonicalize (H12AffineFastState.compose env40482 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound40482 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40483 : List Nat := [2,4,5,16,23,22,5,18,17,4,16,23,20,7,22,20,6,17,18,23,22,17,23,19,3,7,0,0,6,1,20,16,19,17,0,7]

theorem envBound40483 : H12AffineFastState.Bounded env40483 := by
  intro p hp
  have h : env40483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40482_40483 : H12AffineEnvironment.transform 4 23 env40482 = env40483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env40482 == env40483) = true)

def env40484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4097,477,74047,69648,13768,78894,4414,74814,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound40484 : H12AffineFastState.Bounded env40484 := by
  intro p hp
  have h : env40484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40406_40484 : H12AffineEnvironment.transform 17 65665 env40406 = env40484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40406 == env40484) = true)

theorem identity40484 : scanCanonicalize (H12AffineFastState.compose env40484 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound40484 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,69943,65665,4417,324,4097,477,70758,69648,145,65911,4414,69991,1296,67602,5460,5456,257,70006,1344,5953]

theorem envBound40485 : H12AffineFastState.Bounded env40485 := by
  intro p hp
  have h : env40485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40484_40485 : H12AffineEnvironment.transform 12 5465 env40484 = env40485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env40484 == env40485) = true)

def env40486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,1052,5419,1181,4417,324,4097,477,4218,5132,145,1387,4414,5499,1296,3086,5460,5456,257,5482,1344,5953]

theorem envBound40486 : H12AffineFastState.Bounded env40486 := by
  intro p hp
  have h : env40486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40485_40486 : H12AffineEnvironment.transform 15 1052 env40485 = env40486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env40485 == env40486) = true)

theorem identity40486 : scanCanonicalize (H12AffineFastState.compose env40486 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(10+1) ^^^ 572) := by decide +kernel

theorem selectedBound40486 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,572,4096,5465,1297,325,1052,5419,1181,4417,324,4097,477,4218,5132,145,1387,4414,5499,1296,1586,5460,5456,257,5482,1344,5953]

theorem envBound40487 : H12AffineFastState.Bounded env40487 := by
  intro p hp
  have h : env40487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40486_40487 : H12AffineEnvironment.transform 10 572 env40486 = env40487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 572 env40486 == env40487) = true)

def env40488 : List Nat := [2,4,8,16,32,64,128,256,340,1024,360,4096,5465,1297,325,1052,5419,1181,4417,324,4097,477,4218,5132,145,1387,4414,5499,1296,1382,5460,5456,257,5482,1344,5141]

theorem envBound40488 : H12AffineFastState.Bounded env40488 := by
  intro p hp
  have h : env40488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40487_40488 : H12AffineEnvironment.transform 8 340 env40487 = env40488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env40487 == env40488) = true)

def env40489 : List Nat := [2,4,8,16,32,0,128,256,276,1024,296,4096,5401,1297,261,1052,5419,1181,4353,260,4097,413,4154,5132,145,1323,4414,5435,1296,1318,5396,5392,257,5418,1280,5141]

theorem envBound40489 : H12AffineFastState.Bounded env40489 := by
  intro p hp
  have h : env40489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40488_40489 : H12AffineEnvironment.transform 5 0 env40488 = env40489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40488 == env40489) = true)

theorem identity40489 : scanCanonicalize (H12AffineFastState.compose env40489 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 190) := by decide +kernel

theorem selectedBound40489 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40490 : List Nat := [2,4,8,16,32,0,128,256,276,1024,296,190,1447,1297,261,1052,1429,1181,447,260,191,413,132,1202,145,1323,384,1413,1296,1318,1450,1454,257,1428,1280,1195]

theorem envBound40490 : H12AffineFastState.Bounded env40490 := by
  intro p hp
  have h : env40490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40489_40490 : H12AffineEnvironment.transform 11 190 env40489 = env40490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 190 env40489 == env40490) = true)

theorem identity40490 : scanCanonicalize (H12AffineFastState.compose env40490 (packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS)) = affineNative (2^(9+1) ^^^ 144) := by decide +kernel

theorem selectedBound40490 : packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS < 2^1333 := by decide +kernel

def env40491 : List Nat := [2,4,8,16,32,0,128,256,276,144,296,190,311,385,261,140,261,13,447,260,191,413,132,34,145,443,384,277,384,438,314,318,257,260,400,59]

theorem envBound40491 : H12AffineFastState.Bounded env40491 := by
  intro p hp
  have h : env40491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40490_40491 : H12AffineEnvironment.transform 9 144 env40490 = env40491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env40490 == env40491) = true)

theorem identity40491 : scanCanonicalize (H12AffineFastState.compose env40491 (packedSelected [2,4,9,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound40491 : packedSelected [2,4,9,15,16] rootPS < 2^1333 := by decide +kernel

def env40492 : List Nat := [2,4,8,16,32,0,128,19,7,144,59,190,36,146,22,140,22,13,172,23,191,142,132,34,145,168,147,6,147,165,41,45,18,23,131,59]

theorem envBound40492 : H12AffineFastState.Bounded env40492 := by
  intro p hp
  have h : env40492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40491_40492 : H12AffineEnvironment.transform 7 19 env40491 = env40492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env40491 == env40492) = true)

theorem identity40492 : scanCanonicalize (H12AffineFastState.compose env40492 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound40492 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env40493 : List Nat := [2,4,8,16,32,0,40,19,7,56,59,22,36,58,22,36,22,13,4,23,23,38,44,34,57,0,59,6,59,13,41,45,18,23,43,59]

theorem envBound40493 : H12AffineFastState.Bounded env40493 := by
  intro p hp
  have h : env40493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40492_40493 : H12AffineEnvironment.transform 6 40 env40492 = env40493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env40492 == env40493) = true)

theorem identity40493 : scanCanonicalize (H12AffineFastState.compose env40493 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40494 : List Nat := [2,4,8,0,32,0,40,3,7,40,43,6,36,42,6,36,6,13,4,7,7,38,44,34,41,0,43,6,43,13,41,45,2,7,43,43]

theorem envBound40494 : H12AffineFastState.Bounded env40494 := by
  intro p hp
  have h : env40494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40493_40494 : H12AffineEnvironment.transform 3 0 env40493 = env40494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40493 == env40494) = true)

theorem identity40494 : scanCanonicalize (H12AffineFastState.compose env40494 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40494 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40495 : List Nat := [2,4,4,0,32,0,36,3,7,36,39,6,36,38,6,36,6,1,4,7,7,38,32,34,37,0,39,6,39,1,37,33,2,7,39,39]

theorem envBound40495 : H12AffineFastState.Bounded env40495 := by
  intro p hp
  have h : env40495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40494_40495 : H12AffineEnvironment.transform 2 4 env40494 = env40495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40494 == env40495) = true)

theorem identity40495 : scanCanonicalize (H12AffineFastState.compose env40495 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40496 : List Nat := [2,4,4,0,1,0,5,3,7,5,6,6,5,7,6,5,6,1,4,7,7,7,1,3,4,0,6,6,6,1,4,0,2,7,6,6]

theorem envBound40496 : H12AffineFastState.Bounded env40496 := by
  intro p hp
  have h : env40496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40495_40496 : H12AffineEnvironment.transform 4 1 env40495 = env40496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40495 == env40496) = true)

theorem identity40496 : scanCanonicalize (H12AffineFastState.compose env40496 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40497 : List Nat := [1,4,4,0,1,0,5,0,4,5,5,5,5,4,5,5,5,1,4,4,4,4,1,0,4,0,5,5,5,1,4,0,1,4,5,5]

theorem envBound40497 : H12AffineFastState.Bounded env40497 := by
  intro p hp
  have h : env40497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40496_40497 : H12AffineEnvironment.transform 0 1 env40496 = env40497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40496 == env40497) = true)

theorem identity40497 : scanCanonicalize (H12AffineFastState.compose env40497 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40497 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40498 : List Nat := [1,0,0,0,1,0,1,0,0,1,1,1,1,0,1,1,1,1,0,0,0,0,1,0,0,0,1,1,1,1,0,0,1,0,1,1]

theorem envBound40498 : H12AffineFastState.Bounded env40498 := by
  intro p hp
  have h : env40498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40497_40498 : H12AffineEnvironment.transform 1 0 env40497 = env40498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40497 == env40498) = true)

def env40499 : List Nat := [2,4,8,16,32,1,128,256,277,1024,297,4096,5400,1297,260,1052,5419,1181,4352,261,4097,412,4155,5132,145,1322,4414,5434,1296,1319,5397,5393,257,5419,1281,5141]

theorem envBound40499 : H12AffineFastState.Bounded env40499 := by
  intro p hp
  have h : env40499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40488_40499 : H12AffineEnvironment.transform 5 1 env40488 = env40499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40488 == env40499) = true)

theorem identity40499 : scanCanonicalize (H12AffineFastState.compose env40499 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound40499 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40500 : List Nat := [2,4,8,16,32,1,47,256,277,1024,297,4096,5400,1297,260,1052,5419,1074,4352,261,4097,307,4155,5132,62,1322,4414,5434,1296,1319,5397,5393,257,5419,1281,5141]

theorem envBound40500 : H12AffineFastState.Bounded env40500 := by
  intro p hp
  have h : env40500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40499_40500 : H12AffineEnvironment.transform 6 47 env40499 = env40500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env40499 == env40500) = true)

theorem identity40500 : scanCanonicalize (H12AffineFastState.compose env40500 (packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound40500 : packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40501 : List Nat := [2,4,8,16,32,1,47,256,277,257,297,4096,4121,16,260,285,4138,307,4352,261,4097,307,4155,4365,62,43,4414,4155,17,38,4116,4112,257,4138,0,4372]

theorem envBound40501 : H12AffineFastState.Bounded env40501 := by
  intro p hp
  have h : env40501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40500_40501 : H12AffineEnvironment.transform 9 257 env40500 = env40501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env40500 == env40501) = true)

theorem identity40501 : scanCanonicalize (H12AffineFastState.compose env40501 (packedSelected [0,1,7,8,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound40501 : packedSelected [0,1,7,8,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40502 : List Nat := [2,4,8,16,32,1,47,256,277,257,297,22,15,16,260,285,60,307,278,261,23,307,45,283,62,43,296,45,17,38,2,6,257,60,0,258]

theorem envBound40502 : H12AffineFastState.Bounded env40502 := by
  intro p hp
  have h : env40502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40501_40502 : H12AffineEnvironment.transform 11 22 env40501 = env40502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env40501 == env40502) = true)

theorem identity40502 : scanCanonicalize (H12AffineFastState.compose env40502 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40502 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env40503 : List Nat := [2,4,8,16,1,1,14,256,277,257,264,22,15,16,260,285,29,274,278,261,23,274,12,283,31,10,265,12,17,7,2,6,257,29,0,258]

theorem envBound40503 : H12AffineFastState.Bounded env40503 := by
  intro p hp
  have h : env40503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40502_40503 : H12AffineEnvironment.transform 4 1 env40502 = env40503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40502 == env40503) = true)

theorem identity40503 : scanCanonicalize (H12AffineFastState.compose env40503 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40503 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env40504 : List Nat := [2,4,8,12,1,1,14,256,265,257,264,10,15,12,260,257,1,270,266,261,11,270,12,263,3,10,265,12,13,7,2,6,257,1,0,258]

theorem envBound40504 : H12AffineFastState.Bounded env40504 := by
  intro p hp
  have h : env40504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40503_40504 : H12AffineEnvironment.transform 3 12 env40503 = env40504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40503 == env40504) = true)

theorem identity40504 : scanCanonicalize (H12AffineFastState.compose env40504 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40504 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env40505 : List Nat := [2,2,8,10,1,1,8,256,265,257,264,10,9,10,258,257,1,264,266,259,11,264,10,257,3,10,265,10,11,1,2,0,257,1,0,258]

theorem envBound40505 : H12AffineFastState.Bounded env40505 := by
  intro p hp
  have h : env40505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40504_40505 : H12AffineEnvironment.transform 1 2 env40504 = env40505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40504 == env40505) = true)

theorem identity40505 : scanCanonicalize (H12AffineFastState.compose env40505 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40506 : List Nat := [2,2,3,1,1,1,3,256,258,257,259,1,2,1,258,257,1,259,257,259,0,259,1,257,3,1,258,1,0,1,2,0,257,1,0,258]

theorem envBound40506 : H12AffineFastState.Bounded env40506 := by
  intro p hp
  have h : env40506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40505_40506 : H12AffineEnvironment.transform 2 3 env40505 = env40506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40505 == env40506) = true)

theorem identity40506 : scanCanonicalize (H12AffineFastState.compose env40506 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound40506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40507 : List Nat := [2,2,3,1,1,1,3,2,0,3,1,1,2,1,0,3,1,1,3,1,0,1,1,3,3,1,0,1,0,1,2,0,3,1,0,0]

theorem envBound40507 : H12AffineFastState.Bounded env40507 := by
  intro p hp
  have h : env40507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40506_40507 : H12AffineEnvironment.transform 7 2 env40506 = env40507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env40506 == env40507) = true)

def env40508 : List Nat := [2,4,8,16,32,64,128,256,341,1024,361,4096,5465,1297,325,1052,5419,1181,4417,324,4097,477,4218,5132,145,1387,4414,5499,1296,1383,5460,5456,257,5482,1344,5140]

theorem envBound40508 : H12AffineFastState.Bounded env40508 := by
  intro p hp
  have h : env40508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40487_40508 : H12AffineEnvironment.transform 8 341 env40487 = env40508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env40487 == env40508) = true)

def env40509 : List Nat := [2,4,8,16,32,0,128,256,277,1024,297,4096,5401,1297,261,1052,5419,1181,4353,260,4097,413,4154,5132,145,1323,4414,5435,1296,1319,5396,5392,257,5418,1280,5140]

theorem envBound40509 : H12AffineFastState.Bounded env40509 := by
  intro p hp
  have h : env40509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40508_40509 : H12AffineEnvironment.transform 5 0 env40508 = env40509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40508 == env40509) = true)

theorem identity40509 : scanCanonicalize (H12AffineFastState.compose env40509 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound40509 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40510 : List Nat := [2,4,8,16,32,0,20,256,277,1024,297,4096,5401,1297,261,1052,5419,1033,4353,260,4097,265,4154,5132,5,1323,4414,5435,1296,1319,5396,5392,257,5418,1280,5140]

theorem envBound40510 : H12AffineFastState.Bounded env40510 := by
  intro p hp
  have h : env40510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40509_40510 : H12AffineEnvironment.transform 6 20 env40509 = env40510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env40509 == env40510) = true)

theorem identity40510 : scanCanonicalize (H12AffineFastState.compose env40510 (packedSelected [2,3,4,9,12,13,16,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40510 : packedSelected [2,3,4,9,12,13,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40511 : List Nat := [2,4,8,16,32,0,20,256,277,273,297,4096,4104,0,261,269,4154,280,4353,260,4097,265,4154,4381,5,58,4414,4138,1,54,4101,4097,257,4155,17,4357]

theorem envBound40511 : H12AffineFastState.Bounded env40511 := by
  intro p hp
  have h : env40511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40510_40511 : H12AffineEnvironment.transform 9 273 env40510 = env40511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40510 == env40511) = true)

theorem identity40511 : scanCanonicalize (H12AffineFastState.compose env40511 (packedSelected [0,1,5,7,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound40511 : packedSelected [0,1,5,7,12,13,18] rootPS < 2^1333 := by decide +kernel

def env40512 : List Nat := [2,4,8,16,32,0,20,9,28,24,32,4096,4104,0,12,4,4154,17,4104,13,4097,0,4154,4116,5,58,4151,4138,1,54,4101,4097,8,4155,17,4108]

theorem envBound40512 : H12AffineFastState.Bounded env40512 := by
  intro p hp
  have h : env40512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40511_40512 : H12AffineEnvironment.transform 7 9 env40511 = env40512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env40511 == env40512) = true)

theorem identity40512 : scanCanonicalize (H12AffineFastState.compose env40512 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 38) := by decide +kernel

theorem selectedBound40512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40513 : List Nat := [2,4,8,16,32,0,20,9,28,24,32,38,46,0,12,4,28,17,46,13,39,0,28,50,5,58,17,12,1,54,35,39,8,29,17,42]

theorem envBound40513 : H12AffineFastState.Bounded env40513 := by
  intro p hp
  have h : env40513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40512_40513 : H12AffineEnvironment.transform 11 38 env40512 = env40513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 38 env40512 == env40513) = true)

theorem identity40513 : scanCanonicalize (H12AffineFastState.compose env40513 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40513 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env40514 : List Nat := [2,4,8,16,28,0,20,9,28,24,28,26,18,0,12,4,28,17,18,13,27,0,28,14,5,6,17,12,1,10,31,27,8,29,17,22]

theorem envBound40514 : H12AffineFastState.Bounded env40514 := by
  intro p hp
  have h : env40514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40513_40514 : H12AffineEnvironment.transform 4 28 env40513 = env40514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40513 == env40514) = true)

def env40515 : List Nat := [2,4,8,16,32,1,128,256,276,1024,296,4096,5400,1297,260,1052,5419,1181,4352,261,4097,412,4155,5132,145,1322,4414,5434,1296,1318,5397,5393,257,5419,1281,5140]

theorem envBound40515 : H12AffineFastState.Bounded env40515 := by
  intro p hp
  have h : env40515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40508_40515 : H12AffineEnvironment.transform 5 1 env40508 = env40515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40508 == env40515) = true)

theorem identity40515 : scanCanonicalize (H12AffineFastState.compose env40515 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 132) := by decide +kernel

theorem selectedBound40515 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40516 : List Nat := [2,4,8,16,32,1,128,256,276,1024,296,132,1436,1297,260,1052,1455,1181,388,261,133,412,191,1160,145,1322,442,1470,1296,1318,1425,1429,257,1455,1281,1168]

theorem envBound40516 : H12AffineFastState.Bounded env40516 := by
  intro p hp
  have h : env40516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40515_40516 : H12AffineEnvironment.transform 11 132 env40515 = env40516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 132 env40515 == env40516) = true)

theorem identity40516 : scanCanonicalize (H12AffineFastState.compose env40516 (packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40516 : packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env40517 : List Nat := [2,4,8,16,28,1,128,256,276,1024,276,132,1436,1297,260,1052,1427,1181,388,261,133,412,131,1160,145,1302,390,1410,1296,1306,1425,1429,257,1427,1281,1168]

theorem envBound40517 : H12AffineFastState.Bounded env40517 := by
  intro p hp
  have h : env40517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40516_40517 : H12AffineEnvironment.transform 4 28 env40516 = env40517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40516 == env40517) = true)

theorem identity40517 : scanCanonicalize (H12AffineFastState.compose env40517 (packedSelected [0,3,7,8,11,12,17] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound40517 : packedSelected [0,3,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env40518 : List Nat := [2,4,8,16,28,1,128,256,276,393,276,132,21,152,260,405,26,276,388,261,133,412,131,257,145,159,390,11,153,147,24,28,257,26,136,281]

theorem envBound40518 : H12AffineFastState.Bounded env40518 := by
  intro p hp
  have h : env40518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40517_40518 : H12AffineEnvironment.transform 9 393 env40517 = env40518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env40517 == env40518) = true)

theorem identity40518 : scanCanonicalize (H12AffineFastState.compose env40518 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40518 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env40519 : List Nat := [2,4,8,11,7,1,128,256,271,393,271,132,14,131,260,398,1,271,388,261,133,391,131,257,138,132,390,11,130,136,3,7,257,1,136,258]

theorem envBound40519 : H12AffineFastState.Bounded env40519 := by
  intro p hp
  have h : env40519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40518_40519 : H12AffineEnvironment.transform 3 11 env40518 = env40519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40518 == env40519) = true)

theorem identity40519 : scanCanonicalize (H12AffineFastState.compose env40519 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound40519 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env40520 : List Nat := [2,4,8,11,7,1,128,2,13,139,13,132,14,131,6,140,1,13,134,7,133,133,131,3,138,132,132,11,130,136,3,7,3,1,136,0]

theorem envBound40520 : H12AffineFastState.Bounded env40520 := by
  intro p hp
  have h : env40520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40519_40520 : H12AffineEnvironment.transform 7 2 env40519 = env40520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env40519 == env40520) = true)

theorem identity40520 : scanCanonicalize (H12AffineFastState.compose env40520 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound40520 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40521 : List Nat := [2,4,8,11,7,1,15,2,13,4,13,11,14,12,6,3,1,13,9,7,10,10,12,3,5,11,11,11,13,7,3,7,3,1,7,0]

theorem envBound40521 : H12AffineFastState.Bounded env40521 := by
  intro p hp
  have h : env40521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40520_40521 : H12AffineEnvironment.transform 6 15 env40520 = env40521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env40520 == env40521) = true)

def env40522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,1053,5418,1180,4417,324,4097,477,4219,5133,145,1386,4414,5498,1296,3087,5460,5456,257,5483,1344,5953]

theorem envBound40522 : H12AffineFastState.Bounded env40522 := by
  intro p hp
  have h : env40522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40485_40522 : H12AffineEnvironment.transform 15 1053 env40485 = env40522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env40485 == env40522) = true)

theorem identity40522 : scanCanonicalize (H12AffineFastState.compose env40522 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(10+1) ^^^ 518) := by decide +kernel

theorem selectedBound40522 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,518,4096,5465,1297,325,1053,5418,1180,4417,324,4097,477,4219,5133,145,1386,4414,5498,1296,1545,5460,5456,257,5483,1344,5953]

theorem envBound40523 : H12AffineFastState.Bounded env40523 := by
  intro p hp
  have h : env40523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40522_40523 : H12AffineEnvironment.transform 10 518 env40522 = env40523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 518 env40522 == env40523) = true)

def env40524 : List Nat := [2,4,8,16,32,64,128,256,340,1024,338,4096,5465,1297,325,1053,5418,1180,4417,324,4097,477,4219,5133,145,1386,4414,5498,1296,1373,5460,5456,257,5483,1344,5141]

theorem envBound40524 : H12AffineFastState.Bounded env40524 := by
  intro p hp
  have h : env40524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40523_40524 : H12AffineEnvironment.transform 8 340 env40523 = env40524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env40523 == env40524) = true)

def env40525 : List Nat := [2,4,8,16,32,0,128,256,276,1024,274,4096,5401,1297,261,1053,5418,1180,4353,260,4097,413,4155,5133,145,1322,4414,5434,1296,1309,5396,5392,257,5419,1280,5141]

theorem envBound40525 : H12AffineFastState.Bounded env40525 := by
  intro p hp
  have h : env40525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40524_40525 : H12AffineEnvironment.transform 5 0 env40524 = env40525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40524 == env40525) = true)

theorem identity40525 : scanCanonicalize (H12AffineFastState.compose env40525 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 190) := by decide +kernel

theorem selectedBound40525 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40526 : List Nat := [2,4,8,16,32,0,128,256,276,1024,274,190,1447,1297,261,1053,1428,1180,447,260,191,413,133,1203,145,1322,384,1412,1296,1309,1450,1454,257,1429,1280,1195]

theorem envBound40526 : H12AffineFastState.Bounded env40526 := by
  intro p hp
  have h : env40526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40525_40526 : H12AffineEnvironment.transform 11 190 env40525 = env40526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 190 env40525 == env40526) = true)

theorem identity40526 : scanCanonicalize (H12AffineFastState.compose env40526 (packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40526 : packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env40527 : List Nat := [2,2,8,16,32,0,128,256,274,1024,274,184,1441,1297,259,1051,1426,1178,441,258,185,411,131,1203,145,1322,384,1410,1296,1307,1450,1448,257,1427,1280,1195]

theorem envBound40527 : H12AffineFastState.Bounded env40527 := by
  intro p hp
  have h : env40527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40526_40527 : H12AffineEnvironment.transform 1 2 env40526 = env40527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40526 == env40527) = true)

theorem identity40527 : scanCanonicalize (H12AffineFastState.compose env40527 (packedSelected [0,3,7,8,11,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40527 : packedSelected [0,3,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env40528 : List Nat := [2,2,8,16,17,0,128,256,274,1024,274,137,1424,1297,259,1051,1426,1178,392,258,136,411,131,1154,145,1307,384,1410,1296,1307,1435,1433,257,1427,1280,1178]

theorem envBound40528 : H12AffineFastState.Bounded env40528 := by
  intro p hp
  have h : env40528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40527_40528 : H12AffineEnvironment.transform 4 17 env40527 = env40528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40527 == env40528) = true)

theorem identity40528 : scanCanonicalize (H12AffineFastState.compose env40528 (packedSelected [0,3,4,7,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 282) := by decide +kernel

theorem selectedBound40528 : packedSelected [0,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env40529 : List Nat := [2,2,8,16,17,0,128,256,274,282,274,137,138,11,259,257,136,384,392,258,136,411,131,408,145,1,384,152,10,1,129,131,257,137,26,384]

theorem envBound40529 : H12AffineFastState.Bounded env40529 := by
  intro p hp
  have h : env40529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40528_40529 : H12AffineEnvironment.transform 9 282 env40528 = env40529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 282 env40528 == env40529) = true)

theorem identity40529 : scanCanonicalize (H12AffineFastState.compose env40529 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound40529 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40530 : List Nat := [2,2,8,16,17,0,18,256,274,282,274,27,24,11,259,257,26,274,282,258,26,265,17,266,3,1,274,10,10,1,19,17,257,27,26,274]

theorem envBound40530 : H12AffineFastState.Bounded env40530 := by
  intro p hp
  have h : env40530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40529_40530 : H12AffineEnvironment.transform 6 18 env40529 = env40530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env40529 == env40530) = true)

theorem identity40530 : scanCanonicalize (H12AffineFastState.compose env40530 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40531 : List Nat := [2,2,8,1,0,0,3,256,259,267,259,10,9,11,259,257,11,259,267,258,11,265,0,266,3,1,259,10,10,1,2,0,257,10,11,259]

theorem envBound40531 : H12AffineFastState.Bounded env40531 := by
  intro p hp
  have h : env40531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40530_40531 : H12AffineEnvironment.transform 3 1 env40530 = env40531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40530 == env40531) = true)

def env40532 : List Nat := [2,4,8,16,32,1,128,256,277,1024,275,4096,5400,1297,260,1053,5418,1180,4352,261,4097,412,4154,5133,145,1323,4414,5435,1296,1308,5397,5393,257,5418,1281,5141]

theorem envBound40532 : H12AffineFastState.Bounded env40532 := by
  intro p hp
  have h : env40532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40524_40532 : H12AffineEnvironment.transform 5 1 env40524 = env40532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40524 == env40532) = true)

theorem identity40532 : scanCanonicalize (H12AffineFastState.compose env40532 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound40532 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40533 : List Nat := [2,4,8,16,32,1,47,256,277,1024,275,4096,5400,1297,260,1053,5418,1075,4352,261,4097,307,4154,5133,62,1323,4414,5435,1296,1308,5397,5393,257,5418,1281,5141]

theorem envBound40533 : H12AffineFastState.Bounded env40533 := by
  intro p hp
  have h : env40533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40532_40533 : H12AffineEnvironment.transform 6 47 env40532 = env40533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env40532 == env40533) = true)

theorem identity40533 : scanCanonicalize (H12AffineFastState.compose env40533 (packedSelected [2,3,4,9,12,13,16,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40533 : packedSelected [2,3,4,9,12,13,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40534 : List Nat := [2,4,8,16,32,1,47,256,277,273,275,4096,4105,0,260,268,4155,290,4352,261,4097,307,4154,4380,62,58,4414,4138,1,13,4100,4096,257,4155,16,4356]

theorem envBound40534 : H12AffineFastState.Bounded env40534 := by
  intro p hp
  have h : env40534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40533_40534 : H12AffineEnvironment.transform 9 273 env40533 = env40534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40533 == env40534) = true)

theorem identity40534 : scanCanonicalize (H12AffineFastState.compose env40534 (packedSelected [0,1,5,7,12,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 291) := by decide +kernel

theorem selectedBound40534 : packedSelected [0,1,5,7,12,13,18] rootPS < 2^1333 := by decide +kernel

def env40535 : List Nat := [2,4,8,16,32,1,47,256,277,273,275,291,298,0,260,268,280,290,35,261,290,307,281,63,62,58,29,265,1,13,295,291,257,280,16,39]

theorem envBound40535 : H12AffineFastState.Bounded env40535 := by
  intro p hp
  have h : env40535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40534_40535 : H12AffineEnvironment.transform 11 291 env40534 = env40535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 291 env40534 == env40535) = true)

theorem identity40535 : scanCanonicalize (H12AffineFastState.compose env40535 (packedSelected [0,2,5,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound40535 : packedSelected [0,2,5,7,12] rootPS < 2^1333 := by decide +kernel

def env40536 : List Nat := [2,4,8,16,32,1,47,15,26,30,28,44,37,0,11,3,23,45,35,10,45,60,22,63,62,58,29,6,1,13,40,44,14,23,16,39]

theorem envBound40536 : H12AffineFastState.Bounded env40536 := by
  intro p hp
  have h : env40536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40535_40536 : H12AffineEnvironment.transform 7 15 env40535 = env40536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env40535 == env40536) = true)

theorem identity40536 : scanCanonicalize (H12AffineFastState.compose env40536 (packedSelected [0,1,2,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40536 : packedSelected [0,1,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40537 : List Nat := [2,4,8,11,32,1,47,15,1,5,7,44,37,0,11,3,12,45,35,10,45,39,13,36,37,33,6,6,1,13,40,44,14,12,11,39]

theorem envBound40537 : H12AffineFastState.Bounded env40537 := by
  intro p hp
  have h : env40537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40536_40537 : H12AffineEnvironment.transform 3 11 env40536 = env40537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40536 == env40537) = true)

theorem identity40537 : scanCanonicalize (H12AffineFastState.compose env40537 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40537 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40538 : List Nat := [2,4,8,11,13,1,2,15,1,5,7,1,8,0,11,3,12,0,14,10,0,10,13,9,8,12,6,6,1,13,5,1,14,12,11,10]

theorem envBound40538 : H12AffineFastState.Bounded env40538 := by
  intro p hp
  have h : env40538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40537_40538 : H12AffineEnvironment.transform 4 13 env40537 = env40538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40537 == env40538) = true)

def env40539 : List Nat := [2,4,8,16,32,64,128,256,341,1024,339,4096,5465,1297,325,1053,5418,1180,4417,324,4097,477,4219,5133,145,1386,4414,5498,1296,1372,5460,5456,257,5483,1344,5140]

theorem envBound40539 : H12AffineFastState.Bounded env40539 := by
  intro p hp
  have h : env40539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40523_40539 : H12AffineEnvironment.transform 8 341 env40523 = env40539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env40523 == env40539) = true)

def env40540 : List Nat := [2,4,8,16,32,0,128,256,277,1024,275,4096,5401,1297,261,1053,5418,1180,4353,260,4097,413,4155,5133,145,1322,4414,5434,1296,1308,5396,5392,257,5419,1280,5140]

theorem envBound40540 : H12AffineFastState.Bounded env40540 := by
  intro p hp
  have h : env40540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40539_40540 : H12AffineEnvironment.transform 5 0 env40539 = env40540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40539 == env40540) = true)

theorem identity40540 : scanCanonicalize (H12AffineFastState.compose env40540 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound40540 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40541 : List Nat := [2,4,8,16,32,0,21,256,277,1024,275,4096,5401,1297,261,1053,5418,1033,4353,260,4097,264,4155,5133,4,1322,4414,5434,1296,1308,5396,5392,257,5419,1280,5140]

theorem envBound40541 : H12AffineFastState.Bounded env40541 := by
  intro p hp
  have h : env40541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40540_40541 : H12AffineEnvironment.transform 6 21 env40540 = env40541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env40540 == env40541) = true)

theorem identity40541 : scanCanonicalize (H12AffineFastState.compose env40541 (packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound40541 : packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40542 : List Nat := [2,4,8,16,32,0,21,256,277,256,275,4096,4121,17,261,285,4138,265,4353,260,4097,264,4155,4365,4,42,4414,4154,16,28,4116,4112,257,4139,0,4372]

theorem envBound40542 : H12AffineFastState.Bounded env40542 := by
  intro p hp
  have h : env40542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40541_40542 : H12AffineEnvironment.transform 9 256 env40541 = env40542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env40541 == env40542) = true)

theorem identity40542 : scanCanonicalize (H12AffineFastState.compose env40542 (packedSelected [0,1,7,8,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 44) := by decide +kernel

theorem selectedBound40542 : packedSelected [0,1,7,8,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40543 : List Nat := [2,4,8,16,32,0,21,256,277,256,275,44,53,17,261,285,6,265,301,260,45,264,23,289,4,42,274,22,16,28,56,60,257,7,0,312]

theorem envBound40543 : H12AffineFastState.Bounded env40543 := by
  intro p hp
  have h : env40543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40542_40543 : H12AffineEnvironment.transform 11 44 env40542 = env40543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 44 env40542 == env40543) = true)

theorem identity40543 : scanCanonicalize (H12AffineFastState.compose env40543 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40543 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env40544 : List Nat := [2,4,8,16,0,0,21,256,277,256,275,12,21,17,261,285,6,265,269,260,13,264,23,257,4,10,274,22,16,28,24,28,257,7,0,280]

theorem envBound40544 : H12AffineFastState.Bounded env40544 := by
  intro p hp
  have h : env40544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40543_40544 : H12AffineEnvironment.transform 4 0 env40543 = env40544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40543 == env40544) = true)

theorem identity40544 : scanCanonicalize (H12AffineFastState.compose env40544 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40544 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env40545 : List Nat := [2,4,2,16,0,0,21,256,277,256,275,6,21,17,261,279,6,259,263,260,7,258,23,257,4,0,274,22,16,22,18,22,257,7,0,274]

theorem envBound40545 : H12AffineFastState.Bounded env40545 := by
  intro p hp
  have h : env40545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40544_40545 : H12AffineEnvironment.transform 2 2 env40544 = env40545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40544 == env40545) = true)

def env40546 : List Nat := [2,4,8,16,32,1,128,256,276,1024,274,4096,5400,1297,260,1053,5418,1180,4352,261,4097,412,4154,5133,145,1323,4414,5435,1296,1309,5397,5393,257,5418,1281,5140]

theorem envBound40546 : H12AffineFastState.Bounded env40546 := by
  intro p hp
  have h : env40546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40539_40546 : H12AffineEnvironment.transform 5 1 env40539 = env40546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40539 == env40546) = true)

theorem identity40546 : scanCanonicalize (H12AffineFastState.compose env40546 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 133) := by decide +kernel

theorem selectedBound40546 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40547 : List Nat := [2,4,8,16,32,1,128,256,276,1024,274,133,1437,1297,260,1053,1455,1180,389,261,132,412,191,1160,145,1323,443,1470,1296,1309,1424,1428,257,1455,1281,1169]

theorem envBound40547 : H12AffineFastState.Bounded env40547 := by
  intro p hp
  have h : env40547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40546_40547 : H12AffineEnvironment.transform 11 133 env40546 = env40547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 133 env40546 == env40547) = true)

theorem identity40547 : scanCanonicalize (H12AffineFastState.compose env40547 (packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS)) = affineNative (2^(9+1) ^^^ 171) := by decide +kernel

theorem selectedBound40547 : packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS < 2^1333 := by decide +kernel

def env40548 : List Nat := [2,4,8,16,32,1,128,256,276,171,274,133,310,442,260,182,260,55,389,261,132,412,191,35,145,384,443,277,443,438,315,319,257,260,426,58]

theorem envBound40548 : H12AffineFastState.Bounded env40548 := by
  intro p hp
  have h : env40548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40547_40548 : H12AffineEnvironment.transform 9 171 env40547 = env40548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 171 env40547 == env40548) = true)

theorem identity40548 : scanCanonicalize (H12AffineFastState.compose env40548 (packedSelected [2,4,9,15,16] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40548 : packedSelected [2,4,9,15,16] rootPS < 2^1333 := by decide +kernel

def env40549 : List Nat := [2,2,8,16,32,1,128,256,274,171,274,131,304,442,258,176,258,49,387,259,130,410,185,35,145,384,443,275,443,432,315,313,257,258,426,58]

theorem envBound40549 : H12AffineFastState.Bounded env40549 := by
  intro p hp
  have h : env40549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40548_40549 : H12AffineEnvironment.transform 1 2 env40548 = env40549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40548 == env40549) = true)

theorem identity40549 : scanCanonicalize (H12AffineFastState.compose env40549 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40549 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40550 : List Nat := [2,2,8,16,0,1,128,256,274,139,274,131,272,410,258,144,258,17,387,259,130,410,153,3,145,384,411,275,411,400,283,281,257,258,394,26]

theorem envBound40550 : H12AffineFastState.Bounded env40550 := by
  intro p hp
  have h : env40550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40549_40550 : H12AffineEnvironment.transform 4 0 env40549 = env40550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40549 == env40550) = true)

theorem identity40550 : scanCanonicalize (H12AffineFastState.compose env40550 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40550 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env40551 : List Nat := [2,2,2,16,0,1,128,256,274,129,274,131,272,400,258,144,258,17,387,259,130,400,147,3,145,384,401,275,401,400,273,275,257,258,384,16]

theorem envBound40551 : H12AffineFastState.Bounded env40551 := by
  intro p hp
  have h : env40551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40550_40551 : H12AffineEnvironment.transform 2 2 env40550 = env40551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40550 == env40551) = true)

theorem identity40551 : scanCanonicalize (H12AffineFastState.compose env40551 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound40551 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env40552 : List Nat := [2,2,2,16,0,1,2,256,274,3,274,1,272,274,258,18,258,17,257,259,0,274,17,3,19,258,275,275,275,274,273,275,257,258,258,16]

theorem envBound40552 : H12AffineFastState.Bounded env40552 := by
  intro p hp
  have h : env40552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40551_40552 : H12AffineEnvironment.transform 6 2 env40551 = env40552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env40551 == env40552) = true)

theorem identity40552 : scanCanonicalize (H12AffineFastState.compose env40552 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40552 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40553 : List Nat := [2,2,2,1,0,1,2,256,259,3,259,1,257,259,258,3,258,0,257,259,0,259,0,3,2,258,258,258,258,259,256,258,257,258,258,1]

theorem envBound40553 : H12AffineFastState.Bounded env40553 := by
  intro p hp
  have h : env40553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40552_40553 : H12AffineEnvironment.transform 3 1 env40552 = env40553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40552 == env40553) = true)

theorem identity40553 : scanCanonicalize (H12AffineFastState.compose env40553 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound40553 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40554 : List Nat := [2,2,2,1,0,1,2,3,0,3,0,1,2,0,1,3,1,0,2,0,0,0,0,3,2,1,1,1,1,0,3,1,2,1,1,1]

theorem envBound40554 : H12AffineFastState.Bounded env40554 := by
  intro p hp
  have h : env40554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40553_40554 : H12AffineEnvironment.transform 7 3 env40553 = env40554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env40553 == env40554) = true)

theorem identity40554 : scanCanonicalize (H12AffineFastState.compose env40554 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40555 : List Nat := [0,0,0,1,0,1,0,1,0,1,0,1,0,0,1,1,1,0,0,0,0,0,0,1,0,1,1,1,1,0,1,1,0,1,1,1]

theorem envBound40555 : H12AffineFastState.Bounded env40555 := by
  intro p hp
  have h : env40555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40554_40555 : H12AffineEnvironment.transform 0 0 env40554 = env40555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40554 == env40555) = true)

def env40556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123165,28888,78895,385202,90415,1297,96346,25884,25881,257,74799,1344,21073]

theorem envBound40556 : H12AffineFastState.Bounded env40556 := by
  intro p hp
  have h : env40556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40301_40556 : H12AffineEnvironment.transform 18 21585 env40301 = env40556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env40301 == env40556) = true)

theorem identity40556 : scanCanonicalize (H12AffineFastState.compose env40556 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound40556 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env40557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4097,5276,91182,66897,28888,78895,328958,90415,1297,96346,25884,25881,257,74799,1344,21073]

theorem envBound40557 : H12AffineFastState.Bounded env40557 := by
  intro p hp
  have h : env40557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40556_40557 : H12AffineEnvironment.transform 14 25676 env40556 = env40557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env40556 == env40557) = true)

def env40558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4097,5276,74046,66897,13768,78895,328958,74815,1297,81226,8204,8201,257,74799,1344,5953]

theorem envBound40558 : H12AffineFastState.Bounded env40558 := by
  intro p hp
  have h : env40558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40557_40558 : H12AffineEnvironment.transform 13 1296 env40557 = env40558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40557 == env40558) = true)

def env40559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4097,5276,74046,66897,13768,78895,1150,74815,1297,81226,8204,8201,257,74799,1344,5953]

theorem envBound40559 : H12AffineFastState.Bounded env40559 := by
  intro p hp
  have h : env40559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40558_40559 : H12AffineEnvironment.transform 17 65664 env40558 = env40559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40558 == env40559) = true)

theorem identity40559 : scanCanonicalize (H12AffineFastState.compose env40559 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40559 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40560 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,65536,74110,65664,4417,8541,4097,4492,74046,65601,12504,78143,366,74031,1,79962,8204,8201,257,74047,80,4689]

theorem envBound40560 : H12AffineFastState.Bounded env40560 := by
  intro p hp
  have h : env40560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40559_40560 : H12AffineEnvironment.transform 9 272 env40559 = env40560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40559 == env40560) = true)

def env40561 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,0,8540,65536,74110,65664,581,8541,773,648,74046,65601,9180,74299,366,74031,1,76638,8204,8201,257,74047,80,341]

theorem envBound40561 : H12AffineFastState.Bounded env40561 := by
  intro p hp
  have h : env40561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40560_40561 : H12AffineEnvironment.transform 11 772 env40560 = env40561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env40560 == env40561) = true)

def env40562 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,65536,74046,65664,517,8477,773,648,74046,65537,9116,74299,302,74031,1,76574,8204,8201,257,74047,16,277]

theorem envBound40562 : H12AffineFastState.Bounded env40562 := by
  intro p hp
  have h : env40562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40561_40562 : H12AffineEnvironment.transform 5 0 env40561 = env40562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40561 == env40562) = true)

theorem identity40562 : scanCanonicalize (H12AffineFastState.compose env40562 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound40562 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40563 : List Nat := [2,4,8,16,32,0,63,256,512,272,2048,772,8192,0,8476,65536,74046,65599,517,8477,773,567,74046,65537,8995,74299,302,74031,1,76574,8204,8201,257,74047,16,277]

theorem envBound40563 : H12AffineFastState.Bounded env40563 := by
  intro p hp
  have h : env40563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40562_40563 : H12AffineEnvironment.transform 6 63 env40562 = env40563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env40562 == env40563) = true)

def env40564 : List Nat := [2,4,8,16,32,0,63,256,512,272,2048,772,24,0,260,65536,65830,65599,517,261,773,567,65830,65537,827,66083,302,65847,1,68358,20,17,257,65831,16,277]

theorem envBound40564 : H12AffineFastState.Bounded env40564 := by
  intro p hp
  have h : env40564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40563_40564 : H12AffineEnvironment.transform 12 24 env40563 = env40564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40563 == env40564) = true)

theorem identity40564 : scanCanonicalize (H12AffineFastState.compose env40564 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40564 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40565 : List Nat := [2,4,8,16,32,0,63,256,16,272,2048,276,24,0,260,65536,65830,65599,21,261,277,39,65830,65537,299,65587,302,65847,1,67862,20,17,257,65831,16,277]

theorem envBound40565 : H12AffineFastState.Bounded env40565 := by
  intro p hp
  have h : env40565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40564_40565 : H12AffineEnvironment.transform 8 16 env40564 = env40565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40564 == env40565) = true)

theorem identity40565 : scanCanonicalize (H12AffineFastState.compose env40565 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 31) := by decide +kernel

theorem selectedBound40565 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40566 : List Nat := [2,4,8,16,32,0,63,256,16,272,2048,276,24,0,260,31,313,32,21,261,277,39,313,30,299,44,302,296,1,2313,20,17,257,312,16,277]

theorem envBound40566 : H12AffineFastState.Bounded env40566 := by
  intro p hp
  have h : env40566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40565_40566 : H12AffineEnvironment.transform 15 31 env40565 = env40566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31 env40565 == env40566) = true)

theorem identity40566 : scanCanonicalize (H12AffineFastState.compose env40566 (packedSelected [0,4,5,7,8,9,10,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40566 : packedSelected [0,4,5,7,8,9,10,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40567 : List Nat := [2,4,8,16,32,0,63,52,16,36,2048,32,24,0,48,31,13,32,21,49,33,39,13,30,31,44,26,28,1,2109,20,17,53,12,16,33]

theorem envBound40567 : H12AffineFastState.Bounded env40567 := by
  intro p hp
  have h : env40567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40566_40567 : H12AffineEnvironment.transform 7 52 env40566 = env40567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40566 == env40567) = true)

theorem identity40567 : scanCanonicalize (H12AffineFastState.compose env40567 (packedSelected [3,4,7,8,10,12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40567 : packedSelected [3,4,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40568 : List Nat := [2,2,8,16,32,0,57,50,16,34,2048,32,24,0,48,25,11,32,19,49,33,33,11,24,25,42,26,26,1,2107,18,17,51,10,16,33]

theorem envBound40568 : H12AffineFastState.Bounded env40568 := by
  intro p hp
  have h : env40568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40567_40568 : H12AffineEnvironment.transform 1 2 env40567 = env40568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40567 == env40568) = true)

theorem identity40568 : scanCanonicalize (H12AffineFastState.compose env40568 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40568 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env40569 : List Nat := [2,2,8,16,32,0,57,50,16,34,49,32,24,0,48,25,11,32,19,49,33,33,11,24,25,42,26,26,1,10,18,17,51,10,16,33]

theorem envBound40569 : H12AffineFastState.Bounded env40569 := by
  intro p hp
  have h : env40569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40568_40569 : H12AffineEnvironment.transform 10 49 env40568 = env40569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40568 == env40569) = true)

theorem identity40569 : scanCanonicalize (H12AffineFastState.compose env40569 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40569 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40570 : List Nat := [2,2,8,16,16,0,9,2,16,18,1,16,24,0,0,25,11,16,19,1,17,17,11,24,25,26,26,26,1,10,18,17,3,10,16,17]

theorem envBound40570 : H12AffineFastState.Bounded env40570 := by
  intro p hp
  have h : env40570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40569_40570 : H12AffineEnvironment.transform 4 16 env40569 = env40570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40569 == env40570) = true)

theorem identity40570 : scanCanonicalize (H12AffineFastState.compose env40570 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound40570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40571 : List Nat := [2,2,0,16,16,0,1,2,16,18,1,16,16,0,0,17,3,16,19,1,17,17,3,16,17,18,18,18,1,2,18,17,3,2,16,17]

theorem envBound40571 : H12AffineFastState.Bounded env40571 := by
  intro p hp
  have h : env40571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40570_40571 : H12AffineEnvironment.transform 2 0 env40570 = env40571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env40570 == env40571) = true)

theorem identity40571 : scanCanonicalize (H12AffineFastState.compose env40571 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40571 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40572 : List Nat := [0,0,0,16,16,0,1,0,16,16,1,16,16,0,0,17,1,16,17,1,17,17,1,16,17,16,16,16,1,0,16,17,1,0,16,17]

theorem envBound40572 : H12AffineFastState.Bounded env40572 := by
  intro p hp
  have h : env40572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40571_40572 : H12AffineEnvironment.transform 0 0 env40571 = env40572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40571 == env40572) = true)

theorem identity40572 : scanCanonicalize (H12AffineFastState.compose env40572 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40572 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40573 : List Nat := [0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,1,0,1,1,1,1,1,0,1,0,0,0,1,0,0,1,1,0,0,1]

theorem envBound40573 : H12AffineFastState.Bounded env40573 := by
  intro p hp
  have h : env40573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40572_40573 : H12AffineEnvironment.transform 3 0 env40572 = env40573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40572 == env40573) = true)

def env40574 : List Nat := [2,4,8,16,32,0,63,256,512,272,2048,772,25,0,261,65536,65831,65599,517,260,773,567,65831,65537,826,66082,302,65846,1,68359,21,16,257,65830,16,277]

theorem envBound40574 : H12AffineFastState.Bounded env40574 := by
  intro p hp
  have h : env40574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40563_40574 : H12AffineEnvironment.transform 12 25 env40563 = env40574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40563 == env40574) = true)

theorem identity40574 : scanCanonicalize (H12AffineFastState.compose env40574 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40574 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40575 : List Nat := [2,4,8,16,32,0,63,5,512,21,2048,513,25,0,0,65536,65570,65599,517,1,512,567,65570,65537,575,66082,43,65587,1,68098,21,16,4,65571,16,16]

theorem envBound40575 : H12AffineFastState.Bounded env40575 := by
  intro p hp
  have h : env40575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40574_40575 : H12AffineEnvironment.transform 7 5 env40574 = env40575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40574 == env40575) = true)

theorem identity40575 : scanCanonicalize (H12AffineFastState.compose env40575 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 527) := by decide +kernel

theorem selectedBound40575 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env40576 : List Nat := [2,4,8,16,32,0,63,5,512,21,2048,513,25,0,0,527,557,560,517,1,512,567,557,526,575,45,43,572,1,2061,21,16,4,556,16,16]

theorem envBound40576 : H12AffineFastState.Bounded env40576 := by
  intro p hp
  have h : env40576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40575_40576 : H12AffineEnvironment.transform 15 527 env40575 = env40576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 527 env40575 == env40576) = true)

theorem identity40576 : scanCanonicalize (H12AffineFastState.compose env40576 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound40576 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env40577 : List Nat := [2,4,8,16,32,0,63,5,54,21,2048,55,25,0,0,57,27,6,51,1,54,1,27,56,9,45,43,10,1,2061,21,16,4,26,16,16]

theorem envBound40577 : H12AffineFastState.Bounded env40577 := by
  intro p hp
  have h : env40577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40576_40577 : H12AffineEnvironment.transform 8 54 env40576 = env40577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env40576 == env40577) = true)

theorem identity40577 : scanCanonicalize (H12AffineFastState.compose env40577 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound40577 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40578 : List Nat := [2,4,8,16,32,0,63,5,54,21,59,55,25,0,0,57,27,6,51,1,54,1,27,56,9,45,43,10,1,54,21,16,4,26,16,16]

theorem envBound40578 : H12AffineFastState.Bounded env40578 := by
  intro p hp
  have h : env40578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40577_40578 : H12AffineEnvironment.transform 10 59 env40577 = env40578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env40577 == env40578) = true)

def env40579 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,65536,74047,65664,516,8476,773,648,74046,65536,9117,74299,303,74031,1,76575,8204,8201,257,74047,17,276]

theorem envBound40579 : H12AffineFastState.Bounded env40579 := by
  intro p hp
  have h : env40579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40561_40579 : H12AffineEnvironment.transform 5 1 env40561 = env40579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40561 == env40579) = true)

theorem identity40579 : scanCanonicalize (H12AffineFastState.compose env40579 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 166) := by decide +kernel

theorem selectedBound40579 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40580 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,166,0,443,65536,65945,65664,516,442,773,648,65944,65536,827,66205,303,65929,1,68537,170,175,257,65945,17,276]

theorem envBound40580 : H12AffineFastState.Bounded env40580 := by
  intro p hp
  have h : env40580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40579_40580 : H12AffineEnvironment.transform 12 166 env40579 = env40580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 166 env40579 == env40580) = true)

def env40581 : List Nat := [2,4,8,16,32,1,52,256,512,272,2048,772,18,0,271,65536,65837,65588,516,270,773,572,65836,65536,827,66089,303,65853,1,68365,30,27,257,65837,17,276]

theorem envBound40581 : H12AffineFastState.Bounded env40581 := by
  intro p hp
  have h : env40581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40580_40581 : H12AffineEnvironment.transform 6 52 env40580 = env40581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env40580 == env40581) = true)

theorem identity40581 : scanCanonicalize (H12AffineFastState.compose env40581 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound40581 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40582 : List Nat := [2,4,8,16,32,1,52,41,512,57,2048,557,18,0,38,65536,65540,65588,516,39,556,572,65541,65536,530,66089,6,65556,1,68132,30,27,40,65540,17,61]

theorem envBound40582 : H12AffineFastState.Bounded env40582 := by
  intro p hp
  have h : env40582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40581_40582 : H12AffineEnvironment.transform 7 41 env40581 = env40582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env40581 == env40582) = true)

theorem identity40582 : scanCanonicalize (H12AffineFastState.compose env40582 (packedSelected [3,8,10,12,13,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound40582 : packedSelected [3,8,10,12,13,15,23] rootPS < 2^1333 := by decide +kernel

def env40583 : List Nat := [2,4,8,16,32,1,52,41,512,57,2048,557,18,0,38,4,0,48,516,39,556,572,1,4,530,557,6,16,1,2592,30,27,40,0,17,61]

theorem envBound40583 : H12AffineFastState.Bounded env40583 := by
  intro p hp
  have h : env40583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40582_40583 : H12AffineEnvironment.transform 15 4 env40582 = env40583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env40582 == env40583) = true)

theorem identity40583 : scanCanonicalize (H12AffineFastState.compose env40583 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40583 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40584 : List Nat := [2,4,8,16,13,1,25,4,512,20,2048,512,18,0,11,4,0,29,516,10,513,529,1,4,530,512,6,16,1,2573,30,27,5,0,17,16]

theorem envBound40584 : H12AffineFastState.Bounded env40584 := by
  intro p hp
  have h : env40584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40583_40584 : H12AffineEnvironment.transform 4 13 env40583 = env40584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40583 == env40584) = true)

theorem identity40584 : scanCanonicalize (H12AffineFastState.compose env40584 (packedSelected [1,4,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound40584 : packedSelected [1,4,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env40585 : List Nat := [2,4,8,16,13,1,25,4,512,20,16,512,18,0,11,4,0,29,516,10,513,529,1,4,530,512,6,16,1,541,30,27,5,0,17,16]

theorem envBound40585 : H12AffineFastState.Bounded env40585 := by
  intro p hp
  have h : env40585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40584_40585 : H12AffineEnvironment.transform 10 16 env40584 = env40585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env40584 == env40585) = true)

theorem identity40585 : scanCanonicalize (H12AffineFastState.compose env40585 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound40585 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40586 : List Nat := [2,4,8,6,13,1,15,4,512,2,6,512,4,0,11,4,0,11,516,10,513,519,1,4,516,512,6,6,1,523,8,13,5,0,7,6]

theorem envBound40586 : H12AffineFastState.Bounded env40586 := by
  intro p hp
  have h : env40586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40585_40586 : H12AffineEnvironment.transform 3 6 env40585 = env40586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env40585 == env40586) = true)

theorem identity40586 : scanCanonicalize (H12AffineFastState.compose env40586 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound40586 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env40587 : List Nat := [2,4,8,6,13,1,15,4,7,2,6,7,4,0,11,4,0,11,3,10,6,0,1,4,3,7,6,6,1,12,8,13,5,0,7,6]

theorem envBound40587 : H12AffineFastState.Bounded env40587 := by
  intro p hp
  have h : env40587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40586_40587 : H12AffineEnvironment.transform 8 7 env40586 = env40587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env40586 == env40587) = true)

theorem identity40587 : scanCanonicalize (H12AffineFastState.compose env40587 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40587 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40588 : List Nat := [2,1,8,3,8,1,10,1,2,2,3,2,1,0,11,1,0,11,3,10,3,0,1,1,3,2,3,3,1,9,8,8,0,0,2,3]

theorem envBound40588 : H12AffineFastState.Bounded env40588 := by
  intro p hp
  have h : env40588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40587_40588 : H12AffineEnvironment.transform 1 1 env40587 = env40588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40587 == env40588) = true)

theorem identity40588 : scanCanonicalize (H12AffineFastState.compose env40588 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40588 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40589 : List Nat := [2,1,3,3,3,1,1,1,2,2,3,2,1,0,0,1,0,0,3,1,3,0,1,1,3,2,3,3,1,2,3,3,0,0,2,3]

theorem envBound40589 : H12AffineFastState.Bounded env40589 := by
  intro p hp
  have h : env40589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40588_40589 : H12AffineEnvironment.transform 2 3 env40588 = env40589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40588 == env40589) = true)

theorem identity40589 : scanCanonicalize (H12AffineFastState.compose env40589 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40589 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40590 : List Nat := [1,1,0,0,0,1,1,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0,1,1,0,1,0,0,1,1,0,0,0,0,1,0]

theorem envBound40590 : H12AffineFastState.Bounded env40590 := by
  intro p hp
  have h : env40590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40589_40590 : H12AffineEnvironment.transform 0 1 env40589 = env40590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40589 == env40590) = true)

def env40591 : List Nat := [2,4,8,16,32,1,53,256,512,272,2048,772,19,0,270,65536,65836,65589,516,271,773,573,65837,65536,827,66088,303,65852,1,68364,31,26,257,65836,17,276]

theorem envBound40591 : H12AffineFastState.Bounded env40591 := by
  intro p hp
  have h : env40591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40580_40591 : H12AffineEnvironment.transform 6 53 env40580 = env40591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env40580 == env40591) = true)

theorem identity40591 : scanCanonicalize (H12AffineFastState.compose env40591 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound40591 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40592 : List Nat := [2,4,8,16,32,1,53,34,512,50,2048,550,19,0,44,65536,65550,65589,516,45,551,573,65551,65536,537,66088,13,65566,1,68142,31,26,35,65550,17,54]

theorem envBound40592 : H12AffineFastState.Bounded env40592 := by
  intro p hp
  have h : env40592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40591_40592 : H12AffineEnvironment.transform 7 34 env40591 = env40592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env40591 == env40592) = true)

theorem identity40592 : scanCanonicalize (H12AffineFastState.compose env40592 (packedSelected [0,2,3,5,9,10,13,16,17,18,19,20,23,32,38] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound40592 : packedSelected [0,2,3,5,9,10,13,16,17,18,19,20,23,32,38] rootPS < 2^1333 := by decide +kernel

def env40593 : List Nat := [2,4,8,16,26,1,15,24,512,8,2048,540,19,0,22,65536,65550,65551,516,23,541,519,65551,65536,537,66066,13,65566,1,68116,31,26,25,65550,17,12]

theorem envBound40593 : H12AffineFastState.Bounded env40593 := by
  intro p hp
  have h : env40593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40592_40593 : H12AffineEnvironment.transform 4 26 env40592 = env40593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env40592 == env40593) = true)

theorem identity40593 : scanCanonicalize (H12AffineFastState.compose env40593 (packedSelected [0,4,7,8,9,11,12,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 524) := by decide +kernel

theorem selectedBound40593 : packedSelected [0,4,7,8,9,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env40594 : List Nat := [2,4,8,16,26,1,15,24,512,8,524,540,19,0,22,65536,65550,65551,516,23,541,519,65551,65536,537,66066,13,65566,1,65560,31,26,25,65550,17,12]

theorem envBound40594 : H12AffineFastState.Bounded env40594 := by
  intro p hp
  have h : env40594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40593_40594 : H12AffineEnvironment.transform 10 524 env40593 = env40594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 524 env40593 == env40594) = true)

theorem identity40594 : scanCanonicalize (H12AffineFastState.compose env40594 (packedSelected [2,3,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound40594 : packedSelected [2,3,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40595 : List Nat := [2,4,8,16,26,1,15,24,12,8,0,16,19,0,22,65536,65550,65551,8,23,17,11,65551,65536,21,65566,13,65566,1,65560,31,26,25,65550,17,12]

theorem envBound40595 : H12AffineFastState.Bounded env40595 := by
  intro p hp
  have h : env40595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40594_40595 : H12AffineEnvironment.transform 8 12 env40594 = env40595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env40594 == env40595) = true)

theorem identity40595 : scanCanonicalize (H12AffineFastState.compose env40595 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound40595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40596 : List Nat := [2,4,8,16,26,1,15,24,12,8,0,16,19,0,22,4,10,11,8,23,17,11,11,4,21,26,13,26,1,28,31,26,25,10,17,12]

theorem envBound40596 : H12AffineFastState.Bounded env40596 := by
  intro p hp
  have h : env40596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40595_40596 : H12AffineEnvironment.transform 15 4 env40595 = env40596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env40595 == env40596) = true)

theorem identity40596 : scanCanonicalize (H12AffineFastState.compose env40596 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40596 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40597 : List Nat := [2,4,8,1,11,1,15,9,12,8,0,1,2,0,7,4,10,11,8,6,0,11,11,4,4,11,13,11,1,13,14,11,8,10,0,12]

theorem envBound40597 : H12AffineFastState.Bounded env40597 := by
  intro p hp
  have h : env40597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40596_40597 : H12AffineEnvironment.transform 3 1 env40596 = env40597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40596 == env40597) = true)

theorem identity40597 : scanCanonicalize (H12AffineFastState.compose env40597 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40597 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40598 : List Nat := [2,4,5,1,6,1,2,4,1,5,0,1,2,0,7,4,7,6,5,6,0,6,6,4,4,6,0,6,1,0,3,6,5,7,0,1]

theorem envBound40598 : H12AffineFastState.Bounded env40598 := by
  intro p hp
  have h : env40598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40597_40598 : H12AffineEnvironment.transform 2 5 env40597 = env40598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40597 == env40598) = true)

theorem identity40598 : scanCanonicalize (H12AffineFastState.compose env40598 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40598 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40599 : List Nat := [2,2,3,1,0,1,2,2,1,3,0,1,2,0,1,2,1,0,3,0,0,0,0,2,2,0,0,0,1,0,3,0,3,1,0,1]

theorem envBound40599 : H12AffineFastState.Bounded env40599 := by
  intro p hp
  have h : env40599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40598_40599 : H12AffineEnvironment.transform 1 2 env40598 = env40599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40598 == env40599) = true)

def env40600 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,0,8540,65536,74110,65664,580,8541,772,649,74046,65601,9181,74298,366,74031,1,76639,8204,8201,257,74047,80,340]

theorem envBound40600 : H12AffineFastState.Bounded env40600 := by
  intro p hp
  have h : env40600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40560_40600 : H12AffineEnvironment.transform 11 773 env40560 = env40600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env40560 == env40600) = true)

def env40601 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,65536,74046,65664,516,8477,772,649,74046,65537,9117,74298,302,74031,1,76575,8204,8201,257,74047,16,276]

theorem envBound40601 : H12AffineFastState.Bounded env40601 := by
  intro p hp
  have h : env40601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40600_40601 : H12AffineEnvironment.transform 5 0 env40600 = env40601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40600 == env40601) = true)

theorem identity40601 : scanCanonicalize (H12AffineFastState.compose env40601 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8593) := by decide +kernel

theorem selectedBound40601 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40602 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,8593,175,8465,516,8477,772,649,175,8592,9117,939,302,190,1,2702,8204,8201,257,174,16,276]

theorem envBound40602 : H12AffineFastState.Bounded env40602 := by
  intro p hp
  have h : env40602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40601_40602 : H12AffineEnvironment.transform 15 8593 env40601 = env40602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8593 env40601 == env40602) = true)

def env40603 : List Nat := [2,4,8,16,32,0,128,256,28,272,2048,281,8192,0,8476,8593,175,8465,24,8477,280,149,175,8592,8577,439,302,190,1,2194,8204,8201,257,174,16,276]

theorem envBound40603 : H12AffineFastState.Bounded env40603 := by
  intro p hp
  have h : env40603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40602_40603 : H12AffineEnvironment.transform 8 28 env40602 = env40603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env40602 == env40603) = true)

def env40604 : List Nat := [2,4,8,16,32,0,128,256,28,272,2048,281,2336,0,2108,2225,175,2097,24,2109,280,149,175,2224,2209,439,302,190,1,2194,2348,2345,257,174,16,276]

theorem envBound40604 : H12AffineFastState.Bounded env40604 := by
  intro p hp
  have h : env40604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40603_40604 : H12AffineEnvironment.transform 12 2336 env40603 = env40604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2336 env40603 == env40604) = true)

theorem identity40604 : scanCanonicalize (H12AffineFastState.compose env40604 (packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound40604 : packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env40605 : List Nat := [2,4,8,16,12,0,128,256,28,272,2048,281,2316,0,2064,2205,131,2077,24,2065,280,149,131,2204,2189,411,258,146,1,2194,2304,2309,257,130,16,276]

theorem envBound40605 : H12AffineFastState.Bounded env40605 := by
  intro p hp
  have h : env40605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40604_40605 : H12AffineEnvironment.transform 4 12 env40604 = env40605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env40604 == env40605) = true)

theorem identity40605 : scanCanonicalize (H12AffineFastState.compose env40605 (packedSelected [1,4,8,9,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound40605 : packedSelected [1,4,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40606 : List Nat := [2,4,8,16,12,0,128,256,28,272,286,281,18,0,270,387,131,259,24,271,280,149,131,386,403,411,258,146,1,396,30,27,257,130,16,276]

theorem envBound40606 : H12AffineFastState.Bounded env40606 := by
  intro p hp
  have h : env40606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40605_40606 : H12AffineEnvironment.transform 10 286 env40605 = env40606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env40605 == env40606) = true)

theorem identity40606 : scanCanonicalize (H12AffineFastState.compose env40606 (packedSelected [1,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound40606 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env40607 : List Nat := [2,4,8,16,12,0,128,2,28,18,28,27,18,0,12,129,131,1,24,13,26,149,131,128,145,153,0,146,1,142,30,27,3,130,16,22]

theorem envBound40607 : H12AffineFastState.Bounded env40607 := by
  intro p hp
  have h : env40607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40606_40607 : H12AffineEnvironment.transform 7 2 env40606 = env40607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env40606 == env40607) = true)

theorem identity40607 : scanCanonicalize (H12AffineFastState.compose env40607 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40607 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env40608 : List Nat := [2,4,8,16,12,0,9,2,28,18,28,27,18,0,12,8,10,1,24,13,26,28,10,9,24,16,0,27,1,7,30,27,3,11,16,22]

theorem envBound40608 : H12AffineFastState.Bounded env40608 := by
  intro p hp
  have h : env40608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40607_40608 : H12AffineEnvironment.transform 6 9 env40607 = env40608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40607 == env40608) = true)

def env40609 : List Nat := [2,4,8,16,32,0,128,256,28,272,2048,281,2337,0,2109,2224,175,2096,24,2108,280,149,175,2225,2208,439,302,190,1,2194,2349,2344,257,174,16,276]

theorem envBound40609 : H12AffineFastState.Bounded env40609 := by
  intro p hp
  have h : env40609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40603_40609 : H12AffineEnvironment.transform 12 2337 env40603 = env40609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2337 env40603 == env40609) = true)

theorem identity40609 : scanCanonicalize (H12AffineFastState.compose env40609 (packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40609 : packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env40610 : List Nat := [2,4,8,16,11,0,128,256,28,272,2048,281,2314,0,2070,2203,132,2075,24,2071,280,149,132,2202,2187,412,261,149,1,2194,2310,2307,257,133,16,276]

theorem envBound40610 : H12AffineFastState.Bounded env40610 := by
  intro p hp
  have h : env40610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40609_40610 : H12AffineEnvironment.transform 4 11 env40609 = env40610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40609 == env40610) = true)

theorem identity40610 : scanCanonicalize (H12AffineFastState.compose env40610 (packedSelected [1,4,8,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound40610 : packedSelected [1,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env40611 : List Nat := [2,4,8,16,11,0,128,256,28,272,396,281,134,0,410,279,132,407,24,411,280,149,132,278,263,412,261,149,1,286,138,143,257,133,16,276]

theorem envBound40611 : H12AffineFastState.Bounded env40611 := by
  intro p hp
  have h : env40611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40610_40611 : H12AffineEnvironment.transform 10 396 env40610 = env40611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env40610 == env40611) = true)

theorem identity40611 : scanCanonicalize (H12AffineFastState.compose env40611 (packedSelected [0,1,3,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 139) := by decide +kernel

theorem selectedBound40611 : packedSelected [0,1,3,7,10] rootPS < 2^1333 := by decide +kernel

def env40612 : List Nat := [2,4,8,16,11,0,128,139,28,155,7,146,134,0,17,156,132,28,24,16,147,149,132,157,140,23,142,149,1,149,138,143,138,133,16,159]

theorem envBound40612 : H12AffineFastState.Bounded env40612 := by
  intro p hp
  have h : env40612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40611_40612 : H12AffineEnvironment.transform 7 139 env40611 = env40612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 139 env40611 == env40612) = true)

theorem identity40612 : scanCanonicalize (H12AffineFastState.compose env40612 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40612 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40613 : List Nat := [2,4,8,10,11,0,128,139,6,129,7,136,134,0,11,134,132,6,2,10,137,143,132,135,140,13,142,143,1,143,138,143,138,133,10,133]

theorem envBound40613 : H12AffineFastState.Bounded env40613 := by
  intro p hp
  have h : env40613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40612_40613 : H12AffineEnvironment.transform 3 10 env40612 = env40613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40612 == env40613) = true)

def env40614 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,280,8192,0,8476,8593,175,8465,25,8477,281,148,175,8592,8576,438,302,190,1,2195,8204,8201,257,174,16,276]

theorem envBound40614 : H12AffineFastState.Bounded env40614 := by
  intro p hp
  have h : env40614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40602_40614 : H12AffineEnvironment.transform 8 29 env40602 = env40614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env40602 == env40614) = true)

def env40615 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,280,2336,0,2108,2225,175,2097,25,2109,281,148,175,2224,2208,438,302,190,1,2195,2348,2345,257,174,16,276]

theorem envBound40615 : H12AffineFastState.Bounded env40615 := by
  intro p hp
  have h : env40615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40614_40615 : H12AffineEnvironment.transform 12 2336 env40614 = env40615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2336 env40614 == env40615) = true)

theorem identity40615 : scanCanonicalize (H12AffineFastState.compose env40615 (packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS)) = affineNative (2^(7+1) ^^^ 155) := by decide +kernel

theorem selectedBound40615 : packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env40616 : List Nat := [2,4,8,16,32,0,128,155,29,139,2048,131,2235,0,2108,2225,175,2097,25,2109,130,148,175,2224,2208,45,181,190,1,2195,2231,2226,154,174,16,143]

theorem envBound40616 : H12AffineFastState.Bounded env40616 := by
  intro p hp
  have h : env40616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40615_40616 : H12AffineEnvironment.transform 7 155 env40615 = env40616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 155 env40615 == env40616) = true)

theorem identity40616 : scanCanonicalize (H12AffineFastState.compose env40616 (packedSelected [1,2,5,7,9,11,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 178) := by decide +kernel

theorem selectedBound40616 : packedSelected [1,2,5,7,9,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env40617 : List Nat := [2,4,8,16,32,0,128,155,29,139,178,131,9,0,142,3,175,131,25,143,130,148,175,2,18,45,181,190,1,33,5,0,154,174,16,143]

theorem envBound40617 : H12AffineFastState.Bounded env40617 := by
  intro p hp
  have h : env40617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40616_40617 : H12AffineEnvironment.transform 10 178 env40616 = env40617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 178 env40616 == env40617) = true)

theorem identity40617 : scanCanonicalize (H12AffineFastState.compose env40617 (packedSelected [0,3,4,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound40617 : packedSelected [0,3,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env40618 : List Nat := [2,4,8,16,32,0,24,3,29,19,42,27,9,0,22,3,55,27,25,23,26,12,55,2,18,45,45,38,1,33,5,0,2,54,16,23]

theorem envBound40618 : H12AffineFastState.Bounded env40618 := by
  intro p hp
  have h : env40618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40617_40618 : H12AffineEnvironment.transform 6 24 env40617 = env40618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env40617 == env40618) = true)

theorem identity40618 : scanCanonicalize (H12AffineFastState.compose env40618 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40618 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env40619 : List Nat := [2,4,8,16,10,0,24,3,29,19,0,27,9,0,22,3,29,27,25,23,26,12,29,2,18,7,7,12,1,11,5,0,2,28,16,23]

theorem envBound40619 : H12AffineFastState.Bounded env40619 := by
  intro p hp
  have h : env40619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40618_40619 : H12AffineEnvironment.transform 4 10 env40618 = env40619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40618 == env40619) = true)

theorem identity40619 : scanCanonicalize (H12AffineFastState.compose env40619 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40619 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env40620 : List Nat := [2,2,8,16,10,0,24,3,27,19,0,27,9,0,16,3,27,27,25,17,26,10,27,2,18,1,1,10,1,11,3,0,2,26,16,17]

theorem envBound40620 : H12AffineFastState.Bounded env40620 := by
  intro p hp
  have h : env40620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40619_40620 : H12AffineEnvironment.transform 1 2 env40619 = env40620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40619 == env40620) = true)

theorem identity40620 : scanCanonicalize (H12AffineFastState.compose env40620 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40621 : List Nat := [2,2,3,16,1,0,19,3,16,19,0,16,2,0,16,3,16,16,18,17,17,1,16,2,18,1,1,1,1,0,3,0,2,17,16,17]

theorem envBound40621 : H12AffineFastState.Bounded env40621 := by
  intro p hp
  have h : env40621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40620_40621 : H12AffineEnvironment.transform 2 3 env40620 = env40621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40620 == env40621) = true)

theorem identity40621 : scanCanonicalize (H12AffineFastState.compose env40621 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40622 : List Nat := [1,1,0,16,1,0,16,0,16,16,0,16,1,0,16,0,16,16,17,17,17,1,16,1,17,1,1,1,1,0,0,0,1,17,16,17]

theorem envBound40622 : H12AffineFastState.Bounded env40622 := by
  intro p hp
  have h : env40622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40621_40622 : H12AffineEnvironment.transform 0 1 env40621 = env40622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40621 == env40622) = true)

theorem identity40622 : scanCanonicalize (H12AffineFastState.compose env40622 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40623 : List Nat := [1,1,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,1,1,0,1]

theorem envBound40623 : H12AffineFastState.Bounded env40623 := by
  intro p hp
  have h : env40623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40622_40623 : H12AffineEnvironment.transform 3 0 env40622 = env40623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40622 == env40623) = true)

def env40624 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,280,2337,0,2109,2224,175,2096,25,2108,281,148,175,2225,2209,438,302,190,1,2195,2349,2344,257,174,16,276]

theorem envBound40624 : H12AffineFastState.Bounded env40624 := by
  intro p hp
  have h : env40624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40614_40624 : H12AffineEnvironment.transform 12 2337 env40614 = env40624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2337 env40614 == env40624) = true)

theorem identity40624 : scanCanonicalize (H12AffineFastState.compose env40624 (packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound40624 : packedSelected [3,4,9,11,12,15,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env40625 : List Nat := [2,4,8,16,32,0,128,156,29,140,2048,132,2237,0,2109,2224,175,2096,25,2108,133,148,175,2225,2209,42,178,190,1,2195,2225,2228,157,174,16,136]

theorem envBound40625 : H12AffineFastState.Bounded env40625 := by
  intro p hp
  have h : env40625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40624_40625 : H12AffineEnvironment.transform 7 156 env40624 = env40625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env40624 == env40625) = true)

theorem identity40625 : scanCanonicalize (H12AffineFastState.compose env40625 (packedSelected [0,2,3,9,10,12,15,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40625 : packedSelected [0,2,3,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40626 : List Nat := [2,2,8,16,32,0,128,154,27,138,2048,130,2235,0,2107,2224,169,2096,25,2106,131,146,169,2225,2209,42,178,184,1,2195,2225,2226,155,168,16,136]

theorem envBound40626 : H12AffineFastState.Bounded env40626 := by
  intro p hp
  have h : env40626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40625_40626 : H12AffineEnvironment.transform 1 2 env40625 = env40626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40625 == env40626) = true)

theorem identity40626 : scanCanonicalize (H12AffineFastState.compose env40626 (packedSelected [2,3,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound40626 : packedSelected [2,3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40627 : List Nat := [2,2,8,16,32,0,128,154,27,138,162,130,25,0,153,18,169,146,25,152,131,146,169,19,3,42,178,184,1,49,19,16,155,168,16,136]

theorem envBound40627 : H12AffineFastState.Bounded env40627 := by
  intro p hp
  have h : env40627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40626_40627 : H12AffineEnvironment.transform 10 162 env40626 = env40627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env40626 == env40627) = true)

theorem identity40627 : scanCanonicalize (H12AffineFastState.compose env40627 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40627 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40628 : List Nat := [2,2,8,10,32,0,128,128,1,138,162,130,3,0,131,8,169,136,3,130,131,136,169,9,3,42,168,162,1,43,9,10,129,168,10,136]

theorem envBound40628 : H12AffineFastState.Bounded env40628 := by
  intro p hp
  have h : env40628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40627_40628 : H12AffineEnvironment.transform 3 10 env40627 = env40628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40627 == env40628) = true)

theorem identity40628 : scanCanonicalize (H12AffineFastState.compose env40628 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound40628 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env40629 : List Nat := [2,2,8,10,32,0,41,41,1,35,11,43,3,0,42,8,0,33,3,43,42,33,0,9,3,42,1,11,1,43,9,10,40,1,10,33]

theorem envBound40629 : H12AffineFastState.Bounded env40629 := by
  intro p hp
  have h : env40629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40628_40629 : H12AffineEnvironment.transform 6 41 env40628 = env40629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env40628 == env40629) = true)

def env40630 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,65536,74047,65664,517,8476,772,649,74046,65536,9116,74298,303,74031,1,76574,8204,8201,257,74047,17,277]

theorem envBound40630 : H12AffineFastState.Bounded env40630 := by
  intro p hp
  have h : env40630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40600_40630 : H12AffineEnvironment.transform 5 1 env40600 = env40630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40600 == env40630) = true)

theorem identity40630 : scanCanonicalize (H12AffineFastState.compose env40630 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 392) := by decide +kernel

theorem selectedBound40630 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40631 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,392,8375,264,517,8476,772,649,8374,392,9116,9138,303,8359,1,10902,8204,8201,257,8375,17,277]

theorem envBound40631 : H12AffineFastState.Bounded env40631 := by
  intro p hp
  have h : env40631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40630_40631 : H12AffineEnvironment.transform 15 392 env40630 = env40631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env40630 == env40631) = true)

def env40632 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,24,0,261,392,175,264,517,260,772,649,174,392,900,938,303,191,1,2702,20,17,257,175,17,277]

theorem envBound40632 : H12AffineFastState.Bounded env40632 := by
  intro p hp
  have h : env40632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40631_40632 : H12AffineEnvironment.transform 12 24 env40631 = env40632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40631 == env40632) = true)

theorem identity40632 : scanCanonicalize (H12AffineFastState.compose env40632 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40632 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40633 : List Nat := [2,4,8,16,32,1,128,256,17,272,2048,276,24,0,261,392,175,264,20,260,277,152,174,392,405,443,303,191,1,2207,20,17,257,175,17,277]

theorem envBound40633 : H12AffineFastState.Bounded env40633 := by
  intro p hp
  have h : env40633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40632_40633 : H12AffineEnvironment.transform 8 17 env40632 = env40633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40632 == env40633) = true)

theorem identity40633 : scanCanonicalize (H12AffineFastState.compose env40633 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound40633 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40634 : List Nat := [2,4,8,16,32,1,128,41,17,57,2048,61,24,0,44,161,175,33,20,45,60,152,174,161,188,146,6,191,1,2207,20,17,40,175,17,60]

theorem envBound40634 : H12AffineFastState.Bounded env40634 := by
  intro p hp
  have h : env40634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40633_40634 : H12AffineEnvironment.transform 7 41 env40633 = env40634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env40633 == env40634) = true)

theorem identity40634 : scanCanonicalize (H12AffineFastState.compose env40634 (packedSelected [0,4,5,7,8,9,10,15,16,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40634 : packedSelected [0,4,5,7,8,9,10,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40635 : List Nat := [2,4,8,12,32,1,128,41,13,37,2048,33,4,0,44,161,175,33,8,45,32,132,174,161,160,142,6,163,1,2179,8,13,40,175,13,32]

theorem envBound40635 : H12AffineFastState.Bounded env40635 := by
  intro p hp
  have h : env40635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40634_40635 : H12AffineEnvironment.transform 3 12 env40634 = env40635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40634 == env40635) = true)

theorem identity40635 : scanCanonicalize (H12AffineFastState.compose env40635 (packedSelected [3,4,7,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound40635 : packedSelected [3,4,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40636 : List Nat := [2,4,8,12,32,1,37,41,13,37,2048,33,4,0,44,4,10,33,8,45,32,33,11,4,5,43,6,6,1,2086,8,13,40,10,13,32]

theorem envBound40636 : H12AffineFastState.Bounded env40636 := by
  intro p hp
  have h : env40636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40635_40636 : H12AffineEnvironment.transform 6 37 env40635 = env40636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env40635 == env40636) = true)

theorem identity40636 : scanCanonicalize (H12AffineFastState.compose env40636 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40636 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env40637 : List Nat := [2,4,8,12,32,1,37,41,13,37,0,33,4,0,44,4,10,33,8,45,32,33,11,4,5,43,6,6,1,38,8,13,40,10,13,32]

theorem envBound40637 : H12AffineFastState.Bounded env40637 := by
  intro p hp
  have h : env40637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40636_40637 : H12AffineEnvironment.transform 10 0 env40636 = env40637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40636 == env40637) = true)

theorem identity40637 : scanCanonicalize (H12AffineFastState.compose env40637 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40637 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40638 : List Nat := [2,4,8,12,0,1,5,9,13,5,0,1,4,0,12,4,10,1,8,13,0,1,11,4,5,11,6,6,1,6,8,13,8,10,13,0]

theorem envBound40638 : H12AffineFastState.Bounded env40638 := by
  intro p hp
  have h : env40638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40637_40638 : H12AffineEnvironment.transform 4 0 env40637 = env40638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40637 == env40638) = true)

theorem identity40638 : scanCanonicalize (H12AffineFastState.compose env40638 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40638 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40639 : List Nat := [2,4,5,1,0,1,5,4,0,5,0,1,4,0,1,4,7,1,5,0,0,1,6,4,5,6,6,6,1,6,5,0,5,7,0,0]

theorem envBound40639 : H12AffineFastState.Bounded env40639 := by
  intro p hp
  have h : env40639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40638_40639 : H12AffineEnvironment.transform 2 5 env40638 = env40639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40638 == env40639) = true)

theorem identity40639 : scanCanonicalize (H12AffineFastState.compose env40639 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40640 : List Nat := [2,2,3,1,0,1,3,2,0,3,0,1,2,0,1,2,1,1,3,0,0,1,0,2,3,0,0,0,1,0,3,0,3,1,0,0]

theorem envBound40640 : H12AffineFastState.Bounded env40640 := by
  intro p hp
  have h : env40640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40639_40640 : H12AffineEnvironment.transform 1 2 env40639 = env40640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40639 == env40640) = true)

def env40641 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,25,0,260,392,174,264,517,261,772,649,175,392,901,939,303,190,1,2703,21,16,257,174,17,277]

theorem envBound40641 : H12AffineFastState.Bounded env40641 := by
  intro p hp
  have h : env40641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40631_40641 : H12AffineEnvironment.transform 12 25 env40631 = env40641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40631 == env40641) = true)

theorem identity40641 : scanCanonicalize (H12AffineFastState.compose env40641 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40641 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40642 : List Nat := [2,4,8,16,32,1,128,4,512,20,2048,513,25,0,0,140,174,12,517,1,512,649,175,140,641,687,43,190,1,2703,21,16,5,174,17,17]

theorem envBound40642 : H12AffineFastState.Bounded env40642 := by
  intro p hp
  have h : env40642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40641_40642 : H12AffineEnvironment.transform 7 4 env40641 = env40642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40641 == env40642) = true)

theorem identity40642 : scanCanonicalize (H12AffineFastState.compose env40642 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40642 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env40643 : List Nat := [2,4,8,16,13,1,128,4,512,20,2048,513,25,0,0,140,131,12,517,1,512,649,130,140,641,642,6,147,1,2703,21,16,5,131,17,17]

theorem envBound40643 : H12AffineFastState.Bounded env40643 := by
  intro p hp
  have h : env40643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40642_40643 : H12AffineEnvironment.transform 4 13 env40642 = env40643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40642 == env40643) = true)

theorem identity40643 : scanCanonicalize (H12AffineFastState.compose env40643 (packedSelected [0,1,2,3,4,5,7,9,11,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound40643 : packedSelected [0,1,2,3,4,5,7,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env40644 : List Nat := [2,4,8,16,13,1,31,4,512,20,2048,513,25,0,0,19,28,12,517,1,512,534,29,19,542,541,6,12,1,2576,21,16,5,28,17,17]

theorem envBound40644 : H12AffineFastState.Bounded env40644 := by
  intro p hp
  have h : env40644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40643_40644 : H12AffineEnvironment.transform 6 31 env40643 = env40644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env40643 == env40644) = true)

theorem identity40644 : scanCanonicalize (H12AffineFastState.compose env40644 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40644 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env40645 : List Nat := [2,4,8,16,13,1,31,4,17,20,2048,16,25,0,0,19,28,12,20,1,17,7,29,19,15,12,6,12,1,2049,21,16,5,28,17,17]

theorem envBound40645 : H12AffineFastState.Bounded env40645 := by
  intro p hp
  have h : env40645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40644_40645 : H12AffineEnvironment.transform 8 17 env40644 = env40645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40644 == env40645) = true)

theorem identity40645 : scanCanonicalize (H12AffineFastState.compose env40645 (packedSelected [3,4] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound40645 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env40646 : List Nat := [2,4,8,16,13,1,31,4,17,20,27,16,25,0,0,19,28,12,20,1,17,7,29,19,15,12,6,12,1,26,21,16,5,28,17,17]

theorem envBound40646 : H12AffineFastState.Bounded env40646 := by
  intro p hp
  have h : env40646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40645_40646 : H12AffineEnvironment.transform 10 27 env40645 = env40646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env40645 == env40646) = true)

def env40647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4097,5276,74046,66897,13768,78895,1151,74815,1297,81226,8204,8201,257,74799,1344,5953]

theorem envBound40647 : H12AffineFastState.Bounded env40647 := by
  intro p hp
  have h : env40647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40558_40647 : H12AffineEnvironment.transform 17 65665 env40558 = env40647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40558 == env40647) = true)

theorem identity40647 : scanCanonicalize (H12AffineFastState.compose env40647 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound40647 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74862,65665,273,8541,81,1228,74046,66897,9624,74879,1151,74815,1297,77082,8204,8201,257,74799,1344,1809]

theorem envBound40648 : H12AffineFastState.Bounded env40648 := by
  intro p hp
  have h : env40648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40647_40648 : H12AffineEnvironment.transform 11 80 env40647 = env40648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env40647 == env40648) = true)

def env40649 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74030,65665,273,8541,81,396,74046,65553,8408,74047,319,74111,81,75866,8204,8201,257,74095,0,593]

theorem envBound40649 : H12AffineFastState.Bounded env40649 := by
  intro p hp
  have h : env40649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40648_40649 : H12AffineEnvironment.transform 9 320 env40648 = env40649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env40648 == env40649) = true)

theorem identity40649 : scanCanonicalize (H12AffineFastState.compose env40649 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40649 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env40650 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,8192,80,8216,65536,73834,65665,85,8217,81,200,73850,65553,8408,73851,123,73787,81,75866,8204,8201,69,73771,0,593]

theorem envBound40650 : H12AffineFastState.Bounded env40650 := by
  intro p hp
  have h : env40650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40649_40650 : H12AffineEnvironment.transform 7 68 env40649 = env40650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40649 == env40650) = true)

theorem identity40650 : scanCanonicalize (H12AffineFastState.compose env40650 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound40650 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env40651 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,657,80,649,65536,66299,65665,85,648,81,200,66283,65553,585,66282,123,66218,81,68299,669,664,69,66234,0,593]

theorem envBound40651 : H12AffineFastState.Bounded env40651 := by
  intro p hp
  have h : env40651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40650_40651 : H12AffineEnvironment.transform 12 657 env40650 = env40651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env40650 == env40651) = true)

theorem identity40651 : scanCanonicalize (H12AffineFastState.compose env40651 (packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 2769) := by decide +kernel

theorem selectedBound40651 : packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS < 2^1333 := by decide +kernel

def env40652 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,657,80,649,2769,2090,2640,85,648,81,200,2106,2752,585,2107,123,2171,81,26,669,664,69,2155,0,593]

theorem envBound40652 : H12AffineFastState.Bounded env40652 := by
  intro p hp
  have h : env40652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40651_40652 : H12AffineEnvironment.transform 15 2769 env40651 = env40652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2769 env40651 == env40652) = true)

theorem identity40652 : scanCanonicalize (H12AffineFastState.compose env40652 (packedSelected [2,4,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound40652 : packedSelected [2,4,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40653 : List Nat := [2,4,8,16,32,64,128,68,512,4,674,80,657,80,649,115,648,242,85,648,81,200,664,98,585,665,123,729,81,26,669,664,69,713,0,593]

theorem envBound40653 : H12AffineFastState.Bounded env40653 := by
  intro p hp
  have h : env40653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40652_40653 : H12AffineEnvironment.transform 10 674 env40652 = env40653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env40652 == env40653) = true)

theorem identity40653 : scanCanonicalize (H12AffineFastState.compose env40653 (packedSelected [1,2,3,4,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound40653 : packedSelected [1,2,3,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40654 : List Nat := [2,4,8,16,32,64,128,68,136,4,42,80,25,80,1,115,0,242,85,0,81,200,16,98,193,17,123,81,81,26,21,16,69,65,0,217]

theorem envBound40654 : H12AffineFastState.Bounded env40654 := by
  intro p hp
  have h : env40654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40653_40654 : H12AffineEnvironment.transform 8 136 env40653 = env40654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env40653 == env40654) = true)

theorem identity40654 : scanCanonicalize (H12AffineFastState.compose env40654 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound40654 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40655 : List Nat := [2,4,8,16,32,64,66,68,74,4,42,80,25,80,1,115,0,48,85,0,81,10,16,98,3,17,123,81,81,26,21,16,69,65,0,27]

theorem envBound40655 : H12AffineFastState.Bounded env40655 := by
  intro p hp
  have h : env40655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40654_40655 : H12AffineEnvironment.transform 6 66 env40654 = env40655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env40654 == env40655) = true)

theorem identity40655 : scanCanonicalize (H12AffineFastState.compose env40655 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40655 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env40656 : List Nat := [2,4,4,16,32,64,66,68,70,4,38,80,21,80,1,115,0,48,85,0,81,6,16,98,3,17,119,81,81,22,21,16,69,65,0,23]

theorem envBound40656 : H12AffineFastState.Bounded env40656 := by
  intro p hp
  have h : env40656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40655_40656 : H12AffineEnvironment.transform 2 4 env40655 = env40656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40655 == env40656) = true)

theorem identity40656 : scanCanonicalize (H12AffineFastState.compose env40656 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40656 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env40657 : List Nat := [2,4,4,16,17,64,66,68,70,4,23,80,21,80,1,66,0,1,85,0,81,6,16,83,3,17,70,81,81,22,21,16,69,65,0,23]

theorem envBound40657 : H12AffineFastState.Bounded env40657 := by
  intro p hp
  have h : env40657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40656_40657 : H12AffineEnvironment.transform 4 17 env40656 = env40657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40656 == env40657) = true)

def env40658 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74031,65665,273,8541,81,397,74046,65552,8409,74046,318,74110,80,75867,8204,8201,257,74094,1,592]

theorem envBound40658 : H12AffineFastState.Bounded env40658 := by
  intro p hp
  have h : env40658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40648_40658 : H12AffineEnvironment.transform 9 321 env40648 = env40658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40648 == env40658) = true)

theorem identity40658 : scanCanonicalize (H12AffineFastState.compose env40658 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound40658 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env40659 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,80,8192,81,8264,65536,73787,65665,5,8265,81,153,73770,65552,8409,73770,42,73834,80,75867,8204,8201,21,73850,1,592]

theorem envBound40659 : H12AffineFastState.Bounded env40659 := by
  intro p hp
  have h : env40659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40658_40659 : H12AffineEnvironment.transform 7 20 env40658 = env40659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env40658 == env40659) = true)

def env40660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4097,5276,74047,66897,13769,78895,328958,74814,1297,81227,8205,8200,257,74799,1344,5952]

theorem envBound40660 : H12AffineFastState.Bounded env40660 := by
  intro p hp
  have h : env40660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40557_40660 : H12AffineEnvironment.transform 13 1297 env40557 = env40660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40557 == env40660) = true)

def env40661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4097,5276,74047,66897,13769,78895,1150,74814,1297,81227,8205,8200,257,74799,1344,5952]

theorem envBound40661 : H12AffineFastState.Bounded env40661 := by
  intro p hp
  have h : env40661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40660_40661 : H12AffineEnvironment.transform 17 65664 env40660 = env40661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40660 == env40661) = true)

theorem identity40661 : scanCanonicalize (H12AffineFastState.compose env40661 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound40661 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,65536,69943,65664,4416,5125,4097,5276,70758,66897,144,65910,1150,69991,1297,67602,5460,5457,257,70006,1344,5952]

theorem envBound40662 : H12AffineFastState.Bounded env40662 := by
  intro p hp
  have h : env40662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40661_40662 : H12AffineEnvironment.transform 12 5465 env40661 = env40662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env40661 == env40662) = true)

def env40663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1297,528,65536,67363,65664,1876,529,1557,648,66162,66897,144,65910,1150,67443,1297,67602,832,837,257,67426,1344,340]

theorem envBound40663 : H12AffineFastState.Bounded env40663 := by
  intro p hp
  have h : env40663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40662_40663 : H12AffineEnvironment.transform 11 1556 env40662 = env40663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env40662 == env40663) = true)

def env40664 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,65536,66163,65664,516,529,837,648,66162,65537,144,65910,302,66083,65,67602,832,837,257,66098,16,340]

theorem envBound40664 : H12AffineFastState.Bounded env40664 := by
  intro p hp
  have h : env40664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40663_40664 : H12AffineEnvironment.transform 9 336 env40663 = env40664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env40663 == env40664) = true)

theorem identity40664 : scanCanonicalize (H12AffineFastState.compose env40664 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 85) := by decide +kernel

theorem selectedBound40664 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40665 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,85,550,213,516,529,837,648,551,84,144,291,302,630,65,2119,832,837,257,615,16,340]

theorem envBound40665 : H12AffineFastState.Bounded env40665 := by
  intro p hp
  have h : env40665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40664_40665 : H12AffineEnvironment.transform 15 85 env40664 = env40665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 85 env40664 == env40665) = true)

def env40666 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,80,89,65,260,85,306,213,272,261,81,412,307,84,144,291,302,354,65,2119,84,81,257,371,16,340]

theorem envBound40666 : H12AffineFastState.Bounded env40666 := by
  intro p hp
  have h : env40666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40665_40666 : H12AffineEnvironment.transform 8 276 env40665 = env40666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env40665 == env40666) = true)

theorem identity40666 : scanCanonicalize (H12AffineFastState.compose env40666 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound40666 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40667 : List Nat := [2,4,8,16,32,64,128,69,81,21,2048,80,89,65,65,85,119,213,85,64,81,217,118,84,144,102,107,39,65,2119,84,81,68,54,16,17]

theorem envBound40667 : H12AffineFastState.Bounded env40667 := by
  intro p hp
  have h : env40667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40666_40667 : H12AffineEnvironment.transform 7 69 env40666 = env40667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env40666 == env40667) = true)

theorem identity40667 : scanCanonicalize (H12AffineFastState.compose env40667 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound40667 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env40668 : List Nat := [2,4,8,16,32,64,128,69,81,21,28,80,89,65,65,85,119,213,85,64,81,217,118,84,144,102,107,39,65,91,84,81,68,54,16,17]

theorem envBound40668 : H12AffineFastState.Bounded env40668 := by
  intro p hp
  have h : env40668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40667_40668 : H12AffineEnvironment.transform 10 28 env40667 = env40668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env40667 == env40668) = true)

theorem identity40668 : scanCanonicalize (H12AffineFastState.compose env40668 (packedSelected [0,1,2,3,4,7,9,10,12,13] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound40668 : packedSelected [0,1,2,3,4,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env40669 : List Nat := [2,4,8,7,32,64,128,69,70,2,11,71,78,65,65,66,96,194,66,64,70,206,97,67,135,102,107,39,65,76,67,70,68,33,7,6]

theorem envBound40669 : H12AffineFastState.Bounded env40669 := by
  intro p hp
  have h : env40669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40668_40669 : H12AffineEnvironment.transform 3 7 env40668 = env40669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env40668 == env40669) = true)

theorem identity40669 : scanCanonicalize (H12AffineFastState.compose env40669 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound40669 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40670 : List Nat := [2,4,8,7,32,44,128,41,42,2,11,43,34,45,45,46,12,174,46,44,42,162,13,47,135,10,7,39,45,32,47,42,40,33,7,6]

theorem envBound40670 : H12AffineFastState.Bounded env40670 := by
  intro p hp
  have h : env40670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40669_40670 : H12AffineEnvironment.transform 5 44 env40669 = env40670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env40669 == env40670) = true)

theorem identity40670 : scanCanonicalize (H12AffineFastState.compose env40670 (packedSelected [1,3,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40670 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env40671 : List Nat := [2,2,8,1,32,42,128,41,42,2,11,43,34,43,43,40,10,168,40,42,42,162,11,41,129,10,1,33,43,32,41,42,40,33,1,0]

theorem envBound40671 : H12AffineFastState.Bounded env40671 := by
  intro p hp
  have h : env40671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40670_40671 : H12AffineEnvironment.transform 1 2 env40670 = env40671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40670 == env40671) = true)

theorem identity40671 : scanCanonicalize (H12AffineFastState.compose env40671 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40671 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env40672 : List Nat := [2,2,3,1,32,33,128,34,33,2,0,32,34,32,32,35,1,163,35,33,33,162,0,34,129,1,1,33,32,32,34,33,35,33,1,0]

theorem envBound40672 : H12AffineFastState.Bounded env40672 := by
  intro p hp
  have h : env40672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40671_40672 : H12AffineEnvironment.transform 2 3 env40671 = env40672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40671 == env40672) = true)

theorem identity40672 : scanCanonicalize (H12AffineFastState.compose env40672 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound40672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40673 : List Nat := [2,2,3,1,32,33,3,34,33,2,0,32,34,32,32,35,1,32,35,33,33,33,0,34,2,1,1,33,32,32,34,33,35,33,1,0]

theorem envBound40673 : H12AffineFastState.Bounded env40673 := by
  intro p hp
  have h : env40673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40672_40673 : H12AffineEnvironment.transform 6 3 env40672 = env40673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env40672 == env40673) = true)

def env40674 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,81,88,65,261,85,307,213,273,260,80,413,306,84,144,291,302,355,65,2119,85,80,257,370,16,340]

theorem envBound40674 : H12AffineFastState.Bounded env40674 := by
  intro p hp
  have h : env40674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40665_40674 : H12AffineEnvironment.transform 8 277 env40665 = env40674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env40665 == env40674) = true)

theorem identity40674 : scanCanonicalize (H12AffineFastState.compose env40674 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40674 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40675 : List Nat := [2,4,8,16,32,64,128,5,16,85,2048,81,88,65,0,85,54,213,20,1,80,152,55,84,144,38,43,102,65,2119,85,80,4,119,16,81]

theorem envBound40675 : H12AffineFastState.Bounded env40675 := by
  intro p hp
  have h : env40675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40674_40675 : H12AffineEnvironment.transform 7 5 env40674 = env40675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40674 == env40675) = true)

theorem identity40675 : scanCanonicalize (H12AffineFastState.compose env40675 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40675 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40676 : List Nat := [2,4,8,16,32,17,128,5,16,4,2048,0,9,16,0,4,54,132,20,1,1,152,55,5,144,38,43,55,16,2070,4,1,4,38,16,0]

theorem envBound40676 : H12AffineFastState.Bounded env40676 := by
  intro p hp
  have h : env40676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40675_40676 : H12AffineEnvironment.transform 5 17 env40675 = env40676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40675 == env40676) = true)

theorem identity40676 : scanCanonicalize (H12AffineFastState.compose env40676 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40676 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env40677 : List Nat := [2,4,8,16,1,17,128,5,16,4,2048,0,9,16,0,4,23,132,20,1,1,152,22,5,144,7,10,22,16,2070,4,1,4,7,16,0]

theorem envBound40677 : H12AffineFastState.Bounded env40677 := by
  intro p hp
  have h : env40677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40676_40677 : H12AffineEnvironment.transform 4 1 env40676 = env40677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40676 == env40677) = true)

theorem identity40677 : scanCanonicalize (H12AffineFastState.compose env40677 (packedSelected [0,1,2,3,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound40677 : packedSelected [0,1,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40678 : List Nat := [2,4,8,16,1,17,128,5,16,4,147,0,9,16,0,4,23,132,20,1,1,152,22,5,144,7,10,22,16,133,4,1,4,7,16,0]

theorem envBound40678 : H12AffineFastState.Bounded env40678 := by
  intro p hp
  have h : env40678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40677_40678 : H12AffineEnvironment.transform 10 147 env40677 = env40678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env40677 == env40678) = true)

theorem identity40678 : scanCanonicalize (H12AffineFastState.compose env40678 (packedSelected [0,1,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound40678 : packedSelected [0,1,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40679 : List Nat := [2,4,8,16,1,17,31,5,16,4,12,0,9,16,0,4,23,27,20,1,1,7,22,5,15,7,10,22,16,26,4,1,4,7,16,0]

theorem envBound40679 : H12AffineFastState.Bounded env40679 := by
  intro p hp
  have h : env40679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40678_40679 : H12AffineEnvironment.transform 6 31 env40678 = env40679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env40678 == env40679) = true)

theorem identity40679 : scanCanonicalize (H12AffineFastState.compose env40679 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40679 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40680 : List Nat := [2,4,3,16,1,17,20,5,16,4,7,0,2,16,0,4,23,16,20,1,1,7,22,5,4,7,1,22,16,17,4,1,4,7,16,0]

theorem envBound40680 : H12AffineFastState.Bounded env40680 := by
  intro p hp
  have h : env40680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40679_40680 : H12AffineEnvironment.transform 2 3 env40679 = env40680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40679 == env40680) = true)

theorem identity40680 : scanCanonicalize (H12AffineFastState.compose env40680 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40680 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40681 : List Nat := [2,2,3,16,1,17,18,3,16,2,1,0,2,16,0,2,17,16,18,1,1,1,16,3,2,1,1,16,16,17,2,1,2,1,16,0]

theorem envBound40681 : H12AffineFastState.Bounded env40681 := by
  intro p hp
  have h : env40681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40680_40681 : H12AffineEnvironment.transform 1 2 env40680 = env40681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40680 == env40681) = true)

theorem identity40681 : scanCanonicalize (H12AffineFastState.compose env40681 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40681 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40682 : List Nat := [2,2,3,0,1,1,2,3,0,2,1,0,2,0,0,2,1,0,2,1,1,1,0,3,2,1,1,0,0,1,2,1,2,1,0,0]

theorem envBound40682 : H12AffineFastState.Bounded env40682 := by
  intro p hp
  have h : env40682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40681_40682 : H12AffineEnvironment.transform 3 0 env40681 = env40682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40681 == env40682) = true)

def env40683 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,65536,66162,65664,517,529,836,648,66162,65536,144,65910,303,66082,64,67602,832,837,257,66099,17,340]

theorem envBound40683 : H12AffineFastState.Bounded env40683 := by
  intro p hp
  have h : env40683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40663_40683 : H12AffineEnvironment.transform 9 337 env40663 = env40683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env40663 == env40683) = true)

theorem identity40683 : scanCanonicalize (H12AffineFastState.compose env40683 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 833) := by decide +kernel

theorem selectedBound40683 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40684 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,833,307,961,517,529,836,648,307,833,144,567,303,355,64,2899,832,837,257,370,17,340]

theorem envBound40684 : H12AffineFastState.Bounded env40684 := by
  intro p hp
  have h : env40684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40683_40684 : H12AffineEnvironment.transform 15 833 env40683 = env40684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 833 env40683 == env40684) = true)

def env40685 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,81,89,64,260,85,307,213,273,261,80,412,307,85,144,291,303,355,64,2119,84,81,257,370,17,340]

theorem envBound40685 : H12AffineFastState.Bounded env40685 := by
  intro p hp
  have h : env40685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40684_40685 : H12AffineEnvironment.transform 8 276 env40684 = env40685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env40684 == env40685) = true)

theorem identity40685 : scanCanonicalize (H12AffineFastState.compose env40685 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40685 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40686 : List Nat := [2,4,8,16,32,64,128,4,16,85,2048,81,89,64,0,85,55,213,21,1,80,152,55,85,144,39,43,103,64,2119,84,81,5,118,17,80]

theorem envBound40686 : H12AffineFastState.Bounded env40686 := by
  intro p hp
  have h : env40686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40685_40686 : H12AffineEnvironment.transform 7 4 env40685 = env40686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40685 == env40686) = true)

theorem identity40686 : scanCanonicalize (H12AffineFastState.compose env40686 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40686 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40687 : List Nat := [2,4,8,16,32,17,128,4,16,4,2048,0,8,17,0,4,55,132,21,1,1,152,55,4,144,39,43,54,17,2070,5,0,5,39,17,1]

theorem envBound40687 : H12AffineFastState.Bounded env40687 := by
  intro p hp
  have h : env40687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40686_40687 : H12AffineEnvironment.transform 5 17 env40686 = env40687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40686 == env40687) = true)

theorem identity40687 : scanCanonicalize (H12AffineFastState.compose env40687 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40687 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env40688 : List Nat := [2,3,8,16,32,17,128,3,16,3,2048,0,8,17,0,3,48,131,18,1,1,152,48,3,144,32,43,49,17,2065,2,0,2,32,17,1]

theorem envBound40688 : H12AffineFastState.Bounded env40688 := by
  intro p hp
  have h : env40688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40687_40688 : H12AffineEnvironment.transform 1 3 env40687 = env40688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40687 == env40688) = true)

theorem identity40688 : scanCanonicalize (H12AffineFastState.compose env40688 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound40688 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40689 : List Nat := [2,3,8,16,32,17,128,3,16,3,184,0,8,17,0,3,48,131,18,1,1,152,48,3,144,32,43,49,17,169,2,0,2,32,17,1]

theorem envBound40689 : H12AffineFastState.Bounded env40689 := by
  intro p hp
  have h : env40689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40688_40689 : H12AffineEnvironment.transform 10 184 env40688 = env40689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env40688 == env40689) = true)

theorem identity40689 : scanCanonicalize (H12AffineFastState.compose env40689 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound40689 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40690 : List Nat := [2,3,8,16,32,17,24,3,16,3,32,0,8,17,0,3,48,27,18,1,1,0,48,3,8,32,43,49,17,49,2,0,2,32,17,1]

theorem envBound40690 : H12AffineFastState.Bounded env40690 := by
  intro p hp
  have h : env40690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40689_40690 : H12AffineEnvironment.transform 6 24 env40689 = env40690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env40689 == env40690) = true)

theorem identity40690 : scanCanonicalize (H12AffineFastState.compose env40690 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40691 : List Nat := [2,3,8,1,32,0,9,3,1,3,32,0,8,0,0,3,33,10,3,1,1,0,33,3,8,32,43,32,0,32,2,0,2,32,0,1]

theorem envBound40691 : H12AffineFastState.Bounded env40691 := by
  intro p hp
  have h : env40691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40690_40691 : H12AffineEnvironment.transform 3 1 env40690 = env40691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40690 == env40691) = true)

theorem identity40691 : scanCanonicalize (H12AffineFastState.compose env40691 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40691 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40692 : List Nat := [2,3,2,1,32,0,3,3,1,3,32,0,2,0,0,3,33,0,3,1,1,0,33,3,2,32,33,32,0,32,2,0,2,32,0,1]

theorem envBound40692 : H12AffineFastState.Bounded env40692 := by
  intro p hp
  have h : env40692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40691_40692 : H12AffineEnvironment.transform 2 2 env40691 = env40692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40691 == env40692) = true)

def env40693 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,80,88,64,261,84,307,212,272,260,81,413,307,84,144,290,303,355,64,2118,85,80,257,370,17,340]

theorem envBound40693 : H12AffineFastState.Bounded env40693 := by
  intro p hp
  have h : env40693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40684_40693 : H12AffineEnvironment.transform 8 277 env40684 = env40693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env40684 == env40693) = true)

theorem identity40693 : scanCanonicalize (H12AffineFastState.compose env40693 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound40693 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40694 : List Nat := [2,4,8,16,32,64,128,69,80,20,2048,80,88,64,64,84,118,212,85,65,81,216,118,84,144,103,106,38,64,2118,85,80,68,55,17,17]

theorem envBound40694 : H12AffineFastState.Bounded env40694 := by
  intro p hp
  have h : env40694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40693_40694 : H12AffineEnvironment.transform 7 69 env40693 = env40694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env40693 == env40694) = true)

theorem identity40694 : scanCanonicalize (H12AffineFastState.compose env40694 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound40694 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env40695 : List Nat := [2,4,8,16,32,64,128,69,80,20,122,80,88,64,64,84,118,212,85,65,81,216,118,84,144,103,106,38,64,60,85,80,68,55,17,17]

theorem envBound40695 : H12AffineFastState.Bounded env40695 := by
  intro p hp
  have h : env40695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40694_40695 : H12AffineEnvironment.transform 10 122 env40694 = env40695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env40694 == env40695) = true)

theorem identity40695 : scanCanonicalize (H12AffineFastState.compose env40695 (packedSelected [2,3,5,10,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound40695 : packedSelected [2,3,5,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env40696 : List Nat := [2,4,8,16,32,64,21,69,80,20,122,80,88,64,64,84,118,65,85,65,81,77,118,84,5,103,106,38,64,60,85,80,68,55,17,17]

theorem envBound40696 : H12AffineFastState.Bounded env40696 := by
  intro p hp
  have h : env40696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40695_40696 : H12AffineEnvironment.transform 6 21 env40695 = env40696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env40695 == env40696) = true)

theorem identity40696 : scanCanonicalize (H12AffineFastState.compose env40696 (packedSelected [2,3,4,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound40696 : packedSelected [2,3,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40697 : List Nat := [2,4,8,16,23,64,21,69,80,20,77,80,88,64,64,84,65,65,85,65,81,77,65,84,5,80,93,17,64,11,85,80,68,0,17,17]

theorem envBound40697 : H12AffineFastState.Bounded env40697 := by
  intro p hp
  have h : env40697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40696_40697 : H12AffineEnvironment.transform 4 23 env40696 = env40697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env40696 == env40697) = true)

theorem identity40697 : scanCanonicalize (H12AffineFastState.compose env40697 (packedSelected [0,1,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound40697 : packedSelected [0,1,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40698 : List Nat := [2,4,8,6,1,64,3,69,70,2,77,70,78,64,64,66,65,65,67,65,71,77,65,66,5,70,75,7,64,11,67,70,68,0,7,7]

theorem envBound40698 : H12AffineFastState.Bounded env40698 := by
  intro p hp
  have h : env40698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40697_40698 : H12AffineEnvironment.transform 3 6 env40697 = env40698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env40697 == env40698) = true)

def env40699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1297,529,65536,67362,65664,1877,528,1556,649,66163,66897,144,65910,1150,67442,1297,67602,833,836,257,67427,1344,341]

theorem envBound40699 : H12AffineFastState.Bounded env40699 := by
  intro p hp
  have h : env40699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40662_40699 : H12AffineEnvironment.transform 11 1557 env40662 = env40699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env40662 == env40699) = true)

def env40700 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,65536,66162,65664,517,528,836,649,66163,65537,144,65910,302,66082,65,67602,833,836,257,66099,16,341]

theorem envBound40700 : H12AffineFastState.Bounded env40700 := by
  intro p hp
  have h : env40700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40699_40700 : H12AffineEnvironment.transform 9 336 env40699 = env40700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env40699 == env40700) = true)

theorem identity40700 : scanCanonicalize (H12AffineFastState.compose env40700 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound40700 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40701 : List Nat := [2,4,8,16,32,64,128,256,54,336,2048,371,378,65,39,65536,65604,65664,51,38,370,191,65605,65537,144,65910,302,65556,65,67602,375,370,257,65541,16,341]

theorem envBound40701 : H12AffineFastState.Bounded env40701 := by
  intro p hp
  have h : env40701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40700_40701 : H12AffineEnvironment.transform 8 54 env40700 = env40701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env40700 == env40701) = true)

def env40702 : List Nat := [2,4,8,16,32,64,128,40,54,120,2048,91,82,65,39,65536,65604,65664,51,38,90,191,65605,65537,144,65630,6,65556,65,67602,95,90,41,65541,16,125]

theorem envBound40702 : H12AffineFastState.Bounded env40702 := by
  intro p hp
  have h : env40702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40701_40702 : H12AffineEnvironment.transform 7 40 env40701 = env40702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env40701 == env40702) = true)

theorem identity40702 : scanCanonicalize (H12AffineFastState.compose env40702 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound40702 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40703 : List Nat := [2,4,8,16,32,64,53,40,54,120,2048,91,82,65,39,65536,65604,65589,51,38,90,10,65605,65537,37,65630,6,65556,65,67602,95,90,41,65541,16,125]

theorem envBound40703 : H12AffineFastState.Bounded env40703 := by
  intro p hp
  have h : env40703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40702_40703 : H12AffineEnvironment.transform 6 53 env40702 = env40703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env40702 == env40703) = true)

theorem identity40703 : scanCanonicalize (H12AffineFastState.compose env40703 (packedSelected [0,1,2,4,7,9,10,13,15,17,18,19,21,23,32] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40703 : packedSelected [0,1,2,4,7,9,10,13,15,17,18,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env40704 : List Nat := [2,4,5,16,32,64,53,37,54,117,2048,86,82,65,39,65536,65604,65589,51,38,87,7,65605,65537,37,65619,6,65556,65,67602,82,87,36,65541,16,112]

theorem envBound40704 : H12AffineFastState.Bounded env40704 := by
  intro p hp
  have h : env40704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40703_40704 : H12AffineEnvironment.transform 2 5 env40703 = env40704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40703 == env40704) = true)

theorem identity40704 : scanCanonicalize (H12AffineFastState.compose env40704 (packedSelected [4,5,9,10,11,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 2130) := by decide +kernel

theorem selectedBound40704 : packedSelected [4,5,9,10,11,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40705 : List Nat := [2,4,5,16,32,64,53,37,54,117,2048,86,82,65,39,2130,2070,2151,51,38,87,7,2071,2131,37,2049,6,2118,65,64,82,87,36,2135,16,112]

theorem envBound40705 : H12AffineFastState.Bounded env40705 := by
  intro p hp
  have h : env40705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40704_40705 : H12AffineEnvironment.transform 15 2130 env40704 = env40705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2130 env40704 == env40705) = true)

theorem identity40705 : scanCanonicalize (H12AffineFastState.compose env40705 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound40705 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env40706 : List Nat := [2,4,5,16,32,64,53,37,54,117,39,86,82,65,39,117,49,64,51,38,87,7,48,116,37,38,6,97,65,64,82,87,36,112,16,112]

theorem envBound40706 : H12AffineFastState.Bounded env40706 := by
  intro p hp
  have h : env40706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40705_40706 : H12AffineEnvironment.transform 10 39 env40705 = env40706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env40705 == env40706) = true)

theorem identity40706 : scanCanonicalize (H12AffineFastState.compose env40706 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound40706 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env40707 : List Nat := [2,4,5,7,32,64,34,37,33,98,39,65,69,65,39,98,38,64,36,38,64,7,39,99,37,38,6,97,65,64,69,64,36,103,7,103]

theorem envBound40707 : H12AffineFastState.Bounded env40707 := by
  intro p hp
  have h : env40707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40706_40707 : H12AffineEnvironment.transform 3 7 env40706 = env40707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env40706 == env40707) = true)

theorem identity40707 : scanCanonicalize (H12AffineFastState.compose env40707 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40708 : List Nat := [2,4,5,7,1,64,3,4,0,67,6,65,69,65,6,67,7,64,5,7,64,7,6,66,4,7,6,64,65,64,69,64,5,70,7,70]

theorem envBound40708 : H12AffineFastState.Bounded env40708 := by
  intro p hp
  have h : env40708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40707_40708 : H12AffineEnvironment.transform 4 1 env40707 = env40708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40707 == env40708) = true)

theorem identity40708 : scanCanonicalize (H12AffineFastState.compose env40708 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound40708 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40709 : List Nat := [2,4,5,7,1,1,3,4,0,2,6,0,4,0,6,2,7,1,5,7,1,7,6,3,4,7,6,1,0,1,4,1,5,7,7,7]

theorem envBound40709 : H12AffineFastState.Bounded env40709 := by
  intro p hp
  have h : env40709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40708_40709 : H12AffineEnvironment.transform 5 1 env40708 = env40709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40708 == env40709) = true)

theorem identity40709 : scanCanonicalize (H12AffineFastState.compose env40709 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40710 : List Nat := [2,3,2,0,1,1,3,3,0,2,1,0,3,0,1,2,0,1,2,0,1,0,1,3,3,0,1,1,0,1,3,1,2,0,0,0]

theorem envBound40710 : H12AffineFastState.Bounded env40710 := by
  intro p hp
  have h : env40710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40709_40710 : H12AffineEnvironment.transform 1 3 env40709 = env40710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40709 == env40710) = true)

def env40711 : List Nat := [2,4,8,16,32,64,128,41,54,121,2048,90,83,65,39,65536,65604,65664,51,38,91,191,65605,65537,144,65631,7,65556,65,67602,94,91,40,65541,16,124]

theorem envBound40711 : H12AffineFastState.Bounded env40711 := by
  intro p hp
  have h : env40711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40701_40711 : H12AffineEnvironment.transform 7 41 env40701 = env40711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env40701 == env40711) = true)

theorem identity40711 : scanCanonicalize (H12AffineFastState.compose env40711 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound40711 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40712 : List Nat := [2,4,8,16,32,64,63,41,54,121,2048,90,83,65,39,65536,65604,65599,51,38,91,0,65605,65537,47,65631,7,65556,65,67602,94,91,40,65541,16,124]

theorem envBound40712 : H12AffineFastState.Bounded env40712 := by
  intro p hp
  have h : env40712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40711_40712 : H12AffineEnvironment.transform 6 63 env40711 = env40712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env40711 == env40712) = true)

theorem identity40712 : scanCanonicalize (H12AffineFastState.compose env40712 (packedSelected [0,2,5,9,10,19,21,32] rootPS)) = affineNative (2^(15+1) ^^^ 2072) := by decide +kernel

theorem selectedBound40712 : packedSelected [0,2,5,9,10,19,21,32] rootPS < 2^1333 := by decide +kernel

def env40713 : List Nat := [2,4,8,16,32,64,63,41,54,121,2048,90,83,65,39,2072,2140,2087,51,38,91,0,2141,2073,47,2119,7,2060,65,10,94,91,40,2077,16,124]

theorem envBound40713 : H12AffineFastState.Bounded env40713 := by
  intro p hp
  have h : env40713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40712_40713 : H12AffineEnvironment.transform 15 2072 env40712 = env40713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2072 env40712 == env40713) = true)

theorem identity40713 : scanCanonicalize (H12AffineFastState.compose env40713 (packedSelected [1,7,9,10,11,13,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40713 : packedSelected [1,7,9,10,11,13,15,18] rootPS < 2^1333 := by decide +kernel

def env40714 : List Nat := [2,4,8,16,17,64,14,24,7,72,2048,90,83,65,22,2072,2140,2070,2,23,91,0,2141,2073,30,2119,7,2060,65,10,94,91,25,2077,16,77]

theorem envBound40714 : H12AffineFastState.Bounded env40714 := by
  intro p hp
  have h : env40714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40713_40714 : H12AffineEnvironment.transform 4 17 env40713 = env40714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40713 == env40714) = true)

theorem identity40714 : scanCanonicalize (H12AffineFastState.compose env40714 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound40714 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env40715 : List Nat := [2,4,8,16,17,6,14,24,7,14,2048,28,21,7,22,2072,2074,2070,2,23,29,0,2075,2073,30,2049,7,2060,7,10,24,29,25,2077,16,11]

theorem envBound40715 : H12AffineFastState.Bounded env40715 := by
  intro p hp
  have h : env40715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40714_40715 : H12AffineEnvironment.transform 5 6 env40714 = env40715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env40714 == env40715) = true)

theorem identity40715 : scanCanonicalize (H12AffineFastState.compose env40715 (packedSelected [0,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40715 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env40716 : List Nat := [2,4,5,16,17,6,3,21,7,3,2048,17,21,7,22,2069,2071,2070,2,23,16,0,2070,2068,19,2049,7,2049,7,7,21,16,20,2064,16,6]

theorem envBound40716 : H12AffineFastState.Bounded env40716 := by
  intro p hp
  have h : env40716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40715_40716 : H12AffineEnvironment.transform 2 5 env40715 = env40716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40715 == env40716) = true)

theorem identity40716 : scanCanonicalize (H12AffineFastState.compose env40716 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound40716 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40717 : List Nat := [2,4,5,16,17,6,3,21,7,3,7,17,21,7,22,18,16,17,2,23,16,0,17,19,19,6,7,6,7,7,21,16,20,23,16,6]

theorem envBound40717 : H12AffineFastState.Bounded env40717 := by
  intro p hp
  have h : env40717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40716_40717 : H12AffineEnvironment.transform 10 7 env40716 = env40717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env40716 == env40717) = true)

theorem identity40717 : scanCanonicalize (H12AffineFastState.compose env40717 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound40717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40718 : List Nat := [2,4,5,5,4,6,3,0,7,3,7,4,0,7,3,7,5,4,2,2,5,0,4,6,6,6,7,6,7,7,0,5,1,2,5,6]

theorem envBound40718 : H12AffineFastState.Bounded env40718 := by
  intro p hp
  have h : env40718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40717_40718 : H12AffineEnvironment.transform 3 5 env40717 = env40718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env40717 == env40718) = true)

theorem identity40718 : scanCanonicalize (H12AffineFastState.compose env40718 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40718 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env40719 : List Nat := [2,0,1,1,0,2,3,0,3,3,3,0,0,3,3,3,1,0,2,2,1,0,0,2,2,2,3,2,3,3,0,1,1,2,1,2]

theorem envBound40719 : H12AffineFastState.Bounded env40719 := by
  intro p hp
  have h : env40719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40718_40719 : H12AffineEnvironment.transform 1 0 env40718 = env40719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40718 == env40719) = true)

def env40720 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,65536,66163,65664,516,528,837,649,66163,65536,144,65910,303,66083,64,67602,833,836,257,66098,17,341]

theorem envBound40720 : H12AffineFastState.Bounded env40720 := by
  intro p hp
  have h : env40720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40699_40720 : H12AffineEnvironment.transform 9 337 env40699 = env40720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env40699 == env40720) = true)

theorem identity40720 : scanCanonicalize (H12AffineFastState.compose env40720 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound40720 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40721 : List Nat := [2,4,8,16,32,64,128,35,512,114,2048,615,623,64,529,65536,66163,65664,516,528,614,649,66163,65536,144,65621,12,66083,64,67602,610,615,34,66098,17,118]

theorem envBound40721 : H12AffineFastState.Bounded env40721 := by
  intro p hp
  have h : env40721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40720_40721 : H12AffineEnvironment.transform 7 35 env40720 = env40721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env40720 == env40721) = true)

def env40722 : List Nat := [2,4,8,16,32,64,128,35,60,114,2048,91,83,64,45,65536,65615,65664,56,44,90,181,65615,65536,144,65621,12,65567,64,67602,94,91,34,65550,17,118]

theorem envBound40722 : H12AffineFastState.Bounded env40722 := by
  intro p hp
  have h : env40722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40721_40722 : H12AffineEnvironment.transform 8 60 env40721 = env40722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env40721 == env40722) = true)

theorem identity40722 : scanCanonicalize (H12AffineFastState.compose env40722 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 234) := by decide +kernel

theorem selectedBound40722 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40723 : List Nat := [2,4,8,16,32,64,128,35,60,114,2048,91,83,64,45,234,165,106,56,44,90,181,165,234,144,191,12,245,64,2296,94,91,34,228,17,118]

theorem envBound40723 : H12AffineFastState.Bounded env40723 := by
  intro p hp
  have h : env40723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40722_40723 : H12AffineEnvironment.transform 15 234 env40722 = env40723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 234 env40722 == env40723) = true)

theorem identity40723 : scanCanonicalize (H12AffineFastState.compose env40723 (packedSelected [0,3,4,5,9,13,17,18,20,21,27] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound40723 : packedSelected [0,3,4,5,9,13,17,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env40724 : List Nat := [2,4,8,16,32,64,128,35,60,114,125,91,83,64,45,234,165,106,56,44,90,181,165,234,144,191,12,245,64,133,94,91,34,228,17,118]

theorem envBound40724 : H12AffineFastState.Bounded env40724 := by
  intro p hp
  have h : env40724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40723_40724 : H12AffineEnvironment.transform 10 125 env40723 = env40724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env40723 == env40724) = true)

theorem identity40724 : scanCanonicalize (H12AffineFastState.compose env40724 (packedSelected [1,2,3,7,8,9,11,13,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound40724 : packedSelected [1,2,3,7,8,9,11,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env40725 : List Nat := [2,4,8,16,32,27,128,35,60,41,38,0,8,27,45,177,165,49,56,44,1,181,165,177,144,191,12,174,27,133,5,0,34,191,17,45]

theorem envBound40725 : H12AffineFastState.Bounded env40725 := by
  intro p hp
  have h : env40725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40724_40725 : H12AffineEnvironment.transform 5 27 env40724 = env40725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env40724 == env40725) = true)

theorem identity40725 : scanCanonicalize (H12AffineFastState.compose env40725 (packedSelected [0,1,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40725 : packedSelected [0,1,3,5,9] rootPS < 2^1333 := by decide +kernel

def env40726 : List Nat := [2,4,8,16,28,27,128,31,0,21,26,0,8,27,17,141,153,13,4,16,1,137,153,141,144,131,12,146,27,133,5,0,30,131,17,17]

theorem envBound40726 : H12AffineFastState.Bounded env40726 := by
  intro p hp
  have h : env40726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40725_40726 : H12AffineEnvironment.transform 4 28 env40725 = env40726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40725 == env40726) = true)

theorem identity40726 : scanCanonicalize (H12AffineFastState.compose env40726 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40726 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env40727 : List Nat := [2,2,8,16,26,27,128,25,0,19,26,0,8,27,17,139,153,11,2,16,1,137,153,139,144,131,10,146,27,131,3,0,24,131,17,17]

theorem envBound40727 : H12AffineFastState.Bounded env40727 := by
  intro p hp
  have h : env40727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40726_40727 : H12AffineEnvironment.transform 1 2 env40726 = env40727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40726 == env40727) = true)

theorem identity40727 : scanCanonicalize (H12AffineFastState.compose env40727 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40727 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40728 : List Nat := [2,2,8,10,0,1,128,3,0,9,0,0,8,1,11,139,131,11,2,10,1,137,131,139,138,131,10,136,1,131,3,0,2,131,11,11]

theorem envBound40728 : H12AffineFastState.Bounded env40728 := by
  intro p hp
  have h : env40728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40727_40728 : H12AffineEnvironment.transform 3 10 env40727 = env40728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40727 == env40728) = true)

theorem identity40728 : scanCanonicalize (H12AffineFastState.compose env40728 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40729 : List Nat := [2,2,2,0,0,1,128,3,0,3,0,0,2,1,1,129,131,1,2,0,1,131,131,129,128,131,0,130,1,131,3,0,2,131,1,1]

theorem envBound40729 : H12AffineFastState.Bounded env40729 := by
  intro p hp
  have h : env40729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40728_40729 : H12AffineEnvironment.transform 2 2 env40728 = env40729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40728 == env40729) = true)

theorem identity40729 : scanCanonicalize (H12AffineFastState.compose env40729 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40730 : List Nat := [1,1,1,0,0,1,128,0,0,0,0,0,1,1,1,129,128,1,1,0,1,128,128,129,128,128,0,129,1,128,0,0,1,128,1,1]

theorem envBound40730 : H12AffineFastState.Bounded env40730 := by
  intro p hp
  have h : env40730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40729_40730 : H12AffineEnvironment.transform 0 1 env40729 = env40730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40729 == env40730) = true)

def env40731 : List Nat := [2,4,8,16,32,64,128,35,61,114,2048,90,82,64,44,65536,65614,65664,57,45,91,180,65614,65536,144,65621,12,65566,64,67602,95,90,34,65551,17,118]

theorem envBound40731 : H12AffineFastState.Bounded env40731 := by
  intro p hp
  have h : env40731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40721_40731 : H12AffineEnvironment.transform 8 61 env40721 = env40731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env40721 == env40731) = true)

theorem identity40731 : scanCanonicalize (H12AffineFastState.compose env40731 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 225) := by decide +kernel

theorem selectedBound40731 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env40732 : List Nat := [2,4,8,16,32,64,128,35,61,114,2048,90,82,64,44,225,175,97,57,45,91,180,175,225,144,180,12,255,64,2291,95,90,34,238,17,118]

theorem envBound40732 : H12AffineFastState.Bounded env40732 := by
  intro p hp
  have h : env40732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40731_40732 : H12AffineEnvironment.transform 15 225 env40731 = env40732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 225 env40731 == env40732) = true)

theorem identity40732 : scanCanonicalize (H12AffineFastState.compose env40732 (packedSelected [3,4,8,9,10,12,15,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound40732 : packedSelected [3,4,8,9,10,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env40733 : List Nat := [2,4,8,16,32,64,128,35,61,114,143,90,82,64,44,225,175,97,57,45,91,180,175,225,144,180,12,255,64,124,95,90,34,238,17,118]

theorem envBound40733 : H12AffineFastState.Bounded env40733 := by
  intro p hp
  have h : env40733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40732_40733 : H12AffineEnvironment.transform 10 143 env40732 = env40733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env40732 == env40733) = true)

theorem identity40733 : scanCanonicalize (H12AffineFastState.compose env40733 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound40733 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env40734 : List Nat := [2,4,8,16,32,64,14,35,61,114,1,90,82,64,44,111,33,97,57,45,91,58,33,111,30,58,12,113,64,124,95,90,34,96,17,118]

theorem envBound40734 : H12AffineFastState.Bounded env40734 := by
  intro p hp
  have h : env40734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40733_40734 : H12AffineEnvironment.transform 6 14 env40733 = env40734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env40733 == env40734) = true)

theorem identity40734 : scanCanonicalize (H12AffineFastState.compose env40734 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40734 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env40735 : List Nat := [2,4,8,10,32,64,14,35,39,104,1,64,72,64,44,111,33,97,35,45,65,32,33,111,4,32,12,107,64,102,69,64,34,96,11,108]

theorem envBound40735 : H12AffineFastState.Bounded env40735 := by
  intro p hp
  have h : env40735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40734_40735 : H12AffineEnvironment.transform 3 10 env40734 = env40735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40734 == env40735) = true)

end H12CloudChart2