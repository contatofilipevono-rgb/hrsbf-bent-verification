import H12CloudChart2Data214

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound54179 : H12AffineFastState.Bounded env54179 := by
  intro p hp
  have h : env54179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54178_54179 : H12AffineEnvironment.transform 0 0 env54178 = env54179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54178 == env54179) = true)

def env54180 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,80,477,74047,65600,9624,74878,366,74815,1297,77082,8204,74798,256,8200,1344,1092]

theorem envBound54180 : H12AffineFastState.Bounded env54180 := by
  intro p hp
  have h : env54180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54142_54180 : H12AffineEnvironment.transform 8 341 env54142 = env54180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env54142 == env54180) = true)

def env54181 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9229,65536,74799,65664,272,9228,16,413,74047,65536,9624,74814,302,74815,1297,77082,8204,74798,256,8200,1280,1028]

theorem envBound54181 : H12AffineFastState.Bounded env54181 := by
  intro p hp
  have h : env54181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54180_54181 : H12AffineEnvironment.transform 5 0 env54180 = env54181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54180 == env54181) = true)

theorem identity54181 : scanCanonicalize (H12AffineFastState.compose env54181 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8456) := by decide +kernel

theorem selectedBound54181 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54182 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9229,8456,1319,8584,272,9228,16,413,55,8456,9624,1334,302,1335,1297,3090,8204,1318,256,8200,1280,1028]

theorem envBound54182 : H12AffineFastState.Bounded env54182 := by
  intro p hp
  have h : env54182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54181_54182 : H12AffineEnvironment.transform 15 8456 env54181 = env54182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env54181 == env54182) = true)

def env54183 : List Nat := [2,4,8,16,0,0,128,256,277,1024,2048,17,8192,1297,9229,8456,1287,8584,272,9228,16,413,23,8456,9624,1302,270,1303,1297,3090,8204,1286,256,8200,1280,1028]

theorem envBound54183 : H12AffineFastState.Bounded env54183 := by
  intro p hp
  have h : env54183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54182_54183 : H12AffineEnvironment.transform 4 0 env54182 = env54183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54182 == env54183) = true)

theorem identity54183 : scanCanonicalize (H12AffineFastState.compose env54183 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54183 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env54184 : List Nat := [2,4,8,16,0,0,128,5,16,1024,2048,17,8192,1044,9229,8205,1026,8333,21,9228,16,152,23,8205,9373,1043,11,1042,1044,3090,8204,1027,5,8200,1029,1028]

theorem envBound54184 : H12AffineFastState.Bounded env54184 := by
  intro p hp
  have h : env54184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54183_54184 : H12AffineEnvironment.transform 7 5 env54183 = env54184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54183 == env54184) = true)

theorem identity54184 : scanCanonicalize (H12AffineFastState.compose env54184 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54184 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54185 : List Nat := [2,4,8,1,0,0,128,5,1,1024,2048,0,8192,1029,9229,8205,1026,8333,4,9228,1,137,6,8205,9356,1026,11,1027,1029,3075,8204,1027,5,8200,1029,1028]

theorem envBound54185 : H12AffineFastState.Bounded env54185 := by
  intro p hp
  have h : env54185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54184_54185 : H12AffineEnvironment.transform 3 1 env54184 = env54185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54184 == env54185) = true)

theorem identity54185 : scanCanonicalize (H12AffineFastState.compose env54185 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54185 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54186 : List Nat := [2,4,8,1,0,0,128,5,1,1024,0,0,8192,1029,9229,8205,1026,8333,4,9228,1,137,6,8205,9356,1026,11,1027,1029,1027,8204,1027,5,8200,1029,1028]

theorem envBound54186 : H12AffineFastState.Bounded env54186 := by
  intro p hp
  have h : env54186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54185_54186 : H12AffineEnvironment.transform 10 0 env54185 = env54186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54185 == env54186) = true)

theorem identity54186 : scanCanonicalize (H12AffineFastState.compose env54186 (packedSelected [0,1,2,3,4,5,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound54186 : packedSelected [0,1,2,3,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env54187 : List Nat := [2,4,8,1,0,0,128,5,1,1024,0,0,1031,1029,10,1034,1026,1162,4,11,1,137,6,1034,139,1026,11,1027,1029,1027,1035,1027,5,1039,1029,1028]

theorem envBound54187 : H12AffineFastState.Bounded env54187 := by
  intro p hp
  have h : env54187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54186_54187 : H12AffineEnvironment.transform 12 1031 env54186 = env54187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env54186 == env54187) = true)

theorem identity54187 : scanCanonicalize (H12AffineFastState.compose env54187 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound54187 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env54188 : List Nat := [2,4,8,1,0,0,128,5,1,15,0,0,8,10,10,5,13,133,4,11,1,137,6,5,139,13,11,12,10,12,4,12,5,0,10,11]

theorem envBound54188 : H12AffineFastState.Bounded env54188 := by
  intro p hp
  have h : env54188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54187_54188 : H12AffineEnvironment.transform 9 15 env54187 = env54188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env54187 == env54188) = true)

def env54189 : List Nat := [2,4,8,16,1,0,128,256,277,1024,2048,17,8192,1297,9229,8456,1286,8584,272,9228,16,413,22,8456,9624,1303,271,1302,1297,3090,8204,1287,256,8200,1280,1028]

theorem envBound54189 : H12AffineFastState.Bounded env54189 := by
  intro p hp
  have h : env54189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54182_54189 : H12AffineEnvironment.transform 4 1 env54182 = env54189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54182 == env54189) = true)

theorem identity54189 : scanCanonicalize (H12AffineFastState.compose env54189 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound54189 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env54190 : List Nat := [2,4,8,16,1,0,128,3,22,1024,2048,17,8192,1042,9229,8203,1029,8331,19,9228,16,158,22,8203,9371,1044,12,1045,1042,3090,8204,1028,3,8200,1027,1028]

theorem envBound54190 : H12AffineFastState.Bounded env54190 := by
  intro p hp
  have h : env54190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54189_54190 : H12AffineEnvironment.transform 7 3 env54189 = env54190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env54189 == env54190) = true)

theorem identity54190 : scanCanonicalize (H12AffineFastState.compose env54190 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound54190 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54191 : List Nat := [2,4,8,16,1,0,128,3,22,1024,2048,17,8,1042,1029,3,1029,131,19,1028,16,158,22,3,1171,1044,12,1045,1042,3090,4,1028,3,0,1027,1028]

theorem envBound54191 : H12AffineFastState.Bounded env54191 := by
  intro p hp
  have h : env54191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54190_54191 : H12AffineEnvironment.transform 12 8 env54190 = env54191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env54190 == env54191) = true)

theorem identity54191 : scanCanonicalize (H12AffineFastState.compose env54191 (packedSelected [0,2,3,4,5,7,9,11,12,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound54191 : packedSelected [0,2,3,4,5,7,9,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54192 : List Nat := [2,4,8,16,1,0,128,3,22,1024,153,17,8,1042,1029,3,1029,131,19,1028,16,158,22,3,1171,1044,12,1045,1042,1163,4,1028,3,0,1027,1028]

theorem envBound54192 : H12AffineFastState.Bounded env54192 := by
  intro p hp
  have h : env54192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54191_54192 : H12AffineEnvironment.transform 10 153 env54191 = env54192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env54191 == env54192) = true)

theorem identity54192 : scanCanonicalize (H12AffineFastState.compose env54192 (packedSelected [0,1,2,3,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound54192 : packedSelected [0,1,2,3,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54193 : List Nat := [2,4,8,16,1,0,128,3,22,135,153,17,8,149,130,3,130,131,19,131,16,158,22,3,20,147,12,146,149,12,4,131,3,0,132,131]

theorem envBound54193 : H12AffineFastState.Bounded env54193 := by
  intro p hp
  have h : env54193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54192_54193 : H12AffineEnvironment.transform 9 135 env54192 = env54193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env54192 == env54193) = true)

theorem identity54193 : scanCanonicalize (H12AffineFastState.compose env54193 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54193 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54194 : List Nat := [2,4,8,0,1,0,128,3,6,135,137,1,8,133,130,3,130,131,3,131,0,142,6,3,4,131,12,130,133,12,4,131,3,0,132,131]

theorem envBound54194 : H12AffineFastState.Bounded env54194 := by
  intro p hp
  have h : env54194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54193_54194 : H12AffineEnvironment.transform 3 0 env54193 = env54194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54193 == env54194) = true)

theorem identity54194 : scanCanonicalize (H12AffineFastState.compose env54194 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound54194 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54195 : List Nat := [2,4,8,0,1,0,2,3,6,5,11,1,8,7,0,3,0,1,3,1,0,12,6,3,4,1,12,0,7,12,4,1,3,0,6,1]

theorem envBound54195 : H12AffineFastState.Bounded env54195 := by
  intro p hp
  have h : env54195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54194_54195 : H12AffineEnvironment.transform 6 2 env54194 = env54195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env54194 == env54195) = true)

theorem identity54195 : scanCanonicalize (H12AffineFastState.compose env54195 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54195 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54196 : List Nat := [2,3,8,0,1,0,2,3,1,2,11,1,8,0,0,3,0,1,3,1,0,11,1,3,3,1,11,0,0,11,3,1,3,0,1,1]

theorem envBound54196 : H12AffineFastState.Bounded env54196 := by
  intro p hp
  have h : env54196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54195_54196 : H12AffineEnvironment.transform 1 3 env54195 = env54196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54195 == env54196) = true)

def env54197 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9228,65536,74798,65664,272,9229,17,412,74047,65537,9624,74815,303,74815,1297,77082,8204,74798,256,8200,1281,1029]

theorem envBound54197 : H12AffineFastState.Bounded env54197 := by
  intro p hp
  have h : env54197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54180_54197 : H12AffineEnvironment.transform 5 1 env54180 = env54197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54180 == env54197) = true)

theorem identity54197 : scanCanonicalize (H12AffineFastState.compose env54197 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1024) := by decide +kernel

theorem selectedBound54197 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54198 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9228,1024,8238,1152,272,9229,17,412,9535,1025,9624,8255,303,8255,1297,10522,8204,8238,256,8200,1281,1029]

theorem envBound54198 : H12AffineFastState.Bounded env54198 := by
  intro p hp
  have h : env54198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54197_54198 : H12AffineEnvironment.transform 15 1024 env54197 = env54198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1024 env54197 == env54198) = true)

def env54199 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1320,1297,292,1024,1286,1152,272,293,17,412,23,1025,176,1303,303,1303,1297,3122,1316,1286,256,1312,1281,1029]

theorem envBound54199 : H12AffineFastState.Bounded env54199 := by
  intro p hp
  have h : env54199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54198_54199 : H12AffineEnvironment.transform 12 1320 env54198 = env54199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1320 env54198 == env54199) = true)

theorem identity54199 : scanCanonicalize (H12AffineFastState.compose env54199 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(9+1) ^^^ 311) := by decide +kernel

theorem selectedBound54199 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env54200 : List Nat := [2,4,8,16,32,1,128,256,276,311,2048,16,31,38,292,311,49,439,272,293,17,412,23,310,176,32,303,32,38,2309,19,49,256,23,54,306]

theorem envBound54200 : H12AffineFastState.Bounded env54200 := by
  intro p hp
  have h : env54200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54199_54200 : H12AffineEnvironment.transform 9 311 env54199 = env54200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 311 env54199 == env54200) = true)

theorem identity54200 : scanCanonicalize (H12AffineFastState.compose env54200 (packedSelected [0,2,3,7,10,11,13,16,19,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound54200 : packedSelected [0,2,3,7,10,11,13,16,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54201 : List Nat := [2,4,8,16,32,1,128,256,276,311,61,16,31,38,292,311,49,439,272,293,17,412,23,310,176,32,303,32,38,312,19,49,256,23,54,306]

theorem envBound54201 : H12AffineFastState.Bounded env54201 := by
  intro p hp
  have h : env54201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54200_54201 : H12AffineEnvironment.transform 10 61 env54200 = env54201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env54200 == env54201) = true)

theorem identity54201 : scanCanonicalize (H12AffineFastState.compose env54201 (packedSelected [0,2,5,7,8,10,12,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54201 : packedSelected [0,2,5,7,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env54202 : List Nat := [2,4,8,16,32,1,128,21,1,34,61,16,31,38,49,34,49,162,5,48,17,137,23,35,176,32,58,32,38,45,19,49,21,23,54,39]

theorem envBound54202 : H12AffineFastState.Bounded env54202 := by
  intro p hp
  have h : env54202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54201_54202 : H12AffineEnvironment.transform 7 21 env54201 = env54202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54201 == env54202) = true)

theorem identity54202 : scanCanonicalize (H12AffineFastState.compose env54202 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound54202 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env54203 : List Nat := [2,4,8,16,12,1,128,21,1,14,17,16,31,10,29,14,29,142,5,28,17,137,23,15,156,12,22,12,10,1,19,29,21,23,26,11]

theorem envBound54203 : H12AffineFastState.Bounded env54203 := by
  intro p hp
  have h : env54203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54202_54203 : H12AffineEnvironment.transform 4 12 env54202 = env54203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env54202 == env54203) = true)

def env54204 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1321,1297,293,1024,1287,1152,272,292,17,412,22,1025,177,1302,303,1302,1297,3123,1317,1287,256,1313,1281,1029]

theorem envBound54204 : H12AffineFastState.Bounded env54204 := by
  intro p hp
  have h : env54204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54198_54204 : H12AffineEnvironment.transform 12 1321 env54198 = env54204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1321 env54198 == env54204) = true)

theorem identity54204 : scanCanonicalize (H12AffineFastState.compose env54204 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound54204 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env54205 : List Nat := [2,4,8,16,32,1,128,256,276,305,2048,16,24,32,293,305,54,433,272,292,17,412,22,304,177,39,303,39,32,2306,20,54,256,16,48,308]

theorem envBound54205 : H12AffineFastState.Bounded env54205 := by
  intro p hp
  have h : env54205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54204_54205 : H12AffineEnvironment.transform 9 305 env54204 = env54205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env54204 == env54205) = true)

theorem identity54205 : scanCanonicalize (H12AffineFastState.compose env54205 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound54205 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54206 : List Nat := [2,4,8,16,32,1,128,35,55,18,2048,16,24,32,6,18,54,146,51,7,17,191,22,19,177,39,12,39,32,2081,20,54,35,16,48,23]

theorem envBound54206 : H12AffineFastState.Bounded env54206 := by
  intro p hp
  have h : env54206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54205_54206 : H12AffineEnvironment.transform 7 35 env54205 = env54206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env54205 == env54206) = true)

theorem identity54206 : scanCanonicalize (H12AffineFastState.compose env54206 (packedSelected [2,5,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound54206 : packedSelected [2,5,11,13,18] rootPS < 2^1333 := by decide +kernel

def env54207 : List Nat := [2,4,8,16,32,1,128,35,55,18,27,16,24,32,6,18,54,146,51,7,17,191,22,19,177,39,12,39,32,58,20,54,35,16,48,23]

theorem envBound54207 : H12AffineFastState.Bounded env54207 := by
  intro p hp
  have h : env54207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54206_54207 : H12AffineEnvironment.transform 10 27 env54206 = env54207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env54206 == env54207) = true)

theorem identity54207 : scanCanonicalize (H12AffineFastState.compose env54207 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound54207 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54208 : List Nat := [2,4,8,16,32,1,15,35,55,18,27,16,24,32,6,18,54,29,51,7,17,48,22,19,62,39,12,39,32,58,20,54,35,16,48,23]

theorem envBound54208 : H12AffineFastState.Bounded env54208 := by
  intro p hp
  have h : env54208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54207_54208 : H12AffineEnvironment.transform 6 15 env54207 = env54208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env54207 == env54208) = true)

theorem identity54208 : scanCanonicalize (H12AffineFastState.compose env54208 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54208 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54209 : List Nat := [2,4,8,7,32,1,15,35,32,5,12,7,15,32,6,5,33,10,36,7,6,39,1,4,41,39,12,39,32,45,3,33,35,7,39,0]

theorem envBound54209 : H12AffineFastState.Bounded env54209 := by
  intro p hp
  have h : env54209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54208_54209 : H12AffineEnvironment.transform 3 7 env54208 = env54209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54208 == env54209) = true)

theorem identity54209 : scanCanonicalize (H12AffineFastState.compose env54209 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54209 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54210 : List Nat := [2,4,8,7,1,1,15,2,1,5,12,7,15,1,6,5,0,10,5,7,6,6,1,4,8,6,12,6,1,12,3,0,2,7,6,0]

theorem envBound54210 : H12AffineFastState.Bounded env54210 := by
  intro p hp
  have h : env54210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54209_54210 : H12AffineEnvironment.transform 4 1 env54209 = env54210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54209 == env54210) = true)

theorem identity54210 : scanCanonicalize (H12AffineFastState.compose env54210 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54211 : List Nat := [2,4,0,7,1,1,7,2,1,5,4,7,7,1,6,5,0,2,5,7,6,6,1,4,0,6,4,6,1,4,3,0,2,7,6,0]

theorem envBound54211 : H12AffineFastState.Bounded env54211 := by
  intro p hp
  have h : env54211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54210_54211 : H12AffineEnvironment.transform 2 0 env54210 = env54211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54210 == env54211) = true)

theorem identity54211 : scanCanonicalize (H12AffineFastState.compose env54211 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54211 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54212 : List Nat := [0,4,0,5,1,1,5,0,1,5,4,5,5,1,4,5,0,0,5,5,4,4,1,4,0,4,4,4,1,4,1,0,0,5,4,0]

theorem envBound54212 : H12AffineFastState.Bounded env54212 := by
  intro p hp
  have h : env54212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54211_54212 : H12AffineEnvironment.transform 0 0 env54211 = env54212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54211 == env54212) = true)

theorem identity54212 : scanCanonicalize (H12AffineFastState.compose env54212 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54213 : List Nat := [0,1,0,0,1,1,0,0,1,0,1,0,0,1,1,0,0,0,0,0,1,1,1,1,0,1,1,1,1,1,1,0,0,0,1,0]

theorem envBound54213 : H12AffineFastState.Bounded env54213 := by
  intro p hp
  have h : env54213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54212_54213 : H12AffineEnvironment.transform 1 1 env54212 = env54213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54212 == env54213) = true)

def env54214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4097,477,74047,69649,13769,78895,4414,74815,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound54214 : H12AffineFastState.Bounded env54214 := by
  intro p hp
  have h : env54214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54140_54214 : H12AffineEnvironment.transform 17 65665 env54140 = env54214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54140 == env54214) = true)

theorem identity54214 : scanCanonicalize (H12AffineFastState.compose env54214 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54214 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54215 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,1,79963,8204,74046,256,8200,80,4688]

theorem envBound54215 : H12AffineFastState.Bounded env54215 := by
  intro p hp
  have h : env54215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54214_54215 : H12AffineEnvironment.transform 9 272 env54214 = env54215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54214 == env54215) = true)

def env54216 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,1,79963,8204,74046,256,8200,80,4356]

theorem envBound54216 : H12AffineFastState.Bounded env54216 := by
  intro p hp
  have h : env54216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54215_54216 : H12AffineEnvironment.transform 8 340 env54215 = env54216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env54215 == env54216) = true)

def env54217 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,65536,74111,65665,337,8477,17,477,74047,65537,8393,74031,302,74031,1,75851,8204,74046,256,8200,80,276]

theorem envBound54217 : H12AffineFastState.Bounded env54217 := by
  intro p hp
  have h : env54217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54216_54217 : H12AffineEnvironment.transform 11 16 env54216 = env54217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env54216 == env54217) = true)

theorem identity54217 : scanCanonicalize (H12AffineFastState.compose env54217 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 127) := by decide +kernel

theorem selectedBound54217 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54218 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,127,1,355,65536,65792,65665,337,354,17,477,65856,65537,182,65872,302,65872,1,67636,115,65857,256,119,80,276]

theorem envBound54218 : H12AffineFastState.Bounded env54218 := by
  intro p hp
  have h : env54218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54217_54218 : H12AffineEnvironment.transform 12 127 env54217 = env54218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 127 env54217 == env54218) = true)

def env54219 : List Nat := [2,4,8,16,32,44,128,256,312,272,2048,16,19,1,271,65536,65792,65665,317,270,17,433,65836,65537,182,65852,302,65852,1,67636,31,65837,256,27,60,276]

theorem envBound54219 : H12AffineFastState.Bounded env54219 := by
  intro p hp
  have h : env54219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54218_54219 : H12AffineEnvironment.transform 5 44 env54218 = env54219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env54218 == env54219) = true)

theorem identity54219 : scanCanonicalize (H12AffineFastState.compose env54219 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2482) := by decide +kernel

theorem selectedBound54219 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env54220 : List Nat := [2,4,8,16,32,44,128,256,312,272,2048,16,19,1,271,2482,2226,2355,317,270,17,433,2206,2483,182,2190,302,2190,1,390,31,2207,256,27,60,276]

theorem envBound54220 : H12AffineFastState.Bounded env54220 := by
  intro p hp
  have h : env54220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54219_54220 : H12AffineEnvironment.transform 15 2482 env54219 = env54220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2482 env54219 == env54220) = true)

theorem identity54220 : scanCanonicalize (H12AffineFastState.compose env54220 (packedSelected [0,1,2,3,4,10,11,13,16,17,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound54220 : packedSelected [0,1,2,3,4,10,11,13,16,17,21,23] rootPS < 2^1333 := by decide +kernel

def env54221 : List Nat := [2,4,8,16,32,44,128,256,312,272,26,16,19,1,271,424,168,297,317,270,17,433,132,425,182,148,302,148,1,390,31,133,256,27,60,276]

theorem envBound54221 : H12AffineFastState.Bounded env54221 := by
  intro p hp
  have h : env54221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54220_54221 : H12AffineEnvironment.transform 10 26 env54220 = env54221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env54220 == env54221) = true)

theorem identity54221 : scanCanonicalize (H12AffineFastState.compose env54221 (packedSelected [1,4,5,9,11,12,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound54221 : packedSelected [1,4,5,9,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env54222 : List Nat := [2,4,8,16,32,44,4,256,312,272,26,16,19,1,271,300,44,297,317,270,17,309,0,301,50,16,302,16,1,258,31,1,256,27,60,276]

theorem envBound54222 : H12AffineFastState.Bounded env54222 := by
  intro p hp
  have h : env54222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54221_54222 : H12AffineEnvironment.transform 6 4 env54221 = env54222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env54221 == env54222) = true)

theorem identity54222 : scanCanonicalize (H12AffineFastState.compose env54222 (packedSelected [2,3,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound54222 : packedSelected [2,3,10,12] rootPS < 2^1333 := by decide +kernel

def env54223 : List Nat := [2,4,8,16,32,44,4,24,32,8,26,16,19,1,23,52,44,49,37,22,17,45,0,53,50,16,54,16,1,26,31,1,24,27,60,12]

theorem envBound54223 : H12AffineFastState.Bounded env54223 := by
  intro p hp
  have h : env54223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54222_54223 : H12AffineEnvironment.transform 7 24 env54222 = env54223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env54222 == env54223) = true)

theorem identity54223 : scanCanonicalize (H12AffineFastState.compose env54223 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54223 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54224 : List Nat := [2,4,8,11,32,44,4,3,32,8,1,11,8,1,12,47,44,42,37,13,10,45,0,46,41,11,45,11,1,1,4,1,3,0,39,12]

theorem envBound54224 : H12AffineFastState.Bounded env54224 := by
  intro p hp
  have h : env54224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54223_54224 : H12AffineEnvironment.transform 3 11 env54223 = env54224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54223 == env54224) = true)

theorem identity54224 : scanCanonicalize (H12AffineFastState.compose env54224 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound54224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54225 : List Nat := [2,4,8,11,13,1,4,3,13,8,1,11,8,1,12,2,1,7,8,13,10,0,0,3,4,11,0,11,1,1,4,1,3,0,10,12]

theorem envBound54225 : H12AffineFastState.Bounded env54225 := by
  intro p hp
  have h : env54225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54224_54225 : H12AffineEnvironment.transform 4 13 env54224 = env54225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env54224 == env54225) = true)

theorem identity54225 : scanCanonicalize (H12AffineFastState.compose env54225 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54226 : List Nat := [2,4,4,7,1,1,4,3,1,4,1,7,4,1,0,2,1,7,4,1,6,0,0,3,4,7,0,7,1,1,4,1,3,0,6,0]

theorem envBound54226 : H12AffineFastState.Bounded env54226 := by
  intro p hp
  have h : env54226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54225_54226 : H12AffineEnvironment.transform 2 4 env54225 = env54226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54225 == env54226) = true)

theorem identity54226 : scanCanonicalize (H12AffineFastState.compose env54226 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54227 : List Nat := [0,4,4,5,1,1,4,1,1,4,1,5,4,1,0,0,1,5,4,1,4,0,0,1,4,5,0,5,1,1,4,1,1,0,4,0]

theorem envBound54227 : H12AffineFastState.Bounded env54227 := by
  intro p hp
  have h : env54227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54226_54227 : H12AffineEnvironment.transform 0 0 env54226 = env54227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54226 == env54227) = true)

theorem identity54227 : scanCanonicalize (H12AffineFastState.compose env54227 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54227 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54228 : List Nat := [0,1,1,0,1,1,1,1,1,1,1,0,1,1,0,0,1,0,1,1,1,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0]

theorem envBound54228 : H12AffineFastState.Bounded env54228 := by
  intro p hp
  have h : env54228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54227_54228 : H12AffineEnvironment.transform 1 1 env54227 = env54228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54227 == env54228) = true)

def env54229 : List Nat := [2,4,8,16,32,45,128,256,313,272,2048,16,18,1,270,65536,65792,65665,316,271,17,432,65837,65537,182,65853,302,65853,1,67636,30,65836,256,26,61,276]

theorem envBound54229 : H12AffineFastState.Bounded env54229 := by
  intro p hp
  have h : env54229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54218_54229 : H12AffineEnvironment.transform 5 45 env54218 = env54229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env54218 == env54229) = true)

theorem identity54229 : scanCanonicalize (H12AffineFastState.compose env54229 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2489) := by decide +kernel

theorem selectedBound54229 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env54230 : List Nat := [2,4,8,16,32,45,128,256,313,272,2048,16,18,1,270,2489,2233,2360,316,271,17,432,2196,2488,182,2180,302,2180,1,397,30,2197,256,26,61,276]

theorem envBound54230 : H12AffineFastState.Bounded env54230 := by
  intro p hp
  have h : env54230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54229_54230 : H12AffineEnvironment.transform 15 2489 env54229 = env54230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2489 env54229 == env54230) = true)

theorem identity54230 : scanCanonicalize (H12AffineFastState.compose env54230 (packedSelected [1,4,8,9,10,13,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound54230 : packedSelected [1,4,8,9,10,13,16,18,19] rootPS < 2^1333 := by decide +kernel

def env54231 : List Nat := [2,4,8,16,32,45,128,256,313,272,412,16,18,1,270,37,293,164,316,271,17,432,264,36,182,280,302,280,1,397,30,265,256,26,61,276]

theorem envBound54231 : H12AffineFastState.Bounded env54231 := by
  intro p hp
  have h : env54231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54230_54231 : H12AffineEnvironment.transform 10 412 env54230 = env54231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env54230 == env54231) = true)

theorem identity54231 : scanCanonicalize (H12AffineFastState.compose env54231 (packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound54231 : packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env54232 : List Nat := [2,4,8,16,32,45,128,166,159,182,58,16,18,1,168,37,131,164,154,169,17,22,174,36,182,190,136,190,1,43,30,175,166,26,61,178]

theorem envBound54232 : H12AffineFastState.Bounded env54232 := by
  intro p hp
  have h : env54232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54231_54232 : H12AffineEnvironment.transform 7 166 env54231 = env54232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env54231 == env54232) = true)

theorem identity54232 : scanCanonicalize (H12AffineFastState.compose env54232 (packedSelected [1,3,4,5,9,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54232 : packedSelected [1,3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env54233 : List Nat := [2,4,8,11,32,45,128,166,132,173,33,11,9,1,168,37,131,164,129,169,10,13,174,36,173,165,136,165,1,43,5,175,166,1,38,169]

theorem envBound54233 : H12AffineFastState.Bounded env54233 := by
  intro p hp
  have h : env54233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54232_54233 : H12AffineEnvironment.transform 3 11 env54232 = env54233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54232 == env54233) = true)

theorem identity54233 : scanCanonicalize (H12AffineFastState.compose env54233 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound54233 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54234 : List Nat := [2,4,8,11,32,45,4,34,0,41,33,11,9,1,44,37,7,32,5,45,10,13,42,36,41,33,12,33,1,43,5,43,34,1,38,45]

theorem envBound54234 : H12AffineFastState.Bounded env54234 := by
  intro p hp
  have h : env54234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54233_54234 : H12AffineEnvironment.transform 6 4 env54233 = env54234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env54233 == env54234) = true)

theorem identity54234 : scanCanonicalize (H12AffineFastState.compose env54234 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54234 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54235 : List Nat := [2,4,8,11,10,7,4,8,0,3,11,11,9,1,6,15,7,10,5,7,10,13,0,14,3,11,12,11,1,1,5,1,8,1,12,7]

theorem envBound54235 : H12AffineFastState.Bounded env54235 := by
  intro p hp
  have h : env54235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54234_54235 : H12AffineEnvironment.transform 4 10 env54234 = env54235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54234 == env54235) = true)

theorem identity54235 : scanCanonicalize (H12AffineFastState.compose env54235 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54235 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54236 : List Nat := [2,4,5,6,7,7,4,5,0,3,6,6,4,1,6,2,7,7,5,7,7,0,0,3,3,6,1,6,1,1,5,1,5,1,1,7]

theorem envBound54236 : H12AffineFastState.Bounded env54236 := by
  intro p hp
  have h : env54236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54235_54236 : H12AffineEnvironment.transform 2 5 env54235 = env54236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54235 == env54236) = true)

def env54237 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,65536,74111,65665,336,8476,16,477,74047,65536,8392,74030,303,74031,1,75850,8204,74046,256,8200,80,277]

theorem envBound54237 : H12AffineFastState.Bounded env54237 := by
  intro p hp
  have h : env54237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54216_54237 : H12AffineEnvironment.transform 11 17 env54216 = env54237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54216 == env54237) = true)

theorem identity54237 : scanCanonicalize (H12AffineFastState.compose env54237 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound54237 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54238 : List Nat := [2,4,8,16,32,38,128,256,306,272,2048,17,8192,1,8477,65536,74009,65665,310,8476,16,443,74047,65536,8366,74030,303,74031,1,75820,8204,74046,256,8200,54,277]

theorem envBound54238 : H12AffineFastState.Bounded env54238 := by
  intro p hp
  have h : env54238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54237_54238 : H12AffineEnvironment.transform 5 38 env54237 = env54238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env54237 == env54238) = true)

def env54239 : List Nat := [2,4,8,16,32,38,128,256,306,272,2048,17,24,1,261,65536,65793,65665,310,260,16,443,65831,65536,182,65846,303,65847,1,67636,20,65830,256,16,54,277]

theorem envBound54239 : H12AffineFastState.Bounded env54239 := by
  intro p hp
  have h : env54239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54238_54239 : H12AffineEnvironment.transform 12 24 env54238 = env54239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env54238 == env54239) = true)

theorem identity54239 : scanCanonicalize (H12AffineFastState.compose env54239 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound54239 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54240 : List Nat := [2,4,8,16,32,38,128,256,306,272,2048,17,24,1,261,50,307,179,310,260,16,443,277,50,182,260,303,261,1,2054,20,276,256,16,54,277]

theorem envBound54240 : H12AffineFastState.Bounded env54240 := by
  intro p hp
  have h : env54240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54239_54240 : H12AffineEnvironment.transform 15 50 env54239 = env54240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env54239 == env54240) = true)

theorem identity54240 : scanCanonicalize (H12AffineFastState.compose env54240 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54240 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env54241 : List Nat := [2,4,8,16,23,17,128,256,261,272,2048,17,24,1,261,5,260,132,257,260,16,396,277,5,129,260,280,261,1,2054,20,276,256,16,1,277]

theorem envBound54241 : H12AffineFastState.Bounded env54241 := by
  intro p hp
  have h : env54241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54240_54241 : H12AffineEnvironment.transform 4 23 env54240 = env54241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54240 == env54241) = true)

theorem identity54241 : scanCanonicalize (H12AffineFastState.compose env54241 (packedSelected [1,3,8,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound54241 : packedSelected [1,3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54242 : List Nat := [2,4,8,16,23,17,128,3,6,19,2048,17,24,1,6,5,7,132,2,7,16,143,22,5,129,7,27,6,1,2054,20,23,3,16,1,22]

theorem envBound54242 : H12AffineFastState.Bounded env54242 := by
  intro p hp
  have h : env54242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54241_54242 : H12AffineEnvironment.transform 7 3 env54241 = env54242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env54241 == env54242) = true)

theorem identity54242 : scanCanonicalize (H12AffineFastState.compose env54242 (packedSelected [0,1,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound54242 : packedSelected [0,1,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54243 : List Nat := [2,4,8,16,23,17,128,3,6,19,6,17,24,1,6,5,7,132,2,7,16,143,22,5,129,7,27,6,1,0,20,23,3,16,1,22]

theorem envBound54243 : H12AffineFastState.Bounded env54243 := by
  intro p hp
  have h : env54243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54242_54243 : H12AffineEnvironment.transform 10 6 env54242 = env54243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env54242 == env54243) = true)

theorem identity54243 : scanCanonicalize (H12AffineFastState.compose env54243 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54243 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54244 : List Nat := [2,4,8,6,1,7,128,3,6,5,6,7,14,1,6,5,7,132,2,7,6,143,0,5,129,7,13,6,1,0,2,1,3,6,1,0]

theorem envBound54244 : H12AffineFastState.Bounded env54244 := by
  intro p hp
  have h : env54244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54243_54244 : H12AffineEnvironment.transform 3 6 env54243 = env54244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54243 == env54244) = true)

theorem identity54244 : scanCanonicalize (H12AffineFastState.compose env54244 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54244 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env54245 : List Nat := [2,4,5,6,1,7,128,3,6,5,6,7,3,1,6,5,7,132,2,7,6,130,0,5,129,7,0,6,1,0,2,1,3,6,1,0]

theorem envBound54245 : H12AffineFastState.Bounded env54245 := by
  intro p hp
  have h : env54245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54244_54245 : H12AffineEnvironment.transform 2 5 env54244 = env54245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54244 == env54245) = true)

def env54246 : List Nat := [2,4,8,16,32,38,128,256,306,272,2048,17,25,1,260,65536,65792,65665,310,261,16,443,65830,65536,183,65847,303,65846,1,67637,21,65831,256,17,54,277]

theorem envBound54246 : H12AffineFastState.Bounded env54246 := by
  intro p hp
  have h : env54246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54238_54246 : H12AffineEnvironment.transform 12 25 env54238 = env54246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54238 == env54246) = true)

theorem identity54246 : scanCanonicalize (H12AffineFastState.compose env54246 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound54246 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54247 : List Nat := [2,4,8,16,32,38,128,256,306,272,2048,17,25,1,260,21,277,148,310,261,16,443,307,21,183,290,303,291,1,2080,21,306,256,17,54,277]

theorem envBound54247 : H12AffineFastState.Bounded env54247 := by
  intro p hp
  have h : env54247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54246_54247 : H12AffineEnvironment.transform 15 21 env54246 = env54247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env54246 == env54247) = true)

theorem identity54247 : scanCanonicalize (H12AffineFastState.compose env54247 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound54247 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env54248 : List Nat := [2,4,8,16,32,38,128,35,17,51,2048,17,25,1,39,21,54,148,21,38,16,152,16,21,183,1,12,0,1,2080,21,17,35,17,54,54]

theorem envBound54248 : H12AffineFastState.Bounded env54248 := by
  intro p hp
  have h : env54248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54247_54248 : H12AffineEnvironment.transform 7 35 env54247 = env54248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env54247 == env54248) = true)

theorem identity54248 : scanCanonicalize (H12AffineFastState.compose env54248 (packedSelected [1,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound54248 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env54249 : List Nat := [2,4,8,16,32,38,128,35,17,51,22,17,25,1,39,21,54,148,21,38,16,152,16,21,183,1,12,0,1,54,21,17,35,17,54,54]

theorem envBound54249 : H12AffineFastState.Bounded env54249 := by
  intro p hp
  have h : env54249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54248_54249 : H12AffineEnvironment.transform 10 22 env54248 = env54249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env54248 == env54249) = true)

theorem identity54249 : scanCanonicalize (H12AffineFastState.compose env54249 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54249 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env54250 : List Nat := [2,4,8,16,11,13,128,8,17,24,22,17,25,1,12,21,29,148,21,13,16,152,16,21,156,1,12,0,1,29,21,17,8,17,29,29]

theorem envBound54250 : H12AffineFastState.Bounded env54250 := by
  intro p hp
  have h : env54250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54249_54250 : H12AffineEnvironment.transform 4 11 env54249 = env54250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54249 == env54250) = true)

theorem identity54250 : scanCanonicalize (H12AffineFastState.compose env54250 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound54250 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54251 : List Nat := [2,4,8,16,11,13,20,8,17,24,22,17,25,1,12,21,29,0,21,13,16,12,16,21,8,1,12,0,1,29,21,17,8,17,29,29]

theorem envBound54251 : H12AffineFastState.Bounded env54251 := by
  intro p hp
  have h : env54251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54250_54251 : H12AffineEnvironment.transform 6 20 env54250 = env54251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env54250 == env54251) = true)

theorem identity54251 : scanCanonicalize (H12AffineFastState.compose env54251 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54251 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54252 : List Nat := [2,4,5,16,6,0,20,5,17,21,22,17,20,1,1,21,16,0,21,0,16,1,16,21,5,1,1,0,1,16,21,17,5,17,16,16]

theorem envBound54252 : H12AffineFastState.Bounded env54252 := by
  intro p hp
  have h : env54252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54251_54252 : H12AffineEnvironment.transform 2 5 env54251 = env54252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54251 == env54252) = true)

theorem identity54252 : scanCanonicalize (H12AffineFastState.compose env54252 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54253 : List Nat := [2,4,5,6,6,0,2,5,7,3,0,7,2,1,1,3,6,0,3,0,6,1,6,3,5,1,1,0,1,6,3,7,5,7,6,6]

theorem envBound54253 : H12AffineFastState.Bounded env54253 := by
  intro p hp
  have h : env54253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54252_54253 : H12AffineEnvironment.transform 3 6 env54252 = env54253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54252 == env54253) = true)

theorem identity54253 : scanCanonicalize (H12AffineFastState.compose env54253 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54254 : List Nat := [2,0,1,2,2,0,2,1,3,3,0,3,2,1,1,3,2,0,3,0,2,1,2,3,1,1,1,0,1,2,3,3,1,3,2,2]

theorem envBound54254 : H12AffineFastState.Bounded env54254 := by
  intro p hp
  have h : env54254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54253_54254 : H12AffineEnvironment.transform 1 0 env54253 = env54254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54253 == env54254) = true)

theorem identity54254 : scanCanonicalize (H12AffineFastState.compose env54254 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54254 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54255 : List Nat := [0,0,1,0,0,0,0,1,1,1,0,1,0,1,1,1,0,0,1,0,0,1,0,1,1,1,1,0,1,0,1,1,1,1,0,0]

theorem envBound54255 : H12AffineFastState.Bounded env54255 := by
  intro p hp
  have h : env54255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54254_54255 : H12AffineEnvironment.transform 0 0 env54254 = env54255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54254 == env54255) = true)

def env54256 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,1,79963,8204,74046,256,8200,80,4357]

theorem envBound54256 : H12AffineFastState.Bounded env54256 := by
  intro p hp
  have h : env54256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54215_54256 : H12AffineEnvironment.transform 8 341 env54215 = env54256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env54215 == env54256) = true)

def env54257 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,65536,74111,65665,337,8477,17,477,74047,65537,8393,74031,302,74031,1,75851,8204,74046,256,8200,80,277]

theorem envBound54257 : H12AffineFastState.Bounded env54257 := by
  intro p hp
  have h : env54257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54256_54257 : H12AffineEnvironment.transform 11 16 env54256 = env54257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env54256 == env54257) = true)

theorem identity54257 : scanCanonicalize (H12AffineFastState.compose env54257 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 336) := by decide +kernel

theorem selectedBound54257 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54258 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,336,8239,465,337,8477,17,477,8303,337,8393,8319,302,8319,1,10523,8204,8302,256,8200,80,277]

theorem envBound54258 : H12AffineFastState.Bounded env54258 := by
  intro p hp
  have h : env54258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54257_54258 : H12AffineEnvironment.transform 15 336 env54257 = env54258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 336 env54257 == env54258) = true)

def env54259 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,120,1,356,336,87,465,337,357,17,477,23,337,177,7,302,7,1,2403,116,22,256,112,80,277]

theorem envBound54259 : H12AffineFastState.Bounded env54259 := by
  intro p hp
  have h : env54259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54258_54259 : H12AffineEnvironment.transform 12 120 env54258 = env54259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54258 == env54259) = true)

theorem identity54259 : scanCanonicalize (H12AffineFastState.compose env54259 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound54259 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env54260 : List Nat := [2,4,8,16,6,64,128,256,341,272,2048,16,94,1,322,336,87,465,337,323,17,477,23,337,151,7,264,7,1,2373,82,22,256,86,80,277]

theorem envBound54260 : H12AffineFastState.Bounded env54260 := by
  intro p hp
  have h : env54260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54259_54260 : H12AffineEnvironment.transform 4 6 env54259 = env54260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env54259 == env54260) = true)

theorem identity54260 : scanCanonicalize (H12AffineFastState.compose env54260 (packedSelected [0,1,2,5,7,8,11,13,16,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 280) := by decide +kernel

theorem selectedBound54260 : packedSelected [0,1,2,5,7,8,11,13,16,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54261 : List Nat := [2,4,8,16,6,64,128,256,341,272,280,16,94,1,322,336,87,465,337,323,17,477,23,337,151,7,264,7,1,93,82,22,256,86,80,277]

theorem envBound54261 : H12AffineFastState.Bounded env54261 := by
  intro p hp
  have h : env54261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54260_54261 : H12AffineEnvironment.transform 10 280 env54260 = env54261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 280 env54260 == env54261) = true)

theorem identity54261 : scanCanonicalize (H12AffineFastState.compose env54261 (packedSelected [1,4,5,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound54261 : packedSelected [1,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env54262 : List Nat := [2,4,8,16,6,64,128,15,90,31,23,16,94,1,77,95,87,222,94,76,17,210,23,94,151,7,7,7,1,93,82,22,15,86,80,26]

theorem envBound54262 : H12AffineFastState.Bounded env54262 := by
  intro p hp
  have h : env54262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54261_54262 : H12AffineEnvironment.transform 7 15 env54261 = env54262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env54261 == env54262) = true)

theorem identity54262 : scanCanonicalize (H12AffineFastState.compose env54262 (packedSelected [1,4,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound54262 : packedSelected [1,4,9,10,13] rootPS < 2^1333 := by decide +kernel

def env54263 : List Nat := [2,4,8,16,6,64,85,15,90,31,23,16,94,1,77,95,87,11,94,76,17,7,23,94,66,7,7,7,1,93,82,22,15,86,80,26]

theorem envBound54263 : H12AffineFastState.Bounded env54263 := by
  intro p hp
  have h : env54263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54262_54263 : H12AffineEnvironment.transform 6 85 env54262 = env54263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env54262 == env54263) = true)

theorem identity54263 : scanCanonicalize (H12AffineFastState.compose env54263 (packedSelected [0,3,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound54263 : packedSelected [0,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env54264 : List Nat := [2,4,8,16,6,13,24,15,23,31,23,16,19,1,0,18,26,11,19,1,17,7,23,19,15,7,7,7,1,16,31,22,15,27,29,26]

theorem envBound54264 : H12AffineFastState.Bounded env54264 := by
  intro p hp
  have h : env54264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54263_54264 : H12AffineEnvironment.transform 5 13 env54263 = env54264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env54263 == env54264) = true)

def env54265 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,121,1,357,336,86,465,337,356,17,477,22,337,176,6,302,6,1,2402,117,23,256,113,80,277]

theorem envBound54265 : H12AffineFastState.Bounded env54265 := by
  intro p hp
  have h : env54265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54258_54265 : H12AffineEnvironment.transform 12 121 env54258 = env54265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env54258 == env54265) = true)

theorem identity54265 : scanCanonicalize (H12AffineFastState.compose env54265 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54265 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env54266 : List Nat := [2,4,8,16,0,64,128,256,341,272,2048,16,89,1,325,336,86,465,337,324,17,477,22,337,144,6,270,6,1,2370,85,23,256,81,80,277]

theorem envBound54266 : H12AffineFastState.Bounded env54266 := by
  intro p hp
  have h : env54266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54265_54266 : H12AffineEnvironment.transform 4 0 env54265 = env54266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54265 == env54266) = true)

theorem identity54266 : scanCanonicalize (H12AffineFastState.compose env54266 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound54266 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54267 : List Nat := [2,4,8,16,0,64,128,67,22,83,2048,16,89,1,6,19,86,146,18,7,17,158,22,18,144,6,77,6,1,2049,85,23,67,81,80,86]

theorem envBound54267 : H12AffineFastState.Bounded env54267 := by
  intro p hp
  have h : env54267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54266_54267 : H12AffineEnvironment.transform 7 67 env54266 = env54267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env54266 == env54267) = true)

theorem identity54267 : scanCanonicalize (H12AffineFastState.compose env54267 (packedSelected [0,1,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound54267 : packedSelected [0,1,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54268 : List Nat := [2,4,8,16,0,64,128,67,22,83,17,16,89,1,6,19,86,146,18,7,17,158,22,18,144,6,77,6,1,16,85,23,67,81,80,86]

theorem envBound54268 : H12AffineFastState.Bounded env54268 := by
  intro p hp
  have h : env54268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54267_54268 : H12AffineEnvironment.transform 10 17 env54267 = env54268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env54267 == env54268) = true)

theorem identity54268 : scanCanonicalize (H12AffineFastState.compose env54268 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound54268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54269 : List Nat := [2,4,8,16,0,22,128,21,22,5,17,16,15,1,6,19,0,146,18,7,17,158,22,18,144,6,27,6,1,16,3,23,21,7,6,0]

theorem envBound54269 : H12AffineFastState.Bounded env54269 := by
  intro p hp
  have h : env54269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54268_54269 : H12AffineEnvironment.transform 5 22 env54268 = env54269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env54268 == env54269) = true)

theorem identity54269 : scanCanonicalize (H12AffineFastState.compose env54269 (packedSelected [0,5,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54269 : packedSelected [0,5,9] rootPS < 2^1333 := by decide +kernel

def env54270 : List Nat := [2,4,5,16,0,22,128,21,22,5,17,16,2,1,6,19,0,146,18,7,17,147,22,18,144,6,22,6,1,16,3,23,21,7,6,0]

theorem envBound54270 : H12AffineFastState.Bounded env54270 := by
  intro p hp
  have h : env54270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54269_54270 : H12AffineEnvironment.transform 2 5 env54269 = env54270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54269 == env54270) = true)

theorem identity54270 : scanCanonicalize (H12AffineFastState.compose env54270 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54271 : List Nat := [2,4,5,6,0,0,128,3,0,5,7,6,2,1,6,5,0,132,4,7,7,133,0,4,134,6,0,6,1,6,3,1,3,7,6,0]

theorem envBound54271 : H12AffineFastState.Bounded env54271 := by
  intro p hp
  have h : env54271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54270_54271 : H12AffineEnvironment.transform 3 6 env54270 = env54271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54270 == env54271) = true)

theorem identity54271 : scanCanonicalize (H12AffineFastState.compose env54271 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound54271 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54272 : List Nat := [2,4,5,6,0,0,3,3,0,5,7,6,2,1,6,5,0,7,4,7,7,6,0,4,5,6,0,6,1,6,3,1,3,7,6,0]

theorem envBound54272 : H12AffineFastState.Bounded env54272 := by
  intro p hp
  have h : env54272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54271_54272 : H12AffineEnvironment.transform 6 3 env54271 = env54272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env54271 == env54272) = true)

theorem identity54272 : scanCanonicalize (H12AffineFastState.compose env54272 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54273 : List Nat := [2,3,2,1,0,0,3,3,0,2,0,1,2,1,1,2,0,0,3,0,0,1,0,3,2,1,0,1,1,1,3,1,3,0,1,0]

theorem envBound54273 : H12AffineFastState.Bounded env54273 := by
  intro p hp
  have h : env54273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54272_54273 : H12AffineEnvironment.transform 1 3 env54272 = env54273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54272 == env54273) = true)

def env54274 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,65536,74111,65665,336,8476,16,477,74047,65536,8392,74030,303,74031,1,75850,8204,74046,256,8200,80,276]

theorem envBound54274 : H12AffineFastState.Bounded env54274 := by
  intro p hp
  have h : env54274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54256_54274 : H12AffineEnvironment.transform 11 17 env54256 = env54274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54256 == env54274) = true)

theorem identity54274 : scanCanonicalize (H12AffineFastState.compose env54274 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8521) := by decide +kernel

theorem selectedBound54274 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54275 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,8521,54,8648,336,8476,16,477,118,8521,8392,103,303,102,1,2307,8204,119,256,8200,80,276]

theorem envBound54275 : H12AffineFastState.Bounded env54275 := by
  intro p hp
  have h : env54275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54274_54275 : H12AffineEnvironment.transform 15 8521 env54274 = env54275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8521 env54274 == env54275) = true)

def env54276 : List Nat := [2,4,8,16,32,0,128,256,277,272,2048,17,8192,1,8477,8457,54,8584,272,8476,16,413,54,8457,8328,39,303,38,1,2307,8204,55,256,8200,16,276]

theorem envBound54276 : H12AffineFastState.Bounded env54276 := by
  intro p hp
  have h : env54276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54275_54276 : H12AffineEnvironment.transform 5 0 env54275 = env54276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54275 == env54276) = true)

theorem identity54276 : scanCanonicalize (H12AffineFastState.compose env54276 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54276 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54277 : List Nat := [2,4,8,16,32,0,128,256,277,272,2048,17,268,1,17,5,54,132,272,16,16,413,54,5,388,39,303,38,1,2307,256,55,256,260,16,276]

theorem envBound54277 : H12AffineFastState.Bounded env54277 := by
  intro p hp
  have h : env54277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54276_54277 : H12AffineEnvironment.transform 12 268 env54276 = env54277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54276 == env54277) = true)

theorem identity54277 : scanCanonicalize (H12AffineFastState.compose env54277 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound54277 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54278 : List Nat := [2,4,8,16,32,0,128,35,54,51,2048,17,47,1,17,5,54,132,51,16,16,190,54,5,167,39,12,38,1,2080,35,55,35,39,16,55]

theorem envBound54278 : H12AffineFastState.Bounded env54278 := by
  intro p hp
  have h : env54278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54277_54278 : H12AffineEnvironment.transform 7 35 env54277 = env54278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env54277 == env54278) = true)

theorem identity54278 : scanCanonicalize (H12AffineFastState.compose env54278 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound54278 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54279 : List Nat := [2,4,8,16,32,0,128,35,54,51,23,17,47,1,17,5,54,132,51,16,16,190,54,5,167,39,12,38,1,55,35,55,35,39,16,55]

theorem envBound54279 : H12AffineFastState.Bounded env54279 := by
  intro p hp
  have h : env54279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54278_54279 : H12AffineEnvironment.transform 10 23 env54278 = env54279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env54278 == env54279) = true)

theorem identity54279 : scanCanonicalize (H12AffineFastState.compose env54279 (packedSelected [1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54279 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env54280 : List Nat := [2,4,8,10,32,0,128,35,44,41,13,11,47,1,11,5,44,132,41,10,10,164,44,5,167,39,12,38,1,45,35,45,35,39,10,45]

theorem envBound54280 : H12AffineFastState.Bounded env54280 := by
  intro p hp
  have h : env54280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54279_54280 : H12AffineEnvironment.transform 3 10 env54279 = env54280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54279 == env54280) = true)

theorem identity54280 : scanCanonicalize (H12AffineFastState.compose env54280 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54280 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env54281 : List Nat := [2,4,4,6,32,0,128,35,32,37,1,7,35,1,7,5,32,132,37,6,6,164,32,5,167,39,0,38,1,33,35,33,35,39,6,33]

theorem envBound54281 : H12AffineFastState.Bounded env54281 := by
  intro p hp
  have h : env54281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54280_54281 : H12AffineEnvironment.transform 2 4 env54280 = env54281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54280 == env54281) = true)

theorem identity54281 : scanCanonicalize (H12AffineFastState.compose env54281 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54281 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54282 : List Nat := [2,3,3,1,32,0,128,35,32,34,1,0,35,1,0,2,32,131,34,1,1,163,32,2,160,32,0,33,1,33,35,33,35,32,1,33]

theorem envBound54282 : H12AffineFastState.Bounded env54282 := by
  intro p hp
  have h : env54282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54281_54282 : H12AffineEnvironment.transform 1 3 env54281 = env54282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54281 == env54282) = true)

theorem identity54282 : scanCanonicalize (H12AffineFastState.compose env54282 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54283 : List Nat := [1,0,0,1,32,0,128,32,32,33,1,0,32,1,0,1,32,128,33,1,1,160,32,1,160,32,0,33,1,33,32,33,32,32,1,33]

theorem envBound54283 : H12AffineFastState.Bounded env54283 := by
  intro p hp
  have h : env54283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54282_54283 : H12AffineEnvironment.transform 0 1 env54282 = env54283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54282 == env54283) = true)

theorem identity54283 : scanCanonicalize (H12AffineFastState.compose env54283 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54284 : List Nat := [1,0,0,1,1,0,128,1,1,0,1,0,1,1,0,1,1,128,0,1,1,129,1,1,129,1,0,0,1,0,1,0,1,1,1,0]

theorem envBound54284 : H12AffineFastState.Bounded env54284 := by
  intro p hp
  have h : env54284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54283_54284 : H12AffineEnvironment.transform 4 1 env54283 = env54284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54283 == env54284) = true)

def env54285 : List Nat := [2,4,8,16,32,1,128,256,276,272,2048,17,8192,1,8477,8456,54,8585,273,8476,16,412,55,8456,8329,38,303,39,1,2307,8204,54,256,8200,17,276]

theorem envBound54285 : H12AffineFastState.Bounded env54285 := by
  intro p hp
  have h : env54285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54275_54285 : H12AffineEnvironment.transform 5 1 env54275 = env54285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54275 == env54285) = true)

theorem identity54285 : scanCanonicalize (H12AffineFastState.compose env54285 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 314) := by decide +kernel

theorem selectedBound54285 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54286 : List Nat := [2,4,8,16,32,1,128,256,276,272,2048,17,314,1,39,50,54,179,273,38,16,412,55,50,435,38,303,39,1,2307,310,54,256,306,17,276]

theorem envBound54286 : H12AffineFastState.Bounded env54286 := by
  intro p hp
  have h : env54286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54285_54286 : H12AffineEnvironment.transform 12 314 env54285 = env54286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 314 env54285 == env54286) = true)

theorem identity54286 : scanCanonicalize (H12AffineFastState.compose env54286 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54286 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54287 : List Nat := [2,4,8,0,32,1,128,256,260,256,2048,1,298,1,39,34,38,163,257,38,0,396,39,34,419,38,303,39,1,2307,294,38,256,290,1,260]

theorem envBound54287 : H12AffineFastState.Bounded env54287 := by
  intro p hp
  have h : env54287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54286_54287 : H12AffineEnvironment.transform 3 0 env54286 = env54287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54286 == env54287) = true)

theorem identity54287 : scanCanonicalize (H12AffineFastState.compose env54287 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 291) := by decide +kernel

theorem selectedBound54287 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54288 : List Nat := [2,4,8,0,32,1,128,256,260,256,291,1,298,1,39,34,38,163,257,38,0,396,39,34,419,38,303,39,1,32,294,38,256,290,1,260]

theorem envBound54288 : H12AffineFastState.Bounded env54288 := by
  intro p hp
  have h : env54288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54287_54288 : H12AffineEnvironment.transform 10 291 env54287 = env54288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 291 env54287 == env54288) = true)

theorem identity54288 : scanCanonicalize (H12AffineFastState.compose env54288 (packedSelected [0,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54288 : packedSelected [0,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54289 : List Nat := [2,4,8,0,32,1,8,256,260,256,291,1,298,1,39,34,38,43,257,38,0,260,39,34,299,38,303,39,1,32,294,38,256,290,1,260]

theorem envBound54289 : H12AffineFastState.Bounded env54289 := by
  intro p hp
  have h : env54289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54288_54289 : H12AffineEnvironment.transform 6 8 env54288 = env54289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54288 == env54289) = true)

theorem identity54289 : scanCanonicalize (H12AffineFastState.compose env54289 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound54289 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54290 : List Nat := [2,4,8,0,32,1,8,40,44,40,11,1,2,1,39,34,38,43,41,38,0,44,39,34,3,38,7,39,1,32,14,38,40,10,1,44]

theorem envBound54290 : H12AffineFastState.Bounded env54290 := by
  intro p hp
  have h : env54290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54289_54290 : H12AffineEnvironment.transform 7 40 env54289 = env54290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env54289 == env54290) = true)

theorem identity54290 : scanCanonicalize (H12AffineFastState.compose env54290 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54290 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env54291 : List Nat := [2,4,8,0,0,1,8,8,12,8,11,1,2,1,7,2,6,11,9,6,0,12,7,2,3,6,7,7,1,0,14,6,8,10,1,12]

theorem envBound54291 : H12AffineFastState.Bounded env54291 := by
  intro p hp
  have h : env54291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54290_54291 : H12AffineEnvironment.transform 4 0 env54290 = env54291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54290 == env54291) = true)

def env54292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123164,28889,78894,385202,90414,1296,96346,25885,74798,256,25880,1344,21072]

theorem envBound54292 : H12AffineFastState.Bounded env54292 := by
  intro p hp
  have h : env54292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53977_54292 : H12AffineEnvironment.transform 18 21585 env53977 = env54292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env53977 == env54292) = true)

theorem identity54292 : scanCanonicalize (H12AffineFastState.compose env54292 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound54292 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env54293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4097,5277,91182,66897,28889,78894,328959,90414,1296,96346,25885,74798,256,25880,1344,21072]

theorem envBound54293 : H12AffineFastState.Bounded env54293 := by
  intro p hp
  have h : env54293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54292_54293 : H12AffineEnvironment.transform 14 25677 env54292 = env54293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env54292 == env54293) = true)

def env54294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4097,5277,74046,66897,13769,78894,328959,74814,1296,81226,8205,74798,256,8200,1344,5952]

theorem envBound54294 : H12AffineFastState.Bounded env54294 := by
  intro p hp
  have h : env54294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54293_54294 : H12AffineEnvironment.transform 13 1296 env54293 = env54294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env54293 == env54294) = true)

def env54295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4097,5277,74046,66897,13769,78894,1151,74814,1296,81226,8205,74798,256,8200,1344,5952]

theorem envBound54295 : H12AffineFastState.Bounded env54295 := by
  intro p hp
  have h : env54295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54294_54295 : H12AffineEnvironment.transform 17 65664 env54294 = env54295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54294 == env54295) = true)

theorem identity54295 : scanCanonicalize (H12AffineFastState.compose env54295 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound54295 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66678,65664,4417,325,4097,5277,65831,66897,5584,70711,1151,66599,1296,73043,20,66615,256,17,1344,5952]

theorem envBound54296 : H12AffineFastState.Bounded env54296 := by
  intro p hp
  have h : env54296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54295_54296 : H12AffineEnvironment.transform 12 25 env54295 = env54296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54295 == env54296) = true)

def env54297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,324,65536,66678,65664,1025,325,1345,477,65831,66897,144,65911,1151,66599,1296,67603,20,66615,256,17,1344,512]

theorem envBound54297 : H12AffineFastState.Bounded env54297 := by
  intro p hp
  have h : env54297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54296_54297 : H12AffineEnvironment.transform 11 1344 env54296 = env54297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env54296 == env54297) = true)

theorem identity54297 : scanCanonicalize (H12AffineFastState.compose env54297 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound54297 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,324,114,1028,242,1025,325,1345,477,341,1315,144,261,1151,1109,1296,2145,20,1093,256,17,1344,512]

theorem envBound54298 : H12AffineFastState.Bounded env54298 := by
  intro p hp
  have h : env54298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54297_54298 : H12AffineEnvironment.transform 15 114 env54297 = env54298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env54297 == env54298) = true)

theorem identity54298 : scanCanonicalize (H12AffineFastState.compose env54298 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54298 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54299 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,25,1029,81,114,1028,242,1025,80,1108,200,64,1078,144,16,1151,1109,1029,2145,20,1093,21,17,1109,512]

theorem envBound54299 : H12AffineFastState.Bounded env54299 := by
  intro p hp
  have h : env54299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54298_54299 : H12AffineEnvironment.transform 7 21 env54298 = env54299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54298 == env54299) = true)

theorem identity54299 : scanCanonicalize (H12AffineFastState.compose env54299 (packedSelected [0,1,2,7,8,10,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 246) := by decide +kernel

theorem selectedBound54299 : packedSelected [0,1,2,7,8,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54300 : List Nat := [2,4,8,16,32,64,128,21,512,246,2048,163,25,243,81,114,242,242,247,80,162,200,64,192,144,16,137,163,243,2145,20,179,21,17,163,512]

theorem envBound54300 : H12AffineFastState.Bounded env54300 := by
  intro p hp
  have h : env54300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54299_54300 : H12AffineEnvironment.transform 9 246 env54299 = env54300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 246 env54299 == env54300) = true)

theorem identity54300 : scanCanonicalize (H12AffineFastState.compose env54300 (packedSelected [0,2,3,5,7,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound54300 : packedSelected [0,2,3,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env54301 : List Nat := [2,4,8,16,32,64,128,21,512,246,755,163,25,243,81,114,242,242,247,80,162,200,64,192,144,16,137,163,243,658,20,179,21,17,163,512]

theorem envBound54301 : H12AffineFastState.Bounded env54301 := by
  intro p hp
  have h : env54301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54300_54301 : H12AffineEnvironment.transform 10 755 env54300 = env54301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env54300 == env54301) = true)

theorem identity54301 : scanCanonicalize (H12AffineFastState.compose env54301 (packedSelected [0,1,5,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 242) := by decide +kernel

theorem selectedBound54301 : packedSelected [0,1,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env54302 : List Nat := [2,4,8,16,32,64,128,21,242,246,1,163,25,243,81,114,242,242,247,80,162,200,64,192,144,16,137,163,243,96,20,179,21,17,163,242]

theorem envBound54302 : H12AffineFastState.Bounded env54302 := by
  intro p hp
  have h : env54302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54301_54302 : H12AffineEnvironment.transform 8 242 env54301 = env54302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 242 env54301 == env54302) = true)

theorem identity54302 : scanCanonicalize (H12AffineFastState.compose env54302 (packedSelected [0,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound54302 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env54303 : List Nat := [2,4,8,16,32,64,67,21,49,53,1,96,25,48,81,114,49,49,52,80,97,11,64,3,83,16,74,96,48,96,20,112,21,17,96,49]

theorem envBound54303 : H12AffineFastState.Bounded env54303 := by
  intro p hp
  have h : env54303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54302_54303 : H12AffineEnvironment.transform 6 67 env54302 = env54303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env54302 == env54303) = true)

theorem identity54303 : scanCanonicalize (H12AffineFastState.compose env54303 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound54303 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env54304 : List Nat := [2,4,8,16,32,32,35,21,49,53,1,0,25,48,49,18,49,49,52,48,1,11,32,3,51,16,42,0,48,0,20,16,21,17,0,49]

theorem envBound54304 : H12AffineFastState.Bounded env54304 := by
  intro p hp
  have h : env54304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54303_54304 : H12AffineEnvironment.transform 5 32 env54303 = env54304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env54303 == env54304) = true)

theorem identity54304 : scanCanonicalize (H12AffineFastState.compose env54304 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54305 : List Nat := [2,4,8,13,32,32,35,8,44,40,1,0,4,45,44,15,44,44,41,45,1,11,32,3,46,13,42,0,45,0,9,13,8,12,0,44]

theorem envBound54305 : H12AffineFastState.Bounded env54305 := by
  intro p hp
  have h : env54305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54304_54305 : H12AffineEnvironment.transform 3 13 env54304 = env54305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54304 == env54305) = true)

theorem identity54305 : scanCanonicalize (H12AffineFastState.compose env54305 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54305 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54306 : List Nat := [2,3,8,10,32,32,35,8,43,40,1,0,3,42,43,8,43,43,41,42,1,11,32,3,41,10,42,0,42,0,9,10,8,11,0,43]

theorem envBound54306 : H12AffineFastState.Bounded env54306 := by
  intro p hp
  have h : env54306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54305_54306 : H12AffineEnvironment.transform 1 3 env54305 = env54306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54305 == env54306) = true)

theorem identity54306 : scanCanonicalize (H12AffineFastState.compose env54306 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54306 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54307 : List Nat := [2,3,8,10,11,11,8,8,0,3,1,0,3,1,0,8,0,0,2,1,1,11,11,3,2,10,1,0,1,0,9,10,8,11,0,0]

theorem envBound54307 : H12AffineFastState.Bounded env54307 := by
  intro p hp
  have h : env54307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54306_54307 : H12AffineEnvironment.transform 4 11 env54306 = env54307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54306 == env54307) = true)

def env54308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,324,65536,66678,65664,1024,325,1344,476,65831,66897,145,65910,1151,66599,1296,67602,20,66615,256,17,1344,513]

theorem envBound54308 : H12AffineFastState.Bounded env54308 := by
  intro p hp
  have h : env54308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54296_54308 : H12AffineEnvironment.transform 11 1345 env54296 = env54308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env54296 == env54308) = true)

theorem identity54308 : scanCanonicalize (H12AffineFastState.compose env54308 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54308 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54309 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,25,1028,80,65536,66678,65664,1024,81,1108,200,65587,66629,145,65634,1151,66599,1028,67602,20,66615,20,17,1108,513]

theorem envBound54309 : H12AffineFastState.Bounded env54309 := by
  intro p hp
  have h : env54309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54308_54309 : H12AffineEnvironment.transform 7 20 env54308 = env54309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54308 == env54309) = true)

theorem identity54309 : scanCanonicalize (H12AffineFastState.compose env54309 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1143) := by decide +kernel

theorem selectedBound54309 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54310 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,25,1028,80,1143,1,1271,1024,81,1108,200,1092,50,145,1045,1151,80,1028,3173,20,64,20,17,1108,513]

theorem envBound54310 : H12AffineFastState.Bounded env54310 := by
  intro p hp
  have h : env54310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54309_54310 : H12AffineEnvironment.transform 15 1143 env54309 = env54310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1143 env54309 == env54310) = true)

theorem identity54310 : scanCanonicalize (H12AffineFastState.compose env54310 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound54310 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54311 : List Nat := [2,4,8,16,32,1,128,20,512,1024,2048,1044,25,1028,17,1078,1,1206,1024,16,1045,137,1029,50,145,1045,1086,17,1028,3108,20,1,20,17,1045,513]

theorem envBound54311 : H12AffineFastState.Bounded env54311 := by
  intro p hp
  have h : env54311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54310_54311 : H12AffineEnvironment.transform 5 1 env54310 = env54311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54310 == env54311) = true)

theorem identity54311 : scanCanonicalize (H12AffineFastState.compose env54311 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 669) := by decide +kernel

theorem selectedBound54311 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env54312 : List Nat := [2,4,8,16,32,1,128,20,512,669,2048,649,25,665,17,683,1,555,669,16,648,137,664,50,145,648,675,17,665,2745,20,1,20,17,648,513]

theorem envBound54312 : H12AffineFastState.Bounded env54312 := by
  intro p hp
  have h : env54312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54311_54312 : H12AffineEnvironment.transform 9 669 env54311 = env54312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 669 env54311 == env54312) = true)

theorem identity54312 : scanCanonicalize (H12AffineFastState.compose env54312 (packedSelected [1,2,3,5,12,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound54312 : packedSelected [1,2,3,5,12,13,17] rootPS < 2^1333 := by decide +kernel

def env54313 : List Nat := [2,4,8,16,32,1,128,20,13,144,2048,132,25,148,17,166,1,38,144,16,133,137,149,50,145,133,174,17,148,2228,20,1,20,17,133,12]

theorem envBound54313 : H12AffineFastState.Bounded env54313 := by
  intro p hp
  have h : env54313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54312_54313 : H12AffineEnvironment.transform 8 13 env54312 = env54313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env54312 == env54313) = true)

theorem identity54313 : scanCanonicalize (H12AffineFastState.compose env54313 (packedSelected [1,2,8,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound54313 : packedSelected [1,2,8,11,20] rootPS < 2^1333 := by decide +kernel

def env54314 : List Nat := [2,4,8,16,32,1,128,20,13,144,146,132,25,148,17,166,1,38,144,16,133,137,149,50,145,133,174,17,148,38,20,1,20,17,133,12]

theorem envBound54314 : H12AffineFastState.Bounded env54314 := by
  intro p hp
  have h : env54314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54313_54314 : H12AffineEnvironment.transform 10 146 env54313 = env54314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env54313 == env54314) = true)

theorem identity54314 : scanCanonicalize (H12AffineFastState.compose env54314 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound54314 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54315 : List Nat := [2,4,8,16,12,1,128,20,13,144,146,132,25,148,17,138,1,10,144,16,133,137,149,30,145,133,130,17,148,10,20,1,20,17,133,12]

theorem envBound54315 : H12AffineFastState.Bounded env54315 := by
  intro p hp
  have h : env54315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54314_54315 : H12AffineEnvironment.transform 4 12 env54314 = env54315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env54314 == env54315) = true)

theorem identity54315 : scanCanonicalize (H12AffineFastState.compose env54315 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54315 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54316 : List Nat := [2,4,4,16,0,1,128,20,1,144,146,132,21,148,17,134,1,6,144,16,133,133,149,18,145,133,130,17,148,6,20,1,20,17,133,0]

theorem envBound54316 : H12AffineFastState.Bounded env54316 := by
  intro p hp
  have h : env54316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54315_54316 : H12AffineEnvironment.transform 2 4 env54315 = env54316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54315 == env54316) = true)

theorem identity54316 : scanCanonicalize (H12AffineFastState.compose env54316 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound54316 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54317 : List Nat := [2,4,4,5,0,1,128,1,1,133,135,132,0,129,4,134,1,6,133,5,133,133,128,7,132,133,130,4,129,6,1,1,1,4,133,0]

theorem envBound54317 : H12AffineFastState.Bounded env54317 := by
  intro p hp
  have h : env54317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54316_54317 : H12AffineEnvironment.transform 3 5 env54316 = env54317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env54316 == env54317) = true)

theorem identity54317 : scanCanonicalize (H12AffineFastState.compose env54317 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound54317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54318 : List Nat := [2,4,4,5,0,1,5,1,1,0,2,1,0,4,4,3,1,6,0,5,0,0,5,7,1,0,7,4,4,6,1,1,1,4,0,0]

theorem envBound54318 : H12AffineFastState.Bounded env54318 := by
  intro p hp
  have h : env54318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54317_54318 : H12AffineEnvironment.transform 6 5 env54317 = env54318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env54317 == env54318) = true)

theorem identity54318 : scanCanonicalize (H12AffineFastState.compose env54318 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54318 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54319 : List Nat := [0,4,4,5,0,1,5,1,1,0,0,1,0,4,4,1,1,4,0,5,0,0,5,5,1,0,5,4,4,4,1,1,1,4,0,0]

theorem envBound54319 : H12AffineFastState.Bounded env54319 := by
  intro p hp
  have h : env54319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54318_54319 : H12AffineEnvironment.transform 0 0 env54318 = env54319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54318 == env54319) = true)

theorem identity54319 : scanCanonicalize (H12AffineFastState.compose env54319 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54320 : List Nat := [0,0,0,1,0,1,1,1,1,0,0,1,0,0,0,1,1,0,0,1,0,0,1,1,1,0,1,0,0,0,1,1,1,0,0,0]

theorem envBound54320 : H12AffineFastState.Bounded env54320 := by
  intro p hp
  have h : env54320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54319_54320 : H12AffineEnvironment.transform 1 0 env54319 = env54320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54319 == env54320) = true)

def env54321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4097,5277,74046,66897,13769,78894,1150,74814,1296,81226,8205,74798,256,8200,1344,5952]

theorem envBound54321 : H12AffineFastState.Bounded env54321 := by
  intro p hp
  have h : env54321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54294_54321 : H12AffineEnvironment.transform 17 65665 env54294 = env54321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54294 == env54321) = true)

theorem identity54321 : scanCanonicalize (H12AffineFastState.compose env54321 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound54321 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,65536,69943,65665,4417,5124,4097,5277,70758,66897,145,65910,1150,69990,1296,67602,5461,70006,256,5456,1344,5952]

theorem envBound54322 : H12AffineFastState.Bounded env54322 := by
  intro p hp
  have h : env54322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54321_54322 : H12AffineEnvironment.transform 12 5464 env54321 = env54322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env54321 == env54322) = true)

def env54323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1296,529,65536,67363,65665,1877,528,1557,649,66162,66897,145,65910,1150,67442,1296,67602,833,67426,256,836,1344,340]

theorem envBound54323 : H12AffineFastState.Bounded env54323 := by
  intro p hp
  have h : env54323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54322_54323 : H12AffineEnvironment.transform 11 1556 env54322 = env54323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env54322 == env54323) = true)

def env54324 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,65536,66163,65665,517,528,837,649,66162,65537,145,65910,302,66082,64,67602,833,66098,256,836,16,340]

theorem envBound54324 : H12AffineFastState.Bounded env54324 := by
  intro p hp
  have h : env54324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54323_54324 : H12AffineEnvironment.transform 9 336 env54323 = env54324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env54323 == env54324) = true)

theorem identity54324 : scanCanonicalize (H12AffineFastState.compose env54324 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 597) := by decide +kernel

theorem selectedBound54324 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54325 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,597,38,724,517,528,837,649,39,596,145,803,302,119,64,2631,833,103,256,836,16,340]

theorem envBound54325 : H12AffineFastState.Bounded env54325 := by
  intro p hp
  have h : env54325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54324_54325 : H12AffineEnvironment.transform 15 597 env54324 = env54325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 597 env54324 == env54325) = true)

def env54326 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,80,88,64,261,321,38,448,273,260,81,413,39,320,145,55,302,119,64,2387,85,103,256,80,16,340]

theorem envBound54326 : H12AffineFastState.Bounded env54326 := by
  intro p hp
  have h : env54326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54325_54326 : H12AffineEnvironment.transform 8 276 env54325 = env54326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54325 == env54326) = true)

theorem identity54326 : scanCanonicalize (H12AffineFastState.compose env54326 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound54326 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54327 : List Nat := [2,4,8,16,32,64,128,51,39,99,2048,80,88,64,54,114,38,243,34,55,81,174,39,115,145,55,29,119,64,2144,85,103,51,80,16,103]

theorem envBound54327 : H12AffineFastState.Bounded env54327 := by
  intro p hp
  have h : env54327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54326_54327 : H12AffineEnvironment.transform 7 51 env54326 = env54327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env54326 == env54327) = true)

theorem identity54327 : scanCanonicalize (H12AffineFastState.compose env54327 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound54327 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env54328 : List Nat := [2,4,8,16,32,64,47,51,39,99,2048,80,88,64,54,114,38,92,34,55,81,1,39,115,62,55,29,119,64,2144,85,103,51,80,16,103]

theorem envBound54328 : H12AffineFastState.Bounded env54328 := by
  intro p hp
  have h : env54328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54327_54328 : H12AffineEnvironment.transform 6 47 env54327 = env54328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env54327 == env54328) = true)

theorem identity54328 : scanCanonicalize (H12AffineFastState.compose env54328 (packedSelected [3,4,5,9,10,16] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54328 : packedSelected [3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env54329 : List Nat := [2,4,8,16,7,64,8,20,0,68,2048,80,88,64,17,85,1,92,5,16,81,1,0,84,25,16,29,80,64,2119,85,64,20,80,16,64]

theorem envBound54329 : H12AffineFastState.Bounded env54329 := by
  intro p hp
  have h : env54329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54328_54329 : H12AffineEnvironment.transform 4 7 env54328 = env54329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54328 == env54329) = true)

theorem identity54329 : scanCanonicalize (H12AffineFastState.compose env54329 (packedSelected [0,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound54329 : packedSelected [0,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54330 : List Nat := [2,4,8,16,7,64,8,20,0,68,7,80,88,64,17,85,1,92,5,16,81,1,0,84,25,16,29,80,64,64,85,64,20,80,16,64]

theorem envBound54330 : H12AffineFastState.Bounded env54330 := by
  intro p hp
  have h : env54330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54329_54330 : H12AffineEnvironment.transform 10 7 env54329 = env54330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env54329 == env54330) = true)

theorem identity54330 : scanCanonicalize (H12AffineFastState.compose env54330 (packedSelected [0,1,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54330 : packedSelected [0,1,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54331 : List Nat := [2,4,3,16,7,64,3,20,0,68,7,80,83,64,17,85,1,87,5,16,81,1,0,84,18,16,22,80,64,64,85,64,20,80,16,64]

theorem envBound54331 : H12AffineFastState.Bounded env54331 := by
  intro p hp
  have h : env54331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54330_54331 : H12AffineEnvironment.transform 2 3 env54330 = env54331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54330 == env54331) = true)

theorem identity54331 : scanCanonicalize (H12AffineFastState.compose env54331 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54331 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54332 : List Nat := [2,4,3,7,7,64,3,3,0,68,7,71,68,64,6,66,1,64,5,7,70,1,0,67,5,7,1,71,64,64,66,64,3,71,7,64]

theorem envBound54332 : H12AffineFastState.Bounded env54332 := by
  intro p hp
  have h : env54332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54331_54332 : H12AffineEnvironment.transform 3 7 env54331 = env54332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54331 == env54332) = true)

theorem identity54332 : scanCanonicalize (H12AffineFastState.compose env54332 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound54332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54333 : List Nat := [2,4,3,7,7,7,3,3,0,3,7,0,3,7,6,5,1,7,5,7,1,1,0,4,5,7,1,0,7,7,5,7,3,0,7,7]

theorem envBound54333 : H12AffineFastState.Bounded env54333 := by
  intro p hp
  have h : env54333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54332_54333 : H12AffineEnvironment.transform 5 7 env54332 = env54333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env54332 == env54333) = true)

theorem identity54333 : scanCanonicalize (H12AffineFastState.compose env54333 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54333 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54334 : List Nat := [2,3,3,0,0,0,3,3,0,3,0,0,3,0,1,2,1,0,2,0,1,1,0,3,2,0,1,0,0,0,2,0,3,0,0,0]

theorem envBound54334 : H12AffineFastState.Bounded env54334 := by
  intro p hp
  have h : env54334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54333_54334 : H12AffineEnvironment.transform 1 3 env54333 = env54334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54333 == env54334) = true)

def env54335 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,81,89,64,260,320,38,449,272,261,80,412,39,321,145,54,302,119,64,2386,84,103,256,81,16,340]

theorem envBound54335 : H12AffineFastState.Bounded env54335 := by
  intro p hp
  have h : env54335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54325_54335 : H12AffineEnvironment.transform 8 277 env54325 = env54335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54325 == env54335) = true)

theorem identity54335 : scanCanonicalize (H12AffineFastState.compose env54335 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound54335 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54336 : List Nat := [2,4,8,16,32,64,128,115,102,35,2048,81,89,64,119,51,38,178,99,118,80,239,39,50,145,54,93,119,64,2081,84,103,115,81,16,39]

theorem envBound54336 : H12AffineFastState.Bounded env54336 := by
  intro p hp
  have h : env54336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54335_54336 : H12AffineEnvironment.transform 7 115 env54335 = env54336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env54335 == env54336) = true)

theorem identity54336 : scanCanonicalize (H12AffineFastState.compose env54336 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54336 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env54337 : List Nat := [2,4,8,16,23,64,128,68,81,20,2048,81,89,64,64,4,17,133,84,65,80,216,16,5,145,1,93,64,64,2070,84,80,68,81,16,16]

theorem envBound54337 : H12AffineFastState.Bounded env54337 := by
  intro p hp
  have h : env54337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54336_54337 : H12AffineEnvironment.transform 4 23 env54336 = env54337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54336 == env54337) = true)

theorem identity54337 : scanCanonicalize (H12AffineFastState.compose env54337 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound54337 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env54338 : List Nat := [2,4,8,16,23,64,128,68,81,20,64,81,89,64,64,4,17,133,84,65,80,216,16,5,145,1,93,64,64,86,84,80,68,81,16,16]

theorem envBound54338 : H12AffineFastState.Bounded env54338 := by
  intro p hp
  have h : env54338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54337_54338 : H12AffineEnvironment.transform 10 64 env54337 = env54338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env54337 == env54338) = true)

theorem identity54338 : scanCanonicalize (H12AffineFastState.compose env54338 (packedSelected [2,3,5,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54338 : packedSelected [2,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54339 : List Nat := [2,4,8,6,1,64,128,68,71,2,64,71,79,64,64,4,7,133,66,65,70,206,6,5,135,1,75,64,64,64,66,70,68,71,6,6]

theorem envBound54339 : H12AffineFastState.Bounded env54339 := by
  intro p hp
  have h : env54339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54338_54339 : H12AffineEnvironment.transform 3 6 env54338 = env54339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54338 == env54339) = true)

theorem identity54339 : scanCanonicalize (H12AffineFastState.compose env54339 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54340 : List Nat := [2,2,8,0,1,64,128,66,65,2,64,65,73,64,64,2,1,131,66,65,64,200,0,3,129,1,75,64,64,64,66,64,66,65,0,0]

theorem envBound54340 : H12AffineFastState.Bounded env54340 := by
  intro p hp
  have h : env54340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54339_54340 : H12AffineEnvironment.transform 1 2 env54339 = env54340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54339 == env54340) = true)

theorem identity54340 : scanCanonicalize (H12AffineFastState.compose env54340 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54341 : List Nat := [2,2,3,0,1,64,128,66,65,2,64,65,66,64,64,2,1,131,66,65,64,195,0,3,129,1,64,64,64,64,66,64,66,65,0,0]

theorem envBound54341 : H12AffineFastState.Bounded env54341 := by
  intro p hp
  have h : env54341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54340_54341 : H12AffineEnvironment.transform 2 3 env54340 = env54341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54340 == env54341) = true)

theorem identity54341 : scanCanonicalize (H12AffineFastState.compose env54341 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound54341 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54342 : List Nat := [2,2,3,0,1,64,3,66,65,2,64,65,66,64,64,2,1,0,66,65,64,64,0,3,2,1,64,64,64,64,66,64,66,65,0,0]

theorem envBound54342 : H12AffineFastState.Bounded env54342 := by
  intro p hp
  have h : env54342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54341_54342 : H12AffineEnvironment.transform 6 3 env54341 = env54342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env54341 == env54342) = true)

theorem identity54342 : scanCanonicalize (H12AffineFastState.compose env54342 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54342 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54343 : List Nat := [2,2,3,0,1,0,3,2,1,2,0,1,2,0,0,2,1,0,2,1,0,0,0,3,2,1,0,0,0,0,2,0,2,1,0,0]

theorem envBound54343 : H12AffineFastState.Bounded env54343 := by
  intro p hp
  have h : env54343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54342_54343 : H12AffineEnvironment.transform 5 0 env54342 = env54343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54342 == env54343) = true)

theorem identity54343 : scanCanonicalize (H12AffineFastState.compose env54343 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54344 : List Nat := [0,0,1,0,1,0,1,0,1,0,0,1,0,0,0,0,1,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,1,0,0]

theorem envBound54344 : H12AffineFastState.Bounded env54344 := by
  intro p hp
  have h : env54344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54343_54344 : H12AffineEnvironment.transform 0 0 env54343 = env54344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54343 == env54344) = true)

def env54345 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,65536,66162,65665,516,528,836,649,66162,65536,145,65910,303,66083,65,67602,833,66099,256,836,17,340]

theorem envBound54345 : H12AffineFastState.Bounded env54345 := by
  intro p hp
  have h : env54345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54323_54345 : H12AffineEnvironment.transform 9 337 env54323 = env54345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env54323 == env54345) = true)

theorem identity54345 : scanCanonicalize (H12AffineFastState.compose env54345 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 321) := by decide +kernel

theorem selectedBound54345 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54346 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,321,819,448,516,528,836,649,819,321,145,55,303,866,65,2387,833,882,256,836,17,340]

theorem envBound54346 : H12AffineFastState.Bounded env54346 := by
  intro p hp
  have h : env54346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54345_54346 : H12AffineEnvironment.transform 15 321 env54345 = env54346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 321 env54345 == env54346) = true)

def env54347 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,81,88,65,261,321,39,448,272,260,80,413,39,321,145,55,303,118,65,2387,85,102,256,80,17,340]

theorem envBound54347 : H12AffineFastState.Bounded env54347 := by
  intro p hp
  have h : env54347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54346_54347 : H12AffineEnvironment.transform 8 276 env54346 = env54347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54346 == env54347) = true)

theorem identity54347 : scanCanonicalize (H12AffineFastState.compose env54347 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound54347 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54348 : List Nat := [2,4,8,16,32,64,128,115,103,34,2048,81,88,65,118,50,39,179,99,119,80,238,39,50,145,55,92,118,65,2080,85,102,115,80,17,39]

theorem envBound54348 : H12AffineFastState.Bounded env54348 := by
  intro p hp
  have h : env54348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54347_54348 : H12AffineEnvironment.transform 7 115 env54347 = env54348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env54347 == env54348) = true)

theorem identity54348 : scanCanonicalize (H12AffineFastState.compose env54348 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54348 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env54349 : List Nat := [2,4,8,16,23,64,128,68,80,21,2048,81,88,65,65,5,16,132,84,64,80,217,16,5,145,0,92,65,65,2071,85,81,68,80,17,16]

theorem envBound54349 : H12AffineFastState.Bounded env54349 := by
  intro p hp
  have h : env54349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54348_54349 : H12AffineEnvironment.transform 4 23 env54348 = env54349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54348 == env54349) = true)

theorem identity54349 : scanCanonicalize (H12AffineFastState.compose env54349 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound54349 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env54350 : List Nat := [2,4,8,16,23,64,128,68,80,21,65,81,88,65,65,5,16,132,84,64,80,217,16,5,145,0,92,65,65,86,85,81,68,80,17,16]

theorem envBound54350 : H12AffineFastState.Bounded env54350 := by
  intro p hp
  have h : env54350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54349_54350 : H12AffineEnvironment.transform 10 65 env54349 = env54350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env54349 == env54350) = true)

theorem identity54350 : scanCanonicalize (H12AffineFastState.compose env54350 (packedSelected [2,3,5,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54350 : packedSelected [2,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54351 : List Nat := [2,4,8,6,1,64,128,68,70,3,65,71,78,65,65,5,6,132,66,64,70,207,6,5,135,0,74,65,65,64,67,71,68,70,7,6]

theorem envBound54351 : H12AffineFastState.Bounded env54351 := by
  intro p hp
  have h : env54351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54350_54351 : H12AffineEnvironment.transform 3 6 env54350 = env54351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54350 == env54351) = true)

theorem identity54351 : scanCanonicalize (H12AffineFastState.compose env54351 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound54351 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54352 : List Nat := [2,4,8,6,1,1,128,5,7,3,0,6,15,0,0,5,6,132,3,1,7,142,6,5,135,0,11,0,0,1,2,6,5,7,7,6]

theorem envBound54352 : H12AffineFastState.Bounded env54352 := by
  intro p hp
  have h : env54352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54351_54352 : H12AffineEnvironment.transform 5 1 env54351 = env54352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54351 == env54352) = true)

theorem identity54352 : scanCanonicalize (H12AffineFastState.compose env54352 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound54352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54353 : List Nat := [2,4,8,6,1,1,10,5,7,3,0,6,15,0,0,5,6,14,3,1,7,4,6,5,13,0,11,0,0,1,2,6,5,7,7,6]

theorem envBound54353 : H12AffineFastState.Bounded env54353 := by
  intro p hp
  have h : env54353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54352_54353 : H12AffineEnvironment.transform 6 10 env54352 = env54353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env54352 == env54353) = true)

def env54354 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,80,89,65,260,321,38,448,273,261,81,412,38,321,145,55,303,119,65,2387,84,103,256,81,17,340]

theorem envBound54354 : H12AffineFastState.Bounded env54354 := by
  intro p hp
  have h : env54354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54346_54354 : H12AffineEnvironment.transform 8 277 env54346 = env54354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54346 == env54354) = true)

theorem identity54354 : scanCanonicalize (H12AffineFastState.compose env54354 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound54354 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54355 : List Nat := [2,4,8,16,32,64,128,51,38,98,2048,80,89,65,55,114,38,243,34,54,81,175,38,114,145,55,28,119,65,2144,84,103,51,81,17,103]

theorem envBound54355 : H12AffineFastState.Bounded env54355 := by
  intro p hp
  have h : env54355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54354_54355 : H12AffineEnvironment.transform 7 51 env54354 = env54355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env54354 == env54355) = true)

theorem identity54355 : scanCanonicalize (H12AffineFastState.compose env54355 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound54355 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env54356 : List Nat := [2,4,8,16,32,64,25,51,38,98,2048,80,89,65,55,114,38,106,34,54,81,54,38,114,8,55,28,119,65,2144,84,103,51,81,17,103]

theorem envBound54356 : H12AffineFastState.Bounded env54356 := by
  intro p hp
  have h : env54356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54355_54356 : H12AffineEnvironment.transform 6 25 env54355 = env54356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env54355 == env54356) = true)

theorem identity54356 : scanCanonicalize (H12AffineFastState.compose env54356 (packedSelected [2,3,5,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound54356 : packedSelected [2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env54357 : List Nat := [2,4,8,16,32,64,25,51,38,98,122,80,89,65,55,114,38,106,34,54,81,54,38,114,8,55,28,119,65,26,84,103,51,81,17,103]

theorem envBound54357 : H12AffineFastState.Bounded env54357 := by
  intro p hp
  have h : env54357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54356_54357 : H12AffineEnvironment.transform 10 122 env54356 = env54357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env54356 == env54357) = true)

theorem identity54357 : scanCanonicalize (H12AffineFastState.compose env54357 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54357 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54358 : List Nat := [2,4,8,16,1,64,25,18,7,67,91,80,89,65,22,83,7,75,3,23,81,23,7,83,8,22,28,86,65,26,84,70,18,81,17,70]

theorem envBound54358 : H12AffineFastState.Bounded env54358 := by
  intro p hp
  have h : env54358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54357_54358 : H12AffineEnvironment.transform 4 1 env54357 = env54358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54357 == env54358) = true)

theorem identity54358 : scanCanonicalize (H12AffineFastState.compose env54358 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound54358 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54359 : List Nat := [2,4,8,16,1,27,25,18,7,24,0,11,2,26,22,8,7,16,3,23,10,23,7,8,8,22,28,13,26,26,15,29,18,10,17,29]

theorem envBound54359 : H12AffineFastState.Bounded env54359 := by
  intro p hp
  have h : env54359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54358_54359 : H12AffineEnvironment.transform 5 27 env54358 = env54359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env54358 == env54359) = true)

def env54360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1296,528,65536,67362,65665,1876,529,1556,648,66163,66897,145,65910,1150,67443,1296,67602,832,67427,256,837,1344,341]

theorem envBound54360 : H12AffineFastState.Bounded env54360 := by
  intro p hp
  have h : env54360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54322_54360 : H12AffineEnvironment.transform 11 1557 env54322 = env54360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env54322 == env54360) = true)

def env54361 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,65536,66162,65665,516,529,836,648,66163,65537,145,65910,302,66083,64,67602,832,66099,256,837,16,341]

theorem envBound54361 : H12AffineFastState.Bounded env54361 := by
  intro p hp
  have h : env54361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54360_54361 : H12AffineEnvironment.transform 9 336 env54360 = env54361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env54360 == env54361) = true)

theorem identity54361 : scanCanonicalize (H12AffineFastState.compose env54361 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54361 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54362 : List Nat := [2,4,8,16,23,64,128,256,512,336,2048,837,845,64,528,65536,66117,65665,516,529,836,648,66116,65537,145,65857,281,66068,64,67602,832,66052,256,837,16,341]

theorem envBound54362 : H12AffineFastState.Bounded env54362 := by
  intro p hp
  have h : env54362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54361_54362 : H12AffineEnvironment.transform 4 23 env54361 = env54362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54361 == env54362) = true)

def env54363 : List Nat := [2,4,8,16,23,64,128,256,276,336,2048,81,89,64,260,65536,65873,65665,272,261,80,412,65872,65537,145,65857,281,65792,64,67602,84,65808,256,81,16,341]

theorem envBound54363 : H12AffineFastState.Bounded env54363 := by
  intro p hp
  have h : env54363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54362_54363 : H12AffineEnvironment.transform 8 276 env54362 = env54363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54362 == env54363) = true)

theorem identity54363 : scanCanonicalize (H12AffineFastState.compose env54363 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound54363 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54364 : List Nat := [2,4,8,16,23,64,128,256,276,336,2048,81,89,64,260,4,341,133,272,261,80,412,340,5,145,325,281,260,64,2070,84,276,256,81,16,341]

theorem envBound54364 : H12AffineFastState.Bounded env54364 := by
  intro p hp
  have h : env54364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54363_54364 : H12AffineEnvironment.transform 15 4 env54363 = env54364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env54363 == env54364) = true)

theorem identity54364 : scanCanonicalize (H12AffineFastState.compose env54364 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound54364 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env54365 : List Nat := [2,4,8,16,23,64,128,68,80,20,2048,81,89,64,64,4,17,133,84,65,80,216,16,5,145,1,93,64,64,2070,84,80,68,81,16,17]

theorem envBound54365 : H12AffineFastState.Bounded env54365 := by
  intro p hp
  have h : env54365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54364_54365 : H12AffineEnvironment.transform 7 68 env54364 = env54365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env54364 == env54365) = true)

theorem identity54365 : scanCanonicalize (H12AffineFastState.compose env54365 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound54365 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env54366 : List Nat := [2,4,8,16,23,64,128,68,80,20,64,81,89,64,64,4,17,133,84,65,80,216,16,5,145,1,93,64,64,86,84,80,68,81,16,17]

theorem envBound54366 : H12AffineFastState.Bounded env54366 := by
  intro p hp
  have h : env54366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54365_54366 : H12AffineEnvironment.transform 10 64 env54365 = env54366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env54365 == env54366) = true)

theorem identity54366 : scanCanonicalize (H12AffineFastState.compose env54366 (packedSelected [2,3,5,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54366 : packedSelected [2,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54367 : List Nat := [2,4,8,7,0,64,128,68,71,3,64,70,78,64,64,4,6,133,67,65,71,207,7,5,134,1,74,64,64,65,67,71,68,70,7,6]

theorem envBound54367 : H12AffineFastState.Bounded env54367 := by
  intro p hp
  have h : env54367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54366_54367 : H12AffineEnvironment.transform 3 7 env54366 = env54367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54366 == env54367) = true)

theorem identity54367 : scanCanonicalize (H12AffineFastState.compose env54367 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54368 : List Nat := [2,4,8,7,0,0,128,4,7,3,0,6,14,0,0,4,6,133,3,1,7,143,7,5,134,1,10,0,0,1,3,7,4,6,7,6]

theorem envBound54368 : H12AffineFastState.Bounded env54368 := by
  intro p hp
  have h : env54368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54367_54368 : H12AffineEnvironment.transform 5 0 env54367 = env54368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54367 == env54368) = true)

theorem identity54368 : scanCanonicalize (H12AffineFastState.compose env54368 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound54368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54369 : List Nat := [2,4,8,7,0,0,11,4,7,3,0,6,14,0,0,4,6,14,3,1,7,4,7,5,13,1,10,0,0,1,3,7,4,6,7,6]

theorem envBound54369 : H12AffineFastState.Bounded env54369 := by
  intro p hp
  have h : env54369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54368_54369 : H12AffineEnvironment.transform 6 11 env54368 = env54369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env54368 == env54369) = true)

def env54370 : List Nat := [2,4,8,16,23,64,128,256,277,336,2048,80,88,64,261,65536,65872,65665,273,260,81,413,65873,65537,145,65857,281,65793,64,67602,85,65809,256,80,16,341]

theorem envBound54370 : H12AffineFastState.Bounded env54370 := by
  intro p hp
  have h : env54370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54362_54370 : H12AffineEnvironment.transform 8 277 env54362 = env54370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54362 == env54370) = true)

theorem identity54370 : scanCanonicalize (H12AffineFastState.compose env54370 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound54370 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54371 : List Nat := [2,4,8,16,23,64,128,256,277,336,2048,80,88,64,261,69,277,196,273,260,81,413,276,68,145,260,281,324,64,2135,85,340,256,80,16,341]

theorem envBound54371 : H12AffineFastState.Bounded env54371 := by
  intro p hp
  have h : env54371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54370_54371 : H12AffineEnvironment.transform 15 69 env54370 = env54371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env54370 == env54371) = true)

theorem identity54371 : scanCanonicalize (H12AffineFastState.compose env54371 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54371 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env54372 : List Nat := [2,4,8,16,23,64,88,256,277,336,2048,80,88,64,261,69,277,28,273,260,81,325,276,68,73,260,281,324,64,2135,85,340,256,80,16,341]

theorem envBound54372 : H12AffineFastState.Bounded env54372 := by
  intro p hp
  have h : env54372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54371_54372 : H12AffineEnvironment.transform 6 88 env54371 = env54372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54371 == env54372) = true)

theorem identity54372 : scanCanonicalize (H12AffineFastState.compose env54372 (packedSelected [2,4,9,10,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound54372 : packedSelected [2,4,9,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env54373 : List Nat := [2,4,8,16,23,64,88,256,277,336,28,80,88,64,261,69,277,28,273,260,81,325,276,68,73,260,281,324,64,75,85,340,256,80,16,341]

theorem envBound54373 : H12AffineFastState.Bounded env54373 := by
  intro p hp
  have h : env54373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54372_54373 : H12AffineEnvironment.transform 10 28 env54372 = env54373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env54372 == env54373) = true)

theorem identity54373 : scanCanonicalize (H12AffineFastState.compose env54373 (packedSelected [0,1,2,4,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54373 : packedSelected [0,1,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env54374 : List Nat := [2,4,8,1,6,64,73,256,260,321,13,65,73,64,261,69,260,13,256,260,64,325,261,68,73,260,264,324,64,75,68,325,256,65,1,324]

theorem envBound54374 : H12AffineFastState.Bounded env54374 := by
  intro p hp
  have h : env54374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54373_54374 : H12AffineEnvironment.transform 3 1 env54373 = env54374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54373 == env54374) = true)

theorem identity54374 : scanCanonicalize (H12AffineFastState.compose env54374 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound54374 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env54375 : List Nat := [2,4,8,1,6,13,4,256,260,268,13,12,4,13,261,8,260,13,256,260,13,264,261,9,4,260,264,265,13,6,9,264,256,12,1,265]

theorem envBound54375 : H12AffineFastState.Bounded env54375 := by
  intro p hp
  have h : env54375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54374_54375 : H12AffineEnvironment.transform 5 13 env54374 = env54375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env54374 == env54375) = true)

theorem identity54375 : scanCanonicalize (H12AffineFastState.compose env54375 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54376 : List Nat := [2,3,8,1,1,10,3,256,259,267,10,11,3,10,258,8,259,10,256,259,10,264,258,9,3,259,264,265,10,1,9,264,256,11,1,265]

theorem envBound54376 : H12AffineFastState.Bounded env54376 := by
  intro p hp
  have h : env54376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54375_54376 : H12AffineEnvironment.transform 1 3 env54375 = env54376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54375 == env54376) = true)

theorem identity54376 : scanCanonicalize (H12AffineFastState.compose env54376 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound54376 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54377 : List Nat := [2,3,8,1,1,10,3,9,10,2,10,11,3,10,11,8,10,10,9,10,10,1,11,9,3,10,1,0,10,1,9,1,9,11,1,0]

theorem envBound54377 : H12AffineFastState.Bounded env54377 := by
  intro p hp
  have h : env54377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54376_54377 : H12AffineEnvironment.transform 7 9 env54376 = env54377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env54376 == env54377) = true)

theorem identity54377 : scanCanonicalize (H12AffineFastState.compose env54377 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54378 : List Nat := [2,3,2,1,1,0,3,3,0,2,0,1,3,0,1,2,0,0,3,0,0,1,1,3,3,0,1,0,0,1,3,1,3,1,1,0]

theorem envBound54378 : H12AffineFastState.Bounded env54378 := by
  intro p hp
  have h : env54378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54377_54378 : H12AffineEnvironment.transform 2 2 env54377 = env54378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54377 == env54378) = true)

def env54379 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,65536,66163,65665,517,529,837,648,66163,65536,145,65910,303,66082,65,67602,832,66098,256,837,17,341]

theorem envBound54379 : H12AffineFastState.Bounded env54379 := by
  intro p hp
  have h : env54379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54360_54379 : H12AffineEnvironment.transform 9 337 env54360 = env54379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env54360 == env54379) = true)

theorem identity54379 : scanCanonicalize (H12AffineFastState.compose env54379 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 290) := by decide +kernel

theorem selectedBound54379 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54380 : List Nat := [2,4,8,16,32,64,128,256,290,337,2048,102,111,65,306,65536,65873,65665,295,307,103,426,65873,65536,145,65910,303,65792,65,67602,98,65808,256,103,17,341]

theorem envBound54380 : H12AffineFastState.Bounded env54380 := by
  intro p hp
  have h : env54380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54379_54380 : H12AffineEnvironment.transform 8 290 env54379 = env54380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 290 env54379 == env54380) = true)

def env54381 : List Nat := [2,4,8,16,28,64,128,256,286,337,2048,90,83,65,270,65536,65873,65665,283,271,91,406,65873,65536,145,65866,275,65792,65,67602,94,65808,256,91,17,341]

theorem envBound54381 : H12AffineFastState.Bounded env54381 := by
  intro p hp
  have h : env54381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54380_54381 : H12AffineEnvironment.transform 4 28 env54380 = env54381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env54380 == env54381) = true)

theorem identity54381 : scanCanonicalize (H12AffineFastState.compose env54381 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 212) := by decide +kernel

theorem selectedBound54381 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env54382 : List Nat := [2,4,8,16,28,64,128,256,286,337,212,90,83,65,270,65536,65873,65665,283,271,91,406,65873,65536,145,65866,275,65792,65,65734,94,65808,256,91,17,341]

theorem envBound54382 : H12AffineFastState.Bounded env54382 := by
  intro p hp
  have h : env54382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54381_54382 : H12AffineEnvironment.transform 10 212 env54381 = env54382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 212 env54381 == env54382) = true)

theorem identity54382 : scanCanonicalize (H12AffineFastState.compose env54382 (packedSelected [0,1,2,3,5,7,8,11,15,18,20] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54382 : packedSelected [0,1,2,3,5,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env54383 : List Nat := [2,4,2,16,22,64,128,256,276,337,212,80,83,65,260,65536,65873,65665,273,261,81,406,65873,65536,145,65856,275,65792,65,65734,84,65808,256,81,17,341]

theorem envBound54383 : H12AffineFastState.Bounded env54383 := by
  intro p hp
  have h : env54383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54382_54383 : H12AffineEnvironment.transform 2 2 env54382 = env54383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54382 == env54383) = true)

theorem identity54383 : scanCanonicalize (H12AffineFastState.compose env54383 (packedSelected [1,2,7,8,9,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 405) := by decide +kernel

theorem selectedBound54383 : packedSelected [1,2,7,8,9,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54384 : List Nat := [2,4,2,16,22,64,128,256,276,337,212,80,83,65,260,405,196,276,273,261,81,406,196,405,145,213,275,149,65,339,84,133,256,81,17,341]

theorem envBound54384 : H12AffineFastState.Bounded env54384 := by
  intro p hp
  have h : env54384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54383_54384 : H12AffineEnvironment.transform 15 405 env54383 = env54384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 405 env54383 == env54384) = true)

theorem identity54384 : scanCanonicalize (H12AffineFastState.compose env54384 (packedSelected [2,5,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound54384 : packedSelected [2,5,11] rootPS < 2^1333 := by decide +kernel

def env54385 : List Nat := [2,4,2,16,22,64,128,68,80,21,212,80,83,65,64,209,196,80,85,65,81,210,196,209,145,213,87,149,65,23,84,133,68,81,17,17]

theorem envBound54385 : H12AffineFastState.Bounded env54385 := by
  intro p hp
  have h : env54385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54384_54385 : H12AffineEnvironment.transform 7 68 env54384 = env54385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env54384 == env54385) = true)

theorem identity54385 : scanCanonicalize (H12AffineFastState.compose env54385 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54385 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54386 : List Nat := [2,2,2,16,16,64,128,66,80,19,210,80,83,65,64,209,194,80,83,65,81,210,194,209,145,211,81,147,65,17,82,131,66,81,17,17]

theorem envBound54386 : H12AffineFastState.Bounded env54386 := by
  intro p hp
  have h : env54386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54385_54386 : H12AffineEnvironment.transform 1 2 env54385 = env54386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54385 == env54386) = true)

theorem identity54386 : scanCanonicalize (H12AffineFastState.compose env54386 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound54386 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54387 : List Nat := [2,2,2,16,16,64,83,66,80,19,1,80,83,65,64,2,17,80,83,65,81,1,17,2,66,0,81,64,65,17,82,80,66,81,17,17]

theorem envBound54387 : H12AffineFastState.Bounded env54387 := by
  intro p hp
  have h : env54387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54386_54387 : H12AffineEnvironment.transform 6 83 env54386 = env54387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env54386 == env54387) = true)

theorem identity54387 : scanCanonicalize (H12AffineFastState.compose env54387 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound54387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54388 : List Nat := [2,2,2,16,16,1,18,3,17,19,1,17,18,0,1,2,17,17,18,0,16,1,17,2,3,0,16,1,0,17,19,17,3,16,17,17]

theorem envBound54388 : H12AffineFastState.Bounded env54388 := by
  intro p hp
  have h : env54388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54387_54388 : H12AffineEnvironment.transform 5 1 env54387 = env54388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54387 == env54388) = true)

theorem identity54388 : scanCanonicalize (H12AffineFastState.compose env54388 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54389 : List Nat := [2,2,2,1,1,1,3,3,0,2,1,0,3,0,1,2,0,0,3,0,1,1,0,2,3,0,1,1,0,0,2,0,3,1,0,0]

theorem envBound54389 : H12AffineFastState.Bounded env54389 := by
  intro p hp
  have h : env54389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54388_54389 : H12AffineEnvironment.transform 3 1 env54388 = env54389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54388 == env54389) = true)

def env54390 : List Nat := [2,4,8,16,29,64,128,256,287,337,2048,91,82,65,271,65536,65873,65665,282,270,90,407,65873,65536,145,65867,274,65792,65,67602,95,65808,256,90,17,341]

theorem envBound54390 : H12AffineFastState.Bounded env54390 := by
  intro p hp
  have h : env54390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54380_54390 : H12AffineEnvironment.transform 4 29 env54380 = env54390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env54380 == env54390) = true)

theorem identity54390 : scanCanonicalize (H12AffineFastState.compose env54390 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 222) := by decide +kernel

theorem selectedBound54390 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env54391 : List Nat := [2,4,8,16,29,64,128,256,287,337,222,91,82,65,271,65536,65873,65665,282,270,90,407,65873,65536,145,65867,274,65792,65,65740,95,65808,256,90,17,341]

theorem envBound54391 : H12AffineFastState.Bounded env54391 := by
  intro p hp
  have h : env54391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54390_54391 : H12AffineEnvironment.transform 10 222 env54390 = env54391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 222 env54390 == env54391) = true)

theorem identity54391 : scanCanonicalize (H12AffineFastState.compose env54391 (packedSelected [3,8,10,15,16,18,20,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound54391 : packedSelected [3,8,10,15,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54392 : List Nat := [2,4,8,16,29,64,128,69,90,20,222,91,82,65,74,65536,65556,65665,95,75,90,210,65556,65536,145,65550,87,65605,65,65740,95,65621,69,90,17,16]

theorem envBound54392 : H12AffineFastState.Bounded env54392 := by
  intro p hp
  have h : env54392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54391_54392 : H12AffineEnvironment.transform 7 69 env54391 = env54392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env54391 == env54392) = true)

theorem identity54392 : scanCanonicalize (H12AffineFastState.compose env54392 (packedSelected [0,2,4,5,10,11,12,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54392 : packedSelected [0,2,4,5,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env54393 : List Nat := [2,2,8,16,27,64,128,67,90,18,216,91,82,65,74,65536,65554,65665,89,75,90,210,65554,65536,145,65544,81,65603,65,65738,89,65619,67,90,17,16]

theorem envBound54393 : H12AffineFastState.Bounded env54393 := by
  intro p hp
  have h : env54393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54392_54393 : H12AffineEnvironment.transform 1 2 env54392 = env54393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54392 == env54393) = true)

theorem identity54393 : scanCanonicalize (H12AffineFastState.compose env54393 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54393 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env54394 : List Nat := [2,2,8,0,11,64,128,67,74,2,200,75,66,65,74,65536,65538,65665,73,75,74,194,65538,65536,129,65544,65,65603,65,65738,73,65603,67,74,1,0]

theorem envBound54394 : H12AffineFastState.Bounded env54394 := by
  intro p hp
  have h : env54394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54393_54394 : H12AffineEnvironment.transform 3 0 env54393 = env54394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54393 == env54394) = true)

theorem identity54394 : scanCanonicalize (H12AffineFastState.compose env54394 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound54394 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54395 : List Nat := [2,2,8,0,11,64,128,67,74,2,200,75,66,65,74,129,131,0,73,75,74,194,131,129,129,137,65,194,65,75,73,194,67,74,1,0]

theorem envBound54395 : H12AffineFastState.Bounded env54395 := by
  intro p hp
  have h : env54395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54394_54395 : H12AffineEnvironment.transform 15 129 env54394 = env54395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env54394 == env54395) = true)

theorem identity54395 : scanCanonicalize (H12AffineFastState.compose env54395 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound54395 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54396 : List Nat := [2,2,8,0,11,1,128,2,11,2,137,10,3,0,11,129,131,0,8,10,11,131,131,129,129,137,0,131,0,10,8,131,2,11,1,0]

theorem envBound54396 : H12AffineFastState.Bounded env54396 := by
  intro p hp
  have h : env54396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54395_54396 : H12AffineEnvironment.transform 5 1 env54395 = env54396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54395 == env54396) = true)

theorem identity54396 : scanCanonicalize (H12AffineFastState.compose env54396 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound54396 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54397 : List Nat := [2,2,8,0,11,1,3,2,11,2,10,10,3,0,11,2,0,0,8,10,11,0,0,2,2,10,0,0,0,10,8,0,2,11,1,0]

theorem envBound54397 : H12AffineFastState.Bounded env54397 := by
  intro p hp
  have h : env54397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54396_54397 : H12AffineEnvironment.transform 6 3 env54396 = env54397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env54396 == env54397) = true)

theorem identity54397 : scanCanonicalize (H12AffineFastState.compose env54397 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54398 : List Nat := [2,2,2,0,1,1,3,2,1,2,0,0,3,0,1,2,0,0,2,0,1,0,0,2,2,0,0,0,0,0,2,0,2,1,1,0]

theorem envBound54398 : H12AffineFastState.Bounded env54398 := by
  intro p hp
  have h : env54398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54397_54398 : H12AffineEnvironment.transform 2 2 env54397 = env54398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54397 == env54398) = true)

theorem identity54398 : scanCanonicalize (H12AffineFastState.compose env54398 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54399 : List Nat := [1,1,1,0,1,1,0,1,1,1,0,0,0,0,1,1,0,0,1,0,1,0,0,1,1,0,0,0,0,0,1,0,1,1,1,0]

theorem envBound54399 : H12AffineFastState.Bounded env54399 := by
  intro p hp
  have h : env54399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54398_54399 : H12AffineEnvironment.transform 0 1 env54398 = env54399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54398 == env54399) = true)

def env54400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4097,5277,74047,66897,13768,78894,328959,74815,1296,81227,8204,74798,256,8201,1344,5953]

theorem envBound54400 : H12AffineFastState.Bounded env54400 := by
  intro p hp
  have h : env54400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54293_54400 : H12AffineEnvironment.transform 13 1297 env54293 = env54400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env54293 == env54400) = true)

def env54401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4097,5277,74047,66897,13768,78894,1151,74815,1296,81227,8204,74798,256,8201,1344,5953]

theorem envBound54401 : H12AffineFastState.Bounded env54401 := by
  intro p hp
  have h : env54401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54400_54401 : H12AffineEnvironment.transform 17 65664 env54400 = env54401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54400 == env54401) = true)

theorem identity54401 : scanCanonicalize (H12AffineFastState.compose env54401 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound54401 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74863,65664,272,8541,81,1229,74047,66897,9624,74878,1151,74815,1296,77083,8204,74798,256,8201,1344,1809]

theorem envBound54402 : H12AffineFastState.Bounded env54402 := by
  intro p hp
  have h : env54402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54401_54402 : H12AffineEnvironment.transform 11 80 env54401 = env54402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54401 == env54402) = true)

def env54403 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74031,65664,272,8541,81,397,74047,65553,8408,74046,319,74111,80,75867,8204,74094,256,8201,0,593]

theorem envBound54403 : H12AffineFastState.Bounded env54403 := by
  intro p hp
  have h : env54403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54402_54403 : H12AffineEnvironment.transform 9 320 env54402 = env54403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env54402 == env54403) = true)

theorem identity54403 : scanCanonicalize (H12AffineFastState.compose env54403 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound54403 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env54404 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,34,8461,162,272,8541,81,397,8477,51,8408,8476,319,8541,80,10361,8204,8524,256,8201,0,593]

theorem envBound54404 : H12AffineFastState.Bounded env54404 := by
  intro p hp
  have h : env54404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54403_54404 : H12AffineEnvironment.transform 15 34 env54403 = env54404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env54403 == env54404) = true)

theorem identity54404 : scanCanonicalize (H12AffineFastState.compose env54404 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54404 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env54405 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,348,81,0,34,81,162,272,1,81,397,65,51,388,64,319,1,80,2341,336,16,256,341,0,593]

theorem envBound54405 : H12AffineFastState.Bounded env54405 := by
  intro p hp
  have h : env54405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54404_54405 : H12AffineEnvironment.transform 12 348 env54404 = env54405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54404 == env54405) = true)

theorem identity54405 : scanCanonicalize (H12AffineFastState.compose env54405 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54405 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54406 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,0,0,34,0,162,272,1,0,397,16,51,388,17,319,1,1,2341,257,16,256,260,0,512]

theorem envBound54406 : H12AffineFastState.Bounded env54406 := by
  intro p hp
  have h : env54406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54405_54406 : H12AffineEnvironment.transform 5 17 env54405 = env54406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54405 == env54406) = true)

theorem identity54406 : scanCanonicalize (H12AffineFastState.compose env54406 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound54406 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54407 : List Nat := [2,4,8,16,32,17,128,134,512,151,2048,1,139,0,0,34,0,162,150,1,0,11,16,51,2,17,185,1,1,2211,135,16,134,130,0,512]

theorem envBound54407 : H12AffineFastState.Bounded env54407 := by
  intro p hp
  have h : env54407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54406_54407 : H12AffineEnvironment.transform 7 134 env54406 = env54407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env54406 == env54407) = true)

theorem identity54407 : scanCanonicalize (H12AffineFastState.compose env54407 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound54407 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env54408 : List Nat := [2,4,8,16,32,17,128,134,26,151,2048,1,139,0,0,34,0,162,150,1,0,11,16,51,2,17,185,1,1,2211,135,16,134,130,0,26]

theorem envBound54408 : H12AffineFastState.Bounded env54408 := by
  intro p hp
  have h : env54408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54407_54408 : H12AffineEnvironment.transform 8 26 env54407 = env54408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env54407 == env54408) = true)

theorem identity54408 : scanCanonicalize (H12AffineFastState.compose env54408 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound54408 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env54409 : List Nat := [2,4,8,16,32,17,128,134,26,151,163,1,139,0,0,34,0,162,150,1,0,11,16,51,2,17,185,1,1,0,135,16,134,130,0,26]

theorem envBound54409 : H12AffineFastState.Bounded env54409 := by
  intro p hp
  have h : env54409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54408_54409 : H12AffineEnvironment.transform 10 163 env54408 = env54409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env54408 == env54409) = true)

theorem identity54409 : scanCanonicalize (H12AffineFastState.compose env54409 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound54409 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env54410 : List Nat := [2,4,8,16,32,17,34,36,26,53,1,1,41,0,0,34,0,0,52,1,0,11,16,51,2,17,27,1,1,0,37,16,36,32,0,26]

theorem envBound54410 : H12AffineFastState.Bounded env54410 := by
  intro p hp
  have h : env54410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54409_54410 : H12AffineEnvironment.transform 6 34 env54409 = env54410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env54409 == env54410) = true)

theorem identity54410 : scanCanonicalize (H12AffineFastState.compose env54410 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54410 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env54411 : List Nat := [2,4,8,16,10,17,8,14,26,31,1,1,3,0,0,8,0,0,30,1,0,11,16,25,2,17,27,1,1,0,15,16,14,10,0,26]

theorem envBound54411 : H12AffineFastState.Bounded env54411 := by
  intro p hp
  have h : env54411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54410_54411 : H12AffineEnvironment.transform 4 10 env54410 = env54411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54410 == env54411) = true)

theorem identity54411 : scanCanonicalize (H12AffineFastState.compose env54411 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54411 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54412 : List Nat := [2,4,8,10,10,11,8,14,0,5,1,1,3,0,0,8,0,0,4,1,0,11,10,3,2,11,1,1,1,0,15,10,14,10,0,0]

theorem envBound54412 : H12AffineFastState.Bounded env54412 := by
  intro p hp
  have h : env54412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54411_54412 : H12AffineEnvironment.transform 3 10 env54411 = env54412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54411 == env54412) = true)

theorem identity54412 : scanCanonicalize (H12AffineFastState.compose env54412 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54413 : List Nat := [2,4,4,6,6,7,4,2,0,5,1,1,3,0,0,4,0,0,4,1,0,7,6,3,2,7,1,1,1,0,3,6,2,6,0,0]

theorem envBound54413 : H12AffineFastState.Bounded env54413 := by
  intro p hp
  have h : env54413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54412_54413 : H12AffineEnvironment.transform 2 4 env54412 = env54413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54412 == env54413) = true)

def env54414 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74030,65664,272,8541,81,396,74047,65552,8409,74047,318,74110,81,75866,8204,74095,256,8201,1,592]

theorem envBound54414 : H12AffineFastState.Bounded env54414 := by
  intro p hp
  have h : env54414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54402_54414 : H12AffineEnvironment.transform 9 321 env54402 = env54414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env54402 == env54414) = true)

theorem identity54414 : scanCanonicalize (H12AffineFastState.compose env54414 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound54414 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env54415 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,115,8541,243,272,8541,81,396,8524,99,8409,8524,318,8461,81,10281,8204,8476,256,8201,1,592]

theorem envBound54415 : H12AffineFastState.Bounded env54415 := by
  intro p hp
  have h : env54415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54414_54415 : H12AffineEnvironment.transform 15 115 env54414 = env54415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env54414 == env54415) = true)

theorem identity54415 : scanCanonicalize (H12AffineFastState.compose env54415 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54415 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54416 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,349,80,1,115,0,243,272,0,81,396,17,99,388,17,318,80,81,2420,337,65,256,340,1,592]

theorem envBound54416 : H12AffineFastState.Bounded env54416 := by
  intro p hp
  have h : env54416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54415_54416 : H12AffineEnvironment.transform 12 349 env54415 = env54416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54415 == env54416) = true)

theorem identity54416 : scanCanonicalize (H12AffineFastState.compose env54416 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54416 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54417 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,0,1,35,0,163,272,0,1,396,17,51,388,17,318,0,1,2340,257,17,256,260,1,512]

theorem envBound54417 : H12AffineFastState.Bounded env54417 := by
  intro p hp
  have h : env54417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54416_54417 : H12AffineEnvironment.transform 5 16 env54416 = env54417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54416 == env54417) = true)

theorem identity54417 : scanCanonicalize (H12AffineFastState.compose env54417 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 925) := by decide +kernel

theorem selectedBound54417 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54418 : List Nat := [2,4,8,16,32,16,128,256,512,273,925,0,269,0,1,35,0,163,272,0,1,396,17,51,388,17,318,0,1,697,257,17,256,260,1,512]

theorem envBound54418 : H12AffineFastState.Bounded env54418 := by
  intro p hp
  have h : env54418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54417_54418 : H12AffineEnvironment.transform 10 925 env54417 = env54418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 925 env54417 == env54418) = true)

theorem identity54418 : scanCanonicalize (H12AffineFastState.compose env54418 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound54418 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env54419 : List Nat := [2,4,8,16,32,16,128,256,292,273,185,0,269,0,1,35,0,163,272,0,1,396,17,51,388,17,318,0,1,413,257,17,256,260,1,292]

theorem envBound54419 : H12AffineFastState.Bounded env54419 := by
  intro p hp
  have h : env54419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54418_54419 : H12AffineEnvironment.transform 8 292 env54418 = env54419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env54418 == env54419) = true)

theorem identity54419 : scanCanonicalize (H12AffineFastState.compose env54419 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound54419 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env54420 : List Nat := [2,4,8,16,32,16,128,173,137,188,185,0,160,0,1,35,0,163,189,0,1,33,17,51,41,17,147,0,1,48,172,17,173,169,1,137]

theorem envBound54420 : H12AffineFastState.Bounded env54420 := by
  intro p hp
  have h : env54420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54419_54420 : H12AffineEnvironment.transform 7 173 env54419 = env54420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54419 == env54420) = true)

theorem identity54420 : scanCanonicalize (H12AffineFastState.compose env54420 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54421 : List Nat := [2,4,8,16,32,16,8,37,1,52,49,0,40,0,1,35,0,43,53,0,1,33,17,51,41,17,27,0,1,48,36,17,37,33,1,1]

theorem envBound54421 : H12AffineFastState.Bounded env54421 := by
  intro p hp
  have h : env54421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54420_54421 : H12AffineEnvironment.transform 6 8 env54420 = env54421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54420 == env54421) = true)

theorem identity54421 : scanCanonicalize (H12AffineFastState.compose env54421 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54421 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54422 : List Nat := [2,4,8,16,17,16,8,20,1,5,0,0,25,0,1,18,0,26,4,0,1,16,17,2,24,17,27,0,1,1,21,17,20,16,1,1]

theorem envBound54422 : H12AffineFastState.Bounded env54422 := by
  intro p hp
  have h : env54422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54421_54422 : H12AffineEnvironment.transform 4 17 env54421 = env54422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54421 == env54422) = true)

theorem identity54422 : scanCanonicalize (H12AffineFastState.compose env54422 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54423 : List Nat := [2,4,8,13,12,13,8,9,1,5,0,0,4,0,1,15,0,7,4,0,1,13,12,2,5,12,6,0,1,1,8,12,9,13,1,1]

theorem envBound54423 : H12AffineFastState.Bounded env54423 := by
  intro p hp
  have h : env54423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54422_54423 : H12AffineEnvironment.transform 3 13 env54422 = env54423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54422 == env54423) = true)

def env54424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4097,5277,74047,66897,13768,78894,1150,74815,1296,81227,8204,74798,256,8201,1344,5953]

theorem envBound54424 : H12AffineFastState.Bounded env54424 := by
  intro p hp
  have h : env54424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54400_54424 : H12AffineEnvironment.transform 17 65665 env54400 = env54424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54400 == env54424) = true)

theorem identity54424 : scanCanonicalize (H12AffineFastState.compose env54424 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54424 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54425 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,65536,74111,65665,4416,8541,4097,4493,74047,65601,12504,78142,366,74031,0,79963,8204,74046,256,8201,80,4689]

theorem envBound54425 : H12AffineFastState.Bounded env54425 := by
  intro p hp
  have h : env54425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54424_54425 : H12AffineEnvironment.transform 9 272 env54424 = env54425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54424 == env54425) = true)

def env54426 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,1,8540,65536,74111,65665,580,8541,773,649,74047,65601,9180,74298,366,74031,0,76639,8204,74046,256,8201,80,341]

theorem envBound54426 : H12AffineFastState.Bounded env54426 := by
  intro p hp
  have h : env54426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54425_54426 : H12AffineEnvironment.transform 11 772 env54425 = env54426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env54425 == env54426) = true)

def env54427 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,65536,74047,65665,516,8477,773,649,74047,65537,9116,74298,302,74031,0,76575,8204,74046,256,8201,16,277]

theorem envBound54427 : H12AffineFastState.Bounded env54427 := by
  intro p hp
  have h : env54427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54426_54427 : H12AffineEnvironment.transform 5 0 env54426 = env54427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54426 == env54427) = true)

theorem identity54427 : scanCanonicalize (H12AffineFastState.compose env54427 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound54427 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54428 : List Nat := [2,4,8,16,32,0,128,256,190,272,2048,442,8192,1,8476,65536,74047,65665,186,8477,443,55,74047,65537,8482,73860,302,74031,0,76193,8204,74046,256,8201,16,277]

theorem envBound54428 : H12AffineFastState.Bounded env54428 := by
  intro p hp
  have h : env54428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54427_54428 : H12AffineEnvironment.transform 8 190 env54427 = env54428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env54427 == env54428) = true)

def env54429 : List Nat := [2,4,8,16,32,0,128,256,190,272,2048,442,24,1,260,65536,65831,65665,186,261,443,55,65831,65537,314,65692,302,65847,0,68025,20,65830,256,17,16,277]

theorem envBound54429 : H12AffineFastState.Bounded env54429 := by
  intro p hp
  have h : env54429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54428_54429 : H12AffineEnvironment.transform 12 24 env54428 = env54429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env54428 == env54429) = true)

theorem identity54429 : scanCanonicalize (H12AffineFastState.compose env54429 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 408) := by decide +kernel

theorem selectedBound54429 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54430 : List Nat := [2,4,8,16,32,0,128,256,190,272,2048,442,24,1,260,408,191,281,186,261,443,55,191,409,314,260,302,175,0,2081,20,190,256,17,16,277]

theorem envBound54430 : H12AffineFastState.Bounded env54430 := by
  intro p hp
  have h : env54430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54429_54430 : H12AffineEnvironment.transform 15 408 env54429 = env54430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 408 env54429 == env54430) = true)

theorem identity54430 : scanCanonicalize (H12AffineFastState.compose env54430 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound54430 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env54431 : List Nat := [2,4,8,16,32,0,35,256,29,272,2048,281,24,1,260,315,28,281,25,261,280,55,28,314,314,260,302,12,0,2081,20,29,256,17,16,277]

theorem envBound54431 : H12AffineFastState.Bounded env54431 := by
  intro p hp
  have h : env54431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54430_54431 : H12AffineEnvironment.transform 6 35 env54430 = env54431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env54430 == env54431) = true)

theorem identity54431 : scanCanonicalize (H12AffineFastState.compose env54431 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound54431 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env54432 : List Nat := [2,4,8,16,32,0,35,256,29,272,302,281,24,1,260,315,28,281,25,261,280,55,28,314,314,260,302,12,0,271,20,29,256,17,16,277]

theorem envBound54432 : H12AffineFastState.Bounded env54432 := by
  intro p hp
  have h : env54432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54431_54432 : H12AffineEnvironment.transform 10 302 env54431 = env54432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env54431 == env54432) = true)

theorem identity54432 : scanCanonicalize (H12AffineFastState.compose env54432 (packedSelected [2,3,4,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54432 : packedSelected [2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54433 : List Nat := [2,4,8,16,32,0,35,2,29,18,44,27,24,1,6,57,28,27,25,7,26,55,28,56,56,6,44,12,0,13,20,29,2,17,16,23]

theorem envBound54433 : H12AffineFastState.Bounded env54433 := by
  intro p hp
  have h : env54433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54432_54433 : H12AffineEnvironment.transform 7 2 env54432 = env54433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54432 == env54433) = true)

theorem identity54433 : scanCanonicalize (H12AffineFastState.compose env54433 (packedSelected [0,3,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54433 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env54434 : List Nat := [2,3,8,16,32,0,35,2,26,18,43,27,24,1,1,57,27,27,25,0,26,48,27,56,56,1,43,11,0,10,19,26,2,17,16,16]

theorem envBound54434 : H12AffineFastState.Bounded env54434 := by
  intro p hp
  have h : env54434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54433_54434 : H12AffineEnvironment.transform 1 3 env54433 = env54434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54433 == env54434) = true)

theorem identity54434 : scanCanonicalize (H12AffineFastState.compose env54434 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound54434 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env54435 : List Nat := [2,3,8,16,26,0,25,2,26,18,17,27,24,1,1,3,27,27,25,0,26,10,27,2,2,1,17,11,0,10,19,26,2,17,16,16]

theorem envBound54435 : H12AffineFastState.Bounded env54435 := by
  intro p hp
  have h : env54435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54434_54435 : H12AffineEnvironment.transform 4 26 env54434 = env54435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env54434 == env54435) = true)

theorem identity54435 : scanCanonicalize (H12AffineFastState.compose env54435 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54436 : List Nat := [2,3,8,11,1,0,2,2,1,9,10,0,3,1,1,3,0,0,2,0,1,10,0,2,2,1,10,11,0,10,8,1,2,10,11,11]

theorem envBound54436 : H12AffineFastState.Bounded env54436 := by
  intro p hp
  have h : env54436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54435_54436 : H12AffineEnvironment.transform 3 11 env54435 = env54436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54435 == env54436) = true)

def env54437 : List Nat := [2,4,8,16,32,0,128,256,190,272,2048,442,25,1,261,65536,65830,65665,186,260,443,55,65830,65537,315,65693,302,65846,0,68024,21,65831,256,16,16,277]

theorem envBound54437 : H12AffineFastState.Bounded env54437 := by
  intro p hp
  have h : env54437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54428_54437 : H12AffineEnvironment.transform 12 25 env54428 = env54437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54428 == env54437) = true)

theorem identity54437 : scanCanonicalize (H12AffineFastState.compose env54437 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound54437 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54438 : List Nat := [2,4,8,16,32,0,128,256,190,272,2048,442,25,1,261,51,277,178,186,260,443,55,277,50,315,174,302,261,0,2443,21,276,256,16,16,277]

theorem envBound54438 : H12AffineFastState.Bounded env54438 := by
  intro p hp
  have h : env54438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54437_54438 : H12AffineEnvironment.transform 15 51 env54437 = env54438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env54437 == env54438) = true)

theorem identity54438 : scanCanonicalize (H12AffineFastState.compose env54438 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound54438 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54439 : List Nat := [2,4,8,16,32,0,63,256,1,272,2048,261,25,1,261,51,277,13,5,260,260,55,277,50,315,17,302,261,0,2356,21,276,256,16,16,277]

theorem envBound54439 : H12AffineFastState.Bounded env54439 := by
  intro p hp
  have h : env54439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54438_54439 : H12AffineEnvironment.transform 6 63 env54438 = env54439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env54438 == env54439) = true)

end H12CloudChart2