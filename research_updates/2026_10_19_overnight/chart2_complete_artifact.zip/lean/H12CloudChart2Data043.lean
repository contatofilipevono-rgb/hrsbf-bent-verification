import H12CloudChart2Data042

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity10481 : scanCanonicalize (H12AffineFastState.compose env10481 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound10481 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,5324,1025,32768,4097,4194304,5456,103492,4259840,67108864,4194440,67110224,4176,71409034,4164,4294967296,257,4362117478,4096,4268680]

theorem envBound10482 : H12AffineFastState.Bounded env10482 := by
  intro p hp
  have h : env10482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10481_10482 : H12AffineEnvironment.transform 17 5324 env10481 = env10482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env10481 == env10482) = true)

def env10483 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,5276,1025,32768,4097,4194304,5376,103444,4259840,67108864,4194440,67110144,4096,71409034,4116,4294967296,257,4362117430,4096,4268680]

theorem envBound10483 : H12AffineFastState.Bounded env10483 := by
  intro p hp
  have h : env10483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10482_10483 : H12AffineEnvironment.transform 5 16 env10482 = env10483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10482 == env10483) = true)

theorem identity10483 : scanCanonicalize (H12AffineFastState.compose env10483 (packedSelected [1,3,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 15540) := by decide +kernel

theorem selectedBound10483 : packedSelected [1,3,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10484 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,15540,65536,4096,5276,1025,15540,4097,4194304,5376,75936,4259840,67108864,4194440,67110144,4096,71377214,4116,4294967296,257,4362083714,4096,4268680]

theorem envBound10484 : H12AffineFastState.Bounded env10484 := by
  intro p hp
  have h : env10484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10483_10484 : H12AffineEnvironment.transform 14 15540 env10483 = env10484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15540 env10483 == env10484) = true)

theorem identity10484 : scanCanonicalize (H12AffineFastState.compose env10484 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(21+1) ^^^ 2210) := by decide +kernel

theorem selectedBound10484 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env10485 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,15540,65536,4096,5276,1025,15540,4097,2210,5376,75936,67746,67108864,2090,67110144,4096,67185052,4116,4294967296,257,4362083714,4096,76330]

theorem envBound10485 : H12AffineFastState.Bounded env10485 := by
  intro p hp
  have h : env10485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10484_10485 : H12AffineEnvironment.transform 21 2210 env10484 = env10485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2210 env10484 == env10485) = true)

theorem identity10485 : scanCanonicalize (H12AffineFastState.compose env10485 (packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS)) = affineNative (2^(25+1) ^^^ 81194) := by decide +kernel

theorem selectedBound10485 : packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS < 2^1333 := by decide +kernel

def env10486 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,15540,65536,4096,5276,1025,15540,4097,2210,5376,75936,67746,81194,2090,79914,4096,5302,4116,4294967296,257,4295041192,4096,76330]

theorem envBound10486 : H12AffineFastState.Bounded env10486 := by
  intro p hp
  have h : env10486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10485_10486 : H12AffineEnvironment.transform 25 81194 env10485 = env10486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 81194 env10485 == env10486) = true)

theorem identity10486 : scanCanonicalize (H12AffineFastState.compose env10486 (packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 775) := by decide +kernel

theorem selectedBound10486 : packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS < 2^1333 := by decide +kernel

def env10487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,775,4097,8115,65536,4096,5276,1025,8115,4097,2210,5376,68519,67746,73261,2090,72493,4096,5302,4116,4294967296,257,4295033775,4096,67885]

theorem envBound10487 : H12AffineFastState.Bounded env10487 := by
  intro p hp
  have h : env10487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10486_10487 : H12AffineEnvironment.transform 12 775 env10486 = env10487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 775 env10486 == env10487) = true)

theorem identity10487 : scanCanonicalize (H12AffineFastState.compose env10487 (packedSelected [2,4,5,6,7,12,13,15,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 7348) := by decide +kernel

theorem selectedBound10487 : packedSelected [2,4,5,6,7,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env10488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,775,4097,8115,7348,4096,5276,1025,8115,4097,2210,5376,5907,5142,665,2090,1945,4096,5302,4116,4294967296,257,4294975259,4096,5529]

theorem envBound10488 : H12AffineFastState.Bounded env10488 := by
  intro p hp
  have h : env10488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10487_10488 : H12AffineEnvironment.transform 15 7348 env10487 = env10488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7348 env10487 == env10488) = true)

theorem identity10488 : scanCanonicalize (H12AffineFastState.compose env10488 (packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound10488 : packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env10489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,168,4096,775,4097,5915,5148,4096,5276,1025,5915,4097,10,5376,5907,5142,665,130,1945,4096,5302,4116,4294967296,257,4294973363,4096,5529]

theorem envBound10489 : H12AffineFastState.Bounded env10489 := by
  intro p hp
  have h : env10489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10488_10489 : H12AffineEnvironment.transform 10 168 env10488 = env10489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env10488 == env10489) = true)

theorem identity10489 : scanCanonicalize (H12AffineFastState.compose env10489 (packedSelected [0,2,4,5,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound10489 : packedSelected [0,2,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env10490 : List Nat := [2,4,8,16,32,16,128,256,512,517,168,4096,775,4097,4382,4633,4096,4761,516,4382,4097,10,4869,4374,4627,665,130,412,4096,4787,4116,4294967296,257,4294971830,4096,5020]

theorem envBound10490 : H12AffineFastState.Bounded env10490 := by
  intro p hp
  have h : env10490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10489_10490 : H12AffineEnvironment.transform 9 517 env10489 = env10490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env10489 == env10490) = true)

theorem identity10490 : scanCanonicalize (H12AffineFastState.compose env10490 (packedSelected [0,3,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound10490 : packedSelected [0,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env10491 : List Nat := [2,4,8,16,32,16,128,256,271,266,168,4096,8,4097,4382,4374,4096,4502,267,4382,4097,10,4106,4374,4380,406,130,412,4096,4540,4116,4294967296,257,4294971830,4096,4243]

theorem envBound10491 : H12AffineFastState.Bounded env10491 := by
  intro p hp
  have h : env10491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10490_10491 : H12AffineEnvironment.transform 8 271 env10490 = env10491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env10490 == env10491) = true)

theorem identity10491 : scanCanonicalize (H12AffineFastState.compose env10491 (packedSelected [5,6,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 412) := by decide +kernel

theorem selectedBound10491 : packedSelected [5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env10492 : List Nat := [2,4,8,16,32,16,128,256,271,266,168,412,8,413,130,138,412,10,267,130,413,10,406,138,128,406,130,412,412,32,392,4294967296,257,4294967338,412,271]

theorem envBound10492 : H12AffineFastState.Bounded env10492 := by
  intro p hp
  have h : env10492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10491_10492 : H12AffineEnvironment.transform 11 412 env10491 = env10492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 412 env10491 == env10492) = true)

theorem identity10492 : scanCanonicalize (H12AffineFastState.compose env10492 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound10492 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10493 : List Nat := [2,4,8,16,32,16,128,256,271,266,168,412,8,413,130,138,412,10,267,130,413,10,406,138,128,406,130,412,412,32,392,429,257,391,412,271]

theorem envBound10493 : H12AffineFastState.Bounded env10493 := by
  intro p hp
  have h : env10493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10492_10493 : H12AffineEnvironment.transform 31 429 env10492 = env10493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env10492 == env10493) = true)

theorem identity10493 : scanCanonicalize (H12AffineFastState.compose env10493 (packedSelected [1,26] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound10493 : packedSelected [1,26] rootPS < 2^1333 := by decide +kernel

def env10494 : List Nat := [2,4,8,16,32,16,128,135,136,141,168,27,8,26,130,138,27,10,140,130,26,10,17,138,128,17,130,27,27,32,15,42,134,0,27,136]

theorem envBound10494 : H12AffineFastState.Bounded env10494 := by
  intro p hp
  have h : env10494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10493_10494 : H12AffineEnvironment.transform 7 135 env10493 = env10494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env10493 == env10494) = true)

theorem identity10494 : scanCanonicalize (H12AffineFastState.compose env10494 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10495 : List Nat := [2,4,8,16,32,16,34,37,42,47,10,27,8,26,32,40,27,10,46,32,26,10,17,40,34,17,32,27,27,32,15,42,36,0,27,42]

theorem envBound10495 : H12AffineFastState.Bounded env10495 := by
  intro p hp
  have h : env10495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10494_10495 : H12AffineEnvironment.transform 6 34 env10494 = env10495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10494 == env10495) = true)

theorem identity10495 : scanCanonicalize (H12AffineFastState.compose env10495 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound10495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10496 : List Nat := [2,4,8,16,18,16,16,23,24,29,10,27,8,26,18,26,27,10,28,18,26,10,17,26,16,17,18,27,27,18,15,24,22,0,27,24]

theorem envBound10496 : H12AffineFastState.Bounded env10496 := by
  intro p hp
  have h : env10496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10495_10496 : H12AffineEnvironment.transform 4 18 env10495 = env10496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env10495 == env10496) = true)

def env10497 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,5277,1025,32768,4097,4194304,5377,103445,4259840,67108864,4194440,67110145,4097,71409034,4117,4294967296,257,4362117431,4096,4268680]

theorem envBound10497 : H12AffineFastState.Bounded env10497 := by
  intro p hp
  have h : env10497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10482_10497 : H12AffineEnvironment.transform 5 17 env10482 = env10497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10482 == env10497) = true)

def env10498 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,5277,1025,32768,4097,4194304,5377,103445,4259840,5376,4194440,4097,4097,4294794,4117,4294967296,257,4295013431,4096,4268680]

theorem envBound10498 : H12AffineFastState.Bounded env10498 := by
  intro p hp
  have h : env10498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10497_10498 : H12AffineEnvironment.transform 25 5376 env10497 = env10498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env10497 == env10498) = true)

theorem identity10498 : scanCanonicalize (H12AffineFastState.compose env10498 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 73864) := by decide +kernel

theorem selectedBound10498 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10499 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,5277,1025,32768,4097,73864,5377,103445,8328,5376,73728,4097,4097,43010,4117,4294967296,257,4295013431,4096,512]

theorem envBound10499 : H12AffineFastState.Bounded env10499 := by
  intro p hp
  have h : env10499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10498_10499 : H12AffineEnvironment.transform 21 73864 env10498 = env10499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73864 env10498 == env10499) = true)

theorem identity10499 : scanCanonicalize (H12AffineFastState.compose env10499 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 13333) := by decide +kernel

theorem selectedBound10499 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10500 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,13333,4096,5277,1025,32768,4097,5277,5377,40960,8328,5376,5141,4097,4097,43010,4117,4294967296,257,4295013431,4096,512]

theorem envBound10500 : H12AffineFastState.Bounded env10500 := by
  intro p hp
  have h : env10500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10499_10500 : H12AffineEnvironment.transform 15 13333 env10499 = env10500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13333 env10499 == env10500) = true)

theorem identity10500 : scanCanonicalize (H12AffineFastState.compose env10500 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 8226) := by decide +kernel

theorem selectedBound10500 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10501 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,13333,4096,5277,1025,32768,4097,5277,5377,40960,8328,5376,5141,4097,4097,43010,4117,8226,257,37909,4096,512]

theorem envBound10501 : H12AffineFastState.Bounded env10501 := by
  intro p hp
  have h : env10501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10500_10501 : H12AffineEnvironment.transform 31 8226 env10500 = env10501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8226 env10500 == env10501) = true)

theorem identity10501 : scanCanonicalize (H12AffineFastState.compose env10501 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10501 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10502 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,261,13333,4096,5277,1025,261,4097,5277,5377,8453,8328,5376,5141,4097,4097,10503,4117,8226,257,5392,4096,512]

theorem envBound10502 : H12AffineFastState.Bounded env10502 := by
  intro p hp
  have h : env10502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10501_10502 : H12AffineEnvironment.transform 14 261 env10501 = env10502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10501 == env10502) = true)

theorem identity10502 : scanCanonicalize (H12AffineFastState.compose env10502 (packedSelected [9,22] rootPS)) = affineNative (2^(12+1) ^^^ 5400) := by decide +kernel

theorem selectedBound10502 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env10503 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5400,4096,261,269,4096,5277,1025,261,4097,5277,5377,5149,5520,5376,5141,4097,4097,7199,4117,5434,257,5392,4096,512]

theorem envBound10503 : H12AffineFastState.Bounded env10503 := by
  intro p hp
  have h : env10503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10502_10503 : H12AffineEnvironment.transform 12 5400 env10502 = env10503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5400 env10502 == env10503) = true)

theorem identity10503 : scanCanonicalize (H12AffineFastState.compose env10503 (packedSelected [1,3,10,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10503 : packedSelected [1,3,10,26] rootPS < 2^1333 := by decide +kernel

def env10504 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8,1296,261,269,1296,397,1025,261,1297,397,17,269,128,16,261,1297,1297,2319,1285,42,257,0,1296,512]

theorem envBound10504 : H12AffineFastState.Bounded env10504 := by
  intro p hp
  have h : env10504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10503_10504 : H12AffineEnvironment.transform 11 1296 env10503 = env10504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10503 == env10504) = true)

theorem identity10504 : scanCanonicalize (H12AffineFastState.compose env10504 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound10504 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10505 : List Nat := [2,4,8,16,32,17,17,256,512,1024,2048,1296,8,1296,261,269,1296,284,1025,261,1297,284,17,269,17,16,261,1297,1297,2319,1285,42,257,0,1296,512]

theorem envBound10505 : H12AffineFastState.Bounded env10505 := by
  intro p hp
  have h : env10505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10504_10505 : H12AffineEnvironment.transform 6 17 env10504 = env10505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env10504 == env10505) = true)

theorem identity10505 : scanCanonicalize (H12AffineFastState.compose env10505 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound10505 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10506 : List Nat := [2,4,8,16,32,17,17,256,512,47,2048,319,8,319,261,269,319,284,46,261,318,284,17,269,17,16,261,318,318,2319,298,42,257,0,319,512]

theorem envBound10506 : H12AffineFastState.Bounded env10506 := by
  intro p hp
  have h : env10506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10505_10506 : H12AffineEnvironment.transform 9 47 env10505 = env10506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env10505 == env10506) = true)

theorem identity10506 : scanCanonicalize (H12AffineFastState.compose env10506 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 57) := by decide +kernel

theorem selectedBound10506 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10507 : List Nat := [2,4,8,16,32,17,17,256,512,47,57,319,8,319,261,269,319,284,46,261,318,284,17,269,17,16,261,318,318,310,298,42,257,0,319,512]

theorem envBound10507 : H12AffineFastState.Bounded env10507 := by
  intro p hp
  have h : env10507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10506_10507 : H12AffineEnvironment.transform 10 57 env10506 = env10507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 57 env10506 == env10507) = true)

theorem identity10507 : scanCanonicalize (H12AffineFastState.compose env10507 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10508 : List Nat := [2,4,8,16,10,17,17,256,512,5,19,277,8,277,261,269,277,284,4,261,276,284,17,269,17,16,261,276,276,284,256,0,257,0,277,512]

theorem envBound10508 : H12AffineFastState.Bounded env10508 := by
  intro p hp
  have h : env10508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10507_10508 : H12AffineEnvironment.transform 4 10 env10507 = env10508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10507 == env10508) = true)

theorem identity10508 : scanCanonicalize (H12AffineFastState.compose env10508 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 28) := by decide +kernel

theorem selectedBound10508 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10509 : List Nat := [2,4,8,16,10,17,17,28,512,5,19,9,8,9,25,17,9,0,4,25,8,0,17,17,17,16,25,8,8,0,28,0,29,0,9,512]

theorem envBound10509 : H12AffineFastState.Bounded env10509 := by
  intro p hp
  have h : env10509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10508_10509 : H12AffineEnvironment.transform 7 28 env10508 = env10509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 28 env10508 == env10509) = true)

theorem identity10509 : scanCanonicalize (H12AffineFastState.compose env10509 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound10509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10510 : List Nat := [2,4,8,9,10,8,8,5,512,5,10,9,8,9,0,8,9,0,4,0,8,0,8,8,8,9,0,8,8,0,5,0,4,0,9,512]

theorem envBound10510 : H12AffineFastState.Bounded env10510 := by
  intro p hp
  have h : env10510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10509_10510 : H12AffineEnvironment.transform 3 9 env10509 = env10510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env10509 == env10510) = true)

theorem identity10510 : scanCanonicalize (H12AffineFastState.compose env10510 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10511 : List Nat := [2,4,8,9,10,8,8,5,1,5,10,9,8,9,0,8,9,0,4,0,8,0,8,8,8,9,0,8,8,0,5,0,4,0,9,1]

theorem envBound10511 : H12AffineFastState.Bounded env10511 := by
  intro p hp
  have h : env10511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10510_10511 : H12AffineEnvironment.transform 8 1 env10510 = env10511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10510 == env10511) = true)

theorem identity10511 : scanCanonicalize (H12AffineFastState.compose env10511 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10511 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10512 : List Nat := [2,4,2,3,0,2,2,5,1,5,0,3,2,3,0,2,3,0,4,0,2,0,2,2,2,3,0,2,2,0,5,0,4,0,3,1]

theorem envBound10512 : H12AffineFastState.Bounded env10512 := by
  intro p hp
  have h : env10512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10511_10512 : H12AffineEnvironment.transform 2 2 env10511 = env10512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10511 == env10512) = true)

def leafEnv10512 : List Nat := [2,4,2,3,0,2,2,5,1,5,0,3,2,3,0,2,3,0,4,0,2,0,2,2,4,2,1,3,0,2,2,0,5,0,4,0,5,2,3,1,0,2,1]

def active10512 : List Nat := [0,1]

def tree10512 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10512 : H12WitnessSearch.Good tree10512 := H12GlobalWitnessIndex.good

theorem leafIdentity10512 : H12AffineFastState.composeSystem env10512 rootObs = leafEnv10512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10512 rootObs == leafEnv10512) = true)

theorem terminalChecked10512 : H12PackedTerminal.terminalCheckFast leafEnv10512 active10512 tree10512 = true := by decide +kernel

def env10513 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,5277,1025,32768,4097,4194304,5377,103445,4259840,5377,4194440,4096,4097,4294795,4117,4294967296,257,4295013430,4096,4268680]

theorem envBound10513 : H12AffineFastState.Bounded env10513 := by
  intro p hp
  have h : env10513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10497_10513 : H12AffineEnvironment.transform 25 5377 env10497 = env10513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env10497 == env10513) = true)

theorem identity10513 : scanCanonicalize (H12AffineFastState.compose env10513 (packedSelected [1,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 3513) := by decide +kernel

theorem selectedBound10513 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10514 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,8192,3513,32768,65536,3513,2340,1025,32768,3512,4194304,2232,100780,4259840,2232,4194440,3513,3512,4294795,3500,4294967296,257,4295010703,3513,4268680]

theorem envBound10514 : H12AffineFastState.Bounded env10514 := by
  intro p hp
  have h : env10514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10513_10514 : H12AffineEnvironment.transform 11 3513 env10513 = env10514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3513 env10513 == env10514) = true)

theorem identity10514 : scanCanonicalize (H12AffineFastState.compose env10514 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 2476) := by decide +kernel

theorem selectedBound10514 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10515 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,8192,3513,32768,65536,3513,2340,1025,32768,3512,4194304,2232,100780,4259840,2232,4194440,3513,3512,4294795,3500,2476,257,40995,3513,4268680]

theorem envBound10515 : H12AffineFastState.Bounded env10515 := by
  intro p hp
  have h : env10515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10514_10515 : H12AffineEnvironment.transform 31 2476 env10514 = env10515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2476 env10514 == env10515) = true)

theorem identity10515 : scanCanonicalize (H12AffineFastState.compose env10515 (packedSelected [5,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 75809) := by decide +kernel

theorem selectedBound10515 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env10516 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,8192,3513,32768,65536,3513,2340,1025,32768,3512,75809,2232,100780,10273,2232,75945,3513,3512,41130,3500,2476,257,40995,3513,2729]

theorem envBound10516 : H12AffineFastState.Bounded env10516 := by
  intro p hp
  have h : env10516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10515_10516 : H12AffineEnvironment.transform 21 75809 env10515 = env10516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 75809 env10515 == env10516) = true)

theorem identity10516 : scanCanonicalize (H12AffineFastState.compose env10516 (packedSelected [5,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10516 : packedSelected [5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env10517 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,8192,3513,32768,8203,3513,2340,1025,32768,3512,2090,2232,43431,10273,2232,2210,3513,3512,41130,3500,2476,257,40995,3513,2729]

theorem envBound10517 : H12AffineFastState.Bounded env10517 := by
  intro p hp
  have h : env10517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10516_10517 : H12AffineEnvironment.transform 15 8203 env10516 = env10517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10516 == env10517) = true)

theorem identity10517 : scanCanonicalize (H12AffineFastState.compose env10517 (packedSelected [0,1,3,4,5,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound10517 : packedSelected [0,1,3,4,5,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10518 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,8192,3513,168,8203,3513,2340,1025,168,3512,2090,2232,10511,10273,2232,2210,3513,3512,8194,3500,2476,257,8331,3513,2729]

theorem envBound10518 : H12AffineFastState.Bounded env10518 := by
  intro p hp
  have h : env10518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10517_10518 : H12AffineEnvironment.transform 14 168 env10517 = env10518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env10517 == env10518) = true)

theorem identity10518 : scanCanonicalize (H12AffineFastState.compose env10518 (packedSelected [1,2,3,4,5,7,11,20] rootPS)) = affineNative (2^(12+1) ^^^ 1419) := by decide +kernel

theorem selectedBound10518 : packedSelected [1,2,3,4,5,7,11,20] rootPS < 2^1333 := by decide +kernel

def env10519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3513,1419,3513,168,1408,3513,2340,1025,168,3512,2090,2232,3204,3498,2232,2210,3513,3512,1417,3500,2476,257,1280,3513,2729]

theorem envBound10519 : H12AffineFastState.Bounded env10519 := by
  intro p hp
  have h : env10519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10518_10519 : H12AffineEnvironment.transform 12 1419 env10518 = env10519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1419 env10518 == env10519) = true)

theorem identity10519 : scanCanonicalize (H12AffineFastState.compose env10519 (packedSelected [6,25] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound10519 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,1297,1419,1297,168,1408,1297,396,1025,168,1296,130,16,1068,1282,16,10,1297,1296,1417,1284,260,257,1280,1297,513]

theorem envBound10520 : H12AffineFastState.Bounded env10520 := by
  intro p hp
  have h : env10520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10519_10520 : H12AffineEnvironment.transform 10 168 env10519 = env10520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env10519 == env10520) = true)

def env10521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,1025,32768,4097,4194304,5456,103493,4259840,67108864,4461637,67110224,4177,71409034,4165,4294967296,257,4362117479,4097,4268680]

theorem envBound10521 : H12AffineFastState.Bounded env10521 := by
  intro p hp
  have h : env10521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10480_10521 : H12AffineEnvironment.transform 16 4097 env10480 = env10521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10480 == env10521) = true)

theorem identity10521 : scanCanonicalize (H12AffineFastState.compose env10521 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 341709) := by decide +kernel

theorem selectedBound10521 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,1025,32768,4097,341709,5456,103493,276173,67108864,74376,67110224,4177,67414855,4165,4294967296,257,4362117479,4097,267333]

theorem envBound10522 : H12AffineFastState.Bounded env10522 := by
  intro p hp
  have h : env10522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10521_10522 : H12AffineEnvironment.transform 21 341709 env10521 = env10522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341709 env10521 == env10522) = true)

def env10523 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,341661,5376,103445,276125,67108864,74376,67110144,4097,67414807,4117,4294967296,257,4362117431,4097,267285]

theorem envBound10523 : H12AffineFastState.Bounded env10523 := by
  intro p hp
  have h : env10523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10522_10523 : H12AffineEnvironment.transform 5 16 env10522 = env10523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10522 == env10523) = true)

def env10524 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,341661,5376,103445,276125,5376,74376,4096,4097,310807,4117,4294967296,257,4295013431,4097,267285]

theorem envBound10524 : H12AffineFastState.Bounded env10524 := by
  intro p hp
  have h : env10524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10523_10524 : H12AffineEnvironment.transform 25 5376 env10523 = env10524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env10523 == env10524) = true)

theorem identity10524 : scanCanonicalize (H12AffineFastState.compose env10524 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 5653) := by decide +kernel

theorem selectedBound10524 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10525 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,5653,1025,32768,4097,73864,5376,103445,8328,5376,74376,4096,4097,43010,4117,4294967296,257,4295013431,4097,512]

theorem envBound10525 : H12AffineFastState.Bounded env10525 := by
  intro p hp
  have h : env10525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10524_10525 : H12AffineEnvironment.transform 17 5653 env10524 = env10525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5653 env10524 == env10525) = true)

theorem identity10525 : scanCanonicalize (H12AffineFastState.compose env10525 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 13333) := by decide +kernel

theorem selectedBound10525 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10526 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,13333,4097,5653,1025,32768,4097,5277,5376,40960,8328,5376,5789,4096,4097,43010,4117,4294967296,257,4295013431,4097,512]

theorem envBound10526 : H12AffineFastState.Bounded env10526 := by
  intro p hp
  have h : env10526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10525_10526 : H12AffineEnvironment.transform 15 13333 env10525 = env10526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13333 env10525 == env10526) = true)

theorem identity10526 : scanCanonicalize (H12AffineFastState.compose env10526 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 8226) := by decide +kernel

theorem selectedBound10526 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10527 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,13333,4097,5653,1025,32768,4097,5277,5376,40960,8328,5376,5789,4096,4097,43010,4117,8226,257,37909,4097,512]

theorem envBound10527 : H12AffineFastState.Bounded env10527 := by
  intro p hp
  have h : env10527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10526_10527 : H12AffineEnvironment.transform 31 8226 env10526 = env10527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8226 env10526 == env10527) = true)

theorem identity10527 : scanCanonicalize (H12AffineFastState.compose env10527 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound10527 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,260,13333,4097,5653,1025,260,4097,5277,5376,8452,8328,5376,5789,4096,4097,10502,4117,8226,257,5393,4097,512]

theorem envBound10528 : H12AffineFastState.Bounded env10528 := by
  intro p hp
  have h : env10528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10527_10528 : H12AffineEnvironment.transform 14 260 env10527 = env10528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env10527 == env10528) = true)

theorem identity10528 : scanCanonicalize (H12AffineFastState.compose env10528 (packedSelected [9,22] rootPS)) = affineNative (2^(12+1) ^^^ 5401) := by decide +kernel

theorem selectedBound10528 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env10529 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5401,4097,260,268,4097,5653,1025,260,4097,5277,5376,5149,5521,5376,5789,4096,4097,7199,4117,5435,257,5393,4097,512]

theorem envBound10529 : H12AffineFastState.Bounded env10529 := by
  intro p hp
  have h : env10529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10528_10529 : H12AffineEnvironment.transform 12 5401 env10528 = env10529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5401 env10528 == env10529) = true)

theorem identity10529 : scanCanonicalize (H12AffineFastState.compose env10529 (packedSelected [1,3,10,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10529 : packedSelected [1,3,10,26] rootPS < 2^1333 := by decide +kernel

def env10530 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,9,1297,260,268,1297,773,1025,260,1297,397,16,269,129,16,909,1296,1297,2319,1285,43,257,1,1297,512]

theorem envBound10530 : H12AffineFastState.Bounded env10530 := by
  intro p hp
  have h : env10530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10529_10530 : H12AffineEnvironment.transform 11 1296 env10529 = env10530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10529 == env10530) = true)

theorem identity10530 : scanCanonicalize (H12AffineFastState.compose env10530 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound10530 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10531 : List Nat := [2,4,8,16,32,16,128,256,512,47,2048,319,9,318,260,268,318,773,46,260,318,397,16,269,129,16,909,319,318,2319,298,43,257,1,318,512]

theorem envBound10531 : H12AffineFastState.Bounded env10531 := by
  intro p hp
  have h : env10531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10530_10531 : H12AffineEnvironment.transform 9 47 env10530 = env10531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env10530 == env10531) = true)

theorem identity10531 : scanCanonicalize (H12AffineFastState.compose env10531 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound10531 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10532 : List Nat := [2,4,8,16,32,16,128,256,512,47,544,319,9,318,260,268,318,773,46,260,318,397,16,269,129,16,909,319,318,815,298,43,257,1,318,512]

theorem envBound10532 : H12AffineFastState.Bounded env10532 := by
  intro p hp
  have h : env10532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10531_10532 : H12AffineEnvironment.transform 10 544 env10531 = env10532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env10531 == env10532) = true)

theorem identity10532 : scanCanonicalize (H12AffineFastState.compose env10532 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound10532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10533 : List Nat := [2,4,8,16,32,16,128,173,512,47,544,146,9,147,169,161,147,680,46,169,147,32,16,160,129,16,544,146,147,642,135,43,172,1,147,512]

theorem envBound10533 : H12AffineFastState.Bounded env10533 := by
  intro p hp
  have h : env10533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10532_10533 : H12AffineEnvironment.transform 7 173 env10532 = env10533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env10532 == env10533) = true)

theorem identity10533 : scanCanonicalize (H12AffineFastState.compose env10533 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10533 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10534 : List Nat := [2,4,8,16,10,16,128,135,512,5,522,146,9,147,131,139,147,642,4,131,147,10,16,138,129,16,522,146,147,642,135,1,134,1,147,512]

theorem envBound10534 : H12AffineFastState.Bounded env10534 := by
  intro p hp
  have h : env10534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10533_10534 : H12AffineEnvironment.transform 4 10 env10533 = env10534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10533 == env10534) = true)

theorem identity10534 : scanCanonicalize (H12AffineFastState.compose env10534 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound10534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10535 : List Nat := [2,4,8,16,10,16,128,135,130,5,136,146,9,147,131,139,147,0,4,131,147,10,16,138,129,16,136,146,147,0,135,1,134,1,147,130]

theorem envBound10535 : H12AffineFastState.Bounded env10535 := by
  intro p hp
  have h : env10535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10534_10535 : H12AffineEnvironment.transform 8 130 env10534 = env10535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env10534 == env10535) = true)

theorem identity10535 : scanCanonicalize (H12AffineFastState.compose env10535 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound10535 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10536 : List Nat := [2,4,8,16,10,16,3,4,1,5,11,17,9,16,0,8,16,0,4,0,16,10,16,9,2,16,11,17,16,0,4,1,5,1,16,1]

theorem envBound10536 : H12AffineFastState.Bounded env10536 := by
  intro p hp
  have h : env10536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10535_10536 : H12AffineEnvironment.transform 6 3 env10535 = env10536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env10535 == env10536) = true)

theorem identity10536 : scanCanonicalize (H12AffineFastState.compose env10536 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound10536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10537 : List Nat := [2,4,8,8,10,8,3,4,1,5,11,9,9,8,0,8,8,0,4,0,8,10,8,9,2,8,11,9,8,0,4,1,5,1,8,1]

theorem envBound10537 : H12AffineFastState.Bounded env10537 := by
  intro p hp
  have h : env10537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10536_10537 : H12AffineEnvironment.transform 3 8 env10536 = env10537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env10536 == env10537) = true)

theorem identity10537 : scanCanonicalize (H12AffineFastState.compose env10537 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10537 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10538 : List Nat := [2,4,3,3,1,3,3,4,1,5,0,2,2,3,0,3,3,0,4,0,3,1,3,2,2,3,0,2,3,0,4,1,5,1,3,1]

theorem envBound10538 : H12AffineFastState.Bounded env10538 := by
  intro p hp
  have h : env10538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10537_10538 : H12AffineEnvironment.transform 2 3 env10537 = env10538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10537 == env10538) = true)

def env10539 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,341661,5376,103445,276125,5377,74376,4097,4097,310806,4117,4294967296,257,4295013430,4097,267285]

theorem envBound10539 : H12AffineFastState.Bounded env10539 := by
  intro p hp
  have h : env10539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10523_10539 : H12AffineEnvironment.transform 25 5377 env10523 = env10539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env10523 == env10539) = true)

theorem identity10539 : scanCanonicalize (H12AffineFastState.compose env10539 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound10539 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10540 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,2340,1025,32768,4097,81849,5376,103445,16313,5377,74376,4097,4097,46898,4117,4294967296,257,4295013430,4097,7473]

theorem envBound10540 : H12AffineFastState.Bounded env10540 := by
  intro p hp
  have h : env10540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10539_10540 : H12AffineEnvironment.transform 17 2340 env10539 = env10540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env10539 == env10540) = true)

theorem identity10540 : scanCanonicalize (H12AffineFastState.compose env10540 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 5140) := by decide +kernel

theorem selectedBound10540 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10541 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,2340,1025,32768,4097,81849,5376,103445,16313,5377,74376,4097,4097,46898,4117,5140,257,40994,4097,7473]

theorem envBound10541 : H12AffineFastState.Bounded env10541 := by
  intro p hp
  have h : env10541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10540_10541 : H12AffineEnvironment.transform 31 5140 env10540 = env10541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5140 env10540 == env10541) = true)

theorem identity10541 : scanCanonicalize (H12AffineFastState.compose env10541 (packedSelected [5,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound10541 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env10542 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,8192,4097,32768,65536,4097,773,1025,32768,4097,79256,5376,103445,13720,5377,74376,4097,4097,46898,4117,5140,257,40994,4097,5904]

theorem envBound10542 : H12AffineFastState.Bounded env10542 := by
  intro p hp
  have h : env10542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10541_10542 : H12AffineEnvironment.transform 10 545 env10541 = env10542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env10541 == env10542) = true)

theorem identity10542 : scanCanonicalize (H12AffineFastState.compose env10542 (packedSelected [5,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 13594) := by decide +kernel

theorem selectedBound10542 : packedSelected [5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env10543 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,8192,4097,32768,13594,4097,773,1025,32768,4097,130,5376,41231,13720,5377,6034,4097,4097,46898,4117,5140,257,40994,4097,5904]

theorem envBound10543 : H12AffineFastState.Bounded env10543 := by
  intro p hp
  have h : env10543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10542_10543 : H12AffineEnvironment.transform 15 13594 env10542 = env10543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13594 env10542 == env10543) = true)

theorem identity10543 : scanCanonicalize (H12AffineFastState.compose env10543 (packedSelected [0,1,3,4,5,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 545) := by decide +kernel

theorem selectedBound10543 : packedSelected [0,1,3,4,5,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,8192,4097,545,13594,4097,773,1025,545,4097,130,5376,9006,13720,5377,6034,4097,4097,13587,4117,5140,257,8707,4097,5904]

theorem envBound10544 : H12AffineFastState.Bounded env10544 := by
  intro p hp
  have h : env10544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10543_10544 : H12AffineEnvironment.transform 14 545 env10543 = env10544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 545 env10543 == env10544) = true)

theorem identity10544 : scanCanonicalize (H12AffineFastState.compose env10544 (packedSelected [2,4,7,10,11,12,13,20] rootPS)) = affineNative (2^(12+1) ^^^ 4500) := by decide +kernel

theorem selectedBound10544 : packedSelected [2,4,7,10,11,12,13,20] rootPS < 2^1333 := by decide +kernel

def env10545 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,4500,4097,545,1166,4097,773,1025,545,4097,130,5376,4794,1036,5377,6034,4097,4097,1159,4117,5140,257,5015,4097,5904]

theorem envBound10545 : H12AffineFastState.Bounded env10545 := by
  intro p hp
  have h : env10545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10544_10545 : H12AffineEnvironment.transform 12 4500 env10544 = env10545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4500 env10544 == env10545) = true)

theorem identity10545 : scanCanonicalize (H12AffineFastState.compose env10545 (packedSelected [6,25] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10545 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10546 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1297,1157,1296,545,1166,1296,773,1025,545,1296,130,17,1963,1036,16,643,1296,1296,1159,1284,261,257,1670,1296,513]

theorem envBound10546 : H12AffineFastState.Bounded env10546 := by
  intro p hp
  have h : env10546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10545_10546 : H12AffineEnvironment.transform 11 1297 env10545 = env10546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10545 == env10546) = true)

def env10547 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,262144,1025,32768,4097,341660,5377,103444,276124,67108864,74376,67110145,4096,67414806,4116,4294967296,257,4362117430,4097,267284]

theorem envBound10547 : H12AffineFastState.Bounded env10547 := by
  intro p hp
  have h : env10547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10522_10547 : H12AffineEnvironment.transform 5 17 env10522 = env10547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10522 == env10547) = true)

theorem identity10547 : scanCanonicalize (H12AffineFastState.compose env10547 (packedSelected [1,3,8,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10547 : packedSelected [1,3,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10548 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,43048,1025,32768,4097,106164,5377,103444,40628,67108864,74376,67110145,4096,67109694,4116,4294967296,257,4362117430,4097,48188]

theorem envBound10548 : H12AffineFastState.Bounded env10548 := by
  intro p hp
  have h : env10548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10547_10548 : H12AffineEnvironment.transform 17 43048 env10547 = env10548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10547 == env10548) = true)

theorem identity10548 : scanCanonicalize (H12AffineFastState.compose env10548 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(15+1) ^^^ 10914) := by decide +kernel

theorem selectedBound10548 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env10549 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,10914,4097,43048,1025,32768,4097,46102,5377,48822,40628,67108864,2090,67110145,4096,67109694,4116,4294967296,257,4362117430,4097,48188]

theorem envBound10549 : H12AffineFastState.Bounded env10549 := by
  intro p hp
  have h : env10549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10548_10549 : H12AffineEnvironment.transform 15 10914 env10548 = env10549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10914 env10548 == env10549) = true)

theorem identity10549 : scanCanonicalize (H12AffineFastState.compose env10549 (packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS)) = affineNative (2^(25+1) ^^^ 43836) := by decide +kernel

theorem selectedBound10549 : packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS < 2^1333 := by decide +kernel

def env10550 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,10914,4097,43048,1025,32768,4097,46102,5377,48822,40628,43836,2090,44605,4096,43010,4116,4294967296,257,4294969866,4097,48188]

theorem envBound10550 : H12AffineFastState.Bounded env10550 := by
  intro p hp
  have h : env10550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10549_10550 : H12AffineEnvironment.transform 25 43836 env10549 = env10550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 43836 env10549 == env10550) = true)

theorem identity10550 : scanCanonicalize (H12AffineFastState.compose env10550 (packedSelected [0,7,8,10,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 7870) := by decide +kernel

theorem selectedBound10550 : packedSelected [0,7,8,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env10551 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7870,4096,32768,5148,4097,38550,1025,32768,4097,35496,5377,32776,40628,38274,2090,36995,4096,38588,4116,4294967296,257,4294969866,4097,33410]

theorem envBound10551 : H12AffineFastState.Bounded env10551 := by
  intro p hp
  have h : env10551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10550_10551 : H12AffineEnvironment.transform 12 7870 env10550 = env10551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7870 env10550 == env10551) = true)

theorem identity10551 : scanCanonicalize (H12AffineFastState.compose env10551 (packedSelected [1,2,3,4,6,7,10,11,13,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 8115) := by decide +kernel

theorem selectedBound10551 : packedSelected [1,2,3,4,6,7,10,11,13,15,20] rootPS < 2^1333 := by decide +kernel

def env10552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7870,4096,8115,5148,4097,2341,1025,8115,4097,5403,5377,8123,263,2609,2090,3888,4096,2319,4116,4294967296,257,4294969866,4097,7473]

theorem envBound10552 : H12AffineFastState.Bounded env10552 := by
  intro p hp
  have h : env10552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10551_10552 : H12AffineEnvironment.transform 14 8115 env10551 = env10552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8115 env10551 == env10552) = true)

theorem identity10552 : scanCanonicalize (H12AffineFastState.compose env10552 (packedSelected [1,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound10552 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3889,399,3889,130,2861,3888,2341,1025,130,3888,2602,2608,138,263,2609,2090,3888,3889,2319,3877,4294967296,257,4294969866,3888,512]

theorem envBound10553 : H12AffineFastState.Bounded env10553 := by
  intro p hp
  have h : env10553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10552_10553 : H12AffineEnvironment.transform 11 3889 env10552 = env10553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env10552 == env10553) = true)

theorem identity10553 : scanCanonicalize (H12AffineFastState.compose env10553 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound10553 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10554 : List Nat := [2,4,8,16,32,17,128,135,512,1024,2048,3766,8,3766,130,2730,3767,2210,1025,130,3767,2602,2608,138,128,2609,2090,3767,3766,2184,3746,4294967296,134,4294969866,3767,512]

theorem envBound10554 : H12AffineFastState.Bounded env10554 := by
  intro p hp
  have h : env10554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10553_10554 : H12AffineEnvironment.transform 7 135 env10553 = env10554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env10553 == env10554) = true)

theorem identity10554 : scanCanonicalize (H12AffineFastState.compose env10554 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 2570) := by decide +kernel

theorem selectedBound10554 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10555 : List Nat := [2,4,8,16,32,17,128,135,512,1024,2048,3766,8,3766,130,2730,3767,2210,1025,130,3767,2602,2608,138,128,2609,2090,3767,3766,2184,3746,2570,134,0,3767,512]

theorem envBound10555 : H12AffineFastState.Bounded env10555 := by
  intro p hp
  have h : env10555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10554_10555 : H12AffineEnvironment.transform 31 2570 env10554 = env10555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2570 env10554 == env10555) = true)

theorem identity10555 : scanCanonicalize (H12AffineFastState.compose env10555 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound10555 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10556 : List Nat := [2,4,8,16,32,17,128,135,512,1024,545,1175,8,1175,130,139,1174,643,1025,130,1174,11,17,138,128,16,523,1174,1175,681,1155,43,134,0,1174,512]

theorem envBound10556 : H12AffineFastState.Bounded env10556 := by
  intro p hp
  have h : env10556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10555_10556 : H12AffineEnvironment.transform 10 545 env10555 = env10556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env10555 == env10556) = true)

theorem identity10556 : scanCanonicalize (H12AffineFastState.compose env10556 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound10556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10557 : List Nat := [2,4,8,16,32,17,128,135,131,1024,162,1175,8,1175,130,139,1174,0,1025,130,1174,11,17,138,128,16,136,1174,1175,42,1155,43,134,0,1174,131]

theorem envBound10557 : H12AffineFastState.Bounded env10557 := by
  intro p hp
  have h : env10557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10556_10557 : H12AffineEnvironment.transform 8 131 env10556 = env10557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env10556 == env10557) = true)

theorem identity10557 : scanCanonicalize (H12AffineFastState.compose env10557 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10557 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10558 : List Nat := [2,4,8,16,32,17,8,15,11,1024,42,1055,8,1055,10,3,1054,0,1025,10,1054,11,17,2,8,16,0,1054,1055,42,1035,43,14,0,1054,11]

theorem envBound10558 : H12AffineFastState.Bounded env10558 := by
  intro p hp
  have h : env10558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10557_10558 : H12AffineEnvironment.transform 6 8 env10557 = env10558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10557 == env10558) = true)

theorem identity10558 : scanCanonicalize (H12AffineFastState.compose env10558 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound10558 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10559 : List Nat := [2,4,1,16,32,17,1,6,2,1024,35,1046,1,1046,3,3,1047,0,1025,3,1047,2,17,2,1,16,0,1047,1046,35,1026,34,7,0,1047,2]

theorem envBound10559 : H12AffineFastState.Bounded env10559 := by
  intro p hp
  have h : env10559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10558_10559 : H12AffineEnvironment.transform 2 1 env10558 = env10559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env10558 == env10559) = true)

theorem identity10559 : scanCanonicalize (H12AffineFastState.compose env10559 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10559 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10560 : List Nat := [2,4,1,16,32,17,1,6,2,5,35,19,1,19,3,3,18,0,4,3,18,2,17,2,1,16,0,18,19,35,7,34,7,0,18,2]

theorem envBound10560 : H12AffineFastState.Bounded env10560 := by
  intro p hp
  have h : env10560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10559_10560 : H12AffineEnvironment.transform 9 5 env10559 = env10560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10559 == env10560) = true)

theorem identity10560 : scanCanonicalize (H12AffineFastState.compose env10560 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10560 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10561 : List Nat := [0,4,1,16,32,17,1,4,0,5,33,17,1,17,1,1,16,0,4,1,16,0,17,0,1,16,0,16,17,33,5,32,5,0,16,0]

theorem envBound10561 : H12AffineFastState.Bounded env10561 := by
  intro p hp
  have h : env10561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10560_10561 : H12AffineEnvironment.transform 0 0 env10560 = env10561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10560 == env10561) = true)

def env10562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,5456,230468,4259841,67108864,4588612,67110224,131152,71409034,131140,4294967296,257,4362252647,131072,4268681]

theorem envBound10562 : H12AffineFastState.Bounded env10562 := by
  intro p hp
  have h : env10562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10479_10562 : H12AffineEnvironment.transform 24 4259841 env10479 = env10562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4259841 env10479 == env10562) = true)

def env10563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,262144,1025,32768,4097,4194304,5456,103492,4259841,67108864,4461636,67110224,4176,71409034,4164,4294967296,257,4362117479,4096,4268681]

theorem envBound10563 : H12AffineFastState.Bounded env10563 := by
  intro p hp
  have h : env10563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10562_10563 : H12AffineEnvironment.transform 16 4096 env10562 = env10563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10562 == env10563) = true)

theorem identity10563 : scanCanonicalize (H12AffineFastState.compose env10563 (packedSelected [3,5,24] rootPS)) = affineNative (2^(25+1) ^^^ 267405) := by decide +kernel

theorem selectedBound10563 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,262144,1025,32768,4097,4194304,5456,103492,4259841,267405,4461636,266717,4176,4557063,4164,4294967296,257,4295276010,4096,4268681]

theorem envBound10564 : H12AffineFastState.Bounded env10564 := by
  intro p hp
  have h : env10564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10563_10564 : H12AffineEnvironment.transform 25 267405 env10563 = env10564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 267405 env10563 == env10564) = true)

def env10565 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,1025,32768,4097,4194304,5376,103444,4259841,267405,4461588,266637,4096,4557063,4116,4294967296,257,4295275962,4096,4268681]

theorem envBound10565 : H12AffineFastState.Bounded env10565 := by
  intro p hp
  have h : env10565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10564_10565 : H12AffineEnvironment.transform 5 16 env10564 = env10565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10564 == env10565) = true)

theorem identity10565 : scanCanonicalize (H12AffineFastState.compose env10565 (packedSelected [1,3,8,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10565 : packedSelected [1,3,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10566 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,43048,1025,32768,4097,4194304,5376,103444,4259841,48293,4242492,47525,4096,4268335,4116,4294967296,257,4294974866,4096,4268681]

theorem envBound10566 : H12AffineFastState.Bounded env10566 := by
  intro p hp
  have h : env10566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10565_10566 : H12AffineEnvironment.transform 17 43048 env10565 = env10566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10565 == env10566) = true)

theorem identity10566 : scanCanonicalize (H12AffineFastState.compose env10566 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(21+1) ^^^ 46103) := by decide +kernel

theorem selectedBound10566 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env10567 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,43048,1025,32768,4097,46103,5376,103444,111638,48293,2091,47525,4096,103736,4116,4294967296,257,4294974866,4096,104094]

theorem envBound10567 : H12AffineFastState.Bounded env10567 := by
  intro p hp
  have h : env10567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10566_10567 : H12AffineEnvironment.transform 21 46103 env10566 = env10567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46103 env10566 == env10567) = true)

theorem identity10567 : scanCanonicalize (H12AffineFastState.compose env10567 (packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 15675) := by decide +kernel

theorem selectedBound10567 : packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS < 2^1333 := by decide +kernel

def env10568 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,15675,4096,43048,1025,32768,4097,46103,5376,43311,35117,48293,2091,47525,4096,43011,4116,4294967296,257,4294974866,4096,43941]

theorem envBound10568 : H12AffineFastState.Bounded env10568 := by
  intro p hp
  have h : env10568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10567_10568 : H12AffineEnvironment.transform 15 15675 env10567 = env10568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15675 env10567 == env10568) = true)

theorem identity10568 : scanCanonicalize (H12AffineFastState.compose env10568 (packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 5654) := by decide +kernel

theorem selectedBound10568 : packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS < 2^1333 := by decide +kernel

def env10569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5654,4097,32768,2861,4096,40510,1025,32768,4097,33281,5376,40761,35117,35507,2091,36787,4096,40469,4116,4294967296,257,4294974866,4096,40371]

theorem envBound10569 : H12AffineFastState.Bounded env10569 := by
  intro p hp
  have h : env10569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10568_10569 : H12AffineEnvironment.transform 12 5654 env10568 = env10569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5654 env10568 == env10569) = true)

theorem identity10569 : scanCanonicalize (H12AffineFastState.compose env10569 (packedSelected [1,2,3,4,6,7,8,11,16] rootPS)) = affineNative (2^(14+1) ^^^ 7482) := by decide +kernel

theorem selectedBound10569 : packedSelected [1,2,3,4,6,7,8,11,16] rootPS < 2^1333 := by decide +kernel

def env10570 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5654,4097,7482,2861,4096,772,1025,7482,4097,7995,5376,515,5143,6025,2091,4745,4096,815,4116,4294967296,257,4294974866,4096,137]

theorem envBound10570 : H12AffineFastState.Bounded env10570 := by
  intro p hp
  have h : env10570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10569_10570 : H12AffineEnvironment.transform 14 7482 env10569 = env10570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7482 env10569 == env10570) = true)

theorem identity10570 : scanCanonicalize (H12AffineFastState.compose env10570 (packedSelected [0,1,3,5,7,10,11,12,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound10570 : packedSelected [0,1,3,5,7,10,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env10571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3888,2342,3889,522,2861,3888,772,1025,522,3889,11,2608,515,2855,2233,2091,3513,3888,815,3876,4294967296,257,4294967970,3888,137]

theorem envBound10571 : H12AffineFastState.Bounded env10571 := by
  intro p hp
  have h : env10571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10570_10571 : H12AffineEnvironment.transform 11 3888 env10570 = env10571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env10570 == env10571) = true)

theorem identity10571 : scanCanonicalize (H12AffineFastState.compose env10571 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10571 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env10572 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,3605,2051,3604,522,2568,3605,545,1025,522,3604,11,2608,515,2562,2233,2091,3228,3605,522,3585,4294967296,36,4294967970,3605,137]

theorem envBound10572 : H12AffineFastState.Bounded env10572 := by
  intro p hp
  have h : env10572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10571_10572 : H12AffineEnvironment.transform 7 37 env10571 = env10572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10571 == env10572) = true)

theorem identity10572 : scanCanonicalize (H12AffineFastState.compose env10572 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound10572 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10573 : List Nat := [2,4,8,16,32,16,128,37,512,1024,642,1175,641,1174,522,138,1175,545,1025,522,1174,11,178,515,128,571,681,1566,1175,522,1155,4294967296,36,4294967970,1175,137]

theorem envBound10573 : H12AffineFastState.Bounded env10573 := by
  intro p hp
  have h : env10573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10572_10573 : H12AffineEnvironment.transform 10 642 env10572 = env10573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env10572 == env10573) = true)

theorem identity10573 : scanCanonicalize (H12AffineFastState.compose env10573 (packedSelected [0,1,2,3,4,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound10573 : packedSelected [0,1,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env10574 : List Nat := [2,4,8,16,32,16,128,37,43,1024,169,1175,170,1174,33,138,1175,10,1025,33,1174,11,178,40,128,16,130,1077,1175,33,1155,4294967296,36,4294967433,1175,137]

theorem envBound10574 : H12AffineFastState.Bounded env10574 := by
  intro p hp
  have h : env10574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10573_10574 : H12AffineEnvironment.transform 8 43 env10573 = env10574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env10573 == env10574) = true)

theorem identity10574 : scanCanonicalize (H12AffineFastState.compose env10574 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10574 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env10575 : List Nat := [2,4,8,16,32,16,34,37,43,1024,11,1077,8,1076,33,40,1077,10,1025,33,1076,11,16,40,34,16,32,1077,1077,33,1057,4294967296,36,4294967339,1077,43]

theorem envBound10575 : H12AffineFastState.Bounded env10575 := by
  intro p hp
  have h : env10575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10574_10575 : H12AffineEnvironment.transform 6 34 env10574 = env10575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10574 == env10575) = true)

theorem identity10575 : scanCanonicalize (H12AffineFastState.compose env10575 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 41) := by decide +kernel

theorem selectedBound10575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10576 : List Nat := [2,4,8,16,32,16,34,37,43,1024,11,1077,8,1076,33,40,1077,10,1025,33,1076,11,16,40,34,16,32,1077,1077,33,1057,41,36,2,1077,43]

theorem envBound10576 : H12AffineFastState.Bounded env10576 := by
  intro p hp
  have h : env10576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10575_10576 : H12AffineEnvironment.transform 31 41 env10575 = env10576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 41 env10575 == env10576) = true)

theorem identity10576 : scanCanonicalize (H12AffineFastState.compose env10576 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10577 : List Nat := [2,4,0,16,32,16,34,37,35,1024,3,1077,0,1076,33,32,1077,2,1025,33,1076,3,16,32,34,16,32,1077,1077,33,1057,33,36,2,1077,35]

theorem envBound10577 : H12AffineFastState.Bounded env10577 := by
  intro p hp
  have h : env10577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10576_10577 : H12AffineEnvironment.transform 2 0 env10576 = env10577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10576 == env10577) = true)

theorem identity10577 : scanCanonicalize (H12AffineFastState.compose env10577 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound10577 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10578 : List Nat := [2,4,0,16,3,16,1,6,0,1024,3,1046,0,1047,2,3,1046,2,1025,2,1047,3,16,3,1,16,3,1046,1046,2,1026,2,7,2,1046,0]

theorem envBound10578 : H12AffineFastState.Bounded env10578 := by
  intro p hp
  have h : env10578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10577_10578 : H12AffineEnvironment.transform 4 3 env10577 = env10578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env10577 == env10578) = true)

def env10579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,1025,32768,4097,4194304,5377,103445,4259841,267405,4461589,266636,4097,4557063,4117,4294967296,257,4295275963,4096,4268681]

theorem envBound10579 : H12AffineFastState.Bounded env10579 := by
  intro p hp
  have h : env10579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10564_10579 : H12AffineEnvironment.transform 5 17 env10564 = env10579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10564 == env10579) = true)

def env10580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,396,1025,32768,4097,4194304,5377,103445,4259841,5377,4199833,4096,4097,4294795,4117,4294967296,257,4295013431,4096,4268681]

theorem envBound10580 : H12AffineFastState.Bounded env10580 := by
  intro p hp
  have h : env10580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10579_10580 : H12AffineEnvironment.transform 17 396 env10579 = env10580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 396 env10579 == env10580) = true)

theorem identity10580 : scanCanonicalize (H12AffineFastState.compose env10580 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound10580 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,8192,4096,32768,65536,4096,396,1025,32768,4097,4194304,5377,103445,4259841,5377,4199833,4096,4097,4292643,4117,4294967296,257,4295013431,4096,4268681]

theorem envBound10581 : H12AffineFastState.Bounded env10581 := by
  intro p hp
  have h : env10581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10580_10581 : H12AffineEnvironment.transform 10 168 env10580 = env10581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env10580 == env10581) = true)

theorem identity10581 : scanCanonicalize (H12AffineFastState.compose env10581 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 5141) := by decide +kernel

theorem selectedBound10581 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10582 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,8192,4096,32768,65536,4096,396,1025,32768,4097,4194304,5377,103445,4259841,5377,4199833,4096,4097,4292643,4117,5141,257,40994,4096,4268681]

theorem envBound10582 : H12AffineFastState.Bounded env10582 := by
  intro p hp
  have h : env10582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10581_10582 : H12AffineEnvironment.transform 31 5141 env10581 = env10582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5141 env10581 == env10582) = true)

theorem identity10582 : scanCanonicalize (H12AffineFastState.compose env10582 (packedSelected [5,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 79257) := by decide +kernel

theorem selectedBound10582 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env10583 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,8192,4096,32768,65536,4096,396,1025,32768,4097,79257,5377,103445,13720,5377,73728,4096,4097,46522,4117,5141,257,40994,4096,5904]

theorem envBound10583 : H12AffineFastState.Bounded env10583 := by
  intro p hp
  have h : env10583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10582_10583 : H12AffineEnvironment.transform 21 79257 env10582 = env10583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79257 env10582 == env10583) = true)

theorem identity10583 : scanCanonicalize (H12AffineFastState.compose env10583 (packedSelected [5,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10583 : packedSelected [5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env10584 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,8192,4096,32768,8203,4096,396,1025,32768,4097,5522,5377,46110,13720,5377,11,4096,4097,46522,4117,5141,257,40994,4096,5904]

theorem envBound10584 : H12AffineFastState.Bounded env10584 := by
  intro p hp
  have h : env10584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10583_10584 : H12AffineEnvironment.transform 15 8203 env10583 = env10584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10583 == env10584) = true)

theorem identity10584 : scanCanonicalize (H12AffineFastState.compose env10584 (packedSelected [0,1,3,4,5,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5561) := by decide +kernel

theorem selectedBound10584 : packedSelected [0,1,3,4,5,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10585 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,8192,4096,5561,8203,4096,396,1025,5561,4097,5522,5377,8615,13720,5377,11,4096,4097,8195,4117,5141,257,13723,4096,5904]

theorem envBound10585 : H12AffineFastState.Bounded env10585 := by
  intro p hp
  have h : env10585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10584_10585 : H12AffineEnvironment.transform 14 5561 env10584 = env10585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5561 env10584 == env10585) = true)

theorem identity10585 : scanCanonicalize (H12AffineFastState.compose env10585 (packedSelected [1,2,3,4,5,7,11,20] rootPS)) = affineNative (2^(12+1) ^^^ 1419) := by decide +kernel

theorem selectedBound10585 : packedSelected [1,2,3,4,5,7,11,20] rootPS < 2^1333 := by decide +kernel

def env10586 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,4096,1419,4096,5561,1408,4096,396,1025,5561,4097,5522,5377,1068,4115,5377,11,4096,4097,1416,4117,5141,257,4112,4096,5904]

theorem envBound10586 : H12AffineFastState.Bounded env10586 := by
  intro p hp
  have h : env10586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10585_10586 : H12AffineEnvironment.transform 12 1419 env10585 = env10586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1419 env10585 == env10586) = true)

theorem identity10586 : scanCanonicalize (H12AffineFastState.compose env10586 (packedSelected [6,25] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10586 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10587 : List Nat := [2,4,8,16,32,17,128,256,512,1024,168,1297,1419,1297,168,1408,1297,396,1025,168,1296,131,16,1068,1282,16,11,1297,1296,1416,1284,260,257,1281,1297,513]

theorem envBound10587 : H12AffineFastState.Bounded env10587 := by
  intro p hp
  have h : env10587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10586_10587 : H12AffineEnvironment.transform 11 1297 env10586 = env10587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10586 == env10587) = true)

def env10588 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,397,1025,32768,4097,4194304,5377,103445,4259841,5376,4199832,4097,4097,4294794,4117,4294967296,257,4295013430,4096,4268681]

theorem envBound10588 : H12AffineFastState.Bounded env10588 := by
  intro p hp
  have h : env10588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10579_10588 : H12AffineEnvironment.transform 17 397 env10579 = env10588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 397 env10579 == env10588) = true)

theorem identity10588 : scanCanonicalize (H12AffineFastState.compose env10588 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 73865) := by decide +kernel

theorem selectedBound10588 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10589 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,397,1025,32768,4097,73865,5377,103445,8328,5376,79121,4097,4097,43011,4117,4294967296,257,4295013430,4096,512]

theorem envBound10589 : H12AffineFastState.Bounded env10589 := by
  intro p hp
  have h : env10589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10588_10589 : H12AffineEnvironment.transform 21 73865 env10588 = env10589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73865 env10588 == env10589) = true)

theorem identity10589 : scanCanonicalize (H12AffineFastState.compose env10589 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 13332) := by decide +kernel

theorem selectedBound10589 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,13332,4096,397,1025,32768,4097,5277,5377,40961,8328,5376,261,4097,4097,43011,4117,4294967296,257,4295013430,4096,512]

theorem envBound10590 : H12AffineFastState.Bounded env10590 := by
  intro p hp
  have h : env10590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10589_10590 : H12AffineEnvironment.transform 15 13332 env10589 = env10590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13332 env10589 == env10590) = true)

theorem identity10590 : scanCanonicalize (H12AffineFastState.compose env10590 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 8227) := by decide +kernel

theorem selectedBound10590 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10591 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,13332,4096,397,1025,32768,4097,5277,5377,40961,8328,5376,261,4097,4097,43011,4117,8227,257,37909,4096,512]

theorem envBound10591 : H12AffineFastState.Bounded env10591 := by
  intro p hp
  have h : env10591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10590_10591 : H12AffineEnvironment.transform 31 8227 env10590 = env10591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8227 env10590 == env10591) = true)

theorem identity10591 : scanCanonicalize (H12AffineFastState.compose env10591 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10591 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10592 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,261,13332,4096,397,1025,261,4097,5277,5377,8452,8328,5376,261,4097,4097,10502,4117,8227,257,5392,4096,512]

theorem envBound10592 : H12AffineFastState.Bounded env10592 := by
  intro p hp
  have h : env10592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10591_10592 : H12AffineEnvironment.transform 14 261 env10591 = env10592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10591 == env10592) = true)

theorem identity10592 : scanCanonicalize (H12AffineFastState.compose env10592 (packedSelected [9,22] rootPS)) = affineNative (2^(12+1) ^^^ 5400) := by decide +kernel

theorem selectedBound10592 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env10593 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5400,4096,261,268,4096,397,1025,261,4097,5277,5377,5148,5520,5376,261,4097,4097,7198,4117,5435,257,5392,4096,512]

theorem envBound10593 : H12AffineFastState.Bounded env10593 := by
  intro p hp
  have h : env10593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10592_10593 : H12AffineEnvironment.transform 12 5400 env10592 = env10593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5400 env10592 == env10593) = true)

theorem identity10593 : scanCanonicalize (H12AffineFastState.compose env10593 (packedSelected [1,3,10,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10593 : packedSelected [1,3,10,26] rootPS < 2^1333 := by decide +kernel

def env10594 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8,1296,261,268,1296,397,1025,261,1297,397,17,268,128,16,261,1297,1297,2318,1285,43,257,0,1296,512]

theorem envBound10594 : H12AffineFastState.Bounded env10594 := by
  intro p hp
  have h : env10594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10593_10594 : H12AffineEnvironment.transform 11 1296 env10593 = env10594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10593 == env10594) = true)

theorem identity10594 : scanCanonicalize (H12AffineFastState.compose env10594 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound10594 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10595 : List Nat := [2,4,8,16,32,17,16,256,512,1024,2048,1296,8,1296,261,268,1296,285,1025,261,1297,285,17,268,16,16,261,1297,1297,2318,1285,43,257,0,1296,512]

theorem envBound10595 : H12AffineFastState.Bounded env10595 := by
  intro p hp
  have h : env10595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10594_10595 : H12AffineEnvironment.transform 6 16 env10594 = env10595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env10594 == env10595) = true)

theorem identity10595 : scanCanonicalize (H12AffineFastState.compose env10595 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound10595 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10596 : List Nat := [2,4,8,16,32,17,16,256,512,46,2048,318,8,318,261,268,318,285,47,261,319,285,17,268,16,16,261,319,319,2318,299,43,257,0,318,512]

theorem envBound10596 : H12AffineFastState.Bounded env10596 := by
  intro p hp
  have h : env10596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10595_10596 : H12AffineEnvironment.transform 9 46 env10595 = env10596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env10595 == env10596) = true)

theorem identity10596 : scanCanonicalize (H12AffineFastState.compose env10596 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 56) := by decide +kernel

theorem selectedBound10596 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10597 : List Nat := [2,4,8,16,32,17,16,256,512,46,56,318,8,318,261,268,318,285,47,261,319,285,17,268,16,16,261,319,319,310,299,43,257,0,318,512]

theorem envBound10597 : H12AffineFastState.Bounded env10597 := by
  intro p hp
  have h : env10597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10596_10597 : H12AffineEnvironment.transform 10 56 env10596 = env10597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 56 env10596 == env10597) = true)

theorem identity10597 : scanCanonicalize (H12AffineFastState.compose env10597 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound10597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10598 : List Nat := [2,4,8,16,11,17,16,256,512,5,19,277,8,277,261,268,277,285,4,261,276,285,17,268,16,16,261,276,276,285,256,0,257,0,277,512]

theorem envBound10598 : H12AffineFastState.Bounded env10598 := by
  intro p hp
  have h : env10598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10597_10598 : H12AffineEnvironment.transform 4 11 env10597 = env10598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env10597 == env10598) = true)

theorem identity10598 : scanCanonicalize (H12AffineFastState.compose env10598 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 28) := by decide +kernel

theorem selectedBound10598 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10599 : List Nat := [2,4,8,16,11,17,16,28,512,5,19,9,8,9,25,16,9,1,4,25,8,1,17,16,16,16,25,8,8,1,28,0,29,0,9,512]

theorem envBound10599 : H12AffineFastState.Bounded env10599 := by
  intro p hp
  have h : env10599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10598_10599 : H12AffineEnvironment.transform 7 28 env10598 = env10599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 28 env10598 == env10599) = true)

theorem identity10599 : scanCanonicalize (H12AffineFastState.compose env10599 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound10599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10600 : List Nat := [2,4,8,2,11,3,2,14,512,5,1,9,8,9,11,2,9,1,4,11,8,1,3,2,2,2,11,8,8,1,14,0,15,0,9,512]

theorem envBound10600 : H12AffineFastState.Bounded env10600 := by
  intro p hp
  have h : env10600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10599_10600 : H12AffineEnvironment.transform 3 2 env10599 = env10600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env10599 == env10600) = true)

theorem identity10600 : scanCanonicalize (H12AffineFastState.compose env10600 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound10600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10601 : List Nat := [2,4,8,2,11,3,2,14,10,5,1,9,8,9,11,2,9,1,4,11,8,1,3,2,2,2,11,8,8,1,14,0,15,0,9,10]

theorem envBound10601 : H12AffineFastState.Bounded env10601 := by
  intro p hp
  have h : env10601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10600_10601 : H12AffineEnvironment.transform 8 10 env10600 = env10601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env10600 == env10601) = true)

theorem identity10601 : scanCanonicalize (H12AffineFastState.compose env10601 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10601 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10602 : List Nat := [2,4,2,2,1,3,2,4,0,5,1,3,2,3,1,2,3,1,4,1,2,1,3,2,2,2,1,2,2,1,4,0,5,0,3,0]

theorem envBound10602 : H12AffineFastState.Bounded env10602 := by
  intro p hp
  have h : env10602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10601_10602 : H12AffineEnvironment.transform 2 2 env10601 = env10602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10601 == env10602) = true)

def leafEnv10602 : List Nat := [2,4,2,2,1,3,2,4,0,5,1,3,2,3,1,2,3,1,4,1,2,1,3,2,5,2,1,2,1,2,2,1,4,0,5,0,5,2,3,0,0,2,1]

def active10602 : List Nat := [0,1]

def tree10602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10602 : H12WitnessSearch.Good tree10602 := H12GlobalWitnessIndex.good

theorem leafIdentity10602 : H12AffineFastState.composeSystem env10602 rootObs = leafEnv10602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10602 rootObs == leafEnv10602) = true)

theorem terminalChecked10602 : H12PackedTerminal.terminalCheckFast leafEnv10602 active10602 tree10602 = true := by decide +kernel

def env10603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,1025,32768,4097,4194304,5456,103493,4259841,67108864,4461637,67110224,4177,71409034,4165,4294967296,257,4362117478,4097,4268681]

theorem envBound10603 : H12AffineFastState.Bounded env10603 := by
  intro p hp
  have h : env10603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10562_10603 : H12AffineEnvironment.transform 16 4097 env10562 = env10603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10562 == env10603) = true)

theorem identity10603 : scanCanonicalize (H12AffineFastState.compose env10603 (packedSelected [3,5,24] rootPS)) = affineNative (2^(25+1) ^^^ 4535948) := by decide +kernel

theorem selectedBound10603 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,1025,32768,4097,4194304,5456,103493,4259841,4535948,4461637,4535260,4177,305926,4165,4294967296,257,4299528170,4097,4268681]

theorem envBound10604 : H12AffineFastState.Bounded env10604 := by
  intro p hp
  have h : env10604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10603_10604 : H12AffineEnvironment.transform 25 4535948 env10603 = env10604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 4535948 env10603 == env10604) = true)

def env10605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,4194304,5376,103445,4259841,4535948,4461589,4535180,4097,305926,4117,4294967296,257,4299528122,4097,4268681]

theorem envBound10605 : H12AffineFastState.Bounded env10605 := by
  intro p hp
  have h : env10605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10604_10605 : H12AffineEnvironment.transform 5 16 env10604 = env10605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10604 == env10605) = true)

def env10606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,4194304,5376,103445,4259841,4535948,4461589,4535180,4097,303398,4117,4294967296,257,4299528122,4097,4268681]

theorem envBound10606 : H12AffineFastState.Bounded env10606 := by
  intro p hp
  have h : env10606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10605_10606 : H12AffineEnvironment.transform 10 544 env10605 = env10606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env10605 == env10606) = true)

theorem identity10606 : scanCanonicalize (H12AffineFastState.compose env10606 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 73865) := by decide +kernel

theorem selectedBound10606 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,73865,5376,103445,8328,267781,341148,267013,4097,303398,4117,4294967296,257,4295276339,4097,512]

theorem envBound10607 : H12AffineFastState.Bounded env10607 := by
  intro p hp
  have h : env10607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10606_10607 : H12AffineEnvironment.transform 21 73865 env10606 = env10607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73865 env10606 == env10607) = true)

theorem identity10607 : scanCanonicalize (H12AffineFastState.compose env10607 (packedSelected [4,5,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 13332) := by decide +kernel

theorem selectedBound10607 : packedSelected [4,5,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env10608 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,8192,4097,32768,13332,4097,262144,1025,32768,4097,5277,5376,40961,8328,267781,262280,267013,4097,303398,4117,4294967296,257,4295276339,4097,512]

theorem envBound10608 : H12AffineFastState.Bounded env10608 := by
  intro p hp
  have h : env10608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10607_10608 : H12AffineEnvironment.transform 15 13332 env10607 = env10608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13332 env10607 == env10608) = true)

theorem identity10608 : scanCanonicalize (H12AffineFastState.compose env10608 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound10608 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10609 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,8192,4097,260,13332,4097,262144,1025,260,4097,5277,5376,8453,8328,267781,262280,267013,4097,270370,4117,4294967296,257,4295243319,4097,512]

theorem envBound10609 : H12AffineFastState.Bounded env10609 := by
  intro p hp
  have h : env10609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10608_10609 : H12AffineEnvironment.transform 14 260 env10608 = env10609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env10608 == env10609) = true)

theorem identity10609 : scanCanonicalize (H12AffineFastState.compose env10609 (packedSelected [4,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 13852) := by decide +kernel

theorem selectedBound10609 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10610 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,8192,4097,260,13332,4097,13852,1025,260,4097,5277,5376,8453,8328,8217,13972,9497,4097,5694,4117,4294967296,257,4294967339,4097,512]

theorem envBound10610 : H12AffineFastState.Bounded env10610 := by
  intro p hp
  have h : env10610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10609_10610 : H12AffineEnvironment.transform 17 13852 env10609 = env10610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13852 env10609 == env10610) = true)

theorem identity10610 : scanCanonicalize (H12AffineFastState.compose env10610 (packedSelected [6,25] rootPS)) = affineNative (2^(12+1) ^^^ 5401) := by decide +kernel

theorem selectedBound10610 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10611 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,5401,4097,260,269,4097,773,1025,260,4097,5277,5376,5148,5521,5376,909,4096,4097,5694,4117,4294967296,257,4294967339,4097,512]

theorem envBound10611 : H12AffineFastState.Bounded env10611 := by
  intro p hp
  have h : env10611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10610_10611 : H12AffineEnvironment.transform 12 5401 env10610 = env10611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5401 env10610 == env10611) = true)

theorem identity10611 : scanCanonicalize (H12AffineFastState.compose env10611 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 5434) := by decide +kernel

theorem selectedBound10611 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,544,4096,5401,4097,260,269,4097,773,1025,260,4097,5277,5376,5148,5521,5376,909,4096,4097,5694,4117,5434,257,5393,4097,512]

theorem envBound10612 : H12AffineFastState.Bounded env10612 := by
  intro p hp
  have h : env10612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10611_10612 : H12AffineEnvironment.transform 31 5434 env10611 = env10612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5434 env10611 == env10612) = true)

def env10613 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,8192,4097,32768,65536,4097,262144,1025,32768,4097,4194304,5376,103445,4259841,4535948,4461589,4535180,4097,303399,4117,4294967296,257,4299528122,4097,4268681]

theorem envBound10613 : H12AffineFastState.Bounded env10613 := by
  intro p hp
  have h : env10613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10605_10613 : H12AffineEnvironment.transform 10 545 env10605 = env10613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env10605 == env10613) = true)

theorem identity10613 : scanCanonicalize (H12AffineFastState.compose env10613 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 773) := by decide +kernel

theorem selectedBound10613 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10614 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,4096,8192,4097,32768,65536,4097,773,1025,32768,4097,4194304,5376,103445,4259841,4273545,4200208,4272265,4097,41506,4117,4294967296,257,4299265215,4097,4268681]

theorem envBound10614 : H12AffineFastState.Bounded env10614 := by
  intro p hp
  have h : env10614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10613_10614 : H12AffineEnvironment.transform 17 773 env10613 = env10614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 773 env10613 == env10614) = true)

theorem identity10614 : scanCanonicalize (H12AffineFastState.compose env10614 (packedSelected [5,10,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10614 : packedSelected [5,10,26] rootPS < 2^1333 := by decide +kernel

def env10615 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,8192,1297,32768,65536,1297,773,1025,32768,1297,4194304,16,98565,4259841,4268185,4194816,4269465,1297,41506,1285,4294967296,257,4299260335,1297,4268681]

theorem envBound10615 : H12AffineFastState.Bounded env10615 := by
  intro p hp
  have h : env10615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10614_10615 : H12AffineEnvironment.transform 11 1296 env10614 = env10615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10614 == env10615) = true)

theorem identity10615 : scanCanonicalize (H12AffineFastState.compose env10615 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 98307) := by decide +kernel

theorem selectedBound10615 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10616 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,8192,1297,32768,65536,1297,773,1025,32768,1297,98307,16,98565,32770,41114,98819,42394,1297,41506,1285,4294967296,257,4294967724,1297,41610]

theorem envBound10616 : H12AffineFastState.Bounded env10616 := by
  intro p hp
  have h : env10616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10615_10616 : H12AffineEnvironment.transform 21 98307 env10615 = env10616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98307 env10615 == env10616) = true)

theorem identity10616 : scanCanonicalize (H12AffineFastState.compose env10616 (packedSelected [5,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8330) := by decide +kernel

theorem selectedBound10616 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env10617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,8192,1297,8330,65536,1297,773,1025,8330,1297,73865,16,74127,8328,16,74377,1296,1297,680,1285,4294967296,257,4294967724,1297,512]

theorem envBound10617 : H12AffineFastState.Bounded env10617 := by
  intro p hp
  have h : env10617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10616_10617 : H12AffineEnvironment.transform 14 8330 env10616 = env10617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8330 env10616 == env10617) = true)

theorem identity10617 : scanCanonicalize (H12AffineFastState.compose env10617 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound10617 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,8192,1297,8330,8323,1297,773,1025,8330,1297,10,16,268,8328,16,522,1296,1297,680,1285,4294967296,257,4294967724,1297,512]

theorem envBound10618 : H12AffineFastState.Bounded env10618 := by
  intro p hp
  have h : env10618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10617_10618 : H12AffineEnvironment.transform 15 8323 env10617 = env10618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env10617 == env10618) = true)

theorem identity10618 : scanCanonicalize (H12AffineFastState.compose env10618 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 8227) := by decide +kernel

theorem selectedBound10618 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,8192,1297,8330,8323,1297,773,1025,8330,1297,10,16,268,8328,16,522,1296,1297,680,1285,8227,257,8591,1297,512]

theorem envBound10619 : H12AffineFastState.Bounded env10619 := by
  intro p hp
  have h : env10619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10618_10619 : H12AffineEnvironment.transform 31 8227 env10618 = env10619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8227 env10618 == env10619) = true)

theorem identity10619 : scanCanonicalize (H12AffineFastState.compose env10619 (packedSelected [1,10] rootPS)) = affineNative (2^(12+1) ^^^ 1440) := by decide +kernel

theorem selectedBound10619 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,545,1296,1440,1297,1322,1315,1297,773,1025,1322,1297,10,16,268,1320,16,522,1296,1297,680,1285,1411,257,1071,1297,512]

theorem envBound10620 : H12AffineFastState.Bounded env10620 := by
  intro p hp
  have h : env10620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10619_10620 : H12AffineEnvironment.transform 12 1440 env10619 = env10620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1440 env10619 == env10620) = true)

theorem identity10620 : scanCanonicalize (H12AffineFastState.compose env10620 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound10620 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10621 : List Nat := [2,4,8,16,32,16,128,134,512,1024,545,1174,1062,1175,1196,1189,1175,643,1025,1196,1175,10,16,138,1198,16,522,1174,1175,680,1155,1029,135,1071,1175,512]

theorem envBound10621 : H12AffineFastState.Bounded env10621 := by
  intro p hp
  have h : env10621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10620_10621 : H12AffineEnvironment.transform 7 134 env10620 = env10621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env10620 == env10621) = true)

theorem identity10621 : scanCanonicalize (H12AffineFastState.compose env10621 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound10621 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10622 : List Nat := [2,4,8,16,11,16,128,134,512,1024,522,1174,1037,1175,1159,1166,1175,643,1025,1159,1175,10,16,138,1157,16,522,1174,1175,643,1155,1029,135,1028,1175,512]

theorem envBound10622 : H12AffineFastState.Bounded env10622 := by
  intro p hp
  have h : env10622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10621_10622 : H12AffineEnvironment.transform 4 11 env10621 = env10622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env10621 == env10622) = true)

theorem identity10622 : scanCanonicalize (H12AffineFastState.compose env10622 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10623 : List Nat := [2,4,8,16,11,16,128,134,0,1024,10,1174,1037,1175,1159,1166,1175,131,1025,1159,1175,10,16,138,1157,16,10,1174,1175,131,1155,1029,135,1028,1175,0]

theorem envBound10623 : H12AffineFastState.Bounded env10623 := by
  intro p hp
  have h : env10623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10622_10623 : H12AffineEnvironment.transform 8 0 env10622 = env10623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10622 == env10623) = true)

theorem identity10623 : scanCanonicalize (H12AffineFastState.compose env10623 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10623 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10624 : List Nat := [2,4,8,16,11,16,128,134,0,5,10,147,8,146,130,139,146,131,4,130,146,10,16,138,128,16,10,147,146,131,134,0,135,1,146,0]

theorem envBound10624 : H12AffineFastState.Bounded env10624 := by
  intro p hp
  have h : env10624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10623_10624 : H12AffineEnvironment.transform 9 5 env10623 = env10624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10623 == env10624) = true)

theorem identity10624 : scanCanonicalize (H12AffineFastState.compose env10624 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound10624 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10625 : List Nat := [2,4,8,16,11,16,16,22,0,5,10,3,8,2,18,27,2,19,4,18,2,10,16,26,16,16,10,3,2,19,22,0,23,1,2,0]

theorem envBound10625 : H12AffineFastState.Bounded env10625 := by
  intro p hp
  have h : env10625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10624_10625 : H12AffineEnvironment.transform 6 16 env10624 = env10625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env10624 == env10625) = true)

theorem identity10625 : scanCanonicalize (H12AffineFastState.compose env10625 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound10625 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10626 : List Nat := [2,4,8,8,11,8,8,14,0,5,10,3,8,2,10,3,2,11,4,10,2,10,8,2,8,8,10,3,2,11,14,0,15,1,2,0]

theorem envBound10626 : H12AffineFastState.Bounded env10626 := by
  intro p hp
  have h : env10626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10625_10626 : H12AffineEnvironment.transform 3 8 env10625 = env10626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env10625 == env10626) = true)

def env10627 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,262144,1025,32768,4097,4194304,5377,103444,4259841,4535948,4461588,4535181,4096,305926,4116,4294967296,257,4299528123,4097,4268681]

theorem envBound10627 : H12AffineFastState.Bounded env10627 := by
  intro p hp
  have h : env10627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10604_10627 : H12AffineEnvironment.transform 5 17 env10604 = env10627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10604 == env10627) = true)

theorem identity10627 : scanCanonicalize (H12AffineFastState.compose env10627 (packedSelected [1,3,8,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10627 : packedSelected [1,3,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,43048,1025,32768,4097,4194304,5377,103444,4259841,4300452,4242492,4299685,4096,814,4116,4294967296,257,4299243411,4097,4268681]

theorem envBound10628 : H12AffineFastState.Bounded env10628 := by
  intro p hp
  have h : env10628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10627_10628 : H12AffineEnvironment.transform 17 43048 env10627 = env10628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10627 == env10628) = true)

theorem identity10628 : scanCanonicalize (H12AffineFastState.compose env10628 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(21+1) ^^^ 46103) := by decide +kernel

theorem selectedBound10628 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env10629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,43048,1025,32768,4097,46103,5377,103444,111638,76467,2091,77746,4096,814,4116,4294967296,257,4295068548,4097,104094]

theorem envBound10629 : H12AffineFastState.Bounded env10629 := by
  intro p hp
  have h : env10629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10628_10629 : H12AffineEnvironment.transform 21 46103 env10628 = env10629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46103 env10628 == env10629) = true)

theorem identity10629 : scanCanonicalize (H12AffineFastState.compose env10629 (packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 11053) := by decide +kernel

theorem selectedBound10629 : packedSelected [0,4,7,10,11,12,13,15,16,17,19,22,23] rootPS < 2^1333 := by decide +kernel

def env10630 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,11053,65536,4097,773,1025,11053,4097,7994,5377,81721,73531,76467,2091,77746,4096,814,4116,4294967296,257,4295041193,4097,81331]

theorem envBound10630 : H12AffineFastState.Bounded env10630 := by
  intro p hp
  have h : env10630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10629_10630 : H12AffineEnvironment.transform 14 11053 env10629 = env10630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11053 env10629 == env10630) = true)

theorem identity10630 : scanCanonicalize (H12AffineFastState.compose env10630 (packedSelected [0,1,3,5,7,10,11,12,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 5149) := by decide +kernel

theorem selectedBound10630 : packedSelected [0,1,3,5,7,10,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env10631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,11053,5149,4097,773,1025,11053,4097,7994,5377,11044,2854,16046,2091,15279,4096,814,4116,4294967296,257,4294980788,4097,10670]

theorem envBound10631 : H12AffineFastState.Bounded env10631 := by
  intro p hp
  have h : env10631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10630_10631 : H12AffineEnvironment.transform 15 5149 env10630 = env10631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5149 env10630 == env10631) = true)

theorem identity10631 : scanCanonicalize (H12AffineFastState.compose env10631 (packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound10631 : packedSelected [0,1,2,3,4,6,8,11,16,20] rootPS < 2^1333 := by decide +kernel

def env10632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3888,8192,3888,11053,2861,3889,773,1025,11053,3889,10,2609,11044,2854,8606,2091,9375,3888,814,3876,4294967296,257,4294978436,3889,10670]

theorem envBound10632 : H12AffineFastState.Bounded env10632 := by
  intro p hp
  have h : env10632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10631_10632 : H12AffineEnvironment.transform 11 3888 env10631 = env10632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env10631 == env10632) = true)

theorem identity10632 : scanCanonicalize (H12AffineFastState.compose env10632 (packedSelected [0,2,4,5,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1548) := by decide +kernel

theorem selectedBound10632 : packedSelected [0,2,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env10633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3888,1548,3888,3361,2861,3889,773,1025,3361,3889,10,2609,3368,2854,1938,2091,659,3888,814,3876,4294967296,257,4294970760,3889,4002]

theorem envBound10633 : H12AffineFastState.Bounded env10633 := by
  intro p hp
  have h : env10633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10632_10633 : H12AffineEnvironment.transform 12 1548 env10632 = env10633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1548 env10632 == env10633) = true)

theorem identity10633 : scanCanonicalize (H12AffineFastState.compose env10633 (packedSelected [0,1,3,7,10,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound10633 : packedSelected [0,1,3,7,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env10634 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1442,658,1548,658,131,1679,659,773,1025,131,659,10,1939,138,1668,1938,1417,659,658,814,646,4294967296,257,4294967338,659,512]

theorem envBound10634 : H12AffineFastState.Bounded env10634 := by
  intro p hp
  have h : env10634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10633_10634 : H12AffineEnvironment.transform 10 1442 env10633 = env10634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env10633 == env10634) = true)

theorem identity10634 : scanCanonicalize (H12AffineFastState.compose env10634 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound10634 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10635 : List Nat := [2,4,8,16,32,17,128,134,512,1024,1060,658,1548,658,131,1679,659,643,1025,131,659,10,1557,138,1668,1556,1039,659,658,680,646,4294967296,135,4294967338,659,512]

theorem envBound10635 : H12AffineFastState.Bounded env10635 := by
  intro p hp
  have h : env10635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10634_10635 : H12AffineEnvironment.transform 7 134 env10634 = env10635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env10634 == env10635) = true)

theorem identity10635 : scanCanonicalize (H12AffineFastState.compose env10635 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound10635 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10636 : List Nat := [2,4,8,16,32,17,128,134,512,1024,1060,658,1548,658,131,1679,659,643,1025,131,659,10,1557,138,1668,1556,1039,659,658,680,646,42,135,0,659,512]

theorem envBound10636 : H12AffineFastState.Bounded env10636 := by
  intro p hp
  have h : env10636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10635_10636 : H12AffineEnvironment.transform 31 42 env10635 = env10636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env10635 == env10636) = true)

theorem identity10636 : scanCanonicalize (H12AffineFastState.compose env10636 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound10636 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10637 : List Nat := [2,4,8,16,32,17,128,134,512,516,544,658,8,658,131,139,659,643,517,131,659,10,17,138,128,16,523,659,658,680,646,42,135,0,659,512]

theorem envBound10637 : H12AffineFastState.Bounded env10637 := by
  intro p hp
  have h : env10637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10636_10637 : H12AffineEnvironment.transform 9 516 env10636 = env10637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env10636 == env10637) = true)

theorem identity10637 : scanCanonicalize (H12AffineFastState.compose env10637 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound10637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10638 : List Nat := [2,4,8,16,32,17,128,134,131,135,163,17,8,17,131,139,16,0,134,131,16,10,17,138,128,16,136,16,17,43,5,42,135,0,16,131]

theorem envBound10638 : H12AffineFastState.Bounded env10638 := by
  intro p hp
  have h : env10638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10637_10638 : H12AffineEnvironment.transform 8 131 env10637 = env10638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env10637 == env10638) = true)

theorem identity10638 : scanCanonicalize (H12AffineFastState.compose env10638 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10638 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10639 : List Nat := [2,4,8,16,32,17,8,14,11,15,43,17,8,17,11,3,16,0,14,11,16,10,17,2,8,16,0,16,17,43,5,42,15,0,16,11]

theorem envBound10639 : H12AffineFastState.Bounded env10639 := by
  intro p hp
  have h : env10639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10638_10639 : H12AffineEnvironment.transform 6 8 env10638 = env10639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10638 == env10639) = true)

theorem identity10639 : scanCanonicalize (H12AffineFastState.compose env10639 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10640 : List Nat := [2,4,0,16,32,17,0,6,3,7,35,17,0,17,3,3,16,0,6,3,16,2,17,2,0,16,0,16,17,35,5,34,7,0,16,3]

theorem envBound10640 : H12AffineFastState.Bounded env10640 := by
  intro p hp
  have h : env10640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10639_10640 : H12AffineEnvironment.transform 2 0 env10639 = env10640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10639 == env10640) = true)

def env10641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,23445585,67130625,131153,1073741824,16876545,4294967296,256,4417151346,131072,33563272]

theorem envBound10641 : H12AffineFastState.Bounded env10641 := by
  intro p hp
  have h : env10641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10092_10641 : H12AffineEnvironment.transform 26 23445585 env10092 = env10641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env10092 == env10641) = true)

def env10642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352529,67130625,131153,1073741824,16876545,4294967296,256,4417151346,131072,33563272]

theorem envBound10642 : H12AffineFastState.Bounded env10642 := by
  intro p hp
  have h : env10642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10641_10642 : H12AffineEnvironment.transform 20 4096 env10641 = env10642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env10641 == env10642) = true)

theorem identity10642 : scanCanonicalize (H12AffineFastState.compose env10642 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10642 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,5376,21352529,16385,131153,1073741824,16876545,4294967296,256,4350047346,131072,33563272]

theorem envBound10643 : H12AffineFastState.Bounded env10643 := by
  intro p hp
  have h : env10643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10642_10643 : H12AffineEnvironment.transform 25 5376 env10642 = env10643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env10642 == env10643) = true)

theorem identity10643 : scanCanonicalize (H12AffineFastState.compose env10643 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10643 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,8329,5376,21352529,16385,131153,1073741824,16876545,4294967296,256,4316484859,131072,513]

theorem envBound10644 : H12AffineFastState.Bounded env10644 := by
  intro p hp
  have h : env10644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10643_10644 : H12AffineEnvironment.transform 24 8329 env10643 = env10644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10643 == env10644) = true)

def env10645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4096,4194304,5457,16777216,8329,5376,21331969,4177,131153,1073741824,16876545,4294967296,256,4316464299,131072,513]

theorem envBound10645 : H12AffineFastState.Bounded env10645 := by
  intro p hp
  have h : env10645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10644_10645 : H12AffineEnvironment.transform 13 4176 env10644 = env10645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10644 == env10645) = true)

theorem identity10645 : scanCanonicalize (H12AffineFastState.compose env10645 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(29+1) ^^^ 21629135) := by decide +kernel

theorem selectedBound10645 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env10646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4096,4194304,5457,16777216,8329,5376,21331969,4177,131153,21629135,16876545,4294967296,256,4316464299,131072,513]

theorem envBound10646 : H12AffineFastState.Bounded env10646 := by
  intro p hp
  have h : env10646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10645_10646 : H12AffineEnvironment.transform 29 21629135 env10645 = env10646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21629135 env10645 == env10646) = true)

theorem identity10646 : scanCanonicalize (H12AffineFastState.compose env10646 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound10646 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4096,4194304,5457,230468,8329,5376,4588613,4177,131153,4820107,131141,4294967296,256,4299915503,131072,513]

theorem envBound10647 : H12AffineFastState.Bounded env10647 := by
  intro p hp
  have h : env10647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10646_10647 : H12AffineEnvironment.transform 23 230468 env10646 = env10647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env10646 == env10647) = true)

theorem identity10647 : scanCanonicalize (H12AffineFastState.compose env10647 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound10647 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,5457,230468,8329,5376,4588613,4177,131153,4294795,131141,4294967296,256,4299392239,131072,513]

theorem envBound10648 : H12AffineFastState.Bounded env10648 := by
  intro p hp
  have h : env10648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10647_10648 : H12AffineEnvironment.transform 18 1024 env10647 = env10648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10647 == env10648) = true)

theorem identity10648 : scanCanonicalize (H12AffineFastState.compose env10648 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4329688) := by decide +kernel

theorem selectedBound10648 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,5457,230468,8329,5376,4588613,4177,131153,4294795,131141,4329688,256,103479,131072,513]

theorem envBound10649 : H12AffineFastState.Bounded env10649 := by
  intro p hp
  have h : env10649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10648_10649 : H12AffineEnvironment.transform 31 4329688 env10648 = env10649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4329688 env10648 == env10649) = true)

def env10650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4096,4194304,5456,16777216,8329,5376,21331968,4176,131153,1073741824,16876545,4294967296,256,4316464298,131072,513]

theorem envBound10650 : H12AffineFastState.Bounded env10650 := by
  intro p hp
  have h : env10650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10644_10650 : H12AffineEnvironment.transform 13 4177 env10644 = env10650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env10644 == env10650) = true)

theorem identity10650 : scanCanonicalize (H12AffineFastState.compose env10650 (packedSelected [6,25] rootPS)) = affineNative (2^(29+1) ^^^ 4294795) := by decide +kernel

theorem selectedBound10650 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4096,4194304,5456,16777216,8329,5376,21331968,4176,131153,4294795,16876545,4294967296,256,4316464298,131072,513]

theorem envBound10651 : H12AffineFastState.Bounded env10651 := by
  intro p hp
  have h : env10651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10650_10651 : H12AffineEnvironment.transform 29 4294795 env10650 = env10651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294795 env10650 == env10651) = true)

def env10652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,262144,524288,32768,4096,4194304,5456,16777216,8329,5376,21331968,4176,4177,4294795,16876545,4294967296,256,4316464298,4096,513]

theorem envBound10652 : H12AffineFastState.Bounded env10652 := by
  intro p hp
  have h : env10652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10651_10652 : H12AffineEnvironment.transform 16 4096 env10651 = env10652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10651 == env10652) = true)

def env10653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1296,1297,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound10653 : H12AffineFastState.Bounded env10653 := by
  intro p hp
  have h : env10653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10652_10653 : H12AffineEnvironment.transform 11 1344 env10652 = env10653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env10652 == env10653) = true)

theorem identity10653 : scanCanonicalize (H12AffineFastState.compose env10653 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99293) := by decide +kernel

theorem selectedBound10653 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32768,1344,4194304,16,99293,8329,64,4457437,1296,1297,4294795,2012,4294967296,256,4299786103,1344,513]

theorem envBound10654 : H12AffineFastState.Bounded env10654 := by
  intro p hp
  have h : env10654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10653_10654 : H12AffineEnvironment.transform 23 99293 env10653 = env10654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99293 env10653 == env10654) = true)

theorem identity10654 : scanCanonicalize (H12AffineFastState.compose env10654 (packedSelected [4,16,22] rootPS)) = affineNative (2^(18+1) ^^^ 1753) := by decide +kernel

theorem selectedBound10654 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1753,32768,1344,4194304,16,99293,8329,64,4457437,1296,1297,4294795,2012,4294967296,256,4299260334,1344,513]

theorem envBound10655 : H12AffineFastState.Bounded env10655 := by
  intro p hp
  have h : env10655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10654_10655 : H12AffineEnvironment.transform 18 1753 env10654 = env10655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1753 env10654 == env10655) = true)

theorem identity10655 : scanCanonicalize (H12AffineFastState.compose env10655 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound10655 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10656 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1344,8192,1297,32768,65536,1344,262144,1025,32768,1344,4194304,16,98565,8329,64,4456709,1296,1297,4294795,1284,4294967296,256,4299260334,1344,217]

theorem envBound10656 : H12AffineFastState.Bounded env10656 := by
  intro p hp
  have h : env10656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10655_10656 : H12AffineEnvironment.transform 8 216 env10655 = env10656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env10655 == env10656) = true)

theorem identity10656 : scanCanonicalize (H12AffineFastState.compose env10656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98599) := by decide +kernel

theorem selectedBound10656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10657 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1344,8192,1297,32768,65536,1344,262144,1025,32768,1344,4194304,16,98565,8329,64,4456709,1296,1297,4294795,1284,98599,256,4194441,1344,217]

theorem envBound10657 : H12AffineFastState.Bounded env10657 := by
  intro p hp
  have h : env10657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10656_10657 : H12AffineEnvironment.transform 31 98599 env10656 = env10657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98599 env10656 == env10657) = true)

theorem identity10657 : scanCanonicalize (H12AffineFastState.compose env10657 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 338396) := by decide +kernel

theorem selectedBound10657 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10658 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1344,8192,1297,32768,65536,1344,262144,1025,32768,1344,338396,16,98565,8329,64,75993,1296,1297,303447,1284,98599,256,338261,1344,217]

theorem envBound10658 : H12AffineFastState.Bounded env10658 := by
  intro p hp
  have h : env10658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10657_10658 : H12AffineEnvironment.transform 21 338396 env10657 = env10658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 338396 env10657 == env10658) = true)

theorem identity10658 : scanCanonicalize (H12AffineFastState.compose env10658 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound10658 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env10659 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1344,8192,1297,32768,65536,1344,43049,1025,32768,1344,98805,16,98565,8329,64,75993,1296,1297,2430,1284,98599,256,98684,1344,217]

theorem envBound10659 : H12AffineFastState.Bounded env10659 := by
  intro p hp
  have h : env10659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10658_10659 : H12AffineEnvironment.transform 17 43049 env10658 = env10659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env10658 == env10659) = true)

theorem identity10659 : scanCanonicalize (H12AffineFastState.compose env10659 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound10659 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10660 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1344,8192,1297,8460,65536,1344,2341,1025,8460,1344,73977,16,73737,8329,64,75993,1296,1297,2430,1284,73771,256,73840,1344,217]

theorem envBound10660 : H12AffineFastState.Bounded env10660 := by
  intro p hp
  have h : env10660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10659_10660 : H12AffineEnvironment.transform 14 8460 env10659 = env10660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env10659 == env10660) = true)

theorem identity10660 : scanCanonicalize (H12AffineFastState.compose env10660 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1165) := by decide +kernel

theorem selectedBound10660 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10661 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1165,1344,8192,1297,8460,65536,1344,1448,1025,8460,1344,73977,16,73737,8329,64,74836,1296,1297,1523,1284,73771,256,73840,1344,217]

theorem envBound10661 : H12AffineFastState.Bounded env10661 := by
  intro p hp
  have h : env10661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10660_10661 : H12AffineEnvironment.transform 10 1165 env10660 = env10661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1165 env10660 == env10661) = true)

theorem identity10661 : scanCanonicalize (H12AffineFastState.compose env10661 (packedSelected [1,12,21] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10661 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env10662 : List Nat := [2,4,3,16,32,64,128,256,211,1024,1158,1344,8192,1297,8455,65536,1344,1443,1025,8455,1344,73970,16,73730,8322,64,74836,1296,1297,1523,1284,73760,256,73840,1344,210]

theorem envBound10662 : H12AffineFastState.Bounded env10662 := by
  intro p hp
  have h : env10662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10661_10662 : H12AffineEnvironment.transform 2 3 env10661 = env10662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10661 == env10662) = true)

def env10663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1297,1296,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound10663 : H12AffineFastState.Bounded env10663 := by
  intro p hp
  have h : env10663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10652_10663 : H12AffineEnvironment.transform 11 1345 env10652 = env10663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env10652 == env10663) = true)

theorem identity10663 : scanCanonicalize (H12AffineFastState.compose env10663 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99213) := by decide +kernel

theorem selectedBound10663 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,524288,32768,1345,4194304,17,99213,8329,65,4457357,1297,1296,4294795,1932,4294967296,256,4299786023,1345,513]

theorem envBound10664 : H12AffineFastState.Bounded env10664 := by
  intro p hp
  have h : env10664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10663_10664 : H12AffineEnvironment.transform 23 99213 env10663 = env10664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99213 env10663 == env10664) = true)

theorem identity10664 : scanCanonicalize (H12AffineFastState.compose env10664 (packedSelected [4,16,22] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10664 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10665 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,65536,1345,262144,524288,32768,1345,4194304,17,98564,8329,65,4456708,1297,1296,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10665 : H12AffineFastState.Bounded env10665 := by
  intro p hp
  have h : env10665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10664_10665 : H12AffineEnvironment.transform 8 137 env10664 = env10665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10664 == env10665) = true)

theorem identity10665 : scanCanonicalize (H12AffineFastState.compose env10665 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10665 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10666 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,262144,524288,32768,1345,4194304,17,138,8329,65,4456708,1297,1296,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10666 : H12AffineFastState.Bounded env10666 := by
  intro p hp
  have h : env10666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10665_10666 : H12AffineEnvironment.transform 15 33166 env10665 = env10666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10665 == env10666) = true)

theorem identity10666 : scanCanonicalize (H12AffineFastState.compose env10666 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10666 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10667 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,524288,32768,1345,4194304,17,138,8329,65,4237612,1297,1296,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10667 : H12AffineFastState.Bounded env10667 := by
  intro p hp
  have h : env10667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10666_10667 : H12AffineEnvironment.transform 17 43048 env10666 = env10667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10666 == env10667) = true)

def env10668 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,524288,32768,1345,41088,17,138,8329,65,2476,1297,1296,43397,1285,4294967296,256,4295533728,1345,136]

theorem envBound10668 : H12AffineFastState.Bounded env10668 := by
  intro p hp
  have h : env10668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10667_10668 : H12AffineEnvironment.transform 21 41088 env10667 = env10668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env10667 == env10668) = true)

theorem identity10668 : scanCanonicalize (H12AffineFastState.compose env10668 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3459) := by decide +kernel

theorem selectedBound10668 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10669 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,524288,32768,1345,41088,17,138,8329,65,2476,1297,1296,43397,1285,3459,256,567587,1345,136]

theorem envBound10669 : H12AffineFastState.Bounded env10669 := by
  intro p hp
  have h : env10669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10668_10669 : H12AffineEnvironment.transform 31 3459 env10668 = env10669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3459 env10668 == env10669) = true)

theorem identity10669 : scanCanonicalize (H12AffineFastState.compose env10669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1238) := by decide +kernel

theorem selectedBound10669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10670 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1238,1345,8192,1296,32768,33166,1345,42238,524288,32768,1345,41088,17,138,8329,65,1402,1297,1296,42323,1285,341,256,566773,1345,136]

theorem envBound10670 : H12AffineFastState.Bounded env10670 := by
  intro p hp
  have h : env10670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10669_10670 : H12AffineEnvironment.transform 10 1238 env10669 = env10670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1238 env10669 == env10670) = true)

def env10671 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1238,1345,8192,1296,8580,8202,1345,1402,524288,8580,1345,260,17,138,8329,65,1402,1297,1296,1239,1285,341,256,525425,1345,136]

theorem envBound10671 : H12AffineFastState.Bounded env10671 := by
  intro p hp
  have h : env10671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10670_10671 : H12AffineEnvironment.transform 14 8580 env10670 = env10671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env10670 == env10671) = true)

theorem identity10671 : scanCanonicalize (H12AffineFastState.compose env10671 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1247) := by decide +kernel

theorem selectedBound10671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10672 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1238,1345,1247,1296,1371,1237,1345,1402,524288,1371,1345,260,17,138,1110,65,1402,1297,1296,1239,1285,341,256,525425,1345,136]

theorem envBound10672 : H12AffineFastState.Bounded env10672 := by
  intro p hp
  have h : env10672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10671_10672 : H12AffineEnvironment.transform 12 1247 env10671 = env10672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1247 env10671 == env10672) = true)

theorem identity10672 : scanCanonicalize (H12AffineFastState.compose env10672 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10672 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10673 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1238,1093,1247,1044,1119,1237,1093,1150,524288,1119,1093,0,17,138,1110,65,1150,1045,1044,1239,1025,81,4,525425,1093,136]

theorem envBound10673 : H12AffineFastState.Bounded env10673 := by
  intro p hp
  have h : env10673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10672_10673 : H12AffineEnvironment.transform 7 4 env10672 = env10673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10672 == env10673) = true)

theorem identity10673 : scanCanonicalize (H12AffineFastState.compose env10673 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound10673 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10674 : List Nat := [2,4,8,16,32,64,121,4,112,1024,1071,1093,1062,1044,1119,1068,1093,1150,524288,1119,1093,0,17,115,1110,65,1150,1045,1044,1070,1025,81,4,525425,1093,113]

theorem envBound10674 : H12AffineFastState.Bounded env10674 := by
  intro p hp
  have h : env10674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10673_10674 : H12AffineEnvironment.transform 6 121 env10673 = env10674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env10673 == env10674) = true)

theorem identity10674 : scanCanonicalize (H12AffineFastState.compose env10674 (packedSelected [5] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound10674 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10675 : List Nat := [2,4,8,16,32,64,121,4,112,1024,1071,1093,1062,1044,1119,1068,1093,1150,1025,1119,1093,0,17,115,1110,65,1150,1045,1044,1070,1025,81,4,112,1093,113]

theorem envBound10675 : H12AffineFastState.Bounded env10675 := by
  intro p hp
  have h : env10675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10674_10675 : H12AffineEnvironment.transform 18 1025 env10674 = env10675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10674 == env10675) = true)

theorem identity10675 : scanCanonicalize (H12AffineFastState.compose env10675 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10675 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10676 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1071,1044,1062,1044,1038,1068,1044,1071,1025,1038,1044,0,17,34,1031,16,1071,1045,1044,1070,1025,0,4,33,1044,32]

theorem envBound10676 : H12AffineFastState.Bounded env10676 := by
  intro p hp
  have h : env10676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10675_10676 : H12AffineEnvironment.transform 5 17 env10675 = env10676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10675 == env10676) = true)

theorem identity10676 : scanCanonicalize (H12AffineFastState.compose env10676 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10676 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10677 : List Nat := [2,4,8,16,0,17,8,4,1,1024,1039,1044,1030,1044,1038,1036,1044,1039,1025,1038,1044,0,17,2,1031,16,1039,1045,1044,1038,1025,0,4,1,1044,0]

theorem envBound10677 : H12AffineFastState.Bounded env10677 := by
  intro p hp
  have h : env10677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10676_10677 : H12AffineEnvironment.transform 4 0 env10676 = env10677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10676 == env10677) = true)

def env10678 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1238,1345,8192,1296,8581,8203,1345,1403,524288,8581,1345,261,17,138,8329,65,1402,1297,1296,1238,1285,341,256,525424,1345,136]

theorem envBound10678 : H12AffineFastState.Bounded env10678 := by
  intro p hp
  have h : env10678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10670_10678 : H12AffineEnvironment.transform 14 8581 env10670 = env10678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env10670 == env10678) = true)

theorem identity10678 : scanCanonicalize (H12AffineFastState.compose env10678 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10678 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10679 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1238,1093,8192,1044,8321,8203,1093,1151,524288,8321,1093,1,17,138,8329,65,1150,1045,1044,1238,1025,81,4,525424,1093,136]

theorem envBound10679 : H12AffineFastState.Bounded env10679 := by
  intro p hp
  have h : env10679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10678_10679 : H12AffineEnvironment.transform 7 4 env10678 = env10679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10678 == env10679) = true)

theorem identity10679 : scanCanonicalize (H12AffineFastState.compose env10679 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 1143) := by decide +kernel

theorem selectedBound10679 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10680 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1238,1093,1143,1044,1270,1148,1093,1151,524288,1270,1093,1,17,138,1278,65,1150,1045,1044,1238,1025,81,4,525424,1093,136]

theorem envBound10680 : H12AffineFastState.Bounded env10680 := by
  intro p hp
  have h : env10680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10679_10680 : H12AffineEnvironment.transform 12 1143 env10679 = env10680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1143 env10679 == env10680) = true)

theorem identity10680 : scanCanonicalize (H12AffineFastState.compose env10680 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10680 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10681 : List Nat := [2,4,8,16,32,64,120,4,113,1024,1070,1093,1143,1044,1038,1148,1093,1151,524288,1038,1093,1,17,114,1030,65,1150,1045,1044,1070,1025,81,4,525424,1093,112]

theorem envBound10681 : H12AffineFastState.Bounded env10681 := by
  intro p hp
  have h : env10681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10680_10681 : H12AffineEnvironment.transform 6 120 env10680 = env10681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10680 == env10681) = true)

def env10682 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1038,1093,1111,1044,1038,1116,1093,1119,524288,1038,1093,1,17,82,1030,65,1118,1045,1044,1038,1025,81,4,525392,1093,80]

theorem envBound10682 : H12AffineFastState.Bounded env10682 := by
  intro p hp
  have h : env10682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10681_10682 : H12AffineEnvironment.transform 4 0 env10681 = env10682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10681 == env10682) = true)

def env10683 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1038,1093,1111,1044,1038,1116,1093,1119,1024,1038,1093,1,17,82,1030,65,1118,1045,1044,1038,1025,81,4,80,1093,80]

theorem envBound10683 : H12AffineFastState.Bounded env10683 := by
  intro p hp
  have h : env10683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10682_10683 : H12AffineEnvironment.transform 18 1024 env10682 = env10683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10682 == env10683) = true)

theorem identity10683 : scanCanonicalize (H12AffineFastState.compose env10683 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10683 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10684 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1038,1044,1030,1044,1038,1037,1044,1038,1024,1038,1044,1,17,3,1030,16,1039,1045,1044,1038,1025,0,4,1,1044,1]

theorem envBound10684 : H12AffineFastState.Bounded env10684 := by
  intro p hp
  have h : env10684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10683_10684 : H12AffineEnvironment.transform 5 17 env10683 = env10684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10683 == env10684) = true)

def leafEnv10684 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1038,1044,1030,1044,1038,1037,1044,1038,1024,1038,1044,1,17,3,1024,1030,1,16,1039,1045,1044,1038,1025,0,4,1,5,1037,1044,1,0,1045,1]

def active10684 : List Nat := [0,1,2,3,9]

def tree10684 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10684 : H12WitnessSearch.Good tree10684 := H12GlobalWitnessIndex.good

theorem leafIdentity10684 : H12AffineFastState.composeSystem env10684 rootObs = leafEnv10684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10684 rootObs == leafEnv10684) = true)

theorem terminalChecked10684 : H12PackedTerminal.terminalCheckFast leafEnv10684 active10684 tree10684 = true := by decide +kernel

def env10685 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1038,1093,1111,1044,1038,1116,1093,1119,1025,1038,1093,1,17,82,1030,65,1118,1045,1044,1038,1025,81,4,81,1093,80]

theorem envBound10685 : H12AffineFastState.Bounded env10685 := by
  intro p hp
  have h : env10685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10682_10685 : H12AffineEnvironment.transform 18 1025 env10682 = env10685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10682 == env10685) = true)

def leafEnv10685 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1038,1093,1111,1044,1038,1116,1093,1119,1025,1038,1093,1,17,82,1025,1030,1,65,1118,1045,1044,1038,1025,81,4,81,5,1037,1093,80,0,1045,1]

def active10685 : List Nat := [0,1,2,3,5,9]

def tree10685 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10685 : H12WitnessSearch.Good tree10685 := H12GlobalWitnessIndex.good

theorem leafIdentity10685 : H12AffineFastState.composeSystem env10685 rootObs = leafEnv10685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10685 rootObs == leafEnv10685) = true)

theorem terminalChecked10685 : H12PackedTerminal.terminalCheckFast leafEnv10685 active10685 tree10685 = true := by decide +kernel

def env10686 : List Nat := [2,4,8,16,1,64,89,4,80,1024,1039,1093,1110,1044,1038,1117,1093,1118,524288,1038,1093,1,17,83,1030,65,1119,1045,1044,1039,1025,81,4,525393,1093,81]

theorem envBound10686 : H12AffineFastState.Bounded env10686 := by
  intro p hp
  have h : env10686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10681_10686 : H12AffineEnvironment.transform 4 1 env10681 = env10686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10681 == env10686) = true)

theorem identity10686 : scanCanonicalize (H12AffineFastState.compose env10686 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10686 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10687 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1039,1045,1030,1044,1038,1037,1045,1038,524288,1038,1045,1,17,3,1030,17,1039,1045,1044,1039,1025,1,4,525313,1045,1]

theorem envBound10687 : H12AffineFastState.Bounded env10687 := by
  intro p hp
  have h : env10687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10686_10687 : H12AffineEnvironment.transform 5 16 env10686 = env10687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10686 == env10687) = true)

def leafEnv10687 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1039,1045,1030,1044,1038,1037,1045,1038,524288,1038,1045,1,17,3,524288,1030,1,17,1039,1045,1044,1039,1025,1,4,525313,5,1037,1045,1,0,1045,1]

def active10687 : List Nat := [0,1,2,3,9,18]

def tree10687 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10687 : H12WitnessSearch.Good tree10687 := H12GlobalWitnessIndex.good

theorem leafIdentity10687 : H12AffineFastState.composeSystem env10687 rootObs = leafEnv10687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10687 rootObs == leafEnv10687) = true)

theorem terminalChecked10687 : H12PackedTerminal.terminalCheckFast leafEnv10687 active10687 tree10687 = true := by decide +kernel

def env10688 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,524288,32768,1345,41089,17,138,8329,65,2477,1297,1296,43396,1285,4294967296,256,4295533729,1345,136]

theorem envBound10688 : H12AffineFastState.Bounded env10688 := by
  intro p hp
  have h : env10688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10667_10688 : H12AffineEnvironment.transform 21 41089 env10667 = env10688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env10667 == env10688) = true)

theorem identity10688 : scanCanonicalize (H12AffineFastState.compose env10688 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44175) := by decide +kernel

theorem selectedBound10688 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10689 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,524288,32768,1345,41089,17,138,8329,65,2477,1297,1296,43396,1285,44175,256,526382,1345,136]

theorem envBound10689 : H12AffineFastState.Bounded env10689 := by
  intro p hp
  have h : env10689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10688_10689 : H12AffineEnvironment.transform 31 44175 env10688 = env10689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44175 env10688 == env10689) = true)

theorem identity10689 : scanCanonicalize (H12AffineFastState.compose env10689 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 43482) := by decide +kernel

theorem selectedBound10689 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10690 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1345,43048,43482,32768,1345,41089,17,138,8329,65,2477,1297,1296,43396,1285,44175,256,41460,1345,136]

theorem envBound10690 : H12AffineFastState.Bounded env10690 := by
  intro p hp
  have h : env10690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10689_10690 : H12AffineEnvironment.transform 18 43482 env10689 = env10690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 43482 env10689 == env10690) = true)

def env10691 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2184,2310,1345,8352,8530,2184,1345,10249,17,138,8329,65,2477,1297,1296,8460,1285,9223,256,10620,1345,136]

theorem envBound10691 : H12AffineFastState.Bounded env10691 := by
  intro p hp
  have h : env10691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10690_10691 : H12AffineEnvironment.transform 14 2184 env10690 = env10691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env10690 == env10691) = true)

theorem identity10691 : scanCanonicalize (H12AffineFastState.compose env10691 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10691 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10692 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,8192,1044,2184,2050,1093,8352,8278,2184,1093,10249,17,138,8329,65,2217,1045,1044,8200,1025,9223,4,10360,1093,136]

theorem envBound10692 : H12AffineFastState.Bounded env10692 := by
  intro p hp
  have h : env10692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10691_10692 : H12AffineEnvironment.transform 7 4 env10691 = env10692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10691 == env10692) = true)

theorem identity10692 : scanCanonicalize (H12AffineFastState.compose env10692 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2289) := by decide +kernel

theorem selectedBound10692 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10693 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,2289,1044,2184,2050,1093,2129,2215,2184,1093,248,17,138,2168,65,2217,1045,1044,2297,1025,3318,4,137,1093,136]

theorem envBound10693 : H12AffineFastState.Bounded env10693 := by
  intro p hp
  have h : env10693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10692_10693 : H12AffineEnvironment.transform 12 2289 env10692 = env10693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2289 env10692 == env10693) = true)

theorem identity10693 : scanCanonicalize (H12AffineFastState.compose env10693 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound10693 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env10694 : List Nat := [2,4,8,16,32,64,121,4,112,1024,2048,1093,2056,1044,2161,2050,1093,2129,2142,2161,1093,1,17,115,2168,65,2128,1045,1044,2048,1025,3087,4,112,1093,113]

theorem envBound10694 : H12AffineFastState.Bounded env10694 := by
  intro p hp
  have h : env10694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10693_10694 : H12AffineEnvironment.transform 6 121 env10693 = env10694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env10693 == env10694) = true)

theorem identity10694 : scanCanonicalize (H12AffineFastState.compose env10694 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10694 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10695 : List Nat := [2,4,8,16,32,17,40,4,33,1024,2048,1044,2056,1044,2080,2050,1044,2048,2063,2080,1044,1,17,34,2089,16,2049,1045,1044,2048,1025,3087,4,33,1044,32]

theorem envBound10695 : H12AffineFastState.Bounded env10695 := by
  intro p hp
  have h : env10695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10694_10695 : H12AffineEnvironment.transform 5 17 env10694 = env10695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10694 == env10695) = true)

theorem identity10695 : scanCanonicalize (H12AffineFastState.compose env10695 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound10695 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10696 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1044,1030,1044,1070,1036,1044,1038,1025,1070,1044,1,17,34,1063,16,1039,1045,1044,1038,1025,1,4,33,1044,32]

theorem envBound10696 : H12AffineFastState.Bounded env10696 := by
  intro p hp
  have h : env10696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10695_10696 : H12AffineEnvironment.transform 10 1038 env10695 = env10696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env10695 == env10696) = true)

def leafEnv10696 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1044,1030,1044,1070,1036,1044,1038,1025,1070,1044,1,17,34,1025,1063,1,16,1039,1045,1044,1038,1025,1,4,33,5,1069,1044,32,0,1045,1]

def active10696 : List Nat := [0,1,2,3,4,9]

def tree10696 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10696 : H12WitnessSearch.Good tree10696 := H12GlobalWitnessIndex.good

theorem leafIdentity10696 : H12AffineFastState.composeSystem env10696 rootObs = leafEnv10696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10696 rootObs == leafEnv10696) = true)

theorem terminalChecked10696 : H12PackedTerminal.terminalCheckFast leafEnv10696 active10696 tree10696 = true := by decide +kernel

def env10697 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2185,2311,1345,8353,8531,2185,1345,10248,17,138,8329,65,2477,1297,1296,8461,1285,9222,256,10621,1345,136]

theorem envBound10697 : H12AffineFastState.Bounded env10697 := by
  intro p hp
  have h : env10697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10690_10697 : H12AffineEnvironment.transform 14 2185 env10690 = env10697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env10690 == env10697) = true)

theorem identity10697 : scanCanonicalize (H12AffineFastState.compose env10697 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound10697 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10698 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2057,1296,2185,2311,1345,2216,2394,2185,1345,1,17,138,2176,65,2477,1297,1296,2308,1285,3087,256,372,1345,136]

theorem envBound10698 : H12AffineFastState.Bounded env10698 := by
  intro p hp
  have h : env10698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10697_10698 : H12AffineEnvironment.transform 12 2057 env10697 = env10698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env10697 == env10698) = true)

theorem identity10698 : scanCanonicalize (H12AffineFastState.compose env10698 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10698 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10699 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,2057,1092,2185,2131,1045,2216,2062,2185,1045,1,17,138,2176,65,2297,1093,1092,2128,1105,3087,84,32,1045,136]

theorem envBound10699 : H12AffineFastState.Bounded env10699 := by
  intro p hp
  have h : env10699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10698_10699 : H12AffineEnvironment.transform 7 84 env10698 = env10699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10698 == env10699) = true)

theorem identity10699 : scanCanonicalize (H12AffineFastState.compose env10699 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound10699 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10700 : List Nat := [2,4,8,16,32,64,121,84,112,1024,2048,1045,2057,1092,2160,2131,1045,2129,2062,2160,1045,1,17,115,2169,65,2048,1093,1092,2128,1105,3087,84,32,1045,113]

theorem envBound10700 : H12AffineFastState.Bounded env10700 := by
  intro p hp
  have h : env10700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10699_10700 : H12AffineEnvironment.transform 6 121 env10699 = env10700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env10699 == env10700) = true)

theorem identity10700 : scanCanonicalize (H12AffineFastState.compose env10700 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10700 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10701 : List Nat := [2,4,8,16,32,16,41,4,32,1024,2048,1045,2057,1044,2080,2051,1045,2049,2062,2080,1045,1,17,35,2089,17,2048,1045,1044,2048,1025,3087,4,32,1045,33]

theorem envBound10701 : H12AffineFastState.Bounded env10701 := by
  intro p hp
  have h : env10701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10700_10701 : H12AffineEnvironment.transform 5 16 env10700 = env10701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10700 == env10701) = true)

theorem identity10701 : scanCanonicalize (H12AffineFastState.compose env10701 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound10701 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10702 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1039,1045,1030,1044,1071,1036,1045,1038,1025,1071,1045,1,17,35,1062,17,1039,1045,1044,1039,1025,0,4,32,1045,33]

theorem envBound10702 : H12AffineFastState.Bounded env10702 := by
  intro p hp
  have h : env10702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10701_10702 : H12AffineEnvironment.transform 10 1039 env10701 = env10702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env10701 == env10702) = true)

theorem identity10702 : scanCanonicalize (H12AffineFastState.compose env10702 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10703 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1039,1045,1030,1044,1039,1036,1045,1038,1025,1039,1045,1,17,3,1030,17,1039,1045,1044,1039,1025,0,4,0,1045,1]

theorem envBound10703 : H12AffineFastState.Bounded env10703 := by
  intro p hp
  have h : env10703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10702_10703 : H12AffineEnvironment.transform 4 0 env10702 = env10703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10702 == env10703) = true)

def leafEnv10703 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1039,1045,1030,1044,1039,1036,1045,1038,1025,1039,1045,1,17,3,1025,1030,1,17,1039,1045,1044,1039,1025,0,4,0,5,1036,1045,1,0,1045,1]

def active10703 : List Nat := [0,1,2,3,9]

def tree10703 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10703 : H12WitnessSearch.Good tree10703 := H12GlobalWitnessIndex.good

theorem leafIdentity10703 : H12AffineFastState.composeSystem env10703 rootObs = leafEnv10703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10703 rootObs == leafEnv10703) = true)

theorem terminalChecked10703 : H12PackedTerminal.terminalCheckFast leafEnv10703 active10703 tree10703 = true := by decide +kernel

def env10704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,524288,32768,4096,4194304,5456,16777216,8329,5376,21331968,4176,4176,4294795,16876545,4294967296,256,4316464298,4097,513]

theorem envBound10704 : H12AffineFastState.Bounded env10704 := by
  intro p hp
  have h : env10704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10651_10704 : H12AffineEnvironment.transform 16 4097 env10651 = env10704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10651 == env10704) = true)

def env10705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound10705 : H12AffineFastState.Bounded env10705 := by
  intro p hp
  have h : env10705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10704_10705 : H12AffineEnvironment.transform 11 1344 env10704 = env10705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env10704 == env10705) = true)

theorem identity10705 : scanCanonicalize (H12AffineFastState.compose env10705 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10705 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10706 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1345,136]

theorem envBound10706 : H12AffineFastState.Bounded env10706 := by
  intro p hp
  have h : env10706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10705_10706 : H12AffineEnvironment.transform 8 137 env10705 = env10706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10705 == env10706) = true)

theorem identity10706 : scanCanonicalize (H12AffineFastState.compose env10706 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound10706 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10707 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1344,4194304,16,98564,8329,64,4456708,1296,1296,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10707 : H12AffineFastState.Bounded env10707 := by
  intro p hp
  have h : env10707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10706_10707 : H12AffineEnvironment.transform 23 98564 env10706 = env10707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env10706 == env10707) = true)

theorem identity10707 : scanCanonicalize (H12AffineFastState.compose env10707 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10707 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10708 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,262144,524288,32768,1344,4194304,16,138,8329,64,4456708,1296,1296,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10708 : H12AffineFastState.Bounded env10708 := by
  intro p hp
  have h : env10708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10707_10708 : H12AffineEnvironment.transform 15 33166 env10707 = env10708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10707 == env10708) = true)

theorem identity10708 : scanCanonicalize (H12AffineFastState.compose env10708 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound10708 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10709 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,524288,32768,1344,4194304,16,138,8329,64,4237612,1296,1296,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10709 : H12AffineFastState.Bounded env10709 := by
  intro p hp
  have h : env10709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10708_10709 : H12AffineEnvironment.transform 17 43048 env10708 = env10709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env10708 == env10709) = true)

def env10710 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,524288,32768,1344,41088,16,138,8329,64,2476,1296,1296,43397,1285,4294967296,256,4295533728,1345,136]

theorem envBound10710 : H12AffineFastState.Bounded env10710 := by
  intro p hp
  have h : env10710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10709_10710 : H12AffineEnvironment.transform 21 41088 env10709 = env10710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env10709 == env10710) = true)

theorem identity10710 : scanCanonicalize (H12AffineFastState.compose env10710 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3458) := by decide +kernel

theorem selectedBound10710 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10711 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,524288,32768,1344,41088,16,138,8329,64,2476,1296,1296,43397,1285,3458,256,567586,1345,136]

theorem envBound10711 : H12AffineFastState.Bounded env10711 := by
  intro p hp
  have h : env10711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10710_10711 : H12AffineEnvironment.transform 31 3458 env10710 = env10711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3458 env10710 == env10711) = true)

theorem identity10711 : scanCanonicalize (H12AffineFastState.compose env10711 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1239) := by decide +kernel

theorem selectedBound10711 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10712 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1239,1344,8192,1297,32768,33166,1345,42239,524288,32768,1344,41088,16,138,8329,64,1403,1296,1296,42322,1285,341,256,566773,1345,136]

theorem envBound10712 : H12AffineFastState.Bounded env10712 := by
  intro p hp
  have h : env10712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10711_10712 : H12AffineEnvironment.transform 10 1239 env10711 = env10712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1239 env10711 == env10712) = true)

def env10713 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1239,1344,8192,1297,8580,8202,1345,1403,524288,8580,1344,260,16,138,8329,64,1403,1296,1296,1238,1285,341,256,525425,1345,136]

theorem envBound10713 : H12AffineFastState.Bounded env10713 := by
  intro p hp
  have h : env10713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10712_10713 : H12AffineEnvironment.transform 14 8580 env10712 = env10713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env10712 == env10713) = true)

theorem identity10713 : scanCanonicalize (H12AffineFastState.compose env10713 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1246) := by decide +kernel

theorem selectedBound10713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10714 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1239,1344,1246,1297,1370,1236,1345,1403,524288,1370,1344,260,16,138,1111,64,1403,1296,1296,1238,1285,341,256,525425,1345,136]

theorem envBound10714 : H12AffineFastState.Bounded env10714 := by
  intro p hp
  have h : env10714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10713_10714 : H12AffineEnvironment.transform 12 1246 env10713 = env10714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1246 env10713 == env10714) = true)

theorem identity10714 : scanCanonicalize (H12AffineFastState.compose env10714 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10714 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10715 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1239,1092,1246,1045,1118,1236,1093,1151,524288,1118,1092,0,16,138,1111,64,1151,1044,1044,1238,1025,81,4,525425,1093,136]

theorem envBound10715 : H12AffineFastState.Bounded env10715 := by
  intro p hp
  have h : env10715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10714_10715 : H12AffineEnvironment.transform 7 4 env10714 = env10715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10714 == env10715) = true)

theorem identity10715 : scanCanonicalize (H12AffineFastState.compose env10715 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10715 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10716 : List Nat := [2,4,8,16,32,64,120,4,113,1024,1071,1092,1062,1045,1118,1068,1093,1151,524288,1118,1092,0,16,114,1111,64,1151,1044,1044,1070,1025,81,4,525425,1093,112]

theorem envBound10716 : H12AffineFastState.Bounded env10716 := by
  intro p hp
  have h : env10716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10715_10716 : H12AffineEnvironment.transform 6 120 env10715 = env10716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10715 == env10716) = true)

theorem identity10716 : scanCanonicalize (H12AffineFastState.compose env10716 (packedSelected [5] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound10716 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10717 : List Nat := [2,4,8,16,32,64,120,4,113,1024,1071,1092,1062,1045,1118,1068,1093,1151,1025,1118,1092,0,16,114,1111,64,1151,1044,1044,1070,1025,81,4,112,1093,112]

theorem envBound10717 : H12AffineFastState.Bounded env10717 := by
  intro p hp
  have h : env10717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10716_10717 : H12AffineEnvironment.transform 18 1025 env10716 = env10717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10716 == env10717) = true)

def env10718 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1239,1344,8192,1297,8581,8203,1345,1402,524288,8581,1344,261,16,138,8329,64,1403,1296,1296,1239,1285,341,256,525424,1345,136]

theorem envBound10718 : H12AffineFastState.Bounded env10718 := by
  intro p hp
  have h : env10718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10712_10718 : H12AffineEnvironment.transform 14 8581 env10712 = env10718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env10712 == env10718) = true)

theorem identity10718 : scanCanonicalize (H12AffineFastState.compose env10718 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10719 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1239,1092,8192,1045,8321,8203,1093,1150,524288,8321,1092,1,16,138,8329,64,1151,1044,1044,1239,1025,81,4,525424,1093,136]

theorem envBound10719 : H12AffineFastState.Bounded env10719 := by
  intro p hp
  have h : env10719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10718_10719 : H12AffineEnvironment.transform 7 4 env10718 = env10719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10718 == env10719) = true)

theorem identity10719 : scanCanonicalize (H12AffineFastState.compose env10719 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 1142) := by decide +kernel

theorem selectedBound10719 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10720 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1239,1092,1142,1045,1271,1149,1093,1150,524288,1271,1092,1,16,138,1279,64,1151,1044,1044,1239,1025,81,4,525424,1093,136]

theorem envBound10720 : H12AffineFastState.Bounded env10720 := by
  intro p hp
  have h : env10720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10719_10720 : H12AffineEnvironment.transform 12 1142 env10719 = env10720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1142 env10719 == env10720) = true)

theorem identity10720 : scanCanonicalize (H12AffineFastState.compose env10720 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound10720 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10721 : List Nat := [2,4,8,16,32,64,121,4,112,1024,1070,1092,1142,1045,1038,1149,1093,1150,524288,1038,1092,1,16,115,1030,64,1151,1044,1044,1070,1025,81,4,525424,1093,113]

theorem envBound10721 : H12AffineFastState.Bounded env10721 := by
  intro p hp
  have h : env10721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10720_10721 : H12AffineEnvironment.transform 6 121 env10720 = env10721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env10720 == env10721) = true)

def env10722 : List Nat := [2,4,8,16,0,64,89,4,80,1024,1038,1092,1110,1045,1038,1117,1093,1118,524288,1038,1092,1,16,83,1030,64,1119,1044,1044,1038,1025,81,4,525392,1093,81]

theorem envBound10722 : H12AffineFastState.Bounded env10722 := by
  intro p hp
  have h : env10722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10721_10722 : H12AffineEnvironment.transform 4 0 env10721 = env10722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10721 == env10722) = true)

theorem identity10722 : scanCanonicalize (H12AffineFastState.compose env10722 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10723 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1038,1044,1030,1045,1038,1037,1045,1038,524288,1038,1044,1,16,3,1030,16,1039,1044,1044,1038,1025,1,4,525312,1045,1]

theorem envBound10723 : H12AffineFastState.Bounded env10723 := by
  intro p hp
  have h : env10723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10722_10723 : H12AffineEnvironment.transform 5 16 env10722 = env10723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10722 == env10723) = true)

def leafEnv10723 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1038,1044,1030,1045,1038,1037,1045,1038,524288,1038,1044,1,16,3,524288,1030,1,16,1039,1044,1044,1038,1025,1,4,525312,5,1037,1045,1,0,1045,1]

def active10723 : List Nat := [0,1,2,3,9,18]

def tree10723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10723 : H12WitnessSearch.Good tree10723 := H12GlobalWitnessIndex.good

theorem leafIdentity10723 : H12AffineFastState.composeSystem env10723 rootObs = leafEnv10723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10723 rootObs == leafEnv10723) = true)

theorem terminalChecked10723 : H12PackedTerminal.terminalCheckFast leafEnv10723 active10723 tree10723 = true := by decide +kernel

def env10724 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1039,1092,1111,1045,1038,1116,1093,1119,524288,1038,1092,1,16,82,1030,64,1118,1044,1044,1039,1025,81,4,525393,1093,80]

theorem envBound10724 : H12AffineFastState.Bounded env10724 := by
  intro p hp
  have h : env10724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10721_10724 : H12AffineEnvironment.transform 4 1 env10721 = env10724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10721 == env10724) = true)

def env10725 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1039,1092,1111,1045,1038,1116,1093,1119,1024,1038,1092,1,16,82,1030,64,1118,1044,1044,1039,1025,81,4,81,1093,80]

theorem envBound10725 : H12AffineFastState.Bounded env10725 := by
  intro p hp
  have h : env10725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10725 : H12AffineEnvironment.transform 18 1024 env10724 = env10725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10724 == env10725) = true)

theorem identity10725 : scanCanonicalize (H12AffineFastState.compose env10725 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10726 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1045,1030,1045,1038,1037,1044,1038,1024,1038,1045,1,16,3,1030,17,1039,1044,1044,1039,1025,0,4,0,1044,1]

theorem envBound10726 : H12AffineFastState.Bounded env10726 := by
  intro p hp
  have h : env10726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10725_10726 : H12AffineEnvironment.transform 5 17 env10725 = env10726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10725 == env10726) = true)

def leafEnv10726 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1045,1030,1045,1038,1037,1044,1038,1024,1038,1045,1,16,3,1024,1030,1,17,1039,1044,1044,1039,1025,0,4,0,5,1037,1044,1,0,1045,1]

def active10726 : List Nat := [0,1,2,3,9]

def tree10726 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10726 : H12WitnessSearch.Good tree10726 := H12GlobalWitnessIndex.good

theorem leafIdentity10726 : H12AffineFastState.composeSystem env10726 rootObs = leafEnv10726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10726 rootObs == leafEnv10726) = true)

theorem terminalChecked10726 : H12PackedTerminal.terminalCheckFast leafEnv10726 active10726 tree10726 = true := by decide +kernel

def env10727 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1039,1092,1111,1045,1038,1116,1093,1119,1025,1038,1092,1,16,82,1030,64,1118,1044,1044,1039,1025,81,4,80,1093,80]

theorem envBound10727 : H12AffineFastState.Bounded env10727 := by
  intro p hp
  have h : env10727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10727 : H12AffineEnvironment.transform 18 1025 env10724 = env10727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10724 == env10727) = true)

def leafEnv10727 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1039,1092,1111,1045,1038,1116,1093,1119,1025,1038,1092,1,16,82,1025,1030,1,64,1118,1044,1044,1039,1025,81,4,80,5,1037,1093,80,0,1045,1]

def active10727 : List Nat := [0,1,2,3,5,9]

def tree10727 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10727 : H12WitnessSearch.Good tree10727 := H12GlobalWitnessIndex.good

theorem leafIdentity10727 : H12AffineFastState.composeSystem env10727 rootObs = leafEnv10727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10727 rootObs == leafEnv10727) = true)

theorem terminalChecked10727 : H12PackedTerminal.terminalCheckFast leafEnv10727 active10727 tree10727 = true := by decide +kernel

def env10728 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,524288,32768,1344,41089,16,138,8329,64,2477,1296,1296,43396,1285,4294967296,256,4295533729,1345,136]

theorem envBound10728 : H12AffineFastState.Bounded env10728 := by
  intro p hp
  have h : env10728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2