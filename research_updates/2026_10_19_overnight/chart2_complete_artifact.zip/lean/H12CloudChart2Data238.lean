import H12CloudChart2Data237

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans60123_60124 : H12AffineEnvironment.transform 10 1442 env60123 = env60124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env60123 == env60124) = true)

theorem identity60124 : scanCanonicalize (H12AffineFastState.compose env60124 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60124 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60125 : List Nat := [2,4,8,16,32,64,128,256,340,272,178,1,24,1,276,35,324,162,320,277,1,477,260,51,192,261,319,277,0,210,21,260,256,17,81,261]

theorem envBound60125 : H12AffineFastState.Bounded env60125 := by
  intro p hp
  have h : env60125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60124_60125 : H12AffineEnvironment.transform 9 272 env60124 = env60125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60124 == env60125) = true)

theorem identity60125 : scanCanonicalize (H12AffineFastState.compose env60125 (packedSelected [8,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound60125 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env60126 : List Nat := [2,4,8,16,32,64,128,19,71,3,178,1,24,1,7,35,87,162,83,6,1,206,23,51,192,22,44,6,0,210,21,23,19,17,81,22]

theorem envBound60126 : H12AffineFastState.Bounded env60126 := by
  intro p hp
  have h : env60126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60125_60126 : H12AffineEnvironment.transform 7 19 env60125 = env60126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env60125 == env60126) = true)

theorem identity60126 : scanCanonicalize (H12AffineFastState.compose env60126 (packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound60126 : packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env60127 : List Nat := [2,4,8,16,32,64,100,19,71,3,86,1,24,1,7,35,87,70,83,6,1,42,23,51,36,22,44,6,0,54,21,23,19,17,81,22]

theorem envBound60127 : H12AffineFastState.Bounded env60127 := by
  intro p hp
  have h : env60127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60126_60127 : H12AffineEnvironment.transform 6 100 env60126 = env60127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env60126 == env60127) = true)

theorem identity60127 : scanCanonicalize (H12AffineFastState.compose env60127 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60127 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60128 : List Nat := [2,4,8,16,32,58,30,19,61,3,44,1,24,1,7,35,45,60,41,6,1,42,23,51,36,22,44,6,0,54,21,23,19,17,43,22]

theorem envBound60128 : H12AffineFastState.Bounded env60128 := by
  intro p hp
  have h : env60128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60127_60128 : H12AffineEnvironment.transform 5 58 env60127 = env60128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60127 == env60128) = true)

theorem identity60128 : scanCanonicalize (H12AffineFastState.compose env60128 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60128 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env60129 : List Nat := [2,4,8,11,32,33,5,8,38,3,44,1,3,1,7,35,45,39,41,6,1,42,12,40,36,13,44,6,0,45,14,12,8,10,43,13]

theorem envBound60129 : H12AffineFastState.Bounded env60129 := by
  intro p hp
  have h : env60129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60128_60129 : H12AffineEnvironment.transform 3 11 env60128 = env60129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60128 == env60129) = true)

theorem identity60129 : scanCanonicalize (H12AffineFastState.compose env60129 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60129 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60130 : List Nat := [2,4,8,11,1,0,5,8,7,3,13,1,3,1,7,2,12,6,8,6,1,11,12,9,5,13,13,6,0,12,14,12,8,10,10,13]

theorem envBound60130 : H12AffineFastState.Bounded env60130 := by
  intro p hp
  have h : env60130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60129_60130 : H12AffineEnvironment.transform 4 1 env60129 = env60130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60129 == env60130) = true)

theorem identity60130 : scanCanonicalize (H12AffineFastState.compose env60130 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60130 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60131 : List Nat := [2,3,8,11,1,0,2,8,0,3,10,1,3,1,0,2,11,1,8,1,1,11,11,9,2,10,10,1,0,11,9,11,8,10,10,10]

theorem envBound60131 : H12AffineFastState.Bounded env60131 := by
  intro p hp
  have h : env60131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60130_60131 : H12AffineEnvironment.transform 1 3 env60130 = env60131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60130 == env60131) = true)

theorem identity60131 : scanCanonicalize (H12AffineFastState.compose env60131 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60132 : List Nat := [2,3,2,1,1,0,2,2,0,3,0,1,3,1,0,2,1,1,2,1,1,1,1,3,2,0,0,1,0,1,3,1,2,0,0,0]

theorem envBound60132 : H12AffineFastState.Bounded env60132 := by
  intro p hp
  have h : env60132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60131_60132 : H12AffineEnvironment.transform 2 2 env60131 = env60132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60131 == env60132) = true)

def env60133 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4096,477,70710,69649,192,65830,4414,69943,1296,67651,5380,69926,256,5376,1345,5141]

theorem envBound60133 : H12AffineFastState.Bounded env60133 := by
  intro p hp
  have h : env60133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60112_60133 : H12AffineEnvironment.transform 8 341 env60112 = env60133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env60112 == env60133) = true)

def env60134 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,276,65536,65894,65665,321,277,0,477,66614,65553,192,65830,318,65847,1296,67651,1284,65830,256,1280,1345,1045]

theorem envBound60134 : H12AffineFastState.Bounded env60134 := by
  intro p hp
  have h : env60134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60133_60134 : H12AffineEnvironment.transform 11 0 env60133 = env60134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env60133 == env60134) = true)

theorem identity60134 : scanCanonicalize (H12AffineFastState.compose env60134 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60134 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60135 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,276,114,276,243,321,277,0,477,1092,99,192,340,318,325,1296,2097,1284,340,256,1280,1345,1045]

theorem envBound60135 : H12AffineFastState.Bounded env60135 := by
  intro p hp
  have h : env60135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60134_60135 : H12AffineEnvironment.transform 15 114 env60134 = env60135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60134 == env60135) = true)

theorem identity60135 : scanCanonicalize (H12AffineFastState.compose env60135 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 287) := by decide +kernel

theorem selectedBound60135 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env60136 : List Nat := [2,4,8,16,32,64,128,256,341,1024,287,0,1289,1297,276,114,276,243,321,277,0,477,1092,99,192,340,318,325,1296,302,1284,340,256,1280,1345,1045]

theorem envBound60136 : H12AffineFastState.Bounded env60136 := by
  intro p hp
  have h : env60136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60135_60136 : H12AffineEnvironment.transform 10 287 env60135 = env60136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 287 env60135 == env60136) = true)

theorem identity60136 : scanCanonicalize (H12AffineFastState.compose env60136 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound60136 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env60137 : List Nat := [2,4,8,16,32,64,128,256,341,320,287,0,73,81,276,114,276,243,321,277,0,477,260,99,192,340,318,325,80,302,68,340,256,64,1,341]

theorem envBound60137 : H12AffineFastState.Bounded env60137 := by
  intro p hp
  have h : env60137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60136_60137 : H12AffineEnvironment.transform 9 320 env60136 = env60137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60136 == env60137) = true)

theorem identity60137 : scanCanonicalize (H12AffineFastState.compose env60137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound60137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60138 : List Nat := [2,4,8,16,32,64,128,140,217,204,147,0,73,81,152,114,152,243,205,153,0,81,136,99,192,216,178,201,80,162,68,216,140,64,1,217]

theorem envBound60138 : H12AffineFastState.Bounded env60138 := by
  intro p hp
  have h : env60138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60137_60138 : H12AffineEnvironment.transform 7 140 env60137 = env60138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env60137 == env60138) = true)

theorem identity60138 : scanCanonicalize (H12AffineFastState.compose env60138 (packedSelected [1,3,4,8,9,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound60138 : packedSelected [1,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60139 : List Nat := [2,4,8,13,32,64,128,140,196,204,142,0,73,76,133,111,133,238,205,132,0,76,136,99,192,197,175,201,77,162,68,197,140,64,1,196]

theorem envBound60139 : H12AffineFastState.Bounded env60139 := by
  intro p hp
  have h : env60139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60138_60139 : H12AffineEnvironment.transform 3 13 env60138 = env60139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env60138 == env60139) = true)

theorem identity60139 : scanCanonicalize (H12AffineFastState.compose env60139 (packedSelected [0,1,2,3,4,5,7,9,13] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound60139 : packedSelected [0,1,2,3,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env60140 : List Nat := [2,4,8,13,32,64,99,111,39,47,109,0,73,76,102,111,102,13,46,103,0,76,107,99,35,38,76,42,77,65,68,38,111,64,1,39]

theorem envBound60140 : H12AffineFastState.Bounded env60140 := by
  intro p hp
  have h : env60140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60139_60140 : H12AffineEnvironment.transform 6 99 env60139 = env60140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env60139 == env60140) = true)

theorem identity60140 : scanCanonicalize (H12AffineFastState.compose env60140 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound60140 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60141 : List Nat := [2,4,8,13,32,13,46,34,39,47,32,0,4,1,43,34,43,13,46,42,0,1,38,46,35,38,1,42,0,12,9,38,34,13,1,39]

theorem envBound60141 : H12AffineFastState.Bounded env60141 := by
  intro p hp
  have h : env60141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60140_60141 : H12AffineEnvironment.transform 5 13 env60140 = env60141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env60140 == env60141) = true)

def env60142 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,276,65536,65895,65665,320,277,1,477,66615,65552,192,65830,319,65846,1296,67651,1285,65831,256,1281,1345,1044]

theorem envBound60142 : H12AffineFastState.Bounded env60142 := by
  intro p hp
  have h : env60142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60133_60142 : H12AffineEnvironment.transform 11 1 env60133 = env60142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60133 == env60142) = true)

theorem identity60142 : scanCanonicalize (H12AffineFastState.compose env60142 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound60142 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60143 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,276,1331,1108,1458,320,277,1,477,260,1315,192,1045,319,1029,1296,3440,1285,1044,256,1281,1345,1044]

theorem envBound60143 : H12AffineFastState.Bounded env60143 := by
  intro p hp
  have h : env60143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60142_60143 : H12AffineEnvironment.transform 15 1331 env60142 = env60143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env60142 == env60143) = true)

theorem identity60143 : scanCanonicalize (H12AffineFastState.compose env60143 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1443) := by decide +kernel

theorem selectedBound60143 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env60144 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1443,1,1288,1297,276,1331,1108,1458,320,277,1,477,260,1315,192,1045,319,1029,1296,211,1285,1044,256,1281,1345,1044]

theorem envBound60144 : H12AffineFastState.Bounded env60144 := by
  intro p hp
  have h : env60144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60143_60144 : H12AffineEnvironment.transform 10 1443 env60143 = env60144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1443 env60143 == env60144) = true)

theorem identity60144 : scanCanonicalize (H12AffineFastState.compose env60144 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60144 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60145 : List Nat := [2,4,8,16,32,64,128,256,341,272,179,1,24,1,276,35,324,162,320,277,1,477,260,51,192,261,319,277,0,211,21,260,256,17,81,260]

theorem envBound60145 : H12AffineFastState.Bounded env60145 := by
  intro p hp
  have h : env60145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60144_60145 : H12AffineEnvironment.transform 9 272 env60144 = env60145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60144 == env60145) = true)

theorem identity60145 : scanCanonicalize (H12AffineFastState.compose env60145 (packedSelected [8,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound60145 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env60146 : List Nat := [2,4,8,16,32,23,128,256,258,272,179,1,24,1,276,35,275,162,279,277,1,394,260,51,151,261,319,277,0,132,21,260,256,17,6,260]

theorem envBound60146 : H12AffineFastState.Bounded env60146 := by
  intro p hp
  have h : env60146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60145_60146 : H12AffineEnvironment.transform 5 23 env60145 = env60146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env60145 == env60146) = true)

theorem identity60146 : scanCanonicalize (H12AffineFastState.compose env60146 (packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound60146 : packedSelected [0,1,2,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env60147 : List Nat := [2,4,8,16,32,23,128,167,165,183,179,1,24,1,179,35,180,162,176,178,1,45,163,51,151,162,152,178,0,132,21,163,167,17,6,163]

theorem envBound60147 : H12AffineFastState.Bounded env60147 := by
  intro p hp
  have h : env60147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60146_60147 : H12AffineEnvironment.transform 7 167 env60146 = env60147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env60146 == env60147) = true)

theorem identity60147 : scanCanonicalize (H12AffineFastState.compose env60147 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound60147 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60148 : List Nat := [2,4,8,16,7,23,128,128,130,144,148,1,24,1,148,4,147,133,151,149,1,10,132,20,151,133,152,149,0,132,21,132,128,17,6,132]

theorem envBound60148 : H12AffineFastState.Bounded env60148 := by
  intro p hp
  have h : env60148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60147_60148 : H12AffineEnvironment.transform 4 7 env60147 = env60148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env60147 == env60148) = true)

theorem identity60148 : scanCanonicalize (H12AffineFastState.compose env60148 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound60148 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60149 : List Nat := [2,4,8,16,7,23,31,31,29,15,11,1,24,1,11,4,12,26,8,10,1,10,27,20,8,26,7,10,0,27,21,27,31,17,6,27]

theorem envBound60149 : H12AffineFastState.Bounded env60149 := by
  intro p hp
  have h : env60149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60148_60149 : H12AffineEnvironment.transform 6 31 env60148 = env60149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env60148 == env60149) = true)

theorem identity60149 : scanCanonicalize (H12AffineFastState.compose env60149 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60150 : List Nat := [2,4,8,0,7,7,15,15,13,15,11,1,8,1,11,4,12,10,8,10,1,10,11,4,8,10,7,10,0,11,5,11,15,1,6,11]

theorem envBound60150 : H12AffineFastState.Bounded env60150 := by
  intro p hp
  have h : env60150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60149_60150 : H12AffineEnvironment.transform 3 0 env60149 = env60150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60149 == env60150) = true)

theorem identity60150 : scanCanonicalize (H12AffineFastState.compose env60150 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60150 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60151 : List Nat := [2,2,8,0,1,1,9,9,11,9,11,1,8,1,11,2,10,10,8,10,1,10,11,2,8,10,1,10,0,11,3,11,9,1,0,11]

theorem envBound60151 : H12AffineFastState.Bounded env60151 := by
  intro p hp
  have h : env60151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60150_60151 : H12AffineEnvironment.transform 1 2 env60150 = env60151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60150 == env60151) = true)

theorem identity60151 : scanCanonicalize (H12AffineFastState.compose env60151 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60151 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60152 : List Nat := [2,2,3,0,1,1,2,2,0,2,0,1,3,1,0,2,1,1,3,1,1,1,0,2,3,1,1,1,0,0,3,0,2,1,0,0]

theorem envBound60152 : H12AffineFastState.Bounded env60152 := by
  intro p hp
  have h : env60152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60151_60152 : H12AffineEnvironment.transform 2 3 env60151 = env60152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60151 == env60152) = true)

def env60153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123165,28889,78894,385203,90415,1297,96347,25884,74799,256,25881,1345,21072]

theorem envBound60153 : H12AffineFastState.Bounded env60153 := by
  intro p hp
  have h : env60153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59900_60153 : H12AffineEnvironment.transform 18 21585 env59900 = env60153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env59900 == env60153) = true)

theorem identity60153 : scanCanonicalize (H12AffineFastState.compose env60153 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound60153 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4096,5277,91182,66897,28889,78894,328959,90415,1297,96347,25884,74799,256,25881,1345,21072]

theorem envBound60154 : H12AffineFastState.Bounded env60154 := by
  intro p hp
  have h : env60154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60153_60154 : H12AffineEnvironment.transform 14 25676 env60153 = env60154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env60153 == env60154) = true)

def env60155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4096,5277,74046,66897,13769,78894,328959,74815,1297,81227,8204,74799,256,8201,1345,5952]

theorem envBound60155 : H12AffineFastState.Bounded env60155 := by
  intro p hp
  have h : env60155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60154_60155 : H12AffineEnvironment.transform 13 1296 env60154 = env60155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60154 == env60155) = true)

def env60156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4096,5277,74046,66897,13769,78894,1151,74815,1297,81227,8204,74799,256,8201,1345,5952]

theorem envBound60156 : H12AffineFastState.Bounded env60156 := by
  intro p hp
  have h : env60156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60155_60156 : H12AffineEnvironment.transform 17 65664 env60155 = env60156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60155 == env60156) = true)

theorem identity60156 : scanCanonicalize (H12AffineFastState.compose env60156 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound60156 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60157 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,65536,74031,65664,4417,8541,4096,4573,74046,65553,12425,78190,319,74111,81,79883,8204,74095,256,8201,1,4608]

theorem envBound60157 : H12AffineFastState.Bounded env60157 := by
  intro p hp
  have h : env60157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60156_60157 : H12AffineEnvironment.transform 9 320 env60156 = env60157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60156 == env60157) = true)

def env60158 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,80,8540,65536,74031,65664,533,8541,852,649,74046,65553,9181,74298,319,74111,81,76639,8204,74095,256,8201,1,340]

theorem envBound60158 : H12AffineFastState.Bounded env60158 := by
  intro p hp
  have h : env60158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60157_60158 : H12AffineEnvironment.transform 11 852 env60157 = env60158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env60157 == env60158) = true)

def env60159 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,65536,74031,65664,517,8525,836,649,74030,65537,9165,74282,303,74095,65,76623,8204,74095,256,8201,1,324]

theorem envBound60159 : H12AffineFastState.Bounded env60159 := by
  intro p hp
  have h : env60159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60158_60159 : H12AffineEnvironment.transform 3 0 env60158 = env60159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60158 == env60159) = true)

theorem identity60159 : scanCanonicalize (H12AffineFastState.compose env60159 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 265) := by decide +kernel

theorem selectedBound60159 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60160 : List Nat := [2,4,8,0,32,64,128,256,265,320,2048,77,8192,64,8524,65536,74031,65664,268,8525,77,384,74030,65537,8388,74019,303,74095,65,75846,8204,74095,256,8201,1,324]

theorem envBound60160 : H12AffineFastState.Bounded env60160 := by
  intro p hp
  have h : env60160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60159_60160 : H12AffineEnvironment.transform 8 265 env60159 = env60160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env60159 == env60160) = true)

def env60161 : List Nat := [2,4,8,0,32,64,128,256,265,320,2048,77,72,64,260,65536,65895,65664,268,261,77,384,65894,65537,140,65899,303,65831,65,67598,68,65831,256,65,1,324]

theorem envBound60161 : H12AffineFastState.Bounded env60161 := by
  intro p hp
  have h : env60161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60160_60161 : H12AffineEnvironment.transform 12 72 env60160 = env60161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env60160 == env60161) = true)

theorem identity60161 : scanCanonicalize (H12AffineFastState.compose env60161 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound60161 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60162 : List Nat := [2,4,8,0,32,64,128,256,265,320,2048,77,72,64,260,99,260,227,268,261,77,384,261,98,140,264,303,324,65,2157,68,324,256,65,1,324]

theorem envBound60162 : H12AffineFastState.Bounded env60162 := by
  intro p hp
  have h : env60162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60161_60162 : H12AffineEnvironment.transform 15 99 env60161 = env60162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env60161 == env60162) = true)

theorem identity60162 : scanCanonicalize (H12AffineFastState.compose env60162 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound60162 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60163 : List Nat := [2,4,8,0,32,64,128,9,0,73,2048,77,72,64,13,99,13,227,5,12,77,137,12,98,140,1,38,77,65,2157,68,77,9,65,1,77]

theorem envBound60163 : H12AffineFastState.Bounded env60163 := by
  intro p hp
  have h : env60163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60162_60163 : H12AffineEnvironment.transform 7 9 env60162 = env60163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env60162 == env60163) = true)

theorem identity60163 : scanCanonicalize (H12AffineFastState.compose env60163 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound60163 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60164 : List Nat := [2,4,8,0,32,64,128,9,0,73,102,77,72,64,13,99,13,227,5,12,77,137,12,98,140,1,38,77,65,11,68,77,9,65,1,77]

theorem envBound60164 : H12AffineFastState.Bounded env60164 := by
  intro p hp
  have h : env60164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60163_60164 : H12AffineEnvironment.transform 10 102 env60163 = env60164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env60163 == env60164) = true)

theorem identity60164 : scanCanonicalize (H12AffineFastState.compose env60164 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound60164 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60165 : List Nat := [2,4,8,0,32,44,128,9,0,37,10,33,36,44,13,15,13,143,5,12,33,137,12,14,140,1,38,33,45,11,40,33,9,45,1,33]

theorem envBound60165 : H12AffineFastState.Bounded env60165 := by
  intro p hp
  have h : env60165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60164_60165 : H12AffineEnvironment.transform 5 44 env60164 = env60165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env60164 == env60165) = true)

theorem identity60165 : scanCanonicalize (H12AffineFastState.compose env60165 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60165 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60166 : List Nat := [2,4,8,0,32,44,34,9,0,37,10,33,36,44,13,15,13,45,5,12,33,43,12,14,46,1,38,33,45,11,40,33,9,45,1,33]

theorem envBound60166 : H12AffineFastState.Bounded env60166 := by
  intro p hp
  have h : env60166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60165_60166 : H12AffineEnvironment.transform 6 34 env60165 = env60166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60165 == env60166) = true)

theorem identity60166 : scanCanonicalize (H12AffineFastState.compose env60166 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60166 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60167 : List Nat := [2,4,2,0,32,38,34,3,0,37,0,33,36,38,7,5,7,39,5,6,33,33,6,4,36,1,38,33,39,1,34,33,3,39,1,33]

theorem envBound60167 : H12AffineFastState.Bounded env60167 := by
  intro p hp
  have h : env60167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60166_60167 : H12AffineEnvironment.transform 2 2 env60166 = env60167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60166 == env60167) = true)

theorem identity60167 : scanCanonicalize (H12AffineFastState.compose env60167 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound60167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60168 : List Nat := [2,4,2,0,7,1,5,3,0,2,0,6,3,1,7,5,7,0,5,6,6,6,6,4,3,1,1,6,0,1,5,6,3,0,1,6]

theorem envBound60168 : H12AffineFastState.Bounded env60168 := by
  intro p hp
  have h : env60168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60167_60168 : H12AffineEnvironment.transform 4 7 env60167 = env60168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env60167 == env60168) = true)

theorem identity60168 : scanCanonicalize (H12AffineFastState.compose env60168 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60169 : List Nat := [2,3,2,0,0,1,2,3,0,2,0,1,3,1,0,2,0,0,2,1,1,1,1,3,3,1,1,1,0,1,2,1,3,0,1,1]

theorem envBound60169 : H12AffineFastState.Bounded env60169 := by
  intro p hp
  have h : env60169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60168_60169 : H12AffineEnvironment.transform 1 3 env60168 = env60169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60168 == env60169) = true)

theorem identity60169 : scanCanonicalize (H12AffineFastState.compose env60169 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60170 : List Nat := [0,1,0,0,0,1,0,1,0,0,0,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,1,0,1,1,0,1,1]

theorem envBound60170 : H12AffineFastState.Bounded env60170 := by
  intro p hp
  have h : env60170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60169_60170 : H12AffineEnvironment.transform 0 0 env60169 = env60170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60169 == env60170) = true)

def env60171 : List Nat := [2,4,8,0,32,64,128,256,265,320,2048,77,73,64,261,65536,65894,65664,268,260,77,384,65895,65537,141,65898,303,65830,65,67599,69,65830,256,64,1,324]

theorem envBound60171 : H12AffineFastState.Bounded env60171 := by
  intro p hp
  have h : env60171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60160_60171 : H12AffineEnvironment.transform 12 73 env60160 = env60171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env60160 == env60171) = true)

theorem identity60171 : scanCanonicalize (H12AffineFastState.compose env60171 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound60171 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60172 : List Nat := [2,4,8,0,32,64,128,256,265,320,2048,77,73,64,261,46,328,174,268,260,77,384,329,47,141,324,303,264,65,2081,69,264,256,64,1,324]

theorem envBound60172 : H12AffineFastState.Bounded env60172 := by
  intro p hp
  have h : env60172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60171_60172 : H12AffineEnvironment.transform 15 46 env60171 = env60172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env60171 == env60172) = true)

theorem identity60172 : scanCanonicalize (H12AffineFastState.compose env60172 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound60172 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60173 : List Nat := [2,4,8,0,32,13,128,256,265,269,2048,0,4,13,261,46,261,174,268,260,0,384,260,47,141,265,303,264,12,2081,8,264,256,13,1,265]

theorem envBound60173 : H12AffineFastState.Bounded env60173 := by
  intro p hp
  have h : env60173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60172_60173 : H12AffineEnvironment.transform 5 13 env60172 = env60173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env60172 == env60173) = true)

theorem identity60173 : scanCanonicalize (H12AffineFastState.compose env60173 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound60173 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60174 : List Nat := [2,4,8,0,32,13,4,256,265,269,2048,0,4,13,261,46,261,42,268,260,0,260,260,47,9,265,303,264,12,2081,8,264,256,13,1,265]

theorem envBound60174 : H12AffineFastState.Bounded env60174 := by
  intro p hp
  have h : env60174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60173_60174 : H12AffineEnvironment.transform 6 4 env60173 = env60174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env60173 == env60174) = true)

theorem identity60174 : scanCanonicalize (H12AffineFastState.compose env60174 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60174 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60175 : List Nat := [2,4,8,0,10,13,4,256,265,269,2048,0,4,13,261,4,261,0,268,260,0,260,260,5,9,265,261,264,12,2059,8,264,256,13,1,265]

theorem envBound60175 : H12AffineFastState.Bounded env60175 := by
  intro p hp
  have h : env60175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60174_60175 : H12AffineEnvironment.transform 4 10 env60174 = env60175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60174 == env60175) = true)

theorem identity60175 : scanCanonicalize (H12AffineFastState.compose env60175 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound60175 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env60176 : List Nat := [2,4,8,0,10,13,4,256,265,269,0,0,4,13,261,4,261,0,268,260,0,260,260,5,9,265,261,264,12,11,8,264,256,13,1,265]

theorem envBound60176 : H12AffineFastState.Bounded env60176 := by
  intro p hp
  have h : env60176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60175_60176 : H12AffineEnvironment.transform 10 0 env60175 = env60176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env60175 == env60176) = true)

theorem identity60176 : scanCanonicalize (H12AffineFastState.compose env60176 (packedSelected [1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60176 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env60177 : List Nat := [2,4,5,0,7,0,4,256,260,256,0,0,4,0,261,4,261,0,257,260,0,260,260,5,4,260,261,261,1,6,5,261,256,0,1,260]

theorem envBound60177 : H12AffineFastState.Bounded env60177 := by
  intro p hp
  have h : env60177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60176_60177 : H12AffineEnvironment.transform 2 5 env60176 = env60177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60176 == env60177) = true)

def env60178 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,65536,74031,65664,516,8524,837,649,74031,65536,9164,74283,302,74094,64,76622,8204,74095,256,8201,1,325]

theorem envBound60178 : H12AffineFastState.Bounded env60178 := by
  intro p hp
  have h : env60178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60158_60178 : H12AffineEnvironment.transform 3 1 env60158 = env60178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60158 == env60178) = true)

theorem identity60178 : scanCanonicalize (H12AffineFastState.compose env60178 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 832) := by decide +kernel

theorem selectedBound60178 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60179 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,832,65,525,65536,66159,65664,516,524,837,649,66159,65536,140,65899,302,66094,64,67598,844,66095,256,841,1,325]

theorem envBound60179 : H12AffineFastState.Bounded env60179 := by
  intro p hp
  have h : env60179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60178_60179 : H12AffineEnvironment.transform 12 832 env60178 = env60179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 832 env60178 == env60179) = true)

def env60180 : List Nat := [2,4,8,1,32,64,128,256,264,320,2048,77,72,65,261,65536,65895,65664,268,260,77,385,65895,65536,140,65899,302,65830,64,67598,68,65831,256,65,1,325]

theorem envBound60180 : H12AffineFastState.Bounded env60180 := by
  intro p hp
  have h : env60180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60179_60180 : H12AffineEnvironment.transform 8 264 env60179 = env60180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env60179 == env60180) = true)

theorem identity60180 : scanCanonicalize (H12AffineFastState.compose env60180 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound60180 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60181 : List Nat := [2,4,8,1,32,64,128,256,264,320,2048,77,72,65,261,98,261,226,268,260,77,385,261,98,140,265,302,324,64,2156,68,325,256,65,1,325]

theorem envBound60181 : H12AffineFastState.Bounded env60181 := by
  intro p hp
  have h : env60181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60180_60181 : H12AffineEnvironment.transform 15 98 env60180 = env60181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env60180 == env60181) = true)

theorem identity60181 : scanCanonicalize (H12AffineFastState.compose env60181 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound60181 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60182 : List Nat := [2,4,8,1,32,64,128,9,1,73,2048,77,72,65,12,98,12,226,5,13,77,136,12,98,140,0,39,77,64,2156,68,76,9,65,1,76]

theorem envBound60182 : H12AffineFastState.Bounded env60182 := by
  intro p hp
  have h : env60182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60181_60182 : H12AffineEnvironment.transform 7 9 env60181 = env60182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env60181 == env60182) = true)

theorem identity60182 : scanCanonicalize (H12AffineFastState.compose env60182 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound60182 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60183 : List Nat := [2,4,8,1,32,64,128,9,1,73,103,77,72,65,12,98,12,226,5,13,77,136,12,98,140,0,39,77,64,11,68,76,9,65,1,76]

theorem envBound60183 : H12AffineFastState.Bounded env60183 := by
  intro p hp
  have h : env60183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60182_60183 : H12AffineEnvironment.transform 10 103 env60182 = env60183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env60182 == env60183) = true)

theorem identity60183 : scanCanonicalize (H12AffineFastState.compose env60183 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound60183 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60184 : List Nat := [2,4,8,1,32,64,73,9,1,73,103,77,72,65,12,98,12,43,5,13,77,65,12,98,69,0,39,77,64,11,68,76,9,65,1,76]

theorem envBound60184 : H12AffineFastState.Bounded env60184 := by
  intro p hp
  have h : env60184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60183_60184 : H12AffineEnvironment.transform 6 73 env60183 = env60184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env60183 == env60184) = true)

theorem identity60184 : scanCanonicalize (H12AffineFastState.compose env60184 (packedSelected [1,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60184 : packedSelected [1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env60185 : List Nat := [2,4,8,1,11,64,73,9,1,73,76,77,72,65,12,73,12,0,5,13,77,65,12,73,69,0,12,77,64,11,68,76,9,65,1,76]

theorem envBound60185 : H12AffineFastState.Bounded env60185 := by
  intro p hp
  have h : env60185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60184_60185 : H12AffineEnvironment.transform 4 11 env60184 = env60185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60184 == env60185) = true)

def env60186 : List Nat := [2,4,8,1,32,64,128,256,265,320,2048,76,73,65,260,65536,65894,65664,269,261,76,384,65894,65536,140,65899,302,65831,64,67598,69,65830,256,64,1,325]

theorem envBound60186 : H12AffineFastState.Bounded env60186 := by
  intro p hp
  have h : env60186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60179_60186 : H12AffineEnvironment.transform 8 265 env60179 = env60186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env60179 == env60186) = true)

theorem identity60186 : scanCanonicalize (H12AffineFastState.compose env60186 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound60186 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60187 : List Nat := [2,4,8,1,32,64,128,256,265,320,2048,76,73,65,260,46,328,174,269,261,76,384,328,46,140,325,302,265,64,2080,69,264,256,64,1,325]

theorem envBound60187 : H12AffineFastState.Bounded env60187 := by
  intro p hp
  have h : env60187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60186_60187 : H12AffineEnvironment.transform 15 46 env60186 = env60187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env60186 == env60187) = true)

theorem identity60187 : scanCanonicalize (H12AffineFastState.compose env60187 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound60187 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60188 : List Nat := [2,4,8,1,32,12,128,256,265,268,2048,0,5,13,260,46,260,174,269,261,0,384,260,46,140,265,302,265,12,2080,9,264,256,12,1,265]

theorem envBound60188 : H12AffineFastState.Bounded env60188 := by
  intro p hp
  have h : env60188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60187_60188 : H12AffineEnvironment.transform 5 12 env60187 = env60188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env60187 == env60188) = true)

theorem identity60188 : scanCanonicalize (H12AffineFastState.compose env60188 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound60188 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60189 : List Nat := [2,4,8,1,32,12,5,256,265,268,2048,0,5,13,260,46,260,43,269,261,0,261,260,46,9,265,302,265,12,2080,9,264,256,12,1,265]

theorem envBound60189 : H12AffineFastState.Bounded env60189 := by
  intro p hp
  have h : env60189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60188_60189 : H12AffineEnvironment.transform 6 5 env60188 = env60189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env60188 == env60189) = true)

theorem identity60189 : scanCanonicalize (H12AffineFastState.compose env60189 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound60189 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60190 : List Nat := [2,4,8,1,7,12,5,256,265,268,2048,0,5,13,260,9,260,12,269,261,0,261,260,9,9,265,265,265,12,2055,9,264,256,12,1,265]

theorem envBound60190 : H12AffineFastState.Bounded env60190 := by
  intro p hp
  have h : env60190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60189_60190 : H12AffineEnvironment.transform 4 7 env60189 = env60190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env60189 == env60190) = true)

theorem identity60190 : scanCanonicalize (H12AffineFastState.compose env60190 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound60190 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env60191 : List Nat := [2,4,8,1,7,12,5,8,1,4,2048,0,5,13,12,9,12,12,5,13,0,13,12,9,9,1,1,1,12,2055,9,0,8,12,1,1]

theorem envBound60191 : H12AffineFastState.Bounded env60191 := by
  intro p hp
  have h : env60191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60190_60191 : H12AffineEnvironment.transform 7 8 env60190 = env60191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env60190 == env60191) = true)

theorem identity60191 : scanCanonicalize (H12AffineFastState.compose env60191 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60191 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60192 : List Nat := [2,4,5,1,7,1,5,5,1,4,2048,0,5,0,1,4,1,1,5,0,0,0,1,4,4,1,1,1,1,2055,4,0,5,1,1,1]

theorem envBound60192 : H12AffineFastState.Bounded env60192 := by
  intro p hp
  have h : env60192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60191_60192 : H12AffineEnvironment.transform 2 5 env60191 = env60192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60191 == env60192) = true)

theorem identity60192 : scanCanonicalize (H12AffineFastState.compose env60192 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound60192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60193 : List Nat := [2,4,5,1,7,1,5,5,1,4,6,0,5,0,1,4,1,1,5,0,0,0,1,4,4,1,1,1,1,1,4,0,5,1,1,1]

theorem envBound60193 : H12AffineFastState.Bounded env60193 := by
  intro p hp
  have h : env60193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60192_60193 : H12AffineEnvironment.transform 10 6 env60192 = env60193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env60192 == env60193) = true)

theorem identity60193 : scanCanonicalize (H12AffineFastState.compose env60193 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60194 : List Nat := [2,2,3,1,1,1,3,3,1,2,0,0,3,0,1,2,1,1,3,0,0,0,1,2,2,1,1,1,1,1,2,0,3,1,1,1]

theorem envBound60194 : H12AffineFastState.Bounded env60194 := by
  intro p hp
  have h : env60194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60193_60194 : H12AffineEnvironment.transform 1 2 env60193 = env60194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60193 == env60194) = true)

def env60195 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,80,8540,65536,74031,65664,532,8541,853,648,74046,65553,9180,74299,319,74111,81,76638,8204,74095,256,8201,1,341]

theorem envBound60195 : H12AffineFastState.Bounded env60195 := by
  intro p hp
  have h : env60195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60157_60195 : H12AffineEnvironment.transform 11 853 env60157 = env60195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env60157 == env60195) = true)

def env60196 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,65536,74031,65664,516,8525,837,648,74030,65537,9164,74283,303,74095,65,76622,8204,74095,256,8201,1,325]

theorem envBound60196 : H12AffineFastState.Bounded env60196 := by
  intro p hp
  have h : env60196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60195_60196 : H12AffineEnvironment.transform 3 0 env60195 = env60196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60195 == env60196) = true)

theorem identity60196 : scanCanonicalize (H12AffineFastState.compose env60196 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8743) := by decide +kernel

theorem selectedBound60196 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60197 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,8743,776,8871,516,8525,837,648,777,8742,9164,12,303,840,65,2409,8204,840,256,8201,1,325]

theorem envBound60197 : H12AffineFastState.Bounded env60197 := by
  intro p hp
  have h : env60197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60196_60197 : H12AffineEnvironment.transform 15 8743 env60196 = env60197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8743 env60196 == env60197) = true)

def env60198 : List Nat := [2,4,8,0,32,64,128,256,328,320,2048,13,8192,64,8524,8559,64,8687,332,8525,13,448,65,8558,8324,12,303,0,65,2409,8204,0,256,8201,1,325]

theorem envBound60198 : H12AffineFastState.Bounded env60198 := by
  intro p hp
  have h : env60198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60197_60198 : H12AffineEnvironment.transform 8 328 env60197 = env60198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env60197 == env60198) = true)

theorem identity60198 : scanCanonicalize (H12AffineFastState.compose env60198 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound60198 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60199 : List Nat := [2,4,8,0,32,64,128,256,328,320,2048,13,257,64,77,110,64,238,332,76,13,448,65,111,389,12,303,0,65,2409,269,0,256,264,1,325]

theorem envBound60199 : H12AffineFastState.Bounded env60199 := by
  intro p hp
  have h : env60199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60198_60199 : H12AffineEnvironment.transform 12 257 env60198 = env60199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env60198 == env60199) = true)

theorem identity60199 : scanCanonicalize (H12AffineFastState.compose env60199 (packedSelected [0,3,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 291) := by decide +kernel

theorem selectedBound60199 : packedSelected [0,3,7,20] rootPS < 2^1333 := by decide +kernel

def env60200 : List Nat := [2,4,8,0,32,64,128,256,328,320,291,13,257,64,77,110,64,238,332,76,13,448,65,111,389,12,303,0,65,74,269,0,256,264,1,325]

theorem envBound60200 : H12AffineFastState.Bounded env60200 := by
  intro p hp
  have h : env60200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60199_60200 : H12AffineEnvironment.transform 10 291 env60199 = env60200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 291 env60199 == env60200) = true)

theorem identity60200 : scanCanonicalize (H12AffineFastState.compose env60200 (packedSelected [2,4,5,8,9,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound60200 : packedSelected [2,4,5,8,9,17,18] rootPS < 2^1333 := by decide +kernel

def env60201 : List Nat := [2,4,8,0,32,64,46,256,328,320,291,13,257,64,77,110,64,64,332,76,13,366,65,111,299,12,303,0,65,74,269,0,256,264,1,325]

theorem envBound60201 : H12AffineFastState.Bounded env60201 := by
  intro p hp
  have h : env60201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60200_60201 : H12AffineEnvironment.transform 6 46 env60200 = env60201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env60200 == env60201) = true)

theorem identity60201 : scanCanonicalize (H12AffineFastState.compose env60201 (packedSelected [3,4,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound60201 : packedSelected [3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60202 : List Nat := [2,4,8,0,13,64,3,256,328,320,270,13,257,64,77,67,64,64,332,76,13,323,65,66,262,12,258,0,65,74,269,0,256,264,1,325]

theorem envBound60202 : H12AffineFastState.Bounded env60202 := by
  intro p hp
  have h : env60202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60201_60202 : H12AffineEnvironment.transform 4 13 env60201 = env60202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env60201 == env60202) = true)

theorem identity60202 : scanCanonicalize (H12AffineFastState.compose env60202 (packedSelected [3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound60202 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env60203 : List Nat := [2,4,8,0,13,64,3,72,0,8,70,13,73,64,77,67,64,64,4,76,13,11,65,66,78,12,74,0,65,74,69,0,72,64,1,13]

theorem envBound60203 : H12AffineFastState.Bounded env60203 := by
  intro p hp
  have h : env60203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60202_60203 : H12AffineEnvironment.transform 7 72 env60202 = env60203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env60202 == env60203) = true)

theorem identity60203 : scanCanonicalize (H12AffineFastState.compose env60203 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound60203 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env60204 : List Nat := [2,4,8,0,13,13,3,5,0,8,11,13,4,13,0,14,13,13,4,1,13,11,12,15,3,12,7,0,12,7,8,0,5,13,1,13]

theorem envBound60204 : H12AffineFastState.Bounded env60204 := by
  intro p hp
  have h : env60204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60203_60204 : H12AffineEnvironment.transform 5 13 env60203 = env60204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env60203 == env60204) = true)

theorem identity60204 : scanCanonicalize (H12AffineFastState.compose env60204 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60205 : List Nat := [2,4,4,0,1,1,3,5,0,4,7,1,4,1,0,2,1,1,4,1,1,7,0,3,3,0,7,0,0,7,4,0,5,1,1,1]

theorem envBound60205 : H12AffineFastState.Bounded env60205 := by
  intro p hp
  have h : env60205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60204_60205 : H12AffineEnvironment.transform 2 4 env60204 = env60205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60204 == env60205) = true)

theorem identity60205 : scanCanonicalize (H12AffineFastState.compose env60205 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60206 : List Nat := [1,4,4,0,1,1,0,5,0,4,4,1,4,1,0,1,1,1,4,1,1,4,0,0,0,0,4,0,0,4,4,0,5,1,1,1]

theorem envBound60206 : H12AffineFastState.Bounded env60206 := by
  intro p hp
  have h : env60206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60205_60206 : H12AffineEnvironment.transform 0 1 env60205 = env60206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60205 == env60206) = true)

def env60207 : List Nat := [2,4,8,0,32,64,128,256,329,320,2048,12,8192,64,8524,8558,65,8686,333,8525,12,449,64,8559,8325,12,303,1,65,2409,8204,1,256,8201,1,325]

theorem envBound60207 : H12AffineFastState.Bounded env60207 := by
  intro p hp
  have h : env60207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60197_60207 : H12AffineEnvironment.transform 8 329 env60197 = env60207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env60197 == env60207) = true)

theorem identity60207 : scanCanonicalize (H12AffineFastState.compose env60207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound60207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60208 : List Nat := [2,4,8,0,32,64,128,256,329,320,2048,12,269,64,65,99,65,227,333,64,12,449,64,98,392,12,303,1,65,2409,257,1,256,260,1,325]

theorem envBound60208 : H12AffineFastState.Bounded env60208 := by
  intro p hp
  have h : env60208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60207_60208 : H12AffineEnvironment.transform 12 269 env60207 = env60208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env60207 == env60208) = true)

theorem identity60208 : scanCanonicalize (H12AffineFastState.compose env60208 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound60208 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env60209 : List Nat := [2,4,8,0,6,64,128,256,329,320,2048,12,269,64,65,69,65,197,333,64,12,449,64,68,392,12,265,1,65,2383,257,1,256,260,1,325]

theorem envBound60209 : H12AffineFastState.Bounded env60209 := by
  intro p hp
  have h : env60209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60208_60209 : H12AffineEnvironment.transform 4 6 env60208 = env60209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env60208 == env60209) = true)

theorem identity60209 : scanCanonicalize (H12AffineFastState.compose env60209 (packedSelected [1,2,8,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60209 : packedSelected [1,2,8,15,17] rootPS < 2^1333 := by decide +kernel

def env60210 : List Nat := [2,4,8,0,6,64,128,256,329,320,325,12,269,64,65,69,65,197,333,64,12,449,64,68,392,12,265,1,65,10,257,1,256,260,1,325]

theorem envBound60210 : H12AffineFastState.Bounded env60210 := by
  intro p hp
  have h : env60210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60209_60210 : H12AffineEnvironment.transform 10 325 env60209 = env60210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60209 == env60210) = true)

def env60211 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,65536,74031,65664,517,8524,836,648,74031,65536,9165,74282,302,74094,64,76623,8204,74095,256,8201,1,324]

theorem envBound60211 : H12AffineFastState.Bounded env60211 := by
  intro p hp
  have h : env60211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60195_60211 : H12AffineEnvironment.transform 3 1 env60195 = env60211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60195 == env60211) = true)

theorem identity60211 : scanCanonicalize (H12AffineFastState.compose env60211 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 622) := by decide +kernel

theorem selectedBound60211 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60212 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,622,9025,750,517,8524,836,648,9025,622,9165,8260,302,8960,64,10529,8204,8961,256,8201,1,324]

theorem envBound60212 : H12AffineFastState.Bounded env60212 := by
  intro p hp
  have h : env60212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60211_60212 : H12AffineEnvironment.transform 15 622 env60211 = env60212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 622 env60211 == env60212) = true)

def env60213 : List Nat := [2,4,8,1,32,64,128,256,328,320,2048,12,8192,65,8525,294,8201,422,333,8524,12,448,8201,294,8325,8260,302,8264,64,10529,8204,8265,256,8201,1,324]

theorem envBound60213 : H12AffineFastState.Bounded env60213 := by
  intro p hp
  have h : env60213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60212_60213 : H12AffineEnvironment.transform 8 328 env60212 = env60213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env60212 == env60213) = true)

theorem identity60213 : scanCanonicalize (H12AffineFastState.compose env60213 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60213 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60214 : List Nat := [2,4,4,1,32,64,128,256,324,320,2048,0,8192,65,8513,294,8197,422,321,8512,0,448,8197,294,8325,8260,290,8260,64,10529,8192,8261,256,8197,1,324]

theorem envBound60214 : H12AffineFastState.Bounded env60214 := by
  intro p hp
  have h : env60214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60213_60214 : H12AffineEnvironment.transform 2 4 env60213 = env60214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60213 == env60214) = true)

theorem identity60214 : scanCanonicalize (H12AffineFastState.compose env60214 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound60214 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60215 : List Nat := [2,4,4,1,32,64,128,68,0,4,2048,0,8192,65,8197,98,8197,226,5,8196,0,132,8197,98,8325,8260,102,8260,64,10341,8192,8261,68,8197,1,0]

theorem envBound60215 : H12AffineFastState.Bounded env60215 := by
  intro p hp
  have h : env60215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60214_60215 : H12AffineEnvironment.transform 7 68 env60214 = env60215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env60214 == env60215) = true)

theorem identity60215 : scanCanonicalize (H12AffineFastState.compose env60215 (packedSelected [1,2,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 67) := by decide +kernel

theorem selectedBound60215 : packedSelected [1,2,10,12,13] rootPS < 2^1333 := by decide +kernel

def env60216 : List Nat := [2,4,4,1,32,64,128,68,0,4,2048,0,67,65,70,98,70,226,5,71,0,132,70,98,198,7,102,7,64,2086,67,6,68,70,1,0]

theorem envBound60216 : H12AffineFastState.Bounded env60216 := by
  intro p hp
  have h : env60216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60215_60216 : H12AffineEnvironment.transform 12 67 env60215 = env60216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 67 env60215 == env60216) = true)

theorem identity60216 : scanCanonicalize (H12AffineFastState.compose env60216 (packedSelected [0,2,3,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound60216 : packedSelected [0,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60217 : List Nat := [2,4,4,1,32,64,128,68,0,4,1,0,67,65,70,98,70,226,5,71,0,132,70,98,198,7,102,7,64,39,67,6,68,70,1,0]

theorem envBound60217 : H12AffineFastState.Bounded env60217 := by
  intro p hp
  have h : env60217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60216_60217 : H12AffineEnvironment.transform 10 1 env60216 = env60217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env60216 == env60217) = true)

theorem identity60217 : scanCanonicalize (H12AffineFastState.compose env60217 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound60217 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60218 : List Nat := [2,4,4,1,32,64,37,68,0,4,1,0,67,65,70,98,70,71,5,71,0,33,70,98,99,7,102,7,64,39,67,6,68,70,1,0]

theorem envBound60218 : H12AffineFastState.Bounded env60218 := by
  intro p hp
  have h : env60218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60217_60218 : H12AffineEnvironment.transform 6 37 env60217 = env60218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env60217 == env60218) = true)

theorem identity60218 : scanCanonicalize (H12AffineFastState.compose env60218 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60218 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60219 : List Nat := [2,4,4,1,1,64,4,68,0,4,1,0,67,65,70,67,70,71,5,71,0,0,70,67,66,7,71,7,64,6,67,6,68,70,1,0]

theorem envBound60219 : H12AffineFastState.Bounded env60219 := by
  intro p hp
  have h : env60219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60218_60219 : H12AffineEnvironment.transform 4 1 env60218 = env60219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60218 == env60219) = true)

theorem identity60219 : scanCanonicalize (H12AffineFastState.compose env60219 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound60219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60220 : List Nat := [2,4,4,1,1,6,4,2,0,4,1,0,5,7,0,5,0,1,5,1,0,0,0,5,4,7,1,7,6,6,5,6,2,0,1,0]

theorem envBound60220 : H12AffineFastState.Bounded env60220 := by
  intro p hp
  have h : env60220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60219_60220 : H12AffineEnvironment.transform 5 6 env60219 = env60220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env60219 == env60220) = true)

theorem identity60220 : scanCanonicalize (H12AffineFastState.compose env60220 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60221 : List Nat := [2,2,2,1,1,0,2,2,0,2,1,0,3,1,0,3,0,1,3,1,0,0,0,3,2,1,1,1,0,0,3,0,2,0,1,0]

theorem envBound60221 : H12AffineFastState.Bounded env60221 := by
  intro p hp
  have h : env60221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60220_60221 : H12AffineEnvironment.transform 1 2 env60220 = env60221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60220 == env60221) = true)

def env60222 : List Nat := [2,4,8,1,32,64,128,256,329,320,2048,13,8192,65,8525,295,8200,423,332,8524,13,449,8200,295,8324,8260,302,8265,64,10529,8204,8264,256,8201,1,324]

theorem envBound60222 : H12AffineFastState.Bounded env60222 := by
  intro p hp
  have h : env60222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60212_60222 : H12AffineEnvironment.transform 8 329 env60212 = env60222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env60212 == env60222) = true)

theorem identity60222 : scanCanonicalize (H12AffineFastState.compose env60222 (packedSelected [0,2,3,4,5,7,9,10,13,15,16,17,20,21,23,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 456) := by decide +kernel

theorem selectedBound60222 : packedSelected [0,2,3,4,5,7,9,10,13,15,16,17,20,21,23,32,41] rootPS < 2^1333 := by decide +kernel

def env60223 : List Nat := [2,4,8,1,32,64,128,256,329,320,2048,13,456,65,133,295,448,423,332,132,13,449,448,295,332,396,302,385,64,2281,452,384,256,449,1,324]

theorem envBound60223 : H12AffineFastState.Bounded env60223 := by
  intro p hp
  have h : env60223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60222_60223 : H12AffineEnvironment.transform 12 456 env60222 = env60223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 456 env60222 == env60223) = true)

theorem identity60223 : scanCanonicalize (H12AffineFastState.compose env60223 (packedSelected [1,8,12,17,24] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound60223 : packedSelected [1,8,12,17,24] rootPS < 2^1333 := by decide +kernel

def env60224 : List Nat := [2,4,8,1,32,64,128,256,329,320,137,13,456,65,133,295,448,423,332,132,13,449,448,295,332,396,302,385,64,96,452,384,256,449,1,324]

theorem envBound60224 : H12AffineFastState.Bounded env60224 := by
  intro p hp
  have h : env60224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60223_60224 : H12AffineEnvironment.transform 10 137 env60223 = env60224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env60223 == env60224) = true)

theorem identity60224 : scanCanonicalize (H12AffineFastState.compose env60224 (packedSelected [1,7,9,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound60224 : packedSelected [1,7,9,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env60225 : List Nat := [2,4,8,1,32,64,128,40,97,104,137,13,224,65,133,15,232,143,100,132,13,233,232,15,100,164,6,169,64,96,236,168,40,233,1,108]

theorem envBound60225 : H12AffineFastState.Bounded env60225 := by
  intro p hp
  have h : env60225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60224_60225 : H12AffineEnvironment.transform 7 40 env60224 = env60225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env60224 == env60225) = true)

theorem identity60225 : scanCanonicalize (H12AffineFastState.compose env60225 (packedSelected [1,3,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60225 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env60226 : List Nat := [2,4,5,1,32,64,128,37,97,101,132,0,224,65,133,2,229,130,100,132,0,228,229,2,100,164,6,164,64,96,225,165,37,228,1,97]

theorem envBound60226 : H12AffineFastState.Bounded env60226 := by
  intro p hp
  have h : env60226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60225_60226 : H12AffineEnvironment.transform 2 5 env60225 = env60226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60225 == env60226) = true)

theorem identity60226 : scanCanonicalize (H12AffineFastState.compose env60226 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60227 : List Nat := [2,4,5,1,1,64,128,4,64,68,132,0,193,65,133,2,196,130,69,132,0,197,196,2,69,133,6,133,64,65,192,132,4,197,1,64]

theorem envBound60227 : H12AffineFastState.Bounded env60227 := by
  intro p hp
  have h : env60227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60226_60227 : H12AffineEnvironment.transform 4 1 env60226 = env60227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60226 == env60227) = true)

theorem identity60227 : scanCanonicalize (H12AffineFastState.compose env60227 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound60227 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env60228 : List Nat := [2,4,5,1,1,1,128,4,1,5,132,0,128,0,133,2,133,130,4,132,0,132,133,2,4,133,6,133,1,0,129,132,4,132,1,1]

theorem envBound60228 : H12AffineFastState.Bounded env60228 := by
  intro p hp
  have h : env60228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60227_60228 : H12AffineEnvironment.transform 5 1 env60227 = env60228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60227 == env60228) = true)

theorem identity60228 : scanCanonicalize (H12AffineFastState.compose env60228 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound60228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60229 : List Nat := [2,4,5,1,1,1,5,4,1,5,1,0,5,0,0,2,0,7,4,1,0,1,0,2,4,0,6,0,1,0,4,1,4,1,1,1]

theorem envBound60229 : H12AffineFastState.Bounded env60229 := by
  intro p hp
  have h : env60229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60228_60229 : H12AffineEnvironment.transform 6 5 env60228 = env60229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env60228 == env60229) = true)

theorem identity60229 : scanCanonicalize (H12AffineFastState.compose env60229 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60229 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60230 : List Nat := [2,2,3,1,1,1,3,2,1,3,1,0,3,0,0,2,0,1,2,1,0,1,0,2,2,0,0,0,1,0,2,1,2,1,1,1]

theorem envBound60230 : H12AffineFastState.Bounded env60230 := by
  intro p hp
  have h : env60230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60229_60230 : H12AffineEnvironment.transform 1 2 env60229 = env60230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60229 == env60230) = true)

def env60231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4096,5277,74046,66897,13769,78894,1150,74815,1297,81227,8204,74799,256,8201,1345,5952]

theorem envBound60231 : H12AffineFastState.Bounded env60231 := by
  intro p hp
  have h : env60231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60155_60231 : H12AffineEnvironment.transform 17 65665 env60155 = env60231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60155 == env60231) = true)

theorem identity60231 : scanCanonicalize (H12AffineFastState.compose env60231 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound60231 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,65536,74863,65665,320,8541,1,1180,74046,66897,9672,74799,1150,74815,1297,77130,8204,74799,256,8201,1345,1857]

theorem envBound60232 : H12AffineFastState.Bounded env60232 := by
  intro p hp
  have h : env60232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60231_60232 : H12AffineEnvironment.transform 11 1 env60231 = env60232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60231 == env60232) = true)

def env60233 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8540,65536,74031,65665,320,8541,1,476,74046,65553,8328,74095,318,74111,81,75786,8204,74095,256,8201,1,513]

theorem envBound60233 : H12AffineFastState.Bounded env60233 := by
  intro p hp
  have h : env60233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60232_60233 : H12AffineEnvironment.transform 9 320 env60232 = env60233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60232 == env60233) = true)

theorem identity60233 : scanCanonicalize (H12AffineFastState.compose env60233 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound60233 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60234 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,269,80,81,65536,65570,65665,320,80,1,476,65587,65553,389,65634,318,65650,81,67847,257,65634,256,260,1,513]

theorem envBound60234 : H12AffineFastState.Bounded env60234 := by
  intro p hp
  have h : env60234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60233_60234 : H12AffineEnvironment.transform 12 269 env60233 = env60234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env60233 == env60234) = true)

theorem identity60234 : scanCanonicalize (H12AffineFastState.compose env60234 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound60234 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60235 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,269,80,81,310,276,439,320,80,1,476,261,295,389,340,318,324,81,2097,257,340,256,260,1,513]

theorem envBound60235 : H12AffineFastState.Bounded env60235 := by
  intro p hp
  have h : env60235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60234_60235 : H12AffineEnvironment.transform 15 310 env60234 = env60235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env60234 == env60235) = true)

theorem identity60235 : scanCanonicalize (H12AffineFastState.compose env60235 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound60235 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60236 : List Nat := [2,4,8,16,32,64,128,84,512,20,2048,1,89,80,81,98,64,227,20,80,1,136,81,115,209,0,106,16,81,2097,85,0,84,80,1,513]

theorem envBound60236 : H12AffineFastState.Bounded env60236 := by
  intro p hp
  have h : env60236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60235_60236 : H12AffineEnvironment.transform 7 84 env60235 = env60236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env60235 == env60236) = true)

theorem identity60236 : scanCanonicalize (H12AffineFastState.compose env60236 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound60236 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env60237 : List Nat := [2,4,8,16,32,64,128,84,201,20,2048,1,89,80,81,98,64,227,20,80,1,136,81,115,209,0,106,16,81,2097,85,0,84,80,1,200]

theorem envBound60237 : H12AffineFastState.Bounded env60237 := by
  intro p hp
  have h : env60237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60236_60237 : H12AffineEnvironment.transform 8 201 env60236 = env60237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env60236 == env60237) = true)

theorem identity60237 : scanCanonicalize (H12AffineFastState.compose env60237 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound60237 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env60238 : List Nat := [2,4,8,16,32,64,111,84,38,20,2048,1,89,80,81,98,64,12,20,80,1,103,81,115,62,0,106,16,81,2097,85,0,84,80,1,39]

theorem envBound60238 : H12AffineFastState.Bounded env60238 := by
  intro p hp
  have h : env60238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60237_60238 : H12AffineEnvironment.transform 6 111 env60237 = env60238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env60237 == env60238) = true)

theorem identity60238 : scanCanonicalize (H12AffineFastState.compose env60238 (packedSelected [1,2,5,8,11,12,13,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound60238 : packedSelected [1,2,5,8,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env60239 : List Nat := [2,4,8,16,32,64,111,84,38,20,123,1,89,80,81,98,64,12,20,80,1,103,81,115,62,0,106,16,81,74,85,0,84,80,1,39]

theorem envBound60239 : H12AffineFastState.Bounded env60239 := by
  intro p hp
  have h : env60239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60238_60239 : H12AffineEnvironment.transform 10 123 env60238 = env60239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env60238 == env60239) = true)

theorem identity60239 : scanCanonicalize (H12AffineFastState.compose env60239 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60239 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env60240 : List Nat := [2,3,8,16,32,64,104,83,33,19,123,1,89,80,81,98,64,11,19,80,1,96,81,115,57,0,106,16,81,74,82,0,83,80,1,32]

theorem envBound60240 : H12AffineFastState.Bounded env60240 := by
  intro p hp
  have h : env60240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60239_60240 : H12AffineEnvironment.transform 1 3 env60239 = env60240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60239 == env60240) = true)

def env60241 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,65536,74030,65665,320,8541,1,477,74046,65552,8329,74094,319,74110,80,75787,8204,74094,256,8201,0,512]

theorem envBound60241 : H12AffineFastState.Bounded env60241 := by
  intro p hp
  have h : env60241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60232_60241 : H12AffineEnvironment.transform 9 321 env60232 = env60241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60232 == env60241) = true)

theorem identity60241 : scanCanonicalize (H12AffineFastState.compose env60241 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound60241 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60242 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,115,8541,242,320,8541,1,477,8525,99,8329,8477,319,8461,80,10360,8204,8477,256,8201,0,512]

theorem envBound60242 : H12AffineFastState.Bounded env60242 := by
  intro p hp
  have h : env60242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60241_60242 : H12AffineEnvironment.transform 15 115 env60241 = env60242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env60241 == env60242) = true)

theorem identity60242 : scanCanonicalize (H12AffineFastState.compose env60242 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound60242 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60243 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,81,80,115,81,242,320,81,1,477,65,99,389,17,319,1,80,2420,256,17,256,261,0,512]

theorem envBound60243 : H12AffineFastState.Bounded env60243 := by
  intro p hp
  have h : env60243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60242_60243 : H12AffineEnvironment.transform 12 268 env60242 = env60243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env60242 == env60243) = true)

theorem identity60243 : scanCanonicalize (H12AffineFastState.compose env60243 (packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound60243 : packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60244 : List Nat := [2,4,8,16,32,64,128,256,512,321,74,1,268,81,80,115,81,242,320,81,1,477,65,99,389,17,319,1,80,318,256,17,256,261,0,512]

theorem envBound60244 : H12AffineFastState.Bounded env60244 := by
  intro p hp
  have h : env60244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60243_60244 : H12AffineEnvironment.transform 10 74 env60243 = env60244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env60243 == env60244) = true)

theorem identity60244 : scanCanonicalize (H12AffineFastState.compose env60244 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound60244 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env60245 : List Nat := [2,4,8,16,32,64,128,183,512,246,74,1,187,81,80,115,81,242,247,81,1,106,65,99,50,17,136,1,80,137,183,17,183,178,0,512]

theorem envBound60245 : H12AffineFastState.Bounded env60245 := by
  intro p hp
  have h : env60245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60244_60245 : H12AffineEnvironment.transform 7 183 env60244 = env60245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env60244 == env60245) = true)

theorem identity60245 : scanCanonicalize (H12AffineFastState.compose env60245 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound60245 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60246 : List Nat := [2,4,8,16,32,64,128,183,27,246,74,1,187,81,80,115,81,242,247,81,1,106,65,99,50,17,136,1,80,137,183,17,183,178,0,27]

theorem envBound60246 : H12AffineFastState.Bounded env60246 := by
  intro p hp
  have h : env60246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60245_60246 : H12AffineEnvironment.transform 8 27 env60245 = env60246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env60245 == env60246) = true)

theorem identity60246 : scanCanonicalize (H12AffineFastState.compose env60246 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60246 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env60247 : List Nat := [2,4,8,16,16,64,128,135,27,198,74,1,139,81,80,67,81,194,199,81,1,90,65,83,2,17,136,1,80,137,135,17,135,130,0,27]

theorem envBound60247 : H12AffineFastState.Bounded env60247 := by
  intro p hp
  have h : env60247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60246_60247 : H12AffineEnvironment.transform 4 16 env60246 = env60247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60246 == env60247) = true)

theorem identity60247 : scanCanonicalize (H12AffineFastState.compose env60247 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound60247 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60248 : List Nat := [2,4,8,16,16,64,88,95,27,30,74,1,83,81,80,67,81,26,31,81,1,90,65,83,2,17,80,1,80,81,95,17,95,90,0,27]

theorem envBound60248 : H12AffineFastState.Bounded env60248 := by
  intro p hp
  have h : env60248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60247_60248 : H12AffineEnvironment.transform 6 88 env60247 = env60248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env60247 == env60248) = true)

theorem identity60248 : scanCanonicalize (H12AffineFastState.compose env60248 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60248 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env60249 : List Nat := [2,4,8,16,16,17,9,14,27,30,27,1,2,0,1,18,0,26,31,0,1,11,16,2,2,17,1,1,1,0,14,17,14,11,0,27]

theorem envBound60249 : H12AffineFastState.Bounded env60249 := by
  intro p hp
  have h : env60249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60248_60249 : H12AffineEnvironment.transform 5 17 env60248 = env60249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60248 == env60249) = true)

def env60250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4096,5277,74047,66897,13768,78894,328959,74814,1297,81226,8205,74799,256,8200,1345,5953]

theorem envBound60250 : H12AffineFastState.Bounded env60250 := by
  intro p hp
  have h : env60250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60154_60250 : H12AffineEnvironment.transform 13 1297 env60154 = env60250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60154 == env60250) = true)

def env60251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4096,5277,74047,66897,13768,78894,1151,74814,1297,81226,8205,74799,256,8200,1345,5953]

theorem envBound60251 : H12AffineFastState.Bounded env60251 := by
  intro p hp
  have h : env60251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60250_60251 : H12AffineEnvironment.transform 17 65664 env60250 = env60251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60250 == env60251) = true)

theorem identity60251 : scanCanonicalize (H12AffineFastState.compose env60251 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound60251 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,65536,69991,65664,4416,5204,4096,5277,70711,66897,192,65830,1151,69942,1297,67650,5381,69927,256,5376,1345,5953]

theorem envBound60252 : H12AffineFastState.Bounded env60252 := by
  intro p hp
  have h : env60252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60251_60252 : H12AffineEnvironment.transform 12 5384 env60251 = env60252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env60251 == env60252) = true)

def env60253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1297,577,65536,67443,65664,1876,576,1556,649,66083,66897,192,65830,1151,67362,1297,67650,785,67379,256,788,1345,341]

theorem envBound60253 : H12AffineFastState.Bounded env60253 := by
  intro p hp
  have h : env60253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60252_60253 : H12AffineEnvironment.transform 11 1556 env60252 = env60253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env60252 == env60253) = true)

def env60254 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,65536,66083,65664,516,576,836,649,66083,65537,192,65830,303,66162,65,67650,785,66147,256,788,17,341]

theorem envBound60254 : H12AffineFastState.Bounded env60254 := by
  intro p hp
  have h : env60254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60253_60254 : H12AffineEnvironment.transform 9 336 env60253 = env60254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env60253 == env60254) = true)

theorem identity60254 : scanCanonicalize (H12AffineFastState.compose env60254 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 931) := by decide +kernel

theorem selectedBound60254 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60255 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,931,384,803,516,576,836,649,384,930,192,645,303,465,65,3041,785,448,256,788,17,341]

theorem envBound60255 : H12AffineFastState.Bounded env60255 := by
  intro p hp
  have h : env60255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60254_60255 : H12AffineEnvironment.transform 15 931 env60254 = env60255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 931 env60254 == env60255) = true)

def env60256 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,80,8,65,341,183,384,55,272,340,80,413,384,182,192,401,303,465,65,2293,5,448,256,0,17,341]

theorem envBound60256 : H12AffineFastState.Bounded env60256 := by
  intro p hp
  have h : env60256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60255_60256 : H12AffineEnvironment.transform 8 276 env60255 = env60256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env60255 == env60256) = true)

theorem identity60256 : scanCanonicalize (H12AffineFastState.compose env60256 (packedSelected [0,1,3,4,7,9,10,12,13,18,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound60256 : packedSelected [0,1,3,4,7,9,10,12,13,18,23,24] rootPS < 2^1333 := by decide +kernel

def env60257 : List Nat := [2,4,8,16,32,64,51,256,276,336,2048,80,8,65,341,4,307,55,272,340,80,302,307,5,115,290,303,354,65,2118,5,371,256,0,17,341]

theorem envBound60257 : H12AffineFastState.Bounded env60257 := by
  intro p hp
  have h : env60257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60256_60257 : H12AffineEnvironment.transform 6 51 env60256 = env60257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env60256 == env60257) = true)

theorem identity60257 : scanCanonicalize (H12AffineFastState.compose env60257 (packedSelected [0,1,2,5,7,8,10,11,12,13,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 275) := by decide +kernel

theorem selectedBound60257 : packedSelected [0,1,2,5,7,8,10,11,12,13,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env60258 : List Nat := [2,4,8,16,32,64,51,256,276,336,275,80,8,65,341,4,307,55,272,340,80,302,307,5,115,290,303,354,65,341,5,371,256,0,17,341]

theorem envBound60258 : H12AffineFastState.Bounded env60258 := by
  intro p hp
  have h : env60258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60257_60258 : H12AffineEnvironment.transform 10 275 env60257 = env60258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 275 env60257 == env60258) = true)

theorem identity60258 : scanCanonicalize (H12AffineFastState.compose env60258 (packedSelected [1,8,10,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound60258 : packedSelected [1,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60259 : List Nat := [2,4,8,16,32,64,51,98,118,50,113,80,8,65,55,4,81,55,114,54,80,76,81,5,115,64,77,0,65,55,5,17,98,0,17,55]

theorem envBound60259 : H12AffineFastState.Bounded env60259 := by
  intro p hp
  have h : env60259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60258_60259 : H12AffineEnvironment.transform 7 98 env60258 = env60259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env60258 == env60259) = true)

theorem identity60259 : scanCanonicalize (H12AffineFastState.compose env60259 (packedSelected [1,2,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60259 : packedSelected [1,2,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60260 : List Nat := [2,4,8,16,32,33,51,3,23,50,16,49,8,32,55,4,48,55,19,54,49,45,48,5,18,33,44,0,32,55,5,17,3,0,17,55]

theorem envBound60260 : H12AffineFastState.Bounded env60260 := by
  intro p hp
  have h : env60260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60259_60260 : H12AffineEnvironment.transform 5 33 env60259 = env60260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60259 == env60260) = true)

theorem identity60260 : scanCanonicalize (H12AffineFastState.compose env60260 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound60260 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env60261 : List Nat := [2,4,8,16,13,12,30,3,23,31,16,28,8,13,26,4,29,26,19,27,28,0,29,5,18,12,1,0,13,26,5,17,3,0,17,26]

theorem envBound60261 : H12AffineFastState.Bounded env60261 := by
  intro p hp
  have h : env60261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60260_60261 : H12AffineEnvironment.transform 4 13 env60260 = env60261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env60260 == env60261) = true)

theorem identity60261 : scanCanonicalize (H12AffineFastState.compose env60261 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60261 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60262 : List Nat := [2,4,4,16,1,0,18,3,23,19,16,16,4,1,22,4,17,22,19,23,16,0,17,5,18,0,1,0,1,22,5,17,3,0,17,22]

theorem envBound60262 : H12AffineFastState.Bounded env60262 := by
  intro p hp
  have h : env60262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60261_60262 : H12AffineEnvironment.transform 2 4 env60261 = env60262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60261 == env60262) = true)

theorem identity60262 : scanCanonicalize (H12AffineFastState.compose env60262 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60262 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60263 : List Nat := [2,1,1,16,1,0,18,3,18,19,16,16,1,1,19,1,17,19,19,18,16,0,17,0,18,0,1,0,1,19,0,17,3,0,17,19]

theorem envBound60263 : H12AffineFastState.Bounded env60263 := by
  intro p hp
  have h : env60263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60262_60263 : H12AffineEnvironment.transform 1 1 env60262 = env60263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60262 == env60263) = true)

def env60264 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,81,9,65,340,182,384,54,273,341,81,412,384,183,192,400,303,465,65,2292,4,448,256,1,17,341]

theorem envBound60264 : H12AffineFastState.Bounded env60264 := by
  intro p hp
  have h : env60264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60255_60264 : H12AffineEnvironment.transform 8 277 env60255 = env60264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env60255 == env60264) = true)

theorem identity60264 : scanCanonicalize (H12AffineFastState.compose env60264 (packedSelected [0,1,3,4,7,9,10,12,13,18,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound60264 : packedSelected [0,1,3,4,7,9,10,12,13,18,23,24] rootPS < 2^1333 := by decide +kernel

def env60265 : List Nat := [2,4,8,16,32,64,53,256,277,336,2048,81,9,65,340,3,309,54,273,341,81,297,309,2,117,293,303,356,65,2113,4,373,256,1,17,341]

theorem envBound60265 : H12AffineFastState.Bounded env60265 := by
  intro p hp
  have h : env60265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60264_60265 : H12AffineEnvironment.transform 6 53 env60264 = env60265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env60264 == env60265) = true)

theorem identity60265 : scanCanonicalize (H12AffineFastState.compose env60265 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60265 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env60266 : List Nat := [2,4,8,16,32,0,53,256,277,272,2048,17,9,1,276,3,309,54,273,277,17,297,309,2,53,293,303,292,1,2049,4,309,256,1,17,277]

theorem envBound60266 : H12AffineFastState.Bounded env60266 := by
  intro p hp
  have h : env60266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60265_60266 : H12AffineEnvironment.transform 5 0 env60265 = env60266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60265 == env60266) = true)

theorem identity60266 : scanCanonicalize (H12AffineFastState.compose env60266 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60266 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60267 : List Nat := [2,4,8,16,17,0,4,256,277,272,2048,17,9,1,276,3,260,7,273,277,17,280,260,2,4,276,286,277,1,2049,4,260,256,1,17,277]

theorem envBound60267 : H12AffineFastState.Bounded env60267 := by
  intro p hp
  have h : env60267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60266_60267 : H12AffineEnvironment.transform 4 17 env60266 = env60267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60266 == env60267) = true)

theorem identity60267 : scanCanonicalize (H12AffineFastState.compose env60267 (packedSelected [1,3,7,8,10,11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60267 : packedSelected [1,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env60268 : List Nat := [2,2,8,16,17,0,2,256,275,272,2048,17,9,1,274,3,258,1,273,275,17,280,258,2,2,274,280,275,1,2049,2,258,256,1,17,275]

theorem envBound60268 : H12AffineFastState.Bounded env60268 := by
  intro p hp
  have h : env60268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60267_60268 : H12AffineEnvironment.transform 1 2 env60267 = env60268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60267 == env60268) = true)

theorem identity60268 : scanCanonicalize (H12AffineFastState.compose env60268 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound60268 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env60269 : List Nat := [2,2,8,16,17,0,2,256,275,272,259,17,9,1,274,3,258,1,273,275,17,280,258,2,2,274,280,275,1,258,2,258,256,1,17,275]

theorem envBound60269 : H12AffineFastState.Bounded env60269 := by
  intro p hp
  have h : env60269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60268_60269 : H12AffineEnvironment.transform 10 259 env60268 = env60269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env60268 == env60269) = true)

theorem identity60269 : scanCanonicalize (H12AffineFastState.compose env60269 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound60269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60270 : List Nat := [2,2,8,16,17,0,2,24,11,8,27,17,9,1,10,3,26,1,9,11,17,0,26,2,2,10,0,11,1,26,2,26,24,1,17,11]

theorem envBound60270 : H12AffineFastState.Bounded env60270 := by
  intro p hp
  have h : env60270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60269_60270 : H12AffineEnvironment.transform 7 24 env60269 = env60270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env60269 == env60270) = true)

theorem identity60270 : scanCanonicalize (H12AffineFastState.compose env60270 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60270 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60271 : List Nat := [2,2,3,16,17,0,2,19,0,3,16,17,2,1,1,3,17,1,2,0,17,0,17,2,2,1,0,0,1,17,2,17,19,1,17,0]

theorem envBound60271 : H12AffineFastState.Bounded env60271 := by
  intro p hp
  have h : env60271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60270_60271 : H12AffineEnvironment.transform 2 3 env60270 = env60271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60270 == env60271) = true)

theorem identity60271 : scanCanonicalize (H12AffineFastState.compose env60271 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60272 : List Nat := [2,2,3,1,0,0,2,2,0,3,1,0,2,1,1,3,0,1,2,0,0,0,0,2,2,1,0,0,1,0,2,0,2,1,0,0]

theorem envBound60272 : H12AffineFastState.Bounded env60272 := by
  intro p hp
  have h : env60272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60271_60272 : H12AffineEnvironment.transform 3 1 env60271 = env60272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60271 == env60272) = true)

def env60273 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,65536,66082,65664,517,576,837,649,66083,65536,192,65830,302,66163,64,67650,785,66146,256,788,16,341]

theorem envBound60273 : H12AffineFastState.Bounded env60273 := by
  intro p hp
  have h : env60273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60253_60273 : H12AffineEnvironment.transform 9 337 env60253 = env60273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env60253 == env60273) = true)

theorem identity60273 : scanCanonicalize (H12AffineFastState.compose env60273 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 231) := by decide +kernel

theorem selectedBound60273 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60274 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,231,709,103,517,576,837,649,708,231,192,449,302,660,64,2213,785,645,256,788,16,341]

theorem envBound60274 : H12AffineFastState.Bounded env60274 := by
  intro p hp
  have h : env60274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60273_60274 : H12AffineEnvironment.transform 15 231 env60273 = env60274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 231 env60273 == env60274) = true)

def env60275 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,780,64,577,231,709,103,517,576,837,649,708,231,192,449,302,644,64,2213,769,645,256,772,0,325]

theorem envBound60275 : H12AffineFastState.Bounded env60275 := by
  intro p hp
  have h : env60275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60274_60275 : H12AffineEnvironment.transform 3 0 env60274 = env60275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60274 == env60275) = true)

theorem identity60275 : scanCanonicalize (H12AffineFastState.compose env60275 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound60275 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60276 : List Nat := [2,4,8,0,32,64,5,256,512,321,2048,837,780,64,577,98,576,103,517,576,837,524,577,98,69,324,302,513,64,2080,769,512,256,772,0,325]

theorem envBound60276 : H12AffineFastState.Bounded env60276 := by
  intro p hp
  have h : env60276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60275_60276 : H12AffineEnvironment.transform 6 5 env60275 = env60276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env60275 == env60276) = true)

theorem identity60276 : scanCanonicalize (H12AffineFastState.compose env60276 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound60276 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env60277 : List Nat := [2,4,8,0,32,64,5,256,512,321,586,837,780,64,577,98,576,103,517,576,837,524,577,98,69,324,302,513,64,618,769,512,256,772,0,325]

theorem envBound60277 : H12AffineFastState.Bounded env60277 := by
  intro p hp
  have h : env60277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60276_60277 : H12AffineEnvironment.transform 10 586 env60276 = env60277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env60276 == env60277) = true)

theorem identity60277 : scanCanonicalize (H12AffineFastState.compose env60277 (packedSelected [0,4,7,8,9,10,11,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound60277 : packedSelected [0,4,7,8,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env60278 : List Nat := [2,4,8,0,32,64,5,14,512,79,586,587,514,64,577,98,576,103,517,576,587,524,577,98,69,74,32,513,64,618,527,512,14,522,0,75]

theorem envBound60278 : H12AffineFastState.Bounded env60278 := by
  intro p hp
  have h : env60278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60277_60278 : H12AffineEnvironment.transform 7 14 env60277 = env60278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env60277 == env60278) = true)

theorem identity60278 : scanCanonicalize (H12AffineFastState.compose env60278 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound60278 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env60279 : List Nat := [2,4,8,0,32,64,5,14,96,79,42,43,98,64,33,98,32,103,101,32,43,108,33,98,69,74,32,97,64,10,111,96,14,106,0,75]

theorem envBound60279 : H12AffineFastState.Bounded env60279 := by
  intro p hp
  have h : env60279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60278_60279 : H12AffineEnvironment.transform 8 96 env60278 = env60279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env60278 == env60279) = true)

theorem identity60279 : scanCanonicalize (H12AffineFastState.compose env60279 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound60279 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60280 : List Nat := [2,4,8,0,32,13,5,14,45,2,42,43,47,13,33,47,32,42,40,32,43,33,33,47,8,7,32,44,13,10,34,45,14,39,0,6]

theorem envBound60280 : H12AffineFastState.Bounded env60280 := by
  intro p hp
  have h : env60280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60279_60280 : H12AffineEnvironment.transform 5 13 env60279 = env60280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env60279 == env60280) = true)

theorem identity60280 : scanCanonicalize (H12AffineFastState.compose env60280 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60280 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env60281 : List Nat := [2,4,4,0,32,1,5,2,33,2,38,39,35,1,33,35,32,38,36,32,39,33,33,35,4,7,32,32,1,6,34,33,2,39,0,6]

theorem envBound60281 : H12AffineFastState.Bounded env60281 := by
  intro p hp
  have h : env60281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60280_60281 : H12AffineEnvironment.transform 2 4 env60280 = env60281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60280 == env60281) = true)

theorem identity60281 : scanCanonicalize (H12AffineFastState.compose env60281 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60281 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60282 : List Nat := [2,3,3,0,32,1,2,2,33,2,33,32,35,1,33,35,32,33,35,32,32,33,33,35,3,0,32,32,1,1,34,33,2,32,0,1]

theorem envBound60282 : H12AffineFastState.Bounded env60282 := by
  intro p hp
  have h : env60282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60281_60282 : H12AffineEnvironment.transform 1 3 env60281 = env60282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60281 == env60282) = true)

def env60283 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,781,64,577,231,709,103,517,576,837,649,708,231,192,449,302,645,64,2213,768,645,256,773,1,324]

theorem envBound60283 : H12AffineFastState.Bounded env60283 := by
  intro p hp
  have h : env60283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60274_60283 : H12AffineEnvironment.transform 3 1 env60274 = env60283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60274 == env60283) = true)

theorem identity60283 : scanCanonicalize (H12AffineFastState.compose env60283 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 448) := by decide +kernel

theorem selectedBound60283 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60284 : List Nat := [2,4,8,1,32,64,128,256,448,320,2048,133,205,64,385,231,261,103,453,384,133,329,260,231,192,449,302,325,64,2213,192,325,256,197,1,324]

theorem envBound60284 : H12AffineFastState.Bounded env60284 := by
  intro p hp
  have h : env60284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60283_60284 : H12AffineEnvironment.transform 8 448 env60283 = env60284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 448 env60283 == env60284) = true)

theorem identity60284 : scanCanonicalize (H12AffineFastState.compose env60284 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 486) := by decide +kernel

theorem selectedBound60284 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env60285 : List Nat := [2,4,8,1,32,64,128,256,448,320,486,133,205,64,385,231,261,103,453,384,133,329,260,231,192,449,302,325,64,323,192,325,256,197,1,324]

theorem envBound60285 : H12AffineFastState.Bounded env60285 := by
  intro p hp
  have h : env60285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60284_60285 : H12AffineEnvironment.transform 10 486 env60284 = env60285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 486 env60284 == env60285) = true)

theorem identity60285 : scanCanonicalize (H12AffineFastState.compose env60285 (packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60285 : packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env60286 : List Nat := [2,4,8,1,32,11,128,256,395,267,429,133,134,11,385,172,261,44,398,384,133,258,260,172,139,394,302,270,11,264,139,270,256,142,1,271]

theorem envBound60286 : H12AffineFastState.Bounded env60286 := by
  intro p hp
  have h : env60286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60285_60286 : H12AffineEnvironment.transform 5 11 env60285 = env60286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60285 == env60286) = true)

theorem identity60286 : scanCanonicalize (H12AffineFastState.compose env60286 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound60286 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60287 : List Nat := [2,4,8,1,32,11,128,41,162,34,132,133,134,11,168,172,44,44,167,169,133,43,45,172,139,163,7,39,11,33,139,39,41,142,1,38]

theorem envBound60287 : H12AffineFastState.Bounded env60287 := by
  intro p hp
  have h : env60287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60286_60287 : H12AffineEnvironment.transform 7 41 env60286 = env60287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env60286 == env60287) = true)

theorem identity60287 : scanCanonicalize (H12AffineFastState.compose env60287 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60287 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env60288 : List Nat := [2,4,4,1,32,7,128,37,162,34,132,133,134,7,164,160,32,32,167,165,133,39,33,160,135,163,7,39,7,33,135,39,37,130,1,38]

theorem envBound60288 : H12AffineFastState.Bounded env60288 := by
  intro p hp
  have h : env60288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60287_60288 : H12AffineEnvironment.transform 2 4 env60287 = env60288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60287 == env60288) = true)

theorem identity60288 : scanCanonicalize (H12AffineFastState.compose env60288 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60288 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60289 : List Nat := [2,3,3,1,32,0,128,34,162,34,131,130,129,0,163,160,32,32,160,162,130,32,33,160,128,163,0,32,0,33,128,32,34,130,1,33]

theorem envBound60289 : H12AffineFastState.Bounded env60289 := by
  intro p hp
  have h : env60289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60288_60289 : H12AffineEnvironment.transform 1 3 env60288 = env60289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60288 == env60289) = true)

theorem identity60289 : scanCanonicalize (H12AffineFastState.compose env60289 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60289 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60290 : List Nat := [2,3,3,1,0,0,128,2,130,2,131,130,129,0,131,128,0,0,128,130,130,0,1,128,128,131,0,0,0,1,128,0,2,130,1,1]

theorem envBound60290 : H12AffineFastState.Bounded env60290 := by
  intro p hp
  have h : env60290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60289_60290 : H12AffineEnvironment.transform 4 0 env60289 = env60290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60289 == env60290) = true)

theorem identity60290 : scanCanonicalize (H12AffineFastState.compose env60290 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound60290 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60291 : List Nat := [2,3,3,1,0,0,2,2,0,2,1,0,3,0,1,2,0,0,2,0,0,0,1,2,2,1,0,0,0,1,2,0,2,0,1,1]

theorem envBound60291 : H12AffineFastState.Bounded env60291 := by
  intro p hp
  have h : env60291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60290_60291 : H12AffineEnvironment.transform 6 2 env60290 = env60291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env60290 == env60291) = true)

theorem identity60291 : scanCanonicalize (H12AffineFastState.compose env60291 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60292 : List Nat := [0,1,1,1,0,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0,1,1]

theorem envBound60292 : H12AffineFastState.Bounded env60292 := by
  intro p hp
  have h : env60292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60291_60292 : H12AffineEnvironment.transform 0 0 env60291 = env60292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60291 == env60292) = true)

def env60293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1297,576,65536,67442,65664,1877,577,1557,648,66082,66897,192,65830,1151,67363,1297,67650,784,67378,256,789,1345,340]

theorem envBound60293 : H12AffineFastState.Bounded env60293 := by
  intro p hp
  have h : env60293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60252_60293 : H12AffineEnvironment.transform 11 1557 env60252 = env60293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env60252 == env60293) = true)

def env60294 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,65536,66082,65664,517,577,837,648,66082,65537,192,65830,303,66163,65,67650,784,66146,256,789,17,340]

theorem envBound60294 : H12AffineFastState.Bounded env60294 := by
  intro p hp
  have h : env60294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60293_60294 : H12AffineEnvironment.transform 9 336 env60293 = env60294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env60293 == env60294) = true)

theorem identity60294 : scanCanonicalize (H12AffineFastState.compose env60294 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound60294 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60295 : List Nat := [2,4,8,16,32,64,128,145,512,193,2048,724,652,65,576,65536,66082,65664,517,577,724,648,66082,65537,192,65719,190,66163,65,67650,641,66146,145,644,17,197]

theorem envBound60295 : H12AffineFastState.Bounded env60295 := by
  intro p hp
  have h : env60295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60294_60295 : H12AffineEnvironment.transform 7 145 env60294 = env60295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env60294 == env60295) = true)

def env60296 : List Nat := [2,4,8,16,32,64,128,145,212,193,2048,0,88,65,148,65536,65782,65664,209,149,0,92,65782,65537,192,65719,190,65703,65,67650,85,65718,145,80,17,197]

theorem envBound60296 : H12AffineFastState.Bounded env60296 := by
  intro p hp
  have h : env60296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60295_60296 : H12AffineEnvironment.transform 8 212 env60295 = env60296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 212 env60295 == env60296) = true)

theorem identity60296 : scanCanonicalize (H12AffineFastState.compose env60296 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound60296 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60297 : List Nat := [2,4,8,16,32,64,128,145,212,193,2048,0,88,65,148,99,149,227,209,149,0,92,149,98,192,212,190,196,65,2081,85,213,145,80,17,197]

theorem envBound60297 : H12AffineFastState.Bounded env60297 := by
  intro p hp
  have h : env60297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60296_60297 : H12AffineEnvironment.transform 15 99 env60296 = env60297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env60296 == env60297) = true)

theorem identity60297 : scanCanonicalize (H12AffineFastState.compose env60297 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60297 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60298 : List Nat := [2,4,8,1,32,64,128,128,197,193,2048,0,73,65,133,99,132,227,192,132,0,77,132,98,192,197,175,196,65,2081,68,196,128,65,0,197]

theorem envBound60298 : H12AffineFastState.Bounded env60298 := by
  intro p hp
  have h : env60298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60297_60298 : H12AffineEnvironment.transform 3 1 env60297 = env60298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60297 == env60298) = true)

theorem identity60298 : scanCanonicalize (H12AffineFastState.compose env60298 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound60298 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60299 : List Nat := [2,4,8,1,32,64,73,73,12,8,2048,0,73,65,76,99,77,42,9,77,0,77,77,98,9,12,102,13,65,2081,68,13,73,65,0,12]

theorem envBound60299 : H12AffineFastState.Bounded env60299 := by
  intro p hp
  have h : env60299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60298_60299 : H12AffineEnvironment.transform 6 73 env60298 = env60299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env60298 == env60299) = true)

theorem identity60299 : scanCanonicalize (H12AffineFastState.compose env60299 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60299 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60300 : List Nat := [2,3,8,1,32,64,73,73,11,8,2048,0,73,65,75,99,74,42,9,74,0,74,74,98,9,11,97,10,65,2081,67,10,73,65,0,11]

theorem envBound60300 : H12AffineFastState.Bounded env60300 := by
  intro p hp
  have h : env60300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60299_60300 : H12AffineEnvironment.transform 1 3 env60299 = env60300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60299 == env60300) = true)

theorem identity60300 : scanCanonicalize (H12AffineFastState.compose env60300 (packedSelected [0,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound60300 : packedSelected [0,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env60301 : List Nat := [2,3,8,1,32,64,73,73,11,8,75,0,73,65,75,99,74,42,9,74,0,74,74,98,9,11,97,10,65,106,67,10,73,65,0,11]

theorem envBound60301 : H12AffineFastState.Bounded env60301 := by
  intro p hp
  have h : env60301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60300_60301 : H12AffineEnvironment.transform 10 75 env60300 = env60301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env60300 == env60301) = true)

theorem identity60301 : scanCanonicalize (H12AffineFastState.compose env60301 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60301 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env60302 : List Nat := [2,3,8,1,11,64,73,73,11,8,75,0,73,65,75,72,74,1,9,74,0,74,74,73,9,11,74,10,65,65,67,10,73,65,0,11]

theorem envBound60302 : H12AffineFastState.Bounded env60302 := by
  intro p hp
  have h : env60302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60301_60302 : H12AffineEnvironment.transform 4 11 env60301 = env60302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60301 == env60302) = true)

theorem identity60302 : scanCanonicalize (H12AffineFastState.compose env60302 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60302 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60303 : List Nat := [2,3,2,1,1,64,67,67,1,2,65,0,67,65,65,66,64,1,3,64,0,64,64,67,3,1,64,0,65,65,67,0,67,65,0,1]

theorem envBound60303 : H12AffineFastState.Bounded env60303 := by
  intro p hp
  have h : env60303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60302_60303 : H12AffineEnvironment.transform 2 2 env60302 = env60303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60302 == env60303) = true)

def env60304 : List Nat := [2,4,8,16,32,64,128,145,213,193,2048,1,89,65,149,65536,65783,65664,208,148,1,93,65783,65537,192,65719,190,65702,65,67650,84,65719,145,81,17,197]

theorem envBound60304 : H12AffineFastState.Bounded env60304 := by
  intro p hp
  have h : env60304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60295_60304 : H12AffineEnvironment.transform 8 213 env60295 = env60304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 213 env60295 == env60304) = true)

theorem identity60304 : scanCanonicalize (H12AffineFastState.compose env60304 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60304 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60305 : List Nat := [2,4,8,16,32,64,128,145,213,193,2048,1,89,65,149,114,133,242,208,148,1,93,133,115,192,197,190,212,65,2096,84,197,145,81,17,197]

theorem envBound60305 : H12AffineFastState.Bounded env60305 := by
  intro p hp
  have h : env60305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60304_60305 : H12AffineEnvironment.transform 15 114 env60304 = env60305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60304 == env60305) = true)

theorem identity60305 : scanCanonicalize (H12AffineFastState.compose env60305 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound60305 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60306 : List Nat := [2,4,8,16,32,64,69,84,16,4,2048,1,89,65,80,114,64,55,21,81,1,93,64,115,5,0,123,17,65,2096,84,0,84,81,17,0]

theorem envBound60306 : H12AffineFastState.Bounded env60306 := by
  intro p hp
  have h : env60306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60305_60306 : H12AffineEnvironment.transform 6 69 env60305 = env60306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env60305 == env60306) = true)

theorem identity60306 : scanCanonicalize (H12AffineFastState.compose env60306 (packedSelected [0,1,5,7,8,10,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound60306 : packedSelected [0,1,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60307 : List Nat := [2,4,8,16,32,49,52,37,16,4,2048,1,40,48,33,3,49,55,21,32,1,44,49,2,5,0,10,17,48,2096,37,0,37,32,17,0]

theorem envBound60307 : H12AffineFastState.Bounded env60307 := by
  intro p hp
  have h : env60307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60306_60307 : H12AffineEnvironment.transform 5 49 env60306 = env60307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env60306 == env60307) = true)

theorem identity60307 : scanCanonicalize (H12AffineFastState.compose env60307 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound60307 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60308 : List Nat := [2,4,8,16,32,49,52,37,16,4,26,1,40,48,33,3,49,55,21,32,1,44,49,2,5,0,10,17,48,42,37,0,37,32,17,0]

theorem envBound60308 : H12AffineFastState.Bounded env60308 := by
  intro p hp
  have h : env60308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60307_60308 : H12AffineEnvironment.transform 10 26 env60307 = env60308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env60307 == env60308) = true)

theorem identity60308 : scanCanonicalize (H12AffineFastState.compose env60308 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound60308 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env60309 : List Nat := [2,4,8,6,32,39,34,37,6,4,12,1,40,38,33,3,39,33,3,32,1,44,39,2,5,0,10,7,38,42,37,0,37,32,7,0]

theorem envBound60309 : H12AffineFastState.Bounded env60309 := by
  intro p hp
  have h : env60309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60308_60309 : H12AffineEnvironment.transform 3 6 env60308 = env60309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env60308 == env60309) = true)

theorem identity60309 : scanCanonicalize (H12AffineFastState.compose env60309 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60309 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env60310 : List Nat := [2,4,2,6,32,39,34,37,6,4,6,1,34,38,33,3,39,33,3,32,1,38,39,2,5,0,0,7,38,32,37,0,37,32,7,0]

theorem envBound60310 : H12AffineFastState.Bounded env60310 := by
  intro p hp
  have h : env60310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60309_60310 : H12AffineEnvironment.transform 2 2 env60309 = env60310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60309 == env60310) = true)

theorem identity60310 : scanCanonicalize (H12AffineFastState.compose env60310 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60311 : List Nat := [2,4,2,6,0,7,2,5,6,4,6,1,2,6,1,3,7,1,3,0,1,6,7,2,5,0,0,7,6,0,5,0,5,0,7,0]

theorem envBound60311 : H12AffineFastState.Bounded env60311 := by
  intro p hp
  have h : env60311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60310_60311 : H12AffineEnvironment.transform 4 0 env60310 = env60311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60310 == env60311) = true)

theorem identity60311 : scanCanonicalize (H12AffineFastState.compose env60311 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60312 : List Nat := [2,3,2,1,0,0,2,2,1,3,1,1,2,1,1,3,0,1,3,0,1,1,0,2,2,0,0,0,1,0,2,0,2,0,0,0]

theorem envBound60312 : H12AffineFastState.Bounded env60312 := by
  intro p hp
  have h : env60312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60311_60312 : H12AffineEnvironment.transform 1 3 env60311 = env60312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60311 == env60312) = true)

theorem identity60312 : scanCanonicalize (H12AffineFastState.compose env60312 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60313 : List Nat := [0,1,0,1,0,0,0,0,1,1,1,1,0,1,1,1,0,1,1,0,1,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0]

theorem envBound60313 : H12AffineFastState.Bounded env60313 := by
  intro p hp
  have h : env60313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60312_60313 : H12AffineEnvironment.transform 0 0 env60312 = env60313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60312 == env60313) = true)

def env60314 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,65536,66083,65664,516,577,836,648,66082,65536,192,65830,302,66162,64,67650,784,66147,256,789,16,340]

theorem envBound60314 : H12AffineFastState.Bounded env60314 := by
  intro p hp
  have h : env60314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60293_60314 : H12AffineEnvironment.transform 9 337 env60293 = env60314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env60293 == env60314) = true)

theorem identity60314 : scanCanonicalize (H12AffineFastState.compose env60314 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 212) := by decide +kernel

theorem selectedBound60314 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60315 : List Nat := [2,4,8,16,32,64,128,256,212,337,2048,400,457,64,148,65536,65783,65664,208,149,400,92,65782,65536,192,65830,302,65702,64,67650,452,65719,256,449,16,340]

theorem envBound60315 : H12AffineFastState.Bounded env60315 := by
  intro p hp
  have h : env60315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60314_60315 : H12AffineEnvironment.transform 8 212 env60314 = env60315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 212 env60314 == env60315) = true)

def env60316 : List Nat := [2,4,8,16,32,64,128,128,212,209,2048,16,73,64,148,65536,65783,65664,208,149,16,92,65782,65536,192,65702,174,65702,64,67650,68,65719,128,65,16,212]

theorem envBound60316 : H12AffineFastState.Bounded env60316 := by
  intro p hp
  have h : env60316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60315_60316 : H12AffineEnvironment.transform 7 128 env60315 = env60316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env60315 == env60316) = true)

theorem identity60316 : scanCanonicalize (H12AffineFastState.compose env60316 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60316 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60317 : List Nat := [2,4,8,16,32,64,128,128,212,209,2048,16,73,64,148,114,133,242,208,149,16,92,132,114,192,212,174,212,64,2096,68,197,128,65,16,212]

theorem envBound60317 : H12AffineFastState.Bounded env60317 := by
  intro p hp
  have h : env60317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60316_60317 : H12AffineEnvironment.transform 15 114 env60316 = env60317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60316 == env60317) = true)

theorem identity60317 : scanCanonicalize (H12AffineFastState.compose env60317 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound60317 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60318 : List Nat := [2,4,8,16,32,64,68,68,16,21,2048,16,73,64,80,114,65,54,20,81,16,92,64,114,4,16,106,16,64,2096,68,1,68,65,16,16]

theorem envBound60318 : H12AffineFastState.Bounded env60318 := by
  intro p hp
  have h : env60318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60317_60318 : H12AffineEnvironment.transform 6 68 env60317 = env60318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env60317 == env60318) = true)

theorem identity60318 : scanCanonicalize (H12AffineFastState.compose env60318 (packedSelected [0,7,8,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound60318 : packedSelected [0,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60319 : List Nat := [2,4,8,16,32,64,68,68,16,21,1,16,73,64,80,114,65,54,20,81,16,92,64,114,4,16,106,16,64,49,68,1,68,65,16,16]

theorem envBound60319 : H12AffineFastState.Bounded env60319 := by
  intro p hp
  have h : env60319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60318_60319 : H12AffineEnvironment.transform 10 1 env60318 = env60319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env60318 == env60319) = true)

theorem identity60319 : scanCanonicalize (H12AffineFastState.compose env60319 (packedSelected [1,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound60319 : packedSelected [1,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env60320 : List Nat := [2,4,8,16,26,64,68,68,16,21,1,16,73,64,80,72,65,12,20,81,16,92,64,72,4,16,80,16,64,11,68,1,68,65,16,16]

theorem envBound60320 : H12AffineFastState.Bounded env60320 := by
  intro p hp
  have h : env60320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60319_60320 : H12AffineEnvironment.transform 4 26 env60319 = env60320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env60319 == env60320) = true)

theorem identity60320 : scanCanonicalize (H12AffineFastState.compose env60320 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60320 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60321 : List Nat := [2,4,8,16,26,11,15,15,16,21,1,16,2,11,27,3,10,12,20,26,16,23,11,3,4,16,27,16,11,11,15,1,15,10,16,16]

theorem envBound60321 : H12AffineFastState.Bounded env60321 := by
  intro p hp
  have h : env60321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60320_60321 : H12AffineEnvironment.transform 5 11 env60320 = env60321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60320 == env60321) = true)

theorem identity60321 : scanCanonicalize (H12AffineFastState.compose env60321 (packedSelected [0,1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60321 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env60322 : List Nat := [2,4,3,16,17,0,4,4,16,21,1,16,2,0,16,3,1,7,20,17,16,23,0,3,4,16,16,16,0,0,4,1,4,1,16,16]

theorem envBound60322 : H12AffineFastState.Bounded env60322 := by
  intro p hp
  have h : env60322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60321_60322 : H12AffineEnvironment.transform 2 3 env60321 = env60322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60321 == env60322) = true)

theorem identity60322 : scanCanonicalize (H12AffineFastState.compose env60322 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound60322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60323 : List Nat := [2,4,3,7,6,0,4,4,7,2,1,7,2,0,7,3,1,7,3,6,7,0,0,3,4,7,7,7,0,0,4,1,4,1,7,7]

theorem envBound60323 : H12AffineFastState.Bounded env60323 := by
  intro p hp
  have h : env60323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60322_60323 : H12AffineEnvironment.transform 3 7 env60322 = env60323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env60322 == env60323) = true)

theorem identity60323 : scanCanonicalize (H12AffineFastState.compose env60323 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60324 : List Nat := [2,3,3,0,1,0,3,3,0,2,1,0,2,0,0,3,1,0,3,1,0,0,0,3,3,0,0,0,0,0,3,1,3,1,0,0]

theorem envBound60324 : H12AffineFastState.Bounded env60324 := by
  intro p hp
  have h : env60324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60323_60324 : H12AffineEnvironment.transform 1 3 env60323 = env60324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60323 == env60324) = true)

def env60325 : List Nat := [2,4,8,16,32,64,128,129,212,208,2048,17,72,64,148,65536,65783,65664,208,149,17,92,65782,65536,192,65703,175,65702,64,67650,69,65719,129,64,16,213]

theorem envBound60325 : H12AffineFastState.Bounded env60325 := by
  intro p hp
  have h : env60325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60315_60325 : H12AffineEnvironment.transform 7 129 env60315 = env60325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env60315 == env60325) = true)

theorem identity60325 : scanCanonicalize (H12AffineFastState.compose env60325 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound60325 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60326 : List Nat := [2,4,8,16,32,64,68,69,16,20,2048,17,72,64,80,65536,65587,65604,20,81,17,92,65586,65536,4,65635,107,65634,64,67650,69,65651,69,64,16,17]

theorem envBound60326 : H12AffineFastState.Bounded env60326 := by
  intro p hp
  have h : env60326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60325_60326 : H12AffineEnvironment.transform 6 68 env60325 = env60326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env60325 == env60326) = true)

theorem identity60326 : scanCanonicalize (H12AffineFastState.compose env60326 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound60326 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60327 : List Nat := [2,4,8,16,32,64,68,69,16,20,2048,17,72,64,80,98,81,38,20,81,17,92,80,98,4,1,107,0,64,2080,69,17,69,64,16,17]

theorem envBound60327 : H12AffineFastState.Bounded env60327 := by
  intro p hp
  have h : env60327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60326_60327 : H12AffineEnvironment.transform 15 98 env60326 = env60327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env60326 == env60327) = true)

theorem identity60327 : scanCanonicalize (H12AffineFastState.compose env60327 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60327 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60328 : List Nat := [2,4,8,1,32,64,68,69,1,5,2048,0,72,64,65,98,64,38,5,64,0,77,65,98,4,1,107,0,64,2080,69,0,69,64,1,0]

theorem envBound60328 : H12AffineFastState.Bounded env60328 := by
  intro p hp
  have h : env60328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60327_60328 : H12AffineEnvironment.transform 3 1 env60327 = env60328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60327 == env60328) = true)

theorem identity60328 : scanCanonicalize (H12AffineFastState.compose env60328 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound60328 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60329 : List Nat := [2,4,8,1,13,64,68,69,1,5,2048,0,72,64,65,79,64,11,5,64,0,77,65,79,4,1,70,0,64,2061,69,0,69,64,1,0]

theorem envBound60329 : H12AffineFastState.Bounded env60329 := by
  intro p hp
  have h : env60329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60328_60329 : H12AffineEnvironment.transform 4 13 env60328 = env60329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env60328 == env60329) = true)

theorem identity60329 : scanCanonicalize (H12AffineFastState.compose env60329 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound60329 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60330 : List Nat := [2,4,8,1,13,64,68,69,1,5,7,0,72,64,65,79,64,11,5,64,0,77,65,79,4,1,70,0,64,10,69,0,69,64,1,0]

theorem envBound60330 : H12AffineFastState.Bounded env60330 := by
  intro p hp
  have h : env60330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60329_60330 : H12AffineEnvironment.transform 10 7 env60329 = env60330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env60329 == env60330) = true)

theorem identity60330 : scanCanonicalize (H12AffineFastState.compose env60330 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60331 : List Nat := [2,4,8,1,13,11,15,14,1,5,7,0,3,11,10,4,11,11,5,11,0,6,10,4,4,1,13,0,11,10,14,0,14,11,1,0]

theorem envBound60331 : H12AffineFastState.Bounded env60331 := by
  intro p hp
  have h : env60331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60330_60331 : H12AffineEnvironment.transform 5 11 env60330 = env60331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60330 == env60331) = true)

theorem identity60331 : scanCanonicalize (H12AffineFastState.compose env60331 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound60331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60332 : List Nat := [2,0,8,1,9,11,11,10,1,1,3,0,3,11,10,0,11,11,1,11,0,2,10,0,0,1,9,0,11,10,10,0,10,11,1,0]

theorem envBound60332 : H12AffineFastState.Bounded env60332 := by
  intro p hp
  have h : env60332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60331_60332 : H12AffineEnvironment.transform 1 0 env60331 = env60332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env60331 == env60332) = true)

theorem identity60332 : scanCanonicalize (H12AffineFastState.compose env60332 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60332 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60333 : List Nat := [2,0,3,1,2,0,0,1,1,1,3,0,3,0,1,0,0,0,1,0,0,2,1,0,0,1,2,0,0,1,1,0,1,0,1,0]

theorem envBound60333 : H12AffineFastState.Bounded env60333 := by
  intro p hp
  have h : env60333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60332_60333 : H12AffineEnvironment.transform 2 3 env60332 = env60333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60332 == env60333) = true)

def env60334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4096,5277,74047,66897,13768,78894,1150,74814,1297,81226,8205,74799,256,8200,1345,5953]

theorem envBound60334 : H12AffineFastState.Bounded env60334 := by
  intro p hp
  have h : env60334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60250_60334 : H12AffineEnvironment.transform 17 65665 env60250 = env60334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60250 == env60334) = true)

theorem identity60334 : scanCanonicalize (H12AffineFastState.compose env60334 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound60334 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,65536,66599,65665,4416,276,4096,5277,65911,66897,5504,70758,1150,66678,1297,72962,69,66663,256,64,1345,5953]

theorem envBound60335 : H12AffineFastState.Bounded env60335 := by
  intro p hp
  have h : env60335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60334_60335 : H12AffineEnvironment.transform 12 72 env60334 = env60335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env60334 == env60335) = true)

def env60336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1297,277,65536,66599,65665,1876,276,1556,649,65911,66897,916,66162,1150,66678,1297,68374,69,66663,256,64,1345,341]

theorem envBound60336 : H12AffineFastState.Bounded env60336 := by
  intro p hp
  have h : env60336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60335_60336 : H12AffineEnvironment.transform 11 1556 env60335 = env60336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env60335 == env60336) = true)

def env60337 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,81,277,65536,65895,65665,532,276,852,649,65911,65553,916,66162,318,65846,81,68374,69,65831,256,64,1,341]

theorem envBound60337 : H12AffineFastState.Bounded env60337 := by
  intro p hp
  have h : env60337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60336_60337 : H12AffineEnvironment.transform 9 320 env60336 = env60337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60336 == env60337) = true)

theorem identity60337 : scanCanonicalize (H12AffineFastState.compose env60337 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound60337 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60338 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,81,277,807,576,934,532,276,852,649,592,822,916,341,318,529,81,2097,69,512,256,64,1,341]

theorem envBound60338 : H12AffineFastState.Bounded env60338 := by
  intro p hp
  have h : env60338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60337_60338 : H12AffineEnvironment.transform 15 807 env60337 = env60338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env60337 == env60338) = true)

theorem identity60338 : scanCanonicalize (H12AffineFastState.compose env60338 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound60338 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60339 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,1,72,81,277,114,277,243,321,276,1,476,261,99,193,341,318,324,81,2097,69,341,256,64,1,341]

theorem envBound60339 : H12AffineFastState.Bounded env60339 := by
  intro p hp
  have h : env60339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60338_60339 : H12AffineEnvironment.transform 8 341 env60338 = env60339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env60338 == env60339) = true)

theorem identity60339 : scanCanonicalize (H12AffineFastState.compose env60339 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound60339 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60340 : List Nat := [2,4,8,16,32,64,72,256,341,320,2048,1,72,81,277,114,277,59,321,276,1,276,261,99,9,341,318,324,81,2097,69,341,256,64,1,341]

theorem envBound60340 : H12AffineFastState.Bounded env60340 := by
  intro p hp
  have h : env60340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60339_60340 : H12AffineEnvironment.transform 6 72 env60339 = env60340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env60339 == env60340) = true)

theorem identity60340 : scanCanonicalize (H12AffineFastState.compose env60340 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60340 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env60341 : List Nat := [2,4,8,0,32,64,72,256,325,320,2048,1,72,65,261,98,261,43,321,260,1,260,261,99,9,325,302,324,65,2081,69,325,256,64,1,325]

theorem envBound60341 : H12AffineFastState.Bounded env60341 := by
  intro p hp
  have h : env60341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60340_60341 : H12AffineEnvironment.transform 3 0 env60340 = env60341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60340 == env60341) = true)

theorem identity60341 : scanCanonicalize (H12AffineFastState.compose env60341 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound60341 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60342 : List Nat := [2,4,8,0,32,64,72,256,325,320,293,1,72,65,261,98,261,43,321,260,1,260,261,99,9,325,302,324,65,260,69,325,256,64,1,325]

theorem envBound60342 : H12AffineFastState.Bounded env60342 := by
  intro p hp
  have h : env60342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60341_60342 : H12AffineEnvironment.transform 10 293 env60341 = env60342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env60341 == env60342) = true)

theorem identity60342 : scanCanonicalize (H12AffineFastState.compose env60342 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60342 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env60343 : List Nat := [2,4,8,0,32,33,41,256,292,289,293,1,41,32,261,3,261,43,288,260,1,260,261,2,9,292,302,293,32,260,36,292,256,33,1,292]

theorem envBound60343 : H12AffineFastState.Bounded env60343 := by
  intro p hp
  have h : env60343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60342_60343 : H12AffineEnvironment.transform 5 33 env60342 = env60343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60342 == env60343) = true)

theorem identity60343 : scanCanonicalize (H12AffineFastState.compose env60343 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound60343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60344 : List Nat := [2,4,8,0,32,33,41,5,33,36,32,1,41,32,0,3,0,43,37,1,1,1,0,2,9,33,43,32,32,1,36,33,5,33,1,33]

theorem envBound60344 : H12AffineFastState.Bounded env60344 := by
  intro p hp
  have h : env60344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60343_60344 : H12AffineEnvironment.transform 7 5 env60343 = env60344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env60343 == env60344) = true)

theorem identity60344 : scanCanonicalize (H12AffineFastState.compose env60344 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60345 : List Nat := [2,4,5,0,32,33,36,5,33,36,32,1,36,32,0,3,0,38,37,1,1,1,0,2,4,33,38,32,32,1,36,33,5,33,1,33]

theorem envBound60345 : H12AffineFastState.Bounded env60345 := by
  intro p hp
  have h : env60345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60344_60345 : H12AffineEnvironment.transform 2 5 env60344 = env60345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60344 == env60345) = true)

theorem identity60345 : scanCanonicalize (H12AffineFastState.compose env60345 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound60345 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60346 : List Nat := [2,4,5,0,6,7,2,5,7,2,6,1,2,6,0,3,0,0,3,1,1,1,0,2,4,7,0,6,6,1,2,7,5,7,1,7]

theorem envBound60346 : H12AffineFastState.Bounded env60346 := by
  intro p hp
  have h : env60346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60345_60346 : H12AffineEnvironment.transform 4 6 env60345 = env60346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env60345 == env60346) = true)

def env60347 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,80,277,65536,65894,65665,533,276,853,649,65911,65552,916,66162,319,65847,80,68374,69,65830,256,64,0,341]

theorem envBound60347 : H12AffineFastState.Bounded env60347 := by
  intro p hp
  have h : env60347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60336_60347 : H12AffineEnvironment.transform 9 321 env60336 = env60347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60336 == env60347) = true)

theorem identity60347 : scanCanonicalize (H12AffineFastState.compose env60347 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60347 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60348 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,80,277,114,276,243,533,276,853,649,261,98,916,512,319,325,80,2916,69,340,256,64,0,341]

theorem envBound60348 : H12AffineFastState.Bounded env60348 := by
  intro p hp
  have h : env60348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60347_60348 : H12AffineEnvironment.transform 15 114 env60347 = env60348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60347 == env60348) = true)

theorem identity60348 : scanCanonicalize (H12AffineFastState.compose env60348 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60348 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60349 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,528,72,80,80,114,81,243,533,81,528,649,64,98,721,512,122,0,80,2593,69,17,69,64,0,16]

theorem envBound60349 : H12AffineFastState.Bounded env60349 := by
  intro p hp
  have h : env60349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60348_60349 : H12AffineEnvironment.transform 7 69 env60348 = env60349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60348 == env60349) = true)

theorem identity60349 : scanCanonicalize (H12AffineFastState.compose env60349 (packedSelected [1,2,10,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 229) := by decide +kernel

theorem selectedBound60349 : packedSelected [1,2,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env60350 : List Nat := [2,4,8,16,32,64,128,69,229,4,2048,245,72,80,80,114,81,243,240,81,245,108,64,98,52,229,122,0,80,2244,69,17,69,64,0,16]

theorem envBound60350 : H12AffineFastState.Bounded env60350 := by
  intro p hp
  have h : env60350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60349_60350 : H12AffineEnvironment.transform 8 229 env60349 = env60350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 229 env60349 == env60350) = true)

theorem identity60350 : scanCanonicalize (H12AffineFastState.compose env60350 (packedSelected [3,5,10,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound60350 : packedSelected [3,5,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env60351 : List Nat := [2,4,8,16,32,64,128,69,229,4,195,245,72,80,80,114,81,243,240,81,245,108,64,98,52,229,122,0,80,7,69,17,69,64,0,16]

theorem envBound60351 : H12AffineFastState.Bounded env60351 := by
  intro p hp
  have h : env60351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60350_60351 : H12AffineEnvironment.transform 10 195 env60350 = env60351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env60350 == env60351) = true)

theorem identity60351 : scanCanonicalize (H12AffineFastState.compose env60351 (packedSelected [0,2,4,7,9,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound60351 : packedSelected [0,2,4,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env60352 : List Nat := [2,4,8,16,32,64,4,69,97,4,71,113,72,80,80,114,81,119,116,81,113,108,64,98,52,97,122,0,80,7,69,17,69,64,0,16]

theorem envBound60352 : H12AffineFastState.Bounded env60352 := by
  intro p hp
  have h : env60352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60351_60352 : H12AffineEnvironment.transform 6 4 env60351 = env60352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env60351 == env60352) = true)

theorem identity60352 : scanCanonicalize (H12AffineFastState.compose env60352 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound60352 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60353 : List Nat := [2,4,8,16,32,39,4,34,6,4,32,22,47,55,55,21,54,16,19,54,22,11,39,5,52,6,29,0,55,7,34,17,34,39,0,16]

theorem envBound60353 : H12AffineFastState.Bounded env60353 := by
  intro p hp
  have h : env60353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60352_60353 : H12AffineEnvironment.transform 5 39 env60352 = env60353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env60352 == env60353) = true)

theorem identity60353 : scanCanonicalize (H12AffineFastState.compose env60353 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60353 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60354 : List Nat := [2,4,5,16,32,39,4,34,6,4,32,22,34,55,55,21,54,16,19,54,22,6,39,5,52,6,16,0,55,7,34,17,34,39,0,16]

theorem envBound60354 : H12AffineFastState.Bounded env60354 := by
  intro p hp
  have h : env60354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60353_60354 : H12AffineEnvironment.transform 2 5 env60353 = env60354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60353 == env60354) = true)

theorem identity60354 : scanCanonicalize (H12AffineFastState.compose env60354 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound60354 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env60355 : List Nat := [2,4,5,16,22,17,4,20,6,4,22,22,20,1,1,21,0,16,19,0,22,6,17,5,2,6,16,0,1,7,20,17,20,17,0,16]

theorem envBound60355 : H12AffineFastState.Bounded env60355 := by
  intro p hp
  have h : env60355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60354_60355 : H12AffineEnvironment.transform 4 22 env60354 = env60355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env60354 == env60355) = true)

theorem identity60355 : scanCanonicalize (H12AffineFastState.compose env60355 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60355 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60356 : List Nat := [2,4,5,1,7,0,4,5,6,4,7,7,5,1,1,4,0,1,2,0,7,6,0,5,2,6,1,0,1,7,5,0,5,0,0,1]

theorem envBound60356 : H12AffineFastState.Bounded env60356 := by
  intro p hp
  have h : env60356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60355_60356 : H12AffineEnvironment.transform 3 1 env60355 = env60356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60355 == env60356) = true)

theorem identity60356 : scanCanonicalize (H12AffineFastState.compose env60356 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60356 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60357 : List Nat := [2,3,2,1,0,0,3,2,1,3,0,0,2,1,1,3,0,1,2,0,0,1,0,2,2,1,1,0,1,0,2,0,2,0,0,1]

theorem envBound60357 : H12AffineFastState.Bounded env60357 := by
  intro p hp
  have h : env60357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60356_60357 : H12AffineEnvironment.transform 1 3 env60356 = env60357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60356 == env60357) = true)

def env60358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1297,277,65536,66599,65665,1877,276,1557,648,65911,66897,917,66163,1150,66678,1297,68375,69,66663,256,64,1345,340]

theorem envBound60358 : H12AffineFastState.Bounded env60358 := by
  intro p hp
  have h : env60358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60335_60358 : H12AffineEnvironment.transform 11 1557 env60335 = env60358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env60335 == env60358) = true)

def env60359 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,81,277,65536,65895,65665,533,276,853,648,65911,65553,917,66163,318,65846,81,68375,69,65831,256,64,1,340]

theorem envBound60359 : H12AffineFastState.Bounded env60359 := by
  intro p hp
  have h : env60359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60358_60359 : H12AffineEnvironment.transform 9 320 env60358 = env60359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60358 == env60359) = true)

theorem identity60359 : scanCanonicalize (H12AffineFastState.compose env60359 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound60359 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60360 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,81,277,806,577,935,533,276,853,648,593,823,917,341,318,528,81,2097,69,513,256,64,1,340]

theorem envBound60360 : H12AffineFastState.Bounded env60360 := by
  intro p hp
  have h : env60360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60359_60360 : H12AffineEnvironment.transform 15 806 env60359 = env60360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env60359 == env60360) = true)

theorem identity60360 : scanCanonicalize (H12AffineFastState.compose env60360 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound60360 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60361 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,1,72,81,277,114,277,243,321,276,1,476,261,99,193,341,318,324,81,2097,69,341,256,64,1,340]

theorem envBound60361 : H12AffineFastState.Bounded env60361 := by
  intro p hp
  have h : env60361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60360_60361 : H12AffineEnvironment.transform 8 340 env60360 = env60361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env60360 == env60361) = true)

theorem identity60361 : scanCanonicalize (H12AffineFastState.compose env60361 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound60361 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60362 : List Nat := [2,4,8,16,32,64,73,256,340,320,2048,1,72,81,277,114,277,58,321,276,1,277,261,99,8,341,318,324,81,2097,69,341,256,64,1,340]

theorem envBound60362 : H12AffineFastState.Bounded env60362 := by
  intro p hp
  have h : env60362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60361_60362 : H12AffineEnvironment.transform 6 73 env60361 = env60362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env60361 == env60362) = true)

theorem identity60362 : scanCanonicalize (H12AffineFastState.compose env60362 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60362 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env60363 : List Nat := [2,4,8,1,32,64,73,256,325,320,2048,1,72,64,260,99,260,43,321,261,1,260,261,99,8,324,303,324,64,2080,69,324,256,64,1,325]

theorem envBound60363 : H12AffineFastState.Bounded env60363 := by
  intro p hp
  have h : env60363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60362_60363 : H12AffineEnvironment.transform 3 1 env60362 = env60363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60362 == env60363) = true)

theorem identity60363 : scanCanonicalize (H12AffineFastState.compose env60363 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound60363 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60364 : List Nat := [2,4,8,1,32,64,73,256,325,320,293,1,72,64,260,99,260,43,321,261,1,260,261,99,8,324,303,324,64,261,69,324,256,64,1,325]

theorem envBound60364 : H12AffineFastState.Bounded env60364 := by
  intro p hp
  have h : env60364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60363_60364 : H12AffineEnvironment.transform 10 293 env60363 = env60364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env60363 == env60364) = true)

theorem identity60364 : scanCanonicalize (H12AffineFastState.compose env60364 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60364 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env60365 : List Nat := [2,4,8,1,32,33,40,256,292,289,293,1,41,33,260,2,260,43,288,261,1,260,261,2,8,293,303,293,33,261,36,293,256,33,1,292]

theorem envBound60365 : H12AffineFastState.Bounded env60365 := by
  intro p hp
  have h : env60365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60364_60365 : H12AffineEnvironment.transform 5 33 env60364 = env60365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60364 == env60365) = true)

theorem identity60365 : scanCanonicalize (H12AffineFastState.compose env60365 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound60365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60366 : List Nat := [2,4,8,1,32,33,40,4,32,37,33,1,41,33,0,2,0,43,36,1,1,0,1,2,8,33,43,33,33,1,36,33,4,33,1,32]

theorem envBound60366 : H12AffineFastState.Bounded env60366 := by
  intro p hp
  have h : env60366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60365_60366 : H12AffineEnvironment.transform 7 4 env60365 = env60366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env60365 == env60366) = true)

theorem identity60366 : scanCanonicalize (H12AffineFastState.compose env60366 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60367 : List Nat := [2,4,5,1,32,33,37,4,32,37,33,1,36,33,0,2,0,38,36,1,1,0,1,2,5,33,38,33,33,1,36,33,4,33,1,32]

theorem envBound60367 : H12AffineFastState.Bounded env60367 := by
  intro p hp
  have h : env60367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60366_60367 : H12AffineEnvironment.transform 2 5 env60366 = env60367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60366 == env60367) = true)

theorem identity60367 : scanCanonicalize (H12AffineFastState.compose env60367 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound60367 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60368 : List Nat := [2,4,5,1,6,7,3,4,6,3,7,1,2,7,0,2,0,0,2,1,1,0,1,2,5,7,0,7,7,1,2,7,4,7,1,6]

theorem envBound60368 : H12AffineFastState.Bounded env60368 := by
  intro p hp
  have h : env60368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60367_60368 : H12AffineEnvironment.transform 4 6 env60367 = env60368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env60367 == env60368) = true)

def env60369 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,80,277,65536,65894,65665,532,276,852,648,65911,65552,917,66163,319,65847,80,68375,69,65830,256,64,0,340]

theorem envBound60369 : H12AffineFastState.Bounded env60369 := by
  intro p hp
  have h : env60369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60358_60369 : H12AffineEnvironment.transform 9 321 env60358 = env60369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60358 == env60369) = true)

theorem identity60369 : scanCanonicalize (H12AffineFastState.compose env60369 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60369 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60370 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,80,277,114,276,243,532,276,852,648,261,98,917,513,319,325,80,2917,69,340,256,64,0,340]

theorem envBound60370 : H12AffineFastState.Bounded env60370 := by
  intro p hp
  have h : env60370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60369_60370 : H12AffineEnvironment.transform 15 114 env60369 = env60370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60369 == env60370) = true)

theorem identity60370 : scanCanonicalize (H12AffineFastState.compose env60370 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60370 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60371 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,529,72,80,80,114,81,243,532,81,529,648,64,98,720,513,122,0,80,2592,69,17,69,64,0,17]

theorem envBound60371 : H12AffineFastState.Bounded env60371 := by
  intro p hp
  have h : env60371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60370_60371 : H12AffineEnvironment.transform 7 69 env60370 = env60371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60370 == env60371) = true)

theorem identity60371 : scanCanonicalize (H12AffineFastState.compose env60371 (packedSelected [1,2,10,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound60371 : packedSelected [1,2,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env60372 : List Nat := [2,4,8,16,32,64,128,69,180,4,2048,165,72,80,80,114,81,243,160,81,165,60,64,98,100,181,122,0,80,2196,69,17,69,64,0,17]

theorem envBound60372 : H12AffineFastState.Bounded env60372 := by
  intro p hp
  have h : env60372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60371_60372 : H12AffineEnvironment.transform 8 180 env60371 = env60372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env60371 == env60372) = true)

theorem identity60372 : scanCanonicalize (H12AffineFastState.compose env60372 (packedSelected [3,5,10,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound60372 : packedSelected [3,5,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env60373 : List Nat := [2,4,8,16,32,64,128,69,180,4,195,165,72,80,80,114,81,243,160,81,165,60,64,98,100,181,122,0,80,87,69,17,69,64,0,17]

theorem envBound60373 : H12AffineFastState.Bounded env60373 := by
  intro p hp
  have h : env60373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60372_60373 : H12AffineEnvironment.transform 10 195 env60372 = env60373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env60372 == env60373) = true)

theorem identity60373 : scanCanonicalize (H12AffineFastState.compose env60373 (packedSelected [0,2,4,7,9,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound60373 : packedSelected [0,2,4,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env60374 : List Nat := [2,4,8,16,32,64,85,69,97,4,22,112,72,80,80,114,81,38,117,81,112,60,64,98,100,96,122,0,80,87,69,17,69,64,0,17]

theorem envBound60374 : H12AffineFastState.Bounded env60374 := by
  intro p hp
  have h : env60374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60373_60374 : H12AffineEnvironment.transform 6 85 env60373 = env60374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env60373 == env60374) = true)

theorem identity60374 : scanCanonicalize (H12AffineFastState.compose env60374 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound60374 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60375 : List Nat := [2,4,8,16,32,7,18,2,38,4,22,55,15,23,23,53,22,38,50,22,55,60,7,37,35,39,61,0,23,16,2,17,2,7,0,17]

theorem envBound60375 : H12AffineFastState.Bounded env60375 := by
  intro p hp
  have h : env60375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60374_60375 : H12AffineEnvironment.transform 5 7 env60374 = env60375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env60374 == env60375) = true)

theorem identity60375 : scanCanonicalize (H12AffineFastState.compose env60375 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60375 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60376 : List Nat := [2,4,8,11,32,7,9,2,38,4,13,44,15,12,12,46,13,38,41,13,44,39,7,37,35,39,38,0,12,11,2,10,2,7,0,10]

theorem envBound60376 : H12AffineFastState.Bounded env60376 := by
  intro p hp
  have h : env60376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60375_60376 : H12AffineEnvironment.transform 3 11 env60375 = env60376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60375 == env60376) = true)

theorem identity60376 : scanCanonicalize (H12AffineFastState.compose env60376 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60376 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env60377 : List Nat := [2,4,5,6,32,7,4,2,38,4,0,33,2,1,1,35,0,38,36,0,33,39,7,37,35,39,38,0,1,6,2,7,2,7,0,7]

theorem envBound60377 : H12AffineFastState.Bounded env60377 := by
  intro p hp
  have h : env60377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60376_60377 : H12AffineEnvironment.transform 2 5 env60376 = env60377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60376 == env60377) = true)

theorem identity60377 : scanCanonicalize (H12AffineFastState.compose env60377 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound60377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60378 : List Nat := [2,4,5,6,7,7,4,2,1,4,0,6,2,1,1,4,0,1,3,0,6,0,7,2,4,0,1,0,1,6,2,7,2,7,0,7]

theorem envBound60378 : H12AffineFastState.Bounded env60378 := by
  intro p hp
  have h : env60378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60377_60378 : H12AffineEnvironment.transform 4 7 env60377 = env60378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env60377 == env60378) = true)

theorem identity60378 : scanCanonicalize (H12AffineFastState.compose env60378 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60378 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60379 : List Nat := [2,3,2,1,0,0,3,2,1,3,0,1,2,1,1,3,0,1,3,0,1,0,0,2,3,0,1,0,1,1,2,0,2,0,0,0]

theorem envBound60379 : H12AffineFastState.Bounded env60379 := by
  intro p hp
  have h : env60379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60378_60379 : H12AffineEnvironment.transform 1 3 env60378 = env60379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60378 == env60379) = true)

theorem identity60379 : scanCanonicalize (H12AffineFastState.compose env60379 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60380 : List Nat := [1,0,1,1,0,0,0,1,1,0,0,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,0,0,0]

theorem envBound60380 : H12AffineFastState.Bounded env60380 := by
  intro p hp
  have h : env60380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60379_60380 : H12AffineEnvironment.transform 0 1 env60379 = env60380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60379 == env60380) = true)

def env60381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,134217728,148800,545089,96347,16876544,74799,257,17420372,151462016,525824]

theorem envBound60381 : H12AffineFastState.Bounded env60381 := by
  intro p hp
  have h : env60381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59469_60381 : H12AffineEnvironment.transform 24 533641 env59469 = env60381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env59469 == env60381) = true)

def env60382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245632,148800,545089,96347,16876544,74799,257,17420372,1344,525824]

theorem envBound60382 : H12AffineFastState.Bounded env60382 := by
  intro p hp
  have h : env60382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60381_60382 : H12AffineEnvironment.transform 26 17245632 env60381 = env60382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env60381 == env60382) = true)

theorem identity60382 : scanCanonicalize (H12AffineFastState.compose env60382 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound60382 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env60383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717115,533641,672784,906491,148800,545089,96347,750907,74799,257,205167,1344,525824]

theorem envBound60383 : H12AffineFastState.Bounded env60383 := by
  intro p hp
  have h : env60383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60382_60383 : H12AffineEnvironment.transform 23 717115 env60382 = env60383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env60382 == env60383) = true)

end H12CloudChart2