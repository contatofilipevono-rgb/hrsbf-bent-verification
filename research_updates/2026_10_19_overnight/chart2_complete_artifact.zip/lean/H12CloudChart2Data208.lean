import H12CloudChart2Data207

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52371 : scanCanonicalize (H12AffineFastState.compose env52371 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound52371 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52372 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,65536,184,262144,5305,12312,4097,1060,1044,4146,12336,5292,341174,184,184,81079,74795,73770,173,74799,1212,4793]

theorem envBound52372 : H12AffineFastState.Bounded env52372 := by
  intro p hp
  have h : env52372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52371_52372 : H12AffineEnvironment.transform 14 12313 env52371 = env52372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env52371 == env52372) = true)

theorem identity52372 : scanCanonicalize (H12AffineFastState.compose env52372 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound52372 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env52373 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,9351,184,262144,5305,12312,4097,1060,1044,4146,12336,5292,266289,184,184,6192,172,1197,173,168,1212,4793]

theorem envBound52373 : H12AffineFastState.Bounded env52373 := by
  intro p hp
  have h : env52373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52372_52373 : H12AffineEnvironment.transform 15 9351 env52372 = env52373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env52372 == env52373) = true)

theorem identity52373 : scanCanonicalize (H12AffineFastState.compose env52373 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound52373 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env52374 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,9351,184,6192,5305,12312,4097,1060,1044,4146,12336,5292,2049,184,184,6192,172,1197,173,168,1212,4793]

theorem envBound52374 : H12AffineFastState.Bounded env52374 := by
  intro p hp
  have h : env52374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52373_52374 : H12AffineEnvironment.transform 17 6192 env52373 = env52374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env52373 == env52374) = true)

theorem identity52374 : scanCanonicalize (H12AffineFastState.compose env52374 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound52374 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env52375 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,554,8192,1213,8755,9351,184,2586,1683,8754,555,1060,1044,536,8730,1670,2049,184,184,2586,172,1197,173,168,1212,147]

theorem envBound52375 : H12AffineFastState.Bounded env52375 := by
  intro p hp
  have h : env52375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52374_52375 : H12AffineEnvironment.transform 11 554 env52374 = env52375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env52374 == env52375) = true)

theorem identity52375 : scanCanonicalize (H12AffineFastState.compose env52375 (packedSelected [1,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 1565) := by decide +kernel

theorem selectedBound52375 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env52376 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,554,1565,1213,1070,666,184,2586,1683,1071,555,1060,1044,536,1031,1670,2049,184,184,2586,172,1197,173,168,1212,147]

theorem envBound52376 : H12AffineFastState.Bounded env52376 := by
  intro p hp
  have h : env52376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52375_52376 : H12AffineEnvironment.transform 12 1565 env52375 = env52376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1565 env52375 == env52376) = true)

theorem identity52376 : scanCanonicalize (H12AffineFastState.compose env52376 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52376 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env52377 : List Nat := [2,4,8,16,32,16,128,172,137,1024,2048,163,1172,1213,1070,19,184,2195,1050,1071,162,1060,1044,145,1031,1039,2049,184,184,2195,172,1197,173,168,1212,147]

theorem envBound52377 : H12AffineFastState.Bounded env52377 := by
  intro p hp
  have h : env52377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52376_52377 : H12AffineEnvironment.transform 8 137 env52376 = env52377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52376 == env52377) = true)

theorem identity52377 : scanCanonicalize (H12AffineFastState.compose env52377 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound52377 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52378 : List Nat := [2,4,8,16,32,16,128,172,137,150,2048,163,2,43,184,19,184,2195,140,185,162,178,130,145,145,153,2049,184,184,2195,172,59,173,168,42,147]

theorem envBound52378 : H12AffineFastState.Bounded env52378 := by
  intro p hp
  have h : env52378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52377_52378 : H12AffineEnvironment.transform 9 150 env52377 = env52378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env52377 == env52378) = true)

theorem identity52378 : scanCanonicalize (H12AffineFastState.compose env52378 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound52378 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52379 : List Nat := [2,4,8,16,32,16,19,63,26,5,2048,48,2,43,43,19,43,2048,31,42,49,33,17,2,2,10,2049,43,43,2048,63,59,62,59,42,0]

theorem envBound52379 : H12AffineFastState.Bounded env52379 := by
  intro p hp
  have h : env52379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52378_52379 : H12AffineEnvironment.transform 6 19 env52378 = env52379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env52378 == env52379) = true)

theorem identity52379 : scanCanonicalize (H12AffineFastState.compose env52379 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound52379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52380 : List Nat := [2,4,8,16,32,16,19,63,26,5,61,48,2,43,43,19,43,61,31,42,49,33,17,2,2,10,60,43,43,61,63,59,62,59,42,0]

theorem envBound52380 : H12AffineFastState.Bounded env52380 := by
  intro p hp
  have h : env52380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52379_52380 : H12AffineEnvironment.transform 10 61 env52379 = env52380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env52379 == env52380) = true)

theorem identity52380 : scanCanonicalize (H12AffineFastState.compose env52380 (packedSelected [2,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52380 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env52381 : List Nat := [2,4,4,16,32,16,19,51,22,5,49,48,2,39,39,19,39,49,19,38,49,33,17,2,2,6,48,39,39,49,51,55,50,55,38,0]

theorem envBound52381 : H12AffineFastState.Bounded env52381 := by
  intro p hp
  have h : env52381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52380_52381 : H12AffineEnvironment.transform 2 4 env52380 = env52381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52380 == env52381) = true)

theorem identity52381 : scanCanonicalize (H12AffineFastState.compose env52381 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound52381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52382 : List Nat := [2,4,4,7,32,7,4,36,1,5,38,39,2,39,39,4,39,38,4,38,38,33,6,2,2,6,39,39,39,38,36,32,37,32,38,0]

theorem envBound52382 : H12AffineFastState.Bounded env52382 := by
  intro p hp
  have h : env52382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52381_52382 : H12AffineEnvironment.transform 3 7 env52381 = env52382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env52381 == env52382) = true)

theorem identity52382 : scanCanonicalize (H12AffineFastState.compose env52382 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound52382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52383 : List Nat := [2,0,0,3,32,3,0,32,1,1,34,35,2,35,35,0,35,34,0,34,34,33,2,2,2,2,35,35,35,34,32,32,33,32,34,0]

theorem envBound52383 : H12AffineFastState.Bounded env52383 := by
  intro p hp
  have h : env52383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52382_52383 : H12AffineEnvironment.transform 1 0 env52382 = env52383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env52382 == env52383) = true)

theorem identity52383 : scanCanonicalize (H12AffineFastState.compose env52383 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound52383 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52384 : List Nat := [2,0,0,3,2,3,0,2,1,1,0,1,2,1,1,0,1,0,0,0,0,3,2,2,2,2,1,1,1,0,2,2,3,2,0,0]

theorem envBound52384 : H12AffineFastState.Bounded env52384 := by
  intro p hp
  have h : env52384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52383_52384 : H12AffineEnvironment.transform 4 2 env52383 = env52384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env52383 == env52384) = true)

theorem identity52384 : scanCanonicalize (H12AffineFastState.compose env52384 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52384 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52385 : List Nat := [0,0,0,1,0,1,0,0,1,1,0,1,0,1,1,0,1,0,0,0,0,1,0,0,0,0,1,1,1,0,0,0,1,0,0,0]

theorem envBound52385 : H12AffineFastState.Bounded env52385 := by
  intro p hp
  have h : env52385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52384_52385 : H12AffineEnvironment.transform 0 0 env52384 = env52385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52384 == env52385) = true)

def env52386 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143496,20497,492566,148668,148668,96267,74795,204947,173,90258,1213,135681]

theorem envBound52386 : H12AffineFastState.Bounded env52386 := by
  intro p hp
  have h : env52386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52368_52386 : H12AffineEnvironment.transform 5 17 env52368 = env52386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52368 == env52386) = true)

theorem identity52386 : scanCanonicalize (H12AffineFastState.compose env52386 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound52386 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52387 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,41003,143496,20497,105631,148668,148668,96267,74795,204947,173,90258,1213,135681]

theorem envBound52387 : H12AffineFastState.Bounded env52387 := by
  intro p hp
  have h : env52387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52386_52387 : H12AffineEnvironment.transform 17 137353 env52386 = env52387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env52386 == env52387) = true)

theorem identity52387 : scanCanonicalize (H12AffineFastState.compose env52387 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound52387 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52388 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4097,61569,147472,41003,143496,20497,43169,148668,148668,19509,4117,136365,173,21676,1213,135681]

theorem envBound52388 : H12AffineFastState.Bounded env52388 := by
  intro p hp
  have h : env52388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52387_52388 : H12AffineEnvironment.transform 15 13374 env52387 = env52388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env52387 == env52388) = true)

theorem identity52388 : scanCanonicalize (H12AffineFastState.compose env52388 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound52388 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52389 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136193,32769,4097,46140,132269,41003,143496,5292,43169,131073,131073,2184,4117,136365,173,4113,1213,135681]

theorem envBound52389 : H12AffineFastState.Bounded env52389 := by
  intro p hp
  have h : env52389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52388_52389 : H12AffineEnvironment.transform 13 1213 env52388 = env52389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env52388 == env52389) = true)

theorem identity52389 : scanCanonicalize (H12AffineFastState.compose env52389 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound52389 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env52390 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,46245,44076,41124,32769,4097,46140,45064,41003,33837,5292,43169,46244,46244,2184,4117,40968,173,4113,1213,42660]

theorem envBound52390 : H12AffineFastState.Bounded env52390 := by
  intro p hp
  have h : env52390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52389_52390 : H12AffineEnvironment.transform 16 46245 env52389 = env52390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env52389 == env52390) = true)

theorem identity52390 : scanCanonicalize (H12AffineFastState.compose env52390 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52390 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52391 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,32768,12347,45216,43049,41124,32769,4097,45113,45064,41003,32808,4265,43169,45217,45217,2184,4117,40968,173,4113,184,41633]

theorem envBound52391 : H12AffineFastState.Bounded env52391 := by
  intro p hp
  have h : env52391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52390_52391 : H12AffineEnvironment.transform 9 5 env52390 = env52391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52390 == env52391) = true)

theorem identity52391 : scanCanonicalize (H12AffineFastState.compose env52391 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound52391 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52392 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,2194,8192,184,32768,10409,43058,43049,41124,32769,2195,43179,43162,41003,32808,2107,43169,43059,43059,2184,2183,40968,173,2179,184,41633]

theorem envBound52392 : H12AffineFastState.Bounded env52392 := by
  intro p hp
  have h : env52392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52391_52392 : H12AffineEnvironment.transform 11 2194 env52391 = env52392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env52391 == env52392) = true)

theorem identity52392 : scanCanonicalize (H12AffineFastState.compose env52392 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 10427) := by decide +kernel

theorem selectedBound52392 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52393 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,2194,8192,184,10427,10409,137,146,2079,10426,2195,16,33,2192,10387,2107,26,136,136,2184,2183,2227,173,2179,184,2586]

theorem envBound52393 : H12AffineFastState.Bounded env52393 := by
  intro p hp
  have h : env52393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52392_52393 : H12AffineEnvironment.transform 14 10427 env52392 = env52393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10427 env52392 == env52393) = true)

theorem identity52393 : scanCanonicalize (H12AffineFastState.compose env52393 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound52393 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env52394 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,2194,2098,184,137,155,137,146,2079,136,2195,16,33,2192,161,2107,26,136,136,2184,2183,2227,173,2179,184,2586]

theorem envBound52394 : H12AffineFastState.Bounded env52394 := by
  intro p hp
  have h : env52394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52393_52394 : H12AffineEnvironment.transform 12 2098 env52393 = env52394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env52393 == env52394) = true)

theorem identity52394 : scanCanonicalize (H12AffineFastState.compose env52394 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound52394 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52395 : List Nat := [2,4,8,16,32,17,128,172,42,5,2048,2194,2098,184,137,155,137,146,2079,136,2195,16,33,2192,161,2107,26,136,136,2184,2183,2227,173,2179,184,2096]

theorem envBound52395 : H12AffineFastState.Bounded env52395 := by
  intro p hp
  have h : env52395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52394_52395 : H12AffineEnvironment.transform 8 42 env52394 = env52395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env52394 == env52395) = true)

theorem identity52395 : scanCanonicalize (H12AffineFastState.compose env52395 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound52395 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env52396 : List Nat := [2,4,8,16,32,17,128,172,42,5,184,42,138,184,137,155,137,146,167,136,43,16,33,40,161,131,26,136,136,48,63,11,173,59,184,136]

theorem envBound52396 : H12AffineFastState.Bounded env52396 := by
  intro p hp
  have h : env52396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52395_52396 : H12AffineEnvironment.transform 10 184 env52395 = env52396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env52395 == env52396) = true)

theorem identity52396 : scanCanonicalize (H12AffineFastState.compose env52396 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52396 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52397 : List Nat := [2,4,8,16,32,17,8,36,42,5,48,42,2,48,1,19,1,26,47,0,43,16,33,40,41,11,26,0,0,48,63,11,37,59,48,0]

theorem envBound52397 : H12AffineFastState.Bounded env52397 := by
  intro p hp
  have h : env52397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52396_52397 : H12AffineEnvironment.transform 6 8 env52396 = env52397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52396 == env52397) = true)

theorem identity52397 : scanCanonicalize (H12AffineFastState.compose env52397 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52397 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52398 : List Nat := [2,4,8,11,32,10,8,36,42,5,43,42,2,43,1,8,1,1,47,0,43,11,33,40,41,11,1,0,0,43,36,11,37,32,43,0]

theorem envBound52398 : H12AffineFastState.Bounded env52398 := by
  intro p hp
  have h : env52398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52397_52398 : H12AffineEnvironment.transform 3 11 env52397 = env52398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52397 == env52398) = true)

theorem identity52398 : scanCanonicalize (H12AffineFastState.compose env52398 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52399 : List Nat := [2,4,8,11,10,10,8,14,0,5,1,0,2,1,1,8,1,1,5,0,1,11,11,2,3,11,1,0,0,1,14,11,15,10,1,0]

theorem envBound52399 : H12AffineFastState.Bounded env52399 := by
  intro p hp
  have h : env52399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52398_52399 : H12AffineEnvironment.transform 4 10 env52398 = env52399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52398 == env52399) = true)

theorem identity52399 : scanCanonicalize (H12AffineFastState.compose env52399 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52400 : List Nat := [2,2,8,11,10,10,8,8,0,3,1,0,2,1,1,8,1,1,3,0,1,11,11,2,3,11,1,0,0,1,8,11,9,10,1,0]

theorem envBound52400 : H12AffineFastState.Bounded env52400 := by
  intro p hp
  have h : env52400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52399_52400 : H12AffineEnvironment.transform 1 2 env52399 = env52400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52399 == env52400) = true)

def env52401 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143496,20497,492614,148716,148716,96346,74795,204995,172,90259,1261,135681]

theorem envBound52401 : H12AffineFastState.Bounded env52401 := by
  intro p hp
  have h : env52401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52367_52401 : H12AffineEnvironment.transform 7 173 env52367 = env52401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52367 == env52401) = true)

def env52402 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143496,20497,492566,148668,148668,96266,74795,204947,172,90259,1213,135681]

theorem envBound52402 : H12AffineFastState.Bounded env52402 := by
  intro p hp
  have h : env52402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52401_52402 : H12AffineEnvironment.transform 5 16 env52401 = env52402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52401 == env52402) = true)

theorem identity52402 : scanCanonicalize (H12AffineFastState.compose env52402 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound52402 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52403 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61568,98355,41003,127146,20497,279604,99486,99486,96266,74795,57521,172,90259,1213,119331]

theorem envBound52403 : H12AffineFastState.Bounded env52403 := by
  intro p hp
  have h : env52403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52402_52403 : H12AffineEnvironment.transform 16 114722 env52402 = env52403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env52402 == env52403) = true)

theorem identity52403 : scanCanonicalize (H12AffineFastState.compose env52403 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound52403 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52404 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,6193,119843,32769,4097,61568,98355,41003,127146,20497,23557,99486,99486,96266,74795,57521,172,90259,1213,119331]

theorem envBound52404 : H12AffineFastState.Bounded env52404 := by
  intro p hp
  have h : env52404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52403_52404 : H12AffineEnvironment.transform 17 6193 env52403 = env52404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env52403 == env52404) = true)

theorem identity52404 : scanCanonicalize (H12AffineFastState.compose env52404 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound52404 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env52405 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,6193,1024,32769,4097,61568,20496,41003,8329,20497,23557,21693,21693,43049,62472,57521,172,45232,1213,512]

theorem envBound52405 : H12AffineFastState.Bounded env52405 := by
  intro p hp
  have h : env52405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52404_52405 : H12AffineEnvironment.transform 15 53283 env52404 = env52405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env52404 == env52405) = true)

theorem identity52405 : scanCanonicalize (H12AffineFastState.compose env52405 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound52405 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52406 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,9350,4097,6193,1024,29860,4097,1061,20496,21646,8329,20497,23557,21693,21693,23692,173,5140,172,17429,1213,512]

theorem envBound52406 : H12AffineFastState.Bounded env52406 := by
  intro p hp
  have h : env52406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52405_52406 : H12AffineEnvironment.transform 14 29861 env52405 = env52406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env52405 == env52406) = true)

theorem identity52406 : scanCanonicalize (H12AffineFastState.compose env52406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound52406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52407 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5676,16384,17033,4778,4097,6193,1024,17032,4097,1061,20496,21646,5797,20497,23557,21693,21693,23692,173,5140,172,17429,1213,512]

theorem envBound52407 : H12AffineFastState.Bounded env52407 := by
  intro p hp
  have h : env52407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52406_52407 : H12AffineEnvironment.transform 12 5676 env52406 = env52407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env52406 == env52407) = true)

theorem identity52407 : scanCanonicalize (H12AffineFastState.compose env52407 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 1703) := by decide +kernel

theorem selectedBound52407 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env52408 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5676,1703,1070,4778,4097,6193,1024,1071,4097,1061,5815,4649,5797,5814,6818,4634,4634,6699,173,5140,172,690,1213,512]

theorem envBound52408 : H12AffineFastState.Bounded env52408 := by
  intro p hp
  have h : env52408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52407_52408 : H12AffineEnvironment.transform 13 1703 env52407 = env52408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1703 env52407 == env52408) = true)

theorem identity52408 : scanCanonicalize (H12AffineFastState.compose env52408 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound52408 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52409 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3076,2600,1703,1070,3758,3077,1077,1024,1071,3077,1061,2739,3629,2721,2738,1702,3614,3614,1583,173,2064,172,690,1213,512]

theorem envBound52409 : H12AffineFastState.Bounded env52409 := by
  intro p hp
  have h : env52409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52408_52409 : H12AffineEnvironment.transform 11 3076 env52408 = env52409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env52408 == env52409) = true)

theorem identity52409 : scanCanonicalize (H12AffineFastState.compose env52409 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound52409 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env52410 : List Nat := [2,4,8,16,32,16,128,173,512,150,2048,2194,2600,561,184,2616,2195,163,150,185,2195,179,2739,2747,2721,2738,560,2696,2696,697,173,2064,172,690,43,512]

theorem envBound52410 : H12AffineFastState.Bounded env52410 := by
  intro p hp
  have h : env52410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52409_52410 : H12AffineEnvironment.transform 9 150 env52409 = env52410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env52409 == env52410) = true)

theorem identity52410 : scanCanonicalize (H12AffineFastState.compose env52410 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound52410 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52411 : List Nat := [2,4,8,16,32,16,128,173,512,150,555,697,3,561,184,19,696,163,150,185,696,179,152,144,138,153,560,163,163,697,173,571,172,690,43,512]

theorem envBound52411 : H12AffineFastState.Bounded env52411 := by
  intro p hp
  have h : env52411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52410_52411 : H12AffineEnvironment.transform 10 555 env52410 = env52411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env52410 == env52411) = true)

theorem identity52411 : scanCanonicalize (H12AffineFastState.compose env52411 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52411 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52412 : List Nat := [2,4,8,16,32,16,128,173,137,150,162,48,3,184,184,19,49,163,150,185,49,179,152,144,138,153,185,163,163,48,173,178,172,59,43,137]

theorem envBound52412 : H12AffineFastState.Bounded env52412 := by
  intro p hp
  have h : env52412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52411_52412 : H12AffineEnvironment.transform 8 137 env52411 = env52412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52411 == env52412) = true)

theorem identity52412 : scanCanonicalize (H12AffineFastState.compose env52412 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52412 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env52413 : List Nat := [2,4,8,16,32,16,9,36,0,31,43,48,3,49,49,19,49,42,31,48,49,58,17,25,3,16,48,42,42,48,36,59,37,59,43,0]

theorem envBound52413 : H12AffineFastState.Bounded env52413 := by
  intro p hp
  have h : env52413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52412_52413 : H12AffineEnvironment.transform 6 9 env52412 = env52413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52412 == env52413) = true)

theorem identity52413 : scanCanonicalize (H12AffineFastState.compose env52413 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52414 : List Nat := [2,4,8,10,32,10,9,36,0,5,43,42,3,43,43,9,43,42,5,42,43,32,11,3,3,10,42,42,42,42,36,33,37,33,43,0]

theorem envBound52414 : H12AffineFastState.Bounded env52414 := by
  intro p hp
  have h : env52414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52413_52414 : H12AffineEnvironment.transform 3 10 env52413 = env52414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52413 == env52414) = true)

theorem identity52414 : scanCanonicalize (H12AffineFastState.compose env52414 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound52414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52415 : List Nat := [2,4,8,10,12,10,9,8,0,5,7,6,3,7,7,9,7,6,5,6,7,12,11,3,3,10,6,6,6,6,8,13,9,13,7,0]

theorem envBound52415 : H12AffineFastState.Bounded env52415 := by
  intro p hp
  have h : env52415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52414_52415 : H12AffineEnvironment.transform 4 12 env52414 = env52415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env52414 == env52415) = true)

theorem identity52415 : scanCanonicalize (H12AffineFastState.compose env52415 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52415 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52416 : List Nat := [2,2,8,10,10,10,9,8,0,3,1,0,3,1,1,9,1,0,3,0,1,10,11,3,3,10,0,0,0,0,8,11,9,11,1,0]

theorem envBound52416 : H12AffineFastState.Bounded env52416 := by
  intro p hp
  have h : env52416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52415_52416 : H12AffineEnvironment.transform 1 2 env52415 = env52416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52415 == env52416) = true)

def env52417 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143496,20497,492567,148669,148669,96267,74795,204946,172,90259,1212,135681]

theorem envBound52417 : H12AffineFastState.Bounded env52417 := by
  intro p hp
  have h : env52417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52401_52417 : H12AffineEnvironment.transform 5 17 env52401 = env52417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52401 == env52417) = true)

theorem identity52417 : scanCanonicalize (H12AffineFastState.compose env52417 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound52417 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52418 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61569,147472,41003,143496,20497,60444,148669,148669,96267,74795,204946,172,90259,1212,135681]

theorem envBound52418 : H12AffineFastState.Bounded env52418 := by
  intro p hp
  have h : env52418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52417_52418 : H12AffineEnvironment.transform 17 223243 env52417 = env52418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env52417 == env52418) = true)

theorem identity52418 : scanCanonicalize (H12AffineFastState.compose env52418 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound52418 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52419 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4097,61569,147472,41003,143496,20497,60444,148669,148669,2184,21672,151569,172,4112,1212,135681]

theorem envBound52419 : H12AffineFastState.Bounded env52419 := by
  intro p hp
  have h : env52419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52418_52419 : H12AffineEnvironment.transform 15 28803 env52418 = env52419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env52418 == env52419) = true)

theorem identity52419 : scanCanonicalize (H12AffineFastState.compose env52419 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound52419 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52420 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,28803,131072,137352,136193,12313,4097,16537,147472,4147,143496,20497,23556,148669,148669,2184,21672,151569,172,4112,1212,135681]

theorem envBound52420 : H12AffineFastState.Bounded env52420 := by
  intro p hp
  have h : env52420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52419_52420 : H12AffineEnvironment.transform 14 12312 env52419 = env52420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env52419 == env52420) = true)

theorem identity52420 : scanCanonicalize (H12AffineFastState.compose env52420 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound52420 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52421 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,13375,131072,137352,136193,12313,4097,1061,132268,4147,143496,5293,6328,131073,131073,2184,4116,136365,172,4112,1212,135681]

theorem envBound52421 : H12AffineFastState.Bounded env52421 := by
  intro p hp
  have h : env52421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52420_52421 : H12AffineEnvironment.transform 13 1212 env52420 = env52421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env52420 == env52421) = true)

theorem identity52421 : scanCanonicalize (H12AffineFastState.compose env52421 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 14386) := by decide +kernel

theorem selectedBound52421 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52422 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,13375,14386,8378,11315,12313,4097,1061,15518,4147,2234,5293,6328,14387,14387,2184,4116,11423,172,4112,1212,10803]

theorem envBound52422 : H12AffineFastState.Bounded env52422 := by
  intro p hp
  have h : env52422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52421_52422 : H12AffineEnvironment.transform 16 14386 env52421 = env52422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 14386 env52421 == env52422) = true)

theorem identity52422 : scanCanonicalize (H12AffineFastState.compose env52422 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52422 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env52423 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,185,12312,12346,14386,8378,10294,12313,4097,32,14491,4147,2234,4264,6328,14387,14387,2184,4116,10394,172,4112,185,10803]

theorem envBound52423 : H12AffineFastState.Bounded env52423 := by
  intro p hp
  have h : env52423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52422_52423 : H12AffineEnvironment.transform 9 5 env52422 = env52423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52422 == env52423) = true)

theorem identity52423 : scanCanonicalize (H12AffineFastState.compose env52423 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 6795) := by decide +kernel

theorem selectedBound52423 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env52424 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,6795,185,2707,2737,697,6705,4797,2706,4097,32,528,4147,2234,4264,6328,696,696,2184,4116,4625,172,4112,185,4280]

theorem envBound52424 : H12AffineFastState.Bounded env52424 := by
  intro p hp
  have h : env52424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52423_52424 : H12AffineEnvironment.transform 12 6795 env52423 = env52424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6795 env52423 == env52424) = true)

theorem identity52424 : scanCanonicalize (H12AffineFastState.compose env52424 (packedSelected [6,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2223) := by decide +kernel

theorem selectedBound52424 : packedSelected [6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env52425 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2223,548,185,2707,2737,697,670,2578,2706,2222,32,528,2204,2234,2055,23,696,696,2184,2235,2750,172,2239,185,2071]

theorem envBound52425 : H12AffineFastState.Bounded env52425 := by
  intro p hp
  have h : env52425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52424_52425 : H12AffineEnvironment.transform 11 2223 env52424 = env52425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2223 env52424 == env52425) = true)

theorem identity52425 : scanCanonicalize (H12AffineFastState.compose env52425 (packedSelected [0,4,8,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound52425 : packedSelected [0,4,8,10,15] rootPS < 2^1333 := by decide +kernel

def env52426 : List Nat := [2,4,8,16,32,17,52,25,512,5,2048,2075,548,13,2599,2565,525,554,2578,2598,2074,32,528,2088,2062,2055,23,524,524,2108,2063,2570,24,2059,13,2071]

theorem envBound52426 : H12AffineFastState.Bounded env52426 := by
  intro p hp
  have h : env52426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52425_52426 : H12AffineEnvironment.transform 6 52 env52425 = env52426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env52425 == env52426) = true)

theorem identity52426 : scanCanonicalize (H12AffineFastState.compose env52426 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound52426 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env52427 : List Nat := [2,4,8,16,32,17,52,25,512,5,561,554,548,13,22,52,525,554,35,23,555,32,528,537,575,566,23,524,524,525,574,59,24,570,13,550]

theorem envBound52427 : H12AffineFastState.Bounded env52427 := by
  intro p hp
  have h : env52427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52426_52427 : H12AffineEnvironment.transform 10 561 env52426 = env52427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env52426 == env52427) = true)

theorem identity52427 : scanCanonicalize (H12AffineFastState.compose env52427 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound52427 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env52428 : List Nat := [2,4,8,16,32,17,52,25,39,5,22,13,3,13,22,52,42,13,35,23,12,32,55,62,24,17,23,43,43,42,25,59,24,29,13,1]

theorem envBound52428 : H12AffineFastState.Bounded env52428 := by
  intro p hp
  have h : env52428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52427_52428 : H12AffineEnvironment.transform 8 39 env52427 = env52428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env52427 == env52428) = true)

theorem identity52428 : scanCanonicalize (H12AffineFastState.compose env52428 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound52428 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env52429 : List Nat := [2,4,8,16,7,17,19,25,0,5,22,13,3,13,22,19,13,13,4,23,12,7,16,25,24,17,23,12,12,13,25,28,24,29,13,1]

theorem envBound52429 : H12AffineFastState.Bounded env52429 := by
  intro p hp
  have h : env52429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52428_52429 : H12AffineEnvironment.transform 4 7 env52428 = env52429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env52428 == env52429) = true)

theorem identity52429 : scanCanonicalize (H12AffineFastState.compose env52429 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound52429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52430 : List Nat := [2,4,8,9,7,8,10,0,0,5,15,13,3,13,15,10,13,13,4,14,12,7,9,0,1,8,14,12,12,13,0,5,1,4,13,1]

theorem envBound52430 : H12AffineFastState.Bounded env52430 := by
  intro p hp
  have h : env52430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52429_52430 : H12AffineEnvironment.transform 3 9 env52429 = env52430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env52429 == env52430) = true)

theorem identity52430 : scanCanonicalize (H12AffineFastState.compose env52430 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound52430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52431 : List Nat := [2,0,8,9,3,8,10,0,0,1,11,9,3,9,11,10,9,9,0,10,8,3,9,0,1,8,10,8,8,9,0,1,1,0,9,1]

theorem envBound52431 : H12AffineFastState.Bounded env52431 := by
  intro p hp
  have h : env52431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52430_52431 : H12AffineEnvironment.transform 1 0 env52430 = env52431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env52430 == env52431) = true)

theorem identity52431 : scanCanonicalize (H12AffineFastState.compose env52431 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52432 : List Nat := [1,0,8,9,0,8,9,0,0,1,8,9,0,9,8,9,9,9,0,9,8,0,9,0,1,8,9,8,8,9,0,1,1,0,9,1]

theorem envBound52432 : H12AffineFastState.Bounded env52432 := by
  intro p hp
  have h : env52432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52431_52432 : H12AffineEnvironment.transform 0 1 env52431 = env52432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52431 == env52432) = true)

theorem identity52432 : scanCanonicalize (H12AffineFastState.compose env52432 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52432 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52433 : List Nat := [1,0,0,1,0,0,1,0,0,1,0,1,0,1,0,1,1,1,0,1,0,0,1,0,1,0,1,0,0,1,0,1,1,0,1,1]

theorem envBound52433 : H12AffineFastState.Bounded env52433 := by
  intro p hp
  have h : env52433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52432_52433 : H12AffineEnvironment.transform 2 0 env52432 = env52433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52432 == env52433) = true)

def env52434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,17245633,148801,545088,96346,16876544,205167,257,17552661,1345,525824]

theorem envBound52434 : H12AffineFastState.Bounded env52434 := by
  intro p hp
  have h : env52434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52312_52434 : H12AffineEnvironment.transform 26 17245633 env52312 = env52434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env52312 == env52434) = true)

theorem identity52434 : scanCanonicalize (H12AffineFastState.compose env52434 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound52434 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717115,533641,672784,906490,148801,545088,96346,750907,205167,257,74798,1345,525824]

theorem envBound52435 : H12AffineFastState.Bounded env52435 := by
  intro p hp
  have h : env52435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52434_52435 : H12AffineEnvironment.transform 23 717115 env52434 = env52435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env52434 == env52435) = true)

def env52436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58683,143497,20496,508154,148801,148800,96346,90427,205167,257,74798,1345,135680]

theorem envBound52436 : H12AffineFastState.Bounded env52436 := by
  intro p hp
  have h : env52436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52435_52436 : H12AffineEnvironment.transform 18 136192 env52435 = env52436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env52435 == env52436) = true)

def env52437 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143497,20496,508154,148717,148716,96346,90263,204995,173,74798,1261,135680]

theorem envBound52437 : H12AffineFastState.Bounded env52437 := by
  intro p hp
  have h : env52437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52436_52437 : H12AffineEnvironment.transform 7 172 env52436 = env52437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52436 == env52437) = true)

def env52438 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143497,20496,508074,148669,148668,96266,90263,204947,173,74798,1213,135680]

theorem envBound52438 : H12AffineFastState.Bounded env52438 := by
  intro p hp
  have h : env52438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52437_52438 : H12AffineEnvironment.transform 5 16 env52437 = env52438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52437 == env52438) = true)

theorem identity52438 : scanCanonicalize (H12AffineFastState.compose env52438 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound52438 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52439 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,58519,143497,20496,120866,148669,148668,96266,90263,204947,173,74798,1213,135680]

theorem envBound52439 : H12AffineFastState.Bounded env52439 := by
  intro p hp
  have h : env52439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52438_52439 : H12AffineEnvironment.transform 17 137352 env52438 = env52439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env52438 == env52439) = true)

theorem identity52439 : scanCanonicalize (H12AffineFastState.compose env52439 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound52439 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env52440 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4097,61568,46093,58519,50325,20496,120866,45217,45216,96266,90263,119951,173,74798,1213,58908]

theorem envBound52440 : H12AffineFastState.Bounded env52440 := by
  intro p hp
  have h : env52440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52439_52440 : H12AffineEnvironment.transform 16 62492 env52439 = env52440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env52439 == env52440) = true)

theorem identity52440 : scanCanonicalize (H12AffineFastState.compose env52440 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound52440 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52441 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12312,65536,17412,23692,20484,12313,4097,16536,1045,21647,29837,20496,92218,185,184,96266,90263,91287,173,74798,1213,22020]

theorem envBound52441 : H12AffineFastState.Bounded env52441 := by
  intro p hp
  have h : env52441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52440_52441 : H12AffineEnvironment.transform 14 12312 env52440 = env52441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env52440 == env52441) = true)

theorem identity52441 : scanCanonicalize (H12AffineFastState.compose env52441 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound52441 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env52442 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12312,2730,17412,23692,20484,12313,4097,16536,1045,21647,29837,20496,25232,185,184,29344,27197,28221,173,11908,1213,22020]

theorem envBound52442 : H12AffineFastState.Bounded env52442 := by
  intro p hp
  have h : env52442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52441_52442 : H12AffineEnvironment.transform 15 2730 env52441 = env52442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env52441 == env52442) = true)

theorem identity52442 : scanCanonicalize (H12AffineFastState.compose env52442 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 10897) := by decide +kernel

theorem selectedBound52442 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env52443 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,10897,12312,2730,11925,13853,14997,12313,4097,10761,1045,15902,7708,14977,2049,185,184,6193,172,1196,173,11908,1213,15509]

theorem envBound52443 : H12AffineFastState.Bounded env52443 := by
  intro p hp
  have h : env52443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52442_52443 : H12AffineEnvironment.transform 13 10897 env52442 = env52443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10897 env52442 == env52443) = true)

theorem identity52443 : scanCanonicalize (H12AffineFastState.compose env52443 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound52443 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52444 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7829,5124,3725,2730,4096,2184,1024,3724,4097,5276,1045,139,7708,1044,2049,185,184,6193,172,1196,173,4113,1213,512]

theorem envBound52444 : H12AffineFastState.Bounded env52444 := by
  intro p hp
  have h : env52444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52443_52444 : H12AffineEnvironment.transform 12 7829 env52443 = env52444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env52443 == env52444) = true)

theorem identity52444 : scanCanonicalize (H12AffineFastState.compose env52444 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound52444 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env52445 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,4096,6680,4233,2560,2730,4096,2184,141,2561,4097,4113,152,139,6801,153,2049,185,184,6193,172,33,173,4113,48,512]

theorem envBound52445 : H12AffineFastState.Bounded env52445 := by
  intro p hp
  have h : env52445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52444_52445 : H12AffineEnvironment.transform 9 141 env52444 = env52445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env52444 == env52445) = true)

theorem identity52445 : scanCanonicalize (H12AffineFastState.compose env52445 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound52445 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52446 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,674,2234,555,2560,2730,674,2184,141,2561,675,691,152,139,2099,153,2049,185,184,2707,172,33,173,691,48,512]

theorem envBound52446 : H12AffineFastState.Bounded env52446 := by
  intro p hp
  have h : env52446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52445_52446 : H12AffineEnvironment.transform 11 674 env52445 = env52446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env52445 == env52446) = true)

theorem identity52446 : scanCanonicalize (H12AffineFastState.compose env52446 (packedSelected [2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound52446 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env52447 : List Nat := [2,4,8,16,32,16,128,172,512,141,162,674,24,555,674,520,674,42,141,675,675,691,152,139,145,153,163,185,184,561,172,33,173,691,48,512]

theorem envBound52447 : H12AffineFastState.Bounded env52447 := by
  intro p hp
  have h : env52447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52446_52447 : H12AffineEnvironment.transform 10 162 env52446 = env52447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env52446 == env52447) = true)

theorem identity52447 : scanCanonicalize (H12AffineFastState.compose env52447 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52447 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env52448 : List Nat := [2,4,8,11,32,11,128,172,512,141,162,674,3,555,674,520,674,42,141,675,675,680,131,139,138,130,163,162,163,554,172,33,173,680,43,512]

theorem envBound52448 : H12AffineFastState.Bounded env52448 := by
  intro p hp
  have h : env52448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52447_52448 : H12AffineEnvironment.transform 3 11 env52447 = env52448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52447 == env52448) = true)

theorem identity52448 : scanCanonicalize (H12AffineFastState.compose env52448 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52448 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52449 : List Nat := [2,4,8,11,32,11,128,172,137,141,162,43,3,162,43,129,43,42,141,42,42,33,131,139,138,130,163,162,163,163,172,33,173,33,43,137]

theorem envBound52449 : H12AffineFastState.Bounded env52449 := by
  intro p hp
  have h : env52449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52448_52449 : H12AffineEnvironment.transform 8 137 env52448 = env52449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52448 == env52449) = true)

theorem identity52449 : scanCanonicalize (H12AffineFastState.compose env52449 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52449 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52450 : List Nat := [2,4,8,11,32,11,9,37,0,4,43,43,3,43,43,8,43,42,4,42,42,33,10,2,3,11,42,43,42,42,37,33,36,33,43,0]

theorem envBound52450 : H12AffineFastState.Bounded env52450 := by
  intro p hp
  have h : env52450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52449_52450 : H12AffineEnvironment.transform 6 9 env52449 = env52450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52449 == env52450) = true)

theorem identity52450 : scanCanonicalize (H12AffineFastState.compose env52450 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound52450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52451 : List Nat := [2,4,8,11,12,11,9,9,0,4,7,7,3,7,7,8,7,6,4,6,6,13,10,2,3,11,6,7,6,6,9,13,8,13,7,0]

theorem envBound52451 : H12AffineFastState.Bounded env52451 := by
  intro p hp
  have h : env52451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52450_52451 : H12AffineEnvironment.transform 4 12 env52450 = env52451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env52450 == env52451) = true)

def env52452 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143497,20496,508075,148668,148669,96267,90263,204946,173,74798,1212,135680]

theorem envBound52452 : H12AffineFastState.Bounded env52452 := by
  intro p hp
  have h : env52452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52437_52452 : H12AffineEnvironment.transform 5 17 env52437 = env52452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52437 == env52452) = true)

theorem identity52452 : scanCanonicalize (H12AffineFastState.compose env52452 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound52452 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52453 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,58519,32809,20496,356363,62492,62493,96267,90263,102450,173,74798,1212,41632]

theorem envBound52453 : H12AffineFastState.Bounded env52453 := by
  intro p hp
  have h : env52453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52452_52453 : H12AffineEnvironment.transform 16 45216 env52452 = env52453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env52452 == env52453) = true)

theorem identity52453 : scanCanonicalize (H12AffineFastState.compose env52453 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound52453 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52454 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4097,61569,61616,58519,32809,20496,96386,62492,62493,96267,90263,102450,173,74798,1212,41632]

theorem envBound52454 : H12AffineFastState.Bounded env52454 := by
  intro p hp
  have h : env52454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52453_52454 : H12AffineEnvironment.transform 17 2185 env52453 = env52454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env52453 == env52454) = true)

theorem identity52454 : scanCanonicalize (H12AffineFastState.compose env52454 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound52454 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52455 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,9350,45216,2185,42144,32769,4097,61569,61616,58519,32809,20496,23556,62492,62493,23693,17425,46260,173,168,1212,41632]

theorem envBound52455 : H12AffineFastState.Bounded env52455 := by
  intro p hp
  have h : env52455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52454_52455 : H12AffineEnvironment.transform 15 9350 env52454 = env52455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env52454 == env52455) = true)

theorem identity52455 : scanCanonicalize (H12AffineFastState.compose env52455 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound52455 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env52456 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,9350,40985,2185,42144,32769,184,57400,57353,58519,32809,16553,19645,58533,58532,19508,17425,41997,173,168,1212,41632]

theorem envBound52456 : H12AffineFastState.Bounded env52456 := by
  intro p hp
  have h : env52456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52455_52456 : H12AffineEnvironment.transform 11 185 env52455 = env52456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env52455 == env52456) = true)

theorem identity52456 : scanCanonicalize (H12AffineFastState.compose env52456 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10913) := by decide +kernel

theorem selectedBound52456 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env52457 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,10913,32768,9350,40985,2185,42144,32769,184,35481,35496,36406,32809,10760,9756,36356,36357,9877,11952,41997,173,168,1212,41632]

theorem envBound52457 : H12AffineFastState.Bounded env52457 := by
  intro p hp
  have h : env52457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52456_52457 : H12AffineEnvironment.transform 13 10913 env52456 = env52457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10913 env52456 == env52457) = true)

theorem identity52457 : scanCanonicalize (H12AffineFastState.compose env52457 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound52457 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env52458 : List Nat := [2,4,8,16,32,17,128,172,512,1024,513,185,8192,8352,32768,9350,40985,648,42144,32769,184,32920,32937,33847,32809,8201,9756,33797,33796,9877,9393,41997,173,168,1212,41632]

theorem envBound52458 : H12AffineFastState.Bounded env52458 := by
  intro p hp
  have h : env52458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52457_52458 : H12AffineEnvironment.transform 10 513 env52457 = env52458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env52457 == env52458) = true)

theorem identity52458 : scanCanonicalize (H12AffineFastState.compose env52458 (packedSelected [0,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound52458 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env52459 : List Nat := [2,4,8,16,32,17,128,172,512,565,513,185,8192,8352,32768,8883,40985,648,41621,32769,184,32920,32937,33282,32809,8201,8233,33328,33329,8352,8836,41528,173,168,649,41632]

theorem envBound52459 : H12AffineFastState.Bounded env52459 := by
  intro p hp
  have h : env52459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52458_52459 : H12AffineEnvironment.transform 9 565 env52458 = env52459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env52458 == env52459) = true)

theorem identity52459 : scanCanonicalize (H12AffineFastState.compose env52459 (packedSelected [2,3,7,8,9,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 162) := by decide +kernel

theorem selectedBound52459 : packedSelected [2,3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env52460 : List Nat := [2,4,8,16,32,17,128,172,512,565,513,185,8192,8352,162,8883,8379,648,8759,163,184,58,11,672,139,8201,8233,658,659,8352,8836,8858,173,168,649,8706]

theorem envBound52460 : H12AffineFastState.Bounded env52460 := by
  intro p hp
  have h : env52460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52459_52460 : H12AffineEnvironment.transform 14 162 env52459 = env52460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 162 env52459 == env52460) = true)

theorem identity52460 : scanCanonicalize (H12AffineFastState.compose env52460 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound52460 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52461 : List Nat := [2,4,8,16,32,17,128,172,512,565,513,185,144,48,162,547,43,648,679,163,184,58,11,672,139,153,185,658,659,48,532,522,173,168,649,658]

theorem envBound52461 : H12AffineFastState.Bounded env52461 := by
  intro p hp
  have h : env52461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52460_52461 : H12AffineEnvironment.transform 12 144 env52460 = env52461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env52460 == env52461) = true)

theorem identity52461 : scanCanonicalize (H12AffineFastState.compose env52461 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound52461 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52462 : List Nat := [2,4,8,16,32,17,128,172,184,141,185,185,144,48,162,155,43,48,31,163,184,58,11,24,139,153,185,42,43,48,172,178,173,168,49,42]

theorem envBound52462 : H12AffineFastState.Bounded env52462 := by
  intro p hp
  have h : env52462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52461_52462 : H12AffineEnvironment.transform 8 184 env52461 = env52462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env52461 == env52462) = true)

theorem identity52462 : scanCanonicalize (H12AffineFastState.compose env52462 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52463 : List Nat := [2,4,8,16,32,17,18,62,42,31,43,43,2,48,48,9,43,48,31,49,42,58,11,24,25,11,43,42,43,48,62,32,63,58,49,42]

theorem envBound52463 : H12AffineFastState.Bounded env52463 := by
  intro p hp
  have h : env52463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52462_52463 : H12AffineEnvironment.transform 6 18 env52462 = env52463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52462 == env52463) = true)

theorem identity52463 : scanCanonicalize (H12AffineFastState.compose env52463 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound52463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52464 : List Nat := [2,4,8,16,6,17,18,24,12,31,13,13,2,22,22,9,13,22,31,23,12,28,11,24,25,11,13,12,13,22,24,6,25,28,23,12]

theorem envBound52464 : H12AffineFastState.Bounded env52464 := by
  intro p hp
  have h : env52464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52463_52464 : H12AffineEnvironment.transform 4 6 env52463 = env52464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env52463 == env52464) = true)

theorem identity52464 : scanCanonicalize (H12AffineFastState.compose env52464 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52464 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52465 : List Nat := [2,4,8,10,6,11,8,2,12,5,13,13,2,12,12,9,13,12,5,13,12,6,11,2,3,11,13,12,13,12,2,6,3,6,13,12]

theorem envBound52465 : H12AffineFastState.Bounded env52465 := by
  intro p hp
  have h : env52465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52464_52465 : H12AffineEnvironment.transform 3 10 env52464 = env52465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52464 == env52465) = true)

def env52466 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143497,20496,508154,148716,148717,96346,90262,204994,172,74798,1260,135680]

theorem envBound52466 : H12AffineFastState.Bounded env52466 := by
  intro p hp
  have h : env52466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52436_52466 : H12AffineEnvironment.transform 7 173 env52436 = env52466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52436 == env52466) = true)

def env52467 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143497,20496,508074,148668,148669,96266,90262,204946,172,74798,1212,135680]

theorem envBound52467 : H12AffineFastState.Bounded env52467 := by
  intro p hp
  have h : env52467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52466_52467 : H12AffineEnvironment.transform 5 16 env52466 = env52467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52466 == env52467) = true)

theorem identity52467 : scanCanonicalize (H12AffineFastState.compose env52467 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound52467 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52468 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61568,147473,58518,143497,20496,60444,148668,148669,96266,90262,204946,172,74798,1212,135680]

theorem envBound52468 : H12AffineFastState.Bounded env52468 := by
  intro p hp
  have h : env52468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52467_52468 : H12AffineEnvironment.transform 17 208054 env52467 = env52468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env52467 == env52468) = true)

theorem identity52468 : scanCanonicalize (H12AffineFastState.compose env52468 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound52468 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env52469 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4097,61568,147473,58518,143497,20496,60444,148668,148669,43048,45236,192688,172,62476,1212,135680]

theorem envBound52469 : H12AffineFastState.Bounded env52469 := by
  intro p hp
  have h : env52469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52468_52469 : H12AffineEnvironment.transform 15 53282 env52468 = env52469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env52468 == env52469) = true)

theorem identity52469 : scanCanonicalize (H12AffineFastState.compose env52469 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound52469 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52470 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4097,61568,5293,58518,25653,20496,60444,4096,4097,43048,45236,41996,172,62476,1212,18108]

theorem envBound52470 : H12AffineFastState.Bounded env52470 := by
  intro p hp
  have h : env52470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52469_52470 : H12AffineEnvironment.transform 16 21692 env52469 = env52470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env52469 == env52470) = true)

theorem identity52470 : scanCanonicalize (H12AffineFastState.compose env52470 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound52470 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env52471 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,24634,21692,6192,16572,12313,4097,16536,5293,21646,25653,20496,23556,4096,4097,6192,172,5140,172,17428,1212,18108]

theorem envBound52471 : H12AffineFastState.Bounded env52471 := by
  intro p hp
  have h : env52471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52470_52471 : H12AffineEnvironment.transform 14 12312 env52470 = env52471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env52470 == env52471) = true)

theorem identity52471 : scanCanonicalize (H12AffineFastState.compose env52471 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(13+1) ^^^ 12960) := by decide +kernel

theorem selectedBound52471 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env52472 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,12960,12312,4762,9756,6192,12828,12313,4097,12856,5293,9774,5781,8880,11940,4096,4097,6192,172,5140,172,14004,1212,13340]

theorem envBound52472 : H12AffineFastState.Bounded env52472 := by
  intro p hp
  have h : env52472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52471_52472 : H12AffineEnvironment.transform 13 12960 env52471 = env52472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12960 env52471 == env52472) = true)

theorem identity52472 : scanCanonicalize (H12AffineFastState.compose env52472 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound52472 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env52473 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3639,7319,7727,4762,2091,6192,7211,7726,4097,7183,5293,2073,5781,3207,147,4096,4097,6192,172,5140,172,6275,1212,6699]

theorem envBound52473 : H12AffineFastState.Bounded env52473 := by
  intro p hp
  have h : env52473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52472_52473 : H12AffineEnvironment.transform 12 3639 env52472 = env52473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env52472 == env52473) = true)

theorem identity52473 : scanCanonicalize (H12AffineFastState.compose env52473 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound52473 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52474 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,136,3639,3103,3751,530,2091,2232,3235,3750,137,3207,1061,2073,1565,3207,147,136,137,2232,172,1180,172,2059,1212,2723]

theorem envBound52474 : H12AffineFastState.Bounded env52474 := by
  intro p hp
  have h : env52474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52473_52474 : H12AffineEnvironment.transform 11 136 env52473 = env52474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env52473 == env52474) = true)

theorem identity52474 : scanCanonicalize (H12AffineFastState.compose env52474 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52474 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52475 : List Nat := [2,4,8,16,11,16,128,134,512,1024,2048,136,3612,3103,3724,530,2048,2195,3208,3725,137,3207,1038,2073,1565,3207,147,136,137,2195,135,1180,135,2059,1175,2696]

theorem envBound52475 : H12AffineFastState.Bounded env52475 := by
  intro p hp
  have h : env52475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52474_52475 : H12AffineEnvironment.transform 4 11 env52474 = env52475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52474 == env52475) = true)

theorem identity52475 : scanCanonicalize (H12AffineFastState.compose env52475 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52475 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52476 : List Nat := [2,4,8,16,11,16,8,14,512,1024,2048,0,3612,3103,3588,530,2048,2075,3072,3589,1,3087,1038,2073,1565,3087,27,0,1,2075,15,1044,15,2059,1055,2560]

theorem envBound52476 : H12AffineFastState.Bounded env52476 := by
  intro p hp
  have h : env52476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52475_52476 : H12AffineEnvironment.transform 6 8 env52475 = env52476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52475 == env52476) = true)

theorem identity52476 : scanCanonicalize (H12AffineFastState.compose env52476 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound52476 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52477 : List Nat := [2,4,8,16,11,16,8,14,512,30,2048,0,2562,2049,2586,530,2048,2075,2078,2587,1,2065,16,2073,515,2065,27,0,1,2075,15,10,15,2059,1,2560]

theorem envBound52477 : H12AffineFastState.Bounded env52477 := by
  intro p hp
  have h : env52477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52476_52477 : H12AffineEnvironment.transform 9 30 env52476 = env52477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env52476 == env52477) = true)

theorem identity52477 : scanCanonicalize (H12AffineFastState.compose env52477 (packedSelected [1,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52477 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env52478 : List Nat := [2,4,8,10,11,10,8,14,512,4,2048,0,2562,2049,2560,520,2048,2049,2052,2561,1,2059,10,2051,515,2059,1,0,1,2049,15,10,15,2059,1,2560]

theorem envBound52478 : H12AffineFastState.Bounded env52478 := by
  intro p hp
  have h : env52478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52477_52478 : H12AffineEnvironment.transform 3 10 env52477 = env52478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52477 == env52478) = true)

theorem identity52478 : scanCanonicalize (H12AffineFastState.compose env52478 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52478 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52479 : List Nat := [2,4,8,10,11,10,8,14,0,4,2048,0,2050,2049,2048,8,2048,2049,2052,2049,1,2059,10,2051,3,2059,1,0,1,2049,15,10,15,2059,1,2048]

theorem envBound52479 : H12AffineFastState.Bounded env52479 := by
  intro p hp
  have h : env52479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52478_52479 : H12AffineEnvironment.transform 8 0 env52478 = env52479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52478 == env52479) = true)

theorem identity52479 : scanCanonicalize (H12AffineFastState.compose env52479 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52480 : List Nat := [2,4,8,10,11,10,8,14,0,4,0,0,2,1,0,8,0,1,4,1,1,11,10,3,3,11,1,0,1,1,15,10,15,11,1,0]

theorem envBound52480 : H12AffineFastState.Bounded env52480 := by
  intro p hp
  have h : env52480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52479_52480 : H12AffineEnvironment.transform 10 0 env52479 = env52480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52479 == env52480) = true)

theorem identity52480 : scanCanonicalize (H12AffineFastState.compose env52480 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52481 : List Nat := [2,2,8,10,11,10,8,8,0,2,0,0,2,1,0,8,0,1,2,1,1,11,10,3,3,11,1,0,1,1,9,10,9,11,1,0]

theorem envBound52481 : H12AffineFastState.Bounded env52481 := by
  intro p hp
  have h : env52481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52480_52481 : H12AffineEnvironment.transform 1 2 env52480 = env52481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52480 == env52481) = true)

def env52482 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143497,20496,508075,148669,148668,96267,90262,204947,172,74798,1213,135680]

theorem envBound52482 : H12AffineFastState.Bounded env52482 := by
  intro p hp
  have h : env52482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52466_52482 : H12AffineEnvironment.transform 5 17 env52466 = env52482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52466 == env52482) = true)

theorem identity52482 : scanCanonicalize (H12AffineFastState.compose env52482 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound52482 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52483 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61569,115855,58518,111638,20496,279604,114722,114723,96267,90262,41996,172,74798,1213,104095]

theorem envBound52483 : H12AffineFastState.Bounded env52483 := by
  intro p hp
  have h : env52483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52482_52483 : H12AffineEnvironment.transform 16 99487 env52482 = env52483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env52482 == env52483) = true)

theorem identity52483 : scanCanonicalize (H12AffineFastState.compose env52483 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound52483 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env52484 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,65536,94266,262144,91194,29860,4097,1060,77866,4147,82099,20496,279604,78983,78982,96267,90262,20649,172,74798,1213,90682]

theorem envBound52484 : H12AffineFastState.Bounded env52484 := by
  intro p hp
  have h : env52484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52483_52484 : H12AffineEnvironment.transform 14 29861 env52483 = env52484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env52483 == env52484) = true)

theorem identity52484 : scanCanonicalize (H12AffineFastState.compose env52484 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound52484 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52485 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,24634,4096,262144,1024,29860,4097,1060,20496,4147,8329,20496,279604,21693,21692,6193,172,20649,172,17428,1213,512]

theorem envBound52485 : H12AffineFastState.Bounded env52485 := by
  intro p hp
  have h : env52485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52484_52485 : H12AffineEnvironment.transform 15 24634 env52484 = env52485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env52484 == env52485) = true)

theorem identity52485 : scanCanonicalize (H12AffineFastState.compose env52485 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound52485 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52486 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12313,9350,4096,262144,1024,12312,4097,1060,5292,4147,8329,5292,262280,4097,4096,6193,172,5141,172,168,1213,512]

theorem envBound52486 : H12AffineFastState.Bounded env52486 := by
  intro p hp
  have h : env52486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52485_52486 : H12AffineEnvironment.transform 13 1212 env52485 = env52486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env52485 == env52486) = true)

theorem identity52486 : scanCanonicalize (H12AffineFastState.compose env52486 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound52486 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52487 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4648,1212,561,5806,4096,262144,1024,560,4097,1060,5292,4147,4769,5292,262280,4097,4096,6193,172,5141,172,168,1213,512]

theorem envBound52487 : H12AffineFastState.Bounded env52487 := by
  intro p hp
  have h : env52487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52486_52487 : H12AffineEnvironment.transform 12 4648 env52486 = env52487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env52486 == env52487) = true)

theorem identity52487 : scanCanonicalize (H12AffineFastState.compose env52487 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7220) := by decide +kernel

theorem selectedBound52487 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52488 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4648,1212,561,5806,4096,7220,1024,560,4097,1060,5292,4147,4769,5292,7356,4097,4096,6193,172,5141,172,168,1213,512]

theorem envBound52488 : H12AffineFastState.Bounded env52488 := by
  intro p hp
  have h : env52488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52487_52488 : H12AffineEnvironment.transform 17 7220 env52487 = env52488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7220 env52487 == env52488) = true)

theorem identity52488 : scanCanonicalize (H12AffineFastState.compose env52488 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound52488 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52489 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2587,2099,1212,561,3253,2587,1583,1024,560,2586,1060,3767,2600,2234,3767,1703,2586,2587,554,172,3598,172,168,1213,512]

theorem envBound52489 : H12AffineFastState.Bounded env52489 := by
  intro p hp
  have h : env52489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52488_52489 : H12AffineEnvironment.transform 11 2587 env52488 = env52489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env52488 == env52489) = true)

theorem identity52489 : scanCanonicalize (H12AffineFastState.compose env52489 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound52489 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env52490 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,185,657,1212,561,1559,185,1583,1024,560,184,1060,1045,138,536,1045,1703,184,185,554,172,1196,172,168,1213,512]

theorem envBound52490 : H12AffineFastState.Bounded env52490 := by
  intro p hp
  have h : env52490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52489_52490 : H12AffineEnvironment.transform 10 674 env52489 = env52490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env52489 == env52490) = true)

theorem identity52490 : scanCanonicalize (H12AffineFastState.compose env52490 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52490 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52491 : List Nat := [2,4,8,16,32,17,35,14,512,1024,513,26,562,1055,561,1559,26,1583,1024,560,27,1060,1045,41,536,1045,1540,27,26,554,15,1039,15,11,1054,512]

theorem envBound52491 : H12AffineFastState.Bounded env52491 := by
  intro p hp
  have h : env52491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52490_52491 : H12AffineEnvironment.transform 6 35 env52490 = env52491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52490 == env52491) = true)

theorem identity52491 : scanCanonicalize (H12AffineFastState.compose env52491 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound52491 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52492 : List Nat := [2,4,8,16,32,17,35,14,512,30,513,26,562,1,561,521,26,561,30,560,27,58,11,41,536,11,538,27,26,554,15,17,15,11,0,512]

theorem envBound52492 : H12AffineFastState.Bounded env52492 := by
  intro p hp
  have h : env52492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52491_52492 : H12AffineEnvironment.transform 9 30 env52491 = env52492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env52491 == env52492) = true)

theorem identity52492 : scanCanonicalize (H12AffineFastState.compose env52492 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52493 : List Nat := [2,4,8,6,32,7,35,14,512,8,513,12,548,1,551,521,12,551,8,550,13,44,11,41,526,11,524,13,12,554,15,7,15,11,0,512]

theorem envBound52493 : H12AffineFastState.Bounded env52493 := by
  intro p hp
  have h : env52493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52492_52493 : H12AffineEnvironment.transform 3 6 env52492 = env52493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52492 == env52493) = true)

theorem identity52493 : scanCanonicalize (H12AffineFastState.compose env52493 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound52493 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52494 : List Nat := [2,4,8,6,32,7,35,14,12,8,13,12,40,1,43,5,12,43,8,42,13,44,11,41,2,11,0,13,12,38,15,7,15,11,0,12]

theorem envBound52494 : H12AffineFastState.Bounded env52494 := by
  intro p hp
  have h : env52494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52493_52494 : H12AffineEnvironment.transform 8 12 env52493 = env52494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env52493 == env52494) = true)

theorem identity52494 : scanCanonicalize (H12AffineFastState.compose env52494 (packedSelected [1,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound52494 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env52495 : List Nat := [2,4,8,6,6,7,5,14,12,8,13,12,14,1,13,5,12,13,8,12,13,10,11,15,2,11,0,13,12,0,15,7,15,11,0,12]

theorem envBound52495 : H12AffineFastState.Bounded env52495 := by
  intro p hp
  have h : env52495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52494_52495 : H12AffineEnvironment.transform 4 6 env52494 = env52495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env52494 == env52495) = true)

def env52496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58682,143496,20497,508155,148801,148801,96346,90426,205167,257,74798,1345,135681]

theorem envBound52496 : H12AffineFastState.Bounded env52496 := by
  intro p hp
  have h : env52496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52435_52496 : H12AffineEnvironment.transform 18 136193 env52435 = env52496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env52435 == env52496) = true)

def env52497 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143496,20497,508155,148717,148717,96346,90262,204995,173,74798,1261,135681]

theorem envBound52497 : H12AffineFastState.Bounded env52497 := by
  intro p hp
  have h : env52497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52496_52497 : H12AffineEnvironment.transform 7 172 env52496 = env52497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52496 == env52497) = true)

def env52498 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143496,20497,508075,148669,148669,96266,90262,204947,173,74798,1213,135681]

theorem envBound52498 : H12AffineFastState.Bounded env52498 := by
  intro p hp
  have h : env52498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52497_52498 : H12AffineEnvironment.transform 5 16 env52497 = env52498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52497 == env52498) = true)

theorem identity52498 : scanCanonicalize (H12AffineFastState.compose env52498 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound52498 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52499 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,58518,32809,20497,356362,62492,62492,96266,90262,102450,173,74798,1213,41632]

theorem envBound52499 : H12AffineFastState.Bounded env52499 := by
  intro p hp
  have h : env52499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52498_52499 : H12AffineEnvironment.transform 16 45217 env52498 = env52499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env52498 == env52499) = true)

theorem identity52499 : scanCanonicalize (H12AffineFastState.compose env52499 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound52499 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52500 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4097,61568,61616,58518,32809,20497,96387,62492,62492,96266,90262,102450,173,74798,1213,41632]

theorem envBound52500 : H12AffineFastState.Bounded env52500 := by
  intro p hp
  have h : env52500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52499_52500 : H12AffineEnvironment.transform 17 2185 env52499 = env52500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env52499 == env52500) = true)

theorem identity52500 : scanCanonicalize (H12AffineFastState.compose env52500 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound52500 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52501 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,9351,45217,2185,42144,32769,4097,61568,61616,58518,32809,20497,23556,62492,62492,23693,17425,46261,173,169,1213,41632]

theorem envBound52501 : H12AffineFastState.Bounded env52501 := by
  intro p hp
  have h : env52501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52500_52501 : H12AffineEnvironment.transform 15 9351 env52500 = env52501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env52500 == env52501) = true)

theorem identity52501 : scanCanonicalize (H12AffineFastState.compose env52501 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound52501 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env52502 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,9351,40985,2185,42144,32769,185,57400,57352,58518,32809,16553,19644,58532,58532,19509,17425,41997,173,169,1213,41632]

theorem envBound52502 : H12AffineFastState.Bounded env52502 := by
  intro p hp
  have h : env52502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52501_52502 : H12AffineEnvironment.transform 11 184 env52501 = env52502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env52501 == env52502) = true)

theorem identity52502 : scanCanonicalize (H12AffineFastState.compose env52502 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3773) := by decide +kernel

theorem selectedBound52502 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env52503 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,3773,9351,11940,2185,10781,3772,185,28293,28341,27179,3732,16553,19644,27161,27161,19509,17425,10928,173,169,1213,11293]

theorem envBound52503 : H12AffineFastState.Bounded env52503 := by
  intro p hp
  have h : env52503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52502_52503 : H12AffineEnvironment.transform 14 3773 env52502 = env52503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3773 env52502 == env52503) = true)

theorem identity52503 : scanCanonicalize (H12AffineFastState.compose env52503 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 8353) := by decide +kernel

theorem selectedBound52503 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env52504 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,8353,3773,9351,11940,2185,10781,3772,185,3620,3604,2698,3732,8200,11293,2744,2744,11412,9392,10928,173,169,1213,11293]

theorem envBound52504 : H12AffineFastState.Bounded env52504 := by
  intro p hp
  have h : env52504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52503_52504 : H12AffineEnvironment.transform 13 8353 env52503 = env52504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8353 env52503 == env52504) = true)

theorem identity52504 : scanCanonicalize (H12AffineFastState.compose env52504 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound52504 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52505 : List Nat := [2,4,8,16,32,16,128,172,42,1024,2048,184,8192,8353,3223,9351,11406,2185,10295,3222,185,3086,3134,2208,3262,8200,11293,2194,2194,11412,9392,10394,173,169,1213,11293]

theorem envBound52505 : H12AffineFastState.Bounded env52505 := by
  intro p hp
  have h : env52505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52504_52505 : H12AffineEnvironment.transform 8 42 env52504 = env52505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env52504 == env52505) = true)

theorem identity52505 : scanCanonicalize (H12AffineFastState.compose env52505 (packedSelected [7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound52505 : packedSelected [7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52506 : List Nat := [2,4,8,16,32,16,128,172,42,1024,185,184,8192,8353,1070,9351,9271,48,8334,1071,185,1207,1159,25,1031,8200,9380,43,43,9261,9392,8227,173,169,1213,9380]

theorem envBound52506 : H12AffineFastState.Bounded env52506 := by
  intro p hp
  have h : env52506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52505_52506 : H12AffineEnvironment.transform 10 185 env52505 = env52506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env52505 == env52506) = true)

theorem identity52506 : scanCanonicalize (H12AffineFastState.compose env52506 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound52506 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52507 : List Nat := [2,4,8,16,32,16,128,172,42,1024,185,184,1166,1071,1070,9,185,48,1024,1071,185,1207,1159,25,1031,1158,42,43,43,163,62,1197,173,169,1213,42]

theorem envBound52507 : H12AffineFastState.Bounded env52507 := by
  intro p hp
  have h : env52507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52506_52507 : H12AffineEnvironment.transform 12 1166 env52506 = env52507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env52506 == env52507) = true)

theorem identity52507 : scanCanonicalize (H12AffineFastState.compose env52507 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52507 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52508 : List Nat := [2,4,8,16,32,16,18,62,42,1024,43,42,1052,1071,1070,9,43,48,1024,1071,43,1061,1045,25,1031,1044,42,43,43,49,62,1087,63,59,1071,42]

theorem envBound52508 : H12AffineFastState.Bounded env52508 := by
  intro p hp
  have h : env52508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52507_52508 : H12AffineEnvironment.transform 6 18 env52507 = env52508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52507 == env52508) = true)

theorem identity52508 : scanCanonicalize (H12AffineFastState.compose env52508 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52509 : List Nat := [2,4,8,10,32,10,8,36,42,1024,43,42,1030,1071,1070,9,43,42,1024,1071,43,1061,1039,3,1031,1038,42,43,43,43,36,1061,37,33,1071,42]

theorem envBound52509 : H12AffineFastState.Bounded env52509 := by
  intro p hp
  have h : env52509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52508_52509 : H12AffineEnvironment.transform 3 10 env52508 = env52509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52508 == env52509) = true)

theorem identity52509 : scanCanonicalize (H12AffineFastState.compose env52509 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound52509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52510 : List Nat := [2,4,8,10,32,10,8,36,42,41,43,42,47,6,7,9,43,42,41,6,43,12,38,3,46,39,42,43,43,43,36,12,37,33,6,42]

theorem envBound52510 : H12AffineFastState.Bounded env52510 := by
  intro p hp
  have h : env52510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52509_52510 : H12AffineEnvironment.transform 9 41 env52509 = env52510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env52509 == env52510) = true)

theorem identity52510 : scanCanonicalize (H12AffineFastState.compose env52510 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound52510 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52511 : List Nat := [2,4,8,10,12,10,8,8,6,5,7,6,3,6,7,9,7,6,5,6,7,12,10,3,2,11,6,7,7,7,8,12,9,13,6,6]

theorem envBound52511 : H12AffineFastState.Bounded env52511 := by
  intro p hp
  have h : env52511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52510_52511 : H12AffineEnvironment.transform 4 12 env52510 = env52511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env52510 == env52511) = true)

def env52512 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143496,20497,508074,148668,148668,96267,90262,204946,173,74798,1212,135681]

theorem envBound52512 : H12AffineFastState.Bounded env52512 := by
  intro p hp
  have h : env52512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52497_52512 : H12AffineEnvironment.transform 5 17 env52497 = env52512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52497 == env52512) = true)

theorem identity52512 : scanCanonicalize (H12AffineFastState.compose env52512 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound52512 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52513 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,58518,143496,20497,120867,148668,148668,96267,90262,204946,173,74798,1212,135681]

theorem envBound52513 : H12AffineFastState.Bounded env52513 := by
  intro p hp
  have h : env52513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52512_52513 : H12AffineEnvironment.transform 17 137353 env52512 = env52513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env52512 == env52513) = true)

theorem identity52513 : scanCanonicalize (H12AffineFastState.compose env52513 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound52513 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env52514 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4097,61569,46092,58518,50324,20497,120867,45216,45216,96267,90262,119950,173,74798,1212,58909]

theorem envBound52514 : H12AffineFastState.Bounded env52514 := by
  intro p hp
  have h : env52514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52513_52514 : H12AffineEnvironment.transform 16 62492 env52513 = env52514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env52513 == env52514) = true)

theorem identity52514 : scanCanonicalize (H12AffineFastState.compose env52514 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound52514 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52515 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12313,65536,17413,23692,20484,12312,4097,16536,1045,21647,29837,20497,92218,185,185,96267,90262,91287,173,74798,1212,22020]

theorem envBound52515 : H12AffineFastState.Bounded env52515 := by
  intro p hp
  have h : env52515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52514_52515 : H12AffineEnvironment.transform 14 12313 env52514 = env52515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env52514 == env52515) = true)

theorem identity52515 : scanCanonicalize (H12AffineFastState.compose env52515 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 14888) := by decide +kernel

theorem selectedBound52515 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env52516 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14888,12313,65536,15917,9892,10796,12312,4097,15024,1045,11943,3749,10809,70162,185,185,66083,72382,73407,173,74798,1212,11308]

theorem envBound52516 : H12AffineFastState.Bounded env52516 := by
  intro p hp
  have h : env52516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52515_52516 : H12AffineEnvironment.transform 13 14888 env52515 = env52516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14888 env52515 == env52516) = true)

theorem identity52516 : scanCanonicalize (H12AffineFastState.compose env52516 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 6675) := by decide +kernel

theorem selectedBound52516 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env52517 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14888,12313,6675,15917,9892,10796,12312,4097,15024,1045,11943,3749,10809,2049,185,185,6192,173,1196,173,15933,1212,11308]

theorem envBound52517 : H12AffineFastState.Bounded env52517 := by
  intro p hp
  have h : env52517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52516_52517 : H12AffineEnvironment.transform 15 6675 env52516 = env52517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6675 env52516 == env52517) = true)

theorem identity52517 : scanCanonicalize (H12AffineFastState.compose env52517 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3628) := by decide +kernel

theorem selectedBound52517 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52518 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3628,5124,7733,6675,4097,2184,1024,7732,4097,5276,1045,139,3749,1045,2049,185,185,6192,173,1196,173,4113,1212,512]

theorem envBound52518 : H12AffineFastState.Bounded env52518 := by
  intro p hp
  have h : env52518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52517_52518 : H12AffineEnvironment.transform 12 3628 env52517 = env52518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3628 env52517 == env52518) = true)

theorem identity52518 : scanCanonicalize (H12AffineFastState.compose env52518 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound52518 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env52519 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,4096,2721,4233,6840,6675,4097,2184,141,6841,4097,4113,152,139,2600,152,2049,185,185,6192,173,33,173,4113,49,512]

theorem envBound52519 : H12AffineFastState.Bounded env52519 := by
  intro p hp
  have h : env52519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52518_52519 : H12AffineEnvironment.transform 9 141 env52518 = env52519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env52518 == env52519) = true)

theorem identity52519 : scanCanonicalize (H12AffineFastState.compose env52519 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound52519 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52520 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,675,2721,554,2075,2224,674,2184,141,2074,674,690,152,139,2600,152,2049,185,185,2707,173,33,173,690,49,512]

theorem envBound52520 : H12AffineFastState.Bounded env52520 := by
  intro p hp
  have h : env52520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52519_52520 : H12AffineEnvironment.transform 11 675 env52519 = env52520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env52519 == env52520) = true)

theorem identity52520 : scanCanonicalize (H12AffineFastState.compose env52520 (packedSelected [2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound52520 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env52521 : List Nat := [2,4,8,16,32,17,128,172,512,141,163,675,514,554,184,19,674,43,141,185,674,690,152,139,651,152,162,185,185,560,173,33,173,690,49,512]

theorem envBound52521 : H12AffineFastState.Bounded env52521 := by
  intro p hp
  have h : env52521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52520_52521 : H12AffineEnvironment.transform 10 163 env52520 = env52521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env52520 == env52521) = true)

theorem identity52521 : scanCanonicalize (H12AffineFastState.compose env52521 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52521 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env52522 : List Nat := [2,4,8,10,32,11,128,172,512,141,163,675,514,554,162,9,674,43,141,163,674,680,130,139,651,130,162,163,163,554,173,33,173,680,43,512]

theorem envBound52522 : H12AffineFastState.Bounded env52522 := by
  intro p hp
  have h : env52522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52521_52522 : H12AffineEnvironment.transform 3 10 env52521 = env52522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52521 == env52522) = true)

theorem identity52522 : scanCanonicalize (H12AffineFastState.compose env52522 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound52522 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52523 : List Nat := [2,4,8,10,32,11,128,172,136,141,163,43,138,162,162,9,42,43,141,163,42,32,130,139,3,130,162,163,163,162,173,33,173,32,43,136]

theorem envBound52523 : H12AffineFastState.Bounded env52523 := by
  intro p hp
  have h : env52523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52522_52523 : H12AffineEnvironment.transform 8 136 env52522 = env52523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env52522 == env52523) = true)

theorem identity52523 : scanCanonicalize (H12AffineFastState.compose env52523 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52523 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52524 : List Nat := [2,4,8,10,32,11,9,37,1,4,42,43,3,43,43,9,42,43,4,42,42,32,11,2,3,11,43,42,42,43,36,33,36,32,43,1]

theorem envBound52524 : H12AffineFastState.Bounded env52524 := by
  intro p hp
  have h : env52524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52523_52524 : H12AffineEnvironment.transform 6 9 env52523 = env52524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52523 == env52524) = true)

theorem identity52524 : scanCanonicalize (H12AffineFastState.compose env52524 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52525 : List Nat := [2,2,8,10,32,11,9,35,1,2,42,43,3,43,43,9,42,43,2,42,42,32,11,2,3,11,43,42,42,43,34,33,34,32,43,1]

theorem envBound52525 : H12AffineFastState.Bounded env52525 := by
  intro p hp
  have h : env52525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52524_52525 : H12AffineEnvironment.transform 1 2 env52524 = env52525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52524 == env52525) = true)

def env52526 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143496,20497,508155,148716,148716,96346,90263,204994,172,74798,1260,135681]

theorem envBound52526 : H12AffineFastState.Bounded env52526 := by
  intro p hp
  have h : env52526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52496_52526 : H12AffineEnvironment.transform 7 173 env52496 = env52526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52496 == env52526) = true)

def env52527 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143496,20497,508075,148668,148668,96266,90263,204946,172,74798,1212,135681]

theorem envBound52527 : H12AffineFastState.Bounded env52527 := by
  intro p hp
  have h : env52527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52526_52527 : H12AffineEnvironment.transform 5 16 env52526 = env52527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52526 == env52527) = true)

theorem identity52527 : scanCanonicalize (H12AffineFastState.compose env52527 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound52527 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52528 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61568,115855,58519,111638,20497,279605,114722,114722,96266,90263,41996,172,74798,1212,104095]

theorem envBound52528 : H12AffineFastState.Bounded env52528 := by
  intro p hp
  have h : env52528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52527_52528 : H12AffineEnvironment.transform 16 99486 env52527 = env52528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env52527 == env52528) = true)

theorem identity52528 : scanCanonicalize (H12AffineFastState.compose env52528 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound52528 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env52529 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,65536,94267,262144,91194,29860,4097,1061,77866,4146,82099,20497,279605,78983,78983,96266,90263,20649,172,74798,1212,90682]

theorem envBound52529 : H12AffineFastState.Bounded env52529 := by
  intro p hp
  have h : env52529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52528_52529 : H12AffineEnvironment.transform 14 29861 env52528 = env52529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env52528 == env52529) = true)

theorem identity52529 : scanCanonicalize (H12AffineFastState.compose env52529 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound52529 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52530 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,24634,4097,262144,1024,29860,4097,1061,20496,4146,8329,20497,279605,21693,21693,6192,173,20649,172,17428,1212,512]

theorem envBound52530 : H12AffineFastState.Bounded env52530 := by
  intro p hp
  have h : env52530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52529_52530 : H12AffineEnvironment.transform 15 24634 env52529 = env52530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env52529 == env52530) = true)

theorem identity52530 : scanCanonicalize (H12AffineFastState.compose env52530 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound52530 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52531 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,9351,4097,262144,1024,12313,4097,1061,5293,4146,8329,5292,262280,4096,4096,6192,173,5140,172,169,1212,512]

theorem envBound52531 : H12AffineFastState.Bounded env52531 := by
  intro p hp
  have h : env52531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52530_52531 : H12AffineEnvironment.transform 13 1213 env52530 = env52531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env52530 == env52531) = true)

theorem identity52531 : scanCanonicalize (H12AffineFastState.compose env52531 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound52531 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52532 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,657,1213,4745,1558,4097,262144,1024,4744,4097,1061,5293,4146,536,5292,262280,4096,4096,6192,173,5140,172,169,1212,512]

theorem envBound52532 : H12AffineFastState.Bounded env52532 := by
  intro p hp
  have h : env52532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52531_52532 : H12AffineEnvironment.transform 12 657 env52531 = env52532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env52531 == env52532) = true)

theorem identity52532 : scanCanonicalize (H12AffineFastState.compose env52532 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound52532 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52533 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,657,1213,4745,1558,4097,3212,1024,4744,4097,1061,5293,4146,536,5292,3076,4096,4096,6192,173,5140,172,169,1212,512]

theorem envBound52533 : H12AffineFastState.Bounded env52533 := by
  intro p hp
  have h : env52533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52532_52533 : H12AffineEnvironment.transform 17 3212 env52532 = env52533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env52532 == env52533) = true)

theorem identity52533 : scanCanonicalize (H12AffineFastState.compose env52533 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound52533 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52534 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,4096,657,1213,4745,1558,4097,1582,1024,4744,4097,1061,5293,4146,536,5292,1702,4096,4096,4754,173,5140,172,169,1212,512]

theorem envBound52534 : H12AffineFastState.Bounded env52534 := by
  intro p hp
  have h : env52534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52533_52534 : H12AffineEnvironment.transform 10 674 env52533 = env52534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env52533 == env52534) = true)

def env52535 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143496,20497,508074,148669,148669,96267,90263,204947,172,74798,1213,135681]

theorem envBound52535 : H12AffineFastState.Bounded env52535 := by
  intro p hp
  have h : env52535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52526_52535 : H12AffineEnvironment.transform 5 17 env52526 = env52535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52526 == env52535) = true)

theorem identity52535 : scanCanonicalize (H12AffineFastState.compose env52535 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound52535 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env52536 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61569,147472,58519,143496,20497,60445,148669,148669,96267,90263,204947,172,74798,1213,135681]

theorem envBound52536 : H12AffineFastState.Bounded env52536 := by
  intro p hp
  have h : env52536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52535_52536 : H12AffineEnvironment.transform 17 208055 env52535 = env52536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env52535 == env52536) = true)

theorem identity52536 : scanCanonicalize (H12AffineFastState.compose env52536 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound52536 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env52537 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4097,61569,147472,58519,143496,20497,60445,148669,148669,43048,45236,192688,172,62477,1213,135681]

theorem envBound52537 : H12AffineFastState.Bounded env52537 := by
  intro p hp
  have h : env52537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52536_52537 : H12AffineEnvironment.transform 15 53283 env52536 = env52537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env52536 == env52537) = true)

theorem identity52537 : scanCanonicalize (H12AffineFastState.compose env52537 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound52537 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52538 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4097,61569,5292,58519,25652,20497,60445,4097,4097,43048,45236,41996,172,62477,1213,18109]

theorem envBound52538 : H12AffineFastState.Bounded env52538 := by
  intro p hp
  have h : env52538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52537_52538 : H12AffineEnvironment.transform 16 21692 env52537 = env52538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env52537 == env52538) = true)

theorem identity52538 : scanCanonicalize (H12AffineFastState.compose env52538 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound52538 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env52539 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,24634,21692,6193,16573,12312,4097,16536,5292,21646,25652,20497,23556,4097,4097,6193,173,5141,172,17428,1213,18109]

theorem envBound52539 : H12AffineFastState.Bounded env52539 := by
  intro p hp
  have h : env52539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52538_52539 : H12AffineEnvironment.transform 14 12313 env52538 = env52539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env52538 == env52539) = true)

theorem identity52539 : scanCanonicalize (H12AffineFastState.compose env52539 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 1700) := by decide +kernel

theorem selectedBound52539 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env52540 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1700,16384,5821,18078,21692,6193,16573,5820,4097,16536,5292,21646,17040,20497,23556,4097,4097,6193,173,5141,172,17428,1213,18109]

theorem envBound52540 : H12AffineFastState.Bounded env52540 := by
  intro p hp
  have h : env52540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52539_52540 : H12AffineEnvironment.transform 12 1700 env52539 = env52540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1700 env52539 == env52540) = true)

theorem identity52540 : scanCanonicalize (H12AffineFastState.compose env52540 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 3119) := by decide +kernel

theorem selectedBound52540 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env52541 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1700,3119,5821,2737,6291,6193,3218,5820,4097,3255,5292,6305,3775,7230,4139,4097,4097,6193,173,5141,172,2107,1213,2706]

theorem envBound52541 : H12AffineFastState.Bounded env52541 := by
  intro p hp
  have h : env52541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52540_52541 : H12AffineEnvironment.transform 13 3119 env52540 = env52541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3119 env52540 == env52541) = true)

theorem identity52541 : scanCanonicalize (H12AffineFastState.compose env52541 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52541 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env52542 : List Nat := [2,4,8,16,17,17,128,156,512,1024,2048,4096,1685,3102,5772,2688,6291,6144,3218,5773,4097,3206,5277,6288,3726,7183,4122,4097,4097,6144,156,5141,157,2058,1164,2706]

theorem envBound52542 : H12AffineFastState.Bounded env52542 := by
  intro p hp
  have h : env52542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52541_52542 : H12AffineEnvironment.transform 4 17 env52541 = env52542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52541 == env52542) = true)

theorem identity52542 : scanCanonicalize (H12AffineFastState.compose env52542 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52542 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52543 : List Nat := [2,4,8,10,11,11,128,134,512,1024,2048,4096,1679,3076,5772,2688,6281,6144,3208,5773,4097,3206,5255,6282,3726,7183,4096,4097,4097,6144,134,5135,135,2058,1164,2696]

theorem envBound52543 : H12AffineFastState.Bounded env52543 := by
  intro p hp
  have h : env52543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52542_52543 : H12AffineEnvironment.transform 3 10 env52542 = env52543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52542 == env52543) = true)

theorem identity52543 : scanCanonicalize (H12AffineFastState.compose env52543 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52543 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52544 : List Nat := [2,4,8,10,11,11,8,14,512,1024,2048,4096,1543,3076,5636,2568,6145,6144,3072,5637,4097,3086,5135,6146,3590,7183,4096,4097,4097,6144,14,5135,15,2058,1028,2560]

theorem envBound52544 : H12AffineFastState.Bounded env52544 := by
  intro p hp
  have h : env52544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52543_52544 : H12AffineEnvironment.transform 6 8 env52543 = env52544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52543 == env52544) = true)

theorem identity52544 : scanCanonicalize (H12AffineFastState.compose env52544 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound52544 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52545 : List Nat := [2,4,8,10,11,11,8,14,512,1024,1541,4096,1543,513,5636,1037,5636,5637,517,5637,4097,523,5135,5639,3,4618,4096,4097,4097,5637,14,5135,15,1551,1028,1029]

theorem envBound52545 : H12AffineFastState.Bounded env52545 := by
  intro p hp
  have h : env52545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52544_52545 : H12AffineEnvironment.transform 10 1541 env52544 = env52545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env52544 == env52545) = true)

theorem identity52545 : scanCanonicalize (H12AffineFastState.compose env52545 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52546 : List Nat := [2,4,8,10,11,11,8,14,512,5,512,4096,514,513,4609,8,4609,4608,517,4608,4097,523,4106,4610,3,4618,4096,4097,4097,4608,14,4106,15,522,1,0]

theorem envBound52546 : H12AffineFastState.Bounded env52546 := by
  intro p hp
  have h : env52546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52545_52546 : H12AffineEnvironment.transform 9 5 env52545 = env52546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52545 == env52546) = true)

theorem identity52546 : scanCanonicalize (H12AffineFastState.compose env52546 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound52546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52547 : List Nat := [2,4,8,10,11,11,8,14,512,5,512,513,514,513,0,8,0,1,517,1,512,523,523,3,3,11,513,512,512,1,14,523,15,522,1,0]

theorem envBound52547 : H12AffineFastState.Bounded env52547 := by
  intro p hp
  have h : env52547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52546_52547 : H12AffineEnvironment.transform 11 513 env52546 = env52547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env52546 == env52547) = true)

theorem identity52547 : scanCanonicalize (H12AffineFastState.compose env52547 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound52547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52548 : List Nat := [2,4,8,10,11,11,8,14,7,5,7,6,5,6,0,8,0,1,2,1,7,12,12,3,3,11,6,7,7,1,14,12,15,13,1,0]

theorem envBound52548 : H12AffineFastState.Bounded env52548 := by
  intro p hp
  have h : env52548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52547_52548 : H12AffineEnvironment.transform 8 7 env52547 = env52548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env52547 == env52548) = true)

theorem identity52548 : scanCanonicalize (H12AffineFastState.compose env52548 (packedSelected [4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52548 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52549 : List Nat := [2,3,8,10,11,11,8,9,0,2,0,1,2,1,0,8,0,1,2,1,0,11,11,3,3,11,1,0,0,1,9,11,8,10,1,0]

theorem envBound52549 : H12AffineFastState.Bounded env52549 := by
  intro p hp
  have h : env52549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52548_52549 : H12AffineEnvironment.transform 1 3 env52548 = env52549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52548 == env52549) = true)

def env52550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672784,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound52550 : H12AffineFastState.Bounded env52550 := by
  intro p hp
  have h : env52550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50119_52550 : H12AffineEnvironment.transform 34 151462017 env50119 = env52550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env50119 == env52550) = true)

def env52551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148801,33584585,96347,50962569,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound52551 : H12AffineFastState.Bounded env52551 := by
  intro p hp
  have h : env52551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52550_52551 : H12AffineEnvironment.transform 20 4096 env52550 = env52551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env52550 == env52551) = true)

theorem identity52551 : scanCanonicalize (H12AffineFastState.compose env52551 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 34276839) := by decide +kernel

theorem selectedBound52551 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env52552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148801,33584585,96347,50962569,34276839,34088328,17552661,151462017,33563273]

theorem envBound52552 : H12AffineFastState.Bounded env52552 := by
  intro p hp
  have h : env52552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52551_52552 : H12AffineEnvironment.transform 31 34276839 env52551 = env52552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 34276839 env52551 == env52552) = true)

def env52553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,134217728,148801,545089,96347,16876545,205167,256,17552661,151462017,525825]

theorem envBound52553 : H12AffineFastState.Bounded env52553 := by
  intro p hp
  have h : env52553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52552_52553 : H12AffineEnvironment.transform 24 533640 env52552 = env52553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env52552 == env52553) = true)

def env52554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245632,148801,545089,96347,16876545,205167,256,17552661,1345,525825]

theorem envBound52554 : H12AffineFastState.Bounded env52554 := by
  intro p hp
  have h : env52554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52553_52554 : H12AffineEnvironment.transform 26 17245632 env52553 = env52554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env52553 == env52554) = true)

theorem identity52554 : scanCanonicalize (H12AffineFastState.compose env52554 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound52554 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86519,209263,17245632,148801,74814,96347,16876545,205167,256,16949354,1345,95102]

theorem envBound52555 : H12AffineFastState.Bounded env52555 := by
  intro p hp
  have h : env52555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52554_52555 : H12AffineEnvironment.transform 18 95615 env52554 = env52555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env52554 == env52555) = true)

def env52556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86519,209263,225344,148801,74814,96347,381313,205167,256,456170,1345,95102]

theorem envBound52556 : H12AffineFastState.Bounded env52556 := by
  intro p hp
  have h : env52556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52555_52556 : H12AffineEnvironment.transform 23 284032 env52555 = env52556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env52555 == env52556) = true)

def env52557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86519,94527,77840,1297,74814,96347,381313,90431,256,308666,1345,95102]

theorem envBound52557 : H12AffineFastState.Bounded env52557 := by
  intro p hp
  have h : env52557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52556_52557 : H12AffineEnvironment.transform 16 16464 env52556 = env52557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env52556 == env52557) = true)

def env52558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70887,78895,77840,1297,74814,81227,365713,74799,256,308666,1345,79470]

theorem envBound52558 : H12AffineFastState.Bounded env52558 := by
  intro p hp
  have h : env52558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52557_52558 : H12AffineEnvironment.transform 13 1296 env52557 = env52558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52557 == env52558) = true)

theorem identity52558 : scanCanonicalize (H12AffineFastState.compose env52558 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52558 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,17,266384,70887,78895,77840,1297,74814,81227,336012,74799,256,262567,1345,79470]

theorem envBound52559 : H12AffineFastState.Bounded env52559 := by
  intro p hp
  have h : env52559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52558_52559 : H12AffineEnvironment.transform 14 13341 env52558 = env52559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52558 == env52559) = true)

def env52560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,17,69648,70887,78895,77840,1297,74814,81227,8204,74799,256,65831,1345,79470]

theorem envBound52560 : H12AffineFastState.Bounded env52560 := by
  intro p hp
  have h : env52560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52559_52560 : H12AffineEnvironment.transform 17 65664 env52559 = env52560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52559 == env52560) = true)

theorem identity52560 : scanCanonicalize (H12AffineFastState.compose env52560 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound52560 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12590,1344,12718,321,13340,4096,476,17,8510,9673,1281,318,1297,5392,3173,8204,5377,256,12297,1345,1856]

theorem envBound52561 : H12AffineFastState.Bounded env52561 := by
  intro p hp
  have h : env52561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52560_52561 : H12AffineEnvironment.transform 15 12590 env52560 = env52561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env52560 == env52561) = true)

def env52562 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12590,0,12718,321,12636,4096,476,17,8510,8329,65,318,81,4176,2341,8204,4161,256,12297,1,512]

theorem envBound52562 : H12AffineFastState.Bounded env52562 := by
  intro p hp
  have h : env52562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52561_52562 : H12AffineEnvironment.transform 9 320 env52561 = env52562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52561 == env52562) = true)

theorem identity52562 : scanCanonicalize (H12AffineFastState.compose env52562 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52562 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52563 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,80,4096,4211,0,4339,321,4097,4096,476,17,99,468,65,318,81,4176,2341,337,4161,256,4436,1,512]

theorem envBound52563 : H12AffineFastState.Bounded env52563 := by
  intro p hp
  have h : env52563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52562_52563 : H12AffineEnvironment.transform 12 349 env52562 = env52563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52562 == env52563) = true)

theorem identity52563 : scanCanonicalize (H12AffineFastState.compose env52563 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound52563 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52564 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,349,80,80,35,0,163,321,81,80,476,17,99,468,65,318,81,0,2341,337,17,256,260,1,512]

theorem envBound52564 : H12AffineFastState.Bounded env52564 := by
  intro p hp
  have h : env52564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52563_52564 : H12AffineEnvironment.transform 11 80 env52563 = env52564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env52563 == env52564) = true)

theorem identity52564 : scanCanonicalize (H12AffineFastState.compose env52564 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound52564 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env52565 : List Nat := [2,4,8,16,32,64,105,256,512,320,2048,80,349,80,80,35,0,74,321,81,80,309,17,99,317,65,318,81,0,2341,337,17,256,260,1,512]

theorem envBound52565 : H12AffineFastState.Bounded env52565 := by
  intro p hp
  have h : env52565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52564_52565 : H12AffineEnvironment.transform 6 105 env52564 = env52565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env52564 == env52565) = true)

theorem identity52565 : scanCanonicalize (H12AffineFastState.compose env52565 (packedSelected [1,4,8,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound52565 : packedSelected [1,4,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52566 : List Nat := [2,4,8,16,32,64,105,256,512,320,43,80,349,80,80,35,0,74,321,81,80,309,17,99,317,65,318,81,0,270,337,17,256,260,1,512]

theorem envBound52566 : H12AffineFastState.Bounded env52566 := by
  intro p hp
  have h : env52566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52565_52566 : H12AffineEnvironment.transform 10 43 env52565 = env52566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env52565 == env52566) = true)

theorem identity52566 : scanCanonicalize (H12AffineFastState.compose env52566 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound52566 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52567 : List Nat := [2,4,8,16,32,64,105,256,373,320,43,80,349,80,80,35,0,74,321,81,80,309,17,99,317,65,318,81,0,270,337,17,256,260,1,373]

theorem envBound52567 : H12AffineFastState.Bounded env52567 := by
  intro p hp
  have h : env52567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52566_52567 : H12AffineEnvironment.transform 8 373 env52566 = env52567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env52566 == env52567) = true)

theorem identity52567 : scanCanonicalize (H12AffineFastState.compose env52567 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52567 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52568 : List Nat := [2,4,8,16,32,17,56,256,292,273,43,1,268,1,1,35,0,27,272,0,1,309,17,50,317,16,318,0,0,270,256,17,256,260,1,292]

theorem envBound52568 : H12AffineFastState.Bounded env52568 := by
  intro p hp
  have h : env52568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52567_52568 : H12AffineEnvironment.transform 5 17 env52567 = env52568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52567 == env52568) = true)

theorem identity52568 : scanCanonicalize (H12AffineFastState.compose env52568 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52568 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52569 : List Nat := [2,4,8,10,32,11,34,256,292,267,43,1,268,1,1,35,0,1,266,0,1,303,11,40,295,10,292,0,0,270,256,11,256,260,1,292]

theorem envBound52569 : H12AffineFastState.Bounded env52569 := by
  intro p hp
  have h : env52569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52568_52569 : H12AffineEnvironment.transform 3 10 env52568 = env52569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52568 == env52569) = true)

def env52570 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12590,1,12718,321,12637,4096,476,17,8510,8328,64,318,80,4177,2340,8204,4160,256,12297,0,513]

theorem envBound52570 : H12AffineFastState.Bounded env52570 := by
  intro p hp
  have h : env52570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52561_52570 : H12AffineEnvironment.transform 9 321 env52561 = env52570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52561 == env52570) = true)

theorem identity52570 : scanCanonicalize (H12AffineFastState.compose env52570 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52570 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52571 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,81,4176,4130,1,4258,321,4177,4096,476,17,50,388,64,318,80,4177,2340,256,4160,256,4357,0,513]

theorem envBound52571 : H12AffineFastState.Bounded env52571 := by
  intro p hp
  have h : env52571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52570_52571 : H12AffineEnvironment.transform 12 268 env52570 = env52571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52570 == env52571) = true)

theorem identity52571 : scanCanonicalize (H12AffineFastState.compose env52571 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52571 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52572 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,4096,24,81,4176,4130,1,4258,85,4177,4096,200,17,50,144,64,42,80,4177,2096,20,4160,20,4113,0,513]

theorem envBound52572 : H12AffineFastState.Bounded env52572 := by
  intro p hp
  have h : env52572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52571_52572 : H12AffineEnvironment.transform 7 20 env52571 = env52572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52571 == env52572) = true)

theorem identity52572 : scanCanonicalize (H12AffineFastState.compose env52572 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound52572 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52573 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,65,24,81,17,99,1,227,85,16,65,200,17,50,144,64,42,80,16,2096,20,1,20,80,0,513]

theorem envBound52573 : H12AffineFastState.Bounded env52573 := by
  intro p hp
  have h : env52573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52572_52573 : H12AffineEnvironment.transform 11 65 env52572 = env52573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env52572 == env52573) = true)

theorem identity52573 : scanCanonicalize (H12AffineFastState.compose env52573 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound52573 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env52574 : List Nat := [2,4,8,16,32,64,128,20,201,85,2048,65,24,81,17,99,1,227,85,16,65,200,17,50,144,64,42,80,16,2096,20,1,20,80,0,200]

theorem envBound52574 : H12AffineFastState.Bounded env52574 := by
  intro p hp
  have h : env52574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52573_52574 : H12AffineEnvironment.transform 8 201 env52573 = env52574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env52573 == env52574) = true)

theorem identity52574 : scanCanonicalize (H12AffineFastState.compose env52574 (packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound52574 : packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52575 : List Nat := [2,4,8,16,13,64,128,20,201,85,2048,65,24,81,17,78,1,206,85,16,65,200,17,31,144,64,7,80,16,2077,20,1,20,80,0,200]

theorem envBound52575 : H12AffineFastState.Bounded env52575 := by
  intro p hp
  have h : env52575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52574_52575 : H12AffineEnvironment.transform 4 13 env52574 = env52575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env52574 == env52575) = true)

theorem identity52575 : scanCanonicalize (H12AffineFastState.compose env52575 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52575 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52576 : List Nat := [2,4,8,16,13,0,128,20,137,21,2048,1,24,17,17,14,1,142,21,16,1,136,17,31,144,0,7,16,16,2077,20,1,20,16,0,136]

theorem envBound52576 : H12AffineFastState.Bounded env52576 := by
  intro p hp
  have h : env52576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52575_52576 : H12AffineEnvironment.transform 5 0 env52575 = env52576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52575 == env52576) = true)

theorem identity52576 : scanCanonicalize (H12AffineFastState.compose env52576 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52576 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env52577 : List Nat := [2,4,8,16,13,0,18,20,27,21,2048,1,24,17,17,14,1,28,21,16,1,26,17,31,2,0,7,16,16,2077,20,1,20,16,0,26]

theorem envBound52577 : H12AffineFastState.Bounded env52577 := by
  intro p hp
  have h : env52577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52576_52577 : H12AffineEnvironment.transform 6 18 env52576 = env52577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52576 == env52577) = true)

theorem identity52577 : scanCanonicalize (H12AffineFastState.compose env52577 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound52577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52578 : List Nat := [2,4,8,16,13,0,18,20,27,21,16,1,24,17,17,14,1,28,21,16,1,26,17,31,2,0,7,16,16,13,20,1,20,16,0,26]

theorem envBound52578 : H12AffineFastState.Bounded env52578 := by
  intro p hp
  have h : env52578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52577_52578 : H12AffineEnvironment.transform 10 16 env52577 = env52578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env52577 == env52578) = true)

theorem identity52578 : scanCanonicalize (H12AffineFastState.compose env52578 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52578 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52579 : List Nat := [2,4,2,16,7,0,18,20,17,21,16,1,18,17,17,4,1,22,21,16,1,16,17,21,2,0,7,16,16,7,20,1,20,16,0,16]

theorem envBound52579 : H12AffineFastState.Bounded env52579 := by
  intro p hp
  have h : env52579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52578_52579 : H12AffineEnvironment.transform 2 2 env52578 = env52579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52578 == env52579) = true)

theorem identity52579 : scanCanonicalize (H12AffineFastState.compose env52579 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52579 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52580 : List Nat := [0,4,0,16,5,0,16,20,17,21,16,1,16,17,17,4,1,20,21,16,1,16,17,21,0,0,5,16,16,5,20,1,20,16,0,16]

theorem envBound52580 : H12AffineFastState.Bounded env52580 := by
  intro p hp
  have h : env52580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52579_52580 : H12AffineEnvironment.transform 0 0 env52579 = env52580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52579 == env52580) = true)

theorem identity52580 : scanCanonicalize (H12AffineFastState.compose env52580 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound52580 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52581 : List Nat := [0,4,0,4,5,0,4,0,5,1,4,1,4,5,5,4,1,0,1,4,1,4,5,1,0,0,5,4,4,5,0,1,0,4,0,4]

theorem envBound52581 : H12AffineFastState.Bounded env52581 := by
  intro p hp
  have h : env52581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52580_52581 : H12AffineEnvironment.transform 3 4 env52580 = env52581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env52580 == env52581) = true)

def env52582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,17,69649,70887,78895,77840,1297,74814,81227,8205,74799,256,65830,1345,79470]

theorem envBound52582 : H12AffineFastState.Bounded env52582 := by
  intro p hp
  have h : env52582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52559_52582 : H12AffineEnvironment.transform 17 65665 env52559 = env52582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52559 == env52582) = true)

theorem identity52582 : scanCanonicalize (H12AffineFastState.compose env52582 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound52582 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9326,1344,9455,5121,13340,4096,476,17,13439,12425,4161,5246,1297,80,6437,8205,65,256,9544,1345,4608]

theorem envBound52583 : H12AffineFastState.Bounded env52583 := by
  intro p hp
  have h : env52583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52582_52583 : H12AffineEnvironment.transform 15 9326 env52582 = env52583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env52582 == env52583) = true)

def env52584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9326,1344,9455,1025,9244,0,476,17,9343,8329,65,1150,1297,80,2341,8205,65,256,9544,1345,512]

theorem envBound52584 : H12AffineFastState.Bounded env52584 := by
  intro p hp
  have h : env52584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52583_52584 : H12AffineEnvironment.transform 11 0 env52583 = env52584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52583 == env52584) = true)

theorem identity52584 : scanCanonicalize (H12AffineFastState.compose env52584 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52584 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,348,1296,1345,1330,1344,1459,1025,1344,0,476,17,1315,469,65,1150,1297,80,2341,337,65,256,1044,1345,512]

theorem envBound52585 : H12AffineFastState.Bounded env52585 := by
  intro p hp
  have h : env52585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52584_52585 : H12AffineEnvironment.transform 12 348 env52584 = env52585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52584 == env52585) = true)

theorem identity52585 : scanCanonicalize (H12AffineFastState.compose env52585 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52585 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52586 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,0,348,0,81,34,80,163,273,80,0,476,17,51,469,65,366,1,80,2341,337,65,256,260,81,512]

theorem envBound52586 : H12AffineFastState.Bounded env52586 := by
  intro p hp
  have h : env52586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52585_52586 : H12AffineEnvironment.transform 9 272 env52585 = env52586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52585 == env52586) = true)

theorem identity52586 : scanCanonicalize (H12AffineFastState.compose env52586 (packedSelected [0,1,7,8,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound52586 : packedSelected [0,1,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52587 : List Nat := [2,4,8,16,32,64,128,256,292,272,2048,0,348,0,81,34,80,163,273,80,0,476,17,51,469,65,366,1,80,2341,337,65,256,260,81,292]

theorem envBound52587 : H12AffineFastState.Bounded env52587 := by
  intro p hp
  have h : env52587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52586_52587 : H12AffineEnvironment.transform 8 292 env52586 = env52587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env52586 == env52587) = true)

theorem identity52587 : scanCanonicalize (H12AffineFastState.compose env52587 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound52587 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env52588 : List Nat := [2,4,8,16,32,64,128,256,292,272,147,0,348,0,81,34,80,163,273,80,0,476,17,51,469,65,366,1,80,438,337,65,256,260,81,292]

theorem envBound52588 : H12AffineFastState.Bounded env52588 := by
  intro p hp
  have h : env52588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52587_52588 : H12AffineEnvironment.transform 10 147 env52587 = env52588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env52587 == env52588) = true)

theorem identity52588 : scanCanonicalize (H12AffineFastState.compose env52588 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52588 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52589 : List Nat := [2,4,8,16,32,64,128,173,137,189,147,0,241,0,81,34,80,163,188,80,0,113,17,51,120,65,195,1,80,27,252,65,173,169,81,137]

theorem envBound52589 : H12AffineFastState.Bounded env52589 := by
  intro p hp
  have h : env52589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52588_52589 : H12AffineEnvironment.transform 7 173 env52588 = env52589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52588 == env52589) = true)

theorem identity52589 : scanCanonicalize (H12AffineFastState.compose env52589 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52589 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52590 : List Nat := [2,4,8,16,32,64,18,63,27,47,1,0,99,0,81,34,80,49,46,80,0,113,17,51,120,65,81,1,80,27,110,65,63,59,81,27]

theorem envBound52590 : H12AffineFastState.Bounded env52590 := by
  intro p hp
  have h : env52590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52589_52590 : H12AffineEnvironment.transform 6 18 env52589 = env52590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52589 == env52590) = true)

theorem identity52590 : scanCanonicalize (H12AffineFastState.compose env52590 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52590 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52591 : List Nat := [2,4,8,16,16,64,18,15,27,31,1,0,83,0,81,18,80,1,30,80,0,65,17,3,72,65,81,1,80,27,94,65,15,11,81,27]

theorem envBound52591 : H12AffineFastState.Bounded env52591 := by
  intro p hp
  have h : env52591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52590_52591 : H12AffineEnvironment.transform 4 16 env52590 = env52591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52590 == env52591) = true)

theorem identity52591 : scanCanonicalize (H12AffineFastState.compose env52591 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52591 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52592 : List Nat := [2,4,8,16,16,16,18,15,27,31,1,0,3,0,1,18,0,1,30,0,0,17,17,3,24,17,1,1,0,27,14,17,15,11,1,27]

theorem envBound52592 : H12AffineFastState.Bounded env52592 := by
  intro p hp
  have h : env52592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52591_52592 : H12AffineEnvironment.transform 5 16 env52591 = env52592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52591 == env52592) = true)

def env52593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9326,1344,9455,1024,9245,1,476,17,9342,8328,64,1151,1297,80,2340,8205,65,256,9544,1345,513]

theorem envBound52593 : H12AffineFastState.Bounded env52593 := by
  intro p hp
  have h : env52593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52583_52593 : H12AffineEnvironment.transform 11 1 env52583 = env52593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52583 == env52593) = true)

theorem identity52593 : scanCanonicalize (H12AffineFastState.compose env52593 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52593 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1296,1297,1379,1344,1506,1024,1296,1,476,17,1395,389,64,1151,1297,80,2340,256,65,256,1093,1345,513]

theorem envBound52594 : H12AffineFastState.Bounded env52594 := by
  intro p hp
  have h : env52594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52593_52594 : H12AffineEnvironment.transform 12 269 env52593 = env52594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52593 == env52594) = true)

theorem identity52594 : scanCanonicalize (H12AffineFastState.compose env52594 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound52594 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52595 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,1,269,325,324,310,277,439,85,325,1,476,17,294,389,64,42,324,80,2340,256,65,256,16,276,513]

theorem envBound52595 : H12AffineFastState.Bounded env52595 := by
  intro p hp
  have h : env52595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52594_52595 : H12AffineEnvironment.transform 9 85 env52594 = env52595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env52594 == env52595) = true)

theorem identity52595 : scanCanonicalize (H12AffineFastState.compose env52595 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound52595 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52596 : List Nat := [2,4,8,16,32,64,128,85,512,85,2048,1,88,16,17,99,64,226,85,16,1,137,17,115,208,64,42,17,80,2161,85,65,85,16,65,513]

theorem envBound52596 : H12AffineFastState.Bounded env52596 := by
  intro p hp
  have h : env52596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52595_52596 : H12AffineEnvironment.transform 7 85 env52595 = env52596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env52595 == env52596) = true)

theorem identity52596 : scanCanonicalize (H12AffineFastState.compose env52596 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52596 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env52597 : List Nat := [2,4,8,16,32,64,128,85,137,85,2048,1,88,16,17,99,64,226,85,16,1,137,17,115,208,64,42,17,80,2161,85,65,85,16,65,136]

theorem envBound52597 : H12AffineFastState.Bounded env52597 := by
  intro p hp
  have h : env52597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52596_52597 : H12AffineEnvironment.transform 8 137 env52596 = env52597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52596 == env52597) = true)

theorem identity52597 : scanCanonicalize (H12AffineFastState.compose env52597 (packedSelected [5,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound52597 : packedSelected [5,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52598 : List Nat := [2,4,8,16,32,64,128,85,137,85,7,1,88,16,17,99,64,226,85,16,1,137,17,115,208,64,42,17,80,118,85,65,85,16,65,136]

theorem envBound52598 : H12AffineFastState.Bounded env52598 := by
  intro p hp
  have h : env52598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52597_52598 : H12AffineEnvironment.transform 10 7 env52597 = env52598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env52597 == env52598) = true)

theorem identity52598 : scanCanonicalize (H12AffineFastState.compose env52598 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52598 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52599 : List Nat := [2,4,8,16,32,0,128,21,137,21,7,1,24,16,17,35,0,162,21,16,1,137,17,51,144,0,42,17,16,54,21,1,21,16,1,136]

theorem envBound52599 : H12AffineFastState.Bounded env52599 := by
  intro p hp
  have h : env52599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52598_52599 : H12AffineEnvironment.transform 5 0 env52598 = env52599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52598 == env52599) = true)

theorem identity52599 : scanCanonicalize (H12AffineFastState.compose env52599 (packedSelected [2,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52599 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env52600 : List Nat := [2,4,4,16,32,0,128,21,133,21,7,1,20,16,17,35,0,162,21,16,1,133,17,51,144,0,38,17,16,54,21,1,21,16,1,132]

theorem envBound52600 : H12AffineFastState.Bounded env52600 := by
  intro p hp
  have h : env52600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52599_52600 : H12AffineEnvironment.transform 2 4 env52599 = env52600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52599 == env52600) = true)

theorem identity52600 : scanCanonicalize (H12AffineFastState.compose env52600 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound52600 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env52601 : List Nat := [2,4,4,16,6,0,128,21,133,21,7,1,20,16,17,5,0,132,21,16,1,133,17,21,144,0,0,17,16,16,21,1,21,16,1,132]

theorem envBound52601 : H12AffineFastState.Bounded env52601 := by
  intro p hp
  have h : env52601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52600_52601 : H12AffineEnvironment.transform 4 6 env52600 = env52601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env52600 == env52601) = true)

theorem identity52601 : scanCanonicalize (H12AffineFastState.compose env52601 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound52601 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52602 : List Nat := [2,4,4,3,6,0,128,6,133,6,7,1,7,3,2,5,0,132,6,3,1,133,2,6,131,0,0,2,3,3,6,1,6,3,1,132]

theorem envBound52602 : H12AffineFastState.Bounded env52602 := by
  intro p hp
  have h : env52602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52601_52602 : H12AffineEnvironment.transform 3 3 env52601 = env52602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env52601 == env52602) = true)

def env52603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70886,78894,77840,1297,74814,81226,365712,74798,256,308666,1345,79471]

theorem envBound52603 : H12AffineFastState.Bounded env52603 := by
  intro p hp
  have h : env52603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52557_52603 : H12AffineEnvironment.transform 13 1297 env52557 = env52603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52557 == env52603) = true)

theorem identity52603 : scanCanonicalize (H12AffineFastState.compose env52603 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound52603 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,17,266385,38037,46173,45155,1297,42061,48441,267491,42077,256,308666,1345,46620]

theorem envBound52604 : H12AffineFastState.Bounded env52604 := by
  intro p hp
  have h : env52604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52603_52604 : H12AffineEnvironment.transform 15 32883 env52603 = env52604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env52603 == env52604) = true)

def env52605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263633,33237,41245,42275,1297,42061,43129,262563,42077,256,303354,1345,41820]

theorem envBound52605 : H12AffineFastState.Bounded env52605 := by
  intro p hp
  have h : env52605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52604_52605 : H12AffineEnvironment.transform 11 1344 env52604 = env52605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52604 == env52605) = true)

theorem identity52605 : scanCanonicalize (H12AffineFastState.compose env52605 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound52605 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,487,42333,32769,1344,41088,17,1078,33237,41245,42275,1297,42061,43129,68,42077,256,41245,1345,41820]

theorem envBound52606 : H12AffineFastState.Bounded env52606 := by
  intro p hp
  have h : env52606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52605_52606 : H12AffineEnvironment.transform 17 487 env52605 = env52606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env52605 == env52606) = true)

theorem identity52606 : scanCanonicalize (H12AffineFastState.compose env52606 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52606 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1345,487,1025,8541,1344,476,17,1078,8329,65,1151,1297,1297,2341,68,1281,256,65,1345,512]

theorem envBound52607 : H12AffineFastState.Bounded env52607 := by
  intro p hp
  have h : env52607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52606_52607 : H12AffineEnvironment.transform 14 8540 env52606 = env52607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52606 == env52607) = true)

theorem identity52607 : scanCanonicalize (H12AffineFastState.compose env52607 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound52607 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52608 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,8192,1028,8265,8250,1108,242,1025,8264,1109,201,17,1078,8329,65,1151,1028,1028,2096,68,1044,21,65,1108,512]

theorem envBound52608 : H12AffineFastState.Bounded env52608 := by
  intro p hp
  have h : env52608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52607_52608 : H12AffineEnvironment.transform 7 21 env52607 = env52608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env52607 == env52608) = true)

theorem identity52608 : scanCanonicalize (H12AffineFastState.compose env52608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound52608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52609 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,657,1028,728,683,1108,242,1025,729,1109,201,17,1078,536,65,1151,1028,1028,2096,68,1044,21,65,1108,512]

theorem envBound52609 : H12AffineFastState.Bounded env52609 := by
  intro p hp
  have h : env52609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52608_52609 : H12AffineEnvironment.transform 12 657 env52608 = env52609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env52608 == env52609) = true)

theorem identity52609 : scanCanonicalize (H12AffineFastState.compose env52609 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52609 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52610 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,657,1028,648,683,1028,162,1025,649,1029,153,17,1078,536,17,1071,1028,1028,2096,20,1044,21,17,1028,512]

theorem envBound52610 : H12AffineFastState.Bounded env52610 := by
  intro p hp
  have h : env52610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52609_52610 : H12AffineEnvironment.transform 5 16 env52609 = env52610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52609 == env52610) = true)

theorem identity52610 : scanCanonicalize (H12AffineFastState.compose env52610 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound52610 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52611 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,657,0,648,683,0,162,5,649,1,153,17,50,536,17,43,0,0,2096,20,16,21,17,0,512]

theorem envBound52611 : H12AffineFastState.Bounded env52611 := by
  intro p hp
  have h : env52611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52610_52611 : H12AffineEnvironment.transform 9 4 env52610 = env52611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env52610 == env52611) = true)

theorem identity52611 : scanCanonicalize (H12AffineFastState.compose env52611 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound52611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52612 : List Nat := [2,4,8,16,32,16,30,21,512,4,2048,1,527,0,534,565,0,60,5,535,1,7,17,50,536,17,43,0,0,2096,20,16,21,17,0,512]

theorem envBound52612 : H12AffineFastState.Bounded env52612 := by
  intro p hp
  have h : env52612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52611_52612 : H12AffineEnvironment.transform 6 30 env52611 = env52612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env52611 == env52612) = true)

theorem identity52612 : scanCanonicalize (H12AffineFastState.compose env52612 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52612 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52613 : List Nat := [2,4,8,16,17,16,30,21,512,4,2048,1,527,0,534,516,0,13,5,535,1,7,17,3,536,17,26,0,0,2049,20,16,21,17,0,512]

theorem envBound52613 : H12AffineFastState.Bounded env52613 := by
  intro p hp
  have h : env52613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52612_52613 : H12AffineEnvironment.transform 4 17 env52612 = env52613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52612 == env52613) = true)

theorem identity52613 : scanCanonicalize (H12AffineFastState.compose env52613 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound52613 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52614 : List Nat := [2,4,8,16,17,16,30,21,512,4,539,1,527,0,534,516,0,13,5,535,1,7,17,3,536,17,26,0,0,538,20,16,21,17,0,512]

theorem envBound52614 : H12AffineFastState.Bounded env52614 := by
  intro p hp
  have h : env52614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52613_52614 : H12AffineEnvironment.transform 10 539 env52613 = env52614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env52613 == env52614) = true)

theorem identity52614 : scanCanonicalize (H12AffineFastState.compose env52614 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52614 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52615 : List Nat := [2,4,8,6,7,6,8,3,512,4,525,1,527,0,512,516,0,13,5,513,1,7,7,3,526,7,12,0,0,524,2,6,3,7,0,512]

theorem envBound52615 : H12AffineFastState.Bounded env52615 := by
  intro p hp
  have h : env52615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52614_52615 : H12AffineEnvironment.transform 3 6 env52614 = env52615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52614 == env52615) = true)

theorem identity52615 : scanCanonicalize (H12AffineFastState.compose env52615 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52616 : List Nat := [2,4,4,6,7,6,4,3,512,4,513,1,515,0,512,516,0,1,5,513,1,7,7,3,514,7,0,0,0,512,2,6,3,7,0,512]

theorem envBound52616 : H12AffineFastState.Bounded env52616 := by
  intro p hp
  have h : env52616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52615_52616 : H12AffineEnvironment.transform 2 4 env52615 = env52616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52615 == env52616) = true)

theorem identity52616 : scanCanonicalize (H12AffineFastState.compose env52616 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52616 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52617 : List Nat := [2,4,4,6,7,6,4,3,0,4,1,1,3,0,0,4,0,1,5,1,1,7,7,3,2,7,0,0,0,0,2,6,3,7,0,0]

theorem envBound52617 : H12AffineFastState.Bounded env52617 := by
  intro p hp
  have h : env52617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52616_52617 : H12AffineEnvironment.transform 8 0 env52616 = env52617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52616 == env52617) = true)

def env52618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263632,33236,41244,42274,1297,42061,43128,262562,42077,256,303355,1345,41821]

theorem envBound52618 : H12AffineFastState.Bounded env52618 := by
  intro p hp
  have h : env52618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52604_52618 : H12AffineEnvironment.transform 11 1345 env52604 = env52618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52604 == env52618) = true)

theorem identity52618 : scanCanonicalize (H12AffineFastState.compose env52618 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound52618 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,276,359,1345,262144,9288,277,1345,8597,17,263632,192,8200,9270,1297,9561,10604,262562,9545,256,270831,1345,8777]

theorem envBound52619 : H12AffineFastState.Bounded env52619 := by
  intro p hp
  have h : env52619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52618_52619 : H12AffineEnvironment.transform 14 276 env52618 = env52619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env52618 == env52619) = true)

theorem identity52619 : scanCanonicalize (H12AffineFastState.compose env52619 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10824) := by decide +kernel

theorem selectedBound52619 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,276,359,1345,10824,9288,277,1345,8597,17,12184,192,8200,9270,1297,9561,10604,11242,9545,256,2983,1345,8777]

theorem envBound52620 : H12AffineFastState.Bounded env52620 := by
  intro p hp
  have h : env52620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52619_52620 : H12AffineEnvironment.transform 17 10824 env52619 = env52620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10824 env52619 == env52620) = true)

def env52621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86519,94526,77841,1296,74814,96347,381313,90430,256,308667,1345,95102]

theorem envBound52621 : H12AffineFastState.Bounded env52621 := by
  intro p hp
  have h : env52621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52556_52621 : H12AffineEnvironment.transform 16 16465 env52556 = env52621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env52556 == env52621) = true)

def env52622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70887,78894,77841,1296,74814,81227,365713,74798,256,308667,1345,79470]

theorem envBound52622 : H12AffineFastState.Bounded env52622 := by
  intro p hp
  have h : env52622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52621_52622 : H12AffineEnvironment.transform 13 1296 env52621 = env52622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52621 == env52622) = true)

theorem identity52622 : scanCanonicalize (H12AffineFastState.compose env52622 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound52622 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,16,266384,38037,46172,45155,1296,42060,48441,267491,42076,256,308667,1345,46620]

theorem envBound52623 : H12AffineFastState.Bounded env52623 := by
  intro p hp
  have h : env52623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52622_52623 : H12AffineEnvironment.transform 15 32882 env52622 = env52623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env52622 == env52623) = true)

def env52624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263632,33237,41244,42275,1296,42060,43129,262563,42076,256,303355,1345,41820]

theorem envBound52624 : H12AffineFastState.Bounded env52624 := by
  intro p hp
  have h : env52624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52623_52624 : H12AffineEnvironment.transform 11 1344 env52623 = env52624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52623 == env52624) = true)

theorem identity52624 : scanCanonicalize (H12AffineFastState.compose env52624 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound52624 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,34227,42333,32769,1344,41089,16,32867,33237,41244,42275,1296,42060,43129,33808,42076,256,9544,1345,41820]

theorem envBound52625 : H12AffineFastState.Bounded env52625 := by
  intro p hp
  have h : env52625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52624_52625 : H12AffineEnvironment.transform 17 34227 env52624 = env52625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env52624 == env52625) = true)

theorem identity52625 : scanCanonicalize (H12AffineFastState.compose env52625 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound52625 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3822,1296,32768,32882,1345,34227,35763,32769,1344,36463,16,32867,33237,36850,35789,1296,35490,34455,33808,35506,256,2982,1345,36274]

theorem envBound52626 : H12AffineFastState.Bounded env52626 := by
  intro p hp
  have h : env52626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52625_52626 : H12AffineEnvironment.transform 12 3822 env52625 = env52626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env52625 == env52626) = true)

def env52627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263633,33236,41245,42274,1296,42060,43128,262562,42076,256,303354,1345,41821]

end H12CloudChart2