import H12CloudChart2Data125

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound31171 : H12AffineFastState.Bounded env31171 := by
  intro p hp
  have h : env31171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31170_31171 : H12AffineEnvironment.transform 9 4 env31170 = env31171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31170 == env31171) = true)

theorem identity31171 : scanCanonicalize (H12AffineFastState.compose env31171 (packedSelected [0,2,5,7,8,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound31171 : packedSelected [0,2,5,7,8,13,18] rootPS < 2^1333 := by decide +kernel

def env31172 : List Nat := [2,4,8,16,32,17,128,256,512,4,555,276,8192,277,8461,311,277,439,8221,8460,277,397,17,51,144,8201,8242,277,8460,8982,8204,8201,257,260,277,8729]

theorem envBound31172 : H12AffineFastState.Bounded env31172 := by
  intro p hp
  have h : env31172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31171_31172 : H12AffineEnvironment.transform 10 555 env31171 = env31172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env31171 == env31172) = true)

theorem identity31172 : scanCanonicalize (H12AffineFastState.compose env31172 (packedSelected [1,2,5,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound31172 : packedSelected [1,2,5,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31173 : List Nat := [2,4,8,16,32,17,128,256,26,4,49,276,8192,277,8461,311,277,439,8221,8460,277,397,17,51,144,8201,8242,277,8460,8460,8204,8201,257,260,277,8195]

theorem envBound31173 : H12AffineFastState.Bounded env31173 := by
  intro p hp
  have h : env31173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31172_31173 : H12AffineEnvironment.transform 8 26 env31172 = env31173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env31172 == env31173) = true)

theorem identity31173 : scanCanonicalize (H12AffineFastState.compose env31173 (packedSelected [1,2,5,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound31173 : packedSelected [1,2,5,10,15] rootPS < 2^1333 := by decide +kernel

def env31174 : List Nat := [2,4,8,16,32,17,128,256,26,4,49,276,388,277,137,311,277,439,409,136,277,397,17,51,144,397,438,277,136,136,392,397,257,260,277,391]

theorem envBound31174 : H12AffineFastState.Bounded env31174 := by
  intro p hp
  have h : env31174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31173_31174 : H12AffineEnvironment.transform 12 388 env31173 = env31174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env31173 == env31174) = true)

theorem identity31174 : scanCanonicalize (H12AffineFastState.compose env31174 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound31174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31175 : List Nat := [2,4,8,16,32,17,128,182,26,4,49,162,50,163,137,129,163,1,47,136,163,59,17,51,144,59,0,163,136,136,62,59,183,178,163,49]

theorem envBound31175 : H12AffineFastState.Bounded env31175 := by
  intro p hp
  have h : env31175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31174_31175 : H12AffineEnvironment.transform 7 182 env31174 = env31175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env31174 == env31175) = true)

theorem identity31175 : scanCanonicalize (H12AffineFastState.compose env31175 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound31175 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31176 : List Nat := [2,4,8,16,32,17,18,36,26,4,49,48,50,49,27,19,49,1,47,26,49,59,17,51,2,59,0,49,26,26,62,59,37,32,49,49]

theorem envBound31176 : H12AffineFastState.Bounded env31176 := by
  intro p hp
  have h : env31176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31175_31176 : H12AffineEnvironment.transform 6 18 env31175 = env31176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env31175 == env31176) = true)

def env31177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,17,69649,70886,78894,77841,1297,74815,81227,8205,8200,257,1280,1344,79471]

theorem envBound31177 : H12AffineFastState.Bounded env31177 := by
  intro p hp
  have h : env31177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31155_31177 : H12AffineEnvironment.transform 17 65665 env31155 = env31177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31155 == env31177) = true)

theorem identity31177 : scanCanonicalize (H12AffineFastState.compose env31177 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound31177 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,310,1344,439,12633,13340,4097,476,17,4391,5584,13592,12583,1297,9481,15485,8205,8200,257,1280,1344,14169]

theorem envBound31178 : H12AffineFastState.Bounded env31178 := by
  intro p hp
  have h : env31178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31177_31178 : H12AffineEnvironment.transform 15 310 env31177 = env31178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env31177 == env31178) = true)

def env31179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5125,310,1344,439,4417,5124,4097,476,17,4391,5584,5376,4415,1297,1297,7269,21,16,257,1280,1344,5953]

theorem envBound31179 : H12AffineFastState.Bounded env31179 := by
  intro p hp
  have h : env31179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31178_31179 : H12AffineEnvironment.transform 12 24 env31178 = env31179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env31178 == env31179) = true)

theorem identity31179 : scanCanonicalize (H12AffineFastState.compose env31179 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound31179 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env31180 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,4420,310,1,439,4417,4421,4097,476,17,4391,4241,4161,4415,80,80,6436,21,16,257,65,1,4608]

theorem envBound31180 : H12AffineFastState.Bounded env31180 := by
  intro p hp
  have h : env31180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31179_31180 : H12AffineEnvironment.transform 9 321 env31179 = env31180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env31179 == env31180) = true)

theorem identity31180 : scanCanonicalize (H12AffineFastState.compose env31180 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound31180 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31181 : List Nat := [2,4,8,16,32,64,128,256,512,321,318,4096,24,80,4420,310,1,439,4417,4421,4097,476,17,4391,4241,4161,4415,80,80,4122,21,16,257,65,1,4608]

theorem envBound31181 : H12AffineFastState.Bounded env31181 := by
  intro p hp
  have h : env31181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31180_31181 : H12AffineEnvironment.transform 10 318 env31180 = env31181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env31180 == env31181) = true)

theorem identity31181 : scanCanonicalize (H12AffineFastState.compose env31181 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound31181 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env31182 : List Nat := [2,4,8,16,32,64,128,256,81,321,318,4096,24,80,4420,310,1,439,4417,4421,4097,476,17,4391,4241,4161,4415,80,80,4122,21,16,257,65,1,4177]

theorem envBound31182 : H12AffineFastState.Bounded env31182 := by
  intro p hp
  have h : env31182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31181_31182 : H12AffineEnvironment.transform 8 81 env31181 = env31182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env31181 == env31182) = true)

theorem identity31182 : scanCanonicalize (H12AffineFastState.compose env31182 (packedSelected [1,3,4,9,10,11,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound31182 : packedSelected [1,3,4,9,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env31183 : List Nat := [2,4,8,16,32,64,128,20,81,85,42,4096,24,80,4176,34,1,163,4181,4177,4097,200,17,4147,4241,4161,4139,80,80,4122,21,16,21,65,1,4177]

theorem envBound31183 : H12AffineFastState.Bounded env31183 := by
  intro p hp
  have h : env31183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31182_31183 : H12AffineEnvironment.transform 7 20 env31182 = env31183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env31182 == env31183) = true)

theorem identity31183 : scanCanonicalize (H12AffineFastState.compose env31183 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 122) := by decide +kernel

theorem selectedBound31183 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env31184 : List Nat := [2,4,8,16,32,64,128,20,81,85,42,122,24,80,42,34,1,163,47,43,123,200,17,73,235,59,81,80,80,96,21,16,21,65,1,43]

theorem envBound31184 : H12AffineFastState.Bounded env31184 := by
  intro p hp
  have h : env31184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31183_31184 : H12AffineEnvironment.transform 11 122 env31183 = env31184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 122 env31183 == env31184) = true)

theorem identity31184 : scanCanonicalize (H12AffineFastState.compose env31184 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31184 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31185 : List Nat := [2,4,8,16,32,64,9,20,81,85,42,122,24,80,42,34,1,42,47,43,123,65,17,73,98,59,81,80,80,96,21,16,21,65,1,43]

theorem envBound31185 : H12AffineFastState.Bounded env31185 := by
  intro p hp
  have h : env31185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31184_31185 : H12AffineEnvironment.transform 6 9 env31184 = env31185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31184 == env31185) = true)

theorem identity31185 : scanCanonicalize (H12AffineFastState.compose env31185 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31185 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31186 : List Nat := [2,4,8,11,32,64,9,15,74,78,42,97,3,75,42,34,1,42,47,43,96,65,10,73,98,32,74,75,75,96,14,11,14,65,1,43]

theorem envBound31186 : H12AffineFastState.Bounded env31186 := by
  intro p hp
  have h : env31186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31185_31186 : H12AffineEnvironment.transform 3 11 env31185 = env31186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31185 == env31186) = true)

theorem identity31186 : scanCanonicalize (H12AffineFastState.compose env31186 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound31186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31187 : List Nat := [2,4,8,11,32,11,9,15,1,5,42,42,3,0,42,34,1,42,47,43,43,10,10,2,41,32,1,0,0,43,14,11,14,10,1,43]

theorem envBound31187 : H12AffineFastState.Bounded env31187 := by
  intro p hp
  have h : env31187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31186_31187 : H12AffineEnvironment.transform 5 11 env31186 = env31187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env31186 == env31187) = true)

theorem identity31187 : scanCanonicalize (H12AffineFastState.compose env31187 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound31187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31188 : List Nat := [2,4,8,11,12,11,9,15,1,5,6,6,3,0,6,14,1,6,3,7,7,10,10,2,5,12,1,0,0,7,14,11,14,10,1,7]

theorem envBound31188 : H12AffineFastState.Bounded env31188 := by
  intro p hp
  have h : env31188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31187_31188 : H12AffineEnvironment.transform 4 12 env31187 = env31188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env31187 == env31188) = true)

theorem identity31188 : scanCanonicalize (H12AffineFastState.compose env31188 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31188 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31189 : List Nat := [2,3,8,11,11,11,9,8,1,2,1,1,3,0,1,9,1,1,3,0,0,10,10,2,2,11,1,0,0,0,9,11,9,10,1,0]

theorem envBound31189 : H12AffineFastState.Bounded env31189 := by
  intro p hp
  have h : env31189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31188_31189 : H12AffineEnvironment.transform 1 3 env31188 = env31189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31188 == env31189) = true)

theorem identity31189 : scanCanonicalize (H12AffineFastState.compose env31189 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31190 : List Nat := [2,3,0,3,3,3,1,0,1,2,1,1,3,0,1,1,1,1,3,0,0,2,2,2,2,3,1,0,0,0,1,3,1,2,1,0]

theorem envBound31190 : H12AffineFastState.Bounded env31190 := by
  intro p hp
  have h : env31190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31189_31190 : H12AffineEnvironment.transform 2 0 env31189 = env31190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31189 == env31190) = true)

theorem identity31190 : scanCanonicalize (H12AffineFastState.compose env31190 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31190 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31191 : List Nat := [0,1,0,1,1,1,1,0,1,0,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,1,1,0,0,0,1,1,1,0,1,0]

theorem envBound31191 : H12AffineFastState.Bounded env31191 := by
  intro p hp
  have h : env31191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31190_31191 : H12AffineEnvironment.transform 0 0 env31190 = env31191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31190 == env31191) = true)

def env31192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,310,1344,439,4416,5125,4097,476,17,4391,5584,5377,4414,1297,1296,7268,20,17,257,1280,1344,5952]

theorem envBound31192 : H12AffineFastState.Bounded env31192 := by
  intro p hp
  have h : env31192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31178_31192 : H12AffineEnvironment.transform 12 25 env31178 = env31192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env31178 == env31192) = true)

theorem identity31192 : scanCanonicalize (H12AffineFastState.compose env31192 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31192 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env31193 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,25,277,4096,310,324,439,4416,4097,4097,476,17,4391,4564,4357,4414,277,276,6240,20,17,257,260,324,4932]

theorem envBound31193 : H12AffineFastState.Bounded env31193 := by
  intro p hp
  have h : env31193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31192_31193 : H12AffineEnvironment.transform 9 4 env31192 = env31193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31192 == env31193) = true)

theorem identity31193 : scanCanonicalize (H12AffineFastState.compose env31193 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound31193 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31194 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,2195,25,277,2195,310,324,439,2515,2194,2194,476,17,2484,2375,2454,2477,277,276,243,20,17,257,260,324,3031]

theorem envBound31194 : H12AffineFastState.Bounded env31194 := by
  intro p hp
  have h : env31194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31193_31194 : H12AffineEnvironment.transform 11 2195 env31193 = env31194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env31193 == env31194) = true)

theorem identity31194 : scanCanonicalize (H12AffineFastState.compose env31194 (packedSelected [1,2,3,4,5,8,9,12,15,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31194 : packedSelected [1,2,3,4,5,8,9,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env31195 : List Nat := [2,4,8,16,32,64,128,256,0,4,2048,2195,25,277,2195,310,324,439,2515,2194,2194,476,17,2484,2375,2454,2477,277,276,243,20,17,257,260,324,2519]

theorem envBound31195 : H12AffineFastState.Bounded env31195 := by
  intro p hp
  have h : env31195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31194_31195 : H12AffineEnvironment.transform 8 0 env31194 = env31195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31194 == env31195) = true)

theorem identity31195 : scanCanonicalize (H12AffineFastState.compose env31195 (packedSelected [5,8,10,12,13,15,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound31195 : packedSelected [5,8,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env31196 : List Nat := [2,4,8,16,32,11,128,256,0,4,2048,2195,25,277,2195,310,271,439,2456,2194,2194,407,17,2484,2316,2454,2477,277,276,184,20,17,257,260,271,2460]

theorem envBound31196 : H12AffineFastState.Bounded env31196 := by
  intro p hp
  have h : env31196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31195_31196 : H12AffineEnvironment.transform 5 11 env31195 = env31196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env31195 == env31196) = true)

theorem identity31196 : scanCanonicalize (H12AffineFastState.compose env31196 (packedSelected [0,5,7,8,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound31196 : packedSelected [0,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env31197 : List Nat := [2,4,8,16,32,11,18,256,0,4,2048,2049,25,277,2049,310,271,293,2314,2048,2048,261,17,2342,2316,2308,2367,277,276,42,20,17,257,260,271,2318]

theorem envBound31197 : H12AffineFastState.Bounded env31197 := by
  intro p hp
  have h : env31197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31196_31197 : H12AffineEnvironment.transform 6 18 env31196 = env31197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env31196 == env31197) = true)

theorem identity31197 : scanCanonicalize (H12AffineFastState.compose env31197 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31197 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31198 : List Nat := [2,4,8,16,16,11,18,256,0,4,2048,2049,25,277,2049,262,271,277,2314,2048,2048,261,17,2326,2316,2308,2319,277,276,26,20,17,257,260,271,2318]

theorem envBound31198 : H12AffineFastState.Bounded env31198 := by
  intro p hp
  have h : env31198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31197_31198 : H12AffineEnvironment.transform 4 16 env31197 = env31198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31197 == env31198) = true)

theorem identity31198 : scanCanonicalize (H12AffineFastState.compose env31198 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound31198 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31199 : List Nat := [2,4,8,16,16,11,18,256,0,4,277,276,25,277,276,262,271,277,31,277,277,261,17,3,25,17,26,277,276,26,20,17,257,260,271,27]

theorem envBound31199 : H12AffineFastState.Bounded env31199 := by
  intro p hp
  have h : env31199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31198_31199 : H12AffineEnvironment.transform 10 277 env31198 = env31199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env31198 == env31199) = true)

theorem identity31199 : scanCanonicalize (H12AffineFastState.compose env31199 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31199 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31200 : List Nat := [2,4,8,16,16,11,18,21,0,4,0,1,25,0,1,19,26,0,31,0,0,16,17,3,25,17,26,0,1,26,20,17,20,17,26,27]

theorem envBound31200 : H12AffineFastState.Bounded env31200 := by
  intro p hp
  have h : env31200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31199_31200 : H12AffineEnvironment.transform 7 21 env31199 = env31200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31199 == env31200) = true)

theorem identity31200 : scanCanonicalize (H12AffineFastState.compose env31200 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31201 : List Nat := [2,4,5,16,16,6,18,21,0,4,0,1,20,0,1,19,23,0,18,0,0,16,17,3,20,17,23,0,1,23,20,17,20,17,23,22]

theorem envBound31201 : H12AffineFastState.Bounded env31201 := by
  intro p hp
  have h : env31201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31200_31201 : H12AffineEnvironment.transform 2 5 env31200 = env31201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31200 == env31201) = true)

theorem identity31201 : scanCanonicalize (H12AffineFastState.compose env31201 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31202 : List Nat := [2,4,5,6,6,6,4,3,0,4,0,1,2,0,1,5,1,0,4,0,0,6,7,3,2,7,1,0,1,1,2,7,2,7,1,0]

theorem envBound31202 : H12AffineFastState.Bounded env31202 := by
  intro p hp
  have h : env31202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31201_31202 : H12AffineEnvironment.transform 3 6 env31201 = env31202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31201 == env31202) = true)

def env31203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound31203 : H12AffineFastState.Bounded env31203 := by
  intro p hp
  have h : env31203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26410_31203 : H12AffineEnvironment.transform 22 147521 env26410 = env31203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env26410 == env31203) = true)

def env31204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound31204 : H12AffineFastState.Bounded env31204 := by
  intro p hp
  have h : env31204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31203_31204 : H12AffineEnvironment.transform 34 151462016 env31203 = env31204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env31203 == env31204) = true)

def env31205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148801,33584585,96347,50962568,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound31205 : H12AffineFastState.Bounded env31205 := by
  intro p hp
  have h : env31205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31204_31205 : H12AffineEnvironment.transform 20 4096 env31204 = env31205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env31204 == env31205) = true)

theorem identity31205 : scanCanonicalize (H12AffineFastState.compose env31205 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 16819499) := by decide +kernel

theorem selectedBound31205 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env31206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148801,33584585,96347,50962568,16819499,34088328,33584601,151462016,33563273]

theorem envBound31206 : H12AffineFastState.Bounded env31206 := by
  intro p hp
  have h : env31206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31205_31206 : H12AffineEnvironment.transform 31 16819499 env31205 = env31206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 16819499 env31205 == env31206) = true)

def env31207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,134217728,148801,545089,96347,16876544,16819499,256,545105,151462016,525825]

theorem envBound31207 : H12AffineFastState.Bounded env31207 := by
  intro p hp
  have h : env31207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31206_31207 : H12AffineEnvironment.transform 24 533640 env31206 = env31207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env31206 == env31207) = true)

def env31208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245632,148801,545089,96347,16876544,16819499,256,545105,1344,525825]

theorem envBound31208 : H12AffineFastState.Bounded env31208 := by
  intro p hp
  have h : env31208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31207_31208 : H12AffineEnvironment.transform 26 17245632 env31207 = env31208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env31207 == env31208) = true)

theorem identity31208 : scanCanonicalize (H12AffineFastState.compose env31208 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound31208 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41003,533640,672785,493035,148801,545089,96347,74795,1280,256,545105,1344,525825]

theorem envBound31209 : H12AffineFastState.Bounded env31209 := by
  intro p hp
  have h : env31209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31208_31209 : H12AffineEnvironment.transform 23 41003 env31208 = env31209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env31208 == env31209) = true)

def env31210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,493035,148801,148801,96347,74795,1280,256,148817,1344,135681]

theorem envBound31210 : H12AffineFastState.Bounded env31210 := by
  intro p hp
  have h : env31210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31210 : H12AffineEnvironment.transform 18 136192 env31209 = env31210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env31209 == env31210) = true)

def env31211 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,492615,148717,148717,96347,74795,1196,172,148733,1260,135681]

theorem envBound31211 : H12AffineFastState.Bounded env31211 := by
  intro p hp
  have h : env31211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31210_31211 : H12AffineEnvironment.transform 7 172 env31210 = env31211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31210 == env31211) = true)

def env31212 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143496,20497,492567,148669,148669,96267,74795,1196,172,148653,1212,135681]

theorem envBound31212 : H12AffineFastState.Bounded env31212 := by
  intro p hp
  have h : env31212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31211_31212 : H12AffineEnvironment.transform 5 16 env31211 = env31212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31211 == env31212) = true)

theorem identity31212 : scanCanonicalize (H12AffineFastState.compose env31212 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound31212 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31213 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61569,147473,41003,143496,20497,60444,148669,148669,96267,74795,1196,172,148653,1212,135681]

theorem envBound31213 : H12AffineFastState.Bounded env31213 := by
  intro p hp
  have h : env31213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31212_31213 : H12AffineEnvironment.transform 17 223243 env31212 = env31213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env31212 == env31213) = true)

theorem identity31213 : scanCanonicalize (H12AffineFastState.compose env31213 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound31213 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31214 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4096,61569,147473,41003,143496,20497,60444,148669,148669,2184,21672,1196,172,148653,1212,135681]

theorem envBound31214 : H12AffineFastState.Bounded env31214 := by
  intro p hp
  have h : env31214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31213_31214 : H12AffineEnvironment.transform 15 28803 env31213 = env31214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env31213 == env31214) = true)

theorem identity31214 : scanCanonicalize (H12AffineFastState.compose env31214 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58533) := by decide +kernel

theorem selectedBound31214 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31215 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,58533,64557,61605,32769,4096,61569,42164,41003,54317,20497,60444,40984,40984,2184,21672,1196,172,40968,1212,63140]

theorem envBound31215 : H12AffineFastState.Bounded env31215 := by
  intro p hp
  have h : env31215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31214_31215 : H12AffineEnvironment.transform 16 58533 env31214 = env31215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58533 env31214 == env31215) = true)

theorem identity31215 : scanCanonicalize (H12AffineFastState.compose env31215 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound31215 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env31216 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,40985,47249,46105,32769,4096,46141,42164,41003,37009,5293,43168,40984,40984,2184,4116,1196,172,40968,1212,45592]

theorem envBound31216 : H12AffineFastState.Bounded env31216 := by
  intro p hp
  have h : env31216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31215_31216 : H12AffineEnvironment.transform 13 1212 env31215 = env31216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env31215 == env31216) = true)

theorem identity31216 : scanCanonicalize (H12AffineFastState.compose env31216 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound31216 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env31217 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2098,1212,32768,7181,34859,37027,39979,32769,4096,39951,35974,34841,37009,5293,32914,34858,34858,2184,4116,1196,172,34874,1212,39466]

theorem envBound31217 : H12AffineFastState.Bounded env31217 := by
  intro p hp
  have h : env31217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31216_31217 : H12AffineEnvironment.transform 12 2098 env31216 = env31217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env31216 == env31217) = true)

theorem identity31217 : scanCanonicalize (H12AffineFastState.compose env31217 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 7215) := by decide +kernel

theorem selectedBound31217 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env31218 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2098,1212,7215,7181,5124,3212,4,7214,4096,32,4265,5174,3262,5293,7357,5125,5125,2184,4116,1196,172,5141,1212,1541]

theorem envBound31218 : H12AffineFastState.Bounded env31218 := by
  intro p hp
  have h : env31218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31217_31218 : H12AffineEnvironment.transform 14 7215 env31217 = env31218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7215 env31217 == env31218) = true)

theorem identity31218 : scanCanonicalize (H12AffineFastState.compose env31218 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31218 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env31219 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,4096,2098,1212,7215,7181,5124,3212,4,7214,4096,32,4265,5174,3262,5293,7357,5125,5125,2184,4116,1196,172,5141,1212,1028]

theorem envBound31219 : H12AffineFastState.Bounded env31219 := by
  intro p hp
  have h : env31219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31218_31219 : H12AffineEnvironment.transform 8 1 env31218 = env31219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31218 == env31219) = true)

theorem identity31219 : scanCanonicalize (H12AffineFastState.compose env31219 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound31219 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31220 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1190,4096,1172,1212,4233,4267,5124,42,4,4232,4096,32,4265,5174,24,5293,4123,5125,5125,1070,4116,1196,172,5141,1212,1028]

theorem envBound31220 : H12AffineFastState.Bounded env31220 := by
  intro p hp
  have h : env31220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31219_31220 : H12AffineEnvironment.transform 10 1190 env31219 = env31220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env31219 == env31220) = true)

theorem identity31220 : scanCanonicalize (H12AffineFastState.compose env31220 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound31220 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env31221 : List Nat := [2,4,8,16,32,16,19,63,1,1024,1077,4096,1031,1071,4122,4152,5124,42,4,4123,4096,32,4154,5174,24,5182,4123,5125,5125,1070,4116,1087,63,5141,1071,1028]

theorem envBound31221 : H12AffineFastState.Bounded env31221 := by
  intro p hp
  have h : env31221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31220_31221 : H12AffineEnvironment.transform 6 19 env31220 = env31221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env31220 == env31221) = true)

theorem identity31221 : scanCanonicalize (H12AffineFastState.compose env31221 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound31221 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31222 : List Nat := [2,4,8,16,32,16,19,63,1,1024,1077,22,1031,1071,12,46,1042,42,4,13,22,32,44,1056,24,1064,13,1043,1043,1070,2,1087,63,1027,1071,1028]

theorem envBound31222 : H12AffineFastState.Bounded env31222 := by
  intro p hp
  have h : env31222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31221_31222 : H12AffineEnvironment.transform 11 22 env31221 = env31222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env31221 == env31222) = true)

theorem identity31222 : scanCanonicalize (H12AffineFastState.compose env31222 (packedSelected [0,1,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound31222 : packedSelected [0,1,2,9] rootPS < 2^1333 := by decide +kernel

def env31223 : List Nat := [2,4,8,16,32,16,19,63,1,34,23,22,37,13,12,46,48,42,4,13,22,32,44,2,24,10,13,49,49,12,2,29,63,33,13,38]

theorem envBound31223 : H12AffineFastState.Bounded env31223 := by
  intro p hp
  have h : env31223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31222_31223 : H12AffineEnvironment.transform 9 34 env31222 = env31223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env31222 == env31223) = true)

def env31224 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143496,20497,492566,148668,148668,96266,74795,1196,172,148652,1213,135681]

theorem envBound31224 : H12AffineFastState.Bounded env31224 := by
  intro p hp
  have h : env31224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31211_31224 : H12AffineEnvironment.transform 5 17 env31211 = env31224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31211 == env31224) = true)

theorem identity31224 : scanCanonicalize (H12AffineFastState.compose env31224 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound31224 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31225 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61568,98354,41003,127146,20497,279604,99486,99486,96266,74795,1196,172,99470,1213,119331]

theorem envBound31225 : H12AffineFastState.Bounded env31225 := by
  intro p hp
  have h : env31225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31224_31225 : H12AffineEnvironment.transform 16 114722 env31224 = env31225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env31224 == env31225) = true)

theorem identity31225 : scanCanonicalize (H12AffineFastState.compose env31225 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64556) := by decide +kernel

theorem selectedBound31225 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31226 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,64556,119842,32769,4096,61568,98354,41003,127146,20497,47128,99486,99486,96266,74795,1196,172,99470,1213,119331]

theorem envBound31226 : H12AffineFastState.Bounded env31226 := by
  intro p hp
  have h : env31226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31225_31226 : H12AffineEnvironment.transform 17 64556 env31225 = env31226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64556 env31225 == env31226) = true)

theorem identity31226 : scanCanonicalize (H12AffineFastState.compose env31226 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound31226 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env31227 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,64556,1025,32769,4096,61568,20497,41003,8329,20497,47128,21693,21693,43049,62472,1196,172,21677,1213,512]

theorem envBound31227 : H12AffineFastState.Bounded env31227 := by
  intro p hp
  have h : env31227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31226_31227 : H12AffineEnvironment.transform 15 53283 env31226 = env31227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env31226 == env31227) = true)

theorem identity31227 : scanCanonicalize (H12AffineFastState.compose env31227 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound31227 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31228 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,49307,185,60564,1025,32769,184,57400,16553,41003,8329,16553,43168,17413,17413,43049,58544,1196,172,17429,1213,512]

theorem envBound31228 : H12AffineFastState.Bounded env31228 := by
  intro p hp
  have h : env31228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31227_31228 : H12AffineEnvironment.transform 11 184 env31227 = env31228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env31227 == env31228) = true)

theorem identity31228 : scanCanonicalize (H12AffineFastState.compose env31228 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17032) := by decide +kernel

theorem selectedBound31228 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31229 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,17032,531,185,11804,1025,17033,184,8880,16553,25251,8329,16553,27176,17413,17413,27297,9784,1196,172,17429,1213,512]

theorem envBound31229 : H12AffineFastState.Bounded env31229 := by
  intro p hp
  have h : env31229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31228_31229 : H12AffineEnvironment.transform 14 17032 env31228 = env31229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17032 env31228 == env31229) = true)

theorem identity31229 : scanCanonicalize (H12AffineFastState.compose env31229 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 1702) := by decide +kernel

theorem selectedBound31229 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env31230 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1702,1070,531,185,11804,1025,1071,184,8880,1551,9221,8329,1551,11406,675,675,11271,9784,1196,172,691,1213,512]

theorem envBound31230 : H12AffineFastState.Bounded env31230 := by
  intro p hp
  have h : env31230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31229_31230 : H12AffineEnvironment.transform 13 1702 env31229 = env31230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1702 env31229 == env31230) = true)

theorem identity31230 : scanCanonicalize (H12AffineFastState.compose env31230 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound31230 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env31231 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1212,184,8192,1702,1070,531,185,8864,1025,1071,184,8880,1551,9221,8329,1551,8242,675,675,8379,9784,1196,172,691,1213,512]

theorem envBound31231 : H12AffineFastState.Bounded env31231 := by
  intro p hp
  have h : env31231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31230_31231 : H12AffineEnvironment.transform 10 1212 env31230 = env31231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env31230 == env31231) = true)

theorem identity31231 : scanCanonicalize (H12AffineFastState.compose env31231 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound31231 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env31232 : List Nat := [2,4,8,16,32,17,128,172,512,151,43,184,8192,561,185,531,185,8864,150,184,184,8880,664,8338,8329,664,8242,675,675,8379,8879,59,172,691,42,512]

theorem envBound31232 : H12AffineFastState.Bounded env31232 := by
  intro p hp
  have h : env31232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31231_31232 : H12AffineEnvironment.transform 9 151 env31231 = env31232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env31231 == env31232) = true)

theorem identity31232 : scanCanonicalize (H12AffineFastState.compose env31232 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31232 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env31233 : List Nat := [2,4,8,10,32,11,128,172,512,141,43,162,8192,555,163,521,163,8864,140,162,162,8874,642,8328,8329,642,8232,675,675,8353,8879,33,172,681,42,512]

theorem envBound31233 : H12AffineFastState.Bounded env31233 := by
  intro p hp
  have h : env31233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31232_31233 : H12AffineEnvironment.transform 3 10 env31232 = env31233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31232 == env31233) = true)

theorem identity31233 : scanCanonicalize (H12AffineFastState.compose env31233 (packedSelected [0,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound31233 : packedSelected [0,5,6] rootPS < 2^1333 := by decide +kernel

def env31234 : List Nat := [2,4,8,10,32,11,128,172,512,141,43,162,3,555,163,521,163,675,140,162,162,681,642,139,138,642,43,675,675,162,684,33,172,681,42,512]

theorem envBound31234 : H12AffineFastState.Bounded env31234 := by
  intro p hp
  have h : env31234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31233_31234 : H12AffineEnvironment.transform 12 3 env31233 = env31234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env31233 == env31234) = true)

theorem identity31234 : scanCanonicalize (H12AffineFastState.compose env31234 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31234 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31235 : List Nat := [2,4,8,10,32,11,128,172,0,141,43,162,3,43,163,9,163,163,140,162,162,169,130,139,138,130,43,163,163,162,172,33,172,169,42,0]

theorem envBound31235 : H12AffineFastState.Bounded env31235 := by
  intro p hp
  have h : env31235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31234_31235 : H12AffineEnvironment.transform 8 0 env31234 = env31235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31234 == env31235) = true)

def env31236 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,492614,148716,148716,96347,74795,1197,173,148732,1261,135681]

theorem envBound31236 : H12AffineFastState.Bounded env31236 := by
  intro p hp
  have h : env31236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31210_31236 : H12AffineEnvironment.transform 7 173 env31210 = env31236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31210 == env31236) = true)

def env31237 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143496,20497,492566,148668,148668,96267,74795,1197,173,148652,1213,135681]

theorem envBound31237 : H12AffineFastState.Bounded env31237 := by
  intro p hp
  have h : env31237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31236_31237 : H12AffineEnvironment.transform 5 16 env31236 = env31237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31236 == env31237) = true)

theorem identity31237 : scanCanonicalize (H12AffineFastState.compose env31237 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound31237 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31238 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,41003,143496,20497,105631,148668,148668,96267,74795,1197,173,148652,1213,135681]

theorem envBound31238 : H12AffineFastState.Bounded env31238 := by
  intro p hp
  have h : env31238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31237_31238 : H12AffineEnvironment.transform 17 137353 env31237 = env31238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env31237 == env31238) = true)

theorem identity31238 : scanCanonicalize (H12AffineFastState.compose env31238 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound31238 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env31239 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4096,61569,147473,41003,143496,20497,43169,148668,148668,19509,4117,1197,173,148652,1213,135681]

theorem envBound31239 : H12AffineFastState.Bounded env31239 := by
  intro p hp
  have h : env31239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31238_31239 : H12AffineEnvironment.transform 15 13374 env31238 = env31239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env31238 == env31239) = true)

theorem identity31239 : scanCanonicalize (H12AffineFastState.compose env31239 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound31239 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31240 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136192,32769,4096,46140,132268,41003,143496,5292,43169,131073,131073,2184,4117,1197,173,131089,1213,135681]

theorem envBound31240 : H12AffineFastState.Bounded env31240 := by
  intro p hp
  have h : env31240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31239_31240 : H12AffineEnvironment.transform 13 1213 env31239 = env31240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env31239 == env31240) = true)

theorem identity31240 : scanCanonicalize (H12AffineFastState.compose env31240 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound31240 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env31241 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9381,13374,131072,137353,136192,9380,4096,4249,132268,1166,143496,5292,3076,131073,131073,2184,4117,1197,173,131089,1213,135681]

theorem envBound31241 : H12AffineFastState.Bounded env31241 := by
  intro p hp
  have h : env31241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31240_31241 : H12AffineEnvironment.transform 14 9381 env31240 = env31241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env31240 == env31241) = true)

theorem identity31241 : scanCanonicalize (H12AffineFastState.compose env31241 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 5125) := by decide +kernel

theorem selectedBound31241 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env31242 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9381,13374,5125,3212,5,9380,4096,4249,4265,1166,9357,5292,3076,5124,5124,2184,4117,1197,173,5140,1213,1540]

theorem envBound31242 : H12AffineFastState.Bounded env31242 := by
  intro p hp
  have h : env31242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31241_31242 : H12AffineEnvironment.transform 16 5125 env31241 = env31242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5125 env31241 == env31242) = true)

theorem identity31242 : scanCanonicalize (H12AffineFastState.compose env31242 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3222) := by decide +kernel

theorem selectedBound31242 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31243 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3222,8192,1213,9381,10408,2195,3212,5,9380,3222,3087,3135,1166,9357,2106,3076,2194,2194,2184,3203,1197,173,2178,1213,1540]

theorem envBound31243 : H12AffineFastState.Bounded env31243 := by
  intro p hp
  have h : env31243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31242_31243 : H12AffineEnvironment.transform 11 3222 env31242 = env31243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3222 env31242 == env31243) = true)

theorem identity31243 : scanCanonicalize (H12AffineFastState.compose env31243 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound31243 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31244 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1055,137,8192,1213,9381,9399,1164,147,5,9380,137,16,32,1166,9357,1061,27,1165,1165,1175,156,1197,173,1181,1213,1540]

theorem envBound31244 : H12AffineFastState.Bounded env31244 := by
  intro p hp
  have h : env31244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31243_31244 : H12AffineEnvironment.transform 10 1055 env31243 = env31244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env31243 == env31244) = true)

theorem identity31244 : scanCanonicalize (H12AffineFastState.compose env31244 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound31244 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env31245 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1055,137,1069,1213,136,154,1164,147,5,137,137,16,32,1166,160,1061,27,1165,1165,1175,156,1197,173,1181,1213,1540]

theorem envBound31245 : H12AffineFastState.Bounded env31245 := by
  intro p hp
  have h : env31245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31244_31245 : H12AffineEnvironment.transform 12 1069 env31244 = env31245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env31244 == env31245) = true)

theorem identity31245 : scanCanonicalize (H12AffineFastState.compose env31245 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound31245 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31246 : List Nat := [2,4,8,16,32,16,128,173,43,1024,1055,137,1069,1213,136,154,1164,147,5,137,137,16,32,1166,160,1061,27,1165,1165,1175,156,1197,173,1181,1213,1071]

theorem envBound31246 : H12AffineFastState.Bounded env31246 := by
  intro p hp
  have h : env31246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31245_31246 : H12AffineEnvironment.transform 8 43 env31245 = env31246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env31245 == env31246) = true)

theorem identity31246 : scanCanonicalize (H12AffineFastState.compose env31246 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound31246 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env31247 : List Nat := [2,4,8,16,32,16,34,15,43,1024,1055,43,1069,1055,42,56,1070,49,5,43,43,16,32,1068,2,1061,27,1071,1071,1077,62,1039,15,1087,1055,1071]

theorem envBound31247 : H12AffineFastState.Bounded env31247 := by
  intro p hp
  have h : env31247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31246_31247 : H12AffineEnvironment.transform 6 34 env31246 = env31247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env31246 == env31247) = true)

theorem identity31247 : scanCanonicalize (H12AffineFastState.compose env31247 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound31247 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31248 : List Nat := [2,4,8,16,32,16,34,15,43,46,49,43,3,49,42,56,0,49,5,43,43,16,32,2,2,11,27,1,1,27,62,33,15,17,49,1]

theorem envBound31248 : H12AffineFastState.Bounded env31248 := by
  intro p hp
  have h : env31248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31247_31248 : H12AffineEnvironment.transform 9 46 env31247 = env31248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env31247 == env31248) = true)

theorem identity31248 : scanCanonicalize (H12AffineFastState.compose env31248 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31248 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31249 : List Nat := [2,4,8,11,32,11,34,15,43,46,42,43,3,42,42,35,0,42,5,43,43,11,32,2,2,11,0,1,1,0,37,33,15,10,42,1]

theorem envBound31249 : H12AffineFastState.Bounded env31249 := by
  intro p hp
  have h : env31249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31248_31249 : H12AffineEnvironment.transform 3 11 env31248 = env31249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31248 == env31249) = true)

theorem identity31249 : scanCanonicalize (H12AffineFastState.compose env31249 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31249 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31250 : List Nat := [2,3,8,11,32,11,34,8,43,41,42,43,3,42,42,35,0,42,2,43,43,11,32,2,2,11,0,1,1,0,34,33,8,10,42,1]

theorem envBound31250 : H12AffineFastState.Bounded env31250 := by
  intro p hp
  have h : env31250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31249_31250 : H12AffineEnvironment.transform 1 3 env31249 = env31250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31249 == env31250) = true)

theorem identity31250 : scanCanonicalize (H12AffineFastState.compose env31250 (packedSelected [1,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31250 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env31251 : List Nat := [2,3,8,11,11,11,9,8,0,2,1,0,3,1,1,8,0,1,2,0,0,11,11,2,2,11,0,1,1,0,9,10,8,10,1,1]

theorem envBound31251 : H12AffineFastState.Bounded env31251 := by
  intro p hp
  have h : env31251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31250_31251 : H12AffineEnvironment.transform 4 11 env31250 = env31251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31250 == env31251) = true)

theorem identity31251 : scanCanonicalize (H12AffineFastState.compose env31251 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31252 : List Nat := [1,0,8,8,8,8,9,8,0,1,1,0,0,1,1,8,0,1,1,0,0,8,8,1,1,8,0,1,1,0,9,9,8,9,1,1]

theorem envBound31252 : H12AffineFastState.Bounded env31252 := by
  intro p hp
  have h : env31252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31251_31252 : H12AffineEnvironment.transform 0 1 env31251 = env31252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31251 == env31252) = true)

theorem identity31252 : scanCanonicalize (H12AffineFastState.compose env31252 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31253 : List Nat := [1,0,0,0,0,0,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,0,1,1,0,1,1,1]

theorem envBound31253 : H12AffineFastState.Bounded env31253 := by
  intro p hp
  have h : env31253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31252_31253 : H12AffineEnvironment.transform 2 0 env31252 = env31253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31252 == env31253) = true)

def env31254 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143496,20497,492567,148669,148669,96266,74795,1197,173,148653,1212,135681]

theorem envBound31254 : H12AffineFastState.Bounded env31254 := by
  intro p hp
  have h : env31254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31236_31254 : H12AffineEnvironment.transform 5 17 env31236 = env31254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31236 == env31254) = true)

theorem identity31254 : scanCanonicalize (H12AffineFastState.compose env31254 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound31254 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31255 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,41003,32809,20497,341174,62492,62492,96266,74795,1197,173,62476,1212,41632]

theorem envBound31255 : H12AffineFastState.Bounded env31255 := by
  intro p hp
  have h : env31255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31254_31255 : H12AffineEnvironment.transform 16 45217 env31254 = env31255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env31254 == env31255) = true)

theorem identity31255 : scanCanonicalize (H12AffineFastState.compose env31255 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound31255 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env31256 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4096,46141,46092,41003,32809,5292,341174,45217,45217,81079,74795,1197,173,45233,1212,41632]

theorem envBound31256 : H12AffineFastState.Bounded env31256 := by
  intro p hp
  have h : env31256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31255_31256 : H12AffineEnvironment.transform 13 1213 env31255 = env31256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env31255 == env31256) = true)

theorem identity31256 : scanCanonicalize (H12AffineFastState.compose env31256 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound31256 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31257 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,9351,45217,262144,42145,32769,4096,46141,46092,41003,32809,5292,266289,45217,45217,6192,172,1197,173,45233,1212,41632]

theorem envBound31257 : H12AffineFastState.Bounded env31257 := by
  intro p hp
  have h : env31257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31256_31257 : H12AffineEnvironment.transform 15 9351 env31256 = env31257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env31256 == env31257) = true)

theorem identity31257 : scanCanonicalize (H12AffineFastState.compose env31257 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound31257 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env31258 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12313,9351,184,262144,5304,12312,4096,1060,1045,4146,12336,5292,266289,184,184,6192,172,1197,173,168,1212,4793]

theorem envBound31258 : H12AffineFastState.Bounded env31258 := by
  intro p hp
  have h : env31258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31257_31258 : H12AffineEnvironment.transform 14 12313 env31257 = env31258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env31257 == env31258) = true)

theorem identity31258 : scanCanonicalize (H12AffineFastState.compose env31258 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound31258 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env31259 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,8352,9351,184,262144,1025,8353,185,1060,1045,139,8329,1045,262280,184,184,2185,172,1197,173,168,1212,512]

theorem envBound31259 : H12AffineFastState.Bounded env31259 := by
  intro p hp
  have h : env31259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31258_31259 : H12AffineEnvironment.transform 11 185 env31258 = env31259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env31258 == env31259) = true)

theorem identity31259 : scanCanonicalize (H12AffineFastState.compose env31259 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound31259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31260 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2600,1213,2696,3759,184,262144,1025,2697,185,1060,1045,139,2721,1045,262280,184,184,2185,172,1197,173,168,1212,512]

theorem envBound31260 : H12AffineFastState.Bounded env31260 := by
  intro p hp
  have h : env31260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31259_31260 : H12AffineEnvironment.transform 12 2600 env31259 = env31260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env31259 == env31260) = true)

theorem identity31260 : scanCanonicalize (H12AffineFastState.compose env31260 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound31260 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31261 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2600,1213,2696,3759,184,2707,1025,2697,185,1060,1045,139,2721,1045,2587,184,184,2185,172,1197,173,168,1212,512]

theorem envBound31261 : H12AffineFastState.Bounded env31261 := by
  intro p hp
  have h : env31261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31260_31261 : H12AffineEnvironment.transform 17 2707 env31260 = env31261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env31260 == env31261) = true)

theorem identity31261 : scanCanonicalize (H12AffineFastState.compose env31261 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound31261 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31262 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,185,1685,1213,1589,530,184,1582,1025,1588,185,1060,1045,139,1564,1045,1702,184,184,1076,172,1197,173,168,1212,512]

theorem envBound31262 : H12AffineFastState.Bounded env31262 := by
  intro p hp
  have h : env31262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31261_31262 : H12AffineEnvironment.transform 10 1213 env31261 = env31262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env31261 == env31262) = true)

theorem identity31262 : scanCanonicalize (H12AffineFastState.compose env31262 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31262 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env31263 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1213,185,1173,1213,1077,18,184,1070,1025,1076,185,1060,1045,139,1052,1045,1190,184,184,1076,172,1197,173,168,1212,0]

theorem envBound31263 : H12AffineFastState.Bounded env31263 := by
  intro p hp
  have h : env31263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31262_31263 : H12AffineEnvironment.transform 8 0 env31262 = env31263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31262 == env31263) = true)

theorem identity31263 : scanCanonicalize (H12AffineFastState.compose env31263 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound31263 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env31264 : List Nat := [2,4,8,16,32,17,19,62,0,1024,1070,42,1030,1070,1077,18,43,1070,1025,1076,42,1060,1045,24,1052,1045,1077,43,43,1076,63,1086,62,59,1071,0]

theorem envBound31264 : H12AffineFastState.Bounded env31264 := by
  intro p hp
  have h : env31264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31263_31264 : H12AffineEnvironment.transform 6 19 env31263 = env31264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env31263 == env31264) = true)

theorem identity31264 : scanCanonicalize (H12AffineFastState.compose env31264 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31264 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31265 : List Nat := [2,4,8,16,32,17,19,62,0,4,42,42,2,42,49,18,43,42,5,48,42,32,17,24,24,17,49,43,43,48,63,58,62,59,43,0]

theorem envBound31265 : H12AffineFastState.Bounded env31265 := by
  intro p hp
  have h : env31265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31264_31265 : H12AffineEnvironment.transform 9 4 env31264 = env31265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31264 == env31265) = true)

theorem identity31265 : scanCanonicalize (H12AffineFastState.compose env31265 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound31265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31266 : List Nat := [2,4,8,16,28,17,19,2,0,4,22,22,2,22,13,18,23,22,5,12,22,28,17,24,24,17,13,23,23,12,3,6,2,7,23,0]

theorem envBound31266 : H12AffineFastState.Bounded env31266 := by
  intro p hp
  have h : env31266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31265_31266 : H12AffineEnvironment.transform 4 28 env31265 = env31266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env31265 == env31266) = true)

def env31267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,493035,148801,148800,96347,74795,1280,256,148816,1344,135680]

theorem envBound31267 : H12AffineFastState.Bounded env31267 := by
  intro p hp
  have h : env31267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31267 : H12AffineEnvironment.transform 18 136193 env31209 = env31267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env31209 == env31267) = true)

def env31268 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,492615,148717,148716,96347,74795,1196,172,148732,1260,135680]

theorem envBound31268 : H12AffineFastState.Bounded env31268 := by
  intro p hp
  have h : env31268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31267_31268 : H12AffineEnvironment.transform 7 172 env31267 = env31268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31267 == env31268) = true)

def env31269 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143497,20496,492567,148669,148668,96267,74795,1196,172,148652,1212,135680]

theorem envBound31269 : H12AffineFastState.Bounded env31269 := by
  intro p hp
  have h : env31269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31268_31269 : H12AffineEnvironment.transform 5 16 env31268 = env31269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31268 == env31269) = true)

theorem identity31269 : scanCanonicalize (H12AffineFastState.compose env31269 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound31269 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31270 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61569,98355,41003,127147,20496,279605,99487,99486,96267,74795,1196,172,99470,1212,119330]

theorem envBound31270 : H12AffineFastState.Bounded env31270 := by
  intro p hp
  have h : env31270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31269_31270 : H12AffineEnvironment.transform 16 114722 env31269 = env31270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env31269 == env31270) = true)

theorem identity31270 : scanCanonicalize (H12AffineFastState.compose env31270 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64556) := by decide +kernel

theorem selectedBound31270 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31271 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,64556,119843,32769,4096,61569,98355,41003,127147,20496,47129,99487,99486,96267,74795,1196,172,99470,1212,119330]

theorem envBound31271 : H12AffineFastState.Bounded env31271 := by
  intro p hp
  have h : env31271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31270_31271 : H12AffineEnvironment.transform 17 64556 env31270 = env31271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64556 env31270 == env31271) = true)

theorem identity31271 : scanCanonicalize (H12AffineFastState.compose env31271 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound31271 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env31272 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,64556,1025,32769,4096,61569,20497,41003,8329,20496,47129,21693,21692,43049,62473,1196,172,21676,1212,512]

theorem envBound31272 : H12AffineFastState.Bounded env31272 := by
  intro p hp
  have h : env31272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31271_31272 : H12AffineEnvironment.transform 15 53282 env31271 = env31272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env31271 == env31272) = true)

theorem identity31272 : scanCanonicalize (H12AffineFastState.compose env31272 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound31272 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31273 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,49307,185,60565,1025,32769,185,57400,16552,41003,8329,16553,43168,17412,17413,43049,58544,1196,172,17429,1212,512]

theorem envBound31273 : H12AffineFastState.Bounded env31273 := by
  intro p hp
  have h : env31273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31272_31273 : H12AffineEnvironment.transform 11 185 env31272 = env31273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env31272 == env31273) = true)

theorem identity31273 : scanCanonicalize (H12AffineFastState.compose env31273 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound31273 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31274 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,8745,32768,41650,185,36540,1025,32769,185,33297,8833,41003,8329,8832,43168,9773,9772,43049,34457,1196,172,9788,1212,512]

theorem envBound31274 : H12AffineFastState.Bounded env31274 := by
  intro p hp
  have h : env31274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31273_31274 : H12AffineEnvironment.transform 13 8745 env31273 = env31274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env31273 == env31274) = true)

theorem identity31274 : scanCanonicalize (H12AffineFastState.compose env31274 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 8891) := by decide +kernel

theorem selectedBound31274 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31275 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,8745,8891,9,185,11271,1025,8890,185,8362,8833,656,8329,8832,2587,9773,9772,2706,9250,1196,172,9788,1212,512]

theorem envBound31275 : H12AffineFastState.Bounded env31275 := by
  intro p hp
  have h : env31275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31274_31275 : H12AffineEnvironment.transform 14 8891 env31274 = env31275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8891 env31274 == env31275) = true)

theorem identity31275 : scanCanonicalize (H12AffineFastState.compose env31275 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound31275 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env31276 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,1166,1703,1589,9,185,2185,1025,1588,185,1060,1551,656,1031,1550,2587,675,674,2706,172,1196,172,690,1212,512]

theorem envBound31276 : H12AffineFastState.Bounded env31276 := by
  intro p hp
  have h : env31276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31275_31276 : H12AffineEnvironment.transform 12 1166 env31275 = env31276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env31275 == env31276) = true)

theorem identity31276 : scanCanonicalize (H12AffineFastState.compose env31276 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31276 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env31277 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1,185,1166,1703,1589,9,185,136,1025,1588,185,1060,1551,656,1031,1550,538,675,674,659,172,1196,172,690,1212,512]

theorem envBound31277 : H12AffineFastState.Bounded env31277 := by
  intro p hp
  have h : env31277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31276_31277 : H12AffineEnvironment.transform 10 1 env31276 = env31277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31276 == env31277) = true)

theorem identity31277 : scanCanonicalize (H12AffineFastState.compose env31277 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31277 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env31278 : List Nat := [2,4,8,16,16,16,128,156,512,1024,1,137,1166,1687,1541,9,137,136,1025,1540,137,1044,1551,656,1031,1550,538,659,658,659,156,1180,156,642,1164,512]

theorem envBound31278 : H12AffineFastState.Bounded env31278 := by
  intro p hp
  have h : env31278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31277_31278 : H12AffineEnvironment.transform 4 16 env31277 = env31278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31277 == env31278) = true)

theorem identity31278 : scanCanonicalize (H12AffineFastState.compose env31278 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31278 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31279 : List Nat := [2,4,8,16,16,16,128,156,1,1024,1,137,1166,1174,1028,9,137,136,1025,1029,137,1044,1038,145,1031,1039,27,146,147,146,156,1180,156,131,1164,1]

theorem envBound31279 : H12AffineFastState.Bounded env31279 := by
  intro p hp
  have h : env31279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31278_31279 : H12AffineEnvironment.transform 8 1 env31278 = env31279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31278 == env31279) = true)

theorem identity31279 : scanCanonicalize (H12AffineFastState.compose env31279 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound31279 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31280 : List Nat := [2,4,8,16,16,16,18,14,1,1024,1,27,1052,1028,1028,9,27,26,1025,1029,27,1044,1038,3,1031,1039,27,0,1,0,14,1038,14,17,1054,1]

theorem envBound31280 : H12AffineFastState.Bounded env31280 := by
  intro p hp
  have h : env31280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31279_31280 : H12AffineEnvironment.transform 6 18 env31279 = env31280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env31279 == env31280) = true)

theorem identity31280 : scanCanonicalize (H12AffineFastState.compose env31280 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31280 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31281 : List Nat := [2,4,4,16,16,16,18,2,1,1024,1,23,1040,1028,1028,5,23,22,1025,1029,23,1044,1026,3,1031,1027,23,0,1,0,2,1026,2,17,1042,1]

theorem envBound31281 : H12AffineFastState.Bounded env31281 := by
  intro p hp
  have h : env31281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31280_31281 : H12AffineEnvironment.transform 2 4 env31280 = env31281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31280 == env31281) = true)

theorem identity31281 : scanCanonicalize (H12AffineFastState.compose env31281 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31281 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env31282 : List Nat := [2,4,4,7,7,7,5,2,1,1024,1,0,1031,1028,1028,5,0,1,1025,1029,0,1027,1026,3,1031,1027,0,0,1,0,2,1026,2,6,1029,1]

theorem envBound31282 : H12AffineFastState.Bounded env31282 := by
  intro p hp
  have h : env31282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31281_31282 : H12AffineEnvironment.transform 3 7 env31281 = env31282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31281 == env31282) = true)

theorem identity31282 : scanCanonicalize (H12AffineFastState.compose env31282 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31283 : List Nat := [2,4,4,7,7,7,5,2,1,5,1,0,2,1,1,5,0,1,4,0,0,6,7,3,2,6,0,0,1,0,2,7,2,6,0,1]

theorem envBound31283 : H12AffineFastState.Bounded env31283 := by
  intro p hp
  have h : env31283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31282_31283 : H12AffineEnvironment.transform 9 5 env31282 = env31283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31282 == env31283) = true)

def env31284 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143497,20496,492566,148668,148669,96266,74795,1196,172,148653,1213,135680]

theorem envBound31284 : H12AffineFastState.Bounded env31284 := by
  intro p hp
  have h : env31284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31268_31284 : H12AffineEnvironment.transform 5 17 env31268 = env31284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31268 == env31284) = true)

theorem identity31284 : scanCanonicalize (H12AffineFastState.compose env31284 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound31284 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31285 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61568,147472,41003,143497,20496,60445,148668,148669,96266,74795,1196,172,148653,1213,135680]

theorem envBound31285 : H12AffineFastState.Bounded env31285 := by
  intro p hp
  have h : env31285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31284_31285 : H12AffineEnvironment.transform 17 223243 env31284 = env31285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env31284 == env31285) = true)

theorem identity31285 : scanCanonicalize (H12AffineFastState.compose env31285 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound31285 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31286 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4096,61568,147472,41003,143497,20496,60445,148668,148669,2184,21673,1196,172,148653,1213,135680]

theorem envBound31286 : H12AffineFastState.Bounded env31286 := by
  intro p hp
  have h : env31286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31285_31286 : H12AffineEnvironment.transform 15 28802 env31285 = env31286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env31285 == env31286) = true)

theorem identity31286 : scanCanonicalize (H12AffineFastState.compose env31286 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58532) := by decide +kernel

theorem selectedBound31286 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31287 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,58532,64557,61605,32769,4096,61568,42164,41003,54317,20496,60445,40984,40985,2184,21673,1196,172,40969,1213,63140]

theorem envBound31287 : H12AffineFastState.Bounded env31287 := by
  intro p hp
  have h : env31287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31286_31287 : H12AffineEnvironment.transform 16 58532 env31286 = env31287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58532 env31286 == env31287) = true)

theorem identity31287 : scanCanonicalize (H12AffineFastState.compose env31287 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound31287 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env31288 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,40985,47248,46104,32769,4096,46141,42164,41003,37008,5293,43168,40984,40985,2184,4116,1196,172,40969,1213,45593]

theorem envBound31288 : H12AffineFastState.Bounded env31288 := by
  intro p hp
  have h : env31288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31287_31288 : H12AffineEnvironment.transform 13 1213 env31287 = env31288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env31287 == env31288) = true)

theorem identity31288 : scanCanonicalize (H12AffineFastState.compose env31288 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 2195) := by decide +kernel

theorem selectedBound31288 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env31289 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,2195,13375,10378,12291,15499,2194,4096,15534,11303,10424,6147,5293,8243,10379,10378,2184,4116,1196,172,10394,1213,14986]

theorem envBound31289 : H12AffineFastState.Bounded env31289 := by
  intro p hp
  have h : env31289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31288_31289 : H12AffineEnvironment.transform 14 2195 env31288 = env31289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2195 env31288 == env31289) = true)

theorem identity31289 : scanCanonicalize (H12AffineFastState.compose env31289 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31289 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env31290 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,2195,12346,10378,12291,14478,2194,4096,14507,10274,10424,6147,4264,8243,10379,10378,2184,4116,169,172,10394,184,14986]

theorem envBound31290 : H12AffineFastState.Bounded env31290 := by
  intro p hp
  have h : env31290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31289_31290 : H12AffineEnvironment.transform 9 5 env31289 = env31290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31289 == env31290) = true)

theorem identity31290 : scanCanonicalize (H12AffineFastState.compose env31290 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound31290 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env31291 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,697,8192,184,2195,8835,10378,8890,10807,2194,697,10770,10274,10424,2746,529,8243,10379,10378,2184,685,169,172,10394,184,10291]

theorem envBound31291 : H12AffineFastState.Bounded env31291 := by
  intro p hp
  have h : env31291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31290_31291 : H12AffineEnvironment.transform 11 697 env31290 = env31291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env31290 == env31291) = true)

theorem identity31291 : scanCanonicalize (H12AffineFastState.compose env31291 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound31291 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31292 : List Nat := [2,4,8,16,32,17,128,172,512,5,163,697,8192,184,48,8835,8233,8890,8852,49,697,8881,8321,8219,537,529,8243,8232,8233,43,685,169,172,8249,184,8336]

theorem envBound31292 : H12AffineFastState.Bounded env31292 := by
  intro p hp
  have h : env31292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31291_31292 : H12AffineEnvironment.transform 10 163 env31291 = env31292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env31291 == env31292) = true)

theorem identity31292 : scanCanonicalize (H12AffineFastState.compose env31292 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound31292 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env31293 : List Nat := [2,4,8,16,32,17,128,172,512,5,163,697,2,184,48,641,43,696,662,49,697,691,131,25,537,529,49,42,43,43,685,169,172,59,184,146]

theorem envBound31293 : H12AffineFastState.Bounded env31293 := by
  intro p hp
  have h : env31293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31292_31293 : H12AffineEnvironment.transform 12 2 env31292 = env31293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env31292 == env31293) = true)

theorem identity31293 : scanCanonicalize (H12AffineFastState.compose env31293 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound31293 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env31294 : List Nat := [2,4,8,16,32,17,128,172,26,5,163,163,2,184,48,155,43,162,140,49,163,169,131,25,3,11,49,42,43,43,183,169,172,59,184,146]

theorem envBound31294 : H12AffineFastState.Bounded env31294 := by
  intro p hp
  have h : env31294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31293_31294 : H12AffineEnvironment.transform 8 26 env31293 = env31294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env31293 == env31294) = true)

theorem identity31294 : scanCanonicalize (H12AffineFastState.compose env31294 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound31294 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31295 : List Nat := [2,4,8,16,32,17,30,50,26,5,61,61,2,38,48,5,43,60,18,49,61,55,29,25,3,11,49,42,43,43,41,55,50,59,38,12]

theorem envBound31295 : H12AffineFastState.Bounded env31295 := by
  intro p hp
  have h : env31295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31294_31295 : H12AffineEnvironment.transform 6 30 env31294 = env31295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env31294 == env31295) = true)

theorem identity31295 : scanCanonicalize (H12AffineFastState.compose env31295 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31295 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31296 : List Nat := [2,4,4,16,32,17,18,50,22,5,49,49,2,38,48,5,39,48,18,49,49,55,17,21,3,7,49,38,39,39,37,55,50,55,38,0]

theorem envBound31296 : H12AffineFastState.Bounded env31296 := by
  intro p hp
  have h : env31296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31295_31296 : H12AffineEnvironment.transform 2 4 env31295 = env31296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31295 == env31296) = true)

theorem identity31296 : scanCanonicalize (H12AffineFastState.compose env31296 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31296 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31297 : List Nat := [2,4,4,6,32,7,4,36,0,5,39,39,2,38,38,5,39,38,4,39,39,33,7,3,3,7,39,38,39,39,37,33,36,33,38,0]

theorem envBound31297 : H12AffineFastState.Bounded env31297 := by
  intro p hp
  have h : env31297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31296_31297 : H12AffineEnvironment.transform 3 6 env31296 = env31297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31296 == env31297) = true)

def env31298 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143497,20496,492614,148716,148717,96347,74795,1197,173,148733,1261,135680]

theorem envBound31298 : H12AffineFastState.Bounded env31298 := by
  intro p hp
  have h : env31298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31267_31298 : H12AffineEnvironment.transform 7 173 env31267 = env31298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31267 == env31298) = true)

def env31299 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143497,20496,492566,148668,148669,96267,74795,1197,173,148653,1213,135680]

theorem envBound31299 : H12AffineFastState.Bounded env31299 := by
  intro p hp
  have h : env31299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31298_31299 : H12AffineEnvironment.transform 5 16 env31298 = env31299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31298 == env31299) = true)

theorem identity31299 : scanCanonicalize (H12AffineFastState.compose env31299 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound31299 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31300 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,41003,32809,20496,341174,62492,62493,96267,74795,1197,173,62477,1213,41632]

theorem envBound31300 : H12AffineFastState.Bounded env31300 := by
  intro p hp
  have h : env31300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31299_31300 : H12AffineEnvironment.transform 16 45216 env31299 = env31300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env31299 == env31300) = true)

theorem identity31300 : scanCanonicalize (H12AffineFastState.compose env31300 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound31300 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env31301 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4096,46141,46093,41003,32809,5292,341174,45216,45217,81079,74795,1197,173,45233,1213,41632]

theorem envBound31301 : H12AffineFastState.Bounded env31301 := by
  intro p hp
  have h : env31301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31300_31301 : H12AffineEnvironment.transform 13 1212 env31300 = env31301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env31300 == env31301) = true)

theorem identity31301 : scanCanonicalize (H12AffineFastState.compose env31301 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound31301 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31302 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,9350,45216,262144,42145,32769,4096,46141,46093,41003,32809,5292,266288,45216,45217,6193,173,1197,173,45233,1213,41632]

theorem envBound31302 : H12AffineFastState.Bounded env31302 := by
  intro p hp
  have h : env31302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31301_31302 : H12AffineEnvironment.transform 15 9350 env31301 = env31302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env31301 == env31302) = true)

theorem identity31302 : scanCanonicalize (H12AffineFastState.compose env31302 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound31302 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env31303 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,9350,184,262144,5305,12313,4096,1061,1045,4147,12337,5292,266288,184,185,6193,173,1197,173,169,1213,4792]

theorem envBound31303 : H12AffineFastState.Bounded env31303 := by
  intro p hp
  have h : env31303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31302_31303 : H12AffineEnvironment.transform 14 12312 env31302 = env31303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env31302 == env31303) = true)

theorem identity31303 : scanCanonicalize (H12AffineFastState.compose env31303 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound31303 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env31304 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,9350,184,9407,5305,12313,4096,1061,1045,4147,12337,5292,13455,184,185,6193,173,1197,173,169,1213,4792]

theorem envBound31304 : H12AffineFastState.Bounded env31304 := by
  intro p hp
  have h : env31304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31303_31304 : H12AffineEnvironment.transform 17 9407 env31303 = env31304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env31303 == env31304) = true)

theorem identity31304 : scanCanonicalize (H12AffineFastState.compose env31304 (packedSelected [1,2,3,10,11,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 6658) := by decide +kernel

theorem selectedBound31304 : packedSelected [1,2,3,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env31305 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,6658,1212,2586,7812,184,7869,5305,2587,4096,1061,1045,4147,2611,5292,3725,184,185,6193,173,1197,173,169,1213,4792]

theorem envBound31305 : H12AffineFastState.Bounded env31305 := by
  intro p hp
  have h : env31305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31304_31305 : H12AffineEnvironment.transform 12 6658 env31304 = env31305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6658 env31304 == env31305) = true)

theorem identity31305 : scanCanonicalize (H12AffineFastState.compose env31305 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound31305 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31306 : List Nat := [2,4,8,16,32,16,128,173,512,1024,43,4096,4649,1212,561,5807,184,5782,5305,560,4096,1061,1045,4147,536,5292,1702,184,185,4122,173,1197,173,169,1213,4792]

theorem envBound31306 : H12AffineFastState.Bounded env31306 := by
  intro p hp
  have h : env31306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31305_31306 : H12AffineEnvironment.transform 10 43 env31305 = env31306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env31305 == env31306) = true)

theorem identity31306 : scanCanonicalize (H12AffineFastState.compose env31306 (packedSelected [2,4,6,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound31306 : packedSelected [2,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31307 : List Nat := [2,4,8,16,32,16,128,173,512,151,43,4096,4649,43,561,4664,184,4609,4142,560,4096,178,130,4147,536,4155,561,184,185,4122,173,58,173,169,42,4792]

theorem envBound31307 : H12AffineFastState.Bounded env31307 := by
  intro p hp
  have h : env31307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31306_31307 : H12AffineEnvironment.transform 9 151 env31306 = env31307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env31306 == env31307) = true)

theorem identity31307 : scanCanonicalize (H12AffineFastState.compose env31307 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31307 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env31308 : List Nat := [2,4,8,10,32,10,128,173,512,141,43,4096,4649,43,555,4642,162,4609,4142,554,4096,168,130,4137,514,4129,555,162,163,4096,173,32,173,169,42,4770]

theorem envBound31308 : H12AffineFastState.Bounded env31308 := by
  intro p hp
  have h : env31308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31307_31308 : H12AffineEnvironment.transform 3 10 env31307 = env31308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31307 == env31308) = true)

theorem identity31308 : scanCanonicalize (H12AffineFastState.compose env31308 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound31308 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31309 : List Nat := [2,4,8,10,32,10,128,173,512,141,43,43,514,43,555,521,162,554,5,554,43,168,130,2,514,10,555,162,163,43,173,32,173,169,42,649]

theorem envBound31309 : H12AffineFastState.Bounded env31309 := by
  intro p hp
  have h : env31309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31308_31309 : H12AffineEnvironment.transform 11 43 env31308 = env31309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env31308 == env31309) = true)

theorem identity31309 : scanCanonicalize (H12AffineFastState.compose env31309 (packedSelected [1,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound31309 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env31310 : List Nat := [2,4,8,10,32,10,128,173,137,141,43,43,139,43,162,128,162,163,5,163,43,168,130,2,139,10,162,162,163,43,173,32,173,169,42,0]

theorem envBound31310 : H12AffineFastState.Bounded env31310 := by
  intro p hp
  have h : env31310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31309_31310 : H12AffineEnvironment.transform 8 137 env31309 = env31310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env31309 == env31310) = true)

theorem identity31310 : scanCanonicalize (H12AffineFastState.compose env31310 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31311 : List Nat := [2,4,8,10,7,10,128,138,137,141,12,12,139,12,133,128,133,132,5,132,12,143,130,2,139,10,133,133,132,12,138,7,138,142,13,0]

theorem envBound31311 : H12AffineFastState.Bounded env31311 := by
  intro p hp
  have h : env31311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31310_31311 : H12AffineEnvironment.transform 4 7 env31310 = env31311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31310 == env31311) = true)

theorem identity31311 : scanCanonicalize (H12AffineFastState.compose env31311 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31311 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31312 : List Nat := [2,4,4,6,7,6,128,134,133,129,0,0,135,0,133,128,133,132,5,132,0,131,130,2,135,6,133,133,132,0,134,7,134,130,1,0]

theorem envBound31312 : H12AffineFastState.Bounded env31312 := by
  intro p hp
  have h : env31312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31311_31312 : H12AffineEnvironment.transform 2 4 env31311 = env31312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31311 == env31312) = true)

theorem identity31312 : scanCanonicalize (H12AffineFastState.compose env31312 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound31312 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31313 : List Nat := [2,4,4,6,7,6,4,2,1,5,0,0,3,0,1,4,1,0,5,0,0,7,6,2,3,6,1,1,0,0,2,7,2,6,1,0]

theorem envBound31313 : H12AffineFastState.Bounded env31313 := by
  intro p hp
  have h : env31313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31312_31313 : H12AffineEnvironment.transform 6 4 env31312 = env31313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env31312 == env31313) = true)

theorem identity31313 : scanCanonicalize (H12AffineFastState.compose env31313 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31314 : List Nat := [2,0,0,2,3,2,0,2,1,1,0,0,3,0,1,0,1,0,1,0,0,3,2,2,3,2,1,1,0,0,2,3,2,2,1,0]

theorem envBound31314 : H12AffineFastState.Bounded env31314 := by
  intro p hp
  have h : env31314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31313_31314 : H12AffineEnvironment.transform 1 0 env31313 = env31314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31313 == env31314) = true)

theorem identity31314 : scanCanonicalize (H12AffineFastState.compose env31314 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31314 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31315 : List Nat := [1,0,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,0,1,0,0,0,1,1,0,1,1,1,0,0,1,0,1,1,1,0]

theorem envBound31315 : H12AffineFastState.Bounded env31315 := by
  intro p hp
  have h : env31315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31314_31315 : H12AffineEnvironment.transform 0 1 env31314 = env31315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31314 == env31315) = true)

def env31316 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143497,20496,492567,148669,148668,96266,74795,1197,173,148652,1212,135680]

theorem envBound31316 : H12AffineFastState.Bounded env31316 := by
  intro p hp
  have h : env31316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31298_31316 : H12AffineEnvironment.transform 5 17 env31298 = env31316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31298 == env31316) = true)

theorem identity31316 : scanCanonicalize (H12AffineFastState.compose env31316 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound31316 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31317 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,41003,143497,20496,105631,148669,148668,96266,74795,1197,173,148652,1212,135680]

theorem envBound31317 : H12AffineFastState.Bounded env31317 := by
  intro p hp
  have h : env31317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31316_31317 : H12AffineEnvironment.transform 17 137352 env31316 = env31317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env31316 == env31317) = true)

theorem identity31317 : scanCanonicalize (H12AffineFastState.compose env31317 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound31317 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env31318 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4096,61568,147472,41003,143497,20496,43169,148669,148668,19508,4117,1197,173,148652,1212,135680]

theorem envBound31318 : H12AffineFastState.Bounded env31318 := by
  intro p hp
  have h : env31318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31317_31318 : H12AffineEnvironment.transform 15 13374 env31317 = env31318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env31317 == env31318) = true)

theorem identity31318 : scanCanonicalize (H12AffineFastState.compose env31318 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound31318 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31319 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136193,32769,4096,46140,132268,41003,143497,5292,43169,131073,131072,2184,4117,1197,173,131088,1212,135680]

theorem envBound31319 : H12AffineFastState.Bounded env31319 := by
  intro p hp
  have h : env31319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31318_31319 : H12AffineEnvironment.transform 13 1212 env31318 = env31319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env31318 == env31319) = true)

theorem identity31319 : scanCanonicalize (H12AffineFastState.compose env31319 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound31319 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env31320 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,46245,44077,41124,32769,4096,46140,45065,41003,33836,5292,43169,46244,46245,2184,4117,1197,173,46261,1212,42661]

theorem envBound31320 : H12AffineFastState.Bounded env31320 := by
  intro p hp
  have h : env31320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31319_31320 : H12AffineEnvironment.transform 16 46245 env31319 = env31320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env31319 == env31320) = true)

theorem identity31320 : scanCanonicalize (H12AffineFastState.compose env31320 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 14523) := by decide +kernel

theorem selectedBound31320 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31321 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,14523,13374,3102,5270,6175,14522,4096,3207,2226,6288,15511,5292,4122,3103,3102,2184,4117,1197,173,3086,1212,7710]

theorem envBound31321 : H12AffineFastState.Bounded env31321 := by
  intro p hp
  have h : env31321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31320_31321 : H12AffineEnvironment.transform 14 14523 env31320 = env31321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14523 env31320 == env31321) = true)

theorem identity31321 : scanCanonicalize (H12AffineFastState.compose env31321 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 7174) := by decide +kernel

theorem selectedBound31321 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env31322 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7174,1212,1213,2104,3102,5270,6175,1212,4096,3207,2226,6288,145,5292,4122,3103,3102,2184,4117,1197,173,3086,1212,7710]

theorem envBound31322 : H12AffineFastState.Bounded env31322 := by
  intro p hp
  have h : env31322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31321_31322 : H12AffineEnvironment.transform 12 7174 env31321 = env31322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7174 env31321 == env31322) = true)

theorem identity31322 : scanCanonicalize (H12AffineFastState.compose env31322 (packedSelected [0,1,2,3,4,6,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound31322 : packedSelected [0,1,2,3,4,6,10,13] rootPS < 2^1333 := by decide +kernel

def env31323 : List Nat := [2,4,8,16,32,17,128,173,512,1024,42,4096,5164,1212,1213,18,1076,5270,4149,1212,4096,1197,152,4282,145,5292,4122,1077,1076,162,4117,1197,173,1060,1212,5684]

theorem envBound31323 : H12AffineFastState.Bounded env31323 := by
  intro p hp
  have h : env31323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31322_31323 : H12AffineEnvironment.transform 10 42 env31322 = env31323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env31322 == env31323) = true)

theorem identity31323 : scanCanonicalize (H12AffineFastState.compose env31323 (packedSelected [0,2,4,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound31323 : packedSelected [0,2,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env31324 : List Nat := [2,4,8,16,32,17,128,173,512,1024,42,1077,25,1212,1213,18,1076,163,1024,1212,1077,1197,152,1167,145,153,1071,1077,1076,162,1056,1197,173,1060,1212,513]

theorem envBound31324 : H12AffineFastState.Bounded env31324 := by
  intro p hp
  have h : env31324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31323_31324 : H12AffineEnvironment.transform 11 1077 env31323 = env31324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env31323 == env31324) = true)

theorem identity31324 : scanCanonicalize (H12AffineFastState.compose env31324 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound31324 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31325 : List Nat := [2,4,8,16,32,17,40,5,512,1024,42,1077,25,1044,1045,18,1076,11,1024,1044,1077,1029,48,1063,57,49,1071,1077,1076,10,1056,1029,5,1060,1044,513]

theorem envBound31325 : H12AffineFastState.Bounded env31325 := by
  intro p hp
  have h : env31325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31324_31325 : H12AffineEnvironment.transform 6 40 env31324 = env31325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env31324 == env31325) = true)

theorem identity31325 : scanCanonicalize (H12AffineFastState.compose env31325 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound31325 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31326 : List Nat := [2,4,8,16,32,17,40,5,512,37,42,16,25,49,48,18,17,11,37,49,16,32,48,2,57,49,10,16,17,10,5,32,5,1,49,513]

theorem envBound31326 : H12AffineFastState.Bounded env31326 := by
  intro p hp
  have h : env31326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31325_31326 : H12AffineEnvironment.transform 9 37 env31325 = env31326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env31325 == env31326) = true)

theorem identity31326 : scanCanonicalize (H12AffineFastState.compose env31326 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound31326 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31327 : List Nat := [2,4,8,16,32,17,40,5,10,37,42,16,25,49,48,18,17,11,37,49,16,32,48,2,57,49,10,16,17,10,5,32,5,1,49,11]

theorem envBound31327 : H12AffineFastState.Bounded env31327 := by
  intro p hp
  have h : env31327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31326_31327 : H12AffineEnvironment.transform 8 10 env31326 = env31327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env31326 == env31327) = true)

theorem identity31327 : scanCanonicalize (H12AffineFastState.compose env31327 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound31327 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31328 : List Nat := [2,4,7,16,32,17,39,5,5,37,37,16,22,49,48,18,17,4,37,49,16,32,48,2,54,49,5,16,17,5,5,32,5,1,49,4]

theorem envBound31328 : H12AffineFastState.Bounded env31328 := by
  intro p hp
  have h : env31328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31327_31328 : H12AffineEnvironment.transform 2 7 env31327 = env31328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env31327 == env31328) = true)

theorem identity31328 : scanCanonicalize (H12AffineFastState.compose env31328 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31328 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31329 : List Nat := [2,4,7,16,16,17,23,5,5,21,21,16,22,1,0,18,17,4,21,1,16,16,0,2,6,1,5,16,17,5,5,16,5,1,1,4]

theorem envBound31329 : H12AffineFastState.Bounded env31329 := by
  intro p hp
  have h : env31329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31328_31329 : H12AffineEnvironment.transform 4 16 env31328 = env31329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31328 == env31329) = true)

theorem identity31329 : scanCanonicalize (H12AffineFastState.compose env31329 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound31329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31330 : List Nat := [2,4,7,4,4,5,3,5,5,1,1,4,2,1,0,6,5,4,1,1,4,4,0,2,6,1,5,4,5,5,5,4,5,1,1,4]

theorem envBound31330 : H12AffineFastState.Bounded env31330 := by
  intro p hp
  have h : env31330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31329_31330 : H12AffineEnvironment.transform 3 4 env31329 = env31330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env31329 == env31330) = true)

theorem identity31330 : scanCanonicalize (H12AffineFastState.compose env31330 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31331 : List Nat := [1,4,4,4,4,5,0,5,5,1,1,4,1,1,0,5,5,4,1,1,4,4,0,1,5,1,5,4,5,5,5,4,5,1,1,4]

theorem envBound31331 : H12AffineFastState.Bounded env31331 := by
  intro p hp
  have h : env31331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31330_31331 : H12AffineEnvironment.transform 0 1 env31330 = env31331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31330 == env31331) = true)

def env31332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245633,148801,545089,96347,16876544,16819499,256,545105,1345,525825]

theorem envBound31332 : H12AffineFastState.Bounded env31332 := by
  intro p hp
  have h : env31332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31207_31332 : H12AffineEnvironment.transform 26 17245633 env31207 = env31332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env31207 == env31332) = true)

theorem identity31332 : scanCanonicalize (H12AffineFastState.compose env31332 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound31332 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717115,533640,672785,906490,148801,545089,96347,750907,676880,256,545105,1345,525825]

theorem envBound31333 : H12AffineFastState.Bounded env31333 := by
  intro p hp
  have h : env31333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31332_31333 : H12AffineEnvironment.transform 23 717115 env31332 = env31333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env31332 == env31333) = true)

def env31334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58683,143496,20497,508154,148801,148801,96347,90427,16400,256,148817,1345,135681]

theorem envBound31334 : H12AffineFastState.Bounded env31334 := by
  intro p hp
  have h : env31334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31333_31334 : H12AffineEnvironment.transform 18 136192 env31333 = env31334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env31333 == env31334) = true)

def env31335 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143496,20497,508154,148717,148717,96347,90263,16400,172,148733,1261,135681]

theorem envBound31335 : H12AffineFastState.Bounded env31335 := by
  intro p hp
  have h : env31335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31334_31335 : H12AffineEnvironment.transform 7 172 env31334 = env31335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31334 == env31335) = true)

def env31336 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143496,20497,508074,148669,148669,96267,90263,16400,172,148653,1213,135681]

theorem envBound31336 : H12AffineFastState.Bounded env31336 := by
  intro p hp
  have h : env31336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31335_31336 : H12AffineEnvironment.transform 5 16 env31335 = env31336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31335 == env31336) = true)

theorem identity31336 : scanCanonicalize (H12AffineFastState.compose env31336 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound31336 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31337 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61569,147473,58519,143496,20497,60445,148669,148669,96267,90263,16400,172,148653,1213,135681]

theorem envBound31337 : H12AffineFastState.Bounded env31337 := by
  intro p hp
  have h : env31337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31336_31337 : H12AffineEnvironment.transform 17 208055 env31336 = env31337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env31336 == env31337) = true)

theorem identity31337 : scanCanonicalize (H12AffineFastState.compose env31337 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound31337 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env31338 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4096,61569,147473,58519,143496,20497,60445,148669,148669,43048,45236,16400,172,148653,1213,135681]

theorem envBound31338 : H12AffineFastState.Bounded env31338 := by
  intro p hp
  have h : env31338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31337_31338 : H12AffineEnvironment.transform 15 53283 env31337 = env31338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env31337 == env31338) = true)

theorem identity31338 : scanCanonicalize (H12AffineFastState.compose env31338 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound31338 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31339 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4096,61569,5293,58519,25652,20497,60445,4097,4097,43048,45236,16400,172,4113,1213,18109]

theorem envBound31339 : H12AffineFastState.Bounded env31339 := by
  intro p hp
  have h : env31339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31338_31339 : H12AffineEnvironment.transform 16 21692 env31338 = env31339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env31338 == env31339) = true)

theorem identity31339 : scanCanonicalize (H12AffineFastState.compose env31339 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound31339 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env31340 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5125,32768,33830,185,43048,5305,32769,4096,42116,5293,45202,12337,1044,47128,4097,4097,43048,45236,5141,172,4113,1213,4792]

theorem envBound31340 : H12AffineFastState.Bounded env31340 := by
  intro p hp
  have h : env31340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31339_31340 : H12AffineEnvironment.transform 13 5125 env31339 = env31340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env31339 == env31340) = true)

theorem identity31340 : scanCanonicalize (H12AffineFastState.compose env31340 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5660) := by decide +kernel

theorem selectedBound31340 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31341 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5660,5125,32768,33830,185,40500,5305,32769,4096,37528,5293,34446,1581,1044,36356,4097,4097,40500,34472,5141,172,4113,1213,4792]

theorem envBound31341 : H12AffineFastState.Bounded env31341 := by
  intro p hp
  have h : env31341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31340_31341 : H12AffineEnvironment.transform 12 5660 env31340 = env31341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5660 env31340 == env31341) = true)

theorem identity31341 : scanCanonicalize (H12AffineFastState.compose env31341 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3734) := by decide +kernel

theorem selectedBound31341 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env31342 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5660,5125,3734,2736,185,4258,5305,3735,4096,7182,5293,2072,1581,1044,146,4097,4097,4258,2110,5141,172,4113,1213,4792]

theorem envBound31342 : H12AffineFastState.Bounded env31342 := by
  intro p hp
  have h : env31342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31341_31342 : H12AffineEnvironment.transform 14 3734 env31341 = env31342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3734 env31341 == env31342) = true)

theorem identity31342 : scanCanonicalize (H12AffineFastState.compose env31342 (packedSelected [1,3,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31342 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env31343 : List Nat := [2,4,8,16,17,16,128,157,512,1024,2048,4096,5660,5125,3734,2689,136,4243,5256,3735,4096,7182,5276,2072,1564,1044,146,4097,4097,4243,2063,5141,157,4113,1164,4745]

theorem envBound31343 : H12AffineFastState.Bounded env31343 := by
  intro p hp
  have h : env31343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31342_31343 : H12AffineEnvironment.transform 4 17 env31342 = env31343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31342 == env31343) = true)

theorem identity31343 : scanCanonicalize (H12AffineFastState.compose env31343 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31343 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env31344 : List Nat := [2,4,8,11,10,11,128,134,512,1024,2048,4096,5639,5125,3725,2689,136,4232,5256,3724,4096,7182,5255,2051,1543,1039,137,4097,4097,4232,2063,5134,134,4106,1164,4745]

theorem envBound31344 : H12AffineFastState.Bounded env31344 := by
  intro p hp
  have h : env31344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31343_31344 : H12AffineEnvironment.transform 3 11 env31343 = env31344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31343 == env31344) = true)

theorem identity31344 : scanCanonicalize (H12AffineFastState.compose env31344 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31344 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env31345 : List Nat := [2,4,8,11,10,11,9,15,512,1024,2048,4096,5639,5125,3588,2568,1,4097,5121,3589,4096,7182,5134,2051,1543,1039,0,4097,4097,4097,2063,5134,15,4106,1029,4608]

theorem envBound31345 : H12AffineFastState.Bounded env31345 := by
  intro p hp
  have h : env31345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31344_31345 : H12AffineEnvironment.transform 6 9 env31344 = env31345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31344 == env31345) = true)

theorem identity31345 : scanCanonicalize (H12AffineFastState.compose env31345 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound31345 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31346 : List Nat := [2,4,8,11,10,11,9,15,512,1024,2048,3077,2562,2048,3588,2568,1,3076,2052,3589,3077,11,2059,2051,1543,1039,0,3076,3076,3076,2063,2059,15,3087,1029,3589]

theorem envBound31346 : H12AffineFastState.Bounded env31346 := by
  intro p hp
  have h : env31346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31345_31346 : H12AffineEnvironment.transform 11 3077 env31345 = env31346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env31345 == env31346) = true)

theorem identity31346 : scanCanonicalize (H12AffineFastState.compose env31346 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31347 : List Nat := [2,4,8,11,10,11,9,15,0,1024,2048,3077,2050,2048,3076,2056,1,3076,2052,3077,3077,11,2059,2051,1031,1039,0,3076,3076,3076,2063,2059,15,3087,1029,3077]

theorem envBound31347 : H12AffineFastState.Bounded env31347 := by
  intro p hp
  have h : env31347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31346_31347 : H12AffineEnvironment.transform 8 0 env31346 = env31347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31346 == env31347) = true)

theorem identity31347 : scanCanonicalize (H12AffineFastState.compose env31347 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31348 : List Nat := [2,4,8,11,10,11,9,15,0,1024,1,1028,3,1,1029,9,1,1029,5,1028,1028,11,10,2,1031,1039,0,1029,1029,1029,14,10,15,1038,1029,1028]

theorem envBound31348 : H12AffineFastState.Bounded env31348 := by
  intro p hp
  have h : env31348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31347_31348 : H12AffineEnvironment.transform 10 1 env31347 = env31348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31347 == env31348) = true)

theorem identity31348 : scanCanonicalize (H12AffineFastState.compose env31348 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound31348 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31349 : List Nat := [2,4,8,11,10,11,9,15,0,2,1,6,3,1,7,9,1,7,5,6,6,11,10,2,5,13,0,7,7,7,14,10,15,12,7,6]

theorem envBound31349 : H12AffineFastState.Bounded env31349 := by
  intro p hp
  have h : env31349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31348_31349 : H12AffineEnvironment.transform 9 2 env31348 = env31349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env31348 == env31349) = true)

theorem identity31349 : scanCanonicalize (H12AffineFastState.compose env31349 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31349 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31350 : List Nat := [2,3,8,11,10,11,9,8,0,2,1,1,3,1,0,9,1,0,2,1,1,11,10,2,2,10,0,0,0,0,9,10,8,11,0,1]

theorem envBound31350 : H12AffineFastState.Bounded env31350 := by
  intro p hp
  have h : env31350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31349_31350 : H12AffineEnvironment.transform 1 3 env31349 = env31350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31349 == env31350) = true)

theorem identity31350 : scanCanonicalize (H12AffineFastState.compose env31350 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound31350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31351 : List Nat := [2,3,1,2,3,2,0,1,0,2,1,1,3,1,0,0,1,0,2,1,1,2,3,2,2,3,0,0,0,0,0,3,1,2,0,1]

theorem envBound31351 : H12AffineFastState.Bounded env31351 := by
  intro p hp
  have h : env31351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31350_31351 : H12AffineEnvironment.transform 2 1 env31350 = env31351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env31350 == env31351) = true)

theorem identity31351 : scanCanonicalize (H12AffineFastState.compose env31351 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31351 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31352 : List Nat := [0,1,1,0,1,0,0,1,0,0,1,1,1,1,0,0,1,0,0,1,1,0,1,0,0,1,0,0,0,0,0,1,1,0,0,1]

theorem envBound31352 : H12AffineFastState.Bounded env31352 := by
  intro p hp
  have h : env31352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31351_31352 : H12AffineEnvironment.transform 0 0 env31351 = env31352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31351 == env31352) = true)

def env31353 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143496,20497,508075,148668,148668,96266,90263,16400,172,148652,1212,135681]

theorem envBound31353 : H12AffineFastState.Bounded env31353 := by
  intro p hp
  have h : env31353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31335_31353 : H12AffineEnvironment.transform 5 17 env31335 = env31353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31335 == env31353) = true)

theorem identity31353 : scanCanonicalize (H12AffineFastState.compose env31353 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound31353 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31354 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61568,115854,58519,111638,20497,279605,114722,114722,96266,90263,16400,172,114738,1212,104095]

theorem envBound31354 : H12AffineFastState.Bounded env31354 := by
  intro p hp
  have h : env31354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31353_31354 : H12AffineEnvironment.transform 16 99486 env31353 = env31354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env31353 == env31354) = true)

theorem identity31354 : scanCanonicalize (H12AffineFastState.compose env31354 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound31354 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env31355 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,65536,99486,262144,98343,32769,185,57401,115854,58519,107695,16552,279605,114722,114722,92339,90263,16400,172,114738,1212,99878]

theorem envBound31355 : H12AffineFastState.Bounded env31355 := by
  intro p hp
  have h : env31355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31354_31355 : H12AffineEnvironment.transform 11 185 env31354 = env31355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env31354 == env31355) = true)

theorem identity31355 : scanCanonicalize (H12AffineFastState.compose env31355 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound31355 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31356 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,33830,184,262144,1025,32769,185,57401,16552,58519,8329,16552,279605,17412,17412,60565,58545,16400,172,17428,1212,512]

theorem envBound31356 : H12AffineFastState.Bounded env31356 := by
  intro p hp
  have h : env31356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31355_31356 : H12AffineEnvironment.transform 15 33830 env31355 = env31356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env31355 == env31356) = true)

theorem identity31356 : scanCanonicalize (H12AffineFastState.compose env31356 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound31356 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31357 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33830,184,262144,1025,32769,185,42116,1045,41002,8329,1045,262280,185,185,43048,40972,1197,172,169,1212,512]

theorem envBound31357 : H12AffineFastState.Bounded env31357 := by
  intro p hp
  have h : env31357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31356_31357 : H12AffineEnvironment.transform 13 1213 env31356 = env31357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env31356 == env31357) = true)

theorem identity31357 : scanCanonicalize (H12AffineFastState.compose env31357 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound31357 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31358 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,561,1559,184,262144,1025,560,185,9909,1045,8731,8329,1045,262280,185,185,10777,8765,1197,172,169,1212,512]

theorem envBound31358 : H12AffineFastState.Bounded env31358 := by
  intro p hp
  have h : env31358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31357_31358 : H12AffineEnvironment.transform 14 561 env31357 = env31358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env31357 == env31358) = true)

theorem identity31358 : scanCanonicalize (H12AffineFastState.compose env31358 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31358 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env31359 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,185,8192,185,561,531,184,262144,5,560,185,8881,17,8731,8329,17,262280,185,185,10777,8765,169,172,169,184,512]

theorem envBound31359 : H12AffineFastState.Bounded env31359 := by
  intro p hp
  have h : env31359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31358_31359 : H12AffineEnvironment.transform 9 4 env31358 = env31359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31358 == env31359) = true)

theorem identity31359 : scanCanonicalize (H12AffineFastState.compose env31359 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 8379) := by decide +kernel

theorem selectedBound31359 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31360 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,185,8192,185,561,531,184,8379,5,560,185,8881,17,8731,8329,17,8243,185,185,10777,8765,169,172,169,184,512]

theorem envBound31360 : H12AffineFastState.Bounded env31360 := by
  intro p hp
  have h : env31360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31359_31360 : H12AffineEnvironment.transform 17 8379 env31359 = env31360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8379 env31359 == env31360) = true)

def env31361 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143496,20497,508154,148716,148716,96347,90262,16400,173,148732,1260,135681]

theorem envBound31361 : H12AffineFastState.Bounded env31361 := by
  intro p hp
  have h : env31361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31334_31361 : H12AffineEnvironment.transform 7 173 env31334 = env31361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31334 == env31361) = true)

def env31362 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143496,20497,508074,148668,148668,96267,90262,16400,173,148652,1212,135681]

theorem envBound31362 : H12AffineFastState.Bounded env31362 := by
  intro p hp
  have h : env31362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31361_31362 : H12AffineEnvironment.transform 5 16 env31361 = env31362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31361 == env31362) = true)

theorem identity31362 : scanCanonicalize (H12AffineFastState.compose env31362 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound31362 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31363 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,58518,143496,20497,120867,148668,148668,96267,90262,16400,173,148652,1212,135681]

theorem envBound31363 : H12AffineFastState.Bounded env31363 := by
  intro p hp
  have h : env31363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31362_31363 : H12AffineEnvironment.transform 17 137353 env31362 = env31363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env31362 == env31363) = true)

theorem identity31363 : scanCanonicalize (H12AffineFastState.compose env31363 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound31363 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env31364 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4096,61569,46093,58518,50324,20497,120867,45216,45216,96267,90262,16400,173,45232,1212,58909]

theorem envBound31364 : H12AffineFastState.Bounded env31364 := by
  intro p hp
  have h : env31364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31363_31364 : H12AffineEnvironment.transform 16 62492 env31363 = env31364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env31363 == env31364) = true)

theorem identity31364 : scanCanonicalize (H12AffineFastState.compose env31364 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound31364 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31365 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,9351,62492,60565,57372,32769,4096,61569,46093,58518,50324,20497,64676,45216,45216,23692,17425,16400,173,45232,1212,58909]

theorem envBound31365 : H12AffineFastState.Bounded env31365 := by
  intro p hp
  have h : env31365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31364_31365 : H12AffineEnvironment.transform 15 9351 env31364 = env31365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env31364 == env31365) = true)

theorem identity31365 : scanCanonicalize (H12AffineFastState.compose env31365 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound31365 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31366 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,3724,9351,31376,25113,28304,3725,4096,32269,14977,27162,18968,20497,29224,15916,15916,23692,17425,16400,173,15932,1212,26769]

theorem envBound31366 : H12AffineFastState.Bounded env31366 := by
  intro p hp
  have h : env31366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31365_31366 : H12AffineEnvironment.transform 14 3724 env31365 = env31366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env31365 == env31366) = true)

theorem identity31366 : scanCanonicalize (H12AffineFastState.compose env31366 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound31366 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env31367 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,14889,3724,9351,185,6192,5305,3725,4096,1060,14977,4147,12337,10808,2049,15916,15916,9893,15928,14905,173,15932,1212,4792]

theorem envBound31367 : H12AffineFastState.Bounded env31367 := by
  intro p hp
  have h : env31367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31366_31367 : H12AffineEnvironment.transform 13 14889 env31366 = env31367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env31366 == env31367) = true)

theorem identity31367 : scanCanonicalize (H12AffineFastState.compose env31367 (packedSelected [0,1,3,5,8,9,11,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound31367 : packedSelected [0,1,3,5,8,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env31368 : List Nat := [2,4,8,16,32,16,128,173,136,1024,2048,4096,8192,14497,3076,9351,185,6192,5305,3077,4096,1060,14345,4147,12337,10416,2049,15524,15524,9261,15536,14513,173,15540,1212,4144]

theorem envBound31368 : H12AffineFastState.Bounded env31368 := by
  intro p hp
  have h : env31368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31367_31368 : H12AffineEnvironment.transform 8 136 env31367 = env31368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env31367 == env31368) = true)

theorem identity31368 : scanCanonicalize (H12AffineFastState.compose env31368 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 5311) := by decide +kernel

theorem selectedBound31368 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31369 : List Nat := [2,4,8,16,32,16,128,173,136,1024,2048,4096,5311,3102,3076,4152,185,6192,5305,3077,4096,1060,3254,4147,1166,7183,2049,2075,2075,4242,2063,3086,173,2059,1212,4144]

theorem envBound31369 : H12AffineFastState.Bounded env31369 := by
  intro p hp
  have h : env31369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31368_31369 : H12AffineEnvironment.transform 12 5311 env31368 = env31369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5311 env31368 == env31369) = true)

theorem identity31369 : scanCanonicalize (H12AffineFastState.compose env31369 (packedSelected [1,3,4,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound31369 : packedSelected [1,3,4,9,13] rootPS < 2^1333 := by decide +kernel

def env31370 : List Nat := [2,4,8,16,32,16,128,173,136,30,2048,4096,4257,2048,2074,4152,185,6192,4263,2075,4096,58,2216,4147,144,6161,2049,2075,2075,4242,2063,2064,173,2059,162,4144]

theorem envBound31370 : H12AffineFastState.Bounded env31370 := by
  intro p hp
  have h : env31370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31369_31370 : H12AffineEnvironment.transform 9 30 env31369 = env31370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env31369 == env31370) = true)

def env31371 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143496,20497,508075,148669,148669,96266,90262,16400,173,148653,1213,135681]

theorem envBound31371 : H12AffineFastState.Bounded env31371 := by
  intro p hp
  have h : env31371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31361_31371 : H12AffineEnvironment.transform 5 17 env31361 = env31371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31361 == env31371) = true)

theorem identity31371 : scanCanonicalize (H12AffineFastState.compose env31371 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound31371 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31372 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,58518,32809,20497,356362,62492,62492,96266,90262,16400,173,62476,1213,41632]

theorem envBound31372 : H12AffineFastState.Bounded env31372 := by
  intro p hp
  have h : env31372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31371_31372 : H12AffineEnvironment.transform 16 45217 env31371 = env31372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env31371 == env31372) = true)

theorem identity31372 : scanCanonicalize (H12AffineFastState.compose env31372 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound31372 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31373 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4096,61568,61617,58518,32809,20497,96387,62492,62492,96266,90262,16400,173,62476,1213,41632]

theorem envBound31373 : H12AffineFastState.Bounded env31373 := by
  intro p hp
  have h : env31373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31372_31373 : H12AffineEnvironment.transform 17 2185 env31372 = env31373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env31372 == env31373) = true)

theorem identity31373 : scanCanonicalize (H12AffineFastState.compose env31373 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound31373 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31374 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,65536,17412,2185,20484,29860,4096,1061,1044,4147,29836,20497,96387,185,185,96266,90262,16400,173,169,1213,22021]

theorem envBound31374 : H12AffineFastState.Bounded env31374 := by
  intro p hp
  have h : env31374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31373_31374 : H12AffineEnvironment.transform 14 29861 env31373 = env31374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env31373 == env31374) = true)

theorem identity31374 : scanCanonicalize (H12AffineFastState.compose env31374 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound31374 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env31375 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,13375,17412,2185,20484,29860,4096,1061,1044,4147,29836,20497,19644,185,185,19509,21673,16400,173,169,1213,22021]

theorem envBound31375 : H12AffineFastState.Bounded env31375 := by
  intro p hp
  have h : env31375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31374_31375 : H12AffineEnvironment.transform 15 13375 env31374 = env31375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env31374 == env31375) = true)

theorem identity31375 : scanCanonicalize (H12AffineFastState.compose env31375 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 14873) := by decide +kernel

theorem selectedBound31375 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env31376 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,14873,3772,13375,15901,2185,10781,3773,4096,1061,1044,4147,3733,10760,13989,185,185,13868,11952,14857,173,169,1213,11292]

theorem envBound31376 : H12AffineFastState.Bounded env31376 := by
  intro p hp
  have h : env31376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31375_31376 : H12AffineEnvironment.transform 13 14873 env31375 = env31376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14873 env31375 == env31376) = true)

theorem identity31376 : scanCanonicalize (H12AffineFastState.compose env31376 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound31376 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31377 : List Nat := [2,4,8,16,32,17,128,173,512,1024,512,4096,8192,12313,1212,13375,13341,649,8221,1213,4096,1061,1044,4147,1173,8200,13989,185,185,13868,9392,12297,173,169,1213,9756]

theorem envBound31377 : H12AffineFastState.Bounded env31377 := by
  intro p hp
  have h : env31377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31376_31377 : H12AffineEnvironment.transform 10 512 env31376 = env31377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env31376 == env31377) = true)

theorem identity31377 : scanCanonicalize (H12AffineFastState.compose env31377 (packedSelected [0,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound31377 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env31378 : List Nat := [2,4,8,16,32,17,128,173,512,564,512,4096,8192,12313,648,12811,12841,649,8221,649,4096,529,544,4147,673,8200,12433,185,185,12312,8836,12297,173,169,649,8232]

theorem envBound31378 : H12AffineFastState.Bounded env31378 := by
  intro p hp
  have h : env31378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31377_31378 : H12AffineEnvironment.transform 9 564 env31377 = env31378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env31377 == env31378) = true)

theorem identity31378 : scanCanonicalize (H12AffineFastState.compose env31378 (packedSelected [0,1,2,6,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound31378 : packedSelected [0,1,2,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env31379 : List Nat := [2,4,8,16,32,17,57,20,512,564,512,4096,8192,12313,561,12811,12841,560,8221,560,4096,529,544,4147,536,8200,12328,0,0,12312,8765,12297,20,16,560,8232]

theorem envBound31379 : H12AffineFastState.Bounded env31379 := by
  intro p hp
  have h : env31379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31378_31379 : H12AffineEnvironment.transform 6 57 env31378 = env31379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env31378 == env31379) = true)

theorem identity31379 : scanCanonicalize (H12AffineFastState.compose env31379 (packedSelected [1,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound31379 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env31380 : List Nat := [2,4,8,16,32,17,57,20,512,564,512,4096,4120,1,561,531,561,560,4101,560,4096,529,544,4147,536,4112,48,0,0,0,4645,17,20,16,560,4144]

theorem envBound31380 : H12AffineFastState.Bounded env31380 := by
  intro p hp
  have h : env31380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31379_31380 : H12AffineEnvironment.transform 12 4120 env31379 = env31380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env31379 == env31380) = true)

theorem identity31380 : scanCanonicalize (H12AffineFastState.compose env31380 (packedSelected [4,7] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound31380 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env31381 : List Nat := [2,4,8,16,32,17,57,20,512,564,512,560,552,1,561,531,561,560,565,560,560,529,544,515,536,544,48,0,0,0,21,17,20,16,560,512]

theorem envBound31381 : H12AffineFastState.Bounded env31381 := by
  intro p hp
  have h : env31381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31380_31381 : H12AffineEnvironment.transform 11 560 env31380 = env31381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env31380 == env31381) = true)

theorem identity31381 : scanCanonicalize (H12AffineFastState.compose env31381 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31382 : List Nat := [2,4,8,16,16,17,9,20,512,516,512,512,536,1,513,531,513,512,517,512,512,529,528,515,536,528,0,0,0,0,21,17,20,16,512,512]

theorem envBound31382 : H12AffineFastState.Bounded env31382 := by
  intro p hp
  have h : env31382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31381_31382 : H12AffineEnvironment.transform 4 16 env31381 = env31382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31381 == env31382) = true)

theorem identity31382 : scanCanonicalize (H12AffineFastState.compose env31382 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound31382 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31383 : List Nat := [2,4,8,16,16,17,9,20,26,30,26,26,2,1,27,9,27,26,31,26,26,11,10,25,2,10,0,0,0,0,21,17,20,16,26,26]

theorem envBound31383 : H12AffineFastState.Bounded env31383 := by
  intro p hp
  have h : env31383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31382_31383 : H12AffineEnvironment.transform 8 26 env31382 = env31383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env31382 == env31383) = true)

theorem identity31383 : scanCanonicalize (H12AffineFastState.compose env31383 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31383 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31384 : List Nat := [2,4,8,11,11,10,9,15,1,5,1,1,2,1,0,9,0,1,4,1,1,11,10,2,2,10,0,0,0,0,14,10,15,11,1,1]

theorem envBound31384 : H12AffineFastState.Bounded env31384 := by
  intro p hp
  have h : env31384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31383_31384 : H12AffineEnvironment.transform 3 11 env31383 = env31384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31383 == env31384) = true)

theorem identity31384 : scanCanonicalize (H12AffineFastState.compose env31384 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31385 : List Nat := [2,2,8,11,11,10,9,9,1,3,1,1,2,1,0,9,0,1,2,1,1,11,10,2,2,10,0,0,0,0,8,10,9,11,1,1]

theorem envBound31385 : H12AffineFastState.Bounded env31385 := by
  intro p hp
  have h : env31385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31384_31385 : H12AffineEnvironment.transform 1 2 env31384 = env31385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31384 == env31385) = true)

def env31386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58682,143497,20496,508155,148801,148800,96347,90426,16401,256,148816,1345,135680]

theorem envBound31386 : H12AffineFastState.Bounded env31386 := by
  intro p hp
  have h : env31386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31333_31386 : H12AffineEnvironment.transform 18 136193 env31333 = env31386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env31333 == env31386) = true)

def env31387 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143497,20496,508155,148717,148716,96347,90262,16401,172,148732,1261,135680]

theorem envBound31387 : H12AffineFastState.Bounded env31387 := by
  intro p hp
  have h : env31387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31386_31387 : H12AffineEnvironment.transform 7 172 env31386 = env31387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31386 == env31387) = true)

def env31388 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143497,20496,508075,148669,148668,96267,90262,16401,172,148652,1213,135680]

theorem envBound31388 : H12AffineFastState.Bounded env31388 := by
  intro p hp
  have h : env31388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31387_31388 : H12AffineEnvironment.transform 5 16 env31387 = env31388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31387 == env31388) = true)

theorem identity31388 : scanCanonicalize (H12AffineFastState.compose env31388 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound31388 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31389 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61569,115854,58518,111638,20496,279604,114722,114723,96267,90262,16401,172,114739,1213,104095]

theorem envBound31389 : H12AffineFastState.Bounded env31389 := by
  intro p hp
  have h : env31389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31388_31389 : H12AffineEnvironment.transform 16 99487 env31388 = env31389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env31388 == env31389) = true)

theorem identity31389 : scanCanonicalize (H12AffineFastState.compose env31389 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound31389 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env31390 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,65536,99487,262144,98342,32769,184,57401,115854,58518,107694,16552,279604,114722,114723,92339,90262,16401,172,114739,1213,99879]

theorem envBound31390 : H12AffineFastState.Bounded env31390 := by
  intro p hp
  have h : env31390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31389_31390 : H12AffineEnvironment.transform 11 184 env31389 = env31390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env31389 == env31390) = true)

theorem identity31390 : scanCanonicalize (H12AffineFastState.compose env31390 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound31390 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31391 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,33831,184,262144,1025,32769,184,57401,16553,58518,8329,16552,279604,17413,17412,60564,58545,16401,172,17428,1213,512]

theorem envBound31391 : H12AffineFastState.Bounded env31391 := by
  intro p hp
  have h : env31391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31390_31391 : H12AffineEnvironment.transform 15 33831 env31390 = env31391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env31390 == env31391) = true)

theorem identity31391 : scanCanonicalize (H12AffineFastState.compose env31391 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound31391 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31392 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33831,184,262144,1025,32769,184,42117,1045,41002,8329,1044,262280,185,184,43048,40973,1197,172,168,1213,512]

theorem envBound31392 : H12AffineFastState.Bounded env31392 := by
  intro p hp
  have h : env31392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31391_31392 : H12AffineEnvironment.transform 13 1212 env31391 = env31392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env31391 == env31392) = true)

theorem identity31392 : scanCanonicalize (H12AffineFastState.compose env31392 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound31392 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31393 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,657,1212,32768,33831,184,262144,1025,32769,184,34324,1045,33467,536,1044,262280,185,184,35513,33436,1197,172,168,1213,512]

theorem envBound31393 : H12AffineFastState.Bounded env31393 := by
  intro p hp
  have h : env31393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31392_31393 : H12AffineEnvironment.transform 12 657 env31392 = env31393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env31392 == env31393) = true)

theorem identity31393 : scanCanonicalize (H12AffineFastState.compose env31393 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 1588) := by decide +kernel

theorem selectedBound31393 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env31394 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,657,1212,1588,531,184,262144,1025,1589,184,32,1045,1167,536,1044,262280,185,184,3213,1192,1197,172,168,1213,512]

theorem envBound31394 : H12AffineFastState.Bounded env31394 := by
  intro p hp
  have h : env31394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31393_31394 : H12AffineEnvironment.transform 14 1588 env31393 = env31394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1588 env31393 == env31394) = true)

theorem identity31394 : scanCanonicalize (H12AffineFastState.compose env31394 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound31394 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31395 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,657,1212,1588,531,184,1582,1025,1589,184,32,1045,1167,536,1044,1702,185,184,3213,1192,1197,172,168,1213,512]

theorem envBound31395 : H12AffineFastState.Bounded env31395 := by
  intro p hp
  have h : env31395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31394_31395 : H12AffineEnvironment.transform 17 1582 env31394 = env31395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env31394 == env31395) = true)

theorem identity31395 : scanCanonicalize (H12AffineFastState.compose env31395 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31395 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env31396 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,184,657,185,561,531,184,555,4,560,184,32,16,138,536,17,675,185,184,2184,173,168,172,168,184,512]

theorem envBound31396 : H12AffineFastState.Bounded env31396 := by
  intro p hp
  have h : env31396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31395_31396 : H12AffineEnvironment.transform 9 5 env31395 = env31396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31395 == env31396) = true)

theorem identity31396 : scanCanonicalize (H12AffineFastState.compose env31396 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound31396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31397 : List Nat := [2,4,8,16,32,16,128,172,512,5,512,184,657,185,561,531,184,555,4,560,184,32,16,138,536,17,675,185,184,648,173,168,172,168,184,512]

theorem envBound31397 : H12AffineFastState.Bounded env31397 := by
  intro p hp
  have h : env31397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31396_31397 : H12AffineEnvironment.transform 10 512 env31396 = env31397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env31396 == env31397) = true)

theorem identity31397 : scanCanonicalize (H12AffineFastState.compose env31397 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound31397 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31398 : List Nat := [2,4,8,16,32,16,56,20,512,5,512,0,553,1,561,531,0,555,4,560,0,32,16,50,536,17,539,1,0,560,21,16,20,16,0,512]

theorem envBound31398 : H12AffineFastState.Bounded env31398 := by
  intro p hp
  have h : env31398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31397_31398 : H12AffineEnvironment.transform 6 56 env31397 = env31398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env31397 == env31398) = true)

theorem identity31398 : scanCanonicalize (H12AffineFastState.compose env31398 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31399 : List Nat := [2,4,5,16,32,16,53,20,512,5,512,0,548,1,561,531,0,550,4,560,0,32,16,50,533,17,534,1,0,560,21,16,20,16,0,512]

theorem envBound31399 : H12AffineFastState.Bounded env31399 := by
  intro p hp
  have h : env31399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31398_31399 : H12AffineEnvironment.transform 2 5 env31398 = env31399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31398 == env31399) = true)

theorem identity31399 : scanCanonicalize (H12AffineFastState.compose env31399 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31400 : List Nat := [2,4,5,16,32,16,53,20,0,5,0,0,36,1,49,19,0,38,4,48,0,32,16,50,21,17,22,1,0,48,21,16,20,16,0,0]

theorem envBound31400 : H12AffineFastState.Bounded env31400 := by
  intro p hp
  have h : env31400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31399_31400 : H12AffineEnvironment.transform 8 0 env31399 = env31400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31399 == env31400) = true)

theorem identity31400 : scanCanonicalize (H12AffineFastState.compose env31400 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31400 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31401 : List Nat := [2,4,5,6,32,6,35,2,0,5,0,0,36,1,39,5,0,38,4,38,0,32,6,36,3,7,0,1,0,38,3,6,2,6,0,0]

theorem envBound31401 : H12AffineFastState.Bounded env31401 := by
  intro p hp
  have h : env31401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31400_31401 : H12AffineEnvironment.transform 3 6 env31400 = env31401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31400 == env31401) = true)

def env31402 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143497,20496,508074,148668,148669,96266,90262,16401,172,148653,1212,135680]

theorem envBound31402 : H12AffineFastState.Bounded env31402 := by
  intro p hp
  have h : env31402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31387_31402 : H12AffineEnvironment.transform 5 17 env31387 = env31402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31387 == env31402) = true)

theorem identity31402 : scanCanonicalize (H12AffineFastState.compose env31402 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound31402 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31403 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61568,147472,58518,143497,20496,60444,148668,148669,96266,90262,16401,172,148653,1212,135680]

theorem envBound31403 : H12AffineFastState.Bounded env31403 := by
  intro p hp
  have h : env31403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31402_31403 : H12AffineEnvironment.transform 17 208054 env31402 = env31403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env31402 == env31403) = true)

theorem identity31403 : scanCanonicalize (H12AffineFastState.compose env31403 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound31403 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env31404 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4096,61568,147472,58518,143497,20496,60444,148668,148669,43048,45236,16401,172,148653,1212,135680]

theorem envBound31404 : H12AffineFastState.Bounded env31404 := by
  intro p hp
  have h : env31404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31403_31404 : H12AffineEnvironment.transform 15 53282 env31403 = env31404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env31403 == env31404) = true)

theorem identity31404 : scanCanonicalize (H12AffineFastState.compose env31404 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound31404 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31405 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4096,61568,5292,58518,25653,20496,60444,4096,4097,43048,45236,16401,172,4113,1212,18108]

theorem envBound31405 : H12AffineFastState.Bounded env31405 := by
  intro p hp
  have h : env31405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31404_31405 : H12AffineEnvironment.transform 16 21692 env31404 = env31405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env31404 == env31405) = true)

theorem identity31405 : scanCanonicalize (H12AffineFastState.compose env31405 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound31405 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env31406 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5125,32768,33831,185,43048,5304,32769,4096,42117,5292,45203,12336,1045,47129,4096,4097,43048,45236,5140,172,4113,1212,4793]

theorem envBound31406 : H12AffineFastState.Bounded env31406 := by
  intro p hp
  have h : env31406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31405_31406 : H12AffineEnvironment.transform 13 5125 env31405 = env31406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env31405 == env31406) = true)

theorem identity31406 : scanCanonicalize (H12AffineFastState.compose env31406 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound31406 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31407 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5125,1540,547,185,11820,5304,1541,4096,8833,5292,13975,12336,1045,15901,4096,4097,11820,14000,5140,172,4113,1212,4793]

theorem envBound31407 : H12AffineFastState.Bounded env31407 := by
  intro p hp
  have h : env31407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31406_31407 : H12AffineEnvironment.transform 14 1540 env31406 = env31407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env31406 == env31407) = true)

theorem identity31407 : scanCanonicalize (H12AffineFastState.compose env31407 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound31407 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env31408 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2090,8192,3119,1540,547,185,11820,3218,1541,2090,8833,3206,11965,10266,1045,9783,2090,2091,11820,11930,3134,172,2107,1212,2707]

theorem envBound31408 : H12AffineFastState.Bounded env31408 := by
  intro p hp
  have h : env31408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31407_31408 : H12AffineEnvironment.transform 11 2090 env31407 = env31408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env31407 == env31408) = true)

theorem identity31408 : scanCanonicalize (H12AffineFastState.compose env31408 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound31408 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env31409 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2090,1684,3119,1540,547,185,2232,3218,1541,2090,1045,3206,2089,3726,1045,163,2090,2091,2232,2062,3134,172,2107,1212,2707]

theorem envBound31409 : H12AffineFastState.Bounded env31409 := by
  intro p hp
  have h : env31409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31408_31409 : H12AffineEnvironment.transform 12 1684 env31408 = env31409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env31408 == env31409) = true)

theorem identity31409 : scanCanonicalize (H12AffineFastState.compose env31409 (packedSelected [1,2,4,6,7,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31409 : packedSelected [1,2,4,6,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env31410 : List Nat := [2,4,8,16,10,17,128,134,512,1024,2048,2048,1684,3077,1540,521,147,2194,3218,1541,2048,1045,3206,2051,3726,1045,137,2048,2049,2194,2062,3092,134,2065,1174,2707]

theorem envBound31410 : H12AffineFastState.Bounded env31410 := by
  intro p hp
  have h : env31410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31409_31410 : H12AffineEnvironment.transform 4 10 env31409 = env31410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31409 == env31410) = true)

theorem identity31410 : scanCanonicalize (H12AffineFastState.compose env31410 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31410 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env31411 : List Nat := [2,4,8,16,10,17,9,15,512,1024,2048,2048,1565,3077,1540,521,26,2075,3099,1541,2048,1045,3087,2051,3591,1045,0,2048,2049,2075,2062,3092,15,2065,1055,2586]

theorem envBound31411 : H12AffineFastState.Bounded env31411 := by
  intro p hp
  have h : env31411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31410_31411 : H12AffineEnvironment.transform 6 9 env31410 = env31411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31410 == env31411) = true)

theorem identity31411 : scanCanonicalize (H12AffineFastState.compose env31411 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound31411 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31412 : List Nat := [2,4,8,16,10,17,9,15,512,1024,1566,1566,1565,539,1540,521,26,1541,517,1541,1566,1045,529,1565,25,1045,0,1566,1567,1541,1552,522,15,1551,1055,1028]

theorem envBound31412 : H12AffineFastState.Bounded env31412 := by
  intro p hp
  have h : env31412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31411_31412 : H12AffineEnvironment.transform 10 1566 env31411 = env31412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env31411 == env31412) = true)

theorem identity31412 : scanCanonicalize (H12AffineFastState.compose env31412 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31412 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31413 : List Nat := [2,4,8,16,10,17,9,15,0,1024,1054,1054,1053,27,1028,9,26,1029,5,1029,1054,1045,17,1053,25,1045,0,1054,1055,1029,1040,10,15,1039,1055,1028]

theorem envBound31413 : H12AffineFastState.Bounded env31413 := by
  intro p hp
  have h : env31413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31412_31413 : H12AffineEnvironment.transform 8 0 env31412 = env31413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31412 == env31413) = true)

theorem identity31413 : scanCanonicalize (H12AffineFastState.compose env31413 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound31413 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31414 : List Nat := [2,4,8,16,10,17,9,15,0,30,0,0,3,27,26,9,26,27,5,27,0,11,17,3,25,11,0,0,1,27,14,10,15,17,1,26]

theorem envBound31414 : H12AffineFastState.Bounded env31414 := by
  intro p hp
  have h : env31414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31413_31414 : H12AffineEnvironment.transform 9 30 env31413 = env31414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env31413 == env31414) = true)

theorem identity31414 : scanCanonicalize (H12AffineFastState.compose env31414 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31415 : List Nat := [2,4,8,7,10,6,9,15,0,9,0,0,3,12,13,9,13,12,5,12,0,11,6,3,14,11,0,0,1,12,14,10,15,6,1,13]

theorem envBound31415 : H12AffineFastState.Bounded env31415 := by
  intro p hp
  have h : env31415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31414_31415 : H12AffineEnvironment.transform 3 7 env31414 = env31415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31414 == env31415) = true)

theorem identity31415 : scanCanonicalize (H12AffineFastState.compose env31415 (packedSelected [0,4,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31415 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env31416 : List Nat := [2,4,5,7,7,6,4,2,0,4,0,0,3,1,0,4,0,1,5,1,0,6,6,3,3,6,0,0,1,1,3,7,2,6,1,0]

theorem envBound31416 : H12AffineFastState.Bounded env31416 := by
  intro p hp
  have h : env31416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31415_31416 : H12AffineEnvironment.transform 2 5 env31415 = env31416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31415 == env31416) = true)

def env31417 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143497,20496,508155,148716,148717,96347,90263,16401,173,148733,1260,135680]

theorem envBound31417 : H12AffineFastState.Bounded env31417 := by
  intro p hp
  have h : env31417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31386_31417 : H12AffineEnvironment.transform 7 173 env31386 = env31417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31386 == env31417) = true)

def env31418 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143497,20496,508075,148668,148669,96267,90263,16401,173,148653,1212,135680]

theorem envBound31418 : H12AffineFastState.Bounded env31418 := by
  intro p hp
  have h : env31418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31417_31418 : H12AffineEnvironment.transform 5 16 env31417 = env31418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31417 == env31418) = true)

theorem identity31418 : scanCanonicalize (H12AffineFastState.compose env31418 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound31418 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31419 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,58519,32809,20496,356363,62492,62493,96267,90263,16401,173,62477,1212,41632]

theorem envBound31419 : H12AffineFastState.Bounded env31419 := by
  intro p hp
  have h : env31419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31418_31419 : H12AffineEnvironment.transform 16 45216 env31418 = env31419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env31418 == env31419) = true)

theorem identity31419 : scanCanonicalize (H12AffineFastState.compose env31419 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound31419 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31420 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4096,61569,61617,58519,32809,20496,96386,62492,62493,96267,90263,16401,173,62477,1212,41632]

theorem envBound31420 : H12AffineFastState.Bounded env31420 := by
  intro p hp
  have h : env31420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31419_31420 : H12AffineEnvironment.transform 17 2185 env31419 = env31420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env31419 == env31420) = true)

theorem identity31420 : scanCanonicalize (H12AffineFastState.compose env31420 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound31420 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31421 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,65536,17413,2185,20484,29860,4096,1060,1044,4146,29836,20496,96386,185,184,96267,90263,16401,173,168,1212,22021]

theorem envBound31421 : H12AffineFastState.Bounded env31421 := by
  intro p hp
  have h : env31421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31420_31421 : H12AffineEnvironment.transform 14 29861 env31420 = env31421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env31420 == env31421) = true)

theorem identity31421 : scanCanonicalize (H12AffineFastState.compose env31421 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound31421 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env31422 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,13375,17413,2185,20484,29860,4096,1060,1044,4146,29836,20496,19645,185,184,19508,21672,16401,173,168,1212,22021]

theorem envBound31422 : H12AffineFastState.Bounded env31422 := by
  intro p hp
  have h : env31422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31421_31422 : H12AffineEnvironment.transform 15 13375 env31421 = env31422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env31421 == env31422) = true)

theorem identity31422 : scanCanonicalize (H12AffineFastState.compose env31422 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10912) := by decide +kernel

theorem selectedBound31422 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env31423 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,10912,7685,13375,11941,2185,15012,7684,4096,1060,1044,4146,7724,15024,9757,185,184,9876,15880,10929,173,168,1212,15525]

theorem envBound31423 : H12AffineFastState.Bounded env31423 := by
  intro p hp
  have h : env31423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31422_31423 : H12AffineEnvironment.transform 13 10912 env31422 = env31423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10912 env31422 == env31423) = true)

theorem identity31423 : scanCanonicalize (H12AffineFastState.compose env31423 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound31423 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31424 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2745,8192,10912,1212,11910,11941,2185,8221,1213,2745,1060,1044,2699,1173,8201,9757,185,184,9876,9393,10929,173,168,1212,9756]

theorem envBound31424 : H12AffineFastState.Bounded env31424 := by
  intro p hp
  have h : env31424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31423_31424 : H12AffineEnvironment.transform 11 2745 env31423 = env31424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env31423 == env31424) = true)

theorem identity31424 : scanCanonicalize (H12AffineFastState.compose env31424 (packedSelected [2,3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound31424 : packedSelected [2,3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31425 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2745,2562,162,1212,1156,1191,2185,2591,1213,2745,1060,1044,2699,1173,2571,3103,185,184,3222,3763,179,173,168,1212,3102]

theorem envBound31425 : H12AffineFastState.Bounded env31425 := by
  intro p hp
  have h : env31425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31424_31425 : H12AffineEnvironment.transform 12 2562 env31424 = env31425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env31424 == env31425) = true)

end H12CloudChart2