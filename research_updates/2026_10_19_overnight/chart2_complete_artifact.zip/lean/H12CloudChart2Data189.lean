import H12CloudChart2Data188

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity47461 : scanCanonicalize (H12AffineFastState.compose env47461 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47461 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47462 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,773,24,1,277,35,276,163,533,276,772,649,261,50,917,513,319,277,1,2869,21,261,256,16,1,260]

theorem envBound47462 : H12AffineFastState.Bounded env47462 := by
  intro p hp
  have h : env47462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47461_47462 : H12AffineEnvironment.transform 5 16 env47461 = env47462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47461 == env47462) = true)

theorem identity47462 : scanCanonicalize (H12AffineFastState.compose env47462 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 939) := by decide +kernel

theorem selectedBound47462 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env47463 : List Nat := [2,4,8,16,32,16,128,256,512,272,939,773,24,1,277,35,276,163,533,276,772,649,261,50,917,513,319,277,1,158,21,261,256,16,1,260]

theorem envBound47463 : H12AffineFastState.Bounded env47463 := by
  intro p hp
  have h : env47463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47462_47463 : H12AffineEnvironment.transform 10 939 env47462 = env47463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 939 env47462 == env47463) = true)

theorem identity47463 : scanCanonicalize (H12AffineFastState.compose env47463 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound47463 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47464 : List Nat := [2,4,8,16,32,16,128,256,146,272,313,407,24,1,277,35,276,163,135,276,406,27,261,50,263,147,319,277,1,158,21,261,256,16,1,260]

theorem envBound47464 : H12AffineFastState.Bounded env47464 := by
  intro p hp
  have h : env47464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47463_47464 : H12AffineEnvironment.transform 8 146 env47463 = env47464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env47463 == env47464) = true)

theorem identity47464 : scanCanonicalize (H12AffineFastState.compose env47464 (packedSelected [0,4,5,7,9,10,11,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound47464 : packedSelected [0,4,5,7,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env47465 : List Nat := [2,4,8,16,32,16,52,256,38,272,313,291,24,1,277,35,276,23,51,276,290,27,261,50,263,39,319,277,1,42,21,261,256,16,1,260]

theorem envBound47465 : H12AffineFastState.Bounded env47465 := by
  intro p hp
  have h : env47465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47464_47465 : H12AffineEnvironment.transform 6 52 env47464 = env47465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env47464 == env47465) = true)

theorem identity47465 : scanCanonicalize (H12AffineFastState.compose env47465 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47465 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env47466 : List Nat := [2,4,8,16,13,16,25,256,11,272,276,270,24,1,277,14,276,23,30,276,271,27,261,31,263,10,274,277,1,7,21,261,256,16,1,260]

theorem envBound47466 : H12AffineFastState.Bounded env47466 := by
  intro p hp
  have h : env47466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47465_47466 : H12AffineEnvironment.transform 4 13 env47465 = env47466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47465 == env47466) = true)

theorem identity47466 : scanCanonicalize (H12AffineFastState.compose env47466 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound47466 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env47467 : List Nat := [2,4,8,16,13,16,25,9,11,25,29,7,24,1,28,14,29,23,30,29,6,27,12,31,14,10,27,28,1,7,21,12,9,16,1,13]

theorem envBound47467 : H12AffineFastState.Bounded env47467 := by
  intro p hp
  have h : env47467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47466_47467 : H12AffineEnvironment.transform 7 9 env47466 = env47467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env47466 == env47467) = true)

theorem identity47467 : scanCanonicalize (H12AffineFastState.compose env47467 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47467 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47468 : List Nat := [2,4,5,16,0,16,20,4,6,20,16,7,21,1,17,3,16,23,19,16,6,22,1,18,3,7,22,17,1,7,21,1,4,16,1,0]

theorem envBound47468 : H12AffineFastState.Bounded env47468 := by
  intro p hp
  have h : env47468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47467_47468 : H12AffineEnvironment.transform 2 5 env47467 = env47468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47467 == env47468) = true)

theorem identity47468 : scanCanonicalize (H12AffineFastState.compose env47468 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47468 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47469 : List Nat := [2,4,5,7,0,7,3,4,6,3,7,7,2,1,6,3,7,0,4,7,6,1,1,5,3,7,1,6,1,7,2,1,4,7,1,0]

theorem envBound47469 : H12AffineFastState.Bounded env47469 := by
  intro p hp
  have h : env47469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47468_47469 : H12AffineEnvironment.transform 3 7 env47468 = env47469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47468 == env47469) = true)

def env47470 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,80,277,65536,65894,65664,532,276,853,649,65910,65552,917,66162,318,65847,80,68374,69,65831,256,64,0,340]

theorem envBound47470 : H12AffineFastState.Bounded env47470 := by
  intro p hp
  have h : env47470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47459_47470 : H12AffineEnvironment.transform 9 321 env47459 = env47470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47459 == env47470) = true)

theorem identity47470 : scanCanonicalize (H12AffineFastState.compose env47470 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound47470 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47471 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,80,277,807,577,935,532,276,853,649,593,823,917,341,318,528,80,2097,69,512,256,64,0,340]

theorem envBound47471 : H12AffineFastState.Bounded env47471 := by
  intro p hp
  have h : env47471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47470_47471 : H12AffineEnvironment.transform 15 807 env47470 = env47471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env47470 == env47471) = true)

theorem identity47471 : scanCanonicalize (H12AffineFastState.compose env47471 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47471 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47472 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,577,72,80,0,562,577,690,532,1,576,649,593,546,640,64,43,528,80,2097,69,512,21,64,0,65]

theorem envBound47472 : H12AffineFastState.Bounded env47472 := by
  intro p hp
  have h : env47472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47471_47472 : H12AffineEnvironment.transform 7 21 env47471 = env47472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47471 == env47472) = true)

theorem identity47472 : scanCanonicalize (H12AffineFastState.compose env47472 (packedSelected [2,3,4,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound47472 : packedSelected [2,3,4,9,10,16] rootPS < 2^1333 := by decide +kernel

def env47473 : List Nat := [2,4,8,16,32,64,128,21,512,84,22,577,72,80,0,562,577,690,532,1,576,649,593,546,640,64,43,528,80,39,69,512,21,64,0,65]

theorem envBound47473 : H12AffineFastState.Bounded env47473 := by
  intro p hp
  have h : env47473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47472_47473 : H12AffineEnvironment.transform 10 22 env47472 = env47473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env47472 == env47473) = true)

theorem identity47473 : scanCanonicalize (H12AffineFastState.compose env47473 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound47473 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env47474 : List Nat := [2,4,8,16,32,64,128,21,49,84,22,112,72,80,0,3,112,131,37,1,113,184,96,19,177,64,43,33,80,39,69,49,21,64,0,65]

theorem envBound47474 : H12AffineFastState.Bounded env47474 := by
  intro p hp
  have h : env47474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47473_47474 : H12AffineEnvironment.transform 8 49 env47473 = env47474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47473 == env47474) = true)

theorem identity47474 : scanCanonicalize (H12AffineFastState.compose env47474 (packedSelected [0,1,2,5,7,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 126) := by decide +kernel

theorem selectedBound47474 : packedSelected [0,1,2,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env47475 : List Nat := [2,4,8,16,32,64,126,21,49,84,22,112,72,80,0,3,112,125,37,1,113,70,96,19,79,64,43,33,80,39,69,49,21,64,0,65]

theorem envBound47475 : H12AffineFastState.Bounded env47475 := by
  intro p hp
  have h : env47475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47474_47475 : H12AffineEnvironment.transform 6 126 env47474 = env47475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 126 env47474 == env47475) = true)

theorem identity47475 : scanCanonicalize (H12AffineFastState.compose env47475 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47475 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47476 : List Nat := [2,4,8,16,1,64,95,21,16,84,22,81,72,80,0,3,81,92,4,1,80,70,65,19,79,64,10,0,80,6,69,16,21,64,0,65]

theorem envBound47476 : H12AffineFastState.Bounded env47476 := by
  intro p hp
  have h : env47476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47475_47476 : H12AffineEnvironment.transform 4 1 env47475 = env47476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47475 == env47476) = true)

theorem identity47476 : scanCanonicalize (H12AffineFastState.compose env47476 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound47476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47477 : List Nat := [2,4,8,16,1,27,4,21,16,15,22,10,19,11,0,3,10,7,4,1,11,29,26,19,20,27,10,0,11,6,30,16,21,27,0,26]

theorem envBound47477 : H12AffineFastState.Bounded env47477 := by
  intro p hp
  have h : env47477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47476_47477 : H12AffineEnvironment.transform 5 27 env47476 = env47477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env47476 == env47477) = true)

theorem identity47477 : scanCanonicalize (H12AffineFastState.compose env47477 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47477 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47478 : List Nat := [2,2,8,16,1,27,2,19,16,9,16,10,19,11,0,3,10,1,2,1,11,27,26,19,18,27,10,0,11,0,24,16,19,27,0,26]

theorem envBound47478 : H12AffineFastState.Bounded env47478 := by
  intro p hp
  have h : env47478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47477_47478 : H12AffineEnvironment.transform 1 2 env47477 = env47478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47477 == env47478) = true)

theorem identity47478 : scanCanonicalize (H12AffineFastState.compose env47478 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47478 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47479 : List Nat := [2,2,8,10,1,1,2,9,10,9,10,10,9,11,0,3,10,1,2,1,11,1,0,9,8,1,10,0,11,0,2,10,9,1,0,0]

theorem envBound47479 : H12AffineFastState.Bounded env47479 := by
  intro p hp
  have h : env47479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47478_47479 : H12AffineEnvironment.transform 3 10 env47478 = env47479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47478 == env47479) = true)

theorem identity47479 : scanCanonicalize (H12AffineFastState.compose env47479 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47479 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47480 : List Nat := [2,2,3,1,1,1,2,2,1,2,1,1,2,0,0,3,1,1,2,1,0,1,0,2,3,1,1,0,0,0,2,1,2,1,0,0]

theorem envBound47480 : H12AffineFastState.Bounded env47480 := by
  intro p hp
  have h : env47480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47479_47480 : H12AffineEnvironment.transform 2 3 env47479 = env47480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47479 == env47480) = true)

theorem identity47480 : scanCanonicalize (H12AffineFastState.compose env47480 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47481 : List Nat := [0,0,1,1,1,1,0,0,1,0,1,1,0,0,0,1,1,1,0,1,0,1,0,0,1,1,1,0,0,0,0,1,0,1,0,0]

theorem envBound47481 : H12AffineFastState.Bounded env47481 := by
  intro p hp
  have h : env47481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47480_47481 : H12AffineEnvironment.transform 0 0 env47480 = env47481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47480 == env47481) = true)

def env47482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4097,5276,74046,66897,13768,78895,1150,74814,1297,81227,8205,74798,256,8200,1345,5953]

theorem envBound47482 : H12AffineFastState.Bounded env47482 := by
  intro p hp
  have h : env47482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47434_47482 : H12AffineEnvironment.transform 17 65665 env47434 = env47482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47434 == env47482) = true)

theorem identity47482 : scanCanonicalize (H12AffineFastState.compose env47482 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound47482 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,65536,69991,65665,4416,5204,4097,5276,70710,66897,192,65831,1150,69942,1297,67651,5381,69926,256,5376,1345,5953]

theorem envBound47483 : H12AffineFastState.Bounded env47483 := by
  intro p hp
  have h : env47483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47482_47483 : H12AffineEnvironment.transform 12 5384 env47482 = env47483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env47482 == env47483) = true)

def env47484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1297,577,65536,67443,65665,1876,576,1557,648,66082,66897,192,65831,1150,67362,1297,67651,785,67378,256,788,1345,341]

theorem envBound47484 : H12AffineFastState.Bounded env47484 := by
  intro p hp
  have h : env47484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47483_47484 : H12AffineEnvironment.transform 11 1556 env47483 = env47484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env47483 == env47484) = true)

def env47485 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,65536,66083,65665,516,576,837,648,66082,65537,192,65831,302,66162,65,67651,785,66146,256,788,17,341]

theorem envBound47485 : H12AffineFastState.Bounded env47485 := by
  intro p hp
  have h : env47485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47484_47485 : H12AffineEnvironment.transform 9 336 env47484 = env47485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env47484 == env47485) = true)

theorem identity47485 : scanCanonicalize (H12AffineFastState.compose env47485 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 580) := by decide +kernel

theorem selectedBound47485 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47486 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,580,103,709,516,576,837,648,102,581,192,867,302,54,65,2567,785,38,256,788,17,341]

theorem envBound47486 : H12AffineFastState.Bounded env47486 := by
  intro p hp
  have h : env47486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47485_47486 : H12AffineEnvironment.transform 15 580 env47485 = env47486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 580 env47485 == env47486) = true)

def env47487 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,780,65,577,580,103,709,516,576,837,648,102,581,192,867,302,38,65,2567,769,38,256,772,1,325]

theorem envBound47487 : H12AffineFastState.Bounded env47487 := by
  intro p hp
  have h : env47487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47486_47487 : H12AffineEnvironment.transform 3 0 env47486 = env47487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47486 == env47487) = true)

theorem identity47487 : scanCanonicalize (H12AffineFastState.compose env47487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound47487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47488 : List Nat := [2,4,8,0,32,64,128,256,39,320,2048,355,299,65,102,99,103,226,35,103,354,175,102,98,192,324,302,38,65,2080,294,38,256,291,1,325]

theorem envBound47488 : H12AffineFastState.Bounded env47488 := by
  intro p hp
  have h : env47488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47487_47488 : H12AffineEnvironment.transform 8 39 env47487 = env47488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env47487 == env47488) = true)

theorem identity47488 : scanCanonicalize (H12AffineFastState.compose env47488 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 197) := by decide +kernel

theorem selectedBound47488 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47489 : List Nat := [2,4,8,0,32,64,128,256,39,320,197,355,299,65,102,99,103,226,35,103,354,175,102,98,192,324,302,38,65,229,294,38,256,291,1,325]

theorem envBound47489 : H12AffineFastState.Bounded env47489 := by
  intro p hp
  have h : env47489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47488_47489 : H12AffineEnvironment.transform 10 197 env47488 = env47489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 197 env47488 == env47489) = true)

theorem identity47489 : scanCanonicalize (H12AffineFastState.compose env47489 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47489 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47490 : List Nat := [2,4,8,0,32,0,128,256,39,256,133,291,299,1,38,35,39,162,35,39,290,175,38,34,128,260,302,38,1,165,294,38,256,291,1,261]

theorem envBound47490 : H12AffineFastState.Bounded env47490 := by
  intro p hp
  have h : env47490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47489_47490 : H12AffineEnvironment.transform 5 0 env47489 = env47490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47489 == env47490) = true)

theorem identity47490 : scanCanonicalize (H12AffineFastState.compose env47490 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound47490 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47491 : List Nat := [2,4,8,0,32,0,34,256,39,256,39,291,299,1,38,35,39,0,35,39,290,13,38,34,34,260,302,38,1,7,294,38,256,291,1,261]

theorem envBound47491 : H12AffineFastState.Bounded env47491 := by
  intro p hp
  have h : env47491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47490_47491 : H12AffineEnvironment.transform 6 34 env47490 = env47491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env47490 == env47491) = true)

theorem identity47491 : scanCanonicalize (H12AffineFastState.compose env47491 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47492 : List Nat := [2,4,4,0,32,0,34,256,39,256,39,291,295,1,38,35,39,0,35,39,290,1,38,34,34,260,290,38,1,7,294,38,256,291,1,261]

theorem envBound47492 : H12AffineFastState.Bounded env47492 := by
  intro p hp
  have h : env47492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47491_47492 : H12AffineEnvironment.transform 2 4 env47491 = env47492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47491 == env47492) = true)

theorem identity47492 : scanCanonicalize (H12AffineFastState.compose env47492 (packedSelected [0,1,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47492 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env47493 : List Nat := [2,4,4,0,32,0,34,37,39,37,39,6,2,1,38,35,39,0,35,39,7,1,38,34,34,33,7,38,1,7,3,38,37,6,1,32]

theorem envBound47493 : H12AffineFastState.Bounded env47493 := by
  intro p hp
  have h : env47493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47492_47493 : H12AffineEnvironment.transform 7 37 env47492 = env47493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47492 == env47493) = true)

theorem identity47493 : scanCanonicalize (H12AffineFastState.compose env47493 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47493 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47494 : List Nat := [2,4,4,0,7,0,5,2,0,2,0,6,2,1,1,4,0,0,4,0,7,1,1,5,5,6,7,1,1,7,3,1,2,6,1,7]

theorem envBound47494 : H12AffineFastState.Bounded env47494 := by
  intro p hp
  have h : env47494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47493_47494 : H12AffineEnvironment.transform 4 7 env47493 = env47494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47493 == env47494) = true)

theorem identity47494 : scanCanonicalize (H12AffineFastState.compose env47494 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47495 : List Nat := [2,3,3,0,0,0,2,2,0,2,0,1,2,1,1,3,0,0,3,0,0,1,1,2,2,1,0,1,1,0,3,1,2,1,1,0]

theorem envBound47495 : H12AffineFastState.Bounded env47495 := by
  intro p hp
  have h : env47495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47494_47495 : H12AffineEnvironment.transform 1 3 env47494 = env47495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47494 == env47495) = true)

def env47496 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,781,65,577,580,103,709,516,576,837,648,102,581,192,867,302,39,65,2567,768,38,256,773,0,324]

theorem envBound47496 : H12AffineFastState.Bounded env47496 := by
  intro p hp
  have h : env47496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47486_47496 : H12AffineEnvironment.transform 3 1 env47486 = env47496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47486 == env47496) = true)

theorem identity47496 : scanCanonicalize (H12AffineFastState.compose env47496 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound47496 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47497 : List Nat := [2,4,8,1,32,64,128,98,512,35,2048,550,623,65,577,580,103,709,516,576,551,648,102,581,192,513,76,39,65,2567,610,38,98,615,0,38]

theorem envBound47497 : H12AffineFastState.Bounded env47497 := by
  intro p hp
  have h : env47497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47496_47497 : H12AffineEnvironment.transform 7 98 env47496 = env47497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env47496 == env47497) = true)

theorem identity47497 : scanCanonicalize (H12AffineFastState.compose env47497 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 621) := by decide +kernel

theorem selectedBound47497 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47498 : List Nat := [2,4,8,1,32,64,128,98,512,35,621,550,623,65,577,580,103,709,516,576,551,648,102,581,192,513,76,39,65,106,610,38,98,615,0,38]

theorem envBound47498 : H12AffineFastState.Bounded env47498 := by
  intro p hp
  have h : env47498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47497_47498 : H12AffineEnvironment.transform 10 621 env47497 = env47498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 621 env47497 == env47498) = true)

theorem identity47498 : scanCanonicalize (H12AffineFastState.compose env47498 (packedSelected [1,2,4,9,11,15,16,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound47498 : packedSelected [1,2,4,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47499 : List Nat := [2,4,8,1,32,64,128,98,133,35,232,163,234,65,196,193,103,64,129,197,162,13,102,192,192,132,76,39,65,106,231,38,98,226,0,38]

theorem envBound47499 : H12AffineFastState.Bounded env47499 := by
  intro p hp
  have h : env47499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47498_47499 : H12AffineEnvironment.transform 8 133 env47498 = env47499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env47498 == env47499) = true)

theorem identity47499 : scanCanonicalize (H12AffineFastState.compose env47499 (packedSelected [0,2,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound47499 : packedSelected [0,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env47500 : List Nat := [2,4,8,1,32,38,128,4,133,35,142,163,140,39,162,167,1,38,129,163,162,13,0,166,166,132,42,39,39,12,129,38,4,132,0,38]

theorem envBound47500 : H12AffineFastState.Bounded env47500 := by
  intro p hp
  have h : env47500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47499_47500 : H12AffineEnvironment.transform 5 38 env47499 = env47500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env47499 == env47500) = true)

theorem identity47500 : scanCanonicalize (H12AffineFastState.compose env47500 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound47500 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47501 : List Nat := [2,4,8,1,32,38,40,4,45,35,38,11,36,39,10,15,1,38,41,11,10,13,0,14,14,44,42,39,39,12,41,38,4,44,0,38]

theorem envBound47501 : H12AffineFastState.Bounded env47501 := by
  intro p hp
  have h : env47501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47500_47501 : H12AffineEnvironment.transform 6 40 env47500 = env47501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env47500 == env47501) = true)

theorem identity47501 : scanCanonicalize (H12AffineFastState.compose env47501 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound47501 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47502 : List Nat := [2,4,8,1,11,13,3,4,6,8,13,11,15,12,10,15,1,13,2,11,10,13,0,14,14,7,1,12,12,12,2,13,4,7,0,13]

theorem envBound47502 : H12AffineFastState.Bounded env47502 := by
  intro p hp
  have h : env47502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47501_47502 : H12AffineEnvironment.transform 4 11 env47501 = env47502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env47501 == env47502) = true)

theorem identity47502 : scanCanonicalize (H12AffineFastState.compose env47502 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47503 : List Nat := [2,2,8,1,11,11,3,2,0,8,11,11,9,10,10,9,1,11,2,11,10,11,0,8,8,1,1,10,10,10,2,11,2,1,0,11]

theorem envBound47503 : H12AffineFastState.Bounded env47503 := by
  intro p hp
  have h : env47503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47502_47503 : H12AffineEnvironment.transform 1 2 env47502 = env47503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47502 == env47503) = true)

theorem identity47503 : scanCanonicalize (H12AffineFastState.compose env47503 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47504 : List Nat := [2,2,3,1,0,0,3,2,0,3,0,0,2,1,1,2,1,0,2,0,1,0,0,3,3,1,1,1,1,1,2,0,2,1,0,0]

theorem envBound47504 : H12AffineFastState.Bounded env47504 := by
  intro p hp
  have h : env47504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47503_47504 : H12AffineEnvironment.transform 2 3 env47503 = env47504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47503 == env47504) = true)

def env47505 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,65536,66082,65665,517,576,836,648,66082,65536,192,65831,303,66163,64,67651,785,66147,256,788,16,341]

theorem envBound47505 : H12AffineFastState.Bounded env47505 := by
  intro p hp
  have h : env47505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47484_47505 : H12AffineEnvironment.transform 9 337 env47484 = env47505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env47484 == env47505) = true)

theorem identity47505 : scanCanonicalize (H12AffineFastState.compose env47505 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 257) := by decide +kernel

theorem selectedBound47505 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47506 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,257,803,384,517,576,836,648,803,257,192,38,303,882,64,2370,785,866,256,788,16,341]

theorem envBound47506 : H12AffineFastState.Bounded env47506 := by
  intro p hp
  have h : env47506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47505_47506 : H12AffineEnvironment.transform 15 257 env47505 = env47506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env47505 == env47506) = true)

def env47507 : List Nat := [2,4,8,16,32,64,128,256,324,337,2048,1,88,64,261,257,103,384,321,260,0,460,103,257,192,38,303,54,64,2370,85,38,256,80,16,341]

theorem envBound47507 : H12AffineFastState.Bounded env47507 := by
  intro p hp
  have h : env47507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47506_47507 : H12AffineEnvironment.transform 8 324 env47506 = env47507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env47506 == env47507) = true)

theorem identity47507 : scanCanonicalize (H12AffineFastState.compose env47507 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound47507 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47508 : List Nat := [2,4,8,16,32,64,128,99,39,50,2048,1,88,64,102,98,103,227,34,103,0,175,103,98,192,38,76,54,64,2081,85,38,99,80,16,54]

theorem envBound47508 : H12AffineFastState.Bounded env47508 := by
  intro p hp
  have h : env47508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47507_47508 : H12AffineEnvironment.transform 7 99 env47507 = env47508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env47507 == env47508) = true)

theorem identity47508 : scanCanonicalize (H12AffineFastState.compose env47508 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound47508 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47509 : List Nat := [2,4,8,16,32,38,128,5,39,50,2048,1,62,38,0,4,1,133,34,1,0,175,1,4,166,38,42,54,38,2081,51,38,5,54,16,54]

theorem envBound47509 : H12AffineFastState.Bounded env47509 := by
  intro p hp
  have h : env47509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47508_47509 : H12AffineEnvironment.transform 5 38 env47508 = env47509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env47508 == env47509) = true)

theorem identity47509 : scanCanonicalize (H12AffineFastState.compose env47509 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47509 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env47510 : List Nat := [2,4,4,16,32,38,128,5,39,50,2048,1,50,38,0,4,1,133,34,1,0,163,1,4,166,38,38,54,38,2081,51,38,5,54,16,54]

theorem envBound47510 : H12AffineFastState.Bounded env47510 := by
  intro p hp
  have h : env47510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47509_47510 : H12AffineEnvironment.transform 2 4 env47509 = env47510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47509 == env47510) = true)

theorem identity47510 : scanCanonicalize (H12AffineFastState.compose env47510 (packedSelected [1,2,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound47510 : packedSelected [1,2,5,13] rootPS < 2^1333 := by decide +kernel

def env47511 : List Nat := [2,4,4,16,32,38,128,5,39,50,165,1,50,38,0,4,1,133,34,1,0,163,1,4,166,38,38,54,38,132,51,38,5,54,16,54]

theorem envBound47511 : H12AffineFastState.Bounded env47511 := by
  intro p hp
  have h : env47511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47510_47511 : H12AffineEnvironment.transform 10 165 env47510 = env47511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env47510 == env47511) = true)

theorem identity47511 : scanCanonicalize (H12AffineFastState.compose env47511 (packedSelected [4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47511 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env47512 : List Nat := [2,3,3,16,32,33,128,2,32,50,162,1,50,33,0,3,1,130,34,1,0,163,1,3,161,33,33,49,33,131,51,33,2,49,16,49]

theorem envBound47512 : H12AffineFastState.Bounded env47512 := by
  intro p hp
  have h : env47512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47511_47512 : H12AffineEnvironment.transform 1 3 env47511 = env47512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47511 == env47512) = true)

def env47513 : List Nat := [2,4,8,16,32,64,128,256,325,337,2048,0,89,64,260,257,102,384,320,261,1,461,102,257,192,38,303,55,64,2370,84,39,256,81,16,341]

theorem envBound47513 : H12AffineFastState.Bounded env47513 := by
  intro p hp
  have h : env47513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47506_47513 : H12AffineEnvironment.transform 8 325 env47506 = env47513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env47506 == env47513) = true)

theorem identity47513 : scanCanonicalize (H12AffineFastState.compose env47513 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 114) := by decide +kernel

theorem selectedBound47513 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47514 : List Nat := [2,4,8,16,32,64,128,114,55,35,2048,0,89,64,118,115,102,242,50,119,1,191,102,115,192,38,93,55,64,2096,84,39,114,81,16,39]

theorem envBound47514 : H12AffineFastState.Bounded env47514 := by
  intro p hp
  have h : env47514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47513_47514 : H12AffineEnvironment.transform 7 114 env47513 = env47514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 114 env47513 == env47514) = true)

theorem identity47514 : scanCanonicalize (H12AffineFastState.compose env47514 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47514 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47515 : List Nat := [2,4,8,16,32,16,128,34,55,35,2048,0,9,16,38,35,54,162,50,39,1,191,54,35,144,38,13,55,16,2096,4,39,34,1,16,39]

theorem envBound47515 : H12AffineFastState.Bounded env47515 := by
  intro p hp
  have h : env47515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47514_47515 : H12AffineEnvironment.transform 5 16 env47514 = env47515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47514 == env47515) = true)

theorem identity47515 : scanCanonicalize (H12AffineFastState.compose env47515 (packedSelected [0,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound47515 : packedSelected [0,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47516 : List Nat := [2,4,8,16,32,16,128,34,55,35,6,0,9,16,38,35,54,162,50,39,1,191,54,35,144,38,13,55,16,54,4,39,34,1,16,39]

theorem envBound47516 : H12AffineFastState.Bounded env47516 := by
  intro p hp
  have h : env47516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47515_47516 : H12AffineEnvironment.transform 10 6 env47515 = env47516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env47515 == env47516) = true)

theorem identity47516 : scanCanonicalize (H12AffineFastState.compose env47516 (packedSelected [0,5,7,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47516 : packedSelected [0,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47517 : List Nat := [2,4,4,16,32,16,128,34,55,35,6,0,5,16,38,35,54,162,50,39,1,179,54,35,144,38,1,55,16,54,4,39,34,1,16,39]

theorem envBound47517 : H12AffineFastState.Bounded env47517 := by
  intro p hp
  have h : env47517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47516_47517 : H12AffineEnvironment.transform 2 4 env47516 = env47517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47516 == env47517) = true)

theorem identity47517 : scanCanonicalize (H12AffineFastState.compose env47517 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound47517 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env47518 : List Nat := [2,4,4,16,32,16,52,34,55,35,6,0,5,16,38,35,54,22,50,39,1,7,54,35,36,38,1,55,16,54,4,39,34,1,16,39]

theorem envBound47518 : H12AffineFastState.Bounded env47518 := by
  intro p hp
  have h : env47518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47517_47518 : H12AffineEnvironment.transform 6 52 env47517 = env47518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env47517 == env47518) = true)

theorem identity47518 : scanCanonicalize (H12AffineFastState.compose env47518 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound47518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47519 : List Nat := [2,4,4,16,22,16,2,20,1,21,6,0,5,16,16,21,0,22,4,17,1,7,0,21,18,16,1,1,16,0,4,17,20,1,16,17]

theorem envBound47519 : H12AffineFastState.Bounded env47519 := by
  intro p hp
  have h : env47519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47518_47519 : H12AffineEnvironment.transform 4 22 env47518 = env47519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env47518 == env47519) = true)

theorem identity47519 : scanCanonicalize (H12AffineFastState.compose env47519 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47519 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47520 : List Nat := [2,4,4,1,7,1,2,5,1,4,6,0,5,1,1,4,0,7,4,0,1,7,0,4,3,1,1,1,1,0,4,0,5,1,1,0]

theorem envBound47520 : H12AffineFastState.Bounded env47520 := by
  intro p hp
  have h : env47520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47519_47520 : H12AffineEnvironment.transform 3 1 env47519 = env47520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47519 == env47520) = true)

theorem identity47520 : scanCanonicalize (H12AffineFastState.compose env47520 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47521 : List Nat := [2,1,1,1,2,1,2,0,1,1,3,0,0,1,1,1,0,2,1,0,1,2,0,1,3,1,1,1,1,0,1,0,0,1,1,0]

theorem envBound47521 : H12AffineFastState.Bounded env47521 := by
  intro p hp
  have h : env47521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47520_47521 : H12AffineEnvironment.transform 1 1 env47520 = env47521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47520 == env47521) = true)

theorem identity47521 : scanCanonicalize (H12AffineFastState.compose env47521 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47521 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47522 : List Nat := [1,1,1,1,1,1,1,0,1,1,0,0,0,1,1,1,0,1,1,0,1,1,0,1,0,1,1,1,1,0,1,0,0,1,1,0]

theorem envBound47522 : H12AffineFastState.Bounded env47522 := by
  intro p hp
  have h : env47522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47521_47522 : H12AffineEnvironment.transform 0 1 env47521 = env47522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47521 == env47522) = true)

def env47523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1297,576,65536,67442,65665,1877,577,1556,649,66083,66897,192,65831,1150,67363,1297,67651,784,67379,256,789,1345,340]

theorem envBound47523 : H12AffineFastState.Bounded env47523 := by
  intro p hp
  have h : env47523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47483_47523 : H12AffineEnvironment.transform 11 1557 env47483 = env47523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env47483 == env47523) = true)

def env47524 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,65536,66082,65665,517,577,836,649,66083,65537,192,65831,302,66163,65,67651,784,66147,256,789,17,340]

theorem envBound47524 : H12AffineFastState.Bounded env47524 := by
  intro p hp
  have h : env47524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47523_47524 : H12AffineEnvironment.transform 9 336 env47523 = env47524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env47523 == env47524) = true)

theorem identity47524 : scanCanonicalize (H12AffineFastState.compose env47524 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound47524 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47525 : List Nat := [2,4,8,16,32,54,128,256,512,294,2048,819,797,55,566,65536,66082,65665,517,567,818,649,66083,65537,182,65831,302,66053,55,67637,784,66069,256,789,17,290]

theorem envBound47525 : H12AffineFastState.Bounded env47525 := by
  intro p hp
  have h : env47525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47524_47525 : H12AffineEnvironment.transform 5 54 env47524 = env47525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env47524 == env47525) = true)

def env47526 : List Nat := [2,4,8,16,32,54,128,256,312,294,2048,11,37,55,270,65536,65818,65665,317,271,10,433,65819,65537,182,65831,302,65853,55,67637,40,65837,256,45,17,290]

theorem envBound47526 : H12AffineFastState.Bounded env47526 := by
  intro p hp
  have h : env47526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47525_47526 : H12AffineEnvironment.transform 8 312 env47525 = env47526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 312 env47525 == env47526) = true)

theorem identity47526 : scanCanonicalize (H12AffineFastState.compose env47526 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2463) := by decide +kernel

theorem selectedBound47526 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env47527 : List Nat := [2,4,8,16,32,54,128,256,312,294,2048,11,37,55,270,2463,2181,2334,317,271,10,433,2180,2462,182,2232,302,2210,55,426,40,2226,256,45,17,290]

theorem envBound47527 : H12AffineFastState.Bounded env47527 := by
  intro p hp
  have h : env47527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47526_47527 : H12AffineEnvironment.transform 15 2463 env47526 = env47527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2463 env47526 == env47527) = true)

theorem identity47527 : scanCanonicalize (H12AffineFastState.compose env47527 (packedSelected [1,2,3,4,5,9,10,11,12,13,15,18,19,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound47527 : packedSelected [1,2,3,4,5,9,10,11,12,13,15,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env47528 : List Nat := [2,4,8,16,32,54,128,256,312,294,153,11,37,55,270,262,28,391,317,271,10,433,29,263,182,33,302,59,55,426,40,43,256,45,17,290]

theorem envBound47528 : H12AffineFastState.Bounded env47528 := by
  intro p hp
  have h : env47528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47527_47528 : H12AffineEnvironment.transform 10 153 env47527 = env47528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env47527 == env47528) = true)

theorem identity47528 : scanCanonicalize (H12AffineFastState.compose env47528 (packedSelected [0,1,4,7,8,9,10,12,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 57) := by decide +kernel

theorem selectedBound47528 : packedSelected [0,1,4,7,8,9,10,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env47529 : List Nat := [2,4,8,16,32,54,128,57,1,31,153,11,37,55,55,63,28,190,4,54,10,136,29,62,182,33,23,59,55,147,40,43,57,45,17,27]

theorem envBound47529 : H12AffineFastState.Bounded env47529 := by
  intro p hp
  have h : env47529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47528_47529 : H12AffineEnvironment.transform 7 57 env47528 = env47529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 57 env47528 == env47529) = true)

theorem identity47529 : scanCanonicalize (H12AffineFastState.compose env47529 (packedSelected [0,1,3,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound47529 : packedSelected [0,1,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47530 : List Nat := [2,4,8,16,32,54,25,57,1,31,0,11,37,55,55,63,28,39,4,54,10,17,29,62,47,33,23,59,55,10,40,43,57,45,17,27]

theorem envBound47530 : H12AffineFastState.Bounded env47530 := by
  intro p hp
  have h : env47530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47529_47530 : H12AffineEnvironment.transform 6 25 env47529 = env47530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env47529 == env47530) = true)

theorem identity47530 : scanCanonicalize (H12AffineFastState.compose env47530 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound47530 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47531 : List Nat := [2,4,8,6,32,32,15,47,1,9,0,11,37,33,33,41,10,39,4,32,10,7,11,40,47,33,1,45,33,10,40,43,47,45,7,13]

theorem envBound47531 : H12AffineFastState.Bounded env47531 := by
  intro p hp
  have h : env47531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47530_47531 : H12AffineEnvironment.transform 3 6 env47530 = env47531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env47530 == env47531) = true)

theorem identity47531 : scanCanonicalize (H12AffineFastState.compose env47531 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47531 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47532 : List Nat := [2,4,4,6,32,32,3,35,1,5,0,7,37,33,33,37,6,39,4,32,6,7,7,36,35,33,1,33,33,6,36,39,35,33,7,1]

theorem envBound47532 : H12AffineFastState.Bounded env47532 := by
  intro p hp
  have h : env47532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47531_47532 : H12AffineEnvironment.transform 2 4 env47531 = env47532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47531 == env47532) = true)

theorem identity47532 : scanCanonicalize (H12AffineFastState.compose env47532 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47532 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47533 : List Nat := [2,4,4,6,1,1,3,2,1,5,0,7,4,0,0,4,6,6,4,1,6,7,7,5,2,0,1,0,0,6,5,6,2,0,7,1]

theorem envBound47533 : H12AffineFastState.Bounded env47533 := by
  intro p hp
  have h : env47533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47532_47533 : H12AffineEnvironment.transform 4 1 env47532 = env47533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47532 == env47533) = true)

def env47534 : List Nat := [2,4,8,16,32,54,128,256,313,294,2048,10,36,55,271,65536,65819,65665,316,270,11,432,65818,65537,182,65831,302,65852,55,67637,41,65836,256,44,17,290]

theorem envBound47534 : H12AffineFastState.Bounded env47534 := by
  intro p hp
  have h : env47534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47525_47534 : H12AffineEnvironment.transform 8 313 env47525 = env47534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 313 env47525 == env47534) = true)

theorem identity47534 : scanCanonicalize (H12AffineFastState.compose env47534 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2453) := by decide +kernel

theorem selectedBound47534 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env47535 : List Nat := [2,4,8,16,32,54,128,256,313,294,2048,10,36,55,271,2453,2190,2324,316,270,11,432,2191,2452,182,2226,302,2217,55,416,41,2233,256,44,17,290]

theorem envBound47535 : H12AffineFastState.Bounded env47535 := by
  intro p hp
  have h : env47535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47534_47535 : H12AffineEnvironment.transform 15 2453 env47534 = env47535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2453 env47534 == env47535) = true)

theorem identity47535 : scanCanonicalize (H12AffineFastState.compose env47535 (packedSelected [0,2,5,7,9,10,11,12,15,19,20,23,27] rootPS)) = affineNative (2^(10+1) ^^^ 281) := by decide +kernel

theorem selectedBound47535 : packedSelected [0,2,5,7,9,10,11,12,15,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env47536 : List Nat := [2,4,8,16,32,54,128,256,313,294,281,10,36,55,271,140,407,13,316,270,11,432,406,141,182,427,302,432,55,416,41,416,256,44,17,290]

theorem envBound47536 : H12AffineFastState.Bounded env47536 := by
  intro p hp
  have h : env47536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47535_47536 : H12AffineEnvironment.transform 10 281 env47535 = env47536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 281 env47535 == env47536) = true)

theorem identity47536 : scanCanonicalize (H12AffineFastState.compose env47536 (packedSelected [3,4,5,7,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound47536 : packedSelected [3,4,5,7,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47537 : List Nat := [2,4,8,16,32,54,128,19,42,53,10,10,36,55,28,140,132,13,47,29,11,163,133,141,182,184,61,163,55,179,41,179,19,44,17,49]

theorem envBound47537 : H12AffineFastState.Bounded env47537 := by
  intro p hp
  have h : env47537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47536_47537 : H12AffineEnvironment.transform 7 19 env47536 = env47537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env47536 == env47537) = true)

theorem identity47537 : scanCanonicalize (H12AffineFastState.compose env47537 (packedSelected [2,7,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47537 : packedSelected [2,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env47538 : List Nat := [2,4,8,16,32,54,9,19,42,53,10,10,36,55,28,5,13,13,47,29,11,42,12,4,63,49,61,42,55,58,41,58,19,44,17,49]

theorem envBound47538 : H12AffineFastState.Bounded env47538 := by
  intro p hp
  have h : env47538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47537_47538 : H12AffineEnvironment.transform 6 9 env47537 = env47538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47537 == env47538) = true)

theorem identity47538 : scanCanonicalize (H12AffineFastState.compose env47538 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47538 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47539 : List Nat := [2,4,8,16,16,6,9,19,26,5,10,10,20,7,28,5,13,13,31,29,11,26,12,4,15,1,13,26,7,10,25,10,19,28,17,1]

theorem envBound47539 : H12AffineFastState.Bounded env47539 := by
  intro p hp
  have h : env47539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47538_47539 : H12AffineEnvironment.transform 4 16 env47538 = env47539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47538 == env47539) = true)

theorem identity47539 : scanCanonicalize (H12AffineFastState.compose env47539 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47539 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47540 : List Nat := [2,4,8,1,1,6,9,2,11,5,10,10,5,7,13,5,13,13,14,12,11,11,12,4,15,1,13,11,7,10,8,10,2,13,0,1]

theorem envBound47540 : H12AffineFastState.Bounded env47540 := by
  intro p hp
  have h : env47540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47539_47540 : H12AffineEnvironment.transform 3 1 env47539 = env47540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47539 == env47540) = true)

def env47541 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,65536,66083,65665,516,577,837,649,66083,65536,192,65831,303,66162,64,67651,784,66146,256,789,16,340]

theorem envBound47541 : H12AffineFastState.Bounded env47541 := by
  intro p hp
  have h : env47541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47523_47541 : H12AffineEnvironment.transform 9 337 env47523 = env47541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env47523 == env47541) = true)

theorem identity47541 : scanCanonicalize (H12AffineFastState.compose env47541 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 306) := by decide +kernel

theorem selectedBound47541 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47542 : List Nat := [2,4,8,16,32,64,128,256,306,337,2048,118,47,64,370,65536,65809,65665,310,371,119,443,65809,65536,192,65831,303,65856,64,67651,34,65872,256,39,16,340]

theorem envBound47542 : H12AffineFastState.Bounded env47542 := by
  intro p hp
  have h : env47542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47541_47542 : H12AffineEnvironment.transform 8 306 env47541 = env47542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 306 env47541 == env47542) = true)

def env47543 : List Nat := [2,4,8,0,32,64,128,256,290,321,2048,102,47,64,354,65536,65793,65665,294,355,103,427,65793,65536,192,65831,303,65856,64,67651,34,65856,256,39,0,324]

theorem envBound47543 : H12AffineFastState.Bounded env47543 := by
  intro p hp
  have h : env47543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47542_47543 : H12AffineEnvironment.transform 3 0 env47542 = env47543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47542 == env47543) = true)

theorem identity47543 : scanCanonicalize (H12AffineFastState.compose env47543 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound47543 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47544 : List Nat := [2,4,8,0,32,64,128,256,290,321,2048,102,47,64,354,5,260,132,294,355,103,427,260,5,192,290,303,325,64,2118,34,325,256,39,0,324]

theorem envBound47544 : H12AffineFastState.Bounded env47544 := by
  intro p hp
  have h : env47544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47543_47544 : H12AffineEnvironment.transform 15 5 env47543 = env47544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env47543 == env47544) = true)

theorem identity47544 : scanCanonicalize (H12AffineFastState.compose env47544 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound47544 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47545 : List Nat := [2,4,8,0,32,64,128,256,290,321,45,102,47,64,354,5,260,132,294,355,103,427,260,5,192,290,303,325,64,107,34,325,256,39,0,324]

theorem envBound47545 : H12AffineFastState.Bounded env47545 := by
  intro p hp
  have h : env47545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47544_47545 : H12AffineEnvironment.transform 10 45 env47544 = env47545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env47544 == env47545) = true)

theorem identity47545 : scanCanonicalize (H12AffineFastState.compose env47545 (packedSelected [1,2,4,9,11,15,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound47545 : packedSelected [1,2,4,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47546 : List Nat := [2,4,8,0,32,64,35,256,290,321,45,102,47,64,354,5,260,39,294,355,103,264,260,5,99,290,303,325,64,107,34,325,256,39,0,324]

theorem envBound47546 : H12AffineFastState.Bounded env47546 := by
  intro p hp
  have h : env47546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47545_47546 : H12AffineEnvironment.transform 6 35 env47545 = env47546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env47545 == env47546) = true)

theorem identity47546 : scanCanonicalize (H12AffineFastState.compose env47546 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound47546 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47547 : List Nat := [2,4,8,0,32,13,35,256,290,268,45,43,47,13,303,5,260,39,294,302,42,264,260,5,46,290,303,264,13,38,34,264,256,39,0,265]

theorem envBound47547 : H12AffineFastState.Bounded env47547 := by
  intro p hp
  have h : env47547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47546_47547 : H12AffineEnvironment.transform 5 13 env47546 = env47547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env47546 == env47547) = true)

theorem identity47547 : scanCanonicalize (H12AffineFastState.compose env47547 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound47547 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47548 : List Nat := [2,4,8,0,32,13,35,35,1,47,45,43,47,13,12,5,39,39,5,13,42,43,39,5,46,1,12,43,13,38,34,43,35,39,0,42]

theorem envBound47548 : H12AffineFastState.Bounded env47548 := by
  intro p hp
  have h : env47548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47547_47548 : H12AffineEnvironment.transform 7 35 env47547 = env47548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env47547 == env47548) = true)

theorem identity47548 : scanCanonicalize (H12AffineFastState.compose env47548 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47549 : List Nat := [2,4,3,0,32,6,35,35,1,36,38,32,36,6,7,5,39,39,5,6,33,32,39,5,37,1,7,32,6,38,34,32,35,39,0,33]

theorem envBound47549 : H12AffineFastState.Bounded env47549 := by
  intro p hp
  have h : env47549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47548_47549 : H12AffineEnvironment.transform 2 3 env47548 = env47549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47548 == env47549) = true)

def env47550 : List Nat := [2,4,8,1,32,64,128,256,291,320,2048,103,47,64,355,65536,65792,65665,295,354,102,426,65792,65536,192,65831,303,65856,64,67651,34,65857,256,39,1,325]

theorem envBound47550 : H12AffineFastState.Bounded env47550 := by
  intro p hp
  have h : env47550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47542_47550 : H12AffineEnvironment.transform 3 1 env47542 = env47550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47542 == env47550) = true)

theorem identity47550 : scanCanonicalize (H12AffineFastState.compose env47550 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound47550 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47551 : List Nat := [2,4,8,1,32,64,128,256,291,320,2048,103,47,64,355,98,354,227,295,354,102,426,354,98,192,325,303,290,64,2081,34,291,256,39,1,325]

theorem envBound47551 : H12AffineFastState.Bounded env47551 := by
  intro p hp
  have h : env47551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47550_47551 : H12AffineEnvironment.transform 15 98 env47550 = env47551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env47550 == env47551) = true)

theorem identity47551 : scanCanonicalize (H12AffineFastState.compose env47551 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 448) := by decide +kernel

theorem selectedBound47551 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47552 : List Nat := [2,4,8,1,32,64,128,256,291,320,448,103,47,64,355,98,354,227,295,354,102,426,354,98,192,325,303,290,64,481,34,291,256,39,1,325]

theorem envBound47552 : H12AffineFastState.Bounded env47552 := by
  intro p hp
  have h : env47552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47551_47552 : H12AffineEnvironment.transform 10 448 env47551 = env47552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 448 env47551 == env47552) = true)

theorem identity47552 : scanCanonicalize (H12AffineFastState.compose env47552 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47552 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47553 : List Nat := [2,4,8,1,32,1,128,256,291,257,385,38,47,1,290,35,291,162,295,291,39,426,291,35,129,260,303,290,1,416,34,291,256,39,1,260]

theorem envBound47553 : H12AffineFastState.Bounded env47553 := by
  intro p hp
  have h : env47553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47552_47553 : H12AffineEnvironment.transform 5 1 env47552 = env47553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47552 == env47553) = true)

theorem identity47553 : scanCanonicalize (H12AffineFastState.compose env47553 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound47553 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47554 : List Nat := [2,4,8,1,32,1,34,256,291,257,291,38,47,1,290,35,291,0,295,291,39,264,291,35,35,260,303,290,1,258,34,291,256,39,1,260]

theorem envBound47554 : H12AffineFastState.Bounded env47554 := by
  intro p hp
  have h : env47554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47553_47554 : H12AffineEnvironment.transform 6 34 env47553 = env47554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env47553 == env47554) = true)

theorem identity47554 : scanCanonicalize (H12AffineFastState.compose env47554 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound47554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47555 : List Nat := [2,4,8,1,32,1,34,8,43,9,43,38,47,1,42,35,43,0,47,43,39,0,43,35,35,12,39,42,1,10,34,43,8,39,1,12]

theorem envBound47555 : H12AffineFastState.Bounded env47555 := by
  intro p hp
  have h : env47555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47554_47555 : H12AffineEnvironment.transform 7 8 env47554 = env47555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env47554 == env47555) = true)

theorem identity47555 : scanCanonicalize (H12AffineFastState.compose env47555 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47555 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env47556 : List Nat := [2,4,2,1,32,1,34,2,33,3,33,38,37,1,32,35,33,0,37,33,39,0,33,35,35,6,39,32,1,0,34,33,2,39,1,6]

theorem envBound47556 : H12AffineFastState.Bounded env47556 := by
  intro p hp
  have h : env47556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47555_47556 : H12AffineEnvironment.transform 2 2 env47555 = env47556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47555 == env47556) = true)

theorem identity47556 : scanCanonicalize (H12AffineFastState.compose env47556 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47557 : List Nat := [2,4,2,1,1,1,3,2,0,3,0,7,4,1,1,2,0,0,4,0,6,0,0,2,2,6,6,1,1,0,3,0,2,6,1,6]

theorem envBound47557 : H12AffineFastState.Bounded env47557 := by
  intro p hp
  have h : env47557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47556_47557 : H12AffineEnvironment.transform 4 1 env47556 = env47557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47556 == env47557) = true)

theorem identity47557 : scanCanonicalize (H12AffineFastState.compose env47557 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47557 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47558 : List Nat := [2,2,2,1,1,1,3,2,0,3,0,1,2,1,1,2,0,0,2,0,0,0,0,2,2,0,0,1,1,0,3,0,2,0,1,0]

theorem envBound47558 : H12AffineFastState.Bounded env47558 := by
  intro p hp
  have h : env47558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47557_47558 : H12AffineEnvironment.transform 1 2 env47557 = env47558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47557 == env47558) = true)

def env47559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,134217728,148800,545089,96346,16876544,151934399,257,134652357,151462016,525824]

theorem envBound47559 : H12AffineFastState.Bounded env47559 := by
  intro p hp
  have h : env47559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46601_47559 : H12AffineEnvironment.transform 24 533641 env46601 = env47559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env46601 == env47559) = true)

def env47560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245632,148800,545089,96346,16876544,618623,257,16876549,1344,525824]

theorem envBound47560 : H12AffineFastState.Bounded env47560 := by
  intro p hp
  have h : env47560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47559_47560 : H12AffineEnvironment.transform 26 17245632 env47559 = env47560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env47559 == env47560) = true)

theorem identity47560 : scanCanonicalize (H12AffineFastState.compose env47560 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound47560 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717115,533641,672785,906491,148800,545089,96346,750907,618623,257,750910,1344,525824]

theorem envBound47561 : H12AffineFastState.Bounded env47561 := by
  intro p hp
  have h : env47561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47560_47561 : H12AffineEnvironment.transform 23 717115 env47560 = env47561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env47560 == env47561) = true)

def env47562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58683,143497,20497,508155,148800,148801,96346,90427,222335,257,90430,1344,135680]

theorem envBound47562 : H12AffineFastState.Bounded env47562 := by
  intro p hp
  have h : env47562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47561_47562 : H12AffineEnvironment.transform 18 136192 env47561 = env47562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env47561 == env47562) = true)

def env47563 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143497,20497,508155,148716,148717,96346,90263,222335,173,90258,1260,135680]

theorem envBound47563 : H12AffineFastState.Bounded env47563 := by
  intro p hp
  have h : env47563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47562_47563 : H12AffineEnvironment.transform 7 172 env47562 = env47563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env47562 == env47563) = true)

def env47564 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143497,20497,508075,148668,148669,96266,90263,222255,173,90258,1212,135680]

theorem envBound47564 : H12AffineFastState.Bounded env47564 := by
  intro p hp
  have h : env47564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47563_47564 : H12AffineEnvironment.transform 5 16 env47563 = env47564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47563 == env47564) = true)

theorem identity47564 : scanCanonicalize (H12AffineFastState.compose env47564 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound47564 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47565 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61568,147472,58519,143497,20497,60445,148668,148669,96266,90263,222255,173,90258,1212,135680]

theorem envBound47565 : H12AffineFastState.Bounded env47565 := by
  intro p hp
  have h : env47565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47564_47565 : H12AffineEnvironment.transform 17 208054 env47564 = env47565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env47564 == env47565) = true)

theorem identity47565 : scanCanonicalize (H12AffineFastState.compose env47565 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound47565 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env47566 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4097,61568,147472,58519,143497,20497,60445,148668,148669,43048,45237,177165,173,45232,1212,135680]

theorem envBound47566 : H12AffineFastState.Bounded env47566 := by
  intro p hp
  have h : env47566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47565_47566 : H12AffineEnvironment.transform 15 53282 env47565 = env47566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env47565 == env47566) = true)

theorem identity47566 : scanCanonicalize (H12AffineFastState.compose env47566 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound47566 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47567 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4097,61568,5292,58519,25653,20497,60445,4096,4097,43048,45237,57521,173,45232,1212,18108]

theorem envBound47567 : H12AffineFastState.Bounded env47567 := by
  intro p hp
  have h : env47567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47566_47567 : H12AffineEnvironment.transform 16 21692 env47566 = env47567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env47566 == env47567) = true)

theorem identity47567 : scanCanonicalize (H12AffineFastState.compose env47567 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound47567 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env47568 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12312,24634,21692,6192,16572,12313,4097,16536,5292,21647,25653,20497,23557,4096,4097,6192,173,20649,173,168,1212,18108]

theorem envBound47568 : H12AffineFastState.Bounded env47568 := by
  intro p hp
  have h : env47568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47567_47568 : H12AffineEnvironment.transform 14 12312 env47567 = env47568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env47567 == env47568) = true)

theorem identity47568 : scanCanonicalize (H12AffineFastState.compose env47568 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 4632) := by decide +kernel

theorem selectedBound47568 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env47569 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4632,16384,512,21026,21692,6192,16572,513,4097,16536,5292,21647,22061,20497,23557,4096,4097,6192,173,20649,173,168,1212,18108]

theorem envBound47569 : H12AffineFastState.Bounded env47569 := by
  intro p hp
  have h : env47569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47568_47569 : H12AffineEnvironment.transform 12 4632 env47568 = env47569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4632 env47568 == env47569) = true)

theorem identity47569 : scanCanonicalize (H12AffineFastState.compose env47569 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 2091) := by decide +kernel

theorem selectedBound47569 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env47570 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4632,2091,512,6665,7319,6192,2199,513,4097,2227,5292,7332,7686,6202,5166,4096,4097,6192,173,6274,173,168,1212,3735]

theorem envBound47570 : H12AffineFastState.Bounded env47570 := by
  intro p hp
  have h : env47570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47569_47570 : H12AffineEnvironment.transform 13 2091 env47569 = env47570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2091 env47569 == env47570) = true)

theorem identity47570 : scanCanonicalize (H12AffineFastState.compose env47570 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound47570 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env47571 : List Nat := [2,4,8,16,32,16,128,172,512,53,2048,4096,4632,2091,512,6665,6306,6192,2199,513,4097,2227,4249,6289,6707,6202,4123,4096,4097,6192,173,6274,173,168,137,2722]

theorem envBound47571 : H12AffineFastState.Bounded env47571 := by
  intro p hp
  have h : env47571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47570_47571 : H12AffineEnvironment.transform 9 53 env47570 = env47571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47570 == env47571) = true)

theorem identity47571 : scanCanonicalize (H12AffineFastState.compose env47571 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound47571 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47572 : List Nat := [2,4,8,16,32,16,128,172,26,53,2048,4096,4098,2091,26,6163,6306,6192,2199,27,4097,2227,4249,6289,6185,6202,4123,4096,4097,6192,173,6274,173,168,137,2232]

theorem envBound47572 : H12AffineFastState.Bounded env47572 := by
  intro p hp
  have h : env47572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47571_47572 : H12AffineEnvironment.transform 8 26 env47571 = env47572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env47571 == env47572) = true)

theorem identity47572 : scanCanonicalize (H12AffineFastState.compose env47572 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound47572 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47573 : List Nat := [2,4,8,16,32,16,128,172,26,53,2048,2097,2099,2091,26,34,147,1,2199,27,2096,2227,2216,160,24,11,2090,2097,2096,1,173,179,173,168,137,2232]

theorem envBound47573 : H12AffineFastState.Bounded env47573 := by
  intro p hp
  have h : env47573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47572_47573 : H12AffineEnvironment.transform 11 2097 env47572 = env47573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env47572 == env47573) = true)

theorem identity47573 : scanCanonicalize (H12AffineFastState.compose env47573 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound47573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47574 : List Nat := [2,4,8,16,32,16,19,63,26,53,2048,2097,2099,2091,26,34,0,1,2052,27,2096,2080,2107,51,24,11,2090,2097,2096,1,62,32,62,59,26,2091]

theorem envBound47574 : H12AffineFastState.Bounded env47574 := by
  intro p hp
  have h : env47574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47573_47574 : H12AffineEnvironment.transform 6 19 env47573 = env47574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env47573 == env47574) = true)

theorem identity47574 : scanCanonicalize (H12AffineFastState.compose env47574 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47574 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47575 : List Nat := [2,4,8,16,17,16,19,14,26,4,2048,2048,2050,2074,26,19,0,1,2052,27,2049,2065,2058,2,24,11,2075,2048,2049,1,15,17,15,10,26,2074]

theorem envBound47575 : H12AffineFastState.Bounded env47575 := by
  intro p hp
  have h : env47575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47574_47575 : H12AffineEnvironment.transform 4 17 env47574 = env47575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47574 == env47575) = true)

def env47576 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143497,20497,508074,148669,148668,96267,90263,222254,173,90258,1213,135680]

theorem envBound47576 : H12AffineFastState.Bounded env47576 := by
  intro p hp
  have h : env47576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47563_47576 : H12AffineEnvironment.transform 5 17 env47563 = env47576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47563 == env47576) = true)

theorem identity47576 : scanCanonicalize (H12AffineFastState.compose env47576 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound47576 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47577 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61569,115854,58519,111638,20497,279605,114722,114723,96267,90263,57521,173,90258,1213,104095]

theorem envBound47577 : H12AffineFastState.Bounded env47577 := by
  intro p hp
  have h : env47577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47576_47577 : H12AffineEnvironment.transform 16 99487 env47576 = env47577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env47576 == env47577) = true)

theorem identity47577 : scanCanonicalize (H12AffineFastState.compose env47577 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound47577 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env47578 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,9350,40985,262144,46105,32769,4097,61569,57352,58519,37008,20497,279605,58532,58533,23693,17425,57521,173,17428,1213,45593]

theorem envBound47578 : H12AffineFastState.Bounded env47578 := by
  intro p hp
  have h : env47578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47577_47578 : H12AffineEnvironment.transform 15 9350 env47577 = env47578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env47577 == env47578) = true)

theorem identity47578 : scanCanonicalize (H12AffineFastState.compose env47578 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound47578 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47579 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12313,9350,4096,262144,1024,12312,4097,16536,20497,21646,8329,20497,279605,21693,21692,23693,17425,20648,173,17428,1213,512]

theorem envBound47579 : H12AffineFastState.Bounded env47579 := by
  intro p hp
  have h : env47579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47578_47579 : H12AffineEnvironment.transform 14 12313 env47578 = env47579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env47578 == env47579) = true)

theorem identity47579 : scanCanonicalize (H12AffineFastState.compose env47579 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound47579 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47580 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12313,9350,4096,262144,1024,12312,4097,1060,5293,4146,8329,5293,262281,4097,4096,6193,173,5140,173,168,1213,512]

theorem envBound47580 : H12AffineFastState.Bounded env47580 := by
  intro p hp
  have h : env47580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47579_47580 : H12AffineEnvironment.transform 13 1212 env47579 = env47580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env47579 == env47580) = true)

theorem identity47580 : scanCanonicalize (H12AffineFastState.compose env47580 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound47580 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47581 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,4648,1212,561,5806,4096,262144,1024,560,4097,1060,5293,4146,4769,5293,262281,4097,4096,6193,173,5140,173,168,1213,512]

theorem envBound47581 : H12AffineFastState.Bounded env47581 := by
  intro p hp
  have h : env47581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47580_47581 : H12AffineEnvironment.transform 12 4648 env47580 = env47581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env47580 == env47581) = true)

theorem identity47581 : scanCanonicalize (H12AffineFastState.compose env47581 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47581 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env47582 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,1685,1212,561,531,1213,262144,1024,560,1212,1060,16,1167,1564,16,262281,1212,1213,3212,173,169,173,168,1213,512]

theorem envBound47582 : H12AffineFastState.Bounded env47582 := by
  intro p hp
  have h : env47582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47581_47582 : H12AffineEnvironment.transform 11 1213 env47581 = env47582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env47581 == env47582) = true)

theorem identity47582 : scanCanonicalize (H12AffineFastState.compose env47582 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound47582 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47583 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,1685,1212,561,531,1213,1582,1024,560,1212,1060,16,1167,1564,16,1703,1212,1213,3212,173,169,173,168,1213,512]

theorem envBound47583 : H12AffineFastState.Bounded env47583 := by
  intro p hp
  have h : env47583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47582_47583 : H12AffineEnvironment.transform 17 1582 env47582 = env47583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env47582 == env47583) = true)

theorem identity47583 : scanCanonicalize (H12AffineFastState.compose env47583 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound47583 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env47584 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,184,656,185,561,531,184,555,5,560,185,33,16,138,537,16,674,185,184,2185,173,169,173,168,184,512]

theorem envBound47584 : H12AffineFastState.Bounded env47584 := by
  intro p hp
  have h : env47584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47583_47584 : H12AffineEnvironment.transform 9 5 env47583 = env47584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env47583 == env47584) = true)

theorem identity47584 : scanCanonicalize (H12AffineFastState.compose env47584 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound47584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47585 : List Nat := [2,4,8,16,32,17,128,172,512,5,512,184,656,185,561,531,184,555,5,560,185,33,16,138,537,16,674,185,184,649,173,169,173,168,184,512]

theorem envBound47585 : H12AffineFastState.Bounded env47585 := by
  intro p hp
  have h : env47585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47584_47585 : H12AffineEnvironment.transform 10 512 env47584 = env47585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env47584 == env47585) = true)

theorem identity47585 : scanCanonicalize (H12AffineFastState.compose env47585 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47586 : List Nat := [2,4,8,10,32,11,128,172,512,5,512,162,650,163,555,521,162,555,5,554,163,33,10,138,515,10,674,163,162,649,173,169,173,168,162,512]

theorem envBound47586 : H12AffineFastState.Bounded env47586 := by
  intro p hp
  have h : env47586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47585_47586 : H12AffineEnvironment.transform 3 10 env47585 = env47586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47585 == env47586) = true)

theorem identity47586 : scanCanonicalize (H12AffineFastState.compose env47586 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound47586 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47587 : List Nat := [2,4,8,10,32,11,128,172,133,5,133,162,15,163,174,140,162,174,5,175,163,33,10,138,134,10,39,163,162,12,173,169,173,168,162,133]

theorem envBound47587 : H12AffineFastState.Bounded env47587 := by
  intro p hp
  have h : env47587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47586_47587 : H12AffineEnvironment.transform 8 133 env47586 = env47587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env47586 == env47587) = true)

theorem identity47587 : scanCanonicalize (H12AffineFastState.compose env47587 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound47587 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47588 : List Nat := [2,4,8,10,32,11,4,40,1,5,1,38,15,39,42,8,38,42,5,43,39,33,10,14,2,10,39,39,38,12,41,45,41,44,38,1]

theorem envBound47588 : H12AffineFastState.Bounded env47588 := by
  intro p hp
  have h : env47588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47587_47588 : H12AffineEnvironment.transform 6 4 env47587 = env47588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env47587 == env47588) = true)

def env47589 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143497,20497,508155,148717,148716,96346,90262,222335,172,90259,1261,135680]

theorem envBound47589 : H12AffineFastState.Bounded env47589 := by
  intro p hp
  have h : env47589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47562_47589 : H12AffineEnvironment.transform 7 173 env47562 = env47589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47562 == env47589) = true)

def env47590 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143497,20497,508075,148669,148668,96266,90262,222255,172,90259,1213,135680]

theorem envBound47590 : H12AffineFastState.Bounded env47590 := by
  intro p hp
  have h : env47590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47589_47590 : H12AffineEnvironment.transform 5 16 env47589 = env47590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47589 == env47590) = true)

theorem identity47590 : scanCanonicalize (H12AffineFastState.compose env47590 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound47590 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47591 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,58518,143497,20497,120866,148669,148668,96266,90262,222255,172,90259,1213,135680]

theorem envBound47591 : H12AffineFastState.Bounded env47591 := by
  intro p hp
  have h : env47591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47590_47591 : H12AffineEnvironment.transform 17 137353 env47590 = env47591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env47590 == env47591) = true)

theorem identity47591 : scanCanonicalize (H12AffineFastState.compose env47591 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound47591 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env47592 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4097,61568,46093,58518,50324,20497,120866,45216,45217,96266,90262,102450,172,90259,1213,58909]

theorem envBound47592 : H12AffineFastState.Bounded env47592 := by
  intro p hp
  have h : env47592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47591_47592 : H12AffineEnvironment.transform 16 62493 env47591 = env47592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env47591 == env47592) = true)

theorem identity47592 : scanCanonicalize (H12AffineFastState.compose env47592 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound47592 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47593 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,16384,32768,65536,58533,60564,57373,32769,185,57400,42165,58518,50324,16553,116890,40984,40985,92338,90262,98442,172,90259,1213,58909]

theorem envBound47593 : H12AffineFastState.Bounded env47593 := by
  intro p hp
  have h : env47593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47592_47593 : H12AffineEnvironment.transform 11 184 env47592 = env47593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env47592 == env47593) = true)

theorem identity47593 : scanCanonicalize (H12AffineFastState.compose env47593 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 3628) := by decide +kernel

theorem selectedBound47593 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47594 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,3628,16384,32768,65536,51849,49848,52785,32769,185,52756,35481,51898,50324,16553,116890,36404,36405,83614,85690,98442,172,85695,1213,51249]

theorem envBound47594 : H12AffineFastState.Bounded env47594 := by
  intro p hp
  have h : env47594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47593_47594 : H12AffineEnvironment.transform 12 3628 env47593 = env47594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3628 env47593 == env47594) = true)

theorem identity47594 : scanCanonicalize (H12AffineFastState.compose env47594 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound47594 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env47595 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,3628,16384,32768,49307,51849,49848,52785,32769,185,52756,35481,51898,50324,16553,2049,36404,36405,34309,36385,16401,172,36388,1213,51249]

theorem envBound47595 : H12AffineFastState.Bounded env47595 := by
  intro p hp
  have h : env47595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47594_47595 : H12AffineEnvironment.transform 15 49307 env47594 = env47595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env47594 == env47595) = true)

theorem identity47595 : scanCanonicalize (H12AffineFastState.compose env47595 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 18993) := by decide +kernel

theorem selectedBound47595 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env47596 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,3628,16384,18993,2730,184,2185,1024,18992,185,1061,16552,139,3749,16553,2049,17413,17412,19508,17424,16401,172,17429,1213,512]

theorem envBound47596 : H12AffineFastState.Bounded env47596 := by
  intro p hp
  have h : env47596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47595_47596 : H12AffineEnvironment.transform 14 18993 env47595 = env47596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18993 env47595 == env47596) = true)

theorem identity47596 : scanCanonicalize (H12AffineFastState.compose env47596 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 48) := by decide +kernel

theorem selectedBound47596 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env47597 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,3628,48,2561,2730,184,2185,1024,2560,185,1061,152,139,3749,153,2049,1077,1076,3076,1056,33,172,1061,1213,512]

theorem envBound47597 : H12AffineFastState.Bounded env47597 := by
  intro p hp
  have h : env47597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47596_47597 : H12AffineEnvironment.transform 13 48 env47596 = env47597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 48 env47596 == env47597) = true)

theorem identity47597 : scanCanonicalize (H12AffineFastState.compose env47597 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound47597 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47598 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,184,3126,48,2075,2224,184,2185,1024,2074,185,1061,152,139,3263,153,2049,1077,1076,3076,1056,33,172,1061,1213,26]

theorem envBound47598 : H12AffineFastState.Bounded env47598 := by
  intro p hp
  have h : env47598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47597_47598 : H12AffineEnvironment.transform 8 26 env47597 = env47598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env47597 == env47598) = true)

theorem identity47598 : scanCanonicalize (H12AffineFastState.compose env47598 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47598 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env47599 : List Nat := [2,4,8,10,32,10,128,173,0,1024,2048,162,3116,42,2049,2218,162,2185,1024,2048,163,1061,130,139,3237,131,2049,1071,1070,3076,1056,33,172,1061,1191,0]

theorem envBound47599 : H12AffineFastState.Bounded env47599 := by
  intro p hp
  have h : env47599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47598_47599 : H12AffineEnvironment.transform 3 10 env47598 = env47599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47598 == env47599) = true)

theorem identity47599 : scanCanonicalize (H12AffineFastState.compose env47599 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound47599 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47600 : List Nat := [2,4,8,10,32,10,128,173,0,5,2048,162,2089,42,2049,2218,162,2185,5,2048,163,32,130,139,2208,131,2049,42,43,2049,37,33,172,32,162,0]

theorem envBound47600 : H12AffineFastState.Bounded env47600 := by
  intro p hp
  have h : env47600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47599_47600 : H12AffineEnvironment.transform 9 5 env47599 = env47600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env47599 == env47600) = true)

theorem identity47600 : scanCanonicalize (H12AffineFastState.compose env47600 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound47600 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47601 : List Nat := [2,4,8,10,32,10,128,173,0,5,43,162,2,42,42,129,162,162,5,43,163,32,130,139,139,131,42,42,43,42,37,33,172,32,162,0]

theorem envBound47601 : H12AffineFastState.Bounded env47601 := by
  intro p hp
  have h : env47601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47600_47601 : H12AffineEnvironment.transform 10 43 env47600 = env47601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env47600 == env47601) = true)

theorem identity47601 : scanCanonicalize (H12AffineFastState.compose env47601 (packedSelected [0,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47601 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env47602 : List Nat := [2,4,8,10,32,10,8,37,0,5,43,42,2,42,42,9,42,42,5,43,43,32,10,3,3,11,42,42,43,42,37,33,36,32,42,0]

theorem envBound47602 : H12AffineFastState.Bounded env47602 := by
  intro p hp
  have h : env47602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47601_47602 : H12AffineEnvironment.transform 6 8 env47601 = env47602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47601 == env47602) = true)

theorem identity47602 : scanCanonicalize (H12AffineFastState.compose env47602 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47603 : List Nat := [2,3,8,10,32,10,8,34,0,2,43,42,2,42,42,9,42,42,2,43,43,32,10,3,3,11,42,42,43,42,34,33,35,32,42,0]

theorem envBound47603 : H12AffineFastState.Bounded env47603 := by
  intro p hp
  have h : env47603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47602_47603 : H12AffineEnvironment.transform 1 3 env47602 = env47603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47602 == env47603) = true)

def env47604 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143497,20497,508074,148668,148669,96267,90262,222254,172,90259,1212,135680]

theorem envBound47604 : H12AffineFastState.Bounded env47604 := by
  intro p hp
  have h : env47604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47589_47604 : H12AffineEnvironment.transform 5 17 env47589 = env47604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47589 == env47604) = true)

theorem identity47604 : scanCanonicalize (H12AffineFastState.compose env47604 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound47604 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47605 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,58518,32808,20497,356363,62493,62492,96267,90262,119951,172,90259,1212,41633]

theorem envBound47605 : H12AffineFastState.Bounded env47605 := by
  intro p hp
  have h : env47605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47604_47605 : H12AffineEnvironment.transform 16 45217 env47604 = env47605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env47604 == env47605) = true)

theorem identity47605 : scanCanonicalize (H12AffineFastState.compose env47605 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound47605 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47606 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4097,61569,61616,58518,32808,20497,96387,62493,62492,96267,90262,119951,172,90259,1212,41633]

theorem envBound47606 : H12AffineFastState.Bounded env47606 := by
  intro p hp
  have h : env47606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47605_47606 : H12AffineEnvironment.transform 17 2184 env47605 = env47606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env47605 == env47606) = true)

theorem identity47606 : scanCanonicalize (H12AffineFastState.compose env47606 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound47606 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47607 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,49306,45217,2184,42145,32769,4097,61569,61616,58518,32808,20497,47129,62493,62492,47249,40972,5141,172,40969,1212,41633]

theorem envBound47607 : H12AffineFastState.Bounded env47607 := by
  intro p hp
  have h : env47607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47606_47607 : H12AffineEnvironment.transform 15 49306 env47606 = env47607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env47606 == env47607) = true)

theorem identity47607 : scanCanonicalize (H12AffineFastState.compose env47607 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound47607 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env47608 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,13374,17413,2184,20485,29861,4097,1061,1044,4146,29836,20497,19645,185,184,19509,21672,5141,172,21677,1212,22021]

theorem envBound47608 : H12AffineFastState.Bounded env47608 := by
  intro p hp
  have h : env47608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47607_47608 : H12AffineEnvironment.transform 14 29860 env47607 = env47608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env47607 == env47608) = true)

theorem identity47608 : scanCanonicalize (H12AffineFastState.compose env47608 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(13+1) ^^^ 14497) := by decide +kernel

theorem selectedBound47608 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env47609 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,14497,3077,13374,15524,2184,10404,3076,4097,1061,1044,4146,3117,10416,13340,185,184,13460,11273,5141,172,11276,1212,11940]

theorem envBound47609 : H12AffineFastState.Bounded env47609 := by
  intro p hp
  have h : env47609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47608_47609 : H12AffineEnvironment.transform 13 14497 env47608 = env47609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14497 env47608 == env47609) = true)

theorem identity47609 : scanCanonicalize (H12AffineFastState.compose env47609 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound47609 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env47610 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,512,8192,10913,3077,9790,11940,2184,10404,3076,513,1061,1044,562,3117,10416,9756,185,184,9876,11273,1557,172,11276,1212,11940]

theorem envBound47610 : H12AffineFastState.Bounded env47610 := by
  intro p hp
  have h : env47610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47609_47610 : H12AffineEnvironment.transform 11 512 env47609 = env47610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env47609 == env47610) = true)

theorem identity47610 : scanCanonicalize (H12AffineFastState.compose env47610 (packedSelected [1,2,4,7,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 2704) := by decide +kernel

theorem selectedBound47610 : packedSelected [1,2,4,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env47611 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,512,2704,49,3077,3246,1076,2184,564,3076,513,1061,1044,562,3117,544,3212,185,184,3076,1689,1557,172,1692,1212,1076]

theorem envBound47611 : H12AffineFastState.Bounded env47611 := by
  intro p hp
  have h : env47611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47610_47611 : H12AffineEnvironment.transform 12 2704 env47610 = env47611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2704 env47610 == env47611) = true)

theorem identity47611 : scanCanonicalize (H12AffineFastState.compose env47611 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound47611 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env47612 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1190,512,1590,49,163,8,1076,1070,564,162,513,1061,1044,562,139,544,42,185,184,162,1689,1557,172,1692,1212,1076]

theorem envBound47612 : H12AffineFastState.Bounded env47612 := by
  intro p hp
  have h : env47612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47611_47612 : H12AffineEnvironment.transform 10 1190 env47611 = env47612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env47611 == env47612) = true)

theorem identity47612 : scanCanonicalize (H12AffineFastState.compose env47612 (packedSelected [0,5,7,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound47612 : packedSelected [0,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47613 : List Nat := [2,4,8,16,32,17,128,173,48,1024,1190,48,1030,49,163,8,1076,1070,4,162,49,1061,1044,2,139,16,42,185,184,162,1193,1061,172,1196,1212,1076]

theorem envBound47613 : H12AffineFastState.Bounded env47613 := by
  intro p hp
  have h : env47613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47612_47613 : H12AffineEnvironment.transform 8 48 env47612 = env47613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47612 == env47613) = true)

theorem identity47613 : scanCanonicalize (H12AffineFastState.compose env47613 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound47613 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env47614 : List Nat := [2,4,8,16,32,17,128,173,48,150,48,48,144,49,163,8,162,184,4,162,49,179,130,2,139,16,42,185,184,162,63,179,172,58,42,162]

theorem envBound47614 : H12AffineFastState.Bounded env47614 := by
  intro p hp
  have h : env47614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47613_47614 : H12AffineEnvironment.transform 9 150 env47613 = env47614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env47613 == env47614) = true)

theorem identity47614 : scanCanonicalize (H12AffineFastState.compose env47614 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47614 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47615 : List Nat := [2,4,8,10,32,11,128,173,42,140,42,42,138,43,163,8,162,162,4,162,43,169,130,2,139,10,42,163,162,162,37,169,172,32,42,162]

theorem envBound47615 : H12AffineFastState.Bounded env47615 := by
  intro p hp
  have h : env47615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47614_47615 : H12AffineEnvironment.transform 3 10 env47614 = env47615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47614 == env47615) = true)

theorem identity47615 : scanCanonicalize (H12AffineFastState.compose env47615 (packedSelected [0,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47615 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env47616 : List Nat := [2,4,4,6,32,7,128,161,38,128,38,38,134,39,163,4,162,162,4,162,39,165,130,2,135,6,38,163,162,162,37,165,160,32,38,162]

theorem envBound47616 : H12AffineFastState.Bounded env47616 := by
  intro p hp
  have h : env47616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47615_47616 : H12AffineEnvironment.transform 2 4 env47615 = env47616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47615 == env47616) = true)

theorem identity47616 : scanCanonicalize (H12AffineFastState.compose env47616 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound47616 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env47617 : List Nat := [2,4,4,6,32,7,4,37,38,4,38,38,2,39,39,4,38,38,4,38,39,33,6,2,3,6,38,39,38,38,37,33,36,32,38,38]

theorem envBound47617 : H12AffineFastState.Bounded env47617 := by
  intro p hp
  have h : env47617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47616_47617 : H12AffineEnvironment.transform 6 4 env47616 = env47617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env47616 == env47617) = true)

theorem identity47617 : scanCanonicalize (H12AffineFastState.compose env47617 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47618 : List Nat := [2,4,4,6,6,7,4,3,0,4,0,0,2,1,1,4,0,0,4,0,1,7,6,2,3,6,0,1,0,0,3,7,2,6,0,0]

theorem envBound47618 : H12AffineFastState.Bounded env47618 := by
  intro p hp
  have h : env47618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47617_47618 : H12AffineEnvironment.transform 4 6 env47617 = env47618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47617 == env47618) = true)

def env47619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58682,143496,20496,508154,148800,148800,96346,90426,222334,257,90431,1344,135681]

theorem envBound47619 : H12AffineFastState.Bounded env47619 := by
  intro p hp
  have h : env47619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47561_47619 : H12AffineEnvironment.transform 18 136193 env47561 = env47619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env47561 == env47619) = true)

def env47620 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143496,20496,508154,148716,148716,96346,90262,222334,173,90259,1260,135681]

theorem envBound47620 : H12AffineFastState.Bounded env47620 := by
  intro p hp
  have h : env47620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47619_47620 : H12AffineEnvironment.transform 7 172 env47619 = env47620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env47619 == env47620) = true)

def env47621 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143496,20496,508074,148668,148668,96266,90262,222254,173,90259,1212,135681]

theorem envBound47621 : H12AffineFastState.Bounded env47621 := by
  intro p hp
  have h : env47621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47620_47621 : H12AffineEnvironment.transform 5 16 env47620 = env47621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47620 == env47621) = true)

theorem identity47621 : scanCanonicalize (H12AffineFastState.compose env47621 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound47621 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47622 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61568,115854,58518,111638,20496,279604,114722,114722,96266,90262,57520,173,90259,1212,104095]

theorem envBound47622 : H12AffineFastState.Bounded env47622 := by
  intro p hp
  have h : env47622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47621_47622 : H12AffineEnvironment.transform 16 99486 env47621 = env47622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env47621 == env47622) = true)

theorem identity47622 : scanCanonicalize (H12AffineFastState.compose env47622 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound47622 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env47623 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,9351,40985,262144,46104,32769,4097,61568,57353,58518,37009,20496,279604,58533,58533,23693,17425,57520,173,17428,1212,45592]

theorem envBound47623 : H12AffineFastState.Bounded env47623 := by
  intro p hp
  have h : env47623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47622_47623 : H12AffineEnvironment.transform 15 9351 env47622 = env47623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env47622 == env47623) = true)

theorem identity47623 : scanCanonicalize (H12AffineFastState.compose env47623 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound47623 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47624 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12312,9351,4097,262144,1024,12313,4097,16536,20497,21646,8329,20496,279604,21693,21693,23693,17425,20648,173,17428,1212,512]

theorem envBound47624 : H12AffineFastState.Bounded env47624 := by
  intro p hp
  have h : env47624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47623_47624 : H12AffineEnvironment.transform 14 12312 env47623 = env47624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env47623 == env47624) = true)

theorem identity47624 : scanCanonicalize (H12AffineFastState.compose env47624 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47624 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47625 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12312,9351,4097,262144,1024,12313,4097,1061,5292,4147,8329,5293,262281,4096,4096,6192,172,5141,173,169,1212,512]

theorem envBound47625 : H12AffineFastState.Bounded env47625 := by
  intro p hp
  have h : env47625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47624_47625 : H12AffineEnvironment.transform 13 1213 env47624 = env47625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env47624 == env47625) = true)

theorem identity47625 : scanCanonicalize (H12AffineFastState.compose env47625 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound47625 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47626 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,656,1213,4744,1559,4097,262144,1024,4745,4097,1061,5292,4147,537,5293,262281,4096,4096,6192,172,5141,173,169,1212,512]

theorem envBound47626 : H12AffineFastState.Bounded env47626 := by
  intro p hp
  have h : env47626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47625_47626 : H12AffineEnvironment.transform 12 656 env47625 = env47626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env47625 == env47626) = true)

theorem identity47626 : scanCanonicalize (H12AffineFastState.compose env47626 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound47626 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env47627 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,656,185,4744,531,4097,262144,4,4745,4097,33,4264,4147,537,4265,262281,4096,4096,6192,172,4113,173,169,184,512]

theorem envBound47627 : H12AffineFastState.Bounded env47627 := by
  intro p hp
  have h : env47627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47626_47627 : H12AffineEnvironment.transform 9 4 env47626 = env47627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env47626 == env47627) = true)

theorem identity47627 : scanCanonicalize (H12AffineFastState.compose env47627 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4755) := by decide +kernel

theorem selectedBound47627 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47628 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,656,185,4744,531,4097,4755,4,4745,4097,33,4264,4147,537,4265,4634,4096,4096,6192,172,4113,173,169,184,512]

theorem envBound47628 : H12AffineFastState.Bounded env47628 := by
  intro p hp
  have h : env47628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47627_47628 : H12AffineEnvironment.transform 17 4755 env47627 = env47628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4755 env47627 == env47628) = true)

def env47629 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143496,20496,508075,148669,148669,96267,90262,222255,173,90259,1213,135681]

theorem envBound47629 : H12AffineFastState.Bounded env47629 := by
  intro p hp
  have h : env47629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47620_47629 : H12AffineEnvironment.transform 5 17 env47620 = env47629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47620 == env47629) = true)

theorem identity47629 : scanCanonicalize (H12AffineFastState.compose env47629 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound47629 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47630 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61569,147473,58518,143496,20496,60444,148669,148669,96267,90262,222255,173,90259,1213,135681]

theorem envBound47630 : H12AffineFastState.Bounded env47630 := by
  intro p hp
  have h : env47630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47629_47630 : H12AffineEnvironment.transform 17 208055 env47629 = env47630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env47629 == env47630) = true)

theorem identity47630 : scanCanonicalize (H12AffineFastState.compose env47630 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound47630 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env47631 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4097,61569,147473,58518,143496,20496,60444,148669,148669,43048,45237,177164,173,45232,1213,135681]

theorem envBound47631 : H12AffineFastState.Bounded env47631 := by
  intro p hp
  have h : env47631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47630_47631 : H12AffineEnvironment.transform 15 53283 env47630 = env47631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env47630 == env47631) = true)

theorem identity47631 : scanCanonicalize (H12AffineFastState.compose env47631 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound47631 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47632 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4097,61569,5293,58518,25652,20496,60444,4097,4097,43048,45237,57520,173,45232,1213,18109]

theorem envBound47632 : H12AffineFastState.Bounded env47632 := by
  intro p hp
  have h : env47632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47631_47632 : H12AffineEnvironment.transform 16 21692 env47631 = env47632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env47631 == env47632) = true)

theorem identity47632 : scanCanonicalize (H12AffineFastState.compose env47632 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound47632 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env47633 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12313,24634,21692,6193,16573,12312,4097,16536,5293,21647,25652,20496,23557,4097,4097,6193,172,20649,173,169,1213,18109]

theorem envBound47633 : H12AffineFastState.Bounded env47633 := by
  intro p hp
  have h : env47633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47632_47633 : H12AffineEnvironment.transform 14 12313 env47632 = env47633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env47632 == env47633) = true)

theorem identity47633 : scanCanonicalize (H12AffineFastState.compose env47633 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound47633 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env47634 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,673,16384,4792,17051,21692,6193,16573,4793,4097,16536,5293,21647,18069,20496,23557,4097,4097,6193,172,20649,173,169,1213,18109]

theorem envBound47634 : H12AffineFastState.Bounded env47634 := by
  intro p hp
  have h : env47634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47633_47634 : H12AffineEnvironment.transform 12 673 env47633 = env47634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env47633 == env47634) = true)

theorem identity47634 : scanCanonicalize (H12AffineFastState.compose env47634 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound47634 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env47635 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3118,673,16384,3734,17051,18578,1055,16573,3735,3119,16536,2179,18593,18069,19518,16427,3119,3119,1055,172,19591,173,169,1213,18109]

theorem envBound47635 : H12AffineFastState.Bounded env47635 := by
  intro p hp
  have h : env47635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47634_47635 : H12AffineEnvironment.transform 11 3118 env47634 = env47635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env47634 == env47635) = true)

theorem identity47635 : scanCanonicalize (H12AffineFastState.compose env47635 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(13+1) ^^^ 3103) := by decide +kernel

theorem selectedBound47635 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env47636 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3118,673,3103,3734,3716,1165,1055,3234,3735,3119,3207,2179,1214,2698,33,3124,3119,3119,1055,172,152,173,169,1213,2722]

theorem envBound47636 : H12AffineFastState.Bounded env47636 := by
  intro p hp
  have h : env47636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47635_47636 : H12AffineEnvironment.transform 13 3103 env47635 = env47636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3103 env47635 == env47636) = true)

theorem identity47636 : scanCanonicalize (H12AffineFastState.compose env47636 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound47636 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47637 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1677,675,673,658,27,9,1165,1055,559,26,674,522,1550,1214,1031,33,697,674,674,1055,172,152,173,169,1213,1071]

theorem envBound47637 : H12AffineFastState.Bounded env47637 := by
  intro p hp
  have h : env47637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47636_47637 : H12AffineEnvironment.transform 10 1677 env47636 = env47637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env47636 == env47637) = true)

theorem identity47637 : scanCanonicalize (H12AffineFastState.compose env47637 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound47637 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47638 : List Nat := [2,4,8,16,32,17,128,172,512,517,136,675,673,658,27,9,648,538,559,26,674,522,11,699,514,33,697,674,674,538,172,152,173,169,696,554]

theorem envBound47638 : H12AffineFastState.Bounded env47638 := by
  intro p hp
  have h : env47638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47637_47638 : H12AffineEnvironment.transform 9 517 env47637 = env47638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env47637 == env47638) = true)

theorem identity47638 : scanCanonicalize (H12AffineFastState.compose env47638 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47638 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env47639 : List Nat := [2,4,8,16,32,17,8,36,512,517,0,555,553,538,27,9,512,538,559,26,554,522,11,563,514,33,561,554,554,538,36,16,37,33,560,554]

theorem envBound47639 : H12AffineFastState.Bounded env47639 := by
  intro p hp
  have h : env47639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47638_47639 : H12AffineEnvironment.transform 6 8 env47638 = env47639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47638 == env47639) = true)

theorem identity47639 : scanCanonicalize (H12AffineFastState.compose env47639 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47639 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47640 : List Nat := [2,4,8,16,32,17,8,36,0,5,0,43,41,26,27,9,0,26,47,26,42,10,11,51,2,33,49,42,42,26,36,16,37,33,48,42]

theorem envBound47640 : H12AffineFastState.Bounded env47640 := by
  intro p hp
  have h : env47640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47639_47640 : H12AffineEnvironment.transform 8 0 env47639 = env47640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47639 == env47640) = true)

theorem identity47640 : scanCanonicalize (H12AffineFastState.compose env47640 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47640 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47641 : List Nat := [2,4,8,16,16,17,8,20,0,5,0,27,25,26,27,9,0,26,31,26,26,10,11,3,2,17,1,26,26,26,20,16,21,17,0,26]

theorem envBound47641 : H12AffineFastState.Bounded env47641 := by
  intro p hp
  have h : env47641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47640_47641 : H12AffineEnvironment.transform 4 16 env47640 = env47641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47640 == env47641) = true)

theorem identity47641 : scanCanonicalize (H12AffineFastState.compose env47641 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47642 : List Nat := [2,3,8,16,16,17,8,19,0,2,0,27,25,26,27,9,0,26,24,26,26,10,11,3,2,17,1,26,26,26,19,16,18,17,0,26]

theorem envBound47642 : H12AffineFastState.Bounded env47642 := by
  intro p hp
  have h : env47642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47641_47642 : H12AffineEnvironment.transform 1 3 env47641 = env47642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47641 == env47642) = true)

theorem identity47642 : scanCanonicalize (H12AffineFastState.compose env47642 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47643 : List Nat := [2,3,8,11,11,10,8,8,0,2,0,0,2,1,0,9,0,1,3,1,1,10,11,3,2,10,1,1,1,1,8,11,9,10,0,1]

theorem envBound47643 : H12AffineFastState.Bounded env47643 := by
  intro p hp
  have h : env47643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47642_47643 : H12AffineEnvironment.transform 3 11 env47642 = env47643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47642 == env47643) = true)

theorem identity47643 : scanCanonicalize (H12AffineFastState.compose env47643 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47644 : List Nat := [2,3,0,3,3,2,0,0,0,2,0,0,2,1,0,1,0,1,3,1,1,2,3,3,2,2,1,1,1,1,0,3,1,2,0,1]

theorem envBound47644 : H12AffineFastState.Bounded env47644 := by
  intro p hp
  have h : env47644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47643_47644 : H12AffineEnvironment.transform 2 0 env47643 = env47644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47643 == env47644) = true)

theorem identity47644 : scanCanonicalize (H12AffineFastState.compose env47644 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47644 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47645 : List Nat := [1,0,0,0,0,1,0,0,0,1,0,0,1,1,0,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,0,0,1,1,0,1]

theorem envBound47645 : H12AffineFastState.Bounded env47645 := by
  intro p hp
  have h : env47645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47644_47645 : H12AffineEnvironment.transform 0 1 env47644 = env47645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47644 == env47645) = true)

def env47646 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143496,20496,508154,148717,148717,96346,90263,222334,172,90258,1261,135681]

theorem envBound47646 : H12AffineFastState.Bounded env47646 := by
  intro p hp
  have h : env47646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47619_47646 : H12AffineEnvironment.transform 7 173 env47619 = env47646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47619 == env47646) = true)

def env47647 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143496,20496,508074,148669,148669,96266,90263,222254,172,90258,1213,135681]

theorem envBound47647 : H12AffineFastState.Bounded env47647 := by
  intro p hp
  have h : env47647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47646_47647 : H12AffineEnvironment.transform 5 16 env47646 = env47647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47646 == env47647) = true)

theorem identity47647 : scanCanonicalize (H12AffineFastState.compose env47647 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound47647 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47648 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,58519,32808,20496,356362,62493,62493,96266,90263,119950,172,90258,1213,41633]

theorem envBound47648 : H12AffineFastState.Bounded env47648 := by
  intro p hp
  have h : env47648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47647_47648 : H12AffineEnvironment.transform 16 45216 env47647 = env47648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env47647 == env47648) = true)

theorem identity47648 : scanCanonicalize (H12AffineFastState.compose env47648 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound47648 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47649 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4097,61568,61616,58519,32808,20496,96386,62493,62493,96266,90263,119950,172,90258,1213,41633]

theorem envBound47649 : H12AffineFastState.Bounded env47649 := by
  intro p hp
  have h : env47649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47648_47649 : H12AffineEnvironment.transform 17 2184 env47648 = env47649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env47648 == env47649) = true)

theorem identity47649 : scanCanonicalize (H12AffineFastState.compose env47649 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound47649 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47650 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,49306,45216,2184,42145,32769,4097,61568,61616,58519,32808,20496,47128,62493,62493,47248,40973,5140,172,40968,1213,41633]

theorem envBound47650 : H12AffineFastState.Bounded env47650 := by
  intro p hp
  have h : env47650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47649_47650 : H12AffineEnvironment.transform 15 49306 env47649 = env47650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env47649 == env47650) = true)

theorem identity47650 : scanCanonicalize (H12AffineFastState.compose env47650 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound47650 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env47651 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,13374,17412,2184,20485,29861,4097,1060,1044,4147,29836,20496,19644,185,185,19508,21673,5140,172,21676,1213,22021]

theorem envBound47651 : H12AffineFastState.Bounded env47651 := by
  intro p hp
  have h : env47651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47650_47651 : H12AffineEnvironment.transform 14 29860 env47650 = env47651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env47650 == env47651) = true)

theorem identity47651 : scanCanonicalize (H12AffineFastState.compose env47651 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound47651 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env47652 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7196,16384,18616,2082,17412,2184,20485,18617,4097,1060,1044,4147,18576,20496,19644,185,185,19508,21673,5140,172,21676,1213,22021]

theorem envBound47652 : H12AffineFastState.Bounded env47652 := by
  intro p hp
  have h : env47652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47651_47652 : H12AffineEnvironment.transform 12 7196 env47651 = env47652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env47651 == env47652) = true)

theorem identity47652 : scanCanonicalize (H12AffineFastState.compose env47652 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound47652 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env47653 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7196,1540,3772,2082,512,2184,5633,3773,4097,1060,1044,4147,3732,5652,2744,185,185,2608,4781,5140,172,4776,1213,4097]

theorem envBound47653 : H12AffineFastState.Bounded env47653 := by
  intro p hp
  have h : env47653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47652_47653 : H12AffineEnvironment.transform 13 1540 env47652 = env47653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env47652 == env47653) = true)

theorem identity47653 : scanCanonicalize (H12AffineFastState.compose env47653 (packedSelected [1,2,4,7,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound47653 : packedSelected [1,2,4,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env47654 : List Nat := [2,4,8,16,32,16,128,173,512,565,2048,4096,6697,49,2185,2082,512,2184,4148,2184,4097,529,545,4147,2209,4129,2744,185,185,2608,4781,4641,172,4776,648,4097]

theorem envBound47654 : H12AffineFastState.Bounded env47654 := by
  intro p hp
  have h : env47654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47653_47654 : H12AffineEnvironment.transform 9 565 env47653 = env47654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env47653 == env47654) = true)

theorem identity47654 : scanCanonicalize (H12AffineFastState.compose env47654 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound47654 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env47655 : List Nat := [2,4,8,16,32,16,128,173,512,565,658,4096,4283,49,539,688,512,538,4148,538,4097,529,545,4147,563,4129,42,185,185,162,4781,4641,172,4776,648,4097]

theorem envBound47655 : H12AffineFastState.Bounded env47655 := by
  intro p hp
  have h : env47655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47654_47655 : H12AffineEnvironment.transform 10 658 env47654 = env47655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env47654 == env47655) = true)

theorem identity47655 : scanCanonicalize (H12AffineFastState.compose env47655 (packedSelected [0,5,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound47655 : packedSelected [0,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47656 : List Nat := [2,4,8,16,32,16,128,173,512,565,658,648,563,49,539,688,512,538,700,538,649,529,545,699,563,681,42,185,185,162,37,169,172,32,648,649]

theorem envBound47656 : H12AffineFastState.Bounded env47656 := by
  intro p hp
  have h : env47656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47655_47656 : H12AffineEnvironment.transform 11 648 env47655 = env47656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env47655 == env47656) = true)

theorem identity47656 : scanCanonicalize (H12AffineFastState.compose env47656 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47656 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47657 : List Nat := [2,4,8,16,16,16,128,157,512,517,658,648,515,1,539,640,512,538,652,538,649,529,529,651,515,665,26,137,137,146,21,153,156,16,648,649]

theorem envBound47657 : H12AffineFastState.Bounded env47657 := by
  intro p hp
  have h : env47657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47656_47657 : H12AffineEnvironment.transform 4 16 env47656 = env47657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47656 == env47657) = true)

theorem identity47657 : scanCanonicalize (H12AffineFastState.compose env47657 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound47657 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47658 : List Nat := [2,4,8,16,16,16,128,157,27,30,137,147,24,1,0,155,27,1,151,1,146,10,10,144,24,130,26,137,137,146,21,153,156,16,147,146]

theorem envBound47658 : H12AffineFastState.Bounded env47658 := by
  intro p hp
  have h : env47658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47657_47658 : H12AffineEnvironment.transform 8 27 env47657 = env47658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env47657 == env47658) = true)

theorem identity47658 : scanCanonicalize (H12AffineFastState.compose env47658 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47659 : List Nat := [2,4,8,16,16,16,18,15,27,30,27,1,24,1,0,9,27,1,5,1,0,10,10,2,24,16,26,27,27,0,21,11,14,16,1,0]

theorem envBound47659 : H12AffineFastState.Bounded env47659 := by
  intro p hp
  have h : env47659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47658_47659 : H12AffineEnvironment.transform 6 18 env47658 = env47659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47658 == env47659) = true)

theorem identity47659 : scanCanonicalize (H12AffineFastState.compose env47659 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47659 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47660 : List Nat := [2,4,8,10,10,10,8,15,1,4,1,1,2,1,0,9,1,1,5,1,0,10,10,2,2,10,0,1,1,0,15,11,14,10,1,0]

theorem envBound47660 : H12AffineFastState.Bounded env47660 := by
  intro p hp
  have h : env47660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47659_47660 : H12AffineEnvironment.transform 3 10 env47659 = env47660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47659 == env47660) = true)

theorem identity47660 : scanCanonicalize (H12AffineFastState.compose env47660 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47661 : List Nat := [2,1,8,10,10,10,8,10,1,1,1,1,2,1,0,9,1,1,0,1,0,10,10,2,2,10,0,1,1,0,10,11,11,10,1,0]

theorem envBound47661 : H12AffineFastState.Bounded env47661 := by
  intro p hp
  have h : env47661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47660_47661 : H12AffineEnvironment.transform 1 1 env47660 = env47661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47660 == env47661) = true)

theorem identity47661 : scanCanonicalize (H12AffineFastState.compose env47661 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47662 : List Nat := [2,1,0,2,2,2,0,2,1,1,1,1,2,1,0,1,1,1,0,1,0,2,2,2,2,2,0,1,1,0,2,3,3,2,1,0]

theorem envBound47662 : H12AffineFastState.Bounded env47662 := by
  intro p hp
  have h : env47662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47661_47662 : H12AffineEnvironment.transform 2 0 env47661 = env47662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47661 == env47662) = true)

theorem identity47662 : scanCanonicalize (H12AffineFastState.compose env47662 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47662 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47663 : List Nat := [0,1,0,0,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,1,0,0,0,0,0,0,0,1,1,0,0,1,1,0,1,0]

theorem envBound47663 : H12AffineFastState.Bounded env47663 := by
  intro p hp
  have h : env47663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47662_47663 : H12AffineEnvironment.transform 0 0 env47662 = env47663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47662 == env47663) = true)

def env47664 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143496,20496,508075,148668,148668,96267,90263,222255,172,90258,1212,135681]

theorem envBound47664 : H12AffineFastState.Bounded env47664 := by
  intro p hp
  have h : env47664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47646_47664 : H12AffineEnvironment.transform 5 17 env47646 = env47664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47646 == env47664) = true)

theorem identity47664 : scanCanonicalize (H12AffineFastState.compose env47664 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound47664 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47665 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,58519,143496,20496,120867,148668,148668,96267,90263,222255,172,90258,1212,135681]

theorem envBound47665 : H12AffineFastState.Bounded env47665 := by
  intro p hp
  have h : env47665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47664_47665 : H12AffineEnvironment.transform 17 137352 env47664 = env47665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env47664 == env47665) = true)

theorem identity47665 : scanCanonicalize (H12AffineFastState.compose env47665 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound47665 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env47666 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4097,61569,46092,58519,50325,20496,120867,45217,45217,96267,90263,102450,172,90258,1212,58908]

theorem envBound47666 : H12AffineFastState.Bounded env47666 := by
  intro p hp
  have h : env47666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47665_47666 : H12AffineEnvironment.transform 16 62493 env47665 = env47666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env47665 == env47666) = true)

theorem identity47666 : scanCanonicalize (H12AffineFastState.compose env47666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound47666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47667 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,32768,65536,58532,60565,57372,32769,184,57400,42165,58519,50325,16553,116890,40984,40984,92338,90263,98443,172,90258,1212,58908]

theorem envBound47667 : H12AffineFastState.Bounded env47667 := by
  intro p hp
  have h : env47667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47666_47667 : H12AffineEnvironment.transform 11 185 env47666 = env47667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env47666 == env47667) = true)

theorem identity47667 : scanCanonicalize (H12AffineFastState.compose env47667 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 19991) := by decide +kernel

theorem selectedBound47667 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47668 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,32768,19991,58532,60565,57372,32769,184,57400,42165,58519,50325,16553,34445,40984,40984,9893,11904,52892,172,11909,1212,58908]

theorem envBound47668 : H12AffineFastState.Bounded env47668 := by
  intro p hp
  have h : env47668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47667_47668 : H12AffineEnvironment.transform 15 19991 env47667 = env47668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19991 env47667 == env47668) = true)

theorem identity47668 : scanCanonicalize (H12AffineFastState.compose env47668 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound47668 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env47669 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,3724,19991,27176,25113,28304,3725,184,28340,10809,27163,18969,16553,2049,11924,11924,9893,11904,16400,172,11909,1212,26768]

theorem envBound47669 : H12AffineFastState.Bounded env47669 := by
  intro p hp
  have h : env47669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47668_47669 : H12AffineEnvironment.transform 14 3724 env47668 = env47669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env47668 == env47669) = true)

theorem identity47669 : scanCanonicalize (H12AffineFastState.compose env47669 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 10896) := by decide +kernel

theorem selectedBound47669 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env47670 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,10896,3724,9351,184,2185,1024,3725,184,1060,10809,139,8329,10809,2049,11924,11924,9893,11904,10880,172,11909,1212,512]

theorem envBound47670 : H12AffineFastState.Bounded env47670 := by
  intro p hp
  have h : env47670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47669_47670 : H12AffineEnvironment.transform 13 10896 env47669 = env47670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10896 env47669 == env47670) = true)

theorem identity47670 : scanCanonicalize (H12AffineFastState.compose env47670 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound47670 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env47671 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2721,49,3724,3622,184,2185,1024,3725,184,1060,152,139,2600,152,2049,1077,1077,3076,1057,33,172,1060,1212,512]

theorem envBound47671 : H12AffineFastState.Bounded env47671 := by
  intro p hp
  have h : env47671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47670_47671 : H12AffineEnvironment.transform 12 2721 env47670 = env47671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env47670 == env47671) = true)

theorem identity47671 : scanCanonicalize (H12AffineFastState.compose env47671 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound47671 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47672 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,185,2235,49,3222,3132,184,2185,1024,3223,184,1060,152,139,2098,152,2049,1077,1077,3076,1057,33,172,1060,1212,26]

theorem envBound47672 : H12AffineFastState.Bounded env47672 := by
  intro p hp
  have h : env47672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47671_47672 : H12AffineEnvironment.transform 8 26 env47671 = env47672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env47671 == env47672) = true)

theorem identity47672 : scanCanonicalize (H12AffineFastState.compose env47672 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47672 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env47673 : List Nat := [2,4,8,11,32,10,128,173,1,1024,2048,162,2208,42,3213,3111,163,2185,1024,3212,163,1060,131,139,2089,131,2049,1070,1070,3076,1057,33,172,1060,1191,1]

theorem envBound47673 : H12AffineFastState.Bounded env47673 := by
  intro p hp
  have h : env47673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47672_47673 : H12AffineEnvironment.transform 3 11 env47672 = env47673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47672 == env47673) = true)

theorem identity47673 : scanCanonicalize (H12AffineFastState.compose env47673 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound47673 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47674 : List Nat := [2,4,8,11,32,10,128,173,1,5,2048,162,2208,42,2184,2082,163,2185,5,2185,163,33,131,139,2089,131,2049,43,43,2049,36,33,172,33,162,1]

theorem envBound47674 : H12AffineFastState.Bounded env47674 := by
  intro p hp
  have h : env47674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47673_47674 : H12AffineEnvironment.transform 9 5 env47673 = env47674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env47673 == env47674) = true)

theorem identity47674 : scanCanonicalize (H12AffineFastState.compose env47674 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound47674 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47675 : List Nat := [2,4,8,11,32,10,128,173,1,5,163,162,3,42,43,129,163,42,5,42,163,33,131,139,138,131,162,43,43,162,36,33,172,33,162,1]

theorem envBound47675 : H12AffineFastState.Bounded env47675 := by
  intro p hp
  have h : env47675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47674_47675 : H12AffineEnvironment.transform 10 163 env47674 = env47675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env47674 == env47675) = true)

theorem identity47675 : scanCanonicalize (H12AffineFastState.compose env47675 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47675 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env47676 : List Nat := [2,4,8,11,32,10,9,36,1,5,42,43,3,42,43,8,42,42,5,42,42,33,10,2,3,10,43,43,43,43,36,33,37,33,43,1]

theorem envBound47676 : H12AffineFastState.Bounded env47676 := by
  intro p hp
  have h : env47676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47675_47676 : H12AffineEnvironment.transform 6 9 env47675 = env47676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47675 == env47676) = true)

theorem identity47676 : scanCanonicalize (H12AffineFastState.compose env47676 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47676 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47677 : List Nat := [2,4,5,6,32,7,4,36,1,5,39,38,3,39,38,5,39,39,5,39,39,33,7,2,3,7,38,38,38,38,36,33,37,33,38,1]

theorem envBound47677 : H12AffineFastState.Bounded env47677 := by
  intro p hp
  have h : env47677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47676_47677 : H12AffineEnvironment.transform 2 5 env47676 = env47677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47676 == env47677) = true)

theorem identity47677 : scanCanonicalize (H12AffineFastState.compose env47677 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47678 : List Nat := [2,4,5,6,6,7,4,2,1,5,1,0,3,1,0,5,1,1,5,1,1,7,7,2,3,7,0,0,0,0,2,7,3,7,0,1]

theorem envBound47678 : H12AffineFastState.Bounded env47678 := by
  intro p hp
  have h : env47678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47677_47678 : H12AffineEnvironment.transform 4 6 env47677 = env47678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47677 == env47678) = true)

def env47679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245633,148800,545089,96346,16876544,618622,257,16876548,1345,525824]

theorem envBound47679 : H12AffineFastState.Bounded env47679 := by
  intro p hp
  have h : env47679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47559_47679 : H12AffineEnvironment.transform 26 17245633 env47559 = env47679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env47559 == env47679) = true)

theorem identity47679 : scanCanonicalize (H12AffineFastState.compose env47679 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound47679 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41002,533641,672785,493035,148800,545089,96346,74794,618622,257,74798,1345,525824]

theorem envBound47680 : H12AffineFastState.Bounded env47680 := by
  intro p hp
  have h : env47680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47679_47680 : H12AffineEnvironment.transform 23 41002 env47679 = env47680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env47679 == env47680) = true)

def env47681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,493035,148800,148801,96346,74794,222334,257,74798,1345,135680]

theorem envBound47681 : H12AffineFastState.Bounded env47681 := by
  intro p hp
  have h : env47681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47680_47681 : H12AffineEnvironment.transform 18 136192 env47680 = env47681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env47680 == env47681) = true)

def env47682 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,492615,148716,148717,96346,74794,222334,173,74798,1261,135680]

theorem envBound47682 : H12AffineFastState.Bounded env47682 := by
  intro p hp
  have h : env47682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47681_47682 : H12AffineEnvironment.transform 7 172 env47681 = env47682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env47681 == env47682) = true)

def env47683 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143497,20497,492567,148668,148669,96266,74794,222254,173,74798,1213,135680]

theorem envBound47683 : H12AffineFastState.Bounded env47683 := by
  intro p hp
  have h : env47683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47682_47683 : H12AffineEnvironment.transform 5 16 env47682 = env47683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47682 == env47683) = true)

theorem identity47683 : scanCanonicalize (H12AffineFastState.compose env47683 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound47683 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47684 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61568,147472,41002,143497,20497,60444,148668,148669,96266,74794,222254,173,74798,1213,135680]

theorem envBound47684 : H12AffineFastState.Bounded env47684 := by
  intro p hp
  have h : env47684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47683_47684 : H12AffineEnvironment.transform 17 223243 env47683 = env47684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env47683 == env47684) = true)

theorem identity47684 : scanCanonicalize (H12AffineFastState.compose env47684 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound47684 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47685 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4097,61568,147472,41002,143497,20497,60444,148668,148669,2185,21673,136365,173,21677,1213,135680]

theorem envBound47685 : H12AffineFastState.Bounded env47685 := by
  intro p hp
  have h : env47685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47684_47685 : H12AffineEnvironment.transform 15 28803 env47684 = env47685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env47684 == env47685) = true)

theorem identity47685 : scanCanonicalize (H12AffineFastState.compose env47685 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58533) := by decide +kernel

theorem selectedBound47685 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env47686 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,58533,64557,61605,32769,4097,61568,42165,41002,54316,20497,60444,40985,40984,2185,21673,61448,173,21677,1213,63141]

theorem envBound47686 : H12AffineFastState.Bounded env47686 := by
  intro p hp
  have h : env47686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47685_47686 : H12AffineEnvironment.transform 16 58533 env47685 = env47686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58533 env47685 == env47686) = true)

theorem identity47686 : scanCanonicalize (H12AffineFastState.compose env47686 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47686 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env47687 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,40984,47248,46104,32769,4097,46141,42165,41002,37009,5292,43169,40985,40984,2185,4116,46261,173,4112,1213,45592]

theorem envBound47687 : H12AffineFastState.Bounded env47687 := by
  intro p hp
  have h : env47687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47686_47687 : H12AffineEnvironment.transform 13 1213 env47686 = env47687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env47686 == env47687) = true)

theorem identity47687 : scanCanonicalize (H12AffineFastState.compose env47687 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound47687 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env47688 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2099,1213,32768,7181,34859,37027,39979,32769,4097,39950,35974,34841,37009,5292,32914,34858,34859,2185,4116,40070,173,4112,1213,39467]

theorem envBound47688 : H12AffineFastState.Bounded env47688 := by
  intro p hp
  have h : env47688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47687_47688 : H12AffineEnvironment.transform 12 2099 env47687 = env47688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env47687 == env47688) = true)

theorem identity47688 : scanCanonicalize (H12AffineFastState.compose env47688 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 3222) := by decide +kernel

theorem selectedBound47688 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47689 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2099,1213,3222,7181,1213,7221,4285,3223,4097,4248,16,1167,7175,5292,3076,1212,1213,2185,4116,4112,173,4112,1213,5821]

theorem envBound47689 : H12AffineFastState.Bounded env47689 := by
  intro p hp
  have h : env47689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47688_47689 : H12AffineEnvironment.transform 14 3222 env47688 = env47689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3222 env47688 == env47689) = true)

theorem identity47689 : scanCanonicalize (H12AffineFastState.compose env47689 (packedSelected [6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound47689 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env47690 : List Nat := [2,4,8,16,32,16,128,172,512,19,2048,4096,2099,174,2181,6174,174,6182,4285,2180,4097,4248,16,156,6164,4287,2071,175,174,2185,4116,4112,173,4112,174,4782]

theorem envBound47690 : H12AffineFastState.Bounded env47690 := by
  intro p hp
  have h : env47690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47689_47690 : H12AffineEnvironment.transform 9 19 env47689 = env47690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env47689 == env47690) = true)

theorem identity47690 : scanCanonicalize (H12AffineFastState.compose env47690 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 686) := by decide +kernel

theorem selectedBound47690 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env47691 : List Nat := [2,4,8,16,32,16,128,172,512,19,2048,686,2099,174,2181,2736,174,2696,531,2180,687,566,16,156,2746,529,2071,175,174,2185,698,702,173,702,174,0]

theorem envBound47691 : H12AffineFastState.Bounded env47691 := by
  intro p hp
  have h : env47691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47690_47691 : H12AffineEnvironment.transform 11 686 env47690 = env47691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 686 env47690 == env47691) = true)

theorem identity47691 : scanCanonicalize (H12AffineFastState.compose env47691 (packedSelected [1,2,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound47691 : packedSelected [1,2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env47692 : List Nat := [2,4,8,16,32,16,128,172,512,19,675,686,656,174,550,19,174,43,531,551,687,566,16,156,25,529,692,175,174,554,698,702,173,702,174,0]

theorem envBound47692 : H12AffineFastState.Bounded env47692 := by
  intro p hp
  have h : env47692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47691_47692 : H12AffineEnvironment.transform 10 675 env47691 = env47692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env47691 == env47692) = true)

theorem identity47692 : scanCanonicalize (H12AffineFastState.compose env47692 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47692 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47693 : List Nat := [2,4,8,16,32,16,18,62,512,19,561,572,514,60,550,19,60,43,531,551,573,566,16,14,25,529,550,61,60,554,552,556,63,556,60,0]

theorem envBound47693 : H12AffineFastState.Bounded env47693 := by
  intro p hp
  have h : env47693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47692_47693 : H12AffineEnvironment.transform 6 18 env47692 = env47693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47692 == env47693) = true)

def env47694 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143497,20497,492566,148669,148668,96267,74794,222255,173,74798,1212,135680]

theorem envBound47694 : H12AffineFastState.Bounded env47694 := by
  intro p hp
  have h : env47694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47682_47694 : H12AffineEnvironment.transform 5 17 env47682 = env47694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47682 == env47694) = true)

theorem identity47694 : scanCanonicalize (H12AffineFastState.compose env47694 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound47694 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47695 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61569,98355,41002,127147,20497,279604,99487,99486,96267,74794,41997,173,74798,1212,119330]

theorem envBound47695 : H12AffineFastState.Bounded env47695 := by
  intro p hp
  have h : env47695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47694_47695 : H12AffineEnvironment.transform 16 114722 env47694 = env47695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env47694 == env47695) = true)

theorem identity47695 : scanCanonicalize (H12AffineFastState.compose env47695 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 101550) := by decide +kernel

theorem selectedBound47695 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47696 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,101550,119842,32769,4097,61569,98355,41002,127147,20497,116890,99487,99486,96267,74794,41997,173,74798,1212,119330]

theorem envBound47696 : H12AffineFastState.Bounded env47696 := by
  intro p hp
  have h : env47696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47695_47696 : H12AffineEnvironment.transform 17 101550 env47695 = env47696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 101550 env47695 == env47696) = true)

theorem identity47696 : scanCanonicalize (H12AffineFastState.compose env47696 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound47696 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47697 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,23692,1024,32769,4097,61569,20497,41002,8329,20497,6328,21693,21692,43049,62472,41997,173,62476,1212,512]

theorem envBound47697 : H12AffineFastState.Bounded env47697 := by
  intro p hp
  have h : env47697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47696_47697 : H12AffineEnvironment.transform 15 53282 env47696 = env47697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env47696 == env47697) = true)

theorem identity47697 : scanCanonicalize (H12AffineFastState.compose env47697 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound47697 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47698 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12313,24635,4096,23692,1024,12312,4097,16536,20497,4147,8329,20497,6328,21693,21692,6192,17425,5140,173,17429,1212,512]

theorem envBound47698 : H12AffineFastState.Bounded env47698 := by
  intro p hp
  have h : env47698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47697_47698 : H12AffineEnvironment.transform 14 12313 env47697 = env47698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env47697 == env47698) = true)

theorem identity47698 : scanCanonicalize (H12AffineFastState.compose env47698 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound47698 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47699 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,8745,12313,530,4096,16037,1024,12312,4097,8881,12856,4147,8329,12856,6328,13972,13973,6192,9784,5140,173,9788,1212,512]

theorem envBound47699 : H12AffineFastState.Bounded env47699 := by
  intro p hp
  have h : env47699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47698_47699 : H12AffineEnvironment.transform 13 8745 env47698 = env47699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env47698 == env47699) = true)

theorem identity47699 : scanCanonicalize (H12AffineFastState.compose env47699 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 5175) := by decide +kernel

theorem selectedBound47699 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env47700 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5175,5662,1070,530,4096,2706,1024,1071,4097,5766,1551,4147,5310,1551,6328,675,674,6192,4623,5140,173,4619,1212,512]

theorem envBound47700 : H12AffineFastState.Bounded env47700 := by
  intro p hp
  have h : env47700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47699_47700 : H12AffineEnvironment.transform 12 5175 env47699 = env47700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5175 env47699 == env47700) = true)

def env47701 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,492614,148717,148716,96346,74794,222334,172,74798,1260,135680]

theorem envBound47701 : H12AffineFastState.Bounded env47701 := by
  intro p hp
  have h : env47701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47681_47701 : H12AffineEnvironment.transform 7 173 env47681 = env47701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47681 == env47701) = true)

def env47702 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143497,20497,492566,148669,148668,96266,74794,222254,172,74798,1212,135680]

theorem envBound47702 : H12AffineFastState.Bounded env47702 := by
  intro p hp
  have h : env47702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47701_47702 : H12AffineEnvironment.transform 5 16 env47701 = env47702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47701 == env47702) = true)

theorem identity47702 : scanCanonicalize (H12AffineFastState.compose env47702 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound47702 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47703 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,41002,143497,20497,105631,148669,148668,96266,74794,222254,172,74798,1212,135680]

theorem envBound47703 : H12AffineFastState.Bounded env47703 := by
  intro p hp
  have h : env47703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47702_47703 : H12AffineEnvironment.transform 17 137353 env47702 = env47703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env47702 == env47703) = true)

theorem identity47703 : scanCanonicalize (H12AffineFastState.compose env47703 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound47703 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47704 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4097,61568,147472,41002,143497,20497,43168,148669,148668,19509,4117,151569,172,4113,1212,135680]

theorem envBound47704 : H12AffineFastState.Bounded env47704 := by
  intro p hp
  have h : env47704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47703_47704 : H12AffineEnvironment.transform 15 13375 env47703 = env47704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env47703 == env47704) = true)

theorem identity47704 : scanCanonicalize (H12AffineFastState.compose env47704 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound47704 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47705 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136192,32769,4097,46140,132268,41002,143497,5293,43168,131073,131072,2185,4117,136365,172,4113,1212,135680]

theorem envBound47705 : H12AffineFastState.Bounded env47705 := by
  intro p hp
  have h : env47705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47704_47705 : H12AffineEnvironment.transform 13 1212 env47704 = env47705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env47704 == env47705) = true)

theorem identity47705 : scanCanonicalize (H12AffineFastState.compose env47705 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound47705 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env47706 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,13375,131072,137353,136192,9381,4097,4248,132268,1166,143497,5293,3076,131073,131072,2185,4117,136365,172,4113,1212,135680]

theorem envBound47706 : H12AffineFastState.Bounded env47706 := by
  intro p hp
  have h : env47706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47705_47706 : H12AffineEnvironment.transform 14 9380 env47705 = env47706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env47705 == env47706) = true)

theorem identity47706 : scanCanonicalize (H12AffineFastState.compose env47706 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound47706 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47707 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2075,8192,1212,9380,11300,131072,131218,134171,9381,2074,2179,132268,1166,141458,3254,3076,131073,131072,2185,2062,134326,172,2058,1212,133659]

theorem envBound47707 : H12AffineFastState.Bounded env47707 := by
  intro p hp
  have h : env47707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47706_47707 : H12AffineEnvironment.transform 11 2075 env47706 = env47707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env47706 == env47707) = true)

theorem identity47707 : scanCanonicalize (H12AffineFastState.compose env47707 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 2234) := by decide +kernel

theorem selectedBound47707 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47708 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2075,2234,1212,3102,1182,131072,131218,134171,3103,2074,2179,132268,1166,131112,3254,3076,131073,131072,2185,2062,134326,172,2058,1212,133659]

theorem envBound47708 : H12AffineFastState.Bounded env47708 := by
  intro p hp
  have h : env47708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47707_47708 : H12AffineEnvironment.transform 12 2234 env47707 = env47708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2234 env47707 == env47708) = true)

theorem identity47708 : scanCanonicalize (H12AffineFastState.compose env47708 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound47708 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env47709 : List Nat := [2,4,8,16,32,16,128,173,136,1024,2048,2075,2234,1212,3102,1182,131072,131218,134171,3103,2074,2179,132268,1166,131112,3254,3076,131073,131072,2185,2062,134326,172,2058,1212,133267]

theorem envBound47709 : H12AffineFastState.Bounded env47709 := by
  intro p hp
  have h : env47709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47708_47709 : H12AffineEnvironment.transform 8 136 env47708 = env47709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env47708 == env47709) = true)

def env47710 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143497,20497,492567,148668,148669,96267,74794,222255,172,74798,1213,135680]

theorem envBound47710 : H12AffineFastState.Bounded env47710 := by
  intro p hp
  have h : env47710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47701_47710 : H12AffineEnvironment.transform 5 17 env47701 = env47710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47701 == env47710) = true)

theorem identity47710 : scanCanonicalize (H12AffineFastState.compose env47710 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound47710 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47711 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,41002,32808,20497,341174,62493,62492,96267,74794,119950,172,74798,1213,41633]

theorem envBound47711 : H12AffineFastState.Bounded env47711 := by
  intro p hp
  have h : env47711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47710_47711 : H12AffineEnvironment.transform 16 45217 env47710 = env47711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env47710 == env47711) = true)

theorem identity47711 : scanCanonicalize (H12AffineFastState.compose env47711 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound47711 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env47712 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4097,46141,46092,41002,32808,5293,341174,45217,45216,81079,74794,102450,172,74798,1213,41633]

theorem envBound47712 : H12AffineFastState.Bounded env47712 := by
  intro p hp
  have h : env47712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47711_47712 : H12AffineEnvironment.transform 13 1212 env47711 = env47712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env47711 == env47712) = true)

theorem identity47712 : scanCanonicalize (H12AffineFastState.compose env47712 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound47712 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47713 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,32768,65536,40985,262144,42145,32769,185,42117,42164,41002,32808,1045,336910,40985,40984,76815,74794,98442,172,74798,1213,41633]

theorem envBound47713 : H12AffineFastState.Bounded env47713 := by
  intro p hp
  have h : env47713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47712_47713 : H12AffineEnvironment.transform 11 184 env47712 = env47713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env47712 == env47713) = true)

theorem identity47713 : scanCanonicalize (H12AffineFastState.compose env47713 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound47713 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env47714 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,32768,33830,40985,262144,42145,32769,185,42117,42164,41002,32808,1045,303144,40985,40984,43049,40972,1196,172,40968,1213,41633]

theorem envBound47714 : H12AffineFastState.Bounded env47714 := by
  intro p hp
  have h : env47714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47713_47714 : H12AffineEnvironment.transform 15 33830 env47713 = env47714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env47713 == env47714) = true)

theorem identity47714 : scanCanonicalize (H12AffineFastState.compose env47714 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound47714 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env47715 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,8353,9351,184,262144,1024,8352,185,1060,1045,139,8329,1045,262281,184,185,2184,173,1196,172,169,1213,512]

theorem envBound47715 : H12AffineFastState.Bounded env47715 := by
  intro p hp
  have h : env47715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47714_47715 : H12AffineEnvironment.transform 14 8353 env47714 = env47715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env47714 == env47715) = true)

theorem identity47715 : scanCanonicalize (H12AffineFastState.compose env47715 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound47715 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47716 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2601,1212,2696,3758,184,262144,1024,2697,185,1060,1045,139,2720,1045,262281,184,185,2184,173,1196,172,169,1213,512]

theorem envBound47716 : H12AffineFastState.Bounded env47716 := by
  intro p hp
  have h : env47716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47715_47716 : H12AffineEnvironment.transform 12 2601 env47715 = env47716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env47715 == env47716) = true)

theorem identity47716 : scanCanonicalize (H12AffineFastState.compose env47716 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound47716 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47717 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2601,1212,2696,3758,184,2707,1024,2697,185,1060,1045,139,2720,1045,2586,184,185,2184,173,1196,172,169,1213,512]

theorem envBound47717 : H12AffineFastState.Bounded env47717 := by
  intro p hp
  have h : env47717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47716_47717 : H12AffineEnvironment.transform 17 2707 env47716 = env47717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env47716 == env47717) = true)

end H12CloudChart2