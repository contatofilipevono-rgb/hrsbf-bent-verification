import H12CloudChart2Data142

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound35566 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35567 : List Nat := [2,4,8,0,32,64,128,68,1,4,2048,0,8192,64,8201,8230,76,8358,5,8200,1,137,77,8231,8328,12,106,13,65,2092,8205,8261,69,64,0,0]

theorem envBound35567 : H12AffineFastState.Bounded env35567 := by
  intro p hp
  have h : env35567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35566_35567 : H12AffineEnvironment.transform 7 68 env35566 = env35567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35566 == env35567) = true)

theorem identity35567 : scanCanonicalize (H12AffineFastState.compose env35567 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound35567 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35568 : List Nat := [2,4,8,0,32,64,128,68,1,4,2048,0,68,64,77,98,76,226,5,76,1,137,77,99,204,12,106,13,65,2092,73,1,69,64,0,0]

theorem envBound35568 : H12AffineFastState.Bounded env35568 := by
  intro p hp
  have h : env35568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35567_35568 : H12AffineEnvironment.transform 12 68 env35567 = env35568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env35567 == env35568) = true)

theorem identity35568 : scanCanonicalize (H12AffineFastState.compose env35568 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound35568 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35569 : List Nat := [2,4,8,0,32,13,128,9,1,4,2048,0,9,13,0,47,1,175,5,1,1,137,0,46,129,12,39,13,12,2092,4,1,8,13,0,0]

theorem envBound35569 : H12AffineFastState.Bounded env35569 := by
  intro p hp
  have h : env35569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35568_35569 : H12AffineEnvironment.transform 5 13 env35568 = env35569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env35568 == env35569) = true)

theorem identity35569 : scanCanonicalize (H12AffineFastState.compose env35569 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35569 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35570 : List Nat := [2,4,8,0,32,13,128,9,1,4,33,0,9,13,0,47,1,175,5,1,1,137,0,46,129,12,39,13,12,13,4,1,8,13,0,0]

theorem envBound35570 : H12AffineFastState.Bounded env35570 := by
  intro p hp
  have h : env35570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35569_35570 : H12AffineEnvironment.transform 10 33 env35569 = env35570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35569 == env35570) = true)

theorem identity35570 : scanCanonicalize (H12AffineFastState.compose env35570 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound35570 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35571 : List Nat := [2,4,8,0,32,13,42,9,1,4,33,0,9,13,0,47,1,5,5,1,1,35,0,46,43,12,39,13,12,13,4,1,8,13,0,0]

theorem envBound35571 : H12AffineFastState.Bounded env35571 := by
  intro p hp
  have h : env35571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35570_35571 : H12AffineEnvironment.transform 6 42 env35570 = env35571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env35570 == env35571) = true)

theorem identity35571 : scanCanonicalize (H12AffineFastState.compose env35571 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound35571 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env35572 : List Nat := [2,4,8,0,15,13,5,9,1,4,14,0,9,13,0,0,1,5,5,1,1,12,0,1,4,12,8,13,12,13,4,1,8,13,0,0]

theorem envBound35572 : H12AffineFastState.Bounded env35572 := by
  intro p hp
  have h : env35572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35571_35572 : H12AffineEnvironment.transform 4 15 env35571 = env35572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env35571 == env35572) = true)

def env35573 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,8192,65,8524,8546,77,8674,321,8525,1,461,77,8547,8329,13,302,12,64,2409,8205,8261,257,65,1,325]

theorem envBound35573 : H12AffineFastState.Bounded env35573 := by
  intro p hp
  have h : env35573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35565_35573 : H12AffineEnvironment.transform 9 321 env35565 = env35573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35565 == env35573) = true)

theorem identity35573 : scanCanonicalize (H12AffineFastState.compose env35573 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound35573 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35574 : List Nat := [2,4,8,0,32,64,128,72,13,9,2048,0,8192,65,8196,8234,77,8362,9,8197,1,133,77,8235,8329,13,102,12,64,2081,8205,8261,73,65,1,13]

theorem envBound35574 : H12AffineFastState.Bounded env35574 := by
  intro p hp
  have h : env35574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35573_35574 : H12AffineEnvironment.transform 7 72 env35573 = env35574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env35573 == env35574) = true)

theorem identity35574 : scanCanonicalize (H12AffineFastState.compose env35574 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35574 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35575 : List Nat := [2,4,4,0,32,64,128,68,1,5,2048,0,8192,65,8196,8230,65,8358,5,8197,1,133,65,8231,8325,1,102,0,64,2081,8193,8261,69,65,1,1]

theorem envBound35575 : H12AffineFastState.Bounded env35575 := by
  intro p hp
  have h : env35575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35574_35575 : H12AffineEnvironment.transform 2 4 env35574 = env35575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35574 == env35575) = true)

theorem identity35575 : scanCanonicalize (H12AffineFastState.compose env35575 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound35575 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35576 : List Nat := [2,4,4,0,32,64,128,68,1,5,165,0,8192,65,8196,8230,65,8358,5,8197,1,133,65,8231,8325,1,102,0,64,132,8193,8261,69,65,1,1]

theorem envBound35576 : H12AffineFastState.Bounded env35576 := by
  intro p hp
  have h : env35576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35575_35576 : H12AffineEnvironment.transform 10 165 env35575 = env35576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env35575 == env35576) = true)

theorem identity35576 : scanCanonicalize (H12AffineFastState.compose env35576 (packedSelected [0,2,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35576 : packedSelected [0,2,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35577 : List Nat := [2,4,4,0,32,0,128,4,1,5,165,0,8192,1,8196,8230,1,8358,5,8197,1,133,1,8231,8325,1,38,0,0,132,8193,8197,5,1,1,1]

theorem envBound35577 : H12AffineFastState.Bounded env35577 := by
  intro p hp
  have h : env35577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35576_35577 : H12AffineEnvironment.transform 5 0 env35576 = env35577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35576 == env35577) = true)

theorem identity35577 : scanCanonicalize (H12AffineFastState.compose env35577 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound35577 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35578 : List Nat := [2,4,4,0,32,0,4,4,1,5,33,0,8192,1,8196,8230,1,8226,5,8197,1,1,1,8231,8193,1,38,0,0,0,8193,8197,5,1,1,1]

theorem envBound35578 : H12AffineFastState.Bounded env35578 := by
  intro p hp
  have h : env35578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35577_35578 : H12AffineEnvironment.transform 6 4 env35577 = env35578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env35577 == env35578) = true)

def env35579 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9228,65536,74862,65664,321,9229,1,460,74030,65536,9672,74798,303,74798,1280,77130,8205,65831,257,1280,1344,1029]

theorem envBound35579 : H12AffineFastState.Bounded env35579 := by
  intro p hp
  have h : env35579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35563_35579 : H12AffineEnvironment.transform 3 1 env35563 = env35579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35563 == env35579) = true)

theorem identity35579 : scanCanonicalize (H12AffineFastState.compose env35579 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1131) := by decide +kernel

theorem selectedBound35579 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35580 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9228,1131,8197,1259,321,9229,1,460,9541,1131,9672,8261,303,8261,1280,10529,8205,1356,257,1280,1344,1029]

theorem envBound35580 : H12AffineFastState.Bounded env35580 := by
  intro p hp
  have h : env35580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35579_35580 : H12AffineEnvironment.transform 15 1131 env35579 = env35580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1131 env35579 == env35580) = true)

def env35581 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,8192,65,8524,299,8197,427,321,8525,1,460,8197,299,8328,8261,303,8261,64,10529,8205,12,257,64,0,325]

theorem envBound35581 : H12AffineFastState.Bounded env35581 := by
  intro p hp
  have h : env35581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35580_35581 : H12AffineEnvironment.transform 9 320 env35580 = env35581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35580 == env35581) = true)

theorem identity35581 : scanCanonicalize (H12AffineFastState.compose env35581 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35581 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35582 : List Nat := [2,4,8,1,32,64,128,68,0,4,2048,0,8192,65,8200,111,8197,239,5,8201,1,136,8197,111,8328,8261,107,8261,64,10341,8205,12,69,64,0,1]

theorem envBound35582 : H12AffineFastState.Bounded env35582 := by
  intro p hp
  have h : env35582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35581_35582 : H12AffineEnvironment.transform 7 68 env35581 = env35582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35581 == env35582) = true)

theorem identity35582 : scanCanonicalize (H12AffineFastState.compose env35582 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35582 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35583 : List Nat := [2,4,4,1,32,64,128,68,0,4,2048,0,8192,65,8196,99,8197,227,5,8197,1,132,8197,99,8324,8261,103,8261,64,10341,8193,0,69,64,0,1]

theorem envBound35583 : H12AffineFastState.Bounded env35583 := by
  intro p hp
  have h : env35583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35582_35583 : H12AffineEnvironment.transform 2 4 env35582 = env35583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35582 == env35583) = true)

theorem identity35583 : scanCanonicalize (H12AffineFastState.compose env35583 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound35583 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35584 : List Nat := [2,4,4,1,32,64,128,68,0,4,2048,0,5,65,1,99,0,227,5,0,1,132,0,99,129,64,103,64,64,2144,4,0,69,64,0,1]

theorem envBound35584 : H12AffineFastState.Bounded env35584 := by
  intro p hp
  have h : env35584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35583_35584 : H12AffineEnvironment.transform 12 5 env35583 = env35584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env35583 == env35584) = true)

theorem identity35584 : scanCanonicalize (H12AffineFastState.compose env35584 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound35584 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35585 : List Nat := [2,4,4,1,32,64,128,68,0,4,226,0,5,65,1,99,0,227,5,0,1,132,0,99,129,64,103,64,64,130,4,0,69,64,0,1]

theorem envBound35585 : H12AffineFastState.Bounded env35585 := by
  intro p hp
  have h : env35585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35584_35585 : H12AffineEnvironment.transform 10 226 env35584 = env35585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env35584 == env35585) = true)

theorem identity35585 : scanCanonicalize (H12AffineFastState.compose env35585 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound35585 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env35586 : List Nat := [2,4,4,1,32,64,100,68,0,4,6,0,5,65,1,99,0,7,5,0,1,96,0,99,101,64,103,64,64,102,4,0,69,64,0,1]

theorem envBound35586 : H12AffineFastState.Bounded env35586 := by
  intro p hp
  have h : env35586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35585_35586 : H12AffineEnvironment.transform 6 100 env35585 = env35586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env35585 == env35586) = true)

theorem identity35586 : scanCanonicalize (H12AffineFastState.compose env35586 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound35586 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35587 : List Nat := [2,4,4,1,32,7,35,3,0,4,6,0,5,6,1,36,0,7,5,0,1,39,0,36,34,7,32,7,7,33,4,0,2,7,0,1]

theorem envBound35587 : H12AffineFastState.Bounded env35587 := by
  intro p hp
  have h : env35587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35586_35587 : H12AffineEnvironment.transform 5 7 env35586 = env35587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env35586 == env35587) = true)

theorem identity35587 : scanCanonicalize (H12AffineFastState.compose env35587 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35587 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35588 : List Nat := [2,1,1,1,32,2,35,3,0,1,3,0,0,3,1,33,0,2,0,0,1,34,0,33,34,2,32,2,2,33,1,0,2,2,0,1]

theorem envBound35588 : H12AffineFastState.Bounded env35588 := by
  intro p hp
  have h : env35588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35587_35588 : H12AffineEnvironment.transform 1 1 env35587 = env35588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35587 == env35588) = true)

theorem identity35588 : scanCanonicalize (H12AffineFastState.compose env35588 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35588 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35589 : List Nat := [2,1,1,1,1,2,2,3,0,1,3,0,0,3,1,0,0,2,0,0,1,3,0,0,3,2,1,2,2,0,1,0,2,2,0,1]

theorem envBound35589 : H12AffineFastState.Bounded env35589 := by
  intro p hp
  have h : env35589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35588_35589 : H12AffineEnvironment.transform 4 1 env35588 = env35589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35588 == env35589) = true)

theorem identity35589 : scanCanonicalize (H12AffineFastState.compose env35589 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35589 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env35590 : List Nat := [1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,0,1,0,0,1,0,0,0,0,1,1,1,1,0,1,0,1,1,0,1]

theorem envBound35590 : H12AffineFastState.Bounded env35590 := by
  intro p hp
  have h : env35590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35589_35590 : H12AffineEnvironment.transform 0 1 env35589 = env35590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35589 == env35590) = true)

def env35591 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,8192,64,8525,298,8197,426,321,8524,1,460,8196,298,8329,8261,303,8261,65,10529,8205,13,257,65,1,324]

theorem envBound35591 : H12AffineFastState.Bounded env35591 := by
  intro p hp
  have h : env35591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35580_35591 : H12AffineEnvironment.transform 9 321 env35580 = env35591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35580 == env35591) = true)

theorem identity35591 : scanCanonicalize (H12AffineFastState.compose env35591 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound35591 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35592 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,257,64,76,298,260,426,321,77,1,460,261,298,392,324,303,324,65,2080,268,13,257,65,1,324]

theorem envBound35592 : H12AffineFastState.Bounded env35592 := by
  intro p hp
  have h : env35592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35591_35592 : H12AffineEnvironment.transform 12 257 env35591 = env35592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env35591 == env35592) = true)

theorem identity35592 : scanCanonicalize (H12AffineFastState.compose env35592 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35592 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35593 : List Nat := [2,4,8,1,32,64,128,68,0,5,2048,0,69,64,76,110,64,238,5,77,1,136,65,110,204,0,107,0,65,2080,72,13,69,65,1,0]

theorem envBound35593 : H12AffineFastState.Bounded env35593 := by
  intro p hp
  have h : env35593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35592_35593 : H12AffineEnvironment.transform 7 68 env35592 = env35593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35592 == env35593) = true)

theorem identity35593 : scanCanonicalize (H12AffineFastState.compose env35593 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 232) := by decide +kernel

theorem selectedBound35593 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35594 : List Nat := [2,4,8,1,32,64,128,68,0,5,232,0,69,64,76,110,64,238,5,77,1,136,65,110,204,0,107,0,65,200,72,13,69,65,1,0]

theorem envBound35594 : H12AffineFastState.Bounded env35594 := by
  intro p hp
  have h : env35594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35593_35594 : H12AffineEnvironment.transform 10 232 env35593 = env35594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 232 env35593 == env35594) = true)

theorem identity35594 : scanCanonicalize (H12AffineFastState.compose env35594 (packedSelected [0,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound35594 : packedSelected [0,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35595 : List Nat := [2,4,8,1,32,64,5,68,0,5,109,0,69,64,76,110,64,107,5,77,1,13,65,110,73,0,107,0,65,77,72,13,69,65,1,0]

theorem envBound35595 : H12AffineFastState.Bounded env35595 := by
  intro p hp
  have h : env35595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35594_35595 : H12AffineEnvironment.transform 6 5 env35594 = env35595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env35594 == env35595) = true)

theorem identity35595 : scanCanonicalize (H12AffineFastState.compose env35595 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound35595 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env35596 : List Nat := [2,4,8,1,12,64,5,68,0,5,65,0,69,64,76,66,64,71,5,77,1,13,65,66,73,0,71,0,65,77,72,13,69,65,1,0]

theorem envBound35596 : H12AffineFastState.Bounded env35596 := by
  intro p hp
  have h : env35596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35595_35596 : H12AffineEnvironment.transform 4 12 env35595 = env35596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env35595 == env35596) = true)

theorem identity35596 : scanCanonicalize (H12AffineFastState.compose env35596 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35597 : List Nat := [2,4,8,1,12,0,5,4,0,5,1,0,5,0,12,2,0,7,5,13,1,13,1,2,9,0,7,0,1,13,8,13,5,1,1,0]

theorem envBound35597 : H12AffineFastState.Bounded env35597 := by
  intro p hp
  have h : env35597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35596_35597 : H12AffineEnvironment.transform 5 0 env35596 = env35597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35596 == env35597) = true)

def env35598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4097,477,74047,69649,13768,78894,4415,74815,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound35598 : H12AffineFastState.Bounded env35598 := by
  intro p hp
  have h : env35598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35518_35598 : H12AffineEnvironment.transform 17 65665 env35518 = env35598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35518 == env35598) = true)

theorem identity35598 : scanCanonicalize (H12AffineFastState.compose env35598 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound35598 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35599 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4097,477,74047,69649,12424,78190,4415,74111,81,79882,8205,65831,257,64,0,4609]

theorem envBound35599 : H12AffineFastState.Bounded env35599 := by
  intro p hp
  have h : env35599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35598_35599 : H12AffineEnvironment.transform 9 320 env35598 = env35599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35598 == env35599) = true)

def env35600 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4097,477,74047,69649,12424,78190,4415,74111,81,79882,8205,65831,257,64,0,4437]

theorem envBound35600 : H12AffineFastState.Bounded env35600 := by
  intro p hp
  have h : env35600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35599_35600 : H12AffineEnvironment.transform 8 340 env35599 = env35600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env35599 == env35600) = true)

def env35601 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,80,8525,65536,74030,65665,337,8524,17,477,74047,65537,8344,74110,303,74111,81,75802,8205,65831,257,64,0,325]

theorem envBound35601 : H12AffineFastState.Bounded env35601 := by
  intro p hp
  have h : env35601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35600_35601 : H12AffineEnvironment.transform 11 16 env35600 = env35601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env35600 == env35601) = true)

theorem identity35601 : scanCanonicalize (H12AffineFastState.compose env35601 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound35601 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35602 : List Nat := [2,4,8,16,32,13,128,256,281,269,2048,16,8192,29,8448,65536,74030,65665,284,8449,17,400,74047,65537,8344,74035,303,74034,28,75802,8205,65831,257,13,0,264]

theorem envBound35602 : H12AffineFastState.Bounded env35602 := by
  intro p hp
  have h : env35602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35601_35602 : H12AffineEnvironment.transform 5 13 env35601 = env35602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env35601 == env35602) = true)

def env35603 : List Nat := [2,4,8,0,32,13,128,256,265,269,2048,0,8192,13,8448,65536,74030,65665,268,8449,1,384,74031,65537,8328,74019,303,74018,12,75786,8205,65831,257,13,0,264]

theorem envBound35603 : H12AffineFastState.Bounded env35603 := by
  intro p hp
  have h : env35603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35602_35603 : H12AffineEnvironment.transform 3 0 env35602 = env35603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35602 == env35603) = true)

theorem identity35603 : scanCanonicalize (H12AffineFastState.compose env35603 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound35603 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35604 : List Nat := [2,4,8,0,32,13,128,9,0,4,2048,0,8192,13,8201,65536,73767,65665,5,8200,1,137,73766,65537,8328,73770,38,73771,12,75786,8205,65582,8,13,0,1]

theorem envBound35604 : H12AffineFastState.Bounded env35604 := by
  intro p hp
  have h : env35604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35603_35604 : H12AffineEnvironment.transform 7 9 env35603 = env35604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env35603 == env35604) = true)

theorem identity35604 : scanCanonicalize (H12AffineFastState.compose env35604 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound35604 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35605 : List Nat := [2,4,8,0,32,13,128,9,0,4,2048,0,8192,13,8201,47,8200,174,5,8200,1,137,8201,46,8328,8197,38,8196,12,10277,8205,1,8,13,0,1]

theorem envBound35605 : H12AffineFastState.Bounded env35605 := by
  intro p hp
  have h : env35605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35604_35605 : H12AffineEnvironment.transform 15 47 env35604 = env35605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env35604 == env35605) = true)

theorem identity35605 : scanCanonicalize (H12AffineFastState.compose env35605 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound35605 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35606 : List Nat := [2,4,8,0,32,13,128,9,0,4,2048,0,9,13,0,47,1,174,5,1,1,137,0,46,129,12,38,13,12,2092,4,1,8,13,0,1]

theorem envBound35606 : H12AffineFastState.Bounded env35606 := by
  intro p hp
  have h : env35606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35605_35606 : H12AffineEnvironment.transform 12 9 env35605 = env35606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env35605 == env35606) = true)

theorem identity35606 : scanCanonicalize (H12AffineFastState.compose env35606 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound35606 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35607 : List Nat := [2,4,8,0,32,13,128,9,0,4,32,0,9,13,0,47,1,174,5,1,1,137,0,46,129,12,38,13,12,12,4,1,8,13,0,1]

theorem envBound35607 : H12AffineFastState.Bounded env35607 := by
  intro p hp
  have h : env35607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35606_35607 : H12AffineEnvironment.transform 10 32 env35606 = env35607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env35606 == env35607) = true)

theorem identity35607 : scanCanonicalize (H12AffineFastState.compose env35607 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound35607 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35608 : List Nat := [2,4,8,0,32,13,10,9,0,4,32,0,9,13,0,47,1,36,5,1,1,3,0,46,11,12,38,13,12,12,4,1,8,13,0,1]

theorem envBound35608 : H12AffineFastState.Bounded env35608 := by
  intro p hp
  have h : env35608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35607_35608 : H12AffineEnvironment.transform 6 10 env35607 = env35608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env35607 == env35608) = true)

theorem identity35608 : scanCanonicalize (H12AffineFastState.compose env35608 (packedSelected [0,2,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35608 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env35609 : List Nat := [0,4,8,0,32,13,8,9,0,4,32,0,9,13,0,45,1,36,5,1,1,1,0,44,9,12,36,13,12,12,4,1,8,13,0,1]

theorem envBound35609 : H12AffineFastState.Bounded env35609 := by
  intro p hp
  have h : env35609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35608_35609 : H12AffineEnvironment.transform 0 0 env35608 = env35609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35608 == env35609) = true)

theorem identity35609 : scanCanonicalize (H12AffineFastState.compose env35609 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35609 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35610 : List Nat := [0,4,5,0,32,0,5,4,0,4,32,0,4,0,0,32,1,36,5,1,1,1,0,33,4,1,36,0,1,1,4,1,5,0,0,1]

theorem envBound35610 : H12AffineFastState.Bounded env35610 := by
  intro p hp
  have h : env35610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35609_35610 : H12AffineEnvironment.transform 2 5 env35609 = env35610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35609 == env35610) = true)

theorem identity35610 : scanCanonicalize (H12AffineFastState.compose env35610 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound35610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35611 : List Nat := [0,4,5,0,4,0,5,4,0,4,4,0,4,0,0,4,1,0,5,1,1,1,0,5,4,1,0,0,1,1,4,1,5,0,0,1]

theorem envBound35611 : H12AffineFastState.Bounded env35611 := by
  intro p hp
  have h : env35611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35610_35611 : H12AffineEnvironment.transform 4 4 env35610 = env35611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env35610 == env35611) = true)

theorem identity35611 : scanCanonicalize (H12AffineFastState.compose env35611 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35612 : List Nat := [0,1,0,0,1,0,0,1,0,1,1,0,1,0,0,1,1,0,0,1,1,1,0,0,1,1,0,0,1,1,1,1,0,0,0,1]

theorem envBound35612 : H12AffineFastState.Bounded env35612 := by
  intro p hp
  have h : env35612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35611_35612 : H12AffineEnvironment.transform 1 1 env35611 = env35612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35611 == env35612) = true)

def env35613 : List Nat := [2,4,8,1,32,13,128,256,264,269,2048,1,8192,12,8448,65536,74030,65665,269,8449,0,385,74030,65537,8329,74018,303,74019,13,75787,8205,65831,257,13,0,264]

theorem envBound35613 : H12AffineFastState.Bounded env35613 := by
  intro p hp
  have h : env35613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35602_35613 : H12AffineEnvironment.transform 3 1 env35602 = env35613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35602 == env35613) = true)

theorem identity35613 : scanCanonicalize (H12AffineFastState.compose env35613 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound35613 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35614 : List Nat := [2,4,8,1,32,13,128,256,264,269,2048,1,8192,12,8448,8234,260,8363,269,8449,0,385,260,8235,8329,264,303,265,13,2081,8205,8461,257,13,0,264]

theorem envBound35614 : H12AffineFastState.Bounded env35614 := by
  intro p hp
  have h : env35614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35613_35614 : H12AffineEnvironment.transform 15 8234 env35613 = env35614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env35613 == env35614) = true)

theorem identity35614 : scanCanonicalize (H12AffineFastState.compose env35614 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound35614 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35615 : List Nat := [2,4,8,1,32,13,128,8,0,5,2048,1,8192,12,8200,8234,12,8363,5,8201,0,137,12,8235,8329,0,39,1,13,2081,8205,8197,9,13,0,0]

theorem envBound35615 : H12AffineFastState.Bounded env35615 := by
  intro p hp
  have h : env35615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35614_35615 : H12AffineEnvironment.transform 7 8 env35614 = env35615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env35614 == env35615) = true)

theorem identity35615 : scanCanonicalize (H12AffineFastState.compose env35615 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound35615 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35616 : List Nat := [2,4,8,1,32,13,3,8,0,5,2048,1,8192,12,8200,8234,12,8232,5,8201,0,10,12,8235,8202,0,39,1,13,2081,8205,8197,9,13,0,0]

theorem envBound35616 : H12AffineFastState.Bounded env35616 := by
  intro p hp
  have h : env35616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35615_35616 : H12AffineEnvironment.transform 6 3 env35615 = env35616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env35615 == env35616) = true)

theorem identity35616 : scanCanonicalize (H12AffineFastState.compose env35616 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound35616 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env35617 : List Nat := [2,4,8,1,32,13,3,8,0,5,2048,1,2082,12,2090,2056,12,2058,5,2091,0,10,12,2057,2088,0,39,1,13,2081,2095,2087,9,13,0,0]

theorem envBound35617 : H12AffineFastState.Bounded env35617 := by
  intro p hp
  have h : env35617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35616_35617 : H12AffineEnvironment.transform 12 2082 env35616 = env35617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env35616 == env35617) = true)

theorem identity35617 : scanCanonicalize (H12AffineFastState.compose env35617 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound35617 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35618 : List Nat := [2,4,8,1,12,13,3,8,0,5,2048,1,2062,12,2054,2056,12,2058,5,2055,0,10,12,2057,2052,0,11,1,13,2061,2051,2059,9,13,0,0]

theorem envBound35618 : H12AffineFastState.Bounded env35618 := by
  intro p hp
  have h : env35618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35617_35618 : H12AffineEnvironment.transform 4 12 env35617 = env35618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env35617 == env35618) = true)

theorem identity35618 : scanCanonicalize (H12AffineFastState.compose env35618 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound35618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35619 : List Nat := [2,4,8,1,12,13,3,8,0,5,13,1,3,12,11,5,12,7,5,10,0,10,12,4,9,0,11,1,13,0,14,6,9,13,0,0]

theorem envBound35619 : H12AffineFastState.Bounded env35619 := by
  intro p hp
  have h : env35619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35618_35619 : H12AffineEnvironment.transform 10 13 env35618 = env35619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env35618 == env35619) = true)

theorem identity35619 : scanCanonicalize (H12AffineFastState.compose env35619 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35619 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35620 : List Nat := [2,4,3,1,7,6,3,3,0,5,6,1,3,7,0,5,7,7,5,1,0,1,7,4,2,0,0,1,6,0,5,6,2,6,0,0]

theorem envBound35620 : H12AffineFastState.Bounded env35620 := by
  intro p hp
  have h : env35620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35619_35620 : H12AffineEnvironment.transform 2 3 env35619 = env35620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35619 == env35620) = true)

def env35621 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,80,8524,65536,74030,65665,336,8525,16,477,74047,65536,8345,74111,302,74111,81,75803,8205,65831,257,64,0,324]

theorem envBound35621 : H12AffineFastState.Bounded env35621 := by
  intro p hp
  have h : env35621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35600_35621 : H12AffineEnvironment.transform 11 17 env35600 = env35621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35600 == env35621) = true)

theorem identity35621 : scanCanonicalize (H12AffineFastState.compose env35621 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound35621 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35622 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,4,80,328,65536,65834,65665,336,329,16,477,65851,65536,157,65915,302,65915,81,67615,9,65831,257,64,0,324]

theorem envBound35622 : H12AffineFastState.Bounded env35622 := by
  intro p hp
  have h : env35622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35621_35622 : H12AffineEnvironment.transform 12 4 env35621 = env35622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env35621 == env35622) = true)

def env35623 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,4,64,328,65536,65834,65665,320,329,0,461,65835,65536,141,65899,302,65899,65,67599,9,65831,257,64,0,324]

theorem envBound35623 : H12AffineFastState.Bounded env35623 := by
  intro p hp
  have h : env35623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35622_35623 : H12AffineEnvironment.transform 3 0 env35622 = env35623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35622 == env35623) = true)

theorem identity35623 : scanCanonicalize (H12AffineFastState.compose env35623 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound35623 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35624 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,4,64,328,47,261,174,320,329,0,461,260,47,141,324,302,324,65,2080,9,264,257,64,0,324]

theorem envBound35624 : H12AffineFastState.Bounded env35624 := by
  intro p hp
  have h : env35624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35623_35624 : H12AffineEnvironment.transform 15 47 env35623 = env35624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env35623 == env35624) = true)

theorem identity35624 : scanCanonicalize (H12AffineFastState.compose env35624 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35624 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35625 : List Nat := [2,4,8,0,32,64,128,69,1,5,2048,1,4,64,13,47,64,174,5,12,0,136,65,47,141,1,107,1,65,2080,9,77,68,64,0,1]

theorem envBound35625 : H12AffineFastState.Bounded env35625 := by
  intro p hp
  have h : env35625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35624_35625 : H12AffineEnvironment.transform 7 69 env35624 = env35625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35624 == env35625) = true)

theorem identity35625 : scanCanonicalize (H12AffineFastState.compose env35625 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound35625 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35626 : List Nat := [2,4,8,0,32,64,67,69,1,5,2048,1,4,64,13,47,64,109,5,12,0,75,65,47,78,1,107,1,65,2080,9,77,68,64,0,1]

theorem envBound35626 : H12AffineFastState.Bounded env35626 := by
  intro p hp
  have h : env35626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35625_35626 : H12AffineEnvironment.transform 6 67 env35625 = env35626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env35625 == env35626) = true)

theorem identity35626 : scanCanonicalize (H12AffineFastState.compose env35626 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound35626 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env35627 : List Nat := [2,4,8,0,32,64,67,69,1,5,39,1,4,64,13,47,64,109,5,12,0,75,65,47,78,1,107,1,65,7,9,77,68,64,0,1]

theorem envBound35627 : H12AffineFastState.Bounded env35627 := by
  intro p hp
  have h : env35627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35626_35627 : H12AffineEnvironment.transform 10 39 env35626 = env35627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env35626 == env35627) = true)

theorem identity35627 : scanCanonicalize (H12AffineFastState.compose env35627 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound35627 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env35628 : List Nat := [2,4,8,0,32,13,14,8,1,5,39,1,4,13,13,47,13,32,5,12,0,6,12,47,3,1,38,1,12,7,9,0,9,13,0,1]

theorem envBound35628 : H12AffineFastState.Bounded env35628 := by
  intro p hp
  have h : env35628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35627_35628 : H12AffineEnvironment.transform 5 13 env35627 = env35628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env35627 == env35628) = true)

theorem identity35628 : scanCanonicalize (H12AffineFastState.compose env35628 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35628 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35629 : List Nat := [2,3,8,0,32,10,9,8,1,2,32,1,3,10,10,40,10,32,2,11,0,1,11,40,3,1,33,1,11,0,9,0,9,10,0,1]

theorem envBound35629 : H12AffineFastState.Bounded env35629 := by
  intro p hp
  have h : env35629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35628_35629 : H12AffineEnvironment.transform 1 3 env35628 = env35629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35628 == env35629) = true)

theorem identity35629 : scanCanonicalize (H12AffineFastState.compose env35629 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35629 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35630 : List Nat := [2,3,2,0,32,0,3,2,1,2,32,1,3,0,0,34,0,32,2,1,0,1,1,34,3,1,33,1,1,0,3,0,3,0,0,1]

theorem envBound35630 : H12AffineFastState.Bounded env35630 := by
  intro p hp
  have h : env35630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35629_35630 : H12AffineEnvironment.transform 2 2 env35629 = env35630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35629 == env35630) = true)

def env35631 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,4,65,328,65536,65834,65665,321,329,1,460,65834,65536,140,65898,302,65898,64,67598,9,65831,257,64,0,324]

theorem envBound35631 : H12AffineFastState.Bounded env35631 := by
  intro p hp
  have h : env35631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35622_35631 : H12AffineEnvironment.transform 3 1 env35622 = env35631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35622 == env35631) = true)

theorem identity35631 : scanCanonicalize (H12AffineFastState.compose env35631 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35631 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35632 : List Nat := [2,4,8,1,32,64,128,68,1,4,2048,0,4,65,12,65536,65646,65665,5,13,1,136,65646,65536,140,65582,106,65582,64,67598,9,65635,69,64,0,0]

theorem envBound35632 : H12AffineFastState.Bounded env35632 := by
  intro p hp
  have h : env35632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35631_35632 : H12AffineEnvironment.transform 7 68 env35631 = env35632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35631 == env35632) = true)

theorem identity35632 : scanCanonicalize (H12AffineFastState.compose env35632 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound35632 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35633 : List Nat := [2,4,8,1,32,64,128,68,1,4,2048,0,4,65,12,99,13,226,5,13,1,136,13,99,140,77,106,77,64,2157,9,0,69,64,0,0]

theorem envBound35633 : H12AffineFastState.Bounded env35633 := by
  intro p hp
  have h : env35633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35632_35633 : H12AffineEnvironment.transform 15 99 env35632 = env35633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env35632 == env35633) = true)

theorem identity35633 : scanCanonicalize (H12AffineFastState.compose env35633 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35633 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35634 : List Nat := [2,4,5,1,32,64,128,68,1,4,2048,0,4,65,1,99,0,226,5,0,1,133,0,99,129,64,103,64,64,2144,4,0,69,64,0,0]

theorem envBound35634 : H12AffineFastState.Bounded env35634 := by
  intro p hp
  have h : env35634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35633_35634 : H12AffineEnvironment.transform 2 5 env35633 = env35634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35633 == env35634) = true)

theorem identity35634 : scanCanonicalize (H12AffineFastState.compose env35634 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound35634 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35635 : List Nat := [2,4,5,1,32,64,128,68,1,4,226,0,4,65,1,99,0,226,5,0,1,133,0,99,129,64,103,64,64,130,4,0,69,64,0,0]

theorem envBound35635 : H12AffineFastState.Bounded env35635 := by
  intro p hp
  have h : env35635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35634_35635 : H12AffineEnvironment.transform 10 226 env35634 = env35635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env35634 == env35635) = true)

theorem identity35635 : scanCanonicalize (H12AffineFastState.compose env35635 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound35635 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env35636 : List Nat := [2,4,5,1,32,64,37,68,1,4,71,0,4,65,1,99,0,71,5,0,1,32,0,99,36,64,103,64,64,39,4,0,69,64,0,0]

theorem envBound35636 : H12AffineFastState.Bounded env35636 := by
  intro p hp
  have h : env35636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35635_35636 : H12AffineEnvironment.transform 6 37 env35635 = env35636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env35635 == env35636) = true)

theorem identity35636 : scanCanonicalize (H12AffineFastState.compose env35636 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35636 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35637 : List Nat := [2,3,2,1,32,64,34,67,1,3,64,0,3,65,1,99,0,64,2,0,1,32,0,99,35,64,96,64,64,32,3,0,66,64,0,0]

theorem envBound35637 : H12AffineFastState.Bounded env35637 := by
  intro p hp
  have h : env35637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35636_35637 : H12AffineEnvironment.transform 1 3 env35636 = env35637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35636 == env35637) = true)

theorem identity35637 : scanCanonicalize (H12AffineFastState.compose env35637 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound35637 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35638 : List Nat := [2,3,2,1,2,64,0,67,1,3,64,0,3,65,1,65,0,64,2,0,1,2,0,65,1,64,66,64,64,2,3,0,66,64,0,0]

theorem envBound35638 : H12AffineFastState.Bounded env35638 := by
  intro p hp
  have h : env35638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35637_35638 : H12AffineEnvironment.transform 4 2 env35637 = env35638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env35637 == env35638) = true)

theorem identity35638 : scanCanonicalize (H12AffineFastState.compose env35638 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound35638 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35639 : List Nat := [2,3,2,1,2,3,0,0,1,3,3,0,3,2,1,2,0,3,2,0,1,2,0,2,1,3,1,3,3,2,3,0,1,3,0,0]

theorem envBound35639 : H12AffineFastState.Bounded env35639 := by
  intro p hp
  have h : env35639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35638_35639 : H12AffineEnvironment.transform 5 3 env35638 = env35639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env35638 == env35639) = true)

theorem identity35639 : scanCanonicalize (H12AffineFastState.compose env35639 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35640 : List Nat := [0,1,0,1,0,1,0,0,1,1,1,0,1,0,1,0,0,1,0,0,1,0,0,0,1,1,1,1,1,0,1,0,1,1,0,0]

theorem envBound35640 : H12AffineFastState.Bounded env35640 := by
  intro p hp
  have h : env35640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35639_35640 : H12AffineEnvironment.transform 0 0 env35639 = env35640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35639 == env35640) = true)

def env35641 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4097,477,74047,69649,12424,78190,4415,74111,81,79882,8205,65831,257,64,0,4436]

theorem envBound35641 : H12AffineFastState.Bounded env35641 := by
  intro p hp
  have h : env35641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35599_35641 : H12AffineEnvironment.transform 8 341 env35599 = env35641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env35599 == env35641) = true)

def env35642 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8525,65536,74030,65665,337,8524,17,477,74047,65537,8344,74110,303,74111,81,75802,8205,65831,257,64,0,324]

theorem envBound35642 : H12AffineFastState.Bounded env35642 := by
  intro p hp
  have h : env35642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35641_35642 : H12AffineEnvironment.transform 11 16 env35641 = env35642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env35641 == env35642) = true)

theorem identity35642 : scanCanonicalize (H12AffineFastState.compose env35642 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8547) := by decide +kernel

theorem selectedBound35642 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35643 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,80,8525,8547,77,8674,337,8524,17,477,92,8546,8344,29,303,28,81,2425,8205,8260,257,64,0,324]

theorem envBound35643 : H12AffineFastState.Bounded env35643 := by
  intro p hp
  have h : env35643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35642_35643 : H12AffineEnvironment.transform 15 8547 env35642 = env35643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8547 env35642 == env35643) = true)

def env35644 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,8192,64,8525,8547,77,8674,321,8524,1,461,76,8546,8328,13,303,12,65,2409,8205,8260,257,64,0,324]

theorem envBound35644 : H12AffineFastState.Bounded env35644 := by
  intro p hp
  have h : env35644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35643_35644 : H12AffineEnvironment.transform 3 0 env35643 = env35644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35643 == env35644) = true)

theorem identity35644 : scanCanonicalize (H12AffineFastState.compose env35644 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35644 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35645 : List Nat := [2,4,8,0,32,64,128,68,1,4,2048,0,8192,64,8201,8231,77,8358,5,8200,1,137,76,8230,8328,13,107,12,65,2093,8205,8260,69,64,0,0]

theorem envBound35645 : H12AffineFastState.Bounded env35645 := by
  intro p hp
  have h : env35645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35644_35645 : H12AffineEnvironment.transform 7 68 env35644 = env35645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35644 == env35645) = true)

theorem identity35645 : scanCanonicalize (H12AffineFastState.compose env35645 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 69) := by decide +kernel

theorem selectedBound35645 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35646 : List Nat := [2,4,8,0,32,64,128,68,1,4,2048,0,69,64,76,98,77,227,5,77,1,137,76,99,205,13,107,12,65,2093,72,1,69,64,0,0]

theorem envBound35646 : H12AffineFastState.Bounded env35646 := by
  intro p hp
  have h : env35646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35645_35646 : H12AffineEnvironment.transform 12 69 env35645 = env35646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 69 env35645 == env35646) = true)

theorem identity35646 : scanCanonicalize (H12AffineFastState.compose env35646 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound35646 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35647 : List Nat := [2,4,8,0,32,12,128,8,1,4,2048,0,9,12,0,46,1,175,5,1,1,137,0,47,129,13,39,12,13,2093,4,1,9,12,0,0]

theorem envBound35647 : H12AffineFastState.Bounded env35647 := by
  intro p hp
  have h : env35647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35646_35647 : H12AffineEnvironment.transform 5 12 env35646 = env35647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env35646 == env35647) = true)

theorem identity35647 : scanCanonicalize (H12AffineFastState.compose env35647 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35647 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35648 : List Nat := [2,4,8,0,32,12,128,8,1,4,33,0,9,12,0,46,1,175,5,1,1,137,0,47,129,13,39,12,13,12,4,1,9,12,0,0]

theorem envBound35648 : H12AffineFastState.Bounded env35648 := by
  intro p hp
  have h : env35648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35647_35648 : H12AffineEnvironment.transform 10 33 env35647 = env35648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35647 == env35648) = true)

theorem identity35648 : scanCanonicalize (H12AffineFastState.compose env35648 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound35648 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35649 : List Nat := [2,4,8,0,32,12,43,8,1,4,33,0,9,12,0,46,1,4,5,1,1,34,0,47,42,13,39,12,13,12,4,1,9,12,0,0]

theorem envBound35649 : H12AffineFastState.Bounded env35649 := by
  intro p hp
  have h : env35649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35648_35649 : H12AffineEnvironment.transform 6 43 env35648 = env35649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env35648 == env35649) = true)

theorem identity35649 : scanCanonicalize (H12AffineFastState.compose env35649 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound35649 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env35650 : List Nat := [2,4,8,0,15,12,4,8,1,4,14,0,9,12,0,1,1,4,5,1,1,13,0,0,5,13,8,12,13,12,4,1,9,12,0,0]

theorem envBound35650 : H12AffineFastState.Bounded env35650 := by
  intro p hp
  have h : env35650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35649_35650 : H12AffineEnvironment.transform 4 15 env35649 = env35650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env35649 == env35650) = true)

def env35651 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,8192,65,8525,8547,77,8674,320,8524,0,460,77,8546,8329,12,303,13,64,2408,8205,8260,257,64,0,324]

theorem envBound35651 : H12AffineFastState.Bounded env35651 := by
  intro p hp
  have h : env35651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35643_35651 : H12AffineEnvironment.transform 3 1 env35643 = env35651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35643 == env35651) = true)

theorem identity35651 : scanCanonicalize (H12AffineFastState.compose env35651 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound35651 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35652 : List Nat := [2,4,8,1,32,64,128,73,13,9,2048,1,8192,65,8196,8234,77,8363,9,8197,0,133,77,8235,8329,12,102,13,64,2081,8205,8260,72,64,0,13]

theorem envBound35652 : H12AffineFastState.Bounded env35652 := by
  intro p hp
  have h : env35652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35651_35652 : H12AffineEnvironment.transform 7 73 env35651 = env35652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env35651 == env35652) = true)

theorem identity35652 : scanCanonicalize (H12AffineFastState.compose env35652 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35652 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35653 : List Nat := [2,4,4,1,32,64,128,69,1,5,2048,1,8192,65,8196,8230,65,8359,5,8197,0,133,65,8231,8325,0,102,1,64,2081,8193,8260,68,64,0,1]

theorem envBound35653 : H12AffineFastState.Bounded env35653 := by
  intro p hp
  have h : env35653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35652_35653 : H12AffineEnvironment.transform 2 4 env35652 = env35653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35652 == env35653) = true)

theorem identity35653 : scanCanonicalize (H12AffineFastState.compose env35653 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound35653 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35654 : List Nat := [2,4,4,1,32,64,67,69,1,5,2048,1,8192,65,8196,8230,65,8292,5,8197,0,70,65,8231,8262,0,102,1,64,2081,8193,8260,68,64,0,1]

theorem envBound35654 : H12AffineFastState.Bounded env35654 := by
  intro p hp
  have h : env35654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35653_35654 : H12AffineEnvironment.transform 6 67 env35653 = env35654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env35653 == env35654) = true)

theorem identity35654 : scanCanonicalize (H12AffineFastState.compose env35654 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound35654 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env35655 : List Nat := [2,4,4,1,32,64,67,69,1,5,2048,1,2082,65,2086,2052,65,2118,5,2087,0,70,65,2053,2148,0,102,1,64,2081,2083,2150,68,64,0,1]

theorem envBound35655 : H12AffineFastState.Bounded env35655 := by
  intro p hp
  have h : env35655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35654_35655 : H12AffineEnvironment.transform 12 2082 env35654 = env35655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env35654 == env35655) = true)

theorem identity35655 : scanCanonicalize (H12AffineFastState.compose env35655 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound35655 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env35656 : List Nat := [2,4,4,1,32,64,67,69,1,5,103,1,69,65,65,99,65,33,5,64,0,70,65,98,3,0,102,1,64,70,68,1,68,64,0,1]

theorem envBound35656 : H12AffineFastState.Bounded env35656 := by
  intro p hp
  have h : env35656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35655_35656 : H12AffineEnvironment.transform 10 103 env35655 = env35656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env35655 == env35656) = true)

theorem identity35656 : scanCanonicalize (H12AffineFastState.compose env35656 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound35656 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35657 : List Nat := [2,4,4,1,32,6,5,3,1,5,33,1,3,7,7,37,7,33,5,6,0,0,7,36,3,0,32,1,6,0,2,1,2,6,0,1]

theorem envBound35657 : H12AffineFastState.Bounded env35657 := by
  intro p hp
  have h : env35657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35656_35657 : H12AffineEnvironment.transform 5 6 env35656 = env35657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env35656 == env35657) = true)

theorem identity35657 : scanCanonicalize (H12AffineFastState.compose env35657 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35657 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35658 : List Nat := [2,3,3,1,32,1,2,3,1,2,33,1,3,0,0,34,0,33,2,1,0,0,0,35,3,0,32,1,1,0,2,1,2,1,0,1]

theorem envBound35658 : H12AffineFastState.Bounded env35658 := by
  intro p hp
  have h : env35658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35657_35658 : H12AffineEnvironment.transform 1 3 env35657 = env35658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35657 == env35658) = true)

def env35659 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8524,65536,74030,65665,336,8525,16,477,74047,65536,8345,74111,302,74111,81,75803,8205,65831,257,64,0,325]

theorem envBound35659 : H12AffineFastState.Bounded env35659 := by
  intro p hp
  have h : env35659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35641_35659 : H12AffineEnvironment.transform 11 17 env35641 = env35659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35641 == env35659) = true)

theorem identity35659 : scanCanonicalize (H12AffineFastState.compose env35659 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 298) := by decide +kernel

theorem selectedBound35659 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35660 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,80,8524,298,8196,427,336,8525,16,477,8213,298,8345,8277,302,8277,81,10545,8205,13,257,64,0,325]

theorem envBound35660 : H12AffineFastState.Bounded env35660 := by
  intro p hp
  have h : env35660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35659_35660 : H12AffineEnvironment.transform 15 298 env35659 = env35660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 298 env35659 == env35660) = true)

def env35661 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,8192,64,8524,298,8196,427,320,8525,0,461,8197,298,8329,8261,302,8261,65,10529,8205,13,257,64,0,325]

theorem envBound35661 : H12AffineFastState.Bounded env35661 := by
  intro p hp
  have h : env35661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35660_35661 : H12AffineEnvironment.transform 3 0 env35660 = env35661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35660 == env35661) = true)

theorem identity35661 : scanCanonicalize (H12AffineFastState.compose env35661 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound35661 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35662 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,257,64,77,298,261,427,320,76,0,461,260,298,392,324,302,324,65,2080,268,13,257,64,0,325]

theorem envBound35662 : H12AffineFastState.Bounded env35662 := by
  intro p hp
  have h : env35662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35661_35662 : H12AffineEnvironment.transform 12 257 env35661 = env35662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env35661 == env35662) = true)

theorem identity35662 : scanCanonicalize (H12AffineFastState.compose env35662 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35662 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35663 : List Nat := [2,4,8,0,32,64,128,69,0,5,2048,1,68,64,77,111,64,238,5,76,0,136,65,111,205,1,107,1,65,2080,73,13,68,64,0,0]

theorem envBound35663 : H12AffineFastState.Bounded env35663 := by
  intro p hp
  have h : env35663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35662_35663 : H12AffineEnvironment.transform 7 69 env35662 = env35663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35662 == env35663) = true)

theorem identity35663 : scanCanonicalize (H12AffineFastState.compose env35663 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound35663 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35664 : List Nat := [2,4,8,0,32,64,2,69,0,5,2048,1,68,64,77,111,64,108,5,76,0,10,65,111,79,1,107,1,65,2080,73,13,68,64,0,0]

theorem envBound35664 : H12AffineFastState.Bounded env35664 := by
  intro p hp
  have h : env35664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35663_35664 : H12AffineEnvironment.transform 6 2 env35663 = env35664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env35663 == env35664) = true)

theorem identity35664 : scanCanonicalize (H12AffineFastState.compose env35664 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 103) := by decide +kernel

theorem selectedBound35664 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env35665 : List Nat := [2,4,8,0,32,64,2,69,0,5,103,1,68,64,77,111,64,108,5,76,0,10,65,111,79,1,107,1,65,71,73,13,68,64,0,0]

theorem envBound35665 : H12AffineFastState.Bounded env35665 := by
  intro p hp
  have h : env35665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35664_35665 : H12AffineEnvironment.transform 10 103 env35664 = env35665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 103 env35664 == env35665) = true)

theorem identity35665 : scanCanonicalize (H12AffineFastState.compose env35665 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound35665 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35666 : List Nat := [2,4,8,0,32,33,2,36,0,5,6,1,37,33,44,14,33,13,5,45,0,10,32,14,46,1,10,1,32,38,40,13,37,33,0,0]

theorem envBound35666 : H12AffineFastState.Bounded env35666 := by
  intro p hp
  have h : env35666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35665_35666 : H12AffineEnvironment.transform 5 33 env35665 = env35666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env35665 == env35666) = true)

theorem identity35666 : scanCanonicalize (H12AffineFastState.compose env35666 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound35666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35667 : List Nat := [2,4,8,0,6,7,2,2,0,5,6,1,3,7,10,14,7,13,5,11,0,10,6,14,8,1,10,1,6,0,14,13,3,7,0,0]

theorem envBound35667 : H12AffineFastState.Bounded env35667 := by
  intro p hp
  have h : env35667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35666_35667 : H12AffineEnvironment.transform 4 6 env35666 = env35667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env35666 == env35667) = true)

theorem identity35667 : scanCanonicalize (H12AffineFastState.compose env35667 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35668 : List Nat := [2,4,2,0,6,7,2,2,0,5,6,1,3,7,0,4,7,7,5,1,0,0,6,4,2,1,0,1,6,0,4,7,3,7,0,0]

theorem envBound35668 : H12AffineFastState.Bounded env35668 := by
  intro p hp
  have h : env35668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35667_35668 : H12AffineEnvironment.transform 2 2 env35667 = env35668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35667 == env35668) = true)

def env35669 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,8192,65,8524,298,8196,427,321,8525,1,460,8196,298,8328,8260,302,8260,64,10528,8205,13,257,64,0,325]

theorem envBound35669 : H12AffineFastState.Bounded env35669 := by
  intro p hp
  have h : env35669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35660_35669 : H12AffineEnvironment.transform 3 1 env35660 = env35669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35660 == env35669) = true)

theorem identity35669 : scanCanonicalize (H12AffineFastState.compose env35669 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35669 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35670 : List Nat := [2,4,8,1,32,64,128,68,0,4,2048,0,8192,65,8200,110,8196,239,5,8201,1,136,8196,110,8328,8260,106,8260,64,10340,8205,13,69,64,0,1]

theorem envBound35670 : H12AffineFastState.Bounded env35670 := by
  intro p hp
  have h : env35670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35669_35670 : H12AffineEnvironment.transform 7 68 env35669 = env35670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35669 == env35670) = true)

theorem identity35670 : scanCanonicalize (H12AffineFastState.compose env35670 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35670 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35671 : List Nat := [2,4,5,1,32,64,128,68,0,4,2048,0,8192,65,8197,99,8196,226,5,8196,1,133,8196,99,8325,8260,103,8260,64,10340,8192,0,69,64,0,1]

theorem envBound35671 : H12AffineFastState.Bounded env35671 := by
  intro p hp
  have h : env35671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35670_35671 : H12AffineEnvironment.transform 2 5 env35670 = env35671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35670 == env35671) = true)

theorem identity35671 : scanCanonicalize (H12AffineFastState.compose env35671 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound35671 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35672 : List Nat := [2,4,5,1,32,64,128,68,0,4,2048,0,4,65,1,99,0,226,5,0,1,133,0,99,129,64,103,64,64,2144,4,0,69,64,0,1]

theorem envBound35672 : H12AffineFastState.Bounded env35672 := by
  intro p hp
  have h : env35672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35671_35672 : H12AffineEnvironment.transform 12 4 env35671 = env35672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env35671 == env35672) = true)

theorem identity35672 : scanCanonicalize (H12AffineFastState.compose env35672 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound35672 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env35673 : List Nat := [2,4,5,1,32,64,128,68,0,4,227,0,4,65,1,99,0,226,5,0,1,133,0,99,129,64,103,64,64,131,4,0,69,64,0,1]

theorem envBound35673 : H12AffineFastState.Bounded env35673 := by
  intro p hp
  have h : env35673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35672_35673 : H12AffineEnvironment.transform 10 227 env35672 = env35673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env35672 == env35673) = true)

theorem identity35673 : scanCanonicalize (H12AffineFastState.compose env35673 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound35673 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env35674 : List Nat := [2,4,5,1,32,64,101,68,0,4,6,0,4,65,1,99,0,7,5,0,1,96,0,99,100,64,103,64,64,102,4,0,69,64,0,1]

theorem envBound35674 : H12AffineFastState.Bounded env35674 := by
  intro p hp
  have h : env35674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35673_35674 : H12AffineEnvironment.transform 6 101 env35673 = env35674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env35673 == env35674) = true)

theorem identity35674 : scanCanonicalize (H12AffineFastState.compose env35674 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound35674 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35675 : List Nat := [2,4,5,1,32,6,35,2,0,4,6,0,4,7,1,37,0,7,5,0,1,38,0,37,34,6,33,6,6,32,4,0,3,6,0,1]

theorem envBound35675 : H12AffineFastState.Bounded env35675 := by
  intro p hp
  have h : env35675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35674_35675 : H12AffineEnvironment.transform 5 6 env35674 = env35675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env35674 == env35675) = true)

theorem identity35675 : scanCanonicalize (H12AffineFastState.compose env35675 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound35675 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35676 : List Nat := [2,4,5,1,5,6,6,2,0,4,6,0,4,7,1,0,0,7,5,0,1,3,0,0,7,6,4,6,6,5,4,0,3,6,0,1]

theorem envBound35676 : H12AffineFastState.Bounded env35676 := by
  intro p hp
  have h : env35676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35675_35676 : H12AffineEnvironment.transform 4 5 env35675 = env35676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env35675 == env35676) = true)

theorem identity35676 : scanCanonicalize (H12AffineFastState.compose env35676 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35676 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35677 : List Nat := [1,4,5,1,5,5,5,1,0,4,5,0,4,4,1,0,0,4,5,0,1,0,0,0,4,5,4,5,5,5,4,0,0,5,0,1]

theorem envBound35677 : H12AffineFastState.Bounded env35677 := by
  intro p hp
  have h : env35677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35676_35677 : H12AffineEnvironment.transform 0 1 env35676 = env35677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35676 == env35677) = true)

theorem identity35677 : scanCanonicalize (H12AffineFastState.compose env35677 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35677 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35678 : List Nat := [1,0,1,1,1,1,1,1,0,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,0,1,0,1,1,1,0,0,0,1,0,1]

theorem envBound35678 : H12AffineFastState.Bounded env35678 := by
  intro p hp
  have h : env35678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35677_35678 : H12AffineEnvironment.transform 1 0 env35677 = env35678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35677 == env35678) = true)

def env35679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4097,476,74046,69648,13769,78894,332223,74814,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound35679 : H12AffineFastState.Bounded env35679 := by
  intro p hp
  have h : env35679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35517_35679 : H12AffineEnvironment.transform 13 1297 env35517 = env35679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35517 == env35679) = true)

def env35680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4097,476,74046,69648,13769,78894,4415,74814,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound35680 : H12AffineFastState.Bounded env35680 := by
  intro p hp
  have h : env35680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35679_35680 : H12AffineEnvironment.transform 17 65664 env35679 = env35680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35679 == env35680) = true)

theorem identity35680 : scanCanonicalize (H12AffineFastState.compose env35680 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound35680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4097,476,65911,69648,5504,70759,4415,66679,1297,72962,69,65830,257,1280,1344,5952]

theorem envBound35681 : H12AffineFastState.Bounded env35681 := by
  intro p hp
  have h : env35681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35680_35681 : H12AffineEnvironment.transform 12 73 env35680 = env35681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env35680 == env35681) = true)

def env35682 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4097,476,65911,69648,5504,70759,4415,66679,1297,72962,69,65830,257,1280,1344,5140]

theorem envBound35682 : H12AffineFastState.Bounded env35682 := by
  intro p hp
  have h : env35682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35681_35682 : H12AffineEnvironment.transform 8 340 env35681 = env35682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env35681 == env35682) = true)

def env35683 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4372,65536,65895,65664,4416,4373,4097,476,65911,69648,4288,69927,4415,65847,81,71746,69,65830,257,64,0,4436]

theorem envBound35683 : H12AffineFastState.Bounded env35683 := by
  intro p hp
  have h : env35683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35682_35683 : H12AffineEnvironment.transform 9 320 env35682 = env35683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35682 == env35683) = true)

theorem identity35683 : scanCanonicalize (H12AffineFastState.compose env35683 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound35683 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35684 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4372,4210,4373,4338,4416,4373,4097,476,4357,98,4288,341,4415,4421,81,2096,69,4436,257,64,0,4436]

theorem envBound35684 : H12AffineFastState.Bounded env35684 := by
  intro p hp
  have h : env35684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35683_35684 : H12AffineEnvironment.transform 15 4210 env35683 = env35684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env35683 == env35684) = true)

theorem identity35684 : scanCanonicalize (H12AffineFastState.compose env35684 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound35684 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35685 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,325,73,81,81,311,80,439,5,80,324,476,64,98,389,341,122,0,81,2096,69,17,257,64,0,17]

theorem envBound35685 : H12AffineFastState.Bounded env35685 := by
  intro p hp
  have h : env35685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35684_35685 : H12AffineEnvironment.transform 11 325 env35684 = env35685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env35684 == env35685) = true)

theorem identity35685 : scanCanonicalize (H12AffineFastState.compose env35685 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35685 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35686 : List Nat := [2,4,8,16,32,64,128,69,17,5,2048,0,73,81,81,114,80,242,5,80,1,153,64,98,192,16,122,0,81,2096,69,17,68,64,0,17]

theorem envBound35686 : H12AffineFastState.Bounded env35686 := by
  intro p hp
  have h : env35686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35685_35686 : H12AffineEnvironment.transform 7 69 env35685 = env35686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35685 == env35686) = true)

theorem identity35686 : scanCanonicalize (H12AffineFastState.compose env35686 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound35686 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env35687 : List Nat := [2,4,8,16,32,64,128,69,17,5,191,0,73,81,81,114,80,242,5,80,1,153,64,98,192,16,122,0,81,143,69,17,68,64,0,17]

theorem envBound35687 : H12AffineFastState.Bounded env35687 := by
  intro p hp
  have h : env35687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35686_35687 : H12AffineEnvironment.transform 10 191 env35686 = env35687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env35686 == env35687) = true)

theorem identity35687 : scanCanonicalize (H12AffineFastState.compose env35687 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound35687 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env35688 : List Nat := [2,4,8,16,32,64,73,69,17,5,118,0,73,81,81,114,80,59,5,80,1,80,64,98,9,16,122,0,81,70,69,17,68,64,0,17]

theorem envBound35688 : H12AffineFastState.Bounded env35688 := by
  intro p hp
  have h : env35688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35687_35688 : H12AffineEnvironment.transform 6 73 env35687 = env35688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env35687 == env35688) = true)

theorem identity35688 : scanCanonicalize (H12AffineFastState.compose env35688 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound35688 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35689 : List Nat := [2,4,8,16,32,6,15,3,17,5,48,0,15,23,23,52,22,59,5,22,1,22,6,36,9,16,60,0,23,0,3,17,2,6,0,17]

theorem envBound35689 : H12AffineFastState.Bounded env35689 := by
  intro p hp
  have h : env35689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35688_35689 : H12AffineEnvironment.transform 5 6 env35688 = env35689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env35688 == env35689) = true)

theorem identity35689 : scanCanonicalize (H12AffineFastState.compose env35689 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35690 : List Nat := [2,4,2,16,32,6,5,3,17,5,48,0,5,23,23,52,22,49,5,22,1,22,6,36,3,16,54,0,23,0,3,17,2,6,0,17]

theorem envBound35690 : H12AffineFastState.Bounded env35690 := by
  intro p hp
  have h : env35690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35689_35690 : H12AffineEnvironment.transform 2 2 env35689 = env35690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35689 == env35690) = true)

theorem identity35690 : scanCanonicalize (H12AffineFastState.compose env35690 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35690 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35691 : List Nat := [2,4,2,1,32,6,5,3,0,5,33,0,5,6,6,37,7,32,5,7,1,7,6,36,3,1,39,0,6,0,3,0,2,6,0,0]

theorem envBound35691 : H12AffineFastState.Bounded env35691 := by
  intro p hp
  have h : env35691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35690_35691 : H12AffineEnvironment.transform 3 1 env35690 = env35691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35690 == env35691) = true)

theorem identity35691 : scanCanonicalize (H12AffineFastState.compose env35691 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35692 : List Nat := [2,3,2,1,32,1,2,3,0,2,33,0,2,1,1,34,0,32,2,0,1,0,1,35,3,1,32,0,1,0,3,0,2,1,0,0]

theorem envBound35692 : H12AffineFastState.Bounded env35692 := by
  intro p hp
  have h : env35692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35691_35692 : H12AffineEnvironment.transform 1 3 env35691 = env35692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35691 == env35692) = true)

theorem identity35692 : scanCanonicalize (H12AffineFastState.compose env35692 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35693 : List Nat := [2,3,2,1,0,1,2,3,0,2,1,0,2,1,1,2,0,0,2,0,1,0,1,3,3,1,0,0,1,0,3,0,2,1,0,0]

theorem envBound35693 : H12AffineFastState.Bounded env35693 := by
  intro p hp
  have h : env35693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35692_35693 : H12AffineEnvironment.transform 4 0 env35692 = env35693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35692 == env35693) = true)

def env35694 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4373,65536,65894,65664,4416,4372,4097,476,65911,69648,4289,69926,4415,65846,80,71747,69,65830,257,65,1,4437]

theorem envBound35694 : H12AffineFastState.Bounded env35694 := by
  intro p hp
  have h : env35694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35682_35694 : H12AffineEnvironment.transform 9 321 env35682 = env35694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35682 == env35694) = true)

theorem identity35694 : scanCanonicalize (H12AffineFastState.compose env35694 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35694 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35695 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4373,115,277,243,4416,4372,4097,476,260,4195,4289,4437,4415,325,80,6192,69,341,257,65,1,4437]

theorem envBound35695 : H12AffineFastState.Bounded env35695 := by
  intro p hp
  have h : env35695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35694_35695 : H12AffineEnvironment.transform 15 115 env35694 = env35695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35694 == env35695) = true)

theorem identity35695 : scanCanonicalize (H12AffineFastState.compose env35695 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 503) := by decide +kernel

theorem selectedBound35695 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env35696 : List Nat := [2,4,8,16,32,64,128,256,340,321,503,4096,73,80,4373,115,277,243,4416,4372,4097,476,260,4195,4289,4437,4415,325,80,4551,69,341,257,65,1,4437]

theorem envBound35696 : H12AffineFastState.Bounded env35696 := by
  intro p hp
  have h : env35696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35695_35696 : H12AffineEnvironment.transform 10 503 env35695 = env35696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 503 env35695 == env35696) = true)

theorem identity35696 : scanCanonicalize (H12AffineFastState.compose env35696 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 280) := by decide +kernel

theorem selectedBound35696 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35697 : List Nat := [2,4,8,16,32,64,128,256,340,321,503,280,73,80,13,115,277,243,88,12,281,476,260,379,473,77,39,325,80,223,69,341,257,65,1,77]

theorem envBound35697 : H12AffineFastState.Bounded env35697 := by
  intro p hp
  have h : env35697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35696_35697 : H12AffineEnvironment.transform 11 280 env35696 = env35697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 280 env35696 == env35697) = true)

theorem identity35697 : scanCanonicalize (H12AffineFastState.compose env35697 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35697 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env35698 : List Nat := [2,4,8,16,32,64,128,20,64,85,227,12,73,80,13,115,1,243,88,12,13,200,16,111,205,77,39,81,80,223,69,65,21,65,1,77]

theorem envBound35698 : H12AffineFastState.Bounded env35698 := by
  intro p hp
  have h : env35698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35697_35698 : H12AffineEnvironment.transform 7 20 env35697 = env35698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35697 == env35698) = true)

theorem identity35698 : scanCanonicalize (H12AffineFastState.compose env35698 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound35698 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env35699 : List Nat := [2,4,8,16,32,44,128,20,44,57,143,12,37,60,13,31,1,159,52,12,13,164,16,3,161,33,39,61,60,179,41,45,21,45,1,33]

theorem envBound35699 : H12AffineFastState.Bounded env35699 := by
  intro p hp
  have h : env35699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35698_35699 : H12AffineEnvironment.transform 5 44 env35698 = env35699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env35698 == env35699) = true)

theorem identity35699 : scanCanonicalize (H12AffineFastState.compose env35699 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound35699 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env35700 : List Nat := [2,4,8,16,32,44,46,20,44,57,33,12,37,60,13,31,1,49,52,12,13,10,16,3,15,33,39,61,60,29,41,45,21,45,1,33]

theorem envBound35700 : H12AffineFastState.Bounded env35700 := by
  intro p hp
  have h : env35700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35699_35700 : H12AffineEnvironment.transform 6 46 env35699 = env35700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env35699 == env35700) = true)

theorem identity35700 : scanCanonicalize (H12AffineFastState.compose env35700 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35700 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env35701 : List Nat := [2,4,8,16,1,13,15,20,13,24,0,12,4,29,13,31,1,16,21,12,13,10,16,3,15,0,6,28,29,29,8,12,21,12,1,0]

theorem envBound35701 : H12AffineFastState.Bounded env35701 := by
  intro p hp
  have h : env35701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35700_35701 : H12AffineEnvironment.transform 4 1 env35700 = env35701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35700 == env35701) = true)

theorem identity35701 : scanCanonicalize (H12AffineFastState.compose env35701 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound35701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35702 : List Nat := [2,4,8,12,1,13,15,8,13,4,0,12,4,1,13,3,1,12,9,12,13,10,12,3,15,0,6,0,1,1,8,12,9,12,1,0]

theorem envBound35702 : H12AffineFastState.Bounded env35702 := by
  intro p hp
  have h : env35702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35701_35702 : H12AffineEnvironment.transform 3 12 env35701 = env35702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env35701 == env35702) = true)

def env35703 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1297,5204,65536,66599,65664,4416,5205,4097,476,65911,69648,5504,70759,4415,66679,1297,72962,69,65830,257,1280,1344,5141]

theorem envBound35703 : H12AffineFastState.Bounded env35703 := by
  intro p hp
  have h : env35703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35681_35703 : H12AffineEnvironment.transform 8 341 env35681 = env35703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env35681 == env35703) = true)

def env35704 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4372,65536,65895,65664,4416,4373,4097,476,65911,69648,4288,69927,4415,65847,81,71746,69,65830,257,64,0,4437]

theorem envBound35704 : H12AffineFastState.Bounded env35704 := by
  intro p hp
  have h : env35704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35703_35704 : H12AffineEnvironment.transform 9 320 env35703 = env35704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35703 == env35704) = true)

theorem identity35704 : scanCanonicalize (H12AffineFastState.compose env35704 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound35704 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35705 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4372,4210,4373,4338,4416,4373,4097,476,4357,98,4288,341,4415,4421,81,2096,69,4436,257,64,0,4437]

theorem envBound35705 : H12AffineFastState.Bounded env35705 := by
  intro p hp
  have h : env35705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35704_35705 : H12AffineEnvironment.transform 15 4210 env35704 = env35705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env35704 == env35705) = true)

theorem identity35705 : scanCanonicalize (H12AffineFastState.compose env35705 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound35705 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35706 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,325,73,81,81,311,80,439,5,80,324,476,64,98,389,341,122,0,81,2096,69,17,257,64,0,16]

theorem envBound35706 : H12AffineFastState.Bounded env35706 := by
  intro p hp
  have h : env35706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35705_35706 : H12AffineEnvironment.transform 11 325 env35705 = env35706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env35705 == env35706) = true)

theorem identity35706 : scanCanonicalize (H12AffineFastState.compose env35706 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35706 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35707 : List Nat := [2,4,8,16,32,64,128,69,16,5,2048,0,73,81,81,114,80,242,5,80,1,153,64,98,192,16,122,0,81,2096,69,17,68,64,0,16]

theorem envBound35707 : H12AffineFastState.Bounded env35707 := by
  intro p hp
  have h : env35707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35706_35707 : H12AffineEnvironment.transform 7 69 env35706 = env35707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35706 == env35707) = true)

theorem identity35707 : scanCanonicalize (H12AffineFastState.compose env35707 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 238) := by decide +kernel

theorem selectedBound35707 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env35708 : List Nat := [2,4,8,16,32,64,128,69,16,5,238,0,73,81,81,114,80,242,5,80,1,153,64,98,192,16,122,0,81,222,69,17,68,64,0,16]

theorem envBound35708 : H12AffineFastState.Bounded env35708 := by
  intro p hp
  have h : env35708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35707_35708 : H12AffineEnvironment.transform 10 238 env35707 = env35708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 238 env35707 == env35708) = true)

theorem identity35708 : scanCanonicalize (H12AffineFastState.compose env35708 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound35708 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env35709 : List Nat := [2,4,8,16,32,64,72,69,16,5,38,0,73,81,81,114,80,58,5,80,1,81,64,98,8,16,122,0,81,22,69,17,68,64,0,16]

theorem envBound35709 : H12AffineFastState.Bounded env35709 := by
  intro p hp
  have h : env35709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35708_35709 : H12AffineEnvironment.transform 6 72 env35708 = env35709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env35708 == env35709) = true)

theorem identity35709 : scanCanonicalize (H12AffineFastState.compose env35709 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound35709 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35710 : List Nat := [2,4,8,6,32,64,72,69,6,5,38,0,73,71,71,100,70,44,5,70,1,71,64,98,8,6,108,0,71,0,69,7,68,64,0,6]

theorem envBound35710 : H12AffineFastState.Bounded env35710 := by
  intro p hp
  have h : env35710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35709_35710 : H12AffineEnvironment.transform 3 6 env35709 = env35710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env35709 == env35710) = true)

theorem identity35710 : scanCanonicalize (H12AffineFastState.compose env35710 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35711 : List Nat := [2,4,3,6,32,64,67,69,6,5,38,0,66,71,71,100,70,39,5,70,1,71,64,98,3,6,103,0,71,0,69,7,68,64,0,6]

theorem envBound35711 : H12AffineFastState.Bounded env35711 := by
  intro p hp
  have h : env35711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35710_35711 : H12AffineEnvironment.transform 2 3 env35710 = env35711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35710 == env35711) = true)

theorem identity35711 : scanCanonicalize (H12AffineFastState.compose env35711 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35711 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35712 : List Nat := [2,2,3,0,32,64,67,67,0,3,32,0,66,65,65,98,64,33,3,64,1,65,64,98,3,0,97,0,65,0,67,1,66,64,0,0]

theorem envBound35712 : H12AffineFastState.Bounded env35712 := by
  intro p hp
  have h : env35712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35711_35712 : H12AffineEnvironment.transform 1 2 env35711 = env35712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35711 == env35712) = true)

theorem identity35712 : scanCanonicalize (H12AffineFastState.compose env35712 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35712 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35713 : List Nat := [2,2,3,0,32,0,3,3,0,3,32,0,2,1,1,34,0,33,3,0,1,1,0,34,3,0,33,0,1,0,3,1,2,0,0,0]

theorem envBound35713 : H12AffineFastState.Bounded env35713 := by
  intro p hp
  have h : env35713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35712_35713 : H12AffineEnvironment.transform 5 0 env35712 = env35713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35712 == env35713) = true)

theorem identity35713 : scanCanonicalize (H12AffineFastState.compose env35713 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35714 : List Nat := [2,2,3,0,1,0,3,3,0,3,1,0,2,1,1,3,0,0,3,0,1,1,0,3,3,0,0,0,1,0,3,1,2,0,0,0]

theorem envBound35714 : H12AffineFastState.Bounded env35714 := by
  intro p hp
  have h : env35714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35713_35714 : H12AffineEnvironment.transform 4 1 env35713 = env35714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35713 == env35714) = true)

def env35715 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4373,65536,65894,65664,4416,4372,4097,476,65911,69648,4289,69926,4415,65846,80,71747,69,65830,257,65,1,4436]

theorem envBound35715 : H12AffineFastState.Bounded env35715 := by
  intro p hp
  have h : env35715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35703_35715 : H12AffineEnvironment.transform 9 321 env35703 = env35715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35703 == env35715) = true)

theorem identity35715 : scanCanonicalize (H12AffineFastState.compose env35715 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35715 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35716 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4373,115,277,243,4416,4372,4097,476,260,4195,4289,4437,4415,325,80,6192,69,341,257,65,1,4436]

theorem envBound35716 : H12AffineFastState.Bounded env35716 := by
  intro p hp
  have h : env35716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35715_35716 : H12AffineEnvironment.transform 15 115 env35715 = env35716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35715 == env35716) = true)

theorem identity35716 : scanCanonicalize (H12AffineFastState.compose env35716 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound35716 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env35717 : List Nat := [2,4,8,16,32,64,128,256,341,321,502,4096,73,80,4373,115,277,243,4416,4372,4097,476,260,4195,4289,4437,4415,325,80,4550,69,341,257,65,1,4436]

theorem envBound35717 : H12AffineFastState.Bounded env35717 := by
  intro p hp
  have h : env35717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35716_35717 : H12AffineEnvironment.transform 10 502 env35716 = env35717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env35716 == env35717) = true)

theorem identity35717 : scanCanonicalize (H12AffineFastState.compose env35717 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 13) := by decide +kernel

theorem selectedBound35717 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35718 : List Nat := [2,4,8,16,32,64,128,256,341,321,502,13,73,80,280,115,277,243,333,281,12,476,260,110,204,344,306,325,80,459,69,341,257,65,1,345]

theorem envBound35718 : H12AffineFastState.Bounded env35718 := by
  intro p hp
  have h : env35718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35717_35718 : H12AffineEnvironment.transform 11 13 env35717 = env35718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 13 env35717 == env35718) = true)

theorem identity35718 : scanCanonicalize (H12AffineFastState.compose env35718 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35718 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env35719 : List Nat := [2,4,8,16,32,64,128,20,65,85,226,13,73,80,12,115,1,243,89,13,12,200,16,110,204,76,38,81,80,223,69,65,21,65,1,77]

theorem envBound35719 : H12AffineFastState.Bounded env35719 := by
  intro p hp
  have h : env35719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35718_35719 : H12AffineEnvironment.transform 7 20 env35718 = env35719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35718 == env35719) = true)

theorem identity35719 : scanCanonicalize (H12AffineFastState.compose env35719 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound35719 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env35720 : List Nat := [2,4,8,16,32,45,128,20,44,56,143,13,36,61,12,30,1,158,52,13,12,165,16,3,161,33,38,60,61,178,40,44,21,44,1,32]

theorem envBound35720 : H12AffineFastState.Bounded env35720 := by
  intro p hp
  have h : env35720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35719_35720 : H12AffineEnvironment.transform 5 45 env35719 = env35720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env35719 == env35720) = true)

theorem identity35720 : scanCanonicalize (H12AffineFastState.compose env35720 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound35720 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env35721 : List Nat := [2,4,8,16,32,45,35,20,44,56,44,13,36,61,12,30,1,61,52,13,12,6,16,3,2,33,38,60,61,17,40,44,21,44,1,32]

theorem envBound35721 : H12AffineFastState.Bounded env35721 := by
  intro p hp
  have h : env35721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35720_35721 : H12AffineEnvironment.transform 6 35 env35720 = env35721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env35720 == env35721) = true)

theorem identity35721 : scanCanonicalize (H12AffineFastState.compose env35721 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35721 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35722 : List Nat := [2,4,5,16,32,32,35,20,33,53,33,0,36,48,1,19,1,48,52,0,1,6,16,3,2,33,38,49,48,17,37,33,21,33,1,32]

theorem envBound35722 : H12AffineFastState.Bounded env35722 := by
  intro p hp
  have h : env35722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35721_35722 : H12AffineEnvironment.transform 2 5 env35721 = env35722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35721 == env35722) = true)

theorem identity35722 : scanCanonicalize (H12AffineFastState.compose env35722 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound35722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35723 : List Nat := [2,4,5,16,3,3,0,20,2,22,2,0,7,19,1,19,1,19,23,0,1,6,16,3,2,2,5,18,19,17,6,2,21,2,1,3]

theorem envBound35723 : H12AffineFastState.Bounded env35723 := by
  intro p hp
  have h : env35723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35722_35723 : H12AffineEnvironment.transform 4 3 env35722 = env35723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env35722 == env35723) = true)

theorem identity35723 : scanCanonicalize (H12AffineFastState.compose env35723 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound35723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35724 : List Nat := [2,4,5,3,3,3,0,7,2,5,2,0,7,0,1,0,1,0,4,0,1,6,3,3,2,2,5,1,0,2,6,2,6,2,1,3]

theorem envBound35724 : H12AffineFastState.Bounded env35724 := by
  intro p hp
  have h : env35724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35723_35724 : H12AffineEnvironment.transform 3 3 env35723 = env35724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env35723 == env35724) = true)

theorem identity35724 : scanCanonicalize (H12AffineFastState.compose env35724 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35725 : List Nat := [0,4,5,1,1,1,0,5,0,5,0,0,5,0,1,0,1,0,4,0,1,4,1,1,0,0,5,1,0,0,4,0,4,0,1,1]

theorem envBound35725 : H12AffineFastState.Bounded env35725 := by
  intro p hp
  have h : env35725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35724_35725 : H12AffineEnvironment.transform 0 0 env35724 = env35725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35724 == env35725) = true)

theorem identity35725 : scanCanonicalize (H12AffineFastState.compose env35725 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35725 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env35726 : List Nat := [0,1,0,1,1,1,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,1,1,1,0,0,0,1,0,0,1,0,1,0,1,1]

theorem envBound35726 : H12AffineFastState.Bounded env35726 := by
  intro p hp
  have h : env35726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35725_35726 : H12AffineEnvironment.transform 1 1 env35725 = env35726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35725 == env35726) = true)

def env35727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4097,476,74046,69648,13769,78894,4414,74814,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound35727 : H12AffineFastState.Bounded env35727 := by
  intro p hp
  have h : env35727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35679_35727 : H12AffineEnvironment.transform 17 65665 env35679 = env35727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35679 == env35727) = true)

theorem identity35727 : scanCanonicalize (H12AffineFastState.compose env35727 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound35727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4097,476,70710,69648,193,65830,4414,69942,1297,67651,5380,65830,257,1280,1344,5952]

theorem envBound35728 : H12AffineFastState.Bounded env35728 := by
  intro p hp
  have h : env35728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35727_35728 : H12AffineEnvironment.transform 12 5384 env35727 = env35728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env35727 == env35728) = true)

def env35729 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4097,476,70710,69648,193,65830,4414,69942,1297,67651,5380,65830,257,1280,1344,5140]

theorem envBound35729 : H12AffineFastState.Bounded env35729 := by
  intro p hp
  have h : env35729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35728_35729 : H12AffineEnvironment.transform 8 340 env35728 = env35729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env35728 == env35729) = true)

def env35730 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1297,277,65536,65894,65665,320,276,1,476,66614,65552,193,65830,318,65846,1297,67651,1284,65830,257,1280,1344,1044]

theorem envBound35730 : H12AffineFastState.Bounded env35730 := by
  intro p hp
  have h : env35730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35729_35730 : H12AffineEnvironment.transform 11 0 env35729 = env35730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35729 == env35730) = true)

theorem identity35730 : scanCanonicalize (H12AffineFastState.compose env35730 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35730 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35731 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1297,277,115,277,242,320,276,1,476,1093,99,193,341,318,325,1297,2096,1284,341,257,1280,1344,1044]

theorem envBound35731 : H12AffineFastState.Bounded env35731 := by
  intro p hp
  have h : env35731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35730_35731 : H12AffineEnvironment.transform 15 115 env35730 = env35731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35730 == env35731) = true)

theorem identity35731 : scanCanonicalize (H12AffineFastState.compose env35731 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 422) := by decide +kernel

theorem selectedBound35731 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35732 : List Nat := [2,4,8,16,32,64,128,256,340,1024,422,0,1288,1297,277,115,277,242,320,276,1,476,1093,99,193,341,318,325,1297,406,1284,341,257,1280,1344,1044]

theorem envBound35732 : H12AffineFastState.Bounded env35732 := by
  intro p hp
  have h : env35732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35731_35732 : H12AffineEnvironment.transform 10 422 env35731 = env35732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 422 env35731 == env35732) = true)

theorem identity35732 : scanCanonicalize (H12AffineFastState.compose env35732 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound35732 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env35733 : List Nat := [2,4,8,16,32,64,128,256,340,85,422,0,349,324,277,115,277,242,320,276,1,476,16,99,193,341,318,325,324,406,337,341,257,341,277,65]

theorem envBound35733 : H12AffineFastState.Bounded env35733 := by
  intro p hp
  have h : env35733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35732_35733 : H12AffineEnvironment.transform 9 85 env35732 = env35733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env35732 == env35733) = true)

theorem identity35733 : scanCanonicalize (H12AffineFastState.compose env35733 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound35733 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env35734 : List Nat := [2,4,8,16,32,64,128,53,97,85,147,0,104,113,32,115,32,242,117,33,1,233,16,99,193,96,11,112,113,163,100,96,52,96,32,65]

theorem envBound35734 : H12AffineFastState.Bounded env35734 := by
  intro p hp
  have h : env35734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35733_35734 : H12AffineEnvironment.transform 7 53 env35733 = env35734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env35733 == env35734) = true)

theorem identity35734 : scanCanonicalize (H12AffineFastState.compose env35734 (packedSelected [0,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound35734 : packedSelected [0,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35735 : List Nat := [2,4,8,16,32,64,36,53,97,85,55,0,104,113,32,115,32,86,117,33,1,77,16,99,101,96,11,112,113,7,100,96,52,96,32,65]

theorem envBound35735 : H12AffineFastState.Bounded env35735 := by
  intro p hp
  have h : env35735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35734_35735 : H12AffineEnvironment.transform 6 36 env35734 = env35735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env35734 == env35735) = true)

theorem identity35735 : scanCanonicalize (H12AffineFastState.compose env35735 (packedSelected [0,3,5,7,8,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35735 : packedSelected [0,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35736 : List Nat := [2,4,2,16,32,64,36,53,97,85,55,0,98,113,32,115,32,86,117,33,1,71,16,99,101,96,1,112,113,7,100,96,52,96,32,65]

theorem envBound35736 : H12AffineFastState.Bounded env35736 := by
  intro p hp
  have h : env35736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35735_35736 : H12AffineEnvironment.transform 2 2 env35735 = env35736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35735 == env35736) = true)

theorem identity35736 : scanCanonicalize (H12AffineFastState.compose env35736 (packedSelected [4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound35736 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env35737 : List Nat := [2,4,2,16,32,22,36,53,55,3,55,0,52,39,32,37,32,0,35,33,1,17,16,53,51,54,1,38,39,7,50,54,52,54,32,23]

theorem envBound35737 : H12AffineFastState.Bounded env35737 := by
  intro p hp
  have h : env35737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35736_35737 : H12AffineEnvironment.transform 5 22 env35736 = env35737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env35736 == env35737) = true)

def env35738 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1297,277,65536,65895,65665,321,276,0,476,66615,65553,193,65830,319,65847,1297,67651,1285,65830,257,1280,1344,1045]

theorem envBound35738 : H12AffineFastState.Bounded env35738 := by
  intro p hp
  have h : env35738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35729_35738 : H12AffineEnvironment.transform 11 1 env35729 = env35738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env35729 == env35738) = true)

theorem identity35738 : scanCanonicalize (H12AffineFastState.compose env35738 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound35738 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35739 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1297,277,1331,1108,1458,321,276,0,476,260,1314,193,1045,319,1028,1297,3440,1285,1045,257,1280,1344,1045]

theorem envBound35739 : H12AffineFastState.Bounded env35739 := by
  intro p hp
  have h : env35739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35738_35739 : H12AffineEnvironment.transform 15 1331 env35738 = env35739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env35738 == env35739) = true)

theorem identity35739 : scanCanonicalize (H12AffineFastState.compose env35739 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound35739 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env35740 : List Nat := [2,4,8,16,32,64,128,256,340,1024,91,1,1289,1297,277,1331,1108,1458,321,276,0,476,260,1314,193,1045,319,1028,1297,1323,1285,1045,257,1280,1344,1045]

theorem envBound35740 : H12AffineFastState.Bounded env35740 := by
  intro p hp
  have h : env35740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35739_35740 : H12AffineEnvironment.transform 10 91 env35739 = env35740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env35739 == env35740) = true)

theorem identity35740 : scanCanonicalize (H12AffineFastState.compose env35740 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35740 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35741 : List Nat := [2,4,8,16,32,64,128,68,16,1024,91,1,1101,1109,81,1143,1108,1270,5,80,0,152,64,1126,193,1045,123,1028,1109,1135,1089,1045,69,1092,1028,1045]

theorem envBound35741 : H12AffineFastState.Bounded env35741 := by
  intro p hp
  have h : env35741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35740_35741 : H12AffineEnvironment.transform 7 68 env35740 = env35741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35740 == env35741) = true)

theorem identity35741 : scanCanonicalize (H12AffineFastState.compose env35741 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35741 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env35742 : List Nat := [2,2,8,16,32,64,128,66,16,1024,91,1,1099,1107,81,1137,1106,1264,3,80,0,152,64,1120,193,1043,123,1026,1107,1129,1089,1043,67,1090,1026,1043]

theorem envBound35742 : H12AffineFastState.Bounded env35742 := by
  intro p hp
  have h : env35742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35741_35742 : H12AffineEnvironment.transform 1 2 env35741 = env35742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35741 == env35742) = true)

theorem identity35742 : scanCanonicalize (H12AffineFastState.compose env35742 (packedSelected [1,3,15] rootPS)) = affineNative (2^(9+1) ^^^ 25) := by decide +kernel

theorem selectedBound35742 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env35743 : List Nat := [2,2,8,16,32,64,128,66,16,25,91,1,82,74,81,104,75,233,3,80,0,152,64,121,193,10,123,27,74,112,88,10,67,91,27,10]

theorem envBound35743 : H12AffineFastState.Bounded env35743 := by
  intro p hp
  have h : env35743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35742_35743 : H12AffineEnvironment.transform 9 25 env35742 = env35743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 25 env35742 == env35743) = true)

theorem identity35743 : scanCanonicalize (H12AffineFastState.compose env35743 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound35743 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35744 : List Nat := [2,2,8,16,32,48,128,50,16,25,43,1,34,58,33,24,59,153,3,32,0,152,48,9,177,10,11,27,58,0,40,10,51,43,27,10]

theorem envBound35744 : H12AffineFastState.Bounded env35744 := by
  intro p hp
  have h : env35744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35743_35744 : H12AffineEnvironment.transform 5 48 env35743 = env35744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env35743 == env35744) = true)

theorem identity35744 : scanCanonicalize (H12AffineFastState.compose env35744 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound35744 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env35745 : List Nat := [2,2,8,16,32,48,50,50,16,25,43,1,34,58,33,24,59,43,3,32,0,42,48,9,3,10,11,27,58,0,40,10,51,43,27,10]

theorem envBound35745 : H12AffineFastState.Bounded env35745 := by
  intro p hp
  have h : env35745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35744_35745 : H12AffineEnvironment.transform 6 50 env35744 = env35745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env35744 == env35745) = true)

theorem identity35745 : scanCanonicalize (H12AffineFastState.compose env35745 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35745 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35746 : List Nat := [2,2,8,0,32,32,34,34,0,9,43,1,34,42,33,8,43,43,3,32,0,42,32,9,3,10,11,11,42,0,40,10,35,43,11,10]

theorem envBound35746 : H12AffineFastState.Bounded env35746 := by
  intro p hp
  have h : env35746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35745_35746 : H12AffineEnvironment.transform 3 0 env35745 = env35746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35745 == env35746) = true)

theorem identity35746 : scanCanonicalize (H12AffineFastState.compose env35746 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35747 : List Nat := [2,2,8,0,1,1,3,3,0,9,10,1,3,11,0,8,10,10,3,1,0,11,1,9,3,10,11,11,11,0,9,10,2,10,11,10]

theorem envBound35747 : H12AffineFastState.Bounded env35747 := by
  intro p hp
  have h : env35747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35746_35747 : H12AffineEnvironment.transform 4 1 env35746 = env35747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35746 == env35747) = true)

theorem identity35747 : scanCanonicalize (H12AffineFastState.compose env35747 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35747 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35748 : List Nat := [2,2,3,0,1,1,3,3,0,2,1,1,3,0,0,3,1,1,3,1,0,0,1,2,3,1,0,0,0,0,2,1,2,1,0,1]

theorem envBound35748 : H12AffineFastState.Bounded env35748 := by
  intro p hp
  have h : env35748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35747_35748 : H12AffineEnvironment.transform 2 3 env35747 = env35748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35747 == env35748) = true)

theorem identity35748 : scanCanonicalize (H12AffineFastState.compose env35748 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35748 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35749 : List Nat := [0,0,1,0,1,1,1,1,0,0,1,1,1,0,0,1,1,1,1,1,0,0,1,0,1,1,0,0,0,0,0,1,0,1,0,1]

theorem envBound35749 : H12AffineFastState.Bounded env35749 := by
  intro p hp
  have h : env35749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35748_35749 : H12AffineEnvironment.transform 0 0 env35748 = env35749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35748 == env35749) = true)

def env35750 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1297,277,65536,69990,65665,4416,276,4097,476,70710,69648,193,65830,4414,69942,1297,67651,5380,65830,257,1280,1344,5141]

theorem envBound35750 : H12AffineFastState.Bounded env35750 := by
  intro p hp
  have h : env35750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35728_35750 : H12AffineEnvironment.transform 8 341 env35728 = env35750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env35728 == env35750) = true)

def env35751 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1297,277,65536,65894,65665,320,276,1,476,66614,65552,193,65830,318,65846,1297,67651,1284,65830,257,1280,1344,1045]

theorem envBound35751 : H12AffineFastState.Bounded env35751 := by
  intro p hp
  have h : env35751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35750_35751 : H12AffineEnvironment.transform 11 0 env35750 = env35751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35750 == env35751) = true)

theorem identity35751 : scanCanonicalize (H12AffineFastState.compose env35751 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35751 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35752 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1297,277,115,277,242,320,276,1,476,1093,99,193,341,318,325,1297,2096,1284,341,257,1280,1344,1045]

theorem envBound35752 : H12AffineFastState.Bounded env35752 := by
  intro p hp
  have h : env35752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35751_35752 : H12AffineEnvironment.transform 15 115 env35751 = env35752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35751 == env35752) = true)

theorem identity35752 : scanCanonicalize (H12AffineFastState.compose env35752 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound35752 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35753 : List Nat := [2,4,8,16,32,64,128,256,341,1024,423,0,1288,1297,277,115,277,242,320,276,1,476,1093,99,193,341,318,325,1297,407,1284,341,257,1280,1344,1045]

theorem envBound35753 : H12AffineFastState.Bounded env35753 := by
  intro p hp
  have h : env35753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35752_35753 : H12AffineEnvironment.transform 10 423 env35752 = env35753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env35752 == env35753) = true)

theorem identity35753 : scanCanonicalize (H12AffineFastState.compose env35753 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound35753 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env35754 : List Nat := [2,4,8,16,32,64,128,256,341,85,423,0,349,324,277,115,277,242,320,276,1,476,16,99,193,341,318,325,324,407,337,341,257,341,277,64]

theorem envBound35754 : H12AffineFastState.Bounded env35754 := by
  intro p hp
  have h : env35754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35753_35754 : H12AffineEnvironment.transform 9 85 env35753 = env35754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env35753 == env35754) = true)

theorem identity35754 : scanCanonicalize (H12AffineFastState.compose env35754 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound35754 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env35755 : List Nat := [2,4,8,16,32,64,128,52,97,85,147,0,105,112,33,115,33,242,116,32,1,232,16,99,193,97,10,113,112,163,101,97,53,97,33,64]

theorem envBound35755 : H12AffineFastState.Bounded env35755 := by
  intro p hp
  have h : env35755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35754_35755 : H12AffineEnvironment.transform 7 52 env35754 = env35755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env35754 == env35755) = true)

theorem identity35755 : scanCanonicalize (H12AffineFastState.compose env35755 (packedSelected [0,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound35755 : packedSelected [0,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35756 : List Nat := [2,4,8,16,32,64,36,52,97,85,55,0,105,112,33,115,33,86,116,32,1,76,16,99,101,97,10,113,112,7,101,97,53,97,33,64]

theorem envBound35756 : H12AffineFastState.Bounded env35756 := by
  intro p hp
  have h : env35756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35755_35756 : H12AffineEnvironment.transform 6 36 env35755 = env35756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env35755 == env35756) = true)

theorem identity35756 : scanCanonicalize (H12AffineFastState.compose env35756 (packedSelected [0,3,5,7,8,11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35756 : packedSelected [0,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35757 : List Nat := [2,4,3,16,32,64,36,52,97,85,55,0,98,112,33,115,33,86,116,32,1,71,16,99,101,97,1,113,112,7,101,97,53,97,33,64]

theorem envBound35757 : H12AffineFastState.Bounded env35757 := by
  intro p hp
  have h : env35757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35756_35757 : H12AffineEnvironment.transform 2 3 env35756 = env35757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35756 == env35757) = true)

theorem identity35757 : scanCanonicalize (H12AffineFastState.compose env35757 (packedSelected [4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound35757 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env35758 : List Nat := [2,4,3,16,32,22,36,52,55,3,55,0,52,38,33,37,33,0,34,32,1,17,16,53,51,55,1,39,38,7,51,55,53,55,33,22]

theorem envBound35758 : H12AffineFastState.Bounded env35758 := by
  intro p hp
  have h : env35758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35757_35758 : H12AffineEnvironment.transform 5 22 env35757 = env35758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env35757 == env35758) = true)

def env35759 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1297,277,65536,65895,65665,321,276,0,476,66615,65553,193,65830,319,65847,1297,67651,1285,65830,257,1280,1344,1044]

theorem envBound35759 : H12AffineFastState.Bounded env35759 := by
  intro p hp
  have h : env35759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35750_35759 : H12AffineEnvironment.transform 11 1 env35750 = env35759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env35750 == env35759) = true)

theorem identity35759 : scanCanonicalize (H12AffineFastState.compose env35759 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound35759 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35760 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1297,277,1331,1108,1458,321,276,0,476,260,1314,193,1045,319,1028,1297,3440,1285,1045,257,1280,1344,1044]

theorem envBound35760 : H12AffineFastState.Bounded env35760 := by
  intro p hp
  have h : env35760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35759_35760 : H12AffineEnvironment.transform 15 1331 env35759 = env35760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env35759 == env35760) = true)

theorem identity35760 : scanCanonicalize (H12AffineFastState.compose env35760 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound35760 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env35761 : List Nat := [2,4,8,16,32,64,128,256,341,1024,90,1,1289,1297,277,1331,1108,1458,321,276,0,476,260,1314,193,1045,319,1028,1297,1322,1285,1045,257,1280,1344,1044]

theorem envBound35761 : H12AffineFastState.Bounded env35761 := by
  intro p hp
  have h : env35761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35760_35761 : H12AffineEnvironment.transform 10 90 env35760 = env35761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env35760 == env35761) = true)

theorem identity35761 : scanCanonicalize (H12AffineFastState.compose env35761 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35761 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35762 : List Nat := [2,4,8,16,32,64,128,68,17,1024,90,1,1101,1109,81,1143,1108,1270,5,80,0,152,64,1126,193,1045,123,1028,1109,1134,1089,1045,69,1092,1028,1044]

theorem envBound35762 : H12AffineFastState.Bounded env35762 := by
  intro p hp
  have h : env35762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35761_35762 : H12AffineEnvironment.transform 7 68 env35761 = env35762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35761 == env35762) = true)

theorem identity35762 : scanCanonicalize (H12AffineFastState.compose env35762 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound35762 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env35763 : List Nat := [2,4,8,16,32,23,128,19,17,1024,13,1,1050,1026,6,1056,1027,1185,5,7,0,152,23,1073,150,1045,44,1028,1026,1081,1046,1045,18,1043,1028,1044]

theorem envBound35763 : H12AffineFastState.Bounded env35763 := by
  intro p hp
  have h : env35763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35762_35763 : H12AffineEnvironment.transform 5 23 env35762 = env35763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env35762 == env35763) = true)

theorem identity35763 : scanCanonicalize (H12AffineFastState.compose env35763 (packedSelected [1,3,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35763 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env35764 : List Nat := [2,4,8,10,32,13,128,9,11,1024,13,1,1024,1026,6,1056,1027,1185,5,7,0,130,13,1067,140,1039,44,1028,1026,1059,1036,1039,8,1033,1028,1038]

theorem envBound35764 : H12AffineFastState.Bounded env35764 := by
  intro p hp
  have h : env35764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35763_35764 : H12AffineEnvironment.transform 3 10 env35763 = env35764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35763 == env35764) = true)

theorem identity35764 : scanCanonicalize (H12AffineFastState.compose env35764 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound35764 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35765 : List Nat := [2,4,8,10,32,13,128,9,11,35,13,1,35,33,6,3,32,130,5,7,0,130,13,8,140,44,44,39,33,0,47,44,8,42,39,45]

theorem envBound35765 : H12AffineFastState.Bounded env35765 := by
  intro p hp
  have h : env35765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35764_35765 : H12AffineEnvironment.transform 9 35 env35764 = env35765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env35764 == env35765) = true)

theorem identity35765 : scanCanonicalize (H12AffineFastState.compose env35765 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35765 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env35766 : List Nat := [2,4,8,10,32,13,9,9,11,35,13,1,35,33,6,3,32,11,5,7,0,11,13,8,5,44,44,39,33,0,47,44,8,42,39,45]

theorem envBound35766 : H12AffineFastState.Bounded env35766 := by
  intro p hp
  have h : env35766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35765_35766 : H12AffineEnvironment.transform 6 9 env35765 = env35766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35765 == env35766) = true)

theorem identity35766 : scanCanonicalize (H12AffineFastState.compose env35766 (packedSelected [1,2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35766 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35767 : List Nat := [2,2,8,10,32,11,9,9,11,35,11,1,35,33,0,3,32,11,3,1,0,11,11,8,3,42,42,33,33,0,41,42,8,42,33,43]

theorem envBound35767 : H12AffineFastState.Bounded env35767 := by
  intro p hp
  have h : env35767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35766_35767 : H12AffineEnvironment.transform 1 2 env35766 = env35767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35766 == env35767) = true)

theorem identity35767 : scanCanonicalize (H12AffineFastState.compose env35767 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35767 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35768 : List Nat := [2,2,8,10,0,11,9,9,11,3,11,1,3,1,0,3,0,11,3,1,0,11,11,8,3,10,10,1,1,0,9,10,8,10,1,11]

theorem envBound35768 : H12AffineFastState.Bounded env35768 := by
  intro p hp
  have h : env35768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35767_35768 : H12AffineEnvironment.transform 4 0 env35767 = env35768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35767 == env35768) = true)

def env35769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123165,533641,614527,385202,90415,545088,96346,25884,82998,257,545105,1344,525824]

theorem envBound35769 : H12AffineFastState.Bounded env35769 := by
  intro p hp
  have h : env35769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35284_35769 : H12AffineEnvironment.transform 23 123165 env35284 = env35769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env35284 == env35769) = true)

def env35770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123165,28889,78895,385202,90415,1296,96346,25884,82998,257,1281,1344,21072]

theorem envBound35770 : H12AffineFastState.Bounded env35770 := by
  intro p hp
  have h : env35770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35769_35770 : H12AffineEnvironment.transform 18 21584 env35769 = env35770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env35769 == env35770) = true)

theorem identity35770 : scanCanonicalize (H12AffineFastState.compose env35770 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound35770 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4097,5276,91183,66897,28889,78895,328958,90415,1296,96346,25884,82998,257,1281,1344,21072]

theorem envBound35771 : H12AffineFastState.Bounded env35771 := by
  intro p hp
  have h : env35771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35770_35771 : H12AffineEnvironment.transform 14 25676 env35770 = env35771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env35770 == env35771) = true)

def env35772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4097,5276,74047,66897,13769,78895,328958,74815,1296,81226,8204,65830,257,1281,1344,5952]

theorem envBound35772 : H12AffineFastState.Bounded env35772 := by
  intro p hp
  have h : env35772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35771_35772 : H12AffineEnvironment.transform 13 1296 env35771 = env35772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35771 == env35772) = true)

def env35773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4097,5276,74047,66897,13769,78895,1150,74815,1296,81226,8204,65830,257,1281,1344,5952]

theorem envBound35773 : H12AffineFastState.Bounded env35773 := by
  intro p hp
  have h : env35773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35772_35773 : H12AffineEnvironment.transform 17 65664 env35772 = env35773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35772 == env35773) = true)

theorem identity35773 : scanCanonicalize (H12AffineFastState.compose env35773 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound35773 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12591,5441,12719,4416,8541,4097,5276,4112,13438,13769,1280,1150,5392,1296,3173,8204,12297,257,1281,1344,5952]

theorem envBound35774 : H12AffineFastState.Bounded env35774 := by
  intro p hp
  have h : env35774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35773_35774 : H12AffineEnvironment.transform 15 12591 env35773 = env35774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env35773 == env35774) = true)

def env35775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8495,1345,8623,320,8541,1,1180,16,9342,9673,1280,1150,1296,1296,3173,8204,8201,257,1281,1344,1856]

theorem envBound35775 : H12AffineFastState.Bounded env35775 := by
  intro p hp
  have h : env35775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35774_35775 : H12AffineEnvironment.transform 11 0 env35774 = env35775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35774 == env35775) = true)

theorem identity35775 : scanCanonicalize (H12AffineFastState.compose env35775 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35775 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35776 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1109,8217,8298,1028,8426,5,8216,1,1180,16,9342,9356,1093,1150,1109,1109,3173,8204,8201,68,1092,1029,1541]

theorem envBound35776 : H12AffineFastState.Bounded env35776 := by
  intro p hp
  have h : env35776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35775_35776 : H12AffineEnvironment.transform 7 69 env35775 = env35776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35775 == env35776) = true)

theorem identity35776 : scanCanonicalize (H12AffineFastState.compose env35776 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35776 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35777 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,80,8217,8298,1,8426,5,8216,1,153,16,8315,8329,64,123,80,80,2144,8204,8201,68,65,0,512]

theorem envBound35777 : H12AffineFastState.Bounded env35777 := by
  intro p hp
  have h : env35777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35776_35777 : H12AffineEnvironment.transform 9 5 env35776 = env35777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35776 == env35777) = true)

theorem identity35777 : scanCanonicalize (H12AffineFastState.compose env35777 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound35777 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35778 : List Nat := [2,4,8,16,32,64,128,69,512,5,123,0,8192,80,8217,8298,1,8426,5,8216,1,153,16,8315,8329,64,123,80,80,27,8204,8201,68,65,0,512]

theorem envBound35778 : H12AffineFastState.Bounded env35778 := by
  intro p hp
  have h : env35778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35777_35778 : H12AffineEnvironment.transform 10 123 env35777 = env35778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env35777 == env35778) = true)

theorem identity35778 : scanCanonicalize (H12AffineFastState.compose env35778 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound35778 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35779 : List Nat := [2,4,8,16,32,64,128,69,96,5,123,0,8192,80,8217,8298,1,8426,5,8216,1,153,16,8315,8329,64,123,80,80,27,8204,8201,68,65,0,96]

theorem envBound35779 : H12AffineFastState.Bounded env35779 := by
  intro p hp
  have h : env35779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35778_35779 : H12AffineEnvironment.transform 8 96 env35778 = env35779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env35778 == env35779) = true)

theorem identity35779 : scanCanonicalize (H12AffineFastState.compose env35779 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound35779 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env35780 : List Nat := [2,4,8,16,32,64,56,69,96,5,123,0,8192,80,8217,8298,1,8274,5,8216,1,33,16,8315,8241,64,123,80,80,27,8204,8201,68,65,0,96]

theorem envBound35780 : H12AffineFastState.Bounded env35780 := by
  intro p hp
  have h : env35780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35779_35780 : H12AffineEnvironment.transform 6 56 env35779 = env35780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env35779 == env35780) = true)

theorem identity35780 : scanCanonicalize (H12AffineFastState.compose env35780 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35780 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35781 : List Nat := [2,4,8,16,32,64,56,69,96,5,123,0,41,80,48,67,1,123,5,49,1,33,16,82,24,64,123,80,80,27,37,32,68,65,0,96]

theorem envBound35781 : H12AffineFastState.Bounded env35781 := by
  intro p hp
  have h : env35781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35780_35781 : H12AffineEnvironment.transform 12 41 env35780 = env35781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35780 == env35781) = true)

theorem identity35781 : scanCanonicalize (H12AffineFastState.compose env35781 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound35781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35782 : List Nat := [2,4,8,16,32,10,56,15,42,5,49,0,41,26,48,9,1,49,5,49,1,33,16,24,24,10,49,26,26,27,37,32,14,11,0,42]

theorem envBound35782 : H12AffineFastState.Bounded env35782 := by
  intro p hp
  have h : env35782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35781_35782 : H12AffineEnvironment.transform 5 10 env35781 = env35782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env35781 == env35782) = true)

theorem identity35782 : scanCanonicalize (H12AffineFastState.compose env35782 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35782 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35783 : List Nat := [2,4,8,16,10,10,18,15,0,5,27,0,3,26,26,9,1,27,5,27,1,11,16,24,24,10,27,26,26,27,15,10,14,11,0,0]

theorem envBound35783 : H12AffineFastState.Bounded env35783 := by
  intro p hp
  have h : env35783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35782_35783 : H12AffineEnvironment.transform 4 10 env35782 = env35783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35782 == env35783) = true)

theorem identity35783 : scanCanonicalize (H12AffineFastState.compose env35783 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound35783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35784 : List Nat := [2,4,8,12,10,10,14,15,0,5,7,0,3,6,6,9,1,7,5,7,1,11,12,4,4,10,7,6,6,7,15,10,14,11,0,0]

theorem envBound35784 : H12AffineFastState.Bounded env35784 := by
  intro p hp
  have h : env35784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35783_35784 : H12AffineEnvironment.transform 3 12 env35783 = env35784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env35783 == env35784) = true)

theorem identity35784 : scanCanonicalize (H12AffineFastState.compose env35784 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35784 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35785 : List Nat := [2,3,8,11,10,10,9,8,0,2,0,0,3,1,1,9,1,0,2,0,1,11,11,3,3,10,0,1,1,0,8,10,9,11,0,0]

theorem envBound35785 : H12AffineFastState.Bounded env35785 := by
  intro p hp
  have h : env35785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35784_35785 : H12AffineEnvironment.transform 1 3 env35784 = env35785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35784 == env35785) = true)

def env35786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8494,1344,8622,321,8541,0,1181,17,9343,9672,1280,1150,1297,1296,3173,8204,8200,257,1281,1344,1857]

theorem envBound35786 : H12AffineFastState.Bounded env35786 := by
  intro p hp
  have h : env35786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35774_35786 : H12AffineEnvironment.transform 11 1 env35774 = env35786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env35774 == env35786) = true)

theorem identity35786 : scanCanonicalize (H12AffineFastState.compose env35786 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound35786 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,24,1296,324,310,1344,438,321,325,0,1181,17,1127,1488,1280,1150,1297,1296,3173,20,16,257,1281,1344,1857]

theorem envBound35787 : H12AffineFastState.Bounded env35787 := by
  intro p hp
  have h : env35787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35786_35787 : H12AffineEnvironment.transform 12 24 env35786 = env35787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env35786 == env35787) = true)

theorem identity35787 : scanCanonicalize (H12AffineFastState.compose env35787 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound35787 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env35788 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,1,24,728,324,310,648,438,321,325,0,853,17,943,536,712,950,729,728,2989,20,16,257,713,648,137]

theorem envBound35788 : H12AffineFastState.Bounded env35788 := by
  intro p hp
  have h : env35788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35787_35788 : H12AffineEnvironment.transform 9 968 env35787 = env35788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env35787 == env35788) = true)

theorem identity35788 : scanCanonicalize (H12AffineFastState.compose env35788 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35788 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env35789 : List Nat := [2,4,8,16,32,64,128,20,512,732,2048,1,24,728,80,34,648,162,85,81,0,577,17,699,536,712,674,729,728,2745,20,16,21,713,648,137]

theorem envBound35789 : H12AffineFastState.Bounded env35789 := by
  intro p hp
  have h : env35789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35788_35789 : H12AffineEnvironment.transform 7 20 env35788 = env35789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35788 == env35789) = true)

theorem identity35789 : scanCanonicalize (H12AffineFastState.compose env35789 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35789 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env35790 : List Nat := [2,4,8,16,11,64,128,20,512,732,2048,1,24,728,80,9,648,137,85,81,0,577,17,656,536,712,649,729,728,2706,20,16,21,713,648,137]

theorem envBound35790 : H12AffineFastState.Bounded env35790 := by
  intro p hp
  have h : env35790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35789_35790 : H12AffineEnvironment.transform 4 11 env35789 = env35790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35789 == env35790) = true)

theorem identity35790 : scanCanonicalize (H12AffineFastState.compose env35790 (packedSelected [5,8,10,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound35790 : packedSelected [5,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env35791 : List Nat := [2,4,8,16,11,64,128,20,512,732,538,1,24,728,80,9,648,137,85,81,0,577,17,656,536,712,649,729,728,136,20,16,21,713,648,137]

theorem envBound35791 : H12AffineFastState.Bounded env35791 := by
  intro p hp
  have h : env35791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35790_35791 : H12AffineEnvironment.transform 10 538 env35790 = env35791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env35790 == env35791) = true)

theorem identity35791 : scanCanonicalize (H12AffineFastState.compose env35791 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35791 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env35792 : List Nat := [2,4,8,16,11,16,128,20,512,652,538,1,24,648,0,9,648,137,5,1,0,529,17,656,536,664,649,649,648,136,20,16,21,665,648,137]

theorem envBound35792 : H12AffineFastState.Bounded env35792 := by
  intro p hp
  have h : env35792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35791_35792 : H12AffineEnvironment.transform 5 16 env35791 = env35792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35791 == env35792) = true)

theorem identity35792 : scanCanonicalize (H12AffineFastState.compose env35792 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound35792 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35793 : List Nat := [2,4,8,16,11,16,128,20,27,151,1,1,24,147,0,9,147,137,5,1,0,10,17,139,3,131,146,146,147,136,20,16,21,130,147,137]

theorem envBound35793 : H12AffineFastState.Bounded env35793 := by
  intro p hp
  have h : env35793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35792_35793 : H12AffineEnvironment.transform 8 27 env35792 = env35793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env35792 == env35793) = true)

theorem identity35793 : scanCanonicalize (H12AffineFastState.compose env35793 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound35793 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35794 : List Nat := [2,4,8,16,11,16,5,20,27,18,1,1,24,22,0,9,22,12,5,1,0,10,17,14,3,6,23,23,22,13,20,16,21,7,22,12]

theorem envBound35794 : H12AffineFastState.Bounded env35794 := by
  intro p hp
  have h : env35794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35793_35794 : H12AffineEnvironment.transform 6 5 env35793 = env35794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env35793 == env35794) = true)

def env35795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4097,5276,74047,66897,13769,78895,1151,74815,1296,81226,8204,65830,257,1281,1344,5952]

theorem envBound35795 : H12AffineFastState.Bounded env35795 := by
  intro p hp
  have h : env35795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35772_35795 : H12AffineEnvironment.transform 17 65665 env35772 = env35795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35772 == env35795) = true)

theorem identity35795 : scanCanonicalize (H12AffineFastState.compose env35795 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound35795 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9326,0,9455,4416,8541,4097,5276,1361,8511,13769,4161,1151,81,1296,6436,8204,9544,257,1281,1344,5952]

theorem envBound35796 : H12AffineFastState.Bounded env35796 := by
  intro p hp
  have h : env35796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35795_35796 : H12AffineEnvironment.transform 15 9326 env35795 = env35796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env35795 == env35796) = true)

def env35797 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8494,0,8623,4416,8541,4097,4572,17,8511,12425,4161,319,81,80,6436,8204,8200,257,65,0,4608]

theorem envBound35797 : H12AffineFastState.Bounded env35797 := by
  intro p hp
  have h : env35797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35796_35797 : H12AffineEnvironment.transform 9 320 env35796 = env35797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35796 == env35797) = true)

theorem identity35797 : scanCanonicalize (H12AffineFastState.compose env35797 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound35797 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35798 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,80,4421,4407,0,4534,4416,4420,4097,4572,17,4390,144,4161,319,81,80,6436,4117,4113,257,65,0,4608]

theorem envBound35798 : H12AffineFastState.Bounded env35798 := by
  intro p hp
  have h : env35798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35797_35798 : H12AffineEnvironment.transform 12 4121 env35797 = env35798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env35797 == env35798) = true)

theorem identity35798 : scanCanonicalize (H12AffineFastState.compose env35798 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound35798 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env35799 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,649,656,80,972,958,0,831,969,973,648,853,17,943,144,712,319,81,80,2989,668,664,257,65,0,137]

theorem envBound35799 : H12AffineFastState.Bounded env35799 := by
  intro p hp
  have h : env35799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35798_35799 : H12AffineEnvironment.transform 11 649 env35798 = env35799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env35798 == env35799) = true)

theorem identity35799 : scanCanonicalize (H12AffineFastState.compose env35799 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound35799 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env35800 : List Nat := [2,4,8,16,32,64,128,256,412,320,2048,277,268,80,80,34,0,163,85,81,276,201,17,51,144,340,319,81,80,2097,256,260,257,65,0,137]

theorem envBound35800 : H12AffineFastState.Bounded env35800 := by
  intro p hp
  have h : env35800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35799_35800 : H12AffineEnvironment.transform 8 412 env35799 = env35800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env35799 == env35800) = true)

theorem identity35800 : scanCanonicalize (H12AffineFastState.compose env35800 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound35800 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env35801 : List Nat := [2,4,8,16,32,33,128,256,412,289,2048,277,268,49,49,34,0,163,52,48,276,168,17,51,144,309,319,48,49,2097,256,260,257,32,0,137]

theorem envBound35801 : H12AffineFastState.Bounded env35801 := by
  intro p hp
  have h : env35801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35800_35801 : H12AffineEnvironment.transform 5 33 env35800 = env35801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env35800 == env35801) = true)

theorem identity35801 : scanCanonicalize (H12AffineFastState.compose env35801 (packedSelected [0,2,5,7,8,10,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35801 : packedSelected [0,2,5,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env35802 : List Nat := [2,4,8,16,32,33,128,21,137,52,2048,0,25,49,49,34,0,163,52,48,1,168,17,51,144,32,42,48,49,2097,21,17,20,32,0,137]

theorem envBound35802 : H12AffineFastState.Bounded env35802 := by
  intro p hp
  have h : env35802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35801_35802 : H12AffineEnvironment.transform 7 21 env35801 = env35802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35801 == env35802) = true)

theorem identity35802 : scanCanonicalize (H12AffineFastState.compose env35802 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound35802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35803 : List Nat := [2,4,8,16,32,33,128,21,137,52,184,0,25,49,49,34,0,163,52,48,1,168,17,51,144,32,42,48,49,137,21,17,20,32,0,137]

theorem envBound35803 : H12AffineFastState.Bounded env35803 := by
  intro p hp
  have h : env35803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35802_35803 : H12AffineEnvironment.transform 10 184 env35802 = env35803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env35802 == env35803) = true)

theorem identity35803 : scanCanonicalize (H12AffineFastState.compose env35803 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35803 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35804 : List Nat := [2,4,8,16,32,33,8,21,1,52,48,0,25,49,49,34,0,43,52,48,1,32,17,51,24,32,42,48,49,1,21,17,20,32,0,1]

theorem envBound35804 : H12AffineFastState.Bounded env35804 := by
  intro p hp
  have h : env35804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35803_35804 : H12AffineEnvironment.transform 6 8 env35803 = env35804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35803 == env35804) = true)

theorem identity35804 : scanCanonicalize (H12AffineFastState.compose env35804 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35804 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35805 : List Nat := [2,4,8,10,32,33,8,15,1,46,42,0,3,43,43,34,0,43,46,42,1,32,11,41,2,32,42,42,43,1,15,11,14,32,0,1]

theorem envBound35805 : H12AffineFastState.Bounded env35805 := by
  intro p hp
  have h : env35805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35804_35805 : H12AffineEnvironment.transform 3 10 env35804 = env35805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35804 == env35805) = true)

def env35806 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8495,0,8622,4416,8541,4097,4573,16,8511,12424,4161,318,81,81,6436,8204,8201,257,64,1,4609]

theorem envBound35806 : H12AffineFastState.Bounded env35806 := by
  intro p hp
  have h : env35806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35796_35806 : H12AffineEnvironment.transform 9 321 env35796 = env35806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35796 == env35806) = true)

theorem identity35806 : scanCanonicalize (H12AffineFastState.compose env35806 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound35806 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35807 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,81,8540,8495,0,8622,5,8541,324,152,16,8511,8653,260,318,81,81,2145,8204,8201,257,64,1,836]

theorem envBound35807 : H12AffineFastState.Bounded env35807 := by
  intro p hp
  have h : env35807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35806_35807 : H12AffineEnvironment.transform 11 325 env35806 = env35807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env35806 == env35807) = true)

theorem identity35807 : scanCanonicalize (H12AffineFastState.compose env35807 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35807 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35808 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,81,8216,8299,0,8426,5,8217,0,152,16,8315,8329,64,122,81,81,2145,8204,8201,69,64,1,512]

theorem envBound35808 : H12AffineFastState.Bounded env35808 := by
  intro p hp
  have h : env35808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35807_35808 : H12AffineEnvironment.transform 7 68 env35807 = env35808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35807 == env35808) = true)

theorem identity35808 : scanCanonicalize (H12AffineFastState.compose env35808 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound35808 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35809 : List Nat := [2,4,8,16,32,64,105,68,512,5,2048,1,8192,81,8216,8299,0,8195,5,8217,0,113,16,8315,8288,64,122,81,81,2145,8204,8201,69,64,1,512]

theorem envBound35809 : H12AffineFastState.Bounded env35809 := by
  intro p hp
  have h : env35809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35808_35809 : H12AffineEnvironment.transform 6 105 env35808 = env35809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env35808 == env35809) = true)

theorem identity35809 : scanCanonicalize (H12AffineFastState.compose env35809 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 2146) := by decide +kernel

theorem selectedBound35809 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env35810 : List Nat := [2,4,8,16,32,64,105,68,512,5,2048,1,2146,81,2170,2057,0,2145,5,2171,0,113,16,2073,2050,64,122,81,81,2145,2158,2155,69,64,1,512]

theorem envBound35810 : H12AffineFastState.Bounded env35810 := by
  intro p hp
  have h : env35810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35809_35810 : H12AffineEnvironment.transform 12 2146 env35809 = env35810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2146 env35809 == env35810) = true)

theorem identity35810 : scanCanonicalize (H12AffineFastState.compose env35810 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound35810 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env35811 : List Nat := [2,4,8,16,32,64,105,68,27,5,2048,1,2146,81,2170,2057,0,2145,5,2171,0,113,16,2073,2050,64,122,81,81,2145,2158,2155,69,64,1,27]

theorem envBound35811 : H12AffineFastState.Bounded env35811 := by
  intro p hp
  have h : env35811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35810_35811 : H12AffineEnvironment.transform 8 27 env35810 = env35811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env35810 == env35811) = true)

theorem identity35811 : scanCanonicalize (H12AffineFastState.compose env35811 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35811 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35812 : List Nat := [2,4,8,16,11,64,66,68,27,5,2048,1,2121,81,2129,2057,0,2122,5,2128,0,90,16,2073,2050,64,81,81,81,2122,2117,2112,69,64,1,27]

theorem envBound35812 : H12AffineFastState.Bounded env35812 := by
  intro p hp
  have h : env35812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35811_35812 : H12AffineEnvironment.transform 4 11 env35811 = env35812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35811 == env35812) = true)

theorem identity35812 : scanCanonicalize (H12AffineFastState.compose env35812 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound35812 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env35813 : List Nat := [2,4,8,16,11,64,66,68,27,5,27,1,82,81,74,18,0,81,5,75,0,90,16,2,25,64,81,81,81,81,94,91,69,64,1,27]

theorem envBound35813 : H12AffineFastState.Bounded env35813 := by
  intro p hp
  have h : env35813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35812_35813 : H12AffineEnvironment.transform 10 27 env35812 = env35813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env35812 == env35813) = true)

theorem identity35813 : scanCanonicalize (H12AffineFastState.compose env35813 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35813 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35814 : List Nat := [2,4,8,16,11,16,18,20,27,5,27,1,2,1,26,18,0,1,5,27,0,10,16,2,25,16,1,1,1,1,14,11,21,16,1,27]

theorem envBound35814 : H12AffineFastState.Bounded env35814 := by
  intro p hp
  have h : env35814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35813_35814 : H12AffineEnvironment.transform 5 16 env35813 = env35814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35813 == env35814) = true)

theorem identity35814 : scanCanonicalize (H12AffineFastState.compose env35814 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35814 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35815 : List Nat := [2,4,8,10,11,10,8,14,1,5,1,1,2,1,0,8,0,1,5,1,0,10,10,2,3,10,1,1,1,1,14,11,15,10,1,1]

theorem envBound35815 : H12AffineFastState.Bounded env35815 := by
  intro p hp
  have h : env35815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35814_35815 : H12AffineEnvironment.transform 3 10 env35814 = env35815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35814 == env35815) = true)

theorem identity35815 : scanCanonicalize (H12AffineFastState.compose env35815 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35816 : List Nat := [2,3,8,10,11,10,8,9,1,2,1,1,2,1,0,8,0,1,2,1,0,10,10,2,3,10,1,1,1,1,9,11,8,10,1,1]

theorem envBound35816 : H12AffineFastState.Bounded env35816 := by
  intro p hp
  have h : env35816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35815_35816 : H12AffineEnvironment.transform 1 3 env35815 = env35816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35815 == env35816) = true)

def env35817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4097,5276,74046,66897,13768,78895,328958,74814,1296,81227,8205,65831,257,1281,1344,5953]

theorem envBound35817 : H12AffineFastState.Bounded env35817 := by
  intro p hp
  have h : env35817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35771_35817 : H12AffineEnvironment.transform 13 1297 env35771 = env35817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35771 == env35817) = true)

def env35818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4097,5276,74046,66897,13768,78895,1150,74814,1296,81227,8205,65831,257,1281,1344,5953]

theorem envBound35818 : H12AffineFastState.Bounded env35818 := by
  intro p hp
  have h : env35818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35817_35818 : H12AffineEnvironment.transform 17 65664 env35817 = env35818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35817 == env35818) = true)

theorem identity35818 : scanCanonicalize (H12AffineFastState.compose env35818 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound35818 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,359,9481,487,4417,8540,4097,5276,8281,1078,13768,13640,1150,9561,1296,15404,8205,64,257,1281,1344,5953]

theorem envBound35819 : H12AffineFastState.Bounded env35819 := by
  intro p hp
  have h : env35819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35818_35819 : H12AffineEnvironment.transform 15 359 env35818 = env35819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env35818 == env35819) = true)

def env35820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,359,1345,487,4417,276,4097,5276,17,1078,5504,5376,1150,1297,1296,7268,69,64,257,1281,1344,5953]

theorem envBound35820 : H12AffineFastState.Bounded env35820 := by
  intro p hp
  have h : env35820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35819_35820 : H12AffineEnvironment.transform 12 72 env35819 = env35820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env35819 == env35820) = true)

theorem identity35820 : scanCanonicalize (H12AffineFastState.compose env35820 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35820 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35821 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,72,276,277,359,324,487,4417,276,4097,4249,17,51,4485,4357,123,276,277,6241,69,64,257,260,325,4932]

theorem envBound35821 : H12AffineFastState.Bounded env35821 := by
  intro p hp
  have h : env35821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35820_35821 : H12AffineEnvironment.transform 9 5 env35820 = env35821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35820 == env35821) = true)

theorem identity35821 : scanCanonicalize (H12AffineFastState.compose env35821 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound35821 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35822 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,276,277,359,324,487,5,276,325,477,17,51,193,65,123,276,277,2341,69,64,257,260,325,512]

theorem envBound35822 : H12AffineFastState.Bounded env35822 := by
  intro p hp
  have h : env35822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35821_35822 : H12AffineEnvironment.transform 11 324 env35821 = env35822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env35821 == env35822) = true)

theorem identity35822 : scanCanonicalize (H12AffineFastState.compose env35822 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35822 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35823 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,25,276,277,310,277,438,5,276,276,396,17,51,144,16,42,276,277,2341,20,17,257,260,276,512]

theorem envBound35823 : H12AffineFastState.Bounded env35823 := by
  intro p hp
  have h : env35823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35822_35823 : H12AffineEnvironment.transform 5 17 env35822 = env35823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35822 == env35823) = true)

theorem identity35823 : scanCanonicalize (H12AffineFastState.compose env35823 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound35823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35824 : List Nat := [2,4,8,16,32,17,128,256,512,5,805,277,25,276,277,310,277,438,5,276,276,396,17,51,144,16,42,276,277,512,20,17,257,260,276,512]

theorem envBound35824 : H12AffineFastState.Bounded env35824 := by
  intro p hp
  have h : env35824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35823_35824 : H12AffineEnvironment.transform 10 805 env35823 = env35824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env35823 == env35824) = true)

theorem identity35824 : scanCanonicalize (H12AffineFastState.compose env35824 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35824 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35825 : List Nat := [2,4,8,16,10,17,128,256,512,5,783,277,25,276,277,284,277,412,5,276,276,396,17,25,144,16,0,276,277,512,20,17,257,260,276,512]

end H12CloudChart2