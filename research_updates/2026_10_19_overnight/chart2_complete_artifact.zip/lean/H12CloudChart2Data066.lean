import H12CloudChart2Data065

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env16172 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,32768,65536,1044,262144,1025,32769,1045,362634,16,98305,8328,16,100491,1044,1045,360587,1025,41120,4,305281,1044,137]

theorem envBound16172 : H12AffineFastState.Bounded env16172 := by
  intro p hp
  have h : env16172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16171_16172 : H12AffineEnvironment.transform 29 360587 env16171 = env16172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 360587 env16171 == env16172) = true)

theorem identity16172 : scanCanonicalize (H12AffineFastState.compose env16172 (packedSelected [1,3] rootPS)) = affineNative (2^(17+1) ^^^ 100491) := by decide +kernel

theorem selectedBound16172 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16173 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,32768,65536,1044,100491,1025,32769,1045,1,16,98305,8328,16,100491,1044,1045,2048,1025,41120,4,73738,1044,137]

theorem envBound16173 : H12AffineFastState.Bounded env16173 := by
  intro p hp
  have h : env16173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16172_16173 : H12AffineEnvironment.transform 17 100491 env16172 = env16173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100491 env16172 == env16173) = true)

theorem identity16173 : scanCanonicalize (H12AffineFastState.compose env16173 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound16173 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16174 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,2081,65536,1044,65706,1025,2080,1045,1,16,67616,8328,16,65706,1044,1045,2048,1025,10369,4,73738,1044,137]

theorem envBound16174 : H12AffineFastState.Bounded env16174 := by
  intro p hp
  have h : env16174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16173_16174 : H12AffineEnvironment.transform 14 2081 env16173 = env16174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env16173 == env16174) = true)

theorem identity16174 : scanCanonicalize (H12AffineFastState.compose env16174 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound16174 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16175 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,2081,8355,1044,8201,1025,2080,1045,1,16,10371,8328,16,8201,1044,1045,2048,1025,10369,4,169,1044,137]

theorem envBound16175 : H12AffineFastState.Bounded env16175 := by
  intro p hp
  have h : env16175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16174_16175 : H12AffineEnvironment.transform 15 8355 env16174 = env16175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env16174 == env16175) = true)

def env16176 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2056,1045,2081,2219,1044,2049,1025,2080,1045,1,16,139,2176,16,2049,1044,1045,2048,1025,137,4,169,1044,137]

theorem envBound16176 : H12AffineFastState.Bounded env16176 := by
  intro p hp
  have h : env16176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16175_16176 : H12AffineEnvironment.transform 12 2056 env16175 = env16176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16175 == env16176) = true)

theorem identity16176 : scanCanonicalize (H12AffineFastState.compose env16176 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound16176 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16177 : List Nat := [2,4,8,16,32,17,128,5,137,1024,169,1045,161,1045,136,2,1044,168,1025,137,1045,1,16,139,41,16,168,1044,1045,169,1025,137,4,169,1044,137]

theorem envBound16177 : H12AffineFastState.Bounded env16177 := by
  intro p hp
  have h : env16177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16176_16177 : H12AffineEnvironment.transform 10 169 env16176 = env16177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env16176 == env16177) = true)

theorem identity16177 : scanCanonicalize (H12AffineFastState.compose env16177 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16177 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16178 : List Nat := [2,4,8,16,32,17,128,5,137,52,169,33,161,33,136,2,32,168,53,137,33,1,16,139,41,16,168,32,33,169,53,137,4,169,32,137]

theorem envBound16178 : H12AffineFastState.Bounded env16178 := by
  intro p hp
  have h : env16178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16177_16178 : H12AffineEnvironment.transform 9 52 env16177 = env16178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16177 == env16178) = true)

def env16179 : List Nat := [2,4,8,16,0,17,128,5,137,20,137,1,129,1,136,2,0,136,21,137,1,1,16,139,9,16,136,0,1,137,21,137,4,137,0,137]

theorem envBound16179 : H12AffineFastState.Bounded env16179 := by
  intro p hp
  have h : env16179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16178_16179 : H12AffineEnvironment.transform 4 0 env16178 = env16179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16178 == env16179) = true)

theorem identity16179 : scanCanonicalize (H12AffineFastState.compose env16179 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16180 : List Nat := [2,4,8,1,0,0,128,5,137,5,137,1,129,1,136,2,0,136,4,137,1,1,1,139,9,1,136,0,1,137,4,137,4,137,0,137]

theorem envBound16180 : H12AffineFastState.Bounded env16180 := by
  intro p hp
  have h : env16180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16179_16180 : H12AffineEnvironment.transform 3 1 env16179 = env16180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16179 == env16180) = true)

def leafEnv16180 : List Nat := [2,4,8,1,0,0,128,5,137,5,137,1,129,1,136,2,0,136,4,137,1,1,1,139,4,9,1,1,136,0,1,137,4,137,4,137,4,139,0,137,0,0,1]

def active16180 : List Nat := [0,1,2,6]

def tree16180 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16180 : H12WitnessSearch.Good tree16180 := H12GlobalWitnessIndex.good

theorem leafIdentity16180 : H12AffineFastState.composeSystem env16180 rootObs = leafEnv16180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16180 rootObs == leafEnv16180) = true)

theorem terminalChecked16180 : H12PackedTerminal.terminalCheckFast leafEnv16180 active16180 tree16180 = true := by decide +kernel

def env16181 : List Nat := [2,4,8,16,1,17,128,5,137,21,136,0,128,0,136,2,1,137,20,137,0,1,16,139,8,16,137,1,0,136,20,137,4,136,1,137]

theorem envBound16181 : H12AffineFastState.Bounded env16181 := by
  intro p hp
  have h : env16181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16178_16181 : H12AffineEnvironment.transform 4 1 env16178 = env16181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16178 == env16181) = true)

theorem identity16181 : scanCanonicalize (H12AffineFastState.compose env16181 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16182 : List Nat := [2,4,8,16,1,17,25,5,16,21,17,0,25,0,17,2,1,16,20,16,0,1,16,18,8,16,16,1,0,17,20,16,4,17,1,16]

theorem envBound16182 : H12AffineFastState.Bounded env16182 := by
  intro p hp
  have h : env16182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16181_16182 : H12AffineEnvironment.transform 6 25 env16181 = env16182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16181 == env16182) = true)

def leafEnv16182 : List Nat := [2,4,8,16,1,17,25,5,16,21,17,0,25,0,17,2,1,16,20,16,0,1,16,18,20,8,1,16,16,1,0,17,20,16,4,17,4,18,1,16,0,1,1]

def active16182 : List Nat := [0,1,2,3]

def tree16182 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16182 : H12WitnessSearch.Good tree16182 := H12GlobalWitnessIndex.good

theorem leafIdentity16182 : H12AffineFastState.composeSystem env16182 rootObs = leafEnv16182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16182 rootObs == leafEnv16182) = true)

theorem terminalChecked16182 : H12PackedTerminal.terminalCheckFast leafEnv16182 active16182 tree16182 = true := by decide +kernel

def env16183 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2057,1045,2081,2218,1044,2048,1025,2080,1045,1,16,138,2177,16,2048,1044,1045,2048,1025,136,4,169,1044,137]

theorem envBound16183 : H12AffineFastState.Bounded env16183 := by
  intro p hp
  have h : env16183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16175_16183 : H12AffineEnvironment.transform 12 2057 env16175 = env16183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env16175 == env16183) = true)

theorem identity16183 : scanCanonicalize (H12AffineFastState.compose env16183 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound16183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16184 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1212,1045,1205,1045,1181,1046,1044,1212,1025,1180,1045,1,16,138,1085,16,1212,1044,1045,1212,1025,136,4,169,1044,137]

theorem envBound16184 : H12AffineFastState.Bounded env16184 := by
  intro p hp
  have h : env16184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16183_16184 : H12AffineEnvironment.transform 10 1212 env16183 = env16184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env16183 == env16184) = true)

def env16185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1344,262144,1025,32769,4096,4194304,5377,98644,8328,5456,4456788,4096,1344,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound16185 : H12AffineFastState.Bounded env16185 := by
  intro p hp
  have h : env16185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16123_16185 : H12AffineEnvironment.transform 13 4097 env16123 = env16185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env16123 == env16185) = true)

theorem identity16185 : scanCanonicalize (H12AffineFastState.compose env16185 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16185 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98564,8328,5376,4456708,4096,1296,1073741824,1284,4294967296,257,4299260334,1296,512]

theorem envBound16186 : H12AffineFastState.Bounded env16186 := by
  intro p hp
  have h : env16186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16185_16186 : H12AffineEnvironment.transform 5 16 env16185 = env16186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16185 == env16186) = true)

theorem identity16186 : scanCanonicalize (H12AffineFastState.compose env16186 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound16186 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98564,8328,5376,4456708,4096,1296,1073741824,1284,73770,257,4235652,1296,512]

theorem envBound16187 : H12AffineFastState.Bounded env16187 := by
  intro p hp
  have h : env16187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16186_16187 : H12AffineEnvironment.transform 31 73770 env16186 = env16187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env16186 == env16187) = true)

theorem identity16187 : scanCanonicalize (H12AffineFastState.compose env16187 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16187 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env16188 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98564,8328,5376,4456708,4096,1296,1073741824,1284,73770,257,4235652,1296,137]

theorem envBound16188 : H12AffineFastState.Bounded env16188 := by
  intro p hp
  have h : env16188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16187_16188 : H12AffineEnvironment.transform 8 137 env16187 = env16188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16187 == env16188) = true)

theorem identity16188 : scanCanonicalize (H12AffineFastState.compose env16188 (packedSelected [1,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16188 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16189 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,4096,8192,4097,32768,65536,1045,262144,1025,32769,4096,4194304,5124,98305,8328,5125,4456449,4096,1045,1073741824,1025,73770,4,4235393,1045,137]

theorem envBound16189 : H12AffineFastState.Bounded env16189 := by
  intro p hp
  have h : env16189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16188_16189 : H12AffineEnvironment.transform 7 5 env16188 = env16189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16188 == env16189) = true)

def env16190 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,8192,1045,32768,65536,1045,262144,1025,32769,1044,4194304,16,98305,8328,17,4456449,1044,1045,1073741824,1025,73770,4,4235393,1045,137]

theorem envBound16190 : H12AffineFastState.Bounded env16190 := by
  intro p hp
  have h : env16190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16189_16190 : H12AffineEnvironment.transform 11 1044 env16189 = env16190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16189 == env16190) = true)

theorem identity16190 : scanCanonicalize (H12AffineFastState.compose env16190 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound16190 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16191 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,8192,1045,32768,65536,1045,262144,1025,32769,1044,4194304,16,98305,8328,17,4456449,1044,1045,43049,1025,73770,4,4235393,1045,137]

theorem envBound16191 : H12AffineFastState.Bounded env16191 := by
  intro p hp
  have h : env16191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16190_16191 : H12AffineEnvironment.transform 29 43049 env16190 = env16191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env16190 == env16191) = true)

def env16192 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8192,1,32768,65536,1,262144,21,32769,0,4194304,16,98305,8328,17,4456449,0,1,43049,21,73770,4,4235393,1,137]

theorem envBound16192 : H12AffineFastState.Bounded env16192 := by
  intro p hp
  have h : env16192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16191_16192 : H12AffineEnvironment.transform 9 20 env16191 = env16192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16191 == env16192) = true)

theorem identity16192 : scanCanonicalize (H12AffineFastState.compose env16192 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 296960) := by decide +kernel

theorem selectedBound16192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16193 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8192,1,32768,65536,1,262144,21,32769,0,296960,16,98305,8328,17,34817,0,1,43049,21,73770,4,272513,1,137]

theorem envBound16193 : H12AffineFastState.Bounded env16193 := by
  intro p hp
  have h : env16193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16192_16193 : H12AffineEnvironment.transform 21 296960 env16192 = env16193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 296960 env16192 == env16193) = true)

theorem identity16193 : scanCanonicalize (H12AffineFastState.compose env16193 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound16193 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16194 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8192,1,32768,65536,1,43048,21,32769,0,8232,16,98305,8328,17,34817,0,1,43049,21,73770,4,32937,1,137]

theorem envBound16194 : H12AffineFastState.Bounded env16194 := by
  intro p hp
  have h : env16194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16193_16194 : H12AffineEnvironment.transform 17 43048 env16193 = env16194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env16193 == env16194) = true)

theorem identity16194 : scanCanonicalize (H12AffineFastState.compose env16194 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound16194 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16195 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8192,1,0,65536,1,10280,21,1,0,8232,16,65537,8328,17,2049,0,1,10281,21,73770,4,169,1,137]

theorem envBound16195 : H12AffineFastState.Bounded env16195 := by
  intro p hp
  have h : env16195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16194_16195 : H12AffineEnvironment.transform 14 0 env16194 = env16195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env16194 == env16195) = true)

def env16196 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,8,1,0,65536,1,2080,21,1,0,32,16,65537,128,17,2049,0,1,2081,21,65570,4,169,1,137]

theorem envBound16196 : H12AffineFastState.Bounded env16196 := by
  intro p hp
  have h : env16196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16195_16196 : H12AffineEnvironment.transform 12 8 env16195 = env16196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16195 == env16196) = true)

theorem identity16196 : scanCanonicalize (H12AffineFastState.compose env16196 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound16196 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16197 : List Nat := [2,4,8,16,32,16,57,5,48,20,2048,0,8,1,0,65536,1,2080,21,1,0,32,16,65537,57,17,2049,0,1,2081,21,65570,4,16,1,48]

theorem envBound16197 : H12AffineFastState.Bounded env16197 := by
  intro p hp
  have h : env16197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16196_16197 : H12AffineEnvironment.transform 6 57 env16196 = env16197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env16196 == env16197) = true)

theorem identity16197 : scanCanonicalize (H12AffineFastState.compose env16197 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound16197 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16198 : List Nat := [2,4,8,16,32,16,57,5,48,20,2048,0,8,1,0,51,1,2080,21,1,0,32,16,50,57,17,2049,0,1,2081,21,17,4,16,1,48]

theorem envBound16198 : H12AffineFastState.Bounded env16198 := by
  intro p hp
  have h : env16198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16197_16198 : H12AffineEnvironment.transform 15 51 env16197 = env16198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env16197 == env16198) = true)

def env16199 : List Nat := [2,4,8,16,32,16,57,5,48,20,0,0,8,1,0,51,1,32,21,1,0,32,16,50,57,17,1,0,1,33,21,17,4,16,1,48]

theorem envBound16199 : H12AffineFastState.Bounded env16199 := by
  intro p hp
  have h : env16199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16198_16199 : H12AffineEnvironment.transform 10 0 env16198 = env16199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16198 == env16199) = true)

theorem identity16199 : scanCanonicalize (H12AffineFastState.compose env16199 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16199 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16200 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,0,8,1,0,18,1,1,21,1,0,1,16,19,24,17,1,0,1,0,21,17,4,16,1,17]

theorem envBound16200 : H12AffineFastState.Bounded env16200 := by
  intro p hp
  have h : env16200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16199_16200 : H12AffineEnvironment.transform 4 1 env16199 = env16200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16199 == env16200) = true)

def leafEnv16200 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,0,8,1,0,18,1,1,21,1,0,1,16,19,21,24,1,17,1,0,1,0,21,17,4,16,4,3,1,17,0,0,1]

def active16200 : List Nat := [0,1,2,3]

def tree16200 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16200 : H12WitnessSearch.Good tree16200 := H12GlobalWitnessIndex.good

theorem leafIdentity16200 : H12AffineFastState.composeSystem env16200 rootObs = leafEnv16200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16200 rootObs == leafEnv16200) = true)

theorem terminalChecked16200 : H12PackedTerminal.terminalCheckFast leafEnv16200 active16200 tree16200 = true := by decide +kernel

def env16201 : List Nat := [2,4,8,16,32,16,57,5,48,20,1,0,8,1,0,51,1,33,21,1,0,32,16,50,57,17,0,0,1,32,21,17,4,16,1,48]

theorem envBound16201 : H12AffineFastState.Bounded env16201 := by
  intro p hp
  have h : env16201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16198_16201 : H12AffineEnvironment.transform 10 1 env16198 = env16201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16198 == env16201) = true)

def env16202 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,9,1,0,65536,1,2081,21,1,0,33,16,65537,129,17,2049,0,1,2080,21,65571,4,169,1,137]

theorem envBound16202 : H12AffineFastState.Bounded env16202 := by
  intro p hp
  have h : env16202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16195_16202 : H12AffineEnvironment.transform 12 9 env16195 = env16202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16195 == env16202) = true)

theorem identity16202 : scanCanonicalize (H12AffineFastState.compose env16202 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound16202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16203 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,9,1,0,154,1,2081,21,1,0,33,16,155,129,17,2049,0,1,2080,21,185,4,169,1,137]

theorem envBound16203 : H12AffineFastState.Bounded env16203 := by
  intro p hp
  have h : env16203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16202_16203 : H12AffineEnvironment.transform 15 154 env16202 = env16203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env16202 == env16203) = true)

def env16204 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,8192,0,32768,65536,0,262144,20,32769,1,4194304,16,98305,8328,17,4456449,1,0,43049,20,73770,4,4235393,0,137]

theorem envBound16204 : H12AffineFastState.Bounded env16204 := by
  intro p hp
  have h : env16204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16191_16204 : H12AffineEnvironment.transform 9 21 env16191 = env16204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16191 == env16204) = true)

theorem identity16204 : scanCanonicalize (H12AffineFastState.compose env16204 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound16204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16205 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,8192,0,32768,138,0,262144,20,32769,1,4194304,16,32907,8328,17,4456449,1,0,43049,20,8352,4,4235393,0,137]

theorem envBound16205 : H12AffineFastState.Bounded env16205 := by
  intro p hp
  have h : env16205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16204_16205 : H12AffineEnvironment.transform 15 138 env16204 = env16205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env16204 == env16205) = true)

theorem identity16205 : scanCanonicalize (H12AffineFastState.compose env16205 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 264192) := by decide +kernel

theorem selectedBound16205 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16206 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,8192,0,32768,138,0,262144,20,32769,1,264192,16,32907,8328,17,2049,1,0,43049,20,8352,4,305281,0,137]

theorem envBound16206 : H12AffineFastState.Bounded env16206 := by
  intro p hp
  have h : env16206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16205_16206 : H12AffineEnvironment.transform 21 264192 env16205 = env16206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264192 env16205 == env16206) = true)

theorem identity16206 : scanCanonicalize (H12AffineFastState.compose env16206 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound16206 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16207 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,8192,0,32768,138,0,43048,20,32769,1,41000,16,32907,8328,17,2049,1,0,43049,20,8352,4,169,0,137]

theorem envBound16207 : H12AffineFastState.Bounded env16207 := by
  intro p hp
  have h : env16207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16206_16207 : H12AffineEnvironment.transform 17 43048 env16206 = env16207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env16206 == env16207) = true)

def env16208 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,160,0,32768,138,0,34952,20,32769,1,32904,16,32907,40,17,2049,1,0,34953,20,0,4,169,0,137]

theorem envBound16208 : H12AffineFastState.Bounded env16208 := by
  intro p hp
  have h : env16208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16207_16208 : H12AffineEnvironment.transform 12 160 env16207 = env16208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env16207 == env16208) = true)

theorem identity16208 : scanCanonicalize (H12AffineFastState.compose env16208 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound16208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16209 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,0,32768,51,0,34865,20,32769,1,32817,16,32818,40,17,2049,1,0,34864,20,0,4,16,0,48]

theorem envBound16209 : H12AffineFastState.Bounded env16209 := by
  intro p hp
  have h : env16209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16208_16209 : H12AffineEnvironment.transform 6 57 env16208 = env16209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env16208 == env16209) = true)

def env16210 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,0,2080,51,0,17,20,2081,1,2065,16,2066,40,17,2049,1,0,16,20,0,4,16,0,48]

theorem envBound16210 : H12AffineFastState.Bounded env16210 := by
  intro p hp
  have h : env16210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16209_16210 : H12AffineEnvironment.transform 14 2080 env16209 = env16210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env16209 == env16210) = true)

def env16211 : List Nat := [2,4,8,16,32,16,57,5,48,21,2048,1,25,0,2081,51,0,16,20,2080,1,2064,16,2067,40,17,2049,1,0,17,20,0,4,16,0,48]

theorem envBound16211 : H12AffineFastState.Bounded env16211 := by
  intro p hp
  have h : env16211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16209_16211 : H12AffineEnvironment.transform 14 2081 env16209 = env16211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env16209 == env16211) = true)

theorem identity16211 : scanCanonicalize (H12AffineFastState.compose env16211 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound16211 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16212 : List Nat := [2,4,8,16,32,16,57,5,48,21,17,1,25,0,48,51,0,16,20,49,1,1,16,2,40,17,16,1,0,17,20,0,4,16,0,48]

theorem envBound16212 : H12AffineFastState.Bounded env16212 := by
  intro p hp
  have h : env16212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16211_16212 : H12AffineEnvironment.transform 10 17 env16211 = env16212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env16211 == env16212) = true)

def env16213 : List Nat := [2,4,8,16,0,16,25,5,16,21,17,1,25,0,16,19,0,16,20,17,1,1,16,2,8,17,16,1,0,17,20,0,4,16,0,16]

theorem envBound16213 : H12AffineFastState.Bounded env16213 := by
  intro p hp
  have h : env16213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16212_16213 : H12AffineEnvironment.transform 4 0 env16212 = env16213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16212 == env16213) = true)

theorem identity16213 : scanCanonicalize (H12AffineFastState.compose env16213 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16214 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,1,9,0,0,3,0,0,4,1,1,1,0,2,8,1,0,1,0,1,4,0,4,0,0,0]

theorem envBound16214 : H12AffineFastState.Bounded env16214 := by
  intro p hp
  have h : env16214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16213_16214 : H12AffineEnvironment.transform 3 0 env16213 = env16214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16213 == env16214) = true)

def leafEnv16214 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,1,9,0,0,3,0,0,4,1,1,1,0,2,4,8,1,1,0,1,0,1,4,0,4,0,4,3,0,0,0,1,1]

def active16214 : List Nat := [0,1,2]

def tree16214 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16214 : H12WitnessSearch.Good tree16214 := H12GlobalWitnessIndex.good

theorem leafIdentity16214 : H12AffineFastState.composeSystem env16214 rootObs = leafEnv16214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16214 rootObs == leafEnv16214) = true)

theorem terminalChecked16214 : H12PackedTerminal.terminalCheckFast leafEnv16214 active16214 tree16214 = true := by decide +kernel

def env16215 : List Nat := [2,4,8,16,1,16,24,5,17,21,17,1,25,0,17,18,0,16,20,16,1,1,16,2,9,17,16,1,0,17,20,0,4,16,0,17]

theorem envBound16215 : H12AffineFastState.Bounded env16215 := by
  intro p hp
  have h : env16215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16212_16215 : H12AffineEnvironment.transform 4 1 env16212 = env16215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16212 == env16215) = true)

def env16216 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,161,0,32768,138,0,34953,20,32769,1,32905,16,32907,41,17,2049,1,0,34952,20,1,4,169,0,137]

theorem envBound16216 : H12AffineFastState.Bounded env16216 := by
  intro p hp
  have h : env16216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16207_16216 : H12AffineEnvironment.transform 12 161 env16207 = env16216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env16207 == env16216) = true)

theorem identity16216 : scanCanonicalize (H12AffineFastState.compose env16216 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 16) := by decide +kernel

theorem selectedBound16216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16217 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,161,0,16,138,0,2201,20,17,1,153,16,155,41,17,2049,1,0,2200,20,1,4,169,0,137]

theorem envBound16217 : H12AffineFastState.Bounded env16217 := by
  intro p hp
  have h : env16217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16216_16217 : H12AffineEnvironment.transform 14 16 env16216 = env16217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16 env16216 == env16217) = true)

def env16218 : List Nat := [2,4,8,16,32,16,128,5,137,21,48,1,161,0,16,138,0,169,20,17,1,153,16,155,41,17,49,1,0,168,20,1,4,169,0,137]

theorem envBound16218 : H12AffineFastState.Bounded env16218 := by
  intro p hp
  have h : env16218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16217_16218 : H12AffineEnvironment.transform 10 48 env16217 = env16218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env16217 == env16218) = true)

def env16219 : List Nat := [2,4,8,16,32,16,128,5,137,21,49,1,161,0,16,138,0,168,20,17,1,153,16,155,41,17,48,1,0,169,20,1,4,169,0,137]

theorem envBound16219 : H12AffineFastState.Bounded env16219 := by
  intro p hp
  have h : env16219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16217_16219 : H12AffineEnvironment.transform 10 49 env16217 = env16219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env16217 == env16219) = true)

theorem identity16219 : scanCanonicalize (H12AffineFastState.compose env16219 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound16219 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16220 : List Nat := [2,4,8,16,32,16,24,5,17,21,49,1,57,0,16,18,0,48,20,17,1,1,16,3,41,17,48,1,0,49,20,1,4,49,0,17]

theorem envBound16220 : H12AffineFastState.Bounded env16220 := by
  intro p hp
  have h : env16220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16219_16220 : H12AffineEnvironment.transform 6 24 env16219 = env16220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env16219 == env16220) = true)

def env16221 : List Nat := [2,4,8,16,0,16,24,5,17,21,17,1,25,0,16,18,0,16,20,17,1,1,16,3,9,17,16,1,0,17,20,1,4,17,0,17]

theorem envBound16221 : H12AffineFastState.Bounded env16221 := by
  intro p hp
  have h : env16221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16220_16221 : H12AffineEnvironment.transform 4 0 env16220 = env16221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16220 == env16221) = true)

theorem identity16221 : scanCanonicalize (H12AffineFastState.compose env16221 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16222 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,1,9,0,0,2,0,0,4,1,1,1,0,3,9,1,0,1,0,1,4,1,4,1,0,1]

theorem envBound16222 : H12AffineFastState.Bounded env16222 := by
  intro p hp
  have h : env16222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16221_16222 : H12AffineEnvironment.transform 3 0 env16221 = env16222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16221 == env16222) = true)

def leafEnv16222 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,1,9,0,0,2,0,0,4,1,1,1,0,3,4,9,1,1,0,1,0,1,4,1,4,1,4,3,0,1,0,1,1]

def active16222 : List Nat := [0,1,2]

def tree16222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16222 : H12WitnessSearch.Good tree16222 := H12GlobalWitnessIndex.good

theorem leafIdentity16222 : H12AffineFastState.composeSystem env16222 rootObs = leafEnv16222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16222 rootObs == leafEnv16222) = true)

theorem terminalChecked16222 : H12PackedTerminal.terminalCheckFast leafEnv16222 active16222 tree16222 = true := by decide +kernel

def env16223 : List Nat := [2,4,8,16,1,16,24,5,17,21,16,1,24,0,16,18,0,17,20,17,1,1,16,3,8,17,17,1,0,16,20,1,4,16,0,17]

theorem envBound16223 : H12AffineFastState.Bounded env16223 := by
  intro p hp
  have h : env16223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16220_16223 : H12AffineEnvironment.transform 4 1 env16220 = env16223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16220 == env16223) = true)

def env16224 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,65536,1045,262144,1025,32769,1045,4194304,17,98305,8328,16,4456449,1045,1045,1073741824,1025,73770,4,4235393,1045,137]

theorem envBound16224 : H12AffineFastState.Bounded env16224 := by
  intro p hp
  have h : env16224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16189_16224 : H12AffineEnvironment.transform 11 1045 env16189 = env16224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env16189 == env16224) = true)

theorem identity16224 : scanCanonicalize (H12AffineFastState.compose env16224 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound16224 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16225 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,65536,1045,262144,1025,32769,1045,362634,17,98305,8328,16,100491,1045,1045,1073741824,1025,73770,4,337931,1045,137]

theorem envBound16225 : H12AffineFastState.Bounded env16225 := by
  intro p hp
  have h : env16225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16224_16225 : H12AffineEnvironment.transform 21 362634 env16224 = env16225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env16224 == env16225) = true)

theorem identity16225 : scanCanonicalize (H12AffineFastState.compose env16225 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 360587) := by decide +kernel

theorem selectedBound16225 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env16226 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,65536,1045,262144,1025,32769,1045,362634,17,98305,8328,16,100491,1045,1045,360587,1025,73770,4,337931,1045,137]

theorem envBound16226 : H12AffineFastState.Bounded env16226 := by
  intro p hp
  have h : env16226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16225_16226 : H12AffineEnvironment.transform 29 360587 env16225 = env16226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 360587 env16225 == env16226) = true)

theorem identity16226 : scanCanonicalize (H12AffineFastState.compose env16226 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound16226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16227 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,8355,1045,262144,1025,32769,1045,305193,17,41122,8328,16,43048,1045,1045,303144,1025,137,4,264360,1045,137]

theorem envBound16227 : H12AffineFastState.Bounded env16227 := by
  intro p hp
  have h : env16227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16226_16227 : H12AffineEnvironment.transform 15 8355 env16226 = env16227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env16226 == env16227) = true)

theorem identity16227 : scanCanonicalize (H12AffineFastState.compose env16227 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound16227 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16228 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,8355,1045,43048,1025,32769,1045,1,17,41122,8328,16,43048,1045,1045,2048,1025,137,4,41088,1045,137]

theorem envBound16228 : H12AffineFastState.Bounded env16228 := by
  intro p hp
  have h : env16228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16227_16228 : H12AffineEnvironment.transform 17 43048 env16227 = env16228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env16227 == env16228) = true)

theorem identity16228 : scanCanonicalize (H12AffineFastState.compose env16228 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound16228 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16229 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,2081,8355,1045,8201,1025,2080,1045,1,17,10371,8328,16,8201,1045,1045,2048,1025,137,4,10401,1045,137]

theorem envBound16229 : H12AffineFastState.Bounded env16229 := by
  intro p hp
  have h : env16229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16228_16229 : H12AffineEnvironment.transform 14 2081 env16228 = env16229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env16228 == env16229) = true)

def env16230 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,2056,1044,2081,2219,1045,2049,1025,2080,1045,1,17,139,2176,16,2049,1045,1045,2048,1025,137,4,169,1045,137]

theorem envBound16230 : H12AffineFastState.Bounded env16230 := by
  intro p hp
  have h : env16230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16229_16230 : H12AffineEnvironment.transform 12 2056 env16229 = env16230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16229 == env16230) = true)

theorem identity16230 : scanCanonicalize (H12AffineFastState.compose env16230 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound16230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16231 : List Nat := [2,4,8,16,32,16,128,5,137,1024,137,1045,129,1044,168,34,1045,136,1025,169,1045,1,17,139,9,16,136,1045,1045,137,1025,137,4,169,1045,137]

theorem envBound16231 : H12AffineFastState.Bounded env16231 := by
  intro p hp
  have h : env16231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16230_16231 : H12AffineEnvironment.transform 10 137 env16230 = env16231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env16230 == env16231) = true)

theorem identity16231 : scanCanonicalize (H12AffineFastState.compose env16231 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16231 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16232 : List Nat := [2,4,8,16,32,16,128,5,137,52,137,33,129,32,168,34,33,136,53,169,33,1,17,139,9,16,136,33,33,137,53,137,4,169,33,137]

theorem envBound16232 : H12AffineFastState.Bounded env16232 := by
  intro p hp
  have h : env16232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16231_16232 : H12AffineEnvironment.transform 9 52 env16231 = env16232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16231 == env16232) = true)

def env16233 : List Nat := [2,4,8,16,0,16,128,5,137,20,137,1,129,0,136,2,1,136,21,137,1,1,17,139,9,16,136,1,1,137,21,137,4,137,1,137]

theorem envBound16233 : H12AffineFastState.Bounded env16233 := by
  intro p hp
  have h : env16233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16232_16233 : H12AffineEnvironment.transform 4 0 env16232 = env16233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16232 == env16233) = true)

theorem identity16233 : scanCanonicalize (H12AffineFastState.compose env16233 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16234 : List Nat := [2,4,8,1,0,1,128,5,137,5,137,1,129,0,136,2,1,136,4,137,1,1,0,139,9,1,136,1,1,137,4,137,4,137,1,137]

theorem envBound16234 : H12AffineFastState.Bounded env16234 := by
  intro p hp
  have h : env16234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16233_16234 : H12AffineEnvironment.transform 3 1 env16233 = env16234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16233 == env16234) = true)

def leafEnv16234 : List Nat := [2,4,8,1,0,1,128,5,137,5,137,1,129,0,136,2,1,136,4,137,1,1,0,139,4,9,1,1,136,1,1,137,4,137,4,137,4,139,1,137,0,0,1]

def active16234 : List Nat := [0,1,2,6]

def tree16234 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16234 : H12WitnessSearch.Good tree16234 := H12GlobalWitnessIndex.good

theorem leafIdentity16234 : H12AffineFastState.composeSystem env16234 rootObs = leafEnv16234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16234 rootObs == leafEnv16234) = true)

theorem terminalChecked16234 : H12PackedTerminal.terminalCheckFast leafEnv16234 active16234 tree16234 = true := by decide +kernel

def env16235 : List Nat := [2,4,8,16,1,16,128,5,137,21,137,0,129,1,137,3,0,136,20,136,0,1,17,139,9,16,136,0,0,137,20,137,4,136,0,137]

theorem envBound16235 : H12AffineFastState.Bounded env16235 := by
  intro p hp
  have h : env16235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16232_16235 : H12AffineEnvironment.transform 4 1 env16232 = env16235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16232 == env16235) = true)

theorem identity16235 : scanCanonicalize (H12AffineFastState.compose env16235 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16236 : List Nat := [2,4,8,16,1,16,25,5,16,21,16,0,24,1,16,3,0,17,20,17,0,1,17,18,9,16,17,0,0,16,20,16,4,17,0,16]

theorem envBound16236 : H12AffineFastState.Bounded env16236 := by
  intro p hp
  have h : env16236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16235_16236 : H12AffineEnvironment.transform 6 25 env16235 = env16236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16235 == env16236) = true)

def leafEnv16236 : List Nat := [2,4,8,16,1,16,25,5,16,21,16,0,24,1,16,3,0,17,20,17,0,1,17,18,20,9,1,16,17,0,0,16,20,16,4,17,4,19,0,16,0,1,1]

def active16236 : List Nat := [0,1,2,3]

def tree16236 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16236 : H12WitnessSearch.Good tree16236 := H12GlobalWitnessIndex.good

theorem leafIdentity16236 : H12AffineFastState.composeSystem env16236 rootObs = leafEnv16236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16236 rootObs == leafEnv16236) = true)

theorem terminalChecked16236 : H12PackedTerminal.terminalCheckFast leafEnv16236 active16236 tree16236 = true := by decide +kernel

def env16237 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,2057,1044,2081,2218,1045,2048,1025,2080,1045,1,17,138,2177,16,2048,1045,1045,2048,1025,137,4,168,1045,137]

theorem envBound16237 : H12AffineFastState.Bounded env16237 := by
  intro p hp
  have h : env16237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16229_16237 : H12AffineEnvironment.transform 12 2057 env16229 = env16237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env16229 == env16237) = true)

theorem identity16237 : scanCanonicalize (H12AffineFastState.compose env16237 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound16237 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16238 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1181,1045,1172,1044,1212,1079,1045,1181,1025,1213,1045,1,17,138,1052,16,1181,1045,1045,1181,1025,137,4,168,1045,137]

theorem envBound16238 : H12AffineFastState.Bounded env16238 := by
  intro p hp
  have h : env16238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16237_16238 : H12AffineEnvironment.transform 10 1181 env16237 = env16238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env16237 == env16238) = true)

def env16239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,644437,8328,541009,134217728,16384,545088,1073741824,545108,4294967296,256,4299806207,138695701,512]

theorem envBound16239 : H12AffineFastState.Bounded env16239 := by
  intro p hp
  have h : env16239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16120_16239 : H12AffineEnvironment.transform 22 17665 env16120 = env16239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env16120 == env16239) = true)

theorem identity16239 : scanCanonicalize (H12AffineFastState.compose env16239 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound16239 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env16240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,644437,8328,541009,4982020,16384,545088,1073741824,545108,4294967296,256,4299806207,545041,512]

theorem envBound16240 : H12AffineFastState.Bounded env16240 := by
  intro p hp
  have h : env16240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16239_16240 : H12AffineEnvironment.transform 26 4982020 env16239 = env16240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env16239 == env16240) = true)

theorem identity16240 : scanCanonicalize (H12AffineFastState.compose env16240 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound16240 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env16241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4096,4194304,17665,119125,8328,17745,4456708,16384,21824,1073741824,21844,4294967296,256,4299280895,21777,512]

theorem envBound16241 : H12AffineFastState.Bounded env16241 := by
  intro p hp
  have h : env16241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16240_16241 : H12AffineEnvironment.transform 18 1024 env16240 = env16241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env16240 == env16241) = true)

def env16242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,1024,32769,4096,4194304,65,103445,8328,17,4456708,1344,4096,1073741824,4116,4294967296,256,4299265215,4177,512]

theorem envBound16242 : H12AffineFastState.Bounded env16242 := by
  intro p hp
  have h : env16242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16241_16242 : H12AffineEnvironment.transform 13 1344 env16241 = env16242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env16241 == env16242) = true)

theorem identity16242 : scanCanonicalize (H12AffineFastState.compose env16242 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound16242 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,65,98645,8328,17,4456708,1344,1344,1073741824,1364,4294967296,256,4299260415,1297,512]

theorem envBound16243 : H12AffineFastState.Bounded env16243 := by
  intro p hp
  have h : env16243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16242_16243 : H12AffineEnvironment.transform 11 1344 env16242 = env16243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env16242 == env16243) = true)

theorem identity16243 : scanCanonicalize (H12AffineFastState.compose env16243 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound16243 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env16244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,262144,1024,32769,1344,4194304,65,138,8328,17,4456708,1344,1344,1073741824,1364,4294967296,256,4299161632,1297,512]

theorem envBound16244 : H12AffineFastState.Bounded env16244 := by
  intro p hp
  have h : env16244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16243_16244 : H12AffineEnvironment.transform 15 33247 env16243 = env16244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env16243 == env16244) = true)

theorem identity16244 : scanCanonicalize (H12AffineFastState.compose env16244 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 264589) := by decide +kernel

theorem selectedBound16244 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env16245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,262144,1024,32769,1344,4194304,65,138,8328,17,4456708,1344,1344,1073741824,1364,264589,256,4458925,1297,512]

theorem envBound16245 : H12AffineFastState.Bounded env16245 := by
  intro p hp
  have h : env16245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16244_16245 : H12AffineEnvironment.transform 31 264589 env16244 = env16245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 264589 env16244 == env16245) = true)

theorem identity16245 : scanCanonicalize (H12AffineFastState.compose env16245 (packedSelected [12,13,17,41] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound16245 : packedSelected [12,13,17,41] rootPS < 2^1333 := by decide +kernel

def env16246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43129,1024,32769,1344,4194304,65,138,8328,17,4237693,1344,1344,1073741824,1364,41460,256,4235732,1297,512]

theorem envBound16246 : H12AffineFastState.Bounded env16246 := by
  intro p hp
  have h : env16246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16245_16246 : H12AffineEnvironment.transform 17 43129 env16245 = env16246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env16245 == env16246) = true)

theorem identity16246 : scanCanonicalize (H12AffineFastState.compose env16246 (packedSelected [1,3,5,8,12,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4227184) := by decide +kernel

theorem selectedBound16246 : packedSelected [1,3,5,8,12,13,17] rootPS < 2^1333 := by decide +kernel

def env16247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43129,1024,32769,1344,4194304,65,138,8328,17,4237693,1344,1344,4227184,1364,41460,256,4235732,1297,512]

theorem envBound16247 : H12AffineFastState.Bounded env16247 := by
  intro p hp
  have h : env16247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16246_16247 : H12AffineEnvironment.transform 29 4227184 env16246 = env16247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227184 env16246 == env16247) = true)

theorem identity16247 : scanCanonicalize (H12AffineFastState.compose env16247 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 10248) := by decide +kernel

theorem selectedBound16247 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env16248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43129,1024,32769,1344,10248,65,138,8328,17,33141,1344,1344,43128,1364,41460,256,35292,1297,512]

theorem envBound16248 : H12AffineFastState.Bounded env16248 := by
  intro p hp
  have h : env16248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16247_16248 : H12AffineEnvironment.transform 21 10248 env16247 = env16248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env16247 == env16248) = true)

theorem identity16248 : scanCanonicalize (H12AffineFastState.compose env16248 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 10913) := by decide +kernel

theorem selectedBound16248 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,10913,11134,1344,728,1024,10912,1344,10248,65,138,8328,17,11220,1344,1344,729,1364,2901,256,9085,1297,512]

theorem envBound16249 : H12AffineFastState.Bounded env16249 := by
  intro p hp
  have h : env16249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16248_16249 : H12AffineEnvironment.transform 14 10913 env16248 = env16249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10913 env16248 == env16249) = true)

theorem identity16249 : scanCanonicalize (H12AffineFastState.compose env16249 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound16249 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,981,1344,2420,2219,1344,728,1024,2421,1344,3037,65,138,861,17,2049,1344,1344,729,1364,2901,256,168,1297,512]

theorem envBound16250 : H12AffineFastState.Bounded env16250 := by
  intro p hp
  have h : env16250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16249_16250 : H12AffineEnvironment.transform 12 981 env16249 = env16250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env16249 == env16250) = true)

theorem identity16250 : scanCanonicalize (H12AffineFastState.compose env16250 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound16250 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16251 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1344,349,1344,2420,2219,1344,80,1024,2421,1344,2389,65,138,469,17,2049,1344,1344,81,1364,2525,256,168,1297,136]

theorem envBound16251 : H12AffineFastState.Bounded env16251 := by
  intro p hp
  have h : env16251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16250_16251 : H12AffineEnvironment.transform 8 136 env16250 = env16251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16250 == env16251) = true)

theorem identity16251 : scanCanonicalize (H12AffineFastState.compose env16251 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound16251 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16252 : List Nat := [2,4,8,16,32,64,128,256,136,1024,81,1344,349,1344,293,250,1344,80,1024,292,1344,260,65,138,469,17,80,1344,1344,81,1364,396,256,168,1297,136]

theorem envBound16252 : H12AffineFastState.Bounded env16252 := by
  intro p hp
  have h : env16252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16251_16252 : H12AffineEnvironment.transform 10 81 env16251 = env16252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env16251 == env16252) = true)

theorem identity16252 : scanCanonicalize (H12AffineFastState.compose env16252 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound16252 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16253 : List Nat := [2,4,8,16,32,64,128,256,136,321,81,1,349,1,293,250,1,80,321,292,1,260,65,138,469,17,80,1,1,81,21,396,256,168,80,136]

theorem envBound16253 : H12AffineFastState.Bounded env16253 := by
  intro p hp
  have h : env16253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16252_16253 : H12AffineEnvironment.transform 9 321 env16252 = env16253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env16252 == env16253) = true)

theorem identity16253 : scanCanonicalize (H12AffineFastState.compose env16253 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16253 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16254 : List Nat := [2,4,8,16,32,16,128,256,136,273,1,1,269,1,293,170,1,0,273,292,1,260,17,138,389,17,0,1,1,1,21,396,256,168,0,136]

theorem envBound16254 : H12AffineFastState.Bounded env16254 := by
  intro p hp
  have h : env16254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16253_16254 : H12AffineEnvironment.transform 5 16 env16253 = env16254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16253 == env16254) = true)

theorem identity16254 : scanCanonicalize (H12AffineFastState.compose env16254 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound16254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16255 : List Nat := [2,4,8,16,32,16,128,46,136,63,1,1,35,1,11,170,1,0,63,10,1,42,17,138,171,17,0,1,1,1,21,162,46,168,0,136]

theorem envBound16255 : H12AffineFastState.Bounded env16255 := by
  intro p hp
  have h : env16255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16254_16255 : H12AffineEnvironment.transform 7 46 env16254 = env16255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env16254 == env16255) = true)

def env16256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,1024,32769,4096,4194304,64,103444,8328,16,4456708,1345,4097,1073741824,4117,4294967296,256,4299265214,4176,512]

theorem envBound16256 : H12AffineFastState.Bounded env16256 := by
  intro p hp
  have h : env16256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16241_16256 : H12AffineEnvironment.transform 13 1345 env16241 = env16256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env16241 == env16256) = true)

theorem identity16256 : scanCanonicalize (H12AffineFastState.compose env16256 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16256 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16257 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,32768,65536,1296,262144,1024,32769,4096,4194304,16,103444,8328,16,4456708,1297,4097,1073741824,4117,4294967296,256,4299265214,4096,512]

theorem envBound16257 : H12AffineFastState.Bounded env16257 := by
  intro p hp
  have h : env16257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16256_16257 : H12AffineEnvironment.transform 5 16 env16256 = env16257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16256 == env16257) = true)

def env16258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,9015381,8328,8914000,134217728,8389888,545089,1073741824,545108,4294967296,8406016,4308177151,138695701,512]

theorem envBound16258 : H12AffineFastState.Bounded env16258 := by
  intro p hp
  have h : env16258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16119_16258 : H12AffineEnvironment.transform 16 1345 env16119 = env16258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env16119 == env16258) = true)

def env16259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17664,644437,8328,541008,134217728,16384,545089,1073741824,545108,4294967296,256,4299806207,138695701,512]

theorem envBound16259 : H12AffineFastState.Bounded env16259 := by
  intro p hp
  have h : env16259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16258_16259 : H12AffineEnvironment.transform 22 17664 env16258 = env16259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env16258 == env16259) = true)

theorem identity16259 : scanCanonicalize (H12AffineFastState.compose env16259 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound16259 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env16260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4096,4194304,17664,98564,8328,5377,134217728,16384,1296,1073741824,1285,4294967296,256,4299260334,138695701,512]

theorem envBound16260 : H12AffineFastState.Bounded env16260 := by
  intro p hp
  have h : env16260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16259_16260 : H12AffineEnvironment.transform 18 21585 env16259 = env16260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env16259 == env16260) = true)

def env16261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16657,32769,1344,4194304,17664,98564,8328,65,134217728,16384,1296,1073741824,1285,4294967296,256,4299260334,138690901,512]

theorem envBound16261 : H12AffineFastState.Bounded env16261 := by
  intro p hp
  have h : env16261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16260_16261 : H12AffineEnvironment.transform 11 1344 env16260 = env16261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env16260 == env16261) = true)

theorem identity16261 : scanCanonicalize (H12AffineFastState.compose env16261 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4473876) := by decide +kernel

theorem selectedBound16261 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env16262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16657,32769,1344,4194304,17664,98564,8328,65,4473876,16384,1296,1073741824,1285,4294967296,256,4299260334,1345,512]

theorem envBound16262 : H12AffineFastState.Bounded env16262 := by
  intro p hp
  have h : env16262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16261_16262 : H12AffineEnvironment.transform 26 4473876 env16261 = env16262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4473876 env16261 == env16262) = true)

theorem identity16262 : scanCanonicalize (H12AffineFastState.compose env16262 (packedSelected [3,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound16262 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1945,32768,65536,1345,262144,1672,32769,1344,4194304,665,98564,8328,65,4457357,1945,1296,1073741824,1285,4294967296,256,4299260334,1345,512]

theorem envBound16263 : H12AffineFastState.Bounded env16263 := by
  intro p hp
  have h : env16263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16262_16263 : H12AffineEnvironment.transform 13 1945 env16262 = env16263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env16262 == env16263) = true)

def env16264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1945,32768,65536,1297,262144,1672,32769,1296,4194304,665,98564,8328,17,4457357,1945,1296,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound16264 : H12AffineFastState.Bounded env16264 := by
  intro p hp
  have h : env16264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16263_16264 : H12AffineEnvironment.transform 5 16 env16263 = env16264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16263 == env16264) = true)

def env16265 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,98564,8328,17,4456709,1297,1296,1073741824,1285,4294967296,256,4299260334,1297,136]

theorem envBound16265 : H12AffineFastState.Bounded env16265 := by
  intro p hp
  have h : env16265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16264_16265 : H12AffineEnvironment.transform 8 136 env16264 = env16265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16264 == env16265) = true)

theorem identity16265 : scanCanonicalize (H12AffineFastState.compose env16265 (packedSelected [1,10] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound16265 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env16266 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,98564,8328,17,4456709,1297,1296,4294794,1285,4294967296,256,4299260334,1297,136]

theorem envBound16266 : H12AffineFastState.Bounded env16266 := by
  intro p hp
  have h : env16266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16265_16266 : H12AffineEnvironment.transform 29 4294794 env16265 = env16266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env16265 == env16266) = true)

theorem identity16266 : scanCanonicalize (H12AffineFastState.compose env16266 (packedSelected [3,12] rootPS)) = affineNative (2^(31+1) ^^^ 4235652) := by decide +kernel

theorem selectedBound16266 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env16267 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,98564,8328,17,4456709,1297,1296,4294794,1285,4235652,256,73770,1297,136]

theorem envBound16267 : H12AffineFastState.Bounded env16267 := by
  intro p hp
  have h : env16267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16266_16267 : H12AffineEnvironment.transform 31 4235652 env16266 = env16267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4235652 env16266 == env16267) = true)

def env16268 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,1,262144,272,32769,0,4194304,17,98564,8328,17,4456709,1,0,4294794,21,4235652,256,73770,1,136]

theorem envBound16268 : H12AffineFastState.Bounded env16268 := by
  intro p hp
  have h : env16268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16267_16268 : H12AffineEnvironment.transform 9 272 env16267 = env16268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16267 == env16268) = true)

theorem identity16268 : scanCanonicalize (H12AffineFastState.compose env16268 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound16268 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16269 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,1,76198,272,32769,0,4194304,17,98564,8328,17,4270243,1,0,4294794,21,4235652,256,73770,1,136]

theorem envBound16269 : H12AffineFastState.Bounded env16269 := by
  intro p hp
  have h : env16269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16268_16269 : H12AffineEnvironment.transform 17 76198 env16268 = env16269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env16268 == env16269) = true)

theorem identity16269 : scanCanonicalize (H12AffineFastState.compose env16269 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound16269 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16270 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,33167,1,43049,272,32769,0,4194304,17,139,8328,17,4237612,1,0,4196613,21,4235652,256,41381,1,136]

theorem envBound16270 : H12AffineFastState.Bounded env16270 := by
  intro p hp
  have h : env16270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16269_16270 : H12AffineEnvironment.transform 15 33167 env16269 = env16270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env16269 == env16270) = true)

def env16271 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,33167,1,43049,272,32769,0,41088,17,139,8328,17,2476,1,0,43397,21,260,256,41381,1,136]

theorem envBound16271 : H12AffineFastState.Bounded env16271 := by
  intro p hp
  have h : env16271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16270_16271 : H12AffineEnvironment.transform 21 41088 env16270 = env16271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env16270 == env16271) = true)

theorem identity16271 : scanCanonicalize (H12AffineFastState.compose env16271 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16271 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16272 : List Nat := [2,4,8,16,32,16,41,256,33,272,2048,0,8192,1,32768,33062,1,43049,272,32769,0,41001,17,34,8225,17,2309,1,0,43308,21,260,256,41228,1,33]

theorem envBound16272 : H12AffineFastState.Bounded env16272 := by
  intro p hp
  have h : env16272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16271_16272 : H12AffineEnvironment.transform 6 41 env16271 = env16272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16271 == env16272) = true)

def env16273 : List Nat := [2,4,8,16,32,16,41,256,33,272,2048,0,8192,1,2080,2310,1,8201,272,2081,0,10249,17,34,8225,17,2309,1,0,8460,21,260,256,10540,1,33]

theorem envBound16273 : H12AffineFastState.Bounded env16273 := by
  intro p hp
  have h : env16273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16272_16273 : H12AffineEnvironment.transform 14 2080 env16272 = env16273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env16272 == env16273) = true)

theorem identity16273 : scanCanonicalize (H12AffineFastState.compose env16273 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound16273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16274 : List Nat := [2,4,8,16,32,16,41,256,33,272,2048,0,2056,1,2080,2310,1,2049,272,2081,0,1,17,34,2089,17,2309,1,0,2308,21,260,256,292,1,33]

theorem envBound16274 : H12AffineFastState.Bounded env16274 := by
  intro p hp
  have h : env16274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16273_16274 : H12AffineEnvironment.transform 12 2056 env16273 = env16274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16273 == env16274) = true)

theorem identity16274 : scanCanonicalize (H12AffineFastState.compose env16274 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16275 : List Nat := [2,4,8,16,32,16,41,4,33,20,2048,0,2056,1,2080,2050,1,2049,20,2081,0,1,17,34,2089,17,2049,1,0,2048,21,0,4,32,1,33]

theorem envBound16275 : H12AffineFastState.Bounded env16275 := by
  intro p hp
  have h : env16275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16274_16275 : H12AffineEnvironment.transform 7 4 env16274 = env16275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16274 == env16275) = true)

def leafEnv16275 : List Nat := [2,4,8,16,32,16,41,4,33,20,2048,0,2056,1,2080,2050,1,2049,20,2081,0,1,17,34,21,2089,1,17,2049,1,0,2048,21,0,4,32,4,2082,1,33,0,0,1]

def active16275 : List Nat := [0,1,2,3,4,10]

def tree16275 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16275 : H12WitnessSearch.Good tree16275 := H12GlobalWitnessIndex.good

theorem leafIdentity16275 : H12AffineFastState.composeSystem env16275 rootObs = leafEnv16275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16275 rootObs == leafEnv16275) = true)

theorem terminalChecked16275 : H12PackedTerminal.terminalCheckFast leafEnv16275 active16275 tree16275 = true := by decide +kernel

def env16276 : List Nat := [2,4,8,16,32,16,41,256,33,272,2048,0,8192,1,2081,2311,1,8200,272,2080,0,10248,17,34,8225,17,2309,1,0,8461,21,260,256,10541,1,33]

theorem envBound16276 : H12AffineFastState.Bounded env16276 := by
  intro p hp
  have h : env16276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16272_16276 : H12AffineEnvironment.transform 14 2081 env16272 = env16276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env16272 == env16276) = true)

theorem identity16276 : scanCanonicalize (H12AffineFastState.compose env16276 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16276 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16277 : List Nat := [2,4,8,16,32,16,41,5,33,21,2048,0,8192,1,2081,2050,1,8200,21,2080,0,10248,17,34,8225,17,2048,1,0,8200,21,1,5,10280,1,33]

theorem envBound16277 : H12AffineFastState.Bounded env16277 := by
  intro p hp
  have h : env16277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16276_16277 : H12AffineEnvironment.transform 7 5 env16276 = env16277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16276 == env16277) = true)

theorem identity16277 : scanCanonicalize (H12AffineFastState.compose env16277 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound16277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16278 : List Nat := [2,4,8,16,32,16,41,5,33,21,2048,0,2056,1,2081,2050,1,2048,21,2080,0,0,17,34,2089,17,2048,1,0,2048,21,1,5,32,1,33]

theorem envBound16278 : H12AffineFastState.Bounded env16278 := by
  intro p hp
  have h : env16278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16277_16278 : H12AffineEnvironment.transform 12 2056 env16277 = env16278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16277 == env16278) = true)

def leafEnv16278 : List Nat := [2,4,8,16,32,16,41,5,33,21,2048,0,2056,1,2081,2050,1,2048,21,2080,0,0,17,34,21,2089,1,17,2048,1,0,2048,21,1,5,32,4,2082,1,33,0,0,1]

def active16278 : List Nat := [0,1,2,3,4,10]

def tree16278 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16278 : H12WitnessSearch.Good tree16278 := H12GlobalWitnessIndex.good

theorem leafIdentity16278 : H12AffineFastState.composeSystem env16278 rootObs = leafEnv16278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16278 rootObs == leafEnv16278) = true)

theorem terminalChecked16278 : H12PackedTerminal.terminalCheckFast leafEnv16278 active16278 tree16278 = true := by decide +kernel

def env16279 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,33167,1,43049,272,32769,0,41089,17,139,8328,17,2477,1,0,43396,21,261,256,41381,1,136]

theorem envBound16279 : H12AffineFastState.Bounded env16279 := by
  intro p hp
  have h : env16279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16270_16279 : H12AffineEnvironment.transform 21 41089 env16270 = env16279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env16270 == env16279) = true)

theorem identity16279 : scanCanonicalize (H12AffineFastState.compose env16279 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound16279 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16280 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,8612,8235,1,2445,272,8613,0,293,17,139,8328,17,2477,1,0,2080,21,261,256,1,1,136]

theorem envBound16280 : H12AffineFastState.Bounded env16280 := by
  intro p hp
  have h : env16280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16279_16280 : H12AffineEnvironment.transform 14 8612 env16279 = env16280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env16279 == env16280) = true)

theorem identity16280 : scanCanonicalize (H12AffineFastState.compose env16280 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound16280 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16281 : List Nat := [2,4,8,16,32,16,128,172,136,188,2048,0,8192,1,8200,8235,1,2081,188,8201,0,137,17,139,8328,17,2049,1,0,2080,21,169,172,1,1,136]

theorem envBound16281 : H12AffineFastState.Bounded env16281 := by
  intro p hp
  have h : env16281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16280_16281 : H12AffineEnvironment.transform 7 172 env16280 = env16281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env16280 == env16281) = true)

def env16282 : List Nat := [2,4,8,16,32,16,128,172,136,188,2048,0,2176,1,2184,2219,1,2081,188,2185,0,137,17,139,2056,17,2049,1,0,2080,21,169,172,1,1,136]

theorem envBound16282 : H12AffineFastState.Bounded env16282 := by
  intro p hp
  have h : env16282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16281_16282 : H12AffineEnvironment.transform 12 2176 env16281 = env16282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env16281 == env16282) = true)

theorem identity16282 : scanCanonicalize (H12AffineFastState.compose env16282 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16283 : List Nat := [2,4,8,16,0,16,128,140,136,156,2048,0,2176,1,2184,2187,1,2049,156,2185,0,137,17,139,2056,17,2049,1,0,2048,21,137,140,1,1,136]

theorem envBound16283 : H12AffineFastState.Bounded env16283 := by
  intro p hp
  have h : env16283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16282_16283 : H12AffineEnvironment.transform 4 0 env16282 = env16283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16282 == env16283) = true)

def leafEnv16283 : List Nat := [2,4,8,16,0,16,128,140,136,156,2048,0,2176,1,2184,2187,1,2049,156,2185,0,137,17,139,21,2056,1,17,2049,1,0,2048,21,137,140,1,4,2050,1,136,0,0,1]

def active16283 : List Nat := [0,1,2,3,6,10]

def tree16283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16283 : H12WitnessSearch.Good tree16283 := H12GlobalWitnessIndex.good

theorem leafIdentity16283 : H12AffineFastState.composeSystem env16283 rootObs = leafEnv16283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16283 rootObs == leafEnv16283) = true)

theorem terminalChecked16283 : H12PackedTerminal.terminalCheckFast leafEnv16283 active16283 tree16283 = true := by decide +kernel

def env16284 : List Nat := [2,4,8,16,32,16,128,172,136,188,2048,0,2177,1,2185,2218,1,2081,188,2184,0,137,17,139,2057,17,2049,1,0,2080,21,169,172,1,1,136]

theorem envBound16284 : H12AffineFastState.Bounded env16284 := by
  intro p hp
  have h : env16284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16281_16284 : H12AffineEnvironment.transform 12 2177 env16281 = env16284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env16281 == env16284) = true)

def env16285 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,65536,0,262144,273,32769,1,4194304,17,98564,8328,17,4456709,0,1,4294794,20,4235652,256,73770,0,136]

theorem envBound16285 : H12AffineFastState.Bounded env16285 := by
  intro p hp
  have h : env16285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16267_16285 : H12AffineEnvironment.transform 9 273 env16267 = env16285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16267 == env16285) = true)

theorem identity16285 : scanCanonicalize (H12AffineFastState.compose env16285 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound16285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16286 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,33167,0,262144,273,32769,1,4194304,17,139,8328,17,4456709,0,1,4196613,20,4235652,256,41381,0,136]

theorem envBound16286 : H12AffineFastState.Bounded env16286 := by
  intro p hp
  have h : env16286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16285_16286 : H12AffineEnvironment.transform 15 33167 env16285 = env16286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env16285 == env16286) = true)

theorem identity16286 : scanCanonicalize (H12AffineFastState.compose env16286 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound16286 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16287 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,33167,0,43049,273,32769,1,4194304,17,139,8328,17,4237612,0,1,4196613,20,4235652,256,41381,0,136]

theorem envBound16287 : H12AffineFastState.Bounded env16287 := by
  intro p hp
  have h : env16287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16286_16287 : H12AffineEnvironment.transform 17 43049 env16286 = env16287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env16286 == env16287) = true)

def env16288 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,33167,0,43049,273,32769,1,41088,17,139,8328,17,2476,0,1,43397,20,260,256,41381,0,136]

theorem envBound16288 : H12AffineFastState.Bounded env16288 := by
  intro p hp
  have h : env16288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16287_16288 : H12AffineEnvironment.transform 21 41088 env16287 = env16288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env16287 == env16288) = true)

theorem identity16288 : scanCanonicalize (H12AffineFastState.compose env16288 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16288 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16289 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,1,8192,0,32768,33062,0,43049,273,32769,1,41001,17,34,8225,17,2309,0,1,43308,20,260,256,41228,0,33]

theorem envBound16289 : H12AffineFastState.Bounded env16289 := by
  intro p hp
  have h : env16289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16288_16289 : H12AffineEnvironment.transform 6 41 env16288 = env16289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16288 == env16289) = true)

def env16290 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,1,8192,0,2080,2310,0,8201,273,2081,1,10249,17,34,8225,17,2309,0,1,8460,20,260,256,10540,0,33]

theorem envBound16290 : H12AffineFastState.Bounded env16290 := by
  intro p hp
  have h : env16290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16289_16290 : H12AffineEnvironment.transform 14 2080 env16289 = env16290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env16289 == env16290) = true)

theorem identity16290 : scanCanonicalize (H12AffineFastState.compose env16290 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound16290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16291 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,1,2056,0,2080,2310,0,2049,273,2081,1,1,17,34,2089,17,2309,0,1,2308,20,260,256,292,0,33]

theorem envBound16291 : H12AffineFastState.Bounded env16291 := by
  intro p hp
  have h : env16291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16290_16291 : H12AffineEnvironment.transform 12 2056 env16290 = env16291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16290 == env16291) = true)

theorem identity16291 : scanCanonicalize (H12AffineFastState.compose env16291 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16292 : List Nat := [2,4,8,16,32,16,41,4,33,21,2048,1,2056,0,2080,2050,0,2049,21,2081,1,1,17,34,2089,17,2049,0,1,2048,20,0,4,32,0,33]

theorem envBound16292 : H12AffineFastState.Bounded env16292 := by
  intro p hp
  have h : env16292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16291_16292 : H12AffineEnvironment.transform 7 4 env16291 = env16292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16291 == env16292) = true)

def leafEnv16292 : List Nat := [2,4,8,16,32,16,41,4,33,21,2048,1,2056,0,2080,2050,0,2049,21,2081,1,1,17,34,20,2089,1,17,2049,0,1,2048,20,0,4,32,4,2082,0,33,0,1,1]

def active16292 : List Nat := [0,1,2,3,4,10]

def tree16292 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16292 : H12WitnessSearch.Good tree16292 := H12GlobalWitnessIndex.good

theorem leafIdentity16292 : H12AffineFastState.composeSystem env16292 rootObs = leafEnv16292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16292 rootObs == leafEnv16292) = true)

theorem terminalChecked16292 : H12PackedTerminal.terminalCheckFast leafEnv16292 active16292 tree16292 = true := by decide +kernel

def env16293 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,1,8192,0,2081,2311,0,8200,273,2080,1,10248,17,34,8225,17,2309,0,1,8461,20,260,256,10541,0,33]

theorem envBound16293 : H12AffineFastState.Bounded env16293 := by
  intro p hp
  have h : env16293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16289_16293 : H12AffineEnvironment.transform 14 2081 env16289 = env16293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env16289 == env16293) = true)

theorem identity16293 : scanCanonicalize (H12AffineFastState.compose env16293 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16294 : List Nat := [2,4,8,16,32,16,41,5,33,20,2048,1,8192,0,2081,2050,0,8200,20,2080,1,10248,17,34,8225,17,2048,0,1,8200,20,1,5,10280,0,33]

theorem envBound16294 : H12AffineFastState.Bounded env16294 := by
  intro p hp
  have h : env16294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16293_16294 : H12AffineEnvironment.transform 7 5 env16293 = env16294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16293 == env16294) = true)

theorem identity16294 : scanCanonicalize (H12AffineFastState.compose env16294 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound16294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16295 : List Nat := [2,4,8,16,32,16,41,5,33,20,2048,1,2056,0,2081,2050,0,2048,20,2080,1,0,17,34,2089,17,2048,0,1,2048,20,1,5,32,0,33]

theorem envBound16295 : H12AffineFastState.Bounded env16295 := by
  intro p hp
  have h : env16295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16294_16295 : H12AffineEnvironment.transform 12 2056 env16294 = env16295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env16294 == env16295) = true)

def leafEnv16295 : List Nat := [2,4,8,16,32,16,41,5,33,20,2048,1,2056,0,2081,2050,0,2048,20,2080,1,0,17,34,20,2089,1,17,2048,0,1,2048,20,1,5,32,4,2082,0,33,0,1,1]

def active16295 : List Nat := [0,1,2,3,4,10]

def tree16295 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16295 : H12WitnessSearch.Good tree16295 := H12GlobalWitnessIndex.good

theorem leafIdentity16295 : H12AffineFastState.composeSystem env16295 rootObs = leafEnv16295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16295 rootObs == leafEnv16295) = true)

theorem terminalChecked16295 : H12PackedTerminal.terminalCheckFast leafEnv16295 active16295 tree16295 = true := by decide +kernel

def env16296 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,33167,0,43049,273,32769,1,41089,17,139,8328,17,2477,0,1,43396,20,261,256,41381,0,136]

theorem envBound16296 : H12AffineFastState.Bounded env16296 := by
  intro p hp
  have h : env16296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16287_16296 : H12AffineEnvironment.transform 21 41089 env16287 = env16296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env16287 == env16296) = true)

theorem identity16296 : scanCanonicalize (H12AffineFastState.compose env16296 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound16296 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16297 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,8612,8235,0,2445,273,8613,1,293,17,139,8328,17,2477,0,1,2080,20,261,256,1,0,136]

theorem envBound16297 : H12AffineFastState.Bounded env16297 := by
  intro p hp
  have h : env16297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16296_16297 : H12AffineEnvironment.transform 14 8612 env16296 = env16297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env16296 == env16297) = true)

theorem identity16297 : scanCanonicalize (H12AffineFastState.compose env16297 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound16297 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16298 : List Nat := [2,4,8,16,32,16,128,172,136,189,2048,1,8192,0,8200,8235,0,2081,189,8201,1,137,17,139,8328,17,2049,0,1,2080,20,169,172,1,0,136]

theorem envBound16298 : H12AffineFastState.Bounded env16298 := by
  intro p hp
  have h : env16298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16297_16298 : H12AffineEnvironment.transform 7 172 env16297 = env16298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env16297 == env16298) = true)

def env16299 : List Nat := [2,4,8,16,32,16,128,172,136,189,2048,1,2176,0,2184,2219,0,2081,189,2185,1,137,17,139,2056,17,2049,0,1,2080,20,169,172,1,0,136]

theorem envBound16299 : H12AffineFastState.Bounded env16299 := by
  intro p hp
  have h : env16299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16298_16299 : H12AffineEnvironment.transform 12 2176 env16298 = env16299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env16298 == env16299) = true)

theorem identity16299 : scanCanonicalize (H12AffineFastState.compose env16299 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16300 : List Nat := [2,4,8,16,0,16,128,140,136,157,2048,1,2176,0,2184,2187,0,2049,157,2185,1,137,17,139,2056,17,2049,0,1,2048,20,137,140,1,0,136]

theorem envBound16300 : H12AffineFastState.Bounded env16300 := by
  intro p hp
  have h : env16300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16299_16300 : H12AffineEnvironment.transform 4 0 env16299 = env16300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16299 == env16300) = true)

def leafEnv16300 : List Nat := [2,4,8,16,0,16,128,140,136,157,2048,1,2176,0,2184,2187,0,2049,157,2185,1,137,17,139,20,2056,1,17,2049,0,1,2048,20,137,140,1,4,2050,0,136,0,1,1]

def active16300 : List Nat := [0,1,2,3,6,10]

def tree16300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16300 : H12WitnessSearch.Good tree16300 := H12GlobalWitnessIndex.good

theorem leafIdentity16300 : H12AffineFastState.composeSystem env16300 rootObs = leafEnv16300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16300 rootObs == leafEnv16300) = true)

theorem terminalChecked16300 : H12PackedTerminal.terminalCheckFast leafEnv16300 active16300 tree16300 = true := by decide +kernel

def env16301 : List Nat := [2,4,8,16,32,16,128,172,136,189,2048,1,2177,0,2185,2218,0,2081,189,2184,1,137,17,139,2057,17,2049,0,1,2080,20,169,172,1,0,136]

theorem envBound16301 : H12AffineFastState.Bounded env16301 := by
  intro p hp
  have h : env16301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16298_16301 : H12AffineEnvironment.transform 12 2177 env16298 = env16301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env16298 == env16301) = true)

def env16302 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1296,4194304,16,98564,8328,17,4456708,1296,1296,1073741824,1285,4294967296,256,4299260334,1297,137]

theorem envBound16302 : H12AffineFastState.Bounded env16302 := by
  intro p hp
  have h : env16302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16264_16302 : H12AffineEnvironment.transform 8 137 env16264 = env16302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16264 == env16302) = true)

theorem identity16302 : scanCanonicalize (H12AffineFastState.compose env16302 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound16302 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16303 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,76199,1025,32769,1296,4194304,16,98564,8328,17,4270243,1296,1296,1073741824,1285,4294967296,256,4299260334,1297,137]

theorem envBound16303 : H12AffineFastState.Bounded env16303 := by
  intro p hp
  have h : env16303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16302_16303 : H12AffineEnvironment.transform 17 76199 env16302 = env16303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env16302 == env16303) = true)

theorem identity16303 : scanCanonicalize (H12AffineFastState.compose env16303 (packedSelected [3] rootPS)) = affineNative (2^(31+1) ^^^ 73864) := by decide +kernel

theorem selectedBound16303 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16304 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,76199,1025,32769,1296,4194304,16,98564,8328,17,4270243,1296,1296,1073741824,1285,73864,256,4235558,1297,137]

theorem envBound16304 : H12AffineFastState.Bounded env16304 := by
  intro p hp
  have h : env16304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16303_16304 : H12AffineEnvironment.transform 31 73864 env16303 = env16304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73864 env16303 == env16304) = true)

theorem identity16304 : scanCanonicalize (H12AffineFastState.compose env16304 (packedSelected [1,8] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound16304 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env16305 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,76199,1025,32769,1296,4194304,16,98564,8328,17,4270243,1296,1296,4196612,1285,73864,256,4235558,1297,137]

theorem envBound16305 : H12AffineFastState.Bounded env16305 := by
  intro p hp
  have h : env16305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16304_16305 : H12AffineEnvironment.transform 29 4196612 env16304 = env16305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env16304 == env16305) = true)

theorem identity16305 : scanCanonicalize (H12AffineFastState.compose env16305 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 108707) := by decide +kernel

theorem selectedBound16305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16306 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,76199,1025,32769,1296,108707,16,98564,8328,17,32768,1296,1296,106919,1285,73864,256,67973,1297,137]

theorem envBound16306 : H12AffineFastState.Bounded env16306 := by
  intro p hp
  have h : env16306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16305_16306 : H12AffineEnvironment.transform 21 108707 env16305 = env16306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 108707 env16305 == env16306) = true)

theorem identity16306 : scanCanonicalize (H12AffineFastState.compose env16306 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound16306 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16307 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,33167,1297,43048,1025,32769,1296,10540,16,139,8328,17,32768,1296,1296,8232,1285,41223,256,34826,1297,137]

theorem envBound16307 : H12AffineFastState.Bounded env16307 := by
  intro p hp
  have h : env16307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16306_16307 : H12AffineEnvironment.transform 15 33167 env16306 = env16307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env16306 == env16307) = true)

theorem identity16307 : scanCanonicalize (H12AffineFastState.compose env16307 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16307 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env16308 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,8460,8323,1297,2340,1025,8461,1296,10540,16,139,8328,17,8460,1296,1296,8232,1285,11,256,10502,1297,137]

theorem envBound16308 : H12AffineFastState.Bounded env16308 := by
  intro p hp
  have h : env16308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16307_16308 : H12AffineEnvironment.transform 14 8460 env16307 = env16308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16307 == env16308) = true)

theorem identity16308 : scanCanonicalize (H12AffineFastState.compose env16308 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound16308 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16309 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2088,1296,2340,2219,1297,2340,1025,2341,1296,260,16,139,2208,17,2340,1296,1296,2048,1285,11,256,302,1297,137]

theorem envBound16309 : H12AffineFastState.Bounded env16309 := by
  intro p hp
  have h : env16309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16308_16309 : H12AffineEnvironment.transform 12 2088 env16308 = env16309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env16308 == env16309) = true)

theorem identity16309 : scanCanonicalize (H12AffineFastState.compose env16309 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound16309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16310 : List Nat := [2,4,8,16,32,16,128,167,137,1024,2048,1207,2088,1207,2179,2219,1206,2179,1025,2178,1207,163,16,139,2208,17,2179,1207,1207,2048,1186,11,167,137,1206,137]

theorem envBound16310 : H12AffineFastState.Bounded env16310 := by
  intro p hp
  have h : env16310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16309_16310 : H12AffineEnvironment.transform 7 167 env16309 = env16310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env16309 == env16310) = true)

def env16311 : List Nat := [2,4,8,16,32,16,40,15,33,1024,2048,1055,2088,1055,2091,2051,1054,2091,1025,2090,1055,11,16,35,2056,17,2091,1055,1055,2048,1034,11,15,33,1054,33]

theorem envBound16311 : H12AffineFastState.Bounded env16311 := by
  intro p hp
  have h : env16311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16310_16311 : H12AffineEnvironment.transform 6 40 env16310 = env16311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16310 == env16311) = true)

theorem identity16311 : scanCanonicalize (H12AffineFastState.compose env16311 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16312 : List Nat := [2,4,8,16,16,16,24,15,17,1024,2048,1055,2072,1055,2075,2051,1054,2075,1025,2074,1055,11,16,19,2056,17,2075,1055,1055,2048,1034,11,15,17,1054,17]

theorem envBound16312 : H12AffineFastState.Bounded env16312 := by
  intro p hp
  have h : env16312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16311_16312 : H12AffineEnvironment.transform 4 16 env16311 = env16312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16311 == env16312) = true)

def leafEnv16312 : List Nat := [2,4,8,16,16,16,24,15,17,1024,2048,1055,2072,1055,2075,2051,1054,2075,1025,2074,1055,11,16,19,1035,2056,1,17,2075,1055,1055,2048,1034,11,15,17,4,2066,1054,17,0,1055,1]

def active16312 : List Nat := [0,1,2,3,9,10]

def tree16312 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16312 : H12WitnessSearch.Good tree16312 := H12GlobalWitnessIndex.good

theorem leafIdentity16312 : H12AffineFastState.composeSystem env16312 rootObs = leafEnv16312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16312 rootObs == leafEnv16312) = true)

theorem terminalChecked16312 : H12PackedTerminal.terminalCheckFast leafEnv16312 active16312 tree16312 = true := by decide +kernel

def env16313 : List Nat := [2,4,8,16,32,16,41,14,32,1024,2048,1054,2088,1054,2090,2050,1055,2090,1025,2091,1054,10,16,34,2057,17,2090,1054,1054,2048,1035,11,14,32,1055,32]

theorem envBound16313 : H12AffineFastState.Bounded env16313 := by
  intro p hp
  have h : env16313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16310_16313 : H12AffineEnvironment.transform 6 41 env16310 = env16313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16310 == env16313) = true)

theorem identity16313 : scanCanonicalize (H12AffineFastState.compose env16313 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16314 : List Nat := [2,4,8,11,32,11,41,14,32,1024,2048,1029,2088,1029,2090,2050,1028,2090,1025,2091,1029,10,11,34,2057,10,2090,1029,1029,2048,1035,11,14,32,1028,32]

theorem envBound16314 : H12AffineFastState.Bounded env16314 := by
  intro p hp
  have h : env16314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16313_16314 : H12AffineEnvironment.transform 3 11 env16313 = env16314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16313 == env16314) = true)

def leafEnv16314 : List Nat := [2,4,8,11,32,11,41,14,32,1024,2048,1029,2088,1029,2090,2050,1028,2090,1025,2091,1029,10,11,34,1034,2057,1,10,2090,1029,1029,2048,1035,11,14,32,4,2082,1028,32,0,1029,1]

def active16314 : List Nat := [0,1,2,4,9,10]

def tree16314 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16314 : H12WitnessSearch.Good tree16314 := H12GlobalWitnessIndex.good

theorem leafIdentity16314 : H12AffineFastState.composeSystem env16314 rootObs = leafEnv16314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16314 rootObs == leafEnv16314) = true)

theorem terminalChecked16314 : H12PackedTerminal.terminalCheckFast leafEnv16314 active16314 tree16314 = true := by decide +kernel

def env16315 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,4194304,665,98564,8328,16,4457357,1945,1296,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound16315 : H12AffineFastState.Bounded env16315 := by
  intro p hp
  have h : env16315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16263_16315 : H12AffineEnvironment.transform 5 17 env16263 = env16315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16263 == env16315) = true)

theorem identity16315 : scanCanonicalize (H12AffineFastState.compose env16315 (packedSelected [3,5,12,15,19] rootPS)) = affineNative (2^(29+1) ^^^ 4295170) := by decide +kernel

theorem selectedBound16315 : packedSelected [3,5,12,15,19] rootPS < 2^1333 := by decide +kernel

def env16316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,4194304,665,98564,8328,16,4457357,1945,1296,4295170,1285,4294967296,256,4299260334,1296,512]

theorem envBound16316 : H12AffineFastState.Bounded env16316 := by
  intro p hp
  have h : env16316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16315_16316 : H12AffineEnvironment.transform 29 4295170 env16315 = env16316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295170 env16315 == env16316) = true)

def env16317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,41480,665,98564,8328,16,303493,1945,1296,75786,1285,4294967296,256,4295041958,1296,512]

theorem envBound16317 : H12AffineFastState.Bounded env16317 := by
  intro p hp
  have h : env16317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16316_16317 : H12AffineEnvironment.transform 21 41480 env16316 = env16317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41480 env16316 == env16317) = true)

theorem identity16317 : scanCanonicalize (H12AffineFastState.compose env16317 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98986) := by decide +kernel

theorem selectedBound16317 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16318 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,41480,665,98564,8328,16,303493,1945,1296,75786,1285,98986,256,41228,1296,512]

theorem envBound16318 : H12AffineFastState.Bounded env16318 := by
  intro p hp
  have h : env16318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16317_16318 : H12AffineEnvironment.transform 31 98986 env16317 = env16318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98986 env16317 == env16318) = true)

def env16319 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,33280,1672,32769,1297,41480,665,98564,8328,16,9093,1945,1296,75786,1285,98986,256,41228,1296,512]

theorem envBound16319 : H12AffineFastState.Bounded env16319 := by
  intro p hp
  have h : env16319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16318_16319 : H12AffineEnvironment.transform 17 33280 env16318 = env16319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33280 env16318 == env16319) = true)

theorem identity16319 : scanCanonicalize (H12AffineFastState.compose env16319 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound16319 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16320 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,8581,65536,1296,9093,1672,8580,1297,909,665,73857,8328,16,9093,1945,1296,75786,1285,74543,256,137,1296,512]

theorem envBound16320 : H12AffineFastState.Bounded env16320 := by
  intro p hp
  have h : env16320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16319_16320 : H12AffineEnvironment.transform 14 8581 env16319 = env16320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env16319 == env16320) = true)

def env16321 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8581,65536,1296,9093,1672,8580,1297,909,665,73857,8328,16,9093,1945,1296,73738,1285,74543,256,137,1296,512]

theorem envBound16321 : H12AffineFastState.Bounded env16321 := by
  intro p hp
  have h : env16321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16320_16321 : H12AffineEnvironment.transform 10 0 env16320 = env16321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16320 == env16321) = true)

theorem identity16321 : scanCanonicalize (H12AffineFastState.compose env16321 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound16321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8581,171,1296,9093,1672,8580,1297,909,665,8234,8328,16,9093,1945,1296,8353,1285,9092,256,137,1296,512]

theorem envBound16322 : H12AffineFastState.Bounded env16322 := by
  intro p hp
  have h : env16322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16321_16322 : H12AffineEnvironment.transform 15 171 env16321 = env16322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env16321 == env16322) = true)

theorem identity16322 : scanCanonicalize (H12AffineFastState.compose env16322 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound16322 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,161,1945,292,171,1296,804,1672,293,1297,909,665,139,41,16,804,1945,1296,0,1285,805,256,137,1296,512]

theorem envBound16323 : H12AffineFastState.Bounded env16323 := by
  intro p hp
  have h : env16323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16322_16323 : H12AffineEnvironment.transform 12 161 env16322 = env16323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env16322 == env16323) = true)

def env16324 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1297,161,1297,292,171,1296,428,1024,293,1297,261,17,139,41,16,428,1297,1296,0,1285,429,256,137,1296,136]

theorem envBound16324 : H12AffineFastState.Bounded env16324 := by
  intro p hp
  have h : env16324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16323_16324 : H12AffineEnvironment.transform 8 136 env16323 = env16324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16323 == env16324) = true)

theorem identity16324 : scanCanonicalize (H12AffineFastState.compose env16324 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16325 : List Nat := [2,4,8,16,1,17,128,256,136,1024,0,1297,128,1297,261,138,1296,397,1024,260,1297,261,17,139,8,16,397,1297,1296,0,1285,396,256,137,1296,136]

theorem envBound16325 : H12AffineFastState.Bounded env16325 := by
  intro p hp
  have h : env16325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16324_16325 : H12AffineEnvironment.transform 4 1 env16324 = env16325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16324 == env16325) = true)

def env16326 : List Nat := [2,4,8,16,1,17,8,256,0,1024,0,1297,8,1297,261,2,1296,261,1024,260,1297,261,17,3,8,16,261,1297,1296,0,1285,260,256,1,1296,0]

theorem envBound16326 : H12AffineFastState.Bounded env16326 := by
  intro p hp
  have h : env16326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16325_16326 : H12AffineEnvironment.transform 6 8 env16325 = env16326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16325 == env16326) = true)

def env16327 : List Nat := [2,4,8,16,1,17,9,256,1,1024,0,1297,9,1297,261,3,1296,260,1024,260,1297,261,17,2,8,16,260,1297,1296,0,1285,261,256,0,1296,1]

theorem envBound16327 : H12AffineFastState.Bounded env16327 := by
  intro p hp
  have h : env16327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16325_16327 : H12AffineEnvironment.transform 6 9 env16325 = env16327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16325 == env16327) = true)

theorem identity16327 : scanCanonicalize (H12AffineFastState.compose env16327 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16327 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16328 : List Nat := [2,4,8,16,1,17,9,4,1,1024,0,1045,9,1045,1,3,1044,0,1024,0,1045,1,17,2,8,16,0,1045,1044,0,1025,1,4,0,1044,1]

theorem envBound16328 : H12AffineFastState.Bounded env16328 := by
  intro p hp
  have h : env16328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16327_16328 : H12AffineEnvironment.transform 7 4 env16327 = env16328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16327 == env16328) = true)

def leafEnv16328 : List Nat := [2,4,8,16,1,17,9,4,1,1024,0,1045,9,1045,1,3,1044,0,1024,0,1045,1,17,2,1025,8,1,16,0,1045,1044,0,1025,1,4,0,4,3,1044,1,0,1044,1]

def active16328 : List Nat := [0,1,2,3,9]

def tree16328 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16328 : H12WitnessSearch.Good tree16328 := H12GlobalWitnessIndex.good

theorem leafIdentity16328 : H12AffineFastState.composeSystem env16328 rootObs = leafEnv16328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16328 rootObs == leafEnv16328) = true)

theorem terminalChecked16328 : H12PackedTerminal.terminalCheckFast leafEnv16328 active16328 tree16328 = true := by decide +kernel

def env16329 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,161,1296,292,171,1296,429,1025,293,1297,260,16,139,41,16,429,1296,1296,0,1285,428,256,137,1296,137]

theorem envBound16329 : H12AffineFastState.Bounded env16329 := by
  intro p hp
  have h : env16329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16323_16329 : H12AffineEnvironment.transform 8 137 env16323 = env16329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16323 == env16329) = true)

theorem identity16329 : scanCanonicalize (H12AffineFastState.compose env16329 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound16329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16330 : List Nat := [2,4,8,16,32,17,128,47,137,1024,0,1086,161,1087,11,171,1087,130,1025,10,1086,43,16,139,41,16,130,1087,1087,0,1066,131,47,137,1087,137]

theorem envBound16330 : H12AffineFastState.Bounded env16330 := by
  intro p hp
  have h : env16330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16329_16330 : H12AffineEnvironment.transform 7 47 env16329 = env16330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env16329 == env16330) = true)

theorem identity16330 : scanCanonicalize (H12AffineFastState.compose env16330 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16330 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16331 : List Nat := [2,4,8,16,32,17,9,47,0,1024,0,1086,40,1087,11,34,1087,11,1025,10,1086,43,16,2,41,16,11,1087,1087,0,1066,10,47,0,1087,0]

theorem envBound16331 : H12AffineFastState.Bounded env16331 := by
  intro p hp
  have h : env16331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16330_16331 : H12AffineEnvironment.transform 6 9 env16330 = env16331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16330 == env16331) = true)

def env16332 : List Nat := [2,4,8,16,0,17,9,15,0,1024,0,1054,8,1055,11,2,1055,11,1025,10,1054,11,16,2,9,16,11,1055,1055,0,1034,10,15,0,1055,0]

theorem envBound16332 : H12AffineFastState.Bounded env16332 := by
  intro p hp
  have h : env16332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16331_16332 : H12AffineEnvironment.transform 4 0 env16331 = env16332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16331 == env16332) = true)

theorem identity16332 : scanCanonicalize (H12AffineFastState.compose env16332 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16333 : List Nat := [2,4,8,10,0,11,9,15,0,1024,0,1028,8,1029,11,2,1029,11,1025,10,1028,11,10,2,9,10,11,1029,1029,0,1034,10,15,0,1029,0]

theorem envBound16333 : H12AffineFastState.Bounded env16333 := by
  intro p hp
  have h : env16333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16332_16333 : H12AffineEnvironment.transform 3 10 env16332 = env16333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16332 == env16333) = true)

def leafEnv16333 : List Nat := [2,4,8,10,0,11,9,15,0,1024,0,1028,8,1029,11,2,1029,11,1025,10,1028,11,10,2,1035,9,1,10,11,1029,1029,0,1034,10,15,0,4,2,1029,0,0,1029,1]

def active16333 : List Nat := [0,1,2,9]

def tree16333 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16333 : H12WitnessSearch.Good tree16333 := H12GlobalWitnessIndex.good

theorem leafIdentity16333 : H12AffineFastState.composeSystem env16333 rootObs = leafEnv16333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16333 rootObs == leafEnv16333) = true)

theorem terminalChecked16333 : H12PackedTerminal.terminalCheckFast leafEnv16333 active16333 tree16333 = true := by decide +kernel

def env16334 : List Nat := [2,4,8,16,1,17,9,14,0,1024,0,1055,9,1054,11,3,1054,11,1025,10,1055,10,16,2,8,16,11,1054,1054,0,1035,10,14,0,1054,0]

theorem envBound16334 : H12AffineFastState.Bounded env16334 := by
  intro p hp
  have h : env16334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16331_16334 : H12AffineEnvironment.transform 4 1 env16331 = env16334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16331 == env16334) = true)

theorem identity16334 : scanCanonicalize (H12AffineFastState.compose env16334 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16334 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16335 : List Nat := [2,4,8,1,1,0,9,14,0,1024,0,1038,9,1039,11,3,1039,11,1025,10,1038,10,1,2,8,1,11,1039,1039,0,1035,10,14,0,1039,0]

theorem envBound16335 : H12AffineFastState.Bounded env16335 := by
  intro p hp
  have h : env16335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16334_16335 : H12AffineEnvironment.transform 3 1 env16334 = env16335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16334 == env16335) = true)

def leafEnv16335 : List Nat := [2,4,8,1,1,0,9,14,0,1024,0,1038,9,1039,11,3,1039,11,1025,10,1038,10,1,2,1034,8,1,1,11,1039,1039,0,1035,10,14,0,4,3,1039,0,0,1039,1]

def active16335 : List Nat := [0,1,2,9]

def tree16335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16335 : H12WitnessSearch.Good tree16335 := H12GlobalWitnessIndex.good

theorem leafIdentity16335 : H12AffineFastState.composeSystem env16335 rootObs = leafEnv16335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16335 rootObs == leafEnv16335) = true)

theorem terminalChecked16335 : H12PackedTerminal.terminalCheckFast leafEnv16335 active16335 tree16335 = true := by decide +kernel

def env16336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1945,8581,65536,1296,9093,1672,8580,1297,909,665,73857,8328,16,9093,1945,1296,73739,1285,74543,256,137,1296,512]

theorem envBound16336 : H12AffineFastState.Bounded env16336 := by
  intro p hp
  have h : env16336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16320_16336 : H12AffineEnvironment.transform 10 1 env16320 = env16336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16320 == env16336) = true)

theorem identity16336 : scanCanonicalize (H12AffineFastState.compose env16336 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound16336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16337 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,160,1945,293,65536,1296,805,1672,292,1297,909,665,65569,40,16,805,1945,1296,65707,1285,66447,256,137,1296,512]

theorem envBound16337 : H12AffineFastState.Bounded env16337 := by
  intro p hp
  have h : env16337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16336_16337 : H12AffineEnvironment.transform 12 160 env16336 = env16337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env16336 == env16337) = true)

theorem identity16337 : scanCanonicalize (H12AffineFastState.compose env16337 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound16337 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16338 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,160,1945,293,170,1296,805,1672,292,1297,909,665,139,40,16,805,1945,1296,1,1285,805,256,137,1296,512]

theorem envBound16338 : H12AffineFastState.Bounded env16338 := by
  intro p hp
  have h : env16338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16337_16338 : H12AffineEnvironment.transform 15 170 env16337 = env16338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env16337 == env16338) = true)

def env16339 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1297,160,1297,293,170,1296,429,1024,292,1297,261,17,139,40,16,429,1297,1296,1,1285,429,256,137,1296,136]

theorem envBound16339 : H12AffineFastState.Bounded env16339 := by
  intro p hp
  have h : env16339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16338_16339 : H12AffineEnvironment.transform 8 136 env16338 = env16339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16338 == env16339) = true)

theorem identity16339 : scanCanonicalize (H12AffineFastState.compose env16339 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16340 : List Nat := [2,4,8,16,1,17,128,256,136,1024,1,1297,129,1297,260,139,1296,396,1024,261,1297,261,17,139,9,16,396,1297,1296,1,1285,396,256,137,1296,136]

theorem envBound16340 : H12AffineFastState.Bounded env16340 := by
  intro p hp
  have h : env16340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16339_16340 : H12AffineEnvironment.transform 4 1 env16339 = env16340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16339 == env16340) = true)

def env16341 : List Nat := [2,4,8,16,1,17,8,256,0,1024,1,1297,9,1297,260,3,1296,260,1024,261,1297,261,17,3,9,16,260,1297,1296,1,1285,260,256,1,1296,0]

theorem envBound16341 : H12AffineFastState.Bounded env16341 := by
  intro p hp
  have h : env16341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16340_16341 : H12AffineEnvironment.transform 6 8 env16340 = env16341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16340 == env16341) = true)

def env16342 : List Nat := [2,4,8,16,1,17,9,256,1,1024,1,1297,8,1297,260,2,1296,261,1024,261,1297,261,17,2,9,16,261,1297,1296,1,1285,261,256,0,1296,1]

theorem envBound16342 : H12AffineFastState.Bounded env16342 := by
  intro p hp
  have h : env16342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16340_16342 : H12AffineEnvironment.transform 6 9 env16340 = env16342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16340 == env16342) = true)

theorem identity16342 : scanCanonicalize (H12AffineFastState.compose env16342 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16343 : List Nat := [2,4,8,16,1,17,9,4,1,1024,1,1045,8,1045,0,2,1044,1,1024,1,1045,1,17,2,9,16,1,1045,1044,1,1025,1,4,0,1044,1]

theorem envBound16343 : H12AffineFastState.Bounded env16343 := by
  intro p hp
  have h : env16343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16342_16343 : H12AffineEnvironment.transform 7 4 env16342 = env16343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16342 == env16343) = true)

def leafEnv16343 : List Nat := [2,4,8,16,1,17,9,4,1,1024,1,1045,8,1045,0,2,1044,1,1024,1,1045,1,17,2,1025,9,1,16,1,1045,1044,1,1025,1,4,0,4,2,1044,1,0,1044,1]

def active16343 : List Nat := [0,1,2,3,9]

def tree16343 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16343 : H12WitnessSearch.Good tree16343 := H12GlobalWitnessIndex.good

theorem leafIdentity16343 : H12AffineFastState.composeSystem env16343 rootObs = leafEnv16343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16343 rootObs == leafEnv16343) = true)

theorem terminalChecked16343 : H12PackedTerminal.terminalCheckFast leafEnv16343 active16343 tree16343 = true := by decide +kernel

def env16344 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,160,1296,293,170,1296,428,1025,292,1297,260,16,139,40,16,428,1296,1296,1,1285,428,256,137,1296,137]

theorem envBound16344 : H12AffineFastState.Bounded env16344 := by
  intro p hp
  have h : env16344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16338_16344 : H12AffineEnvironment.transform 8 137 env16338 = env16344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16338 == env16344) = true)

theorem identity16344 : scanCanonicalize (H12AffineFastState.compose env16344 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound16344 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16345 : List Nat := [2,4,8,16,32,17,128,47,137,1024,1,1086,160,1087,10,170,1087,131,1025,11,1086,43,16,139,40,16,131,1087,1087,1,1066,131,47,137,1087,137]

theorem envBound16345 : H12AffineFastState.Bounded env16345 := by
  intro p hp
  have h : env16345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16344_16345 : H12AffineEnvironment.transform 7 47 env16344 = env16345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env16344 == env16345) = true)

theorem identity16345 : scanCanonicalize (H12AffineFastState.compose env16345 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16345 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16346 : List Nat := [2,4,8,16,32,17,9,47,0,1024,1,1086,41,1087,10,35,1087,10,1025,11,1086,43,16,2,40,16,10,1087,1087,1,1066,10,47,0,1087,0]

theorem envBound16346 : H12AffineFastState.Bounded env16346 := by
  intro p hp
  have h : env16346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16345_16346 : H12AffineEnvironment.transform 6 9 env16345 = env16346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16345 == env16346) = true)

def env16347 : List Nat := [2,4,8,16,0,17,9,15,0,1024,1,1054,9,1055,10,3,1055,10,1025,11,1054,11,16,2,8,16,10,1055,1055,1,1034,10,15,0,1055,0]

theorem envBound16347 : H12AffineFastState.Bounded env16347 := by
  intro p hp
  have h : env16347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16346_16347 : H12AffineEnvironment.transform 4 0 env16346 = env16347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16346 == env16347) = true)

theorem identity16347 : scanCanonicalize (H12AffineFastState.compose env16347 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16348 : List Nat := [2,4,8,10,0,11,9,15,0,1024,1,1028,9,1029,10,3,1029,10,1025,11,1028,11,10,2,8,10,10,1029,1029,1,1034,10,15,0,1029,0]

theorem envBound16348 : H12AffineFastState.Bounded env16348 := by
  intro p hp
  have h : env16348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16347_16348 : H12AffineEnvironment.transform 3 10 env16347 = env16348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16347 == env16348) = true)

def leafEnv16348 : List Nat := [2,4,8,10,0,11,9,15,0,1024,1,1028,9,1029,10,3,1029,10,1025,11,1028,11,10,2,1035,8,1,10,10,1029,1029,1,1034,10,15,0,4,3,1029,0,0,1029,1]

def active16348 : List Nat := [0,1,2,9]

def tree16348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16348 : H12WitnessSearch.Good tree16348 := H12GlobalWitnessIndex.good

theorem leafIdentity16348 : H12AffineFastState.composeSystem env16348 rootObs = leafEnv16348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16348 rootObs == leafEnv16348) = true)

theorem terminalChecked16348 : H12PackedTerminal.terminalCheckFast leafEnv16348 active16348 tree16348 = true := by decide +kernel

def env16349 : List Nat := [2,4,8,16,1,17,9,14,0,1024,1,1055,8,1054,10,2,1054,10,1025,11,1055,10,16,2,9,16,10,1054,1054,1,1035,10,14,0,1054,0]

theorem envBound16349 : H12AffineFastState.Bounded env16349 := by
  intro p hp
  have h : env16349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16346_16349 : H12AffineEnvironment.transform 4 1 env16346 = env16349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16346 == env16349) = true)

theorem identity16349 : scanCanonicalize (H12AffineFastState.compose env16349 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16350 : List Nat := [2,4,8,1,1,0,9,14,0,1024,1,1038,8,1039,10,2,1039,10,1025,11,1038,10,1,2,9,1,10,1039,1039,1,1035,10,14,0,1039,0]

theorem envBound16350 : H12AffineFastState.Bounded env16350 := by
  intro p hp
  have h : env16350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16349_16350 : H12AffineEnvironment.transform 3 1 env16349 = env16350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16349 == env16350) = true)

def leafEnv16350 : List Nat := [2,4,8,1,1,0,9,14,0,1024,1,1038,8,1039,10,2,1039,10,1025,11,1038,10,1,2,1034,9,1,1,10,1039,1039,1,1035,10,14,0,4,2,1039,0,0,1039,1]

def active16350 : List Nat := [0,1,2,9]

def tree16350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16350 : H12WitnessSearch.Good tree16350 := H12GlobalWitnessIndex.good

theorem leafIdentity16350 : H12AffineFastState.composeSystem env16350 rootObs = leafEnv16350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16350 rootObs == leafEnv16350) = true)

theorem terminalChecked16350 : H12PackedTerminal.terminalCheckFast leafEnv16350 active16350 tree16350 = true := by decide +kernel

def env16351 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,33281,1672,32769,1297,41480,665,98564,8328,16,9092,1945,1296,75786,1285,98986,256,41228,1296,512]

theorem envBound16351 : H12AffineFastState.Bounded env16351 := by
  intro p hp
  have h : env16351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16318_16351 : H12AffineEnvironment.transform 17 33281 env16318 = env16351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33281 env16318 == env16351) = true)

def env16352 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,41481,665,98564,8328,16,303492,1945,1296,75787,1285,4294967296,256,4295041959,1296,512]

theorem envBound16352 : H12AffineFastState.Bounded env16352 := by
  intro p hp
  have h : env16352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16316_16352 : H12AffineEnvironment.transform 21 41481 env16316 = env16352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41481 env16316 == env16352) = true)

theorem identity16352 : scanCanonicalize (H12AffineFastState.compose env16352 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74662) := by decide +kernel

theorem selectedBound16352 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16353 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,262144,1672,32769,1297,41481,665,98564,8328,16,303492,1945,1296,75787,1285,74662,256,1,1296,512]

theorem envBound16353 : H12AffineFastState.Bounded env16353 := by
  intro p hp
  have h : env16353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16352_16353 : H12AffineEnvironment.transform 31 74662 env16352 = env16353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74662 env16352 == env16353) = true)

def env16354 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,33280,1672,32769,1297,41481,665,98564,8328,16,9092,1945,1296,75787,1285,74662,256,1,1296,512]

theorem envBound16354 : H12AffineFastState.Bounded env16354 := by
  intro p hp
  have h : env16354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16353_16354 : H12AffineEnvironment.transform 17 33280 env16353 = env16354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33280 env16353 == env16354) = true)

def env16355 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1296,33281,1672,32769,1297,41481,665,98564,8328,16,9093,1945,1296,75787,1285,74662,256,1,1296,512]

theorem envBound16355 : H12AffineFastState.Bounded env16355 := by
  intro p hp
  have h : env16355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16353_16355 : H12AffineEnvironment.transform 17 33281 env16353 = env16355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33281 env16353 == env16355) = true)

theorem identity16355 : scanCanonicalize (H12AffineFastState.compose env16355 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound16355 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16356 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,8580,65536,1296,9093,1672,8581,1297,909,665,73856,8328,16,9093,1945,1296,75787,1285,74662,256,1,1296,512]

theorem envBound16356 : H12AffineFastState.Bounded env16356 := by
  intro p hp
  have h : env16356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16355_16356 : H12AffineEnvironment.transform 14 8580 env16355 = env16356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env16355 == env16356) = true)

def env16357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8580,65536,1296,9093,1672,8581,1297,909,665,73856,8328,16,9093,1945,1296,73739,1285,74662,256,1,1296,512]

theorem envBound16357 : H12AffineFastState.Bounded env16357 := by
  intro p hp
  have h : env16357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16356_16357 : H12AffineEnvironment.transform 10 0 env16356 = env16357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16356 == env16357) = true)

theorem identity16357 : scanCanonicalize (H12AffineFastState.compose env16357 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound16357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8580,171,1296,9093,1672,8581,1297,909,665,8235,8328,16,9093,1945,1296,8352,1285,8973,256,1,1296,512]

theorem envBound16358 : H12AffineFastState.Bounded env16358 := by
  intro p hp
  have h : env16358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16357_16358 : H12AffineEnvironment.transform 15 171 env16357 = env16358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env16357 == env16358) = true)

theorem identity16358 : scanCanonicalize (H12AffineFastState.compose env16358 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound16358 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16359 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,160,1945,292,171,1296,805,1672,293,1297,909,665,139,40,16,805,1945,1296,0,1285,941,256,1,1296,512]

theorem envBound16359 : H12AffineFastState.Bounded env16359 := by
  intro p hp
  have h : env16359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16358_16359 : H12AffineEnvironment.transform 12 160 env16358 = env16359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env16358 == env16359) = true)

def env16360 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1297,160,1297,292,171,1296,429,1024,293,1297,261,17,139,40,16,429,1297,1296,0,1285,293,256,1,1296,136]

theorem envBound16360 : H12AffineFastState.Bounded env16360 := by
  intro p hp
  have h : env16360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16359_16360 : H12AffineEnvironment.transform 8 136 env16359 = env16360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16359 == env16360) = true)

theorem identity16360 : scanCanonicalize (H12AffineFastState.compose env16360 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16361 : List Nat := [2,4,8,16,32,17,40,256,32,1024,0,1297,8,1297,292,3,1296,261,1024,293,1297,261,17,35,40,16,261,1297,1296,0,1285,293,256,1,1296,32]

theorem envBound16361 : H12AffineFastState.Bounded env16361 := by
  intro p hp
  have h : env16361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16360_16361 : H12AffineEnvironment.transform 6 40 env16360 = env16361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16360 == env16361) = true)

def env16362 : List Nat := [2,4,8,16,0,17,8,256,0,1024,0,1297,8,1297,260,3,1296,261,1024,261,1297,261,17,3,8,16,261,1297,1296,0,1285,261,256,1,1296,0]

theorem envBound16362 : H12AffineFastState.Bounded env16362 := by
  intro p hp
  have h : env16362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16361_16362 : H12AffineEnvironment.transform 4 0 env16361 = env16362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16361 == env16362) = true)

theorem identity16362 : scanCanonicalize (H12AffineFastState.compose env16362 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16362 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16363 : List Nat := [2,4,8,16,0,17,8,5,0,1024,0,1044,8,1044,1,3,1045,0,1024,0,1044,0,17,3,8,16,0,1044,1045,0,1024,0,5,1,1045,0]

theorem envBound16363 : H12AffineFastState.Bounded env16363 := by
  intro p hp
  have h : env16363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16362_16363 : H12AffineEnvironment.transform 7 5 env16362 = env16363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16362 == env16363) = true)

def leafEnv16363 : List Nat := [2,4,8,16,0,17,8,5,0,1024,0,1044,8,1044,1,3,1045,0,1024,0,1044,0,17,3,1024,8,1,16,0,1044,1045,0,1024,0,5,1,4,2,1045,0,0,1045,1]

def active16363 : List Nat := [0,1,2,3,9]

def tree16363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16363 : H12WitnessSearch.Good tree16363 := H12GlobalWitnessIndex.good

theorem leafIdentity16363 : H12AffineFastState.composeSystem env16363 rootObs = leafEnv16363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16363 rootObs == leafEnv16363) = true)

theorem terminalChecked16363 : H12PackedTerminal.terminalCheckFast leafEnv16363 active16363 tree16363 = true := by decide +kernel

def env16364 : List Nat := [2,4,8,16,1,17,9,256,1,1024,0,1297,8,1297,261,3,1296,261,1024,260,1297,261,17,2,9,16,261,1297,1296,0,1285,260,256,1,1296,1]

theorem envBound16364 : H12AffineFastState.Bounded env16364 := by
  intro p hp
  have h : env16364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16361_16364 : H12AffineEnvironment.transform 4 1 env16361 = env16364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16361 == env16364) = true)

def leafEnv16364 : List Nat := [2,4,8,16,1,17,9,256,1,1024,0,1297,8,1297,261,3,1296,261,1024,260,1297,261,17,2,1285,9,1,16,261,1297,1296,0,1285,260,256,1,4,3,1296,1,0,1296,1]

def active16364 : List Nat := [0,1,2,3,7,9]

def tree16364 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16364 : H12WitnessSearch.Good tree16364 := H12GlobalWitnessIndex.good

theorem leafIdentity16364 : H12AffineFastState.composeSystem env16364 rootObs = leafEnv16364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16364 rootObs == leafEnv16364) = true)

theorem terminalChecked16364 : H12PackedTerminal.terminalCheckFast leafEnv16364 active16364 tree16364 = true := by decide +kernel

def env16365 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,160,1296,292,171,1296,428,1025,293,1297,260,16,139,40,16,428,1296,1296,0,1285,292,256,1,1296,137]

theorem envBound16365 : H12AffineFastState.Bounded env16365 := by
  intro p hp
  have h : env16365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16359_16365 : H12AffineEnvironment.transform 8 137 env16359 = env16365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16359 == env16365) = true)

theorem identity16365 : scanCanonicalize (H12AffineFastState.compose env16365 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound16365 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16366 : List Nat := [2,4,8,16,32,17,128,167,137,1024,0,1206,160,1207,131,171,1207,11,1025,130,1206,163,16,139,40,16,11,1207,1207,0,1186,131,167,1,1207,137]

theorem envBound16366 : H12AffineFastState.Bounded env16366 := by
  intro p hp
  have h : env16366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16365_16366 : H12AffineEnvironment.transform 7 167 env16365 = env16366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env16365 == env16366) = true)

theorem identity16366 : scanCanonicalize (H12AffineFastState.compose env16366 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16366 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16367 : List Nat := [2,4,8,16,32,17,8,47,1,1024,0,1086,40,1087,11,35,1087,11,1025,10,1086,43,16,3,40,16,11,1087,1087,0,1066,11,47,1,1087,1]

theorem envBound16367 : H12AffineFastState.Bounded env16367 := by
  intro p hp
  have h : env16367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16366_16367 : H12AffineEnvironment.transform 6 8 env16366 = env16367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16366 == env16367) = true)

def env16368 : List Nat := [2,4,8,16,0,17,8,15,1,1024,0,1054,8,1055,11,3,1055,11,1025,10,1054,11,16,3,8,16,11,1055,1055,0,1034,11,15,1,1055,1]

theorem envBound16368 : H12AffineFastState.Bounded env16368 := by
  intro p hp
  have h : env16368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16367_16368 : H12AffineEnvironment.transform 4 0 env16367 = env16368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16367 == env16368) = true)

theorem identity16368 : scanCanonicalize (H12AffineFastState.compose env16368 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16369 : List Nat := [2,4,8,0,0,1,8,15,1,1024,0,1038,8,1039,11,3,1039,11,1025,10,1038,11,0,3,8,0,11,1039,1039,0,1034,11,15,1,1039,1]

theorem envBound16369 : H12AffineFastState.Bounded env16369 := by
  intro p hp
  have h : env16369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16368_16369 : H12AffineEnvironment.transform 3 0 env16368 = env16369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16368 == env16369) = true)

def leafEnv16369 : List Nat := [2,4,8,0,0,1,8,15,1,1024,0,1038,8,1039,11,3,1039,11,1025,10,1038,11,0,3,1035,8,1,0,11,1039,1039,0,1034,11,15,1,4,2,1039,1,0,1039,1]

def active16369 : List Nat := [0,1,2,9]

def tree16369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16369 : H12WitnessSearch.Good tree16369 := H12GlobalWitnessIndex.good

theorem leafIdentity16369 : H12AffineFastState.composeSystem env16369 rootObs = leafEnv16369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16369 rootObs == leafEnv16369) = true)

theorem terminalChecked16369 : H12PackedTerminal.terminalCheckFast leafEnv16369 active16369 tree16369 = true := by decide +kernel

def env16370 : List Nat := [2,4,8,16,1,17,8,14,1,1024,0,1055,9,1054,11,2,1054,11,1025,10,1055,10,16,3,9,16,11,1054,1054,0,1035,11,14,1,1054,1]

theorem envBound16370 : H12AffineFastState.Bounded env16370 := by
  intro p hp
  have h : env16370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16367_16370 : H12AffineEnvironment.transform 4 1 env16367 = env16370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16367 == env16370) = true)

theorem identity16370 : scanCanonicalize (H12AffineFastState.compose env16370 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16371 : List Nat := [2,4,8,11,1,10,8,14,1,1024,0,1028,9,1029,11,2,1029,11,1025,10,1028,10,11,3,9,11,11,1029,1029,0,1035,11,14,1,1029,1]

theorem envBound16371 : H12AffineFastState.Bounded env16371 := by
  intro p hp
  have h : env16371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16370_16371 : H12AffineEnvironment.transform 3 11 env16370 = env16371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16370 == env16371) = true)

def leafEnv16371 : List Nat := [2,4,8,11,1,10,8,14,1,1024,0,1028,9,1029,11,2,1029,11,1025,10,1028,10,11,3,1034,9,1,11,11,1029,1029,0,1035,11,14,1,4,3,1029,1,0,1029,1]

def active16371 : List Nat := [0,1,2,9]

def tree16371 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16371 : H12WitnessSearch.Good tree16371 := H12GlobalWitnessIndex.good

theorem leafIdentity16371 : H12AffineFastState.composeSystem env16371 rootObs = leafEnv16371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16371 rootObs == leafEnv16371) = true)

theorem terminalChecked16371 : H12PackedTerminal.terminalCheckFast leafEnv16371 active16371 tree16371 = true := by decide +kernel

def env16372 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1945,8580,65536,1296,9093,1672,8581,1297,909,665,73856,8328,16,9093,1945,1296,73738,1285,74662,256,1,1296,512]

theorem envBound16372 : H12AffineFastState.Bounded env16372 := by
  intro p hp
  have h : env16372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16356_16372 : H12AffineEnvironment.transform 10 1 env16356 = env16372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16356 == env16372) = true)

theorem identity16372 : scanCanonicalize (H12AffineFastState.compose env16372 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound16372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16373 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,161,1945,293,65536,1296,804,1672,292,1297,909,665,65569,41,16,804,1945,1296,65707,1285,66311,256,1,1296,512]

theorem envBound16373 : H12AffineFastState.Bounded env16373 := by
  intro p hp
  have h : env16373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16372_16373 : H12AffineEnvironment.transform 12 161 env16372 = env16373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env16372 == env16373) = true)

theorem identity16373 : scanCanonicalize (H12AffineFastState.compose env16373 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound16373 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16374 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,161,1945,293,170,1296,804,1672,292,1297,909,665,139,41,16,804,1945,1296,1,1285,941,256,1,1296,512]

theorem envBound16374 : H12AffineFastState.Bounded env16374 := by
  intro p hp
  have h : env16374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16373_16374 : H12AffineEnvironment.transform 15 170 env16373 = env16374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env16373 == env16374) = true)

def env16375 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1297,161,1297,293,170,1296,428,1024,292,1297,261,17,139,41,16,428,1297,1296,1,1285,293,256,1,1296,136]

theorem envBound16375 : H12AffineFastState.Bounded env16375 := by
  intro p hp
  have h : env16375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16374_16375 : H12AffineEnvironment.transform 8 136 env16374 = env16375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16374 == env16375) = true)

theorem identity16375 : scanCanonicalize (H12AffineFastState.compose env16375 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16375 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16376 : List Nat := [2,4,8,16,32,17,40,256,32,1024,1,1297,9,1297,293,2,1296,260,1024,292,1297,261,17,35,41,16,260,1297,1296,1,1285,293,256,1,1296,32]

theorem envBound16376 : H12AffineFastState.Bounded env16376 := by
  intro p hp
  have h : env16376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16375_16376 : H12AffineEnvironment.transform 6 40 env16375 = env16376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16375 == env16376) = true)

def env16377 : List Nat := [2,4,8,16,0,17,8,256,0,1024,1,1297,9,1297,261,2,1296,260,1024,260,1297,261,17,3,9,16,260,1297,1296,1,1285,261,256,1,1296,0]

theorem envBound16377 : H12AffineFastState.Bounded env16377 := by
  intro p hp
  have h : env16377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16376_16377 : H12AffineEnvironment.transform 4 0 env16376 = env16377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16376 == env16377) = true)

theorem identity16377 : scanCanonicalize (H12AffineFastState.compose env16377 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16378 : List Nat := [2,4,8,16,0,17,8,5,0,1024,1,1044,9,1044,0,2,1045,1,1024,1,1044,0,17,3,9,16,1,1044,1045,1,1024,0,5,1,1045,0]

theorem envBound16378 : H12AffineFastState.Bounded env16378 := by
  intro p hp
  have h : env16378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16377_16378 : H12AffineEnvironment.transform 7 5 env16377 = env16378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16377 == env16378) = true)

def leafEnv16378 : List Nat := [2,4,8,16,0,17,8,5,0,1024,1,1044,9,1044,0,2,1045,1,1024,1,1044,0,17,3,1024,9,1,16,1,1044,1045,1,1024,0,5,1,4,3,1045,0,0,1045,1]

def active16378 : List Nat := [0,1,2,3,9]

def tree16378 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16378 : H12WitnessSearch.Good tree16378 := H12GlobalWitnessIndex.good

theorem leafIdentity16378 : H12AffineFastState.composeSystem env16378 rootObs = leafEnv16378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16378 rootObs == leafEnv16378) = true)

theorem terminalChecked16378 : H12PackedTerminal.terminalCheckFast leafEnv16378 active16378 tree16378 = true := by decide +kernel

def env16379 : List Nat := [2,4,8,16,1,17,9,256,1,1024,1,1297,9,1297,260,2,1296,260,1024,261,1297,261,17,2,8,16,260,1297,1296,1,1285,260,256,1,1296,1]

theorem envBound16379 : H12AffineFastState.Bounded env16379 := by
  intro p hp
  have h : env16379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16376_16379 : H12AffineEnvironment.transform 4 1 env16376 = env16379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16376 == env16379) = true)

def leafEnv16379 : List Nat := [2,4,8,16,1,17,9,256,1,1024,1,1297,9,1297,260,2,1296,260,1024,261,1297,261,17,2,1285,8,1,16,260,1297,1296,1,1285,260,256,1,4,2,1296,1,0,1296,1]

def active16379 : List Nat := [0,1,2,3,7,9]

def tree16379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16379 : H12WitnessSearch.Good tree16379 := H12GlobalWitnessIndex.good

theorem leafIdentity16379 : H12AffineFastState.composeSystem env16379 rootObs = leafEnv16379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16379 rootObs == leafEnv16379) = true)

theorem terminalChecked16379 : H12PackedTerminal.terminalCheckFast leafEnv16379 active16379 tree16379 = true := by decide +kernel

def env16380 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,161,1296,293,170,1296,429,1025,292,1297,260,16,139,41,16,429,1296,1296,1,1285,292,256,1,1296,137]

theorem envBound16380 : H12AffineFastState.Bounded env16380 := by
  intro p hp
  have h : env16380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16374_16380 : H12AffineEnvironment.transform 8 137 env16374 = env16380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16374 == env16380) = true)

theorem identity16380 : scanCanonicalize (H12AffineFastState.compose env16380 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound16380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16381 : List Nat := [2,4,8,16,32,17,128,167,137,1024,1,1206,161,1207,130,170,1207,10,1025,131,1206,163,16,139,41,16,10,1207,1207,1,1186,131,167,1,1207,137]

theorem envBound16381 : H12AffineFastState.Bounded env16381 := by
  intro p hp
  have h : env16381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16380_16381 : H12AffineEnvironment.transform 7 167 env16380 = env16381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env16380 == env16381) = true)

theorem identity16381 : scanCanonicalize (H12AffineFastState.compose env16381 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16381 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16382 : List Nat := [2,4,8,16,32,17,8,47,1,1024,1,1086,41,1087,10,34,1087,10,1025,11,1086,43,16,3,41,16,10,1087,1087,1,1066,11,47,1,1087,1]

theorem envBound16382 : H12AffineFastState.Bounded env16382 := by
  intro p hp
  have h : env16382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16381_16382 : H12AffineEnvironment.transform 6 8 env16381 = env16382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16381 == env16382) = true)

def env16383 : List Nat := [2,4,8,16,0,17,8,15,1,1024,1,1054,9,1055,10,2,1055,10,1025,11,1054,11,16,3,9,16,10,1055,1055,1,1034,11,15,1,1055,1]

theorem envBound16383 : H12AffineFastState.Bounded env16383 := by
  intro p hp
  have h : env16383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16382_16383 : H12AffineEnvironment.transform 4 0 env16382 = env16383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16382 == env16383) = true)

theorem identity16383 : scanCanonicalize (H12AffineFastState.compose env16383 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16384 : List Nat := [2,4,8,0,0,1,8,15,1,1024,1,1038,9,1039,10,2,1039,10,1025,11,1038,11,0,3,9,0,10,1039,1039,1,1034,11,15,1,1039,1]

theorem envBound16384 : H12AffineFastState.Bounded env16384 := by
  intro p hp
  have h : env16384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16383_16384 : H12AffineEnvironment.transform 3 0 env16383 = env16384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16383 == env16384) = true)

def leafEnv16384 : List Nat := [2,4,8,0,0,1,8,15,1,1024,1,1038,9,1039,10,2,1039,10,1025,11,1038,11,0,3,1035,9,1,0,10,1039,1039,1,1034,11,15,1,4,3,1039,1,0,1039,1]

def active16384 : List Nat := [0,1,2,9]

def tree16384 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16384 : H12WitnessSearch.Good tree16384 := H12GlobalWitnessIndex.good

theorem leafIdentity16384 : H12AffineFastState.composeSystem env16384 rootObs = leafEnv16384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16384 rootObs == leafEnv16384) = true)

theorem terminalChecked16384 : H12PackedTerminal.terminalCheckFast leafEnv16384 active16384 tree16384 = true := by decide +kernel

def env16385 : List Nat := [2,4,8,16,1,17,8,14,1,1024,1,1055,8,1054,10,3,1054,10,1025,11,1055,10,16,3,8,16,10,1054,1054,1,1035,11,14,1,1054,1]

theorem envBound16385 : H12AffineFastState.Bounded env16385 := by
  intro p hp
  have h : env16385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16382_16385 : H12AffineEnvironment.transform 4 1 env16382 = env16385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16382 == env16385) = true)

theorem identity16385 : scanCanonicalize (H12AffineFastState.compose env16385 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16385 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16386 : List Nat := [2,4,8,11,1,10,8,14,1,1024,1,1028,8,1029,10,3,1029,10,1025,11,1028,10,11,3,8,11,10,1029,1029,1,1035,11,14,1,1029,1]

theorem envBound16386 : H12AffineFastState.Bounded env16386 := by
  intro p hp
  have h : env16386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16385_16386 : H12AffineEnvironment.transform 3 11 env16385 = env16386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16385 == env16386) = true)

def leafEnv16386 : List Nat := [2,4,8,11,1,10,8,14,1,1024,1,1028,8,1029,10,3,1029,10,1025,11,1028,10,11,3,1034,8,1,11,10,1029,1029,1,1035,11,14,1,4,2,1029,1,0,1029,1]

def active16386 : List Nat := [0,1,2,9]

def tree16386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16386 : H12WitnessSearch.Good tree16386 := H12GlobalWitnessIndex.good

theorem leafIdentity16386 : H12AffineFastState.composeSystem env16386 rootObs = leafEnv16386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16386 rootObs == leafEnv16386) = true)

theorem terminalChecked16386 : H12PackedTerminal.terminalCheckFast leafEnv16386 active16386 tree16386 = true := by decide +kernel

def env16387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1073741824,1285,4294967296,256,4299260334,138690900,512]

theorem envBound16387 : H12AffineFastState.Bounded env16387 := by
  intro p hp
  have h : env16387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16260_16387 : H12AffineEnvironment.transform 11 1345 env16260 = env16387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env16260 == env16387) = true)

def env16388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1073741824,1285,4294967296,256,4299260334,138429268,512]

theorem envBound16388 : H12AffineFastState.Bounded env16388 := by
  intro p hp
  have h : env16388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16387_16388 : H12AffineEnvironment.transform 17 512 env16387 = env16388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env16387 == env16388) = true)

def env16389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,0,1285,4294967296,256,4299260334,138429268,512]

theorem envBound16389 : H12AffineFastState.Bounded env16389 := by
  intro p hp
  have h : env16389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16388_16389 : H12AffineEnvironment.transform 29 0 env16388 = env16389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env16388 == env16389) = true)

def env16390 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,32768,65536,1345,0,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,0,1285,4294967296,256,4299260334,138428756,0]

theorem envBound16390 : H12AffineFastState.Bounded env16390 := by
  intro p hp
  have h : env16390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16389_16390 : H12AffineEnvironment.transform 8 0 env16389 = env16390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16389 == env16390) = true)

theorem identity16390 : scanCanonicalize (H12AffineFastState.compose env16390 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 35108) := by decide +kernel

theorem selectedBound16390 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env16391 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,32768,65536,1345,0,16656,32769,1345,4194304,17664,98564,8328,64,35108,16384,1296,0,1285,4294967296,256,4299260334,4245616,0]

theorem envBound16391 : H12AffineFastState.Bounded env16391 := by
  intro p hp
  have h : env16391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16390_16391 : H12AffineEnvironment.transform 26 35108 env16390 = env16391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 35108 env16390 == env16391) = true)

theorem identity16391 : scanCanonicalize (H12AffineFastState.compose env16391 (packedSelected [23] rootPS)) = affineNative (2^(14+1) ^^^ 27961) := by decide +kernel

theorem selectedBound16391 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env16392 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,27961,65536,1345,0,16656,27960,1345,4194304,17664,93245,8328,64,25629,16384,1296,0,1285,4294967296,256,4299254935,4203849,0]

theorem envBound16392 : H12AffineFastState.Bounded env16392 := by
  intro p hp
  have h : env16392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16391_16392 : H12AffineEnvironment.transform 14 27961 env16391 = env16392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27961 env16391 == env16392) = true)

theorem identity16392 : scanCanonicalize (H12AffineFastState.compose env16392 (packedSelected [0,1,4,7,9,11,12,13,21,28,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 11293) := by decide +kernel

theorem selectedBound16392 : packedSelected [0,1,4,7,9,11,12,13,21,28,32,38] rootPS < 2^1333 := by decide +kernel

def env16393 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,11293,292,65536,1345,0,11533,293,1345,4194304,10525,65568,8328,64,2048,11293,1296,0,1285,4294967296,256,4299227274,4203849,0]

theorem envBound16393 : H12AffineFastState.Bounded env16393 := by
  intro p hp
  have h : env16393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16392_16393 : H12AffineEnvironment.transform 13 11293 env16392 = env16393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11293 env16392 == env16393) = true)

theorem identity16393 : scanCanonicalize (H12AffineFastState.compose env16393 (packedSelected [0,3,7,8,10,19,20,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound16393 : packedSelected [0,3,7,8,10,19,20,28] rootPS < 2^1333 := by decide +kernel

def env16394 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,11293,292,65536,1345,0,11533,293,1345,8200,10525,65568,8328,64,2048,11293,1296,0,1285,4294967296,256,4295041154,1345,0]

theorem envBound16394 : H12AffineFastState.Bounded env16394 := by
  intro p hp
  have h : env16394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16393_16394 : H12AffineEnvironment.transform 21 8200 env16393 = env16394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env16393 == env16394) = true)

theorem identity16394 : scanCanonicalize (H12AffineFastState.compose env16394 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16395 : List Nat := [2,4,8,16,32,64,128,256,0,1024,0,1345,8192,9245,292,65536,1345,0,9485,293,1345,8200,8477,65568,8328,64,0,9245,1296,0,1285,4294967296,256,4295041154,1345,0]

theorem envBound16395 : H12AffineFastState.Bounded env16395 := by
  intro p hp
  have h : env16395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16394_16395 : H12AffineEnvironment.transform 10 0 env16394 = env16395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16394 == env16395) = true)

def env16396 : List Nat := [2,4,8,16,32,64,128,36,0,1024,0,1125,8192,9245,0,65536,1125,0,9257,1,1125,8200,8249,65568,8328,64,0,9245,1076,0,1057,4294967296,36,4295041154,1125,0]

theorem envBound16396 : H12AffineFastState.Bounded env16396 := by
  intro p hp
  have h : env16396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16395_16396 : H12AffineEnvironment.transform 7 36 env16395 = env16396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16395 == env16396) = true)

theorem identity16396 : scanCanonicalize (H12AffineFastState.compose env16396 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound16396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16397 : List Nat := [2,4,8,16,32,64,128,36,0,1024,0,1125,8192,9245,0,65536,1125,0,9257,1,1125,8200,8249,65568,8328,64,0,9245,1076,0,1057,136,36,73738,1125,0]

theorem envBound16397 : H12AffineFastState.Bounded env16397 := by
  intro p hp
  have h : env16397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16396_16397 : H12AffineEnvironment.transform 31 136 env16396 = env16397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env16396 == env16397) = true)

def env16398 : List Nat := [2,4,8,16,32,64,128,36,0,1024,0,1125,224,1277,0,65536,1125,0,1225,1,1125,232,217,65568,104,64,0,1277,1076,0,1057,136,36,65770,1125,0]

theorem envBound16398 : H12AffineFastState.Bounded env16398 := by
  intro p hp
  have h : env16398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16397_16398 : H12AffineEnvironment.transform 12 224 env16397 = env16398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env16397 == env16398) = true)

theorem identity16398 : scanCanonicalize (H12AffineFastState.compose env16398 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16399 : List Nat := [2,4,8,16,32,64,9,36,0,1024,0,1125,105,1140,0,65536,1125,0,1088,1,1125,97,80,65568,104,64,0,1140,1076,0,1057,1,36,65635,1125,0]

theorem envBound16399 : H12AffineFastState.Bounded env16399 := by
  intro p hp
  have h : env16399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16398_16399 : H12AffineEnvironment.transform 6 9 env16398 = env16399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16398 == env16399) = true)

theorem identity16399 : scanCanonicalize (H12AffineFastState.compose env16399 (packedSelected [4,5,6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound16399 : packedSelected [4,5,6] rootPS < 2^1333 := by decide +kernel

def env16400 : List Nat := [2,4,8,16,32,64,9,36,0,1024,0,1125,105,1140,0,34,1125,0,1088,1,1125,97,80,2,104,64,0,1140,1076,0,1057,1,36,65,1125,0]

theorem envBound16400 : H12AffineFastState.Bounded env16400 := by
  intro p hp
  have h : env16400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16399_16400 : H12AffineEnvironment.transform 15 34 env16399 = env16400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env16399 == env16400) = true)

theorem identity16400 : scanCanonicalize (H12AffineFastState.compose env16400 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16400 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16401 : List Nat := [2,4,8,16,32,1,9,36,0,1024,0,1060,40,1077,0,34,1060,0,1025,1,1060,32,17,2,41,1,0,1077,1076,0,1057,1,36,0,1060,0]

theorem envBound16401 : H12AffineFastState.Bounded env16401 := by
  intro p hp
  have h : env16401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16400_16401 : H12AffineEnvironment.transform 5 1 env16400 = env16401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16400 == env16401) = true)

theorem identity16401 : scanCanonicalize (H12AffineFastState.compose env16401 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16401 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16402 : List Nat := [2,4,8,10,32,1,9,36,0,1024,0,1060,40,1071,0,34,1060,0,1025,1,1060,32,11,2,41,1,0,1071,1070,0,1057,1,36,0,1060,0]

theorem envBound16402 : H12AffineFastState.Bounded env16402 := by
  intro p hp
  have h : env16402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16401_16402 : H12AffineEnvironment.transform 3 10 env16401 = env16402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16401 == env16402) = true)

def leafEnv16402 : List Nat := [2,4,8,10,32,1,9,36,0,1024,0,1060,40,1071,0,34,1060,0,1025,1,1060,32,11,2,1056,41,1,1,0,1071,1070,0,1057,1,36,0,4,34,1060,0,0,1070,1]

def active16402 : List Nat := [0,1,2,4,9]

def tree16402 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16402 : H12WitnessSearch.Good tree16402 := H12GlobalWitnessIndex.good

theorem leafIdentity16402 : H12AffineFastState.composeSystem env16402 rootObs = leafEnv16402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16402 rootObs == leafEnv16402) = true)

theorem terminalChecked16402 : H12PackedTerminal.terminalCheckFast leafEnv16402 active16402 tree16402 = true := by decide +kernel

def env16403 : List Nat := [2,4,8,16,32,64,128,36,0,1024,0,1125,225,1276,0,65536,1125,0,1224,1,1125,233,216,65568,105,64,0,1276,1076,0,1057,136,36,65771,1125,0]

theorem envBound16403 : H12AffineFastState.Bounded env16403 := by
  intro p hp
  have h : env16403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16397_16403 : H12AffineEnvironment.transform 12 225 env16397 = env16403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env16397 == env16403) = true)

theorem identity16403 : scanCanonicalize (H12AffineFastState.compose env16403 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16404 : List Nat := [2,4,8,16,32,1,128,36,0,1024,0,1060,160,1213,0,65536,1060,0,1161,1,1060,168,153,65568,40,1,0,1213,1076,0,1057,136,36,65706,1060,0]

theorem envBound16404 : H12AffineFastState.Bounded env16404 := by
  intro p hp
  have h : env16404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16403_16404 : H12AffineEnvironment.transform 5 1 env16403 = env16404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16403 == env16404) = true)

theorem identity16404 : scanCanonicalize (H12AffineFastState.compose env16404 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound16404 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env16405 : List Nat := [2,4,8,16,32,1,128,36,0,1024,0,1060,160,1213,0,171,1060,0,1161,1,1060,168,153,139,40,1,0,1213,1076,0,1057,136,36,1,1060,0]

theorem envBound16405 : H12AffineFastState.Bounded env16405 := by
  intro p hp
  have h : env16405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16404_16405 : H12AffineEnvironment.transform 15 171 env16404 = env16405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env16404 == env16405) = true)

theorem identity16405 : scanCanonicalize (H12AffineFastState.compose env16405 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16405 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16406 : List Nat := [2,4,8,16,32,1,9,36,0,1024,0,1060,41,1076,0,34,1060,0,1024,1,1060,33,16,2,40,1,0,1076,1076,0,1057,1,36,1,1060,0]

theorem envBound16406 : H12AffineFastState.Bounded env16406 := by
  intro p hp
  have h : env16406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16405_16406 : H12AffineEnvironment.transform 6 9 env16405 = env16406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16405 == env16406) = true)

theorem identity16406 : scanCanonicalize (H12AffineFastState.compose env16406 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16406 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16407 : List Nat := [2,4,8,16,17,1,9,21,0,1024,0,1045,24,1029,0,19,1045,0,1024,1,1045,16,16,2,25,1,0,1029,1029,0,1040,1,21,1,1045,0]

theorem envBound16407 : H12AffineFastState.Bounded env16407 := by
  intro p hp
  have h : env16407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16406_16407 : H12AffineEnvironment.transform 4 17 env16406 = env16407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16406 == env16407) = true)

def env16408 : List Nat := [2,4,8,16,32,64,128,37,0,1024,0,1124,8192,9245,1,65536,1124,0,9256,0,1124,8200,8248,65568,8328,64,0,9245,1077,0,1056,4294967296,37,4295041154,1124,0]

theorem envBound16408 : H12AffineFastState.Bounded env16408 := by
  intro p hp
  have h : env16408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16395_16408 : H12AffineEnvironment.transform 7 37 env16395 = env16408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16395 == env16408) = true)

theorem identity16408 : scanCanonicalize (H12AffineFastState.compose env16408 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound16408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16409 : List Nat := [2,4,8,16,32,64,128,37,0,1024,0,1124,8192,9245,1,65536,1124,0,9256,0,1124,8200,8248,65568,8328,64,0,9245,1077,0,1056,65706,37,8232,1124,0]

theorem envBound16409 : H12AffineFastState.Bounded env16409 := by
  intro p hp
  have h : env16409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16408_16409 : H12AffineEnvironment.transform 31 65706 env16408 = env16409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env16408 == env16409) = true)

theorem identity16409 : scanCanonicalize (H12AffineFastState.compose env16409 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound16409 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env16410 : List Nat := [2,4,8,16,32,64,128,37,0,1024,0,1124,40,1077,1,65536,1124,0,1024,0,1124,32,16,65568,160,64,0,1077,1077,0,1056,65706,37,0,1124,0]

theorem envBound16410 : H12AffineFastState.Bounded env16410 := by
  intro p hp
  have h : env16410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16409_16410 : H12AffineEnvironment.transform 12 40 env16409 = env16410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env16409 == env16410) = true)

theorem identity16410 : scanCanonicalize (H12AffineFastState.compose env16410 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16410 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env16411 : List Nat := [2,4,8,16,1,64,128,4,0,1024,0,1093,9,1044,1,65536,1093,0,1024,0,1093,1,16,65537,129,64,0,1044,1044,0,1025,65675,4,0,1093,0]

theorem envBound16411 : H12AffineFastState.Bounded env16411 := by
  intro p hp
  have h : env16411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16410_16411 : H12AffineEnvironment.transform 4 1 env16410 = env16411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16410 == env16411) = true)

theorem identity16411 : scanCanonicalize (H12AffineFastState.compose env16411 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound16411 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16412 : List Nat := [2,4,8,16,1,64,128,4,0,1024,0,1093,9,1044,1,2,1093,0,1024,0,1093,1,16,3,129,64,0,1044,1044,0,1025,137,4,0,1093,0]

theorem envBound16412 : H12AffineFastState.Bounded env16412 := by
  intro p hp
  have h : env16412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16411_16412 : H12AffineEnvironment.transform 15 2 env16411 = env16412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env16411 == env16412) = true)

theorem identity16412 : scanCanonicalize (H12AffineFastState.compose env16412 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16413 : List Nat := [2,4,8,16,1,64,8,4,0,1024,0,1093,9,1044,1,2,1093,0,1024,0,1093,1,16,3,9,64,0,1044,1044,0,1025,1,4,0,1093,0]

theorem envBound16413 : H12AffineFastState.Bounded env16413 := by
  intro p hp
  have h : env16413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16412_16413 : H12AffineEnvironment.transform 6 8 env16412 = env16413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16412 == env16413) = true)

def leafEnv16413 : List Nat := [2,4,8,16,1,64,8,4,0,1024,0,1093,9,1044,1,2,1093,0,1024,0,1093,1,16,3,1025,9,1,64,0,1044,1044,0,1025,1,4,0,4,3,1093,0,0,1044,1]

def active16413 : List Nat := [0,1,2,3,5,9]

end H12CloudChart2