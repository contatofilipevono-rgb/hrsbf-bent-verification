import H12CloudChart2Data081

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans20125_20126 : H12AffineEnvironment.transform 31 0 env20125 = env20126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20125 == env20126) = true)

def env20127 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,128,0,0,65536,1,137,20,1,0,137,17,65536,8,16,1,1,1,136,20,0,5,65539,0,136]

theorem envBound20127 : H12AffineFastState.Bounded env20127 := by
  intro p hp
  have h : env20127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20127 : H12AffineEnvironment.transform 4 0 env20126 = env20127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20126 == env20127) = true)

theorem identity20127 : scanCanonicalize (H12AffineFastState.compose env20127 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20128 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,0,65536,1,1,20,1,0,1,17,65536,8,16,1,1,1,0,20,0,5,65539,0,0]

theorem envBound20128 : H12AffineFastState.Bounded env20128 := by
  intro p hp
  have h : env20128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20127_20128 : H12AffineEnvironment.transform 6 8 env20127 = env20128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20127 == env20128) = true)

theorem identity20128 : scanCanonicalize (H12AffineFastState.compose env20128 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound20128 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20129 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,0,3,1,1,20,1,0,1,17,3,8,16,1,1,1,0,20,0,5,0,0,0]

theorem envBound20129 : H12AffineFastState.Bounded env20129 := by
  intro p hp
  have h : env20129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20128_20129 : H12AffineEnvironment.transform 15 3 env20128 = env20129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env20128 == env20129) = true)

def leafEnv20129 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,1,8,0,0,3,1,1,20,1,0,1,17,3,21,8,1,16,1,1,1,0,20,0,5,0,5,2,0,0,0,0,1]

def active20129 : List Nat := [0,1,2,3]

def tree20129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20129 : H12WitnessSearch.Good tree20129 := H12GlobalWitnessIndex.good

theorem leafIdentity20129 : H12AffineFastState.composeSystem env20129 rootObs = leafEnv20129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20129 rootObs == leafEnv20129) = true)

theorem terminalChecked20129 : H12PackedTerminal.terminalCheckFast leafEnv20129 active20129 tree20129 = true := by decide +kernel

def env20130 : List Nat := [2,4,8,16,1,17,128,5,136,20,0,1,129,0,0,65536,1,137,21,1,0,136,17,65537,9,16,1,1,1,136,20,0,4,65538,0,136]

theorem envBound20130 : H12AffineFastState.Bounded env20130 := by
  intro p hp
  have h : env20130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20130 : H12AffineEnvironment.transform 4 1 env20126 = env20130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20126 == env20130) = true)

theorem identity20130 : scanCanonicalize (H12AffineFastState.compose env20130 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20130 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20131 : List Nat := [2,4,8,16,1,17,8,5,0,20,0,1,9,0,0,65536,1,1,21,1,0,0,17,65537,9,16,1,1,1,0,20,0,4,65538,0,0]

theorem envBound20131 : H12AffineFastState.Bounded env20131 := by
  intro p hp
  have h : env20131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20130_20131 : H12AffineEnvironment.transform 6 8 env20130 = env20131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20130 == env20131) = true)

def leafEnv20131 : List Nat := [2,4,8,16,1,17,8,5,0,20,0,1,9,0,0,65536,1,1,21,1,0,0,17,65537,21,9,1,16,1,1,1,0,20,0,4,65538,5,3,0,0,0,0,1]

def active20131 : List Nat := [0,1,2,3,15]

def tree20131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20131 : H12WitnessSearch.Good tree20131 := H12GlobalWitnessIndex.good

theorem leafIdentity20131 : H12AffineFastState.composeSystem env20131 rootObs = leafEnv20131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20131 rootObs == leafEnv20131) = true)

theorem terminalChecked20131 : H12PackedTerminal.terminalCheckFast leafEnv20131 active20131 tree20131 = true := by decide +kernel

def env20132 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,161,0,0,65536,1,136,52,1,0,168,17,65568,41,16,1,1,1,137,20,4294967296,37,4295032866,0,136]

theorem envBound20132 : H12AffineFastState.Bounded env20132 := by
  intro p hp
  have h : env20132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20124_20132 : H12AffineEnvironment.transform 12 161 env20124 = env20132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20124 == env20132) = true)

theorem identity20132 : scanCanonicalize (H12AffineFastState.compose env20132 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound20132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20133 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,161,0,0,65536,1,136,52,1,0,168,17,65568,41,16,1,1,1,137,20,136,37,65706,0,136]

theorem envBound20133 : H12AffineFastState.Bounded env20133 := by
  intro p hp
  have h : env20133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20132_20133 : H12AffineEnvironment.transform 31 136 env20132 = env20133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env20132 == env20133) = true)

def env20134 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,1,41,0,0,65536,1,0,52,1,0,32,17,65568,41,16,1,1,1,1,20,0,37,65570,0,0]

theorem envBound20134 : H12AffineFastState.Bounded env20134 := by
  intro p hp
  have h : env20134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20133_20134 : H12AffineEnvironment.transform 6 8 env20133 = env20134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20133 == env20134) = true)

theorem identity20134 : scanCanonicalize (H12AffineFastState.compose env20134 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound20134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20135 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,1,41,0,0,3,1,0,52,1,0,32,17,35,41,16,1,1,1,1,20,0,37,33,0,0]

theorem envBound20135 : H12AffineFastState.Bounded env20135 := by
  intro p hp
  have h : env20135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20134_20135 : H12AffineEnvironment.transform 15 3 env20134 = env20135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env20134 == env20135) = true)

def env20136 : List Nat := [2,4,8,16,32,17,9,36,1,53,0,1,40,0,0,65536,1,1,52,1,0,33,17,65568,41,16,1,1,1,0,20,1,37,65571,0,1]

theorem envBound20136 : H12AffineFastState.Bounded env20136 := by
  intro p hp
  have h : env20136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20133_20136 : H12AffineEnvironment.transform 6 9 env20133 = env20136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20133 == env20136) = true)

def env20137 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,8,0,0,65536,1,1,20,1,0,1,17,65536,9,16,1,1,1,0,20,1,5,65539,0,1]

theorem envBound20137 : H12AffineFastState.Bounded env20137 := by
  intro p hp
  have h : env20137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20136_20137 : H12AffineEnvironment.transform 4 0 env20136 = env20137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20136 == env20137) = true)

theorem identity20137 : scanCanonicalize (H12AffineFastState.compose env20137 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound20137 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20138 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,8,0,0,2,1,1,20,1,0,1,17,2,9,16,1,1,1,0,20,1,5,1,0,1]

theorem envBound20138 : H12AffineFastState.Bounded env20138 := by
  intro p hp
  have h : env20138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20137_20138 : H12AffineEnvironment.transform 15 2 env20137 = env20138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env20137 == env20138) = true)

def leafEnv20138 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,8,0,0,2,1,1,20,1,0,1,17,2,21,9,1,16,1,1,1,0,20,1,5,1,5,2,0,1,0,0,1]

def active20138 : List Nat := [0,1,2,3]

def tree20138 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20138 : H12WitnessSearch.Good tree20138 := H12GlobalWitnessIndex.good

theorem leafIdentity20138 : H12AffineFastState.composeSystem env20138 rootObs = leafEnv20138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20138 rootObs == leafEnv20138) = true)

theorem terminalChecked20138 : H12PackedTerminal.terminalCheckFast leafEnv20138 active20138 tree20138 = true := by decide +kernel

def env20139 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,1,9,0,0,65536,1,1,21,1,0,0,17,65537,8,16,1,1,1,0,20,1,4,65538,0,1]

theorem envBound20139 : H12AffineFastState.Bounded env20139 := by
  intro p hp
  have h : env20139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20136_20139 : H12AffineEnvironment.transform 4 1 env20136 = env20139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20136 == env20139) = true)

def leafEnv20139 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,1,9,0,0,65536,1,1,21,1,0,0,17,65537,21,8,1,16,1,1,1,0,20,1,4,65538,5,3,0,1,0,0,1]

def active20139 : List Nat := [0,1,2,3,15]

def tree20139 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20139 : H12WitnessSearch.Good tree20139 := H12GlobalWitnessIndex.good

theorem leafIdentity20139 : H12AffineFastState.composeSystem env20139 rootObs = leafEnv20139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20139 rootObs == leafEnv20139) = true)

theorem terminalChecked20139 : H12PackedTerminal.terminalCheckFast leafEnv20139 active20139 tree20139 = true := by decide +kernel

def env20140 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,8192,0,1,65536,1,8232,53,0,0,8201,17,65568,8328,16,1,1,1,8233,20,4294967296,36,4295041155,0,136]

theorem envBound20140 : H12AffineFastState.Bounded env20140 := by
  intro p hp
  have h : env20140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20123_20140 : H12AffineEnvironment.transform 7 37 env20123 = env20140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20123 == env20140) = true)

def env20141 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,160,0,1,65536,1,136,53,0,0,169,17,65568,40,16,1,1,1,137,20,4294967296,36,4295032867,0,136]

theorem envBound20141 : H12AffineFastState.Bounded env20141 := by
  intro p hp
  have h : env20141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20140_20141 : H12AffineEnvironment.transform 12 160 env20140 = env20141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20140 == env20141) = true)

theorem identity20141 : scanCanonicalize (H12AffineFastState.compose env20141 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound20141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20142 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,160,0,1,65536,1,136,53,0,0,169,17,65568,40,16,1,1,1,137,20,65571,36,0,0,136]

theorem envBound20142 : H12AffineFastState.Bounded env20142 := by
  intro p hp
  have h : env20142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20141_20142 : H12AffineEnvironment.transform 31 65571 env20141 = env20142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env20141 == env20142) = true)

def env20143 : List Nat := [2,4,8,16,0,17,128,5,136,20,0,1,128,0,1,65536,1,136,21,0,0,137,17,65536,8,16,1,1,1,137,20,65539,4,0,0,136]

theorem envBound20143 : H12AffineFastState.Bounded env20143 := by
  intro p hp
  have h : env20143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20142_20143 : H12AffineEnvironment.transform 4 0 env20142 = env20143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20142 == env20143) = true)

theorem identity20143 : scanCanonicalize (H12AffineFastState.compose env20143 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound20143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20144 : List Nat := [2,4,8,16,0,17,128,5,136,20,0,1,128,0,1,138,1,136,21,0,0,137,17,138,8,16,1,1,1,137,20,137,4,0,0,136]

theorem envBound20144 : H12AffineFastState.Bounded env20144 := by
  intro p hp
  have h : env20144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20143_20144 : H12AffineEnvironment.transform 15 138 env20143 = env20144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env20143 == env20144) = true)

theorem identity20144 : scanCanonicalize (H12AffineFastState.compose env20144 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20144 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20145 : List Nat := [2,4,8,16,0,17,9,5,1,20,0,1,9,0,1,3,1,1,21,0,0,0,17,3,8,16,1,1,1,0,20,0,4,0,0,1]

theorem envBound20145 : H12AffineFastState.Bounded env20145 := by
  intro p hp
  have h : env20145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20144_20145 : H12AffineEnvironment.transform 6 9 env20144 = env20145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20144 == env20145) = true)

def leafEnv20145 : List Nat := [2,4,8,16,0,17,9,5,1,20,0,1,9,0,1,3,1,1,21,0,0,0,17,3,21,8,1,16,1,1,1,0,20,0,4,0,5,2,0,1,0,0,1]

def active20145 : List Nat := [0,1,2,3]

def tree20145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20145 : H12WitnessSearch.Good tree20145 := H12GlobalWitnessIndex.good

theorem leafIdentity20145 : H12AffineFastState.composeSystem env20145 rootObs = leafEnv20145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20145 rootObs == leafEnv20145) = true)

theorem terminalChecked20145 : H12PackedTerminal.terminalCheckFast leafEnv20145 active20145 tree20145 = true := by decide +kernel

def env20146 : List Nat := [2,4,8,16,1,17,128,4,136,21,0,1,129,0,1,65536,1,136,20,0,0,136,17,65537,9,16,1,1,1,137,20,65538,5,0,0,136]

theorem envBound20146 : H12AffineFastState.Bounded env20146 := by
  intro p hp
  have h : env20146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20142_20146 : H12AffineEnvironment.transform 4 1 env20142 = env20146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20142 == env20146) = true)

theorem identity20146 : scanCanonicalize (H12AffineFastState.compose env20146 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound20146 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20147 : List Nat := [2,4,8,16,1,17,128,4,136,21,0,1,129,0,1,3,1,136,20,0,0,136,17,2,9,16,1,1,1,137,20,1,5,0,0,136]

theorem envBound20147 : H12AffineFastState.Bounded env20147 := by
  intro p hp
  have h : env20147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20146_20147 : H12AffineEnvironment.transform 15 3 env20146 = env20147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env20146 == env20147) = true)

def leafEnv20147 : List Nat := [2,4,8,16,1,17,128,4,136,21,0,1,129,0,1,3,1,136,20,0,0,136,17,2,21,9,1,16,1,1,1,137,20,1,5,0,5,3,0,136,0,0,1]

def active20147 : List Nat := [0,1,2,3,6]

def tree20147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20147 : H12WitnessSearch.Good tree20147 := H12GlobalWitnessIndex.good

theorem leafIdentity20147 : H12AffineFastState.composeSystem env20147 rootObs = leafEnv20147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20147 rootObs == leafEnv20147) = true)

theorem terminalChecked20147 : H12PackedTerminal.terminalCheckFast leafEnv20147 active20147 tree20147 = true := by decide +kernel

def env20148 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,161,0,1,65536,1,137,53,0,0,168,17,65568,41,16,1,1,1,136,20,4294967296,36,4295032866,0,136]

theorem envBound20148 : H12AffineFastState.Bounded env20148 := by
  intro p hp
  have h : env20148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20140_20148 : H12AffineEnvironment.transform 12 161 env20140 = env20148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20140 == env20148) = true)

theorem identity20148 : scanCanonicalize (H12AffineFastState.compose env20148 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound20148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20149 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,161,0,1,65536,1,137,53,0,0,168,17,65568,41,16,1,1,1,136,20,65706,36,136,0,136]

theorem envBound20149 : H12AffineFastState.Bounded env20149 := by
  intro p hp
  have h : env20149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20148_20149 : H12AffineEnvironment.transform 31 65706 env20148 = env20149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env20148 == env20149) = true)

def env20150 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,41,0,1,65536,1,1,53,0,0,32,17,65568,41,16,1,1,1,0,20,65570,36,0,0,0]

theorem envBound20150 : H12AffineFastState.Bounded env20150 := by
  intro p hp
  have h : env20150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20149_20150 : H12AffineEnvironment.transform 6 8 env20149 = env20150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20149 == env20150) = true)

theorem identity20150 : scanCanonicalize (H12AffineFastState.compose env20150 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20151 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,9,0,1,65536,1,1,21,0,0,0,17,65536,9,16,1,1,1,0,20,65538,4,0,0,0]

theorem envBound20151 : H12AffineFastState.Bounded env20151 := by
  intro p hp
  have h : env20151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20150_20151 : H12AffineEnvironment.transform 4 0 env20150 = env20151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20150 == env20151) = true)

def leafEnv20151 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,9,0,1,65536,1,1,21,0,0,0,17,65536,21,9,1,16,1,1,1,0,20,65538,4,0,5,2,0,0,0,0,1]

def active20151 : List Nat := [0,1,2,3,15]

def tree20151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20151 : H12WitnessSearch.Good tree20151 := H12GlobalWitnessIndex.good

theorem leafIdentity20151 : H12AffineFastState.composeSystem env20151 rootObs = leafEnv20151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20151 rootObs == leafEnv20151) = true)

theorem terminalChecked20151 : H12PackedTerminal.terminalCheckFast leafEnv20151 active20151 tree20151 = true := by decide +kernel

def env20152 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,40,0,1,65536,1,0,53,0,0,33,17,65568,41,16,1,1,1,1,20,65571,36,1,0,1]

theorem envBound20152 : H12AffineFastState.Bounded env20152 := by
  intro p hp
  have h : env20152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20149_20152 : H12AffineEnvironment.transform 6 9 env20149 = env20152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20149 == env20152) = true)

theorem identity20152 : scanCanonicalize (H12AffineFastState.compose env20152 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound20152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20153 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,40,0,1,35,1,0,53,0,0,33,17,3,41,16,1,1,1,1,20,0,36,1,0,1]

theorem envBound20153 : H12AffineFastState.Bounded env20153 := by
  intro p hp
  have h : env20153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20152_20153 : H12AffineEnvironment.transform 15 35 env20152 = env20153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env20152 == env20153) = true)

theorem identity20153 : scanCanonicalize (H12AffineFastState.compose env20153 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20153 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20154 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,9,0,1,2,1,0,20,0,0,0,17,3,8,16,1,1,1,1,20,0,5,1,0,1]

theorem envBound20154 : H12AffineFastState.Bounded env20154 := by
  intro p hp
  have h : env20154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20153_20154 : H12AffineEnvironment.transform 4 1 env20153 = env20154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20153 == env20154) = true)

def leafEnv20154 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,9,0,1,2,1,0,20,0,0,0,17,3,21,8,1,16,1,1,1,1,20,0,5,1,5,3,0,1,0,0,1]

def active20154 : List Nat := [0,1,2,3]

def tree20154 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20154 : H12WitnessSearch.Good tree20154 := H12GlobalWitnessIndex.good

theorem leafIdentity20154 : H12AffineFastState.composeSystem env20154 rootObs = leafEnv20154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20154 rootObs == leafEnv20154) = true)

theorem terminalChecked20154 : H12PackedTerminal.terminalCheckFast leafEnv20154 active20154 tree20154 = true := by decide +kernel

def env20155 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,8192,1296,292,65536,1296,8460,1024,293,1297,8201,16,65568,8328,16,1,1297,1296,8461,1285,4294967296,257,4295041155,1297,137]

theorem envBound20155 : H12AffineFastState.Bounded env20155 := by
  intro p hp
  have h : env20155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20108_20155 : H12AffineEnvironment.transform 8 137 env20108 = env20155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20108 == env20155) = true)

theorem identity20155 : scanCanonicalize (H12AffineFastState.compose env20155 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20155 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20156 : List Nat := [2,4,8,16,32,17,128,37,137,1024,0,1077,8192,1077,1,65536,1077,8233,1024,0,1076,8201,16,65568,8328,16,1,1076,1077,8232,1056,4294967296,36,4295041155,1076,137]

theorem envBound20156 : H12AffineFastState.Bounded env20156 := by
  intro p hp
  have h : env20156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20155_20156 : H12AffineEnvironment.transform 7 37 env20155 = env20156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20155 == env20156) = true)

theorem identity20156 : scanCanonicalize (H12AffineFastState.compose env20156 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound20156 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20157 : List Nat := [2,4,8,16,32,17,128,37,137,1024,0,1077,8192,1077,1,171,1077,8233,1024,0,1076,8201,16,139,8328,16,1,1076,1077,8232,1056,4294967296,36,4294975528,1076,137]

theorem envBound20157 : H12AffineFastState.Bounded env20157 := by
  intro p hp
  have h : env20157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20156_20157 : H12AffineEnvironment.transform 15 171 env20156 = env20157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env20156 == env20157) = true)

theorem identity20157 : scanCanonicalize (H12AffineFastState.compose env20157 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound20157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20158 : List Nat := [2,4,8,16,32,17,128,37,137,1024,0,1077,138,1077,1,171,1077,163,1024,0,1076,131,16,139,2,16,1,1076,1077,162,1056,4294967296,36,4294967458,1076,137]

theorem envBound20158 : H12AffineFastState.Bounded env20158 := by
  intro p hp
  have h : env20158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20157_20158 : H12AffineEnvironment.transform 12 138 env20157 = env20158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env20157 == env20158) = true)

theorem identity20158 : scanCanonicalize (H12AffineFastState.compose env20158 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20158 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20159 : List Nat := [2,4,8,16,32,17,34,37,43,1024,0,1077,40,1077,1,9,1077,1,1024,0,1076,33,16,41,2,16,1,1076,1077,0,1056,4294967296,36,4294967296,1076,43]

theorem envBound20159 : H12AffineFastState.Bounded env20159 := by
  intro p hp
  have h : env20159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20158_20159 : H12AffineEnvironment.transform 6 34 env20158 = env20159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20158 == env20159) = true)

theorem identity20159 : scanCanonicalize (H12AffineFastState.compose env20159 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound20159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20160 : List Nat := [2,4,8,16,32,17,34,37,43,1024,0,1077,40,1077,1,9,1077,1,1024,0,1076,33,16,41,2,16,1,1076,1077,0,1056,42,36,42,1076,43]

theorem envBound20160 : H12AffineFastState.Bounded env20160 := by
  intro p hp
  have h : env20160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20159_20160 : H12AffineEnvironment.transform 31 42 env20159 = env20160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env20159 == env20160) = true)

theorem identity20160 : scanCanonicalize (H12AffineFastState.compose env20160 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20160 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20161 : List Nat := [2,4,8,16,16,17,18,21,27,1024,0,1029,24,1029,1,9,1029,1,1024,0,1028,17,16,25,2,16,1,1028,1029,0,1040,26,20,26,1028,27]

theorem envBound20161 : H12AffineFastState.Bounded env20161 := by
  intro p hp
  have h : env20161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20160_20161 : H12AffineEnvironment.transform 4 16 env20160 = env20161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20160 == env20161) = true)

def leafEnv20161 : List Nat := [2,4,8,16,16,17,18,21,27,1024,0,1029,24,1029,1,9,1029,1,1024,0,1028,17,16,25,1040,2,1,16,1,1028,1029,0,1040,26,20,26,5,18,1028,27,0,1028,1]

def active20161 : List Nat := [0,1,2,3,9]

def tree20161 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20161 : H12WitnessSearch.Good tree20161 := H12GlobalWitnessIndex.good

theorem leafIdentity20161 : H12AffineFastState.composeSystem env20161 rootObs = leafEnv20161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20161 rootObs == leafEnv20161) = true)

theorem terminalChecked20161 : H12PackedTerminal.terminalCheckFast leafEnv20161 active20161 tree20161 = true := by decide +kernel

def env20162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,292,65536,1345,262144,271628,293,1296,8201,17664,65568,8328,287837,1,16385,287068,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20162 : H12AffineFastState.Bounded env20162 := by
  intro p hp
  have h : env20162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20089_20162 : H12AffineEnvironment.transform 11 1297 env20089 = env20162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20089 == env20162) = true)

theorem identity20162 : scanCanonicalize (H12AffineFastState.compose env20162 (packedSelected [1,3,5,8,12,13,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound20162 : packedSelected [1,3,5,8,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env20163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,292,171,1345,262144,271628,293,1296,8201,17664,139,8328,287837,1,16385,287068,262145,1285,4294967296,257,4294975528,1344,512]

theorem envBound20163 : H12AffineFastState.Bounded env20163 := by
  intro p hp
  have h : env20163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20162_20163 : H12AffineEnvironment.transform 15 171 env20162 = env20163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env20162 == env20163) = true)

def env20164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,292,171,1345,8864,1964,293,1296,8201,17664,139,8328,18173,1,16385,17404,8865,1285,4294967296,257,4294975528,1344,512]

theorem envBound20164 : H12AffineFastState.Bounded env20164 := by
  intro p hp
  have h : env20164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20163_20164 : H12AffineEnvironment.transform 17 8864 env20163 = env20164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8864 env20163 == env20164) = true)

theorem identity20164 : scanCanonicalize (H12AffineFastState.compose env20164 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1772) := by decide +kernel

theorem selectedBound20164 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1772,292,171,1345,8864,1964,293,1296,8201,1004,139,8328,17,1,1773,1296,8865,1285,4294967296,257,4294975528,1344,512]

theorem envBound20165 : H12AffineFastState.Bounded env20165 := by
  intro p hp
  have h : env20165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20164_20165 : H12AffineEnvironment.transform 13 1772 env20164 = env20165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1772 env20164 == env20165) = true)

theorem identity20165 : scanCanonicalize (H12AffineFastState.compose env20165 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound20165 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,673,1772,292,171,1345,1,1964,293,1296,680,1004,139,553,17,1,1773,1296,0,1285,4294967296,257,4294967945,1344,512]

theorem envBound20166 : H12AffineFastState.Bounded env20166 := by
  intro p hp
  have h : env20166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20165_20166 : H12AffineEnvironment.transform 12 673 env20165 = env20166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20165 == env20166) = true)

def env20167 : List Nat := [2,4,8,16,32,64,88,256,512,1024,0,1297,633,1588,292,115,1345,1,1908,293,1296,624,820,83,553,17,1,1589,1296,0,1285,4294967296,257,4294967889,1344,512]

theorem envBound20167 : H12AffineFastState.Bounded env20167 := by
  intro p hp
  have h : env20167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20166_20167 : H12AffineEnvironment.transform 6 88 env20166 = env20167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20166 == env20167) = true)

theorem identity20167 : scanCanonicalize (H12AffineFastState.compose env20167 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound20167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20168 : List Nat := [2,4,8,16,32,64,88,256,512,1024,0,1297,633,1588,292,115,1345,1,1908,293,1296,624,820,83,553,17,1,1589,1296,0,1285,513,257,80,1344,512]

theorem envBound20168 : H12AffineFastState.Bounded env20168 := by
  intro p hp
  have h : env20168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20167_20168 : H12AffineEnvironment.transform 31 513 env20167 = env20168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env20167 == env20168) = true)

theorem identity20168 : scanCanonicalize (H12AffineFastState.compose env20168 (packedSelected [2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20168 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env20169 : List Nat := [2,4,8,16,32,64,88,37,512,1024,0,1076,633,1588,1,115,1124,1,1617,0,1077,624,529,83,553,17,1,1589,1077,0,1056,513,36,80,1125,512]

theorem envBound20169 : H12AffineFastState.Bounded env20169 := by
  intro p hp
  have h : env20169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20168_20169 : H12AffineEnvironment.transform 7 37 env20168 = env20169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20168 == env20169) = true)

def env20170 : List Nat := [2,4,8,16,32,64,88,37,80,1024,0,1076,41,1124,1,115,1124,1,1025,0,1077,32,65,83,121,17,1,1125,1077,0,1056,81,36,80,1125,80]

theorem envBound20170 : H12AffineFastState.Bounded env20170 := by
  intro p hp
  have h : env20170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20169_20170 : H12AffineEnvironment.transform 8 80 env20169 = env20170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env20169 == env20170) = true)

theorem identity20170 : scanCanonicalize (H12AffineFastState.compose env20170 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20171 : List Nat := [2,4,8,16,32,49,41,37,33,1024,0,1076,41,1045,1,2,1045,1,1025,0,1077,32,48,34,8,17,1,1044,1077,0,1056,32,36,33,1044,33]

theorem envBound20171 : H12AffineFastState.Bounded env20171 := by
  intro p hp
  have h : env20171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20170_20171 : H12AffineEnvironment.transform 5 49 env20170 = env20171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20170 == env20171) = true)

def leafEnv20171 : List Nat := [2,4,8,16,32,49,41,37,33,1024,0,1076,41,1045,1,2,1045,1,1025,0,1077,32,48,34,1057,8,1,17,1,1044,1077,0,1056,32,36,33,5,34,1044,33,0,1076,1]

def active20171 : List Nat := [0,1,2,3,4,9]

def tree20171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20171 : H12WitnessSearch.Good tree20171 := H12GlobalWitnessIndex.good

theorem leafIdentity20171 : H12AffineFastState.composeSystem env20171 rootObs = leafEnv20171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20171 rootObs == leafEnv20171) = true)

theorem terminalChecked20171 : H12PackedTerminal.terminalCheckFast leafEnv20171 active20171 tree20171 = true := by decide +kernel

def env20172 : List Nat := [2,4,8,16,32,64,88,37,81,1024,0,1076,40,1125,1,115,1124,1,1024,0,1077,33,64,83,120,17,1,1124,1077,0,1056,80,36,80,1125,81]

theorem envBound20172 : H12AffineFastState.Bounded env20172 := by
  intro p hp
  have h : env20172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20169_20172 : H12AffineEnvironment.transform 8 81 env20169 = env20172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env20169 == env20172) = true)

theorem identity20172 : scanCanonicalize (H12AffineFastState.compose env20172 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20173 : List Nat := [2,4,8,16,10,64,88,15,81,1024,0,1054,2,1103,1,89,1102,1,1024,0,1055,11,64,83,82,17,1,1102,1055,0,1034,80,14,80,1103,81]

theorem envBound20173 : H12AffineFastState.Bounded env20173 := by
  intro p hp
  have h : env20173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20172_20173 : H12AffineEnvironment.transform 4 10 env20172 = env20173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20172 == env20173) = true)

theorem identity20173 : scanCanonicalize (H12AffineFastState.compose env20173 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound20173 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20174 : List Nat := [2,4,8,16,10,10,18,15,27,1024,0,1054,2,1029,1,19,1028,1,1024,0,1055,11,10,25,24,17,1,1028,1055,0,1034,26,14,26,1029,27]

theorem envBound20174 : H12AffineFastState.Bounded env20174 := by
  intro p hp
  have h : env20174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20173_20174 : H12AffineEnvironment.transform 5 10 env20173 = env20174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env20173 == env20174) = true)

def leafEnv20174 : List Nat := [2,4,8,16,10,10,18,15,27,1024,0,1054,2,1029,1,19,1028,1,1024,0,1055,11,10,25,1034,24,1,17,1,1028,1055,0,1034,26,14,26,5,8,1029,27,0,1054,1]

def active20174 : List Nat := [0,1,2,3,9]

def tree20174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20174 : H12WitnessSearch.Good tree20174 := H12GlobalWitnessIndex.good

theorem leafIdentity20174 : H12AffineFastState.composeSystem env20174 rootObs = leafEnv20174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20174 rootObs == leafEnv20174) = true)

theorem terminalChecked20174 : H12PackedTerminal.terminalCheckFast leafEnv20174 active20174 tree20174 = true := by decide +kernel

def env20175 : List Nat := [2,4,8,16,32,64,89,256,512,1024,0,1297,632,1589,292,114,1345,1,1909,293,1296,625,821,82,553,17,1,1588,1296,0,1285,4294967296,257,4294967888,1344,512]

theorem envBound20175 : H12AffineFastState.Bounded env20175 := by
  intro p hp
  have h : env20175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20166_20175 : H12AffineEnvironment.transform 6 89 env20166 = env20175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20166 == env20175) = true)

theorem identity20175 : scanCanonicalize (H12AffineFastState.compose env20175 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 372) := by decide +kernel

theorem selectedBound20175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20176 : List Nat := [2,4,8,16,32,64,89,256,512,1024,0,1297,632,1589,292,114,1345,1,1909,293,1296,625,821,82,553,17,1,1588,1296,0,1285,372,257,804,1344,512]

theorem envBound20176 : H12AffineFastState.Bounded env20176 := by
  intro p hp
  have h : env20176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20175_20176 : H12AffineEnvironment.transform 31 372 env20175 = env20176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 372 env20175 == env20176) = true)

def env20177 : List Nat := [2,4,8,16,32,64,89,256,372,1024,0,1297,268,1345,292,114,1345,1,1025,293,1296,261,65,82,349,17,1,1344,1296,0,1285,372,257,80,1344,372]

theorem envBound20177 : H12AffineFastState.Bounded env20177 := by
  intro p hp
  have h : env20177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20176_20177 : H12AffineEnvironment.transform 8 372 env20176 = env20177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env20176 == env20177) = true)

theorem identity20177 : scanCanonicalize (H12AffineFastState.compose env20177 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20178 : List Nat := [2,4,8,16,32,64,89,36,80,1024,0,1077,40,1125,0,114,1125,1,1025,1,1076,33,65,82,121,17,1,1124,1076,0,1057,80,37,80,1124,80]

theorem envBound20178 : H12AffineFastState.Bounded env20178 := by
  intro p hp
  have h : env20178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20177_20178 : H12AffineEnvironment.transform 7 36 env20177 = env20178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20177 == env20178) = true)

def env20179 : List Nat := [2,4,8,16,32,64,89,256,373,1024,0,1297,269,1344,292,114,1345,1,1024,293,1296,260,64,82,348,17,1,1345,1296,0,1285,372,257,81,1344,373]

theorem envBound20179 : H12AffineFastState.Bounded env20179 := by
  intro p hp
  have h : env20179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20176_20179 : H12AffineEnvironment.transform 8 373 env20176 = env20179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env20176 == env20179) = true)

theorem identity20179 : scanCanonicalize (H12AffineFastState.compose env20179 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound20179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20180 : List Nat := [2,4,8,16,32,64,89,15,122,1024,0,1054,2,1103,43,114,1102,1,1024,42,1055,11,64,82,83,17,1,1102,1055,0,1034,123,14,81,1103,122]

theorem envBound20180 : H12AffineFastState.Bounded env20180 := by
  intro p hp
  have h : env20180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20179_20180 : H12AffineEnvironment.transform 7 15 env20179 = env20180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env20179 == env20180) = true)

theorem identity20180 : scanCanonicalize (H12AffineFastState.compose env20180 (packedSelected [2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20180 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env20181 : List Nat := [2,4,8,16,10,64,89,15,80,1024,0,1054,2,1103,1,88,1102,1,1024,0,1055,11,64,82,83,17,1,1102,1055,0,1034,81,14,81,1103,80]

theorem envBound20181 : H12AffineFastState.Bounded env20181 := by
  intro p hp
  have h : env20181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20180_20181 : H12AffineEnvironment.transform 4 10 env20180 = env20181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20180 == env20181) = true)

theorem identity20181 : scanCanonicalize (H12AffineFastState.compose env20181 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound20181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20182 : List Nat := [2,4,8,16,10,10,19,15,26,1024,0,1054,2,1029,1,18,1028,1,1024,0,1055,11,10,24,25,17,1,1028,1055,0,1034,27,14,27,1029,26]

theorem envBound20182 : H12AffineFastState.Bounded env20182 := by
  intro p hp
  have h : env20182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20181_20182 : H12AffineEnvironment.transform 5 10 env20181 = env20182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env20181 == env20182) = true)

def leafEnv20182 : List Nat := [2,4,8,16,10,10,19,15,26,1024,0,1054,2,1029,1,18,1028,1,1024,0,1055,11,10,24,1034,25,1,17,1,1028,1055,0,1034,27,14,27,5,8,1029,26,0,1054,1]

def active20182 : List Nat := [0,1,2,3,9]

def tree20182 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20182 : H12WitnessSearch.Good tree20182 := H12GlobalWitnessIndex.good

theorem leafIdentity20182 : H12AffineFastState.composeSystem env20182 rootObs = leafEnv20182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20182 rootObs == leafEnv20182) = true)

theorem terminalChecked20182 : H12PackedTerminal.terminalCheckFast leafEnv20182 active20182 tree20182 = true := by decide +kernel

def env20183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,292,171,1345,8865,1965,293,1296,8201,17664,139,8328,18172,1,16385,17405,8864,1285,4294967296,257,4294975528,1344,512]

theorem envBound20183 : H12AffineFastState.Bounded env20183 := by
  intro p hp
  have h : env20183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20163_20183 : H12AffineEnvironment.transform 17 8865 env20163 = env20183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8865 env20163 == env20183) = true)

theorem identity20183 : scanCanonicalize (H12AffineFastState.compose env20183 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20183 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,292,171,1345,8865,1965,293,1296,8201,65,139,8328,957,1,1344,1724,8864,1285,4294967296,257,4294975528,1344,512]

theorem envBound20184 : H12AffineFastState.Bounded env20184 := by
  intro p hp
  have h : env20184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20183_20184 : H12AffineEnvironment.transform 13 1345 env20183 = env20184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20183 == env20184) = true)

theorem identity20184 : scanCanonicalize (H12AffineFastState.compose env20184 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20185 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1297,8192,1345,292,171,1345,8461,1025,293,1296,8201,65,139,8328,17,1,1344,1296,8460,1285,4294967296,257,4294975528,1344,428]

theorem envBound20185 : H12AffineFastState.Bounded env20185 := by
  intro p hp
  have h : env20185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20184_20185 : H12AffineEnvironment.transform 8 428 env20184 = env20185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20184 == env20185) = true)

theorem identity20185 : scanCanonicalize (H12AffineFastState.compose env20185 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20185 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20186 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1297,268,1345,292,171,1345,1,1025,293,1296,261,65,139,388,17,1,1344,1296,0,1285,4294967296,257,4294967588,1344,428]

theorem envBound20186 : H12AffineFastState.Bounded env20186 := by
  intro p hp
  have h : env20186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20185_20186 : H12AffineEnvironment.transform 12 268 env20185 = env20186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20185 == env20186) = true)

theorem identity20186 : scanCanonicalize (H12AffineFastState.compose env20186 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 508) := by decide +kernel

theorem selectedBound20186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20187 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1297,268,1345,292,171,1345,1,1025,293,1296,261,65,139,388,17,1,1344,1296,0,1285,508,257,216,1344,428]

theorem envBound20187 : H12AffineFastState.Bounded env20187 := by
  intro p hp
  have h : env20187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20186_20187 : H12AffineEnvironment.transform 31 508 env20186 = env20187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 508 env20186 == env20187) = true)

theorem identity20187 : scanCanonicalize (H12AffineFastState.compose env20187 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20188 : List Nat := [2,4,8,16,32,64,128,172,0,1024,0,1213,160,1261,136,171,1261,1,1025,137,1212,169,65,139,40,17,1,1260,1212,0,1193,80,173,216,1260,0]

theorem envBound20188 : H12AffineFastState.Bounded env20188 := by
  intro p hp
  have h : env20188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20187_20188 : H12AffineEnvironment.transform 7 172 env20187 = env20188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20187 == env20188) = true)

theorem identity20188 : scanCanonicalize (H12AffineFastState.compose env20188 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20188 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20189 : List Nat := [2,4,8,16,32,64,8,36,0,1024,0,1077,40,1125,0,35,1125,1,1025,1,1076,33,65,3,40,17,1,1124,1076,0,1057,80,37,80,1124,0]

theorem envBound20189 : H12AffineFastState.Bounded env20189 := by
  intro p hp
  have h : env20189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20188_20189 : H12AffineEnvironment.transform 6 8 env20188 = env20189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20188 == env20189) = true)

theorem identity20189 : scanCanonicalize (H12AffineFastState.compose env20189 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20190 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,40,1076,0,35,1076,1,1025,1,1076,33,16,3,40,17,1,1077,1076,0,1057,1,37,1,1077,0]

theorem envBound20190 : H12AffineFastState.Bounded env20190 := by
  intro p hp
  have h : env20190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20189_20190 : H12AffineEnvironment.transform 5 17 env20189 = env20190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20189 == env20190) = true)

def leafEnv20190 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,40,1076,0,35,1076,1,1025,1,1076,33,16,3,1056,40,1,17,1,1077,1076,0,1057,1,37,1,5,34,1077,0,0,1077,1]

def active20190 : List Nat := [0,1,2,3,4,9]

def tree20190 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20190 : H12WitnessSearch.Good tree20190 := H12GlobalWitnessIndex.good

theorem leafIdentity20190 : H12AffineFastState.composeSystem env20190 rootObs = leafEnv20190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20190 rootObs == leafEnv20190) = true)

theorem terminalChecked20190 : H12PackedTerminal.terminalCheckFast leafEnv20190 active20190 tree20190 = true := by decide +kernel

def env20191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98564,8328,320888,33060,16385,324968,262144,1285,4294967296,257,4295074215,1344,512]

theorem envBound20191 : H12AffineFastState.Bounded env20191 := by
  intro p hp
  have h : env20191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20087_20191 : H12AffineEnvironment.transform 18 304169 env20087 = env20191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20087 == env20191) = true)

theorem identity20191 : scanCanonicalize (H12AffineFastState.compose env20191 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound20191 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,33060,9485,32769,4097,8201,17664,98564,8328,25692,33060,16385,29772,33060,1285,4294967296,257,4295074215,1344,512]

theorem envBound20192 : H12AffineFastState.Bounded env20192 := by
  intro p hp
  have h : env20192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20191_20192 : H12AffineEnvironment.transform 17 33060 env20191 = env20192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env20191 == env20192) = true)

def env20193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,147521,230469,8328,672784,925773,16385,676864,1073741824,131140,4294967296,257,4295206119,1344,512]

theorem envBound20193 : H12AffineFastState.Bounded env20193 := by
  intro p hp
  have h : env20193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20069_20193 : H12AffineEnvironment.transform 10 1 env20069 = env20193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20069 == env20193) = true)

def env20194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98565,8328,541008,795917,16385,545088,1073741824,1284,4294967296,257,4295074215,1344,512]

theorem envBound20194 : H12AffineFastState.Bounded env20194 := by
  intro p hp
  have h : env20194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20193_20194 : H12AffineEnvironment.transform 16 1344 env20193 = env20194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20193 == env20194) = true)

theorem identity20194 : scanCanonicalize (H12AffineFastState.compose env20194 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 262225) := by decide +kernel

theorem selectedBound20194 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98565,8328,541008,795917,16385,545088,262225,1284,4294967296,257,4295074215,1344,512]

theorem envBound20195 : H12AffineFastState.Bounded env20195 := by
  intro p hp
  have h : env20195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20194_20195 : H12AffineEnvironment.transform 29 262225 env20194 = env20195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262225 env20194 == env20195) = true)

theorem identity20195 : scanCanonicalize (H12AffineFastState.compose env20195 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20195 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8200,17665,98565,8328,17745,270604,16385,21825,262225,1284,4294967296,257,4295074215,1344,512]

theorem envBound20196 : H12AffineFastState.Bounded env20196 := by
  intro p hp
  have h : env20196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20195_20196 : H12AffineEnvironment.transform 18 1025 env20195 = env20196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20195 == env20196) = true)

theorem identity20196 : scanCanonicalize (H12AffineFastState.compose env20196 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 106706) := by decide +kernel

theorem selectedBound20196 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,106706,1025,32769,4097,8200,17665,98565,8328,17745,98782,16385,21825,106627,1284,4294967296,257,4295074215,1344,512]

theorem envBound20197 : H12AffineFastState.Bounded env20197 := by
  intro p hp
  have h : env20197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20196_20197 : H12AffineEnvironment.transform 17 106706 env20196 = env20197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106706 env20196 == env20197) = true)

theorem identity20197 : scanCanonicalize (H12AffineFastState.compose env20197 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20197 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,65536,1344,106706,1025,32769,4097,8200,5457,98565,8328,5377,98782,4177,1297,106627,1284,4294967296,257,4295074215,1344,512]

theorem envBound20198 : H12AffineFastState.Bounded env20198 := by
  intro p hp
  have h : env20198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20197_20198 : H12AffineEnvironment.transform 13 4176 env20197 = env20198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20197 == env20198) = true)

theorem identity20198 : scanCanonicalize (H12AffineFastState.compose env20198 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound20198 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,65536,1344,106706,1025,32769,4097,8200,5457,98565,8328,5377,98782,4177,1297,106627,1284,8320,257,98599,1344,512]

theorem envBound20199 : H12AffineFastState.Bounded env20199 := by
  intro p hp
  have h : env20199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20198_20199 : H12AffineEnvironment.transform 31 8320 env20198 = env20199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env20198 == env20199) = true)

theorem identity20199 : scanCanonicalize (H12AffineFastState.compose env20199 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound20199 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,373,65536,1344,74151,1025,372,4097,8200,5457,65648,8328,5377,65707,4177,1297,74230,1284,8320,257,65618,1344,512]

theorem envBound20200 : H12AffineFastState.Bounded env20200 := by
  intro p hp
  have h : env20200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20199_20200 : H12AffineEnvironment.transform 14 373 env20199 = env20200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env20199 == env20200) = true)

theorem identity20200 : scanCanonicalize (H12AffineFastState.compose env20200 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 13714) := by decide +kernel

theorem selectedBound20200 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,373,13714,1344,5173,1025,372,4097,8200,5457,13794,8328,5377,13625,4177,1297,5220,1284,8320,257,13760,1344,512]

theorem envBound20201 : H12AffineFastState.Bounded env20201 := by
  intro p hp
  have h : env20201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20200_20201 : H12AffineEnvironment.transform 15 13714 env20200 = env20201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13714 env20200 == env20201) = true)

theorem identity20201 : scanCanonicalize (H12AffineFastState.compose env20201 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20201 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20202 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1,4096,8192,4176,136,13423,1213,5173,1025,137,4097,8200,5292,13343,8328,5372,13508,4177,1260,5220,1273,8320,252,13373,1213,512]

theorem envBound20202 : H12AffineFastState.Bounded env20202 := by
  intro p hp
  have h : env20202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20201_20202 : H12AffineEnvironment.transform 7 253 env20201 = env20202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20201 == env20202) = true)

theorem identity20202 : scanCanonicalize (H12AffineFastState.compose env20202 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound20202 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20203 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1,1092,8192,1044,136,8235,1213,113,1025,137,1093,8200,232,8283,8328,184,8320,1045,1260,32,1273,8320,252,8313,1213,512]

theorem envBound20203 : H12AffineFastState.Bounded env20203 := by
  intro p hp
  have h : env20203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20202_20203 : H12AffineEnvironment.transform 11 1092 env20202 = env20203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env20202 == env20203) = true)

theorem identity20203 : scanCanonicalize (H12AffineFastState.compose env20203 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20203 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20204 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1,1092,8192,1044,136,8235,1213,113,1025,137,1093,8200,232,8283,8328,184,8320,1045,1260,32,1273,8320,252,8313,1213,0]

theorem envBound20204 : H12AffineFastState.Bounded env20204 := by
  intro p hp
  have h : env20204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20203_20204 : H12AffineEnvironment.transform 8 0 env20203 = env20204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20203 == env20204) = true)

theorem identity20204 : scanCanonicalize (H12AffineFastState.compose env20204 (packedSelected [1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound20204 : packedSelected [1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env20205 : List Nat := [2,4,8,16,32,64,128,253,0,220,1,152,8192,200,136,8235,97,113,221,137,153,8200,232,8283,8328,184,8320,201,48,32,37,8320,252,8313,97,0]

theorem envBound20205 : H12AffineFastState.Bounded env20205 := by
  intro p hp
  have h : env20205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20204_20205 : H12AffineEnvironment.transform 9 220 env20204 = env20205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env20204 == env20205) = true)

theorem identity20205 : scanCanonicalize (H12AffineFastState.compose env20205 (packedSelected [1,2,3,4,5,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 176) := by decide +kernel

theorem selectedBound20205 : packedSelected [1,2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env20206 : List Nat := [2,4,8,16,32,64,128,253,0,220,1,152,176,200,136,155,97,113,221,137,153,184,232,235,56,184,48,201,48,32,37,48,252,201,97,0]

theorem envBound20206 : H12AffineFastState.Bounded env20206 := by
  intro p hp
  have h : env20206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20205_20206 : H12AffineEnvironment.transform 12 176 env20205 = env20206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 176 env20205 == env20206) = true)

theorem identity20206 : scanCanonicalize (H12AffineFastState.compose env20206 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound20206 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20207 : List Nat := [2,4,8,16,32,64,41,84,0,117,1,49,25,97,33,50,97,113,116,32,48,17,65,66,56,17,48,96,48,32,37,48,85,96,97,0]

theorem envBound20207 : H12AffineFastState.Bounded env20207 := by
  intro p hp
  have h : env20207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20206_20207 : H12AffineEnvironment.transform 6 41 env20206 = env20207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env20206 == env20207) = true)

theorem identity20207 : scanCanonicalize (H12AffineFastState.compose env20207 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound20207 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env20208 : List Nat := [2,4,8,16,32,33,41,53,0,20,1,49,25,0,33,50,0,16,21,32,48,17,32,35,56,17,48,1,48,32,37,48,52,1,0,0]

theorem envBound20208 : H12AffineFastState.Bounded env20208 := by
  intro p hp
  have h : env20208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20207_20208 : H12AffineEnvironment.transform 5 33 env20207 = env20208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env20207 == env20208) = true)

theorem identity20208 : scanCanonicalize (H12AffineFastState.compose env20208 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20209 : List Nat := [2,4,8,16,0,1,9,21,0,20,1,17,25,0,1,18,0,16,21,0,16,17,0,3,24,17,16,1,16,0,5,16,20,1,0,0]

theorem envBound20209 : H12AffineFastState.Bounded env20209 := by
  intro p hp
  have h : env20209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20208_20209 : H12AffineEnvironment.transform 4 0 env20208 = env20209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20208 == env20209) = true)

theorem identity20209 : scanCanonicalize (H12AffineFastState.compose env20209 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20210 : List Nat := [2,4,8,0,0,1,9,5,0,4,1,1,9,0,1,2,0,0,5,0,0,1,0,3,8,1,0,1,0,0,5,0,4,1,0,0]

theorem envBound20210 : H12AffineFastState.Bounded env20210 := by
  intro p hp
  have h : env20210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20209_20210 : H12AffineEnvironment.transform 3 0 env20209 = env20210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20209 == env20210) = true)

def env20211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541009,795916,16385,545089,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound20211 : H12AffineFastState.Bounded env20211 := by
  intro p hp
  have h : env20211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20193_20211 : H12AffineEnvironment.transform 16 1345 env20193 = env20211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20193 == env20211) = true)

theorem identity20211 : scanCanonicalize (H12AffineFastState.compose env20211 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound20211 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541009,795916,16385,545089,262145,1285,4294967296,257,4295074214,1344,512]

theorem envBound20212 : H12AffineFastState.Bounded env20212 := by
  intro p hp
  have h : env20212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20211_20212 : H12AffineEnvironment.transform 29 262145 env20211 = env20212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env20211 == env20212) = true)

theorem identity20212 : scanCanonicalize (H12AffineFastState.compose env20212 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound20212 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env20213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,293,65536,1345,262144,524288,292,4097,8200,17664,65569,8328,541009,795916,16385,545089,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20213 : H12AffineFastState.Bounded env20213 := by
  intro p hp
  have h : env20213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20212_20213 : H12AffineEnvironment.transform 14 293 env20212 = env20213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env20212 == env20213) = true)

theorem identity20213 : scanCanonicalize (H12AffineFastState.compose env20213 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 271628) := by decide +kernel

theorem selectedBound20213 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env20214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,293,65536,1345,262144,271628,292,4097,8200,17664,65569,8328,287837,0,16385,291917,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20214 : H12AffineFastState.Bounded env20214 := by
  intro p hp
  have h : env20214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20213_20214 : H12AffineEnvironment.transform 18 271628 env20213 = env20214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 271628 env20213 == env20214) = true)

def env20215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,293,65536,1345,262144,271628,292,1297,8200,17664,65569,8328,287837,0,16385,287069,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20215 : H12AffineFastState.Bounded env20215 := by
  intro p hp
  have h : env20215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20214_20215 : H12AffineEnvironment.transform 11 1296 env20214 = env20215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env20214 == env20215) = true)

theorem identity20215 : scanCanonicalize (H12AffineFastState.compose env20215 (packedSelected [4,9] rootPS)) = affineNative (2^(17+1) ^^^ 25677) := by decide +kernel

theorem selectedBound20215 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,293,65536,1345,25677,16705,292,1297,8200,17664,65569,8328,16,0,16385,1296,25676,1285,4294967296,257,4295041155,1344,512]

theorem envBound20216 : H12AffineFastState.Bounded env20216 := by
  intro p hp
  have h : env20216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20215_20216 : H12AffineEnvironment.transform 17 25677 env20215 = env20216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25677 env20215 == env20216) = true)

def env20217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,16384,293,65536,1297,25629,16657,292,1297,8200,17664,65569,8328,16,0,16385,1296,25628,1285,4294967296,257,4295041155,1296,512]

theorem envBound20217 : H12AffineFastState.Bounded env20217 := by
  intro p hp
  have h : env20217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20216_20217 : H12AffineEnvironment.transform 5 16 env20216 = env20217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20216 == env20217) = true)

def env20218 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1296,293,65536,1297,8461,1025,292,1297,8200,16,65569,8328,16,0,1297,1296,8460,1285,4294967296,257,4295041155,1296,512]

theorem envBound20218 : H12AffineFastState.Bounded env20218 := by
  intro p hp
  have h : env20218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20217_20218 : H12AffineEnvironment.transform 13 1296 env20217 = env20218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env20217 == env20218) = true)

theorem identity20218 : scanCanonicalize (H12AffineFastState.compose env20218 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20219 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1296,293,170,1297,8461,1025,292,1297,8200,16,139,8328,16,0,1297,1296,8460,1285,4294967296,257,4294975529,1296,512]

theorem envBound20219 : H12AffineFastState.Bounded env20219 := by
  intro p hp
  have h : env20219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20218_20219 : H12AffineEnvironment.transform 15 170 env20218 = env20219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20218 == env20219) = true)

theorem identity20219 : scanCanonicalize (H12AffineFastState.compose env20219 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20219 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20220 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,41,1296,293,170,1297,292,1025,292,1297,33,16,139,161,16,0,1297,1296,293,1285,4294967296,257,4294967296,1296,512]

theorem envBound20220 : H12AffineFastState.Bounded env20220 := by
  intro p hp
  have h : env20220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20219_20220 : H12AffineEnvironment.transform 12 41 env20219 = env20220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20219 == env20220) = true)

theorem identity20220 : scanCanonicalize (H12AffineFastState.compose env20220 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound20220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20221 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,41,1296,293,170,1297,292,1025,292,1297,33,16,139,161,16,0,1297,1296,293,1285,805,257,805,1296,512]

theorem envBound20221 : H12AffineFastState.Bounded env20221 := by
  intro p hp
  have h : env20221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20220_20221 : H12AffineEnvironment.transform 31 805 env20220 = env20221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env20220 == env20221) = true)

theorem identity20221 : scanCanonicalize (H12AffineFastState.compose env20221 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound20221 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20222 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1296,41,1296,293,170,1297,292,1025,292,1297,33,16,139,161,16,0,1297,1296,293,1285,429,257,429,1296,136]

theorem envBound20222 : H12AffineFastState.Bounded env20222 := by
  intro p hp
  have h : env20222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20221_20222 : H12AffineEnvironment.transform 8 136 env20221 = env20222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20221 == env20222) = true)

theorem identity20222 : scanCanonicalize (H12AffineFastState.compose env20222 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20223 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,41,1076,1,170,1077,0,1025,0,1077,33,16,139,161,16,0,1077,1076,1,1057,137,37,137,1076,136]

theorem envBound20223 : H12AffineFastState.Bounded env20223 := by
  intro p hp
  have h : env20223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20222_20223 : H12AffineEnvironment.transform 7 36 env20222 = env20223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20222 == env20223) = true)

def leafEnv20223 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,41,1076,1,170,1077,0,1025,0,1077,33,16,139,1056,161,1,16,0,1077,1076,1,1057,137,37,137,5,35,1076,136,0,1077,1]

def active20223 : List Nat := [0,1,2,3,4,6,9]

def tree20223 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20223 : H12WitnessSearch.Good tree20223 := H12GlobalWitnessIndex.good

theorem leafIdentity20223 : H12AffineFastState.composeSystem env20223 rootObs = leafEnv20223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20223 rootObs == leafEnv20223) = true)

theorem terminalChecked20223 : H12PackedTerminal.terminalCheckFast leafEnv20223 active20223 tree20223 = true := by decide +kernel

def env20224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1297,293,65536,1297,8460,1024,292,1297,8200,17,65569,8328,16,0,1296,1296,8461,1285,4294967296,257,4295041155,1296,512]

theorem envBound20224 : H12AffineFastState.Bounded env20224 := by
  intro p hp
  have h : env20224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20217_20224 : H12AffineEnvironment.transform 13 1297 env20217 = env20224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env20217 == env20224) = true)

theorem identity20224 : scanCanonicalize (H12AffineFastState.compose env20224 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 774) := by decide +kernel

theorem selectedBound20224 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20225 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1297,293,774,1297,8460,1024,292,1297,8200,17,807,8328,16,0,1296,1296,8461,1285,4294967296,257,4294976389,1296,512]

theorem envBound20225 : H12AffineFastState.Bounded env20225 := by
  intro p hp
  have h : env20225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20224_20225 : H12AffineEnvironment.transform 15 774 env20224 = env20225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 774 env20224 == env20225) = true)

theorem identity20225 : scanCanonicalize (H12AffineFastState.compose env20225 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20225 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20226 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1,1077,8192,1076,0,547,1076,8233,1024,1,1076,8200,17,514,8328,16,0,1077,1077,8232,1056,4294967296,36,4294976160,1077,512]

theorem envBound20226 : H12AffineFastState.Bounded env20226 := by
  intro p hp
  have h : env20226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20225_20226 : H12AffineEnvironment.transform 7 37 env20225 = env20226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20225 == env20226) = true)

theorem identity20226 : scanCanonicalize (H12AffineFastState.compose env20226 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound20226 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20227 : List Nat := [2,4,8,16,32,16,128,37,137,1024,1,1077,8192,1076,0,170,1076,8233,1024,1,1076,8200,17,139,8328,16,0,1077,1077,8232,1056,4294967296,36,4294975529,1077,137]

theorem envBound20227 : H12AffineFastState.Bounded env20227 := by
  intro p hp
  have h : env20227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20226_20227 : H12AffineEnvironment.transform 8 137 env20226 = env20227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20226 == env20227) = true)

theorem identity20227 : scanCanonicalize (H12AffineFastState.compose env20227 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20228 : List Nat := [2,4,8,16,32,16,34,37,43,1024,1,1077,8192,1076,0,8,1076,8233,1024,1,1076,8200,17,41,8234,16,0,1077,1077,8232,1056,4294967296,36,4294975529,1077,43]

theorem envBound20228 : H12AffineFastState.Bounded env20228 := by
  intro p hp
  have h : env20228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20227_20228 : H12AffineEnvironment.transform 6 34 env20227 = env20228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20227 == env20228) = true)

theorem identity20228 : scanCanonicalize (H12AffineFastState.compose env20228 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20228 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20229 : List Nat := [2,4,8,16,32,16,34,37,43,1024,1,1077,41,1076,0,8,1076,0,1024,1,1076,33,17,41,3,16,0,1077,1077,1,1056,4294967296,36,4294967296,1077,43]

theorem envBound20229 : H12AffineFastState.Bounded env20229 := by
  intro p hp
  have h : env20229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20228_20229 : H12AffineEnvironment.transform 12 41 env20228 = env20229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20228 == env20229) = true)

theorem identity20229 : scanCanonicalize (H12AffineFastState.compose env20229 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound20229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20230 : List Nat := [2,4,8,16,32,16,34,37,43,1024,1,1077,41,1076,0,8,1076,0,1024,1,1076,33,17,41,3,16,0,1077,1077,1,1056,42,36,42,1077,43]

theorem envBound20230 : H12AffineFastState.Bounded env20230 := by
  intro p hp
  have h : env20230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20229_20230 : H12AffineEnvironment.transform 31 42 env20229 = env20230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env20229 == env20230) = true)

theorem identity20230 : scanCanonicalize (H12AffineFastState.compose env20230 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20231 : List Nat := [2,4,8,16,16,16,18,21,27,1024,1,1029,25,1028,0,8,1028,0,1024,1,1028,17,17,25,3,16,0,1029,1029,1,1040,26,20,26,1029,27]

theorem envBound20231 : H12AffineFastState.Bounded env20231 := by
  intro p hp
  have h : env20231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20230_20231 : H12AffineEnvironment.transform 4 16 env20230 = env20231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20230 == env20231) = true)

def leafEnv20231 : List Nat := [2,4,8,16,16,16,18,21,27,1024,1,1029,25,1028,0,8,1028,0,1024,1,1028,17,17,25,1040,3,1,16,0,1029,1029,1,1040,26,20,26,5,19,1029,27,0,1028,1]

def active20231 : List Nat := [0,1,2,3,9]

def tree20231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20231 : H12WitnessSearch.Good tree20231 := H12GlobalWitnessIndex.good

theorem leafIdentity20231 : H12AffineFastState.composeSystem env20231 rootObs = leafEnv20231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20231 rootObs == leafEnv20231) = true)

theorem terminalChecked20231 : H12PackedTerminal.terminalCheckFast leafEnv20231 active20231 tree20231 = true := by decide +kernel

def env20232 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,8192,16384,293,65536,1296,25628,16656,292,1297,8200,17664,65569,8328,16,0,16385,1296,25629,1285,4294967296,257,4295041155,1297,512]

theorem envBound20232 : H12AffineFastState.Bounded env20232 := by
  intro p hp
  have h : env20232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20216_20232 : H12AffineEnvironment.transform 5 17 env20216 = env20232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20216 == env20232) = true)

theorem identity20232 : scanCanonicalize (H12AffineFastState.compose env20232 (packedSelected [1,3,8] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound20232 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env20233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,8192,1945,293,65536,1296,9093,1673,292,1297,8200,665,65569,8328,16,0,1944,1296,9092,1285,4294967296,257,4295041155,1297,512]

theorem envBound20233 : H12AffineFastState.Bounded env20233 := by
  intro p hp
  have h : env20233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20232_20233 : H12AffineEnvironment.transform 13 1945 env20232 = env20233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env20232 == env20233) = true)

def env20234 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1296,8192,1297,293,65536,1296,8461,1025,292,1297,8200,17,65569,8328,16,0,1296,1296,8460,1285,4294967296,257,4295041155,1297,136]

theorem envBound20234 : H12AffineFastState.Bounded env20234 := by
  intro p hp
  have h : env20234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20233_20234 : H12AffineEnvironment.transform 8 136 env20233 = env20234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20233 == env20234) = true)

def env20235 : List Nat := [2,4,8,16,32,17,128,256,136,272,1,0,8192,1,293,65536,0,8461,273,292,1,8200,17,65569,8328,16,0,0,0,8460,21,4294967296,257,4295041155,1,136]

theorem envBound20235 : H12AffineFastState.Bounded env20235 := by
  intro p hp
  have h : env20235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20234_20235 : H12AffineEnvironment.transform 9 272 env20234 = env20235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20234 == env20235) = true)

theorem identity20235 : scanCanonicalize (H12AffineFastState.compose env20235 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20236 : List Nat := [2,4,8,16,32,17,128,256,136,272,1,0,8192,1,293,170,0,8461,273,292,1,8200,17,139,8328,16,0,0,0,8460,21,4294967296,257,4294975529,1,136]

theorem envBound20236 : H12AffineFastState.Bounded env20236 := by
  intro p hp
  have h : env20236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20235_20236 : H12AffineEnvironment.transform 15 170 env20235 = env20236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20235 == env20236) = true)

theorem identity20236 : scanCanonicalize (H12AffineFastState.compose env20236 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20236 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20237 : List Nat := [2,4,8,16,32,17,128,256,136,272,1,0,269,1,293,170,0,0,273,292,1,261,17,139,389,16,0,0,0,1,21,4294967296,257,4294967588,1,136]

theorem envBound20237 : H12AffineFastState.Bounded env20237 := by
  intro p hp
  have h : env20237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20236_20237 : H12AffineEnvironment.transform 12 269 env20236 = env20237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20236 == env20237) = true)

def env20238 : List Nat := [2,4,8,16,32,17,8,256,0,272,1,0,269,1,293,34,0,0,273,292,1,261,17,3,269,16,0,0,0,1,21,4294967296,257,4294967588,1,0]

theorem envBound20238 : H12AffineFastState.Bounded env20238 := by
  intro p hp
  have h : env20238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20237_20238 : H12AffineEnvironment.transform 6 8 env20237 = env20238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20237 == env20238) = true)

theorem identity20238 : scanCanonicalize (H12AffineFastState.compose env20238 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20239 : List Nat := [2,4,8,16,32,17,8,256,0,272,1,0,269,1,293,34,0,0,273,292,1,261,17,3,269,16,0,0,0,1,21,292,257,0,1,0]

theorem envBound20239 : H12AffineFastState.Bounded env20239 := by
  intro p hp
  have h : env20239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20238_20239 : H12AffineEnvironment.transform 31 292 env20238 = env20239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20238 == env20239) = true)

def env20240 : List Nat := [2,4,8,16,0,17,8,256,0,272,1,0,269,1,261,2,0,0,273,260,1,261,17,3,269,16,0,0,0,1,21,260,257,0,1,0]

theorem envBound20240 : H12AffineFastState.Bounded env20240 := by
  intro p hp
  have h : env20240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20239_20240 : H12AffineEnvironment.transform 4 0 env20239 = env20240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20239 == env20240) = true)

def leafEnv20240 : List Nat := [2,4,8,16,0,17,8,256,0,272,1,0,269,1,261,2,0,0,273,260,1,261,17,3,20,269,1,16,0,0,0,1,21,260,257,0,5,3,1,0,0,1,1]

def active20240 : List Nat := [0,1,2,3,7]

def tree20240 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20240 : H12WitnessSearch.Good tree20240 := H12GlobalWitnessIndex.good

theorem leafIdentity20240 : H12AffineFastState.composeSystem env20240 rootObs = leafEnv20240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20240 rootObs == leafEnv20240) = true)

theorem terminalChecked20240 : H12PackedTerminal.terminalCheckFast leafEnv20240 active20240 tree20240 = true := by decide +kernel

def env20241 : List Nat := [2,4,8,16,1,17,8,256,0,272,1,0,269,1,260,3,0,0,273,261,1,261,17,3,269,16,0,0,0,1,21,261,257,0,1,0]

theorem envBound20241 : H12AffineFastState.Bounded env20241 := by
  intro p hp
  have h : env20241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20239_20241 : H12AffineEnvironment.transform 4 1 env20239 = env20241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20239 == env20241) = true)

theorem identity20241 : scanCanonicalize (H12AffineFastState.compose env20241 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20242 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,0,8,1,1,3,0,0,20,0,1,0,17,3,8,16,0,0,0,1,21,0,4,0,1,0]

theorem envBound20242 : H12AffineFastState.Bounded env20242 := by
  intro p hp
  have h : env20242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20241_20242 : H12AffineEnvironment.transform 7 5 env20241 = env20242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20241 == env20242) = true)

def leafEnv20242 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,0,8,1,1,3,0,0,20,0,1,0,17,3,20,8,1,16,0,0,0,1,21,0,4,0,5,2,1,0,0,1,1]

def active20242 : List Nat := [0,1,2,3]

def tree20242 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20242 : H12WitnessSearch.Good tree20242 := H12GlobalWitnessIndex.good

theorem leafIdentity20242 : H12AffineFastState.composeSystem env20242 rootObs = leafEnv20242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20242 rootObs == leafEnv20242) = true)

theorem terminalChecked20242 : H12PackedTerminal.terminalCheckFast leafEnv20242 active20242 tree20242 = true := by decide +kernel

def env20243 : List Nat := [2,4,8,16,32,17,9,256,1,272,1,0,269,1,293,35,0,0,273,292,1,261,17,2,268,16,0,0,0,1,21,4294967296,257,4294967588,1,1]

theorem envBound20243 : H12AffineFastState.Bounded env20243 := by
  intro p hp
  have h : env20243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20237_20243 : H12AffineEnvironment.transform 6 9 env20237 = env20243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20237 == env20243) = true)

theorem identity20243 : scanCanonicalize (H12AffineFastState.compose env20243 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound20243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20244 : List Nat := [2,4,8,16,32,17,9,256,1,272,1,0,269,1,293,35,0,0,273,292,1,261,17,2,268,16,0,0,0,1,21,1,257,293,1,1]

theorem envBound20244 : H12AffineFastState.Bounded env20244 := by
  intro p hp
  have h : env20244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20243_20244 : H12AffineEnvironment.transform 31 1 env20243 = env20244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env20243 == env20244) = true)

def env20245 : List Nat := [2,4,8,16,0,17,9,256,1,272,1,0,269,1,261,3,0,0,273,260,1,261,17,2,268,16,0,0,0,1,21,1,257,261,1,1]

theorem envBound20245 : H12AffineFastState.Bounded env20245 := by
  intro p hp
  have h : env20245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20244_20245 : H12AffineEnvironment.transform 4 0 env20244 = env20245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20244 == env20245) = true)

theorem identity20245 : scanCanonicalize (H12AffineFastState.compose env20245 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20245 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20246 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,0,9,1,1,3,0,0,21,0,1,1,17,2,8,16,0,0,0,1,21,1,5,1,1,1]

theorem envBound20246 : H12AffineFastState.Bounded env20246 := by
  intro p hp
  have h : env20246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20245_20246 : H12AffineEnvironment.transform 7 4 env20245 = env20246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20245 == env20246) = true)

def leafEnv20246 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,0,9,1,1,3,0,0,21,0,1,1,17,2,20,8,1,16,0,0,0,1,21,1,5,1,5,3,1,1,0,1,1]

def active20246 : List Nat := [0,1,2,3]

def tree20246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20246 : H12WitnessSearch.Good tree20246 := H12GlobalWitnessIndex.good

theorem leafIdentity20246 : H12AffineFastState.composeSystem env20246 rootObs = leafEnv20246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20246 rootObs == leafEnv20246) = true)

theorem terminalChecked20246 : H12PackedTerminal.terminalCheckFast leafEnv20246 active20246 tree20246 = true := by decide +kernel

def env20247 : List Nat := [2,4,8,16,1,17,9,256,1,272,1,0,269,1,260,2,0,0,273,261,1,261,17,2,268,16,0,0,0,1,21,1,257,260,1,1]

theorem envBound20247 : H12AffineFastState.Bounded env20247 := by
  intro p hp
  have h : env20247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20244_20247 : H12AffineEnvironment.transform 4 1 env20244 = env20247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20244 == env20247) = true)

def leafEnv20247 : List Nat := [2,4,8,16,1,17,9,256,1,272,1,0,269,1,260,2,0,0,273,261,1,261,17,2,20,268,1,16,0,0,0,1,21,1,257,260,5,2,1,1,0,1,1]

def active20247 : List Nat := [0,1,2,3,7]

def tree20247 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20247 : H12WitnessSearch.Good tree20247 := H12GlobalWitnessIndex.good

theorem leafIdentity20247 : H12AffineFastState.composeSystem env20247 rootObs = leafEnv20247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20247 rootObs == leafEnv20247) = true)

theorem terminalChecked20247 : H12PackedTerminal.terminalCheckFast leafEnv20247 active20247 tree20247 = true := by decide +kernel

def env20248 : List Nat := [2,4,8,16,32,17,128,256,136,273,1,1,8192,0,293,65536,1,8461,272,292,0,8200,17,65569,8328,16,0,1,1,8460,20,4294967296,257,4295041155,0,136]

theorem envBound20248 : H12AffineFastState.Bounded env20248 := by
  intro p hp
  have h : env20248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20234_20248 : H12AffineEnvironment.transform 9 273 env20234 = env20248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20234 == env20248) = true)

def env20249 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,8192,0,1,65536,1,8233,52,0,0,8200,17,65569,8328,16,0,1,1,8232,20,4294967296,37,4295041155,0,136]

theorem envBound20249 : H12AffineFastState.Bounded env20249 := by
  intro p hp
  have h : env20249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20248_20249 : H12AffineEnvironment.transform 7 36 env20248 = env20249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20248 == env20249) = true)

def env20250 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,160,0,1,65536,1,137,52,0,0,168,17,65569,40,16,0,1,1,136,20,4294967296,37,4295032867,0,136]

theorem envBound20250 : H12AffineFastState.Bounded env20250 := by
  intro p hp
  have h : env20250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20249_20250 : H12AffineEnvironment.transform 12 160 env20249 = env20250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20249 == env20250) = true)

theorem identity20250 : scanCanonicalize (H12AffineFastState.compose env20250 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound20250 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20251 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,160,0,1,65536,1,137,52,0,0,168,17,65569,40,16,0,1,1,136,20,65570,37,1,0,136]

theorem envBound20251 : H12AffineFastState.Bounded env20251 := by
  intro p hp
  have h : env20251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20250_20251 : H12AffineEnvironment.transform 31 65570 env20250 = env20251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env20250 == env20251) = true)

def env20252 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,128,0,1,65536,1,137,20,0,0,136,17,65537,8,16,0,1,1,136,20,65538,5,1,0,136]

theorem envBound20252 : H12AffineFastState.Bounded env20252 := by
  intro p hp
  have h : env20252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20251_20252 : H12AffineEnvironment.transform 4 0 env20251 = env20252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20251 == env20252) = true)

theorem identity20252 : scanCanonicalize (H12AffineFastState.compose env20252 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound20252 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20253 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,128,0,1,3,1,137,20,0,0,136,17,2,8,16,0,1,1,136,20,1,5,1,0,136]

theorem envBound20253 : H12AffineFastState.Bounded env20253 := by
  intro p hp
  have h : env20253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20252_20253 : H12AffineEnvironment.transform 15 3 env20252 = env20253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env20252 == env20253) = true)

def leafEnv20253 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,128,0,1,3,1,137,20,0,0,136,17,2,21,8,1,16,0,1,1,136,20,1,5,1,5,3,0,136,0,0,1]

def active20253 : List Nat := [0,1,2,3,6]

def tree20253 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20253 : H12WitnessSearch.Good tree20253 := H12GlobalWitnessIndex.good

theorem leafIdentity20253 : H12AffineFastState.composeSystem env20253 rootObs = leafEnv20253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20253 rootObs == leafEnv20253) = true)

theorem terminalChecked20253 : H12PackedTerminal.terminalCheckFast leafEnv20253 active20253 tree20253 = true := by decide +kernel

def env20254 : List Nat := [2,4,8,16,1,17,128,5,136,20,1,1,129,0,1,65536,1,137,21,0,0,137,17,65536,9,16,0,1,1,136,20,65539,4,1,0,136]

theorem envBound20254 : H12AffineFastState.Bounded env20254 := by
  intro p hp
  have h : env20254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20251_20254 : H12AffineEnvironment.transform 4 1 env20251 = env20254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20251 == env20254) = true)

theorem identity20254 : scanCanonicalize (H12AffineFastState.compose env20254 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20254 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20255 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,1,8,0,1,65536,1,0,21,0,0,0,17,65536,9,16,0,1,1,1,20,65539,4,1,0,1]

theorem envBound20255 : H12AffineFastState.Bounded env20255 := by
  intro p hp
  have h : env20255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20254_20255 : H12AffineEnvironment.transform 6 9 env20254 = env20255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20254 == env20255) = true)

def leafEnv20255 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,1,8,0,1,65536,1,0,21,0,0,0,17,65536,21,9,1,16,0,1,1,1,20,65539,4,1,5,2,0,1,0,0,1]

def active20255 : List Nat := [0,1,2,3,15]

def tree20255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20255 : H12WitnessSearch.Good tree20255 := H12GlobalWitnessIndex.good

theorem leafIdentity20255 : H12AffineFastState.composeSystem env20255 rootObs = leafEnv20255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20255 rootObs == leafEnv20255) = true)

theorem terminalChecked20255 : H12PackedTerminal.terminalCheckFast leafEnv20255 active20255 tree20255 = true := by decide +kernel

def env20256 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,161,0,1,65536,1,136,52,0,0,169,17,65569,41,16,0,1,1,137,20,4294967296,37,4295032866,0,136]

theorem envBound20256 : H12AffineFastState.Bounded env20256 := by
  intro p hp
  have h : env20256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20249_20256 : H12AffineEnvironment.transform 12 161 env20249 = env20256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20249 == env20256) = true)

theorem identity20256 : scanCanonicalize (H12AffineFastState.compose env20256 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound20256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20257 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,161,0,1,65536,1,136,52,0,0,169,17,65569,41,16,0,1,1,137,20,65706,37,136,0,136]

theorem envBound20257 : H12AffineFastState.Bounded env20257 := by
  intro p hp
  have h : env20257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20256_20257 : H12AffineEnvironment.transform 31 65706 env20256 = env20257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env20256 == env20257) = true)

def env20258 : List Nat := [2,4,8,16,32,17,8,36,0,53,1,1,41,0,1,65536,1,0,52,0,0,33,17,65569,41,16,0,1,1,1,20,65570,37,0,0,0]

theorem envBound20258 : H12AffineFastState.Bounded env20258 := by
  intro p hp
  have h : env20258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20257_20258 : H12AffineEnvironment.transform 6 8 env20257 = env20258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20257 == env20258) = true)

def env20259 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,1,9,0,1,65536,1,0,20,0,0,1,17,65537,9,16,0,1,1,1,20,65538,5,0,0,0]

theorem envBound20259 : H12AffineFastState.Bounded env20259 := by
  intro p hp
  have h : env20259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20258_20259 : H12AffineEnvironment.transform 4 0 env20258 = env20259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20258 == env20259) = true)

theorem identity20259 : scanCanonicalize (H12AffineFastState.compose env20259 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound20259 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20260 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,1,9,0,1,2,1,0,20,0,0,1,17,3,9,16,0,1,1,1,20,0,5,0,0,0]

theorem envBound20260 : H12AffineFastState.Bounded env20260 := by
  intro p hp
  have h : env20260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20259_20260 : H12AffineEnvironment.transform 15 2 env20259 = env20260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env20259 == env20260) = true)

def leafEnv20260 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,1,9,0,1,2,1,0,20,0,0,1,17,3,21,9,1,16,0,1,1,1,20,0,5,0,5,3,0,0,0,0,1]

def active20260 : List Nat := [0,1,2,3]

def tree20260 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20260 : H12WitnessSearch.Good tree20260 := H12GlobalWitnessIndex.good

theorem leafIdentity20260 : H12AffineFastState.composeSystem env20260 rootObs = leafEnv20260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20260 rootObs == leafEnv20260) = true)

theorem terminalChecked20260 : H12PackedTerminal.terminalCheckFast leafEnv20260 active20260 tree20260 = true := by decide +kernel

def env20261 : List Nat := [2,4,8,16,1,17,8,5,0,20,1,1,8,0,1,65536,1,0,21,0,0,0,17,65536,8,16,0,1,1,1,20,65539,4,0,0,0]

theorem envBound20261 : H12AffineFastState.Bounded env20261 := by
  intro p hp
  have h : env20261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20258_20261 : H12AffineEnvironment.transform 4 1 env20258 = env20261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20258 == env20261) = true)

def leafEnv20261 : List Nat := [2,4,8,16,1,17,8,5,0,20,1,1,8,0,1,65536,1,0,21,0,0,0,17,65536,21,8,1,16,0,1,1,1,20,65539,4,0,5,2,0,0,0,0,1]

def active20261 : List Nat := [0,1,2,3,15]

def tree20261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20261 : H12WitnessSearch.Good tree20261 := H12GlobalWitnessIndex.good

theorem leafIdentity20261 : H12AffineFastState.composeSystem env20261 rootObs = leafEnv20261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20261 rootObs == leafEnv20261) = true)

theorem terminalChecked20261 : H12PackedTerminal.terminalCheckFast leafEnv20261 active20261 tree20261 = true := by decide +kernel

def env20262 : List Nat := [2,4,8,16,32,17,9,36,1,53,1,1,40,0,1,65536,1,1,52,0,0,32,17,65569,41,16,0,1,1,0,20,65571,37,1,0,1]

theorem envBound20262 : H12AffineFastState.Bounded env20262 := by
  intro p hp
  have h : env20262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20257_20262 : H12AffineEnvironment.transform 6 9 env20257 = env20262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20257 == env20262) = true)

theorem identity20262 : scanCanonicalize (H12AffineFastState.compose env20262 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound20262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20263 : List Nat := [2,4,8,16,32,17,9,36,1,53,1,1,40,0,1,2,1,1,52,0,0,32,17,35,41,16,0,1,1,0,20,33,37,1,0,1]

theorem envBound20263 : H12AffineFastState.Bounded env20263 := by
  intro p hp
  have h : env20263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20262_20263 : H12AffineEnvironment.transform 15 2 env20262 = env20263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env20262 == env20263) = true)

theorem identity20263 : scanCanonicalize (H12AffineFastState.compose env20263 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20263 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20264 : List Nat := [2,4,8,16,0,17,9,4,1,21,1,1,8,0,1,2,1,1,20,0,0,0,17,3,9,16,0,1,1,0,20,1,5,1,0,1]

theorem envBound20264 : H12AffineFastState.Bounded env20264 := by
  intro p hp
  have h : env20264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20263_20264 : H12AffineEnvironment.transform 4 0 env20263 = env20264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20263 == env20264) = true)

def leafEnv20264 : List Nat := [2,4,8,16,0,17,9,4,1,21,1,1,8,0,1,2,1,1,20,0,0,0,17,3,21,9,1,16,0,1,1,0,20,1,5,1,5,3,0,1,0,0,1]

def active20264 : List Nat := [0,1,2,3]

def tree20264 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20264 : H12WitnessSearch.Good tree20264 := H12GlobalWitnessIndex.good

theorem leafIdentity20264 : H12AffineFastState.composeSystem env20264 rootObs = leafEnv20264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20264 rootObs == leafEnv20264) = true)

theorem terminalChecked20264 : H12PackedTerminal.terminalCheckFast leafEnv20264 active20264 tree20264 = true := by decide +kernel

def env20265 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,8192,0,0,65536,1,8232,53,1,0,8200,17,65569,8328,16,0,1,1,8233,20,4294967296,36,4295041155,0,136]

theorem envBound20265 : H12AffineFastState.Bounded env20265 := by
  intro p hp
  have h : env20265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20248_20265 : H12AffineEnvironment.transform 7 37 env20248 = env20265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20248 == env20265) = true)

def env20266 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,160,0,0,65536,1,136,53,1,0,168,17,65569,40,16,0,1,1,137,20,4294967296,36,4295032867,0,136]

theorem envBound20266 : H12AffineFastState.Bounded env20266 := by
  intro p hp
  have h : env20266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20265_20266 : H12AffineEnvironment.transform 12 160 env20265 = env20266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20265 == env20266) = true)

theorem identity20266 : scanCanonicalize (H12AffineFastState.compose env20266 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound20266 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20267 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,160,0,0,65536,1,136,53,1,0,168,17,65569,40,16,0,1,1,137,20,1,36,65570,0,136]

theorem envBound20267 : H12AffineFastState.Bounded env20267 := by
  intro p hp
  have h : env20267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20266_20267 : H12AffineEnvironment.transform 31 1 env20266 = env20267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env20266 == env20267) = true)

def env20268 : List Nat := [2,4,8,16,0,17,128,5,136,20,1,1,128,0,0,65536,1,136,21,1,0,136,17,65537,8,16,0,1,1,137,20,1,4,65538,0,136]

theorem envBound20268 : H12AffineFastState.Bounded env20268 := by
  intro p hp
  have h : env20268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20267_20268 : H12AffineEnvironment.transform 4 0 env20267 = env20268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20267 == env20268) = true)

theorem identity20268 : scanCanonicalize (H12AffineFastState.compose env20268 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound20268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20269 : List Nat := [2,4,8,16,0,17,128,5,136,20,1,1,128,0,0,2,1,136,21,1,0,136,17,3,8,16,0,1,1,137,20,1,4,0,0,136]

theorem envBound20269 : H12AffineFastState.Bounded env20269 := by
  intro p hp
  have h : env20269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20268_20269 : H12AffineEnvironment.transform 15 2 env20268 = env20269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env20268 == env20269) = true)

theorem identity20269 : scanCanonicalize (H12AffineFastState.compose env20269 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20269 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20270 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,8,0,0,2,1,0,21,1,0,0,17,3,8,16,0,1,1,1,20,1,4,0,0,0]

theorem envBound20270 : H12AffineFastState.Bounded env20270 := by
  intro p hp
  have h : env20270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20269_20270 : H12AffineEnvironment.transform 6 8 env20269 = env20270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20269 == env20270) = true)

def leafEnv20270 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,8,0,0,2,1,0,21,1,0,0,17,3,21,8,1,16,0,1,1,1,20,1,4,0,5,3,0,0,0,0,1]

def active20270 : List Nat := [0,1,2,3]

def tree20270 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20270 : H12WitnessSearch.Good tree20270 := H12GlobalWitnessIndex.good

theorem leafIdentity20270 : H12AffineFastState.composeSystem env20270 rootObs = leafEnv20270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20270 rootObs == leafEnv20270) = true)

theorem terminalChecked20270 : H12PackedTerminal.terminalCheckFast leafEnv20270 active20270 tree20270 = true := by decide +kernel

def env20271 : List Nat := [2,4,8,16,1,17,128,4,136,21,1,1,129,0,0,65536,1,136,20,1,0,137,17,65536,9,16,0,1,1,137,20,1,5,65539,0,136]

theorem envBound20271 : H12AffineFastState.Bounded env20271 := by
  intro p hp
  have h : env20271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20267_20271 : H12AffineEnvironment.transform 4 1 env20267 = env20271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20267 == env20271) = true)

theorem identity20271 : scanCanonicalize (H12AffineFastState.compose env20271 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound20271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20272 : List Nat := [2,4,8,16,1,17,128,4,136,21,1,1,129,0,0,138,1,136,20,1,0,137,17,138,9,16,0,1,1,137,20,1,5,137,0,136]

theorem envBound20272 : H12AffineFastState.Bounded env20272 := by
  intro p hp
  have h : env20272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20271_20272 : H12AffineEnvironment.transform 15 138 env20271 = env20272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env20271 == env20272) = true)

theorem identity20272 : scanCanonicalize (H12AffineFastState.compose env20272 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20272 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20273 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,8,0,0,3,1,1,20,1,0,0,17,3,9,16,0,1,1,0,20,1,5,0,0,1]

theorem envBound20273 : H12AffineFastState.Bounded env20273 := by
  intro p hp
  have h : env20273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20272_20273 : H12AffineEnvironment.transform 6 9 env20272 = env20273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20272 == env20273) = true)

def leafEnv20273 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,8,0,0,3,1,1,20,1,0,0,17,3,21,9,1,16,0,1,1,0,20,1,5,0,5,2,0,1,0,0,1]

def active20273 : List Nat := [0,1,2,3]

def tree20273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20273 : H12WitnessSearch.Good tree20273 := H12GlobalWitnessIndex.good

theorem leafIdentity20273 : H12AffineFastState.composeSystem env20273 rootObs = leafEnv20273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20273 rootObs == leafEnv20273) = true)

theorem terminalChecked20273 : H12PackedTerminal.terminalCheckFast leafEnv20273 active20273 tree20273 = true := by decide +kernel

def env20274 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,161,0,0,65536,1,137,53,1,0,169,17,65569,41,16,0,1,1,136,20,4294967296,36,4295032866,0,136]

theorem envBound20274 : H12AffineFastState.Bounded env20274 := by
  intro p hp
  have h : env20274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20265_20274 : H12AffineEnvironment.transform 12 161 env20265 = env20274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20265 == env20274) = true)

theorem identity20274 : scanCanonicalize (H12AffineFastState.compose env20274 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound20274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20275 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,161,0,0,65536,1,137,53,1,0,169,17,65569,41,16,0,1,1,136,20,136,36,65706,0,136]

theorem envBound20275 : H12AffineFastState.Bounded env20275 := by
  intro p hp
  have h : env20275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20274_20275 : H12AffineEnvironment.transform 31 136 env20274 = env20275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env20274 == env20275) = true)

def env20276 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,41,0,0,65536,1,1,53,1,0,33,17,65569,41,16,0,1,1,0,20,0,36,65570,0,0]

theorem envBound20276 : H12AffineFastState.Bounded env20276 := by
  intro p hp
  have h : env20276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20275_20276 : H12AffineEnvironment.transform 6 8 env20275 = env20276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20275 == env20276) = true)

theorem identity20276 : scanCanonicalize (H12AffineFastState.compose env20276 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound20276 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20277 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,41,0,0,35,1,1,53,1,0,33,17,2,41,16,0,1,1,0,20,0,36,1,0,0]

theorem envBound20277 : H12AffineFastState.Bounded env20277 := by
  intro p hp
  have h : env20277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20276_20277 : H12AffineEnvironment.transform 15 35 env20276 = env20277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env20276 == env20277) = true)

theorem identity20277 : scanCanonicalize (H12AffineFastState.compose env20277 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20277 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20278 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,0,0,2,1,1,20,1,0,0,17,2,8,16,0,1,1,0,20,0,5,1,0,0]

theorem envBound20278 : H12AffineFastState.Bounded env20278 := by
  intro p hp
  have h : env20278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20277_20278 : H12AffineEnvironment.transform 4 1 env20277 = env20278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20277 == env20278) = true)

def leafEnv20278 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,0,0,2,1,1,20,1,0,0,17,2,21,8,1,16,0,1,1,0,20,0,5,1,5,2,0,0,0,0,1]

def active20278 : List Nat := [0,1,2,3]

def tree20278 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20278 : H12WitnessSearch.Good tree20278 := H12GlobalWitnessIndex.good

theorem leafIdentity20278 : H12AffineFastState.composeSystem env20278 rootObs = leafEnv20278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20278 rootObs == leafEnv20278) = true)

theorem terminalChecked20278 : H12PackedTerminal.terminalCheckFast leafEnv20278 active20278 tree20278 = true := by decide +kernel

def env20279 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,40,0,0,65536,1,0,53,1,0,32,17,65569,41,16,0,1,1,1,20,1,36,65571,0,1]

theorem envBound20279 : H12AffineFastState.Bounded env20279 := by
  intro p hp
  have h : env20279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20275_20279 : H12AffineEnvironment.transform 6 9 env20275 = env20279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20275 == env20279) = true)

theorem identity20279 : scanCanonicalize (H12AffineFastState.compose env20279 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20279 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20280 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,9,0,0,65536,1,0,20,1,0,1,17,65536,8,16,0,1,1,1,20,1,5,65538,0,1]

theorem envBound20280 : H12AffineFastState.Bounded env20280 := by
  intro p hp
  have h : env20280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20279_20280 : H12AffineEnvironment.transform 4 1 env20279 = env20280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20279 == env20280) = true)

theorem identity20280 : scanCanonicalize (H12AffineFastState.compose env20280 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound20280 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20281 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,9,0,0,2,1,0,20,1,0,1,17,2,8,16,0,1,1,1,20,1,5,0,0,1]

theorem envBound20281 : H12AffineFastState.Bounded env20281 := by
  intro p hp
  have h : env20281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20280_20281 : H12AffineEnvironment.transform 15 2 env20280 = env20281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env20280 == env20281) = true)

def leafEnv20281 : List Nat := [2,4,8,16,1,17,9,4,1,21,1,1,9,0,0,2,1,0,20,1,0,1,17,2,21,8,1,16,0,1,1,1,20,1,5,0,5,2,0,1,0,0,1]

def active20281 : List Nat := [0,1,2,3]

def tree20281 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20281 : H12WitnessSearch.Good tree20281 := H12GlobalWitnessIndex.good

theorem leafIdentity20281 : H12AffineFastState.composeSystem env20281 rootObs = leafEnv20281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20281 rootObs == leafEnv20281) = true)

theorem terminalChecked20281 : H12PackedTerminal.terminalCheckFast leafEnv20281 active20281 tree20281 = true := by decide +kernel

def env20282 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,8192,1296,293,65536,1296,8460,1024,292,1297,8200,16,65569,8328,16,0,1297,1296,8461,1285,4294967296,257,4295041155,1297,137]

theorem envBound20282 : H12AffineFastState.Bounded env20282 := by
  intro p hp
  have h : env20282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20233_20282 : H12AffineEnvironment.transform 8 137 env20233 = env20282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20233 == env20282) = true)

theorem identity20282 : scanCanonicalize (H12AffineFastState.compose env20282 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20282 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20283 : List Nat := [2,4,8,16,32,17,128,37,137,1024,1,1077,8192,1077,0,65536,1077,8233,1024,1,1076,8200,16,65569,8328,16,0,1076,1077,8232,1056,4294967296,36,4295041155,1076,137]

theorem envBound20283 : H12AffineFastState.Bounded env20283 := by
  intro p hp
  have h : env20283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20282_20283 : H12AffineEnvironment.transform 7 37 env20282 = env20283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20282 == env20283) = true)

theorem identity20283 : scanCanonicalize (H12AffineFastState.compose env20283 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20283 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20284 : List Nat := [2,4,8,16,32,17,128,37,137,1024,1,1077,8192,1077,0,170,1077,8233,1024,1,1076,8200,16,139,8328,16,0,1076,1077,8232,1056,4294967296,36,4294975529,1076,137]

theorem envBound20284 : H12AffineFastState.Bounded env20284 := by
  intro p hp
  have h : env20284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20283_20284 : H12AffineEnvironment.transform 15 170 env20283 = env20284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20283 == env20284) = true)

theorem identity20284 : scanCanonicalize (H12AffineFastState.compose env20284 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound20284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20285 : List Nat := [2,4,8,16,32,17,128,37,137,1024,1,1077,139,1077,0,170,1077,162,1024,1,1076,131,16,139,3,16,0,1076,1077,163,1056,4294967296,36,4294967458,1076,137]

theorem envBound20285 : H12AffineFastState.Bounded env20285 := by
  intro p hp
  have h : env20285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20284_20285 : H12AffineEnvironment.transform 12 139 env20284 = env20285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env20284 == env20285) = true)

theorem identity20285 : scanCanonicalize (H12AffineFastState.compose env20285 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20285 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20286 : List Nat := [2,4,8,16,32,17,34,37,43,1024,1,1077,41,1077,0,8,1077,0,1024,1,1076,33,16,41,3,16,0,1076,1077,1,1056,4294967296,36,4294967296,1076,43]

theorem envBound20286 : H12AffineFastState.Bounded env20286 := by
  intro p hp
  have h : env20286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20285_20286 : H12AffineEnvironment.transform 6 34 env20285 = env20286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20285 == env20286) = true)

theorem identity20286 : scanCanonicalize (H12AffineFastState.compose env20286 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound20286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20287 : List Nat := [2,4,8,16,32,17,34,37,43,1024,1,1077,41,1077,0,8,1077,0,1024,1,1076,33,16,41,3,16,0,1076,1077,1,1056,42,36,42,1076,43]

theorem envBound20287 : H12AffineFastState.Bounded env20287 := by
  intro p hp
  have h : env20287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20286_20287 : H12AffineEnvironment.transform 31 42 env20286 = env20287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env20286 == env20287) = true)

theorem identity20287 : scanCanonicalize (H12AffineFastState.compose env20287 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20288 : List Nat := [2,4,8,16,16,17,18,21,27,1024,1,1029,25,1029,0,8,1029,0,1024,1,1028,17,16,25,3,16,0,1028,1029,1,1040,26,20,26,1028,27]

theorem envBound20288 : H12AffineFastState.Bounded env20288 := by
  intro p hp
  have h : env20288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20287_20288 : H12AffineEnvironment.transform 4 16 env20287 = env20288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20287 == env20288) = true)

def leafEnv20288 : List Nat := [2,4,8,16,16,17,18,21,27,1024,1,1029,25,1029,0,8,1029,0,1024,1,1028,17,16,25,1040,3,1,16,0,1028,1029,1,1040,26,20,26,5,19,1028,27,0,1028,1]

def active20288 : List Nat := [0,1,2,3,9]

def tree20288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20288 : H12WitnessSearch.Good tree20288 := H12GlobalWitnessIndex.good

theorem leafIdentity20288 : H12AffineFastState.composeSystem env20288 rootObs = leafEnv20288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20288 rootObs == leafEnv20288) = true)

theorem terminalChecked20288 : H12PackedTerminal.terminalCheckFast leafEnv20288 active20288 tree20288 = true := by decide +kernel

def env20289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,293,65536,1345,262144,271628,292,1296,8200,17664,65569,8328,287837,0,16385,287068,262145,1285,4294967296,257,4295041155,1344,512]

theorem envBound20289 : H12AffineFastState.Bounded env20289 := by
  intro p hp
  have h : env20289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20214_20289 : H12AffineEnvironment.transform 11 1297 env20214 = env20289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20214 == env20289) = true)

theorem identity20289 : scanCanonicalize (H12AffineFastState.compose env20289 (packedSelected [1,3,5,8,12,13,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20289 : packedSelected [1,3,5,8,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env20290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,293,170,1345,262144,271628,292,1296,8200,17664,139,8328,287837,0,16385,287068,262145,1285,4294967296,257,4294975529,1344,512]

theorem envBound20290 : H12AffineFastState.Bounded env20290 := by
  intro p hp
  have h : env20290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20289_20290 : H12AffineEnvironment.transform 15 170 env20289 = env20290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20289 == env20290) = true)

def env20291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,293,170,1345,8864,1964,292,1296,8200,17664,139,8328,18173,0,16385,17404,8865,1285,4294967296,257,4294975529,1344,512]

theorem envBound20291 : H12AffineFastState.Bounded env20291 := by
  intro p hp
  have h : env20291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20290_20291 : H12AffineEnvironment.transform 17 8864 env20290 = env20291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8864 env20290 == env20291) = true)

theorem identity20291 : scanCanonicalize (H12AffineFastState.compose env20291 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1772) := by decide +kernel

theorem selectedBound20291 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1772,293,170,1345,8864,1964,292,1296,8200,1004,139,8328,17,0,1773,1296,8865,1285,4294967296,257,4294975529,1344,512]

theorem envBound20292 : H12AffineFastState.Bounded env20292 := by
  intro p hp
  have h : env20292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20291_20292 : H12AffineEnvironment.transform 13 1772 env20291 = env20292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1772 env20291 == env20292) = true)

theorem identity20292 : scanCanonicalize (H12AffineFastState.compose env20292 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound20292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,672,1772,293,170,1345,0,1964,292,1296,680,1004,139,552,17,0,1773,1296,1,1285,4294967296,257,4294967945,1344,512]

theorem envBound20293 : H12AffineFastState.Bounded env20293 := by
  intro p hp
  have h : env20293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20292_20293 : H12AffineEnvironment.transform 12 672 env20292 = env20293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20292 == env20293) = true)

def env20294 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,1297,632,1588,293,114,1345,0,1908,292,1296,624,820,83,552,17,0,1589,1296,1,1285,4294967296,257,4294967889,1344,512]

theorem envBound20294 : H12AffineFastState.Bounded env20294 := by
  intro p hp
  have h : env20294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20293_20294 : H12AffineEnvironment.transform 6 88 env20293 = env20294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20293 == env20294) = true)

theorem identity20294 : scanCanonicalize (H12AffineFastState.compose env20294 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound20294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20295 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,1297,632,1588,293,114,1345,0,1908,292,1296,624,820,83,552,17,0,1589,1296,1,1285,513,257,80,1344,512]

theorem envBound20295 : H12AffineFastState.Bounded env20295 := by
  intro p hp
  have h : env20295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20294_20295 : H12AffineEnvironment.transform 31 513 env20294 = env20295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env20294 == env20295) = true)

theorem identity20295 : scanCanonicalize (H12AffineFastState.compose env20295 (packedSelected [2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20295 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env20296 : List Nat := [2,4,8,16,32,64,88,37,512,1024,1,1076,632,1588,0,114,1124,0,1617,1,1077,624,529,83,552,17,0,1589,1077,1,1056,513,36,80,1125,512]

theorem envBound20296 : H12AffineFastState.Bounded env20296 := by
  intro p hp
  have h : env20296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20295_20296 : H12AffineEnvironment.transform 7 37 env20295 = env20296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20295 == env20296) = true)

def env20297 : List Nat := [2,4,8,16,32,64,88,37,80,1024,1,1076,40,1124,0,114,1124,0,1025,1,1077,32,65,83,120,17,0,1125,1077,1,1056,81,36,80,1125,80]

theorem envBound20297 : H12AffineFastState.Bounded env20297 := by
  intro p hp
  have h : env20297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20296_20297 : H12AffineEnvironment.transform 8 80 env20296 = env20297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env20296 == env20297) = true)

theorem identity20297 : scanCanonicalize (H12AffineFastState.compose env20297 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20298 : List Nat := [2,4,8,16,32,49,41,37,33,1024,1,1076,40,1045,0,3,1045,0,1025,1,1077,32,48,34,9,17,0,1044,1077,1,1056,32,36,33,1044,33]

theorem envBound20298 : H12AffineFastState.Bounded env20298 := by
  intro p hp
  have h : env20298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20297_20298 : H12AffineEnvironment.transform 5 49 env20297 = env20298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20297 == env20298) = true)

def leafEnv20298 : List Nat := [2,4,8,16,32,49,41,37,33,1024,1,1076,40,1045,0,3,1045,0,1025,1,1077,32,48,34,1057,9,1,17,0,1044,1077,1,1056,32,36,33,5,35,1044,33,0,1076,1]

def active20298 : List Nat := [0,1,2,3,4,9]

def tree20298 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20298 : H12WitnessSearch.Good tree20298 := H12GlobalWitnessIndex.good

theorem leafIdentity20298 : H12AffineFastState.composeSystem env20298 rootObs = leafEnv20298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20298 rootObs == leafEnv20298) = true)

theorem terminalChecked20298 : H12PackedTerminal.terminalCheckFast leafEnv20298 active20298 tree20298 = true := by decide +kernel

def env20299 : List Nat := [2,4,8,16,32,64,88,37,81,1024,1,1076,41,1125,0,114,1124,0,1024,1,1077,33,64,83,121,17,0,1124,1077,1,1056,80,36,80,1125,81]

theorem envBound20299 : H12AffineFastState.Bounded env20299 := by
  intro p hp
  have h : env20299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20296_20299 : H12AffineEnvironment.transform 8 81 env20296 = env20299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env20296 == env20299) = true)

theorem identity20299 : scanCanonicalize (H12AffineFastState.compose env20299 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20299 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20300 : List Nat := [2,4,8,16,10,64,88,15,81,1024,1,1054,3,1103,0,88,1102,0,1024,1,1055,11,64,83,83,17,0,1102,1055,1,1034,80,14,80,1103,81]

theorem envBound20300 : H12AffineFastState.Bounded env20300 := by
  intro p hp
  have h : env20300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20299_20300 : H12AffineEnvironment.transform 4 10 env20299 = env20300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20299 == env20300) = true)

theorem identity20300 : scanCanonicalize (H12AffineFastState.compose env20300 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound20300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20301 : List Nat := [2,4,8,16,10,10,18,15,27,1024,1,1054,3,1029,0,18,1028,0,1024,1,1055,11,10,25,25,17,0,1028,1055,1,1034,26,14,26,1029,27]

theorem envBound20301 : H12AffineFastState.Bounded env20301 := by
  intro p hp
  have h : env20301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20300_20301 : H12AffineEnvironment.transform 5 10 env20300 = env20301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env20300 == env20301) = true)

def leafEnv20301 : List Nat := [2,4,8,16,10,10,18,15,27,1024,1,1054,3,1029,0,18,1028,0,1024,1,1055,11,10,25,1034,25,1,17,0,1028,1055,1,1034,26,14,26,5,9,1029,27,0,1054,1]

def active20301 : List Nat := [0,1,2,3,9]

def tree20301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20301 : H12WitnessSearch.Good tree20301 := H12GlobalWitnessIndex.good

theorem leafIdentity20301 : H12AffineFastState.composeSystem env20301 rootObs = leafEnv20301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20301 rootObs == leafEnv20301) = true)

theorem terminalChecked20301 : H12PackedTerminal.terminalCheckFast leafEnv20301 active20301 tree20301 = true := by decide +kernel

def env20302 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1,1297,633,1589,293,115,1345,0,1909,292,1296,625,821,82,552,17,0,1588,1296,1,1285,4294967296,257,4294967888,1344,512]

theorem envBound20302 : H12AffineFastState.Bounded env20302 := by
  intro p hp
  have h : env20302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20293_20302 : H12AffineEnvironment.transform 6 89 env20293 = env20302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20293 == env20302) = true)

theorem identity20302 : scanCanonicalize (H12AffineFastState.compose env20302 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 372) := by decide +kernel

theorem selectedBound20302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20303 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1,1297,633,1589,293,115,1345,0,1909,292,1296,625,821,82,552,17,0,1588,1296,1,1285,372,257,804,1344,512]

theorem envBound20303 : H12AffineFastState.Bounded env20303 := by
  intro p hp
  have h : env20303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20302_20303 : H12AffineEnvironment.transform 31 372 env20302 = env20303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 372 env20302 == env20303) = true)

def env20304 : List Nat := [2,4,8,16,32,64,89,256,372,1024,1,1297,269,1345,293,115,1345,0,1025,292,1296,261,65,82,348,17,0,1344,1296,1,1285,372,257,80,1344,372]

theorem envBound20304 : H12AffineFastState.Bounded env20304 := by
  intro p hp
  have h : env20304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20303_20304 : H12AffineEnvironment.transform 8 372 env20303 = env20304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env20303 == env20304) = true)

theorem identity20304 : scanCanonicalize (H12AffineFastState.compose env20304 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20305 : List Nat := [2,4,8,16,32,64,89,36,80,1024,1,1077,41,1125,1,115,1125,0,1025,0,1076,33,65,82,120,17,0,1124,1076,1,1057,80,37,80,1124,80]

theorem envBound20305 : H12AffineFastState.Bounded env20305 := by
  intro p hp
  have h : env20305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20304_20305 : H12AffineEnvironment.transform 7 36 env20304 = env20305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20304 == env20305) = true)

def env20306 : List Nat := [2,4,8,16,32,64,89,256,373,1024,1,1297,268,1344,293,115,1345,0,1024,292,1296,260,64,82,349,17,0,1345,1296,1,1285,372,257,81,1344,373]

theorem envBound20306 : H12AffineFastState.Bounded env20306 := by
  intro p hp
  have h : env20306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20303_20306 : H12AffineEnvironment.transform 8 373 env20303 = env20306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env20303 == env20306) = true)

theorem identity20306 : scanCanonicalize (H12AffineFastState.compose env20306 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound20306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20307 : List Nat := [2,4,8,16,32,64,89,15,122,1024,1,1054,3,1103,42,115,1102,0,1024,43,1055,11,64,82,82,17,0,1102,1055,1,1034,123,14,81,1103,122]

theorem envBound20307 : H12AffineFastState.Bounded env20307 := by
  intro p hp
  have h : env20307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20306_20307 : H12AffineEnvironment.transform 7 15 env20306 = env20307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env20306 == env20307) = true)

theorem identity20307 : scanCanonicalize (H12AffineFastState.compose env20307 (packedSelected [2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20307 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env20308 : List Nat := [2,4,8,16,10,64,89,15,80,1024,1,1054,3,1103,0,89,1102,0,1024,1,1055,11,64,82,82,17,0,1102,1055,1,1034,81,14,81,1103,80]

theorem envBound20308 : H12AffineFastState.Bounded env20308 := by
  intro p hp
  have h : env20308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20307_20308 : H12AffineEnvironment.transform 4 10 env20307 = env20308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20307 == env20308) = true)

theorem identity20308 : scanCanonicalize (H12AffineFastState.compose env20308 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound20308 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20309 : List Nat := [2,4,8,16,10,10,19,15,26,1024,1,1054,3,1029,0,19,1028,0,1024,1,1055,11,10,24,24,17,0,1028,1055,1,1034,27,14,27,1029,26]

theorem envBound20309 : H12AffineFastState.Bounded env20309 := by
  intro p hp
  have h : env20309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20308_20309 : H12AffineEnvironment.transform 5 10 env20308 = env20309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env20308 == env20309) = true)

def leafEnv20309 : List Nat := [2,4,8,16,10,10,19,15,26,1024,1,1054,3,1029,0,19,1028,0,1024,1,1055,11,10,24,1034,24,1,17,0,1028,1055,1,1034,27,14,27,5,9,1029,26,0,1054,1]

def active20309 : List Nat := [0,1,2,3,9]

def tree20309 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20309 : H12WitnessSearch.Good tree20309 := H12GlobalWitnessIndex.good

theorem leafIdentity20309 : H12AffineFastState.composeSystem env20309 rootObs = leafEnv20309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20309 rootObs == leafEnv20309) = true)

theorem terminalChecked20309 : H12PackedTerminal.terminalCheckFast leafEnv20309 active20309 tree20309 = true := by decide +kernel

def env20310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,293,170,1345,8865,1965,292,1296,8200,17664,139,8328,18172,0,16385,17405,8864,1285,4294967296,257,4294975529,1344,512]

theorem envBound20310 : H12AffineFastState.Bounded env20310 := by
  intro p hp
  have h : env20310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20290_20310 : H12AffineEnvironment.transform 17 8865 env20290 = env20310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8865 env20290 == env20310) = true)

theorem identity20310 : scanCanonicalize (H12AffineFastState.compose env20310 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20310 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,293,170,1345,8865,1965,292,1296,8200,65,139,8328,957,0,1344,1724,8864,1285,4294967296,257,4294975529,1344,512]

theorem envBound20311 : H12AffineFastState.Bounded env20311 := by
  intro p hp
  have h : env20311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20310_20311 : H12AffineEnvironment.transform 13 1345 env20310 = env20311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20310 == env20311) = true)

theorem identity20311 : scanCanonicalize (H12AffineFastState.compose env20311 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20311 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20312 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1297,8192,1345,293,170,1345,8461,1025,292,1296,8200,65,139,8328,17,0,1344,1296,8460,1285,4294967296,257,4294975529,1344,428]

theorem envBound20312 : H12AffineFastState.Bounded env20312 := by
  intro p hp
  have h : env20312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20311_20312 : H12AffineEnvironment.transform 8 428 env20311 = env20312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20311 == env20312) = true)

theorem identity20312 : scanCanonicalize (H12AffineFastState.compose env20312 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20313 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1297,269,1345,293,170,1345,0,1025,292,1296,261,65,139,389,17,0,1344,1296,1,1285,4294967296,257,4294967588,1344,428]

theorem envBound20313 : H12AffineFastState.Bounded env20313 := by
  intro p hp
  have h : env20313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20312_20313 : H12AffineEnvironment.transform 12 269 env20312 = env20313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20312 == env20313) = true)

theorem identity20313 : scanCanonicalize (H12AffineFastState.compose env20313 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 508) := by decide +kernel

theorem selectedBound20313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20314 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1297,269,1345,293,170,1345,0,1025,292,1296,261,65,139,389,17,0,1344,1296,1,1285,508,257,216,1344,428]

theorem envBound20314 : H12AffineFastState.Bounded env20314 := by
  intro p hp
  have h : env20314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20313_20314 : H12AffineEnvironment.transform 31 508 env20313 = env20314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 508 env20313 == env20314) = true)

theorem identity20314 : scanCanonicalize (H12AffineFastState.compose env20314 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20315 : List Nat := [2,4,8,16,32,64,128,172,0,1024,1,1213,161,1261,137,170,1261,0,1025,136,1212,169,65,139,41,17,0,1260,1212,1,1193,80,173,216,1260,0]

theorem envBound20315 : H12AffineFastState.Bounded env20315 := by
  intro p hp
  have h : env20315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20314_20315 : H12AffineEnvironment.transform 7 172 env20314 = env20315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20314 == env20315) = true)

theorem identity20315 : scanCanonicalize (H12AffineFastState.compose env20315 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20315 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20316 : List Nat := [2,4,8,16,32,64,8,36,0,1024,1,1077,41,1125,1,34,1125,0,1025,0,1076,33,65,3,41,17,0,1124,1076,1,1057,80,37,80,1124,0]

theorem envBound20316 : H12AffineFastState.Bounded env20316 := by
  intro p hp
  have h : env20316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20315_20316 : H12AffineEnvironment.transform 6 8 env20315 = env20316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20315 == env20316) = true)

theorem identity20316 : scanCanonicalize (H12AffineFastState.compose env20316 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20317 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,41,1076,1,34,1076,0,1025,0,1076,33,16,3,41,17,0,1077,1076,1,1057,1,37,1,1077,0]

theorem envBound20317 : H12AffineFastState.Bounded env20317 := by
  intro p hp
  have h : env20317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20316_20317 : H12AffineEnvironment.transform 5 17 env20316 = env20317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20316 == env20317) = true)

def leafEnv20317 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,41,1076,1,34,1076,0,1025,0,1076,33,16,3,1056,41,1,17,0,1077,1076,1,1057,1,37,1,5,35,1077,0,0,1077,1]

def active20317 : List Nat := [0,1,2,3,4,9]

def tree20317 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20317 : H12WitnessSearch.Good tree20317 := H12GlobalWitnessIndex.good

theorem leafIdentity20317 : H12AffineFastState.composeSystem env20317 rootObs = leafEnv20317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20317 rootObs == leafEnv20317) = true)

theorem terminalChecked20317 : H12PackedTerminal.terminalCheckFast leafEnv20317 active20317 tree20317 = true := by decide +kernel

def env20318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,536870912,1073741824,562663488,4294967296,545789248,4315938986,702907649,512]

theorem envBound20318 : H12AffineFastState.Bounded env20318 := by
  intro p hp
  have h : env20318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17941_20318 : H12AffineEnvironment.transform 34 702907649 env17941 = env20318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907649 env17941 == env20318) = true)

def env20319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,2769920,1073741824,27513920,4294967296,10637632,4315938986,164610305,512]

theorem envBound20319 : H12AffineFastState.Bounded env20319 := by
  intro p hp
  have h : env20319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20318_20319 : H12AffineEnvironment.transform 28 2769920 env20318 = env20319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env20318 == env20319) = true)

def env20320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,164610305,512]

theorem envBound20320 : H12AffineFastState.Bounded env20320 := by
  intro p hp
  have h : env20320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20319_20320 : H12AffineEnvironment.transform 20 4096 env20319 = env20320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env20319 == env20320) = true)

theorem identity20320 : scanCanonicalize (H12AffineFastState.compose env20320 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20320 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8389889,545089,1073741824,25280769,4294967296,8406017,4315938986,164480064,512]

theorem envBound20321 : H12AffineFastState.Bounded env20321 := by
  intro p hp
  have h : env20321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20320_20321 : H12AffineEnvironment.transform 16 1345 env20320 = env20321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20320 == env20321) = true)

def env20322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17664,16777216,8328,541009,134217728,16385,545089,1073741824,16876545,4294967296,257,4315938986,156074304,512]

theorem envBound20322 : H12AffineFastState.Bounded env20322 := by
  intro p hp
  have h : env20322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20321_20322 : H12AffineEnvironment.transform 22 17664 env20321 = env20322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env20321 == env20322) = true)

theorem identity20322 : scanCanonicalize (H12AffineFastState.compose env20322 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound20322 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17664,98564,8328,541009,134217728,16385,545089,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20323 : H12AffineFastState.Bounded env20323 := by
  intro p hp
  have h : env20323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20322_20323 : H12AffineEnvironment.transform 23 98564 env20322 = env20323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env20322 == env20323) = true)

def env20324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,524288,32769,1344,4194304,17664,98564,8328,541009,134217728,16385,541697,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20324 : H12AffineFastState.Bounded env20324 := by
  intro p hp
  have h : env20324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20323_20324 : H12AffineEnvironment.transform 11 1344 env20323 = env20324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env20323 == env20324) = true)

def env20325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,64,98564,8328,525329,134217728,1345,524609,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20325 : H12AffineFastState.Bounded env20325 := by
  intro p hp
  have h : env20325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20324_20325 : H12AffineEnvironment.transform 13 1344 env20324 = env20325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env20324 == env20325) = true)

theorem identity20325 : scanCanonicalize (H12AffineFastState.compose env20325 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound20325 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,64,98564,8328,525329,4456709,1345,524609,1073741824,1285,4294967296,257,4299260334,524609,512]

theorem envBound20326 : H12AffineFastState.Bounded env20326 := by
  intro p hp
  have h : env20326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20325_20326 : H12AffineEnvironment.transform 26 4456709 env20325 = env20326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env20325 == env20326) = true)

theorem identity20326 : scanCanonicalize (H12AffineFastState.compose env20326 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20326 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1025,32769,1344,4194304,64,98564,8328,16,4456709,1345,1344,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound20327 : H12AffineFastState.Bounded env20327 := by
  intro p hp
  have h : env20327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20326_20327 : H12AffineEnvironment.transform 18 1025 env20326 = env20327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20326 == env20327) = true)

def env20328 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,262144,321,32769,0,4194304,64,98564,8328,16,4456709,1,0,1073741824,69,4294967296,257,4299260334,0,512]

theorem envBound20328 : H12AffineFastState.Bounded env20328 := by
  intro p hp
  have h : env20328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20327_20328 : H12AffineEnvironment.transform 9 320 env20327 = env20328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env20327 == env20328) = true)

theorem identity20328 : scanCanonicalize (H12AffineFastState.compose env20328 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 303452) := by decide +kernel

theorem selectedBound20328 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20329 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,262144,321,32769,0,4194304,64,98564,8328,16,4456709,1,0,303452,69,4294967296,257,4299260334,0,512]

theorem envBound20329 : H12AffineFastState.Bounded env20329 := by
  intro p hp
  have h : env20329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20328_20329 : H12AffineEnvironment.transform 29 303452 env20328 = env20329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 303452 env20328 == env20329) = true)

theorem identity20329 : scanCanonicalize (H12AffineFastState.compose env20329 (packedSelected [5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20329 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env20330 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,8322,1,262144,321,32769,0,4194304,64,41350,8328,16,4456709,1,0,303452,69,4294967296,257,4299202860,0,512]

theorem envBound20330 : H12AffineFastState.Bounded env20330 := by
  intro p hp
  have h : env20330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20329_20330 : H12AffineEnvironment.transform 15 8322 env20329 = env20330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20329 == env20330) = true)

theorem identity20330 : scanCanonicalize (H12AffineFastState.compose env20330 (packedSelected [3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound20330 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env20331 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,8322,1,2340,321,32769,0,4194304,64,41350,8328,16,4196385,1,0,43128,69,4294967296,257,4299202860,0,512]

theorem envBound20331 : H12AffineFastState.Bounded env20331 := by
  intro p hp
  have h : env20331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20330_20331 : H12AffineEnvironment.transform 17 2340 env20330 = env20331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env20330 == env20331) = true)

theorem identity20331 : scanCanonicalize (H12AffineFastState.compose env20331 (packedSelected [15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20331 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env20332 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,8541,8322,1,2340,321,8540,0,4194304,64,219,8328,16,4196385,1,0,2341,69,4294967296,257,4299161713,0,512]

theorem envBound20332 : H12AffineFastState.Bounded env20332 := by
  intro p hp
  have h : env20332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20331_20332 : H12AffineEnvironment.transform 14 8541 env20331 = env20332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20331 == env20332) = true)

theorem identity20332 : scanCanonicalize (H12AffineFastState.compose env20332 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound20332 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20333 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,8541,8322,1,2340,321,8540,0,112,64,219,8328,16,2129,1,0,2341,69,4294967296,257,4294967297,0,512]

theorem envBound20333 : H12AffineFastState.Bounded env20333 := by
  intro p hp
  have h : env20333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20332_20333 : H12AffineEnvironment.transform 21 112 env20332 = env20333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env20332 == env20333) = true)

theorem identity20333 : scanCanonicalize (H12AffineFastState.compose env20333 (packedSelected [2,11] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20333 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env20334 : List Nat := [2,4,8,16,32,64,128,256,33,320,2048,0,8192,0,8541,8322,1,2340,321,8540,0,112,64,219,8328,16,2129,1,0,2341,69,4294967296,257,4294967297,0,33]

theorem envBound20334 : H12AffineFastState.Bounded env20334 := by
  intro p hp
  have h : env20334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20333_20334 : H12AffineEnvironment.transform 8 33 env20333 = env20334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20333 == env20334) = true)

theorem identity20334 : scanCanonicalize (H12AffineFastState.compose env20334 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20334 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20335 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,8192,0,8461,8322,1,2340,273,8460,0,32,16,139,8328,16,2049,1,0,2341,21,4294967296,257,4294967297,0,33]

theorem envBound20335 : H12AffineFastState.Bounded env20335 := by
  intro p hp
  have h : env20335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20334_20335 : H12AffineEnvironment.transform 5 16 env20334 = env20335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20334 == env20335) = true)

theorem identity20335 : scanCanonicalize (H12AffineFastState.compose env20335 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound20335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20336 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,2348,0,2081,2478,1,2340,273,2080,0,32,16,139,2468,16,2049,1,0,2341,21,4294967296,257,4294967297,0,33]

theorem envBound20336 : H12AffineFastState.Bounded env20336 := by
  intro p hp
  have h : env20336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20335_20336 : H12AffineEnvironment.transform 12 2348 env20335 = env20336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env20335 == env20336) = true)

theorem identity20336 : scanCanonicalize (H12AffineFastState.compose env20336 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20336 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20337 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,2348,0,2081,2478,1,2340,273,2080,0,32,16,139,2468,16,2049,1,0,2341,21,0,257,1,0,33]

theorem envBound20337 : H12AffineFastState.Bounded env20337 := by
  intro p hp
  have h : env20337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20336_20337 : H12AffineEnvironment.transform 31 0 env20336 = env20337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20336 == env20337) = true)

def env20338 : List Nat := [2,4,8,16,32,16,8,256,33,272,2048,0,2348,0,2081,2342,1,2340,273,2080,0,32,16,3,2348,16,2049,1,0,2341,21,0,257,1,0,33]

theorem envBound20338 : H12AffineFastState.Bounded env20338 := by
  intro p hp
  have h : env20338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20337_20338 : H12AffineEnvironment.transform 6 8 env20337 = env20338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20337 == env20338) = true)

theorem identity20338 : scanCanonicalize (H12AffineFastState.compose env20338 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20339 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,0,2316,0,2049,2310,1,2308,273,2048,0,0,16,3,2316,16,2049,1,0,2309,21,0,257,1,0,1]

theorem envBound20339 : H12AffineFastState.Bounded env20339 := by
  intro p hp
  have h : env20339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20338_20339 : H12AffineEnvironment.transform 4 0 env20338 = env20339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20338 == env20339) = true)

def leafEnv20339 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,0,2316,0,2049,2310,1,2308,273,2048,0,0,16,3,20,2316,1,16,2049,1,0,2309,21,0,257,1,5,2311,0,1,0,0,1]

def active20339 : List Nat := [0,1,2,3,7,10]

def tree20339 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20339 : H12WitnessSearch.Good tree20339 := H12GlobalWitnessIndex.good

theorem leafIdentity20339 : H12AffineFastState.composeSystem env20339 rootObs = leafEnv20339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20339 rootObs == leafEnv20339) = true)

theorem terminalChecked20339 : H12PackedTerminal.terminalCheckFast leafEnv20339 active20339 tree20339 = true := by decide +kernel

def env20340 : List Nat := [2,4,8,16,32,16,9,256,33,272,2048,0,2348,0,2081,2343,1,2340,273,2080,0,32,16,2,2349,16,2049,1,0,2341,21,0,257,1,0,33]

theorem envBound20340 : H12AffineFastState.Bounded env20340 := by
  intro p hp
  have h : env20340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20337_20340 : H12AffineEnvironment.transform 6 9 env20337 = env20340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20337 == env20340) = true)

theorem identity20340 : scanCanonicalize (H12AffineFastState.compose env20340 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20340 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20341 : List Nat := [2,4,8,16,32,16,9,37,33,53,2048,0,2057,0,2081,2050,1,2049,52,2080,0,32,16,2,2056,16,2049,1,0,2048,21,0,36,1,0,33]

theorem envBound20341 : H12AffineFastState.Bounded env20341 := by
  intro p hp
  have h : env20341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20340_20341 : H12AffineEnvironment.transform 7 37 env20340 = env20341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20340 == env20341) = true)

def leafEnv20341 : List Nat := [2,4,8,16,32,16,9,37,33,53,2048,0,2057,0,2081,2050,1,2049,52,2080,0,32,16,2,20,2056,1,16,2049,1,0,2048,21,0,36,1,5,2050,0,33,0,0,1]

def active20341 : List Nat := [0,1,2,3,4,10]

def tree20341 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20341 : H12WitnessSearch.Good tree20341 := H12GlobalWitnessIndex.good

theorem leafIdentity20341 : H12AffineFastState.composeSystem env20341 rootObs = leafEnv20341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20341 rootObs == leafEnv20341) = true)

theorem terminalChecked20341 : H12PackedTerminal.terminalCheckFast leafEnv20341 active20341 tree20341 = true := by decide +kernel

def env20342 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,262144,320,32769,1,4194304,64,98564,8328,16,4456709,0,1,1073741824,68,4294967296,257,4299260334,1,512]

theorem envBound20342 : H12AffineFastState.Bounded env20342 := by
  intro p hp
  have h : env20342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20327_20342 : H12AffineEnvironment.transform 9 321 env20327 = env20342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env20327 == env20342) = true)

theorem identity20342 : scanCanonicalize (H12AffineFastState.compose env20342 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 100602) := by decide +kernel

theorem selectedBound20342 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20343 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,262144,320,32769,1,4194304,64,98564,8328,16,4456709,0,1,100602,68,4294967296,257,4299260334,1,512]

theorem envBound20343 : H12AffineFastState.Bounded env20343 := by
  intro p hp
  have h : env20343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20342_20343 : H12AffineEnvironment.transform 29 100602 env20342 = env20343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 100602 env20342 == env20343) = true)

theorem identity20343 : scanCanonicalize (H12AffineFastState.compose env20343 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound20343 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env20344 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,76198,320,32769,1,4194304,64,98564,8328,16,4270243,0,1,100602,68,4294967296,257,4299260334,1,512]

theorem envBound20344 : H12AffineFastState.Bounded env20344 := by
  intro p hp
  have h : env20344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20343_20344 : H12AffineEnvironment.transform 17 76198 env20343 = env20344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env20343 == env20344) = true)

theorem identity20344 : scanCanonicalize (H12AffineFastState.compose env20344 (packedSelected [5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 73970) := by decide +kernel

theorem selectedBound20344 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env20345 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,76198,320,32769,1,73970,64,98564,8328,16,2129,0,1,100602,68,4294967296,257,4295008604,1,512]

theorem envBound20345 : H12AffineFastState.Bounded env20345 := by
  intro p hp
  have h : env20345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20344_20345 : H12AffineEnvironment.transform 21 73970 env20344 = env20345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73970 env20344 == env20345) = true)

theorem identity20345 : scanCanonicalize (H12AffineFastState.compose env20345 (packedSelected [1,8] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20345 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20346 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,8322,0,2340,320,32769,1,112,64,41350,8328,16,2129,0,1,43128,68,4294967296,257,4295008604,1,512]

theorem envBound20346 : H12AffineFastState.Bounded env20346 := by
  intro p hp
  have h : env20346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20345_20346 : H12AffineEnvironment.transform 15 8322 env20345 = env20346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20345 == env20346) = true)

theorem identity20346 : scanCanonicalize (H12AffineFastState.compose env20346 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20347 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,8461,8322,0,2340,320,8460,1,112,64,139,8328,16,2129,0,1,2421,68,4294967296,257,4294967377,1,512]

theorem envBound20347 : H12AffineFastState.Bounded env20347 := by
  intro p hp
  have h : env20347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20346_20347 : H12AffineEnvironment.transform 14 8461 env20346 = env20347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env20346 == env20347) = true)

theorem identity20347 : scanCanonicalize (H12AffineFastState.compose env20347 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20347 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20348 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8461,8322,0,2340,272,8460,1,32,16,139,8328,16,2049,0,1,2341,20,4294967296,257,4294967297,1,512]

theorem envBound20348 : H12AffineFastState.Bounded env20348 := by
  intro p hp
  have h : env20348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20347_20348 : H12AffineEnvironment.transform 5 16 env20347 = env20348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20347 == env20348) = true)

theorem identity20348 : scanCanonicalize (H12AffineFastState.compose env20348 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2829) := by decide +kernel

theorem selectedBound20348 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20349 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2829,1,2560,2959,0,2340,272,2561,1,32,16,139,2949,16,2049,0,1,2341,20,4294967296,257,4294967297,1,512]

theorem envBound20349 : H12AffineFastState.Bounded env20349 := by
  intro p hp
  have h : env20349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20348_20349 : H12AffineEnvironment.transform 12 2829 env20348 = env20349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2829 env20348 == env20349) = true)

theorem identity20349 : scanCanonicalize (H12AffineFastState.compose env20349 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20350 : List Nat := [2,4,8,16,32,16,128,256,33,273,2048,1,2348,1,2081,2478,0,2340,272,2080,1,32,16,139,2468,16,2049,0,1,2341,20,4294967296,257,4294967297,1,33]

theorem envBound20350 : H12AffineFastState.Bounded env20350 := by
  intro p hp
  have h : env20350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20349_20350 : H12AffineEnvironment.transform 8 33 env20349 = env20350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20349 == env20350) = true)

theorem identity20350 : scanCanonicalize (H12AffineFastState.compose env20350 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20350 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20351 : List Nat := [2,4,8,16,32,16,128,256,33,273,2048,1,2348,1,2081,2478,0,2340,272,2080,1,32,16,139,2468,16,2049,0,1,2341,20,0,257,1,1,33]

theorem envBound20351 : H12AffineFastState.Bounded env20351 := by
  intro p hp
  have h : env20351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20350_20351 : H12AffineEnvironment.transform 31 0 env20350 = env20351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20350 == env20351) = true)

def env20352 : List Nat := [2,4,8,16,32,16,8,256,33,273,2048,1,2348,1,2081,2342,0,2340,272,2080,1,32,16,3,2348,16,2049,0,1,2341,20,0,257,1,1,33]

theorem envBound20352 : H12AffineFastState.Bounded env20352 := by
  intro p hp
  have h : env20352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20351_20352 : H12AffineEnvironment.transform 6 8 env20351 = env20352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20351 == env20352) = true)

theorem identity20352 : scanCanonicalize (H12AffineFastState.compose env20352 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20353 : List Nat := [2,4,8,16,0,16,8,256,1,273,2048,1,2316,1,2049,2310,0,2308,272,2048,1,0,16,3,2316,16,2049,0,1,2309,20,0,257,1,1,1]

theorem envBound20353 : H12AffineFastState.Bounded env20353 := by
  intro p hp
  have h : env20353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20352_20353 : H12AffineEnvironment.transform 4 0 env20352 = env20353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20352 == env20353) = true)

def leafEnv20353 : List Nat := [2,4,8,16,0,16,8,256,1,273,2048,1,2316,1,2049,2310,0,2308,272,2048,1,0,16,3,21,2316,1,16,2049,0,1,2309,20,0,257,1,5,2311,1,1,0,1,1]

def active20353 : List Nat := [0,1,2,3,7,10]

def tree20353 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20353 : H12WitnessSearch.Good tree20353 := H12GlobalWitnessIndex.good

theorem leafIdentity20353 : H12AffineFastState.composeSystem env20353 rootObs = leafEnv20353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20353 rootObs == leafEnv20353) = true)

theorem terminalChecked20353 : H12PackedTerminal.terminalCheckFast leafEnv20353 active20353 tree20353 = true := by decide +kernel

def env20354 : List Nat := [2,4,8,16,32,16,9,256,33,273,2048,1,2348,1,2081,2343,0,2340,272,2080,1,32,16,2,2349,16,2049,0,1,2341,20,0,257,1,1,33]

theorem envBound20354 : H12AffineFastState.Bounded env20354 := by
  intro p hp
  have h : env20354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20351_20354 : H12AffineEnvironment.transform 6 9 env20351 = env20354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20351 == env20354) = true)

theorem identity20354 : scanCanonicalize (H12AffineFastState.compose env20354 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20355 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,1,2057,1,2081,2050,0,2049,53,2080,1,32,16,2,2056,16,2049,0,1,2048,20,0,36,1,1,33]

end H12CloudChart2