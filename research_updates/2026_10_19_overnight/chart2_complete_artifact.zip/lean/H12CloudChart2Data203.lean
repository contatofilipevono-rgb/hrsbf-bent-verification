import H12CloudChart2Data202

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound51079 : H12AffineFastState.Bounded env51079 := by
  intro p hp
  have h : env51079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51078_51079 : H12AffineEnvironment.transform 2 5 env51078 = env51079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51078 == env51079) = true)

def env51080 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143497,20496,492567,148669,148668,96266,74795,74799,172,222254,1212,135680]

theorem envBound51080 : H12AffineFastState.Bounded env51080 := by
  intro p hp
  have h : env51080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51064_51080 : H12AffineEnvironment.transform 5 17 env51064 = env51080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51064 == env51080) = true)

theorem identity51080 : scanCanonicalize (H12AffineFastState.compose env51080 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound51080 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51081 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61568,147472,41003,143497,20496,60444,148669,148668,96266,74795,74799,172,222254,1212,135680]

theorem envBound51081 : H12AffineFastState.Bounded env51081 := by
  intro p hp
  have h : env51081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51080_51081 : H12AffineEnvironment.transform 17 223243 env51080 = env51081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env51080 == env51081) = true)

theorem identity51081 : scanCanonicalize (H12AffineFastState.compose env51081 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound51081 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51082 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4096,61568,147472,41003,143497,20496,60444,148669,148668,2184,21673,21677,172,136364,1212,135680]

theorem envBound51082 : H12AffineFastState.Bounded env51082 := by
  intro p hp
  have h : env51082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51081_51082 : H12AffineEnvironment.transform 15 28802 env51081 = env51082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env51081 == env51082) = true)

theorem identity51082 : scanCanonicalize (H12AffineFastState.compose env51082 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound51082 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51083 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,46245,44076,41125,32769,4096,61568,62645,41003,33836,20496,60444,61464,61465,2184,21673,21677,172,40969,1212,42661]

theorem envBound51083 : H12AffineFastState.Bounded env51083 := by
  intro p hp
  have h : env51083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51082_51083 : H12AffineEnvironment.transform 16 46245 env51082 = env51083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env51082 == env51083) = true)

theorem identity51083 : scanCanonicalize (H12AffineFastState.compose env51083 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound51083 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env51084 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,46245,44076,41125,32769,4096,46140,45065,41003,33836,5292,43168,46244,46245,2184,4117,4113,172,40969,1212,42661]

theorem envBound51084 : H12AffineFastState.Bounded env51084 := by
  intro p hp
  have h : env51084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51083_51084 : H12AffineEnvironment.transform 13 1212 env51083 = env51084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env51083 == env51084) = true)

theorem identity51084 : scanCanonicalize (H12AffineFastState.compose env51084 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound51084 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51085 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,13340,13374,185,6192,5305,13341,4096,32,1045,5175,12336,5292,7356,184,185,2184,4117,4113,172,5141,1212,4793]

theorem envBound51085 : H12AffineFastState.Bounded env51085 := by
  intro p hp
  have h : env51085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51084_51085 : H12AffineEnvironment.transform 14 13340 env51084 = env51085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env51084 == env51085) = true)

theorem identity51085 : scanCanonicalize (H12AffineFastState.compose env51085 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51085 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env51086 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,4096,8192,1212,13340,13374,185,6192,5305,13341,4096,32,1045,5175,12336,5292,7356,184,185,2184,4117,4113,172,5141,1212,4280]

theorem envBound51086 : H12AffineFastState.Bounded env51086 := by
  intro p hp
  have h : env51086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51085_51086 : H12AffineEnvironment.transform 8 1 env51085 = env51086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51085 == env51086) = true)

theorem identity51086 : scanCanonicalize (H12AffineFastState.compose env51086 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound51086 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51087 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,2075,8192,1212,11271,11301,185,43,3234,11270,2075,32,1045,3116,10283,3255,1191,184,185,2184,2062,2058,172,3086,1212,2211]

theorem envBound51087 : H12AffineFastState.Bounded env51087 := by
  intro p hp
  have h : env51087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51086_51087 : H12AffineEnvironment.transform 11 2075 env51086 = env51087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env51086 == env51087) = true)

theorem identity51087 : scanCanonicalize (H12AffineFastState.compose env51087 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound51087 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51088 : List Nat := [2,4,8,16,32,17,128,173,1,1024,163,184,8192,1212,9380,9350,185,43,1025,9381,184,32,1045,1167,8328,1044,1191,184,185,43,173,169,172,1197,1212,0]

theorem envBound51088 : H12AffineFastState.Bounded env51088 := by
  intro p hp
  have h : env51088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51087_51088 : H12AffineEnvironment.transform 10 163 env51087 = env51088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env51087 == env51088) = true)

theorem identity51088 : scanCanonicalize (H12AffineFastState.compose env51088 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1041) := by decide +kernel

theorem selectedBound51088 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env51089 : List Nat := [2,4,8,16,32,17,128,173,1,1024,163,184,1041,1212,181,151,185,43,1025,180,184,32,1045,1167,1177,1044,1191,184,185,43,173,169,172,1197,1212,0]

theorem envBound51089 : H12AffineFastState.Bounded env51089 := by
  intro p hp
  have h : env51089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51088_51089 : H12AffineEnvironment.transform 12 1041 env51088 = env51089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1041 env51088 == env51089) = true)

theorem identity51089 : scanCanonicalize (H12AffineFastState.compose env51089 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound51089 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51090 : List Nat := [2,4,8,16,32,17,128,173,1,189,163,184,172,1,181,151,185,43,188,180,184,32,168,50,36,169,26,184,185,43,173,169,172,16,1,0]

theorem envBound51090 : H12AffineFastState.Bounded env51090 := by
  intro p hp
  have h : env51090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51089_51090 : H12AffineEnvironment.transform 9 189 env51089 = env51090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env51089 == env51090) = true)

theorem identity51090 : scanCanonicalize (H12AffineFastState.compose env51090 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51090 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51091 : List Nat := [2,4,8,16,6,17,128,139,1,155,133,158,138,1,147,151,159,13,154,146,158,6,142,20,2,143,26,158,159,13,139,143,138,16,1,0]

theorem envBound51091 : H12AffineFastState.Bounded env51091 := by
  intro p hp
  have h : env51091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51090_51091 : H12AffineEnvironment.transform 4 6 env51090 = env51091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51090 == env51091) = true)

theorem identity51091 : scanCanonicalize (H12AffineFastState.compose env51091 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51091 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51092 : List Nat := [2,4,8,2,6,3,128,139,1,137,133,140,138,1,129,133,141,13,136,128,140,6,142,6,2,143,8,140,141,13,139,143,138,2,1,0]

theorem envBound51092 : H12AffineFastState.Bounded env51092 := by
  intro p hp
  have h : env51092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51091_51092 : H12AffineEnvironment.transform 3 2 env51091 = env51092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51091 == env51092) = true)

theorem identity51092 : scanCanonicalize (H12AffineFastState.compose env51092 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound51092 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51093 : List Nat := [2,4,8,2,6,3,13,6,1,4,8,1,7,1,12,8,0,13,5,13,1,6,3,6,2,2,8,1,0,13,6,2,7,2,1,0]

theorem envBound51093 : H12AffineFastState.Bounded env51093 := by
  intro p hp
  have h : env51093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51092_51093 : H12AffineEnvironment.transform 6 13 env51092 = env51093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env51092 == env51093) = true)

theorem identity51093 : scanCanonicalize (H12AffineFastState.compose env51093 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51094 : List Nat := [1,4,8,1,5,0,13,5,1,4,8,1,4,1,12,8,0,13,5,13,1,5,0,5,1,1,8,1,0,13,5,1,4,1,1,0]

theorem envBound51094 : H12AffineFastState.Bounded env51094 := by
  intro p hp
  have h : env51094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51093_51094 : H12AffineEnvironment.transform 0 1 env51093 = env51094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51093 == env51094) = true)

theorem identity51094 : scanCanonicalize (H12AffineFastState.compose env51094 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51094 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51095 : List Nat := [1,1,8,1,0,0,8,0,1,1,8,1,1,1,9,8,0,8,0,8,1,0,0,0,1,1,8,1,0,8,0,1,1,1,1,0]

theorem envBound51095 : H12AffineFastState.Bounded env51095 := by
  intro p hp
  have h : env51095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51094_51095 : H12AffineEnvironment.transform 1 1 env51094 = env51095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51094 == env51095) = true)

def env51096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,493035,148801,148801,96347,74795,74799,257,222334,1344,135681]

theorem envBound51096 : H12AffineFastState.Bounded env51096 := by
  intro p hp
  have h : env51096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51027_51096 : H12AffineEnvironment.transform 18 136193 env51027 = env51096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env51027 == env51096) = true)

def env51097 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,492615,148717,148717,96347,74795,74799,173,222334,1260,135681]

theorem envBound51097 : H12AffineFastState.Bounded env51097 := by
  intro p hp
  have h : env51097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51096_51097 : H12AffineEnvironment.transform 7 172 env51096 = env51097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51096 == env51097) = true)

def env51098 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143496,20497,492567,148669,148669,96267,74795,74799,173,222254,1212,135681]

theorem envBound51098 : H12AffineFastState.Bounded env51098 := by
  intro p hp
  have h : env51098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51097_51098 : H12AffineEnvironment.transform 5 16 env51097 = env51098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51097 == env51098) = true)

theorem identity51098 : scanCanonicalize (H12AffineFastState.compose env51098 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound51098 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51099 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,41003,143496,20497,105630,148669,148669,96267,74795,74799,173,222254,1212,135681]

theorem envBound51099 : H12AffineFastState.Bounded env51099 := by
  intro p hp
  have h : env51099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51098_51099 : H12AffineEnvironment.transform 17 137353 env51098 = env51099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env51098 == env51099) = true)

theorem identity51099 : scanCanonicalize (H12AffineFastState.compose env51099 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound51099 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51100 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4096,61569,147473,41003,143496,20497,43169,148669,148669,19508,4116,4112,173,151569,1212,135681]

theorem envBound51100 : H12AffineFastState.Bounded env51100 := by
  intro p hp
  have h : env51100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51099_51100 : H12AffineEnvironment.transform 15 13375 env51099 = env51100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env51099 == env51100) = true)

theorem identity51100 : scanCanonicalize (H12AffineFastState.compose env51100 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound51100 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51101 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136193,32769,4096,46141,132269,41003,143496,5293,43169,131073,131073,2184,4116,4112,173,136365,1212,135681]

theorem envBound51101 : H12AffineFastState.Bounded env51101 := by
  intro p hp
  have h : env51101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51100_51101 : H12AffineEnvironment.transform 13 1212 env51100 = env51101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env51100 == env51101) = true)

theorem identity51101 : scanCanonicalize (H12AffineFastState.compose env51101 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound51101 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env51102 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,13375,131072,137353,136193,12312,4096,1060,132269,4146,143496,5293,6328,131073,131073,2184,4116,4112,173,136365,1212,135681]

theorem envBound51102 : H12AffineFastState.Bounded env51102 := by
  intro p hp
  have h : env51102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51101_51102 : H12AffineEnvironment.transform 14 12313 env51101 = env51102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env51101 == env51102) = true)

theorem identity51102 : scanCanonicalize (H12AffineFastState.compose env51102 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound51102 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env51103 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,13375,3102,5271,6175,12312,4096,1060,2227,4146,15510,5293,6328,3103,3103,2184,4116,4112,173,6323,1212,7711]

theorem envBound51103 : H12AffineFastState.Bounded env51103 := by
  intro p hp
  have h : env51103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51102_51103 : H12AffineEnvironment.transform 16 3102 env51102 = env51103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env51102 == env51103) = true)

theorem identity51103 : scanCanonicalize (H12AffineFastState.compose env51103 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound51103 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env51104 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,1212,5124,4130,3102,5271,6175,5125,4096,1060,2227,4146,6283,5293,6328,3103,3103,2184,4116,4112,173,6323,1212,7711]

theorem envBound51104 : H12AffineFastState.Bounded env51104 := by
  intro p hp
  have h : env51104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51103_51104 : H12AffineEnvironment.transform 12 1053 env51103 = env51104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env51103 == env51104) = true)

theorem identity51104 : scanCanonicalize (H12AffineFastState.compose env51104 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound51104 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51105 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2194,1053,1212,3222,2224,3102,3077,141,3223,2194,1060,2227,2208,25,3135,42,3103,3103,2184,2182,2178,173,33,1212,1677]

theorem envBound51105 : H12AffineFastState.Bounded env51105 := by
  intro p hp
  have h : env51105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51104_51105 : H12AffineEnvironment.transform 11 2194 env51104 = env51105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env51104 == env51105) = true)

theorem identity51105 : scanCanonicalize (H12AffineFastState.compose env51105 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound51105 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51106 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,2194,24,185,2195,2224,2075,2048,141,2194,2194,33,2227,2208,25,2106,42,2074,2074,2184,2182,2178,173,33,185,648]

theorem envBound51106 : H12AffineFastState.Bounded env51106 := by
  intro p hp
  have h : env51106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51105_51106 : H12AffineEnvironment.transform 9 5 env51105 = env51106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env51105 == env51106) = true)

theorem identity51106 : scanCanonicalize (H12AffineFastState.compose env51106 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound51106 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51107 : List Nat := [2,4,8,16,32,16,128,172,147,5,2048,2194,24,185,2195,2224,2075,2048,141,2194,2194,33,2227,2208,25,2106,42,2074,2074,2184,2182,2178,173,33,185,27]

theorem envBound51107 : H12AffineFastState.Bounded env51107 := by
  intro p hp
  have h : env51107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51106_51107 : H12AffineEnvironment.transform 8 147 env51106 = env51107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env51106 == env51107) = true)

theorem identity51107 : scanCanonicalize (H12AffineFastState.compose env51107 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound51107 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env51108 : List Nat := [2,4,8,16,32,16,128,172,147,5,142,28,24,185,29,62,149,142,141,28,28,33,61,46,25,180,42,148,148,6,8,12,173,33,185,27]

theorem envBound51108 : H12AffineFastState.Bounded env51108 := by
  intro p hp
  have h : env51108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51107_51108 : H12AffineEnvironment.transform 10 142 env51107 = env51108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env51107 == env51108) = true)

theorem identity51108 : scanCanonicalize (H12AffineFastState.compose env51108 (packedSelected [0,2,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51108 : packedSelected [0,2,5,9] rootPS < 2^1333 := by decide +kernel

def env51109 : List Nat := [2,4,8,16,32,16,9,37,26,5,7,28,24,48,29,62,28,7,4,28,28,33,61,46,25,61,42,29,29,6,8,12,36,33,48,27]

theorem envBound51109 : H12AffineFastState.Bounded env51109 := by
  intro p hp
  have h : env51109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51108_51109 : H12AffineEnvironment.transform 6 9 env51108 = env51109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51108 == env51109) = true)

theorem identity51109 : scanCanonicalize (H12AffineFastState.compose env51109 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound51109 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51110 : List Nat := [2,4,6,16,32,16,7,37,20,5,7,18,22,48,19,48,18,7,4,18,18,33,51,32,23,51,36,19,19,6,6,2,36,33,48,21]

theorem envBound51110 : H12AffineFastState.Bounded env51110 := by
  intro p hp
  have h : env51110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51109_51110 : H12AffineEnvironment.transform 2 6 env51109 = env51110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env51109 == env51110) = true)

theorem identity51110 : scanCanonicalize (H12AffineFastState.compose env51110 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51110 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env51111 : List Nat := [2,4,6,16,17,16,7,20,20,5,7,18,22,1,19,1,18,7,4,18,18,16,2,17,23,2,21,19,19,6,6,2,21,16,1,21]

theorem envBound51111 : H12AffineFastState.Bounded env51111 := by
  intro p hp
  have h : env51111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51110_51111 : H12AffineEnvironment.transform 4 17 env51110 = env51111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51110 == env51111) = true)

theorem identity51111 : scanCanonicalize (H12AffineFastState.compose env51111 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound51111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51112 : List Nat := [2,4,6,5,4,5,7,1,1,5,7,7,3,1,6,1,7,7,4,7,7,5,2,4,2,2,0,6,6,6,6,2,0,5,1,0]

theorem envBound51112 : H12AffineFastState.Bounded env51112 := by
  intro p hp
  have h : env51112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51111_51112 : H12AffineEnvironment.transform 3 5 env51111 = env51112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env51111 == env51112) = true)

theorem identity51112 : scanCanonicalize (H12AffineFastState.compose env51112 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51113 : List Nat := [1,4,5,5,4,5,4,1,1,5,4,4,0,1,5,1,4,4,4,4,4,5,1,4,1,1,0,5,5,5,5,1,0,5,1,0]

theorem envBound51113 : H12AffineFastState.Bounded env51113 := by
  intro p hp
  have h : env51113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51112_51113 : H12AffineEnvironment.transform 0 1 env51112 = env51113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51112 == env51113) = true)

theorem identity51113 : scanCanonicalize (H12AffineFastState.compose env51113 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51113 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51114 : List Nat := [1,1,0,0,1,0,1,1,1,0,1,1,0,1,0,1,1,1,1,1,1,0,1,1,1,1,0,0,0,0,0,1,0,0,1,0]

theorem envBound51114 : H12AffineFastState.Bounded env51114 := by
  intro p hp
  have h : env51114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51113_51114 : H12AffineEnvironment.transform 1 1 env51113 = env51114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51113 == env51114) = true)

def env51115 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143496,20497,492566,148668,148668,96266,74795,74799,173,222255,1213,135681]

theorem envBound51115 : H12AffineFastState.Bounded env51115 := by
  intro p hp
  have h : env51115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51097_51115 : H12AffineEnvironment.transform 5 17 env51097 = env51115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51097 == env51115) = true)

theorem identity51115 : scanCanonicalize (H12AffineFastState.compose env51115 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound51115 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51116 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,41003,32809,20497,341175,62493,62493,96266,74795,74799,173,119950,1213,41632]

theorem envBound51116 : H12AffineFastState.Bounded env51116 := by
  intro p hp
  have h : env51116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51115_51116 : H12AffineEnvironment.transform 16 45217 env51115 = env51116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env51115 == env51116) = true)

theorem identity51116 : scanCanonicalize (H12AffineFastState.compose env51116 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound51116 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env51117 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4096,46140,46093,41003,32809,5293,341175,45217,45217,81078,74795,74799,173,102450,1213,41632]

theorem envBound51117 : H12AffineFastState.Bounded env51117 := by
  intro p hp
  have h : env51117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51116_51117 : H12AffineEnvironment.transform 13 1212 env51116 = env51117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env51116 == env51117) = true)

theorem identity51117 : scanCanonicalize (H12AffineFastState.compose env51117 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound51117 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51118 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,185,32768,65536,45217,262144,41125,32769,4096,45113,45064,41003,32809,4264,340146,45217,45217,80051,73774,73770,173,102450,184,41632]

theorem envBound51118 : H12AffineFastState.Bounded env51118 := by
  intro p hp
  have h : env51118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51117_51118 : H12AffineEnvironment.transform 9 5 env51117 = env51118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env51117 == env51118) = true)

theorem identity51118 : scanCanonicalize (H12AffineFastState.compose env51118 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound51118 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env51119 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,185,32768,37018,45217,262144,41125,32769,4096,45113,45064,41003,32809,4264,303144,45217,45217,43049,45236,45232,173,168,184,41632]

theorem envBound51119 : H12AffineFastState.Bounded env51119 := by
  intro p hp
  have h : env51119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51118_51119 : H12AffineEnvironment.transform 15 37018 env51118 = env51119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env51118 == env51119) = true)

theorem identity51119 : scanCanonicalize (H12AffineFastState.compose env51119 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound51119 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env51120 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,185,32768,37018,45217,2185,41125,32769,4096,45113,45064,41003,32809,4264,43169,45217,45217,43049,45236,45232,173,168,184,41632]

theorem envBound51120 : H12AffineFastState.Bounded env51120 := by
  intro p hp
  have h : env51120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51119_51120 : H12AffineEnvironment.transform 17 2185 env51119 = env51120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env51119 == env51120) = true)

theorem identity51120 : scanCanonicalize (H12AffineFastState.compose env51120 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 6681) := by decide +kernel

theorem selectedBound51120 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51121 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,6681,185,32768,37018,35512,2185,39612,32769,4096,35360,35345,39474,32809,4264,37560,35512,35512,37424,35501,35497,173,168,184,39097]

theorem envBound51121 : H12AffineFastState.Bounded env51121 := by
  intro p hp
  have h : env51121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51120_51121 : H12AffineEnvironment.transform 12 6681 env51120 = env51121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6681 env51120 == env51121) = true)

theorem identity51121 : scanCanonicalize (H12AffineFastState.compose env51121 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 42) := by decide +kernel

theorem selectedBound51121 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51122 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,6681,185,42,4272,2706,2185,6806,43,4096,2570,2619,6680,3,4264,4754,2706,2706,4634,2695,2691,173,168,184,6291]

theorem envBound51122 : H12AffineFastState.Bounded env51122 := by
  intro p hp
  have h : env51122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51121_51122 : H12AffineEnvironment.transform 14 42 env51121 = env51122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 42 env51121 == env51122) = true)

theorem identity51122 : scanCanonicalize (H12AffineFastState.compose env51122 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51122 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51123 : List Nat := [2,4,8,16,32,17,9,37,512,5,2048,4096,6681,48,42,4153,2587,2048,6687,43,4096,2570,2619,6680,3,4129,4635,2587,2587,4634,2574,2570,36,33,49,6170]

theorem envBound51123 : H12AffineFastState.Bounded env51123 := by
  intro p hp
  have h : env51123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51122_51123 : H12AffineEnvironment.transform 6 9 env51122 = env51123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51122 == env51123) = true)

theorem identity51123 : scanCanonicalize (H12AffineFastState.compose env51123 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound51123 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env51124 : List Nat := [2,4,8,16,32,17,9,37,512,5,561,4096,4136,48,42,4153,42,561,4142,43,4096,59,10,4137,3,4129,4635,42,42,4634,63,59,36,33,49,4651]

theorem envBound51124 : H12AffineFastState.Bounded env51124 := by
  intro p hp
  have h : env51124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51123_51124 : H12AffineEnvironment.transform 10 561 env51123 = env51124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env51123 == env51124) = true)

theorem identity51124 : scanCanonicalize (H12AffineFastState.compose env51124 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51124 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51125 : List Nat := [2,4,8,16,32,17,9,37,0,5,49,4096,4136,48,42,4153,42,49,4142,43,4096,59,10,4137,3,4129,4123,42,42,4122,63,59,36,33,49,4139]

theorem envBound51125 : H12AffineFastState.Bounded env51125 := by
  intro p hp
  have h : env51125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51124_51125 : H12AffineEnvironment.transform 8 0 env51124 = env51125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51124 == env51125) = true)

theorem identity51125 : scanCanonicalize (H12AffineFastState.compose env51125 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51126 : List Nat := [2,4,8,11,32,10,9,37,0,5,42,4096,4136,43,42,4130,42,42,4142,43,4096,32,10,4137,3,4129,4096,42,42,4097,36,32,36,33,42,4139]

theorem envBound51126 : H12AffineFastState.Bounded env51126 := by
  intro p hp
  have h : env51126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51125_51126 : H12AffineEnvironment.transform 3 11 env51125 = env51126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51125 == env51126) = true)

theorem identity51126 : scanCanonicalize (H12AffineFastState.compose env51126 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51126 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51127 : List Nat := [2,4,4,7,32,6,5,37,0,5,38,4096,4132,39,38,4130,38,38,4130,39,4096,32,6,4133,3,4129,4096,38,38,4097,36,32,36,33,38,4135]

theorem envBound51127 : H12AffineFastState.Bounded env51127 := by
  intro p hp
  have h : env51127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51126_51127 : H12AffineEnvironment.transform 2 4 env51126 = env51127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51126 == env51127) = true)

theorem identity51127 : scanCanonicalize (H12AffineFastState.compose env51127 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 38) := by decide +kernel

theorem selectedBound51127 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51128 : List Nat := [2,4,4,7,32,6,5,37,0,5,38,38,2,39,38,4,38,38,4,39,38,32,6,3,3,7,38,38,38,39,36,32,36,33,38,1]

theorem envBound51128 : H12AffineFastState.Bounded env51128 := by
  intro p hp
  have h : env51128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51127_51128 : H12AffineEnvironment.transform 11 38 env51127 = env51128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 38 env51127 == env51128) = true)

theorem identity51128 : scanCanonicalize (H12AffineFastState.compose env51128 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51129 : List Nat := [2,0,0,3,32,2,1,33,0,1,34,34,2,35,34,0,34,34,0,35,34,32,2,3,3,3,34,34,34,35,32,32,32,33,34,1]

theorem envBound51129 : H12AffineFastState.Bounded env51129 := by
  intro p hp
  have h : env51129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51128_51129 : H12AffineEnvironment.transform 1 0 env51128 = env51129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51128 == env51129) = true)

theorem identity51129 : scanCanonicalize (H12AffineFastState.compose env51129 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound51129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51130 : List Nat := [2,0,0,3,3,2,1,2,0,1,1,1,2,0,1,0,1,1,0,0,1,3,2,3,3,3,1,1,1,0,3,3,3,2,1,1]

theorem envBound51130 : H12AffineFastState.Bounded env51130 := by
  intro p hp
  have h : env51130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51129_51130 : H12AffineEnvironment.transform 4 3 env51129 = env51130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env51129 == env51130) = true)

theorem identity51130 : scanCanonicalize (H12AffineFastState.compose env51130 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51130 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51131 : List Nat := [1,0,0,0,0,1,1,1,0,1,1,1,1,0,1,0,1,1,0,0,1,0,1,0,0,0,1,1,1,0,0,0,0,1,1,1]

theorem envBound51131 : H12AffineFastState.Bounded env51131 := by
  intro p hp
  have h : env51131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51130_51131 : H12AffineEnvironment.transform 0 1 env51130 = env51131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51130 == env51131) = true)

def env51132 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41003,143496,20497,492614,148716,148716,96347,74795,74799,172,222334,1261,135681]

theorem envBound51132 : H12AffineFastState.Bounded env51132 := by
  intro p hp
  have h : env51132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51096_51132 : H12AffineEnvironment.transform 7 173 env51096 = env51132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51096 == env51132) = true)

def env51133 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41003,143496,20497,492566,148668,148668,96267,74795,74799,172,222254,1213,135681]

theorem envBound51133 : H12AffineFastState.Bounded env51133 := by
  intro p hp
  have h : env51133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51132_51133 : H12AffineEnvironment.transform 5 16 env51132 = env51133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51132 == env51133) = true)

theorem identity51133 : scanCanonicalize (H12AffineFastState.compose env51133 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound51133 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51134 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61569,147473,41003,143496,20497,60445,148668,148668,96267,74795,74799,172,222254,1213,135681]

theorem envBound51134 : H12AffineFastState.Bounded env51134 := by
  intro p hp
  have h : env51134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51133_51134 : H12AffineEnvironment.transform 17 223243 env51133 = env51134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env51133 == env51134) = true)

theorem identity51134 : scanCanonicalize (H12AffineFastState.compose env51134 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound51134 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51135 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4096,61569,147473,41003,143496,20497,60445,148668,148668,2184,21672,21676,172,136365,1213,135681]

theorem envBound51135 : H12AffineFastState.Bounded env51135 := by
  intro p hp
  have h : env51135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51134_51135 : H12AffineEnvironment.transform 15 28803 env51134 = env51135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env51134 == env51135) = true)

theorem identity51135 : scanCanonicalize (H12AffineFastState.compose env51135 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound51135 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51136 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,46245,44077,41124,32769,4096,61569,62644,41003,33837,20497,60445,61465,61465,2184,21672,21676,172,40968,1213,42660]

theorem envBound51136 : H12AffineFastState.Bounded env51136 := by
  intro p hp
  have h : env51136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51135_51136 : H12AffineEnvironment.transform 16 46245 env51135 = env51136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env51135 == env51136) = true)

theorem identity51136 : scanCanonicalize (H12AffineFastState.compose env51136 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound51136 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env51137 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,46245,44077,41124,32769,4096,46140,45065,41003,33837,5292,43168,46244,46244,2184,4117,4113,172,40968,1213,42660]

theorem envBound51137 : H12AffineFastState.Bounded env51137 := by
  intro p hp
  have h : env51137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51136_51137 : H12AffineEnvironment.transform 13 1213 env51136 = env51137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env51136 == env51137) = true)

theorem identity51137 : scanCanonicalize (H12AffineFastState.compose env51137 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound51137 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51138 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13374,1212,7220,4285,12312,4096,1061,16,4146,13364,5292,6329,1213,1213,2184,4117,4113,172,4113,1213,5821]

theorem envBound51138 : H12AffineFastState.Bounded env51138 := by
  intro p hp
  have h : env51138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51137_51138 : H12AffineEnvironment.transform 14 12313 env51137 = env51138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env51137 == env51138) = true)

theorem identity51138 : scanCanonicalize (H12AffineFastState.compose env51138 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 644) := by decide +kernel

theorem selectedBound51138 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env51139 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,644,8192,1213,8861,9914,1212,3760,569,8860,644,1061,16,694,9904,1576,2621,1213,1213,2184,657,661,172,661,1213,1081]

theorem envBound51139 : H12AffineFastState.Bounded env51139 := by
  intro p hp
  have h : env51139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51138_51139 : H12AffineEnvironment.transform 11 644 env51138 = env51139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 644 env51138 == env51139) = true)

theorem identity51139 : scanCanonicalize (H12AffineFastState.compose env51139 (packedSelected [0,4,5,6,7,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 3126) := by decide +kernel

theorem selectedBound51139 : packedSelected [0,4,5,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env51140 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,644,3126,1213,3755,2700,1212,3760,569,3754,644,1061,16,694,2694,1576,2621,1213,1213,2184,657,661,172,661,1213,1081]

theorem envBound51140 : H12AffineFastState.Bounded env51140 := by
  intro p hp
  have h : env51140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51139_51140 : H12AffineEnvironment.transform 12 3126 env51139 = env51140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3126 env51139 == env51140) = true)

theorem identity51140 : scanCanonicalize (H12AffineFastState.compose env51140 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound51140 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env51141 : List Nat := [2,4,8,16,28,16,128,145,512,1024,2048,644,3082,1153,3735,2700,1152,3724,517,3734,644,1049,16,650,2694,1556,2561,1153,1153,2184,657,661,144,661,1153,1029]

theorem envBound51141 : H12AffineFastState.Bounded env51141 := by
  intro p hp
  have h : env51141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51140_51141 : H12AffineEnvironment.transform 4 28 env51140 = env51141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env51140 == env51141) = true)

theorem identity51141 : scanCanonicalize (H12AffineFastState.compose env51141 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound51141 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51142 : List Nat := [2,4,8,16,28,16,128,145,512,1024,158,644,1172,1153,1545,530,1152,1554,517,1544,644,1049,16,650,536,1556,671,1153,1153,22,657,661,144,661,1153,1029]

theorem envBound51142 : H12AffineFastState.Bounded env51142 := by
  intro p hp
  have h : env51142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51141_51142 : H12AffineEnvironment.transform 10 158 env51141 = env51142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env51141 == env51142) = true)

theorem identity51142 : scanCanonicalize (H12AffineFastState.compose env51142 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound51142 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env51143 : List Nat := [2,4,8,16,28,16,128,145,512,150,158,644,2,23,671,530,22,644,517,670,644,143,16,650,536,642,671,23,23,22,657,661,144,661,23,147]

theorem envBound51143 : H12AffineFastState.Bounded env51143 := by
  intro p hp
  have h : env51143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51142_51143 : H12AffineEnvironment.transform 9 150 env51142 = env51143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env51142 == env51143) = true)

theorem identity51143 : scanCanonicalize (H12AffineFastState.compose env51143 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound51143 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env51144 : List Nat := [2,4,8,16,28,16,128,145,136,150,158,12,2,23,23,154,22,12,141,22,12,143,16,2,144,10,23,23,23,22,25,29,144,29,23,147]

theorem envBound51144 : H12AffineFastState.Bounded env51144 := by
  intro p hp
  have h : env51144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51143_51144 : H12AffineEnvironment.transform 8 136 env51143 = env51144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env51143 == env51144) = true)

theorem identity51144 : scanCanonicalize (H12AffineFastState.compose env51144 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51144 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env51145 : List Nat := [2,4,8,16,28,16,9,24,1,31,23,12,2,23,23,19,22,12,4,22,12,6,16,2,25,10,23,23,23,22,25,29,25,29,23,26]

theorem envBound51145 : H12AffineFastState.Bounded env51145 := by
  intro p hp
  have h : env51145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51144_51145 : H12AffineEnvironment.transform 6 9 env51144 = env51145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51144 == env51145) = true)

theorem identity51145 : scanCanonicalize (H12AffineFastState.compose env51145 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51145 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51146 : List Nat := [2,4,8,11,7,11,9,3,1,4,12,12,2,12,12,8,13,12,4,13,12,6,11,2,2,10,12,12,12,13,2,6,2,6,12,1]

theorem envBound51146 : H12AffineFastState.Bounded env51146 := by
  intro p hp
  have h : env51146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51145_51146 : H12AffineEnvironment.transform 3 11 env51145 = env51146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51145 == env51146) = true)

def env51147 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41003,143496,20497,492567,148669,148669,96266,74795,74799,172,222255,1212,135681]

theorem envBound51147 : H12AffineFastState.Bounded env51147 := by
  intro p hp
  have h : env51147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51132_51147 : H12AffineEnvironment.transform 5 17 env51132 = env51147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51132 == env51147) = true)

theorem identity51147 : scanCanonicalize (H12AffineFastState.compose env51147 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound51147 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env51148 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61568,98354,41003,127146,20497,279605,99487,99487,96266,74795,74799,172,41997,1212,119331]

theorem envBound51148 : H12AffineFastState.Bounded env51148 := by
  intro p hp
  have h : env51148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51147_51148 : H12AffineEnvironment.transform 16 114722 env51147 = env51148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env51147 == env51148) = true)

theorem identity51148 : scanCanonicalize (H12AffineFastState.compose env51148 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 122031) := by decide +kernel

theorem selectedBound51148 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51149 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,122031,119843,32769,4096,61568,98354,41003,127146,20497,104602,99487,99487,96266,74795,74799,172,41997,1212,119331]

theorem envBound51149 : H12AffineFastState.Bounded env51149 := by
  intro p hp
  have h : env51149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51148_51149 : H12AffineEnvironment.transform 17 122031 env51148 = env51149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122031 env51148 == env51149) = true)

theorem identity51149 : scanCanonicalize (H12AffineFastState.compose env51149 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound51149 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env51150 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,3212,1024,32769,4096,61568,20497,41003,8329,20497,18617,21692,21692,43049,62472,62476,172,41997,1212,512]

theorem envBound51150 : H12AffineFastState.Bounded env51150 := by
  intro p hp
  have h : env51150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51149_51150 : H12AffineEnvironment.transform 15 53283 env51149 = env51150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env51149 == env51150) = true)

theorem identity51150 : scanCanonicalize (H12AffineFastState.compose env51150 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound51150 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51151 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,12346,4097,3212,1024,24600,4096,4249,20497,16434,8329,20497,18617,21692,21692,18480,5137,5141,172,17428,1212,512]

theorem envBound51151 : H12AffineFastState.Bounded env51151 := by
  intro p hp
  have h : env51151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51150_51151 : H12AffineEnvironment.transform 14 24601 env51150 = env51151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env51150 == env51151) = true)

theorem identity51151 : scanCanonicalize (H12AffineFastState.compose env51151 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound51151 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51152 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,657,16384,17032,4779,4097,3212,1024,17033,4096,4249,20497,16434,536,20497,18617,21692,21692,18480,5137,5141,172,17428,1212,512]

theorem envBound51152 : H12AffineFastState.Bounded env51152 := by
  intro p hp
  have h : env51152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51151_51152 : H12AffineEnvironment.transform 12 657 env51151 = env51152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env51151 == env51152) = true)

theorem identity51152 : scanCanonicalize (H12AffineFastState.compose env51152 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 1703) := by decide +kernel

theorem selectedBound51152 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env51153 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,657,1703,1071,4779,4097,3212,1024,1070,4096,4249,5814,1685,536,5814,3614,4635,4635,3735,5137,5141,172,691,1212,512]

theorem envBound51153 : H12AffineFastState.Bounded env51153 := by
  intro p hp
  have h : env51153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51152_51153 : H12AffineEnvironment.transform 13 1703 env51152 = env51153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1703 env51152 == env51153) = true)

theorem identity51153 : scanCanonicalize (H12AffineFastState.compose env51153 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound51153 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env51154 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2048,657,1703,1071,2731,2049,3212,1024,1070,2048,2201,3766,1685,536,3766,3614,2587,2587,3735,3089,3093,172,691,1212,512]

theorem envBound51154 : H12AffineFastState.Bounded env51154 := by
  intro p hp
  have h : env51154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51153_51154 : H12AffineEnvironment.transform 11 2048 env51153 = env51154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env51153 == env51154) = true)

theorem identity51154 : scanCanonicalize (H12AffineFastState.compose env51154 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound51154 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env51155 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,1213,657,1703,1071,1558,1212,49,1024,1070,1213,1060,523,1685,536,523,675,1702,1702,554,172,168,172,691,1212,512]

theorem envBound51155 : H12AffineFastState.Bounded env51155 := by
  intro p hp
  have h : env51155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51154_51155 : H12AffineEnvironment.transform 10 1213 env51154 = env51155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env51154 == env51155) = true)

theorem identity51155 : scanCanonicalize (H12AffineFastState.compose env51155 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound51155 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51156 : List Nat := [2,4,8,16,32,17,128,173,512,542,675,675,657,185,561,8,674,49,542,560,675,570,523,139,536,523,675,184,184,554,172,168,172,691,674,512]

theorem envBound51156 : H12AffineFastState.Bounded env51156 := by
  intro p hp
  have h : env51156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51155_51156 : H12AffineEnvironment.transform 9 542 env51155 = env51156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env51155 == env51156) = true)

theorem identity51156 : scanCanonicalize (H12AffineFastState.compose env51156 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51156 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env51157 : List Nat := [2,4,8,16,32,17,8,37,512,542,555,555,537,49,561,8,554,49,542,560,555,570,523,3,536,523,555,48,48,554,36,32,36,571,554,512]

theorem envBound51157 : H12AffineFastState.Bounded env51157 := by
  intro p hp
  have h : env51157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51156_51157 : H12AffineEnvironment.transform 6 8 env51156 = env51157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51156 == env51157) = true)

def env51158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245633,148801,545088,96347,16876544,74799,257,17420372,1345,525824]

theorem envBound51158 : H12AffineFastState.Bounded env51158 := by
  intro p hp
  have h : env51158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51025_51158 : H12AffineEnvironment.transform 26 17245633 env51025 = env51158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env51025 == env51158) = true)

theorem identity51158 : scanCanonicalize (H12AffineFastState.compose env51158 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound51158 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717114,533641,672784,906491,148801,545088,96347,750906,74799,257,205166,1345,525824]

theorem envBound51159 : H12AffineFastState.Bounded env51159 := by
  intro p hp
  have h : env51159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51158_51159 : H12AffineEnvironment.transform 23 717114 env51158 = env51159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env51158 == env51159) = true)

def env51160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58682,143497,20496,508155,148801,148800,96347,90426,74799,257,205166,1345,135680]

theorem envBound51160 : H12AffineFastState.Bounded env51160 := by
  intro p hp
  have h : env51160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51159_51160 : H12AffineEnvironment.transform 18 136192 env51159 = env51160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env51159 == env51160) = true)

def env51161 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143497,20496,508155,148717,148716,96347,90262,74799,173,204994,1261,135680]

theorem envBound51161 : H12AffineFastState.Bounded env51161 := by
  intro p hp
  have h : env51161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51160_51161 : H12AffineEnvironment.transform 7 172 env51160 = env51161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51160 == env51161) = true)

def env51162 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143497,20496,508075,148669,148668,96267,90262,74799,173,204946,1213,135680]

theorem envBound51162 : H12AffineFastState.Bounded env51162 := by
  intro p hp
  have h : env51162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51161_51162 : H12AffineEnvironment.transform 5 16 env51161 = env51162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51161 == env51162) = true)

theorem identity51162 : scanCanonicalize (H12AffineFastState.compose env51162 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound51162 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51163 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,58518,32809,20496,356363,62493,62492,96267,90262,74799,173,102450,1213,41632]

theorem envBound51163 : H12AffineFastState.Bounded env51163 := by
  intro p hp
  have h : env51163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51162_51163 : H12AffineEnvironment.transform 16 45216 env51162 = env51163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env51162 == env51163) = true)

theorem identity51163 : scanCanonicalize (H12AffineFastState.compose env51163 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound51163 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51164 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4096,61569,61617,58518,32809,20496,96386,62493,62492,96267,90262,74799,173,102450,1213,41632]

theorem envBound51164 : H12AffineFastState.Bounded env51164 := by
  intro p hp
  have h : env51164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51163_51164 : H12AffineEnvironment.transform 17 2185 env51163 = env51164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env51163 == env51164) = true)

theorem identity51164 : scanCanonicalize (H12AffineFastState.compose env51164 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound51164 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51165 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,37018,45216,2185,42144,32769,4096,61569,61617,58518,32809,20496,59416,62493,62492,59537,61452,46261,173,168,1213,41632]

theorem envBound51165 : H12AffineFastState.Bounded env51165 := by
  intro p hp
  have h : env51165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51164_51165 : H12AffineEnvironment.transform 15 37018 env51164 = env51165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env51164 == env51165) = true)

theorem identity51165 : scanCanonicalize (H12AffineFastState.compose env51165 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound51165 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env51166 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,13374,5124,2185,4,9381,4096,21541,21525,16434,9357,20496,19644,20665,20664,19509,21672,4113,173,168,1213,1540]

theorem envBound51166 : H12AffineFastState.Bounded env51166 := by
  intro p hp
  have h : env51166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51165_51166 : H12AffineEnvironment.transform 14 9380 env51165 = env51166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env51165 == env51166) = true)

theorem identity51166 : scanCanonicalize (H12AffineFastState.compose env51166 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 1541) := by decide +kernel

theorem selectedBound51166 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env51167 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1541,9380,13374,5124,2185,4,9381,4096,4640,4624,1591,9357,5653,2745,5820,5821,2608,4781,4113,173,168,1213,1540]

theorem envBound51167 : H12AffineFastState.Bounded env51167 := by
  intro p hp
  have h : env51167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51166_51167 : H12AffineEnvironment.transform 13 1541 env51166 = env51167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1541 env51166 == env51167) = true)

theorem identity51167 : scanCanonicalize (H12AffineFastState.compose env51167 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound51167 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51168 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2603,8192,1541,9380,11797,3631,2185,4,9381,2603,2059,2107,1591,9357,3134,2745,3223,3222,2608,2182,2618,173,168,1213,1540]

theorem envBound51168 : H12AffineFastState.Bounded env51168 := by
  intro p hp
  have h : env51168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51167_51168 : H12AffineEnvironment.transform 11 2603 env51167 = env51168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env51167 == env51168) = true)

theorem identity51168 : scanCanonicalize (H12AffineFastState.compose env51168 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound51168 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env51169 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2603,3237,1541,2049,688,3631,2185,4,2048,2603,2059,2107,1591,2088,3134,2745,3223,3222,2608,2182,2618,173,168,1213,1540]

theorem envBound51169 : H12AffineFastState.Bounded env51169 := by
  intro p hp
  have h : env51169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51168_51169 : H12AffineEnvironment.transform 12 3237 env51168 = env51169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env51168 == env51169) = true)

theorem identity51169 : scanCanonicalize (H12AffineFastState.compose env51169 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound51169 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env51170 : List Nat := [2,4,8,16,32,16,128,172,512,150,2048,2603,2099,659,2049,688,2745,2185,4,2048,2603,2059,2107,673,2088,2216,2745,2049,2048,2608,2182,2618,173,168,43,658]

theorem envBound51170 : H12AffineFastState.Bounded env51170 := by
  intro p hp
  have h : env51170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51169_51170 : H12AffineEnvironment.transform 9 150 env51169 = env51170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env51169 == env51170) = true)

theorem identity51170 : scanCanonicalize (H12AffineFastState.compose env51170 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound51170 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51171 : List Nat := [2,4,8,16,32,16,128,172,163,150,2048,2184,2099,48,2049,19,2074,2185,4,2048,2184,2059,2107,2,2088,2216,2074,2049,2048,2195,2182,2201,173,168,43,49]

theorem envBound51171 : H12AffineFastState.Bounded env51171 := by
  intro p hp
  have h : env51171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51170_51171 : H12AffineEnvironment.transform 8 163 env51170 = env51171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env51170 == env51171) = true)

theorem identity51171 : scanCanonicalize (H12AffineFastState.compose env51171 (packedSelected [5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51171 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env51172 : List Nat := [2,4,8,16,11,16,128,135,136,150,2048,2184,2072,27,2049,19,2074,2185,4,2048,2184,2059,2064,2,2051,2179,2074,2049,2048,2195,2182,2201,134,131,0,26]

theorem envBound51172 : H12AffineFastState.Bounded env51172 := by
  intro p hp
  have h : env51172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51171_51172 : H12AffineEnvironment.transform 4 11 env51171 = env51172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51171 == env51172) = true)

def env51173 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143497,20496,508074,148668,148669,96266,90262,74799,173,204947,1212,135680]

theorem envBound51173 : H12AffineFastState.Bounded env51173 := by
  intro p hp
  have h : env51173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51161_51173 : H12AffineEnvironment.transform 5 17 env51161 = env51173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51161 == env51173) = true)

theorem identity51173 : scanCanonicalize (H12AffineFastState.compose env51173 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound51173 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51174 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,58518,143497,20496,120866,148668,148669,96266,90262,74799,173,204947,1212,135680]

theorem envBound51174 : H12AffineFastState.Bounded env51174 := by
  intro p hp
  have h : env51174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51173_51174 : H12AffineEnvironment.transform 17 137352 env51173 = env51174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env51173 == env51174) = true)

theorem identity51174 : scanCanonicalize (H12AffineFastState.compose env51174 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound51174 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env51175 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4096,61568,46093,58518,50324,20496,120866,45217,45216,96266,90262,74799,173,119950,1212,58909]

theorem envBound51175 : H12AffineFastState.Bounded env51175 := by
  intro p hp
  have h : env51175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51174_51175 : H12AffineEnvironment.transform 16 62493 env51174 = env51175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env51174 == env51175) = true)

theorem identity51175 : scanCanonicalize (H12AffineFastState.compose env51175 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound51175 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51176 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,185,32768,65536,46244,44076,41124,32769,4096,45113,46093,42031,33837,4265,104603,45217,45216,80051,73775,74799,173,103479,1212,42660]

theorem envBound51176 : H12AffineFastState.Bounded env51176 := by
  intro p hp
  have h : env51176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51175_51176 : H12AffineEnvironment.transform 13 185 env51175 = env51176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env51175 == env51176) = true)

theorem identity51176 : scanCanonicalize (H12AffineFastState.compose env51176 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 44559) := by decide +kernel

theorem selectedBound51176 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env51177 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,185,32768,44559,46244,44076,41124,32769,4096,45113,46093,42031,33837,4265,13972,45217,45216,38588,36384,35360,173,14904,1212,42660]

theorem envBound51177 : H12AffineFastState.Bounded env51177 := by
  intro p hp
  have h : env51177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51176_51177 : H12AffineEnvironment.transform 15 44559 env51176 = env51177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 44559 env51176 == env51177) = true)

theorem identity51177 : scanCanonicalize (H12AffineFastState.compose env51177 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound51177 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env51178 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7829,185,32768,37018,35377,37561,40497,32769,4096,36524,35480,39610,33837,4265,2049,36404,36405,38588,36384,35360,173,1197,1212,38961]

theorem envBound51178 : H12AffineFastState.Bounded env51178 := by
  intro p hp
  have h : env51178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51177_51178 : H12AffineEnvironment.transform 12 7829 env51177 = env51178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env51177 == env51178) = true)

theorem identity51178 : scanCanonicalize (H12AffineFastState.compose env51178 (packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 2561) := by decide +kernel

theorem selectedBound51178 : packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env51179 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7829,185,2561,6811,48,6328,5168,2560,4096,1197,153,4283,3628,4265,2049,1077,1076,7357,1057,33,173,1197,1212,4656]

theorem envBound51179 : H12AffineFastState.Bounded env51179 := by
  intro p hp
  have h : env51179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51178_51179 : H12AffineEnvironment.transform 14 2561 env51178 = env51179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2561 env51178 == env51179) = true)

theorem identity51179 : scanCanonicalize (H12AffineFastState.compose env51179 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound51179 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env51180 : List Nat := [2,4,8,16,32,17,128,172,512,31,2048,4096,6794,185,2561,6811,48,6328,4143,2560,4096,178,153,4283,2611,4265,2049,42,43,6306,62,33,173,178,163,4656]

theorem envBound51180 : H12AffineFastState.Bounded env51180 := by
  intro p hp
  have h : env51180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51179_51180 : H12AffineEnvironment.transform 9 31 env51179 = env51180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env51179 == env51180) = true)

theorem identity51180 : scanCanonicalize (H12AffineFastState.compose env51180 (packedSelected [0,1,3,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound51180 : packedSelected [0,1,3,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51181 : List Nat := [2,4,8,16,32,17,128,172,146,31,2048,4096,6168,185,2195,6153,48,6328,4143,2194,4096,178,153,4283,2209,4265,2049,42,43,6306,62,33,173,178,163,4258]

theorem envBound51181 : H12AffineFastState.Bounded env51181 := by
  intro p hp
  have h : env51181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51180_51181 : H12AffineEnvironment.transform 8 146 env51180 = env51181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env51180 == env51181) = true)

theorem identity51181 : scanCanonicalize (H12AffineFastState.compose env51181 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound51181 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env51182 : List Nat := [2,4,8,16,32,17,128,172,146,31,2048,2195,139,185,2195,154,48,43,2236,2194,2195,178,153,2088,2209,2106,2049,42,43,49,62,33,173,178,163,2097]

theorem envBound51182 : H12AffineFastState.Bounded env51182 := by
  intro p hp
  have h : env51182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51181_51182 : H12AffineEnvironment.transform 11 2195 env51181 = env51182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env51181 == env51182) = true)

theorem identity51182 : scanCanonicalize (H12AffineFastState.compose env51182 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51182 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env51183 : List Nat := [2,4,8,11,32,10,128,172,137,4,2048,2184,139,162,2184,129,43,43,2215,2185,2184,169,130,2088,2209,2081,2049,42,43,42,37,33,173,169,163,2090]

theorem envBound51183 : H12AffineFastState.Bounded env51183 := by
  intro p hp
  have h : env51183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51182_51183 : H12AffineEnvironment.transform 3 11 env51182 = env51183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51182 == env51183) = true)

theorem identity51183 : scanCanonicalize (H12AffineFastState.compose env51183 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51183 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51184 : List Nat := [2,4,8,11,11,10,128,135,137,4,2048,2184,139,137,2184,129,0,0,2188,2185,2184,130,130,2051,2186,2058,2049,1,0,1,14,10,134,130,136,2049]

theorem envBound51184 : H12AffineFastState.Bounded env51184 := by
  intro p hp
  have h : env51184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51183_51184 : H12AffineEnvironment.transform 4 11 env51183 = env51184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51183 == env51184) = true)

theorem identity51184 : scanCanonicalize (H12AffineFastState.compose env51184 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51185 : List Nat := [2,4,8,11,11,10,4,3,13,4,2048,2060,15,13,2060,5,0,0,2056,2061,2060,6,6,2051,2062,2058,2049,1,0,1,14,10,2,6,12,2049]

theorem envBound51185 : H12AffineFastState.Bounded env51185 := by
  intro p hp
  have h : env51185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51184_51185 : H12AffineEnvironment.transform 6 4 env51184 = env51185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51184 == env51185) = true)

theorem identity51185 : scanCanonicalize (H12AffineFastState.compose env51185 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51185 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env51186 : List Nat := [2,4,8,11,11,10,4,3,13,4,0,12,15,13,12,5,0,0,8,13,12,6,6,3,14,10,1,1,0,1,14,10,2,6,12,1]

theorem envBound51186 : H12AffineFastState.Bounded env51186 := by
  intro p hp
  have h : env51186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51185_51186 : H12AffineEnvironment.transform 10 0 env51185 = env51186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51185 == env51186) = true)

theorem identity51186 : scanCanonicalize (H12AffineFastState.compose env51186 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51187 : List Nat := [2,4,5,6,6,7,4,3,0,4,0,1,2,0,1,5,0,0,5,0,1,6,6,3,3,7,1,1,0,1,3,7,2,6,1,1]

theorem envBound51187 : H12AffineFastState.Bounded env51187 := by
  intro p hp
  have h : env51187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51186_51187 : H12AffineEnvironment.transform 2 5 env51186 = env51187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51186 == env51187) = true)

theorem identity51187 : scanCanonicalize (H12AffineFastState.compose env51187 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51188 : List Nat := [2,0,1,2,2,3,0,3,0,0,0,1,2,0,1,1,0,0,1,0,1,2,2,3,3,3,1,1,0,1,3,3,2,2,1,1]

theorem envBound51188 : H12AffineFastState.Bounded env51188 := by
  intro p hp
  have h : env51188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51187_51188 : H12AffineEnvironment.transform 1 0 env51187 = env51188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51187 == env51188) = true)

theorem identity51188 : scanCanonicalize (H12AffineFastState.compose env51188 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51188 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51189 : List Nat := [1,0,1,1,1,0,0,0,0,0,0,1,1,0,1,1,0,0,1,0,1,1,1,0,0,0,1,1,0,1,0,0,1,1,1,1]

theorem envBound51189 : H12AffineFastState.Bounded env51189 := by
  intro p hp
  have h : env51189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51188_51189 : H12AffineEnvironment.transform 0 1 env51188 = env51189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51188 == env51189) = true)

def env51190 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143497,20496,508155,148716,148717,96347,90263,74799,172,204995,1260,135680]

theorem envBound51190 : H12AffineFastState.Bounded env51190 := by
  intro p hp
  have h : env51190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51160_51190 : H12AffineEnvironment.transform 7 173 env51160 = env51190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51160 == env51190) = true)

def env51191 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143497,20496,508075,148668,148669,96267,90263,74799,172,204947,1212,135680]

theorem envBound51191 : H12AffineFastState.Bounded env51191 := by
  intro p hp
  have h : env51191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51190_51191 : H12AffineEnvironment.transform 5 16 env51190 = env51191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51190 == env51191) = true)

theorem identity51191 : scanCanonicalize (H12AffineFastState.compose env51191 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound51191 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51192 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61569,115855,58519,111639,20496,279605,114722,114723,96267,90263,74799,172,41997,1212,104094]

theorem envBound51192 : H12AffineFastState.Bounded env51192 := by
  intro p hp
  have h : env51192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51191_51192 : H12AffineEnvironment.transform 16 99486 env51191 = env51192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env51191 == env51192) = true)

theorem identity51192 : scanCanonicalize (H12AffineFastState.compose env51192 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound51192 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env51193 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,29830,61464,262144,58392,32769,4096,61569,45065,58519,49297,20496,279605,46244,46245,3213,5137,20649,172,41997,1212,57880]

theorem envBound51193 : H12AffineFastState.Bounded env51193 := by
  intro p hp
  have h : env51193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51192_51193 : H12AffineEnvironment.transform 15 29830 env51192 = env51193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env51192 == env51193) = true)

theorem identity51193 : scanCanonicalize (H12AffineFastState.compose env51193 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound51193 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51194 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24600,29830,4096,262144,1024,24601,4096,4249,20497,1167,8329,20496,279605,21692,21693,3213,5137,20649,172,17429,1212,512]

theorem envBound51194 : H12AffineFastState.Bounded env51194 := by
  intro p hp
  have h : env51194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51193_51194 : H12AffineEnvironment.transform 14 24600 env51193 = env51194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env51193 == env51194) = true)

theorem identity51194 : scanCanonicalize (H12AffineFastState.compose env51194 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound51194 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51195 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9381,12347,4096,262144,1024,9380,4096,4249,5292,1167,8329,5293,262280,4097,4096,3213,5137,5140,172,168,1212,512]

theorem envBound51195 : H12AffineFastState.Bounded env51195 := by
  intro p hp
  have h : env51195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51194_51195 : H12AffineEnvironment.transform 13 1213 env51194 = env51195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env51194 == env51195) = true)

theorem identity51195 : scanCanonicalize (H12AffineFastState.compose env51195 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound51195 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51196 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4648,1213,5773,531,4096,262144,1024,5772,4096,4249,5292,1167,4769,5293,262280,4097,4096,3213,5137,5140,172,168,1212,512]

theorem envBound51196 : H12AffineFastState.Bounded env51196 := by
  intro p hp
  have h : env51196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51195_51196 : H12AffineEnvironment.transform 12 4648 env51195 = env51196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env51195 == env51196) = true)

theorem identity51196 : scanCanonicalize (H12AffineFastState.compose env51196 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound51196 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env51197 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4648,1213,5773,531,4096,6192,1024,5772,4096,4249,5292,1167,4769,5293,6328,4097,4096,3213,5137,5140,172,168,1212,512]

theorem envBound51197 : H12AffineFastState.Bounded env51197 := by
  intro p hp
  have h : env51197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51196_51197 : H12AffineEnvironment.transform 17 6192 env51196 = env51197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env51196 == env51197) = true)

theorem identity51197 : scanCanonicalize (H12AffineFastState.compose env51197 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound51197 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51198 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2587,2099,1213,3222,531,2587,555,1024,3223,2587,2690,3767,1167,2234,3766,675,2586,2587,3213,3594,3599,172,168,1212,512]

theorem envBound51198 : H12AffineFastState.Bounded env51198 := by
  intro p hp
  have h : env51198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51197_51198 : H12AffineEnvironment.transform 11 2587 env51197 = env51198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env51197 == env51198) = true)

theorem identity51198 : scanCanonicalize (H12AffineFastState.compose env51198 (packedSelected [1,3,17] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound51198 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env51199 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,184,656,1213,1589,531,184,555,1024,1588,184,33,1044,1167,537,1045,675,185,184,1582,1193,1196,172,168,1212,512]

theorem envBound51199 : H12AffineFastState.Bounded env51199 := by
  intro p hp
  have h : env51199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51198_51199 : H12AffineEnvironment.transform 10 675 env51198 = env51199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env51198 == env51199) = true)

theorem identity51199 : scanCanonicalize (H12AffineFastState.compose env51199 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound51199 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51200 : List Nat := [2,4,8,16,32,16,128,173,512,516,675,184,656,697,49,531,184,555,516,48,184,33,528,651,537,529,675,185,184,42,685,680,172,168,696,512]

theorem envBound51200 : H12AffineFastState.Bounded env51200 := by
  intro p hp
  have h : env51200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51199_51200 : H12AffineEnvironment.transform 9 516 env51199 = env51200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env51199 == env51200) = true)

theorem identity51200 : scanCanonicalize (H12AffineFastState.compose env51200 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound51200 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51201 : List Nat := [2,4,8,16,32,16,128,173,27,31,184,184,139,162,49,8,184,48,31,48,184,33,11,144,2,10,184,185,184,42,182,179,172,168,163,27]

theorem envBound51201 : H12AffineFastState.Bounded env51201 := by
  intro p hp
  have h : env51201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51200_51201 : H12AffineEnvironment.transform 8 27 env51200 = env51201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env51200 == env51201) = true)

def env51202 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143497,20496,508074,148669,148668,96266,90263,74799,172,204946,1213,135680]

theorem envBound51202 : H12AffineFastState.Bounded env51202 := by
  intro p hp
  have h : env51202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51190_51202 : H12AffineEnvironment.transform 5 17 env51190 = env51202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51190 == env51202) = true)

theorem identity51202 : scanCanonicalize (H12AffineFastState.compose env51202 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound51202 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51203 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61568,147472,58519,143497,20496,60445,148669,148668,96266,90263,74799,172,204946,1213,135680]

theorem envBound51203 : H12AffineFastState.Bounded env51203 := by
  intro p hp
  have h : env51203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51202_51203 : H12AffineEnvironment.transform 17 208055 env51202 = env51203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env51202 == env51203) = true)

theorem identity51203 : scanCanonicalize (H12AffineFastState.compose env51203 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound51203 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env51204 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4096,61568,147472,58519,143497,20496,60445,148669,148668,43048,45237,62477,172,192688,1213,135680]

theorem envBound51204 : H12AffineFastState.Bounded env51204 := by
  intro p hp
  have h : env51204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51203_51204 : H12AffineEnvironment.transform 15 53282 env51203 = env51204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env51203 == env51204) = true)

theorem identity51204 : scanCanonicalize (H12AffineFastState.compose env51204 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound51204 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51205 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4096,61568,5293,58519,25652,20496,60445,4096,4097,43048,45237,62477,172,41997,1213,18109]

theorem envBound51205 : H12AffineFastState.Bounded env51205 := by
  intro p hp
  have h : env51205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51204_51205 : H12AffineEnvironment.transform 16 21693 env51204 = env51205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env51204 == env51205) = true)

theorem identity51205 : scanCanonicalize (H12AffineFastState.compose env51205 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound51205 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env51206 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24600,12346,21693,18480,16573,24601,4096,4248,5293,1167,25652,20496,3077,4096,4097,18480,20653,5141,172,17429,1213,18109]

theorem envBound51206 : H12AffineFastState.Bounded env51206 := by
  intro p hp
  have h : env51206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51205_51206 : H12AffineEnvironment.transform 14 24600 env51205 = env51206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env51205 == env51206) = true)

theorem identity51206 : scanCanonicalize (H12AffineFastState.compose env51206 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 9756) := by decide +kernel

theorem selectedBound51206 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env51207 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,9756,1540,12346,12961,11820,9889,1541,4096,4248,5293,1167,552,13836,3077,4096,4097,11820,14001,5141,172,8713,1213,8353]

theorem envBound51207 : H12AffineFastState.Bounded env51207 := by
  intro p hp
  have h : env51207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51206_51207 : H12AffineEnvironment.transform 13 9756 env51206 = env51207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9756 env51206 == env51207) = true)

theorem identity51207 : scanCanonicalize (H12AffineFastState.compose env51207 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound51207 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env51208 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3118,8192,9756,1540,11284,11919,11820,9889,1541,3118,3254,2179,1167,552,10786,3077,3118,3119,11820,10911,2107,172,8713,1213,8353]

theorem envBound51208 : H12AffineFastState.Bounded env51208 := by
  intro p hp
  have h : env51208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51207_51208 : H12AffineEnvironment.transform 11 3118 env51207 = env51208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env51207 == env51208) = true)

theorem identity51208 : scanCanonicalize (H12AffineFastState.compose env51208 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound51208 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env51209 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3118,2562,3102,1540,1558,1165,1070,3235,1541,3118,3254,2179,1167,552,32,3077,3118,3119,1070,157,2107,172,2059,1213,2723]

theorem envBound51209 : H12AffineFastState.Bounded env51209 := by
  intro p hp
  have h : env51209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51208_51209 : H12AffineEnvironment.transform 12 2562 env51208 = env51209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env51208 == env51209) = true)

theorem identity51209 : scanCanonicalize (H12AffineFastState.compose env51209 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound51209 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51210 : List Nat := [2,4,8,16,32,17,128,173,512,46,2048,2048,2562,2096,554,568,163,0,2189,555,2048,2200,2179,161,552,32,2091,2048,2049,0,157,2107,172,2059,147,2723]

theorem envBound51210 : H12AffineFastState.Bounded env51210 := by
  intro p hp
  have h : env51210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51209_51210 : H12AffineEnvironment.transform 9 46 env51209 = env51210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env51209 == env51210) = true)

theorem identity51210 : scanCanonicalize (H12AffineFastState.compose env51210 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound51210 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51211 : List Nat := [2,4,8,16,32,17,128,173,42,46,2048,2048,2088,2096,0,18,163,0,2189,1,2048,2200,2179,161,2,32,2091,2048,2049,0,157,2107,172,2059,147,2185]

theorem envBound51211 : H12AffineFastState.Bounded env51211 := by
  intro p hp
  have h : env51211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51210_51211 : H12AffineEnvironment.transform 8 42 env51210 = env51211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env51210 == env51211) = true)

theorem identity51211 : scanCanonicalize (H12AffineFastState.compose env51211 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound51211 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env51212 : List Nat := [2,4,8,16,32,17,128,173,42,46,147,147,187,163,0,18,163,0,30,1,147,11,16,161,2,32,184,147,146,0,157,168,172,152,147,26]

theorem envBound51212 : H12AffineFastState.Bounded env51212 := by
  intro p hp
  have h : env51212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51211_51212 : H12AffineEnvironment.transform 10 147 env51211 = env51212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env51211 == env51212) = true)

theorem identity51212 : scanCanonicalize (H12AffineFastState.compose env51212 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound51212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51213 : List Nat := [2,4,8,16,32,17,57,20,42,46,42,42,2,26,0,18,26,0,30,1,42,11,16,24,2,32,1,42,43,0,36,17,21,33,42,26]

theorem envBound51213 : H12AffineFastState.Bounded env51213 := by
  intro p hp
  have h : env51213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51212_51213 : H12AffineEnvironment.transform 6 57 env51212 = env51213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env51212 == env51213) = true)

theorem identity51213 : scanCanonicalize (H12AffineFastState.compose env51213 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51213 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51214 : List Nat := [2,4,8,10,32,11,35,14,42,46,42,42,2,0,0,8,0,0,4,1,42,11,10,2,2,32,1,42,43,0,36,11,15,33,42,0]

theorem envBound51214 : H12AffineFastState.Bounded env51214 := by
  intro p hp
  have h : env51214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51213_51214 : H12AffineEnvironment.transform 3 10 env51213 = env51214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51213 == env51214) = true)

theorem identity51214 : scanCanonicalize (H12AffineFastState.compose env51214 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound51214 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env51215 : List Nat := [2,4,8,10,12,11,15,14,6,2,6,6,2,0,0,8,0,0,4,1,6,11,10,2,2,12,1,6,7,0,8,11,15,13,6,0]

theorem envBound51215 : H12AffineFastState.Bounded env51215 := by
  intro p hp
  have h : env51215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51214_51215 : H12AffineEnvironment.transform 4 12 env51214 = env51215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env51214 == env51215) = true)

theorem identity51215 : scanCanonicalize (H12AffineFastState.compose env51215 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51215 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51216 : List Nat := [2,2,8,10,10,11,9,8,0,2,0,0,2,0,0,8,0,0,2,1,0,11,10,2,2,10,1,0,1,0,8,11,9,11,0,0]

theorem envBound51216 : H12AffineFastState.Bounded env51216 := by
  intro p hp
  have h : env51216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51215_51216 : H12AffineEnvironment.transform 1 2 env51215 = env51216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51215 == env51216) = true)

def env51217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58683,143496,20497,508154,148801,148801,96347,90427,74799,257,205166,1345,135681]

theorem envBound51217 : H12AffineFastState.Bounded env51217 := by
  intro p hp
  have h : env51217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51159_51217 : H12AffineEnvironment.transform 18 136193 env51159 = env51217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env51159 == env51217) = true)

def env51218 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143496,20497,508154,148717,148717,96347,90263,74799,173,204994,1261,135681]

theorem envBound51218 : H12AffineFastState.Bounded env51218 := by
  intro p hp
  have h : env51218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51217_51218 : H12AffineEnvironment.transform 7 172 env51217 = env51218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51217 == env51218) = true)

def env51219 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143496,20497,508074,148669,148669,96267,90263,74799,173,204946,1213,135681]

theorem envBound51219 : H12AffineFastState.Bounded env51219 := by
  intro p hp
  have h : env51219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51218_51219 : H12AffineEnvironment.transform 5 16 env51218 = env51219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51218 == env51219) = true)

theorem identity51219 : scanCanonicalize (H12AffineFastState.compose env51219 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound51219 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51220 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,58519,143496,20497,120867,148669,148669,96267,90263,74799,173,204946,1213,135681]

theorem envBound51220 : H12AffineFastState.Bounded env51220 := by
  intro p hp
  have h : env51220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51219_51220 : H12AffineEnvironment.transform 17 137353 env51219 = env51220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env51219 == env51220) = true)

theorem identity51220 : scanCanonicalize (H12AffineFastState.compose env51220 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound51220 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env51221 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4096,61569,46092,58519,50325,20497,120867,45216,45216,96267,90263,74799,173,119951,1213,58908]

theorem envBound51221 : H12AffineFastState.Bounded env51221 := by
  intro p hp
  have h : env51221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51220_51221 : H12AffineEnvironment.transform 16 62493 env51220 = env51221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env51220 == env51221) = true)

theorem identity51221 : scanCanonicalize (H12AffineFastState.compose env51221 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound51221 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51222 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,32768,65536,46244,44077,41125,32769,4096,45112,46092,42030,33836,4264,104602,45216,45216,80050,73774,74799,173,103478,1213,42661]

theorem envBound51222 : H12AffineFastState.Bounded env51222 := by
  intro p hp
  have h : env51222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51221_51222 : H12AffineEnvironment.transform 13 185 env51221 = env51222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env51221 == env51222) = true)

theorem identity51222 : scanCanonicalize (H12AffineFastState.compose env51222 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 7733) := by decide +kernel

theorem selectedBound51222 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env51223 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,7733,65536,10897,12824,16016,7732,4096,11789,10809,14875,6681,4264,67247,11925,11925,80050,73774,74799,173,68099,1213,14480]

theorem envBound51223 : H12AffineFastState.Bounded env51223 := by
  intro p hp
  have h : env51223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51222_51223 : H12AffineEnvironment.transform 14 7733 env51222 = env51223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7733 env51222 == env51223) = true)

theorem identity51223 : scanCanonicalize (H12AffineFastState.compose env51223 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 3758) := by decide +kernel

theorem selectedBound51223 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env51224 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,7733,3758,10897,12824,16016,7732,4096,11789,10809,14875,6681,4264,2049,11925,11925,13852,11904,10881,173,1197,1213,14480]

theorem envBound51224 : H12AffineFastState.Bounded env51224 := by
  intro p hp
  have h : env51224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51223_51224 : H12AffineEnvironment.transform 15 3758 env51223 = env51224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3758 env51223 == env51224) = true)

theorem identity51224 : scanCanonicalize (H12AffineFastState.compose env51224 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound51224 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51225 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2089,185,7733,3758,696,6705,5817,7732,4096,1572,528,4658,6681,4264,2049,1724,1724,7733,1705,680,173,1197,1213,4281]

theorem envBound51225 : H12AffineFastState.Bounded env51225 := by
  intro p hp
  have h : env51225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51224_51225 : H12AffineEnvironment.transform 12 2089 env51224 = env51225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env51224 == env51225) = true)

theorem identity51225 : scanCanonicalize (H12AffineFastState.compose env51225 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound51225 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env51226 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1589,4096,1564,185,4096,155,696,5124,5817,4097,4096,1572,528,4658,5164,4264,1588,1724,1724,4096,1705,680,173,1197,1213,4281]

theorem envBound51226 : H12AffineFastState.Bounded env51226 := by
  intro p hp
  have h : env51226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51225_51226 : H12AffineEnvironment.transform 10 1589 env51225 = env51226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env51225 == env51226) = true)

theorem identity51226 : scanCanonicalize (H12AffineFastState.compose env51226 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound51226 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51227 : List Nat := [2,4,8,16,32,16,128,172,512,151,674,4096,651,185,4096,155,696,4243,4654,4097,4096,691,528,4658,4283,4264,675,555,555,4096,574,680,173,58,42,4281]

theorem envBound51227 : H12AffineFastState.Bounded env51227 := by
  intro p hp
  have h : env51227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51226_51227 : H12AffineEnvironment.transform 9 151 env51226 = env51227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env51226 == env51227) = true)

theorem identity51227 : scanCanonicalize (H12AffineFastState.compose env51227 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound51227 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env51228 : List Nat := [2,4,8,16,32,16,128,172,147,151,49,4096,24,185,4096,155,43,4243,4285,4097,4096,32,131,4257,4283,4264,48,184,184,4096,173,59,173,58,42,4281]

theorem envBound51228 : H12AffineFastState.Bounded env51228 := by
  intro p hp
  have h : env51228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51227_51228 : H12AffineEnvironment.transform 8 147 env51227 = env51228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env51227 == env51228) = true)

theorem identity51228 : scanCanonicalize (H12AffineFastState.compose env51228 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound51228 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env51229 : List Nat := [2,4,8,16,32,16,128,172,147,151,49,43,24,185,43,155,43,184,150,42,43,32,131,138,144,131,48,184,184,43,173,59,173,58,42,146]

theorem envBound51229 : H12AffineFastState.Bounded env51229 := by
  intro p hp
  have h : env51229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51228_51229 : H12AffineEnvironment.transform 11 43 env51228 = env51229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env51228 == env51229) = true)

theorem identity51229 : scanCanonicalize (H12AffineFastState.compose env51229 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound51229 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51230 : List Nat := [2,4,8,16,32,16,0,44,19,23,49,43,24,57,43,27,43,56,22,42,43,32,3,10,16,3,48,56,56,43,45,59,45,58,42,18]

theorem envBound51230 : H12AffineFastState.Bounded env51230 := by
  intro p hp
  have h : env51230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51229_51230 : H12AffineEnvironment.transform 6 0 env51229 = env51230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env51229 == env51230) = true)

theorem identity51230 : scanCanonicalize (H12AffineFastState.compose env51230 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51230 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51231 : List Nat := [2,4,8,16,17,16,0,29,19,23,0,26,24,8,26,27,26,9,22,27,26,17,3,10,16,3,1,9,9,26,28,10,28,11,27,18]

theorem envBound51231 : H12AffineFastState.Bounded env51231 := by
  intro p hp
  have h : env51231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51230_51231 : H12AffineEnvironment.transform 4 17 env51230 = env51231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51230 == env51231) = true)

theorem identity51231 : scanCanonicalize (H12AffineFastState.compose env51231 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound51231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51232 : List Nat := [2,4,8,3,2,3,0,14,0,4,0,9,11,8,9,8,9,9,5,8,9,2,3,10,3,3,1,9,9,9,15,10,15,11,8,1]

theorem envBound51232 : H12AffineFastState.Bounded env51232 := by
  intro p hp
  have h : env51232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51231_51232 : H12AffineEnvironment.transform 3 3 env51231 = env51232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env51231 == env51232) = true)

theorem identity51232 : scanCanonicalize (H12AffineFastState.compose env51232 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51233 : List Nat := [2,4,7,3,2,3,0,1,0,4,0,6,4,7,6,7,6,6,5,7,6,2,3,5,3,3,1,6,6,6,0,5,0,4,7,1]

theorem envBound51233 : H12AffineFastState.Bounded env51233 := by
  intro p hp
  have h : env51233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51232_51233 : H12AffineEnvironment.transform 2 7 env51232 = env51233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51232 == env51233) = true)

theorem identity51233 : scanCanonicalize (H12AffineFastState.compose env51233 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51233 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51234 : List Nat := [2,0,3,3,2,3,0,1,0,0,0,2,0,3,2,3,2,2,1,3,2,2,3,1,3,3,1,2,2,2,0,1,0,0,3,1]

theorem envBound51234 : H12AffineFastState.Bounded env51234 := by
  intro p hp
  have h : env51234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51233_51234 : H12AffineEnvironment.transform 1 0 env51233 = env51234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51233 == env51234) = true)

theorem identity51234 : scanCanonicalize (H12AffineFastState.compose env51234 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51234 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51235 : List Nat := [1,0,0,0,1,0,0,1,0,0,0,1,0,0,1,0,1,1,1,0,1,1,0,1,0,0,1,1,1,1,0,1,0,0,0,1]

theorem envBound51235 : H12AffineFastState.Bounded env51235 := by
  intro p hp
  have h : env51235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51234_51235 : H12AffineEnvironment.transform 0 1 env51234 = env51235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51234 == env51235) = true)

def env51236 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143496,20497,508075,148668,148668,96266,90263,74799,173,204947,1212,135681]

theorem envBound51236 : H12AffineFastState.Bounded env51236 := by
  intro p hp
  have h : env51236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51218_51236 : H12AffineEnvironment.transform 5 17 env51218 = env51236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51218 == env51236) = true)

theorem identity51236 : scanCanonicalize (H12AffineFastState.compose env51236 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound51236 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51237 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,58519,32809,20497,356362,62493,62493,96266,90263,74799,173,102450,1212,41632]

theorem envBound51237 : H12AffineFastState.Bounded env51237 := by
  intro p hp
  have h : env51237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51236_51237 : H12AffineEnvironment.transform 16 45217 env51236 = env51237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env51236 == env51237) = true)

theorem identity51237 : scanCanonicalize (H12AffineFastState.compose env51237 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound51237 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51238 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4096,61568,61617,58519,32809,20497,96387,62493,62493,96266,90263,74799,173,102450,1212,41632]

theorem envBound51238 : H12AffineFastState.Bounded env51238 := by
  intro p hp
  have h : env51238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51237_51238 : H12AffineEnvironment.transform 17 2185 env51237 = env51238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env51237 == env51238) = true)

theorem identity51238 : scanCanonicalize (H12AffineFastState.compose env51238 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound51238 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51239 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,37019,45217,2185,42144,32769,4096,61568,61617,58519,32809,20497,59416,62493,62493,59537,61452,46260,173,169,1212,41632]

theorem envBound51239 : H12AffineFastState.Bounded env51239 := by
  intro p hp
  have h : env51239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51238_51239 : H12AffineEnvironment.transform 15 37019 env51238 = env51239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env51238 == env51239) = true)

theorem identity51239 : scanCanonicalize (H12AffineFastState.compose env51239 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound51239 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env51240 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,13374,5124,2185,5,9380,4096,21541,21524,16434,9356,20497,19645,20664,20664,19508,21673,4113,173,169,1212,1541]

theorem envBound51240 : H12AffineFastState.Bounded env51240 := by
  intro p hp
  have h : env51240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51239_51240 : H12AffineEnvironment.transform 14 9381 env51239 = env51240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env51239 == env51240) = true)

theorem identity51240 : scanCanonicalize (H12AffineFastState.compose env51240 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 1541) := by decide +kernel

theorem selectedBound51240 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env51241 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1541,9381,13374,5124,2185,5,9380,4096,4640,4625,1591,9356,5652,2744,5821,5821,2609,4780,4113,173,169,1212,1541]

theorem envBound51241 : H12AffineFastState.Bounded env51241 := by
  intro p hp
  have h : env51241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51240_51241 : H12AffineEnvironment.transform 13 1541 env51240 = env51241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1541 env51240 == env51241) = true)

theorem identity51241 : scanCanonicalize (H12AffineFastState.compose env51241 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound51241 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51242 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2194,8192,1541,9381,11436,3222,2185,5,9380,2194,2738,2691,1591,9356,3718,2744,3631,3631,2609,2622,2179,173,169,1212,1541]

theorem envBound51242 : H12AffineFastState.Bounded env51242 := by
  intro p hp
  have h : env51242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51241_51242 : H12AffineEnvironment.transform 11 2194 env51241 = env51242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env51241 == env51242) = true)

theorem identity51242 : scanCanonicalize (H12AffineFastState.compose env51242 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound51242 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env51243 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2194,2584,1541,3773,1716,3222,2185,5,3772,2194,2738,2691,1591,3732,3718,2744,3631,3631,2609,2622,2179,173,169,1212,1541]

theorem envBound51243 : H12AffineFastState.Bounded env51243 := by
  intro p hp
  have h : env51243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51242_51243 : H12AffineEnvironment.transform 12 2584 env51242 = env51243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env51242 == env51243) = true)

theorem identity51243 : scanCanonicalize (H12AffineFastState.compose env51243 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound51243 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env51244 : List Nat := [2,4,8,16,32,17,128,172,512,151,2048,2194,2584,658,2602,547,2049,2185,5,2603,2194,2738,2691,672,2563,2577,2744,2744,2744,2609,2622,2179,173,169,43,658]

theorem envBound51244 : H12AffineFastState.Bounded env51244 := by
  intro p hp
  have h : env51244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51243_51244 : H12AffineEnvironment.transform 9 151 env51243 = env51244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env51243 == env51244) = true)

theorem identity51244 : scanCanonicalize (H12AffineFastState.compose env51244 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound51244 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51245 : List Nat := [2,4,8,16,32,17,128,172,163,151,2048,2194,2235,49,2185,128,2049,2185,5,2184,2194,2065,2080,3,2208,2226,2075,2075,2075,2194,2205,2179,173,169,43,49]

theorem envBound51245 : H12AffineFastState.Bounded env51245 := by
  intro p hp
  have h : env51245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51244_51245 : H12AffineEnvironment.transform 8 163 env51244 = env51245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env51244 == env51245) = true)

theorem identity51245 : scanCanonicalize (H12AffineFastState.compose env51245 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound51245 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env51246 : List Nat := [2,4,8,16,32,17,128,172,163,151,147,1,40,49,26,128,146,26,5,27,1,130,179,3,51,33,136,136,136,1,14,16,173,169,43,49]

theorem envBound51246 : H12AffineFastState.Bounded env51246 := by
  intro p hp
  have h : env51246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51245_51246 : H12AffineEnvironment.transform 10 147 env51245 = env51246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env51245 == env51246) = true)

theorem identity51246 : scanCanonicalize (H12AffineFastState.compose env51246 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound51246 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env51247 : List Nat := [2,4,8,16,32,17,18,62,49,5,1,1,40,49,26,18,0,26,5,27,1,16,33,3,51,33,26,26,26,1,14,16,63,59,43,49]

theorem envBound51247 : H12AffineFastState.Bounded env51247 := by
  intro p hp
  have h : env51247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51246_51247 : H12AffineEnvironment.transform 6 18 env51246 = env51247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env51246 == env51247) = true)

theorem identity51247 : scanCanonicalize (H12AffineFastState.compose env51247 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51247 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51248 : List Nat := [2,4,8,16,10,17,18,20,27,5,1,1,2,27,26,18,0,26,5,27,1,16,11,3,25,11,26,26,26,1,14,16,21,17,1,27]

theorem envBound51248 : H12AffineFastState.Bounded env51248 := by
  intro p hp
  have h : env51248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51247_51248 : H12AffineEnvironment.transform 4 10 env51247 = env51248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51247 == env51248) = true)

theorem identity51248 : scanCanonicalize (H12AffineFastState.compose env51248 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51248 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51249 : List Nat := [2,4,8,10,10,11,8,14,1,5,1,1,2,1,0,8,0,0,5,1,1,10,11,3,3,11,0,0,0,1,14,10,15,11,1,1]

theorem envBound51249 : H12AffineFastState.Bounded env51249 := by
  intro p hp
  have h : env51249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51248_51249 : H12AffineEnvironment.transform 3 10 env51248 = env51249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51248 == env51249) = true)

theorem identity51249 : scanCanonicalize (H12AffineFastState.compose env51249 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51250 : List Nat := [2,2,8,10,10,11,8,8,1,3,1,1,2,1,0,8,0,0,3,1,1,10,11,3,3,11,0,0,0,1,8,10,9,11,1,1]

theorem envBound51250 : H12AffineFastState.Bounded env51250 := by
  intro p hp
  have h : env51250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51249_51250 : H12AffineEnvironment.transform 1 2 env51249 = env51250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51249 == env51250) = true)

def env51251 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143496,20497,508154,148716,148716,96347,90262,74799,172,204995,1260,135681]

theorem envBound51251 : H12AffineFastState.Bounded env51251 := by
  intro p hp
  have h : env51251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51217_51251 : H12AffineEnvironment.transform 7 173 env51217 = env51251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51217 == env51251) = true)

def env51252 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143496,20497,508074,148668,148668,96267,90262,74799,172,204947,1212,135681]

theorem envBound51252 : H12AffineFastState.Bounded env51252 := by
  intro p hp
  have h : env51252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51251_51252 : H12AffineEnvironment.transform 5 16 env51251 = env51252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51251 == env51252) = true)

theorem identity51252 : scanCanonicalize (H12AffineFastState.compose env51252 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound51252 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51253 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61569,147473,58518,143496,20497,60444,148668,148668,96267,90262,74799,172,204947,1212,135681]

theorem envBound51253 : H12AffineFastState.Bounded env51253 := by
  intro p hp
  have h : env51253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51252_51253 : H12AffineEnvironment.transform 17 208054 env51252 = env51253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env51252 == env51253) = true)

theorem identity51253 : scanCanonicalize (H12AffineFastState.compose env51253 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound51253 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env51254 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4096,61569,147473,58518,143496,20497,60444,148668,148668,43048,45237,62476,172,192688,1212,135681]

theorem envBound51254 : H12AffineFastState.Bounded env51254 := by
  intro p hp
  have h : env51254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51253_51254 : H12AffineEnvironment.transform 15 53283 env51253 = env51254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env51253 == env51254) = true)

theorem identity51254 : scanCanonicalize (H12AffineFastState.compose env51254 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound51254 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env51255 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4096,61569,5292,58518,25653,20497,60444,4097,4097,43048,45237,62476,172,41997,1212,18108]

theorem envBound51255 : H12AffineFastState.Bounded env51255 := by
  intro p hp
  have h : env51255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51254_51255 : H12AffineEnvironment.transform 16 21693 env51254 = env51255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env51254 == env51255) = true)

theorem identity51255 : scanCanonicalize (H12AffineFastState.compose env51255 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound51255 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env51256 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24600,12347,21693,18480,16572,24601,4096,4249,5292,1166,25653,20497,3076,4097,4097,18480,20653,5140,172,17429,1212,18108]

theorem envBound51256 : H12AffineFastState.Bounded env51256 := by
  intro p hp
  have h : env51256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51255_51256 : H12AffineEnvironment.transform 14 24600 env51255 = env51256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env51255 == env51256) = true)

theorem identity51256 : scanCanonicalize (H12AffineFastState.compose env51256 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound51256 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env51257 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1701,16384,18109,5790,21693,18480,16572,18108,4096,4249,5292,1166,17040,20497,3076,4097,4097,18480,20653,5140,172,17429,1212,18108]

theorem envBound51257 : H12AffineFastState.Bounded env51257 := by
  intro p hp
  have h : env51257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51256_51257 : H12AffineEnvironment.transform 12 1701 env51256 = env51257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env51256 == env51257) = true)

theorem identity51257 : scanCanonicalize (H12AffineFastState.compose env51257 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound51257 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env51258 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2090,1701,16384,18109,3764,19607,18480,16572,18108,2090,2227,3206,1166,17040,18491,3076,2091,2091,18480,18567,3134,172,17429,1212,18108]

theorem envBound51258 : H12AffineFastState.Bounded env51258 := by
  intro p hp
  have h : env51258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51257_51258 : H12AffineEnvironment.transform 11 2090 env51257 = env51258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env51257 == env51258) = true)

theorem identity51258 : scanCanonicalize (H12AffineFastState.compose env51258 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound51258 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env51259 : List Nat := [2,4,8,16,32,16,128,173,512,1024,162,136,1701,16384,18109,1558,17461,16530,16572,18108,136,17,1060,1166,17040,16537,1190,137,137,16530,16421,1180,172,17429,1212,18108]

theorem envBound51259 : H12AffineFastState.Bounded env51259 := by
  intro p hp
  have h : env51259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51258_51259 : H12AffineEnvironment.transform 10 162 env51258 = env51259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env51258 == env51259) = true)

theorem identity51259 : scanCanonicalize (H12AffineFastState.compose env51259 (packedSelected [0,2,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51259 : packedSelected [0,2,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51260 : List Nat := [2,4,8,16,10,16,128,135,512,1024,136,136,1679,16384,18071,1558,17439,16530,16534,18070,136,17,1038,1166,17040,16537,1164,137,137,16530,16399,1180,134,17429,1174,18070]

theorem envBound51260 : H12AffineFastState.Bounded env51260 := by
  intro p hp
  have h : env51260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51259_51260 : H12AffineEnvironment.transform 4 10 env51259 = env51260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51259 == env51260) = true)

theorem identity51260 : scanCanonicalize (H12AffineFastState.compose env51260 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1686) := by decide +kernel

theorem selectedBound51260 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51261 : List Nat := [2,4,8,16,10,16,128,135,512,1024,136,136,1679,1686,1,1558,649,1540,1536,0,136,17,1038,1166,1030,1551,1164,137,137,1540,1689,1180,134,643,1174,0]

theorem envBound51261 : H12AffineFastState.Bounded env51261 := by
  intro p hp
  have h : env51261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51260_51261 : H12AffineEnvironment.transform 13 1686 env51260 = env51261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1686 env51260 == env51261) = true)

theorem identity51261 : scanCanonicalize (H12AffineFastState.compose env51261 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound51261 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env51262 : List Nat := [2,4,8,16,10,16,128,135,147,1024,136,136,1052,1029,1,1157,26,1175,1171,0,136,17,1038,1166,1030,1180,1164,137,137,1175,1034,1180,134,16,1174,0]

theorem envBound51262 : H12AffineFastState.Bounded env51262 := by
  intro p hp
  have h : env51262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51261_51262 : H12AffineEnvironment.transform 8 147 env51261 = env51262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env51261 == env51262) = true)

theorem identity51262 : scanCanonicalize (H12AffineFastState.compose env51262 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound51262 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51263 : List Nat := [2,4,8,16,10,16,18,21,1,1024,26,26,1052,1029,1,1047,26,1029,1025,0,26,17,1038,1052,1030,1038,1054,27,27,1029,1034,1038,20,16,1028,0]

theorem envBound51263 : H12AffineFastState.Bounded env51263 := by
  intro p hp
  have h : env51263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51262_51263 : H12AffineEnvironment.transform 6 18 env51262 = env51263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env51262 == env51263) = true)

theorem identity51263 : scanCanonicalize (H12AffineFastState.compose env51263 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound51263 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env51264 : List Nat := [2,4,8,16,10,16,18,21,1,23,26,26,11,18,1,0,26,18,22,0,26,17,25,11,17,25,9,27,27,18,29,25,20,16,19,0]

theorem envBound51264 : H12AffineFastState.Bounded env51264 := by
  intro p hp
  have h : env51264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51263_51264 : H12AffineEnvironment.transform 9 23 env51263 = env51264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env51263 == env51264) = true)

theorem identity51264 : scanCanonicalize (H12AffineFastState.compose env51264 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51264 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51265 : List Nat := [2,4,8,0,10,0,2,5,1,7,10,10,11,2,1,0,10,2,6,0,10,1,9,11,1,9,9,11,11,2,13,9,4,0,3,0]

theorem envBound51265 : H12AffineFastState.Bounded env51265 := by
  intro p hp
  have h : env51265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51264_51265 : H12AffineEnvironment.transform 3 0 env51264 = env51265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51264 == env51265) = true)

theorem identity51265 : scanCanonicalize (H12AffineFastState.compose env51265 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51266 : List Nat := [2,4,7,0,5,0,2,5,1,7,5,5,4,2,1,0,5,2,6,0,5,1,6,4,1,6,6,4,4,2,2,6,4,0,3,0]

theorem envBound51266 : H12AffineFastState.Bounded env51266 := by
  intro p hp
  have h : env51266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51265_51266 : H12AffineEnvironment.transform 2 7 env51265 = env51266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51265 == env51266) = true)

def env51267 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143496,20497,508075,148669,148669,96266,90262,74799,172,204946,1213,135681]

theorem envBound51267 : H12AffineFastState.Bounded env51267 := by
  intro p hp
  have h : env51267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51251_51267 : H12AffineEnvironment.transform 5 17 env51251 = env51267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51251 == env51267) = true)

theorem identity51267 : scanCanonicalize (H12AffineFastState.compose env51267 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound51267 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51268 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61568,115855,58518,111639,20497,279604,114722,114722,96266,90262,74799,172,41997,1213,104094]

theorem envBound51268 : H12AffineFastState.Bounded env51268 := by
  intro p hp
  have h : env51268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51267_51268 : H12AffineEnvironment.transform 16 99487 env51267 = env51268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env51267 == env51268) = true)

theorem identity51268 : scanCanonicalize (H12AffineFastState.compose env51268 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound51268 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env51269 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,29830,61465,262144,58392,32769,4096,61568,45065,58518,49297,20497,279604,46244,46244,3212,5136,20649,172,41997,1213,57880]

theorem envBound51269 : H12AffineFastState.Bounded env51269 := by
  intro p hp
  have h : env51269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51268_51269 : H12AffineEnvironment.transform 15 29830 env51268 = env51269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env51268 == env51269) = true)

theorem identity51269 : scanCanonicalize (H12AffineFastState.compose env51269 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound51269 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51270 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24600,29830,4097,262144,1024,24601,4096,4248,20497,1166,8329,20497,279604,21692,21692,3212,5136,20649,172,17429,1213,512]

theorem envBound51270 : H12AffineFastState.Bounded env51270 := by
  intro p hp
  have h : env51270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51269_51270 : H12AffineEnvironment.transform 14 24600 env51269 = env51270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env51269 == env51270) = true)

theorem identity51270 : scanCanonicalize (H12AffineFastState.compose env51270 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound51270 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51271 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,9380,12346,4097,262144,1024,9381,4096,4248,5293,1166,8329,5293,262280,4096,4096,3212,5136,5141,172,169,1213,512]

theorem envBound51271 : H12AffineFastState.Bounded env51271 := by
  intro p hp
  have h : env51271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51270_51271 : H12AffineEnvironment.transform 13 1212 env51270 = env51271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env51270 == env51271) = true)

theorem identity51271 : scanCanonicalize (H12AffineFastState.compose env51271 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound51271 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51272 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5677,1212,4745,1559,4097,262144,1024,4744,4096,4248,5293,1166,5796,5293,262280,4096,4096,3212,5136,5141,172,169,1213,512]

theorem envBound51272 : H12AffineFastState.Bounded env51272 := by
  intro p hp
  have h : env51272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51271_51272 : H12AffineEnvironment.transform 12 5677 env51271 = env51272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env51271 == env51272) = true)

theorem identity51272 : scanCanonicalize (H12AffineFastState.compose env51272 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7221) := by decide +kernel

theorem selectedBound51272 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env51273 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5677,1212,4745,1559,4097,7221,1024,4744,4096,4248,5293,1166,5796,5293,7357,4096,4096,3212,5136,5141,172,169,1213,512]

theorem envBound51273 : H12AffineFastState.Bounded env51273 := by
  intro p hp
  have h : env51273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51272_51273 : H12AffineEnvironment.transform 17 7221 env51272 = env51273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7221 env51272 == env51273) = true)

theorem identity51273 : scanCanonicalize (H12AffineFastState.compose env51273 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3614) := by decide +kernel

theorem selectedBound51273 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51274 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3614,2099,1212,3223,1559,3615,555,1024,3222,3614,3718,2739,1166,2234,2739,675,3614,3614,3212,2574,2571,172,169,1213,512]

theorem envBound51274 : H12AffineFastState.Bounded env51274 := by
  intro p hp
  have h : env51274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51273_51274 : H12AffineEnvironment.transform 11 3614 env51273 = env51274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3614 env51273 == env51274) = true)

theorem identity51274 : scanCanonicalize (H12AffineFastState.compose env51274 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound51274 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env51275 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2587,2099,185,2194,530,2586,555,5,2195,2587,2691,2739,139,2234,2739,675,2587,2587,2185,2574,2571,172,169,184,512]

theorem envBound51275 : H12AffineFastState.Bounded env51275 := by
  intro p hp
  have h : env51275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51274_51275 : H12AffineEnvironment.transform 9 5 env51274 = env51275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env51274 == env51275) = true)

theorem identity51275 : scanCanonicalize (H12AffineFastState.compose env51275 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound51275 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51276 : List Nat := [2,4,8,16,32,17,128,173,512,5,48,555,3,185,162,530,554,555,5,163,555,691,643,139,138,643,675,555,555,185,574,571,172,169,184,512]

theorem envBound51276 : H12AffineFastState.Bounded env51276 := by
  intro p hp
  have h : env51276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51275_51276 : H12AffineEnvironment.transform 10 48 env51275 = env51276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env51275 == env51276) = true)

theorem identity51276 : scanCanonicalize (H12AffineFastState.compose env51276 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51276 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51277 : List Nat := [2,4,8,16,32,17,8,37,512,5,48,555,3,49,42,530,554,555,5,43,555,571,523,3,2,523,555,555,555,49,574,571,36,33,48,512]

theorem envBound51277 : H12AffineFastState.Bounded env51277 := by
  intro p hp
  have h : env51277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51276_51277 : H12AffineEnvironment.transform 6 8 env51276 = env51277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51276 == env51277) = true)

theorem identity51277 : scanCanonicalize (H12AffineFastState.compose env51277 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound51277 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51278 : List Nat := [2,4,8,16,32,17,8,37,54,5,48,29,3,49,42,36,28,29,5,43,29,13,61,3,2,61,29,29,29,49,8,13,36,33,48,54]

theorem envBound51278 : H12AffineFastState.Bounded env51278 := by
  intro p hp
  have h : env51278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51277_51278 : H12AffineEnvironment.transform 8 54 env51277 = env51278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env51277 == env51278) = true)

theorem identity51278 : scanCanonicalize (H12AffineFastState.compose env51278 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound51278 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env51279 : List Nat := [2,4,8,16,12,17,8,9,26,5,28,29,3,29,6,8,28,29,5,7,29,13,17,3,2,17,29,29,29,29,8,13,8,13,28,26]

theorem envBound51279 : H12AffineFastState.Bounded env51279 := by
  intro p hp
  have h : env51279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51278_51279 : H12AffineEnvironment.transform 4 12 env51278 = env51279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env51278 == env51279) = true)

theorem identity51279 : scanCanonicalize (H12AffineFastState.compose env51279 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51280 : List Nat := [2,2,8,16,10,17,8,9,26,3,26,27,3,27,0,8,26,27,3,1,27,11,17,3,2,17,27,27,27,27,8,11,8,11,26,26]

theorem envBound51280 : H12AffineFastState.Bounded env51280 := by
  intro p hp
  have h : env51280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51279_51280 : H12AffineEnvironment.transform 1 2 env51279 = env51280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51279 == env51280) = true)

theorem identity51280 : scanCanonicalize (H12AffineFastState.compose env51280 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51280 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51281 : List Nat := [2,2,8,10,10,11,8,9,0,3,0,1,3,1,0,8,0,1,3,1,1,11,11,3,2,11,1,1,1,1,8,11,8,11,0,0]

theorem envBound51281 : H12AffineFastState.Bounded env51281 := by
  intro p hp
  have h : env51281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51280_51281 : H12AffineEnvironment.transform 3 10 env51280 = env51281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51280 == env51281) = true)

def env51282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148801,33584585,96346,50962569,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound51282 : H12AffineFastState.Bounded env51282 := by
  intro p hp
  have h : env51282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50120_51282 : H12AffineEnvironment.transform 20 4097 env50120 = env51282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env50120 == env51282) = true)

theorem identity51282 : scanCanonicalize (H12AffineFastState.compose env51282 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 185344039) := by decide +kernel

theorem selectedBound51282 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env51283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148801,33584585,96346,50962569,185344039,34088328,135065812,151462016,33563273]

theorem envBound51283 : H12AffineFastState.Bounded env51283 := by
  intro p hp
  have h : env51283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51282_51283 : H12AffineEnvironment.transform 31 185344039 env51282 = env51283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185344039 env51282 == env51283) = true)

def env51284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,134217728,148801,545089,96346,16876545,151258287,256,135065812,151462016,525825]

theorem envBound51284 : H12AffineFastState.Bounded env51284 := by
  intro p hp
  have h : env51284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51283_51284 : H12AffineEnvironment.transform 24 533640 env51283 = env51284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env51283 == env51284) = true)

def env51285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245632,148801,545089,96346,16876545,205167,256,17552660,1344,525825]

theorem envBound51285 : H12AffineFastState.Bounded env51285 := by
  intro p hp
  have h : env51285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51284_51285 : H12AffineEnvironment.transform 26 17245632 env51284 = env51285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env51284 == env51285) = true)

theorem identity51285 : scanCanonicalize (H12AffineFastState.compose env51285 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound51285 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,16777216,533640,614526,17039790,90415,545089,96346,16876545,1281,256,17363322,1344,525825]

theorem envBound51286 : H12AffineFastState.Bounded env51286 := by
  intro p hp
  have h : env51286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51285_51286 : H12AffineEnvironment.transform 16 74862 env51285 = env51286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env51285 == env51286) = true)

def env51287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123164,533640,614526,385202,90415,545089,96346,25885,1281,256,594022,1344,525825]

theorem envBound51287 : H12AffineFastState.Bounded env51287 := by
  intro p hp
  have h : env51287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51286_51287 : H12AffineEnvironment.transform 23 123164 env51286 = env51287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env51286 == env51287) = true)

def env51288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123164,28888,78894,385202,90415,1297,96346,25885,1281,256,82998,1344,21073]

theorem envBound51288 : H12AffineFastState.Bounded env51288 := by
  intro p hp
  have h : env51288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51287_51288 : H12AffineEnvironment.transform 18 21584 env51287 = env51288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env51287 == env51288) = true)

theorem identity51288 : scanCanonicalize (H12AffineFastState.compose env51288 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound51288 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env51289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4097,5277,91183,66897,28888,78894,328959,90415,1297,96346,25885,1281,256,82998,1344,21073]

theorem envBound51289 : H12AffineFastState.Bounded env51289 := by
  intro p hp
  have h : env51289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51288_51289 : H12AffineEnvironment.transform 14 25677 env51288 = env51289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env51288 == env51289) = true)

def env51290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4097,5277,74047,66897,13768,78894,328959,74815,1297,81226,8205,1281,256,65830,1344,5953]

theorem envBound51290 : H12AffineFastState.Bounded env51290 := by
  intro p hp
  have h : env51290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51289_51290 : H12AffineEnvironment.transform 13 1296 env51289 = env51290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env51289 == env51290) = true)

def env51291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4097,5277,74047,66897,13768,78894,1151,74815,1297,81226,8205,1281,256,65830,1344,5953]

theorem envBound51291 : H12AffineFastState.Bounded env51291 := by
  intro p hp
  have h : env51291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51290_51291 : H12AffineEnvironment.transform 17 65664 env51290 = env51291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51290 == env51291) = true)

theorem identity51291 : scanCanonicalize (H12AffineFastState.compose env51291 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound51291 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,311,9561,439,4416,8540,4097,5277,8200,1126,13768,13593,1151,9480,1297,15485,8205,1281,256,17,1344,5953]

theorem envBound51292 : H12AffineFastState.Bounded env51292 := by
  intro p hp
  have h : env51292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51291_51292 : H12AffineEnvironment.transform 15 311 env51291 = env51292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env51291 == env51292) = true)

def env51293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,311,1345,439,4416,324,4097,5277,16,1126,5584,5377,1151,1296,1297,7269,21,1281,256,17,1344,5953]

theorem envBound51293 : H12AffineFastState.Bounded env51293 := by
  intro p hp
  have h : env51293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51292_51293 : H12AffineEnvironment.transform 12 24 env51292 = env51293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env51292 == env51293) = true)

theorem identity51293 : scanCanonicalize (H12AffineFastState.compose env51293 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51293 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51294 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,24,1029,80,34,1108,162,4181,81,4097,5277,16,1126,5317,5140,1151,1029,1028,7269,21,1044,21,17,1109,5716]

theorem envBound51294 : H12AffineFastState.Bounded env51294 := by
  intro p hp
  have h : env51294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51293_51294 : H12AffineEnvironment.transform 7 21 env51293 = env51294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51293 == env51294) = true)

theorem identity51294 : scanCanonicalize (H12AffineFastState.compose env51294 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound51294 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51295 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,24,1029,80,34,1108,162,1025,81,1109,201,16,1126,145,64,1151,1029,1028,2097,21,1044,21,17,1109,512]

theorem envBound51295 : H12AffineFastState.Bounded env51295 := by
  intro p hp
  have h : env51295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51294_51295 : H12AffineEnvironment.transform 11 1108 env51294 = env51295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env51294 == env51295) = true)

theorem identity51295 : scanCanonicalize (H12AffineFastState.compose env51295 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51295 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51296 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,24,1029,0,34,1028,162,1025,1,1029,153,16,1078,145,16,1071,1029,1028,2097,21,1044,21,17,1029,512]

theorem envBound51296 : H12AffineFastState.Bounded env51296 := by
  intro p hp
  have h : env51296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51295_51296 : H12AffineEnvironment.transform 5 16 env51295 = env51296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51295 == env51296) = true)

theorem identity51296 : scanCanonicalize (H12AffineFastState.compose env51296 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound51296 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51297 : List Nat := [2,4,8,16,32,16,18,21,512,1024,2048,1028,24,1029,0,34,1028,48,1025,1,1029,11,16,1078,3,16,1071,1029,1028,2097,21,1044,21,17,1029,512]

theorem envBound51297 : H12AffineFastState.Bounded env51297 := by
  intro p hp
  have h : env51297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51296_51297 : H12AffineEnvironment.transform 6 18 env51296 = env51297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env51296 == env51297) = true)

theorem identity51297 : scanCanonicalize (H12AffineFastState.compose env51297 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound51297 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51298 : List Nat := [2,4,8,16,32,16,18,21,512,542,2048,538,24,539,0,34,538,48,543,1,539,11,16,552,3,16,561,539,538,2097,21,522,21,17,539,512]

theorem envBound51298 : H12AffineFastState.Bounded env51298 := by
  intro p hp
  have h : env51298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51297_51298 : H12AffineEnvironment.transform 9 542 env51297 = env51298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env51297 == env51298) = true)

theorem identity51298 : scanCanonicalize (H12AffineFastState.compose env51298 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound51298 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51299 : List Nat := [2,4,8,16,32,16,18,21,512,542,554,538,24,539,0,34,538,48,543,1,539,11,16,552,3,16,561,539,538,539,21,522,21,17,539,512]

theorem envBound51299 : H12AffineFastState.Bounded env51299 := by
  intro p hp
  have h : env51299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51298_51299 : H12AffineEnvironment.transform 10 554 env51298 = env51299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env51298 == env51299) = true)

theorem identity51299 : scanCanonicalize (H12AffineFastState.compose env51299 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51299 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env51300 : List Nat := [2,4,8,16,32,16,18,21,1,31,43,27,24,26,0,34,27,48,30,1,26,11,16,41,3,16,48,26,27,26,21,11,21,17,26,1]

theorem envBound51300 : H12AffineFastState.Bounded env51300 := by
  intro p hp
  have h : env51300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51299_51300 : H12AffineEnvironment.transform 8 1 env51299 = env51300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51299 == env51300) = true)

def env51301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,311,1344,439,4416,325,4097,5277,17,1126,5585,5376,1151,1297,1297,7268,20,1281,256,17,1344,5953]

theorem envBound51301 : H12AffineFastState.Bounded env51301 := by
  intro p hp
  have h : env51301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51292_51301 : H12AffineEnvironment.transform 12 25 env51292 = env51301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env51292 == env51301) = true)

theorem identity51301 : scanCanonicalize (H12AffineFastState.compose env51301 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound51301 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51302 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,25,81,324,311,1,439,4416,325,4097,4572,17,295,4240,4161,318,80,80,6437,20,64,256,17,1,4608]

theorem envBound51302 : H12AffineFastState.Bounded env51302 := by
  intro p hp
  have h : env51302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51301_51302 : H12AffineEnvironment.transform 9 321 env51301 = env51302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env51301 == env51302) = true)

theorem identity51302 : scanCanonicalize (H12AffineFastState.compose env51302 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound51302 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env51303 : List Nat := [2,4,8,16,32,64,128,256,512,321,950,4096,25,81,324,311,1,439,4416,325,4097,4572,17,295,4240,4161,318,80,80,4755,20,64,256,17,1,4608]

theorem envBound51303 : H12AffineFastState.Bounded env51303 := by
  intro p hp
  have h : env51303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51302_51303 : H12AffineEnvironment.transform 10 950 env51302 = env51303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env51302 == env51303) = true)

theorem identity51303 : scanCanonicalize (H12AffineFastState.compose env51303 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound51303 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env51304 : List Nat := [2,4,8,16,32,64,128,256,512,321,950,649,25,81,324,311,1,439,969,325,648,853,17,295,537,712,318,80,80,26,20,64,256,17,1,137]

theorem envBound51304 : H12AffineFastState.Bounded env51304 := by
  intro p hp
  have h : env51304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51303_51304 : H12AffineEnvironment.transform 11 649 env51303 = env51304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env51303 == env51304) = true)

theorem identity51304 : scanCanonicalize (H12AffineFastState.compose env51304 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound51304 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env51305 : List Nat := [2,4,8,16,32,64,128,68,512,5,754,649,25,81,0,115,1,243,653,1,648,529,17,99,537,712,122,80,80,26,20,64,68,17,1,137]

theorem envBound51305 : H12AffineFastState.Bounded env51305 := by
  intro p hp
  have h : env51305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51304_51305 : H12AffineEnvironment.transform 7 68 env51304 = env51305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env51304 == env51305) = true)

theorem identity51305 : scanCanonicalize (H12AffineFastState.compose env51305 (packedSelected [0,1,2,3,4,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound51305 : packedSelected [0,1,2,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env51306 : List Nat := [2,4,8,16,32,64,57,68,512,5,587,560,25,81,0,115,1,74,564,1,561,529,17,99,537,625,122,80,80,26,20,64,68,17,1,48]

theorem envBound51306 : H12AffineFastState.Bounded env51306 := by
  intro p hp
  have h : env51306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51305_51306 : H12AffineEnvironment.transform 6 57 env51305 = env51306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env51305 == env51306) = true)

theorem identity51306 : scanCanonicalize (H12AffineFastState.compose env51306 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51306 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env51307 : List Nat := [2,4,8,16,10,64,19,68,512,5,587,538,25,81,0,89,1,74,542,1,539,529,17,73,537,603,80,80,80,26,20,64,68,17,1,26]

theorem envBound51307 : H12AffineFastState.Bounded env51307 := by
  intro p hp
  have h : env51307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51306_51307 : H12AffineEnvironment.transform 4 10 env51306 = env51307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51306 == env51307) = true)

theorem identity51307 : scanCanonicalize (H12AffineFastState.compose env51307 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51307 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51308 : List Nat := [2,4,8,11,10,64,8,68,512,5,587,513,2,74,0,66,1,74,517,1,512,522,10,73,514,576,75,75,75,1,15,64,68,10,1,1]

theorem envBound51308 : H12AffineFastState.Bounded env51308 := by
  intro p hp
  have h : env51308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51307_51308 : H12AffineEnvironment.transform 3 11 env51307 = env51308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51307 == env51308) = true)

theorem identity51308 : scanCanonicalize (H12AffineFastState.compose env51308 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound51308 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51309 : List Nat := [2,4,8,11,10,64,8,68,74,5,1,75,2,74,0,66,1,74,79,1,74,64,10,73,72,10,75,75,75,1,15,64,68,10,1,1]

theorem envBound51309 : H12AffineFastState.Bounded env51309 := by
  intro p hp
  have h : env51309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51308_51309 : H12AffineEnvironment.transform 8 74 env51308 = env51309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env51308 == env51309) = true)

theorem identity51309 : scanCanonicalize (H12AffineFastState.compose env51309 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51309 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env51310 : List Nat := [2,3,8,11,10,64,8,67,74,2,1,75,2,74,0,66,1,74,72,1,74,64,10,73,72,10,75,75,75,1,8,64,67,10,1,1]

theorem envBound51310 : H12AffineFastState.Bounded env51310 := by
  intro p hp
  have h : env51310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51309_51310 : H12AffineEnvironment.transform 1 3 env51309 = env51310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51309 == env51310) = true)

def env51311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4097,5277,74047,66897,13768,78894,1150,74815,1297,81226,8205,1281,256,65830,1344,5953]

theorem envBound51311 : H12AffineFastState.Bounded env51311 := by
  intro p hp
  have h : env51311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51290_51311 : H12AffineEnvironment.transform 17 65665 env51290 = env51311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51290 == env51311) = true)

theorem identity51311 : scanCanonicalize (H12AffineFastState.compose env51311 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound51311 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5239,12313,5366,4416,8540,4097,5277,13640,4390,13768,8281,1150,12360,1297,10557,8205,1281,256,5457,1344,5953]

theorem envBound51312 : H12AffineFastState.Bounded env51312 := by
  intro p hp
  have h : env51312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51311_51312 : H12AffineEnvironment.transform 15 5239 env51311 = env51312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env51311 == env51312) = true)

def env51313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5239,1345,5366,4416,5124,4097,5277,16,4390,144,5377,1150,1296,1297,7269,5461,1281,256,5457,1344,5953]

theorem envBound51313 : H12AffineFastState.Bounded env51313 := by
  intro p hp
  have h : env51313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51312_51313 : H12AffineEnvironment.transform 12 5464 env51312 = env51313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env51312 == env51313) = true)

theorem identity51313 : scanCanonicalize (H12AffineFastState.compose env51313 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound51313 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1109,269,1296,80,34,1345,163,1301,81,1108,200,16,1395,144,340,1150,1296,1297,2096,256,1281,256,260,1344,788]

theorem envBound51314 : H12AffineFastState.Bounded env51314 := by
  intro p hp
  have h : env51314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51313_51314 : H12AffineEnvironment.transform 11 1109 env51313 = env51314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env51313 == env51314) = true)

theorem identity51314 : scanCanonicalize (H12AffineFastState.compose env51314 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51314 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51315 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,25,1028,80,34,1109,163,1025,81,1108,200,16,1127,144,64,1150,1028,1029,2096,20,1045,20,16,1108,512]

theorem envBound51315 : H12AffineFastState.Bounded env51315 := by
  intro p hp
  have h : env51315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51314_51315 : H12AffineEnvironment.transform 7 20 env51314 = env51315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51314 == env51315) = true)

theorem identity51315 : scanCanonicalize (H12AffineFastState.compose env51315 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51315 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51316 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,25,1028,0,34,1029,163,1025,1,1028,152,16,1079,144,16,1070,1028,1029,2096,20,1045,20,16,1028,512]

theorem envBound51316 : H12AffineFastState.Bounded env51316 := by
  intro p hp
  have h : env51316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51315_51316 : H12AffineEnvironment.transform 5 16 env51315 = env51316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51315 == env51316) = true)

theorem identity51316 : scanCanonicalize (H12AffineFastState.compose env51316 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound51316 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51317 : List Nat := [2,4,8,16,32,16,128,20,512,46,2048,43,25,42,0,34,43,163,47,1,42,152,16,25,144,16,0,42,43,2096,20,59,20,16,42,512]

theorem envBound51317 : H12AffineFastState.Bounded env51317 := by
  intro p hp
  have h : env51317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51316_51317 : H12AffineEnvironment.transform 9 46 env51316 = env51317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env51316 == env51317) = true)

theorem identity51317 : scanCanonicalize (H12AffineFastState.compose env51317 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound51317 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51318 : List Nat := [2,4,8,16,32,16,128,20,163,46,2048,43,25,42,0,34,43,163,47,1,42,152,16,25,144,16,0,42,43,2096,20,59,20,16,42,163]

theorem envBound51318 : H12AffineFastState.Bounded env51318 := by
  intro p hp
  have h : env51318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51317_51318 : H12AffineEnvironment.transform 8 163 env51317 = env51318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env51317 == env51318) = true)

theorem identity51318 : scanCanonicalize (H12AffineFastState.compose env51318 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound51318 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env51319 : List Nat := [2,4,8,16,32,16,19,20,48,46,2048,43,25,42,0,34,43,48,47,1,42,11,16,25,3,16,0,42,43,2096,20,59,20,16,42,48]

theorem envBound51319 : H12AffineFastState.Bounded env51319 := by
  intro p hp
  have h : env51319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51318_51319 : H12AffineEnvironment.transform 6 19 env51318 = env51319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env51318 == env51319) = true)

theorem identity51319 : scanCanonicalize (H12AffineFastState.compose env51319 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound51319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51320 : List Nat := [2,4,8,16,32,16,19,20,48,46,42,43,25,42,0,34,43,48,47,1,42,11,16,25,3,16,0,42,43,26,20,59,20,16,42,48]

theorem envBound51320 : H12AffineFastState.Bounded env51320 := by
  intro p hp
  have h : env51320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51319_51320 : H12AffineEnvironment.transform 10 42 env51319 = env51320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env51319 == env51320) = true)

theorem identity51320 : scanCanonicalize (H12AffineFastState.compose env51320 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51320 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51321 : List Nat := [2,4,8,16,11,16,19,20,27,5,1,0,25,1,0,9,0,27,4,1,1,11,16,25,3,16,0,1,0,26,20,16,20,16,1,27]

theorem envBound51321 : H12AffineFastState.Bounded env51321 := by
  intro p hp
  have h : env51321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51320_51321 : H12AffineEnvironment.transform 4 11 env51320 = env51321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51320 == env51321) = true)

theorem identity51321 : scanCanonicalize (H12AffineFastState.compose env51321 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51322 : List Nat := [2,4,8,7,11,7,4,3,12,5,1,0,14,1,0,9,0,12,4,1,1,11,7,14,3,7,0,1,0,13,3,7,3,7,1,12]

theorem envBound51322 : H12AffineFastState.Bounded env51322 := by
  intro p hp
  have h : env51322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51321_51322 : H12AffineEnvironment.transform 3 7 env51321 = env51322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51321 == env51322) = true)

theorem identity51322 : scanCanonicalize (H12AffineFastState.compose env51322 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51323 : List Nat := [2,4,5,7,6,7,4,3,1,5,1,0,3,1,0,4,0,1,4,1,1,6,7,3,3,7,0,1,0,0,3,7,3,7,1,1]

theorem envBound51323 : H12AffineFastState.Bounded env51323 := by
  intro p hp
  have h : env51323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51322_51323 : H12AffineEnvironment.transform 2 5 env51322 = env51323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51322 == env51323) = true)

def env51324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5239,1344,5366,4416,5125,4097,5277,17,4390,145,5376,1150,1297,1297,7268,5460,1281,256,5457,1344,5953]

theorem envBound51324 : H12AffineFastState.Bounded env51324 := by
  intro p hp
  have h : env51324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51312_51324 : H12AffineEnvironment.transform 12 5465 env51312 = env51324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env51312 == env51324) = true)

theorem identity51324 : scanCanonicalize (H12AffineFastState.compose env51324 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51324 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1296,1029,1142,1344,1271,321,1028,0,1180,17,295,145,1281,1150,1297,1297,3173,1365,1281,256,1360,1344,1856]

theorem envBound51325 : H12AffineFastState.Bounded env51325 := by
  intro p hp
  have h : env51325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51324_51325 : H12AffineEnvironment.transform 11 1 env51324 = env51325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51324 == env51325) = true)

theorem identity51325 : scanCanonicalize (H12AffineFastState.compose env51325 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound51325 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env51326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1,1368,1296,1029,1142,1344,1271,321,1028,0,1180,17,295,145,1281,1150,1297,1297,659,1365,1281,256,1360,1344,1856]

theorem envBound51326 : H12AffineFastState.Bounded env51326 := by
  intro p hp
  have h : env51326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51325_51326 : H12AffineEnvironment.transform 10 1782 env51325 = env51326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env51325 == env51326) = true)

theorem identity51326 : scanCanonicalize (H12AffineFastState.compose env51326 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound51326 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env51327 : List Nat := [2,4,8,16,32,64,128,256,512,968,318,1,656,728,973,958,648,831,321,972,0,852,17,295,145,713,950,729,729,659,669,713,256,664,648,136]

theorem envBound51327 : H12AffineFastState.Bounded env51327 := by
  intro p hp
  have h : env51327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51326_51327 : H12AffineEnvironment.transform 9 968 env51326 = env51327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env51326 == env51327) = true)

theorem identity51327 : scanCanonicalize (H12AffineFastState.compose env51327 (packedSelected [3,8,11,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51327 : packedSelected [3,8,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env51328 : List Nat := [2,4,8,16,32,17,128,256,512,921,318,1,656,649,924,958,648,831,272,925,0,773,17,295,145,664,950,648,648,659,669,664,256,664,648,136]

theorem envBound51328 : H12AffineFastState.Bounded env51328 := by
  intro p hp
  have h : env51328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51327_51328 : H12AffineEnvironment.transform 5 17 env51327 = env51328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51327 == env51328) = true)

theorem identity51328 : scanCanonicalize (H12AffineFastState.compose env51328 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51328 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51329 : List Nat := [2,4,8,16,32,17,128,20,512,653,42,1,656,649,648,682,648,555,4,649,0,529,17,51,145,664,674,648,648,659,669,664,20,664,648,136]

theorem envBound51329 : H12AffineFastState.Bounded env51329 := by
  intro p hp
  have h : env51329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51328_51329 : H12AffineEnvironment.transform 7 20 env51328 = env51329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51328 == env51329) = true)

theorem identity51329 : scanCanonicalize (H12AffineFastState.compose env51329 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound51329 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51330 : List Nat := [2,4,8,16,32,17,128,20,180,57,42,1,36,61,60,30,60,159,4,61,0,165,17,51,145,44,22,60,60,39,41,44,20,44,60,136]

theorem envBound51330 : H12AffineFastState.Bounded env51330 := by
  intro p hp
  have h : env51330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51329_51330 : H12AffineEnvironment.transform 8 180 env51329 = env51330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env51329 == env51330) = true)

def env51331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4097,5277,74046,66897,13769,78894,328959,74814,1297,81227,8204,1281,256,65831,1344,5952]

theorem envBound51331 : H12AffineFastState.Bounded env51331 := by
  intro p hp
  have h : env51331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51289_51331 : H12AffineEnvironment.transform 13 1297 env51289 = env51331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env51289 == env51331) = true)

def env51332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4097,5277,74046,66897,13769,78894,1151,74814,1297,81227,8204,1281,256,65831,1344,5952]

theorem envBound51332 : H12AffineFastState.Bounded env51332 := by
  intro p hp
  have h : env51332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51331_51332 : H12AffineEnvironment.transform 17 65664 env51331 = env51332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51331 == env51332) = true)

theorem identity51332 : scanCanonicalize (H12AffineFastState.compose env51332 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound51332 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12671,5393,12799,4417,8541,4097,5277,4161,13358,13769,1361,1151,5441,1297,3124,8204,1281,256,12376,1344,5952]

theorem envBound51333 : H12AffineFastState.Bounded env51333 := by
  intro p hp
  have h : env51333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51332_51333 : H12AffineEnvironment.transform 15 12671 env51332 = env51333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env51332 == env51333) = true)

def env51334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8495,1345,8623,273,8541,81,1229,17,9342,9625,1361,1151,1297,1297,3124,8204,1281,256,8200,1344,1808]

theorem envBound51334 : H12AffineFastState.Bounded env51334 := by
  intro p hp
  have h : env51334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2