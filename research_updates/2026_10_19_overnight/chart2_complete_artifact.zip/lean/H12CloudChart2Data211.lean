import H12CloudChart2Data210

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound53143 : H12AffineFastState.Bounded env53143 := by
  intro p hp
  have h : env53143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53142_53143 : H12AffineEnvironment.transform 2 1 env53142 = env53143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53142 == env53143) = true)

theorem identity53143 : scanCanonicalize (H12AffineFastState.compose env53143 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53143 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env53144 : List Nat := [2,2,1,1,0,2,128,2,128,0,3,1,0,2,2,3,1,131,0,3,1,131,0,2,129,2,2,2,2,2,2,2,2,1,0,129]

theorem envBound53144 : H12AffineFastState.Bounded env53144 := by
  intro p hp
  have h : env53144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53143_53144 : H12AffineEnvironment.transform 4 0 env53143 = env53144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53143 == env53144) = true)

theorem identity53144 : scanCanonicalize (H12AffineFastState.compose env53144 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound53144 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53145 : List Nat := [2,2,1,1,0,2,1,2,1,0,3,1,0,2,2,3,1,2,0,3,1,2,0,2,0,2,2,2,2,2,2,2,2,1,0,0]

theorem envBound53145 : H12AffineFastState.Bounded env53145 := by
  intro p hp
  have h : env53145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53144_53145 : H12AffineEnvironment.transform 6 1 env53144 = env53145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env53144 == env53145) = true)

theorem identity53145 : scanCanonicalize (H12AffineFastState.compose env53145 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53145 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53146 : List Nat := [1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,0,1,1,0,1,0,1,1,1,1,1,1,1,1,1,0,0]

theorem envBound53146 : H12AffineFastState.Bounded env53146 := by
  intro p hp
  have h : env53146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53145_53146 : H12AffineEnvironment.transform 0 1 env53145 = env53146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53145 == env53146) = true)

def env53147 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8540,65536,74030,65664,320,8541,1,476,74047,65553,8329,74095,319,74110,80,75786,8205,65,256,65830,1,512]

theorem envBound53147 : H12AffineFastState.Bounded env53147 := by
  intro p hp
  have h : env53147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53133_53147 : H12AffineEnvironment.transform 9 321 env53133 = env53147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53133 == env53147) = true)

theorem identity53147 : scanCanonicalize (H12AffineFastState.compose env53147 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53147 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53148 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,349,80,1,65536,65651,65664,320,0,1,476,65634,65553,468,65586,319,65571,80,67927,336,65,256,65830,1,512]

theorem envBound53148 : H12AffineFastState.Bounded env53148 := by
  intro p hp
  have h : env53148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53147_53148 : H12AffineEnvironment.transform 12 349 env53147 = env53148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53147 == env53148) = true)

theorem identity53148 : scanCanonicalize (H12AffineFastState.compose env53148 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53148 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53149 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,269,0,1,65536,65571,65664,272,0,1,396,65586,65553,388,65586,319,65571,0,67847,256,17,256,65830,1,512]

theorem envBound53149 : H12AffineFastState.Bounded env53149 := by
  intro p hp
  have h : env53149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53148_53149 : H12AffineEnvironment.transform 5 16 env53148 = env53149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53148 == env53149) = true)

theorem identity53149 : scanCanonicalize (H12AffineFastState.compose env53149 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound53149 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53150 : List Nat := [2,4,8,16,32,16,128,256,512,273,163,1,269,0,1,65536,65571,65664,272,0,1,396,65586,65553,388,65586,319,65571,0,65956,256,17,256,65830,1,512]

theorem envBound53150 : H12AffineFastState.Bounded env53150 := by
  intro p hp
  have h : env53150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53149_53150 : H12AffineEnvironment.transform 10 163 env53149 = env53150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env53149 == env53150) = true)

theorem identity53150 : scanCanonicalize (H12AffineFastState.compose env53150 (packedSelected [0,2,3,5,7,10,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 404) := by decide +kernel

theorem selectedBound53150 : packedSelected [0,2,3,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env53151 : List Nat := [2,4,8,16,32,16,128,256,512,273,163,1,269,0,1,404,439,276,272,0,1,396,422,389,388,422,319,439,0,48,256,17,256,178,1,512]

theorem envBound53151 : H12AffineFastState.Bounded env53151 := by
  intro p hp
  have h : env53151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53150_53151 : H12AffineEnvironment.transform 15 404 env53150 = env53151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 404 env53150 == env53151) = true)

theorem identity53151 : scanCanonicalize (H12AffineFastState.compose env53151 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound53151 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env53152 : List Nat := [2,4,8,16,32,16,35,256,512,273,0,1,269,0,1,311,276,276,272,0,1,303,261,294,295,261,319,276,0,48,256,17,256,17,1,512]

theorem envBound53152 : H12AffineFastState.Bounded env53152 := by
  intro p hp
  have h : env53152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53151_53152 : H12AffineEnvironment.transform 6 35 env53151 = env53152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env53151 == env53152) = true)

theorem identity53152 : scanCanonicalize (H12AffineFastState.compose env53152 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound53152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53153 : List Nat := [2,4,8,16,32,16,35,24,512,9,0,1,21,0,1,47,12,12,8,0,1,55,29,62,63,29,39,12,0,48,24,17,24,17,1,512]

theorem envBound53153 : H12AffineFastState.Bounded env53153 := by
  intro p hp
  have h : env53153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53152_53153 : H12AffineEnvironment.transform 7 24 env53152 = env53153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env53152 == env53153) = true)

theorem identity53153 : scanCanonicalize (H12AffineFastState.compose env53153 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound53153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53154 : List Nat := [2,4,8,16,32,16,35,24,22,9,0,1,21,0,1,47,12,12,8,0,1,55,29,62,63,29,39,12,0,48,24,17,24,17,1,22]

theorem envBound53154 : H12AffineFastState.Bounded env53154 := by
  intro p hp
  have h : env53154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53153_53154 : H12AffineEnvironment.transform 8 22 env53153 = env53154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env53153 == env53154) = true)

theorem identity53154 : scanCanonicalize (H12AffineFastState.compose env53154 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53154 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53155 : List Nat := [2,4,8,10,32,10,35,2,12,9,0,1,15,0,1,47,12,12,8,0,1,45,7,36,37,7,39,12,0,42,2,11,2,11,1,12]

theorem envBound53155 : H12AffineFastState.Bounded env53155 := by
  intro p hp
  have h : env53155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53154_53155 : H12AffineEnvironment.transform 3 10 env53154 = env53155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53154 == env53155) = true)

theorem identity53155 : scanCanonicalize (H12AffineFastState.compose env53155 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53155 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53156 : List Nat := [2,4,8,10,10,10,9,2,12,9,0,1,15,0,1,5,12,12,8,0,1,7,7,14,15,7,13,12,0,0,2,11,2,11,1,12]

theorem envBound53156 : H12AffineFastState.Bounded env53156 := by
  intro p hp
  have h : env53156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53155_53156 : H12AffineEnvironment.transform 4 10 env53155 = env53156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53155 == env53156) = true)

theorem identity53156 : scanCanonicalize (H12AffineFastState.compose env53156 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53156 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53157 : List Nat := [2,4,5,7,7,7,4,2,1,4,0,1,2,0,1,5,1,1,5,0,1,7,7,3,2,7,0,1,0,0,2,6,2,6,1,1]

theorem envBound53157 : H12AffineFastState.Bounded env53157 := by
  intro p hp
  have h : env53157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53156_53157 : H12AffineEnvironment.transform 2 5 env53156 = env53157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53156 == env53157) = true)

def env53158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4096,5276,74047,66896,13769,78895,1151,74815,1297,81226,8205,1280,256,65830,1344,5952]

theorem envBound53158 : H12AffineFastState.Bounded env53158 := by
  intro p hp
  have h : env53158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53131_53158 : H12AffineEnvironment.transform 17 65665 env53131 = env53158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53131 == env53158) = true)

theorem identity53158 : scanCanonicalize (H12AffineFastState.compose env53158 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound53158 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53159 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,65536,74031,65665,4417,8541,4096,4572,74047,65552,12425,78191,319,74111,81,79882,8205,64,256,65830,0,4608]

theorem envBound53159 : H12AffineFastState.Bounded env53159 := by
  intro p hp
  have h : env53159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53158_53159 : H12AffineEnvironment.transform 9 320 env53158 = env53159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53158 == env53159) = true)

def env53160 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,81,8540,65536,74031,65665,533,8541,852,648,74047,65552,9181,74299,319,74111,81,76638,8205,64,256,65830,0,340]

theorem envBound53160 : H12AffineFastState.Bounded env53160 := by
  intro p hp
  have h : env53160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53159_53160 : H12AffineEnvironment.transform 11 852 env53159 = env53160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env53159 == env53160) = true)

def env53161 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,65536,74031,65665,517,8525,836,648,74031,65536,9165,74283,303,74095,65,76622,8205,64,256,65830,0,324]

theorem envBound53161 : H12AffineFastState.Bounded env53161 := by
  intro p hp
  have h : env53161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53160_53161 : H12AffineEnvironment.transform 3 0 env53160 = env53161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53160 == env53161) = true)

theorem identity53161 : scanCanonicalize (H12AffineFastState.compose env53161 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 833) := by decide +kernel

theorem selectedBound53161 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53162 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,833,8814,960,517,8525,836,648,8814,833,9165,8554,303,8750,65,10255,8205,64,256,615,0,324]

theorem envBound53162 : H12AffineFastState.Bounded env53162 := by
  intro p hp
  have h : env53162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53161_53162 : H12AffineEnvironment.transform 15 833 env53161 = env53162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 833 env53161 == env53162) = true)

def env53163 : List Nat := [2,4,8,0,32,64,128,256,512,320,576,836,8192,65,8524,833,8814,960,517,8525,836,648,8814,833,9165,8554,303,8750,65,8783,8205,64,256,615,0,324]

theorem envBound53163 : H12AffineFastState.Bounded env53163 := by
  intro p hp
  have h : env53163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53162_53163 : H12AffineEnvironment.transform 10 576 env53162 = env53163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env53162 == env53163) = true)

theorem identity53163 : scanCanonicalize (H12AffineFastState.compose env53163 (packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 546) := by decide +kernel

theorem selectedBound53163 : packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53164 : List Nat := [2,4,8,0,32,64,128,256,512,320,576,836,546,65,878,833,76,960,517,879,836,648,76,833,495,840,303,12,65,109,559,64,256,615,0,324]

theorem envBound53164 : H12AffineFastState.Bounded env53164 := by
  intro p hp
  have h : env53164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53163_53164 : H12AffineEnvironment.transform 12 546 env53163 = env53164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 546 env53163 == env53164) = true)

theorem identity53164 : scanCanonicalize (H12AffineFastState.compose env53164 (packedSelected [1,5,7,8,10,11,13,15,16,17,18,19,27] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53164 : packedSelected [1,5,7,8,10,11,13,15,16,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env53165 : List Nat := [2,4,8,0,32,64,128,256,0,320,64,324,34,65,366,321,76,448,5,367,324,136,76,321,495,328,303,12,65,109,47,64,256,103,0,324]

theorem envBound53165 : H12AffineFastState.Bounded env53165 := by
  intro p hp
  have h : env53165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53164_53165 : H12AffineEnvironment.transform 8 0 env53164 = env53165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53164 == env53165) = true)

theorem identity53165 : scanCanonicalize (H12AffineFastState.compose env53165 (packedSelected [0,1,3,5,7,8,11,12,13,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound53165 : packedSelected [0,1,3,5,7,8,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53166 : List Nat := [2,4,8,0,32,64,47,256,0,320,64,324,34,65,366,321,76,367,5,367,324,39,76,321,320,328,303,12,65,109,47,64,256,103,0,324]

theorem envBound53166 : H12AffineFastState.Bounded env53166 := by
  intro p hp
  have h : env53166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53165_53166 : H12AffineEnvironment.transform 6 47 env53165 = env53166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env53165 == env53166) = true)

theorem identity53166 : scanCanonicalize (H12AffineFastState.compose env53166 (packedSelected [0,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53166 : packedSelected [0,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53167 : List Nat := [2,4,8,0,6,64,9,256,0,320,64,324,4,65,328,321,76,329,5,329,324,1,76,321,320,328,265,12,65,75,9,64,256,65,0,324]

theorem envBound53167 : H12AffineFastState.Bounded env53167 := by
  intro p hp
  have h : env53167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53166_53167 : H12AffineEnvironment.transform 4 6 env53166 = env53167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53166 == env53167) = true)

theorem identity53167 : scanCanonicalize (H12AffineFastState.compose env53167 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53167 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53168 : List Nat := [2,4,4,0,6,64,5,256,0,320,64,324,4,65,324,321,64,325,5,325,324,1,64,321,320,324,261,0,65,71,5,64,256,65,0,324]

theorem envBound53168 : H12AffineFastState.Bounded env53168 := by
  intro p hp
  have h : env53168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53167_53168 : H12AffineEnvironment.transform 2 4 env53167 = env53168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53167 == env53168) = true)

theorem identity53168 : scanCanonicalize (H12AffineFastState.compose env53168 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound53168 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env53169 : List Nat := [2,4,4,0,6,7,5,256,0,263,7,259,4,6,259,262,7,258,5,258,259,1,7,262,263,259,261,0,6,0,5,7,256,6,0,259]

theorem envBound53169 : H12AffineFastState.Bounded env53169 := by
  intro p hp
  have h : env53169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53168_53169 : H12AffineEnvironment.transform 5 7 env53168 = env53169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env53168 == env53169) = true)

theorem identity53169 : scanCanonicalize (H12AffineFastState.compose env53169 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53170 : List Nat := [2,3,3,0,1,0,2,256,0,256,0,259,3,1,259,257,0,258,2,258,259,1,0,257,256,259,258,0,1,0,2,0,256,1,0,259]

theorem envBound53170 : H12AffineFastState.Bounded env53170 := by
  intro p hp
  have h : env53170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53169_53170 : H12AffineEnvironment.transform 1 3 env53169 = env53170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53169 == env53170) = true)

theorem identity53170 : scanCanonicalize (H12AffineFastState.compose env53170 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound53170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53171 : List Nat := [2,3,3,0,1,0,2,3,0,3,0,0,3,1,0,2,0,1,2,1,0,1,0,2,3,0,1,0,1,0,2,0,3,1,0,0]

theorem envBound53171 : H12AffineFastState.Bounded env53171 := by
  intro p hp
  have h : env53171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53170_53171 : H12AffineEnvironment.transform 7 3 env53170 = env53171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env53170 == env53171) = true)

def env53172 : List Nat := [2,4,8,0,32,64,128,256,512,320,577,836,8192,65,8524,833,8814,960,517,8525,836,648,8814,833,9165,8554,303,8750,65,8782,8205,64,256,615,0,324]

theorem envBound53172 : H12AffineFastState.Bounded env53172 := by
  intro p hp
  have h : env53172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53162_53172 : H12AffineEnvironment.transform 10 577 env53162 = env53172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env53162 == env53172) = true)

theorem identity53172 : scanCanonicalize (H12AffineFastState.compose env53172 (packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53172 : packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53173 : List Nat := [2,4,4,0,32,64,128,256,512,320,577,836,8192,65,8512,833,8802,960,517,8513,836,644,8802,833,9153,8550,291,8738,65,8770,8193,64,256,615,0,324]

theorem envBound53173 : H12AffineFastState.Bounded env53173 := by
  intro p hp
  have h : env53173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53172_53173 : H12AffineEnvironment.transform 2 4 env53172 = env53173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53172 == env53173) = true)

theorem identity53173 : scanCanonicalize (H12AffineFastState.compose env53173 (packedSelected [0,1,2,4,5,7,8,9,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound53173 : packedSelected [0,1,2,4,5,7,8,9,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env53174 : List Nat := [2,4,4,0,32,64,128,98,512,34,577,550,8192,65,8226,547,8802,674,517,8227,550,644,8802,547,8867,8196,65,8738,65,8770,8193,64,98,615,0,38]

theorem envBound53174 : H12AffineFastState.Bounded env53174 := by
  intro p hp
  have h : env53174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53173_53174 : H12AffineEnvironment.transform 7 98 env53173 = env53174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env53173 == env53174) = true)

theorem identity53174 : scanCanonicalize (H12AffineFastState.compose env53174 (packedSelected [3,4,8,9,10,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound53174 : packedSelected [3,4,8,9,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env53175 : List Nat := [2,4,4,0,32,64,128,98,512,34,577,550,128,65,162,547,738,674,517,163,550,644,738,547,547,132,65,674,65,706,129,64,98,615,0,38]

theorem envBound53175 : H12AffineFastState.Bounded env53175 := by
  intro p hp
  have h : env53175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53174_53175 : H12AffineEnvironment.transform 12 128 env53174 = env53175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env53174 == env53175) = true)

theorem identity53175 : scanCanonicalize (H12AffineFastState.compose env53175 (packedSelected [1,3,7,8,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound53175 : packedSelected [1,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53176 : List Nat := [2,4,4,0,32,64,128,98,133,34,196,163,128,65,162,166,103,39,128,163,163,1,103,166,166,132,65,39,65,71,129,64,98,226,0,38]

theorem envBound53176 : H12AffineFastState.Bounded env53176 := by
  intro p hp
  have h : env53176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53175_53176 : H12AffineEnvironment.transform 8 133 env53175 = env53176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env53175 == env53176) = true)

theorem identity53176 : scanCanonicalize (H12AffineFastState.compose env53176 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound53176 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53177 : List Nat := [2,4,4,0,32,64,34,98,39,34,102,1,34,65,0,4,103,39,34,1,1,1,103,4,4,38,65,39,65,71,35,64,98,64,0,38]

theorem envBound53177 : H12AffineFastState.Bounded env53177 := by
  intro p hp
  have h : env53177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53176_53177 : H12AffineEnvironment.transform 6 34 env53176 = env53177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env53176 == env53177) = true)

theorem identity53177 : scanCanonicalize (H12AffineFastState.compose env53177 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53177 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env53178 : List Nat := [2,4,4,0,1,64,3,67,6,3,71,1,3,65,0,4,70,6,3,1,1,1,70,4,4,7,65,6,65,71,2,64,67,64,0,7]

theorem envBound53178 : H12AffineFastState.Bounded env53178 := by
  intro p hp
  have h : env53178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53177_53178 : H12AffineEnvironment.transform 4 1 env53177 = env53178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53177 == env53178) = true)

theorem identity53178 : scanCanonicalize (H12AffineFastState.compose env53178 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53178 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53179 : List Nat := [0,4,4,0,1,64,1,65,4,1,69,1,1,65,0,4,68,4,1,1,1,1,68,4,4,5,65,4,65,69,0,64,65,64,0,5]

theorem envBound53179 : H12AffineFastState.Bounded env53179 := by
  intro p hp
  have h : env53179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53178_53179 : H12AffineEnvironment.transform 0 0 env53178 = env53179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53178 == env53179) = true)

theorem identity53179 : scanCanonicalize (H12AffineFastState.compose env53179 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound53179 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env53180 : List Nat := [0,4,4,0,1,5,1,4,4,1,0,1,1,4,0,4,1,4,1,1,1,1,1,4,4,5,4,4,4,0,0,5,4,5,0,5]

theorem envBound53180 : H12AffineFastState.Bounded env53180 := by
  intro p hp
  have h : env53180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53179_53180 : H12AffineEnvironment.transform 5 5 env53179 = env53180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env53179 == env53180) = true)

def env53181 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,65536,74031,65665,516,8524,837,648,74030,65537,9164,74282,302,74094,64,76623,8205,64,256,65830,0,325]

theorem envBound53181 : H12AffineFastState.Bounded env53181 := by
  intro p hp
  have h : env53181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53160_53181 : H12AffineEnvironment.transform 3 1 env53160 = env53181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53160 == env53181) = true)

theorem identity53181 : scanCanonicalize (H12AffineFastState.compose env53181 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8969) := by decide +kernel

theorem selectedBound53181 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53182 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,64,8525,8969,550,9096,516,8524,837,648,551,8968,9164,291,302,615,64,2118,8205,64,256,8751,0,325]

theorem envBound53182 : H12AffineFastState.Bounded env53182 := by
  intro p hp
  have h : env53182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53181_53182 : H12AffineEnvironment.transform 15 8969 env53181 = env53182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8969 env53181 == env53182) = true)

def env53183 : List Nat := [2,4,8,1,32,64,128,256,512,320,576,837,8192,64,8525,8969,550,9096,516,8524,837,648,551,8968,9164,291,302,615,64,518,8205,64,256,8751,0,325]

theorem envBound53183 : H12AffineFastState.Bounded env53183 := by
  intro p hp
  have h : env53183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53183 : H12AffineEnvironment.transform 10 576 env53182 = env53183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env53182 == env53183) = true)

theorem identity53183 : scanCanonicalize (H12AffineFastState.compose env53183 (packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound53183 : packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53184 : List Nat := [2,4,8,1,32,64,128,256,512,320,576,837,4,64,329,781,550,908,516,328,837,648,551,780,968,291,302,615,64,518,9,64,256,555,0,325]

theorem envBound53184 : H12AffineFastState.Bounded env53184 := by
  intro p hp
  have h : env53184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53183_53184 : H12AffineEnvironment.transform 12 4 env53183 = env53184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env53183 == env53184) = true)

theorem identity53184 : scanCanonicalize (H12AffineFastState.compose env53184 (packedSelected [2,3,4,5,8,9,10,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound53184 : packedSelected [2,3,4,5,8,9,10,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env53185 : List Nat := [2,4,8,1,32,64,128,256,356,320,292,33,4,64,329,105,322,232,352,328,33,492,323,104,172,291,302,259,64,354,9,64,256,335,0,325]

theorem envBound53185 : H12AffineFastState.Bounded env53185 := by
  intro p hp
  have h : env53185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53184_53185 : H12AffineEnvironment.transform 8 356 env53184 = env53185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env53184 == env53185) = true)

theorem identity53185 : scanCanonicalize (H12AffineFastState.compose env53185 (packedSelected [1,2,5,8,10,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 199) := by decide +kernel

theorem selectedBound53185 : packedSelected [1,2,5,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env53186 : List Nat := [2,4,8,1,32,64,128,199,163,135,227,33,4,64,142,105,133,232,167,143,33,43,132,104,172,228,233,196,64,165,9,64,199,136,0,130]

theorem envBound53186 : H12AffineFastState.Bounded env53186 := by
  intro p hp
  have h : env53186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53185_53186 : H12AffineEnvironment.transform 7 199 env53185 = env53186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 199 env53185 == env53186) = true)

theorem identity53186 : scanCanonicalize (H12AffineFastState.compose env53186 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound53186 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env53187 : List Nat := [2,4,8,1,32,39,128,160,163,135,132,33,4,39,142,14,133,143,167,143,33,43,132,15,172,131,142,163,39,165,9,39,160,136,0,130]

theorem envBound53187 : H12AffineFastState.Bounded env53187 := by
  intro p hp
  have h : env53187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53186_53187 : H12AffineEnvironment.transform 5 39 env53186 = env53187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env53186 == env53187) = true)

theorem identity53187 : scanCanonicalize (H12AffineFastState.compose env53187 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound53187 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53188 : List Nat := [2,4,8,1,32,39,34,2,1,37,38,33,4,39,44,14,39,45,5,45,33,43,38,15,14,33,44,1,39,7,9,39,2,42,0,32]

theorem envBound53188 : H12AffineFastState.Bounded env53188 := by
  intro p hp
  have h : env53188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53187_53188 : H12AffineEnvironment.transform 6 34 env53187 = env53188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env53187 == env53188) = true)

theorem identity53188 : scanCanonicalize (H12AffineFastState.compose env53188 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53189 : List Nat := [2,4,2,1,32,39,34,2,1,37,38,33,4,39,38,4,39,39,5,39,33,33,38,5,4,33,38,1,39,7,3,39,2,32,0,32]

theorem envBound53189 : H12AffineFastState.Bounded env53189 := by
  intro p hp
  have h : env53189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53188_53189 : H12AffineEnvironment.transform 2 2 env53188 = env53189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53188 == env53189) = true)

theorem identity53189 : scanCanonicalize (H12AffineFastState.compose env53189 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53190 : List Nat := [2,4,2,1,7,0,5,2,1,2,1,6,4,0,1,4,0,0,5,0,6,6,1,5,4,6,1,1,0,7,3,0,2,7,0,7]

theorem envBound53190 : H12AffineFastState.Bounded env53190 := by
  intro p hp
  have h : env53190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53189_53190 : H12AffineEnvironment.transform 4 7 env53189 = env53190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53189 == env53190) = true)

theorem identity53190 : scanCanonicalize (H12AffineFastState.compose env53190 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53190 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53191 : List Nat := [2,2,2,1,1,0,3,2,1,2,1,0,2,0,1,2,0,0,3,0,0,0,1,3,2,0,1,1,0,1,3,0,2,1,0,1]

theorem envBound53191 : H12AffineFastState.Bounded env53191 := by
  intro p hp
  have h : env53191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53190_53191 : H12AffineEnvironment.transform 1 2 env53190 = env53191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53190 == env53191) = true)

def env53192 : List Nat := [2,4,8,1,32,64,128,256,512,320,577,837,8192,64,8525,8969,550,9096,516,8524,837,648,551,8968,9164,291,302,615,64,519,8205,64,256,8751,0,325]

theorem envBound53192 : H12AffineFastState.Bounded env53192 := by
  intro p hp
  have h : env53192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53192 : H12AffineEnvironment.transform 10 577 env53182 = env53192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env53182 == env53192) = true)

theorem identity53192 : scanCanonicalize (H12AffineFastState.compose env53192 (packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 611) := by decide +kernel

theorem selectedBound53192 : packedSelected [0,3,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53193 : List Nat := [2,4,8,1,32,64,128,256,512,320,577,837,611,64,814,362,550,491,516,815,837,648,551,363,431,291,302,615,64,519,622,64,256,76,0,325]

theorem envBound53193 : H12AffineFastState.Bounded env53193 := by
  intro p hp
  have h : env53193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53192_53193 : H12AffineEnvironment.transform 12 611 env53192 = env53193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 611 env53192 == env53193) = true)

theorem identity53193 : scanCanonicalize (H12AffineFastState.compose env53193 (packedSelected [1,2,3,5,8,13,15,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 355) := by decide +kernel

theorem selectedBound53193 : packedSelected [1,2,3,5,8,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env53194 : List Nat := [2,4,8,1,32,64,128,256,355,320,290,38,256,64,77,362,325,491,359,76,38,491,324,363,431,291,302,260,64,356,269,64,256,76,0,325]

theorem envBound53194 : H12AffineFastState.Bounded env53194 := by
  intro p hp
  have h : env53194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53193_53194 : H12AffineEnvironment.transform 8 355 env53193 = env53194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 355 env53193 == env53194) = true)

theorem identity53194 : scanCanonicalize (H12AffineFastState.compose env53194 (packedSelected [1,3,4,5,9,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound53194 : packedSelected [1,3,4,5,9,10,15] rootPS < 2^1333 := by decide +kernel

def env53195 : List Nat := [2,4,8,1,32,64,41,256,355,320,290,38,256,64,77,362,325,322,359,76,38,322,324,363,262,291,302,260,64,356,269,64,256,76,0,325]

theorem envBound53195 : H12AffineFastState.Bounded env53195 := by
  intro p hp
  have h : env53195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53194_53195 : H12AffineEnvironment.transform 6 41 env53194 = env53195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env53194 == env53195) = true)

theorem identity53195 : scanCanonicalize (H12AffineFastState.compose env53195 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound53195 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env53196 : List Nat := [2,4,8,1,32,64,41,14,109,78,44,38,14,64,77,100,75,76,105,76,38,76,74,101,8,45,32,10,64,106,3,64,14,76,0,75]

theorem envBound53196 : H12AffineFastState.Bounded env53196 := by
  intro p hp
  have h : env53196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53195_53196 : H12AffineEnvironment.transform 7 14 env53195 = env53196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env53195 == env53196) = true)

theorem identity53196 : scanCanonicalize (H12AffineFastState.compose env53196 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53196 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53197 : List Nat := [2,4,8,1,7,64,14,14,74,78,11,1,14,64,77,67,75,76,78,76,1,76,74,66,8,10,7,10,64,77,3,64,14,76,0,75]

theorem envBound53197 : H12AffineFastState.Bounded env53197 := by
  intro p hp
  have h : env53197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53196_53197 : H12AffineEnvironment.transform 4 7 env53196 = env53197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53196 == env53197) = true)

theorem identity53197 : scanCanonicalize (H12AffineFastState.compose env53197 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53197 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53198 : List Nat := [2,4,8,1,7,0,14,14,10,14,11,1,14,0,13,3,11,12,14,12,1,12,10,2,8,10,7,10,0,13,3,0,14,12,0,11]

theorem envBound53198 : H12AffineFastState.Bounded env53198 := by
  intro p hp
  have h : env53198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53197_53198 : H12AffineEnvironment.transform 5 0 env53197 = env53198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53197 == env53198) = true)

theorem identity53198 : scanCanonicalize (H12AffineFastState.compose env53198 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound53198 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53199 : List Nat := [2,4,7,1,7,0,1,1,5,1,4,1,1,0,2,3,4,3,1,3,1,3,5,2,7,5,7,5,0,2,3,0,1,3,0,4]

theorem envBound53199 : H12AffineFastState.Bounded env53199 := by
  intro p hp
  have h : env53199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53198_53199 : H12AffineEnvironment.transform 2 7 env53198 = env53199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env53198 == env53199) = true)

theorem identity53199 : scanCanonicalize (H12AffineFastState.compose env53199 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53199 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53200 : List Nat := [1,4,4,1,4,0,1,1,5,1,4,1,1,0,1,0,4,0,1,0,1,0,5,1,4,5,4,5,0,1,0,0,1,0,0,4]

theorem envBound53200 : H12AffineFastState.Bounded env53200 := by
  intro p hp
  have h : env53200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53199_53200 : H12AffineEnvironment.transform 0 1 env53199 = env53200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53199 == env53200) = true)

theorem identity53200 : scanCanonicalize (H12AffineFastState.compose env53200 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53200 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53201 : List Nat := [1,0,0,1,0,0,1,1,1,1,0,1,1,0,1,0,0,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,1,0,0,0]

theorem envBound53201 : H12AffineFastState.Bounded env53201 := by
  intro p hp
  have h : env53201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53200_53201 : H12AffineEnvironment.transform 1 0 env53200 = env53201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53200 == env53201) = true)

def env53202 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,81,8540,65536,74031,65665,532,8541,853,649,74047,65552,9180,74298,319,74111,81,76639,8205,64,256,65830,0,341]

theorem envBound53202 : H12AffineFastState.Bounded env53202 := by
  intro p hp
  have h : env53202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53159_53202 : H12AffineEnvironment.transform 11 853 env53159 = env53202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env53159 == env53202) = true)

def env53203 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,65536,74031,65665,516,8525,837,649,74031,65536,9164,74282,303,74095,65,76623,8205,64,256,65830,0,325]

theorem envBound53203 : H12AffineFastState.Bounded env53203 := by
  intro p hp
  have h : env53203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53202_53203 : H12AffineEnvironment.transform 3 0 env53202 = env53203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53202 == env53203) = true)

theorem identity53203 : scanCanonicalize (H12AffineFastState.compose env53203 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 623) := by decide +kernel

theorem selectedBound53203 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53204 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,623,65,803,65536,66368,65665,516,802,837,649,66368,65536,419,65605,303,66304,65,67872,610,64,256,65830,0,325]

theorem envBound53204 : H12AffineFastState.Bounded env53204 := by
  intro p hp
  have h : env53204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53203_53204 : H12AffineEnvironment.transform 12 623 env53203 = env53204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 623 env53203 == env53204) = true)

def env53205 : List Nat := [2,4,8,0,32,64,128,256,136,320,2048,461,231,65,427,65536,65992,65665,140,426,461,1,65992,65536,419,65605,303,65928,65,67872,234,64,256,65830,0,325]

theorem envBound53205 : H12AffineFastState.Bounded env53205 := by
  intro p hp
  have h : env53205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53204_53205 : H12AffineEnvironment.transform 8 136 env53204 = env53205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env53204 == env53205) = true)

theorem identity53205 : scanCanonicalize (H12AffineFastState.compose env53205 (packedSelected [0,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 205) := by decide +kernel

theorem selectedBound53205 : packedSelected [0,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53206 : List Nat := [2,4,8,0,32,64,128,256,136,320,2048,461,231,65,427,205,261,76,140,426,461,1,261,205,419,136,303,325,65,2541,234,64,256,491,0,325]

theorem envBound53206 : H12AffineFastState.Bounded env53206 := by
  intro p hp
  have h : env53206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53205_53206 : H12AffineEnvironment.transform 15 205 env53205 = env53206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 205 env53205 == env53206) = true)

theorem identity53206 : scanCanonicalize (H12AffineFastState.compose env53206 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53206 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53207 : List Nat := [2,4,8,0,7,64,128,256,136,320,2048,461,192,65,396,205,261,76,140,397,461,1,261,205,388,136,264,325,65,2506,205,64,256,460,0,325]

theorem envBound53207 : H12AffineFastState.Bounded env53207 := by
  intro p hp
  have h : env53207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53206_53207 : H12AffineEnvironment.transform 4 7 env53206 = env53207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53206 == env53207) = true)

theorem identity53207 : scanCanonicalize (H12AffineFastState.compose env53207 (packedSelected [1,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound53207 : packedSelected [1,10,12,17] rootPS < 2^1333 := by decide +kernel

def env53208 : List Nat := [2,4,8,0,7,64,128,256,136,320,77,461,192,65,396,205,261,76,140,397,461,1,261,205,388,136,264,325,65,391,205,64,256,460,0,325]

theorem envBound53208 : H12AffineFastState.Bounded env53208 := by
  intro p hp
  have h : env53208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53207_53208 : H12AffineEnvironment.transform 10 77 env53207 = env53208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env53207 == env53208) = true)

theorem identity53208 : scanCanonicalize (H12AffineFastState.compose env53208 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound53208 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env53209 : List Nat := [2,4,8,0,7,64,128,192,136,128,77,13,192,65,76,205,197,76,140,77,13,1,197,205,68,136,200,133,65,71,205,64,192,12,0,133]

theorem envBound53209 : H12AffineFastState.Bounded env53209 := by
  intro p hp
  have h : env53209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53208_53209 : H12AffineEnvironment.transform 7 192 env53208 = env53209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env53208 == env53209) = true)

theorem identity53209 : scanCanonicalize (H12AffineFastState.compose env53209 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound53209 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53210 : List Nat := [2,4,8,0,7,64,4,68,12,4,77,13,68,65,76,73,65,76,8,77,13,1,65,73,68,12,76,1,65,71,73,64,68,12,0,1]

theorem envBound53210 : H12AffineFastState.Bounded env53210 := by
  intro p hp
  have h : env53210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53209_53210 : H12AffineEnvironment.transform 6 4 env53209 = env53210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env53209 == env53210) = true)

theorem identity53210 : scanCanonicalize (H12AffineFastState.compose env53210 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound53210 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53211 : List Nat := [2,4,8,0,7,10,4,14,12,4,7,13,14,11,6,3,11,6,8,7,13,1,11,3,14,12,6,1,11,13,3,10,14,12,0,1]

theorem envBound53211 : H12AffineFastState.Bounded env53211 := by
  intro p hp
  have h : env53211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53210_53211 : H12AffineEnvironment.transform 5 10 env53210 = env53211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env53210 == env53211) = true)

theorem identity53211 : scanCanonicalize (H12AffineFastState.compose env53211 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53211 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53212 : List Nat := [2,2,8,0,1,10,2,8,10,2,1,11,8,11,0,3,11,0,8,1,11,1,11,3,8,10,0,1,11,11,3,10,8,10,0,1]

theorem envBound53212 : H12AffineFastState.Bounded env53212 := by
  intro p hp
  have h : env53212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53211_53212 : H12AffineEnvironment.transform 1 2 env53211 = env53212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53211 == env53212) = true)

def env53213 : List Nat := [2,4,8,0,32,64,128,256,137,320,2048,460,230,65,426,65536,65993,65665,141,427,460,0,65993,65536,419,65605,303,65929,65,67872,235,64,256,65830,0,325]

theorem envBound53213 : H12AffineFastState.Bounded env53213 := by
  intro p hp
  have h : env53213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53204_53213 : H12AffineEnvironment.transform 8 137 env53204 = env53213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env53204 == env53213) = true)

theorem identity53213 : scanCanonicalize (H12AffineFastState.compose env53213 (packedSelected [0,7,12,15,17,20,21,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 257) := by decide +kernel

theorem selectedBound53213 : packedSelected [0,7,12,15,17,20,21,38,41] rootPS < 2^1333 := by decide +kernel

def env53214 : List Nat := [2,4,8,0,32,64,128,256,137,320,2048,460,230,65,426,257,200,384,141,427,460,0,200,257,419,324,303,136,65,2081,235,64,256,39,0,325]

theorem envBound53214 : H12AffineFastState.Bounded env53214 := by
  intro p hp
  have h : env53214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53213_53214 : H12AffineEnvironment.transform 15 257 env53213 = env53214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env53213 == env53214) = true)

theorem identity53214 : scanCanonicalize (H12AffineFastState.compose env53214 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53214 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env53215 : List Nat := [2,4,8,0,32,64,128,5,137,69,2048,201,230,65,175,4,200,133,141,174,201,0,200,4,166,65,42,136,65,2081,235,64,5,39,0,64]

theorem envBound53215 : H12AffineFastState.Bounded env53215 := by
  intro p hp
  have h : env53215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53214_53215 : H12AffineEnvironment.transform 7 5 env53214 = env53215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53214 == env53215) = true)

theorem identity53215 : scanCanonicalize (H12AffineFastState.compose env53215 (packedSelected [3,4,5,9,10,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53215 : packedSelected [3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env53216 : List Nat := [2,4,8,0,6,64,128,5,137,69,2048,201,192,65,137,4,200,133,141,136,201,0,200,4,128,65,12,136,65,2055,205,64,5,1,0,64]

theorem envBound53216 : H12AffineFastState.Bounded env53216 := by
  intro p hp
  have h : env53216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53215_53216 : H12AffineEnvironment.transform 4 6 env53215 = env53216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53215 == env53216) = true)

theorem identity53216 : scanCanonicalize (H12AffineFastState.compose env53216 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound53216 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53217 : List Nat := [2,4,8,0,6,10,128,5,137,15,2048,131,138,11,137,4,130,133,141,136,131,0,130,4,128,11,12,136,11,2055,135,10,5,1,0,10]

theorem envBound53217 : H12AffineFastState.Bounded env53217 := by
  intro p hp
  have h : env53217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53216_53217 : H12AffineEnvironment.transform 5 10 env53216 = env53217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env53216 == env53217) = true)

theorem identity53217 : scanCanonicalize (H12AffineFastState.compose env53217 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound53217 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env53218 : List Nat := [2,4,8,0,6,10,128,5,137,15,132,131,138,11,137,4,130,133,141,136,131,0,130,4,128,11,12,136,11,131,135,10,5,1,0,10]

theorem envBound53218 : H12AffineFastState.Bounded env53218 := by
  intro p hp
  have h : env53218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53217_53218 : H12AffineEnvironment.transform 10 132 env53217 = env53218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env53217 == env53218) = true)

theorem identity53218 : scanCanonicalize (H12AffineFastState.compose env53218 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53218 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53219 : List Nat := [2,4,5,0,6,7,128,5,132,2,132,131,135,6,132,4,130,133,128,133,131,0,130,4,128,6,1,133,6,131,135,7,5,1,0,7]

theorem envBound53219 : H12AffineFastState.Bounded env53219 := by
  intro p hp
  have h : env53219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53218_53219 : H12AffineEnvironment.transform 2 5 env53218 = env53219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53218 == env53219) = true)

theorem identity53219 : scanCanonicalize (H12AffineFastState.compose env53219 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound53219 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53220 : List Nat := [2,4,5,0,6,7,4,5,0,2,0,7,3,6,0,4,6,1,4,1,7,0,6,4,4,6,1,1,6,7,3,7,5,1,0,7]

theorem envBound53220 : H12AffineFastState.Bounded env53220 := by
  intro p hp
  have h : env53220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53219_53220 : H12AffineEnvironment.transform 6 4 env53219 = env53220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env53219 == env53220) = true)

theorem identity53220 : scanCanonicalize (H12AffineFastState.compose env53220 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53221 : List Nat := [2,2,3,0,0,1,2,3,0,2,0,1,3,0,0,2,0,1,2,1,1,0,0,2,2,0,1,1,0,1,3,1,3,1,0,1]

theorem envBound53221 : H12AffineFastState.Bounded env53221 := by
  intro p hp
  have h : env53221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53220_53221 : H12AffineEnvironment.transform 1 2 env53220 = env53221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53220 == env53221) = true)

theorem identity53221 : scanCanonicalize (H12AffineFastState.compose env53221 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53222 : List Nat := [1,1,0,0,0,1,1,0,0,1,0,1,0,0,0,1,0,1,1,1,1,0,0,1,1,0,1,1,0,1,0,1,0,1,0,1]

theorem envBound53222 : H12AffineFastState.Bounded env53222 := by
  intro p hp
  have h : env53222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53221_53222 : H12AffineEnvironment.transform 0 1 env53221 = env53222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53221 == env53222) = true)

def env53223 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,65536,74031,65665,517,8524,836,649,74030,65537,9165,74283,302,74094,64,76622,8205,64,256,65830,0,324]

theorem envBound53223 : H12AffineFastState.Bounded env53223 := by
  intro p hp
  have h : env53223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53202_53223 : H12AffineEnvironment.transform 3 1 env53202 = env53223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53202 == env53223) = true)

theorem identity53223 : scanCanonicalize (H12AffineFastState.compose env53223 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound53223 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53224 : List Nat := [2,4,8,1,32,64,128,256,39,320,2048,355,8192,64,8525,65536,74031,65665,34,8524,355,174,74030,65537,8682,73740,302,74094,64,76137,8205,64,256,65830,0,324]

theorem envBound53224 : H12AffineFastState.Bounded env53224 := by
  intro p hp
  have h : env53224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53223_53224 : H12AffineEnvironment.transform 8 39 env53223 = env53224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env53223 == env53224) = true)

def env53225 : List Nat := [2,4,8,1,32,64,128,256,39,320,2048,355,8192,64,8525,10436,2539,10309,34,8524,355,174,2538,10437,8682,2248,302,2474,64,429,8205,64,256,10722,0,324]

theorem envBound53225 : H12AffineFastState.Bounded env53225 := by
  intro p hp
  have h : env53225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53224_53225 : H12AffineEnvironment.transform 15 10436 env53224 = env53225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10436 env53224 == env53225) = true)

def env53226 : List Nat := [2,4,8,1,32,64,128,256,39,320,200,355,8192,64,8525,8204,291,8333,34,8524,355,174,290,8205,8682,0,302,354,64,429,8205,64,256,8490,0,324]

theorem envBound53226 : H12AffineFastState.Bounded env53226 := by
  intro p hp
  have h : env53226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53225_53226 : H12AffineEnvironment.transform 10 200 env53225 = env53226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 200 env53225 == env53226) = true)

theorem identity53226 : scanCanonicalize (H12AffineFastState.compose env53226 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 321) := by decide +kernel

theorem selectedBound53226 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53227 : List Nat := [2,4,8,1,32,64,128,256,39,320,200,355,321,64,12,333,291,460,34,13,355,174,290,332,171,0,302,354,64,429,332,64,256,107,0,324]

theorem envBound53227 : H12AffineFastState.Bounded env53227 := by
  intro p hp
  have h : env53227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53226_53227 : H12AffineEnvironment.transform 12 321 env53226 = env53227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env53226 == env53227) = true)

theorem identity53227 : scanCanonicalize (H12AffineFastState.compose env53227 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound53227 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53228 : List Nat := [2,4,8,1,32,64,128,110,39,46,200,13,47,64,12,35,77,162,34,13,13,174,76,34,171,0,64,12,64,195,34,64,110,107,0,42]

theorem envBound53228 : H12AffineFastState.Bounded env53228 := by
  intro p hp
  have h : env53228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53227_53228 : H12AffineEnvironment.transform 7 110 env53227 = env53228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env53227 == env53228) = true)

theorem identity53228 : scanCanonicalize (H12AffineFastState.compose env53228 (packedSelected [4,5,8,9,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound53228 : packedSelected [4,5,8,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53229 : List Nat := [2,4,8,1,32,10,128,36,39,46,130,13,47,10,12,35,7,162,34,13,13,174,6,34,171,0,10,12,10,137,34,10,36,33,0,42]

theorem envBound53229 : H12AffineFastState.Bounded env53229 := by
  intro p hp
  have h : env53229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53228_53229 : H12AffineEnvironment.transform 5 10 env53228 = env53229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env53228 == env53229) = true)

theorem identity53229 : scanCanonicalize (H12AffineFastState.compose env53229 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound53229 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env53230 : List Nat := [2,4,8,1,32,10,14,36,39,46,12,13,47,10,12,35,7,44,34,13,13,32,6,34,37,0,10,12,10,7,34,10,36,33,0,42]

theorem envBound53230 : H12AffineFastState.Bounded env53230 := by
  intro p hp
  have h : env53230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53229_53230 : H12AffineEnvironment.transform 6 14 env53229 = env53230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env53229 == env53230) = true)

theorem identity53230 : scanCanonicalize (H12AffineFastState.compose env53230 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound53230 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53231 : List Nat := [2,4,8,1,13,10,14,9,10,3,12,13,2,10,12,14,7,1,15,13,13,13,6,15,8,0,10,12,10,7,15,10,9,12,0,7]

theorem envBound53231 : H12AffineFastState.Bounded env53231 := by
  intro p hp
  have h : env53231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53230_53231 : H12AffineEnvironment.transform 4 13 env53230 = env53231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env53230 == env53231) = true)

theorem identity53231 : scanCanonicalize (H12AffineFastState.compose env53231 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53231 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53232 : List Nat := [2,3,8,1,10,10,9,9,10,3,11,10,2,10,11,9,0,1,8,10,10,10,1,8,8,0,10,11,10,0,8,10,9,11,0,0]

theorem envBound53232 : H12AffineFastState.Bounded env53232 := by
  intro p hp
  have h : env53232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53231_53232 : H12AffineEnvironment.transform 1 3 env53231 = env53232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53231 == env53232) = true)

theorem identity53232 : scanCanonicalize (H12AffineFastState.compose env53232 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53233 : List Nat := [2,3,2,1,0,0,3,3,0,3,1,0,2,0,1,3,0,1,2,0,0,0,1,2,2,0,0,1,0,0,2,0,3,1,0,0]

theorem envBound53233 : H12AffineFastState.Bounded env53233 := by
  intro p hp
  have h : env53233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53232_53233 : H12AffineEnvironment.transform 2 2 env53232 = env53233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53232 == env53233) = true)

def env53234 : List Nat := [2,4,8,1,32,64,128,256,39,320,201,355,8192,64,8525,8205,290,8332,34,8524,355,174,291,8204,8682,1,302,355,64,429,8205,64,256,8491,0,324]

theorem envBound53234 : H12AffineFastState.Bounded env53234 := by
  intro p hp
  have h : env53234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53225_53234 : H12AffineEnvironment.transform 10 201 env53225 = env53234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env53225 == env53234) = true)

theorem identity53234 : scanCanonicalize (H12AffineFastState.compose env53234 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 141) := by decide +kernel

theorem selectedBound53234 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53235 : List Nat := [2,4,8,1,32,64,128,256,39,320,201,355,141,64,448,128,290,1,34,449,355,174,291,129,359,1,302,355,64,429,128,64,256,422,0,324]

theorem envBound53235 : H12AffineFastState.Bounded env53235 := by
  intro p hp
  have h : env53235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53234_53235 : H12AffineEnvironment.transform 12 141 env53234 = env53235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 141 env53234 == env53235) = true)

theorem identity53235 : scanCanonicalize (H12AffineFastState.compose env53235 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound53235 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53236 : List Nat := [2,4,8,1,32,64,128,193,39,129,201,162,141,64,1,128,227,1,34,0,162,174,226,129,166,1,239,162,64,108,128,64,193,103,0,133]

theorem envBound53236 : H12AffineFastState.Bounded env53236 := by
  intro p hp
  have h : env53236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53235_53236 : H12AffineEnvironment.transform 7 193 env53235 = env53236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env53235 == env53236) = true)

theorem identity53236 : scanCanonicalize (H12AffineFastState.compose env53236 (packedSelected [1,2,5,8,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound53236 : packedSelected [1,2,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53237 : List Nat := [2,4,8,1,32,64,100,37,39,101,45,70,105,64,1,100,7,1,34,0,70,74,6,101,66,1,11,70,64,108,100,64,37,103,0,97]

theorem envBound53237 : H12AffineFastState.Bounded env53237 := by
  intro p hp
  have h : env53237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53236_53237 : H12AffineEnvironment.transform 6 100 env53236 = env53237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env53236 == env53237) = true)

theorem identity53237 : scanCanonicalize (H12AffineFastState.compose env53237 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53237 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53238 : List Nat := [2,4,8,1,7,64,67,2,0,66,10,70,78,64,1,67,7,1,5,0,70,74,6,66,66,1,11,70,64,75,67,64,2,64,0,70]

theorem envBound53238 : H12AffineFastState.Bounded env53238 := by
  intro p hp
  have h : env53238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53237_53238 : H12AffineEnvironment.transform 4 7 env53237 = env53238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53237 == env53238) = true)

theorem identity53238 : scanCanonicalize (H12AffineFastState.compose env53238 (packedSelected [0,1,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound53238 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env53239 : List Nat := [2,4,8,1,7,11,8,2,0,9,10,13,5,11,1,8,7,1,5,0,13,1,6,9,9,1,11,13,11,0,8,11,2,11,0,13]

theorem envBound53239 : H12AffineFastState.Bounded env53239 := by
  intro p hp
  have h : env53239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53238_53239 : H12AffineEnvironment.transform 5 11 env53238 = env53239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env53238 == env53239) = true)

theorem identity53239 : scanCanonicalize (H12AffineFastState.compose env53239 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53240 : List Nat := [2,4,2,1,7,1,2,2,0,3,0,7,5,1,1,2,7,1,5,0,7,1,6,3,3,1,1,7,1,0,2,1,2,1,0,7]

theorem envBound53240 : H12AffineFastState.Bounded env53240 := by
  intro p hp
  have h : env53240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53239_53240 : H12AffineEnvironment.transform 2 2 env53239 = env53240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53239 == env53240) = true)

def env53241 : List Nat := [2,4,8,1,32,64,128,256,39,320,2048,355,8192,64,8525,10437,2538,10308,34,8524,355,174,2539,10436,8682,2249,302,2475,64,428,8205,64,256,10723,0,324]

theorem envBound53241 : H12AffineFastState.Bounded env53241 := by
  intro p hp
  have h : env53241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53224_53241 : H12AffineEnvironment.transform 15 10437 env53224 = env53241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10437 env53224 == env53241) = true)

def env53242 : List Nat := [2,4,8,1,32,64,128,256,39,320,200,355,8192,64,8525,8205,290,8332,34,8524,355,174,291,8204,8682,1,302,355,64,428,8205,64,256,8491,0,324]

theorem envBound53242 : H12AffineFastState.Bounded env53242 := by
  intro p hp
  have h : env53242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53241_53242 : H12AffineEnvironment.transform 10 200 env53241 = env53242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 200 env53241 == env53242) = true)

theorem identity53242 : scanCanonicalize (H12AffineFastState.compose env53242 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 494) := by decide +kernel

theorem selectedBound53242 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53243 : List Nat := [2,4,8,1,32,64,128,256,39,320,200,355,494,64,163,483,290,354,34,162,355,174,291,482,4,1,302,355,64,428,483,64,256,197,0,324]

theorem envBound53243 : H12AffineFastState.Bounded env53243 := by
  intro p hp
  have h : env53243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53242_53243 : H12AffineEnvironment.transform 12 494 env53242 = env53243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 494 env53242 == env53243) = true)

theorem identity53243 : scanCanonicalize (H12AffineFastState.compose env53243 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound53243 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53244 : List Nat := [2,4,8,1,32,64,34,256,39,320,106,355,332,64,1,321,290,354,34,0,355,12,291,320,4,1,302,355,64,270,321,64,256,103,0,324]

theorem envBound53244 : H12AffineFastState.Bounded env53244 := by
  intro p hp
  have h : env53244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53243_53244 : H12AffineEnvironment.transform 6 34 env53243 = env53244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env53243 == env53244) = true)

theorem identity53244 : scanCanonicalize (H12AffineFastState.compose env53244 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound53244 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53245 : List Nat := [2,4,8,1,32,64,34,67,39,3,106,32,15,64,1,2,97,33,34,0,32,12,96,3,4,1,109,32,64,77,2,64,67,103,0,7]

theorem envBound53245 : H12AffineFastState.Bounded env53245 := by
  intro p hp
  have h : env53245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53244_53245 : H12AffineEnvironment.transform 7 67 env53244 = env53245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env53244 == env53245) = true)

theorem identity53245 : scanCanonicalize (H12AffineFastState.compose env53245 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53245 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env53246 : List Nat := [2,4,8,1,32,0,34,3,39,3,42,32,15,0,1,2,33,33,34,0,32,12,32,3,4,1,45,32,0,13,2,0,3,39,0,7]

theorem envBound53246 : H12AffineFastState.Bounded env53246 := by
  intro p hp
  have h : env53246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53245_53246 : H12AffineEnvironment.transform 5 0 env53245 = env53246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53245 == env53246) = true)

theorem identity53246 : scanCanonicalize (H12AffineFastState.compose env53246 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53247 : List Nat := [2,4,8,1,0,0,2,3,7,3,10,0,15,0,1,2,1,1,2,0,0,12,0,3,4,1,13,0,0,13,2,0,3,7,0,7]

theorem envBound53247 : H12AffineFastState.Bounded env53247 := by
  intro p hp
  have h : env53247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53246_53247 : H12AffineEnvironment.transform 4 0 env53246 = env53247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53246 == env53247) = true)

theorem identity53247 : scanCanonicalize (H12AffineFastState.compose env53247 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53247 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env53248 : List Nat := [2,3,8,1,0,0,2,3,0,3,10,0,8,0,1,2,1,1,2,0,0,11,0,3,3,1,10,0,0,10,2,0,3,0,0,0]

theorem envBound53248 : H12AffineFastState.Bounded env53248 := by
  intro p hp
  have h : env53248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53247_53248 : H12AffineEnvironment.transform 1 3 env53247 = env53248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53247 == env53248) = true)

def env53249 : List Nat := [2,4,8,1,32,64,128,256,39,320,201,355,8192,64,8525,8204,291,8333,34,8524,355,174,290,8205,8682,0,302,354,64,428,8205,64,256,8490,0,324]

theorem envBound53249 : H12AffineFastState.Bounded env53249 := by
  intro p hp
  have h : env53249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53241_53249 : H12AffineEnvironment.transform 10 201 env53241 = env53249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env53241 == env53249) = true)

theorem identity53249 : scanCanonicalize (H12AffineFastState.compose env53249 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound53249 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53250 : List Nat := [2,4,8,1,32,64,128,256,39,320,201,355,35,64,366,47,291,174,34,367,355,174,290,46,457,0,302,354,64,428,46,64,256,265,0,324]

theorem envBound53250 : H12AffineFastState.Bounded env53250 := by
  intro p hp
  have h : env53250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53249_53250 : H12AffineEnvironment.transform 12 35 env53249 = env53250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env53249 == env53250) = true)

theorem identity53250 : scanCanonicalize (H12AffineFastState.compose env53250 (packedSelected [2,4,5,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound53250 : packedSelected [2,4,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env53251 : List Nat := [2,4,8,1,32,64,128,34,39,98,201,65,35,64,76,47,1,174,34,77,65,174,0,46,235,0,12,64,64,142,46,64,34,43,0,102]

theorem envBound53251 : H12AffineFastState.Bounded env53251 := by
  intro p hp
  have h : env53251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53250_53251 : H12AffineEnvironment.transform 7 34 env53250 = env53251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env53250 == env53251) = true)

theorem identity53251 : scanCanonicalize (H12AffineFastState.compose env53251 (packedSelected [2,4,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound53251 : packedSelected [2,4,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53252 : List Nat := [2,4,8,1,32,64,66,34,39,98,11,65,35,64,76,47,1,108,34,77,65,108,0,46,41,0,12,64,64,76,46,64,34,43,0,102]

theorem envBound53252 : H12AffineFastState.Bounded env53252 := by
  intro p hp
  have h : env53252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53251_53252 : H12AffineEnvironment.transform 6 66 env53251 = env53252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env53251 == env53252) = true)

theorem identity53252 : scanCanonicalize (H12AffineFastState.compose env53252 (packedSelected [1,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound53252 : packedSelected [1,7,9] rootPS < 2^1333 := by decide +kernel

def env53253 : List Nat := [2,4,8,1,32,32,34,34,39,2,11,33,35,32,44,47,1,12,34,45,33,12,0,46,41,0,12,32,32,44,46,32,34,43,0,6]

theorem envBound53253 : H12AffineFastState.Bounded env53253 := by
  intro p hp
  have h : env53253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53252_53253 : H12AffineEnvironment.transform 5 32 env53252 = env53253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env53252 == env53253) = true)

theorem identity53253 : scanCanonicalize (H12AffineFastState.compose env53253 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53253 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53254 : List Nat := [2,4,8,1,7,7,5,5,0,2,11,6,4,7,11,8,1,12,5,10,6,12,0,9,14,0,12,7,7,11,9,7,5,12,0,6]

theorem envBound53254 : H12AffineFastState.Bounded env53254 := by
  intro p hp
  have h : env53254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53253_53254 : H12AffineEnvironment.transform 4 7 env53253 = env53254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53253 == env53254) = true)

theorem identity53254 : scanCanonicalize (H12AffineFastState.compose env53254 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53254 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53255 : List Nat := [2,4,4,1,7,7,5,5,0,2,7,6,4,7,7,4,1,0,5,6,6,0,0,5,2,0,0,7,7,7,5,7,5,0,0,6]

theorem envBound53255 : H12AffineFastState.Bounded env53255 := by
  intro p hp
  have h : env53255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53254_53255 : H12AffineEnvironment.transform 2 4 env53254 = env53255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53254 == env53255) = true)

theorem identity53255 : scanCanonicalize (H12AffineFastState.compose env53255 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53256 : List Nat := [2,2,2,1,1,1,3,3,0,2,1,0,2,1,1,2,1,0,3,0,0,0,0,3,2,0,0,1,1,1,3,1,3,0,0,0]

theorem envBound53256 : H12AffineFastState.Bounded env53256 := by
  intro p hp
  have h : env53256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53255_53256 : H12AffineEnvironment.transform 1 2 env53255 = env53256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53255 == env53256) = true)

def env53257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123165,28889,78894,385203,90414,1296,96347,25884,1280,256,82998,1344,21072]

theorem envBound53257 : H12AffineFastState.Bounded env53257 := by
  intro p hp
  have h : env53257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53002_53257 : H12AffineEnvironment.transform 18 21585 env53002 = env53257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env53002 == env53257) = true)

theorem identity53257 : scanCanonicalize (H12AffineFastState.compose env53257 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound53257 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4096,17612,91182,87296,28889,78894,349358,90414,1296,96347,25884,1280,256,82998,1344,21072]

theorem envBound53258 : H12AffineFastState.Bounded env53258 := by
  intro p hp
  have h : env53258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53257_53258 : H12AffineEnvironment.transform 14 13341 env53257 = env53258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env53257 == env53258) = true)

def env53259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4096,476,74046,69648,13769,78894,332222,74814,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound53259 : H12AffineFastState.Bounded env53259 := by
  intro p hp
  have h : env53259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53258_53259 : H12AffineEnvironment.transform 13 1296 env53258 = env53259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53258 == env53259) = true)

def env53260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4096,476,74046,69648,13769,78894,4414,74814,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound53260 : H12AffineFastState.Bounded env53260 := by
  intro p hp
  have h : env53260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53259_53260 : H12AffineEnvironment.transform 17 65664 env53259 = env53260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53259 == env53260) = true)

theorem identity53260 : scanCanonicalize (H12AffineFastState.compose env53260 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound53260 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4096,476,65911,69648,5504,70759,4414,66679,1296,72962,69,1280,256,65830,1344,5952]

theorem envBound53261 : H12AffineFastState.Bounded env53261 := by
  intro p hp
  have h : env53261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53260_53261 : H12AffineEnvironment.transform 12 73 env53260 = env53261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env53260 == env53261) = true)

def env53262 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4096,476,65911,69648,5504,70759,4414,66679,1296,72962,69,1280,256,65830,1344,5140]

theorem envBound53262 : H12AffineFastState.Bounded env53262 := by
  intro p hp
  have h : env53262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53261_53262 : H12AffineEnvironment.transform 8 340 env53261 = env53262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53261 == env53262) = true)

def env53263 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4372,65536,65894,65664,4417,4373,4096,476,65911,69648,4288,69927,4414,65847,80,71746,69,64,256,65830,0,4436]

theorem envBound53263 : H12AffineFastState.Bounded env53263 := by
  intro p hp
  have h : env53263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53262_53263 : H12AffineEnvironment.transform 9 320 env53262 = env53263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53262 == env53263) = true)

theorem identity53263 : scanCanonicalize (H12AffineFastState.compose env53263 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53263 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53264 : List Nat := [2,4,8,16,32,64,128,21,65,85,2048,4096,73,80,4097,65536,65651,65664,4180,4096,4096,201,65634,69648,4288,69682,4139,65570,80,71746,69,64,21,65587,0,4161]

theorem envBound53264 : H12AffineFastState.Bounded env53264 := by
  intro p hp
  have h : env53264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53263_53264 : H12AffineEnvironment.transform 7 21 env53263 = env53264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53263 == env53264) = true)

theorem identity53264 : scanCanonicalize (H12AffineFastState.compose env53264 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2226) := by decide +kernel

theorem selectedBound53264 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env53265 : List Nat := [2,4,8,16,32,64,128,21,65,85,2048,2226,73,80,2227,65536,65651,65664,2278,2226,2226,201,65634,67746,2162,67712,2201,65570,80,65776,69,64,21,65587,0,2291]

theorem envBound53265 : H12AffineFastState.Bounded env53265 := by
  intro p hp
  have h : env53265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53264_53265 : H12AffineEnvironment.transform 11 2226 env53264 = env53265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2226 env53264 == env53265) = true)

theorem identity53265 : scanCanonicalize (H12AffineFastState.compose env53265 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound53265 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env53266 : List Nat := [2,4,8,16,32,64,128,21,65,85,2048,2226,73,80,2227,115,0,243,2278,2226,2226,201,17,2257,2162,2291,2201,81,80,131,69,64,21,64,0,2291]

theorem envBound53266 : H12AffineFastState.Bounded env53266 := by
  intro p hp
  have h : env53266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53265_53266 : H12AffineEnvironment.transform 15 115 env53265 = env53266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env53265 == env53266) = true)

theorem identity53266 : scanCanonicalize (H12AffineFastState.compose env53266 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound53266 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53267 : List Nat := [2,4,8,12,32,64,128,9,65,73,2048,2222,73,76,2223,111,0,239,2278,2222,2222,201,13,2253,2158,2287,2181,77,76,131,69,64,9,64,0,2287]

theorem envBound53267 : H12AffineFastState.Bounded env53267 := by
  intro p hp
  have h : env53267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53266_53267 : H12AffineEnvironment.transform 3 12 env53266 = env53267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env53266 == env53267) = true)

theorem identity53267 : scanCanonicalize (H12AffineFastState.compose env53267 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound53267 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53268 : List Nat := [2,4,8,12,32,64,128,9,65,73,96,206,73,76,207,111,0,239,134,206,206,201,13,173,14,143,229,77,76,131,69,64,9,64,0,143]

theorem envBound53268 : H12AffineFastState.Bounded env53268 := by
  intro p hp
  have h : env53268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53267_53268 : H12AffineEnvironment.transform 10 96 env53267 = env53268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env53267 == env53268) = true)

theorem identity53268 : scanCanonicalize (H12AffineFastState.compose env53268 (packedSelected [2,5,8,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound53268 : packedSelected [2,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env53269 : List Nat := [2,4,8,12,32,12,128,9,13,5,44,130,5,0,131,35,0,163,134,130,130,133,13,173,14,143,169,1,0,131,9,12,9,12,0,143]

theorem envBound53269 : H12AffineFastState.Bounded env53269 := by
  intro p hp
  have h : env53269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53268_53269 : H12AffineEnvironment.transform 5 12 env53268 = env53269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env53268 == env53269) = true)

theorem identity53269 : scanCanonicalize (H12AffineFastState.compose env53269 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound53269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53270 : List Nat := [2,4,8,12,32,12,41,9,13,5,44,43,5,0,42,35,0,10,47,43,43,44,13,4,14,38,0,1,0,42,9,12,9,12,0,38]

theorem envBound53270 : H12AffineFastState.Bounded env53270 := by
  intro p hp
  have h : env53270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53269_53270 : H12AffineEnvironment.transform 6 41 env53269 = env53270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env53269 == env53270) = true)

def env53271 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4373,65536,65895,65664,4417,4372,4096,476,65911,69648,4289,69926,4414,65846,81,71747,69,65,256,65830,1,4437]

theorem envBound53271 : H12AffineFastState.Bounded env53271 := by
  intro p hp
  have h : env53271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53262_53271 : H12AffineEnvironment.transform 9 321 env53262 = env53271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53262 == env53271) = true)

theorem identity53271 : scanCanonicalize (H12AffineFastState.compose env53271 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound53271 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53272 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,73,81,1,65536,65895,65664,85,0,276,476,65911,65796,469,65586,42,65846,81,67927,69,65,256,65830,1,65]

theorem envBound53272 : H12AffineFastState.Bounded env53272 := by
  intro p hp
  have h : env53272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53271_53272 : H12AffineEnvironment.transform 11 276 env53271 = env53272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env53271 == env53272) = true)

theorem identity53272 : scanCanonicalize (H12AffineFastState.compose env53272 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2365) := by decide +kernel

theorem selectedBound53272 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env53273 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,73,81,1,2365,2138,2493,85,0,276,476,2122,2105,469,2319,42,2059,81,106,69,65,256,2075,1,65]

theorem envBound53273 : H12AffineFastState.Bounded env53273 := by
  intro p hp
  have h : env53273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53272_53273 : H12AffineEnvironment.transform 15 2365 env53272 = env53273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2365 env53272 == env53273) = true)

theorem identity53273 : scanCanonicalize (H12AffineFastState.compose env53273 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53273 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53274 : List Nat := [2,4,8,16,32,64,128,256,340,321,10,276,73,81,1,311,80,439,85,0,276,476,64,51,469,261,42,1,81,106,69,65,256,17,1,65]

theorem envBound53274 : H12AffineFastState.Bounded env53274 := by
  intro p hp
  have h : env53274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53273_53274 : H12AffineEnvironment.transform 10 10 env53273 = env53274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53273 == env53274) = true)

theorem identity53274 : scanCanonicalize (H12AffineFastState.compose env53274 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 247) := by decide +kernel

theorem selectedBound53274 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env53275 : List Nat := [2,4,8,16,32,64,128,247,163,182,10,227,73,81,1,192,80,64,85,0,227,43,64,51,34,242,42,1,81,106,69,65,247,17,1,65]

theorem envBound53275 : H12AffineFastState.Bounded env53275 := by
  intro p hp
  have h : env53275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53274_53275 : H12AffineEnvironment.transform 7 247 env53274 = env53275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 247 env53274 == env53275) = true)

theorem identity53275 : scanCanonicalize (H12AffineFastState.compose env53275 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 79) := by decide +kernel

theorem selectedBound53275 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53276 : List Nat := [2,4,8,16,32,64,79,56,108,121,10,44,73,81,1,15,80,64,85,0,44,43,64,51,34,61,42,1,81,106,69,65,56,17,1,65]

theorem envBound53276 : H12AffineFastState.Bounded env53276 := by
  intro p hp
  have h : env53276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53275_53276 : H12AffineEnvironment.transform 6 79 env53275 = env53276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 79 env53275 == env53276) = true)

theorem identity53276 : scanCanonicalize (H12AffineFastState.compose env53276 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53276 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env53277 : List Nat := [2,4,8,16,10,64,79,18,70,83,10,6,73,81,1,15,80,64,85,0,6,1,64,25,8,23,0,1,81,64,69,65,18,17,1,65]

theorem envBound53277 : H12AffineFastState.Bounded env53277 := by
  intro p hp
  have h : env53277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53276_53277 : H12AffineEnvironment.transform 4 10 env53276 = env53277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53276 == env53277) = true)

theorem identity53277 : scanCanonicalize (H12AffineFastState.compose env53277 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53277 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53278 : List Nat := [2,4,5,16,7,64,66,18,70,83,7,6,68,81,1,2,80,64,85,0,6,1,64,20,5,23,0,1,81,64,69,65,18,17,1,65]

theorem envBound53278 : H12AffineFastState.Bounded env53278 := by
  intro p hp
  have h : env53278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53277_53278 : H12AffineEnvironment.transform 2 5 env53277 = env53278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53277 == env53278) = true)

theorem identity53278 : scanCanonicalize (H12AffineFastState.compose env53278 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53278 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53279 : List Nat := [2,4,5,0,7,64,66,2,70,67,7,6,68,65,1,2,64,64,69,0,6,1,64,4,5,7,0,1,65,64,69,65,2,1,1,65]

theorem envBound53279 : H12AffineFastState.Bounded env53279 := by
  intro p hp
  have h : env53279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53278_53279 : H12AffineEnvironment.transform 3 0 env53278 = env53279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53278 == env53279) = true)

def env53280 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1296,5204,65536,66598,65664,4417,5205,4096,476,65911,69648,5504,70759,4414,66679,1296,72962,69,1280,256,65830,1344,5141]

theorem envBound53280 : H12AffineFastState.Bounded env53280 := by
  intro p hp
  have h : env53280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53261_53280 : H12AffineEnvironment.transform 8 341 env53261 = env53280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env53261 == env53280) = true)

def env53281 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4372,65536,65894,65664,4417,4373,4096,476,65911,69648,4288,69927,4414,65847,80,71746,69,64,256,65830,0,4437]

theorem envBound53281 : H12AffineFastState.Bounded env53281 := by
  intro p hp
  have h : env53281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53280_53281 : H12AffineEnvironment.transform 9 320 env53280 = env53281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53280 == env53281) = true)

theorem identity53281 : scanCanonicalize (H12AffineFastState.compose env53281 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53281 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53282 : List Nat := [2,4,8,16,32,64,128,21,64,85,2048,4096,73,80,4097,65536,65651,65664,4180,4096,4096,201,65634,69648,4288,69682,4139,65570,80,71746,69,64,21,65587,0,4160]

theorem envBound53282 : H12AffineFastState.Bounded env53282 := by
  intro p hp
  have h : env53282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53281_53282 : H12AffineEnvironment.transform 7 21 env53281 = env53282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53281 == env53282) = true)

theorem identity53282 : scanCanonicalize (H12AffineFastState.compose env53282 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2227) := by decide +kernel

theorem selectedBound53282 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env53283 : List Nat := [2,4,8,16,32,64,128,21,64,85,2048,2227,73,80,2226,65536,65651,65664,2279,2227,2227,201,65634,67747,2163,67713,2200,65570,80,65777,69,64,21,65587,0,2291]

theorem envBound53283 : H12AffineFastState.Bounded env53283 := by
  intro p hp
  have h : env53283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53282_53283 : H12AffineEnvironment.transform 11 2227 env53282 = env53283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2227 env53282 == env53283) = true)

theorem identity53283 : scanCanonicalize (H12AffineFastState.compose env53283 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound53283 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env53284 : List Nat := [2,4,8,16,32,64,128,21,64,85,2048,2227,73,80,2226,115,0,243,2279,2227,2227,201,17,2256,2163,2290,2200,81,80,130,69,64,21,64,0,2291]

theorem envBound53284 : H12AffineFastState.Bounded env53284 := by
  intro p hp
  have h : env53284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53283_53284 : H12AffineEnvironment.transform 15 115 env53283 = env53284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env53283 == env53284) = true)

theorem identity53284 : scanCanonicalize (H12AffineFastState.compose env53284 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound53284 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53285 : List Nat := [2,4,8,12,32,64,128,9,64,73,2048,2223,73,76,2222,111,0,239,2279,2223,2223,201,13,2252,2159,2286,2180,77,76,130,69,64,9,64,0,2287]

theorem envBound53285 : H12AffineFastState.Bounded env53285 := by
  intro p hp
  have h : env53285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53284_53285 : H12AffineEnvironment.transform 3 12 env53284 = env53285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env53284 == env53285) = true)

theorem identity53285 : scanCanonicalize (H12AffineFastState.compose env53285 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound53285 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53286 : List Nat := [2,4,8,12,32,64,128,9,64,73,96,207,73,76,206,111,0,239,135,207,207,201,13,172,15,142,228,77,76,130,69,64,9,64,0,143]

theorem envBound53286 : H12AffineFastState.Bounded env53286 := by
  intro p hp
  have h : env53286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53285_53286 : H12AffineEnvironment.transform 10 96 env53285 = env53286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env53285 == env53286) = true)

theorem identity53286 : scanCanonicalize (H12AffineFastState.compose env53286 (packedSelected [2,5,8,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound53286 : packedSelected [2,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env53287 : List Nat := [2,4,8,12,32,64,3,9,64,73,96,76,73,76,77,111,0,108,4,76,76,74,13,47,15,13,103,77,76,1,69,64,9,64,0,12]

theorem envBound53287 : H12AffineFastState.Bounded env53287 := by
  intro p hp
  have h : env53287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53286_53287 : H12AffineEnvironment.transform 6 3 env53286 = env53287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env53286 == env53287) = true)

theorem identity53287 : scanCanonicalize (H12AffineFastState.compose env53287 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53287 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53288 : List Nat := [2,4,8,12,32,1,3,9,1,8,33,13,8,13,12,46,0,45,4,13,13,11,13,47,15,13,38,12,13,1,4,1,9,1,0,12]

theorem envBound53288 : H12AffineFastState.Bounded env53288 := by
  intro p hp
  have h : env53288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53287_53288 : H12AffineEnvironment.transform 5 1 env53287 = env53288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53287 == env53288) = true)

theorem identity53288 : scanCanonicalize (H12AffineFastState.compose env53288 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53288 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53289 : List Nat := [2,4,4,0,32,1,3,5,1,4,33,1,4,1,0,34,0,33,4,1,1,7,1,35,3,1,38,0,1,1,4,1,5,1,0,0]

theorem envBound53289 : H12AffineFastState.Bounded env53289 := by
  intro p hp
  have h : env53289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53288_53289 : H12AffineEnvironment.transform 2 4 env53288 = env53289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53288 == env53289) = true)

theorem identity53289 : scanCanonicalize (H12AffineFastState.compose env53289 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound53289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53290 : List Nat := [2,4,4,0,5,1,3,5,1,4,4,1,4,1,0,7,0,4,4,1,1,7,1,6,3,1,3,0,1,1,4,1,5,1,0,0]

theorem envBound53290 : H12AffineFastState.Bounded env53290 := by
  intro p hp
  have h : env53290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53289_53290 : H12AffineEnvironment.transform 4 5 env53289 = env53290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env53289 == env53290) = true)

theorem identity53290 : scanCanonicalize (H12AffineFastState.compose env53290 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53290 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53291 : List Nat := [1,4,4,0,5,1,0,5,1,4,4,1,4,1,0,4,0,4,4,1,1,4,1,5,0,1,0,0,1,1,4,1,5,1,0,0]

theorem envBound53291 : H12AffineFastState.Bounded env53291 := by
  intro p hp
  have h : env53291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53290_53291 : H12AffineEnvironment.transform 0 1 env53290 = env53291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53290 == env53291) = true)

theorem identity53291 : scanCanonicalize (H12AffineFastState.compose env53291 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53292 : List Nat := [1,0,0,0,1,1,0,1,1,0,0,1,0,1,0,0,0,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,1,1,0,0]

theorem envBound53292 : H12AffineFastState.Bounded env53292 := by
  intro p hp
  have h : env53292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53291_53292 : H12AffineEnvironment.transform 1 0 env53291 = env53292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53291 == env53292) = true)

def env53293 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4373,65536,65895,65664,4417,4372,4096,476,65911,69648,4289,69926,4414,65846,81,71747,69,65,256,65830,1,4436]

theorem envBound53293 : H12AffineFastState.Bounded env53293 := by
  intro p hp
  have h : env53293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53280_53293 : H12AffineEnvironment.transform 9 321 env53280 = env53293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53280 == env53293) = true)

theorem identity53293 : scanCanonicalize (H12AffineFastState.compose env53293 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound53293 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53294 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,73,81,1,65536,65895,65664,85,0,276,476,65911,65796,469,65586,42,65846,81,67927,69,65,256,65830,1,64]

theorem envBound53294 : H12AffineFastState.Bounded env53294 := by
  intro p hp
  have h : env53294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53293_53294 : H12AffineEnvironment.transform 11 276 env53293 = env53294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env53293 == env53294) = true)

theorem identity53294 : scanCanonicalize (H12AffineFastState.compose env53294 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2364) := by decide +kernel

theorem selectedBound53294 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env53295 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,73,81,1,2364,2139,2492,85,0,276,476,2123,2104,469,2318,42,2058,81,107,69,65,256,2074,1,64]

theorem envBound53295 : H12AffineFastState.Bounded env53295 := by
  intro p hp
  have h : env53295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53294_53295 : H12AffineEnvironment.transform 15 2364 env53294 = env53295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2364 env53294 == env53295) = true)

theorem identity53295 : scanCanonicalize (H12AffineFastState.compose env53295 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound53295 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53296 : List Nat := [2,4,8,16,32,64,128,256,341,321,11,276,73,81,1,311,80,439,85,0,276,476,64,51,469,261,42,1,81,107,69,65,256,17,1,64]

theorem envBound53296 : H12AffineFastState.Bounded env53296 := by
  intro p hp
  have h : env53296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53295_53296 : H12AffineEnvironment.transform 10 11 env53295 = env53296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env53295 == env53296) = true)

theorem identity53296 : scanCanonicalize (H12AffineFastState.compose env53296 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound53296 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env53297 : List Nat := [2,4,8,16,32,64,99,256,341,321,11,276,73,81,1,311,80,340,85,0,276,319,64,51,310,261,42,1,81,107,69,65,256,17,1,64]

theorem envBound53297 : H12AffineFastState.Bounded env53297 := by
  intro p hp
  have h : env53297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53296_53297 : H12AffineEnvironment.transform 6 99 env53296 = env53297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env53296 == env53297) = true)

theorem identity53297 : scanCanonicalize (H12AffineFastState.compose env53297 (packedSelected [1,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound53297 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env53298 : List Nat := [2,4,8,16,32,12,47,256,281,269,11,276,5,29,1,311,28,280,25,0,276,319,12,51,310,261,42,1,29,39,9,13,256,17,1,12]

theorem envBound53298 : H12AffineFastState.Bounded env53298 := by
  intro p hp
  have h : env53298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53297_53298 : H12AffineEnvironment.transform 5 12 env53297 = env53298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env53297 == env53298) = true)

theorem identity53298 : scanCanonicalize (H12AffineFastState.compose env53298 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound53298 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env53299 : List Nat := [2,4,8,16,32,12,47,63,38,50,11,43,5,29,1,8,28,39,25,0,43,0,12,51,9,58,42,1,29,39,9,13,63,17,1,12]

theorem envBound53299 : H12AffineFastState.Bounded env53299 := by
  intro p hp
  have h : env53299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53298_53299 : H12AffineEnvironment.transform 7 63 env53298 = env53299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env53298 == env53299) = true)

theorem identity53299 : scanCanonicalize (H12AffineFastState.compose env53299 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53299 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53300 : List Nat := [2,4,3,16,32,7,36,52,38,50,0,32,5,22,1,3,23,39,18,0,32,0,7,51,2,49,33,1,22,39,2,6,52,17,1,7]

theorem envBound53300 : H12AffineFastState.Bounded env53300 := by
  intro p hp
  have h : env53300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53299_53300 : H12AffineEnvironment.transform 2 3 env53299 = env53300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53299 == env53300) = true)

theorem identity53300 : scanCanonicalize (H12AffineFastState.compose env53300 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53300 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53301 : List Nat := [2,4,3,16,0,7,4,20,6,18,0,0,5,22,1,3,23,7,18,0,0,0,7,19,2,17,1,1,22,7,2,6,20,17,1,7]

theorem envBound53301 : H12AffineFastState.Bounded env53301 := by
  intro p hp
  have h : env53301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53300_53301 : H12AffineEnvironment.transform 4 0 env53300 = env53301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53300 == env53301) = true)

theorem identity53301 : scanCanonicalize (H12AffineFastState.compose env53301 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53302 : List Nat := [2,2,3,16,0,1,2,18,0,18,0,0,3,16,1,3,17,1,18,0,0,0,1,19,2,17,1,1,16,1,2,0,18,17,1,1]

theorem envBound53302 : H12AffineFastState.Bounded env53302 := by
  intro p hp
  have h : env53302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53301_53302 : H12AffineEnvironment.transform 1 2 env53301 = env53302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53301 == env53302) = true)

theorem identity53302 : scanCanonicalize (H12AffineFastState.compose env53302 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound53302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53303 : List Nat := [2,2,3,3,0,1,2,1,0,1,0,0,3,3,1,3,2,1,1,0,0,0,1,0,2,2,1,1,3,1,2,0,1,2,1,1]

theorem envBound53303 : H12AffineFastState.Bounded env53303 := by
  intro p hp
  have h : env53303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53302_53303 : H12AffineEnvironment.transform 3 3 env53302 = env53303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env53302 == env53303) = true)

theorem identity53303 : scanCanonicalize (H12AffineFastState.compose env53303 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53304 : List Nat := [0,0,1,1,0,1,0,1,0,1,0,0,1,1,1,1,0,1,1,0,0,0,1,0,0,0,1,1,1,1,0,0,1,0,1,1]

theorem envBound53304 : H12AffineFastState.Bounded env53304 := by
  intro p hp
  have h : env53304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53303_53304 : H12AffineEnvironment.transform 0 0 env53303 = env53304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53303 == env53304) = true)

def env53305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4096,476,74046,69648,13769,78894,4415,74814,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound53305 : H12AffineFastState.Bounded env53305 := by
  intro p hp
  have h : env53305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53259_53305 : H12AffineEnvironment.transform 17 65665 env53259 = env53305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53259 == env53305) = true)

theorem identity53305 : scanCanonicalize (H12AffineFastState.compose env53305 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound53305 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4096,476,70710,69648,193,65830,4415,69942,1296,67651,5380,1280,256,65830,1344,5952]

theorem envBound53306 : H12AffineFastState.Bounded env53306 := by
  intro p hp
  have h : env53306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53305_53306 : H12AffineEnvironment.transform 12 5384 env53305 = env53306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env53305 == env53306) = true)

def env53307 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4096,476,70710,69648,193,65830,4415,69942,1296,67651,5380,1280,256,65830,1344,5140]

theorem envBound53307 : H12AffineFastState.Bounded env53307 := by
  intro p hp
  have h : env53307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53306_53307 : H12AffineEnvironment.transform 8 340 env53306 = env53307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53306 == env53307) = true)

def env53308 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,277,65536,65895,65665,321,276,0,476,66614,65552,193,65830,319,65846,1296,67651,1284,1280,256,65830,1344,1044]

theorem envBound53308 : H12AffineFastState.Bounded env53308 := by
  intro p hp
  have h : env53308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53307_53308 : H12AffineEnvironment.transform 11 0 env53307 = env53308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53307 == env53308) = true)

theorem identity53308 : scanCanonicalize (H12AffineFastState.compose env53308 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53308 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53309 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,0,1052,1028,1,65536,65651,65665,85,0,0,200,66614,65552,193,65586,43,65570,1028,67651,1040,1044,20,65586,1108,1044]

theorem envBound53309 : H12AffineFastState.Bounded env53309 := by
  intro p hp
  have h : env53309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53308_53309 : H12AffineEnvironment.transform 7 20 env53308 = env53309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53308 == env53309) = true)

theorem identity53309 : scanCanonicalize (H12AffineFastState.compose env53309 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound53309 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53310 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,0,1052,1028,1,1142,1029,1271,85,0,0,200,64,1126,193,1092,43,1108,1028,3125,1040,1044,20,1092,1108,1044]

theorem envBound53310 : H12AffineFastState.Bounded env53310 := by
  intro p hp
  have h : env53310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53309_53310 : H12AffineEnvironment.transform 15 1142 env53309 = env53310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env53309 == env53310) = true)

theorem identity53310 : scanCanonicalize (H12AffineFastState.compose env53310 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound53310 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53311 : List Nat := [2,4,8,16,32,64,5,20,64,1024,2048,0,1052,1028,1,1142,1029,1138,85,0,0,77,64,1126,68,1092,43,1108,1028,3125,1040,1044,20,1092,1108,1044]

theorem envBound53311 : H12AffineFastState.Bounded env53311 := by
  intro p hp
  have h : env53311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53310_53311 : H12AffineEnvironment.transform 6 5 env53310 = env53311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env53310 == env53311) = true)

theorem identity53311 : scanCanonicalize (H12AffineFastState.compose env53311 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound53311 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env53312 : List Nat := [2,4,8,16,32,39,5,20,39,1024,2048,0,1052,1028,1,1041,1029,1045,50,0,0,42,39,1025,35,1059,43,1075,1028,3125,1040,1044,20,1059,1075,1044]

theorem envBound53312 : H12AffineFastState.Bounded env53312 := by
  intro p hp
  have h : env53312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53311_53312 : H12AffineEnvironment.transform 5 39 env53311 = env53312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env53311 == env53312) = true)

theorem identity53312 : scanCanonicalize (H12AffineFastState.compose env53312 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 51) := by decide +kernel

theorem selectedBound53312 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53313 : List Nat := [2,4,8,16,32,39,5,20,39,51,2048,0,47,55,1,34,54,38,50,0,0,42,39,50,35,16,43,0,55,2054,35,39,20,16,0,39]

theorem envBound53313 : H12AffineFastState.Bounded env53313 := by
  intro p hp
  have h : env53313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53312_53313 : H12AffineEnvironment.transform 9 51 env53312 = env53313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 51 env53312 == env53313) = true)

theorem identity53313 : scanCanonicalize (H12AffineFastState.compose env53313 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound53313 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53314 : List Nat := [2,4,8,16,32,39,5,20,39,51,28,0,47,55,1,34,54,38,50,0,0,42,39,50,35,16,43,0,55,26,35,39,20,16,0,39]

theorem envBound53314 : H12AffineFastState.Bounded env53314 := by
  intro p hp
  have h : env53314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53313_53314 : H12AffineEnvironment.transform 10 28 env53313 = env53314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env53313 == env53314) = true)

theorem identity53314 : scanCanonicalize (H12AffineFastState.compose env53314 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53314 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env53315 : List Nat := [2,4,8,16,0,7,5,20,7,19,28,0,15,23,1,2,22,6,18,0,0,10,7,18,3,16,11,0,23,26,3,7,20,16,0,7]

theorem envBound53315 : H12AffineFastState.Bounded env53315 := by
  intro p hp
  have h : env53315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53314_53315 : H12AffineEnvironment.transform 4 0 env53314 = env53315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53314 == env53315) = true)

theorem identity53315 : scanCanonicalize (H12AffineFastState.compose env53315 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53315 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53316 : List Nat := [2,4,5,16,0,7,5,20,7,19,17,0,2,23,1,2,22,6,18,0,0,7,7,18,3,16,6,0,23,23,3,7,20,16,0,7]

theorem envBound53316 : H12AffineFastState.Bounded env53316 := by
  intro p hp
  have h : env53316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53315_53316 : H12AffineEnvironment.transform 2 5 env53315 = env53316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53315 == env53316) = true)

theorem identity53316 : scanCanonicalize (H12AffineFastState.compose env53316 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53317 : List Nat := [2,2,3,16,0,1,3,18,1,19,17,0,2,17,1,2,16,0,18,0,0,1,1,18,3,16,0,0,17,17,3,1,18,16,0,1]

theorem envBound53317 : H12AffineFastState.Bounded env53317 := by
  intro p hp
  have h : env53317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53316_53317 : H12AffineEnvironment.transform 1 2 env53316 = env53317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53316 == env53317) = true)

def env53318 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,277,65536,65894,65665,320,276,1,476,66615,65553,193,65830,318,65847,1296,67651,1285,1280,256,65830,1344,1045]

theorem envBound53318 : H12AffineFastState.Bounded env53318 := by
  intro p hp
  have h : env53318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53307_53318 : H12AffineEnvironment.transform 11 1 env53307 = env53318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53307 == env53318) = true)

theorem identity53318 : scanCanonicalize (H12AffineFastState.compose env53318 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound53318 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53319 : List Nat := [2,4,8,16,32,64,128,256,340,85,2048,1,348,325,277,65536,65894,65665,320,276,1,476,65634,65553,193,65830,318,65847,325,67651,336,341,256,65830,277,64]

theorem envBound53319 : H12AffineFastState.Bounded env53319 := by
  intro p hp
  have h : env53319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53318_53319 : H12AffineEnvironment.transform 9 85 env53318 = env53319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env53318 == env53319) = true)

theorem identity53319 : scanCanonicalize (H12AffineFastState.compose env53319 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound53319 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env53320 : List Nat := [2,4,8,16,32,64,128,256,340,85,227,1,348,325,277,65536,65894,65665,320,276,1,476,65634,65553,193,65830,318,65847,325,65696,336,341,256,65830,277,64]

theorem envBound53320 : H12AffineFastState.Bounded env53320 := by
  intro p hp
  have h : env53320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53319_53320 : H12AffineEnvironment.transform 10 227 env53319 = env53320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env53319 == env53320) = true)

theorem identity53320 : scanCanonicalize (H12AffineFastState.compose env53320 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound53320 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53321 : List Nat := [2,4,8,16,32,64,128,256,340,85,227,1,348,325,277,8,366,137,320,276,1,476,106,25,193,302,318,319,325,168,336,341,256,302,277,64]

theorem envBound53321 : H12AffineFastState.Bounded env53321 := by
  intro p hp
  have h : env53321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53320_53321 : H12AffineEnvironment.transform 15 8 env53320 = env53321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env53320 == env53321) = true)

theorem identity53321 : scanCanonicalize (H12AffineFastState.compose env53321 (packedSelected [2,4,9,11,16,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound53321 : packedSelected [2,4,9,11,16,17,20] rootPS < 2^1333 := by decide +kernel

def env53322 : List Nat := [2,4,8,16,32,64,128,85,1,85,227,1,9,16,64,8,59,137,21,65,1,137,106,25,193,123,107,106,16,168,5,0,85,123,64,64]

theorem envBound53322 : H12AffineFastState.Bounded env53322 := by
  intro p hp
  have h : env53322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53321_53322 : H12AffineEnvironment.transform 7 85 env53321 = env53322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env53321 == env53322) = true)

theorem identity53322 : scanCanonicalize (H12AffineFastState.compose env53322 (packedSelected [0,1,2,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound53322 : packedSelected [0,1,2,9,10] rootPS < 2^1333 := by decide +kernel

def env53323 : List Nat := [2,4,8,6,32,64,128,67,1,67,227,1,9,6,64,8,45,137,3,65,1,137,106,15,193,109,107,106,6,168,5,0,67,109,64,64]

theorem envBound53323 : H12AffineFastState.Bounded env53323 := by
  intro p hp
  have h : env53323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53322_53323 : H12AffineEnvironment.transform 3 6 env53322 = env53323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env53322 == env53323) = true)

theorem identity53323 : scanCanonicalize (H12AffineFastState.compose env53323 (packedSelected [3,4,5,9,12,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53323 : packedSelected [3,4,5,9,12,13] rootPS < 2^1333 := by decide +kernel

def env53324 : List Nat := [2,3,8,1,32,64,128,67,1,67,227,1,9,1,64,8,42,137,3,65,1,137,106,8,193,106,107,106,1,168,2,0,67,106,64,64]

theorem envBound53324 : H12AffineFastState.Bounded env53324 := by
  intro p hp
  have h : env53324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53323_53324 : H12AffineEnvironment.transform 1 3 env53323 = env53324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53323 == env53324) = true)

theorem identity53324 : scanCanonicalize (H12AffineFastState.compose env53324 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53324 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53325 : List Nat := [2,3,2,1,32,64,128,67,1,67,227,1,3,1,64,2,32,131,3,65,1,131,96,2,193,96,97,96,1,162,2,0,67,96,64,64]

theorem envBound53325 : H12AffineFastState.Bounded env53325 := by
  intro p hp
  have h : env53325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53324_53325 : H12AffineEnvironment.transform 2 2 env53324 = env53325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53324 == env53325) = true)

theorem identity53325 : scanCanonicalize (H12AffineFastState.compose env53325 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound53325 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53326 : List Nat := [2,3,2,1,32,64,67,67,1,67,32,1,3,1,64,2,32,64,3,65,1,64,96,2,2,96,97,96,1,97,2,0,67,96,64,64]

theorem envBound53326 : H12AffineFastState.Bounded env53326 := by
  intro p hp
  have h : env53326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53325_53326 : H12AffineEnvironment.transform 6 67 env53325 = env53326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env53325 == env53326) = true)

def env53327 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1296,277,65536,69991,65665,4417,276,4096,476,70710,69648,193,65830,4415,69942,1296,67651,5380,1280,256,65830,1344,5141]

theorem envBound53327 : H12AffineFastState.Bounded env53327 := by
  intro p hp
  have h : env53327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53306_53327 : H12AffineEnvironment.transform 8 341 env53306 = env53327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env53306 == env53327) = true)

def env53328 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,277,65536,65895,65665,321,276,0,476,66614,65552,193,65830,319,65846,1296,67651,1284,1280,256,65830,1344,1045]

theorem envBound53328 : H12AffineFastState.Bounded env53328 := by
  intro p hp
  have h : env53328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53327_53328 : H12AffineEnvironment.transform 11 0 env53327 = env53328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53327 == env53328) = true)

theorem identity53328 : scanCanonicalize (H12AffineFastState.compose env53328 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53328 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53329 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,0,1052,1028,1,65536,65651,65665,85,0,0,200,66614,65552,193,65586,43,65570,1028,67651,1040,1044,20,65586,1108,1045]

theorem envBound53329 : H12AffineFastState.Bounded env53329 := by
  intro p hp
  have h : env53329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53328_53329 : H12AffineEnvironment.transform 7 20 env53328 = env53329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53328 == env53329) = true)

theorem identity53329 : scanCanonicalize (H12AffineFastState.compose env53329 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound53329 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53330 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,0,1052,1028,1,1142,1029,1271,85,0,0,200,64,1126,193,1092,43,1108,1028,3125,1040,1044,20,1092,1108,1045]

theorem envBound53330 : H12AffineFastState.Bounded env53330 := by
  intro p hp
  have h : env53330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53329_53330 : H12AffineEnvironment.transform 15 1142 env53329 = env53330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env53329 == env53330) = true)

theorem identity53330 : scanCanonicalize (H12AffineFastState.compose env53330 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound53330 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53331 : List Nat := [2,4,8,16,32,64,84,20,65,1024,2048,0,1052,1028,1,1142,1029,1059,85,0,0,28,64,1126,21,1092,43,1108,1028,3125,1040,1044,20,1092,1108,1045]

theorem envBound53331 : H12AffineFastState.Bounded env53331 := by
  intro p hp
  have h : env53331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53330_53331 : H12AffineEnvironment.transform 6 84 env53330 = env53331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env53330 == env53331) = true)

theorem identity53331 : scanCanonicalize (H12AffineFastState.compose env53331 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(9+1) ^^^ 99) := by decide +kernel

theorem selectedBound53331 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env53332 : List Nat := [2,4,8,16,32,64,84,20,65,99,2048,0,127,103,1,21,102,64,85,0,0,28,64,5,21,39,43,55,103,2134,115,119,20,39,55,118]

theorem envBound53332 : H12AffineFastState.Bounded env53332 := by
  intro p hp
  have h : env53332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53331_53332 : H12AffineEnvironment.transform 9 99 env53331 = env53332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 99 env53331 == env53332) = true)

theorem identity53332 : scanCanonicalize (H12AffineFastState.compose env53332 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound53332 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53333 : List Nat := [2,4,8,16,23,64,84,20,65,84,2048,0,72,80,1,21,81,64,85,0,0,28,64,5,21,16,28,0,80,2134,68,64,20,16,0,65]

theorem envBound53333 : H12AffineFastState.Bounded env53333 := by
  intro p hp
  have h : env53333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53332_53333 : H12AffineEnvironment.transform 4 23 env53332 = env53333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env53332 == env53333) = true)

theorem identity53333 : scanCanonicalize (H12AffineFastState.compose env53333 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound53333 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53334 : List Nat := [2,4,8,16,23,64,84,20,65,84,76,0,72,80,1,21,81,64,85,0,0,28,64,5,21,16,28,0,80,26,68,64,20,16,0,65]

theorem envBound53334 : H12AffineFastState.Bounded env53334 := by
  intro p hp
  have h : env53334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53333_53334 : H12AffineEnvironment.transform 10 76 env53333 = env53334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env53333 == env53334) = true)

theorem identity53334 : scanCanonicalize (H12AffineFastState.compose env53334 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound53334 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env53335 : List Nat := [2,4,8,6,1,64,66,2,65,66,76,0,72,70,1,3,71,64,67,0,0,10,64,5,3,6,10,0,70,12,68,64,2,6,0,65]

theorem envBound53335 : H12AffineFastState.Bounded env53335 := by
  intro p hp
  have h : env53335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53334_53335 : H12AffineEnvironment.transform 3 6 env53334 = env53335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env53334 == env53335) = true)

theorem identity53335 : scanCanonicalize (H12AffineFastState.compose env53335 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound53335 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53336 : List Nat := [2,4,8,6,1,10,8,2,11,8,6,0,2,12,1,3,13,10,9,0,0,10,10,5,3,6,10,0,12,12,14,10,2,6,0,11]

theorem envBound53336 : H12AffineFastState.Bounded env53336 := by
  intro p hp
  have h : env53336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53335_53336 : H12AffineEnvironment.transform 5 10 env53335 = env53336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env53335 == env53336) = true)

theorem identity53336 : scanCanonicalize (H12AffineFastState.compose env53336 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53337 : List Nat := [2,4,2,6,1,0,2,2,1,2,6,0,2,6,1,3,7,0,3,0,0,0,0,5,3,6,0,0,6,6,4,0,2,6,0,1]

theorem envBound53337 : H12AffineFastState.Bounded env53337 := by
  intro p hp
  have h : env53337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53336_53337 : H12AffineEnvironment.transform 2 2 env53336 = env53337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53336 == env53337) = true)

def env53338 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,277,65536,65894,65665,320,276,1,476,66615,65553,193,65830,318,65847,1296,67651,1285,1280,256,65830,1344,1044]

theorem envBound53338 : H12AffineFastState.Bounded env53338 := by
  intro p hp
  have h : env53338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53327_53338 : H12AffineEnvironment.transform 11 1 env53327 = env53338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53327 == env53338) = true)

theorem identity53338 : scanCanonicalize (H12AffineFastState.compose env53338 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound53338 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53339 : List Nat := [2,4,8,16,32,64,128,256,341,85,2048,1,348,325,277,65536,65894,65665,320,276,1,476,65634,65553,193,65830,318,65847,325,67651,336,341,256,65830,277,65]

theorem envBound53339 : H12AffineFastState.Bounded env53339 := by
  intro p hp
  have h : env53339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53338_53339 : H12AffineEnvironment.transform 9 85 env53338 = env53339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env53338 == env53339) = true)

theorem identity53339 : scanCanonicalize (H12AffineFastState.compose env53339 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound53339 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env53340 : List Nat := [2,4,8,16,32,64,128,256,341,85,226,1,348,325,277,65536,65894,65665,320,276,1,476,65634,65553,193,65830,318,65847,325,65697,336,341,256,65830,277,65]

theorem envBound53340 : H12AffineFastState.Bounded env53340 := by
  intro p hp
  have h : env53340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53339_53340 : H12AffineEnvironment.transform 10 226 env53339 = env53340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env53339 == env53340) = true)

theorem identity53340 : scanCanonicalize (H12AffineFastState.compose env53340 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound53340 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53341 : List Nat := [2,4,8,16,32,64,128,256,341,85,226,1,348,325,277,8,366,137,320,276,1,476,106,25,193,302,318,319,325,169,336,341,256,302,277,65]

theorem envBound53341 : H12AffineFastState.Bounded env53341 := by
  intro p hp
  have h : env53341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53340_53341 : H12AffineEnvironment.transform 15 8 env53340 = env53341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env53340 == env53341) = true)

theorem identity53341 : scanCanonicalize (H12AffineFastState.compose env53341 (packedSelected [2,4,9,11,16,17,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53341 : packedSelected [2,4,9,11,16,17,20] rootPS < 2^1333 := by decide +kernel

def env53342 : List Nat := [2,4,8,16,32,0,128,256,277,21,162,1,284,261,277,8,302,137,256,276,1,412,42,25,129,302,318,319,261,169,272,277,256,302,277,1]

theorem envBound53342 : H12AffineFastState.Bounded env53342 := by
  intro p hp
  have h : env53342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53341_53342 : H12AffineEnvironment.transform 5 0 env53341 = env53342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53341 == env53342) = true)

theorem identity53342 : scanCanonicalize (H12AffineFastState.compose env53342 (packedSelected [1,3,4,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound53342 : packedSelected [1,3,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env53343 : List Nat := [2,4,8,16,32,0,128,50,39,21,162,1,46,55,39,8,28,137,50,38,1,174,42,25,129,28,12,13,55,169,34,39,50,28,39,1]

theorem envBound53343 : H12AffineFastState.Bounded env53343 := by
  intro p hp
  have h : env53343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53342_53343 : H12AffineEnvironment.transform 7 50 env53342 = env53343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env53342 == env53343) = true)

theorem identity53343 : scanCanonicalize (H12AffineFastState.compose env53343 (packedSelected [3,4,8,9,10,13] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound53343 : packedSelected [3,4,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env53344 : List Nat := [2,4,8,16,23,0,128,5,16,21,149,1,25,0,16,8,28,137,5,17,1,153,29,25,129,28,12,13,0,158,21,16,5,28,16,1]

theorem envBound53344 : H12AffineFastState.Bounded env53344 := by
  intro p hp
  have h : env53344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53343_53344 : H12AffineEnvironment.transform 4 23 env53343 = env53344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env53343 == env53344) = true)

theorem identity53344 : scanCanonicalize (H12AffineFastState.compose env53344 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound53344 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53345 : List Nat := [2,4,8,16,23,0,25,5,16,21,12,1,25,0,16,8,28,16,5,17,1,0,29,25,24,28,12,13,0,7,21,16,5,28,16,1]

theorem envBound53345 : H12AffineFastState.Bounded env53345 := by
  intro p hp
  have h : env53345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53344_53345 : H12AffineEnvironment.transform 6 25 env53344 = env53345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env53344 == env53345) = true)

theorem identity53345 : scanCanonicalize (H12AffineFastState.compose env53345 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53345 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53346 : List Nat := [2,4,5,16,23,0,20,5,16,21,1,1,20,0,16,5,17,16,5,17,1,0,16,20,21,17,1,0,0,7,21,16,5,17,16,1]

theorem envBound53346 : H12AffineFastState.Bounded env53346 := by
  intro p hp
  have h : env53346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53345_53346 : H12AffineEnvironment.transform 2 5 env53345 = env53346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53345 == env53346) = true)

def env53347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4096,477,74047,69649,13768,78894,332223,74815,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound53347 : H12AffineFastState.Bounded env53347 := by
  intro p hp
  have h : env53347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53258_53347 : H12AffineEnvironment.transform 13 1297 env53258 = env53347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53258 == env53347) = true)

def env53348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4096,477,74047,69649,13768,78894,4415,74815,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound53348 : H12AffineFastState.Bounded env53348 := by
  intro p hp
  have h : env53348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53347_53348 : H12AffineEnvironment.transform 17 65664 env53347 = env53348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53347 == env53348) = true)

theorem identity53348 : scanCanonicalize (H12AffineFastState.compose env53348 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53348 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,1,477,74047,65552,9673,74799,318,74815,1296,77131,8205,1280,256,65831,1344,1856]

theorem envBound53349 : H12AffineFastState.Bounded env53349 := by
  intro p hp
  have h : env53349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53348_53349 : H12AffineEnvironment.transform 11 1 env53348 = env53349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53348 == env53349) = true)

def env53350 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,1,477,74047,65552,9673,74799,318,74815,1296,77131,8205,1280,256,65831,1344,1044]

theorem envBound53350 : H12AffineFastState.Bounded env53350 := by
  intro p hp
  have h : env53350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53349_53350 : H12AffineEnvironment.transform 8 340 env53349 = env53350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53349 == env53350) = true)

def env53351 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9228,65536,74863,65664,321,9229,1,461,74031,65536,9673,74799,302,74799,1280,77131,8205,1280,256,65831,1344,1028]

theorem envBound53351 : H12AffineFastState.Bounded env53351 := by
  intro p hp
  have h : env53351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53350_53351 : H12AffineEnvironment.transform 3 0 env53350 = env53351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53350 == env53351) = true)

theorem identity53351 : scanCanonicalize (H12AffineFastState.compose env53351 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound53351 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53352 : List Nat := [2,4,8,0,32,64,110,256,324,1024,2048,1,8192,1281,9228,65536,74863,65646,321,9229,1,291,74031,65536,9511,74799,302,74799,1280,77131,8205,1280,256,65831,1344,1028]

theorem envBound53352 : H12AffineFastState.Bounded env53352 := by
  intro p hp
  have h : env53352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53351_53352 : H12AffineEnvironment.transform 6 110 env53351 = env53352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env53351 == env53352) = true)

def env53353 : List Nat := [2,4,8,0,32,64,110,256,324,1024,2048,1,8192,1281,9228,1056,8271,1102,321,9229,1,291,9487,1056,9511,8207,302,8207,1280,10603,8205,1280,256,1287,1344,1028]

theorem envBound53353 : H12AffineFastState.Bounded env53353 := by
  intro p hp
  have h : env53353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53352_53353 : H12AffineEnvironment.transform 15 1056 env53352 = env53353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env53352 == env53353) = true)

theorem identity53353 : scanCanonicalize (H12AffineFastState.compose env53353 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound53353 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env53354 : List Nat := [2,4,8,0,32,64,110,256,324,3,2048,1,8192,258,8207,35,8271,77,321,8206,1,291,8460,35,8484,8207,302,8207,259,10603,8205,259,256,260,323,7]

theorem envBound53354 : H12AffineFastState.Bounded env53354 := by
  intro p hp
  have h : env53354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53353_53354 : H12AffineEnvironment.transform 9 3 env53353 = env53354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env53353 == env53354) = true)

theorem identity53354 : scanCanonicalize (H12AffineFastState.compose env53354 (packedSelected [1,3,5,12,15,17,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 2337) := by decide +kernel

theorem selectedBound53354 : packedSelected [1,3,5,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env53355 : List Nat := [2,4,8,0,32,64,110,256,324,3,2048,1,2337,258,2350,35,2414,77,321,2351,1,291,2093,35,2053,2350,302,2350,259,74,2348,259,256,260,323,7]

theorem envBound53355 : H12AffineFastState.Bounded env53355 := by
  intro p hp
  have h : env53355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53354_53355 : H12AffineEnvironment.transform 12 2337 env53354 = env53355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2337 env53354 == env53355) = true)

theorem identity53355 : scanCanonicalize (H12AffineFastState.compose env53355 (packedSelected [0,1,2,5,7,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound53355 : packedSelected [0,1,2,5,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53356 : List Nat := [2,4,8,0,32,64,110,256,324,3,76,1,365,258,354,35,290,77,321,355,1,291,97,35,73,354,302,354,259,74,352,259,256,260,323,7]

theorem envBound53356 : H12AffineFastState.Bounded env53356 := by
  intro p hp
  have h : env53356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53355_53356 : H12AffineEnvironment.transform 10 76 env53355 = env53356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env53355 == env53356) = true)

def env53357 : List Nat := [2,4,8,0,32,64,110,256,324,1024,2048,1,8192,1281,9228,1057,8270,1103,321,9229,1,291,9486,1057,9511,8206,302,8206,1280,10602,8205,1280,256,1286,1344,1028]

theorem envBound53357 : H12AffineFastState.Bounded env53357 := by
  intro p hp
  have h : env53357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53352_53357 : H12AffineEnvironment.transform 15 1057 env53352 = env53357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env53352 == env53357) = true)

theorem identity53357 : scanCanonicalize (H12AffineFastState.compose env53357 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53357 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env53358 : List Nat := [2,4,8,0,32,64,110,256,324,1024,2048,1,268,1281,1280,1057,322,1103,321,1281,1,291,1026,1057,1067,258,302,258,1280,2150,257,1280,256,1286,1344,1028]

theorem envBound53358 : H12AffineFastState.Bounded env53358 := by
  intro p hp
  have h : env53358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53357_53358 : H12AffineEnvironment.transform 12 268 env53357 = env53358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53357 == env53358) = true)

theorem identity53358 : scanCanonicalize (H12AffineFastState.compose env53358 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound53358 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env53359 : List Nat := [2,4,8,0,32,64,110,256,324,1024,11,1,268,1281,1280,1057,322,1103,321,1281,1,291,1026,1057,1067,258,302,258,1280,109,257,1280,256,1286,1344,1028]

theorem envBound53359 : H12AffineFastState.Bounded env53359 := by
  intro p hp
  have h : env53359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53358_53359 : H12AffineEnvironment.transform 10 11 env53358 = env53359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env53358 == env53359) = true)

def env53360 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9229,65536,74863,65664,321,9228,1,460,74030,65537,9673,74799,303,74798,1281,77131,8205,1280,256,65831,1344,1029]

theorem envBound53360 : H12AffineFastState.Bounded env53360 := by
  intro p hp
  have h : env53360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53350_53360 : H12AffineEnvironment.transform 3 1 env53350 = env53360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53350 == env53360) = true)

theorem identity53360 : scanCanonicalize (H12AffineFastState.compose env53360 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1510) := by decide +kernel

theorem selectedBound53360 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53361 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,1510,1280,491,65536,65929,65664,321,490,1,460,66760,65537,47,65993,303,65992,1281,67757,1515,1280,256,65831,1344,1029]

theorem envBound53361 : H12AffineFastState.Bounded env53361 := by
  intro p hp
  have h : env53361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53360_53361 : H12AffineEnvironment.transform 12 1510 env53360 = env53361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1510 env53360 == env53361) = true)

def env53362 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,1510,1280,491,1224,1345,1096,321,490,1,460,0,1225,47,1281,303,1280,1281,3173,1515,1280,256,1519,1344,1029]

theorem envBound53362 : H12AffineFastState.Bounded env53362 := by
  intro p hp
  have h : env53362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53361_53362 : H12AffineEnvironment.transform 15 1224 env53361 = env53362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1224 env53361 == env53362) = true)

theorem identity53362 : scanCanonicalize (H12AffineFastState.compose env53362 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound53362 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env53363 : List Nat := [2,4,8,1,32,64,46,256,325,1024,2048,1,1352,1280,325,1126,1345,1096,321,324,1,354,0,1127,47,1281,303,1280,1281,3173,1349,1280,256,1345,1344,1029]

theorem envBound53363 : H12AffineFastState.Bounded env53363 := by
  intro p hp
  have h : env53363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53362_53363 : H12AffineEnvironment.transform 6 46 env53362 = env53363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env53362 == env53363) = true)

theorem identity53363 : scanCanonicalize (H12AffineFastState.compose env53363 (packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS)) = affineNative (2^(10+1) ^^^ 1356) := by decide +kernel

theorem selectedBound53363 : packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env53364 : List Nat := [2,4,8,1,32,64,46,256,325,1024,1356,1,1352,1280,325,1126,1345,1096,321,324,1,354,0,1127,47,1281,303,1280,1281,297,1349,1280,256,1345,1344,1029]

theorem envBound53364 : H12AffineFastState.Bounded env53364 := by
  intro p hp
  have h : env53364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53363_53364 : H12AffineEnvironment.transform 10 1356 env53363 = env53364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1356 env53363 == env53364) = true)

theorem identity53364 : scanCanonicalize (H12AffineFastState.compose env53364 (packedSelected [13,15] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound53364 : packedSelected [13,15] rootPS < 2^1333 := by decide +kernel

def env53365 : List Nat := [2,4,8,1,32,64,46,69,0,1024,1033,1,1037,1093,0,1126,1028,1096,4,1,1,39,0,1127,47,1092,106,1093,1092,108,1024,1093,69,1028,1029,1029]

theorem envBound53365 : H12AffineFastState.Bounded env53365 := by
  intro p hp
  have h : env53365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53364_53365 : H12AffineEnvironment.transform 7 69 env53364 = env53365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env53364 == env53365) = true)

theorem identity53365 : scanCanonicalize (H12AffineFastState.compose env53365 (packedSelected [0,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound53365 : packedSelected [0,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53366 : List Nat := [2,4,8,1,32,64,46,69,0,78,71,1,67,11,0,40,74,6,4,1,1,39,0,41,47,10,106,11,10,108,78,11,69,74,75,75]

theorem envBound53366 : H12AffineFastState.Bounded env53366 := by
  intro p hp
  have h : env53366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53365_53366 : H12AffineEnvironment.transform 9 78 env53365 = env53366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env53365 == env53366) = true)

theorem identity53366 : scanCanonicalize (H12AffineFastState.compose env53366 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53366 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env53367 : List Nat := [2,4,8,1,1,64,15,69,0,78,71,1,67,11,0,9,74,6,4,1,1,6,0,8,14,10,75,11,10,77,78,11,69,74,75,75]

theorem envBound53367 : H12AffineFastState.Bounded env53367 := by
  intro p hp
  have h : env53367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53366_53367 : H12AffineEnvironment.transform 4 1 env53366 = env53367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53366 == env53367) = true)

theorem identity53367 : scanCanonicalize (H12AffineFastState.compose env53367 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53367 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53368 : List Nat := [2,2,8,1,1,64,9,67,0,72,65,1,67,11,0,9,74,0,2,1,1,0,0,8,8,10,75,11,10,75,72,11,67,74,75,75]

theorem envBound53368 : H12AffineFastState.Bounded env53368 := by
  intro p hp
  have h : env53368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53367_53368 : H12AffineEnvironment.transform 1 2 env53367 = env53368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53367 == env53368) = true)

theorem identity53368 : scanCanonicalize (H12AffineFastState.compose env53368 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound53368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53369 : List Nat := [2,2,8,1,1,11,9,8,0,3,10,1,8,11,0,9,1,0,2,1,1,0,0,8,8,10,0,11,10,0,3,11,8,1,0,0]

theorem envBound53369 : H12AffineFastState.Bounded env53369 := by
  intro p hp
  have h : env53369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53368_53369 : H12AffineEnvironment.transform 5 11 env53368 = env53369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env53368 == env53369) = true)

theorem identity53369 : scanCanonicalize (H12AffineFastState.compose env53369 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53370 : List Nat := [2,2,2,1,1,1,3,2,0,3,0,1,2,1,0,3,1,0,2,1,1,0,0,2,2,0,0,1,0,0,3,1,2,1,0,0]

theorem envBound53370 : H12AffineFastState.Bounded env53370 := by
  intro p hp
  have h : env53370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53369_53370 : H12AffineEnvironment.transform 2 2 env53369 = env53370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53369 == env53370) = true)

def env53371 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,1510,1280,491,1225,1344,1097,321,490,1,460,1,1224,47,1280,303,1281,1281,3172,1515,1280,256,1518,1344,1029]

theorem envBound53371 : H12AffineFastState.Bounded env53371 := by
  intro p hp
  have h : env53371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53361_53371 : H12AffineEnvironment.transform 15 1225 env53361 = env53371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1225 env53361 == env53371) = true)

theorem identity53371 : scanCanonicalize (H12AffineFastState.compose env53371 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound53371 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env53372 : List Nat := [2,4,8,1,32,64,128,170,239,1024,2048,1,1100,1194,65,1225,1258,1097,235,64,1,102,1,1224,47,1194,133,1195,1195,3172,1089,1194,170,1092,1258,1029]

theorem envBound53372 : H12AffineFastState.Bounded env53372 := by
  intro p hp
  have h : env53372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53371_53372 : H12AffineEnvironment.transform 7 170 env53371 = env53372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env53371 == env53372) = true)

theorem identity53372 : scanCanonicalize (H12AffineFastState.compose env53372 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53372 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env53373 : List Nat := [2,3,8,1,32,64,128,170,232,1024,2048,1,1099,1194,65,1225,1258,1097,235,64,1,97,1,1224,40,1194,130,1195,1195,3171,1089,1194,170,1091,1258,1026]

theorem envBound53373 : H12AffineFastState.Bounded env53373 := by
  intro p hp
  have h : env53373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53372_53373 : H12AffineEnvironment.transform 1 3 env53372 = env53373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53372 == env53373) = true)

theorem identity53373 : scanCanonicalize (H12AffineFastState.compose env53373 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53373 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53374 : List Nat := [2,3,8,1,32,0,128,170,168,1024,2048,1,1035,1194,1,1161,1194,1033,171,0,1,33,1,1160,40,1194,130,1195,1195,3107,1025,1194,170,1027,1194,1026]

theorem envBound53374 : H12AffineFastState.Bounded env53374 := by
  intro p hp
  have h : env53374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53373_53374 : H12AffineEnvironment.transform 5 0 env53373 = env53374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53373 == env53374) = true)

theorem identity53374 : scanCanonicalize (H12AffineFastState.compose env53374 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound53374 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53375 : List Nat := [2,3,8,1,32,0,40,2,0,1024,2048,1,1035,1026,1,1057,1026,1033,3,0,1,33,1,1056,40,1026,42,1027,1027,3107,1025,1026,2,1027,1026,1026]

theorem envBound53375 : H12AffineFastState.Bounded env53375 := by
  intro p hp
  have h : env53375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53374_53375 : H12AffineEnvironment.transform 6 40 env53374 = env53375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env53374 == env53375) = true)

theorem identity53375 : scanCanonicalize (H12AffineFastState.compose env53375 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1064) := by decide +kernel

theorem selectedBound53375 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53376 : List Nat := [2,3,8,1,32,0,40,2,0,1024,1064,1,1035,1026,1,1057,1026,1033,3,0,1,33,1,1056,40,1026,42,1027,1027,11,1025,1026,2,1027,1026,1026]

theorem envBound53376 : H12AffineFastState.Bounded env53376 := by
  intro p hp
  have h : env53376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53375_53376 : H12AffineEnvironment.transform 10 1064 env53375 = env53376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1064 env53375 == env53376) = true)

theorem identity53376 : scanCanonicalize (H12AffineFastState.compose env53376 (packedSelected [0,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound53376 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env53377 : List Nat := [2,3,8,1,32,0,40,2,0,35,11,1,40,33,1,2,33,42,3,0,1,33,1,3,40,33,42,32,32,11,34,33,2,32,33,33]

theorem envBound53377 : H12AffineFastState.Bounded env53377 := by
  intro p hp
  have h : env53377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53376_53377 : H12AffineEnvironment.transform 9 35 env53376 = env53377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env53376 == env53377) = true)

theorem identity53377 : scanCanonicalize (H12AffineFastState.compose env53377 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53378 : List Nat := [2,3,8,1,10,0,2,2,0,9,11,1,2,11,1,2,11,0,3,0,1,11,1,3,2,11,0,10,10,11,8,11,2,10,11,11]

theorem envBound53378 : H12AffineFastState.Bounded env53378 := by
  intro p hp
  have h : env53378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53377_53378 : H12AffineEnvironment.transform 4 10 env53377 = env53378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53377 == env53378) = true)

theorem identity53378 : scanCanonicalize (H12AffineFastState.compose env53378 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53378 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53379 : List Nat := [2,3,2,1,0,0,2,2,0,3,1,1,2,1,1,2,1,0,3,0,1,1,1,3,2,1,0,0,0,1,2,1,2,0,1,1]

theorem envBound53379 : H12AffineFastState.Bounded env53379 := by
  intro p hp
  have h : env53379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53378_53379 : H12AffineEnvironment.transform 2 2 env53378 = env53379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53378 == env53379) = true)

theorem identity53379 : scanCanonicalize (H12AffineFastState.compose env53379 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53380 : List Nat := [1,0,1,1,0,0,1,1,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,1,1,0,0,0,1,1,1,1,0,1,1]

theorem envBound53380 : H12AffineFastState.Bounded env53380 := by
  intro p hp
  have h : env53380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53379_53380 : H12AffineEnvironment.transform 0 1 env53379 = env53380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53379 == env53380) = true)

def env53381 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,1,477,74047,65552,9673,74799,318,74815,1296,77131,8205,1280,256,65831,1344,1045]

theorem envBound53381 : H12AffineFastState.Bounded env53381 := by
  intro p hp
  have h : env53381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53349_53381 : H12AffineEnvironment.transform 8 341 env53349 = env53381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env53349 == env53381) = true)

def env53382 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9228,65536,74863,65664,321,9229,1,461,74031,65536,9673,74799,302,74799,1280,77131,8205,1280,256,65831,1344,1029]

theorem envBound53382 : H12AffineFastState.Bounded env53382 := by
  intro p hp
  have h : env53382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53381_53382 : H12AffineEnvironment.transform 3 0 env53381 = env53382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53381 == env53382) = true)

theorem identity53382 : scanCanonicalize (H12AffineFastState.compose env53382 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8641) := by decide +kernel

theorem selectedBound53382 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53383 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9228,8641,1454,8513,321,9229,1,461,238,8641,9673,1518,302,1518,1280,3210,8205,1280,256,8422,1344,1029]

theorem envBound53383 : H12AffineFastState.Bounded env53383 := by
  intro p hp
  have h : env53383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53382_53383 : H12AffineEnvironment.transform 15 8641 env53382 = env53383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8641 env53382 == env53383) = true)

def env53384 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,1288,1281,260,1225,1454,1097,321,261,1,461,238,1225,193,1518,302,1518,1280,3210,1285,1280,256,1518,1344,1029]

theorem envBound53384 : H12AffineFastState.Bounded env53384 := by
  intro p hp
  have h : env53384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53383_53384 : H12AffineEnvironment.transform 12 1288 env53383 = env53384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env53383 == env53384) = true)

theorem identity53384 : scanCanonicalize (H12AffineFastState.compose env53384 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound53384 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53385 : List Nat := [2,4,8,0,32,64,128,256,325,69,2048,1,333,324,260,140,491,12,321,261,1,461,238,140,193,427,302,427,325,2255,320,325,256,427,261,64]

theorem envBound53385 : H12AffineFastState.Bounded env53385 := by
  intro p hp
  have h : env53385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53384_53385 : H12AffineEnvironment.transform 9 69 env53384 = env53385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env53384 == env53385) = true)

theorem identity53385 : scanCanonicalize (H12AffineFastState.compose env53385 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound53385 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env53386 : List Nat := [2,4,8,0,32,64,128,256,325,69,163,1,333,324,260,140,491,12,321,261,1,461,238,140,193,427,302,427,325,108,320,325,256,427,261,64]

theorem envBound53386 : H12AffineFastState.Bounded env53386 := by
  intro p hp
  have h : env53386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53385_53386 : H12AffineEnvironment.transform 10 163 env53385 = env53386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env53385 == env53386) = true)

theorem identity53386 : scanCanonicalize (H12AffineFastState.compose env53386 (packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53386 : packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env53387 : List Nat := [2,4,8,0,32,64,128,4,65,69,163,1,73,64,0,140,239,12,69,1,1,201,238,140,193,175,42,175,65,108,68,65,4,175,1,64]

theorem envBound53387 : H12AffineFastState.Bounded env53387 := by
  intro p hp
  have h : env53387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53386_53387 : H12AffineEnvironment.transform 7 4 env53386 = env53387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53386 == env53387) = true)

theorem identity53387 : scanCanonicalize (H12AffineFastState.compose env53387 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound53387 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53388 : List Nat := [2,4,8,0,32,64,47,4,65,69,12,1,73,64,0,35,64,12,69,1,1,102,65,35,110,0,42,0,65,108,68,65,4,0,1,64]

theorem envBound53388 : H12AffineFastState.Bounded env53388 := by
  intro p hp
  have h : env53388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53387_53388 : H12AffineEnvironment.transform 6 47 env53387 = env53388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env53387 == env53388) = true)

theorem identity53388 : scanCanonicalize (H12AffineFastState.compose env53388 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound53388 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53389 : List Nat := [2,4,8,0,32,10,47,4,11,15,12,1,3,10,0,35,10,12,15,1,1,44,11,35,36,0,42,0,11,38,14,11,4,0,1,10]

theorem envBound53389 : H12AffineFastState.Bounded env53389 := by
  intro p hp
  have h : env53389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53388_53389 : H12AffineEnvironment.transform 5 10 env53388 = env53389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env53388 == env53389) = true)

theorem identity53389 : scanCanonicalize (H12AffineFastState.compose env53389 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53389 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53390 : List Nat := [2,4,4,0,32,6,35,4,7,3,0,1,3,6,0,35,6,0,3,1,1,32,7,35,36,0,38,0,7,38,2,7,4,0,1,6]

theorem envBound53390 : H12AffineFastState.Bounded env53390 := by
  intro p hp
  have h : env53390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53389_53390 : H12AffineEnvironment.transform 2 4 env53389 = env53390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53389 == env53390) = true)

theorem identity53390 : scanCanonicalize (H12AffineFastState.compose env53390 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53391 : List Nat := [1,4,4,0,32,5,32,4,4,0,0,1,0,5,0,32,5,0,0,1,1,32,4,32,36,0,37,0,4,37,1,4,4,0,1,5]

theorem envBound53391 : H12AffineFastState.Bounded env53391 := by
  intro p hp
  have h : env53391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53390_53391 : H12AffineEnvironment.transform 0 1 env53390 = env53391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53390 == env53391) = true)

theorem identity53391 : scanCanonicalize (H12AffineFastState.compose env53391 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53391 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53392 : List Nat := [1,0,0,0,32,1,32,0,0,0,0,1,0,1,0,32,1,0,0,1,1,32,0,32,32,0,33,0,0,33,1,0,0,0,1,1]

theorem envBound53392 : H12AffineFastState.Bounded env53392 := by
  intro p hp
  have h : env53392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53391_53392 : H12AffineEnvironment.transform 1 0 env53391 = env53392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53391 == env53392) = true)

def env53393 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,1289,1281,261,1224,1454,1096,321,260,1,461,238,1224,192,1518,302,1518,1280,3210,1284,1280,256,1519,1344,1029]

theorem envBound53393 : H12AffineFastState.Bounded env53393 := by
  intro p hp
  have h : env53393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53383_53393 : H12AffineEnvironment.transform 12 1289 env53383 = env53393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env53383 == env53393) = true)

theorem identity53393 : scanCanonicalize (H12AffineFastState.compose env53393 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53393 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53394 : List Nat := [2,4,8,0,32,64,128,4,65,1024,2048,1,1037,1029,1,1224,1194,1096,69,0,1,201,238,1224,192,1258,42,1258,1028,3210,1024,1028,4,1259,1092,1029]

theorem envBound53394 : H12AffineFastState.Bounded env53394 := by
  intro p hp
  have h : env53394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53393_53394 : H12AffineEnvironment.transform 7 4 env53393 = env53394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53393 == env53394) = true)

theorem identity53394 : scanCanonicalize (H12AffineFastState.compose env53394 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 235) := by decide +kernel

theorem selectedBound53394 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53395 : List Nat := [2,4,8,0,32,64,128,4,65,235,2048,1,230,238,1,35,65,163,69,0,1,201,238,35,192,1,42,1,239,2145,235,239,4,0,175,238]

theorem envBound53395 : H12AffineFastState.Bounded env53395 := by
  intro p hp
  have h : env53395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53394_53395 : H12AffineEnvironment.transform 9 235 env53394 = env53395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 235 env53394 == env53395) = true)

theorem identity53395 : scanCanonicalize (H12AffineFastState.compose env53395 (packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound53395 : packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53396 : List Nat := [2,4,8,0,32,64,128,4,65,235,64,1,230,238,1,35,65,163,69,0,1,201,238,35,192,1,42,1,239,33,235,239,4,0,175,238]

theorem envBound53396 : H12AffineFastState.Bounded env53396 := by
  intro p hp
  have h : env53396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53395_53396 : H12AffineEnvironment.transform 10 64 env53395 = env53396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env53395 == env53396) = true)

theorem identity53396 : scanCanonicalize (H12AffineFastState.compose env53396 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound53396 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env53397 : List Nat := [2,4,8,0,32,64,41,4,65,66,64,1,79,71,1,35,65,10,69,0,1,96,71,35,105,1,42,1,70,33,66,70,4,0,6,71]

theorem envBound53397 : H12AffineFastState.Bounded env53397 := by
  intro p hp
  have h : env53397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53396_53397 : H12AffineEnvironment.transform 6 41 env53396 = env53397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env53396 == env53397) = true)

theorem identity53397 : scanCanonicalize (H12AffineFastState.compose env53397 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53397 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53398 : List Nat := [2,4,4,0,32,64,37,4,65,66,64,1,67,71,1,35,65,6,69,0,1,96,71,35,101,1,38,1,70,33,66,70,4,0,6,71]

theorem envBound53398 : H12AffineFastState.Bounded env53398 := by
  intro p hp
  have h : env53398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53397_53398 : H12AffineEnvironment.transform 2 4 env53397 = env53398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53397 == env53398) = true)

theorem identity53398 : scanCanonicalize (H12AffineFastState.compose env53398 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53398 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53399 : List Nat := [2,4,4,0,1,64,4,4,65,66,64,1,67,71,1,2,65,6,69,0,1,65,71,2,68,1,7,1,70,0,66,70,4,0,6,71]

theorem envBound53399 : H12AffineFastState.Bounded env53399 := by
  intro p hp
  have h : env53399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53398_53399 : H12AffineEnvironment.transform 4 1 env53398 = env53399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53398 == env53399) = true)

theorem identity53399 : scanCanonicalize (H12AffineFastState.compose env53399 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53400 : List Nat := [2,4,4,0,1,0,4,4,1,2,0,1,3,7,1,2,1,6,5,0,1,1,7,2,4,1,7,1,6,0,2,6,4,0,6,7]

theorem envBound53400 : H12AffineFastState.Bounded env53400 := by
  intro p hp
  have h : env53400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53399_53400 : H12AffineEnvironment.transform 5 0 env53399 = env53400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53399 == env53400) = true)

theorem identity53400 : scanCanonicalize (H12AffineFastState.compose env53400 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53401 : List Nat := [2,3,3,0,1,0,3,3,1,2,0,1,3,0,1,2,1,1,2,0,1,1,0,2,3,1,0,1,1,0,2,1,3,0,1,0]

theorem envBound53401 : H12AffineFastState.Bounded env53401 := by
  intro p hp
  have h : env53401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53400_53401 : H12AffineEnvironment.transform 1 3 env53400 = env53401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53400 == env53401) = true)

theorem identity53401 : scanCanonicalize (H12AffineFastState.compose env53401 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53401 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53402 : List Nat := [1,0,0,0,1,0,0,0,1,1,0,1,0,0,1,1,1,1,1,0,1,1,0,1,0,1,0,1,1,0,1,1,0,0,1,0]

theorem envBound53402 : H12AffineFastState.Bounded env53402 := by
  intro p hp
  have h : env53402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53401_53402 : H12AffineEnvironment.transform 0 1 env53401 = env53402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53401 == env53402) = true)

def env53403 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9229,65536,74863,65664,321,9228,1,460,74030,65537,9673,74799,303,74798,1281,77131,8205,1280,256,65831,1344,1028]

end H12CloudChart2