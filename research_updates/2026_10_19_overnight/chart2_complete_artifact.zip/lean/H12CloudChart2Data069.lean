import H12CloudChart2Data068

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity16897 : scanCanonicalize (H12AffineFastState.compose env16897 (packedSelected [4,9,16] rootPS)) = affineNative (2^(23+1) ^^^ 623877) := by decide +kernel

theorem selectedBound16897 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env16898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,524288,32769,4097,4194304,660545,623877,8328,135185,4982100,529408,656385,1073741824,1285,4294967296,525569,4299785647,1297,512]

theorem envBound16898 : H12AffineFastState.Bounded env16898 := by
  intro p hp
  have h : env16898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16897_16898 : H12AffineEnvironment.transform 23 623877 env16897 = env16898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623877 env16897 == env16898) = true)

theorem identity16898 : scanCanonicalize (H12AffineFastState.compose env16898 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 4294874) := by decide +kernel

theorem selectedBound16898 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,524288,32769,4097,4194304,660545,623877,8328,135185,4982100,529408,656385,4294874,1285,4294967296,525569,4299785647,1297,512]

theorem envBound16899 : H12AffineFastState.Bounded env16899 := by
  intro p hp
  have h : env16899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16898_16899 : H12AffineEnvironment.transform 29 4294874 env16898 = env16899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294874 env16898 == env16899) = true)

theorem identity16899 : scanCanonicalize (H12AffineFastState.compose env16899 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16899 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env16900 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,524288,32769,4097,4194304,660496,623877,8328,135185,4982021,529408,656385,4294795,1285,4294967296,525569,4299785647,1297,512]

theorem envBound16900 : H12AffineFastState.Bounded env16900 := by
  intro p hp
  have h : env16900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16899_16900 : H12AffineEnvironment.transform 5 17 env16899 = env16900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16899 == env16900) = true)

theorem identity16900 : scanCanonicalize (H12AffineFastState.compose env16900 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 42884) := by decide +kernel

theorem selectedBound16900 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16901 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,42884,32769,4097,4194304,177044,74369,8328,135185,4498049,45956,172933,4294795,1285,4294967296,41605,4299235883,1297,512]

theorem envBound16901 : H12AffineFastState.Bounded env16901 := by
  intro p hp
  have h : env16901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16900_16901 : H12AffineEnvironment.transform 18 42884 env16900 = env16901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42884 env16900 == env16901) = true)

theorem identity16901 : scanCanonicalize (H12AffineFastState.compose env16901 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16901 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env16902 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,131072,262144,42253,32769,4097,4194304,176413,73736,8328,135185,4497416,45325,172300,4294795,1285,4294967296,40972,4299235490,1297,137]

theorem envBound16902 : H12AffineFastState.Bounded env16902 := by
  intro p hp
  have h : env16902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16901_16902 : H12AffineEnvironment.transform 8 137 env16901 = env16902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16901 == env16902) = true)

theorem identity16902 : scanCanonicalize (H12AffineFastState.compose env16902 (packedSelected [0,6,27] rootPS)) = affineNative (2^(31+1) ^^^ 230707) := by decide +kernel

theorem selectedBound16902 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env16903 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,131072,262144,42253,32769,4097,4194304,176413,73736,8328,135185,4497416,45325,172300,4294795,1285,230707,40972,4367761,1297,137]

theorem envBound16903 : H12AffineFastState.Bounded env16903 := by
  intro p hp
  have h : env16903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16902_16903 : H12AffineEnvironment.transform 31 230707 env16902 = env16903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 230707 env16902 == env16903) = true)

def env16904 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,1296,262144,42253,32769,4097,4194304,46093,73736,8328,5377,4497416,45325,42012,4294795,1285,98339,40972,4235393,1297,137]

theorem envBound16904 : H12AffineFastState.Bounded env16904 := by
  intro p hp
  have h : env16904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16903_16904 : H12AffineEnvironment.transform 16 1296 env16903 = env16904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env16903 == env16904) = true)

theorem identity16904 : scanCanonicalize (H12AffineFastState.compose env16904 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16904 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16905 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,8460,65536,1296,262144,1025,8461,4097,4194304,5377,73736,8328,5377,4456708,4097,1296,4270471,1285,74031,256,4194701,1297,137]

theorem envBound16905 : H12AffineFastState.Bounded env16905 := by
  intro p hp
  have h : env16905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16904_16905 : H12AffineEnvironment.transform 14 8460 env16904 = env16905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16904 == env16905) = true)

theorem identity16905 : scanCanonicalize (H12AffineFastState.compose env16905 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 264224) := by decide +kernel

theorem selectedBound16905 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16906 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,8460,65536,1296,262144,1025,8461,4097,264224,5377,73736,8328,5377,2340,4097,1296,336295,1285,74031,256,264621,1297,137]

theorem envBound16906 : H12AffineFastState.Bounded env16906 := by
  intro p hp
  have h : env16906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16905_16906 : H12AffineEnvironment.transform 21 264224 env16905 = env16906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264224 env16905 == env16906) = true)

theorem identity16906 : scanCanonicalize (H12AffineFastState.compose env16906 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound16906 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16907 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,8460,8323,1296,262144,1025,8461,4097,264224,5377,139,8328,5377,2340,4097,1296,262436,1285,428,256,264621,1297,137]

theorem envBound16907 : H12AffineFastState.Bounded env16907 := by
  intro p hp
  have h : env16907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16906_16907 : H12AffineEnvironment.transform 15 8323 env16906 = env16907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env16906 == env16907) = true)

theorem identity16907 : scanCanonicalize (H12AffineFastState.compose env16907 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound16907 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16908 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,2088,4096,2340,2219,1296,262144,1025,2341,4097,264224,5377,139,2208,5377,2340,4097,1296,262436,1285,428,256,264621,1297,137]

theorem envBound16908 : H12AffineFastState.Bounded env16908 := by
  intro p hp
  have h : env16908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16907_16908 : H12AffineEnvironment.transform 12 2088 env16907 = env16908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env16907 == env16908) = true)

theorem identity16908 : scanCanonicalize (H12AffineFastState.compose env16908 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound16908 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16909 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,2088,4096,2340,2219,1296,2341,1025,2341,4097,261,5377,139,2208,5377,2340,4097,1296,2049,1285,428,256,136,1297,137]

theorem envBound16909 : H12AffineFastState.Bounded env16909 := by
  intro p hp
  have h : env16909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16908_16909 : H12AffineEnvironment.transform 17 2341 env16908 = env16909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env16908 == env16909) = true)

theorem identity16909 : scanCanonicalize (H12AffineFastState.compose env16909 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16909 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16910 : List Nat := [2,4,8,16,32,17,128,37,137,1024,2048,4096,2088,4096,2049,2219,1077,2048,1025,2048,4097,32,5156,139,2208,5156,2049,4097,1077,2049,1056,137,37,136,1076,137]

theorem envBound16910 : H12AffineFastState.Bounded env16910 := by
  intro p hp
  have h : env16910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16909_16910 : H12AffineEnvironment.transform 7 37 env16909 = env16910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16909 == env16910) = true)

theorem identity16910 : scanCanonicalize (H12AffineFastState.compose env16910 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound16910 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16911 : List Nat := [2,4,8,16,32,17,128,37,137,1024,2048,1196,2088,1196,2049,2219,1077,2048,1025,2048,1197,32,136,139,2208,136,2049,1197,1077,2049,1056,137,37,136,1076,137]

theorem envBound16911 : H12AffineFastState.Bounded env16911 := by
  intro p hp
  have h : env16911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16910_16911 : H12AffineEnvironment.transform 11 1196 env16910 = env16911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env16910 == env16911) = true)

theorem identity16911 : scanCanonicalize (H12AffineFastState.compose env16911 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16911 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16912 : List Nat := [2,4,8,16,32,17,25,37,16,1024,2048,1077,2088,1077,2049,2098,1077,2048,1025,2048,1076,32,17,18,2105,17,2049,1076,1077,2049,1056,16,37,17,1076,16]

theorem envBound16912 : H12AffineFastState.Bounded env16912 := by
  intro p hp
  have h : env16912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16911_16912 : H12AffineEnvironment.transform 6 25 env16911 = env16912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16911 == env16912) = true)

theorem identity16912 : scanCanonicalize (H12AffineFastState.compose env16912 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound16912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16913 : List Nat := [2,4,8,16,32,17,25,37,16,47,2048,26,2088,26,2049,2098,26,2048,46,2048,27,32,17,18,2105,17,2049,27,26,2049,15,16,37,17,27,16]

theorem envBound16913 : H12AffineFastState.Bounded env16913 := by
  intro p hp
  have h : env16913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16912_16913 : H12AffineEnvironment.transform 9 47 env16912 = env16913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env16912 == env16913) = true)

theorem identity16913 : scanCanonicalize (H12AffineFastState.compose env16913 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16913 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16914 : List Nat := [2,4,8,16,32,17,25,37,16,47,1,26,41,26,0,51,26,1,46,1,27,32,17,18,56,17,0,27,26,0,15,16,37,17,27,16]

theorem envBound16914 : H12AffineFastState.Bounded env16914 := by
  intro p hp
  have h : env16914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16913_16914 : H12AffineEnvironment.transform 10 1 env16913 = env16914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16913 == env16914) = true)

def env16915 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,1297,262144,42253,32769,4097,4194304,46092,73736,8328,5376,4497416,45325,42013,4294795,1285,98338,40972,4235392,1297,137]

theorem envBound16915 : H12AffineFastState.Bounded env16915 := by
  intro p hp
  have h : env16915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16903_16915 : H12AffineEnvironment.transform 16 1297 env16903 = env16915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env16903 == env16915) = true)

def env16916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,524288,32769,4097,4194304,660545,16777216,8328,135185,4982100,529408,656384,1073741824,17399809,4294967296,525568,4315938986,17399829,512]

theorem envBound16916 : H12AffineFastState.Bounded env16916 := by
  intro p hp
  have h : env16916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16896_16916 : H12AffineEnvironment.transform 13 4097 env16896 = env16916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env16896 == env16916) = true)

def env16917 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,524288,32769,4097,4194304,660497,16777216,8328,135185,4982020,529408,656384,1073741824,17399809,4294967296,525568,4315938986,17399829,512]

theorem envBound16917 : H12AffineFastState.Bounded env16917 := by
  intro p hp
  have h : env16917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16916_16917 : H12AffineEnvironment.transform 5 16 env16916 = env16917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16916 == env16917) = true)

theorem identity16917 : scanCanonicalize (H12AffineFastState.compose env16917 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1095314853) := by decide +kernel

theorem selectedBound16917 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env16918 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,524288,32769,4097,4194304,660497,16777216,8328,135185,4982020,529408,656384,1073741824,17399809,1095314853,525568,1074343183,17399829,512]

theorem envBound16918 : H12AffineFastState.Bounded env16918 := by
  intro p hp
  have h : env16918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16917_16918 : H12AffineEnvironment.transform 31 1095314853 env16917 = env16918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1095314853 env16917 == env16918) = true)

def env16919 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131344,32769,4097,4194304,5377,16777216,8328,135185,4588564,136464,1296,1073741824,17006865,1094921397,132112,1073949727,17006853,512]

theorem envBound16919 : H12AffineFastState.Bounded env16919 := by
  intro p hp
  have h : env16919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16918_16919 : H12AffineEnvironment.transform 18 131344 env16918 = env16919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131344 env16918 == env16919) = true)

theorem identity16919 : scanCanonicalize (H12AffineFastState.compose env16919 (packedSelected [0,27] rootPS)) = affineNative (2^(16+1) ^^^ 1296) := by decide +kernel

theorem selectedBound16919 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env16920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,16777216,8328,5377,4456708,4096,1296,1073741824,16876545,1094789541,256,1073817871,16876565,512]

theorem envBound16920 : H12AffineFastState.Bounded env16920 := by
  intro p hp
  have h : env16920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16919_16920 : H12AffineEnvironment.transform 16 1296 env16919 = env16920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env16919 == env16920) = true)

def env16921 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,16777216,8328,5377,4456708,4096,1296,1073741824,16876545,1094789541,256,1073817871,16876565,136]

theorem envBound16921 : H12AffineFastState.Bounded env16921 := by
  intro p hp
  have h : env16921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16920_16921 : H12AffineEnvironment.transform 8 136 env16920 = env16921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16920 == env16921) = true)

theorem identity16921 : scanCanonicalize (H12AffineFastState.compose env16921 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(21+1) ^^^ 98306) := by decide +kernel

theorem selectedBound16921 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env16922 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,98306,5377,16777216,8328,5377,360710,4096,1296,1073741824,16876545,1090562471,256,1073817871,16876565,136]

theorem envBound16922 : H12AffineFastState.Bounded env16922 := by
  intro p hp
  have h : env16922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16921_16922 : H12AffineEnvironment.transform 21 98306 env16921 = env16922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98306 env16921 == env16922) = true)

def env16923 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1296,13592,1024,32769,4097,98306,5377,16777216,8328,5377,111646,4096,1296,1073741824,16876545,1090562471,256,1073817871,16876565,136]

theorem envBound16923 : H12AffineFastState.Bounded env16923 := by
  intro p hp
  have h : env16923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16922_16923 : H12AffineEnvironment.transform 17 13592 env16922 = env16923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env16922 == env16923) = true)

theorem identity16923 : scanCanonicalize (H12AffineFastState.compose env16923 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 37917) := by decide +kernel

theorem selectedBound16923 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16924 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1296,13592,1024,32769,4097,98306,5377,37917,8328,5377,111646,4096,1296,1073741824,69660,1073757626,256,1073817871,69640,136]

theorem envBound16924 : H12AffineFastState.Bounded env16924 := by
  intro p hp
  have h : env16924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16923_16924 : H12AffineEnvironment.transform 23 37917 env16923 = env16924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 37917 env16923 == env16924) = true)

def env16925 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5400,1296,13592,1024,32769,4097,38170,5377,37917,8328,5377,41222,4096,1296,1073741824,1284,1073757626,256,1073757207,1296,136]

theorem envBound16925 : H12AffineFastState.Bounded env16925 := by
  intro p hp
  have h : env16925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16924_16925 : H12AffineEnvironment.transform 15 5400 env16924 = env16925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5400 env16924 == env16925) = true)

theorem identity16925 : scanCanonicalize (H12AffineFastState.compose env16925 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 7228) := by decide +kernel

theorem selectedBound16925 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16926 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,7228,4097,32768,5400,1296,2340,1024,32769,4097,38170,5377,37917,7348,5377,40250,4096,1296,1073741824,1284,1073742214,256,1073741867,1296,136]

theorem envBound16926 : H12AffineFastState.Bounded env16926 := by
  intro p hp
  have h : env16926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16925_16926 : H12AffineEnvironment.transform 12 7228 env16925 = env16926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7228 env16925 == env16926) = true)

theorem identity16926 : scanCanonicalize (H12AffineFastState.compose env16926 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 39966) := by decide +kernel

theorem selectedBound16926 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16927 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,7228,4097,32768,5400,1296,2340,1024,32769,4097,38170,5377,37917,7348,5377,40250,4096,1296,39966,1284,40344,256,39989,1296,136]

theorem envBound16927 : H12AffineFastState.Bounded env16927 := by
  intro p hp
  have h : env16927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16926_16927 : H12AffineEnvironment.transform 29 39966 env16926 = env16927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 39966 env16926 == env16927) = true)

theorem identity16927 : scanCanonicalize (H12AffineFastState.compose env16927 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 5270) := by decide +kernel

theorem selectedBound16927 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16928 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,7228,4097,5270,5400,1296,2340,1024,5271,4097,396,5377,139,7348,5377,2476,4096,1296,2184,1284,2318,256,2211,1296,136]

theorem envBound16928 : H12AffineFastState.Bounded env16928 := by
  intro p hp
  have h : env16928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16927_16928 : H12AffineEnvironment.transform 14 5270 env16927 = env16928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5270 env16927 == env16928) = true)

theorem identity16928 : scanCanonicalize (H12AffineFastState.compose env16928 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 3507) := by decide +kernel

theorem selectedBound16928 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16929 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,3507,399,3506,2341,2219,1296,2340,1024,2340,3506,396,2226,139,263,2226,2476,3507,1296,2184,1284,2318,256,2211,1296,136]

theorem envBound16929 : H12AffineFastState.Bounded env16929 := by
  intro p hp
  have h : env16929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16928_16929 : H12AffineEnvironment.transform 11 3507 env16928 = env16929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3507 env16928 == env16929) = true)

theorem identity16929 : scanCanonicalize (H12AffineFastState.compose env16929 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound16929 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16930 : List Nat := [2,4,8,16,32,16,128,256,136,1024,423,1044,399,1045,130,268,1296,131,1024,131,1045,396,277,139,263,277,11,1044,1296,303,1284,169,256,260,1296,136]

theorem envBound16930 : H12AffineFastState.Bounded env16930 := by
  intro p hp
  have h : env16930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16929_16930 : H12AffineEnvironment.transform 10 423 env16929 = env16930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env16929 == env16930) = true)

theorem identity16930 : scanCanonicalize (H12AffineFastState.compose env16930 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound16930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16931 : List Nat := [2,4,8,16,32,16,128,173,136,1024,10,1044,34,1045,130,161,1213,131,1024,131,1045,33,184,139,170,184,11,1044,1213,130,1193,169,173,169,1213,136]

theorem envBound16931 : H12AffineFastState.Bounded env16931 := by
  intro p hp
  have h : env16931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16930_16931 : H12AffineEnvironment.transform 7 173 env16930 = env16931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16930 == env16931) = true)

theorem identity16931 : scanCanonicalize (H12AffineFastState.compose env16931 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16932 : List Nat := [2,4,8,16,0,16,128,141,136,1024,10,1044,2,1045,130,129,1181,131,1024,131,1045,1,152,139,138,152,11,1044,1181,130,1161,137,141,137,1181,136]

theorem envBound16932 : H12AffineFastState.Bounded env16932 := by
  intro p hp
  have h : env16932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16931_16932 : H12AffineEnvironment.transform 4 0 env16931 = env16932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16931 == env16932) = true)

theorem identity16932 : scanCanonicalize (H12AffineFastState.compose env16932 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16933 : List Nat := [2,4,8,16,0,16,9,4,1,1024,10,1044,2,1045,11,8,1044,10,1024,10,1045,1,17,2,3,17,11,1044,1044,11,1024,0,4,0,1044,1]

theorem envBound16933 : H12AffineFastState.Bounded env16933 := by
  intro p hp
  have h : env16933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16932_16933 : H12AffineEnvironment.transform 6 9 env16932 = env16933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16932 == env16933) = true)

def env16934 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5401,1296,13592,1024,32769,4097,38171,5377,37917,8328,5377,41223,4096,1296,1073741824,1285,1073757626,256,1073757206,1297,136]

theorem envBound16934 : H12AffineFastState.Bounded env16934 := by
  intro p hp
  have h : env16934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16924_16934 : H12AffineEnvironment.transform 15 5401 env16924 = env16934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5401 env16924 == env16934) = true)

theorem identity16934 : scanCanonicalize (H12AffineFastState.compose env16934 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 43277) := by decide +kernel

theorem selectedBound16934 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16935 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5401,1296,13592,1024,32769,4097,38171,5377,37917,8328,5377,41223,4096,1296,43277,1285,38071,256,38171,1297,136]

theorem envBound16935 : H12AffineFastState.Bounded env16935 := by
  intro p hp
  have h : env16935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16934_16935 : H12AffineEnvironment.transform 29 43277 env16934 = env16935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43277 env16934 == env16935) = true)

theorem identity16935 : scanCanonicalize (H12AffineFastState.compose env16935 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound16935 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16936 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1044,8192,1045,32768,269,1296,8460,1024,32769,1045,33039,277,32777,8328,277,41223,1044,1296,43277,1285,32931,256,33039,1297,136]

theorem envBound16936 : H12AffineFastState.Bounded env16936 := by
  intro p hp
  have h : env16936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16935_16936 : H12AffineEnvironment.transform 11 1044 env16935 = env16936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16935 == env16936) = true)

theorem identity16936 : scanCanonicalize (H12AffineFastState.compose env16936 (packedSelected [3,5,6,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16936 : packedSelected [3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env16937 : List Nat := [2,4,8,16,32,16,40,256,32,1024,2048,1044,8192,1045,32768,269,1296,8460,1024,32769,1045,33039,277,32777,8224,277,41223,1044,1296,43277,1285,32779,256,33039,1297,32]

theorem envBound16937 : H12AffineFastState.Bounded env16937 := by
  intro p hp
  have h : env16937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16936_16937 : H12AffineEnvironment.transform 6 40 env16936 = env16937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16936 == env16937) = true)

theorem identity16937 : scanCanonicalize (H12AffineFastState.compose env16937 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound16937 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env16938 : List Nat := [2,4,8,16,32,16,40,256,32,1024,270,1044,8192,1045,32768,269,1296,8460,1024,32769,1045,33039,277,32777,8224,277,41223,1044,1296,40963,1285,32779,256,33039,1297,32]

theorem envBound16938 : H12AffineFastState.Bounded env16938 := by
  intro p hp
  have h : env16938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16937_16938 : H12AffineEnvironment.transform 10 270 env16937 = env16938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env16937 == env16938) = true)

theorem identity16938 : scanCanonicalize (H12AffineFastState.compose env16938 (packedSelected [1,5,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 42) := by decide +kernel

theorem selectedBound16938 : packedSelected [1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env16939 : List Nat := [2,4,8,16,32,16,40,256,32,1024,270,1044,8192,1045,42,269,1296,8460,1024,43,1045,293,277,35,8224,277,8493,1044,1296,8233,1285,33,256,293,1297,32]

theorem envBound16939 : H12AffineFastState.Bounded env16939 := by
  intro p hp
  have h : env16939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16938_16939 : H12AffineEnvironment.transform 14 42 env16938 = env16939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 42 env16938 == env16939) = true)

theorem identity16939 : scanCanonicalize (H12AffineFastState.compose env16939 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16939 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env16940 : List Nat := [2,4,8,16,32,16,40,37,32,1024,43,1044,8192,1045,42,40,1077,8233,1024,43,1045,0,48,35,8224,48,8200,1044,1077,8233,1056,33,37,0,1076,32]

theorem envBound16940 : H12AffineFastState.Bounded env16940 := by
  intro p hp
  have h : env16940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16939_16940 : H12AffineEnvironment.transform 7 37 env16939 = env16940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16939 == env16940) = true)

theorem identity16940 : scanCanonicalize (H12AffineFastState.compose env16940 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 34) := by decide +kernel

theorem selectedBound16940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16941 : List Nat := [2,4,8,16,32,16,40,37,32,1024,43,1044,34,1045,42,40,1077,11,1024,43,1045,0,48,35,2,48,42,1044,1077,11,1056,33,37,0,1076,32]

theorem envBound16941 : H12AffineFastState.Bounded env16941 := by
  intro p hp
  have h : env16941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16940_16941 : H12AffineEnvironment.transform 12 34 env16940 = env16941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 34 env16940 == env16941) = true)

theorem identity16941 : scanCanonicalize (H12AffineFastState.compose env16941 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16942 : List Nat := [2,4,8,1,32,1,40,37,32,1024,43,1029,34,1028,42,40,1060,11,1024,43,1028,0,33,35,2,33,42,1029,1060,11,1056,33,37,0,1061,32]

theorem envBound16942 : H12AffineFastState.Bounded env16942 := by
  intro p hp
  have h : env16942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16941_16942 : H12AffineEnvironment.transform 3 1 env16941 = env16942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16941 == env16942) = true)

theorem identity16942 : scanCanonicalize (H12AffineFastState.compose env16942 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound16942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16943 : List Nat := [2,4,8,1,32,1,40,37,32,46,43,43,34,42,42,40,10,11,46,43,42,0,33,35,2,33,42,43,10,11,14,33,37,0,11,32]

theorem envBound16943 : H12AffineFastState.Bounded env16943 := by
  intro p hp
  have h : env16943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16942_16943 : H12AffineEnvironment.transform 9 46 env16942 = env16943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env16942 == env16943) = true)

theorem identity16943 : scanCanonicalize (H12AffineFastState.compose env16943 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16943 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16944 : List Nat := [2,4,8,1,0,1,8,5,0,14,11,11,2,10,10,8,10,11,14,11,10,0,1,3,2,1,10,11,10,11,14,1,5,0,11,0]

theorem envBound16944 : H12AffineFastState.Bounded env16944 := by
  intro p hp
  have h : env16944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16943_16944 : H12AffineEnvironment.transform 4 0 env16943 = env16944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16943 == env16944) = true)

def env16945 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1296,13593,1024,32769,4097,98306,5377,16777216,8328,5377,111647,4096,1296,1073741824,16876545,1090562471,256,1073817871,16876565,136]

theorem envBound16945 : H12AffineFastState.Bounded env16945 := by
  intro p hp
  have h : env16945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16922_16945 : H12AffineEnvironment.transform 17 13593 env16922 = env16945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env16922 == env16945) = true)

theorem identity16945 : scanCanonicalize (H12AffineFastState.compose env16945 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 5401) := by decide +kernel

theorem selectedBound16945 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16946 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5401,1296,13593,1024,32769,4097,38171,5377,16777216,8328,5377,41222,4096,1296,1073741824,16814360,1090562471,256,1073757206,16814348,136]

theorem envBound16946 : H12AffineFastState.Bounded env16946 := by
  intro p hp
  have h : env16946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16945_16946 : H12AffineEnvironment.transform 15 5401 env16945 = env16946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5401 env16945 == env16946) = true)

def env16947 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5401,1296,13593,1024,32769,4097,38171,5377,32776,8328,5377,41222,4096,1296,1073741824,4368,1073752495,256,1073757206,4356,136]

theorem envBound16947 : H12AffineFastState.Bounded env16947 := by
  intro p hp
  have h : env16947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16946_16947 : H12AffineEnvironment.transform 23 32776 env16946 = env16947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 32776 env16946 == env16947) = true)

theorem identity16947 : scanCanonicalize (H12AffineFastState.compose env16947 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 131) := by decide +kernel

theorem selectedBound16947 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16948 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,131,5401,1296,13593,1024,130,4097,5528,5377,139,8328,5377,8581,4096,1296,1073741824,4368,1073752495,256,1073757206,4356,136]

theorem envBound16948 : H12AffineFastState.Bounded env16948 := by
  intro p hp
  have h : env16948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16947_16948 : H12AffineEnvironment.transform 14 131 env16947 = env16948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 131 env16947 == env16948) = true)

def env16949 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,5401,1296,13593,1024,32769,4097,38171,5377,32777,8328,5377,41222,4096,1296,1073741824,4369,1073752494,256,1073757206,4357,136]

theorem envBound16949 : H12AffineFastState.Bounded env16949 := by
  intro p hp
  have h : env16949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16946_16949 : H12AffineEnvironment.transform 23 32777 env16946 = env16949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 32777 env16946 == env16949) = true)

theorem identity16949 : scanCanonicalize (H12AffineFastState.compose env16949 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 5271) := by decide +kernel

theorem selectedBound16949 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16950 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,5271,5401,1296,13593,1024,5270,4097,396,5377,5278,8328,5377,13713,4096,1296,1073741824,4369,1073752494,256,1073757206,4357,136]

theorem envBound16950 : H12AffineFastState.Bounded env16950 := by
  intro p hp
  have h : env16950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16949_16950 : H12AffineEnvironment.transform 14 5271 env16949 = env16950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5271 env16949 == env16950) = true)

def env16951 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,4096,8192,4097,5151,5401,1296,13593,1024,5150,4097,260,5377,5142,8192,5377,13593,4096,1296,1073741824,4369,1073752358,256,1073757206,4357,0]

theorem envBound16951 : H12AffineFastState.Bounded env16951 := by
  intro p hp
  have h : env16951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16950_16951 : H12AffineEnvironment.transform 6 8 env16950 = env16951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16950 == env16951) = true)

theorem identity16951 : scanCanonicalize (H12AffineFastState.compose env16951 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 13373) := by decide +kernel

theorem selectedBound16951 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16952 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,4096,8192,4097,5151,5401,1296,13593,1024,5150,4097,260,5377,5142,8192,5377,13593,4096,1296,13373,4369,7451,256,2091,4357,0]

theorem envBound16952 : H12AffineFastState.Bounded env16952 := by
  intro p hp
  have h : env16952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16951_16952 : H12AffineEnvironment.transform 29 13373 env16951 = env16952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13373 env16951 == env16952) = true)

theorem identity16952 : scanCanonicalize (H12AffineFastState.compose env16952 (packedSelected [1,2,4,6,7,12,13,23] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound16952 : packedSelected [1,2,4,6,7,12,13,23] rootPS < 2^1333 := by decide +kernel

def env16953 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,4096,2349,4097,5151,5401,1296,7220,1024,5150,4097,260,5377,5142,2349,5377,7220,4096,1296,7440,4369,7451,256,2091,4357,0]

theorem envBound16953 : H12AffineFastState.Bounded env16953 := by
  intro p hp
  have h : env16953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16952_16953 : H12AffineEnvironment.transform 12 2349 env16952 = env16953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env16952 == env16953) = true)

theorem identity16953 : scanCanonicalize (H12AffineFastState.compose env16953 (packedSelected [1,3,8,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound16953 : packedSelected [1,3,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env16954 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1297,2349,1296,270,8,1296,2341,1024,271,1296,260,16,263,2349,16,2341,1297,1296,2049,1024,2058,256,2091,1044,0]

theorem envBound16954 : H12AffineFastState.Bounded env16954 := by
  intro p hp
  have h : env16954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16953_16954 : H12AffineEnvironment.transform 11 1297 env16953 = env16954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16953 == env16954) = true)

def env16955 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,4096,8192,4097,5150,5401,1296,13593,1024,5151,4097,261,5377,5143,8193,5377,13592,4096,1296,1073741824,4369,1073752359,256,1073757206,4357,1]

theorem envBound16955 : H12AffineFastState.Bounded env16955 := by
  intro p hp
  have h : env16955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16950_16955 : H12AffineEnvironment.transform 6 9 env16950 = env16955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16950 == env16955) = true)

theorem identity16955 : scanCanonicalize (H12AffineFastState.compose env16955 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 8233) := by decide +kernel

theorem selectedBound16955 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16956 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,4096,8192,4097,5150,5401,1296,13593,1024,5151,4097,261,5377,5143,8193,5377,13592,4096,1296,8233,4369,2318,256,7231,4357,1]

theorem envBound16956 : H12AffineFastState.Bounded env16956 := by
  intro p hp
  have h : env16956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16955_16956 : H12AffineEnvironment.transform 29 8233 env16955 = env16956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8233 env16955 == env16956) = true)

theorem identity16956 : scanCanonicalize (H12AffineFastState.compose env16956 (packedSelected [1,2,4,6,7,12,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound16956 : packedSelected [1,2,4,6,7,12,13,23] rootPS < 2^1333 := by decide +kernel

def env16957 : List Nat := [2,4,8,16,32,16,9,256,1,1024,43,4096,8192,4097,5150,5401,1296,13593,1024,5151,4097,261,5377,5143,8193,5377,13592,4096,1296,8233,4369,293,256,5140,4357,1]

theorem envBound16957 : H12AffineFastState.Bounded env16957 := by
  intro p hp
  have h : env16957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16956_16957 : H12AffineEnvironment.transform 10 43 env16956 = env16957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env16956 == env16957) = true)

theorem identity16957 : scanCanonicalize (H12AffineFastState.compose env16957 (packedSelected [3,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound16957 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env16958 : List Nat := [2,4,8,16,32,16,9,256,1,1024,43,1044,8192,1045,10,269,1296,8461,1024,11,1045,261,277,3,8193,277,8460,1044,1296,8233,1285,293,256,0,1297,1]

theorem envBound16958 : H12AffineFastState.Bounded env16958 := by
  intro p hp
  have h : env16958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16957_16958 : H12AffineEnvironment.transform 11 1044 env16957 = env16958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16957 == env16958) = true)

theorem identity16958 : scanCanonicalize (H12AffineFastState.compose env16958 (packedSelected [1,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16958 : packedSelected [1,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env16959 : List Nat := [2,4,8,16,32,16,9,37,1,1024,43,1044,8192,1045,10,40,1077,8232,1024,11,1045,32,48,3,8193,48,8233,1044,1077,8233,1056,0,37,0,1076,1]

theorem envBound16959 : H12AffineFastState.Bounded env16959 := by
  intro p hp
  have h : env16959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16958_16959 : H12AffineEnvironment.transform 7 37 env16958 = env16959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16958 == env16959) = true)

theorem identity16959 : scanCanonicalize (H12AffineFastState.compose env16959 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound16959 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env16960 : List Nat := [2,4,8,16,26,16,9,31,1,1024,17,1044,8192,1045,10,18,1039,8210,1024,11,1045,26,10,3,8193,10,8211,1044,1039,8211,1050,0,31,0,1038,1]

theorem envBound16960 : H12AffineFastState.Bounded env16960 := by
  intro p hp
  have h : env16960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16959_16960 : H12AffineEnvironment.transform 4 26 env16959 = env16960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env16959 == env16960) = true)

theorem identity16960 : scanCanonicalize (H12AffineFastState.compose env16960 (packedSelected [0,2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound16960 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env16961 : List Nat := [2,4,8,16,26,16,9,31,1,1024,17,1044,8,1045,10,18,1039,26,1024,11,1045,26,10,3,9,10,27,1044,1039,27,1050,0,31,0,1038,1]

theorem envBound16961 : H12AffineFastState.Bounded env16961 := by
  intro p hp
  have h : env16961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16960_16961 : H12AffineEnvironment.transform 12 8 env16960 = env16961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16960 == env16961) = true)

theorem identity16961 : scanCanonicalize (H12AffineFastState.compose env16961 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound16961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16962 : List Nat := [2,4,8,16,26,16,9,31,1,4,17,16,8,17,10,18,11,26,4,11,17,26,10,3,9,10,27,16,11,27,30,0,31,0,10,1]

theorem envBound16962 : H12AffineFastState.Bounded env16962 := by
  intro p hp
  have h : env16962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16961_16962 : H12AffineEnvironment.transform 9 4 env16961 = env16962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env16961 == env16962) = true)

theorem identity16962 : scanCanonicalize (H12AffineFastState.compose env16962 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16962 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16963 : List Nat := [2,4,3,16,17,16,2,20,1,4,17,16,3,17,1,18,0,17,4,0,17,17,1,3,2,1,16,16,0,16,21,0,20,0,1,1]

theorem envBound16963 : H12AffineFastState.Bounded env16963 := by
  intro p hp
  have h : env16963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16962_16963 : H12AffineEnvironment.transform 2 3 env16962 = env16963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16962 == env16963) = true)

def env16964 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,16777216,8328,5377,4456708,4096,1296,1073741824,16876545,1094789541,256,1073817871,16876565,137]

theorem envBound16964 : H12AffineFastState.Bounded env16964 := by
  intro p hp
  have h : env16964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16920_16964 : H12AffineEnvironment.transform 8 137 env16920 = env16964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16920 == env16964) = true)

theorem identity16964 : scanCanonicalize (H12AffineFastState.compose env16964 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(23+1) ^^^ 4194567) := by decide +kernel

theorem selectedBound16964 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env16965 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,4194567,8328,5377,4456708,4096,1296,1073741824,4293894,1073817762,256,1073817871,4293906,137]

theorem envBound16965 : H12AffineFastState.Bounded env16965 := by
  intro p hp
  have h : env16965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16964_16965 : H12AffineEnvironment.transform 23 4194567 env16964 = env16965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4194567 env16964 == env16965) = true)

def env16966 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,13592,1024,32769,4097,4194304,5377,4194567,8328,5377,4207644,4096,1296,1073741824,4293894,1073817762,256,1073817871,4293906,137]

theorem envBound16966 : H12AffineFastState.Bounded env16966 := by
  intro p hp
  have h : env16966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16965_16966 : H12AffineEnvironment.transform 17 13592 env16965 = env16966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env16965 == env16966) = true)

theorem identity16966 : scanCanonicalize (H12AffineFastState.compose env16966 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 9) := by decide +kernel

theorem selectedBound16966 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16967 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,9,1296,13592,1024,32769,4097,4194304,5377,4194567,8328,5377,4207644,4096,1296,1073741824,4228367,1073752235,256,1073752326,4228379,137]

theorem envBound16967 : H12AffineFastState.Bounded env16967 := by
  intro p hp
  have h : env16967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16966_16967 : H12AffineEnvironment.transform 15 9 env16966 = env16967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env16966 == env16967) = true)

def env16968 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1044,8192,1045,32768,9,1296,8460,1024,32769,1045,4194304,277,4194567,8328,277,4202504,1044,1296,1073741824,4228367,1073752235,256,1073752326,4228379,137]

theorem envBound16968 : H12AffineFastState.Bounded env16968 := by
  intro p hp
  have h : env16968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16967_16968 : H12AffineEnvironment.transform 11 1044 env16967 = env16968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16967 == env16968) = true)

theorem identity16968 : scanCanonicalize (H12AffineFastState.compose env16968 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound16968 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16969 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1044,8192,1045,32768,9,1296,8460,1024,32769,1045,396,277,139,8328,277,8580,1044,1296,1073741824,33923,1073752235,256,1073752326,33943,137]

theorem envBound16969 : H12AffineFastState.Bounded env16969 := by
  intro p hp
  have h : env16969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16968_16969 : H12AffineEnvironment.transform 21 396 env16968 = env16969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env16968 == env16969) = true)

def env16970 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1045,8192,1044,32768,9,1296,8461,1024,32769,1044,4194304,276,4194567,8328,276,4202505,1045,1296,1073741824,4228367,1073752235,256,1073752326,4228379,137]

theorem envBound16970 : H12AffineFastState.Bounded env16970 := by
  intro p hp
  have h : env16970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16967_16970 : H12AffineEnvironment.transform 11 1045 env16967 = env16970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env16967 == env16970) = true)

theorem identity16970 : scanCanonicalize (H12AffineFastState.compose env16970 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 391) := by decide +kernel

theorem selectedBound16970 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16971 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1045,8192,1044,391,9,1296,8461,1024,390,1044,4194304,276,4194567,8328,276,4202505,1045,1296,1073741824,4195464,1073752235,256,1073752326,4195484,137]

theorem envBound16971 : H12AffineFastState.Bounded env16971 := by
  intro p hp
  have h : env16971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16970_16971 : H12AffineEnvironment.transform 14 391 env16970 = env16971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 391 env16970 == env16971) = true)

def env16972 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8192,1044,131,9,1044,8201,1024,130,1044,4194304,16,4194307,8328,16,4202505,1045,1044,1073741824,4195464,1073752235,4,1073752066,4195484,137]

theorem envBound16972 : H12AffineFastState.Bounded env16972 := by
  intro p hp
  have h : env16972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16971_16972 : H12AffineEnvironment.transform 7 4 env16971 = env16972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16971 == env16972) = true)

theorem identity16972 : scanCanonicalize (H12AffineFastState.compose env16972 (packedSelected [1,6,7,10] rootPS)) = affineNative (2^(29+1) ^^^ 4196352) := by decide +kernel

theorem selectedBound16972 : packedSelected [1,6,7,10] rootPS < 2^1333 := by decide +kernel

def env16973 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8192,1044,131,9,1044,8201,1024,130,1044,4194304,16,4194307,8328,16,4202505,1045,1044,4196352,4195464,4202667,4,4202498,4195484,137]

theorem envBound16973 : H12AffineFastState.Bounded env16973 := by
  intro p hp
  have h : env16973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16972_16973 : H12AffineEnvironment.transform 29 4196352 env16972 = env16973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196352 env16972 == env16973) = true)

theorem identity16973 : scanCanonicalize (H12AffineFastState.compose env16973 (packedSelected [6,7] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound16973 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env16974 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8192,1044,131,9,1044,8201,1024,130,1044,136,16,139,8328,16,8321,1045,1044,2184,1024,8227,4,8330,1044,137]

theorem envBound16974 : H12AffineFastState.Bounded env16974 := by
  intro p hp
  have h : env16974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16973_16974 : H12AffineEnvironment.transform 21 136 env16973 = env16974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env16973 == env16974) = true)

def env16975 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,130,9,1045,8200,1024,131,1044,4194304,17,4194306,8328,17,4202505,1045,1045,1073741824,4195464,1073752235,5,1073752067,4195484,137]

theorem envBound16975 : H12AffineFastState.Bounded env16975 := by
  intro p hp
  have h : env16975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16971_16975 : H12AffineEnvironment.transform 7 5 env16971 = env16975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16971 == env16975) = true)

theorem identity16975 : scanCanonicalize (H12AffineFastState.compose env16975 (packedSelected [1,6,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound16975 : packedSelected [1,6,7,10] rootPS < 2^1333 := by decide +kernel

def env16976 : List Nat := [2,4,8,16,32,16,128,5,137,1024,162,1045,8192,1044,130,9,1045,8200,1024,131,1044,4194304,17,4194306,8328,17,4202505,1045,1045,1073741824,4195464,1073750025,5,1073750177,4195484,137]

theorem envBound16976 : H12AffineFastState.Bounded env16976 := by
  intro p hp
  have h : env16976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16975_16976 : H12AffineEnvironment.transform 10 162 env16975 = env16976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env16975 == env16976) = true)

theorem identity16976 : scanCanonicalize (H12AffineFastState.compose env16976 (packedSelected [1,3,6,7,8] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound16976 : packedSelected [1,3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env16977 : List Nat := [2,4,8,16,32,16,128,5,137,1024,162,1045,8192,1044,130,9,1045,8200,1024,131,1044,136,17,138,8328,17,8321,1045,1045,1073741824,1024,1073750025,5,1073750177,1044,137]

theorem envBound16977 : H12AffineFastState.Bounded env16977 := by
  intro p hp
  have h : env16977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16976_16977 : H12AffineEnvironment.transform 21 136 env16976 = env16977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env16976 == env16977) = true)

theorem identity16977 : scanCanonicalize (H12AffineFastState.compose env16977 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16977 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16978 : List Nat := [2,4,8,16,32,16,128,5,137,20,162,1,8192,0,130,9,1,8200,20,131,0,136,17,138,8328,17,8321,1,1,1073741824,20,1073750025,5,1073750177,0,137]

theorem envBound16978 : H12AffineFastState.Bounded env16978 := by
  intro p hp
  have h : env16978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16977_16978 : H12AffineEnvironment.transform 9 20 env16977 = env16978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16977 == env16978) = true)

theorem identity16978 : scanCanonicalize (H12AffineFastState.compose env16978 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound16978 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16979 : List Nat := [2,4,8,16,32,16,35,5,42,20,1,1,8192,0,33,9,1,8200,20,32,0,43,17,41,8235,17,8226,1,1,1073741824,20,1073750025,5,1073750018,0,42]

theorem envBound16979 : H12AffineFastState.Bounded env16979 := by
  intro p hp
  have h : env16979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16978_16979 : H12AffineEnvironment.transform 6 35 env16978 = env16979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env16978 == env16979) = true)

theorem identity16979 : scanCanonicalize (H12AffineFastState.compose env16979 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound16979 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16980 : List Nat := [2,4,8,16,32,16,35,5,42,20,1,1,35,0,33,9,1,43,20,32,0,43,17,41,8,17,1,1,1,1073741824,20,1073741866,5,1073741857,0,42]

theorem envBound16980 : H12AffineFastState.Bounded env16980 := by
  intro p hp
  have h : env16980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16979_16980 : H12AffineEnvironment.transform 12 35 env16979 = env16980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env16979 == env16980) = true)

theorem identity16980 : scanCanonicalize (H12AffineFastState.compose env16980 (packedSelected [0,4] rootPS)) = affineNative (2^(29+1) ^^^ 33) := by decide +kernel

theorem selectedBound16980 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16981 : List Nat := [2,4,8,16,32,16,35,5,42,20,1,1,35,0,33,9,1,43,20,32,0,43,17,41,8,17,1,1,1,33,20,11,5,0,0,42]

theorem envBound16981 : H12AffineFastState.Bounded env16981 := by
  intro p hp
  have h : env16981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16980_16981 : H12AffineEnvironment.transform 29 33 env16980 = env16981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33 env16980 == env16981) = true)

theorem identity16981 : scanCanonicalize (H12AffineFastState.compose env16981 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16982 : List Nat := [2,4,8,16,16,16,19,5,26,20,1,1,19,0,17,9,1,27,20,16,0,27,17,25,8,17,1,1,1,17,20,11,5,0,0,26]

theorem envBound16982 : H12AffineFastState.Bounded env16982 := by
  intro p hp
  have h : env16982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16981_16982 : H12AffineEnvironment.transform 4 16 env16981 = env16982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16981 == env16982) = true)

theorem identity16982 : scanCanonicalize (H12AffineFastState.compose env16982 (packedSelected [0,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16982 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16983 : List Nat := [2,4,8,11,11,11,8,5,1,15,1,1,8,0,10,9,1,0,15,11,0,0,10,2,8,10,1,1,1,10,15,11,5,0,0,1]

theorem envBound16983 : H12AffineFastState.Bounded env16983 := by
  intro p hp
  have h : env16983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16982_16983 : H12AffineEnvironment.transform 3 11 env16982 = env16983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16982 == env16983) = true)

theorem identity16983 : scanCanonicalize (H12AffineFastState.compose env16983 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16984 : List Nat := [2,4,3,0,0,0,3,5,1,4,1,1,3,0,1,2,1,0,4,0,0,0,1,2,3,1,1,1,1,1,4,0,5,0,0,1]

theorem envBound16984 : H12AffineFastState.Bounded env16984 := by
  intro p hp
  have h : env16984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16983_16984 : H12AffineEnvironment.transform 2 3 env16983 = env16984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16983 == env16984) = true)

def env16985 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,13593,1024,32769,4097,4194304,5377,4194567,8328,5377,4207645,4096,1296,1073741824,4293894,1073817762,256,1073817871,4293906,137]

theorem envBound16985 : H12AffineFastState.Bounded env16985 := by
  intro p hp
  have h : env16985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16965_16985 : H12AffineEnvironment.transform 17 13593 env16965 = env16985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env16965 == env16985) = true)

theorem identity16985 : scanCanonicalize (H12AffineFastState.compose env16985 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 32778) := by decide +kernel

theorem selectedBound16985 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16986 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,13593,1024,32769,4097,32778,5377,33037,8328,5377,46103,4096,1296,1073741824,66828,1073817762,256,1073817871,66840,137]

theorem envBound16986 : H12AffineFastState.Bounded env16986 := by
  intro p hp
  have h : env16986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16985_16986 : H12AffineEnvironment.transform 21 32778 env16985 = env16986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32778 env16985 == env16986) = true)

def env16987 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,8,1296,13593,1024,32769,4097,32778,5377,33037,8328,5377,46103,4096,1296,1073741824,1284,1073752234,256,1073752327,1296,137]

theorem envBound16987 : H12AffineFastState.Bounded env16987 := by
  intro p hp
  have h : env16987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16986_16987 : H12AffineEnvironment.transform 15 8 env16986 = env16987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env16986 == env16987) = true)

theorem identity16987 : scanCanonicalize (H12AffineFastState.compose env16987 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 7229) := by decide +kernel

theorem selectedBound16987 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16988 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,7229,4097,32768,8,1296,2340,1024,32769,4097,32778,5377,33037,7349,5377,34858,4096,1296,1073741824,1284,1073747095,256,1073747258,1296,137]

theorem envBound16988 : H12AffineFastState.Bounded env16988 := by
  intro p hp
  have h : env16988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16987_16988 : H12AffineEnvironment.transform 12 7229 env16987 = env16988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7229 env16987 == env16988) = true)

theorem identity16988 : scanCanonicalize (H12AffineFastState.compose env16988 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 35086) := by decide +kernel

theorem selectedBound16988 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16989 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,7229,4097,32768,8,1296,2340,1024,32769,4097,32778,5377,33037,7349,5377,34858,4096,1296,35086,1284,40345,256,39988,1296,137]

theorem envBound16989 : H12AffineFastState.Bounded env16989 := by
  intro p hp
  have h : env16989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16988_16989 : H12AffineEnvironment.transform 29 35086 env16988 = env16989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35086 env16988 == env16989) = true)

theorem identity16989 : scanCanonicalize (H12AffineFastState.compose env16989 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 390) := by decide +kernel

theorem selectedBound16989 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16990 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,7229,4097,390,8,1296,2340,1024,391,4097,396,5377,139,7349,5377,2476,4096,1296,2184,1284,7199,256,7602,1296,137]

theorem envBound16990 : H12AffineFastState.Bounded env16990 := by
  intro p hp
  have h : env16990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16989_16990 : H12AffineEnvironment.transform 14 390 env16989 = env16990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 390 env16989 == env16990) = true)

theorem identity16990 : scanCanonicalize (H12AffineFastState.compose env16990 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound16990 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16991 : List Nat := [2,4,8,16,32,16,128,256,137,1024,162,4096,5279,4097,390,8,1296,390,1024,391,4097,396,5377,139,5143,5377,270,4096,1296,42,1284,5309,256,5392,1296,137]

theorem envBound16991 : H12AffineFastState.Bounded env16991 := by
  intro p hp
  have h : env16991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16990_16991 : H12AffineEnvironment.transform 10 162 env16990 = env16991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env16990 == env16991) = true)

theorem identity16991 : scanCanonicalize (H12AffineFastState.compose env16991 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound16991 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16992 : List Nat := [2,4,8,16,32,16,128,256,137,1024,162,1044,139,1045,390,8,1296,390,1024,391,1045,396,277,139,3,277,270,1044,1296,42,1284,169,256,260,1296,137]

theorem envBound16992 : H12AffineFastState.Bounded env16992 := by
  intro p hp
  have h : env16992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16991_16992 : H12AffineEnvironment.transform 11 1044 env16991 = env16992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16991 == env16992) = true)

theorem identity16992 : scanCanonicalize (H12AffineFastState.compose env16992 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16993 : List Nat := [2,4,8,16,32,16,40,256,33,1024,10,1044,35,1045,302,8,1296,302,1024,303,1045,292,277,35,3,277,270,1044,1296,42,1284,1,256,260,1296,33]

theorem envBound16993 : H12AffineFastState.Bounded env16993 := by
  intro p hp
  have h : env16993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16992_16993 : H12AffineEnvironment.transform 6 40 env16992 = env16993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16992 == env16993) = true)

def env16994 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,9,1296,13593,1024,32769,4097,32778,5377,33037,8328,5377,46103,4096,1296,1073741824,1285,1073752235,256,1073752326,1297,137]

theorem envBound16994 : H12AffineFastState.Bounded env16994 := by
  intro p hp
  have h : env16994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16986_16994 : H12AffineEnvironment.transform 15 9 env16986 = env16994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env16986 == env16994) = true)

theorem identity16994 : scanCanonicalize (H12AffineFastState.compose env16994 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 43276) := by decide +kernel

theorem selectedBound16994 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16995 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,9,1296,13593,1024,32769,4097,32778,5377,33037,8328,5377,46103,4096,1296,43276,1285,33191,256,32778,1297,137]

theorem envBound16995 : H12AffineFastState.Bounded env16995 := by
  intro p hp
  have h : env16995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16994_16995 : H12AffineEnvironment.transform 29 43276 env16994 = env16995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43276 env16994 == env16995) = true)

theorem identity16995 : scanCanonicalize (H12AffineFastState.compose env16995 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound16995 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16996 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1045,8192,1044,32768,9,1296,8460,1024,32769,1044,32778,276,33037,8328,276,40962,1045,1296,43276,1285,33191,256,32778,1297,137]

theorem envBound16996 : H12AffineFastState.Bounded env16996 := by
  intro p hp
  have h : env16996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16995_16996 : H12AffineEnvironment.transform 11 1045 env16995 = env16996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env16995 == env16996) = true)

theorem identity16996 : scanCanonicalize (H12AffineFastState.compose env16996 (packedSelected [3,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound16996 : packedSelected [3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env16997 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1045,171,1044,32768,9,1296,423,1024,32769,1044,32778,276,33037,35,276,32937,1045,1296,35239,1285,33191,256,32778,1297,137]

theorem envBound16997 : H12AffineFastState.Bounded env16997 := by
  intro p hp
  have h : env16997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16996_16997 : H12AffineEnvironment.transform 12 171 env16996 = env16997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env16996 == env16997) = true)

theorem identity16997 : scanCanonicalize (H12AffineFastState.compose env16997 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound16997 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env16998 : List Nat := [2,4,8,16,32,16,128,256,137,1024,162,1045,171,1044,32768,9,1296,423,1024,32769,1044,32778,276,33037,35,276,32937,1045,1296,33029,1285,33191,256,32778,1297,137]

theorem envBound16998 : H12AffineFastState.Bounded env16998 := by
  intro p hp
  have h : env16998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16997_16998 : H12AffineEnvironment.transform 10 162 env16997 = env16998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env16997 == env16998) = true)

theorem identity16998 : scanCanonicalize (H12AffineFastState.compose env16998 (packedSelected [1,5,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 390) := by decide +kernel

theorem selectedBound16998 : packedSelected [1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env16999 : List Nat := [2,4,8,16,32,16,128,256,137,1024,162,1045,171,1044,390,9,1296,423,1024,391,1044,396,276,139,35,276,303,1045,1296,131,1285,33,256,396,1297,137]

theorem envBound16999 : H12AffineFastState.Bounded env16999 := by
  intro p hp
  have h : env16999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16998_16999 : H12AffineEnvironment.transform 14 390 env16998 = env16999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 390 env16998 == env16999) = true)

theorem identity16999 : scanCanonicalize (H12AffineFastState.compose env16999 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16999 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17000 : List Nat := [2,4,8,16,32,16,128,36,137,1024,162,1045,171,1044,162,9,1076,131,1024,163,1044,168,48,139,35,48,11,1045,1076,131,1057,33,36,168,1077,137]

theorem envBound17000 : H12AffineFastState.Bounded env17000 := by
  intro p hp
  have h : env17000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16999_17000 : H12AffineEnvironment.transform 7 36 env16999 = env17000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16999 == env17000) = true)

def env17001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131345,32769,4097,4194304,5376,16777216,8328,135185,4588565,136465,1297,1073741824,17006864,1094921396,132113,1073949726,17006852,512]

theorem envBound17001 : H12AffineFastState.Bounded env17001 := by
  intro p hp
  have h : env17001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16918_17001 : H12AffineEnvironment.transform 18 131345 env16918 = env17001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131345 env16918 == env17001) = true)

theorem identity17001 : scanCanonicalize (H12AffineFastState.compose env17001 (packedSelected [0,27] rootPS)) = affineNative (2^(23+1) ^^^ 230421) := by decide +kernel

theorem selectedBound17001 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env17002 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131345,32769,4097,4194304,5376,230421,8328,135185,4588565,136465,1297,1073741824,1285,1077979297,132113,1073949726,1297,512]

theorem envBound17002 : H12AffineFastState.Bounded env17002 := by
  intro p hp
  have h : env17002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17001_17002 : H12AffineEnvironment.transform 23 230421 env17001 = env17002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230421 env17001 == env17002) = true)

theorem identity17002 : scanCanonicalize (H12AffineFastState.compose env17002 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 468663) := by decide +kernel

theorem selectedBound17002 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env17003 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131345,32769,4097,4194304,5376,230421,8328,135185,4588565,136465,1297,468663,1285,4689430,132113,264873,1297,512]

theorem envBound17003 : H12AffineFastState.Bounded env17003 := by
  intro p hp
  have h : env17003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17002_17003 : H12AffineEnvironment.transform 29 468663 env17002 = env17003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 468663 env17002 == env17003) = true)

def env17004 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,131072,262144,131345,32769,1297,4194304,16,230421,8328,132353,4588565,131073,1297,468663,1285,4689430,132113,264873,1297,512]

theorem envBound17004 : H12AffineFastState.Bounded env17004 := by
  intro p hp
  have h : env17004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17003_17004 : H12AffineEnvironment.transform 11 1296 env17003 = env17004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17003 == env17004) = true)

theorem identity17004 : scanCanonicalize (H12AffineFastState.compose env17004 (packedSelected [3,10,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 462364) := by decide +kernel

theorem selectedBound17004 : packedSelected [3,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env17005 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,131072,262144,131345,32769,1297,462364,16,230421,8328,132353,68105,131073,1297,468663,1285,32778,132113,264873,1297,512]

theorem envBound17005 : H12AffineFastState.Bounded env17005 := by
  intro p hp
  have h : env17005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17004_17005 : H12AffineEnvironment.transform 21 462364 env17004 = env17005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 462364 env17004 == env17005) = true)

theorem identity17005 : scanCanonicalize (H12AffineFastState.compose env17005 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 520) := by decide +kernel

theorem selectedBound17005 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17006 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,520,131072,262144,131345,32769,1297,396308,16,165405,8328,132353,2049,131073,1297,402623,1285,32778,132113,264873,1297,512]

theorem envBound17006 : H12AffineFastState.Bounded env17006 := by
  intro p hp
  have h : env17006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17005_17006 : H12AffineEnvironment.transform 15 520 env17005 = env17006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 520 env17005 == env17006) = true)

theorem identity17006 : scanCanonicalize (H12AffineFastState.compose env17006 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound17006 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17007 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,520,131072,43049,131345,32769,1297,173117,16,165405,8328,132353,2049,131073,1297,167062,1285,32778,132113,41600,1297,512]

theorem envBound17007 : H12AffineFastState.Bounded env17007 := by
  intro p hp
  have h : env17007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17006_17007 : H12AffineEnvironment.transform 17 43049 env17006 = env17007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env17006 == env17007) = true)

theorem identity17007 : scanCanonicalize (H12AffineFastState.compose env17007 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 3263) := by decide +kernel

theorem selectedBound17007 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17008 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,3263,1297,32768,520,131072,33942,131345,32769,1297,166018,16,165405,3127,132353,2049,131073,1297,167062,1285,32778,132113,36415,1297,512]

theorem envBound17008 : H12AffineFastState.Bounded env17008 := by
  intro p hp
  have h : env17008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17007_17008 : H12AffineEnvironment.transform 12 3263 env17007 = env17008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3263 env17007 == env17008) = true)

theorem identity17008 : scanCanonicalize (H12AffineFastState.compose env17008 (packedSelected [0,3,5,7,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 3735) := by decide +kernel

theorem selectedBound17008 : packedSelected [0,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17009 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,3263,1297,3735,520,131072,2561,131345,3734,1297,132629,16,133258,3127,132353,2049,131073,1297,131585,1285,3741,132113,168,1297,512]

theorem envBound17009 : H12AffineFastState.Bounded env17009 := by
  intro p hp
  have h : env17009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17008_17009 : H12AffineEnvironment.transform 14 3735 env17008 = env17009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3735 env17008 == env17009) = true)

theorem identity17009 : scanCanonicalize (H12AffineFastState.compose env17009 (packedSelected [0,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 2049) := by decide +kernel

theorem selectedBound17009 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env17010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,3263,1297,3735,520,2049,2561,2320,3734,1297,3604,16,139,3127,3328,2049,2048,1297,2560,1285,3741,3088,168,1297,512]

theorem envBound17010 : H12AffineFastState.Bounded env17010 := by
  intro p hp
  have h : env17010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17009_17010 : H12AffineEnvironment.transform 16 2049 env17009 = env17010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2049 env17009 == env17010) = true)

theorem identity17010 : scanCanonicalize (H12AffineFastState.compose env17010 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17010 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17011 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1296,1296,431,1297,903,520,1297,1809,1024,902,1297,772,16,139,295,16,1297,1296,1297,1808,1285,909,256,168,1297,512]

theorem envBound17011 : H12AffineFastState.Bounded env17011 := by
  intro p hp
  have h : env17011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17010_17011 : H12AffineEnvironment.transform 10 1296 env17010 = env17011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env17010 == env17011) = true)

theorem identity17011 : scanCanonicalize (H12AffineFastState.compose env17011 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound17011 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17012 : List Nat := [2,4,8,16,32,16,128,256,270,1024,1296,1296,431,1297,137,262,1297,1055,1024,136,1297,10,16,139,295,16,1297,1296,1297,1054,1285,131,256,168,1297,270]

theorem envBound17012 : H12AffineFastState.Bounded env17012 := by
  intro p hp
  have h : env17012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17011_17012 : H12AffineEnvironment.transform 8 270 env17011 = env17012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env17011 == env17012) = true)

theorem identity17012 : scanCanonicalize (H12AffineFastState.compose env17012 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound17012 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17013 : List Nat := [2,4,8,16,32,16,35,256,270,1024,1296,1296,268,1297,42,262,1297,1055,1024,43,1297,10,16,40,295,16,1297,1296,1297,1054,1285,32,256,11,1297,270]

theorem envBound17013 : H12AffineFastState.Bounded env17013 := by
  intro p hp
  have h : env17013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17012_17013 : H12AffineEnvironment.transform 6 35 env17012 = env17013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env17012 == env17013) = true)

theorem identity17013 : scanCanonicalize (H12AffineFastState.compose env17013 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound17013 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17014 : List Nat := [2,4,8,16,32,16,35,256,270,272,0,0,268,1,42,262,1,271,272,43,1,10,16,40,295,16,1,0,1,270,21,32,256,11,1,270]

theorem envBound17014 : H12AffineFastState.Bounded env17014 := by
  intro p hp
  have h : env17014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17013_17014 : H12AffineEnvironment.transform 9 272 env17013 = env17014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17013 == env17014) = true)

theorem identity17014 : scanCanonicalize (H12AffineFastState.compose env17014 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound17014 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17015 : List Nat := [2,4,3,16,32,16,35,256,261,272,0,0,263,1,33,262,1,260,272,32,1,1,16,35,295,16,1,0,1,261,21,32,256,0,1,261]

theorem envBound17015 : H12AffineFastState.Bounded env17015 := by
  intro p hp
  have h : env17015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17014_17015 : H12AffineEnvironment.transform 2 3 env17014 = env17015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env17014 == env17015) = true)

theorem identity17015 : scanCanonicalize (H12AffineFastState.compose env17015 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17015 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17016 : List Nat := [2,4,3,16,32,16,35,4,1,20,0,0,3,1,33,2,1,0,20,32,1,1,16,35,35,16,1,0,1,1,21,32,4,0,1,1]

theorem envBound17016 : H12AffineFastState.Bounded env17016 := by
  intro p hp
  have h : env17016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17015_17016 : H12AffineEnvironment.transform 7 4 env17015 = env17016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17015 == env17016) = true)

theorem identity17016 : scanCanonicalize (H12AffineFastState.compose env17016 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17017 : List Nat := [2,4,3,1,32,1,35,4,1,5,0,0,3,1,33,2,1,0,5,32,1,1,1,35,35,1,1,0,1,1,4,32,4,0,1,1]

theorem envBound17017 : H12AffineFastState.Bounded env17017 := by
  intro p hp
  have h : env17017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17016_17017 : H12AffineEnvironment.transform 3 1 env17016 = env17017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17016 == env17017) = true)

def env17018 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,131072,262144,131345,32769,1296,4194304,17,230421,8328,132352,4588565,131072,1297,468663,1285,4689430,132113,264873,1297,512]

theorem envBound17018 : H12AffineFastState.Bounded env17018 := by
  intro p hp
  have h : env17018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17003_17018 : H12AffineEnvironment.transform 11 1297 env17003 = env17018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17003 == env17018) = true)

theorem identity17018 : scanCanonicalize (H12AffineFastState.compose env17018 (packedSelected [3,10,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 238781) := by decide +kernel

theorem selectedBound17018 : packedSelected [3,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env17019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,131072,262144,131345,32769,1296,238781,17,230421,8328,132352,368808,131072,1297,468663,1285,273067,132113,264873,1297,512]

theorem envBound17019 : H12AffineFastState.Bounded env17019 := by
  intro p hp
  have h : env17019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17018_17019 : H12AffineEnvironment.transform 21 238781 env17018 = env17019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 238781 env17018 == env17019) = true)

theorem identity17019 : scanCanonicalize (H12AffineFastState.compose env17019 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound17019 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,129,131072,262144,131345,32769,1296,173116,17,165012,8328,132352,303145,131072,1297,402998,1285,273067,132113,264873,1297,512]

theorem envBound17020 : H12AffineFastState.Bounded env17020 := by
  intro p hp
  have h : env17020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17019_17020 : H12AffineEnvironment.transform 15 129 env17019 = env17020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env17019 == env17020) = true)

theorem identity17020 : scanCanonicalize (H12AffineFastState.compose env17020 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound17020 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,129,131072,43049,131345,32769,1296,173116,17,165012,8328,132352,2048,131072,1297,167455,1285,33410,132113,41600,1297,512]

theorem envBound17021 : H12AffineFastState.Bounded env17021 := by
  intro p hp
  have h : env17021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17020_17021 : H12AffineEnvironment.transform 17 43049 env17020 = env17021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env17020 == env17021) = true)

theorem identity17021 : scanCanonicalize (H12AffineFastState.compose env17021 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 806) := by decide +kernel

theorem selectedBound17021 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,806,1296,32768,129,131072,35599,131345,32769,1296,165658,17,165012,942,132352,2048,131072,1297,167455,1285,33410,132113,33190,1297,512]

theorem envBound17022 : H12AffineFastState.Bounded env17022 := by
  intro p hp
  have h : env17022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17021_17022 : H12AffineEnvironment.transform 12 806 env17021 = env17022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 806 env17021 == env17022) = true)

theorem identity17022 : scanCanonicalize (H12AffineFastState.compose env17022 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17022 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env17023 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,806,1296,32768,129,1297,35599,1024,32769,1296,33291,17,33157,942,17,2048,1297,1297,35598,1285,33410,256,33190,1297,512]

theorem envBound17023 : H12AffineFastState.Bounded env17023 := by
  intro p hp
  have h : env17023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17022_17023 : H12AffineEnvironment.transform 16 1297 env17022 = env17023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env17022 == env17023) = true)

theorem identity17023 : scanCanonicalize (H12AffineFastState.compose env17023 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 315) := by decide +kernel

theorem selectedBound17023 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17024 : List Nat := [2,4,8,16,32,16,128,256,512,315,2048,42,806,43,32768,129,42,35599,315,32769,43,33291,17,33157,942,17,2048,42,42,35598,62,33410,256,33190,42,512]

theorem envBound17024 : H12AffineFastState.Bounded env17024 := by
  intro p hp
  have h : env17024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17023_17024 : H12AffineEnvironment.transform 9 315 env17023 = env17024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 315 env17023 == env17024) = true)

def env17025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,524288,32769,4097,4194304,660496,16777216,8328,135185,4982021,529408,656384,1073741824,17399809,4294967296,525568,4315938986,17399829,512]

theorem envBound17025 : H12AffineFastState.Bounded env17025 := by
  intro p hp
  have h : env17025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16916_17025 : H12AffineEnvironment.transform 5 17 env16916 = env17025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16916 == env17025) = true)

def env17026 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131344,32769,4097,4194304,5376,16777216,8328,135185,4588565,136464,1296,1073741824,17006865,4294967296,132112,4315938986,17006853,512]

theorem envBound17026 : H12AffineFastState.Bounded env17026 := by
  intro p hp
  have h : env17026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17025_17026 : H12AffineEnvironment.transform 18 131344 env17025 = env17026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131344 env17025 == env17026) = true)

theorem identity17026 : scanCanonicalize (H12AffineFastState.compose env17026 (packedSelected [0,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound17026 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env17027 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131344,32769,4097,4194304,5376,98564,8328,135185,4588565,136464,1296,1073741824,131093,4294967296,132112,4299260334,131073,512]

theorem envBound17027 : H12AffineFastState.Bounded env17027 := by
  intro p hp
  have h : env17027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17026_17027 : H12AffineEnvironment.transform 23 98564 env17026 = env17027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env17026 == env17027) = true)

theorem identity17027 : scanCanonicalize (H12AffineFastState.compose env17027 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound17027 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env17028 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131344,32769,4097,4194304,5376,98564,8328,135185,4588565,136464,1296,4497708,131093,4294967296,132112,4299260334,131073,512]

theorem envBound17028 : H12AffineFastState.Bounded env17028 := by
  intro p hp
  have h : env17028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17027_17028 : H12AffineEnvironment.transform 29 4497708 env17027 = env17028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env17027 == env17028) = true)

theorem identity17028 : scanCanonicalize (H12AffineFastState.compose env17028 (packedSelected [10,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 175417) := by decide +kernel

theorem selectedBound17028 : packedSelected [10,12,17] rootPS < 2^1333 := by decide +kernel

def env17029 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,175417,131344,32769,4097,4194304,5376,98564,8328,135185,4237612,136464,1296,4328469,131093,4294967296,132112,4299260334,131073,512]

theorem envBound17029 : H12AffineFastState.Bounded env17029 := by
  intro p hp
  have h : env17029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17028_17029 : H12AffineEnvironment.transform 17 175417 env17028 = env17029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 175417 env17028 == env17029) = true)

def env17030 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,175417,131344,32769,4097,10248,5376,98564,8328,135185,33060,136464,1296,140317,131093,4294967296,132112,4295076262,131073,512]

theorem envBound17030 : H12AffineFastState.Bounded env17030 := by
  intro p hp
  have h : env17030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17029_17030 : H12AffineEnvironment.transform 21 10248 env17029 = env17030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env17029 == env17030) = true)

theorem identity17030 : scanCanonicalize (H12AffineFastState.compose env17030 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound17030 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17031 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,48441,4368,32769,4097,10248,5376,98564,8328,17,33060,1296,1296,13341,4117,4294967296,5136,4295076262,4097,512]

theorem envBound17031 : H12AffineFastState.Bounded env17031 := by
  intro p hp
  have h : env17031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17030_17031 : H12AffineEnvironment.transform 16 4096 env17030 = env17031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env17030 == env17031) = true)

theorem identity17031 : scanCanonicalize (H12AffineFastState.compose env17031 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound17031 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env17032 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2341,65536,4096,13340,4368,2340,4097,10248,5376,67617,8328,17,2049,1296,1296,13341,4117,4294967296,5136,4295041155,4097,512]

theorem envBound17032 : H12AffineFastState.Bounded env17032 := by
  intro p hp
  have h : env17032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17031_17032 : H12AffineEnvironment.transform 14 2341 env17031 = env17032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env17031 == env17032) = true)

def env17033 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,2341,65536,1296,8460,1024,2340,1297,10248,16,67617,8328,17,2049,1296,1296,8461,1285,4294967296,256,4295041155,1297,512]

theorem envBound17033 : H12AffineFastState.Bounded env17033 := by
  intro p hp
  have h : env17033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17032_17033 : H12AffineEnvironment.transform 11 1296 env17032 = env17033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17032 == env17033) = true)

theorem identity17033 : scanCanonicalize (H12AffineFastState.compose env17033 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17033 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17034 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2317,1297,2341,65536,1296,2049,1024,2340,1297,261,16,67617,2437,17,2049,1296,1296,2048,1285,4294967296,256,4295035278,1297,512]

theorem envBound17034 : H12AffineFastState.Bounded env17034 := by
  intro p hp
  have h : env17034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17033_17034 : H12AffineEnvironment.transform 12 2317 env17033 = env17034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17033 == env17034) = true)

def env17035 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2317,1,2341,65536,0,2049,272,2340,1,261,16,67617,2437,17,2049,0,0,2048,21,4294967296,256,4295035278,1,512]

theorem envBound17035 : H12AffineFastState.Bounded env17035 := by
  intro p hp
  have h : env17035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17034_17035 : H12AffineEnvironment.transform 9 272 env17034 = env17035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17034 == env17035) = true)

theorem identity17035 : scanCanonicalize (H12AffineFastState.compose env17035 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 397) := by decide +kernel

theorem selectedBound17035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17036 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2317,1,2341,65536,0,2049,272,2340,1,261,16,67617,2437,17,2049,0,0,2048,21,397,256,67587,1,512]

theorem envBound17036 : H12AffineFastState.Bounded env17036 := by
  intro p hp
  have h : env17036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17035_17036 : H12AffineEnvironment.transform 31 397 env17035 = env17036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 397 env17035 == env17036) = true)

def env17037 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,0,2317,1,2341,65536,0,2049,272,2340,1,261,16,67617,2317,17,2049,0,0,2048,21,261,256,67587,1,512]

theorem envBound17037 : H12AffineFastState.Bounded env17037 := by
  intro p hp
  have h : env17037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17036_17037 : H12AffineEnvironment.transform 6 8 env17036 = env17037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17036 == env17037) = true)

theorem identity17037 : scanCanonicalize (H12AffineFastState.compose env17037 (packedSelected [0,2,6] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound17037 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17038 : List Nat := [2,4,8,16,32,17,8,256,260,272,2048,0,2317,1,2341,65536,0,2049,272,2340,1,261,16,67617,2317,17,2049,0,0,2048,21,261,256,67587,1,260]

theorem envBound17038 : H12AffineFastState.Bounded env17038 := by
  intro p hp
  have h : env17038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17037_17038 : H12AffineEnvironment.transform 8 260 env17037 = env17038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env17037 == env17038) = true)

theorem identity17038 : scanCanonicalize (H12AffineFastState.compose env17038 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound17038 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17039 : List Nat := [2,4,8,16,32,17,8,256,260,272,2048,0,2317,1,2341,2082,0,2049,272,2340,1,261,16,3,2317,17,2049,0,0,2048,21,261,256,33,1,260]

theorem envBound17039 : H12AffineFastState.Bounded env17039 := by
  intro p hp
  have h : env17039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17038_17039 : H12AffineEnvironment.transform 15 2082 env17038 = env17039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env17038 == env17039) = true)

theorem identity17039 : scanCanonicalize (H12AffineFastState.compose env17039 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17040 : List Nat := [2,4,8,16,1,17,8,256,260,272,2048,0,2317,1,2308,2051,0,2049,272,2309,1,261,16,3,2317,17,2049,0,0,2048,21,261,256,0,1,260]

theorem envBound17040 : H12AffineFastState.Bounded env17040 := by
  intro p hp
  have h : env17040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17039_17040 : H12AffineEnvironment.transform 4 1 env17039 = env17040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17039 == env17040) = true)

def leafEnv17040 : List Nat := [2,4,8,16,1,17,8,256,260,272,2048,0,2317,1,2308,2051,0,2049,272,2309,1,261,16,3,21,2317,1,17,2049,0,0,2048,21,261,256,0,4,2050,1,260,0,1,1]

def active17040 : List Nat := [0,1,2,3,7,10]

def tree17040 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17040 : H12WitnessSearch.Good tree17040 := H12GlobalWitnessIndex.good

theorem leafIdentity17040 : H12AffineFastState.composeSystem env17040 rootObs = leafEnv17040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17040 rootObs == leafEnv17040) = true)

theorem terminalChecked17040 : H12PackedTerminal.terminalCheckFast leafEnv17040 active17040 tree17040 = true := by decide +kernel

def env17041 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,0,2317,1,2341,65536,0,2049,272,2340,1,261,16,67617,2316,17,2049,0,0,2048,21,260,256,67587,1,512]

theorem envBound17041 : H12AffineFastState.Bounded env17041 := by
  intro p hp
  have h : env17041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17036_17041 : H12AffineEnvironment.transform 6 9 env17036 = env17041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17036 == env17041) = true)

theorem identity17041 : scanCanonicalize (H12AffineFastState.compose env17041 (packedSelected [0,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17041 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17042 : List Nat := [2,4,8,16,0,17,9,256,512,272,2048,0,2317,1,2309,65536,0,2049,272,2308,1,261,16,67585,2316,17,2049,0,0,2048,21,260,256,67587,1,512]

theorem envBound17042 : H12AffineFastState.Bounded env17042 := by
  intro p hp
  have h : env17042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17041_17042 : H12AffineEnvironment.transform 4 0 env17041 = env17042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17041 == env17042) = true)

def env17043 : List Nat := [2,4,8,16,0,17,9,256,512,272,260,0,9,1,1,65536,0,261,272,0,1,261,16,65797,8,17,261,0,0,260,21,260,256,65799,1,512]

theorem envBound17043 : H12AffineFastState.Bounded env17043 := by
  intro p hp
  have h : env17043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17042_17043 : H12AffineEnvironment.transform 10 260 env17042 = env17043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17042 == env17043) = true)

theorem identity17043 : scanCanonicalize (H12AffineFastState.compose env17043 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound17043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17044 : List Nat := [2,4,8,16,0,17,9,256,512,272,260,0,9,1,1,515,0,261,272,0,1,261,16,774,8,17,261,0,0,260,21,260,256,772,1,512]

theorem envBound17044 : H12AffineFastState.Bounded env17044 := by
  intro p hp
  have h : env17044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17043_17044 : H12AffineEnvironment.transform 15 515 env17043 = env17044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env17043 == env17044) = true)

theorem identity17044 : scanCanonicalize (H12AffineFastState.compose env17044 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17044 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17045 : List Nat := [2,4,8,16,0,17,9,5,512,21,1,0,9,1,1,515,0,0,21,0,1,0,16,515,8,17,0,0,0,1,21,1,5,513,1,512]

theorem envBound17045 : H12AffineFastState.Bounded env17045 := by
  intro p hp
  have h : env17045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17044_17045 : H12AffineEnvironment.transform 7 5 env17044 = env17045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17044 == env17045) = true)

theorem identity17045 : scanCanonicalize (H12AffineFastState.compose env17045 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17045 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17046 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,9,1,1,2,0,0,21,0,1,0,16,2,8,17,0,0,0,1,21,1,5,0,1,1]

theorem envBound17046 : H12AffineFastState.Bounded env17046 := by
  intro p hp
  have h : env17046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17045_17046 : H12AffineEnvironment.transform 8 1 env17045 = env17046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17045 == env17046) = true)

def leafEnv17046 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,9,1,1,2,0,0,21,0,1,0,16,2,21,8,1,17,0,0,0,1,21,1,5,0,4,2,1,1,0,1,1]

def active17046 : List Nat := [0,1,2,3]

def tree17046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17046 : H12WitnessSearch.Good tree17046 := H12GlobalWitnessIndex.good

theorem leafIdentity17046 : H12AffineFastState.composeSystem env17046 rootObs = leafEnv17046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17046 rootObs == leafEnv17046) = true)

theorem terminalChecked17046 : H12PackedTerminal.terminalCheckFast leafEnv17046 active17046 tree17046 = true := by decide +kernel

def env17047 : List Nat := [2,4,8,16,0,17,9,256,512,272,261,0,8,1,0,65536,0,260,272,1,1,261,16,65796,9,17,260,0,0,261,21,260,256,65798,1,512]

theorem envBound17047 : H12AffineFastState.Bounded env17047 := by
  intro p hp
  have h : env17047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17042_17047 : H12AffineEnvironment.transform 10 261 env17042 = env17047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17042 == env17047) = true)

theorem identity17047 : scanCanonicalize (H12AffineFastState.compose env17047 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound17047 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17048 : List Nat := [2,4,8,16,0,17,9,256,260,272,261,0,8,1,0,65536,0,260,272,1,1,261,16,65796,9,17,260,0,0,261,21,260,256,65798,1,260]

theorem envBound17048 : H12AffineFastState.Bounded env17048 := by
  intro p hp
  have h : env17048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17047_17048 : H12AffineEnvironment.transform 8 260 env17047 = env17048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env17047 == env17048) = true)

theorem identity17048 : scanCanonicalize (H12AffineFastState.compose env17048 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17048 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17049 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,0,8,1,0,65536,0,1,21,1,1,0,16,65537,9,17,1,0,0,0,21,1,5,65539,1,1]

theorem envBound17049 : H12AffineFastState.Bounded env17049 := by
  intro p hp
  have h : env17049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17048_17049 : H12AffineEnvironment.transform 7 5 env17048 = env17049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17048 == env17049) = true)

def leafEnv17049 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,0,8,1,0,65536,0,1,21,1,1,0,16,65537,21,9,1,17,1,0,0,0,21,1,5,65539,4,3,1,1,0,1,1]

def active17049 : List Nat := [0,1,2,3,15]

def tree17049 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17049 : H12WitnessSearch.Good tree17049 := H12GlobalWitnessIndex.good

theorem leafIdentity17049 : H12AffineFastState.composeSystem env17049 rootObs = leafEnv17049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17049 rootObs == leafEnv17049) = true)

theorem terminalChecked17049 : H12PackedTerminal.terminalCheckFast leafEnv17049 active17049 tree17049 = true := by decide +kernel

def env17050 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2317,0,2341,65536,1,2049,273,2340,0,261,16,67617,2437,17,2049,1,1,2048,20,4294967296,256,4295035278,0,512]

theorem envBound17050 : H12AffineFastState.Bounded env17050 := by
  intro p hp
  have h : env17050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17034_17050 : H12AffineEnvironment.transform 9 273 env17034 = env17050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17034 == env17050) = true)

theorem identity17050 : scanCanonicalize (H12AffineFastState.compose env17050 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 67879) := by decide +kernel

theorem selectedBound17050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17051 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2317,0,2341,65536,1,2049,273,2340,0,261,16,67617,2437,17,2049,1,1,2048,20,67879,256,169,0,512]

theorem envBound17051 : H12AffineFastState.Bounded env17051 := by
  intro p hp
  have h : env17051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17050_17051 : H12AffineEnvironment.transform 31 67879 env17050 = env17051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67879 env17050 == env17051) = true)

def env17052 : List Nat := [2,4,8,16,32,17,128,256,428,273,2048,1,2317,0,2341,65536,1,2049,273,2340,0,261,16,67617,2437,17,2049,1,1,2048,20,67879,256,169,0,428]

theorem envBound17052 : H12AffineFastState.Bounded env17052 := by
  intro p hp
  have h : env17052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17051_17052 : H12AffineEnvironment.transform 8 428 env17051 = env17052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env17051 == env17052) = true)

theorem identity17052 : scanCanonicalize (H12AffineFastState.compose env17052 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17052 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17053 : List Nat := [2,4,8,16,0,17,128,256,396,273,2048,1,2317,0,2309,65536,1,2049,273,2308,0,261,16,67585,2437,17,2049,1,1,2048,20,67847,256,137,0,396]

theorem envBound17053 : H12AffineFastState.Bounded env17053 := by
  intro p hp
  have h : env17053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17052_17053 : H12AffineEnvironment.transform 4 0 env17052 = env17053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17052 == env17053) = true)

def env17054 : List Nat := [2,4,8,16,0,17,128,256,396,273,260,1,9,0,1,65536,1,261,273,0,0,261,16,65797,129,17,261,1,1,260,20,65539,256,137,0,396]

theorem envBound17054 : H12AffineFastState.Bounded env17054 := by
  intro p hp
  have h : env17054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17053_17054 : H12AffineEnvironment.transform 10 260 env17053 = env17054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17053 == env17054) = true)

def env17055 : List Nat := [2,4,8,16,0,17,128,256,396,273,261,1,8,0,0,65536,1,260,273,1,0,261,16,65796,128,17,260,1,1,261,20,65538,256,137,0,396]

theorem envBound17055 : H12AffineFastState.Bounded env17055 := by
  intro p hp
  have h : env17055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17053_17055 : H12AffineEnvironment.transform 10 261 env17053 = env17055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17053 == env17055) = true)

theorem identity17055 : scanCanonicalize (H12AffineFastState.compose env17055 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound17055 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17056 : List Nat := [2,4,8,16,0,17,128,256,396,273,261,1,8,0,0,398,1,260,273,1,0,261,16,138,128,17,260,1,1,261,20,396,256,137,0,396]

theorem envBound17056 : H12AffineFastState.Bounded env17056 := by
  intro p hp
  have h : env17056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17055_17056 : H12AffineEnvironment.transform 15 398 env17055 = env17056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env17055 == env17056) = true)

theorem identity17056 : scanCanonicalize (H12AffineFastState.compose env17056 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17056 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17057 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,0,0,138,1,0,21,1,0,1,16,138,128,17,0,1,1,1,20,136,4,137,0,136]

theorem envBound17057 : H12AffineFastState.Bounded env17057 := by
  intro p hp
  have h : env17057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17056_17057 : H12AffineEnvironment.transform 7 4 env17056 = env17057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17056 == env17057) = true)

def env17058 : List Nat := [2,4,8,16,32,17,128,256,429,273,2048,1,2317,0,2341,65536,1,2049,273,2340,0,261,16,67617,2437,17,2049,1,1,2048,20,67879,256,169,0,429]

theorem envBound17058 : H12AffineFastState.Bounded env17058 := by
  intro p hp
  have h : env17058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17051_17058 : H12AffineEnvironment.transform 8 429 env17051 = env17058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env17051 == env17058) = true)

theorem identity17058 : scanCanonicalize (H12AffineFastState.compose env17058 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound17058 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17059 : List Nat := [2,4,8,16,32,17,128,256,429,273,2048,1,2317,0,2341,2051,1,2049,273,2340,0,261,16,34,2437,17,2049,1,1,2048,20,292,256,169,0,429]

theorem envBound17059 : H12AffineFastState.Bounded env17059 := by
  intro p hp
  have h : env17059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17058_17059 : H12AffineEnvironment.transform 15 2051 env17058 = env17059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env17058 == env17059) = true)

def env17060 : List Nat := [2,4,8,16,32,17,40,256,261,273,2048,1,2317,0,2341,2051,1,2049,273,2340,0,261,16,34,2349,17,2049,1,1,2048,20,292,256,1,0,261]

theorem envBound17060 : H12AffineFastState.Bounded env17060 := by
  intro p hp
  have h : env17060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17059_17060 : H12AffineEnvironment.transform 6 40 env17059 = env17060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17059 == env17060) = true)

theorem identity17060 : scanCanonicalize (H12AffineFastState.compose env17060 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound17060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17061 : List Nat := [2,4,8,16,32,17,40,256,261,273,293,1,40,0,0,294,1,292,273,1,0,261,16,34,8,17,292,1,1,293,20,292,256,1,0,261]

theorem envBound17061 : H12AffineFastState.Bounded env17061 := by
  intro p hp
  have h : env17061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17060_17061 : H12AffineEnvironment.transform 10 293 env17060 = env17061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17060 == env17061) = true)

theorem identity17061 : scanCanonicalize (H12AffineFastState.compose env17061 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17061 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17062 : List Nat := [2,4,8,16,32,17,40,37,32,52,0,1,40,0,0,3,1,1,52,1,0,32,16,34,8,17,1,1,1,0,20,1,37,1,0,32]

theorem envBound17062 : H12AffineFastState.Bounded env17062 := by
  intro p hp
  have h : env17062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17061_17062 : H12AffineEnvironment.transform 7 37 env17061 = env17062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17061 == env17062) = true)

theorem identity17062 : scanCanonicalize (H12AffineFastState.compose env17062 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17063 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,8,0,0,3,1,1,20,1,0,0,16,2,8,17,1,1,1,0,20,1,5,1,0,0]

theorem envBound17063 : H12AffineFastState.Bounded env17063 := by
  intro p hp
  have h : env17063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17062_17063 : H12AffineEnvironment.transform 4 0 env17062 = env17063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17062 == env17063) = true)

def leafEnv17063 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,8,0,0,3,1,1,20,1,0,0,16,2,20,8,1,17,1,1,1,0,20,1,5,1,4,3,0,0,0,0,1]

def active17063 : List Nat := [0,1,2,3]

def tree17063 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17063 : H12WitnessSearch.Good tree17063 := H12GlobalWitnessIndex.good

theorem leafIdentity17063 : H12AffineFastState.composeSystem env17063 rootObs = leafEnv17063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17063 rootObs == leafEnv17063) = true)

theorem terminalChecked17063 : H12PackedTerminal.terminalCheckFast leafEnv17063 active17063 tree17063 = true := by decide +kernel

def env17064 : List Nat := [2,4,8,16,32,17,41,256,260,273,2048,1,2317,0,2341,2051,1,2049,273,2340,0,261,16,34,2348,17,2049,1,1,2048,20,292,256,0,0,260]

theorem envBound17064 : H12AffineFastState.Bounded env17064 := by
  intro p hp
  have h : env17064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17059_17064 : H12AffineEnvironment.transform 6 41 env17059 = env17064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17059 == env17064) = true)

def env17065 : List Nat := [2,4,8,16,0,17,9,256,260,273,2048,1,2317,0,2309,2051,1,2049,273,2308,0,261,16,2,2316,17,2049,1,1,2048,20,260,256,0,0,260]

theorem envBound17065 : H12AffineFastState.Bounded env17065 := by
  intro p hp
  have h : env17065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17064_17065 : H12AffineEnvironment.transform 4 0 env17064 = env17065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17064 == env17065) = true)

theorem identity17065 : scanCanonicalize (H12AffineFastState.compose env17065 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17066 : List Nat := [2,4,8,16,0,17,9,5,1,20,2048,1,2056,0,2048,2051,1,2049,20,2049,0,0,16,2,2057,17,2049,1,1,2048,20,1,5,0,0,1]

theorem envBound17066 : H12AffineFastState.Bounded env17066 := by
  intro p hp
  have h : env17066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17065_17066 : H12AffineEnvironment.transform 7 5 env17065 = env17066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17065 == env17066) = true)

def leafEnv17066 : List Nat := [2,4,8,16,0,17,9,5,1,20,2048,1,2056,0,2048,2051,1,2049,20,2049,0,0,16,2,20,2057,1,17,2049,1,1,2048,20,1,5,0,4,2051,0,1,0,0,1]

def active17066 : List Nat := [0,1,2,3,10]

def tree17066 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17066 : H12WitnessSearch.Good tree17066 := H12GlobalWitnessIndex.good

theorem leafIdentity17066 : H12AffineFastState.composeSystem env17066 rootObs = leafEnv17066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17066 rootObs == leafEnv17066) = true)

theorem terminalChecked17066 : H12PackedTerminal.terminalCheckFast leafEnv17066 active17066 tree17066 = true := by decide +kernel

def env17067 : List Nat := [2,4,8,16,1,17,8,256,260,273,2048,1,2317,0,2308,2051,1,2049,273,2309,0,261,16,3,2317,17,2049,1,1,2048,20,261,256,0,0,260]

theorem envBound17067 : H12AffineFastState.Bounded env17067 := by
  intro p hp
  have h : env17067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17064_17067 : H12AffineEnvironment.transform 4 1 env17064 = env17067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17064 == env17067) = true)

def leafEnv17067 : List Nat := [2,4,8,16,1,17,8,256,260,273,2048,1,2317,0,2308,2051,1,2049,273,2309,0,261,16,3,20,2317,1,17,2049,1,1,2048,20,261,256,0,4,2050,0,260,0,0,1]

def active17067 : List Nat := [0,1,2,3,7,10]

def tree17067 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17067 : H12WitnessSearch.Good tree17067 := H12GlobalWitnessIndex.good

theorem leafIdentity17067 : H12AffineFastState.composeSystem env17067 rootObs = leafEnv17067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17067 rootObs == leafEnv17067) = true)

theorem terminalChecked17067 : H12PackedTerminal.terminalCheckFast leafEnv17067 active17067 tree17067 = true := by decide +kernel

def env17068 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,2341,65536,1297,8461,1025,2340,1296,10248,17,67617,8328,17,2049,1296,1296,8460,1284,4294967296,257,4295041155,1296,512]

theorem envBound17068 : H12AffineFastState.Bounded env17068 := by
  intro p hp
  have h : env17068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17032_17068 : H12AffineEnvironment.transform 11 1297 env17032 = env17068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17032 == env17068) = true)

theorem identity17068 : scanCanonicalize (H12AffineFastState.compose env17068 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 10761) := by decide +kernel

theorem selectedBound17068 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17069 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,2341,65536,1297,8461,1025,2340,1296,10248,17,67617,8328,17,2049,1296,1296,8460,1284,10761,257,68234,1296,512]

theorem envBound17069 : H12AffineFastState.Bounded env17069 := by
  intro p hp
  have h : env17069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17068_17069 : H12AffineEnvironment.transform 31 10761 env17068 = env17069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10761 env17068 == env17069) = true)

theorem identity17069 : scanCanonicalize (H12AffineFastState.compose env17069 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2688) := by decide +kernel

theorem selectedBound17069 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17070 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2688,1296,2341,65536,1297,2957,1025,2340,1296,648,17,67617,2568,17,2049,1296,1296,2956,1284,137,257,68234,1296,512]

theorem envBound17070 : H12AffineFastState.Bounded env17070 := by
  intro p hp
  have h : env17070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17069_17070 : H12AffineEnvironment.transform 12 2688 env17069 = env17070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2688 env17069 == env17070) = true)

theorem identity17070 : scanCanonicalize (H12AffineFastState.compose env17070 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17070 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env17071 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2057,1296,2341,65536,1297,2308,1025,2340,1296,1,17,67617,2177,17,2049,1296,1296,2309,1284,137,257,67587,1296,137]

theorem envBound17071 : H12AffineFastState.Bounded env17071 := by
  intro p hp
  have h : env17071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17070_17071 : H12AffineEnvironment.transform 8 137 env17070 = env17071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17070 == env17071) = true)

def env17072 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,2057,0,2341,65536,1,2308,273,2340,0,1,17,67617,2177,17,2049,0,0,2309,20,137,257,67587,0,137]

theorem envBound17072 : H12AffineFastState.Bounded env17072 := by
  intro p hp
  have h : env17072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17071_17072 : H12AffineEnvironment.transform 9 272 env17071 = env17072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17071 == env17072) = true)

theorem identity17072 : scanCanonicalize (H12AffineFastState.compose env17072 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound17072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17073 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,2057,0,2341,431,1,2308,273,2340,0,1,17,2446,2177,17,2049,0,0,2309,20,137,257,2476,0,137]

theorem envBound17073 : H12AffineFastState.Bounded env17073 := by
  intro p hp
  have h : env17073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17072_17073 : H12AffineEnvironment.transform 15 431 env17072 = env17073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env17072 == env17073) = true)

def env17074 : List Nat := [2,4,8,16,0,17,128,256,137,272,2048,1,2057,0,2309,399,1,2308,273,2308,0,1,17,2446,2177,17,2049,0,0,2309,20,137,257,2444,0,137]

theorem envBound17074 : H12AffineFastState.Bounded env17074 := by
  intro p hp
  have h : env17074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17073_17074 : H12AffineEnvironment.transform 4 0 env17073 = env17074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17073 == env17074) = true)

theorem identity17074 : scanCanonicalize (H12AffineFastState.compose env17074 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound17074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17075 : List Nat := [2,4,8,16,0,17,128,256,137,272,17,1,24,0,276,399,1,277,273,277,0,1,17,415,144,17,16,0,0,276,20,137,257,413,0,137]

theorem envBound17075 : H12AffineFastState.Bounded env17075 := by
  intro p hp
  have h : env17075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17074_17075 : H12AffineEnvironment.transform 10 17 env17074 = env17075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env17074 == env17075) = true)

def env17076 : List Nat := [2,4,8,16,1,17,128,256,137,272,2048,1,2057,0,2308,398,1,2308,273,2309,0,1,17,2446,2177,17,2049,0,0,2309,20,137,257,2445,0,137]

theorem envBound17076 : H12AffineFastState.Bounded env17076 := by
  intro p hp
  have h : env17076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17073_17076 : H12AffineEnvironment.transform 4 1 env17073 = env17076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17073 == env17076) = true)

theorem identity17076 : scanCanonicalize (H12AffineFastState.compose env17076 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17076 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17077 : List Nat := [2,4,8,16,1,17,24,256,17,272,2048,1,2057,0,2308,278,1,2308,273,2309,0,1,17,2326,2073,17,2049,0,0,2309,20,17,257,2325,0,17]

theorem envBound17077 : H12AffineFastState.Bounded env17077 := by
  intro p hp
  have h : env17077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17076_17077 : H12AffineEnvironment.transform 6 24 env17076 = env17077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17076 == env17077) = true)

theorem identity17077 : scanCanonicalize (H12AffineFastState.compose env17077 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound17077 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17078 : List Nat := [2,4,8,16,1,17,24,256,17,272,261,1,268,0,1,278,1,1,273,0,0,1,17,19,284,17,260,0,0,0,20,17,257,16,0,17]

theorem envBound17078 : H12AffineFastState.Bounded env17078 := by
  intro p hp
  have h : env17078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17077_17078 : H12AffineEnvironment.transform 10 261 env17077 = env17078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17077 == env17078) = true)

def leafEnv17078 : List Nat := [2,4,8,16,1,17,24,256,17,272,261,1,268,0,1,278,1,1,273,0,0,1,17,19,20,284,1,17,260,0,0,0,20,17,257,16,4,263,0,17,0,0,1]

def active17078 : List Nat := [0,1,2,3,7]

def tree17078 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17078 : H12WitnessSearch.Good tree17078 := H12GlobalWitnessIndex.good

theorem leafIdentity17078 : H12AffineFastState.composeSystem env17078 rootObs = leafEnv17078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17078 rootObs == leafEnv17078) = true)

theorem terminalChecked17078 : H12PackedTerminal.terminalCheckFast leafEnv17078 active17078 tree17078 = true := by decide +kernel

def env17079 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,0,2057,1,2341,65536,0,2308,272,2340,1,1,17,67617,2177,17,2049,1,1,2309,21,137,257,67587,1,137]

theorem envBound17079 : H12AffineFastState.Bounded env17079 := by
  intro p hp
  have h : env17079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17071_17079 : H12AffineEnvironment.transform 9 273 env17071 = env17079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17071 == env17079) = true)

theorem identity17079 : scanCanonicalize (H12AffineFastState.compose env17079 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound17079 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17080 : List Nat := [2,4,8,16,32,17,128,256,137,273,261,0,268,1,32,65536,0,1,272,33,1,1,17,65828,388,17,260,1,1,0,21,137,257,65798,1,137]

theorem envBound17080 : H12AffineFastState.Bounded env17080 := by
  intro p hp
  have h : env17080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17079_17080 : H12AffineEnvironment.transform 10 261 env17079 = env17080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17079 == env17080) = true)

def env17081 : List Nat := [2,4,8,16,0,17,128,256,137,273,261,0,268,1,0,65536,0,1,272,1,1,1,17,65796,388,17,260,1,1,0,21,137,257,65798,1,137]

theorem envBound17081 : H12AffineFastState.Bounded env17081 := by
  intro p hp
  have h : env17081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17080_17081 : H12AffineEnvironment.transform 4 0 env17080 = env17081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17080 == env17081) = true)

theorem identity17081 : scanCanonicalize (H12AffineFastState.compose env17081 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17082 : List Nat := [2,4,8,16,0,17,128,21,137,4,16,0,25,1,0,65536,0,1,5,1,1,1,17,65553,145,17,17,1,1,0,21,137,20,65555,1,137]

theorem envBound17082 : H12AffineFastState.Bounded env17082 := by
  intro p hp
  have h : env17082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17081_17082 : H12AffineEnvironment.transform 7 21 env17081 = env17082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17081 == env17082) = true)

theorem identity17082 : scanCanonicalize (H12AffineFastState.compose env17082 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound17082 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17083 : List Nat := [2,4,8,16,0,17,128,21,137,4,16,0,25,1,0,154,0,1,5,1,1,1,17,139,145,17,17,1,1,0,21,137,20,137,1,137]

theorem envBound17083 : H12AffineFastState.Bounded env17083 := by
  intro p hp
  have h : env17083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17082_17083 : H12AffineEnvironment.transform 15 154 env17082 = env17083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env17082 == env17083) = true)

def leafEnv17083 : List Nat := [2,4,8,16,0,17,128,21,137,4,16,0,25,1,0,154,0,1,5,1,1,1,17,139,21,145,1,17,17,1,1,0,21,137,20,137,4,19,1,137,0,1,1]

def active17083 : List Nat := [0,1,2,3,6]

def tree17083 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17083 : H12WitnessSearch.Good tree17083 := H12GlobalWitnessIndex.good

theorem leafIdentity17083 : H12AffineFastState.composeSystem env17083 rootObs = leafEnv17083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17083 rootObs == leafEnv17083) = true)

theorem terminalChecked17083 : H12PackedTerminal.terminalCheckFast leafEnv17083 active17083 tree17083 = true := by decide +kernel

def env17084 : List Nat := [2,4,8,16,1,17,128,256,137,273,261,0,268,1,1,65536,0,1,272,0,1,1,17,65797,388,17,260,1,1,0,21,137,257,65798,1,137]

theorem envBound17084 : H12AffineFastState.Bounded env17084 := by
  intro p hp
  have h : env17084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17080_17084 : H12AffineEnvironment.transform 4 1 env17080 = env17084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17080 == env17084) = true)

theorem identity17084 : scanCanonicalize (H12AffineFastState.compose env17084 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 279) := by decide +kernel

theorem selectedBound17084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17085 : List Nat := [2,4,8,16,1,17,128,256,137,273,261,0,268,1,1,279,0,1,272,0,1,1,17,18,388,17,260,1,1,0,21,137,257,17,1,137]

theorem envBound17085 : H12AffineFastState.Bounded env17085 := by
  intro p hp
  have h : env17085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17084_17085 : H12AffineEnvironment.transform 15 279 env17084 = env17085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 279 env17084 == env17085) = true)

def env17086 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,175417,131344,32769,4097,10249,5376,98564,8328,135185,33061,136464,1296,140316,131093,4294967296,132112,4295076263,131073,512]

theorem envBound17086 : H12AffineFastState.Bounded env17086 := by
  intro p hp
  have h : env17086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17029_17086 : H12AffineEnvironment.transform 21 10249 env17029 = env17086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env17029 == env17086) = true)

theorem identity17086 : scanCanonicalize (H12AffineFastState.compose env17086 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 39204) := by decide +kernel

theorem selectedBound17086 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,39204,13341,38964,32769,4097,10249,5376,98564,8328,35125,33061,35892,1296,48440,39217,4294967296,40244,4295076263,39205,512]

theorem envBound17087 : H12AffineFastState.Bounded env17087 := by
  intro p hp
  have h : env17087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17086_17087 : H12AffineEnvironment.transform 16 39204 env17086 = env17087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 39204 env17086 == env17087) = true)

def env17088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13624,65536,11292,13341,11532,13625,4097,10249,5376,78908,8328,15373,13341,14604,1296,2048,11273,4294967296,10252,4295040159,11293,512]

theorem envBound17088 : H12AffineFastState.Bounded env17088 := by
  intro p hp
  have h : env17088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17087_17088 : H12AffineEnvironment.transform 14 13624 env17087 = env17088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13624 env17087 == env17088) = true)

def env17089 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,13624,65536,11292,13341,11532,13625,4097,10249,5376,78908,8328,15373,13341,14604,1296,2048,11273,4294967296,10252,4295040159,11293,136]

theorem envBound17089 : H12AffineFastState.Bounded env17089 := by
  intro p hp
  have h : env17089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17088_17089 : H12AffineEnvironment.transform 8 136 env17088 = env17089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env17088 == env17089) = true)

theorem identity17089 : scanCanonicalize (H12AffineFastState.compose env17089 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound17089 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17090 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,2316,4097,7220,65536,1296,7441,1024,7221,4097,261,5376,73008,2436,5377,7441,4096,1296,2048,1285,4294967296,256,4295040159,1297,136]

theorem envBound17090 : H12AffineFastState.Bounded env17090 := by
  intro p hp
  have h : env17090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17089_17090 : H12AffineEnvironment.transform 12 2316 env17089 = env17090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env17089 == env17090) = true)

def env17091 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2316,1297,2340,65536,1296,2049,1024,2341,1297,261,16,67616,2436,17,2049,1296,1296,2048,1285,4294967296,256,4295035279,1297,136]

theorem envBound17091 : H12AffineFastState.Bounded env17091 := by
  intro p hp
  have h : env17091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17090_17091 : H12AffineEnvironment.transform 11 1296 env17090 = env17091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17090 == env17091) = true)

def env17092 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,2316,1,2340,65536,0,2049,272,2341,1,261,16,67616,2436,17,2049,0,0,2048,21,4294967296,256,4295035279,1,136]

theorem envBound17092 : H12AffineFastState.Bounded env17092 := by
  intro p hp
  have h : env17092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17091_17092 : H12AffineEnvironment.transform 9 272 env17091 = env17092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17091 == env17092) = true)

theorem identity17092 : scanCanonicalize (H12AffineFastState.compose env17092 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 397) := by decide +kernel

theorem selectedBound17092 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17093 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,2316,1,2340,65536,0,2049,272,2341,1,261,16,67616,2436,17,2049,0,0,2048,21,397,256,67586,1,136]

theorem envBound17093 : H12AffineFastState.Bounded env17093 := by
  intro p hp
  have h : env17093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17092_17093 : H12AffineEnvironment.transform 31 397 env17092 = env17093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 397 env17092 == env17093) = true)

def env17094 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,0,2316,1,2340,65536,0,2049,272,2341,1,261,16,67616,2316,17,2049,0,0,2048,21,261,256,67586,1,0]

theorem envBound17094 : H12AffineFastState.Bounded env17094 := by
  intro p hp
  have h : env17094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17093_17094 : H12AffineEnvironment.transform 6 8 env17093 = env17094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17093 == env17094) = true)

theorem identity17094 : scanCanonicalize (H12AffineFastState.compose env17094 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17094 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17095 : List Nat := [2,4,8,16,32,17,8,5,0,21,2048,0,2057,1,2081,65536,0,2049,21,2080,1,0,16,67616,2057,17,2049,0,0,2048,21,0,5,67586,1,0]

theorem envBound17095 : H12AffineFastState.Bounded env17095 := by
  intro p hp
  have h : env17095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17094_17095 : H12AffineEnvironment.transform 7 5 env17094 = env17095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17094 == env17095) = true)

def env17096 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,0,2316,1,2340,65536,0,2049,272,2341,1,261,16,67616,2317,17,2049,0,0,2048,21,260,256,67586,1,1]

theorem envBound17096 : H12AffineFastState.Bounded env17096 := by
  intro p hp
  have h : env17096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17093_17096 : H12AffineEnvironment.transform 6 9 env17093 = env17096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17093 == env17096) = true)

theorem identity17096 : scanCanonicalize (H12AffineFastState.compose env17096 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17096 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17097 : List Nat := [2,4,8,16,1,17,9,256,1,272,2048,0,2316,1,2309,65536,0,2049,272,2308,1,261,16,67585,2317,17,2049,0,0,2048,21,260,256,67586,1,1]

theorem envBound17097 : H12AffineFastState.Bounded env17097 := by
  intro p hp
  have h : env17097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17096_17097 : H12AffineEnvironment.transform 4 1 env17096 = env17097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17096 == env17097) = true)

def env17098 : List Nat := [2,4,8,16,1,17,9,256,1,272,260,0,8,1,1,65536,0,261,272,0,1,261,16,65797,9,17,261,0,0,260,21,260,256,65798,1,1]

theorem envBound17098 : H12AffineFastState.Bounded env17098 := by
  intro p hp
  have h : env17098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17097_17098 : H12AffineEnvironment.transform 10 260 env17097 = env17098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17097 == env17098) = true)

theorem identity17098 : scanCanonicalize (H12AffineFastState.compose env17098 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound17098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17099 : List Nat := [2,4,8,16,1,17,9,256,1,272,260,0,8,1,1,3,0,261,272,0,1,261,16,262,9,17,261,0,0,260,21,260,256,261,1,1]

theorem envBound17099 : H12AffineFastState.Bounded env17099 := by
  intro p hp
  have h : env17099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17098_17099 : H12AffineEnvironment.transform 15 3 env17098 = env17099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env17098 == env17099) = true)

def env17100 : List Nat := [2,4,8,16,1,17,9,256,1,272,261,0,9,1,0,65536,0,260,272,1,1,261,16,65796,8,17,260,0,0,261,21,260,256,65799,1,1]

theorem envBound17100 : H12AffineFastState.Bounded env17100 := by
  intro p hp
  have h : env17100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17097_17100 : H12AffineEnvironment.transform 10 261 env17097 = env17100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17097 == env17100) = true)

theorem identity17100 : scanCanonicalize (H12AffineFastState.compose env17100 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17100 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17101 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,0,9,1,0,65536,0,0,20,1,1,1,16,65536,8,17,0,0,0,1,21,0,4,65539,1,1]

theorem envBound17101 : H12AffineFastState.Bounded env17101 := by
  intro p hp
  have h : env17101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17100_17101 : H12AffineEnvironment.transform 7 4 env17100 = env17101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17100 == env17101) = true)

theorem identity17101 : scanCanonicalize (H12AffineFastState.compose env17101 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound17101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17102 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,0,9,1,0,3,0,0,20,1,1,1,16,3,8,17,0,0,0,1,21,0,4,0,1,1]

theorem envBound17102 : H12AffineFastState.Bounded env17102 := by
  intro p hp
  have h : env17102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17101_17102 : H12AffineEnvironment.transform 15 3 env17101 = env17102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env17101 == env17102) = true)

def leafEnv17102 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,0,9,1,0,3,0,0,20,1,1,1,16,3,21,8,1,17,0,0,0,1,21,0,4,0,4,2,1,1,0,1,1]

def active17102 : List Nat := [0,1,2,3]

def tree17102 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17102 : H12WitnessSearch.Good tree17102 := H12GlobalWitnessIndex.good

theorem leafIdentity17102 : H12AffineFastState.composeSystem env17102 rootObs = leafEnv17102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17102 rootObs == leafEnv17102) = true)

theorem terminalChecked17102 : H12PackedTerminal.terminalCheckFast leafEnv17102 active17102 tree17102 = true := by decide +kernel

def env17103 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,2316,0,2340,65536,1,2049,273,2341,0,261,16,67616,2436,17,2049,1,1,2048,20,4294967296,256,4295035279,0,136]

theorem envBound17103 : H12AffineFastState.Bounded env17103 := by
  intro p hp
  have h : env17103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17091_17103 : H12AffineEnvironment.transform 9 273 env17091 = env17103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17091 == env17103) = true)

theorem identity17103 : scanCanonicalize (H12AffineFastState.compose env17103 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 67878) := by decide +kernel

theorem selectedBound17103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17104 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,2316,0,2340,65536,1,2049,273,2341,0,261,16,67616,2436,17,2049,1,1,2048,20,67878,256,169,0,136]

theorem envBound17104 : H12AffineFastState.Bounded env17104 := by
  intro p hp
  have h : env17104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17103_17104 : H12AffineEnvironment.transform 31 67878 env17103 = env17104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67878 env17103 == env17104) = true)

def env17105 : List Nat := [2,4,8,16,32,17,128,36,136,53,2048,1,2088,0,2048,65536,1,2049,53,2049,0,33,16,67616,2208,17,2049,1,1,2048,20,67586,36,169,0,136]

theorem envBound17105 : H12AffineFastState.Bounded env17105 := by
  intro p hp
  have h : env17105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17104_17105 : H12AffineEnvironment.transform 7 36 env17104 = env17105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17104 == env17105) = true)

theorem identity17105 : scanCanonicalize (H12AffineFastState.compose env17105 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17105 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17106 : List Nat := [2,4,8,16,1,17,128,5,136,20,2048,1,2057,0,2048,65536,1,2049,20,2049,0,0,16,67585,2177,17,2049,1,1,2048,20,67586,5,136,0,136]

theorem envBound17106 : H12AffineFastState.Bounded env17106 := by
  intro p hp
  have h : env17106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17105_17106 : H12AffineEnvironment.transform 4 1 env17105 = env17106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17105 == env17106) = true)

def env17107 : List Nat := [2,4,8,16,32,17,128,37,136,52,2048,1,2089,0,2049,65536,1,2049,52,2048,0,32,16,67616,2209,17,2049,1,1,2048,20,67587,37,169,0,136]

theorem envBound17107 : H12AffineFastState.Bounded env17107 := by
  intro p hp
  have h : env17107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17104_17107 : H12AffineEnvironment.transform 7 37 env17104 = env17107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17104 == env17107) = true)

theorem identity17107 : scanCanonicalize (H12AffineFastState.compose env17107 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound17107 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17108 : List Nat := [2,4,8,16,32,17,128,37,136,52,2048,1,2089,0,2049,2051,1,2049,52,2048,0,32,16,35,2209,17,2049,1,1,2048,20,0,37,169,0,136]

theorem envBound17108 : H12AffineFastState.Bounded env17108 := by
  intro p hp
  have h : env17108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17107_17108 : H12AffineEnvironment.transform 15 2051 env17107 = env17108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env17107 == env17108) = true)

def env17109 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,41,0,1,3,1,1,52,0,0,32,16,35,161,17,1,1,1,0,20,0,37,169,0,136]

theorem envBound17109 : H12AffineFastState.Bounded env17109 := by
  intro p hp
  have h : env17109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17108_17109 : H12AffineEnvironment.transform 10 0 env17108 = env17109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17108 == env17109) = true)

theorem identity17109 : scanCanonicalize (H12AffineFastState.compose env17109 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17110 : List Nat := [2,4,8,16,32,17,40,37,32,52,0,1,41,0,1,3,1,1,52,0,0,32,16,35,9,17,1,1,1,0,20,0,37,1,0,32]

theorem envBound17110 : H12AffineFastState.Bounded env17110 := by
  intro p hp
  have h : env17110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17109_17110 : H12AffineEnvironment.transform 6 40 env17109 = env17110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17109 == env17110) = true)

def env17111 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,40,0,0,2,1,0,52,1,0,32,16,35,160,17,0,1,1,1,20,0,37,169,0,136]

theorem envBound17111 : H12AffineFastState.Bounded env17111 := by
  intro p hp
  have h : env17111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17108_17111 : H12AffineEnvironment.transform 10 1 env17108 = env17111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17108 == env17111) = true)

def env17112 : List Nat := [2,4,8,16,0,17,128,5,136,20,1,1,8,0,0,2,1,0,20,1,0,0,16,3,128,17,0,1,1,1,20,0,5,137,0,136]

theorem envBound17112 : H12AffineFastState.Bounded env17112 := by
  intro p hp
  have h : env17112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17111_17112 : H12AffineEnvironment.transform 4 0 env17111 = env17112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17111 == env17112) = true)

def env17113 : List Nat := [2,4,8,16,1,17,128,4,136,21,1,1,9,0,0,2,1,0,21,1,0,1,16,2,129,17,0,1,1,1,20,0,4,136,0,136]

theorem envBound17113 : H12AffineFastState.Bounded env17113 := by
  intro p hp
  have h : env17113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17111_17113 : H12AffineEnvironment.transform 4 1 env17111 = env17113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17111 == env17113) = true)

theorem identity17113 : scanCanonicalize (H12AffineFastState.compose env17113 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17114 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,9,0,0,2,1,0,21,1,0,1,16,2,9,17,0,1,1,1,20,0,4,0,0,0]

theorem envBound17114 : H12AffineFastState.Bounded env17114 := by
  intro p hp
  have h : env17114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17113_17114 : H12AffineEnvironment.transform 6 8 env17113 = env17114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17113 == env17114) = true)

def leafEnv17114 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,9,0,0,2,1,0,21,1,0,1,16,2,20,9,1,17,0,1,1,1,20,0,4,0,4,2,0,0,0,0,1]

def active17114 : List Nat := [0,1,2,3]

def tree17114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17114 : H12WitnessSearch.Good tree17114 := H12GlobalWitnessIndex.good

theorem leafIdentity17114 : H12AffineFastState.composeSystem env17114 rootObs = leafEnv17114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17114 rootObs == leafEnv17114) = true)

theorem terminalChecked17114 : H12PackedTerminal.terminalCheckFast leafEnv17114 active17114 tree17114 = true := by decide +kernel

def env17115 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2316,1296,2341,65536,1296,2048,1024,2340,1296,261,17,67617,2436,16,2048,1297,1296,2048,1285,4294967296,256,4295035278,1297,136]

theorem envBound17115 : H12AffineFastState.Bounded env17115 := by
  intro p hp
  have h : env17115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17090_17115 : H12AffineEnvironment.transform 11 1297 env17090 = env17115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17090 == env17115) = true)

theorem identity17115 : scanCanonicalize (H12AffineFastState.compose env17115 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound17115 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17116 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2316,1296,2341,2218,1296,2048,1024,2340,1296,261,17,139,2436,16,2048,1297,1296,2048,1285,4294967296,256,4294967588,1297,136]

theorem envBound17116 : H12AffineFastState.Bounded env17116 := by
  intro p hp
  have h : env17116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17115_17116 : H12AffineEnvironment.transform 15 2218 env17115 = env17116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env17115 == env17116) = true)

theorem identity17116 : scanCanonicalize (H12AffineFastState.compose env17116 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 32) := by decide +kernel

theorem selectedBound17116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17117 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2316,1296,2341,2218,1296,2048,1024,2340,1296,261,17,139,2436,16,2048,1297,1296,2048,1285,32,256,260,1297,136]

theorem envBound17117 : H12AffineFastState.Bounded env17117 := by
  intro p hp
  have h : env17117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17116_17117 : H12AffineEnvironment.transform 31 32 env17116 = env17117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32 env17116 == env17117) = true)

theorem identity17117 : scanCanonicalize (H12AffineFastState.compose env17117 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17118 : List Nat := [2,4,8,16,32,17,40,256,32,1024,2048,1297,2316,1296,2341,2050,1296,2048,1024,2340,1296,261,17,35,2348,16,2048,1297,1296,2048,1285,32,256,260,1297,32]

theorem envBound17118 : H12AffineFastState.Bounded env17118 := by
  intro p hp
  have h : env17118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17117_17118 : H12AffineEnvironment.transform 6 40 env17117 = env17118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17117 == env17118) = true)

def env17119 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,2316,1296,2309,2050,1296,2048,1024,2308,1296,261,17,3,2316,16,2048,1297,1296,2048,1285,0,256,260,1297,0]

theorem envBound17119 : H12AffineFastState.Bounded env17119 := by
  intro p hp
  have h : env17119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17118_17119 : H12AffineEnvironment.transform 4 0 env17118 = env17119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17118 == env17119) = true)

theorem identity17119 : scanCanonicalize (H12AffineFastState.compose env17119 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17119 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17120 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2057,1045,2048,2050,1045,2048,1024,2049,1045,0,17,3,2057,16,2048,1044,1045,2048,1024,0,5,1,1044,0]

theorem envBound17120 : H12AffineFastState.Bounded env17120 := by
  intro p hp
  have h : env17120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17119_17120 : H12AffineEnvironment.transform 7 5 env17119 = env17120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17119 == env17120) = true)

def leafEnv17120 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2057,1045,2048,2050,1045,2048,1024,2049,1045,0,17,3,1024,2057,1,16,2048,1044,1045,2048,1024,0,5,1,4,2051,1044,0,0,1044,1]

def active17120 : List Nat := [0,1,2,3,9,10]

def tree17120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17120 : H12WitnessSearch.Good tree17120 := H12GlobalWitnessIndex.good

theorem leafIdentity17120 : H12AffineFastState.composeSystem env17120 rootObs = leafEnv17120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17120 rootObs == leafEnv17120) = true)

theorem terminalChecked17120 : H12PackedTerminal.terminalCheckFast leafEnv17120 active17120 tree17120 = true := by decide +kernel

def env17121 : List Nat := [2,4,8,16,1,17,9,256,1,1024,2048,1297,2316,1296,2308,2050,1296,2048,1024,2309,1296,261,17,2,2317,16,2048,1297,1296,2048,1285,1,256,260,1297,1]

theorem envBound17121 : H12AffineFastState.Bounded env17121 := by
  intro p hp
  have h : env17121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17118_17121 : H12AffineEnvironment.transform 4 1 env17118 = env17121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17118 == env17121) = true)

def leafEnv17121 : List Nat := [2,4,8,16,1,17,9,256,1,1024,2048,1297,2316,1296,2308,2050,1296,2048,1024,2309,1296,261,17,2,1285,2317,1,16,2048,1297,1296,2048,1285,1,256,260,4,2050,1297,1,0,1297,1]

def active17121 : List Nat := [0,1,2,3,7,9,10]

def tree17121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17121 : H12WitnessSearch.Good tree17121 := H12GlobalWitnessIndex.good

theorem leafIdentity17121 : H12AffineFastState.composeSystem env17121 rootObs = leafEnv17121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17121 rootObs == leafEnv17121) = true)

theorem terminalChecked17121 : H12PackedTerminal.terminalCheckFast leafEnv17121 active17121 tree17121 = true := by decide +kernel

def env17122 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,13624,65536,11292,13341,11532,13625,4097,10249,5376,78908,8328,15373,13341,14604,1296,2048,11273,4294967296,10252,4295040159,11293,137]

theorem envBound17122 : H12AffineFastState.Bounded env17122 := by
  intro p hp
  have h : env17122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17088_17122 : H12AffineEnvironment.transform 8 137 env17088 = env17122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17088 == env17122) = true)

def env17123 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,7448,4097,2080,65536,4356,2309,4116,2081,4097,5393,5376,67876,7568,277,2309,1044,1296,2048,4369,4294967296,5396,4295040159,4357,137]

theorem envBound17123 : H12AffineFastState.Bounded env17123 := by
  intro p hp
  have h : env17123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17122_17123 : H12AffineEnvironment.transform 12 7448 env17122 = env17123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7448 env17122 == env17123) = true)

theorem identity17123 : scanCanonicalize (H12AffineFastState.compose env17123 (packedSelected [3,10] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17123 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env17124 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2056,1297,2080,65536,1044,2309,1284,2081,1297,1,16,67876,2176,277,2309,1044,1296,2048,1025,4294967296,4,4295035279,1045,137]

theorem envBound17124 : H12AffineFastState.Bounded env17124 := by
  intro p hp
  have h : env17124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17123_17124 : H12AffineEnvironment.transform 11 1296 env17123 = env17124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17123 == env17124) = true)

theorem identity17124 : scanCanonicalize (H12AffineFastState.compose env17124 (packedSelected [0,1,2,3,4,5,6] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound17124 : packedSelected [0,1,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17125 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2056,1297,2080,2219,1044,2309,1284,2081,1297,1,16,399,2176,277,2309,1044,1296,2048,1025,4294967296,4,4294967588,1045,137]

theorem envBound17125 : H12AffineFastState.Bounded env17125 := by
  intro p hp
  have h : env17125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17124_17125 : H12AffineEnvironment.transform 15 2219 env17124 = env17125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env17124 == env17125) = true)

def env17126 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1464,1296,1456,1297,1432,1299,1044,1213,1284,1433,1297,1,16,399,1336,277,1213,1044,1296,1464,1025,4294967296,4,4294967588,1045,137]

theorem envBound17126 : H12AffineFastState.Bounded env17126 := by
  intro p hp
  have h : env17126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17125_17126 : H12AffineEnvironment.transform 10 1464 env17125 = env17126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1464 env17125 == env17126) = true)

theorem identity17126 : scanCanonicalize (H12AffineFastState.compose env17126 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 397) := by decide +kernel

theorem selectedBound17126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17127 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1464,1296,1456,1297,1432,1299,1044,1213,1284,1433,1297,1,16,399,1336,277,1213,1044,1296,1464,1025,397,4,169,1045,137]

theorem envBound17127 : H12AffineFastState.Bounded env17127 := by
  intro p hp
  have h : env17127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17126_17127 : H12AffineEnvironment.transform 31 397 env17126 = env17127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 397 env17126 == env17127) = true)

def env17128 : List Nat := [2,4,8,16,32,17,24,256,17,1024,1312,1296,1320,1297,1280,1299,1044,1061,1284,1281,1297,1,16,279,1336,277,1061,1044,1296,1312,1025,277,4,49,1045,17]

theorem envBound17128 : H12AffineFastState.Bounded env17128 := by
  intro p hp
  have h : env17128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17127_17128 : H12AffineEnvironment.transform 6 24 env17127 = env17128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17127 == env17128) = true)

def env17129 : List Nat := [2,4,8,16,0,17,24,256,17,1024,1280,1296,1288,1297,1280,1299,1044,1029,1284,1281,1297,1,16,279,1304,277,1029,1044,1296,1280,1025,277,4,17,1045,17]

theorem envBound17129 : H12AffineFastState.Bounded env17129 := by
  intro p hp
  have h : env17129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17128_17129 : H12AffineEnvironment.transform 4 0 env17128 = env17129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17128 == env17129) = true)

theorem identity17129 : scanCanonicalize (H12AffineFastState.compose env17129 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17130 : List Nat := [2,4,8,0,0,1,8,256,1,1024,1280,1280,1288,1281,1280,1283,1028,1029,1284,1281,1281,1,0,263,1288,261,1029,1028,1280,1280,1025,261,4,1,1029,1]

theorem envBound17130 : H12AffineFastState.Bounded env17130 := by
  intro p hp
  have h : env17130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17129_17130 : H12AffineEnvironment.transform 3 0 env17129 = env17130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17129 == env17130) = true)

def env17131 : List Nat := [2,4,8,16,1,17,24,256,17,1024,1281,1296,1289,1297,1280,1299,1044,1028,1284,1281,1297,1,16,279,1305,277,1028,1044,1296,1281,1025,277,4,16,1045,17]

theorem envBound17131 : H12AffineFastState.Bounded env17131 := by
  intro p hp
  have h : env17131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17128_17131 : H12AffineEnvironment.transform 4 1 env17128 = env17131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17128 == env17131) = true)

def env17132 : List Nat := [2,4,8,16,32,17,25,256,16,1024,1313,1296,1321,1297,1281,1299,1044,1060,1284,1280,1297,1,16,278,1336,277,1060,1044,1296,1313,1025,276,4,48,1045,16]

theorem envBound17132 : H12AffineFastState.Bounded env17132 := by
  intro p hp
  have h : env17132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17127_17132 : H12AffineEnvironment.transform 6 25 env17127 = env17132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17127 == env17132) = true)

def env17133 : List Nat := [2,4,8,16,0,17,25,256,16,1024,1281,1296,1289,1297,1281,1299,1044,1028,1284,1280,1297,1,16,278,1304,277,1028,1044,1296,1281,1025,276,4,16,1045,16]

theorem envBound17133 : H12AffineFastState.Bounded env17133 := by
  intro p hp
  have h : env17133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17132_17133 : H12AffineEnvironment.transform 4 0 env17132 = env17133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17132 == env17133) = true)

theorem identity17133 : scanCanonicalize (H12AffineFastState.compose env17133 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17134 : List Nat := [2,4,8,16,0,17,25,21,16,1024,1044,1029,1052,1028,1044,1030,1044,1028,1041,1045,1028,1,16,3,1037,0,1028,1044,1029,1044,1025,1,4,16,1045,16]

theorem envBound17134 : H12AffineFastState.Bounded env17134 := by
  intro p hp
  have h : env17134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17133_17134 : H12AffineEnvironment.transform 7 21 env17133 = env17134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17133 == env17134) = true)

def env17135 : List Nat := [2,4,8,16,1,17,25,256,16,1024,1280,1296,1288,1297,1281,1299,1044,1029,1284,1280,1297,1,16,278,1305,277,1029,1044,1296,1280,1025,276,4,17,1045,16]

theorem envBound17135 : H12AffineFastState.Bounded env17135 := by
  intro p hp
  have h : env17135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17132_17135 : H12AffineEnvironment.transform 4 1 env17132 = env17135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17132 == env17135) = true)

theorem identity17135 : scanCanonicalize (H12AffineFastState.compose env17135 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17136 : List Nat := [2,4,8,16,1,17,25,5,16,1024,1029,1045,1037,1044,1028,1046,1044,1029,1025,1029,1044,1,16,19,1052,16,1029,1044,1045,1029,1025,17,4,17,1045,16]

theorem envBound17136 : H12AffineFastState.Bounded env17136 := by
  intro p hp
  have h : env17136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17135_17136 : H12AffineEnvironment.transform 7 5 env17135 = env17136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17135 == env17136) = true)

def env17137 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1465,1296,1457,1297,1433,1298,1044,1212,1284,1432,1297,1,16,399,1337,277,1212,1044,1296,1465,1025,4294967296,4,4294967588,1045,137]

theorem envBound17137 : H12AffineFastState.Bounded env17137 := by
  intro p hp
  have h : env17137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17125_17137 : H12AffineEnvironment.transform 10 1465 env17125 = env17137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1465 env17125 == env17137) = true)

theorem identity17137 : scanCanonicalize (H12AffineFastState.compose env17137 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound17137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17138 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1465,1296,1457,1297,1433,1298,1044,1212,1284,1432,1297,1,16,399,1337,277,1212,1044,1296,1465,1025,137,4,429,1045,137]

theorem envBound17138 : H12AffineFastState.Bounded env17138 := by
  intro p hp
  have h : env17138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17137_17138 : H12AffineEnvironment.transform 31 137 env17137 = env17138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env17137 == env17138) = true)

theorem identity17138 : scanCanonicalize (H12AffineFastState.compose env17138 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17138 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17139 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1213,1044,1205,1045,1181,1046,1044,1212,1024,1180,1045,1,16,139,1085,17,1212,1044,1044,1213,1025,137,4,169,1045,137]

theorem envBound17139 : H12AffineFastState.Bounded env17139 := by
  intro p hp
  have h : env17139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17138_17139 : H12AffineEnvironment.transform 7 4 env17138 = env17139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17138 == env17139) = true)

theorem identity17139 : scanCanonicalize (H12AffineFastState.compose env17139 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17139 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17140 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1044,1044,1052,1045,1076,1046,1044,1045,1024,1077,1045,1,16,34,1085,17,1045,1044,1044,1044,1025,32,4,0,1045,32]

theorem envBound17140 : H12AffineFastState.Bounded env17140 := by
  intro p hp
  have h : env17140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17139_17140 : H12AffineEnvironment.transform 6 41 env17139 = env17140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17139 == env17140) = true)

def env17141 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,7449,4097,2081,65536,4357,2308,4117,2080,4097,5392,5376,67877,7569,276,2308,1045,1296,2048,4368,4294967296,5397,4295040159,4356,137]

theorem envBound17141 : H12AffineFastState.Bounded env17141 := by
  intro p hp
  have h : env17141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17122_17141 : H12AffineEnvironment.transform 12 7449 env17122 = env17141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7449 env17122 == env17141) = true)

theorem identity17141 : scanCanonicalize (H12AffineFastState.compose env17141 (packedSelected [3,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17141 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env17142 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,4096,7196,4097,2081,65536,4096,2049,4117,2080,4097,5141,5125,67616,7316,17,2049,1045,1045,2048,4117,4294967296,5136,4295040159,4097,137]

theorem envBound17142 : H12AffineFastState.Bounded env17142 := by
  intro p hp
  have h : env17142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17141_17142 : H12AffineEnvironment.transform 7 5 env17141 = env17142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17141 == env17142) = true)

def env17143 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,4096,7196,4097,2081,65536,4096,2049,4117,2080,4097,5141,5125,67616,7316,17,2049,1045,1045,2048,4117,136,5136,72727,4097,137]

theorem envBound17143 : H12AffineFastState.Bounded env17143 := by
  intro p hp
  have h : env17143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17142_17143 : H12AffineEnvironment.transform 31 136 env17142 = env17143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env17142 == env17143) = true)

theorem identity17143 : scanCanonicalize (H12AffineFastState.compose env17143 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound17143 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17144 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2057,1044,2081,65536,1045,2049,1024,2080,1044,0,16,67616,2177,17,2049,1045,1045,2048,1024,136,5,67586,1044,137]

theorem envBound17144 : H12AffineFastState.Bounded env17144 := by
  intro p hp
  have h : env17144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17143_17144 : H12AffineEnvironment.transform 11 1045 env17143 = env17144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env17143 == env17144) = true)

theorem identity17144 : scanCanonicalize (H12AffineFastState.compose env17144 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound17144 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17145 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2057,1044,2081,2082,1045,2049,1024,2080,1044,0,16,2,2177,17,2049,1045,1045,2048,1024,136,5,32,1044,137]

theorem envBound17145 : H12AffineFastState.Bounded env17145 := by
  intro p hp
  have h : env17145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17144_17145 : H12AffineEnvironment.transform 15 2082 env17144 = env17145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env17144 == env17145) = true)

theorem identity17145 : scanCanonicalize (H12AffineFastState.compose env17145 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17145 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17146 : List Nat := [2,4,8,16,32,17,9,5,0,1024,2048,1045,2057,1044,2081,2082,1045,2049,1024,2080,1044,0,16,2,2056,17,2049,1045,1045,2048,1024,1,5,32,1044,0]

theorem envBound17146 : H12AffineFastState.Bounded env17146 := by
  intro p hp
  have h : env17146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17145_17146 : H12AffineEnvironment.transform 6 9 env17145 = env17146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17145 == env17146) = true)

theorem identity17146 : scanCanonicalize (H12AffineFastState.compose env17146 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17146 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17147 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2057,1044,2048,2051,1045,2049,1024,2049,1044,0,16,2,2056,17,2049,1045,1045,2048,1024,1,5,1,1044,0]

theorem envBound17147 : H12AffineFastState.Bounded env17147 := by
  intro p hp
  have h : env17147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17146_17147 : H12AffineEnvironment.transform 4 1 env17146 = env17147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17146 == env17147) = true)

def leafEnv17147 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2057,1044,2048,2051,1045,2049,1024,2049,1044,0,16,2,1024,2056,1,17,2049,1045,1045,2048,1024,1,5,1,4,2051,1044,0,0,1044,1]

def active17147 : List Nat := [0,1,2,3,9,10]

def tree17147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17147 : H12WitnessSearch.Good tree17147 := H12GlobalWitnessIndex.good

theorem leafIdentity17147 : H12AffineFastState.composeSystem env17147 rootObs = leafEnv17147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17147 rootObs == leafEnv17147) = true)

theorem terminalChecked17147 : H12PackedTerminal.terminalCheckFast leafEnv17147 active17147 tree17147 = true := by decide +kernel

def env17148 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,4096,7196,4097,2081,65536,4096,2049,4117,2080,4097,5141,5125,67616,7316,17,2049,1045,1045,2048,4117,137,5136,72726,4097,137]

theorem envBound17148 : H12AffineFastState.Bounded env17148 := by
  intro p hp
  have h : env17148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17142_17148 : H12AffineEnvironment.transform 31 137 env17142 = env17148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env17142 == env17148) = true)

def env17149 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,0,3100,1,2081,65536,0,2049,21,2080,1,1045,1029,67616,3220,17,2049,1045,1045,2048,21,137,1040,68630,1,137]

theorem envBound17149 : H12AffineFastState.Bounded env17149 := by
  intro p hp
  have h : env17149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17148_17149 : H12AffineEnvironment.transform 11 0 env17148 = env17149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env17148 == env17149) = true)

def env17150 : List Nat := [2,4,8,16,32,17,128,5,137,1024,0,0,1052,1,33,65536,0,1,21,32,1,1045,1029,65568,1172,17,1,1045,1045,0,21,137,1040,66582,1,137]

theorem envBound17150 : H12AffineFastState.Bounded env17150 := by
  intro p hp
  have h : env17150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17149_17150 : H12AffineEnvironment.transform 10 0 env17149 = env17150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17149 == env17150) = true)

def env17151 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1,0,1053,1,32,65536,0,0,21,33,1,1045,1029,65569,1173,17,0,1045,1045,1,21,137,1040,66583,1,137]

theorem envBound17151 : H12AffineFastState.Bounded env17151 := by
  intro p hp
  have h : env17151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17149_17151 : H12AffineEnvironment.transform 10 1 env17149 = env17151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17149 == env17151) = true)

theorem identity17151 : scanCanonicalize (H12AffineFastState.compose env17151 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound17151 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17152 : List Nat := [2,4,8,16,32,17,128,5,137,20,1,0,9,1,32,65536,0,0,21,33,1,1,17,65569,129,17,0,1,1,1,21,137,4,65539,1,137]

theorem envBound17152 : H12AffineFastState.Bounded env17152 := by
  intro p hp
  have h : env17152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17151_17152 : H12AffineEnvironment.transform 9 20 env17151 = env17152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17151 == env17152) = true)

def env17153 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1,3101,0,2081,65536,1,2049,20,2080,0,1044,1028,67616,3221,17,2049,1045,1045,2048,20,137,1041,68631,0,137]

theorem envBound17153 : H12AffineFastState.Bounded env17153 := by
  intro p hp
  have h : env17153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17148_17153 : H12AffineEnvironment.transform 11 1 env17148 = env17153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env17148 == env17153) = true)

def env17154 : List Nat := [2,4,8,16,32,17,128,5,137,1024,0,1,1053,0,33,65536,1,1,20,32,0,1044,1028,65568,1173,17,1,1045,1045,0,20,137,1041,66583,0,137]

theorem envBound17154 : H12AffineFastState.Bounded env17154 := by
  intro p hp
  have h : env17154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17153_17154 : H12AffineEnvironment.transform 10 0 env17153 = env17154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17153 == env17154) = true)

theorem identity17154 : scanCanonicalize (H12AffineFastState.compose env17154 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound17154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17155 : List Nat := [2,4,8,16,32,17,128,5,137,1024,0,1,1053,0,33,170,1,1,20,32,0,1044,1028,138,1173,17,1,1045,1045,0,20,137,1041,1213,0,137]

theorem envBound17155 : H12AffineFastState.Bounded env17155 := by
  intro p hp
  have h : env17155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17154_17155 : H12AffineEnvironment.transform 15 170 env17154 = env17155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env17154 == env17155) = true)

theorem identity17155 : scanCanonicalize (H12AffineFastState.compose env17155 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound17155 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env17156 : List Nat := [2,4,8,16,32,17,128,5,137,21,0,1,8,0,33,170,1,1,20,32,0,1,17,138,128,17,1,0,0,0,20,137,4,168,0,137]

theorem envBound17156 : H12AffineFastState.Bounded env17156 := by
  intro p hp
  have h : env17156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17155_17156 : H12AffineEnvironment.transform 9 21 env17155 = env17156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17155 == env17156) = true)

def env17157 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1,1,1052,0,32,65536,1,0,20,33,0,1044,1028,65569,1172,17,0,1045,1045,1,20,137,1041,66582,0,137]

theorem envBound17157 : H12AffineFastState.Bounded env17157 := by
  intro p hp
  have h : env17157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17153_17157 : H12AffineEnvironment.transform 10 1 env17153 = env17157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17153 == env17157) = true)

end H12CloudChart2