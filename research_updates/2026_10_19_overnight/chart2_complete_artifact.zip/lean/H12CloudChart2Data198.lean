import H12CloudChart2Data197

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound49786 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49787 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,72,1109,81,34,1028,162,1025,80,1028,153,17,1079,193,65,1151,1109,1109,2144,69,1092,68,64,1029,512]

theorem envBound49787 : H12AffineFastState.Bounded env49787 := by
  intro p hp
  have h : env49787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49786_49787 : H12AffineEnvironment.transform 11 1029 env49786 = env49787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env49786 == env49787) = true)

theorem identity49787 : scanCanonicalize (H12AffineFastState.compose env49787 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound49787 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49788 : List Nat := [2,4,8,16,32,64,128,68,512,236,2048,233,72,185,81,34,232,162,237,80,232,153,17,219,193,65,147,185,185,2144,69,168,68,64,233,512]

theorem envBound49788 : H12AffineFastState.Bounded env49788 := by
  intro p hp
  have h : env49788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49787_49788 : H12AffineEnvironment.transform 9 236 env49787 = env49788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env49787 == env49788) = true)

theorem identity49788 : scanCanonicalize (H12AffineFastState.compose env49788 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound49788 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49789 : List Nat := [2,4,8,16,32,64,104,68,512,4,2048,1,72,81,81,34,0,74,5,80,0,113,17,51,41,65,123,81,81,2144,69,64,68,64,1,512]

theorem envBound49789 : H12AffineFastState.Bounded env49789 := by
  intro p hp
  have h : env49789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49788_49789 : H12AffineEnvironment.transform 6 104 env49788 = env49789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env49788 == env49789) = true)

theorem identity49789 : scanCanonicalize (H12AffineFastState.compose env49789 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound49789 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env49790 : List Nat := [2,4,8,16,32,64,104,68,512,4,76,1,72,81,81,34,0,74,5,80,0,113,17,51,41,65,123,81,81,44,69,64,68,64,1,512]

theorem envBound49790 : H12AffineFastState.Bounded env49790 := by
  intro p hp
  have h : env49790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49789_49790 : H12AffineEnvironment.transform 10 76 env49789 = env49790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env49789 == env49790) = true)

theorem identity49790 : scanCanonicalize (H12AffineFastState.compose env49790 (packedSelected [2,8] rootPS)) = affineNative (2^(8+1) ^^^ 125) := by decide +kernel

theorem selectedBound49790 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env49791 : List Nat := [2,4,8,16,32,64,104,68,125,4,76,1,72,81,81,34,0,74,5,80,0,113,17,51,41,65,123,81,81,44,69,64,68,64,1,125]

theorem envBound49791 : H12AffineFastState.Bounded env49791 := by
  intro p hp
  have h : env49791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49790_49791 : H12AffineEnvironment.transform 8 125 env49790 = env49791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 125 env49790 == env49791) = true)

theorem identity49791 : scanCanonicalize (H12AffineFastState.compose env49791 (packedSelected [2,3,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound49791 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env49792 : List Nat := [2,4,8,13,32,64,104,68,96,4,76,1,72,76,76,34,0,74,5,77,0,108,12,46,41,65,102,76,76,44,69,64,68,64,1,96]

theorem envBound49792 : H12AffineFastState.Bounded env49792 := by
  intro p hp
  have h : env49792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49791_49792 : H12AffineEnvironment.transform 3 13 env49791 = env49792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env49791 == env49792) = true)

theorem identity49792 : scanCanonicalize (H12AffineFastState.compose env49792 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound49792 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env49793 : List Nat := [2,4,8,13,32,12,36,8,44,4,0,1,4,0,0,34,0,6,5,1,0,32,12,46,41,13,42,0,0,44,9,12,8,12,1,44]

theorem envBound49793 : H12AffineFastState.Bounded env49793 := by
  intro p hp
  have h : env49793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49792_49793 : H12AffineEnvironment.transform 5 12 env49792 = env49793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env49792 == env49793) = true)

theorem identity49793 : scanCanonicalize (H12AffineFastState.compose env49793 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49794 : List Nat := [2,4,8,13,12,12,8,8,0,4,0,1,4,0,0,14,0,6,5,1,0,12,12,2,5,13,6,0,0,0,9,12,8,12,1,0]

theorem envBound49794 : H12AffineFastState.Bounded env49794 := by
  intro p hp
  have h : env49794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49793_49794 : H12AffineEnvironment.transform 4 12 env49793 = env49794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49793 == env49794) = true)

theorem identity49794 : scanCanonicalize (H12AffineFastState.compose env49794 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49795 : List Nat := [2,3,8,10,11,11,8,8,0,3,0,1,3,0,0,9,0,1,2,1,0,11,11,2,2,10,1,0,0,0,9,11,8,11,1,0]

theorem envBound49795 : H12AffineFastState.Bounded env49795 := by
  intro p hp
  have h : env49795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49794_49795 : H12AffineEnvironment.transform 1 3 env49794 = env49795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49794 == env49795) = true)

def env49796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4097,477,74047,69648,13768,78894,4415,74815,1297,81227,8205,1280,256,65830,1345,5953]

theorem envBound49796 : H12AffineFastState.Bounded env49796 := by
  intro p hp
  have h : env49796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49771_49796 : H12AffineEnvironment.transform 17 65665 env49771 = env49796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49771 == env49796) = true)

theorem identity49796 : scanCanonicalize (H12AffineFastState.compose env49796 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound49796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,9481,486,4416,13341,4097,477,8280,4471,13768,13641,4415,9560,1297,15404,8205,1280,256,65,1345,5953]

theorem envBound49797 : H12AffineFastState.Bounded env49797 := by
  intro p hp
  have h : env49797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49796_49797 : H12AffineEnvironment.transform 15 359 env49796 = env49797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env49796 == env49797) = true)

def env49798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,359,1345,486,4416,5205,4097,477,16,4471,5504,5377,4415,1296,1297,7268,69,1280,256,65,1345,5953]

theorem envBound49798 : H12AffineFastState.Bounded env49798 := by
  intro p hp
  have h : env49798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49797_49798 : H12AffineEnvironment.transform 12 72 env49797 = env49798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env49797 == env49798) = true)

theorem identity49798 : scanCanonicalize (H12AffineFastState.compose env49798 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49798 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49799 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,1,4420,359,81,486,4416,4421,4097,477,16,4471,4240,4113,4415,0,1,6516,69,16,256,65,81,4689]

theorem envBound49799 : H12AffineFastState.Bounded env49799 := by
  intro p hp
  have h : env49799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49798_49799 : H12AffineEnvironment.transform 9 272 env49798 = env49799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49798 == env49799) = true)

theorem identity49799 : scanCanonicalize (H12AffineFastState.compose env49799 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound49799 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49800 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,509,72,1,185,359,81,486,189,184,508,477,16,138,365,492,194,0,1,2185,69,16,256,65,81,940]

theorem envBound49800 : H12AffineFastState.Bounded env49800 := by
  intro p hp
  have h : env49800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49799_49800 : H12AffineEnvironment.transform 11 509 env49799 = env49800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env49799 == env49800) = true)

theorem identity49800 : scanCanonicalize (H12AffineFastState.compose env49800 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound49800 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env49801 : List Nat := [2,4,8,16,32,64,128,256,216,272,2048,509,72,1,185,359,81,486,189,184,508,477,16,138,365,492,194,0,1,2185,69,16,256,65,81,372]

theorem envBound49801 : H12AffineFastState.Bounded env49801 := by
  intro p hp
  have h : env49801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49800_49801 : H12AffineEnvironment.transform 8 216 env49800 = env49801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env49800 == env49801) = true)

theorem identity49801 : scanCanonicalize (H12AffineFastState.compose env49801 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound49801 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env49802 : List Nat := [2,4,8,16,32,64,128,256,216,272,429,509,72,1,185,359,81,486,189,184,508,477,16,138,365,492,194,0,1,292,69,16,256,65,81,372]

theorem envBound49802 : H12AffineFastState.Bounded env49802 := by
  intro p hp
  have h : env49802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49801_49802 : H12AffineEnvironment.transform 10 429 env49801 = env49802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env49801 == env49802) = true)

theorem identity49802 : scanCanonicalize (H12AffineFastState.compose env49802 (packedSelected [3,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound49802 : packedSelected [3,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env49803 : List Nat := [2,4,8,16,10,64,128,256,216,272,391,471,72,1,147,333,81,460,151,146,470,477,16,138,327,454,194,0,1,270,69,16,256,65,81,350]

theorem envBound49803 : H12AffineFastState.Bounded env49803 := by
  intro p hp
  have h : env49803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49802_49803 : H12AffineEnvironment.transform 4 10 env49802 = env49803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env49802 == env49803) = true)

theorem identity49803 : scanCanonicalize (H12AffineFastState.compose env49803 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound49803 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env49804 : List Nat := [2,4,8,16,10,11,128,256,147,272,391,412,3,1,147,262,26,391,151,146,413,406,16,138,268,397,137,0,1,270,14,16,256,10,26,277]

theorem envBound49804 : H12AffineFastState.Bounded env49804 := by
  intro p hp
  have h : env49804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49803_49804 : H12AffineEnvironment.transform 5 11 env49803 = env49804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env49803 == env49804) = true)

def env49805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,359,1344,486,4416,5204,4097,477,17,4471,5505,5376,4415,1297,1297,7269,68,1280,256,65,1345,5953]

theorem envBound49805 : H12AffineFastState.Bounded env49805 := by
  intro p hp
  have h : env49805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49797_49805 : H12AffineEnvironment.transform 12 73 env49797 = env49805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env49797 == env49805) = true)

theorem identity49805 : scanCanonicalize (H12AffineFastState.compose env49805 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound49805 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,73,1297,81,359,1344,486,1348,80,1029,477,17,1395,389,260,1339,1297,1297,2145,68,1280,256,65,1345,837]

theorem envBound49806 : H12AffineFastState.Bounded env49806 := by
  intro p hp
  have h : env49806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49805_49806 : H12AffineEnvironment.transform 11 1028 env49805 = env49806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env49805 == env49806) = true)

theorem identity49806 : scanCanonicalize (H12AffineFastState.compose env49806 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound49806 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env49807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,951,1028,73,1297,81,359,1344,486,1348,80,1029,477,17,1395,389,260,1339,1297,1297,982,68,1280,256,65,1345,837]

theorem envBound49807 : H12AffineFastState.Bounded env49807 := by
  intro p hp
  have h : env49807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49806_49807 : H12AffineEnvironment.transform 10 951 env49806 = env49807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env49806 == env49807) = true)

theorem identity49807 : scanCanonicalize (H12AffineFastState.compose env49807 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49807 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env49808 : List Nat := [2,4,8,16,32,64,128,256,512,320,951,324,73,81,81,359,0,486,4,80,325,477,17,51,389,260,123,81,81,982,68,64,256,65,1,837]

theorem envBound49808 : H12AffineFastState.Bounded env49808 := by
  intro p hp
  have h : env49808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49807_49808 : H12AffineEnvironment.transform 9 320 env49807 = env49808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49807 == env49808) = true)

theorem identity49808 : scanCanonicalize (H12AffineFastState.compose env49808 (packedSelected [2,8] rootPS)) = affineNative (2^(8+1) ^^^ 213) := by decide +kernel

theorem selectedBound49808 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env49809 : List Nat := [2,4,8,16,32,64,128,256,213,320,354,324,73,81,81,359,0,486,4,80,325,477,17,51,389,260,123,81,81,259,68,64,256,65,1,400]

theorem envBound49809 : H12AffineFastState.Bounded env49809 := by
  intro p hp
  have h : env49809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49808_49809 : H12AffineEnvironment.transform 8 213 env49808 = env49809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 213 env49808 == env49809) = true)

theorem identity49809 : scanCanonicalize (H12AffineFastState.compose env49809 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49809 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env49810 : List Nat := [2,4,8,16,32,17,128,256,132,273,307,277,24,0,0,310,0,439,4,1,276,396,17,51,389,260,42,0,0,259,21,17,256,16,1,400]

theorem envBound49810 : H12AffineFastState.Bounded env49810 := by
  intro p hp
  have h : env49810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49809_49810 : H12AffineEnvironment.transform 5 17 env49809 = env49810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49809 == env49810) = true)

theorem identity49810 : scanCanonicalize (H12AffineFastState.compose env49810 (packedSelected [2,5] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound49810 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env49811 : List Nat := [2,4,8,16,32,17,128,182,132,167,133,163,24,0,0,128,0,1,4,1,162,58,17,51,51,178,42,0,0,181,21,17,182,16,1,38]

theorem envBound49811 : H12AffineFastState.Bounded env49811 := by
  intro p hp
  have h : env49811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49810_49811 : H12AffineEnvironment.transform 7 182 env49810 = env49811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env49810 == env49811) = true)

theorem identity49811 : scanCanonicalize (H12AffineFastState.compose env49811 (packedSelected [1,2,3,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49811 : packedSelected [1,2,3,10,12] rootPS < 2^1333 := by decide +kernel

def env49812 : List Nat := [2,4,8,16,17,17,128,135,132,150,133,146,24,0,0,128,0,1,4,1,147,11,17,2,2,131,27,0,0,132,21,17,135,16,1,23]

theorem envBound49812 : H12AffineFastState.Bounded env49812 := by
  intro p hp
  have h : env49812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49811_49812 : H12AffineEnvironment.transform 4 17 env49811 = env49812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49811 == env49812) = true)

theorem identity49812 : scanCanonicalize (H12AffineFastState.compose env49812 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49812 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49813 : List Nat := [2,4,8,6,7,7,128,135,132,128,133,132,14,0,0,128,0,1,4,1,133,11,7,2,2,131,13,0,0,132,3,7,135,6,1,1]

theorem envBound49813 : H12AffineFastState.Bounded env49813 := by
  intro p hp
  have h : env49813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49812_49813 : H12AffineEnvironment.transform 3 6 env49812 = env49813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49812 == env49813) = true)

theorem identity49813 : scanCanonicalize (H12AffineFastState.compose env49813 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49813 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49814 : List Nat := [2,4,8,6,7,7,8,15,12,8,13,12,14,0,0,8,0,1,4,1,13,11,7,2,2,11,13,0,0,12,3,7,15,6,1,1]

theorem envBound49814 : H12AffineFastState.Bounded env49814 := by
  intro p hp
  have h : env49814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49813_49814 : H12AffineEnvironment.transform 6 8 env49813 = env49814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49813 == env49814) = true)

theorem identity49814 : scanCanonicalize (H12AffineFastState.compose env49814 (packedSelected [4,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49814 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env49815 : List Nat := [2,4,5,6,7,7,5,2,1,5,0,1,3,0,0,5,0,1,4,1,0,6,7,2,2,6,0,0,0,1,3,7,2,6,1,1]

theorem envBound49815 : H12AffineFastState.Bounded env49815 := by
  intro p hp
  have h : env49815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49814_49815 : H12AffineEnvironment.transform 2 5 env49814 = env49815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49814 == env49815) = true)

def env49816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245633,148800,545088,96346,16876545,750910,256,17006917,1344,525825]

theorem envBound49816 : H12AffineFastState.Bounded env49816 := by
  intro p hp
  have h : env49816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49134_49816 : H12AffineEnvironment.transform 26 17245633 env49134 = env49816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env49134 == env49816) = true)

theorem identity49816 : scanCanonicalize (H12AffineFastState.compose env49816 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound49816 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86518,209263,17245633,148800,74814,96346,16876545,131136,256,17006917,1344,95103]

theorem envBound49817 : H12AffineFastState.Bounded env49817 := by
  intro p hp
  have h : env49817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49816_49817 : H12AffineEnvironment.transform 18 95614 env49816 = env49817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env49816 == env49817) = true)

def env49818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86518,209263,225345,148800,74814,96346,381313,131136,256,513221,1344,95103]

theorem envBound49818 : H12AffineFastState.Bounded env49818 := by
  intro p hp
  have h : env49818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49817_49818 : H12AffineEnvironment.transform 23 284032 env49817 = env49818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env49817 == env49818) = true)

def env49819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95614,32769,4097,61648,91504,284032,86518,5215,21873,90224,74814,96346,381313,75120,256,324085,1344,95103]

theorem envBound49819 : H12AffineFastState.Bounded env49819 := by
  intro p hp
  have h : env49819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49818_49819 : H12AffineEnvironment.transform 16 75056 env49818 = env49819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env49818 == env49819) = true)

def env49820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1374,32769,4097,61648,5456,284032,8662,5215,21873,4176,21534,2170,303521,21840,256,324085,1344,863]

theorem envBound49820 : H12AffineFastState.Bounded env49820 := by
  intro p hp
  have h : env49820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49819_49820 : H12AffineEnvironment.transform 15 28704 env49819 = env49820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env49819 == env49820) = true)

theorem identity49820 : scanCanonicalize (H12AffineFastState.compose env49820 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound49820 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49821 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21583,262144,1025,32769,4097,61648,5135,283871,8329,5215,21550,4176,21534,2170,303358,21519,95,323754,1055,512]

theorem envBound49821 : H12AffineFastState.Bounded env49821 := by
  intro p hp
  have h : env49821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49820_49821 : H12AffineEnvironment.transform 7 95 env49820 = env49821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env49820 == env49821) = true)

theorem identity49821 : scanCanonicalize (H12AffineFastState.compose env49821 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound49821 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49822 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21583,5357,1025,32769,4097,61648,5135,16434,8329,5215,21550,4176,21534,2170,46099,21519,95,58439,1055,512]

theorem envBound49822 : H12AffineFastState.Bounded env49822 := by
  intro p hp
  have h : env49822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49821_49822 : H12AffineEnvironment.transform 17 5357 env49821 = env49822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env49821 == env49822) = true)

theorem identity49822 : scanCanonicalize (H12AffineFastState.compose env49822 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49822 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49823 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25676,28704,21583,5357,1025,25677,4097,5276,5135,16434,8329,5215,21550,4176,21534,2170,20575,21519,95,11,1055,512]

theorem envBound49823 : H12AffineFastState.Bounded env49823 := by
  intro p hp
  have h : env49823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49822_49823 : H12AffineEnvironment.transform 14 25676 env49822 = env49823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49822 == env49823) = true)

theorem identity49823 : scanCanonicalize (H12AffineFastState.compose env49823 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49823 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49824 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25629,28704,21534,5308,1025,25628,4097,5276,5135,16434,8329,5134,21550,4097,21534,2091,20494,21519,14,11,1055,512]

theorem envBound49824 : H12AffineFastState.Bounded env49824 := by
  intro p hp
  have h : env49824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49823_49824 : H12AffineEnvironment.transform 5 17 env49823 = env49824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49823 == env49824) = true)

theorem identity49824 : scanCanonicalize (H12AffineFastState.compose env49824 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49824 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49825 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,16384,24600,28704,20507,4281,4,24601,4097,4249,4106,16434,8329,4107,20523,4097,20507,2091,20494,20490,14,11,26,512]

theorem envBound49825 : H12AffineFastState.Bounded env49825 := by
  intro p hp
  have h : env49825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49824_49825 : H12AffineEnvironment.transform 9 5 env49824 = env49825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49824 == env49825) = true)

theorem identity49825 : scanCanonicalize (H12AffineFastState.compose env49825 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49825 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49826 : List Nat := [2,4,8,11,32,10,128,14,512,5,2048,4096,8192,16384,24579,28704,20480,4258,4,24578,4097,4226,4106,16425,8329,4107,20523,4097,20480,2091,20494,20490,14,11,1,512]

theorem envBound49826 : H12AffineFastState.Bounded env49826 := by
  intro p hp
  have h : env49826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49825_49826 : H12AffineEnvironment.transform 3 11 env49825 = env49826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49825 == env49826) = true)

theorem identity49826 : scanCanonicalize (H12AffineFastState.compose env49826 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound49826 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49827 : List Nat := [2,4,8,11,32,10,128,14,512,5,2048,513,8192,16384,24579,25121,16897,675,4,24578,512,643,523,16425,8329,522,16938,512,16897,2091,16911,16907,14,11,1,512]

theorem envBound49827 : H12AffineFastState.Bounded env49827 := by
  intro p hp
  have h : env49827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49826_49827 : H12AffineEnvironment.transform 11 513 env49826 = env49827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env49826 == env49827) = true)

theorem identity49827 : scanCanonicalize (H12AffineFastState.compose env49827 (packedSelected [10,15] rootPS)) = affineNative (2^(13+1) ^^^ 137) := by decide +kernel

theorem selectedBound49827 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env49828 : List Nat := [2,4,8,11,32,10,128,14,512,5,2048,513,8192,137,8330,8872,648,675,4,8331,512,643,523,160,8329,522,675,512,648,2091,646,642,14,11,1,512]

theorem envBound49828 : H12AffineFastState.Bounded env49828 := by
  intro p hp
  have h : env49828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49827_49828 : H12AffineEnvironment.transform 13 137 env49827 = env49828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 137 env49827 == env49828) = true)

theorem identity49828 : scanCanonicalize (H12AffineFastState.compose env49828 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 174) := by decide +kernel

theorem selectedBound49828 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49829 : List Nat := [2,4,8,11,32,10,128,14,174,5,2048,175,8192,137,8330,8198,38,13,4,8331,174,45,165,160,8329,164,13,174,38,2091,40,44,14,11,1,174]

theorem envBound49829 : H12AffineFastState.Bounded env49829 := by
  intro p hp
  have h : env49829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49828_49829 : H12AffineEnvironment.transform 8 174 env49828 = env49829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 174 env49828 == env49829) = true)

theorem identity49829 : scanCanonicalize (H12AffineFastState.compose env49829 (packedSelected [0,1,2,8,9,13] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49829 : packedSelected [0,1,2,8,9,13] rootPS < 2^1333 := by decide +kernel

def env49830 : List Nat := [2,4,8,11,6,10,128,14,136,5,2048,137,8192,137,8330,8198,0,13,4,8331,136,11,131,134,8329,130,13,136,0,2061,14,10,14,11,1,136]

theorem envBound49830 : H12AffineFastState.Bounded env49830 := by
  intro p hp
  have h : env49830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49829_49830 : H12AffineEnvironment.transform 4 6 env49829 = env49830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49829 == env49830) = true)

theorem identity49830 : scanCanonicalize (H12AffineFastState.compose env49830 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49831 : List Nat := [2,4,8,11,6,10,5,14,13,5,2048,12,8192,12,8207,8198,0,13,4,8206,13,11,6,3,8204,7,13,13,0,2061,14,10,14,11,1,13]

theorem envBound49831 : H12AffineFastState.Bounded env49831 := by
  intro p hp
  have h : env49831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49830_49831 : H12AffineEnvironment.transform 6 5 env49830 = env49831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49830 == env49831) = true)

def env49832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1375,32769,4097,61648,5457,284032,8663,5215,21873,4177,21535,2171,303520,21841,256,324085,1344,862]

theorem envBound49832 : H12AffineFastState.Bounded env49832 := by
  intro p hp
  have h : env49832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49819_49832 : H12AffineEnvironment.transform 15 28705 env49819 = env49832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env49819 == env49832) = true)

def env49833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95614,32769,4097,61648,91505,284032,86518,5214,21872,90225,74814,96346,381313,75121,256,324084,1344,95103]

theorem envBound49833 : H12AffineFastState.Bounded env49833 := by
  intro p hp
  have h : env49833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49818_49833 : H12AffineEnvironment.transform 16 75057 env49818 = env49833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env49818 == env49833) = true)

def env49834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1374,32769,4097,61648,5457,284032,8662,5214,21872,4177,21534,2170,303521,21841,256,324084,1344,863]

theorem envBound49834 : H12AffineFastState.Bounded env49834 := by
  intro p hp
  have h : env49834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49833_49834 : H12AffineEnvironment.transform 15 28704 env49833 = env49834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env49833 == env49834) = true)

def env49835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1375,32769,4097,61648,5456,284032,8663,5214,21872,4176,21535,2171,303520,21840,256,324084,1344,862]

theorem envBound49835 : H12AffineFastState.Bounded env49835 := by
  intro p hp
  have h : env49835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49833_49835 : H12AffineEnvironment.transform 15 28705 env49833 = env49835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env49833 == env49835) = true)

theorem identity49835 : scanCanonicalize (H12AffineFastState.compose env49835 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound49835 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49836 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21582,262144,1025,32769,4097,61648,5134,283870,8329,5214,21550,4176,21535,2171,303358,21518,94,323754,1054,512]

theorem envBound49836 : H12AffineFastState.Bounded env49836 := by
  intro p hp
  have h : env49836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49835_49836 : H12AffineEnvironment.transform 7 94 env49835 = env49836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env49835 == env49836) = true)

theorem identity49836 : scanCanonicalize (H12AffineFastState.compose env49836 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound49836 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49837 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21582,5356,1025,32769,4097,61648,5134,16434,8329,5214,21550,4176,21535,2171,46098,21518,94,58438,1054,512]

theorem envBound49837 : H12AffineFastState.Bounded env49837 := by
  intro p hp
  have h : env49837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49836_49837 : H12AffineEnvironment.transform 17 5356 env49836 = env49837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env49836 == env49837) = true)

theorem identity49837 : scanCanonicalize (H12AffineFastState.compose env49837 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49837 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49838 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25676,28705,21582,5356,1025,25677,4097,5276,5134,16434,8329,5214,21550,4176,21535,2171,20574,21518,94,10,1054,512]

theorem envBound49838 : H12AffineFastState.Bounded env49838 := by
  intro p hp
  have h : env49838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49837_49838 : H12AffineEnvironment.transform 14 25676 env49837 = env49838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49837 == env49838) = true)

theorem identity49838 : scanCanonicalize (H12AffineFastState.compose env49838 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49838 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49839 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25629,28705,21535,5309,1025,25628,4097,5276,5134,16434,8329,5135,21550,4097,21535,2090,20495,21518,15,10,1054,512]

theorem envBound49839 : H12AffineFastState.Bounded env49839 := by
  intro p hp
  have h : env49839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49838_49839 : H12AffineEnvironment.transform 5 17 env49838 = env49839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49838 == env49839) = true)

theorem identity49839 : scanCanonicalize (H12AffineFastState.compose env49839 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49839 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49840 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,16384,24600,28705,20506,4280,4,24601,4097,4249,4107,16434,8329,4106,20523,4097,20506,2090,20495,20491,15,10,27,512]

theorem envBound49840 : H12AffineFastState.Bounded env49840 := by
  intro p hp
  have h : env49840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49839_49840 : H12AffineEnvironment.transform 9 5 env49839 = env49840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49839 == env49840) = true)

theorem identity49840 : scanCanonicalize (H12AffineFastState.compose env49840 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49840 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49841 : List Nat := [2,4,8,10,32,11,128,15,512,5,2048,4096,8192,16384,24578,28705,20480,4258,4,24579,4097,4227,4107,16424,8329,4106,20523,4097,20480,2090,20495,20491,15,10,1,512]

theorem envBound49841 : H12AffineFastState.Bounded env49841 := by
  intro p hp
  have h : env49841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49840_49841 : H12AffineEnvironment.transform 3 10 env49840 = env49841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49840 == env49841) = true)

theorem identity49841 : scanCanonicalize (H12AffineFastState.compose env49841 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound49841 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49842 : List Nat := [2,4,8,10,32,11,128,15,512,5,2048,512,8192,16384,24578,25121,16896,674,4,24579,513,643,523,16424,8329,522,16939,513,16896,2090,16911,16907,15,10,1,512]

theorem envBound49842 : H12AffineFastState.Bounded env49842 := by
  intro p hp
  have h : env49842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49841_49842 : H12AffineEnvironment.transform 11 512 env49841 = env49842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env49841 == env49842) = true)

theorem identity49842 : scanCanonicalize (H12AffineFastState.compose env49842 (packedSelected [10,15] rootPS)) = affineNative (2^(13+1) ^^^ 137) := by decide +kernel

theorem selectedBound49842 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env49843 : List Nat := [2,4,8,10,32,11,128,15,512,5,2048,512,8192,137,8331,8872,649,674,4,8330,513,643,523,161,8329,522,674,513,649,2090,646,642,15,10,1,512]

theorem envBound49843 : H12AffineFastState.Bounded env49843 := by
  intro p hp
  have h : env49843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49842_49843 : H12AffineEnvironment.transform 13 137 env49842 = env49843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 137 env49842 == env49843) = true)

theorem identity49843 : scanCanonicalize (H12AffineFastState.compose env49843 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound49843 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49844 : List Nat := [2,4,8,10,32,11,128,15,38,5,2048,38,8192,137,8331,8334,175,132,4,8330,39,165,45,161,8329,44,132,39,175,2090,160,164,15,10,1,38]

theorem envBound49844 : H12AffineFastState.Bounded env49844 := by
  intro p hp
  have h : env49844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49843_49844 : H12AffineEnvironment.transform 8 38 env49843 = env49844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env49843 == env49844) = true)

theorem identity49844 : scanCanonicalize (H12AffineFastState.compose env49844 (packedSelected [0,1,2,8,9,13] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound49844 : packedSelected [0,1,2,8,9,13] rootPS < 2^1333 := by decide +kernel

def env49845 : List Nat := [2,4,8,10,32,11,128,15,38,5,162,38,8192,137,8331,8334,175,132,4,8330,39,165,45,161,8329,44,132,39,175,136,160,164,15,10,1,38]

theorem envBound49845 : H12AffineFastState.Bounded env49845 := by
  intro p hp
  have h : env49845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49844_49845 : H12AffineEnvironment.transform 10 162 env49844 = env49845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env49844 == env49845) = true)

theorem identity49845 : scanCanonicalize (H12AffineFastState.compose env49845 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 37) := by decide +kernel

theorem selectedBound49845 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49846 : List Nat := [2,4,8,10,32,11,128,15,38,5,162,38,37,137,174,171,175,132,4,175,39,165,45,161,172,44,132,39,175,136,160,164,15,10,1,38]

theorem envBound49846 : H12AffineFastState.Bounded env49846 := by
  intro p hp
  have h : env49846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49845_49846 : H12AffineEnvironment.transform 12 37 env49845 = env49846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 37 env49845 == env49846) = true)

theorem identity49846 : scanCanonicalize (H12AffineFastState.compose env49846 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49846 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env49847 : List Nat := [2,4,8,10,32,11,8,15,38,5,42,38,37,1,38,35,39,12,4,39,39,45,45,41,36,44,12,39,39,0,40,44,15,10,1,38]

theorem envBound49847 : H12AffineFastState.Bounded env49847 := by
  intro p hp
  have h : env49847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49846_49847 : H12AffineEnvironment.transform 6 8 env49846 = env49847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49846 == env49847) = true)

theorem identity49847 : scanCanonicalize (H12AffineFastState.compose env49847 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49848 : List Nat := [2,4,8,10,11,11,8,15,13,5,1,13,14,1,13,8,12,12,4,12,12,6,6,2,15,7,12,12,12,0,3,7,15,10,1,13]

theorem envBound49848 : H12AffineFastState.Bounded env49848 := by
  intro p hp
  have h : env49848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49847_49848 : H12AffineEnvironment.transform 4 11 env49847 = env49848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49847 == env49848) = true)

theorem identity49848 : scanCanonicalize (H12AffineFastState.compose env49848 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49849 : List Nat := [2,4,5,7,6,6,5,2,0,5,1,0,3,1,0,5,1,1,4,1,1,6,6,2,2,7,1,1,1,0,3,7,2,7,1,0]

theorem envBound49849 : H12AffineFastState.Bounded env49849 := by
  intro p hp
  have h : env49849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49848_49849 : H12AffineEnvironment.transform 2 5 env49848 = env49849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49848 == env49849) = true)

def env49850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86518,209263,225344,148800,74814,96346,381312,131136,256,513220,1344,95103]

theorem envBound49850 : H12AffineFastState.Bounded env49850 := by
  intro p hp
  have h : env49850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49817_49850 : H12AffineEnvironment.transform 23 284033 env49817 = env49850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env49817 == env49850) = true)

def env49851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95614,32769,4097,61648,91504,284033,86518,5215,21872,90224,74814,96346,381312,75120,256,324084,1344,95103]

theorem envBound49851 : H12AffineFastState.Bounded env49851 := by
  intro p hp
  have h : env49851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49850_49851 : H12AffineEnvironment.transform 16 75056 env49850 = env49851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env49850 == env49851) = true)

def env49852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1374,32769,4097,61648,5456,284033,8662,5215,21872,4176,21534,2170,303520,21840,256,324084,1344,863]

theorem envBound49852 : H12AffineFastState.Bounded env49852 := by
  intro p hp
  have h : env49852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49851_49852 : H12AffineEnvironment.transform 15 28704 env49851 = env49852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env49851 == env49852) = true)

theorem identity49852 : scanCanonicalize (H12AffineFastState.compose env49852 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound49852 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49853 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21583,262144,1025,32769,4097,61648,5135,283870,8329,5215,21551,4176,21534,2170,303359,21519,95,323755,1055,512]

theorem envBound49853 : H12AffineFastState.Bounded env49853 := by
  intro p hp
  have h : env49853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49852_49853 : H12AffineEnvironment.transform 7 95 env49852 = env49853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env49852 == env49853) = true)

theorem identity49853 : scanCanonicalize (H12AffineFastState.compose env49853 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound49853 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49854 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21583,5356,1025,32769,4097,61648,5135,16434,8329,5215,21551,4176,21534,2170,46099,21519,95,58439,1055,512]

theorem envBound49854 : H12AffineFastState.Bounded env49854 := by
  intro p hp
  have h : env49854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49853_49854 : H12AffineEnvironment.transform 17 5356 env49853 = env49854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env49853 == env49854) = true)

theorem identity49854 : scanCanonicalize (H12AffineFastState.compose env49854 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49854 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49855 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25676,28704,21583,5356,1025,25677,4097,5276,5135,16434,8329,5215,21551,4176,21534,2170,20575,21519,95,11,1055,512]

theorem envBound49855 : H12AffineFastState.Bounded env49855 := by
  intro p hp
  have h : env49855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49854_49855 : H12AffineEnvironment.transform 14 25676 env49854 = env49855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49854 == env49855) = true)

theorem identity49855 : scanCanonicalize (H12AffineFastState.compose env49855 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49855 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49856 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25629,28704,21534,5309,1025,25628,4097,5276,5135,16434,8329,5134,21551,4097,21534,2091,20494,21519,14,11,1055,512]

theorem envBound49856 : H12AffineFastState.Bounded env49856 := by
  intro p hp
  have h : env49856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49855_49856 : H12AffineEnvironment.transform 5 17 env49855 = env49856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49855 == env49856) = true)

theorem identity49856 : scanCanonicalize (H12AffineFastState.compose env49856 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49856 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49857 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,16384,24600,28704,20507,4280,4,24601,4097,4249,4106,16434,8329,4107,20522,4097,20507,2091,20494,20490,14,11,26,512]

theorem envBound49857 : H12AffineFastState.Bounded env49857 := by
  intro p hp
  have h : env49857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49856_49857 : H12AffineEnvironment.transform 9 5 env49856 = env49857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49856 == env49857) = true)

theorem identity49857 : scanCanonicalize (H12AffineFastState.compose env49857 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49857 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49858 : List Nat := [2,4,8,10,32,11,128,14,512,5,2048,4096,8192,16384,24578,28704,20481,4258,4,24579,4097,4227,4106,16424,8329,4107,20522,4097,20481,2091,20494,20490,14,11,0,512]

theorem envBound49858 : H12AffineFastState.Bounded env49858 := by
  intro p hp
  have h : env49858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49857_49858 : H12AffineEnvironment.transform 3 10 env49857 = env49858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49857 == env49858) = true)

theorem identity49858 : scanCanonicalize (H12AffineFastState.compose env49858 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound49858 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49859 : List Nat := [2,4,8,10,32,11,128,14,512,5,2048,513,8192,16384,24578,25121,16896,675,4,24579,512,642,523,16424,8329,522,16939,512,16896,2091,16911,16907,14,11,0,512]

theorem envBound49859 : H12AffineFastState.Bounded env49859 := by
  intro p hp
  have h : env49859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49858_49859 : H12AffineEnvironment.transform 11 513 env49858 = env49859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env49858 == env49859) = true)

theorem identity49859 : scanCanonicalize (H12AffineFastState.compose env49859 (packedSelected [10,15] rootPS)) = affineNative (2^(13+1) ^^^ 136) := by decide +kernel

theorem selectedBound49859 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env49860 : List Nat := [2,4,8,10,32,11,128,14,512,5,2048,513,8192,136,8330,8873,648,675,4,8331,512,642,523,160,8329,522,675,512,648,2091,647,643,14,11,0,512]

theorem envBound49860 : H12AffineFastState.Bounded env49860 := by
  intro p hp
  have h : env49860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49859_49860 : H12AffineEnvironment.transform 13 136 env49859 = env49860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 136 env49859 == env49860) = true)

theorem identity49860 : scanCanonicalize (H12AffineFastState.compose env49860 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound49860 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49861 : List Nat := [2,4,8,10,32,11,47,14,512,5,2048,513,8192,39,8229,8710,551,524,4,8228,512,557,523,15,8230,522,524,512,551,2091,552,556,14,11,0,512]

theorem envBound49861 : H12AffineFastState.Bounded env49861 := by
  intro p hp
  have h : env49861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49860_49861 : H12AffineEnvironment.transform 6 47 env49860 = env49861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env49860 == env49861) = true)

theorem identity49861 : scanCanonicalize (H12AffineFastState.compose env49861 (packedSelected [0,1,2,8,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound49861 : packedSelected [0,1,2,8,9,13] rootPS < 2^1333 := by decide +kernel

def env49862 : List Nat := [2,4,8,10,32,11,47,14,12,5,2048,13,8192,39,8229,8202,43,0,4,8228,12,33,7,15,8230,6,0,12,43,2091,36,32,14,11,0,12]

theorem envBound49862 : H12AffineFastState.Bounded env49862 := by
  intro p hp
  have h : env49862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49861_49862 : H12AffineEnvironment.transform 8 12 env49861 = env49862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env49861 == env49862) = true)

theorem identity49862 : scanCanonicalize (H12AffineFastState.compose env49862 (packedSelected [3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49862 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env49863 : List Nat := [2,4,4,6,32,7,35,2,0,5,2048,1,8192,39,8229,8198,39,0,4,8228,0,33,7,3,8230,6,0,0,39,2087,36,32,2,7,0,0]

theorem envBound49863 : H12AffineFastState.Bounded env49863 := by
  intro p hp
  have h : env49863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49862_49863 : H12AffineEnvironment.transform 2 4 env49862 = env49863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49862 == env49863) = true)

theorem identity49863 : scanCanonicalize (H12AffineFastState.compose env49863 (packedSelected [0,1] rootPS)) = affineNative (2^(12+1) ^^^ 36) := by decide +kernel

theorem selectedBound49863 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49864 : List Nat := [2,4,4,6,32,7,35,2,0,5,2048,1,36,39,1,34,39,0,4,0,0,33,7,3,2,6,0,0,39,2087,36,32,2,7,0,0]

theorem envBound49864 : H12AffineFastState.Bounded env49864 := by
  intro p hp
  have h : env49864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49863_49864 : H12AffineEnvironment.transform 12 36 env49863 = env49864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 36 env49863 == env49864) = true)

theorem identity49864 : scanCanonicalize (H12AffineFastState.compose env49864 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound49864 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49865 : List Nat := [2,4,4,6,32,7,35,2,0,5,39,1,36,39,1,34,39,0,4,0,0,33,7,3,2,6,0,0,39,0,36,32,2,7,0,0]

theorem envBound49865 : H12AffineFastState.Bounded env49865 := by
  intro p hp
  have h : env49865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49864_49865 : H12AffineEnvironment.transform 10 39 env49864 = env49865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env49864 == env49865) = true)

def env49866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1375,32769,4097,61648,5457,284033,8663,5215,21872,4177,21535,2171,303521,21841,256,324084,1344,862]

theorem envBound49866 : H12AffineFastState.Bounded env49866 := by
  intro p hp
  have h : env49866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49851_49866 : H12AffineEnvironment.transform 15 28705 env49851 = env49866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env49851 == env49866) = true)

def env49867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95614,32769,4097,61648,91505,284033,86518,5214,21873,90225,74814,96346,381312,75121,256,324085,1344,95103]

theorem envBound49867 : H12AffineFastState.Bounded env49867 := by
  intro p hp
  have h : env49867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49850_49867 : H12AffineEnvironment.transform 16 75057 env49850 = env49867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env49850 == env49867) = true)

def env49868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1374,32769,4097,61648,5457,284033,8662,5214,21873,4177,21534,2170,303520,21841,256,324085,1344,863]

theorem envBound49868 : H12AffineFastState.Bounded env49868 := by
  intro p hp
  have h : env49868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49867_49868 : H12AffineEnvironment.transform 15 28704 env49867 = env49868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env49867 == env49868) = true)

def env49869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1375,32769,4097,61648,5456,284033,8663,5214,21873,4176,21535,2171,303521,21840,256,324085,1344,862]

theorem envBound49869 : H12AffineFastState.Bounded env49869 := by
  intro p hp
  have h : env49869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49867_49869 : H12AffineEnvironment.transform 15 28705 env49867 = env49869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env49867 == env49869) = true)

theorem identity49869 : scanCanonicalize (H12AffineFastState.compose env49869 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound49869 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49870 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21582,262144,1025,32769,4097,61648,5134,283871,8329,5214,21551,4176,21535,2171,303359,21518,94,323755,1054,512]

theorem envBound49870 : H12AffineFastState.Bounded env49870 := by
  intro p hp
  have h : env49870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49869_49870 : H12AffineEnvironment.transform 7 94 env49869 = env49870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env49869 == env49870) = true)

theorem identity49870 : scanCanonicalize (H12AffineFastState.compose env49870 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound49870 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49871 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21582,5357,1025,32769,4097,61648,5134,16434,8329,5214,21551,4176,21535,2171,46098,21518,94,58438,1054,512]

theorem envBound49871 : H12AffineFastState.Bounded env49871 := by
  intro p hp
  have h : env49871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49870_49871 : H12AffineEnvironment.transform 17 5357 env49870 = env49871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env49870 == env49871) = true)

theorem identity49871 : scanCanonicalize (H12AffineFastState.compose env49871 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49871 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49872 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25676,28705,21582,5357,1025,25677,4097,5276,5134,16434,8329,5214,21551,4176,21535,2171,20574,21518,94,10,1054,512]

theorem envBound49872 : H12AffineFastState.Bounded env49872 := by
  intro p hp
  have h : env49872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49871_49872 : H12AffineEnvironment.transform 14 25676 env49871 = env49872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49871 == env49872) = true)

theorem identity49872 : scanCanonicalize (H12AffineFastState.compose env49872 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49872 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49873 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25629,28705,21535,5308,1025,25628,4097,5276,5134,16434,8329,5135,21551,4097,21535,2090,20495,21518,15,10,1054,512]

theorem envBound49873 : H12AffineFastState.Bounded env49873 := by
  intro p hp
  have h : env49873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49872_49873 : H12AffineEnvironment.transform 5 17 env49872 = env49873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49872 == env49873) = true)

theorem identity49873 : scanCanonicalize (H12AffineFastState.compose env49873 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49873 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49874 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,16384,24600,28705,20506,4281,4,24601,4097,4249,4107,16434,8329,4106,20522,4097,20506,2090,20495,20491,15,10,27,512]

theorem envBound49874 : H12AffineFastState.Bounded env49874 := by
  intro p hp
  have h : env49874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49873_49874 : H12AffineEnvironment.transform 9 5 env49873 = env49874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49873 == env49874) = true)

theorem identity49874 : scanCanonicalize (H12AffineFastState.compose env49874 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49874 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49875 : List Nat := [2,4,8,11,32,10,128,15,512,5,2048,4096,8192,16384,24579,28705,20481,4258,4,24578,4097,4226,4107,16425,8329,4106,20522,4097,20481,2090,20495,20491,15,10,0,512]

theorem envBound49875 : H12AffineFastState.Bounded env49875 := by
  intro p hp
  have h : env49875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49874_49875 : H12AffineEnvironment.transform 3 11 env49874 = env49875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49874 == env49875) = true)

theorem identity49875 : scanCanonicalize (H12AffineFastState.compose env49875 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound49875 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49876 : List Nat := [2,4,8,11,32,10,128,15,512,5,2048,512,8192,16384,24579,25121,16897,674,4,24578,513,642,523,16425,8329,522,16938,513,16897,2090,16911,16907,15,10,0,512]

theorem envBound49876 : H12AffineFastState.Bounded env49876 := by
  intro p hp
  have h : env49876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49875_49876 : H12AffineEnvironment.transform 11 512 env49875 = env49876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env49875 == env49876) = true)

theorem identity49876 : scanCanonicalize (H12AffineFastState.compose env49876 (packedSelected [10,15] rootPS)) = affineNative (2^(13+1) ^^^ 136) := by decide +kernel

theorem selectedBound49876 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env49877 : List Nat := [2,4,8,11,32,10,128,15,512,5,2048,512,8192,136,8331,8873,649,674,4,8330,513,642,523,161,8329,522,674,513,649,2090,647,643,15,10,0,512]

theorem envBound49877 : H12AffineFastState.Bounded env49877 := by
  intro p hp
  have h : env49877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49876_49877 : H12AffineEnvironment.transform 13 136 env49876 = env49877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 136 env49876 == env49877) = true)

theorem identity49877 : scanCanonicalize (H12AffineFastState.compose env49877 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49877 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49878 : List Nat := [2,4,8,11,6,10,128,15,512,5,2048,512,8192,136,8331,8847,649,644,4,8330,513,642,523,135,8329,522,644,513,649,2060,647,643,15,10,0,512]

theorem envBound49878 : H12AffineFastState.Bounded env49878 := by
  intro p hp
  have h : env49878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49877_49878 : H12AffineEnvironment.transform 4 6 env49877 = env49878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49877 == env49878) = true)

theorem identity49878 : scanCanonicalize (H12AffineFastState.compose env49878 (packedSelected [0,1,2,8,9,13] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound49878 : packedSelected [0,1,2,8,9,13] rootPS < 2^1333 := by decide +kernel

def env49879 : List Nat := [2,4,8,11,6,10,128,15,512,5,136,512,8192,136,8331,8847,649,644,4,8330,513,642,523,135,8329,522,644,513,649,132,647,643,15,10,0,512]

theorem envBound49879 : H12AffineFastState.Bounded env49879 := by
  intro p hp
  have h : env49879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49878_49879 : H12AffineEnvironment.transform 10 136 env49878 = env49879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env49878 == env49879) = true)

theorem identity49879 : scanCanonicalize (H12AffineFastState.compose env49879 (packedSelected [0,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49879 : packedSelected [0,5,8] rootPS < 2^1333 := by decide +kernel

def env49880 : List Nat := [2,4,8,11,6,10,8,15,512,5,0,512,8192,0,8195,8711,513,524,4,8194,513,522,523,15,8193,522,524,513,513,12,527,523,15,10,0,512]

theorem envBound49880 : H12AffineFastState.Bounded env49880 := by
  intro p hp
  have h : env49880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49879_49880 : H12AffineEnvironment.transform 6 8 env49879 = env49880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49879 == env49880) = true)

theorem identity49880 : scanCanonicalize (H12AffineFastState.compose env49880 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49881 : List Nat := [2,4,4,7,6,6,4,3,512,5,0,512,8192,0,8195,8711,513,512,4,8194,513,518,519,3,8193,518,512,513,513,0,515,519,3,6,0,512]

theorem envBound49881 : H12AffineFastState.Bounded env49881 := by
  intro p hp
  have h : env49881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49880_49881 : H12AffineEnvironment.transform 2 4 env49880 = env49881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49880 == env49881) = true)

def env49882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,134217728,148800,545089,96346,16876544,151802110,257,134521988,151462017,525824]

theorem envBound49882 : H12AffineFastState.Bounded env49882 := by
  intro p hp
  have h : env49882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49133_49882 : H12AffineEnvironment.transform 24 533641 env49133 = env49882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env49133 == env49882) = true)

def env49883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245632,148800,545089,96346,16876544,750910,257,17006916,1345,525824]

theorem envBound49883 : H12AffineFastState.Bounded env49883 := by
  intro p hp
  have h : env49883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49882_49883 : H12AffineEnvironment.transform 26 17245632 env49882 = env49883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env49882 == env49883) = true)

theorem identity49883 : scanCanonicalize (H12AffineFastState.compose env49883 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound49883 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41003,533641,672785,493035,148800,545089,96346,74795,750910,257,205167,1345,525824]

theorem envBound49884 : H12AffineFastState.Bounded env49884 := by
  intro p hp
  have h : env49884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49883_49884 : H12AffineEnvironment.transform 23 41003 env49883 = env49884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env49883 == env49884) = true)

def env49885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,493035,148800,148801,96346,74795,90430,257,205167,1345,135680]

theorem envBound49885 : H12AffineFastState.Bounded env49885 := by
  intro p hp
  have h : env49885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49884_49885 : H12AffineEnvironment.transform 18 136192 env49884 = env49885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env49884 == env49885) = true)

def env49886 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,492615,148716,148717,96346,74795,90258,173,204995,1261,135680]

theorem envBound49886 : H12AffineFastState.Bounded env49886 := by
  intro p hp
  have h : env49886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49885_49886 : H12AffineEnvironment.transform 7 172 env49885 = env49886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49885 == env49886) = true)

def env49887 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143497,20497,492567,148668,148669,96266,74795,90258,173,204947,1213,135680]

theorem envBound49887 : H12AffineFastState.Bounded env49887 := by
  intro p hp
  have h : env49887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49886_49887 : H12AffineEnvironment.transform 5 16 env49886 = env49887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49886 == env49887) = true)

theorem identity49887 : scanCanonicalize (H12AffineFastState.compose env49887 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound49887 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49888 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,41003,32809,20497,341175,62492,62493,96266,74795,90258,173,102451,1213,41632]

theorem envBound49888 : H12AffineFastState.Bounded env49888 := by
  intro p hp
  have h : env49888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49887_49888 : H12AffineEnvironment.transform 16 45216 env49887 = env49888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env49887 == env49888) = true)

theorem identity49888 : scanCanonicalize (H12AffineFastState.compose env49888 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound49888 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env49889 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4097,46140,46092,41003,32809,5293,341175,45216,45217,81078,74795,74798,173,102451,1213,41632]

theorem envBound49889 : H12AffineFastState.Bounded env49889 := by
  intro p hp
  have h : env49889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49888_49889 : H12AffineEnvironment.transform 13 1212 env49888 = env49889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env49888 == env49889) = true)

theorem identity49889 : scanCanonicalize (H12AffineFastState.compose env49889 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49889 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49890 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,32768,65536,45216,262144,41125,32769,4097,45113,45065,41003,32809,4264,340146,45216,45217,80051,73774,73771,173,102451,184,41632]

theorem envBound49890 : H12AffineFastState.Bounded env49890 := by
  intro p hp
  have h : env49890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49889_49890 : H12AffineEnvironment.transform 9 5 env49889 = env49890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49889 == env49890) = true)

theorem identity49890 : scanCanonicalize (H12AffineFastState.compose env49890 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound49890 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env49891 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,32768,37018,45216,262144,41125,32769,4097,45113,45065,41003,32809,4264,303144,45216,45217,43049,45236,45233,173,169,184,41632]

theorem envBound49891 : H12AffineFastState.Bounded env49891 := by
  intro p hp
  have h : env49891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49890_49891 : H12AffineEnvironment.transform 15 37018 env49890 = env49891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env49890 == env49891) = true)

theorem identity49891 : scanCanonicalize (H12AffineFastState.compose env49891 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound49891 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env49892 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,32768,37018,45216,2185,41125,32769,4097,45113,45065,41003,32809,4264,43169,45216,45217,43049,45236,45233,173,169,184,41632]

theorem envBound49892 : H12AffineFastState.Bounded env49892 := by
  intro p hp
  have h : env49892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49891_49892 : H12AffineEnvironment.transform 17 2185 env49891 = env49892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env49891 == env49892) = true)

theorem identity49892 : scanCanonicalize (H12AffineFastState.compose env49892 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 6680) := by decide +kernel

theorem selectedBound49892 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env49893 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,6680,185,32768,37018,35512,2185,39613,32769,4097,35361,35345,39475,32809,4264,37561,35512,35513,37425,35500,35497,173,169,184,39096]

theorem envBound49893 : H12AffineFastState.Bounded env49893 := by
  intro p hp
  have h : env49893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49892_49893 : H12AffineEnvironment.transform 12 6680 env49892 = env49893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6680 env49892 == env49893) = true)

theorem identity49893 : scanCanonicalize (H12AffineFastState.compose env49893 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2707) := by decide +kernel

theorem selectedBound49893 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49894 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,2707,139,185,32768,35337,35512,2185,32814,32769,2706,35361,35345,32928,32809,2619,34858,35512,35513,34978,35500,35497,173,169,184,33323]

theorem envBound49894 : H12AffineFastState.Bounded env49894 := by
  intro p hp
  have h : env49894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49893_49894 : H12AffineEnvironment.transform 11 2707 env49893 = env49894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2707 env49893 == env49894) = true)

theorem identity49894 : scanCanonicalize (H12AffineFastState.compose env49894 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49894 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49895 : List Nat := [2,4,8,16,32,16,8,36,512,5,2048,2587,3,49,32768,35337,35376,2049,32814,32769,2586,35361,35345,32808,32809,2619,34858,35376,35377,34858,35364,35361,37,33,48,33323]

theorem envBound49895 : H12AffineFastState.Bounded env49895 := by
  intro p hp
  have h : env49895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49894_49895 : H12AffineEnvironment.transform 6 8 env49894 = env49895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49894 == env49895) = true)

theorem identity49895 : scanCanonicalize (H12AffineFastState.compose env49895 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound49895 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env49896 : List Nat := [2,4,8,16,32,16,8,36,512,5,561,42,3,49,32768,32824,32769,560,32814,32769,43,32784,32800,32808,32809,10,33307,32769,32768,33307,32789,32784,37,33,48,33323]

theorem envBound49896 : H12AffineFastState.Bounded env49896 := by
  intro p hp
  have h : env49896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49895_49896 : H12AffineEnvironment.transform 10 561 env49895 = env49896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env49895 == env49896) = true)

theorem identity49896 : scanCanonicalize (H12AffineFastState.compose env49896 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49896 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49897 : List Nat := [2,4,8,16,32,16,8,36,0,5,49,42,3,49,32768,32824,32769,48,32814,32769,43,32784,32800,32808,32809,10,32795,32769,32768,32795,32789,32784,37,33,48,32811]

theorem envBound49897 : H12AffineFastState.Bounded env49897 := by
  intro p hp
  have h : env49897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49896_49897 : H12AffineEnvironment.transform 8 0 env49896 = env49897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49896 == env49897) = true)

theorem identity49897 : scanCanonicalize (H12AffineFastState.compose env49897 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 49) := by decide +kernel

theorem selectedBound49897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49898 : List Nat := [2,4,8,16,32,16,8,36,0,5,49,42,3,49,49,9,48,48,31,48,43,33,17,25,24,10,42,48,49,42,36,33,37,33,48,26]

theorem envBound49898 : H12AffineFastState.Bounded env49898 := by
  intro p hp
  have h : env49898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49897_49898 : H12AffineEnvironment.transform 14 49 env49897 = env49898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 49 env49897 == env49898) = true)

theorem identity49898 : scanCanonicalize (H12AffineFastState.compose env49898 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound49898 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49899 : List Nat := [2,4,8,16,29,16,8,25,0,5,12,23,3,12,12,9,13,13,31,13,22,28,17,25,24,10,23,13,12,23,25,28,24,28,13,26]

theorem envBound49899 : H12AffineFastState.Bounded env49899 := by
  intro p hp
  have h : env49899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49898_49899 : H12AffineEnvironment.transform 4 29 env49898 = env49899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env49898 == env49899) = true)

theorem identity49899 : scanCanonicalize (H12AffineFastState.compose env49899 (packedSelected [0,4,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49899 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env49900 : List Nat := [2,4,8,11,6,11,8,2,0,5,12,12,3,12,12,9,13,13,4,13,13,7,10,2,3,10,12,13,12,12,2,7,3,7,13,1]

theorem envBound49900 : H12AffineFastState.Bounded env49900 := by
  intro p hp
  have h : env49900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49899_49900 : H12AffineEnvironment.transform 3 11 env49899 = env49900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49899 == env49900) = true)

theorem identity49900 : scanCanonicalize (H12AffineFastState.compose env49900 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49900 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49901 : List Nat := [2,4,1,2,6,2,1,2,0,5,5,5,3,5,5,0,4,4,4,4,4,7,3,2,3,3,5,4,5,5,2,7,3,7,4,1]

theorem envBound49901 : H12AffineFastState.Bounded env49901 := by
  intro p hp
  have h : env49901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49900_49901 : H12AffineEnvironment.transform 2 1 env49900 = env49901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49900 == env49901) = true)

theorem identity49901 : scanCanonicalize (H12AffineFastState.compose env49901 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49902 : List Nat := [2,1,1,2,3,2,1,2,0,0,0,0,3,0,0,0,1,1,1,1,1,2,3,2,3,3,0,1,0,0,2,2,3,2,1,1]

theorem envBound49902 : H12AffineFastState.Bounded env49902 := by
  intro p hp
  have h : env49902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49901_49902 : H12AffineEnvironment.transform 1 1 env49901 = env49902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49901 == env49902) = true)

theorem identity49902 : scanCanonicalize (H12AffineFastState.compose env49902 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49902 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49903 : List Nat := [1,1,1,1,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,1,0,0,1,1,0,1,1,1]

theorem envBound49903 : H12AffineFastState.Bounded env49903 := by
  intro p hp
  have h : env49903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49902_49903 : H12AffineEnvironment.transform 0 1 env49902 = env49903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49902 == env49903) = true)

def env49904 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143497,20497,492566,148669,148668,96267,74795,90258,173,204946,1212,135680]

theorem envBound49904 : H12AffineFastState.Bounded env49904 := by
  intro p hp
  have h : env49904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49886_49904 : H12AffineEnvironment.transform 5 17 env49886 = env49904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49886 == env49904) = true)

theorem identity49904 : scanCanonicalize (H12AffineFastState.compose env49904 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound49904 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49905 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,41003,143497,20497,105630,148669,148668,96267,74795,90258,173,204946,1212,135680]

theorem envBound49905 : H12AffineFastState.Bounded env49905 := by
  intro p hp
  have h : env49905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49904_49905 : H12AffineEnvironment.transform 17 137352 env49904 = env49905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env49904 == env49905) = true)

theorem identity49905 : scanCanonicalize (H12AffineFastState.compose env49905 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound49905 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env49906 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4097,61569,147473,41003,143497,20497,43169,148669,148668,19508,4116,21677,173,136365,1212,135680]

theorem envBound49906 : H12AffineFastState.Bounded env49906 := by
  intro p hp
  have h : env49906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49905_49906 : H12AffineEnvironment.transform 15 13375 env49905 = env49906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env49905 == env49906) = true)

theorem identity49906 : scanCanonicalize (H12AffineFastState.compose env49906 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound49906 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49907 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136192,32769,4097,46141,132269,41003,143497,5293,43169,131073,131072,2184,4116,4113,173,136365,1212,135680]

theorem envBound49907 : H12AffineFastState.Bounded env49907 := by
  intro p hp
  have h : env49907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49906_49907 : H12AffineEnvironment.transform 13 1212 env49906 = env49907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env49906 == env49907) = true)

theorem identity49907 : scanCanonicalize (H12AffineFastState.compose env49907 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound49907 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env49908 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,40984,47248,46104,32769,4097,46141,42165,41003,37009,5293,43169,40985,40984,2184,4116,4113,173,46261,1212,45592]

theorem envBound49908 : H12AffineFastState.Bounded env49908 := by
  intro p hp
  have h : env49908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49907_49908 : H12AffineEnvironment.transform 16 40984 env49907 = env49908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env49907 == env49908) = true)

theorem identity49908 : scanCanonicalize (H12AffineFastState.compose env49908 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 11271) := by decide +kernel

theorem selectedBound49908 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env49909 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,11271,13375,3103,5271,6175,11270,4097,6202,2226,3116,15510,5293,1190,3102,3103,2184,4116,4113,173,6322,1212,7711]

theorem envBound49909 : H12AffineFastState.Bounded env49909 := by
  intro p hp
  have h : env49909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49908_49909 : H12AffineEnvironment.transform 14 11271 env49908 = env49909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11271 env49908 == env49909) = true)

theorem identity49909 : scanCanonicalize (H12AffineFastState.compose env49909 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound49909 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49910 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,11271,9351,3103,1071,2215,11270,185,2178,2226,3116,11310,1045,1190,3102,3103,2184,172,169,173,2058,1212,3751]

theorem envBound49910 : H12AffineFastState.Bounded env49910 := by
  intro p hp
  have h : env49910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49909_49910 : H12AffineEnvironment.transform 11 184 env49909 = env49910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env49909 == env49910) = true)

theorem identity49910 : scanCanonicalize (H12AffineFastState.compose env49910 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound49910 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env49911 : List Nat := [2,4,8,16,32,17,128,172,512,663,2048,184,8192,555,10896,8720,2696,696,2215,10897,185,2178,2226,2747,10937,642,561,2697,2696,2184,172,169,173,2058,555,2096]

theorem envBound49911 : H12AffineFastState.Bounded env49911 := by
  intro p hp
  have h : env49911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49910_49911 : H12AffineEnvironment.transform 9 663 env49910 = env49911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env49910 == env49911) = true)

theorem identity49911 : scanCanonicalize (H12AffineFastState.compose env49911 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound49911 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env49912 : List Nat := [2,4,8,16,32,17,128,172,512,663,2048,184,2099,555,675,2595,2696,696,2215,674,185,2178,2226,2747,650,642,561,2697,2696,2184,172,169,173,2058,555,2096]

theorem envBound49912 : H12AffineFastState.Bounded env49912 := by
  intro p hp
  have h : env49912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49911_49912 : H12AffineEnvironment.transform 12 2099 env49911 = env49912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env49911 == env49912) = true)

theorem identity49912 : scanCanonicalize (H12AffineFastState.compose env49912 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound49912 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env49913 : List Nat := [2,4,8,16,32,17,128,172,147,4,2048,184,2099,184,48,2224,2075,43,2215,49,185,2178,2226,2088,25,17,162,2074,2075,2184,172,169,173,2058,184,2096]

theorem envBound49913 : H12AffineFastState.Bounded env49913 := by
  intro p hp
  have h : env49913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49912_49913 : H12AffineEnvironment.transform 8 147 env49912 = env49913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env49912 == env49913) = true)

theorem identity49913 : scanCanonicalize (H12AffineFastState.compose env49913 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound49913 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49914 : List Nat := [2,4,8,16,32,17,128,172,147,4,42,184,25,184,48,154,49,43,141,49,185,168,152,2,25,17,162,48,49,162,172,169,173,32,184,26]

theorem envBound49914 : H12AffineFastState.Bounded env49914 := by
  intro p hp
  have h : env49914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49913_49914 : H12AffineEnvironment.transform 10 42 env49913 = env49914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env49913 == env49914) = true)

theorem identity49914 : scanCanonicalize (H12AffineFastState.compose env49914 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49914 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49915 : List Nat := [2,4,8,16,12,17,128,128,147,4,6,148,25,148,28,154,29,7,141,29,149,132,152,2,25,17,142,28,29,142,128,133,129,12,148,26]

theorem envBound49915 : H12AffineFastState.Bounded env49915 := by
  intro p hp
  have h : env49915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49914_49915 : H12AffineEnvironment.transform 4 12 env49914 = env49915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49914 == env49915) = true)

theorem identity49915 : scanCanonicalize (H12AffineFastState.compose env49915 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound49915 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env49916 : List Nat := [2,4,8,16,12,17,19,19,0,4,6,7,25,7,28,9,29,7,30,29,6,23,11,2,25,17,29,28,29,29,19,22,18,12,7,26]

theorem envBound49916 : H12AffineFastState.Bounded env49916 := by
  intro p hp
  have h : env49916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49915_49916 : H12AffineEnvironment.transform 6 19 env49915 = env49916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env49915 == env49916) = true)

theorem identity49916 : scanCanonicalize (H12AffineFastState.compose env49916 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49917 : List Nat := [2,4,8,10,12,11,9,9,0,4,6,7,3,7,6,9,7,7,4,7,6,13,11,2,3,11,7,6,7,7,9,12,8,12,7,0]

theorem envBound49917 : H12AffineFastState.Bounded env49917 := by
  intro p hp
  have h : env49917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49916_49917 : H12AffineEnvironment.transform 3 10 env49916 = env49917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49916 == env49917) = true)

def env49918 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,492614,148717,148716,96346,74795,90259,172,204994,1260,135680]

theorem envBound49918 : H12AffineFastState.Bounded env49918 := by
  intro p hp
  have h : env49918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49885_49918 : H12AffineEnvironment.transform 7 173 env49885 = env49918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49885 == env49918) = true)

def env49919 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143497,20497,492566,148669,148668,96266,74795,90259,172,204946,1212,135680]

theorem envBound49919 : H12AffineFastState.Bounded env49919 := by
  intro p hp
  have h : env49919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49918_49919 : H12AffineEnvironment.transform 5 16 env49918 = env49919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49918 == env49919) = true)

theorem identity49919 : scanCanonicalize (H12AffineFastState.compose env49919 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound49919 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49920 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61568,98355,41003,127146,20497,279605,99486,99487,96266,74795,90259,172,57521,1212,119331]

theorem envBound49920 : H12AffineFastState.Bounded env49920 := by
  intro p hp
  have h : env49920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49919_49920 : H12AffineEnvironment.transform 16 114723 env49919 = env49920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env49919 == env49920) = true)

theorem identity49920 : scanCanonicalize (H12AffineFastState.compose env49920 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 104466) := by decide +kernel

theorem selectedBound49920 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49921 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,104466,119843,32769,4097,61568,98355,41003,127146,20497,121895,99486,99487,96266,74795,90259,172,57521,1212,119331]

theorem envBound49921 : H12AffineFastState.Bounded env49921 := by
  intro p hp
  have h : env49921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49920_49921 : H12AffineEnvironment.transform 17 104466 env49920 = env49921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 104466 env49920 == env49921) = true)

theorem identity49921 : scanCanonicalize (H12AffineFastState.compose env49921 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound49921 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env49922 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,18481,1024,32769,4097,61568,20496,41003,8329,20497,3076,21693,21692,43049,62472,45232,172,57521,1212,512]

theorem envBound49922 : H12AffineFastState.Bounded env49922 := by
  intro p hp
  have h : env49922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49921_49922 : H12AffineEnvironment.transform 15 53283 env49921 = env49922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env49921 == env49922) = true)

theorem identity49922 : scanCanonicalize (H12AffineFastState.compose env49922 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound49922 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49923 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9380,29831,4096,18481,1024,9381,4097,21540,20496,1167,8329,20497,3076,21693,21692,3213,20652,5140,172,17429,1212,512]

theorem envBound49923 : H12AffineFastState.Bounded env49923 := by
  intro p hp
  have h : env49923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49922_49923 : H12AffineEnvironment.transform 14 9380 env49922 = env49923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env49922 == env49923) = true)

theorem identity49923 : scanCanonicalize (H12AffineFastState.compose env49923 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound49923 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49924 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8744,9380,5807,4096,10777,1024,9381,4097,13836,12856,1167,8329,12857,3076,13973,13972,3213,12932,5140,172,9789,1212,512]

theorem envBound49924 : H12AffineFastState.Bounded env49924 := by
  intro p hp
  have h : env49924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49923_49924 : H12AffineEnvironment.transform 13 8744 env49923 = env49924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env49923 == env49924) = true)

theorem identity49924 : scanCanonicalize (H12AffineFastState.compose env49924 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound49924 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49925 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1167,1703,43,5807,4096,3734,1024,42,4097,4739,5815,1167,1030,5814,3076,4634,4635,3213,5643,5140,172,690,1212,512]

theorem envBound49925 : H12AffineFastState.Bounded env49925 := by
  intro p hp
  have h : env49925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49924_49925 : H12AffineEnvironment.transform 12 1167 env49924 = env49925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env49924 == env49925) = true)

theorem identity49925 : scanCanonicalize (H12AffineFastState.compose env49925 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound49925 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env49926 : List Nat := [2,4,8,16,32,16,128,173,512,542,2048,4096,657,185,43,4273,4096,2184,542,42,4097,4739,4265,657,536,4264,2586,4634,4635,2707,4117,4618,172,690,674,512]

theorem envBound49926 : H12AffineFastState.Bounded env49926 := by
  intro p hp
  have h : env49926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49925_49926 : H12AffineEnvironment.transform 9 542 env49925 = env49926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env49925 == env49926) = true)

theorem identity49926 : scanCanonicalize (H12AffineFastState.compose env49926 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound49926 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env49927 : List Nat := [2,4,8,16,32,16,128,173,512,542,184,4096,657,185,43,4273,4096,48,542,42,4097,4739,4265,657,536,4264,674,4634,4635,555,4117,4618,172,690,674,512]

theorem envBound49927 : H12AffineFastState.Bounded env49927 := by
  intro p hp
  have h : env49927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49926_49927 : H12AffineEnvironment.transform 10 184 env49926 = env49927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env49926 == env49927) = true)

theorem identity49927 : scanCanonicalize (H12AffineFastState.compose env49927 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound49927 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49928 : List Nat := [2,4,8,16,32,16,128,173,512,542,184,48,657,185,43,129,48,48,542,42,49,691,153,657,536,152,674,554,555,555,37,570,172,690,674,512]

theorem envBound49928 : H12AffineFastState.Bounded env49928 := by
  intro p hp
  have h : env49928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49927_49928 : H12AffineEnvironment.transform 11 48 env49927 = env49928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49927 == env49928) = true)

theorem identity49928 : scanCanonicalize (H12AffineFastState.compose env49928 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49928 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env49929 : List Nat := [2,4,8,16,32,16,8,37,512,542,48,48,537,49,43,9,48,48,542,42,49,571,17,537,536,16,554,554,555,555,37,570,36,570,554,512]

theorem envBound49929 : H12AffineFastState.Bounded env49929 := by
  intro p hp
  have h : env49929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49928_49929 : H12AffineEnvironment.transform 6 8 env49928 = env49929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49928 == env49929) = true)

theorem identity49929 : scanCanonicalize (H12AffineFastState.compose env49929 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound49929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49930 : List Nat := [2,4,8,16,32,16,8,37,26,4,48,48,3,49,43,9,48,48,4,42,49,33,17,3,2,16,48,48,49,49,37,32,36,32,48,26]

theorem envBound49930 : H12AffineFastState.Bounded env49930 := by
  intro p hp
  have h : env49930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49929_49930 : H12AffineEnvironment.transform 8 26 env49929 = env49930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env49929 == env49930) = true)

theorem identity49930 : scanCanonicalize (H12AffineFastState.compose env49930 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound49930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49931 : List Nat := [2,4,8,16,22,16,8,19,26,4,6,6,3,7,29,9,6,6,4,28,7,23,17,3,2,16,6,6,7,7,19,22,18,22,6,26]

theorem envBound49931 : H12AffineFastState.Bounded env49931 := by
  intro p hp
  have h : env49931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49930_49931 : H12AffineEnvironment.transform 4 22 env49930 = env49931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env49930 == env49931) = true)

def env49932 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143497,20497,492567,148668,148669,96267,74795,90259,172,204947,1213,135680]

theorem envBound49932 : H12AffineFastState.Bounded env49932 := by
  intro p hp
  have h : env49932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49918_49932 : H12AffineEnvironment.transform 5 17 env49918 = env49932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49918 == env49932) = true)

theorem identity49932 : scanCanonicalize (H12AffineFastState.compose env49932 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound49932 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49933 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61569,147473,41003,143497,20497,60445,148668,148669,96267,74795,90259,172,204947,1213,135680]

theorem envBound49933 : H12AffineFastState.Bounded env49933 := by
  intro p hp
  have h : env49933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49932_49933 : H12AffineEnvironment.transform 17 223242 env49932 = env49933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env49932 == env49933) = true)

theorem identity49933 : scanCanonicalize (H12AffineFastState.compose env49933 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound49933 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49934 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4097,61569,147473,41003,143497,20497,60445,148668,148669,2184,21672,4112,172,151568,1213,135680]

theorem envBound49934 : H12AffineFastState.Bounded env49934 := by
  intro p hp
  have h : env49934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49933_49934 : H12AffineEnvironment.transform 15 28803 env49933 = env49934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env49933 == env49934) = true)

theorem identity49934 : scanCanonicalize (H12AffineFastState.compose env49934 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61465) := by decide +kernel

theorem selectedBound49934 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49935 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,61465,59536,58393,32769,4097,61569,45064,41003,49296,20497,60445,46245,46244,2184,21672,4112,172,40969,1213,57881]

theorem envBound49935 : H12AffineFastState.Bounded env49935 := by
  intro p hp
  have h : env49935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49934_49935 : H12AffineEnvironment.transform 16 61465 env49934 = env49935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61465 env49934 == env49935) = true)

theorem identity49935 : scanCanonicalize (H12AffineFastState.compose env49935 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49935 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env49936 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,46244,44077,41124,32769,4097,46140,45064,41003,33837,5292,43168,46245,46244,2184,4117,4112,172,40969,1213,42660]

theorem envBound49936 : H12AffineFastState.Bounded env49936 := by
  intro p hp
  have h : env49936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49935_49936 : H12AffineEnvironment.transform 13 1213 env49935 = env49936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env49935 == env49936) = true)

theorem identity49936 : scanCanonicalize (H12AffineFastState.compose env49936 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound49936 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49937 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,13340,13374,184,6193,5304,13341,4097,32,1044,5175,12337,5292,7356,185,184,2184,4117,4112,172,5141,1213,4792]

theorem envBound49937 : H12AffineFastState.Bounded env49937 := by
  intro p hp
  have h : env49937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49936_49937 : H12AffineEnvironment.transform 14 13340 env49936 = env49937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env49936 == env49937) = true)

theorem identity49937 : scanCanonicalize (H12AffineFastState.compose env49937 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound49937 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env49938 : List Nat := [2,4,8,16,32,17,128,173,512,516,2048,4096,8192,697,12824,12858,184,6193,4796,12825,4097,32,528,4659,12337,4776,6840,185,184,2184,4117,4112,172,4625,697,4792]

theorem envBound49938 : H12AffineFastState.Bounded env49938 := by
  intro p hp
  have h : env49938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49937_49938 : H12AffineEnvironment.transform 9 516 env49937 = env49938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env49937 == env49938) = true)

theorem identity49938 : scanCanonicalize (H12AffineFastState.compose env49938 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound49938 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49939 : List Nat := [2,4,8,16,32,17,128,173,512,516,2048,4096,144,697,4744,4778,184,6193,4796,4745,4097,32,528,4659,4257,4776,6840,185,184,2184,4117,4112,172,4625,697,4792]

theorem envBound49939 : H12AffineFastState.Bounded env49939 := by
  intro p hp
  have h : env49939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49938_49939 : H12AffineEnvironment.transform 12 144 env49938 = env49939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env49938 == env49939) = true)

theorem identity49939 : scanCanonicalize (H12AffineFastState.compose env49939 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49939 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env49940 : List Nat := [2,4,8,16,32,17,128,173,512,516,48,4096,144,697,4744,4778,184,4097,4796,4745,4097,32,528,4659,4257,4776,4744,185,184,184,4117,4112,172,4625,697,4792]

theorem envBound49940 : H12AffineFastState.Bounded env49940 := by
  intro p hp
  have h : env49940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49939_49940 : H12AffineEnvironment.transform 10 48 env49939 = env49940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49939 == env49940) = true)

theorem identity49940 : scanCanonicalize (H12AffineFastState.compose env49940 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound49940 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env49941 : List Nat := [2,4,8,16,32,17,128,173,27,31,48,4096,144,162,4243,4273,184,4097,4263,4242,4097,32,11,4136,4257,4275,4243,185,184,184,4117,4112,172,4106,162,4259]

theorem envBound49941 : H12AffineFastState.Bounded env49941 := by
  intro p hp
  have h : env49941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49940_49941 : H12AffineEnvironment.transform 8 27 env49940 = env49941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env49940 == env49941) = true)

theorem identity49941 : scanCanonicalize (H12AffineFastState.compose env49941 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 60) := by decide +kernel

theorem selectedBound49941 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env49942 : List Nat := [2,4,8,16,32,17,128,173,27,31,48,60,144,162,175,141,184,61,155,174,61,32,11,20,157,143,175,185,184,184,41,44,172,54,162,159]

theorem envBound49942 : H12AffineFastState.Bounded env49942 := by
  intro p hp
  have h : env49942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49941_49942 : H12AffineEnvironment.transform 11 60 env49941 = env49942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 60 env49941 == env49942) = true)

theorem identity49942 : scanCanonicalize (H12AffineFastState.compose env49942 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49942 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env49943 : List Nat := [2,4,4,16,32,17,128,161,23,19,48,48,144,162,163,129,180,49,151,162,49,32,7,20,145,131,163,181,180,180,37,32,160,54,162,147]

theorem envBound49943 : H12AffineFastState.Bounded env49943 := by
  intro p hp
  have h : env49943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49942_49943 : H12AffineEnvironment.transform 2 4 env49942 = env49943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49942 == env49943) = true)

theorem identity49943 : scanCanonicalize (H12AffineFastState.compose env49943 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound49943 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env49944 : List Nat := [2,4,4,16,32,17,18,51,23,19,48,48,2,48,49,19,38,49,5,48,49,32,7,20,3,17,49,39,38,38,37,32,50,54,48,1]

theorem envBound49944 : H12AffineFastState.Bounded env49944 := by
  intro p hp
  have h : env49944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49943_49944 : H12AffineEnvironment.transform 6 18 env49943 = env49944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env49943 == env49944) = true)

theorem identity49944 : scanCanonicalize (H12AffineFastState.compose env49944 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49944 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49945 : List Nat := [2,4,4,16,7,17,18,20,23,19,23,23,2,23,22,19,1,22,5,23,22,7,7,20,3,17,22,0,1,1,2,7,21,17,23,1]

theorem envBound49945 : H12AffineFastState.Bounded env49945 := by
  intro p hp
  have h : env49945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49944_49945 : H12AffineEnvironment.transform 4 7 env49944 = env49945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49944 == env49945) = true)

theorem identity49945 : scanCanonicalize (H12AffineFastState.compose env49945 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49946 : List Nat := [2,4,4,6,7,7,4,2,1,5,1,1,2,1,0,5,1,0,5,1,0,7,7,2,3,7,0,0,1,1,2,7,3,7,1,1]

theorem envBound49946 : H12AffineFastState.Bounded env49946 := by
  intro p hp
  have h : env49946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49945_49946 : H12AffineEnvironment.transform 3 6 env49945 = env49946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49945 == env49946) = true)

def env49947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,493035,148800,148800,96346,74795,90431,257,205167,1345,135681]

theorem envBound49947 : H12AffineFastState.Bounded env49947 := by
  intro p hp
  have h : env49947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49884_49947 : H12AffineEnvironment.transform 18 136193 env49884 = env49947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env49884 == env49947) = true)

def env49948 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,492615,148716,148716,96346,74795,90259,173,204995,1261,135681]

theorem envBound49948 : H12AffineFastState.Bounded env49948 := by
  intro p hp
  have h : env49948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49947_49948 : H12AffineEnvironment.transform 7 172 env49947 = env49948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49947 == env49948) = true)

def env49949 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143496,20496,492567,148668,148668,96266,74795,90259,173,204947,1213,135681]

theorem envBound49949 : H12AffineFastState.Bounded env49949 := by
  intro p hp
  have h : env49949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49948_49949 : H12AffineEnvironment.transform 5 16 env49948 = env49949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49948 == env49949) = true)

theorem identity49949 : scanCanonicalize (H12AffineFastState.compose env49949 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound49949 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49950 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,41003,143496,20496,105630,148668,148668,96266,74795,90259,173,204947,1213,135681]

theorem envBound49950 : H12AffineFastState.Bounded env49950 := by
  intro p hp
  have h : env49950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49949_49950 : H12AffineEnvironment.transform 17 137353 env49949 = env49950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env49949 == env49950) = true)

theorem identity49950 : scanCanonicalize (H12AffineFastState.compose env49950 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound49950 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env49951 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4097,61568,147472,41003,143496,20496,43169,148668,148668,19509,4116,21676,173,136364,1213,135681]

theorem envBound49951 : H12AffineFastState.Bounded env49951 := by
  intro p hp
  have h : env49951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49950_49951 : H12AffineEnvironment.transform 15 13375 env49950 = env49951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env49950 == env49951) = true)

theorem identity49951 : scanCanonicalize (H12AffineFastState.compose env49951 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49951 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49952 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136193,32769,4097,46141,132269,41003,143496,5293,43169,131073,131073,2184,4116,4113,173,136364,1213,135681]

theorem envBound49952 : H12AffineFastState.Bounded env49952 := by
  intro p hp
  have h : env49952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49951_49952 : H12AffineEnvironment.transform 13 1213 env49951 = env49952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env49951 == env49952) = true)

theorem identity49952 : scanCanonicalize (H12AffineFastState.compose env49952 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound49952 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env49953 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12312,13375,131072,137353,136193,12313,4097,1061,132269,4147,143496,5293,6329,131073,131073,2184,4116,4113,173,136364,1213,135681]

theorem envBound49953 : H12AffineFastState.Bounded env49953 := by
  intro p hp
  have h : env49953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49952_49953 : H12AffineEnvironment.transform 14 12312 env49952 = env49953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env49952 == env49953) = true)

theorem identity49953 : scanCanonicalize (H12AffineFastState.compose env49953 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound49953 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env49954 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1213,12312,13375,131072,136238,136193,12313,4097,1061,132269,4147,143496,5293,5150,131073,131073,1071,4116,4113,173,136364,1213,135681]

theorem envBound49954 : H12AffineFastState.Bounded env49954 := by
  intro p hp
  have h : env49954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49953_49954 : H12AffineEnvironment.transform 10 1191 env49953 = env49954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env49953 == env49954) = true)

theorem identity49954 : scanCanonicalize (H12AffineFastState.compose env49954 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound49954 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49955 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4257,1213,185,1182,131072,136238,136193,184,4097,1061,132269,4147,131113,5293,5150,131073,131073,1071,4116,4113,173,136364,1213,135681]

theorem envBound49955 : H12AffineFastState.Bounded env49955 := by
  intro p hp
  have h : env49955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49954_49955 : H12AffineEnvironment.transform 12 4257 env49954 = env49955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env49954 == env49955) = true)

theorem identity49955 : scanCanonicalize (H12AffineFastState.compose env49955 (packedSelected [1,7,8,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 1588) := by decide +kernel

theorem selectedBound49955 : packedSelected [1,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49956 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4257,1213,185,1182,1588,4634,4661,184,4097,1061,665,4147,1565,5293,5150,1589,1589,1071,4116,4113,173,4760,1213,5173]

theorem envBound49956 : H12AffineFastState.Bounded env49956 := by
  intro p hp
  have h : env49956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49955_49956 : H12AffineEnvironment.transform 16 1588 env49955 = env49956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1588 env49955 == env49956) = true)

theorem identity49956 : scanCanonicalize (H12AffineFastState.compose env49956 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound49956 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env49957 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,184,25,1213,185,1182,1588,674,653,184,185,1061,665,139,1565,1045,1190,1589,1589,1071,172,169,173,544,1213,1165]

theorem envBound49957 : H12AffineFastState.Bounded env49957 := by
  intro p hp
  have h : env49957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49956_49957 : H12AffineEnvironment.transform 11 184 env49956 = env49957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env49956 == env49957) = true)

theorem identity49957 : scanCanonicalize (H12AffineFastState.compose env49957 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound49957 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env49958 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1191,184,25,1213,185,1182,1070,184,151,184,185,1061,131,139,1031,1045,1190,1071,1071,1071,172,169,173,58,1213,1165]

theorem envBound49958 : H12AffineFastState.Bounded env49958 := by
  intro p hp
  have h : env49958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49957_49958 : H12AffineEnvironment.transform 8 26 env49957 = env49958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env49957 == env49958) = true)

def env49959 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143496,20496,492566,148669,148669,96267,74795,90259,173,204946,1212,135681]

theorem envBound49959 : H12AffineFastState.Bounded env49959 := by
  intro p hp
  have h : env49959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49948_49959 : H12AffineEnvironment.transform 5 17 env49948 = env49959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49948 == env49959) = true)

theorem identity49959 : scanCanonicalize (H12AffineFastState.compose env49959 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound49959 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49960 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,41003,32809,20496,341175,62492,62492,96267,74795,90259,173,102451,1212,41632]

theorem envBound49960 : H12AffineFastState.Bounded env49960 := by
  intro p hp
  have h : env49960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49959_49960 : H12AffineEnvironment.transform 16 45217 env49959 = env49960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env49959 == env49960) = true)

theorem identity49960 : scanCanonicalize (H12AffineFastState.compose env49960 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49960 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env49961 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4097,46140,46093,41003,32809,5293,341175,45217,45217,81078,74795,74798,173,102451,1212,41632]

theorem envBound49961 : H12AffineFastState.Bounded env49961 := by
  intro p hp
  have h : env49961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49960_49961 : H12AffineEnvironment.transform 13 1213 env49960 = env49961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env49960 == env49961) = true)

theorem identity49961 : scanCanonicalize (H12AffineFastState.compose env49961 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound49961 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49962 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,32768,65536,45217,262144,41124,32769,4097,45112,45065,41003,32809,4265,340147,45217,45217,80050,73775,73770,173,102451,184,41632]

theorem envBound49962 : H12AffineFastState.Bounded env49962 := by
  intro p hp
  have h : env49962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49961_49962 : H12AffineEnvironment.transform 9 4 env49961 = env49962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env49961 == env49962) = true)

theorem identity49962 : scanCanonicalize (H12AffineFastState.compose env49962 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound49962 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env49963 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,32768,37019,45217,262144,41124,32769,4097,45112,45065,41003,32809,4265,303144,45217,45217,43049,45236,45233,173,168,184,41632]

theorem envBound49963 : H12AffineFastState.Bounded env49963 := by
  intro p hp
  have h : env49963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49962_49963 : H12AffineEnvironment.transform 15 37019 env49962 = env49963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env49962 == env49963) = true)

theorem identity49963 : scanCanonicalize (H12AffineFastState.compose env49963 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound49963 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env49964 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,32768,37019,45217,43049,41124,32769,4097,45112,45065,41003,32809,4265,2049,45217,45217,43049,45236,45233,173,168,184,41632]

theorem envBound49964 : H12AffineFastState.Bounded env49964 := by
  intro p hp
  have h : env49964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49963_49964 : H12AffineEnvironment.transform 17 43049 env49963 = env49964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env49963 == env49964) = true)

theorem identity49964 : scanCanonicalize (H12AffineFastState.compose env49964 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 8755) := by decide +kernel

theorem selectedBound49964 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env49965 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,8755,12968,4754,2586,663,8754,4097,4619,4666,536,8730,4265,2049,4754,4754,2586,4743,4738,173,168,184,147]

theorem envBound49965 : H12AffineFastState.Bounded env49965 := by
  intro p hp
  have h : env49965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49964_49965 : H12AffineEnvironment.transform 14 8755 env49964 = env49965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8755 env49964 == env49965) = true)

theorem identity49965 : scanCanonicalize (H12AffineFastState.compose env49965 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2697) := by decide +kernel

theorem selectedBound49965 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env49966 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,2697,8192,185,8755,10273,2075,2586,663,8754,2696,2178,2227,536,8730,2592,2049,2075,2075,2586,2062,2059,173,168,184,147]

theorem envBound49966 : H12AffineFastState.Bounded env49966 := by
  intro p hp
  have h : env49966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49965_49966 : H12AffineEnvironment.transform 11 2697 env49965 = env49966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2697 env49965 == env49966) = true)

theorem identity49966 : scanCanonicalize (H12AffineFastState.compose env49966 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 651) := by decide +kernel

theorem selectedBound49966 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env49967 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,2697,651,185,184,2730,2075,2586,663,185,2696,2178,2227,536,145,2592,2049,2075,2075,2586,2062,2059,173,168,184,147]

theorem envBound49967 : H12AffineFastState.Bounded env49967 := by
  intro p hp
  have h : env49967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49966_49967 : H12AffineEnvironment.transform 12 651 env49966 = env49967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 651 env49966 == env49967) = true)

theorem identity49967 : scanCanonicalize (H12AffineFastState.compose env49967 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound49967 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env49968 : List Nat := [2,4,8,16,32,17,128,172,137,4,2048,2048,2,185,184,2083,2075,2195,30,185,2049,2178,2227,145,145,2217,2049,2075,2075,2195,2062,2059,173,168,184,147]

theorem envBound49968 : H12AffineFastState.Bounded env49968 := by
  intro p hp
  have h : env49968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49967_49968 : H12AffineEnvironment.transform 8 137 env49967 = env49968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env49967 == env49968) = true)

theorem identity49968 : scanCanonicalize (H12AffineFastState.compose env49968 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound49968 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49969 : List Nat := [2,4,8,16,32,17,128,172,137,4,163,163,2,185,184,128,184,48,30,185,162,33,16,145,145,10,162,184,184,48,173,168,173,168,184,147]

theorem envBound49969 : H12AffineFastState.Bounded env49969 := by
  intro p hp
  have h : env49969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49968_49969 : H12AffineEnvironment.transform 10 163 env49968 = env49969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env49968 == env49969) = true)

theorem identity49969 : scanCanonicalize (H12AffineFastState.compose env49969 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound49969 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49970 : List Nat := [2,4,8,16,29,17,128,145,137,4,158,158,2,132,133,128,133,13,30,132,159,28,16,145,145,10,159,133,133,13,144,149,144,149,133,147]

theorem envBound49970 : H12AffineFastState.Bounded env49970 := by
  intro p hp
  have h : env49970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49969_49970 : H12AffineEnvironment.transform 4 29 env49969 = env49970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env49969 == env49970) = true)

theorem identity49970 : scanCanonicalize (H12AffineFastState.compose env49970 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49970 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env49971 : List Nat := [2,4,8,16,29,17,8,25,1,4,22,22,2,12,13,8,13,13,30,12,23,28,16,25,25,10,23,13,13,13,24,29,24,29,13,27]

theorem envBound49971 : H12AffineFastState.Bounded env49971 := by
  intro p hp
  have h : env49971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49970_49971 : H12AffineEnvironment.transform 6 8 env49970 = env49971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49970 == env49971) = true)

def env49972 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,492614,148717,148717,96346,74795,90258,172,204994,1260,135681]

theorem envBound49972 : H12AffineFastState.Bounded env49972 := by
  intro p hp
  have h : env49972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49947_49972 : H12AffineEnvironment.transform 7 173 env49947 = env49972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49947 == env49972) = true)

def env49973 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143496,20496,492566,148669,148669,96266,74795,90258,172,204946,1212,135681]

theorem envBound49973 : H12AffineFastState.Bounded env49973 := by
  intro p hp
  have h : env49973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49972_49973 : H12AffineEnvironment.transform 5 16 env49972 = env49973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49972 == env49973) = true)

theorem identity49973 : scanCanonicalize (H12AffineFastState.compose env49973 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound49973 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49974 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61568,147472,41003,143496,20496,60444,148669,148669,96266,74795,90258,172,204946,1212,135681]

theorem envBound49974 : H12AffineFastState.Bounded env49974 := by
  intro p hp
  have h : env49974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49973_49974 : H12AffineEnvironment.transform 17 223242 env49973 = env49974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env49973 == env49974) = true)

theorem identity49974 : scanCanonicalize (H12AffineFastState.compose env49974 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound49974 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49975 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4097,61568,147472,41003,143496,20496,60444,148669,148669,2184,21673,4112,172,151568,1212,135681]

theorem envBound49975 : H12AffineFastState.Bounded env49975 := by
  intro p hp
  have h : env49975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49974_49975 : H12AffineEnvironment.transform 15 28802 env49974 = env49975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env49974 == env49975) = true)

theorem identity49975 : scanCanonicalize (H12AffineFastState.compose env49975 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61464) := by decide +kernel

theorem selectedBound49975 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49976 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,61464,59536,58393,32769,4097,61568,45064,41003,49296,20496,60444,46245,46245,2184,21673,4112,172,40968,1212,57881]

theorem envBound49976 : H12AffineFastState.Bounded env49976 := by
  intro p hp
  have h : env49976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49975_49976 : H12AffineEnvironment.transform 16 61464 env49975 = env49976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61464 env49975 == env49976) = true)

theorem identity49976 : scanCanonicalize (H12AffineFastState.compose env49976 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound49976 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env49977 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13374,46244,44076,41125,32769,4097,46140,45064,41003,33836,5292,43168,46245,46245,2184,4117,4112,172,40968,1212,42661]

theorem envBound49977 : H12AffineFastState.Bounded env49977 := by
  intro p hp
  have h : env49977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49976_49977 : H12AffineEnvironment.transform 13 1212 env49976 = env49977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env49976 == env49977) = true)

theorem identity49977 : scanCanonicalize (H12AffineFastState.compose env49977 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound49977 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49978 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,13374,1212,7220,4285,12313,4097,1060,16,4147,13364,5292,6328,1213,1213,2184,4117,4112,172,4112,1212,5821]

theorem envBound49978 : H12AffineFastState.Bounded env49978 := by
  intro p hp
  have h : env49978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49977_49978 : H12AffineEnvironment.transform 14 12312 env49977 = env49978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env49977 == env49978) = true)

theorem identity49978 : scanCanonicalize (H12AffineFastState.compose env49978 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1545) := by decide +kernel

theorem selectedBound49978 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env49979 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1545,8192,1212,9745,8759,1212,2621,1716,9744,1544,1060,16,1594,8765,677,3761,1213,1213,2184,1564,1561,172,1561,1212,180]

theorem envBound49979 : H12AffineFastState.Bounded env49979 := by
  intro p hp
  have h : env49979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49978_49979 : H12AffineEnvironment.transform 11 1545 env49978 = env49979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1545 env49978 == env49979) = true)

theorem identity49979 : scanCanonicalize (H12AffineFastState.compose env49979 (packedSelected [0,4,5,6,7,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound49979 : packedSelected [0,4,5,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env49980 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1545,2098,1212,3619,2565,1212,2621,1716,3618,1544,1060,16,1594,2575,677,3761,1213,1213,2184,1564,1561,172,1561,1212,180]

theorem envBound49980 : H12AffineFastState.Bounded env49980 := by
  intro p hp
  have h : env49980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49979_49980 : H12AffineEnvironment.transform 12 2098 env49979 = env49980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env49979 == env49980) = true)

theorem identity49980 : scanCanonicalize (H12AffineFastState.compose env49980 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound49980 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env49981 : List Nat := [2,4,8,16,32,16,52,25,512,1024,2048,1545,2098,1032,3619,2565,1032,2621,1536,3618,1544,1060,16,1594,2575,529,3589,1033,1033,2108,1564,1561,24,1561,1032,0]

theorem envBound49981 : H12AffineFastState.Bounded env49981 := by
  intro p hp
  have h : env49981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49980_49981 : H12AffineEnvironment.transform 6 52 env49980 = env49981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env49980 == env49981) = true)

theorem identity49981 : scanCanonicalize (H12AffineFastState.compose env49981 (packedSelected [1,2,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1042) := by decide +kernel

theorem selectedBound49981 : packedSelected [1,2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env49982 : List Nat := [2,4,8,16,32,16,52,25,512,1024,1042,1545,1056,1032,561,1559,1032,1583,1536,560,1544,1060,16,1594,1565,529,535,1033,1033,1070,1564,1561,24,1561,1032,0]

theorem envBound49982 : H12AffineFastState.Bounded env49982 := by
  intro p hp
  have h : env49982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49981_49982 : H12AffineEnvironment.transform 10 1042 env49981 = env49982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1042 env49981 == env49982) = true)

theorem identity49982 : scanCanonicalize (H12AffineFastState.compose env49982 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 546) := by decide +kernel

theorem selectedBound49982 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49983 : List Nat := [2,4,8,16,32,16,52,25,512,546,560,43,514,554,561,53,554,13,34,560,42,518,16,24,63,529,535,555,555,524,62,59,24,59,554,0]

theorem envBound49983 : H12AffineFastState.Bounded env49983 := by
  intro p hp
  have h : env49983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49982_49983 : H12AffineEnvironment.transform 9 546 env49982 = env49983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 546 env49982 == env49983) = true)

theorem identity49983 : scanCanonicalize (H12AffineFastState.compose env49983 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound49983 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env49984 : List Nat := [2,4,8,16,32,16,52,25,27,57,43,43,25,49,42,53,49,13,34,43,42,29,16,24,63,10,12,48,48,23,62,59,24,59,49,0]

theorem envBound49984 : H12AffineFastState.Bounded env49984 := by
  intro p hp
  have h : env49984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49983_49984 : H12AffineEnvironment.transform 8 27 env49983 = env49984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env49983 == env49984) = true)

theorem identity49984 : scanCanonicalize (H12AffineFastState.compose env49984 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49984 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env49985 : List Nat := [2,4,8,11,32,11,47,2,0,34,43,43,2,42,42,46,42,13,34,43,42,6,11,3,36,10,12,43,43,12,37,32,3,32,42,0]

theorem envBound49985 : H12AffineFastState.Bounded env49985 := by
  intro p hp
  have h : env49985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49984_49985 : H12AffineEnvironment.transform 3 11 env49984 = env49985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49984 == env49985) = true)

theorem identity49985 : scanCanonicalize (H12AffineFastState.compose env49985 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49985 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49986 : List Nat := [2,4,8,11,7,11,8,2,0,5,12,12,2,13,13,9,13,13,5,12,13,6,11,3,3,10,12,12,12,12,2,7,3,7,13,0]

theorem envBound49986 : H12AffineFastState.Bounded env49986 := by
  intro p hp
  have h : env49986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49985_49986 : H12AffineEnvironment.transform 4 7 env49985 = env49986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49985 == env49986) = true)

def env49987 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143496,20496,492567,148668,148668,96267,74795,90258,172,204947,1213,135681]

theorem envBound49987 : H12AffineFastState.Bounded env49987 := by
  intro p hp
  have h : env49987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49972_49987 : H12AffineEnvironment.transform 5 17 env49972 = env49987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49972 == env49987) = true)

theorem identity49987 : scanCanonicalize (H12AffineFastState.compose env49987 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound49987 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env49988 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61569,98354,41003,127147,20496,279604,99487,99487,96267,74795,90258,172,57520,1213,119330]

theorem envBound49988 : H12AffineFastState.Bounded env49988 := by
  intro p hp
  have h : env49988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49987_49988 : H12AffineEnvironment.transform 16 114723 env49987 = env49988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env49987 == env49988) = true)

theorem identity49988 : scanCanonicalize (H12AffineFastState.compose env49988 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 104467) := by decide +kernel

theorem selectedBound49988 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49989 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,104467,119842,32769,4097,61569,98354,41003,127147,20496,121895,99487,99487,96267,74795,90258,172,57520,1213,119330]

theorem envBound49989 : H12AffineFastState.Bounded env49989 := by
  intro p hp
  have h : env49989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49988_49989 : H12AffineEnvironment.transform 17 104467 env49988 = env49989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 104467 env49988 == env49989) = true)

theorem identity49989 : scanCanonicalize (H12AffineFastState.compose env49989 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound49989 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env49990 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,18481,1024,32769,4097,61569,20496,41003,8329,20496,3077,21693,21693,43049,62473,45232,172,57520,1213,512]

theorem envBound49990 : H12AffineFastState.Bounded env49990 := by
  intro p hp
  have h : env49990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49989_49990 : H12AffineEnvironment.transform 15 53282 env49989 = env49990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env49989 == env49990) = true)

theorem identity49990 : scanCanonicalize (H12AffineFastState.compose env49990 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound49990 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49991 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9381,29831,4097,18481,1024,9380,4097,21540,20496,1166,8329,20496,3077,21693,21693,3212,20652,5141,172,17429,1213,512]

theorem envBound49991 : H12AffineFastState.Bounded env49991 := by
  intro p hp
  have h : env49991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49990_49991 : H12AffineEnvironment.transform 14 9381 env49990 = env49991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env49990 == env49991) = true)

theorem identity49991 : scanCanonicalize (H12AffineFastState.compose env49991 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 9772) := by decide +kernel

theorem selectedBound49991 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49992 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,9772,9381,4779,4097,11805,1024,9380,4097,12808,13884,1166,8329,13884,3077,12945,12945,3212,13952,5141,172,8761,1213,512]

theorem envBound49992 : H12AffineFastState.Bounded env49992 := by
  intro p hp
  have h : env49992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49991_49992 : H12AffineEnvironment.transform 13 9772 env49991 = env49992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9772 env49991 == env49992) = true)

theorem identity49992 : scanCanonicalize (H12AffineFastState.compose env49992 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound49992 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env49993 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,4096,8192,8243,8890,4779,4097,10242,543,8891,4097,12808,12323,657,8329,12323,2586,12945,12945,2707,12447,4618,172,8761,674,512]

theorem envBound49993 : H12AffineFastState.Bounded env49993 := by
  intro p hp
  have h : env49993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49992_49993 : H12AffineEnvironment.transform 9 543 env49992 = env49993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env49992 == env49993) = true)

theorem identity49993 : scanCanonicalize (H12AffineFastState.compose env49993 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound49993 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49994 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,2049,8192,8243,8890,2730,2048,10242,543,8891,2048,10761,10274,657,8329,10274,2586,10896,10896,2707,10398,2571,172,8761,674,512]

theorem envBound49994 : H12AffineFastState.Bounded env49994 := by
  intro p hp
  have h : env49994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49993_49994 : H12AffineEnvironment.transform 11 2049 env49993 = env49994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env49993 == env49994) = true)

theorem identity49994 : scanCanonicalize (H12AffineFastState.compose env49994 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound49994 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49995 : List Nat := [2,4,8,16,32,17,128,173,512,543,2048,2049,2601,2586,2195,2730,2048,555,543,2194,2048,32,523,657,2720,523,2586,185,185,2707,695,2571,172,2064,674,512]

theorem envBound49995 : H12AffineFastState.Bounded env49995 := by
  intro p hp
  have h : env49995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49994_49995 : H12AffineEnvironment.transform 12 2601 env49994 = env49995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env49994 == env49995) = true)

theorem identity49995 : scanCanonicalize (H12AffineFastState.compose env49995 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound49995 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49996 : List Nat := [2,4,8,16,32,17,128,173,27,4,2048,2049,2098,2049,2195,2225,2048,48,4,2194,2048,32,16,138,2235,16,2049,185,185,2184,172,2064,172,2064,185,27]

theorem envBound49996 : H12AffineFastState.Bounded env49996 := by
  intro p hp
  have h : env49996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49995_49996 : H12AffineEnvironment.transform 8 27 env49995 = env49996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env49995 == env49996) = true)

def env49997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245633,148800,545089,96346,16876544,750911,257,17006917,1344,525824]

theorem envBound49997 : H12AffineFastState.Bounded env49997 := by
  intro p hp
  have h : env49997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49882_49997 : H12AffineEnvironment.transform 26 17245633 env49882 = env49997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env49882 == env49997) = true)

theorem identity49997 : scanCanonicalize (H12AffineFastState.compose env49997 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound49997 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717115,533641,672785,906490,148800,545089,96346,750907,750911,257,618622,1344,525824]

theorem envBound49998 : H12AffineFastState.Bounded env49998 := by
  intro p hp
  have h : env49998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49997_49998 : H12AffineEnvironment.transform 23 717115 env49997 = env49998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env49997 == env49998) = true)

def env49999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58683,143497,20497,508154,148800,148801,96346,90427,90431,257,222334,1344,135680]

theorem envBound49999 : H12AffineFastState.Bounded env49999 := by
  intro p hp
  have h : env49999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49998_49999 : H12AffineEnvironment.transform 18 136192 env49998 = env49999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env49998 == env49999) = true)

def env50000 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143497,20497,508154,148716,148717,96346,90263,90259,173,222334,1260,135680]

theorem envBound50000 : H12AffineFastState.Bounded env50000 := by
  intro p hp
  have h : env50000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49999_50000 : H12AffineEnvironment.transform 7 172 env49999 = env50000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49999 == env50000) = true)

def env50001 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143497,20497,508074,148668,148669,96266,90263,90259,173,222254,1212,135680]

theorem envBound50001 : H12AffineFastState.Bounded env50001 := by
  intro p hp
  have h : env50001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50000_50001 : H12AffineEnvironment.transform 5 16 env50000 = env50001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50000 == env50001) = true)

theorem identity50001 : scanCanonicalize (H12AffineFastState.compose env50001 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound50001 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50002 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,58519,32809,20497,356362,62492,62493,96266,90263,90259,173,119950,1212,41632]

theorem envBound50002 : H12AffineFastState.Bounded env50002 := by
  intro p hp
  have h : env50002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50001_50002 : H12AffineEnvironment.transform 16 45216 env50001 = env50002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env50001 == env50002) = true)

theorem identity50002 : scanCanonicalize (H12AffineFastState.compose env50002 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound50002 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50003 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4097,61568,61616,58519,32809,20497,96387,62492,62493,96266,90263,90259,173,119950,1212,41632]

theorem envBound50003 : H12AffineFastState.Bounded env50003 := by
  intro p hp
  have h : env50003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50002_50003 : H12AffineEnvironment.transform 17 2185 env50002 = env50003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env50002 == env50003) = true)

theorem identity50003 : scanCanonicalize (H12AffineFastState.compose env50003 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound50003 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env50004 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,54310,45216,2185,42144,32769,4097,61568,61616,58519,32809,20497,44197,62492,62493,44076,46257,46261,173,168,1212,41632]

theorem envBound50004 : H12AffineFastState.Bounded env50004 := by
  intro p hp
  have h : env50004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50003_50004 : H12AffineEnvironment.transform 15 54310 env50003 = env50004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env50003 == env50004) = true)

theorem identity50004 : scanCanonicalize (H12AffineFastState.compose env50004 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound50004 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env50005 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,13374,20664,2185,17592,24601,4097,4248,4264,1167,24625,20497,19645,5124,5125,19508,21673,21677,173,168,1212,17080]

theorem envBound50005 : H12AffineFastState.Bounded env50005 := by
  intro p hp
  have h : env50005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50004_50005 : H12AffineEnvironment.transform 14 24600 env50004 = env50005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env50004 == env50005) = true)

theorem identity50005 : scanCanonicalize (H12AffineFastState.compose env50005 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound50005 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env50006 : List Nat := [2,4,8,16,32,16,128,172,512,700,2048,4096,8192,16384,24600,12930,20664,2185,16900,24601,4097,4248,4264,563,24625,20497,18945,4792,4793,19080,21013,21009,173,168,512,17080]

theorem envBound50006 : H12AffineFastState.Bounded env50006 := by
  intro p hp
  have h : env50006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50005_50006 : H12AffineEnvironment.transform 9 700 env50005 = env50006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env50005 == env50006) = true)

theorem identity50006 : scanCanonicalize (H12AffineFastState.compose env50006 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound50006 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env50007 : List Nat := [2,4,8,16,32,16,128,172,512,700,2048,2194,8192,16384,24600,10768,18474,2185,16900,24601,2195,2058,2106,563,24625,18563,18945,2602,2603,19080,19079,19075,173,168,512,17080]

theorem envBound50007 : H12AffineFastState.Bounded env50007 := by
  intro p hp
  have h : env50007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50006_50007 : H12AffineEnvironment.transform 11 2194 env50006 = env50007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env50006 == env50007) = true)

theorem identity50007 : scanCanonicalize (H12AffineFastState.compose env50007 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(13+1) ^^^ 10912) := by decide +kernel

theorem selectedBound50007 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env50008 : List Nat := [2,4,8,16,32,16,128,172,512,700,2048,2194,8192,10912,2744,10768,8842,2185,10404,2745,2195,2058,2106,563,2705,8739,8353,2602,2603,8232,8231,8227,173,168,512,10264]

theorem envBound50008 : H12AffineFastState.Bounded env50008 := by
  intro p hp
  have h : env50008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50007_50008 : H12AffineEnvironment.transform 13 10912 env50007 = env50008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10912 env50007 == env50008) = true)

theorem identity50008 : scanCanonicalize (H12AffineFastState.compose env50008 (packedSelected [1,2,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound50008 : packedSelected [1,2,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50009 : List Nat := [2,4,8,16,32,16,128,172,512,700,539,649,8192,8379,163,8203,8842,658,8895,162,648,529,545,563,138,8739,8353,49,48,8232,8231,8227,173,168,512,8707]

theorem envBound50009 : H12AffineFastState.Bounded env50009 := by
  intro p hp
  have h : env50009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50008_50009 : H12AffineEnvironment.transform 10 539 env50008 = env50009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env50008 == env50009) = true)

theorem identity50009 : scanCanonicalize (H12AffineFastState.compose env50009 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound50009 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50010 : List Nat := [2,4,8,16,32,16,128,172,512,700,539,649,657,554,163,666,27,658,46,162,648,529,545,563,138,178,560,49,48,697,694,690,173,168,512,146]

theorem envBound50010 : H12AffineFastState.Bounded env50010 := by
  intro p hp
  have h : env50010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50009_50010 : H12AffineEnvironment.transform 12 657 env50009 = env50010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env50009 == env50010) = true)

theorem identity50010 : scanCanonicalize (H12AffineFastState.compose env50010 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound50010 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env50011 : List Nat := [2,4,8,16,32,16,57,21,512,517,539,560,552,554,26,547,27,555,46,27,561,529,545,563,51,11,560,49,48,512,527,523,20,17,512,43]

theorem envBound50011 : H12AffineFastState.Bounded env50011 := by
  intro p hp
  have h : env50011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50010_50011 : H12AffineEnvironment.transform 6 57 env50010 = env50011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env50010 == env50011) = true)

theorem identity50011 : scanCanonicalize (H12AffineFastState.compose env50011 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound50011 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50012 : List Nat := [2,4,8,16,32,16,57,21,27,30,0,43,51,49,26,56,27,48,46,27,42,10,58,40,51,11,43,49,48,27,20,16,20,17,27,43]

theorem envBound50012 : H12AffineFastState.Bounded env50012 := by
  intro p hp
  have h : env50012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50011_50012 : H12AffineEnvironment.transform 8 27 env50011 = env50012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env50011 == env50012) = true)

theorem identity50012 : scanCanonicalize (H12AffineFastState.compose env50012 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50013 : List Nat := [2,4,8,10,32,10,35,15,1,4,0,43,41,43,0,34,1,42,46,1,42,10,32,40,41,11,43,43,42,1,14,10,14,11,1,43]

theorem envBound50013 : H12AffineFastState.Bounded env50013 := by
  intro p hp
  have h : env50013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50012_50013 : H12AffineEnvironment.transform 3 10 env50012 = env50013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50012 == env50013) = true)

theorem identity50013 : scanCanonicalize (H12AffineFastState.compose env50013 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50013 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50014 : List Nat := [2,2,8,10,32,10,35,9,1,2,0,43,41,43,0,34,1,42,40,1,42,10,32,40,41,11,43,43,42,1,8,10,8,11,1,43]

theorem envBound50014 : H12AffineFastState.Bounded env50014 := by
  intro p hp
  have h : env50014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50013_50014 : H12AffineEnvironment.transform 1 2 env50013 = env50014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50013 == env50014) = true)

def env50015 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143497,20497,508075,148669,148668,96267,90263,90259,173,222255,1213,135680]

theorem envBound50015 : H12AffineFastState.Bounded env50015 := by
  intro p hp
  have h : env50015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50000_50015 : H12AffineEnvironment.transform 5 17 env50000 = env50015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50000 == env50015) = true)

theorem identity50015 : scanCanonicalize (H12AffineFastState.compose env50015 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound50015 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50016 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,58519,143497,20497,120867,148669,148668,96267,90263,90259,173,222255,1213,135680]

theorem envBound50016 : H12AffineFastState.Bounded env50016 := by
  intro p hp
  have h : env50016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50015_50016 : H12AffineEnvironment.transform 17 137352 env50015 = env50016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env50015 == env50016) = true)

theorem identity50016 : scanCanonicalize (H12AffineFastState.compose env50016 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound50016 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env50017 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4097,61569,46093,58519,50325,20497,120867,45217,45216,96267,90263,90259,173,102451,1213,58908]

theorem envBound50017 : H12AffineFastState.Bounded env50017 := by
  intro p hp
  have h : env50017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50016_50017 : H12AffineEnvironment.transform 16 62492 env50016 = env50017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env50016 == env50017) = true)

theorem identity50017 : scanCanonicalize (H12AffineFastState.compose env50017 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50017 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50018 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,65536,61464,59536,57372,32769,4097,61569,45065,57491,49297,20497,120867,45217,45216,96267,90263,90259,173,102451,185,57880]

theorem envBound50018 : H12AffineFastState.Bounded env50018 := by
  intro p hp
  have h : env50018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50017_50018 : H12AffineEnvironment.transform 9 4 env50017 = env50018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50017 == env50018) = true)

theorem identity50018 : scanCanonicalize (H12AffineFastState.compose env50018 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound50018 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env50019 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,2730,61464,59536,57372,32769,4097,61569,45065,57491,49297,20497,53897,45217,45216,29345,27197,27193,173,39577,185,57880]

theorem envBound50019 : H12AffineFastState.Bounded env50019 := by
  intro p hp
  have h : env50019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50018_50019 : H12AffineEnvironment.transform 15 2730 env50018 = env50019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env50018 == env50019) = true)

theorem identity50019 : scanCanonicalize (H12AffineFastState.compose env50019 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 23176) := by decide +kernel

theorem selectedBound50019 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env50020 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,23176,2730,10896,12824,14996,23177,4097,10761,27265,14875,6681,20497,2049,27177,27176,29345,27197,27193,173,16401,185,14480]

theorem envBound50020 : H12AffineFastState.Bounded env50020 := by
  intro p hp
  have h : env50020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50019_50020 : H12AffineEnvironment.transform 14 23176 env50019 = env50020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23176 env50019 == env50020) = true)

theorem identity50020 : scanCanonicalize (H12AffineFastState.compose env50020 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound50020 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env50021 : List Nat := [2,4,8,16,32,17,128,172,137,4,2048,4096,8192,16384,22529,2083,10265,12433,14365,22528,4097,10368,26632,14482,6288,20497,2049,26784,26785,28712,26804,26800,173,16401,185,14480]

theorem envBound50021 : H12AffineFastState.Bounded env50021 := by
  intro p hp
  have h : env50021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50020_50021 : H12AffineEnvironment.transform 8 137 env50020 = env50021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env50020 == env50021) = true)

theorem identity50021 : scanCanonicalize (H12AffineFastState.compose env50021 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound50021 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env50022 : List Nat := [2,4,8,16,32,17,128,172,137,4,2048,4096,138,16384,22529,2083,2195,4123,6295,22528,4097,2058,18562,6168,6288,20497,2049,18474,18475,20642,18494,18490,173,16401,185,6170]

theorem envBound50022 : H12AffineFastState.Bounded env50022 := by
  intro p hp
  have h : env50022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50021_50022 : H12AffineEnvironment.transform 12 138 env50021 = env50022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env50021 == env50022) = true)

theorem identity50022 : scanCanonicalize (H12AffineFastState.compose env50022 (packedSelected [2,3,6,7,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound50022 : packedSelected [2,3,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env50023 : List Nat := [2,4,8,16,32,17,128,172,137,4,2048,4096,138,2185,4232,2083,2195,4123,6295,4233,4097,2058,11,6168,6288,6296,2049,163,162,6187,183,179,173,2200,185,6170]

theorem envBound50023 : H12AffineFastState.Bounded env50023 := by
  intro p hp
  have h : env50023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50022_50023 : H12AffineEnvironment.transform 13 2185 env50022 = env50023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env50022 == env50023) = true)

theorem identity50023 : scanCanonicalize (H12AffineFastState.compose env50023 (packedSelected [3,4,6,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound50023 : packedSelected [3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env50024 : List Nat := [2,4,8,16,32,17,18,62,27,4,2048,4096,24,2075,4122,2083,2049,4123,6149,4123,4097,2058,11,6168,6146,6154,2049,49,48,6187,37,33,63,2058,43,6170]

theorem envBound50024 : H12AffineFastState.Bounded env50024 := by
  intro p hp
  have h : env50024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50023_50024 : H12AffineEnvironment.transform 6 18 env50023 = env50024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env50023 == env50024) = true)

theorem identity50024 : scanCanonicalize (H12AffineFastState.compose env50024 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound50024 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env50025 : List Nat := [2,4,8,16,32,17,18,62,27,4,2048,48,24,2075,42,2083,2049,43,2101,43,49,2058,11,2088,2098,2106,2049,49,48,2075,37,33,63,2058,43,2090]

theorem envBound50025 : H12AffineFastState.Bounded env50025 := by
  intro p hp
  have h : env50025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50024_50025 : H12AffineEnvironment.transform 11 48 env50024 = env50025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50024 == env50025) = true)

theorem identity50025 : scanCanonicalize (H12AffineFastState.compose env50025 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound50025 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50026 : List Nat := [2,4,8,16,32,17,18,62,27,4,27,48,24,0,42,56,26,43,46,43,49,17,11,51,41,33,26,49,48,0,37,33,63,17,43,49]

theorem envBound50026 : H12AffineFastState.Bounded env50026 := by
  intro p hp
  have h : env50026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50025_50026 : H12AffineEnvironment.transform 10 27 env50025 = env50026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env50025 == env50026) = true)

theorem identity50026 : scanCanonicalize (H12AffineFastState.compose env50026 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound50026 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env50027 : List Nat := [2,4,8,16,28,17,18,2,27,4,27,12,24,0,22,4,26,23,18,23,13,17,11,15,21,29,26,13,12,0,25,29,3,17,23,13]

theorem envBound50027 : H12AffineFastState.Bounded env50027 := by
  intro p hp
  have h : env50027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50026_50027 : H12AffineEnvironment.transform 4 28 env50026 = env50027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env50026 == env50027) = true)

theorem identity50027 : scanCanonicalize (H12AffineFastState.compose env50027 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50027 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50028 : List Nat := [2,4,8,11,7,10,9,2,0,4,0,12,3,0,13,4,1,12,9,12,13,10,11,15,14,6,1,13,12,0,2,6,3,10,12,13]

theorem envBound50028 : H12AffineFastState.Bounded env50028 := by
  intro p hp
  have h : env50028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50027_50028 : H12AffineEnvironment.transform 3 11 env50027 = env50028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50027 == env50028) = true)

theorem identity50028 : scanCanonicalize (H12AffineFastState.compose env50028 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50028 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50029 : List Nat := [2,4,4,7,7,6,5,2,0,4,0,0,3,0,1,4,1,0,5,0,1,6,7,3,2,6,1,1,0,0,2,6,3,6,0,1]

theorem envBound50029 : H12AffineFastState.Bounded env50029 := by
  intro p hp
  have h : env50029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50028_50029 : H12AffineEnvironment.transform 2 4 env50028 = env50029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50028 == env50029) = true)

theorem identity50029 : scanCanonicalize (H12AffineFastState.compose env50029 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50030 : List Nat := [1,4,4,4,4,5,5,1,0,4,0,0,0,0,1,4,1,0,5,0,1,5,4,0,1,5,1,1,0,0,1,5,0,5,0,1]

theorem envBound50030 : H12AffineFastState.Bounded env50030 := by
  intro p hp
  have h : env50030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50029_50030 : H12AffineEnvironment.transform 0 1 env50029 = env50030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50029 == env50030) = true)

theorem identity50030 : scanCanonicalize (H12AffineFastState.compose env50030 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50031 : List Nat := [1,1,1,1,1,0,0,1,0,1,0,0,0,0,1,1,1,0,0,0,1,0,1,0,1,0,1,1,0,0,1,0,0,0,0,1]

theorem envBound50031 : H12AffineFastState.Bounded env50031 := by
  intro p hp
  have h : env50031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50030_50031 : H12AffineEnvironment.transform 1 1 env50030 = env50031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50030 == env50031) = true)

def env50032 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143497,20497,508154,148717,148716,96346,90262,90258,172,222334,1261,135680]

theorem envBound50032 : H12AffineFastState.Bounded env50032 := by
  intro p hp
  have h : env50032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49999_50032 : H12AffineEnvironment.transform 7 173 env49999 = env50032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49999 == env50032) = true)

def env50033 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143497,20497,508074,148669,148668,96266,90262,90258,172,222254,1213,135680]

theorem envBound50033 : H12AffineFastState.Bounded env50033 := by
  intro p hp
  have h : env50033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50032_50033 : H12AffineEnvironment.transform 5 16 env50032 = env50033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50032 == env50033) = true)

theorem identity50033 : scanCanonicalize (H12AffineFastState.compose env50033 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound50033 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50034 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61568,115854,58518,111639,20497,279604,114723,114722,96266,90262,90258,172,57520,1213,104094]

theorem envBound50034 : H12AffineFastState.Bounded env50034 := by
  intro p hp
  have h : env50034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50033_50034 : H12AffineEnvironment.transform 16 99486 env50033 = env50034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env50033 == env50034) = true)

theorem identity50034 : scanCanonicalize (H12AffineFastState.compose env50034 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound50034 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env50035 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,12346,46244,262144,41124,32769,4097,61568,62644,58518,33837,20497,279604,61465,61464,18480,20652,20648,172,57520,1213,42660]

theorem envBound50035 : H12AffineFastState.Bounded env50035 := by
  intro p hp
  have h : env50035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50034_50035 : H12AffineEnvironment.transform 15 12346 env50034 = env50035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env50034 == env50035) = true)

theorem identity50035 : scanCanonicalize (H12AffineFastState.compose env50035 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound50035 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50036 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9380,12346,4096,262144,1024,9381,4097,21540,20496,16434,8329,20497,279604,21693,21692,18480,20652,20648,172,17428,1213,512]

theorem envBound50036 : H12AffineFastState.Bounded env50036 := by
  intro p hp
  have h : env50036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50035_50036 : H12AffineEnvironment.transform 14 9380 env50035 = env50036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env50035 == env50036) = true)

theorem identity50036 : scanCanonicalize (H12AffineFastState.compose env50036 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound50036 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50037 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,12346,4096,262144,1024,9381,4097,4248,5292,1166,8329,5293,262280,4097,4096,3212,5136,5140,172,168,1213,512]

theorem envBound50037 : H12AffineFastState.Bounded env50037 := by
  intro p hp
  have h : env50037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50036_50037 : H12AffineEnvironment.transform 13 1212 env50036 = env50037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env50036 == env50037) = true)

theorem identity50037 : scanCanonicalize (H12AffineFastState.compose env50037 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound50037 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50038 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4648,1212,5772,530,4096,262144,1024,5773,4097,4248,5292,1166,4769,5293,262280,4097,4096,3212,5136,5140,172,168,1213,512]

theorem envBound50038 : H12AffineFastState.Bounded env50038 := by
  intro p hp
  have h : env50038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50037_50038 : H12AffineEnvironment.transform 12 4648 env50037 = env50038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env50037 == env50038) = true)

theorem identity50038 : scanCanonicalize (H12AffineFastState.compose env50038 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7220) := by decide +kernel

theorem selectedBound50038 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50039 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4648,1212,5772,530,4096,7220,1024,5773,4097,4248,5292,1166,4769,5293,7356,4097,4096,3212,5136,5140,172,168,1213,512]

theorem envBound50039 : H12AffineFastState.Bounded env50039 := by
  intro p hp
  have h : env50039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50038_50039 : H12AffineEnvironment.transform 17 7220 env50038 = env50039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7220 env50038 == env50039) = true)

theorem identity50039 : scanCanonicalize (H12AffineFastState.compose env50039 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound50039 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50040 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2586,2098,1212,3222,530,2586,1582,1024,3223,2587,2690,3766,1166,2235,3767,1702,2587,2586,3212,3594,3598,172,168,1213,512]

theorem envBound50040 : H12AffineFastState.Bounded env50040 := by
  intro p hp
  have h : env50040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50039_50040 : H12AffineEnvironment.transform 11 2586 env50039 = env50040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env50039 == env50040) = true)

theorem identity50040 : scanCanonicalize (H12AffineFastState.compose env50040 (packedSelected [1,3,17] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound50040 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env50041 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,185,657,1212,1589,530,185,1582,1024,1588,184,33,1045,1166,536,1044,1702,184,185,1583,1193,1197,172,168,1213,512]

theorem envBound50041 : H12AffineFastState.Bounded env50041 := by
  intro p hp
  have h : env50041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50040_50041 : H12AffineEnvironment.transform 10 675 env50040 = env50041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env50040 == env50041) = true)

theorem identity50041 : scanCanonicalize (H12AffineFastState.compose env50041 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50041 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50042 : List Nat := [2,4,8,10,32,10,128,173,512,1024,675,163,651,1190,1583,520,163,1582,1024,1582,162,33,1039,1166,514,1038,1702,162,163,1583,1193,1197,172,168,1191,512]

theorem envBound50042 : H12AffineFastState.Bounded env50042 := by
  intro p hp
  have h : env50042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50041_50042 : H12AffineEnvironment.transform 3 10 env50041 = env50042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50041 == env50042) = true)

theorem identity50042 : scanCanonicalize (H12AffineFastState.compose env50042 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound50042 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50043 : List Nat := [2,4,8,10,32,10,128,173,512,517,675,163,651,675,42,520,163,43,517,43,162,33,522,651,514,523,163,162,163,42,684,680,172,168,674,512]

end H12CloudChart2