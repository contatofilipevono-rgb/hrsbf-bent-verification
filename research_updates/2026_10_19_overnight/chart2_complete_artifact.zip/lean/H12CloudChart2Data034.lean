import H12CloudChart2Data033

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity8297 : scanCanonicalize (H12AffineFastState.compose env8297 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 12669) := by decide +kernel

theorem selectedBound8297 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8298 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,8192,12669,8232,8322,1344,1,9224,8232,4097,8201,13437,431,8621,5376,32,12669,1296,261,1285,4294967296,257,4294975757,1344,396]

theorem envBound8298 : H12AffineFastState.Bounded env8298 := by
  intro p hp
  have h : env8298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8297_8298 : H12AffineEnvironment.transform 13 12669 env8297 = env8298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12669 env8297 == env8298) = true)

theorem identity8298 : scanCanonicalize (H12AffineFastState.compose env8298 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound8298 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8299 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,301,4176,261,431,1344,1,1317,261,4097,292,5456,431,128,5376,32,4176,1296,261,1285,4294967296,257,4294967328,1344,396]

theorem envBound8299 : H12AffineFastState.Bounded env8299 := by
  intro p hp
  have h : env8299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8298_8299 : H12AffineEnvironment.transform 12 301 env8298 = env8299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env8298 == env8299) = true)

theorem identity8299 : scanCanonicalize (H12AffineFastState.compose env8299 (packedSelected [2,4,7] rootPS)) = affineNative (2^(31+1) ^^^ 5450) := by decide +kernel

theorem selectedBound8299 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8300 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,301,4176,261,431,1344,1,1317,261,4097,292,5456,431,128,5376,32,4176,1296,261,1285,5450,257,5482,1344,396]

theorem envBound8300 : H12AffineFastState.Bounded env8300 := by
  intro p hp
  have h : env8300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8299_8300 : H12AffineEnvironment.transform 31 5450 env8299 = env8300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5450 env8299 == env8300) = true)

theorem identity8300 : scanCanonicalize (H12AffineFastState.compose env8300 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8300 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env8301 : List Nat := [2,4,8,16,0,64,128,256,137,1024,1,4096,269,4176,261,399,1344,1,1285,261,4097,260,5456,399,128,5376,0,4176,1296,261,1285,5450,257,5450,1344,396]

theorem envBound8301 : H12AffineFastState.Bounded env8301 := by
  intro p hp
  have h : env8301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8300_8301 : H12AffineEnvironment.transform 4 0 env8300 = env8301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8300 == env8301) = true)

theorem identity8301 : scanCanonicalize (H12AffineFastState.compose env8301 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8301 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8302 : List Nat := [2,4,8,16,0,64,128,4,137,1024,1,4096,9,4176,1,139,1092,1,1025,1,4097,0,5204,139,128,5124,0,4176,1044,1,1025,5198,5,5198,1092,136]

theorem envBound8302 : H12AffineFastState.Bounded env8302 := by
  intro p hp
  have h : env8302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8301_8302 : H12AffineEnvironment.transform 7 4 env8301 = env8302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8301 == env8302) = true)

theorem identity8302 : scanCanonicalize (H12AffineFastState.compose env8302 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8303 : List Nat := [2,4,8,16,0,64,128,4,137,1024,1,1108,9,1028,1,139,1092,1,1025,1,1109,0,0,139,128,80,0,1028,1044,1,1025,26,5,26,1092,136]

theorem envBound8303 : H12AffineFastState.Bounded env8303 := by
  intro p hp
  have h : env8303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8302_8303 : H12AffineEnvironment.transform 11 1108 env8302 = env8303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8302 == env8303) = true)

theorem identity8303 : scanCanonicalize (H12AffineFastState.compose env8303 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8303 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8304 : List Nat := [2,4,8,16,0,0,128,4,137,1024,1,1044,9,1028,1,139,1028,1,1025,1,1045,0,0,139,128,16,0,1028,1044,1,1025,26,5,26,1028,136]

theorem envBound8304 : H12AffineFastState.Bounded env8304 := by
  intro p hp
  have h : env8304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8303_8304 : H12AffineEnvironment.transform 5 0 env8303 = env8304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8303 == env8304) = true)

theorem identity8304 : scanCanonicalize (H12AffineFastState.compose env8304 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8305 : List Nat := [2,4,2,16,0,0,128,4,131,1024,1,1044,3,1028,1,129,1028,1,1025,1,1045,0,0,129,128,16,0,1028,1044,1,1025,16,5,16,1028,130]

theorem envBound8305 : H12AffineFastState.Bounded env8305 := by
  intro p hp
  have h : env8305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8304_8305 : H12AffineEnvironment.transform 2 2 env8304 = env8305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8304 == env8305) = true)

def env8306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17664,74629,33554432,5376,2122077,16384,1297,35664384,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8306 : H12AffineFastState.Bounded env8306 := by
  intro p hp
  have h : env8306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8291_8306 : H12AffineEnvironment.transform 16 1345 env8291 = env8306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8291 == env8306) = true)

theorem identity8306 : scanCanonicalize (H12AffineFastState.compose env8306 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8306 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,4097,8201,17664,74629,33554432,5376,29020,16384,1297,33563137,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8307 : H12AffineFastState.Bounded env8307 := by
  intro p hp
  have h : env8307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8306_8307 : H12AffineEnvironment.transform 20 4097 env8306 = env8307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8306 == env8307) = true)

theorem identity8307 : scanCanonicalize (H12AffineFastState.compose env8307 (packedSelected [20] rootPS)) = affineNative (2^(11+1) ^^^ 1976) := by decide +kernel

theorem selectedBound8307 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,8192,16384,8833,65536,1345,1,524288,8833,1977,8201,17664,74629,33554432,696,26340,16384,1297,33563137,1284,4294967296,257,4329136199,1345,33563272]

theorem envBound8308 : H12AffineFastState.Bounded env8308 := by
  intro p hp
  have h : env8308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8307_8308 : H12AffineEnvironment.transform 11 1976 env8307 = env8308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1976 env8307 == env8308) = true)

theorem identity8308 : scanCanonicalize (H12AffineFastState.compose env8308 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 26056) := by decide +kernel

theorem selectedBound8308 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,8192,16384,8833,65536,1345,1,524288,8833,1977,8201,17664,74629,26056,696,26340,16384,1297,18377,1284,4294967296,257,4295558543,1345,18240]

theorem envBound8309 : H12AffineFastState.Bounded env8309 := by
  intro p hp
  have h : env8309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8308_8309 : H12AffineEnvironment.transform 24 26056 env8308 = env8309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26056 env8308 == env8309) = true)

theorem identity8309 : scanCanonicalize (H12AffineFastState.compose env8309 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound8309 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,8192,9293,8833,65536,1345,1,524288,8833,1977,8201,8525,74629,389,696,681,9293,1297,9092,1284,4294967296,257,4295558543,1345,8973]

theorem envBound8310 : H12AffineFastState.Bounded env8310 := by
  intro p hp
  have h : env8310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8309_8310 : H12AffineEnvironment.transform 13 9293 env8309 = env8310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env8309 == env8310) = true)

theorem identity8310 : scanCanonicalize (H12AffineFastState.compose env8310 (packedSelected [1,3,9,12,13,15,17,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound8310 : packedSelected [1,3,9,12,13,15,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env8311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,300,1377,941,65536,1345,1,524288,941,1977,293,97,66217,389,696,681,1377,1297,680,1284,4294967296,257,4295558543,1345,545]

theorem envBound8311 : H12AffineFastState.Bounded env8311 := by
  intro p hp
  have h : env8311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8310_8311 : H12AffineEnvironment.transform 12 300 env8310 = env8311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env8310 == env8311) = true)

theorem identity8311 : scanCanonicalize (H12AffineFastState.compose env8311 (packedSelected [1,3,8,10,12,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound8311 : packedSelected [1,3,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env8312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,300,1377,941,139,1345,1,524288,941,1977,293,97,546,389,696,681,1377,1297,680,1284,4294967296,257,4295492868,1345,545]

theorem envBound8312 : H12AffineFastState.Bounded env8312 := by
  intro p hp
  have h : env8312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8311_8312 : H12AffineEnvironment.transform 15 139 env8311 = env8312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env8311 == env8312) = true)

theorem identity8312 : scanCanonicalize (H12AffineFastState.compose env8312 (packedSelected [1,8,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound8312 : packedSelected [1,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8313 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,1296,300,1377,261,139,1345,1,524288,261,1297,293,97,138,389,16,1,1377,1297,0,1284,4294967296,257,4295492868,1345,137]

theorem envBound8313 : H12AffineFastState.Bounded env8313 := by
  intro p hp
  have h : env8313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8312_8313 : H12AffineEnvironment.transform 8 168 env8312 = env8313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env8312 == env8313) = true)

theorem identity8313 : scanCanonicalize (H12AffineFastState.compose env8313 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8313 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8314 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1296,268,1345,261,139,1345,1,524288,261,1297,261,65,138,389,16,1,1345,1297,0,1284,4294967296,257,4295492868,1345,137]

theorem envBound8314 : H12AffineFastState.Bounded env8314 := by
  intro p hp
  have h : env8314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8313_8314 : H12AffineEnvironment.transform 4 0 env8313 = env8314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8313 == env8314) = true)

theorem identity8314 : scanCanonicalize (H12AffineFastState.compose env8314 (packedSelected [2,4] rootPS)) = affineNative (2^(18+1) ^^^ 1285) := by decide +kernel

theorem selectedBound8314 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8315 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1296,268,1345,261,139,1345,1,1285,261,1297,261,65,138,389,16,1,1345,1297,0,1284,4294967296,257,4294967297,1345,137]

theorem envBound8315 : H12AffineFastState.Bounded env8315 := by
  intro p hp
  have h : env8315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8314_8315 : H12AffineEnvironment.transform 18 1285 env8314 = env8315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1285 env8314 == env8315) = true)

theorem identity8315 : scanCanonicalize (H12AffineFastState.compose env8315 (packedSelected [0,1,3] rootPS)) = affineNative (2^(31+1) ^^^ 471) := by decide +kernel

theorem selectedBound8315 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8316 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1296,268,1345,261,139,1345,1,1285,261,1297,261,65,138,389,16,1,1345,1297,0,1284,471,257,470,1345,137]

theorem envBound8316 : H12AffineFastState.Bounded env8316 := by
  intro p hp
  have h : env8316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8315_8316 : H12AffineEnvironment.transform 31 471 env8315 = env8316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 471 env8315 == env8316) = true)

theorem identity8316 : scanCanonicalize (H12AffineFastState.compose env8316 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8316 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env8317 : List Nat := [2,4,8,16,0,64,128,4,136,1024,1,1044,8,1093,1,139,1093,1,1025,1,1045,1,65,138,129,16,1,1093,1045,0,1024,211,5,210,1093,137]

theorem envBound8317 : H12AffineFastState.Bounded env8317 := by
  intro p hp
  have h : env8317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8316_8317 : H12AffineEnvironment.transform 7 4 env8316 = env8317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8316 == env8317) = true)

theorem identity8317 : scanCanonicalize (H12AffineFastState.compose env8317 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound8317 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8318 : List Nat := [2,4,8,16,0,64,89,4,81,1024,1,1044,8,1093,1,82,1093,1,1025,1,1045,1,65,83,88,16,1,1093,1045,0,1024,10,5,11,1093,80]

theorem envBound8318 : H12AffineFastState.Bounded env8318 := by
  intro p hp
  have h : env8318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8317_8318 : H12AffineEnvironment.transform 6 89 env8317 = env8318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env8317 == env8318) = true)

theorem identity8318 : scanCanonicalize (H12AffineFastState.compose env8318 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound8318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8319 : List Nat := [2,4,8,16,0,26,3,4,11,1024,1,1044,8,1055,1,8,1055,1,1025,1,1045,1,27,9,2,16,1,1055,1045,0,1024,10,5,11,1055,10]

theorem envBound8319 : H12AffineFastState.Bounded env8319 := by
  intro p hp
  have h : env8319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8318_8319 : H12AffineEnvironment.transform 5 26 env8318 = env8319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env8318 == env8319) = true)

theorem identity8319 : scanCanonicalize (H12AffineFastState.compose env8319 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8320 : List Nat := [2,4,8,1,0,11,3,4,11,1024,1,1029,8,1038,1,8,1038,1,1025,1,1028,1,10,9,2,1,1,1038,1028,0,1024,10,5,11,1038,10]

theorem envBound8320 : H12AffineFastState.Bounded env8320 := by
  intro p hp
  have h : env8320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8319_8320 : H12AffineEnvironment.transform 3 1 env8319 = env8320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8319 == env8320) = true)

def env8321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17664,230469,33554432,5376,2518045,16384,131152,1073741824,131141,4294967296,257,4329297983,131072,33563272]

theorem envBound8321 : H12AffineFastState.Bounded env8321 := by
  intro p hp
  have h : env8321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8059_8321 : H12AffineEnvironment.transform 21 10249 env8059 = env8321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env8059 == env8321) = true)

def env8322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,10249,17664,206533,33554432,5376,2518045,16384,131152,1073741824,131141,4294967296,257,4329274047,131072,33563272]

theorem envBound8322 : H12AffineFastState.Bounded env8322 := by
  intro p hp
  have h : env8322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8321_8322 : H12AffineEnvironment.transform 14 8832 env8321 = env8322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env8321 == env8322) = true)

def env8323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17664,206533,33554432,5376,2515997,16384,131152,1073741824,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8323 : H12AffineFastState.Bounded env8323 := by
  intro p hp
  have h : env8323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8322_8323 : H12AffineEnvironment.transform 10 0 env8322 = env8323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8322 == env8323) = true)

theorem identity8323 : scanCanonicalize (H12AffineFastState.compose env8323 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 35788005) := by decide +kernel

theorem selectedBound8323 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17664,206533,33554432,5376,2515997,16384,131152,35788005,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8324 : H12AffineFastState.Bounded env8324 := by
  intro p hp
  have h : env8324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8323_8324 : H12AffineEnvironment.transform 29 35788005 env8323 = env8324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35788005 env8323 == env8324) = true)

def env8325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8201,17664,206533,33554432,5376,2253853,16384,131152,35788005,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8325 : H12AffineFastState.Bounded env8325 := by
  intro p hp
  have h : env8325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8324_8325 : H12AffineEnvironment.transform 17 0 env8324 = env8325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8324 == env8325) = true)

def env8326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17664,74629,33554432,5376,2122077,16384,1296,35656101,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8326 : H12AffineFastState.Bounded env8326 := by
  intro p hp
  have h : env8326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8325_8326 : H12AffineEnvironment.transform 16 1344 env8325 = env8326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8325 == env8326) = true)

theorem identity8326 : scanCanonicalize (H12AffineFastState.compose env8326 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8326 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17664,74629,2647257,5376,2122077,16384,1296,554364,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8327 : H12AffineFastState.Bounded env8327 := by
  intro p hp
  have h : env8327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8326_8327 : H12AffineEnvironment.transform 24 2647257 env8326 = env8327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8326 == env8327) = true)

theorem identity8327 : scanCanonicalize (H12AffineFastState.compose env8327 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 603950) := by decide +kernel

theorem selectedBound8327 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,603950,8201,17664,74629,87031,5376,611955,16384,1296,554364,1285,4294967296,257,4295500808,1344,94591]

theorem envBound8328 : H12AffineFastState.Bounded env8328 := by
  intro p hp
  have h : env8328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8327_8328 : H12AffineEnvironment.transform 20 603950 env8327 = env8328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 603950 env8327 == env8328) = true)

theorem identity8328 : scanCanonicalize (H12AffineFastState.compose env8328 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 75567) := by decide +kernel

theorem selectedBound8328 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,75567,8832,4097,8201,17664,74629,87031,5376,29020,16384,1296,86611,1285,4294967296,257,4295033639,1344,94591]

theorem envBound8329 : H12AffineFastState.Bounded env8329 := by
  intro p hp
  have h : env8329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8328_8329 : H12AffineEnvironment.transform 18 75567 env8328 = env8329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75567 env8328 == env8329) = true)

theorem identity8329 : scanCanonicalize (H12AffineFastState.compose env8329 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound8329 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,8615,1344,0,1672,8832,4097,8201,17664,546,29264,5376,29020,16384,1296,29684,1285,4294967296,257,4294976128,1344,20696]

theorem envBound8330 : H12AffineFastState.Bounded env8330 := by
  intro p hp
  have h : env8330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8329_8330 : H12AffineEnvironment.transform 15 8615 env8329 = env8330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env8329 == env8330) = true)

theorem identity8330 : scanCanonicalize (H12AffineFastState.compose env8330 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound8330 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8331 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,4096,8192,16384,8832,8322,1125,0,1672,8832,4097,8201,17445,546,29264,5157,28793,16384,1077,29393,1056,4294967296,36,4294976128,1125,20696]

theorem envBound8331 : H12AffineFastState.Bounded env8331 := by
  intro p hp
  have h : env8331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8330_8331 : H12AffineEnvironment.transform 7 37 env8330 = env8331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env8330 == env8331) = true)

theorem identity8331 : scanCanonicalize (H12AffineFastState.compose env8331 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 4208) := by decide +kernel

theorem selectedBound8331 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8332 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,4096,8192,4208,8832,8322,1125,0,1672,8832,4097,8201,5205,546,8736,5157,8201,4208,1077,8865,1056,4294967296,36,4294976128,1125,168]

theorem envBound8332 : H12AffineFastState.Bounded env8332 := by
  intro p hp
  have h : env8332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8331_8332 : H12AffineEnvironment.transform 13 4208 env8331 = env8332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4208 env8331 == env8332) = true)

theorem identity8332 : scanCanonicalize (H12AffineFastState.compose env8332 (packedSelected [3,8,24] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8332 : packedSelected [3,8,24] rootPS < 2^1333 := by decide +kernel

def env8333 : List Nat := [2,4,3,16,32,64,128,37,512,1024,0,4096,8192,4208,8832,8322,1125,0,1667,8832,4097,8194,5205,546,8736,5157,8194,4208,1077,8865,1056,4294967296,36,4294976128,1125,163]

theorem envBound8333 : H12AffineFastState.Bounded env8333 := by
  intro p hp
  have h : env8333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8332_8333 : H12AffineEnvironment.transform 2 3 env8332 = env8333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8332 == env8333) = true)

theorem identity8333 : scanCanonicalize (H12AffineFastState.compose env8333 (packedSelected [2,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1686) := by decide +kernel

theorem selectedBound8333 : packedSelected [2,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8334 : List Nat := [2,4,3,16,32,64,128,37,512,1024,0,1686,8192,1766,8832,8322,1125,0,1667,8832,1687,8194,707,546,8736,691,8194,1766,1077,8865,1056,4294967296,36,4294976128,1125,163]

theorem envBound8334 : H12AffineFastState.Bounded env8334 := by
  intro p hp
  have h : env8334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8333_8334 : H12AffineEnvironment.transform 11 1686 env8333 = env8334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1686 env8333 == env8334) = true)

theorem identity8334 : scanCanonicalize (H12AffineFastState.compose env8334 (packedSelected [1,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound8334 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env8335 : List Nat := [2,4,3,16,32,64,128,37,131,1024,0,1045,8192,1125,8195,8322,1125,0,1024,8195,1044,8194,64,161,8355,48,8194,1125,1077,8226,1056,4294967296,36,4294975491,1125,163]

theorem envBound8335 : H12AffineFastState.Bounded env8335 := by
  intro p hp
  have h : env8335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8334_8335 : H12AffineEnvironment.transform 8 131 env8334 = env8335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env8334 == env8335) = true)

theorem identity8335 : scanCanonicalize (H12AffineFastState.compose env8335 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound8335 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env8336 : List Nat := [2,4,3,16,32,64,128,37,131,1024,0,1045,2,1125,1,128,1125,0,1024,1,1044,0,64,161,161,48,0,1125,1077,32,1056,4294967296,36,4294967297,1125,163]

theorem envBound8336 : H12AffineFastState.Bounded env8336 := by
  intro p hp
  have h : env8336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8335_8336 : H12AffineEnvironment.transform 12 2 env8335 = env8336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env8335 == env8336) = true)

theorem identity8336 : scanCanonicalize (H12AffineFastState.compose env8336 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8336 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8337 : List Nat := [2,4,3,16,1,64,128,4,131,1024,0,1045,2,1092,1,128,1092,0,1024,1,1044,0,64,128,128,17,0,1092,1044,1,1025,4294967296,5,4294967297,1092,130]

theorem envBound8337 : H12AffineFastState.Bounded env8337 := by
  intro p hp
  have h : env8337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8336_8337 : H12AffineEnvironment.transform 4 1 env8336 = env8337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8336 == env8337) = true)

theorem identity8337 : scanCanonicalize (H12AffineFastState.compose env8337 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 64) := by decide +kernel

theorem selectedBound8337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8338 : List Nat := [2,4,3,16,1,64,128,4,131,1024,0,1045,2,1092,1,128,1092,0,1024,1,1044,0,64,128,128,17,0,1092,1044,1,1025,64,5,65,1092,130]

theorem envBound8338 : H12AffineFastState.Bounded env8338 := by
  intro p hp
  have h : env8338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8337_8338 : H12AffineEnvironment.transform 31 64 env8337 = env8338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 64 env8337 == env8338) = true)

theorem identity8338 : scanCanonicalize (H12AffineFastState.compose env8338 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8339 : List Nat := [2,4,3,16,1,1,128,4,131,1024,0,1045,2,1029,1,128,1029,0,1024,1,1044,0,1,128,128,17,0,1029,1044,1,1025,1,5,0,1029,130]

theorem envBound8339 : H12AffineFastState.Bounded env8339 := by
  intro p hp
  have h : env8339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8338_8339 : H12AffineEnvironment.transform 5 1 env8338 = env8339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8338 == env8339) = true)

def env8340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17664,74628,33554432,5376,2122076,16384,1297,35656100,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8340 : H12AffineFastState.Bounded env8340 := by
  intro p hp
  have h : env8340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8325_8340 : H12AffineEnvironment.transform 16 1345 env8325 = env8340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8325 == env8340) = true)

theorem identity8340 : scanCanonicalize (H12AffineFastState.compose env8340 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8340 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8201,17664,74628,33554432,5376,29021,16384,1297,33554853,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8341 : H12AffineFastState.Bounded env8341 := by
  intro p hp
  have h : env8341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8340_8341 : H12AffineEnvironment.transform 20 4097 env8340 = env8341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8340 == env8341) = true)

theorem identity8341 : scanCanonicalize (H12AffineFastState.compose env8341 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 26433) := by decide +kernel

theorem selectedBound8341 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8201,17664,74628,26433,5376,29021,16384,1297,26340,1284,4294967296,257,4295561407,1345,17865]

theorem envBound8342 : H12AffineFastState.Bounded env8342 := by
  intro p hp
  have h : env8342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8341_8342 : H12AffineEnvironment.transform 24 26433 env8341 = env8342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26433 env8341 == env8342) = true)

theorem identity8342 : scanCanonicalize (H12AffineFastState.compose env8342 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound8342 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,8192,16384,8832,65536,1345,0,524288,8832,1329,8201,17664,74628,26433,48,25709,16384,1297,26340,1284,4294967296,257,4295558543,1345,17865]

theorem envBound8343 : H12AffineFastState.Bounded env8343 := by
  intro p hp
  have h : env8343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8342_8343 : H12AffineEnvironment.transform 11 1328 env8342 = env8343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env8342 == env8343) = true)

theorem identity8343 : scanCanonicalize (H12AffineFastState.compose env8343 (packedSelected [1,3,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound8343 : packedSelected [1,3,10,19] rootPS < 2^1333 := by decide +kernel

def env8344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,8192,1992,8832,65536,1345,0,524288,8832,1329,8201,712,74628,8329,48,9125,1992,1297,8492,1284,4294967296,257,4295558543,1345,513]

theorem envBound8344 : H12AffineFastState.Bounded env8344 := by
  intro p hp
  have h : env8344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8343_8344 : H12AffineEnvironment.transform 13 1992 env8343 = env8344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env8343 == env8344) = true)

theorem identity8344 : scanCanonicalize (H12AffineFastState.compose env8344 (packedSelected [0,4,7,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8344 : packedSelected [0,4,7,9,16] rootPS < 2^1333 := by decide +kernel

def env8345 : List Nat := [2,4,8,16,1,64,128,256,512,1024,0,1297,8192,1992,8832,65536,1345,0,524288,8832,1296,8201,712,74628,8329,17,9092,1992,1297,8461,1284,4294967296,257,4295558543,1345,513]

theorem envBound8345 : H12AffineFastState.Bounded env8345 := by
  intro p hp
  have h : env8345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8344_8345 : H12AffineEnvironment.transform 4 1 env8344 = env8345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8344 == env8345) = true)

theorem identity8345 : scanCanonicalize (H12AffineFastState.compose env8345 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound8345 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env8346 : List Nat := [2,4,8,16,1,64,128,256,512,1024,0,1297,8192,1992,8832,515,1345,0,524288,8832,1296,8201,712,8583,8329,17,9092,1992,1297,8461,1284,4294967296,257,4295493516,1345,513]

theorem envBound8346 : H12AffineFastState.Bounded env8346 := by
  intro p hp
  have h : env8346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8345_8346 : H12AffineEnvironment.transform 15 515 env8345 = env8346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env8345 == env8346) = true)

theorem identity8346 : scanCanonicalize (H12AffineFastState.compose env8346 (packedSelected [0,1,2,3,4,5,6] rootPS)) = affineNative (2^(18+1) ^^^ 10116) := by decide +kernel

theorem selectedBound8346 : packedSelected [0,1,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8347 : List Nat := [2,4,8,16,1,64,128,256,512,1024,0,1297,8192,1992,8832,515,1345,0,10116,8832,1296,8201,712,8583,8329,17,9092,1992,1297,8461,1284,4294967296,257,4294975496,1345,513]

theorem envBound8347 : H12AffineFastState.Bounded env8347 := by
  intro p hp
  have h : env8347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8346_8347 : H12AffineEnvironment.transform 18 10116 env8346 = env8347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 10116 env8346 == env8347) = true)

theorem identity8347 : scanCanonicalize (H12AffineFastState.compose env8347 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8347 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8348 : List Nat := [2,4,8,16,1,64,128,256,136,1024,0,1297,8192,1344,8200,139,1345,0,9484,8200,1296,8201,64,8583,8329,17,8460,1344,1297,8461,1284,4294967296,257,4294975496,1345,137]

theorem envBound8348 : H12AffineFastState.Bounded env8348 := by
  intro p hp
  have h : env8348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8347_8348 : H12AffineEnvironment.transform 8 136 env8347 = env8348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8347 == env8348) = true)

theorem identity8348 : scanCanonicalize (H12AffineFastState.compose env8348 (packedSelected [2,3,4,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8348 : packedSelected [2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env8349 : List Nat := [2,4,8,16,1,64,128,256,136,1024,0,1297,268,1344,260,139,1345,0,1024,260,1296,261,64,139,389,17,0,1344,1297,1,1284,4294967296,257,4294967556,1345,137]

theorem envBound8349 : H12AffineFastState.Bounded env8349 := by
  intro p hp
  have h : env8349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8348_8349 : H12AffineEnvironment.transform 12 268 env8348 = env8349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8348 == env8349) = true)

theorem identity8349 : scanCanonicalize (H12AffineFastState.compose env8349 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8349 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8350 : List Nat := [2,4,8,16,1,64,128,5,136,1024,0,1044,9,1093,1,139,1092,0,1024,1,1045,0,64,139,128,17,0,1093,1044,1,1025,4294967296,4,4294967297,1092,137]

theorem envBound8350 : H12AffineFastState.Bounded env8350 := by
  intro p hp
  have h : env8350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8349_8350 : H12AffineEnvironment.transform 7 5 env8349 = env8350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8349 == env8350) = true)

theorem identity8350 : scanCanonicalize (H12AffineFastState.compose env8350 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound8350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8351 : List Nat := [2,4,8,16,1,64,128,5,136,1024,0,1044,9,1093,1,139,1092,0,1024,1,1045,0,64,139,128,17,0,1093,1044,1,1025,10,4,11,1092,137]

theorem envBound8351 : H12AffineFastState.Bounded env8351 := by
  intro p hp
  have h : env8351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8350_8351 : H12AffineEnvironment.transform 31 10 env8350 = env8351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env8350 == env8351) = true)

theorem identity8351 : scanCanonicalize (H12AffineFastState.compose env8351 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8351 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8352 : List Nat := [2,4,8,16,1,1,128,5,136,1024,0,1044,9,1028,1,139,1029,0,1024,1,1045,0,1,139,128,17,0,1028,1044,1,1025,10,4,11,1029,137]

theorem envBound8352 : H12AffineFastState.Bounded env8352 := by
  intro p hp
  have h : env8352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8351_8352 : H12AffineEnvironment.transform 5 1 env8351 = env8352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8351 == env8352) = true)

def leafEnv8352 : List Nat := [2,4,8,16,1,1,128,5,136,1024,0,1044,9,1028,1,139,1029,0,1024,1,1045,0,1,139,1025,128,1,17,0,1028,1044,1,1025,10,4,11,5,3,1029,137,0,1045,1]

def active8352 : List Nat := [0,1,2,3,6,9]

def tree8352 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8352 : H12WitnessSearch.Good tree8352 := H12GlobalWitnessIndex.good

theorem leafIdentity8352 : H12AffineFastState.composeSystem env8352 rootObs = leafEnv8352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8352 rootObs == leafEnv8352) = true)

theorem terminalChecked8352 : H12PackedTerminal.terminalCheckFast leafEnv8352 active8352 tree8352 = true := by decide +kernel

def env8353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8201,17664,206533,33554432,5376,2253852,16384,131152,35788005,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8353 : H12AffineFastState.Bounded env8353 := by
  intro p hp
  have h : env8353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8324_8353 : H12AffineEnvironment.transform 17 1 env8324 = env8353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8324 == env8353) = true)

def env8354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17664,74629,33554432,5376,2122076,16384,1296,35656101,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8354 : H12AffineFastState.Bounded env8354 := by
  intro p hp
  have h : env8354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8353_8354 : H12AffineEnvironment.transform 16 1344 env8353 = env8354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8353 == env8354) = true)

theorem identity8354 : scanCanonicalize (H12AffineFastState.compose env8354 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8354 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17664,74629,2647257,5376,2122076,16384,1296,554364,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8355 : H12AffineFastState.Bounded env8355 := by
  intro p hp
  have h : env8355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8354_8355 : H12AffineEnvironment.transform 24 2647257 env8354 = env8355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8354 == env8355) = true)

theorem identity8355 : scanCanonicalize (H12AffineFastState.compose env8355 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 603950) := by decide +kernel

theorem selectedBound8355 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,603950,8201,17664,74629,87031,5376,611954,16384,1296,554364,1285,4294967296,257,4295500808,1344,94591]

theorem envBound8356 : H12AffineFastState.Bounded env8356 := by
  intro p hp
  have h : env8356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8355_8356 : H12AffineEnvironment.transform 20 603950 env8355 = env8356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 603950 env8355 == env8356) = true)

theorem identity8356 : scanCanonicalize (H12AffineFastState.compose env8356 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 75567) := by decide +kernel

theorem selectedBound8356 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,75567,8832,4097,8201,17664,74629,87031,5376,29021,16384,1296,86611,1285,4294967296,257,4295033639,1344,94591]

theorem envBound8357 : H12AffineFastState.Bounded env8357 := by
  intro p hp
  have h : env8357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8356_8357 : H12AffineEnvironment.transform 18 75567 env8356 = env8357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75567 env8356 == env8357) = true)

theorem identity8357 : scanCanonicalize (H12AffineFastState.compose env8357 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 20730) := by decide +kernel

theorem selectedBound8357 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,20730,1344,1,30677,8832,4097,8201,17664,29567,781,5376,29021,16384,1296,681,1285,4294967296,257,4294988765,1344,8581]

theorem envBound8358 : H12AffineFastState.Bounded env8358 := by
  intro p hp
  have h : env8358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8357_8358 : H12AffineEnvironment.transform 15 20730 env8357 = env8358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20730 env8357 == env8358) = true)

theorem identity8358 : scanCanonicalize (H12AffineFastState.compose env8358 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 4208) := by decide +kernel

theorem selectedBound8358 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4208,8832,138,1344,1,10149,8832,4097,8201,5488,8975,781,5376,8493,4208,1296,681,1285,4294967296,257,4294968237,1344,8581]

theorem envBound8359 : H12AffineFastState.Bounded env8359 := by
  intro p hp
  have h : env8359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8358_8359 : H12AffineEnvironment.transform 13 4208 env8358 = env8359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4208 env8358 == env8359) = true)

theorem identity8359 : scanCanonicalize (H12AffineFastState.compose env8359 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound8359 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,8192,2025,8832,138,1344,1,10149,8832,1944,8201,745,8975,781,665,8493,2025,1296,681,1285,4294967296,257,4294968237,1344,8581]

theorem envBound8360 : H12AffineFastState.Bounded env8360 := by
  intro p hp
  have h : env8360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8359_8360 : H12AffineEnvironment.transform 11 1945 env8359 = env8360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env8359 == env8360) = true)

theorem identity8360 : scanCanonicalize (H12AffineFastState.compose env8360 (packedSelected [1,3,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound8360 : packedSelected [1,3,10,19] rootPS < 2^1333 := by decide +kernel

def env8361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,40,2025,680,138,1344,1,1933,680,1944,33,745,807,781,665,261,2025,1296,681,1285,4294967296,257,4294968237,1344,429]

theorem envBound8361 : H12AffineFastState.Bounded env8361 := by
  intro p hp
  have h : env8361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8360_8361 : H12AffineEnvironment.transform 12 40 env8360 = env8361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env8360 == env8361) = true)

theorem identity8361 : scanCanonicalize (H12AffineFastState.compose env8361 (packedSelected [0,1,3,5,7,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8361 : packedSelected [0,1,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8362 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,1725,40,1741,680,138,1124,1,1705,680,1724,33,745,515,553,665,33,1741,1076,681,1057,4294967296,37,4294967945,1124,137]

theorem envBound8362 : H12AffineFastState.Bounded env8362 := by
  intro p hp
  have h : env8362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8361_8362 : H12AffineEnvironment.transform 7 36 env8361 = env8362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8361 == env8362) = true)

theorem identity8362 : scanCanonicalize (H12AffineFastState.compose env8362 (packedSelected [1,3,5,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound8362 : packedSelected [1,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8363 : List Nat := [2,4,8,16,32,64,128,36,217,1024,0,1124,40,1044,113,138,1124,1,1136,113,1125,33,48,218,240,64,33,1044,1076,112,1057,4294967296,37,4294967376,1124,137]

theorem envBound8363 : H12AffineFastState.Bounded env8363 := by
  intro p hp
  have h : env8363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8362_8363 : H12AffineEnvironment.transform 8 217 env8362 = env8363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8362 == env8363) = true)

theorem identity8363 : scanCanonicalize (H12AffineFastState.compose env8363 (packedSelected [0,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8363 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env8364 : List Nat := [2,4,8,16,10,64,128,14,217,1024,0,1102,2,1044,91,138,1102,1,1114,91,1103,11,26,218,218,64,11,1044,1054,90,1035,4294967296,15,4294967376,1102,137]

theorem envBound8364 : H12AffineFastState.Bounded env8364 := by
  intro p hp
  have h : env8364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8363_8364 : H12AffineEnvironment.transform 4 10 env8363 = env8364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8363 == env8364) = true)

theorem identity8364 : scanCanonicalize (H12AffineFastState.compose env8364 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 1164) := by decide +kernel

theorem selectedBound8364 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env8365 : List Nat := [2,4,8,16,10,64,128,14,217,1024,0,1102,2,1044,91,138,1102,1,1114,91,1103,11,26,218,218,64,11,1044,1054,90,1035,1164,15,1244,1102,137]

theorem envBound8365 : H12AffineFastState.Bounded env8365 := by
  intro p hp
  have h : env8365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8364_8365 : H12AffineEnvironment.transform 31 1164 env8364 = env8365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1164 env8364 == env8365) = true)

def env8366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17664,74628,33554432,5376,2122077,16384,1297,35656100,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8366 : H12AffineFastState.Bounded env8366 := by
  intro p hp
  have h : env8366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8353_8366 : H12AffineEnvironment.transform 16 1345 env8353 = env8366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8353 == env8366) = true)

theorem identity8366 : scanCanonicalize (H12AffineFastState.compose env8366 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8366 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8201,17664,74628,33554432,5376,29020,16384,1297,33554853,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8367 : H12AffineFastState.Bounded env8367 := by
  intro p hp
  have h : env8367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8366_8367 : H12AffineEnvironment.transform 20 4097 env8366 = env8367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8366 == env8367) = true)

theorem identity8367 : scanCanonicalize (H12AffineFastState.compose env8367 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 5661) := by decide +kernel

theorem selectedBound8367 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8201,17664,74628,5661,5376,29020,16384,1297,6072,1284,4294967296,257,4295582179,1345,13461]

theorem envBound8368 : H12AffineFastState.Bounded env8368 := by
  intro p hp
  have h : env8368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8367_8368 : H12AffineEnvironment.transform 24 5661 env8367 = env8368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5661 env8367 == env8368) = true)

theorem identity8368 : scanCanonicalize (H12AffineFastState.compose env8368 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 9325) := by decide +kernel

theorem selectedBound8368 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9325,8832,65536,1345,1,524288,8832,4097,8201,8557,74628,5661,5376,5425,9325,1297,6072,1284,4294967296,257,4295558542,1345,13461]

theorem envBound8369 : H12AffineFastState.Bounded env8369 := by
  intro p hp
  have h : env8369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8368_8369 : H12AffineEnvironment.transform 13 9325 env8368 = env8369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9325 env8368 == env8369) = true)

theorem identity8369 : scanCanonicalize (H12AffineFastState.compose env8369 (packedSelected [1,9,10,12,13,15,19,21,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound8369 : packedSelected [1,9,10,12,13,15,19,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env8370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,4208,5789,65536,1345,1,524288,5789,4097,5140,5488,71577,5661,5376,5425,4208,1297,6072,1284,4294967296,257,4295558542,1345,136]

theorem envBound8370 : H12AffineFastState.Bounded env8370 := by
  intro p hp
  have h : env8370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8369_8370 : H12AffineEnvironment.transform 12 5149 env8369 = env8370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env8369 == env8370) = true)

theorem identity8370 : scanCanonicalize (H12AffineFastState.compose env8370 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8370 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8371 : List Nat := [2,4,8,16,0,64,128,256,512,1024,0,4096,5149,4176,5789,65536,1345,1,524288,5789,4097,5140,5456,71577,5661,5376,5393,4176,1297,6040,1284,4294967296,257,4295558542,1345,136]

theorem envBound8371 : H12AffineFastState.Bounded env8371 := by
  intro p hp
  have h : env8371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8370_8371 : H12AffineEnvironment.transform 4 0 env8370 = env8371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8370 == env8371) = true)

theorem identity8371 : scanCanonicalize (H12AffineFastState.compose env8371 (packedSelected [0,4,7,9,18] rootPS)) = affineNative (2^(15+1) ^^^ 5906) := by decide +kernel

theorem selectedBound8371 : packedSelected [0,4,7,9,18] rootPS < 2^1333 := by decide +kernel

def env8372 : List Nat := [2,4,8,16,0,64,128,256,512,1024,0,4096,5149,4176,5789,5906,1345,1,524288,5789,4097,5140,5456,139,5661,5376,5393,4176,1297,6040,1284,4294967296,257,4295496348,1345,136]

theorem envBound8372 : H12AffineFastState.Bounded env8372 := by
  intro p hp
  have h : env8372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8371_8372 : H12AffineEnvironment.transform 15 5906 env8371 = env8372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5906 env8371 == env8372) = true)

theorem identity8372 : scanCanonicalize (H12AffineFastState.compose env8372 (packedSelected [1,3,5] rootPS)) = affineNative (2^(18+1) ^^^ 5017) := by decide +kernel

theorem selectedBound8372 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8373 : List Nat := [2,4,8,16,0,64,128,256,512,1024,0,4096,5149,4176,5789,5906,1345,1,5017,5789,4097,5140,5456,139,5661,5376,5393,4176,1297,6040,1284,4294967296,257,4294967557,1345,136]

theorem envBound8373 : H12AffineFastState.Bounded env8373 := by
  intro p hp
  have h : env8373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8372_8373 : H12AffineEnvironment.transform 18 5017 env8372 = env8373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env8372 == env8373) = true)

theorem identity8373 : scanCanonicalize (H12AffineFastState.compose env8373 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound8373 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8374 : List Nat := [2,4,8,16,0,64,128,256,512,1024,0,1297,268,1345,908,515,1345,1,1672,908,1296,261,65,139,780,17,0,1345,1297,649,1284,4294967296,257,4294967557,1345,136]

theorem envBound8374 : H12AffineFastState.Bounded env8374 := by
  intro p hp
  have h : env8374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8373_8374 : H12AffineEnvironment.transform 11 1297 env8373 = env8374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8373 == env8374) = true)

theorem identity8374 : scanCanonicalize (H12AffineFastState.compose env8374 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8374 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8375 : List Nat := [2,4,8,16,0,64,128,256,136,1024,0,1297,268,1345,260,139,1345,1,1024,260,1296,261,65,139,388,17,0,1345,1297,1,1284,4294967296,257,4294967557,1345,136]

theorem envBound8375 : H12AffineFastState.Bounded env8375 := by
  intro p hp
  have h : env8375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8374_8375 : H12AffineEnvironment.transform 8 136 env8374 = env8375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8374 == env8375) = true)

theorem identity8375 : scanCanonicalize (H12AffineFastState.compose env8375 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8375 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8376 : List Nat := [2,4,8,16,0,64,8,256,0,1024,0,1297,268,1345,260,3,1345,1,1024,260,1296,261,65,3,268,17,0,1345,1297,1,1284,4294967296,257,4294967557,1345,0]

theorem envBound8376 : H12AffineFastState.Bounded env8376 := by
  intro p hp
  have h : env8376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8375_8376 : H12AffineEnvironment.transform 6 8 env8375 = env8376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8375 == env8376) = true)

theorem identity8376 : scanCanonicalize (H12AffineFastState.compose env8376 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 82) := by decide +kernel

theorem selectedBound8376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8377 : List Nat := [2,4,8,16,0,64,8,256,0,1024,0,1297,268,1345,260,3,1345,1,1024,260,1296,261,65,3,268,17,0,1345,1297,1,1284,82,257,343,1345,0]

theorem envBound8377 : H12AffineFastState.Bounded env8377 := by
  intro p hp
  have h : env8377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8376_8377 : H12AffineEnvironment.transform 31 82 env8376 = env8377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 82 env8376 == env8377) = true)

theorem identity8377 : scanCanonicalize (H12AffineFastState.compose env8377 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 13) := by decide +kernel

theorem selectedBound8377 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8378 : List Nat := [2,4,8,16,0,64,8,13,0,1024,0,1052,1,1100,9,3,1100,1,1024,9,1053,8,65,3,1,17,0,1100,1052,1,1033,82,12,90,1100,0]

theorem envBound8378 : H12AffineFastState.Bounded env8378 := by
  intro p hp
  have h : env8378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8377_8378 : H12AffineEnvironment.transform 7 13 env8377 = env8378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 13 env8377 == env8378) = true)

theorem identity8378 : scanCanonicalize (H12AffineFastState.compose env8378 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound8378 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8379 : List Nat := [1,4,8,16,0,64,8,13,0,1024,0,1052,1,1100,9,0,1100,1,1024,9,1053,8,65,0,1,17,0,1100,1052,1,1033,81,12,89,1100,0]

theorem envBound8379 : H12AffineFastState.Bounded env8379 := by
  intro p hp
  have h : env8379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8378_8379 : H12AffineEnvironment.transform 0 1 env8378 = env8379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env8378 == env8379) = true)

theorem identity8379 : scanCanonicalize (H12AffineFastState.compose env8379 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8379 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env8380 : List Nat := [1,4,8,16,0,64,8,13,0,5,0,25,1,73,9,0,73,1,5,9,24,8,65,0,1,17,0,73,25,1,12,81,12,89,73,0]

theorem envBound8380 : H12AffineFastState.Bounded env8380 := by
  intro p hp
  have h : env8380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8379_8380 : H12AffineEnvironment.transform 9 5 env8379 = env8380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8379 == env8380) = true)

def env8381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17664,206533,33554432,5376,2515996,16384,131152,1073741824,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8381 : H12AffineFastState.Bounded env8381 := by
  intro p hp
  have h : env8381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8322_8381 : H12AffineEnvironment.transform 10 1 env8322 = env8381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8322 == env8381) = true)

theorem identity8381 : scanCanonicalize (H12AffineFastState.compose env8381 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 423572) := by decide +kernel

theorem selectedBound8381 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17664,206533,33554432,5376,2515996,16384,131152,423572,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8382 : H12AffineFastState.Bounded env8382 := by
  intro p hp
  have h : env8382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8381_8382 : H12AffineEnvironment.transform 29 423572 env8381 = env8382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 423572 env8381 == env8382) = true)

def env8383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17664,206533,33554432,5376,2253852,16384,131152,161428,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8383 : H12AffineFastState.Bounded env8383 := by
  intro p hp
  have h : env8383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8382_8383 : H12AffineEnvironment.transform 17 0 env8382 = env8383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8382 == env8383) = true)

def env8384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8200,17664,74629,33554432,5376,2122076,16384,1296,29652,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8384 : H12AffineFastState.Bounded env8384 := by
  intro p hp
  have h : env8384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8383_8384 : H12AffineEnvironment.transform 16 1344 env8383 = env8384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8383 == env8384) = true)

theorem identity8384 : scanCanonicalize (H12AffineFastState.compose env8384 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8384 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8200,17664,74629,2647257,5376,2122076,16384,1296,29652,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8385 : H12AffineFastState.Bounded env8385 := by
  intro p hp
  have h : env8385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8384_8385 : H12AffineEnvironment.transform 24 2647257 env8384 = env8385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8384 == env8385) = true)

theorem identity8385 : scanCanonicalize (H12AffineFastState.compose env8385 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 78214) := by decide +kernel

theorem selectedBound8385 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,78214,8200,17664,74629,611679,5376,86234,16384,1296,29652,1285,4294967296,257,4294976161,1344,620503]

theorem envBound8386 : H12AffineFastState.Bounded env8386 := by
  intro p hp
  have h : env8386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8385_8386 : H12AffineEnvironment.transform 20 78214 env8385 = env8386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78214 env8385 == env8386) = true)

theorem identity8386 : scanCanonicalize (H12AffineFastState.compose env8386 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound8386 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,8583,1344,0,524288,8832,4097,8200,17664,514,554200,5376,29021,16384,1296,29652,1285,4294967296,257,4294976161,1344,546384]

theorem envBound8387 : H12AffineFastState.Bounded env8387 := by
  intro p hp
  have h : env8387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8386_8387 : H12AffineEnvironment.transform 15 8583 env8386 = env8387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env8386 == env8387) = true)

theorem identity8387 : scanCanonicalize (H12AffineFastState.compose env8387 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 10148) := by decide +kernel

theorem selectedBound8387 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,8583,1344,0,10148,8832,4097,8200,17664,514,21372,5376,29021,16384,1296,29652,1285,4294967296,257,4294976161,1344,29172]

theorem envBound8388 : H12AffineFastState.Bounded env8388 := by
  intro p hp
  have h : env8388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8387_8388 : H12AffineEnvironment.transform 18 10148 env8387 = env8388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 10148 env8387 == env8388) = true)

theorem identity8388 : scanCanonicalize (H12AffineFastState.compose env8388 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 12668) := by decide +kernel

theorem selectedBound8388 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,12668,8832,8583,1344,0,10148,8832,4097,8200,13436,514,8704,5376,33,12668,1296,680,1285,4294967296,257,4294976161,1344,136]

theorem envBound8389 : H12AffineFastState.Bounded env8389 := by
  intro p hp
  have h : env8389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8388_8389 : H12AffineEnvironment.transform 13 12668 env8388 = env8389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12668 env8388 == env8389) = true)

theorem identity8389 : scanCanonicalize (H12AffineFastState.compose env8389 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound8389 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,9324,8832,8583,1344,0,10148,8832,1297,8200,8556,514,8704,16,33,9324,1296,680,1285,4294967296,257,4294976161,1344,136]

theorem envBound8390 : H12AffineFastState.Bounded env8390 := by
  intro p hp
  have h : env8390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8389_8390 : H12AffineEnvironment.transform 11 1296 env8389 = env8390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env8389 == env8390) = true)

theorem identity8390 : scanCanonicalize (H12AffineFastState.compose env8390 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound8390 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,41,1093,681,430,1344,0,1933,681,1297,33,325,514,553,16,33,1093,1296,680,1285,4294967296,257,4294967944,1344,136]

theorem envBound8391 : H12AffineFastState.Bounded env8391 := by
  intro p hp
  have h : env8391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8390_8391 : H12AffineEnvironment.transform 12 41 env8390 = env8391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env8390 == env8391) = true)

theorem identity8391 : scanCanonicalize (H12AffineFastState.compose env8391 (packedSelected [0,7,10,12,15,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8391 : packedSelected [0,7,10,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env8392 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1296,41,1093,33,430,1344,0,1285,33,1297,33,325,138,161,16,33,1093,1296,32,1285,4294967296,257,4294967296,1344,136]

theorem envBound8392 : H12AffineFastState.Bounded env8392 := by
  intro p hp
  have h : env8392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8391_8392 : H12AffineEnvironment.transform 8 136 env8391 = env8392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8391 == env8392) = true)

theorem identity8392 : scanCanonicalize (H12AffineFastState.compose env8392 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound8392 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8393 : List Nat := [2,4,8,16,32,64,128,14,136,1024,1,1054,41,1093,33,160,1102,0,1035,33,1055,33,75,138,161,16,33,1093,1054,32,1035,4294967296,15,4294967296,1102,136]

theorem envBound8393 : H12AffineFastState.Bounded env8393 := by
  intro p hp
  have h : env8393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8392_8393 : H12AffineEnvironment.transform 7 14 env8392 = env8393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env8392 == env8393) = true)

theorem identity8393 : scanCanonicalize (H12AffineFastState.compose env8393 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8393 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8394 : List Nat := [2,4,8,16,32,64,2,14,10,1024,1,1054,41,1093,33,34,1102,0,1035,33,1055,33,75,8,35,16,33,1093,1054,32,1035,4294967296,15,4294967296,1102,10]

theorem envBound8394 : H12AffineFastState.Bounded env8394 := by
  intro p hp
  have h : env8394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8393_8394 : H12AffineEnvironment.transform 6 2 env8393 = env8394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8393 == env8394) = true)

theorem identity8394 : scanCanonicalize (H12AffineFastState.compose env8394 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(31+1) ^^^ 80) := by decide +kernel

theorem selectedBound8394 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8395 : List Nat := [2,4,8,16,32,64,2,14,10,1024,1,1054,41,1093,33,34,1102,0,1035,33,1055,33,75,8,35,16,33,1093,1054,32,1035,80,15,80,1102,10]

theorem envBound8395 : H12AffineFastState.Bounded env8395 := by
  intro p hp
  have h : env8395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8394_8395 : H12AffineEnvironment.transform 31 80 env8394 = env8395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 80 env8394 == env8395) = true)

theorem identity8395 : scanCanonicalize (H12AffineFastState.compose env8395 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 34) := by decide +kernel

theorem selectedBound8395 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env8396 : List Nat := [2,4,8,16,32,34,2,14,10,1024,1,1054,41,1063,33,34,1068,0,1035,33,1055,33,41,8,35,16,33,1063,1054,32,1035,50,15,50,1068,10]

theorem envBound8396 : H12AffineFastState.Bounded env8396 := by
  intro p hp
  have h : env8396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8395_8396 : H12AffineEnvironment.transform 5 34 env8395 = env8396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 34 env8395 == env8396) = true)

theorem identity8396 : scanCanonicalize (H12AffineFastState.compose env8396 (packedSelected [0,1,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound8396 : packedSelected [0,1,2,4,10] rootPS < 2^1333 := by decide +kernel

def env8397 : List Nat := [2,4,8,16,32,34,2,14,10,23,1,9,41,48,33,34,59,0,28,33,8,33,41,8,35,16,33,48,9,32,28,50,15,50,59,10]

theorem envBound8397 : H12AffineFastState.Bounded env8397 := by
  intro p hp
  have h : env8397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8396_8397 : H12AffineEnvironment.transform 9 23 env8396 = env8397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env8396 == env8397) = true)

theorem identity8397 : scanCanonicalize (H12AffineFastState.compose env8397 (packedSelected [3,12] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound8397 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env8398 : List Nat := [2,4,8,3,32,34,2,14,10,4,1,9,41,35,33,34,40,0,15,33,8,33,41,8,35,3,33,35,9,32,15,33,15,33,40,10]

theorem envBound8398 : H12AffineFastState.Bounded env8398 := by
  intro p hp
  have h : env8398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8397_8398 : H12AffineEnvironment.transform 3 3 env8397 = env8398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env8397 == env8398) = true)

theorem identity8398 : scanCanonicalize (H12AffineFastState.compose env8398 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8398 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8399 : List Nat := [2,4,2,3,32,34,2,4,0,4,1,3,35,35,33,34,34,0,5,33,2,33,35,2,35,3,33,35,3,32,5,33,5,33,34,0]

theorem envBound8399 : H12AffineFastState.Bounded env8399 := by
  intro p hp
  have h : env8399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8398_8399 : H12AffineEnvironment.transform 2 2 env8398 = env8399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8398 == env8399) = true)

theorem identity8399 : scanCanonicalize (H12AffineFastState.compose env8399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8400 : List Nat := [2,4,2,3,0,2,2,4,0,4,1,3,3,3,1,2,2,0,5,1,2,1,3,2,3,3,1,3,3,0,5,1,5,1,2,0]

theorem envBound8400 : H12AffineFastState.Bounded env8400 := by
  intro p hp
  have h : env8400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8399_8400 : H12AffineEnvironment.transform 4 0 env8399 = env8400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8399 == env8400) = true)

def env8401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8200,17664,74628,33554432,5376,2122077,16384,1297,29653,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8401 : H12AffineFastState.Bounded env8401 := by
  intro p hp
  have h : env8401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8383_8401 : H12AffineEnvironment.transform 16 1345 env8383 = env8401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8383 == env8401) = true)

theorem identity8401 : scanCanonicalize (H12AffineFastState.compose env8401 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8401 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8200,17664,74628,33554432,5376,29020,16384,1297,29653,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8402 : H12AffineFastState.Bounded env8402 := by
  intro p hp
  have h : env8402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8401_8402 : H12AffineEnvironment.transform 20 4097 env8401 = env8402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8401 == env8402) = true)

theorem identity8402 : scanCanonicalize (H12AffineFastState.compose env8402 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 18028) := by decide +kernel

theorem selectedBound8402 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8200,17664,74628,18028,5376,29020,16384,1297,29653,1284,4294967296,257,4295569811,1345,25828]

theorem envBound8403 : H12AffineFastState.Bounded env8403 := by
  intro p hp
  have h : env8403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8402_8403 : H12AffineEnvironment.transform 24 18028 env8402 = env8403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 18028 env8402 == env8403) = true)

theorem identity8403 : scanCanonicalize (H12AffineFastState.compose env8403 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound8403 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,16384,5788,65536,1345,0,524288,5788,4097,5140,17664,71576,18028,5376,17728,16384,1297,18377,1284,4294967296,257,4295558543,1345,20728]

theorem envBound8404 : H12AffineFastState.Bounded env8404 := by
  intro p hp
  have h : env8404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8403_8404 : H12AffineEnvironment.transform 12 5148 env8403 = env8404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env8403 == env8404) = true)

theorem identity8404 : scanCanonicalize (H12AffineFastState.compose env8404 (packedSelected [3,12,13,15,18,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 4208) := by decide +kernel

theorem selectedBound8404 : packedSelected [3,12,13,15,18,21,24] rootPS < 2^1333 := by decide +kernel

def env8405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,4208,5788,65536,1345,0,524288,5788,4097,5140,5488,71576,5660,5376,5424,4208,1297,6073,1284,4294967296,257,4295558543,1345,136]

theorem envBound8405 : H12AffineFastState.Bounded env8405 := by
  intro p hp
  have h : env8405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8404_8405 : H12AffineEnvironment.transform 13 4208 env8404 = env8405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4208 env8404 == env8405) = true)

theorem identity8405 : scanCanonicalize (H12AffineFastState.compose env8405 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8405 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8406 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,5148,4176,5788,65536,1345,0,524288,5788,4097,5140,5456,71576,5660,5376,5392,4176,1297,6041,1284,4294967296,257,4295558543,1345,136]

theorem envBound8406 : H12AffineFastState.Bounded env8406 := by
  intro p hp
  have h : env8406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8405_8406 : H12AffineEnvironment.transform 4 0 env8405 = env8406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8405 == env8406) = true)

theorem identity8406 : scanCanonicalize (H12AffineFastState.compose env8406 (packedSelected [0,4,7,9,18] rootPS)) = affineNative (2^(15+1) ^^^ 5530) := by decide +kernel

theorem selectedBound8406 : packedSelected [0,4,7,9,18] rootPS < 2^1333 := by decide +kernel

def env8407 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,5148,4176,5788,5530,1345,0,524288,5788,4097,5140,5456,514,5660,5376,5392,4176,1297,6041,1284,4294967296,257,4295495701,1345,136]

theorem envBound8407 : H12AffineFastState.Bounded env8407 := by
  intro p hp
  have h : env8407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8406_8407 : H12AffineEnvironment.transform 15 5530 env8406 = env8407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5530 env8406 == env8407) = true)

theorem identity8407 : scanCanonicalize (H12AffineFastState.compose env8407 (packedSelected [0,1,3,4,5,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 5017) := by decide +kernel

theorem selectedBound8407 : packedSelected [0,1,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8408 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,5148,4176,5788,5530,1345,0,5017,5788,4097,5140,5456,514,5660,5376,5392,4176,1297,6041,1284,4294967296,257,4294968204,1345,136]

theorem envBound8408 : H12AffineFastState.Bounded env8408 := by
  intro p hp
  have h : env8408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8407_8408 : H12AffineEnvironment.transform 18 5017 env8407 = env8408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env8407 == env8408) = true)

theorem identity8408 : scanCanonicalize (H12AffineFastState.compose env8408 (packedSelected [1,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound8408 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env8409 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,1297,269,1345,909,139,1345,0,1672,909,1296,261,65,514,781,17,1,1345,1297,648,1284,4294967296,257,4294968204,1345,136]

theorem envBound8409 : H12AffineFastState.Bounded env8409 := by
  intro p hp
  have h : env8409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8408_8409 : H12AffineEnvironment.transform 11 1297 env8408 = env8409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8408 == env8409) = true)

theorem identity8409 : scanCanonicalize (H12AffineFastState.compose env8409 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8409 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8410 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1297,269,1345,261,139,1345,0,1024,261,1296,261,65,138,389,17,1,1345,1297,0,1284,4294967296,257,4294967556,1345,136]

theorem envBound8410 : H12AffineFastState.Bounded env8410 := by
  intro p hp
  have h : env8410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8409_8410 : H12AffineEnvironment.transform 8 136 env8409 = env8410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8409 == env8410) = true)

theorem identity8410 : scanCanonicalize (H12AffineFastState.compose env8410 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8410 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8411 : List Nat := [2,4,8,16,0,64,88,256,80,1024,1,1297,269,1345,261,83,1345,0,1024,261,1296,261,65,82,349,17,1,1345,1297,0,1284,4294967296,257,4294967556,1345,80]

theorem envBound8411 : H12AffineFastState.Bounded env8411 := by
  intro p hp
  have h : env8411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8410_8411 : H12AffineEnvironment.transform 6 88 env8410 = env8411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8410 == env8411) = true)

theorem identity8411 : scanCanonicalize (H12AffineFastState.compose env8411 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound8411 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8412 : List Nat := [2,4,8,8,0,64,64,256,72,1024,1,1289,269,1345,261,75,1345,0,1024,261,1288,261,65,74,325,9,1,1345,1289,0,1284,4294967296,257,4294967556,1345,72]

theorem envBound8412 : H12AffineFastState.Bounded env8412 := by
  intro p hp
  have h : env8412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8411_8412 : H12AffineEnvironment.transform 3 8 env8411 = env8412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env8411 == env8412) = true)

theorem identity8412 : scanCanonicalize (H12AffineFastState.compose env8412 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound8412 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8413 : List Nat := [2,4,0,0,0,64,64,256,64,1024,1,1281,261,1345,261,67,1345,0,1024,261,1280,261,65,66,325,1,1,1345,1281,0,1284,4294967296,257,4294967556,1345,64]

theorem envBound8413 : H12AffineFastState.Bounded env8413 := by
  intro p hp
  have h : env8413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8412_8413 : H12AffineEnvironment.transform 2 0 env8412 = env8413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env8412 == env8413) = true)

theorem identity8413 : scanCanonicalize (H12AffineFastState.compose env8413 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound8413 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env8414 : List Nat := [2,4,0,0,0,64,64,6,64,1024,1,1031,3,1095,3,67,1095,0,1024,3,1030,3,65,66,67,1,1,1095,1031,0,1026,4294967296,7,4294967298,1095,64]

theorem envBound8414 : H12AffineFastState.Bounded env8414 := by
  intro p hp
  have h : env8414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8413_8414 : H12AffineEnvironment.transform 7 6 env8413 = env8414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env8413 == env8414) = true)

theorem identity8414 : scanCanonicalize (H12AffineFastState.compose env8414 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8414 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8415 : List Nat := [2,4,0,0,0,0,0,6,0,1024,1,1031,3,1031,3,3,1031,0,1024,3,1030,3,1,2,3,1,1,1031,1031,0,1026,4294967296,7,4294967298,1031,0]

theorem envBound8415 : H12AffineFastState.Bounded env8415 := by
  intro p hp
  have h : env8415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8414_8415 : H12AffineEnvironment.transform 5 0 env8414 = env8415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8414 == env8415) = true)

theorem identity8415 : scanCanonicalize (H12AffineFastState.compose env8415 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound8415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8416 : List Nat := [2,4,0,0,0,0,0,6,0,1024,1,1031,3,1031,3,3,1031,0,1024,3,1030,3,1,2,3,1,1,1031,1031,0,1026,1,7,3,1031,0]

theorem envBound8416 : H12AffineFastState.Bounded env8416 := by
  intro p hp
  have h : env8416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8415_8416 : H12AffineEnvironment.transform 31 1 env8415 = env8416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env8415 == env8416) = true)

theorem identity8416 : scanCanonicalize (H12AffineFastState.compose env8416 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound8416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8417 : List Nat := [1,4,0,0,0,0,0,5,0,1024,1,1028,0,1028,0,0,1028,0,1024,0,1029,0,1,1,0,1,1,1028,1028,0,1025,1,4,0,1028,0]

theorem envBound8417 : H12AffineFastState.Bounded env8417 := by
  intro p hp
  have h : env8417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8416_8417 : H12AffineEnvironment.transform 0 1 env8416 = env8417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env8416 == env8417) = true)

theorem identity8417 : scanCanonicalize (H12AffineFastState.compose env8417 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8417 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env8418 : List Nat := [1,4,0,0,0,0,0,5,0,4,1,0,0,0,0,0,0,0,4,0,1,0,1,1,0,1,1,0,0,0,5,1,4,0,0,0]

theorem envBound8418 : H12AffineFastState.Bounded env8418 := by
  intro p hp
  have h : env8418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8417_8418 : H12AffineEnvironment.transform 9 4 env8417 = env8418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8417 == env8418) = true)

def env8419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17664,206533,33554432,5376,2253853,16384,131152,161429,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8419 : H12AffineFastState.Bounded env8419 := by
  intro p hp
  have h : env8419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8382_8419 : H12AffineEnvironment.transform 17 1 env8382 = env8419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8382 == env8419) = true)

def env8420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8200,17664,74629,33554432,5376,2122077,16384,1296,29653,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8420 : H12AffineFastState.Bounded env8420 := by
  intro p hp
  have h : env8420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8419_8420 : H12AffineEnvironment.transform 16 1344 env8419 = env8420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8419 == env8420) = true)

theorem identity8420 : scanCanonicalize (H12AffineFastState.compose env8420 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8420 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8200,17664,74629,2647257,5376,2122077,16384,1296,29653,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8421 : H12AffineFastState.Bounded env8421 := by
  intro p hp
  have h : env8421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8420_8421 : H12AffineEnvironment.transform 24 2647257 env8420 = env8421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8420 == env8421) = true)

theorem identity8421 : scanCanonicalize (H12AffineFastState.compose env8421 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 78215) := by decide +kernel

theorem selectedBound8421 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,78215,8200,17664,74629,611678,5376,86234,16384,1296,29653,1285,4294967296,257,4294976160,1344,620502]

theorem envBound8422 : H12AffineFastState.Bounded env8422 := by
  intro p hp
  have h : env8422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8421_8422 : H12AffineEnvironment.transform 20 78215 env8421 = env8422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78215 env8421 == env8422) = true)

theorem identity8422 : scanCanonicalize (H12AffineFastState.compose env8422 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound8422 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,8582,1344,1,524288,8832,4097,8200,17664,515,554200,5376,29020,16384,1296,29653,1285,4294967296,257,4294976160,1344,546384]

theorem envBound8423 : H12AffineFastState.Bounded env8423 := by
  intro p hp
  have h : env8423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8422_8423 : H12AffineEnvironment.transform 15 8582 env8422 = env8423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env8422 == env8423) = true)

theorem identity8423 : scanCanonicalize (H12AffineFastState.compose env8423 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 22264) := by decide +kernel

theorem selectedBound8423 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,8582,1344,1,22264,8832,4097,8200,17664,515,8736,5376,29020,16384,1296,29653,1285,4294967296,257,4294976160,1344,168]

theorem envBound8424 : H12AffineFastState.Bounded env8424 := by
  intro p hp
  have h : env8424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8423_8424 : H12AffineEnvironment.transform 18 22264 env8423 = env8424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 22264 env8423 == env8424) = true)

theorem identity8424 : scanCanonicalize (H12AffineFastState.compose env8424 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8424 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8425 : List Nat := [2,4,8,16,1,64,128,256,512,1024,1,4096,8192,16384,8832,8582,1344,1,22233,8832,4097,8200,17664,515,8705,5376,29020,16384,1296,29653,1285,4294967296,257,4294976129,1344,137]

theorem envBound8425 : H12AffineFastState.Bounded env8425 := by
  intro p hp
  have h : env8425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8424_8425 : H12AffineEnvironment.transform 4 1 env8424 = env8425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8424 == env8425) = true)

theorem identity8425 : scanCanonicalize (H12AffineFastState.compose env8425 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8425 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8426 : List Nat := [2,4,8,16,1,64,128,4,512,1024,1,4096,8192,16384,8832,8322,1092,1,22233,8832,4097,8200,17412,515,8705,5124,28760,16384,1044,29393,1025,4294967296,5,4294976129,1092,137]

theorem envBound8426 : H12AffineFastState.Bounded env8426 := by
  intro p hp
  have h : env8426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8425_8426 : H12AffineEnvironment.transform 7 4 env8425 = env8426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8425 == env8426) = true)

theorem identity8426 : scanCanonicalize (H12AffineFastState.compose env8426 (packedSelected [2,3,4,5,7,24] rootPS)) = affineNative (2^(31+1) ^^^ 21208) := by decide +kernel

theorem selectedBound8426 : packedSelected [2,3,4,5,7,24] rootPS < 2^1333 := by decide +kernel

def env8427 : List Nat := [2,4,8,16,1,64,128,4,512,1024,1,4096,8192,16384,8832,8322,1092,1,22233,8832,4097,8200,17412,515,8705,5124,28760,16384,1044,29393,1025,21208,5,28761,1092,137]

theorem envBound8427 : H12AffineFastState.Bounded env8427 := by
  intro p hp
  have h : env8427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8426_8427 : H12AffineEnvironment.transform 31 21208 env8426 = env8427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 21208 env8426 == env8427) = true)

theorem identity8427 : scanCanonicalize (H12AffineFastState.compose env8427 (packedSelected [18,32] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound8427 : packedSelected [18,32] rootPS < 2^1333 := by decide +kernel

def env8428 : List Nat := [2,4,8,16,1,64,128,4,512,1024,1,4096,8192,4825,8832,8322,1092,1,1024,8832,4097,8200,5853,515,8705,5124,8833,4825,1044,8200,1025,1,5,8832,1092,137]

theorem envBound8428 : H12AffineFastState.Bounded env8428 := by
  intro p hp
  have h : env8428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8427_8428 : H12AffineEnvironment.transform 13 4825 env8427 = env8428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env8427 == env8428) = true)

theorem identity8428 : scanCanonicalize (H12AffineFastState.compose env8428 (packedSelected [0,1,2,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8428 : packedSelected [0,1,2,9,10,12] rootPS < 2^1333 := by decide +kernel

def env8429 : List Nat := [2,4,8,16,1,64,128,4,136,1024,1,4096,8192,4177,8200,8322,1092,1,1024,8200,4097,8200,5205,139,8329,5124,8201,4177,1044,8200,1025,1,5,8200,1092,137]

theorem envBound8429 : H12AffineFastState.Bounded env8429 := by
  intro p hp
  have h : env8429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8428_8429 : H12AffineEnvironment.transform 8 136 env8428 = env8429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8428 == env8429) = true)

theorem identity8429 : scanCanonicalize (H12AffineFastState.compose env8429 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1119) := by decide +kernel

theorem selectedBound8429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8430 : List Nat := [2,4,8,16,1,64,128,4,136,1024,1,1119,8192,1038,8200,8322,1092,1,1024,8200,1118,8200,10,139,8329,91,8201,1038,1044,8200,1025,1,5,8200,1092,137]

theorem envBound8430 : H12AffineFastState.Bounded env8430 := by
  intro p hp
  have h : env8430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8429_8430 : H12AffineEnvironment.transform 11 1119 env8429 = env8430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1119 env8429 == env8430) = true)

theorem identity8430 : scanCanonicalize (H12AffineFastState.compose env8430 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8430 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8431 : List Nat := [2,4,8,16,1,1,128,4,136,1024,1,1054,8192,1038,8200,8322,1029,1,1024,8200,1055,8200,10,139,8329,26,8201,1038,1044,8200,1025,1,5,8200,1029,137]

theorem envBound8431 : H12AffineFastState.Bounded env8431 := by
  intro p hp
  have h : env8431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8430_8431 : H12AffineEnvironment.transform 5 1 env8430 = env8431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8430 == env8431) = true)

theorem identity8431 : scanCanonicalize (H12AffineFastState.compose env8431 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8431 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8432 : List Nat := [2,4,3,16,1,1,128,4,131,1024,1,1045,8192,1029,8195,8322,1029,1,1024,8195,1044,8195,1,128,8322,17,8194,1029,1044,8195,1025,1,5,8195,1029,130]

theorem envBound8432 : H12AffineFastState.Bounded env8432 := by
  intro p hp
  have h : env8432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8431_8432 : H12AffineEnvironment.transform 2 3 env8431 = env8432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8431 == env8432) = true)

theorem identity8432 : scanCanonicalize (H12AffineFastState.compose env8432 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound8432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8433 : List Nat := [2,4,3,16,1,1,128,4,131,1024,1,1045,3,1029,0,129,1029,1,1024,0,1044,0,1,128,129,17,1,1029,1044,0,1025,1,5,0,1029,130]

theorem envBound8433 : H12AffineFastState.Bounded env8433 := by
  intro p hp
  have h : env8433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8432_8433 : H12AffineEnvironment.transform 12 3 env8432 = env8433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env8432 == env8433) = true)

def env8434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8200,17664,74628,33554432,5376,2122076,16384,1297,29652,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8434 : H12AffineFastState.Bounded env8434 := by
  intro p hp
  have h : env8434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8419_8434 : H12AffineEnvironment.transform 16 1345 env8419 = env8434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8419 == env8434) = true)

theorem identity8434 : scanCanonicalize (H12AffineFastState.compose env8434 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8434 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8200,17664,74628,33554432,5376,29021,16384,1297,29652,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8435 : H12AffineFastState.Bounded env8435 := by
  intro p hp
  have h : env8435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8434_8435 : H12AffineEnvironment.transform 20 4097 env8434 = env8435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8434 == env8435) = true)

theorem identity8435 : scanCanonicalize (H12AffineFastState.compose env8435 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 14129) := by decide +kernel

theorem selectedBound8435 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8200,17664,74628,14129,5376,29021,16384,1297,29652,1284,4294967296,257,4295573710,1345,5561]

theorem envBound8436 : H12AffineFastState.Bounded env8436 := by
  intro p hp
  have h : env8436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8435_8436 : H12AffineEnvironment.transform 24 14129 env8435 = env8436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 14129 env8435 == env8436) = true)

theorem identity8436 : scanCanonicalize (H12AffineFastState.compose env8436 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound8436 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,8832,65536,1345,1,524288,8832,4097,8200,64,74628,14129,5376,13341,1344,1297,13972,1284,4294967296,257,4295558542,1345,5561]

theorem envBound8437 : H12AffineFastState.Bounded env8437 := by
  intro p hp
  have h : env8437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8436_8437 : H12AffineEnvironment.transform 13 1344 env8436 = env8437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env8436 == env8437) = true)

theorem identity8437 : scanCanonicalize (H12AffineFastState.compose env8437 (packedSelected [1,3,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8437 : packedSelected [1,3,10,19] rootPS < 2^1333 := by decide +kernel

def env8438 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,1344,8200,65536,1345,1,524288,8200,4097,8200,64,73996,13753,5376,13341,1344,1297,13340,1284,4294967296,257,4295558542,1345,5561]

theorem envBound8438 : H12AffineFastState.Bounded env8438 := by
  intro p hp
  have h : env8438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8437_8438 : H12AffineEnvironment.transform 8 136 env8437 = env8438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8437 == env8438) = true)

theorem identity8438 : scanCanonicalize (H12AffineFastState.compose env8438 (packedSelected [6,9,16,22,23,25] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound8438 : packedSelected [6,9,16,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8439 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,1344,8200,65536,1345,1,524288,8200,1296,8200,64,73996,8360,17,8460,1344,1297,8461,1284,4294967296,257,4295558542,1345,168]

theorem envBound8439 : H12AffineFastState.Bounded env8439 := by
  intro p hp
  have h : env8439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8438_8439 : H12AffineEnvironment.transform 11 1297 env8438 = env8439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8438 == env8439) = true)

theorem identity8439 : scanCanonicalize (H12AffineFastState.compose env8439 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 75174) := by decide +kernel

theorem selectedBound8439 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8440 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,1344,8200,65536,1345,1,75174,8200,1296,8200,64,73996,8360,17,8460,1344,1297,8461,1284,4294967296,257,4294975528,1345,168]

theorem envBound8440 : H12AffineFastState.Bounded env8440 := by
  intro p hp
  have h : env8440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8439_8440 : H12AffineEnvironment.transform 18 75174 env8439 = env8440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75174 env8439 == env8440) = true)

theorem identity8440 : scanCanonicalize (H12AffineFastState.compose env8440 (packedSelected [1,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound8440 : packedSelected [1,10,12] rootPS < 2^1333 := by decide +kernel

def env8441 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,8192,1344,8200,171,1345,1,9485,8200,1296,8200,64,8615,8360,17,8460,1344,1297,8461,1284,4294967296,257,4294975528,1345,168]

theorem envBound8441 : H12AffineFastState.Bounded env8441 := by
  intro p hp
  have h : env8441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8440_8441 : H12AffineEnvironment.transform 15 171 env8440 = env8441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env8440 == env8441) = true)

theorem identity8441 : scanCanonicalize (H12AffineFastState.compose env8441 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8441 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env8442 : List Nat := [2,4,8,16,1,64,128,256,136,1024,1,1297,8192,1344,8200,138,1345,1,9485,8200,1296,8200,64,8582,8329,17,8460,1344,1297,8461,1284,4294967296,257,4294975497,1345,137]

theorem envBound8442 : H12AffineFastState.Bounded env8442 := by
  intro p hp
  have h : env8442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8441_8442 : H12AffineEnvironment.transform 4 1 env8441 = env8442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8441 == env8442) = true)

theorem identity8442 : scanCanonicalize (H12AffineFastState.compose env8442 (packedSelected [2,3,4,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound8442 : packedSelected [2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env8443 : List Nat := [2,4,8,16,1,64,128,256,136,1024,1,1297,269,1344,261,138,1345,1,1024,261,1296,261,64,139,388,17,1,1344,1297,0,1284,4294967296,257,4294967556,1345,137]

theorem envBound8443 : H12AffineFastState.Bounded env8443 := by
  intro p hp
  have h : env8443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8442_8443 : H12AffineEnvironment.transform 12 269 env8442 = env8443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env8442 == env8443) = true)

theorem identity8443 : scanCanonicalize (H12AffineFastState.compose env8443 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8443 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8444 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1044,8,1093,0,138,1092,1,1024,0,1045,0,64,139,129,17,1,1093,1044,0,1025,4294967296,4,4294967297,1092,137]

theorem envBound8444 : H12AffineFastState.Bounded env8444 := by
  intro p hp
  have h : env8444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8443_8444 : H12AffineEnvironment.transform 7 5 env8443 = env8444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8443 == env8444) = true)

theorem identity8444 : scanCanonicalize (H12AffineFastState.compose env8444 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound8444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8445 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1044,8,1093,0,138,1092,1,1024,0,1045,0,64,139,129,17,1,1093,1044,0,1025,10,4,11,1092,137]

theorem envBound8445 : H12AffineFastState.Bounded env8445 := by
  intro p hp
  have h : env8445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8444_8445 : H12AffineEnvironment.transform 31 10 env8444 = env8445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env8444 == env8445) = true)

theorem identity8445 : scanCanonicalize (H12AffineFastState.compose env8445 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8446 : List Nat := [2,4,8,16,1,1,128,5,136,1024,1,1044,8,1028,0,138,1029,1,1024,0,1045,0,1,139,129,17,1,1028,1044,0,1025,10,4,11,1029,137]

theorem envBound8446 : H12AffineFastState.Bounded env8446 := by
  intro p hp
  have h : env8446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8445_8446 : H12AffineEnvironment.transform 5 1 env8445 = env8446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8445 == env8446) = true)

def leafEnv8446 : List Nat := [2,4,8,16,1,1,128,5,136,1024,1,1044,8,1028,0,138,1029,1,1024,0,1045,0,1,139,1025,129,1,17,1,1028,1044,0,1025,10,4,11,5,2,1029,137,0,1045,1]

def active8446 : List Nat := [0,1,2,3,6,9]

def tree8446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8446 : H12WitnessSearch.Good tree8446 := H12GlobalWitnessIndex.good

theorem leafIdentity8446 : H12AffineFastState.composeSystem env8446 rootObs = leafEnv8446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8446 rootObs == leafEnv8446) = true)

theorem terminalChecked8446 : H12PackedTerminal.terminalCheckFast leafEnv8446 active8446 tree8446 = true := by decide +kernel

def env8447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,10249,17664,206532,33554432,5376,2518045,16384,131152,1073741824,131141,4294967296,257,4329274046,131072,33563272]

theorem envBound8447 : H12AffineFastState.Bounded env8447 := by
  intro p hp
  have h : env8447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8321_8447 : H12AffineEnvironment.transform 14 8833 env8321 = env8447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env8321 == env8447) = true)

def env8448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17664,206532,33554432,5376,2515997,16384,131152,1073741824,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8448 : H12AffineFastState.Bounded env8448 := by
  intro p hp
  have h : env8448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8447_8448 : H12AffineEnvironment.transform 10 0 env8447 = env8448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8447 == env8448) = true)

theorem identity8448 : scanCanonicalize (H12AffineFastState.compose env8448 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 2241645) := by decide +kernel

theorem selectedBound8448 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17664,206532,33554432,5376,2515997,16384,131152,2241645,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8449 : H12AffineFastState.Bounded env8449 := by
  intro p hp
  have h : env8449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8448_8449 : H12AffineEnvironment.transform 29 2241645 env8448 = env8449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2241645 env8448 == env8449) = true)

def env8450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8201,17664,206532,33554432,5376,2253853,16384,131152,2241645,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8450 : H12AffineFastState.Bounded env8450 := by
  intro p hp
  have h : env8450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8449_8450 : H12AffineEnvironment.transform 17 0 env8449 = env8450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8449 == env8450) = true)

def env8451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17664,74628,33554432,5376,2122077,16384,1296,2109741,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8451 : H12AffineFastState.Bounded env8451 := by
  intro p hp
  have h : env8451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8450_8451 : H12AffineEnvironment.transform 16 1344 env8450 = env8451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8450 == env8451) = true)

theorem identity8451 : scanCanonicalize (H12AffineFastState.compose env8451 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8451 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17664,74628,2647257,5376,2122077,16384,1296,2109741,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8452 : H12AffineFastState.Bounded env8452 := by
  intro p hp
  have h : env8452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8451_8452 : H12AffineEnvironment.transform 24 2647257 env8451 = env8452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8451 == env8452) = true)

theorem identity8452 : scanCanonicalize (H12AffineFastState.compose env8452 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 29566) := by decide +kernel

theorem selectedBound8452 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,29566,1344,0,524288,8833,2097152,8201,17664,20730,2647257,5376,2122077,16384,1296,2109741,1285,4294967296,257,4297089113,1344,2639441]

theorem envBound8453 : H12AffineFastState.Bounded env8453 := by
  intro p hp
  have h : env8453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8452_8453 : H12AffineEnvironment.transform 15 29566 env8452 = env8453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29566 env8452 == env8453) = true)

theorem identity8453 : scanCanonicalize (H12AffineFastState.compose env8453 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8453 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,29566,1344,0,524288,8833,4097,8201,17664,20730,554200,5376,29020,16384,1296,8492,1285,4294967296,257,4294996056,1344,546384]

theorem envBound8454 : H12AffineFastState.Bounded env8454 := by
  intro p hp
  have h : env8454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8453_8454 : H12AffineEnvironment.transform 20 4097 env8453 = env8454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8453 == env8454) = true)

theorem identity8454 : scanCanonicalize (H12AffineFastState.compose env8454 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound8454 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4825,8833,8615,1344,0,524288,8833,4097,8201,6105,547,534017,5376,9093,4825,1296,8492,1285,4294967296,257,4294976129,1344,525449]

theorem envBound8455 : H12AffineFastState.Bounded env8455 := by
  intro p hp
  have h : env8455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8454_8455 : H12AffineEnvironment.transform 13 4825 env8454 = env8455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env8454 == env8455) = true)

theorem identity8455 : scanCanonicalize (H12AffineFastState.compose env8455 (packedSelected [1,3,8,10,12,17] rootPS)) = affineNative (2^(18+1) ^^^ 1927) := by decide +kernel

theorem selectedBound8455 : packedSelected [1,3,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env8456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4825,8833,8615,1344,0,1927,8833,4097,8201,6105,547,8582,5376,9093,4825,1296,8492,1285,4294967296,257,4294976129,1344,782]

theorem envBound8456 : H12AffineFastState.Bounded env8456 := by
  intro p hp
  have h : env8456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8455_8456 : H12AffineEnvironment.transform 18 1927 env8455 = env8456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1927 env8455 == env8456) = true)

theorem identity8456 : scanCanonicalize (H12AffineFastState.compose env8456 (packedSelected [1,3,5,13,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound8456 : packedSelected [1,3,5,13,15,19] rootPS < 2^1333 := by decide +kernel

def env8457 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,4096,8192,4825,8833,8322,1125,0,1698,8833,4097,8201,5884,547,8355,5157,8864,4825,1077,8201,1056,4294967296,36,4294976129,1125,555]

theorem envBound8457 : H12AffineFastState.Bounded env8457 := by
  intro p hp
  have h : env8457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8456_8457 : H12AffineEnvironment.transform 7 37 env8456 = env8457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env8456 == env8457) = true)

theorem identity8457 : scanCanonicalize (H12AffineFastState.compose env8457 (packedSelected [1,2,3,5,6,7,9,10,12,21] rootPS)) = affineNative (2^(11+1) ^^^ 1718) := by decide +kernel

theorem selectedBound8457 : packedSelected [1,2,3,5,6,7,9,10,12,21] rootPS < 2^1333 := by decide +kernel

def env8458 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,1718,8192,1135,8833,8322,1125,0,1698,8833,1719,8201,74,547,8355,659,8864,1135,1077,8201,1056,4294967296,36,4294976129,1125,555]

theorem envBound8458 : H12AffineFastState.Bounded env8458 := by
  intro p hp
  have h : env8458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8457_8458 : H12AffineEnvironment.transform 11 1718 env8457 = env8458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1718 env8457 == env8458) = true)

theorem identity8458 : scanCanonicalize (H12AffineFastState.compose env8458 (packedSelected [1,2,3,4,6,7,8,10,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8458 : packedSelected [1,2,3,4,6,7,8,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env8459 : List Nat := [2,4,8,16,32,64,128,37,137,1024,0,1087,8192,1135,8200,8322,1125,0,1067,8200,1086,8201,74,170,8355,26,8233,1135,1077,8201,1056,4294967296,36,4294975496,1125,162]

theorem envBound8459 : H12AffineFastState.Bounded env8459 := by
  intro p hp
  have h : env8459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8458_8459 : H12AffineEnvironment.transform 8 137 env8458 = env8459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8458 == env8459) = true)

theorem identity8459 : scanCanonicalize (H12AffineFastState.compose env8459 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8459 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8460 : List Nat := [2,4,3,16,32,64,128,37,130,1024,0,1076,8192,1124,8195,8322,1125,0,1056,8195,1077,8194,65,161,8355,17,8226,1124,1077,8194,1056,4294967296,36,4294975491,1125,162]

theorem envBound8460 : H12AffineFastState.Bounded env8460 := by
  intro p hp
  have h : env8460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8459_8460 : H12AffineEnvironment.transform 2 3 env8459 = env8460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8459 == env8460) = true)

theorem identity8460 : scanCanonicalize (H12AffineFastState.compose env8460 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(31+1) ^^^ 8194) := by decide +kernel

theorem selectedBound8460 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8461 : List Nat := [2,4,3,16,32,64,128,37,130,1024,0,1076,8192,1124,8195,8322,1125,0,1056,8195,1077,8194,65,161,8355,17,8226,1124,1077,8194,1056,8194,36,1,1125,162]

theorem envBound8461 : H12AffineFastState.Bounded env8461 := by
  intro p hp
  have h : env8461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8460_8461 : H12AffineEnvironment.transform 31 8194 env8460 = env8461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8194 env8460 == env8461) = true)

theorem identity8461 : scanCanonicalize (H12AffineFastState.compose env8461 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound8461 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8462 : List Nat := [2,4,3,16,32,64,128,37,130,1024,0,1076,2,1124,1,128,1125,0,1056,1,1077,0,65,161,161,17,32,1124,1077,0,1056,0,36,1,1125,162]

theorem envBound8462 : H12AffineFastState.Bounded env8462 := by
  intro p hp
  have h : env8462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8461_8462 : H12AffineEnvironment.transform 12 2 env8461 = env8462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env8461 == env8462) = true)

theorem identity8462 : scanCanonicalize (H12AffineFastState.compose env8462 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound8462 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env8463 : List Nat := [2,4,3,16,32,64,128,37,130,167,0,147,2,195,1,128,194,0,135,1,146,0,65,161,161,17,32,195,146,0,135,0,36,1,194,162]

theorem envBound8463 : H12AffineFastState.Bounded env8463 := by
  intro p hp
  have h : env8463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8462_8463 : H12AffineEnvironment.transform 9 167 env8462 = env8463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env8462 == env8463) = true)

theorem identity8463 : scanCanonicalize (H12AffineFastState.compose env8463 (packedSelected [3,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8463 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env8464 : List Nat := [2,4,3,16,0,64,128,5,130,135,0,147,2,195,1,128,194,0,135,1,146,0,65,129,129,17,0,195,146,0,135,0,4,1,194,130]

theorem envBound8464 : H12AffineFastState.Bounded env8464 := by
  intro p hp
  have h : env8464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8463_8464 : H12AffineEnvironment.transform 4 0 env8463 = env8464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8463 == env8464) = true)

theorem identity8464 : scanCanonicalize (H12AffineFastState.compose env8464 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound8464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8465 : List Nat := [2,4,3,3,0,64,128,5,130,135,0,128,2,195,1,128,194,0,135,1,129,0,65,129,129,2,0,195,129,0,135,0,4,1,194,130]

theorem envBound8465 : H12AffineFastState.Bounded env8465 := by
  intro p hp
  have h : env8465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8464_8465 : H12AffineEnvironment.transform 3 3 env8464 = env8465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env8464 == env8465) = true)

theorem identity8465 : scanCanonicalize (H12AffineFastState.compose env8465 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound8465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8466 : List Nat := [2,4,3,3,0,2,128,5,130,135,0,128,2,129,1,128,128,0,135,1,129,0,3,129,129,2,0,129,129,0,135,0,4,1,128,130]

theorem envBound8466 : H12AffineFastState.Bounded env8466 := by
  intro p hp
  have h : env8466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8465_8466 : H12AffineEnvironment.transform 5 2 env8465 = env8466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env8465 == env8466) = true)

theorem identity8466 : scanCanonicalize (H12AffineFastState.compose env8466 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8466 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8467 : List Nat := [2,4,3,3,0,2,2,5,0,5,0,2,2,3,1,2,2,0,5,1,3,0,3,3,3,2,0,3,3,0,5,0,4,1,2,0]

theorem envBound8467 : H12AffineFastState.Bounded env8467 := by
  intro p hp
  have h : env8467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8466_8467 : H12AffineEnvironment.transform 6 2 env8466 = env8467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8466 == env8467) = true)

def env8468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17664,74629,33554432,5376,2122076,16384,1297,2109740,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8468 : H12AffineFastState.Bounded env8468 := by
  intro p hp
  have h : env8468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8450_8468 : H12AffineEnvironment.transform 16 1345 env8450 = env8468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8450 == env8468) = true)

theorem identity8468 : scanCanonicalize (H12AffineFastState.compose env8468 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8468 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,4097,8201,17664,74629,33554432,5376,29021,16384,1297,8493,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8469 : H12AffineFastState.Bounded env8469 := by
  intro p hp
  have h : env8469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8468_8469 : H12AffineEnvironment.transform 20 4097 env8468 = env8469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8468 == env8469) = true)

theorem identity8469 : scanCanonicalize (H12AffineFastState.compose env8469 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound8469 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,8833,65536,1345,0,524288,8833,4097,8201,712,74629,33554432,5376,13973,1992,1297,8493,1284,4294967296,257,4329123895,1345,33563272]

theorem envBound8470 : H12AffineFastState.Bounded env8470 := by
  intro p hp
  have h : env8470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8469_8470 : H12AffineEnvironment.transform 13 1992 env8469 = env8470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env8469 == env8470) = true)

theorem identity8470 : scanCanonicalize (H12AffineFastState.compose env8470 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 13752) := by decide +kernel

theorem selectedBound8470 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,8833,65536,1345,0,524288,8833,4097,8201,712,74629,13752,5376,13973,1992,1297,8493,1284,4294967296,257,4295558543,1345,5936]

theorem envBound8471 : H12AffineFastState.Bounded env8471 := by
  intro p hp
  have h : env8471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8470_8471 : H12AffineEnvironment.transform 24 13752 env8470 = env8471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 13752 env8470 == env8471) = true)

theorem identity8471 : scanCanonicalize (H12AffineFastState.compose env8471 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound8471 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8472 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,8192,1376,8233,65536,1345,0,524288,8233,4097,8201,96,74029,13752,5376,13373,1376,1297,8493,1284,4294967296,257,4295558543,1345,5528]

theorem envBound8472 : H12AffineFastState.Bounded env8472 := by
  intro p hp
  have h : env8472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8471_8472 : H12AffineEnvironment.transform 8 168 env8471 = env8472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env8471 == env8472) = true)

theorem identity8472 : scanCanonicalize (H12AffineFastState.compose env8472 (packedSelected [1,3,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1329) := by decide +kernel

theorem selectedBound8472 : packedSelected [1,3,10,19] rootPS < 2^1333 := by decide +kernel

def env8473 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1329,8192,1376,8233,65536,1345,0,524288,8233,1328,8201,96,74029,8329,49,8460,1376,1297,8493,1284,4294967296,257,4295558543,1345,169]

theorem envBound8473 : H12AffineFastState.Bounded env8473 := by
  intro p hp
  have h : env8473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8472_8473 : H12AffineEnvironment.transform 11 1329 env8472 = env8473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env8472 == env8473) = true)

theorem identity8473 : scanCanonicalize (H12AffineFastState.compose env8473 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 75174) := by decide +kernel

theorem selectedBound8473 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8474 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1329,8192,1376,8233,65536,1345,0,75174,8233,1328,8201,96,74029,8329,49,8460,1376,1297,8493,1284,4294967296,257,4294975529,1345,169]

theorem envBound8474 : H12AffineFastState.Bounded env8474 := by
  intro p hp
  have h : env8474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8473_8474 : H12AffineEnvironment.transform 18 75174 env8473 = env8474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75174 env8473 == env8474) = true)

theorem identity8474 : scanCanonicalize (H12AffineFastState.compose env8474 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8474 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8475 : List Nat := [2,4,8,16,0,64,128,256,136,1024,0,1297,8192,1344,8201,65536,1345,0,75142,8201,1296,8201,64,73997,8329,17,8460,1344,1297,8461,1284,4294967296,257,4294975497,1345,137]

theorem envBound8475 : H12AffineFastState.Bounded env8475 := by
  intro p hp
  have h : env8475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8474_8475 : H12AffineEnvironment.transform 4 0 env8474 = env8475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8474 == env8475) = true)

theorem identity8475 : scanCanonicalize (H12AffineFastState.compose env8475 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8475 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8476 : List Nat := [2,4,8,16,0,64,128,256,136,1024,0,1297,268,1344,261,65536,1345,0,66698,261,1296,261,64,65537,389,17,0,1344,1297,1,1284,4294967296,257,4294967557,1345,137]

theorem envBound8476 : H12AffineFastState.Bounded env8476 := by
  intro p hp
  have h : env8476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8475_8476 : H12AffineEnvironment.transform 12 268 env8475 = env8476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8475 == env8476) = true)

def env8477 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1045,8,1092,1,65536,1093,0,66698,1,1044,1,64,65537,129,17,0,1092,1045,1,1024,4294967296,5,4294967297,1093,137]

theorem envBound8477 : H12AffineFastState.Bounded env8477 := by
  intro p hp
  have h : env8477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8476_8477 : H12AffineEnvironment.transform 7 4 env8476 = env8477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8476 == env8477) = true)

theorem identity8477 : scanCanonicalize (H12AffineFastState.compose env8477 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound8477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8478 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1045,8,1092,1,65536,1093,0,66698,1,1044,1,64,65537,129,17,0,1092,1045,1,1024,11,5,10,1093,137]

theorem envBound8478 : H12AffineFastState.Bounded env8478 := by
  intro p hp
  have h : env8478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8477_8478 : H12AffineEnvironment.transform 31 11 env8477 = env8478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env8477 == env8478) = true)

theorem identity8478 : scanCanonicalize (H12AffineFastState.compose env8478 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8478 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8479 : List Nat := [2,4,8,16,0,1,128,4,136,1024,0,1045,8,1029,1,65536,1028,0,66698,1,1044,1,1,65537,129,17,0,1029,1045,1,1024,11,5,10,1028,137]

theorem envBound8479 : H12AffineFastState.Bounded env8479 := by
  intro p hp
  have h : env8479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8478_8479 : H12AffineEnvironment.transform 5 1 env8478 = env8479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8478 == env8479) = true)

def env8480 : List Nat := [2,4,8,16,0,1,128,4,136,1024,0,1045,8,1029,1,128,1028,0,1034,1,1044,1,1,129,129,17,0,1029,1045,1,1024,11,5,10,1028,137]

theorem envBound8480 : H12AffineFastState.Bounded env8480 := by
  intro p hp
  have h : env8480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8479_8480 : H12AffineEnvironment.transform 15 128 env8479 = env8480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env8479 == env8480) = true)

def env8481 : List Nat := [2,4,8,16,0,1,24,4,16,1024,0,1045,8,1029,1,24,1028,0,1034,1,1044,1,1,25,25,17,0,1029,1045,1,1024,11,5,10,1028,17]

theorem envBound8481 : H12AffineFastState.Bounded env8481 := by
  intro p hp
  have h : env8481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8480_8481 : H12AffineEnvironment.transform 6 24 env8480 = env8481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env8480 == env8481) = true)

theorem identity8481 : scanCanonicalize (H12AffineFastState.compose env8481 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8482 : List Nat := [2,4,2,16,0,1,18,4,16,1024,0,1045,2,1029,1,18,1028,0,1024,1,1044,1,1,19,19,17,0,1029,1045,1,1024,1,5,0,1028,17]

theorem envBound8482 : H12AffineFastState.Bounded env8482 := by
  intro p hp
  have h : env8482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8481_8482 : H12AffineEnvironment.transform 2 2 env8481 = env8482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8481 == env8482) = true)

def leafEnv8482 : List Nat := [2,4,2,16,0,1,18,4,16,1024,0,1045,2,1029,1,18,1028,0,1024,1,1044,1,1,19,1024,19,1,17,0,1029,1045,1,1024,1,5,0,5,2,1028,17,0,1044,1]

def active8482 : List Nat := [0,1,3,9]

def tree8482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8482 : H12WitnessSearch.Good tree8482 := H12GlobalWitnessIndex.good

theorem leafIdentity8482 : H12AffineFastState.composeSystem env8482 rootObs = leafEnv8482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8482 rootObs == leafEnv8482) = true)

theorem terminalChecked8482 : H12PackedTerminal.terminalCheckFast leafEnv8482 active8482 tree8482 = true := by decide +kernel

def env8483 : List Nat := [2,4,8,16,0,1,25,4,17,1024,0,1045,8,1029,1,25,1028,0,1034,1,1044,1,1,24,24,17,0,1029,1045,1,1024,11,5,10,1028,16]

theorem envBound8483 : H12AffineFastState.Bounded env8483 := by
  intro p hp
  have h : env8483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8480_8483 : H12AffineEnvironment.transform 6 25 env8480 = env8483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env8480 == env8483) = true)

def leafEnv8483 : List Nat := [2,4,8,16,0,1,25,4,17,1024,0,1045,8,1029,1,25,1028,0,1034,1,1044,1,1,24,1034,24,1,17,0,1029,1045,1,1024,11,5,10,5,2,1028,16,0,1044,1]

def active8483 : List Nat := [0,1,2,3,9]

def tree8483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8483 : H12WitnessSearch.Good tree8483 := H12GlobalWitnessIndex.good

theorem leafIdentity8483 : H12AffineFastState.composeSystem env8483 rootObs = leafEnv8483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8483 rootObs == leafEnv8483) = true)

theorem terminalChecked8483 : H12PackedTerminal.terminalCheckFast leafEnv8483 active8483 tree8483 = true := by decide +kernel

def env8484 : List Nat := [2,4,8,16,0,1,128,4,136,1024,0,1045,8,1029,1,129,1028,0,1035,1,1044,1,1,128,129,17,0,1029,1045,1,1024,11,5,10,1028,137]

theorem envBound8484 : H12AffineFastState.Bounded env8484 := by
  intro p hp
  have h : env8484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8479_8484 : H12AffineEnvironment.transform 15 129 env8479 = env8484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env8479 == env8484) = true)

theorem identity8484 : scanCanonicalize (H12AffineFastState.compose env8484 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8484 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8485 : List Nat := [2,4,3,16,0,1,128,4,131,1024,0,1045,3,1029,1,129,1028,0,1024,1,1044,1,1,128,129,17,0,1029,1045,1,1024,0,5,1,1028,130]

theorem envBound8485 : H12AffineFastState.Bounded env8485 := by
  intro p hp
  have h : env8485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8484_8485 : H12AffineEnvironment.transform 2 3 env8484 = env8485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8484 == env8485) = true)

def leafEnv8485 : List Nat := [2,4,3,16,0,1,128,4,131,1024,0,1045,3,1029,1,129,1028,0,1024,1,1044,1,1,128,1024,129,1,17,0,1029,1045,1,1024,0,5,1,5,2,1028,130,0,1044,1]

def active8485 : List Nat := [0,1,3,6,9]

def tree8485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8485 : H12WitnessSearch.Good tree8485 := H12GlobalWitnessIndex.good

theorem leafIdentity8485 : H12AffineFastState.composeSystem env8485 rootObs = leafEnv8485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8485 rootObs == leafEnv8485) = true)

theorem terminalChecked8485 : H12PackedTerminal.terminalCheckFast leafEnv8485 active8485 tree8485 = true := by decide +kernel

def env8486 : List Nat := [2,4,8,16,0,64,128,5,136,1024,0,1044,9,1093,0,65536,1092,0,66698,0,1045,0,64,65537,128,17,0,1093,1044,1,1025,4294967296,4,4294967296,1092,137]

theorem envBound8486 : H12AffineFastState.Bounded env8486 := by
  intro p hp
  have h : env8486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8476_8486 : H12AffineEnvironment.transform 7 5 env8476 = env8486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8476 == env8486) = true)

theorem identity8486 : scanCanonicalize (H12AffineFastState.compose env8486 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65544) := by decide +kernel

theorem selectedBound8486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8487 : List Nat := [2,4,8,16,0,64,128,5,136,1024,0,1044,9,1093,0,65536,1092,0,66698,0,1045,0,64,65537,128,17,0,1093,1044,1,1025,65544,4,65544,1092,137]

theorem envBound8487 : H12AffineFastState.Bounded env8487 := by
  intro p hp
  have h : env8487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8486_8487 : H12AffineEnvironment.transform 31 65544 env8486 = env8487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65544 env8486 == env8487) = true)

theorem identity8487 : scanCanonicalize (H12AffineFastState.compose env8487 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound8487 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8488 : List Nat := [2,4,8,16,0,64,66,5,74,1024,0,1044,9,1093,0,65536,1092,0,66632,0,1045,0,64,65537,66,17,0,1093,1044,1,1025,65544,4,65544,1092,75]

theorem envBound8488 : H12AffineFastState.Bounded env8488 := by
  intro p hp
  have h : env8488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8487_8488 : H12AffineEnvironment.transform 6 66 env8487 = env8488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env8487 == env8488) = true)

theorem identity8488 : scanCanonicalize (H12AffineFastState.compose env8488 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound8488 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8489 : List Nat := [2,4,8,16,0,64,66,5,74,1024,0,1044,9,1093,0,72,1092,0,1024,0,1045,0,64,73,66,17,0,1093,1044,1,1025,64,4,64,1092,75]

theorem envBound8489 : H12AffineFastState.Bounded env8489 := by
  intro p hp
  have h : env8489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8488_8489 : H12AffineEnvironment.transform 15 72 env8488 = env8489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env8488 == env8489) = true)

theorem identity8489 : scanCanonicalize (H12AffineFastState.compose env8489 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound8489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8490 : List Nat := [2,4,8,16,0,26,24,5,16,1024,0,1044,9,1055,0,18,1054,0,1024,0,1045,0,26,19,24,17,0,1055,1044,1,1025,26,4,26,1054,17]

theorem envBound8490 : H12AffineFastState.Bounded env8490 := by
  intro p hp
  have h : env8490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8489_8490 : H12AffineEnvironment.transform 5 26 env8489 = env8490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env8489 == env8490) = true)

def env8491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8201,17664,206532,33554432,5376,2253852,16384,131152,2241645,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8491 : H12AffineFastState.Bounded env8491 := by
  intro p hp
  have h : env8491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8449_8491 : H12AffineEnvironment.transform 17 1 env8449 = env8491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8449 == env8491) = true)

def env8492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17664,74628,33554432,5376,2122076,16384,1296,2109741,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8492 : H12AffineFastState.Bounded env8492 := by
  intro p hp
  have h : env8492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8491_8492 : H12AffineEnvironment.transform 16 1344 env8491 = env8492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8491 == env8492) = true)

theorem identity8492 : scanCanonicalize (H12AffineFastState.compose env8492 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8492 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17664,74628,2647257,5376,2122076,16384,1296,2109741,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8493 : H12AffineFastState.Bounded env8493 := by
  intro p hp
  have h : env8493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8492_8493 : H12AffineEnvironment.transform 24 2647257 env8492 = env8493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8492 == env8493) = true)

theorem identity8493 : scanCanonicalize (H12AffineFastState.compose env8493 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 29566) := by decide +kernel

theorem selectedBound8493 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,29566,1344,1,524288,8833,2097152,8201,17664,20730,2647257,5376,2122076,16384,1296,2109741,1285,4294967296,257,4297089113,1344,2639441]

theorem envBound8494 : H12AffineFastState.Bounded env8494 := by
  intro p hp
  have h : env8494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8493_8494 : H12AffineEnvironment.transform 15 29566 env8493 = env8494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29566 env8493 == env8494) = true)

theorem identity8494 : scanCanonicalize (H12AffineFastState.compose env8494 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8494 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,29566,1344,1,524288,8833,4097,8201,17664,20730,554200,5376,29021,16384,1296,8492,1285,4294967296,257,4294996056,1344,546384]

theorem envBound8495 : H12AffineFastState.Bounded env8495 := by
  intro p hp
  have h : env8495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8494_8495 : H12AffineEnvironment.transform 20 4097 env8494 = env8495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8494 == env8495) = true)

theorem identity8495 : scanCanonicalize (H12AffineFastState.compose env8495 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound8495 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,900,16384,261,20730,1344,1,524288,261,4097,909,17664,20730,546652,5376,21209,16384,1296,680,1285,4294967296,257,4294988764,1344,546384]

theorem envBound8496 : H12AffineFastState.Bounded env8496 := by
  intro p hp
  have h : env8496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8495_8496 : H12AffineEnvironment.transform 12 900 env8495 = env8496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env8495 == env8496) = true)

theorem identity8496 : scanCanonicalize (H12AffineFastState.compose env8496 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(18+1) ^^^ 1056) := by decide +kernel

theorem selectedBound8496 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,900,16384,261,20730,1344,1,1056,261,4097,909,17664,20730,21372,5376,21209,16384,1296,680,1285,4294967296,257,4294988764,1344,21104]

theorem envBound8497 : H12AffineFastState.Bounded env8497 := by
  intro p hp
  have h : env8497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8496_8497 : H12AffineEnvironment.transform 18 1056 env8496 = env8497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1056 env8496 == env8497) = true)

theorem identity8497 : scanCanonicalize (H12AffineFastState.compose env8497 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound8497 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8498 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,4096,40,16384,261,20730,1344,1,1056,261,4097,33,17664,20730,20688,5376,20853,16384,1296,260,1285,4294967296,257,4294987888,1344,20956]

theorem envBound8498 : H12AffineFastState.Bounded env8498 := by
  intro p hp
  have h : env8498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8497_8498 : H12AffineEnvironment.transform 8 428 env8497 = env8498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env8497 == env8498) = true)

theorem identity8498 : scanCanonicalize (H12AffineFastState.compose env8498 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1092) := by decide +kernel

theorem selectedBound8498 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8499 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,4096,40,1092,261,5310,1344,1,1056,261,4097,33,324,5310,5268,5376,5425,1092,1296,260,1285,4294967296,257,4294972468,1344,5528]

theorem envBound8499 : H12AffineFastState.Bounded env8499 := by
  intro p hp
  have h : env8499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8498_8499 : H12AffineEnvironment.transform 13 1092 env8498 = env8499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1092 env8498 == env8499) = true)

theorem identity8499 : scanCanonicalize (H12AffineFastState.compose env8499 (packedSelected [0,1,3,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8499 : packedSelected [0,1,3,7,12,15] rootPS < 2^1333 := by decide +kernel

def env8500 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,4096,40,1092,33,5310,1124,1,1056,33,4097,33,96,5310,5268,5156,5141,1092,1076,32,1057,4294967296,37,4294972468,1124,5308]

theorem envBound8500 : H12AffineFastState.Bounded env8500 := by
  intro p hp
  have h : env8500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8499_8500 : H12AffineEnvironment.transform 7 36 env8499 = env8500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8499 == env8500) = true)

theorem identity8500 : scanCanonicalize (H12AffineFastState.compose env8500 (packedSelected [1,3,10,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8500 : packedSelected [1,3,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env8501 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,4096,40,1045,33,5310,1077,1,1056,33,4097,33,49,5310,5268,5156,5141,1045,1076,32,1057,4294967296,37,4294972468,1077,5308]

theorem envBound8501 : H12AffineFastState.Bounded env8501 := by
  intro p hp
  have h : env8501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8500_8501 : H12AffineEnvironment.transform 5 17 env8500 = env8501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8500 == env8501) = true)

theorem identity8501 : scanCanonicalize (H12AffineFastState.compose env8501 (packedSelected [5,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8501 : packedSelected [5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8502 : List Nat := [2,4,8,16,10,17,128,14,136,1024,0,4096,2,1045,11,5268,1055,1,1034,11,4097,11,27,5268,5268,5134,5141,1045,1054,10,1035,4294967296,15,4294972446,1055,5270]

theorem envBound8502 : H12AffineFastState.Bounded env8502 := by
  intro p hp
  have h : env8502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8501_8502 : H12AffineEnvironment.transform 4 10 env8501 = env8502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8501 == env8502) = true)

theorem identity8502 : scanCanonicalize (H12AffineFastState.compose env8502 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(31+1) ^^^ 4243) := by decide +kernel

theorem selectedBound8502 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8503 : List Nat := [2,4,8,16,10,17,128,14,136,1024,0,4096,2,1045,11,5268,1055,1,1034,11,4097,11,27,5268,5268,5134,5141,1045,1054,10,1035,4243,15,1165,1055,5270]

theorem envBound8503 : H12AffineFastState.Bounded env8503 := by
  intro p hp
  have h : env8503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8502_8503 : H12AffineEnvironment.transform 31 4243 env8502 = env8503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4243 env8502 == env8503) = true)

theorem identity8503 : scanCanonicalize (H12AffineFastState.compose env8503 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound8503 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8504 : List Nat := [2,4,8,16,10,17,128,14,136,1024,0,1054,2,1045,11,138,1055,1,1034,11,1055,11,27,138,138,16,11,1045,1054,10,1035,1165,15,1165,1055,136]

theorem envBound8504 : H12AffineFastState.Bounded env8504 := by
  intro p hp
  have h : env8504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8503_8504 : H12AffineEnvironment.transform 11 1054 env8503 = env8504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env8503 == env8504) = true)

theorem identity8504 : scanCanonicalize (H12AffineFastState.compose env8504 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 28) := by decide +kernel

theorem selectedBound8504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8505 : List Nat := [2,4,8,16,10,17,128,14,136,28,0,2,2,9,11,138,3,1,22,11,3,11,27,138,138,16,11,9,2,10,23,145,15,145,3,136]

theorem envBound8505 : H12AffineFastState.Bounded env8505 := by
  intro p hp
  have h : env8505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8504_8505 : H12AffineEnvironment.transform 9 28 env8504 = env8505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 28 env8504 == env8505) = true)

theorem identity8505 : scanCanonicalize (H12AffineFastState.compose env8505 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound8505 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8506 : List Nat := [2,4,8,16,10,17,3,14,11,28,0,2,2,9,11,9,3,1,22,11,3,11,27,9,9,16,11,9,2,10,23,18,15,18,3,11]

theorem envBound8506 : H12AffineFastState.Bounded env8506 := by
  intro p hp
  have h : env8506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8505_8506 : H12AffineEnvironment.transform 6 3 env8505 = env8506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env8505 == env8506) = true)

theorem identity8506 : scanCanonicalize (H12AffineFastState.compose env8506 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound8506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8507 : List Nat := [2,4,8,2,10,3,3,14,11,14,0,2,2,9,11,9,3,1,4,11,3,11,9,9,9,2,11,9,2,10,5,0,15,0,3,11]

theorem envBound8507 : H12AffineFastState.Bounded env8507 := by
  intro p hp
  have h : env8507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8506_8507 : H12AffineEnvironment.transform 3 2 env8506 = env8507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env8506 == env8507) = true)

theorem identity8507 : scanCanonicalize (H12AffineFastState.compose env8507 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8507 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8508 : List Nat := [2,4,2,2,0,3,3,4,1,4,0,2,2,3,1,3,3,1,4,1,3,1,3,3,3,2,1,3,2,0,5,0,5,0,3,1]

theorem envBound8508 : H12AffineFastState.Bounded env8508 := by
  intro p hp
  have h : env8508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8507_8508 : H12AffineEnvironment.transform 2 2 env8507 = env8508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8507 == env8508) = true)

def leafEnv8508 : List Nat := [2,4,2,2,0,3,3,4,1,4,0,2,2,3,1,3,3,1,4,1,3,1,3,3,5,3,1,2,1,3,2,0,5,0,5,0,5,2,3,1,0,3,1]

def active8508 : List Nat := [0,1]

def tree8508 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8508 : H12WitnessSearch.Good tree8508 := H12GlobalWitnessIndex.good

theorem leafIdentity8508 : H12AffineFastState.composeSystem env8508 rootObs = leafEnv8508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8508 rootObs == leafEnv8508) = true)

theorem terminalChecked8508 : H12PackedTerminal.terminalCheckFast leafEnv8508 active8508 tree8508 = true := by decide +kernel

def env8509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17664,74629,33554432,5376,2122077,16384,1297,2109740,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8509 : H12AffineFastState.Bounded env8509 := by
  intro p hp
  have h : env8509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8491_8509 : H12AffineEnvironment.transform 16 1345 env8491 = env8509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8491 == env8509) = true)

theorem identity8509 : scanCanonicalize (H12AffineFastState.compose env8509 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8509 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,4097,8201,17664,74629,33554432,5376,29020,16384,1297,8493,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8510 : H12AffineFastState.Bounded env8510 := by
  intro p hp
  have h : env8510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8509_8510 : H12AffineEnvironment.transform 20 4097 env8509 = env8510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8509 == env8510) = true)

theorem identity8510 : scanCanonicalize (H12AffineFastState.compose env8510 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5780) := by decide +kernel

theorem selectedBound8510 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,16384,5141,65536,1345,1,524288,5141,4097,5789,17664,70929,33554432,5376,18376,16384,1297,6073,1284,4294967296,257,4329128299,1345,33559580]

theorem envBound8511 : H12AffineFastState.Bounded env8511 := by
  intro p hp
  have h : env8511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8510_8511 : H12AffineEnvironment.transform 12 5780 env8510 = env8511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5780 env8510 == env8511) = true)

theorem identity8511 : scanCanonicalize (H12AffineFastState.compose env8511 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 17637) := by decide +kernel

theorem selectedBound8511 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,16384,5141,65536,1345,1,524288,5141,4097,5789,17664,70929,17637,5376,18376,16384,1297,6073,1284,4294967296,257,4295558542,1345,20729]

theorem envBound8512 : H12AffineFastState.Bounded env8512 := by
  intro p hp
  have h : env8512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8511_8512 : H12AffineEnvironment.transform 24 17637 env8511 = env8512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17637 env8511 == env8512) = true)

theorem identity8512 : scanCanonicalize (H12AffineFastState.compose env8512 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8512 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,4176,5141,65536,1345,1,524288,5141,4097,5789,5456,70929,5301,5376,6040,4176,1297,6073,1284,4294967296,257,4295558542,1345,169]

theorem envBound8513 : H12AffineFastState.Bounded env8513 := by
  intro p hp
  have h : env8513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8512_8513 : H12AffineEnvironment.transform 13 4176 env8512 = env8513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8512 == env8513) = true)

theorem identity8513 : scanCanonicalize (H12AffineFastState.compose env8513 (packedSelected [0,1,3,4,7,10,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 5530) := by decide +kernel

theorem selectedBound8513 : packedSelected [0,1,3,4,7,10,19,22,23] rootPS < 2^1333 := by decide +kernel

def env8514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,4176,5141,5530,1345,1,524288,5141,4097,5789,5456,139,5301,5376,6040,4176,1297,6073,1284,4294967296,257,4295495700,1345,169]

theorem envBound8514 : H12AffineFastState.Bounded env8514 := by
  intro p hp
  have h : env8514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8513_8514 : H12AffineEnvironment.transform 15 5530 env8513 = env8514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5530 env8513 == env8514) = true)

theorem identity8514 : scanCanonicalize (H12AffineFastState.compose env8514 (packedSelected [0,3,4,7,9,12,13,15,21,24] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8514 : packedSelected [0,3,4,7,9,12,13,15,21,24] rootPS < 2^1333 := by decide +kernel

def env8515 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4176,5141,5530,1345,1,524288,5141,4097,5140,5456,139,5301,5376,5393,4176,1297,5424,1284,4294967296,257,4295495700,1345,169]

theorem envBound8515 : H12AffineFastState.Bounded env8515 := by
  intro p hp
  have h : env8515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8514_8515 : H12AffineEnvironment.transform 8 137 env8514 = env8515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8514 == env8515) = true)

theorem identity8515 : scanCanonicalize (H12AffineFastState.compose env8515 (packedSelected [0,4,7,8,9,10,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound8515 : packedSelected [0,4,7,8,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env8516 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1328,301,1376,293,170,1345,1,524288,293,1329,292,96,139,389,48,33,1376,1297,0,1284,4294967296,257,4295492900,1345,169]

theorem envBound8516 : H12AffineFastState.Bounded env8516 := by
  intro p hp
  have h : env8516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8515_8516 : H12AffineEnvironment.transform 11 1328 env8515 = env8516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env8515 == env8516) = true)

theorem identity8516 : scanCanonicalize (H12AffineFastState.compose env8516 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8516 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8517 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,1297,268,1345,260,139,1345,1,524288,260,1296,261,65,139,389,17,0,1345,1297,0,1284,4294967296,257,4295492869,1345,136]

theorem envBound8517 : H12AffineFastState.Bounded env8517 := by
  intro p hp
  have h : env8517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8516_8517 : H12AffineEnvironment.transform 4 1 env8516 = env8517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8516 == env8517) = true)

def env8518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17664,206532,33554432,5376,2515996,16384,131152,1073741824,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8518 : H12AffineFastState.Bounded env8518 := by
  intro p hp
  have h : env8518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8447_8518 : H12AffineEnvironment.transform 10 1 env8447 = env8518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8447 == env8518) = true)

theorem identity8518 : scanCanonicalize (H12AffineFastState.compose env8518 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 33969693) := by decide +kernel

theorem selectedBound8518 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17664,206532,33554432,5376,2515996,16384,131152,33969693,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8519 : H12AffineFastState.Bounded env8519 := by
  intro p hp
  have h : env8519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8518_8519 : H12AffineEnvironment.transform 29 33969693 env8518 = env8519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33969693 env8518 == env8519) = true)

def env8520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8200,17664,206532,33554432,5376,2253852,16384,131152,33707549,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8520 : H12AffineFastState.Bounded env8520 := by
  intro p hp
  have h : env8520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8519_8520 : H12AffineEnvironment.transform 17 0 env8519 = env8520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8519 == env8520) = true)

def env8521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,16496,8200,17664,206532,33554432,5376,140396,16384,131152,33707549,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8521 : H12AffineFastState.Bounded env8521 := by
  intro p hp
  have h : env8521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8520_8521 : H12AffineEnvironment.transform 20 16496 env8520 = env8521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16496 env8520 == env8521) = true)

theorem identity8521 : scanCanonicalize (H12AffineFastState.compose env8521 (packedSelected [6,10,12,13,15,16,17,18,19,20,21,23,25,26,31,32,33,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8521 : packedSelected [6,10,12,13,15,16,17,18,19,20,21,23,25,26,31,32,33,38,41] rootPS < 2^1333 := by decide +kernel

def env8522 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,131072,0,524288,8200,16496,8200,17664,205901,33554432,5376,140396,16384,131152,33707156,131141,4294967296,257,4329271350,131072,33562625]

theorem envBound8522 : H12AffineFastState.Bounded env8522 := by
  intro p hp
  have h : env8522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8521_8522 : H12AffineEnvironment.transform 8 137 env8521 = env8522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8521 == env8522) = true)

def env8523 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,131072,0,1024,8200,16496,8200,17664,205901,33554432,5376,140396,16384,131152,33707156,131141,4294967296,257,4328748086,131072,33562625]

theorem envBound8523 : H12AffineFastState.Bounded env8523 := by
  intro p hp
  have h : env8523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8522_8523 : H12AffineEnvironment.transform 18 1024 env8522 = env8523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8522 == env8523) = true)

theorem identity8523 : scanCanonicalize (H12AffineFastState.compose env8523 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(24+1) ^^^ 197711) := by decide +kernel

theorem selectedBound8523 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8524 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,131072,0,1024,8200,16496,8200,17664,205901,197711,5376,140396,16384,131152,86235,131141,4294967296,257,4294996089,131072,205902]

theorem envBound8524 : H12AffineFastState.Bounded env8524 := by
  intro p hp
  have h : env8524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8523_8524 : H12AffineEnvironment.transform 24 197711 env8523 = env8524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 197711 env8523 == env8524) = true)

theorem identity8524 : scanCanonicalize (H12AffineFastState.compose env8524 (packedSelected [0,1,4,5,6,7,8,17,18,21,22,23,24,25] rootPS)) = affineNative (2^(16+1) ^^^ 95383) := by decide +kernel

theorem selectedBound8524 : packedSelected [0,1,4,5,6,7,8,17,18,21,22,23,24,25] rootPS < 2^1333 := by decide +kernel

def env8525 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,95383,0,1024,8200,16496,8200,17664,20698,28888,5376,86267,16384,95431,86235,95442,4294967296,257,4294996089,95383,20697]

theorem envBound8525 : H12AffineFastState.Bounded env8525 := by
  intro p hp
  have h : env8525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8524_8525 : H12AffineEnvironment.transform 16 95383 env8524 = env8525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 95383 env8524 == env8525) = true)

theorem identity8525 : scanCanonicalize (H12AffineFastState.compose env8525 (packedSelected [1,3,5,8,10,17,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound8525 : packedSelected [1,3,5,8,10,17,21,26] rootPS < 2^1333 := by decide +kernel

def env8526 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4209,8200,65536,74982,0,1024,8200,4097,8200,5489,171,8361,5376,65674,4209,74934,65706,74915,4294967296,257,4294975496,74982,168]

theorem envBound8526 : H12AffineFastState.Bounded env8526 := by
  intro p hp
  have h : env8526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8525_8526 : H12AffineEnvironment.transform 13 4209 env8525 = env8526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env8525 == env8526) = true)

theorem identity8526 : scanCanonicalize (H12AffineFastState.compose env8526 (packedSelected [0,1,4,7,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound8526 : packedSelected [0,1,4,7,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env8527 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5149,4209,5141,65536,69883,0,1024,5141,4097,5141,5489,171,5300,5376,65674,4209,69803,65706,69822,4294967296,257,4294972437,69883,168]

theorem envBound8527 : H12AffineFastState.Bounded env8527 := by
  intro p hp
  have h : env8527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8526_8527 : H12AffineEnvironment.transform 12 5149 env8526 = env8527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env8526 == env8527) = true)

theorem identity8527 : scanCanonicalize (H12AffineFastState.compose env8527 (packedSelected [0,4,7,9,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 5530) := by decide +kernel

theorem selectedBound8527 : packedSelected [0,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env8528 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5149,4209,5141,5530,1377,0,1024,5141,4097,5141,5489,171,5300,5376,5392,4209,1329,5424,1316,4294967296,257,4294972437,1377,168]

theorem envBound8528 : H12AffineFastState.Bounded env8528 := by
  intro p hp
  have h : env8528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8527_8528 : H12AffineEnvironment.transform 15 5530 env8527 = env8528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5530 env8527 == env8528) = true)

theorem identity8528 : scanCanonicalize (H12AffineFastState.compose env8528 (packedSelected [0,1,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound8528 : packedSelected [0,1,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8529 : List Nat := [2,4,8,16,32,49,128,256,137,1024,1,4096,5149,4096,5141,5530,1296,0,1024,5141,4097,5141,5376,171,5300,5376,5392,4096,1329,5424,1316,4294967296,257,4294972437,1296,168]

theorem envBound8529 : H12AffineFastState.Bounded env8529 := by
  intro p hp
  have h : env8529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8528_8529 : H12AffineEnvironment.transform 5 49 env8528 = env8529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env8528 == env8529) = true)

theorem identity8529 : scanCanonicalize (H12AffineFastState.compose env8529 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound8529 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8530 : List Nat := [2,4,8,16,32,49,128,256,137,1024,1,1076,41,1076,33,430,1296,0,1024,33,1077,33,308,171,128,308,292,1076,1329,260,1316,4294967296,257,4294967329,1296,168]

theorem envBound8530 : H12AffineFastState.Bounded env8530 := by
  intro p hp
  have h : env8530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8529_8530 : H12AffineEnvironment.transform 11 1076 env8529 = env8530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env8529 == env8530) = true)

theorem identity8530 : scanCanonicalize (H12AffineFastState.compose env8530 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8530 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env8531 : List Nat := [2,4,8,16,1,16,128,256,137,1024,1,1045,8,1045,0,399,1296,0,1024,0,1044,0,277,138,128,277,261,1045,1296,260,1285,4294967296,257,4294967296,1296,137]

theorem envBound8531 : H12AffineFastState.Bounded env8531 := by
  intro p hp
  have h : env8531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8530_8531 : H12AffineEnvironment.transform 4 1 env8530 = env8531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8530 == env8531) = true)

theorem identity8531 : scanCanonicalize (H12AffineFastState.compose env8531 (packedSelected [0,1] rootPS)) = affineNative (2^(31+1) ^^^ 1299) := by decide +kernel

theorem selectedBound8531 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8532 : List Nat := [2,4,8,16,1,16,128,256,137,1024,1,1045,8,1045,0,399,1296,0,1024,0,1044,0,277,138,128,277,261,1045,1296,260,1285,1299,257,1299,1296,137]

theorem envBound8532 : H12AffineFastState.Bounded env8532 := by
  intro p hp
  have h : env8532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8531_8532 : H12AffineEnvironment.transform 31 1299 env8531 = env8532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1299 env8531 == env8532) = true)

theorem identity8532 : scanCanonicalize (H12AffineFastState.compose env8532 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 22) := by decide +kernel

theorem selectedBound8532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8533 : List Nat := [2,4,8,16,1,16,128,256,137,22,1,3,8,3,0,399,262,0,22,0,2,0,277,138,128,277,261,3,262,260,275,261,257,261,262,137]

theorem envBound8533 : H12AffineFastState.Bounded env8533 := by
  intro p hp
  have h : env8533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8532_8533 : H12AffineEnvironment.transform 9 22 env8532 = env8533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 22 env8532 == env8533) = true)

theorem identity8533 : scanCanonicalize (H12AffineFastState.compose env8533 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound8533 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env8534 : List Nat := [2,4,8,16,1,16,9,256,0,22,1,3,8,3,0,262,262,0,22,0,2,0,277,3,9,277,261,3,262,260,275,261,257,261,262,0]

theorem envBound8534 : H12AffineFastState.Bounded env8534 := by
  intro p hp
  have h : env8534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8533_8534 : H12AffineEnvironment.transform 6 9 env8533 = env8534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8533 == env8534) = true)

theorem identity8534 : scanCanonicalize (H12AffineFastState.compose env8534 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound8534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8535 : List Nat := [2,4,8,3,1,3,9,256,0,5,1,3,8,3,0,262,262,0,5,0,2,0,262,3,9,262,261,3,262,260,256,261,257,261,262,0]

theorem envBound8535 : H12AffineFastState.Bounded env8535 := by
  intro p hp
  have h : env8535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8534_8535 : H12AffineEnvironment.transform 3 3 env8534 = env8535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env8534 == env8535) = true)

theorem identity8535 : scanCanonicalize (H12AffineFastState.compose env8535 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound8535 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8536 : List Nat := [2,4,8,3,1,3,9,14,0,5,1,3,8,3,0,8,8,0,5,0,2,0,8,3,9,8,11,3,8,10,14,11,15,11,8,0]

theorem envBound8536 : H12AffineFastState.Bounded env8536 := by
  intro p hp
  have h : env8536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8535_8536 : H12AffineEnvironment.transform 7 14 env8535 = env8536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env8535 == env8536) = true)

theorem identity8536 : scanCanonicalize (H12AffineFastState.compose env8536 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8536 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8537 : List Nat := [2,4,2,3,1,3,3,4,0,5,1,3,2,3,0,2,2,0,5,0,2,0,2,3,3,2,1,3,2,0,4,1,5,1,2,0]

theorem envBound8537 : H12AffineFastState.Bounded env8537 := by
  intro p hp
  have h : env8537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8536_8537 : H12AffineEnvironment.transform 2 2 env8536 = env8537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8536 == env8537) = true)

def env8538 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,131072,0,1025,8200,16496,8200,17664,205901,33554432,5376,140396,16384,131152,33707156,131141,4294967296,257,4328748087,131072,33562625]

theorem envBound8538 : H12AffineFastState.Bounded env8538 := by
  intro p hp
  have h : env8538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8522_8538 : H12AffineEnvironment.transform 18 1025 env8522 = env8538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8522 == env8538) = true)

theorem identity8538 : scanCanonicalize (H12AffineFastState.compose env8538 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(24+1) ^^^ 197742) := by decide +kernel

theorem selectedBound8538 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8539 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,131072,0,1025,8200,16496,8200,17664,205901,197742,5376,140396,16384,131152,86266,131141,4294967296,257,4294996057,131072,205935]

theorem envBound8539 : H12AffineFastState.Bounded env8539 := by
  intro p hp
  have h : env8539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8538_8539 : H12AffineEnvironment.transform 24 197742 env8538 = env8539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 197742 env8538 == env8539) = true)

def env8540 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,1124,0,1025,8200,16496,8200,17664,73769,65546,5376,8200,16384,1076,86266,1057,4294967296,257,4294996057,1124,73739]

theorem envBound8540 : H12AffineFastState.Bounded env8540 := by
  intro p hp
  have h : env8540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8539_8540 : H12AffineEnvironment.transform 16 1124 env8539 = env8540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1124 env8539 == env8540) = true)

theorem identity8540 : scanCanonicalize (H12AffineFastState.compose env8540 (packedSelected [6,16,18,20,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound8540 : packedSelected [6,16,18,20,23,25] rootPS < 2^1333 := by decide +kernel

def env8541 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4209,8200,65536,1124,0,1025,8200,4097,8200,5489,73769,65546,5376,8200,4209,1076,65675,1057,4294967296,257,4294975528,1124,73739]

theorem envBound8541 : H12AffineFastState.Bounded env8541 := by
  intro p hp
  have h : env8541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8540_8541 : H12AffineEnvironment.transform 13 4209 env8540 = env8541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env8540 == env8541) = true)

theorem identity8541 : scanCanonicalize (H12AffineFastState.compose env8541 (packedSelected [1,3,5,8,12,13,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8541 : packedSelected [1,3,5,8,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env8542 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4209,8200,8323,1124,0,1025,8200,4097,8200,5489,170,8329,5376,8200,4209,1076,8200,1057,4294967296,257,4294975528,1124,136]

theorem envBound8542 : H12AffineFastState.Bounded env8542 := by
  intro p hp
  have h : env8542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8541_8542 : H12AffineEnvironment.transform 15 8323 env8541 = env8542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8541 == env8542) = true)

theorem identity8542 : scanCanonicalize (H12AffineFastState.compose env8542 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 5181) := by decide +kernel

theorem selectedBound8542 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8543 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5181,4209,5173,5310,1124,0,1025,5173,4097,5173,5489,170,5300,5376,5173,4209,1076,5173,1057,4294967296,257,4294972437,1124,136]

theorem envBound8543 : H12AffineFastState.Bounded env8543 := by
  intro p hp
  have h : env8543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8542_8543 : H12AffineEnvironment.transform 12 5181 env8542 = env8543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env8542 == env8543) = true)

theorem identity8543 : scanCanonicalize (H12AffineFastState.compose env8543 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound8543 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env8544 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,4096,5181,4209,5173,5310,1124,0,1025,5173,4097,5173,5204,170,5300,5157,5173,4209,1076,5173,1057,4294967296,36,4294972437,1124,136]

theorem envBound8544 : H12AffineFastState.Bounded env8544 := by
  intro p hp
  have h : env8544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8543_8544 : H12AffineEnvironment.transform 7 37 env8543 = env8544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env8543 == env8544) = true)

theorem identity8544 : scanCanonicalize (H12AffineFastState.compose env8544 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(31+1) ^^^ 211) := by decide +kernel

theorem selectedBound8544 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env8545 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,4096,5181,4209,5173,5310,1124,0,1025,5173,4097,5173,5204,170,5300,5157,5173,4209,1076,5173,1057,211,36,5318,1124,136]

end H12CloudChart2