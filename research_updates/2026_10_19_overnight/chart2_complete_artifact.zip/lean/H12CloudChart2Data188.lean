import H12CloudChart2Data187

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound47203 : H12AffineFastState.Bounded env47203 := by
  intro p hp
  have h : env47203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47202_47203 : H12AffineEnvironment.transform 5 1 env47202 = env47203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47202 == env47203) = true)

theorem identity47203 : scanCanonicalize (H12AffineFastState.compose env47203 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound47203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47204 : List Nat := [2,4,5,1,6,1,1,4,1,4,2,1,5,1,1,4,0,4,4,0,0,5,0,4,1,1,0,0,1,4,4,1,4,1,0,0]

theorem envBound47204 : H12AffineFastState.Bounded env47204 := by
  intro p hp
  have h : env47204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47203_47204 : H12AffineEnvironment.transform 10 2 env47203 = env47204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env47203 == env47204) = true)

theorem identity47204 : scanCanonicalize (H12AffineFastState.compose env47204 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47205 : List Nat := [2,2,3,1,0,1,1,2,1,2,2,1,3,1,1,2,0,2,2,0,0,3,0,2,1,1,0,0,1,2,2,1,2,1,0,0]

theorem envBound47205 : H12AffineFastState.Bounded env47205 := by
  intro p hp
  have h : env47205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47204_47205 : H12AffineEnvironment.transform 1 2 env47204 = env47205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47204 == env47205) = true)

theorem identity47205 : scanCanonicalize (H12AffineFastState.compose env47205 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47206 : List Nat := [0,0,1,1,0,1,1,0,1,0,0,1,1,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,0,1,0,1,0,0]

theorem envBound47206 : H12AffineFastState.Bounded env47206 := by
  intro p hp
  have h : env47206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47205_47206 : H12AffineEnvironment.transform 0 0 env47205 = env47206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47205 == env47206) = true)

def env47207 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,126,81,306,257,81,384,336,307,17,477,64,257,231,0,303,1,81,2404,114,17,256,119,0,325]

theorem envBound47207 : H12AffineFastState.Bounded env47207 := by
  intro p hp
  have h : env47207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47196_47207 : H12AffineEnvironment.transform 15 257 env47196 = env47207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env47196 == env47207) = true)

theorem identity47207 : scanCanonicalize (H12AffineFastState.compose env47207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 114) := by decide +kernel

theorem selectedBound47207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47208 : List Nat := [2,4,8,16,32,64,128,114,39,51,2048,16,126,81,64,115,81,242,34,65,17,175,64,115,231,0,93,1,81,2070,114,17,114,119,0,55]

theorem envBound47208 : H12AffineFastState.Bounded env47208 := by
  intro p hp
  have h : env47208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47207_47208 : H12AffineEnvironment.transform 7 114 env47207 = env47208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 114 env47207 == env47208) = true)

theorem identity47208 : scanCanonicalize (H12AffineFastState.compose env47208 (packedSelected [0,1,5,7,8,10,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound47208 : packedSelected [0,1,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env47209 : List Nat := [2,4,8,16,32,64,128,114,39,51,123,16,126,81,64,115,81,242,34,65,17,175,64,115,231,0,93,1,81,109,114,17,114,119,0,55]

theorem envBound47209 : H12AffineFastState.Bounded env47209 := by
  intro p hp
  have h : env47209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47208_47209 : H12AffineEnvironment.transform 10 123 env47208 = env47209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env47208 == env47209) = true)

theorem identity47209 : scanCanonicalize (H12AffineFastState.compose env47209 (packedSelected [0,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 79) := by decide +kernel

theorem selectedBound47209 : packedSelected [0,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env47210 : List Nat := [2,4,8,16,32,64,79,114,39,51,123,16,126,81,64,115,81,61,34,65,17,96,64,115,40,0,93,1,81,109,114,17,114,119,0,55]

theorem envBound47210 : H12AffineFastState.Bounded env47210 := by
  intro p hp
  have h : env47210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47209_47210 : H12AffineEnvironment.transform 6 79 env47209 = env47210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 79 env47209 == env47210) = true)

theorem identity47210 : scanCanonicalize (H12AffineFastState.compose env47210 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound47210 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env47211 : List Nat := [2,4,8,16,32,11,4,57,39,51,48,16,53,26,11,56,26,61,34,10,17,43,11,56,40,0,22,1,26,38,57,17,57,60,0,55]

theorem envBound47211 : H12AffineFastState.Bounded env47211 := by
  intro p hp
  have h : env47211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47210_47211 : H12AffineEnvironment.transform 5 11 env47210 = env47211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env47210 == env47211) = true)

theorem identity47211 : scanCanonicalize (H12AffineFastState.compose env47211 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47211 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env47212 : List Nat := [2,4,8,16,17,11,4,8,22,2,1,16,4,26,11,9,26,12,19,10,17,26,11,9,25,0,22,1,26,23,8,17,8,13,0,6]

theorem envBound47212 : H12AffineFastState.Bounded env47212 := by
  intro p hp
  have h : env47212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47211_47212 : H12AffineEnvironment.transform 4 17 env47211 = env47212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47211 == env47212) = true)

theorem identity47212 : scanCanonicalize (H12AffineFastState.compose env47212 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47212 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47213 : List Nat := [2,4,4,16,17,7,4,4,22,2,1,16,4,22,7,5,22,0,19,6,17,22,7,5,21,0,22,1,22,23,4,17,4,1,0,6]

theorem envBound47213 : H12AffineFastState.Bounded env47213 := by
  intro p hp
  have h : env47213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47212_47213 : H12AffineEnvironment.transform 2 4 env47212 = env47213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47212 == env47213) = true)

def env47214 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,81,8525,65536,74030,65665,337,8524,16,477,74047,65537,8344,74110,302,74110,81,75802,8204,74094,256,8201,0,324]

theorem envBound47214 : H12AffineFastState.Bounded env47214 := by
  intro p hp
  have h : env47214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47194_47214 : H12AffineEnvironment.transform 11 17 env47194 = env47214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47194 == env47214) = true)

theorem identity47214 : scanCanonicalize (H12AffineFastState.compose env47214 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound47214 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47215 : List Nat := [2,4,8,16,22,64,128,256,341,321,2048,17,8192,81,8525,65536,74008,65665,337,8524,16,477,73993,65537,8344,74056,280,74056,81,75802,8204,74072,256,8201,0,324]

theorem envBound47215 : H12AffineFastState.Bounded env47215 := by
  intro p hp
  have h : env47215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47214_47215 : H12AffineEnvironment.transform 4 22 env47214 = env47215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env47214 == env47215) = true)

def env47216 : List Nat := [2,4,8,0,6,64,128,256,325,321,2048,1,8192,65,8525,65536,73992,65665,321,8524,0,461,73993,65537,8328,74056,264,74056,65,75786,8204,74056,256,8201,0,324]

theorem envBound47216 : H12AffineFastState.Bounded env47216 := by
  intro p hp
  have h : env47216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47215_47216 : H12AffineEnvironment.transform 3 0 env47215 = env47216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47215 == env47216) = true)

theorem identity47216 : scanCanonicalize (H12AffineFastState.compose env47216 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47216 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47217 : List Nat := [2,4,8,0,6,64,128,256,325,321,2048,1,268,65,65,65536,65540,65665,321,64,0,461,65541,65537,388,65604,264,65604,65,67846,256,65604,256,261,0,324]

theorem envBound47217 : H12AffineFastState.Bounded env47217 := by
  intro p hp
  have h : env47217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47216_47217 : H12AffineEnvironment.transform 12 268 env47216 = env47217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47216 == env47217) = true)

theorem identity47217 : scanCanonicalize (H12AffineFastState.compose env47217 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 257) := by decide +kernel

theorem selectedBound47217 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47218 : List Nat := [2,4,8,0,6,64,128,256,325,321,2048,1,268,65,65,257,261,384,321,64,0,461,260,256,388,325,264,325,65,2055,256,325,256,261,0,324]

theorem envBound47218 : H12AffineFastState.Bounded env47218 := by
  intro p hp
  have h : env47218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47217_47218 : H12AffineEnvironment.transform 15 257 env47217 = env47218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env47217 == env47218) = true)

theorem identity47218 : scanCanonicalize (H12AffineFastState.compose env47218 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47218 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47219 : List Nat := [2,4,8,0,6,1,128,256,260,256,2048,1,268,0,0,257,261,384,256,1,0,396,260,256,388,260,264,260,0,2055,256,260,256,261,0,261]

theorem envBound47219 : H12AffineFastState.Bounded env47219 := by
  intro p hp
  have h : env47219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47218_47219 : H12AffineEnvironment.transform 5 1 env47218 = env47219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47218 == env47219) = true)

theorem identity47219 : scanCanonicalize (H12AffineFastState.compose env47219 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47219 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47220 : List Nat := [2,4,8,0,6,1,128,4,0,4,2048,1,8,0,0,5,1,132,4,1,0,136,0,4,128,0,12,0,0,2055,4,0,4,1,0,1]

theorem envBound47220 : H12AffineFastState.Bounded env47220 := by
  intro p hp
  have h : env47220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47219_47220 : H12AffineEnvironment.transform 7 4 env47219 = env47220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47219 == env47220) = true)

theorem identity47220 : scanCanonicalize (H12AffineFastState.compose env47220 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47220 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47221 : List Nat := [2,4,4,0,6,1,128,4,0,4,2048,1,4,0,0,5,1,132,4,1,0,132,0,4,128,0,0,0,0,2055,4,0,4,1,0,1]

theorem envBound47221 : H12AffineFastState.Bounded env47221 := by
  intro p hp
  have h : env47221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47220_47221 : H12AffineEnvironment.transform 2 4 env47220 = env47221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47220 == env47221) = true)

theorem identity47221 : scanCanonicalize (H12AffineFastState.compose env47221 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47221 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47222 : List Nat := [2,1,1,0,3,1,128,1,0,1,2048,1,1,0,0,0,1,129,1,1,0,129,0,1,128,0,0,0,0,2050,1,0,1,1,0,1]

theorem envBound47222 : H12AffineFastState.Bounded env47222 := by
  intro p hp
  have h : env47222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47221_47222 : H12AffineEnvironment.transform 1 1 env47221 = env47222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47221 == env47222) = true)

theorem identity47222 : scanCanonicalize (H12AffineFastState.compose env47222 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47222 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47223 : List Nat := [0,1,1,0,1,1,128,1,0,1,2048,1,1,0,0,0,1,129,1,1,0,129,0,1,128,0,0,0,0,2048,1,0,1,1,0,1]

theorem envBound47223 : H12AffineFastState.Bounded env47223 := by
  intro p hp
  have h : env47223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47222_47223 : H12AffineEnvironment.transform 0 0 env47222 = env47223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47222 == env47223) = true)

theorem identity47223 : scanCanonicalize (H12AffineFastState.compose env47223 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47224 : List Nat := [0,1,1,0,1,1,128,1,0,1,1,1,1,0,0,0,1,129,1,1,0,129,0,1,128,0,0,0,0,1,1,0,1,1,0,1]

theorem envBound47224 : H12AffineFastState.Bounded env47224 := by
  intro p hp
  have h : env47224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47223_47224 : H12AffineEnvironment.transform 10 1 env47223 = env47224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47223 == env47224) = true)

theorem identity47224 : scanCanonicalize (H12AffineFastState.compose env47224 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound47224 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47225 : List Nat := [0,1,1,0,1,1,1,1,0,1,1,1,1,0,0,0,1,0,1,1,0,0,0,1,1,0,0,0,0,1,1,0,1,1,0,1]

theorem envBound47225 : H12AffineFastState.Bounded env47225 := by
  intro p hp
  have h : env47225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47224_47225 : H12AffineEnvironment.transform 6 1 env47224 = env47225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env47224 == env47225) = true)

def env47226 : List Nat := [2,4,8,1,7,64,128,256,324,321,2048,0,8192,64,8525,65536,73993,65665,320,8524,1,460,73993,65537,8329,74056,265,74056,64,75787,8204,74057,256,8201,0,324]

theorem envBound47226 : H12AffineFastState.Bounded env47226 := by
  intro p hp
  have h : env47226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47215_47226 : H12AffineEnvironment.transform 3 1 env47215 = env47226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47215 == env47226) = true)

theorem identity47226 : scanCanonicalize (H12AffineFastState.compose env47226 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound47226 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47227 : List Nat := [2,4,8,1,7,64,128,256,324,321,2048,0,8192,64,8525,69,8524,196,320,8524,1,460,8524,68,8329,8461,265,8461,64,10318,8204,8460,256,8201,0,324]

theorem envBound47227 : H12AffineFastState.Bounded env47227 := by
  intro p hp
  have h : env47227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47226_47227 : H12AffineEnvironment.transform 15 69 env47226 = env47227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env47226 == env47227) = true)

theorem identity47227 : scanCanonicalize (H12AffineFastState.compose env47227 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47227 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47228 : List Nat := [2,4,8,1,7,64,128,256,324,321,2048,0,269,64,64,69,65,196,320,65,1,460,65,68,388,0,265,0,64,2371,257,1,256,260,0,324]

theorem envBound47228 : H12AffineFastState.Bounded env47228 := by
  intro p hp
  have h : env47228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47227_47228 : H12AffineEnvironment.transform 12 269 env47227 = env47228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47227 == env47228) = true)

theorem identity47228 : scanCanonicalize (H12AffineFastState.compose env47228 (packedSelected [5,10] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound47228 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env47229 : List Nat := [2,4,8,1,7,64,128,9,77,72,2048,0,4,64,64,69,65,196,73,65,1,197,65,68,141,0,0,0,64,2122,8,1,9,13,0,77]

theorem envBound47229 : H12AffineFastState.Bounded env47229 := by
  intro p hp
  have h : env47229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47228_47229 : H12AffineEnvironment.transform 7 9 env47228 = env47229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env47228 == env47229) = true)

theorem identity47229 : scanCanonicalize (H12AffineFastState.compose env47229 (packedSelected [7,8] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound47229 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env47230 : List Nat := [2,4,8,1,7,64,128,9,77,72,130,0,4,64,64,69,65,196,73,65,1,197,65,68,141,0,0,0,64,200,8,1,9,13,0,77]

theorem envBound47230 : H12AffineFastState.Bounded env47230 := by
  intro p hp
  have h : env47230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47229_47230 : H12AffineEnvironment.transform 10 130 env47229 = env47230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env47229 == env47230) = true)

theorem identity47230 : scanCanonicalize (H12AffineFastState.compose env47230 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound47230 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env47231 : List Nat := [2,4,8,1,7,64,14,9,77,72,12,0,4,64,64,69,65,74,73,65,1,75,65,68,3,0,0,0,64,70,8,1,9,13,0,77]

theorem envBound47231 : H12AffineFastState.Bounded env47231 := by
  intro p hp
  have h : env47231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47230_47231 : H12AffineEnvironment.transform 6 14 env47230 = env47231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env47230 == env47231) = true)

theorem identity47231 : scanCanonicalize (H12AffineFastState.compose env47231 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47231 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env47232 : List Nat := [2,4,8,1,7,10,14,9,7,2,12,0,4,10,10,15,11,0,3,11,1,1,11,14,3,0,0,0,10,12,8,1,9,13,0,7]

theorem envBound47232 : H12AffineFastState.Bounded env47232 := by
  intro p hp
  have h : env47232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47231_47232 : H12AffineEnvironment.transform 5 10 env47231 = env47232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47231 == env47232) = true)

def env47233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4097,476,74046,69649,13769,78894,332223,74814,1296,81227,8205,74799,256,8200,1345,5952]

theorem envBound47233 : H12AffineFastState.Bounded env47233 := by
  intro p hp
  have h : env47233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47070_47233 : H12AffineEnvironment.transform 13 1297 env47070 = env47233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env47070 == env47233) = true)

def env47234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4097,476,74046,69649,13769,78894,4415,74814,1296,81227,8205,74799,256,8200,1345,5952]

theorem envBound47234 : H12AffineFastState.Bounded env47234 := by
  intro p hp
  have h : env47234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47233_47234 : H12AffineEnvironment.transform 17 65664 env47233 = env47234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47233 == env47234) = true)

theorem identity47234 : scanCanonicalize (H12AffineFastState.compose env47234 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound47234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4097,476,65910,69649,5505,70758,4415,66678,1296,72963,69,66663,256,64,1345,5952]

theorem envBound47235 : H12AffineFastState.Bounded env47235 := by
  intro p hp
  have h : env47235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47234_47235 : H12AffineEnvironment.transform 12 72 env47234 = env47235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47234 == env47235) = true)

def env47236 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4097,476,65910,69649,5505,70758,4415,66678,1296,72963,69,66663,256,64,1345,5140]

theorem envBound47236 : H12AffineFastState.Bounded env47236 := by
  intro p hp
  have h : env47236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47235_47236 : H12AffineEnvironment.transform 8 340 env47235 = env47236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env47235 == env47236) = true)

def env47237 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,81,4373,65536,65895,65664,4417,4372,4097,476,65910,69649,4289,69926,4415,65846,80,71747,69,65831,256,64,1,4436]

theorem envBound47237 : H12AffineFastState.Bounded env47237 := by
  intro p hp
  have h : env47237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47236_47237 : H12AffineEnvironment.transform 9 320 env47236 = env47237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47236 == env47237) = true)

theorem identity47237 : scanCanonicalize (H12AffineFastState.compose env47237 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47237 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47238 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,81,4373,114,277,242,4417,4372,4097,476,260,4195,4289,4436,4415,324,80,6193,69,341,256,64,1,4436]

theorem envBound47238 : H12AffineFastState.Bounded env47238 := by
  intro p hp
  have h : env47238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47237_47238 : H12AffineEnvironment.transform 15 114 env47237 = env47238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47237 == env47238) = true)

theorem identity47238 : scanCanonicalize (H12AffineFastState.compose env47238 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 503) := by decide +kernel

theorem selectedBound47238 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env47239 : List Nat := [2,4,8,16,32,64,128,256,340,320,503,4096,72,81,4373,114,277,242,4417,4372,4097,476,260,4195,4289,4436,4415,324,80,4550,69,341,256,64,1,4436]

theorem envBound47239 : H12AffineFastState.Bounded env47239 := by
  intro p hp
  have h : env47239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47238_47239 : H12AffineEnvironment.transform 10 503 env47238 = env47239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 503 env47238 == env47239) = true)

theorem identity47239 : scanCanonicalize (H12AffineFastState.compose env47239 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 239) := by decide +kernel

theorem selectedBound47239 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47240 : List Nat := [2,4,8,16,32,64,128,256,340,320,503,239,72,81,506,114,277,242,430,507,238,476,260,140,46,443,464,324,80,297,69,341,256,64,1,443]

theorem envBound47240 : H12AffineFastState.Bounded env47240 := by
  intro p hp
  have h : env47240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47239_47240 : H12AffineEnvironment.transform 11 239 env47239 = env47240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 239 env47239 == env47240) = true)

theorem identity47240 : scanCanonicalize (H12AffineFastState.compose env47240 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47240 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47241 : List Nat := [2,4,8,16,32,64,128,21,65,85,226,239,72,81,239,114,0,242,187,238,238,201,17,140,46,174,197,81,80,60,69,64,21,64,1,174]

theorem envBound47241 : H12AffineFastState.Bounded env47241 := by
  intro p hp
  have h : env47241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47240_47241 : H12AffineEnvironment.transform 7 21 env47240 = env47241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47240 == env47241) = true)

theorem identity47241 : scanCanonicalize (H12AffineFastState.compose env47241 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47241 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env47242 : List Nat := [2,4,8,7,32,64,128,2,65,66,226,239,72,70,239,101,0,229,172,238,238,201,6,140,46,174,197,70,71,43,69,64,2,64,1,174]

theorem envBound47242 : H12AffineFastState.Bounded env47242 := by
  intro p hp
  have h : env47242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47241_47242 : H12AffineEnvironment.transform 3 7 env47241 = env47242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47241 == env47242) = true)

theorem identity47242 : scanCanonicalize (H12AffineFastState.compose env47242 (packedSelected [1,2,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound47242 : packedSelected [1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47243 : List Nat := [2,4,8,7,32,64,104,2,65,66,10,7,72,70,7,101,0,13,68,6,6,33,6,100,46,70,45,70,71,43,69,64,2,64,1,70]

theorem envBound47243 : H12AffineFastState.Bounded env47243 := by
  intro p hp
  have h : env47243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47242_47243 : H12AffineEnvironment.transform 6 104 env47242 = env47243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env47242 == env47243) = true)

theorem identity47243 : scanCanonicalize (H12AffineFastState.compose env47243 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound47243 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47244 : List Nat := [2,4,8,7,32,44,4,2,45,46,10,7,36,42,7,9,0,13,40,6,6,33,6,8,46,42,45,42,43,43,41,44,2,44,1,42]

theorem envBound47244 : H12AffineFastState.Bounded env47244 := by
  intro p hp
  have h : env47244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47243_47244 : H12AffineEnvironment.transform 5 44 env47243 = env47244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env47243 == env47244) = true)

theorem identity47244 : scanCanonicalize (H12AffineFastState.compose env47244 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47244 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47245 : List Nat := [2,4,8,7,7,11,4,2,10,9,10,7,3,13,7,9,0,13,15,6,6,6,6,8,9,13,10,13,12,12,14,11,2,11,1,13]

theorem envBound47245 : H12AffineFastState.Bounded env47245 := by
  intro p hp
  have h : env47245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47244_47245 : H12AffineEnvironment.transform 4 7 env47244 = env47245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47244 == env47245) = true)

theorem identity47245 : scanCanonicalize (H12AffineFastState.compose env47245 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47245 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47246 : List Nat := [2,4,4,7,7,7,4,2,6,5,6,7,3,1,7,5,0,1,3,6,6,6,6,4,5,1,6,1,0,0,2,7,2,7,1,1]

theorem envBound47246 : H12AffineFastState.Bounded env47246 := by
  intro p hp
  have h : env47246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47245_47246 : H12AffineEnvironment.transform 2 4 env47245 = env47246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47245 == env47246) = true)

def env47247 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,80,4372,65536,65894,65664,4417,4373,4097,476,65910,69649,4288,69927,4415,65847,81,71746,69,65830,256,64,0,4437]

theorem envBound47247 : H12AffineFastState.Bounded env47247 := by
  intro p hp
  have h : env47247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47236_47247 : H12AffineEnvironment.transform 9 321 env47236 = env47247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47236 == env47247) = true)

theorem identity47247 : scanCanonicalize (H12AffineFastState.compose env47247 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound47247 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47248 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,80,4372,4211,4373,4339,4417,4373,4097,476,4357,98,4288,340,4415,4420,81,2097,69,4437,256,64,0,4437]

theorem envBound47248 : H12AffineFastState.Bounded env47248 := by
  intro p hp
  have h : env47248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47247_47248 : H12AffineEnvironment.transform 15 4211 env47247 = env47248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env47247 == env47248) = true)

theorem identity47248 : scanCanonicalize (H12AffineFastState.compose env47248 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound47248 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47249 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,325,72,80,81,310,80,438,4,80,324,476,64,98,389,340,122,1,81,2097,69,16,256,64,0,16]

theorem envBound47249 : H12AffineFastState.Bounded env47249 := by
  intro p hp
  have h : env47249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47248_47249 : H12AffineEnvironment.transform 11 325 env47248 = env47249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env47248 == env47249) = true)

theorem identity47249 : scanCanonicalize (H12AffineFastState.compose env47249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47250 : List Nat := [2,4,8,16,32,64,128,68,16,5,2048,1,72,80,81,114,80,242,4,80,0,152,64,98,193,16,122,1,81,2097,69,16,68,64,0,16]

theorem envBound47250 : H12AffineFastState.Bounded env47250 := by
  intro p hp
  have h : env47250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47249_47250 : H12AffineEnvironment.transform 7 68 env47249 = env47250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47249 == env47250) = true)

theorem identity47250 : scanCanonicalize (H12AffineFastState.compose env47250 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound47250 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env47251 : List Nat := [2,4,8,16,32,64,128,68,16,5,148,1,72,80,81,114,80,242,4,80,0,152,64,98,193,16,122,1,81,165,69,16,68,64,0,16]

theorem envBound47251 : H12AffineFastState.Bounded env47251 := by
  intro p hp
  have h : env47251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47250_47251 : H12AffineEnvironment.transform 10 148 env47250 = env47251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env47250 == env47251) = true)

theorem identity47251 : scanCanonicalize (H12AffineFastState.compose env47251 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound47251 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env47252 : List Nat := [2,4,8,16,32,64,72,68,16,5,92,1,72,80,81,114,80,58,4,80,0,80,64,98,9,16,122,1,81,109,69,16,68,64,0,16]

theorem envBound47252 : H12AffineFastState.Bounded env47252 := by
  intro p hp
  have h : env47252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47251_47252 : H12AffineEnvironment.transform 6 72 env47251 = env47252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env47251 == env47252) = true)

theorem identity47252 : scanCanonicalize (H12AffineFastState.compose env47252 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound47252 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47253 : List Nat := [2,4,8,12,32,64,72,68,12,5,64,1,72,76,77,110,76,38,4,76,0,76,64,98,9,12,102,1,77,109,69,12,68,64,0,12]

theorem envBound47253 : H12AffineFastState.Bounded env47253 := by
  intro p hp
  have h : env47253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47252_47253 : H12AffineEnvironment.transform 3 12 env47252 = env47253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env47252 == env47253) = true)

theorem identity47253 : scanCanonicalize (H12AffineFastState.compose env47253 (packedSelected [0,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound47253 : packedSelected [0,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47254 : List Nat := [2,4,8,12,32,11,3,15,12,5,11,1,3,7,6,37,7,38,4,7,0,7,11,41,9,12,45,1,6,38,14,12,15,11,0,12]

theorem envBound47254 : H12AffineFastState.Bounded env47254 := by
  intro p hp
  have h : env47254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47253_47254 : H12AffineEnvironment.transform 5 11 env47253 = env47254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env47253 == env47254) = true)

theorem identity47254 : scanCanonicalize (H12AffineFastState.compose env47254 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47255 : List Nat := [2,4,8,12,13,11,3,15,12,5,11,1,3,7,6,8,7,11,4,7,0,7,11,4,9,12,0,1,6,11,14,12,15,11,0,12]

theorem envBound47255 : H12AffineFastState.Bounded env47255 := by
  intro p hp
  have h : env47255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47254_47255 : H12AffineEnvironment.transform 4 13 env47254 = env47255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47254 == env47255) = true)

theorem identity47255 : scanCanonicalize (H12AffineFastState.compose env47255 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47256 : List Nat := [2,3,8,11,10,11,3,8,11,2,11,1,3,0,1,8,0,11,3,0,0,0,11,3,9,11,0,1,1,11,9,11,8,11,0,11]

theorem envBound47256 : H12AffineFastState.Bounded env47256 := by
  intro p hp
  have h : env47256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47255_47256 : H12AffineEnvironment.transform 1 3 env47255 = env47256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47255 == env47256) = true)

theorem identity47256 : scanCanonicalize (H12AffineFastState.compose env47256 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47257 : List Nat := [2,3,2,1,0,1,3,2,1,2,1,1,3,0,1,2,0,1,3,0,0,0,1,3,3,1,0,1,1,1,3,1,2,1,0,1]

theorem envBound47257 : H12AffineFastState.Bounded env47257 := by
  intro p hp
  have h : env47257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47256_47257 : H12AffineEnvironment.transform 2 2 env47256 = env47257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47256 == env47257) = true)

def env47258 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4097,476,65910,69649,5505,70758,4415,66678,1296,72963,69,66663,256,64,1345,5141]

theorem envBound47258 : H12AffineFastState.Bounded env47258 := by
  intro p hp
  have h : env47258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47235_47258 : H12AffineEnvironment.transform 8 341 env47235 = env47258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env47235 == env47258) = true)

def env47259 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,81,4373,65536,65895,65664,4417,4372,4097,476,65910,69649,4289,69926,4415,65846,80,71747,69,65831,256,64,1,4437]

theorem envBound47259 : H12AffineFastState.Bounded env47259 := by
  intro p hp
  have h : env47259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47258_47259 : H12AffineEnvironment.transform 9 320 env47258 = env47259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47258 == env47259) = true)

theorem identity47259 : scanCanonicalize (H12AffineFastState.compose env47259 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47259 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47260 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,81,4373,114,277,242,4417,4372,4097,476,260,4195,4289,4436,4415,324,80,6193,69,341,256,64,1,4437]

theorem envBound47260 : H12AffineFastState.Bounded env47260 := by
  intro p hp
  have h : env47260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47259_47260 : H12AffineEnvironment.transform 15 114 env47259 = env47260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47259 == env47260) = true)

theorem identity47260 : scanCanonicalize (H12AffineFastState.compose env47260 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound47260 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env47261 : List Nat := [2,4,8,16,32,64,128,256,341,320,502,4096,72,81,4373,114,277,242,4417,4372,4097,476,260,4195,4289,4436,4415,324,80,4551,69,341,256,64,1,4437]

theorem envBound47261 : H12AffineFastState.Bounded env47261 := by
  intro p hp
  have h : env47261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47260_47261 : H12AffineEnvironment.transform 10 502 env47260 = env47261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env47260 == env47261) = true)

theorem identity47261 : scanCanonicalize (H12AffineFastState.compose env47261 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 506) := by decide +kernel

theorem selectedBound47261 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47262 : List Nat := [2,4,8,16,32,64,128,256,341,320,502,506,72,81,239,114,277,242,187,238,507,476,260,409,315,174,197,324,80,61,69,341,256,64,1,175]

theorem envBound47262 : H12AffineFastState.Bounded env47262 := by
  intro p hp
  have h : env47262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47261_47262 : H12AffineEnvironment.transform 11 506 env47261 = env47262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 506 env47261 == env47262) = true)

theorem identity47262 : scanCanonicalize (H12AffineFastState.compose env47262 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47262 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47263 : List Nat := [2,4,8,16,32,64,128,21,64,85,227,239,72,81,239,114,0,242,187,238,238,201,17,140,46,174,197,81,80,61,69,64,21,64,1,175]

theorem envBound47263 : H12AffineFastState.Bounded env47263 := by
  intro p hp
  have h : env47263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47262_47263 : H12AffineEnvironment.transform 7 21 env47262 = env47263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47262 == env47263) = true)

theorem identity47263 : scanCanonicalize (H12AffineFastState.compose env47263 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound47263 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env47264 : List Nat := [2,4,8,6,32,64,128,3,64,67,227,239,72,71,239,100,0,228,173,238,238,201,7,140,46,174,197,71,70,43,69,64,3,64,1,175]

theorem envBound47264 : H12AffineFastState.Bounded env47264 := by
  intro p hp
  have h : env47264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47263_47264 : H12AffineEnvironment.transform 3 6 env47263 = env47264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env47263 == env47264) = true)

theorem identity47264 : scanCanonicalize (H12AffineFastState.compose env47264 (packedSelected [1,2,5,8,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47264 : packedSelected [1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47265 : List Nat := [2,3,8,1,32,64,128,3,64,67,227,232,72,64,232,99,0,227,170,233,233,201,0,139,41,169,194,64,65,43,66,64,3,64,1,168]

theorem envBound47265 : H12AffineFastState.Bounded env47265 := by
  intro p hp
  have h : env47265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47264_47265 : H12AffineEnvironment.transform 1 3 env47264 = env47265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47264 == env47265) = true)

theorem identity47265 : scanCanonicalize (H12AffineFastState.compose env47265 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound47265 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47266 : List Nat := [2,3,8,1,32,42,128,3,42,41,137,130,34,42,130,9,0,137,170,131,131,163,0,139,41,169,168,42,43,43,40,42,3,42,1,168]

theorem envBound47266 : H12AffineFastState.Bounded env47266 := by
  intro p hp
  have h : env47266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47265_47266 : H12AffineEnvironment.transform 5 42 env47265 = env47266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env47265 == env47266) = true)

theorem identity47266 : scanCanonicalize (H12AffineFastState.compose env47266 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound47266 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47267 : List Nat := [2,3,8,1,32,42,40,3,42,41,33,42,34,42,42,9,0,33,2,43,43,11,0,35,41,1,0,42,43,43,40,42,3,42,1,0]

theorem envBound47267 : H12AffineFastState.Bounded env47267 := by
  intro p hp
  have h : env47267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47266_47267 : H12AffineEnvironment.transform 6 40 env47266 = env47267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env47266 == env47267) = true)

theorem identity47267 : scanCanonicalize (H12AffineFastState.compose env47267 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47268 : List Nat := [2,3,8,1,1,11,9,3,11,8,0,11,3,11,11,9,0,0,2,10,10,11,0,2,8,1,0,11,10,10,9,11,3,11,1,0]

theorem envBound47268 : H12AffineFastState.Bounded env47268 := by
  intro p hp
  have h : env47268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47267_47268 : H12AffineEnvironment.transform 4 1 env47267 = env47268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47267 == env47268) = true)

theorem identity47268 : scanCanonicalize (H12AffineFastState.compose env47268 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47269 : List Nat := [2,3,2,1,1,1,3,3,1,2,0,1,3,1,1,3,0,0,2,0,0,1,0,2,2,1,0,1,0,0,3,1,3,1,1,0]

theorem envBound47269 : H12AffineFastState.Bounded env47269 := by
  intro p hp
  have h : env47269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47268_47269 : H12AffineEnvironment.transform 2 2 env47268 = env47269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47268 == env47269) = true)

theorem identity47269 : scanCanonicalize (H12AffineFastState.compose env47269 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47270 : List Nat := [1,0,1,1,1,1,0,0,1,1,0,1,0,1,1,0,0,0,1,0,0,1,0,1,1,1,0,1,0,0,0,1,0,1,1,0]

theorem envBound47270 : H12AffineFastState.Bounded env47270 := by
  intro p hp
  have h : env47270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47269_47270 : H12AffineEnvironment.transform 0 1 env47269 = env47270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47269 == env47270) = true)

def env47271 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,80,4372,65536,65894,65664,4417,4373,4097,476,65910,69649,4288,69927,4415,65847,81,71746,69,65830,256,64,0,4436]

theorem envBound47271 : H12AffineFastState.Bounded env47271 := by
  intro p hp
  have h : env47271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47258_47271 : H12AffineEnvironment.transform 9 321 env47258 = env47271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47258 == env47271) = true)

theorem identity47271 : scanCanonicalize (H12AffineFastState.compose env47271 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound47271 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47272 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,80,4372,4211,4373,4339,4417,4373,4097,476,4357,98,4288,340,4415,4420,81,2097,69,4437,256,64,0,4436]

theorem envBound47272 : H12AffineFastState.Bounded env47272 := by
  intro p hp
  have h : env47272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47271_47272 : H12AffineEnvironment.transform 15 4211 env47271 = env47272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env47271 == env47272) = true)

theorem identity47272 : scanCanonicalize (H12AffineFastState.compose env47272 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound47272 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47273 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,325,72,80,81,310,80,438,4,80,324,476,64,98,389,340,122,1,81,2097,69,16,256,64,0,17]

theorem envBound47273 : H12AffineFastState.Bounded env47273 := by
  intro p hp
  have h : env47273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47272_47273 : H12AffineEnvironment.transform 11 325 env47272 = env47273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env47272 == env47273) = true)

theorem identity47273 : scanCanonicalize (H12AffineFastState.compose env47273 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47273 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47274 : List Nat := [2,4,8,16,32,64,128,68,17,5,2048,1,72,80,81,114,80,242,4,80,0,152,64,98,193,16,122,1,81,2097,69,16,68,64,0,17]

theorem envBound47274 : H12AffineFastState.Bounded env47274 := by
  intro p hp
  have h : env47274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47273_47274 : H12AffineEnvironment.transform 7 68 env47273 = env47274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47273 == env47274) = true)

theorem identity47274 : scanCanonicalize (H12AffineFastState.compose env47274 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 196) := by decide +kernel

theorem selectedBound47274 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env47275 : List Nat := [2,4,8,16,32,64,128,68,17,5,196,1,72,80,81,114,80,242,4,80,0,152,64,98,193,16,122,1,81,245,69,16,68,64,0,17]

theorem envBound47275 : H12AffineFastState.Bounded env47275 := by
  intro p hp
  have h : env47275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47274_47275 : H12AffineEnvironment.transform 10 196 env47274 = env47275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 196 env47274 == env47275) = true)

theorem identity47275 : scanCanonicalize (H12AffineFastState.compose env47275 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound47275 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env47276 : List Nat := [2,4,8,16,32,64,73,68,17,5,13,1,72,80,81,114,80,59,4,80,0,81,64,98,8,16,122,1,81,60,69,16,68,64,0,17]

theorem envBound47276 : H12AffineFastState.Bounded env47276 := by
  intro p hp
  have h : env47276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47275_47276 : H12AffineEnvironment.transform 6 73 env47275 = env47276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env47275 == env47276) = true)

theorem identity47276 : scanCanonicalize (H12AffineFastState.compose env47276 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound47276 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47277 : List Nat := [2,4,8,16,32,12,5,8,17,5,13,1,4,28,29,62,28,59,4,28,0,29,12,46,8,16,54,1,29,60,9,16,8,12,0,17]

theorem envBound47277 : H12AffineFastState.Bounded env47277 := by
  intro p hp
  have h : env47277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47276_47277 : H12AffineEnvironment.transform 5 12 env47276 = env47277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env47276 == env47277) = true)

theorem identity47277 : scanCanonicalize (H12AffineFastState.compose env47277 (packedSelected [0,2,3,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47277 : packedSelected [0,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47278 : List Nat := [2,3,8,16,32,11,2,8,17,2,10,1,3,27,26,57,27,59,3,27,0,26,11,41,8,16,49,1,26,59,9,16,8,11,0,17]

theorem envBound47278 : H12AffineFastState.Bounded env47278 := by
  intro p hp
  have h : env47278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47277_47278 : H12AffineEnvironment.transform 1 3 env47277 = env47278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47277 == env47278) = true)

theorem identity47278 : scanCanonicalize (H12AffineFastState.compose env47278 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47279 : List Nat := [2,3,8,16,17,11,2,8,17,2,10,1,3,27,26,8,27,10,3,27,0,26,11,24,8,16,0,1,26,10,9,16,8,11,0,17]

theorem envBound47279 : H12AffineFastState.Bounded env47279 := by
  intro p hp
  have h : env47279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47278_47279 : H12AffineEnvironment.transform 4 17 env47278 = env47279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47278 == env47279) = true)

theorem identity47279 : scanCanonicalize (H12AffineFastState.compose env47279 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47280 : List Nat := [2,3,8,11,10,11,2,8,10,2,10,1,3,0,1,8,0,10,3,0,0,1,11,3,8,11,0,1,1,10,9,11,8,11,0,10]

theorem envBound47280 : H12AffineFastState.Bounded env47280 := by
  intro p hp
  have h : env47280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47279_47280 : H12AffineEnvironment.transform 3 11 env47279 = env47280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47279 == env47280) = true)

theorem identity47280 : scanCanonicalize (H12AffineFastState.compose env47280 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47281 : List Nat := [2,3,3,0,1,0,2,3,1,2,1,1,3,0,1,3,0,1,3,0,0,1,0,3,3,0,0,1,1,1,2,0,3,0,0,1]

theorem envBound47281 : H12AffineFastState.Bounded env47281 := by
  intro p hp
  have h : env47281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47280_47281 : H12AffineEnvironment.transform 2 3 env47280 = env47281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47280 == env47281) = true)

def env47282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4097,476,74046,69649,13769,78894,4414,74814,1296,81227,8205,74799,256,8200,1345,5952]

theorem envBound47282 : H12AffineFastState.Bounded env47282 := by
  intro p hp
  have h : env47282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47233_47282 : H12AffineEnvironment.transform 17 65665 env47233 = env47282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47233 == env47282) = true)

theorem identity47282 : scanCanonicalize (H12AffineFastState.compose env47282 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound47282 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4097,476,70711,69649,192,65831,4414,69943,1296,67650,5380,69926,256,5377,1345,5952]

theorem envBound47283 : H12AffineFastState.Bounded env47283 := by
  intro p hp
  have h : env47283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47282_47283 : H12AffineEnvironment.transform 12 5385 env47282 = env47283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env47282 == env47283) = true)

def env47284 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4097,476,70711,69649,192,65831,4414,69943,1296,67650,5380,69926,256,5377,1345,5140]

theorem envBound47284 : H12AffineFastState.Bounded env47284 := by
  intro p hp
  have h : env47284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47283_47284 : H12AffineEnvironment.transform 8 340 env47283 = env47284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env47283 == env47284) = true)

def env47285 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,276,65536,65894,65665,321,277,1,476,66615,65553,192,65831,318,65847,1296,67650,1284,65830,256,1281,1345,1044]

theorem envBound47285 : H12AffineFastState.Bounded env47285 := by
  intro p hp
  have h : env47285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47284_47285 : H12AffineEnvironment.transform 11 0 env47284 = env47285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47284 == env47285) = true)

theorem identity47285 : scanCanonicalize (H12AffineFastState.compose env47285 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound47285 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47286 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,276,1330,1108,1459,321,277,1,476,261,1315,192,1045,318,1029,1296,3440,1284,1044,256,1281,1345,1044]

theorem envBound47286 : H12AffineFastState.Bounded env47286 := by
  intro p hp
  have h : env47286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47285_47286 : H12AffineEnvironment.transform 15 1330 env47285 = env47286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env47285 == env47286) = true)

theorem identity47286 : scanCanonicalize (H12AffineFastState.compose env47286 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound47286 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env47287 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1039,0,1289,1297,276,1330,1108,1459,321,277,1,476,261,1315,192,1045,318,1029,1296,383,1284,1044,256,1281,1345,1044]

theorem envBound47287 : H12AffineFastState.Bounded env47287 := by
  intro p hp
  have h : env47287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47286_47287 : H12AffineEnvironment.transform 10 1039 env47286 = env47287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env47286 == env47287) = true)

theorem identity47287 : scanCanonicalize (H12AffineFastState.compose env47287 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47287 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47288 : List Nat := [2,4,8,16,32,64,128,69,17,1024,1039,0,1100,1108,81,1143,1108,1270,4,80,1,153,64,1126,192,1045,123,1029,1109,58,1089,1044,69,1092,1028,1044]

theorem envBound47288 : H12AffineFastState.Bounded env47288 := by
  intro p hp
  have h : env47288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47287_47288 : H12AffineEnvironment.transform 7 69 env47287 = env47288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47287 == env47288) = true)

theorem identity47288 : scanCanonicalize (H12AffineFastState.compose env47288 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 145) := by decide +kernel

theorem selectedBound47288 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env47289 : List Nat := [2,4,8,16,32,64,128,69,17,145,158,0,221,197,81,230,197,103,4,80,1,153,64,247,192,132,123,148,196,58,208,133,69,213,149,133]

theorem envBound47289 : H12AffineFastState.Bounded env47289 := by
  intro p hp
  have h : env47289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47288_47289 : H12AffineEnvironment.transform 9 145 env47288 = env47289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env47288 == env47289) = true)

theorem identity47289 : scanCanonicalize (H12AffineFastState.compose env47289 (packedSelected [1,3,15] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47289 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env47290 : List Nat := [2,4,8,16,32,10,128,15,17,145,158,0,151,143,27,172,143,45,4,26,1,153,10,189,138,132,49,148,142,58,154,133,15,159,149,133]

theorem envBound47290 : H12AffineFastState.Bounded env47290 := by
  intro p hp
  have h : env47290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47289_47290 : H12AffineEnvironment.transform 5 10 env47289 = env47290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47289 == env47290) = true)

theorem identity47290 : scanCanonicalize (H12AffineFastState.compose env47290 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound47290 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env47291 : List Nat := [2,4,8,16,27,10,128,15,17,145,158,0,151,143,27,151,143,22,4,26,1,153,10,134,138,132,10,148,142,1,154,133,15,159,149,133]

theorem envBound47291 : H12AffineFastState.Bounded env47291 := by
  intro p hp
  have h : env47291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47290_47291 : H12AffineEnvironment.transform 4 27 env47290 = env47291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env47290 == env47291) = true)

theorem identity47291 : scanCanonicalize (H12AffineFastState.compose env47291 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound47291 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47292 : List Nat := [2,4,8,16,27,10,14,15,17,31,16,0,25,1,27,25,1,22,4,26,1,23,10,8,4,10,10,26,0,1,20,11,15,17,27,11]

theorem envBound47292 : H12AffineFastState.Bounded env47292 := by
  intro p hp
  have h : env47292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47291_47292 : H12AffineEnvironment.transform 6 14 env47291 = env47292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env47291 == env47292) = true)

theorem identity47292 : scanCanonicalize (H12AffineFastState.compose env47292 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47292 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47293 : List Nat := [2,4,5,16,22,7,3,2,17,18,16,0,20,1,22,20,1,22,4,23,1,23,7,5,4,7,7,23,0,1,20,6,2,17,22,6]

theorem envBound47293 : H12AffineFastState.Bounded env47293 := by
  intro p hp
  have h : env47293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47292_47293 : H12AffineEnvironment.transform 2 5 env47292 = env47293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47292 == env47293) = true)

theorem identity47293 : scanCanonicalize (H12AffineFastState.compose env47293 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47293 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47294 : List Nat := [2,3,2,16,17,0,3,2,17,18,16,0,19,1,17,19,1,17,3,16,1,16,0,2,3,0,0,16,0,1,19,1,2,17,17,1]

theorem envBound47294 : H12AffineFastState.Bounded env47294 := by
  intro p hp
  have h : env47294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47293_47294 : H12AffineEnvironment.transform 1 3 env47293 = env47294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47293 == env47294) = true)

theorem identity47294 : scanCanonicalize (H12AffineFastState.compose env47294 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47295 : List Nat := [2,3,2,0,1,0,3,2,1,2,0,0,3,1,1,3,1,1,3,0,1,0,0,2,3,0,0,0,0,1,3,1,2,1,1,1]

theorem envBound47295 : H12AffineFastState.Bounded env47295 := by
  intro p hp
  have h : env47295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47294_47295 : H12AffineEnvironment.transform 3 0 env47294 = env47295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47294 == env47295) = true)

def env47296 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,276,65536,65895,65665,320,277,0,476,66614,65552,192,65831,319,65846,1296,67650,1285,65831,256,1280,1345,1045]

theorem envBound47296 : H12AffineFastState.Bounded env47296 := by
  intro p hp
  have h : env47296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47284_47296 : H12AffineEnvironment.transform 11 1 env47284 = env47296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47284 == env47296) = true)

theorem identity47296 : scanCanonicalize (H12AffineFastState.compose env47296 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47296 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47297 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,276,114,277,243,320,277,0,476,1092,98,192,341,319,324,1296,2096,1285,341,256,1280,1345,1045]

theorem envBound47297 : H12AffineFastState.Bounded env47297 := by
  intro p hp
  have h : env47297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47296_47297 : H12AffineEnvironment.transform 15 114 env47296 = env47297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47296 == env47297) = true)

theorem identity47297 : scanCanonicalize (H12AffineFastState.compose env47297 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound47297 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47298 : List Nat := [2,4,8,16,32,64,128,256,340,1024,423,1,1288,1297,276,114,277,243,320,277,0,476,1092,98,192,341,319,324,1296,407,1285,341,256,1280,1345,1045]

theorem envBound47298 : H12AffineFastState.Bounded env47298 := by
  intro p hp
  have h : env47298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47297_47298 : H12AffineEnvironment.transform 10 423 env47297 = env47298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env47297 == env47298) = true)

theorem identity47298 : scanCanonicalize (H12AffineFastState.compose env47298 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound47298 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env47299 : List Nat := [2,4,8,16,32,64,128,256,340,85,423,1,349,324,276,114,277,243,320,277,0,476,17,98,192,341,319,324,325,407,336,341,256,341,276,64]

theorem envBound47299 : H12AffineFastState.Bounded env47299 := by
  intro p hp
  have h : env47299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47298_47299 : H12AffineEnvironment.transform 9 85 env47298 = env47299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env47298 == env47299) = true)

theorem identity47299 : scanCanonicalize (H12AffineFastState.compose env47299 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47299 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env47300 : List Nat := [2,4,8,16,0,64,128,256,340,85,391,1,349,324,276,82,277,211,320,277,0,476,17,66,192,341,287,324,325,407,336,341,256,341,276,64]

theorem envBound47300 : H12AffineFastState.Bounded env47300 := by
  intro p hp
  have h : env47300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47299_47300 : H12AffineEnvironment.transform 4 0 env47299 = env47300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47299 == env47300) = true)

theorem identity47300 : scanCanonicalize (H12AffineFastState.compose env47300 (packedSelected [0,1,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound47300 : packedSelected [0,1,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47301 : List Nat := [2,4,8,16,0,64,85,256,340,85,338,1,349,324,276,82,277,6,320,277,0,265,17,66,21,341,287,324,325,322,336,341,256,341,276,64]

theorem envBound47301 : H12AffineFastState.Bounded env47301 := by
  intro p hp
  have h : env47301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47300_47301 : H12AffineEnvironment.transform 6 85 env47300 = env47301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env47300 == env47301) = true)

theorem identity47301 : scanCanonicalize (H12AffineFastState.compose env47301 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47301 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47302 : List Nat := [2,4,8,16,0,64,85,68,16,85,22,1,25,0,80,82,81,6,4,81,0,77,17,66,21,17,91,0,1,6,20,17,68,17,80,64]

theorem envBound47302 : H12AffineFastState.Bounded env47302 := by
  intro p hp
  have h : env47302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47301_47302 : H12AffineEnvironment.transform 7 68 env47301 = env47302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47301 == env47302) = true)

theorem identity47302 : scanCanonicalize (H12AffineFastState.compose env47302 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound47302 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47303 : List Nat := [2,4,8,13,0,64,72,68,13,72,11,1,4,0,77,79,76,6,4,76,0,77,12,66,8,12,70,0,1,6,9,12,68,12,77,64]

theorem envBound47303 : H12AffineFastState.Bounded env47303 := by
  intro p hp
  have h : env47303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47302_47303 : H12AffineEnvironment.transform 3 13 env47302 = env47303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env47302 == env47303) = true)

theorem identity47303 : scanCanonicalize (H12AffineFastState.compose env47303 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound47303 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47304 : List Nat := [2,4,8,13,0,6,14,2,13,14,11,1,4,0,11,9,10,6,4,10,0,11,12,4,8,12,0,0,1,6,9,12,2,12,11,6]

theorem envBound47304 : H12AffineFastState.Bounded env47304 := by
  intro p hp
  have h : env47304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47303_47304 : H12AffineEnvironment.transform 5 6 env47303 = env47304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env47303 == env47304) = true)

def env47305 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4097,476,70711,69649,192,65831,4414,69943,1296,67650,5380,69926,256,5377,1345,5141]

theorem envBound47305 : H12AffineFastState.Bounded env47305 := by
  intro p hp
  have h : env47305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47283_47305 : H12AffineEnvironment.transform 8 341 env47283 = env47305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env47283 == env47305) = true)

def env47306 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,276,65536,65894,65665,321,277,1,476,66615,65553,192,65831,318,65847,1296,67650,1284,65830,256,1281,1345,1045]

theorem envBound47306 : H12AffineFastState.Bounded env47306 := by
  intro p hp
  have h : env47306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47305_47306 : H12AffineEnvironment.transform 11 0 env47305 = env47306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47305 == env47306) = true)

theorem identity47306 : scanCanonicalize (H12AffineFastState.compose env47306 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound47306 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47307 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,276,1330,1108,1459,321,277,1,476,261,1315,192,1045,318,1029,1296,3440,1284,1044,256,1281,1345,1045]

theorem envBound47307 : H12AffineFastState.Bounded env47307 := by
  intro p hp
  have h : env47307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47306_47307 : H12AffineEnvironment.transform 15 1330 env47306 = env47307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env47306 == env47307) = true)

theorem identity47307 : scanCanonicalize (H12AffineFastState.compose env47307 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound47307 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env47308 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1038,0,1289,1297,276,1330,1108,1459,321,277,1,476,261,1315,192,1045,318,1029,1296,382,1284,1044,256,1281,1345,1045]

theorem envBound47308 : H12AffineFastState.Bounded env47308 := by
  intro p hp
  have h : env47308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47307_47308 : H12AffineEnvironment.transform 10 1038 env47307 = env47308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env47307 == env47308) = true)

theorem identity47308 : scanCanonicalize (H12AffineFastState.compose env47308 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47308 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47309 : List Nat := [2,4,8,16,32,64,128,69,16,1024,1038,0,1100,1108,81,1143,1108,1270,4,80,1,153,64,1126,192,1045,123,1029,1109,59,1089,1044,69,1092,1028,1045]

theorem envBound47309 : H12AffineFastState.Bounded env47309 := by
  intro p hp
  have h : env47309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47308_47309 : H12AffineEnvironment.transform 7 69 env47308 = env47309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47308 == env47309) = true)

theorem identity47309 : scanCanonicalize (H12AffineFastState.compose env47309 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 193) := by decide +kernel

theorem selectedBound47309 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env47310 : List Nat := [2,4,8,16,32,64,128,69,16,193,207,0,141,149,81,182,149,55,4,80,1,153,64,167,192,212,123,196,148,59,128,213,69,133,197,212]

theorem envBound47310 : H12AffineFastState.Bounded env47310 := by
  intro p hp
  have h : env47310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47309_47310 : H12AffineEnvironment.transform 9 193 env47309 = env47310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 193 env47309 == env47310) = true)

theorem identity47310 : scanCanonicalize (H12AffineFastState.compose env47310 (packedSelected [1,3,15] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound47310 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env47311 : List Nat := [2,4,8,16,32,64,14,69,16,79,65,0,3,27,81,56,27,55,4,80,1,23,64,41,78,90,123,74,26,59,14,91,69,11,75,90]

theorem envBound47311 : H12AffineFastState.Bounded env47311 := by
  intro p hp
  have h : env47311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47310_47311 : H12AffineEnvironment.transform 6 14 env47310 = env47311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env47310 == env47311) = true)

theorem identity47311 : scanCanonicalize (H12AffineFastState.compose env47311 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound47311 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env47312 : List Nat := [2,4,8,16,26,64,14,69,16,79,65,0,3,27,81,2,27,13,4,80,1,23,64,19,78,90,65,74,26,1,14,91,69,11,75,90]

theorem envBound47312 : H12AffineFastState.Bounded env47312 := by
  intro p hp
  have h : env47312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47311_47312 : H12AffineEnvironment.transform 4 26 env47311 = env47312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env47311 == env47312) = true)

theorem identity47312 : scanCanonicalize (H12AffineFastState.compose env47312 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47312 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env47313 : List Nat := [2,4,8,16,26,16,14,21,16,31,17,0,3,27,1,2,27,13,4,0,1,23,16,19,30,10,17,26,26,1,14,11,21,11,27,10]

theorem envBound47313 : H12AffineFastState.Bounded env47313 := by
  intro p hp
  have h : env47313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47312_47313 : H12AffineEnvironment.transform 5 16 env47312 = env47313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47312 == env47313) = true)

theorem identity47313 : scanCanonicalize (H12AffineFastState.compose env47313 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47313 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47314 : List Nat := [2,4,3,16,17,16,5,21,16,20,17,0,3,16,1,2,16,6,4,0,1,23,16,19,21,1,17,17,17,1,5,0,21,0,16,1]

theorem envBound47314 : H12AffineFastState.Bounded env47314 := by
  intro p hp
  have h : env47314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47313_47314 : H12AffineEnvironment.transform 2 3 env47313 = env47314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47313 == env47314) = true)

theorem identity47314 : scanCanonicalize (H12AffineFastState.compose env47314 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47314 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47315 : List Nat := [2,3,3,16,17,16,2,18,16,19,17,0,3,16,1,2,16,1,3,0,1,16,16,19,18,1,17,17,17,1,2,0,18,0,16,1]

theorem envBound47315 : H12AffineFastState.Bounded env47315 := by
  intro p hp
  have h : env47315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47314_47315 : H12AffineEnvironment.transform 1 3 env47314 = env47315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47314 == env47315) = true)

theorem identity47315 : scanCanonicalize (H12AffineFastState.compose env47315 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47316 : List Nat := [2,3,3,1,0,1,2,3,1,2,0,0,3,1,1,2,1,1,3,0,1,1,1,2,3,1,0,0,0,1,2,0,3,0,1,1]

theorem envBound47316 : H12AffineFastState.Bounded env47316 := by
  intro p hp
  have h : env47316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47315_47316 : H12AffineEnvironment.transform 3 1 env47315 = env47316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47315 == env47316) = true)

def env47317 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,276,65536,65895,65665,320,277,0,476,66614,65552,192,65831,319,65846,1296,67650,1285,65831,256,1280,1345,1044]

theorem envBound47317 : H12AffineFastState.Bounded env47317 := by
  intro p hp
  have h : env47317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47305_47317 : H12AffineEnvironment.transform 11 1 env47305 = env47317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47305 == env47317) = true)

theorem identity47317 : scanCanonicalize (H12AffineFastState.compose env47317 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47317 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47318 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,276,114,277,243,320,277,0,476,1092,98,192,341,319,324,1296,2096,1285,341,256,1280,1345,1044]

theorem envBound47318 : H12AffineFastState.Bounded env47318 := by
  intro p hp
  have h : env47318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47317_47318 : H12AffineEnvironment.transform 15 114 env47317 = env47318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47317 == env47318) = true)

theorem identity47318 : scanCanonicalize (H12AffineFastState.compose env47318 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 422) := by decide +kernel

theorem selectedBound47318 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47319 : List Nat := [2,4,8,16,32,64,128,256,341,1024,422,1,1288,1297,276,114,277,243,320,277,0,476,1092,98,192,341,319,324,1296,406,1285,341,256,1280,1345,1044]

theorem envBound47319 : H12AffineFastState.Bounded env47319 := by
  intro p hp
  have h : env47319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47318_47319 : H12AffineEnvironment.transform 10 422 env47318 = env47319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 422 env47318 == env47319) = true)

theorem identity47319 : scanCanonicalize (H12AffineFastState.compose env47319 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound47319 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env47320 : List Nat := [2,4,8,16,32,64,128,256,341,85,422,1,349,324,276,114,277,243,320,277,0,476,17,98,192,341,319,324,325,406,336,341,256,341,276,65]

theorem envBound47320 : H12AffineFastState.Bounded env47320 := by
  intro p hp
  have h : env47320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47319_47320 : H12AffineEnvironment.transform 9 85 env47319 = env47320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env47319 == env47320) = true)

theorem identity47320 : scanCanonicalize (H12AffineFastState.compose env47320 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47320 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env47321 : List Nat := [2,4,8,16,1,64,128,256,341,85,391,1,349,324,276,83,277,210,320,277,0,476,17,67,192,341,286,324,325,406,336,341,256,341,276,65]

theorem envBound47321 : H12AffineFastState.Bounded env47321 := by
  intro p hp
  have h : env47321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47320_47321 : H12AffineEnvironment.transform 4 1 env47320 = env47321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47320 == env47321) = true)

theorem identity47321 : scanCanonicalize (H12AffineFastState.compose env47321 (packedSelected [0,1,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound47321 : packedSelected [0,1,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47322 : List Nat := [2,4,8,16,1,64,84,256,341,85,339,1,349,324,276,83,277,6,320,277,0,264,17,67,20,341,286,324,325,322,336,341,256,341,276,65]

theorem envBound47322 : H12AffineFastState.Bounded env47322 := by
  intro p hp
  have h : env47322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47321_47322 : H12AffineEnvironment.transform 6 84 env47321 = env47322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env47321 == env47322) = true)

theorem identity47322 : scanCanonicalize (H12AffineFastState.compose env47322 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47322 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47323 : List Nat := [2,4,8,16,1,64,84,68,17,85,23,1,25,0,80,83,81,6,4,81,0,76,17,67,20,17,90,0,1,6,20,17,68,17,80,65]

theorem envBound47323 : H12AffineFastState.Bounded env47323 := by
  intro p hp
  have h : env47323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47322_47323 : H12AffineEnvironment.transform 7 68 env47322 = env47323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47322 == env47323) = true)

theorem identity47323 : scanCanonicalize (H12AffineFastState.compose env47323 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound47323 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47324 : List Nat := [2,4,8,13,1,64,73,68,12,72,10,1,4,0,77,78,76,6,4,76,0,76,12,67,9,12,71,0,1,6,9,12,68,12,77,65]

theorem envBound47324 : H12AffineFastState.Bounded env47324 := by
  intro p hp
  have h : env47324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47323_47324 : H12AffineEnvironment.transform 3 13 env47323 = env47324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env47323 == env47324) = true)

theorem identity47324 : scanCanonicalize (H12AffineFastState.compose env47324 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound47324 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47325 : List Nat := [2,4,8,13,1,7,14,3,12,15,10,1,4,0,10,9,11,6,4,11,0,11,12,4,9,12,0,0,1,6,9,12,3,12,10,6]

theorem envBound47325 : H12AffineFastState.Bounded env47325 := by
  intro p hp
  have h : env47325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47324_47325 : H12AffineEnvironment.transform 5 7 env47324 = env47325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env47324 == env47325) = true)

def env47326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123165,28889,78895,385203,90415,1297,96346,25884,74798,256,25881,1345,21072]

theorem envBound47326 : H12AffineFastState.Bounded env47326 := by
  intro p hp
  have h : env47326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47068_47326 : H12AffineEnvironment.transform 18 21585 env47068 = env47326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env47068 == env47326) = true)

theorem identity47326 : scanCanonicalize (H12AffineFastState.compose env47326 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound47326 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4097,5276,91183,66897,28889,78895,328959,90415,1297,96346,25884,74798,256,25881,1345,21072]

theorem envBound47327 : H12AffineFastState.Bounded env47327 := by
  intro p hp
  have h : env47327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47326_47327 : H12AffineEnvironment.transform 14 25676 env47326 = env47327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env47326 == env47327) = true)

def env47328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4097,5276,74047,66897,13769,78895,328959,74815,1297,81226,8204,74798,256,8201,1345,5952]

theorem envBound47328 : H12AffineFastState.Bounded env47328 := by
  intro p hp
  have h : env47328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47327_47328 : H12AffineEnvironment.transform 13 1296 env47327 = env47328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env47327 == env47328) = true)

def env47329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4097,5276,74047,66897,13769,78895,1151,74815,1297,81226,8204,74798,256,8201,1345,5952]

theorem envBound47329 : H12AffineFastState.Bounded env47329 := by
  intro p hp
  have h : env47329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47328_47329 : H12AffineEnvironment.transform 17 65664 env47328 = env47329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47328 == env47329) = true)

theorem identity47329 : scanCanonicalize (H12AffineFastState.compose env47329 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound47329 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,65536,74863,65664,320,8541,0,1181,74047,66897,9672,74798,1151,74815,1297,77131,8204,74798,256,8201,1345,1857]

theorem envBound47330 : H12AffineFastState.Bounded env47330 := by
  intro p hp
  have h : env47330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47329_47330 : H12AffineEnvironment.transform 11 1 env47329 = env47330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47329 == env47330) = true)

def env47331 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8540,65536,74031,65664,320,8541,0,477,74047,65553,8328,74094,319,74111,81,75787,8204,74094,256,8201,1,513]

theorem envBound47331 : H12AffineFastState.Bounded env47331 := by
  intro p hp
  have h : env47331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47330_47331 : H12AffineEnvironment.transform 9 320 env47330 = env47331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47330 == env47331) = true)

theorem identity47331 : scanCanonicalize (H12AffineFastState.compose env47331 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47331 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47332 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,80,80,65536,65571,65664,320,81,0,477,65587,65553,388,65634,319,65651,81,67847,256,65634,256,261,1,513]

theorem envBound47332 : H12AffineFastState.Bounded env47332 := by
  intro p hp
  have h : env47332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47331_47332 : H12AffineEnvironment.transform 12 268 env47331 = env47332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47331 == env47332) = true)

theorem identity47332 : scanCanonicalize (H12AffineFastState.compose env47332 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound47332 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47333 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,80,80,311,276,439,320,81,0,477,260,294,388,341,319,324,81,2096,256,341,256,261,1,513]

theorem envBound47333 : H12AffineFastState.Bounded env47333 := by
  intro p hp
  have h : env47333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47332_47333 : H12AffineEnvironment.transform 15 311 env47332 = env47333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env47332 == env47333) = true)

theorem identity47333 : scanCanonicalize (H12AffineFastState.compose env47333 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47333 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47334 : List Nat := [2,4,8,16,32,64,128,4,512,68,2048,1,8,80,80,51,16,179,68,81,0,217,0,34,128,81,59,64,81,2096,4,81,4,1,1,513]

theorem envBound47334 : H12AffineFastState.Bounded env47334 := by
  intro p hp
  have h : env47334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47333_47334 : H12AffineEnvironment.transform 7 4 env47333 = env47334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47333 == env47334) = true)

theorem identity47334 : scanCanonicalize (H12AffineFastState.compose env47334 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound47334 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env47335 : List Nat := [2,4,8,16,32,64,128,4,152,68,2048,1,8,80,80,51,16,179,68,81,0,217,0,34,128,81,59,64,81,2096,4,81,4,1,1,153]

theorem envBound47335 : H12AffineFastState.Bounded env47335 := by
  intro p hp
  have h : env47335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47334_47335 : H12AffineEnvironment.transform 8 152 env47334 = env47335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env47334 == env47335) = true)

theorem identity47335 : scanCanonicalize (H12AffineFastState.compose env47335 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound47335 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env47336 : List Nat := [2,4,8,16,28,64,128,4,152,68,2048,1,8,80,80,15,16,143,68,81,0,217,0,30,128,81,7,64,81,2060,4,81,4,1,1,153]

theorem envBound47336 : H12AffineFastState.Bounded env47336 := by
  intro p hp
  have h : env47336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47335_47336 : H12AffineEnvironment.transform 4 28 env47335 = env47336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env47335 == env47336) = true)

theorem identity47336 : scanCanonicalize (H12AffineFastState.compose env47336 (packedSelected [13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47336 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47337 : List Nat := [2,4,8,0,12,64,128,4,136,68,2048,1,8,64,64,15,0,143,68,65,0,201,0,14,128,65,7,64,65,2060,4,65,4,1,1,137]

theorem envBound47337 : H12AffineFastState.Bounded env47337 := by
  intro p hp
  have h : env47337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47336_47337 : H12AffineEnvironment.transform 3 0 env47336 = env47337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47336 == env47337) = true)

theorem identity47337 : scanCanonicalize (H12AffineFastState.compose env47337 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound47337 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env47338 : List Nat := [2,4,8,0,12,64,128,4,136,68,75,1,8,64,64,15,0,143,68,65,0,201,0,14,128,65,7,64,65,71,4,65,4,1,1,137]

theorem envBound47338 : H12AffineFastState.Bounded env47338 := by
  intro p hp
  have h : env47338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47337_47338 : H12AffineEnvironment.transform 10 75 env47337 = env47338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env47337 == env47338) = true)

theorem identity47338 : scanCanonicalize (H12AffineFastState.compose env47338 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47338 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env47339 : List Nat := [2,4,3,0,7,64,128,4,131,68,64,1,3,64,64,4,0,132,68,65,0,194,0,5,128,65,7,64,65,71,4,65,4,1,1,130]

theorem envBound47339 : H12AffineFastState.Bounded env47339 := by
  intro p hp
  have h : env47339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47338_47339 : H12AffineEnvironment.transform 2 3 env47338 = env47339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47338 == env47339) = true)

theorem identity47339 : scanCanonicalize (H12AffineFastState.compose env47339 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound47339 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env47340 : List Nat := [2,4,3,0,7,3,128,4,131,7,3,1,3,3,3,4,0,132,7,2,0,129,0,5,128,2,7,3,2,4,4,2,4,1,1,130]

theorem envBound47340 : H12AffineFastState.Bounded env47340 := by
  intro p hp
  have h : env47340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47339_47340 : H12AffineEnvironment.transform 5 3 env47339 = env47340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env47339 == env47340) = true)

theorem identity47340 : scanCanonicalize (H12AffineFastState.compose env47340 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound47340 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47341 : List Nat := [2,4,3,0,7,3,7,4,4,7,3,1,3,3,3,4,0,3,7,2,0,6,0,5,7,2,7,3,2,4,4,2,4,1,1,5]

theorem envBound47341 : H12AffineFastState.Bounded env47341 := by
  intro p hp
  have h : env47341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47340_47341 : H12AffineEnvironment.transform 6 7 env47340 = env47341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env47340 == env47341) = true)

theorem identity47341 : scanCanonicalize (H12AffineFastState.compose env47341 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47342 : List Nat := [0,4,1,0,5,1,5,4,4,5,1,1,1,1,1,4,0,1,5,0,0,4,0,5,5,0,5,1,0,4,4,0,4,1,1,5]

theorem envBound47342 : H12AffineFastState.Bounded env47342 := by
  intro p hp
  have h : env47342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47341_47342 : H12AffineEnvironment.transform 0 0 env47341 = env47342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47341 == env47342) = true)

def env47343 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,65536,74030,65664,320,8541,0,476,74047,65552,8329,74095,318,74110,80,75786,8204,74095,256,8201,0,512]

theorem envBound47343 : H12AffineFastState.Bounded env47343 := by
  intro p hp
  have h : env47343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47330_47343 : H12AffineEnvironment.transform 9 321 env47330 = env47343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47330 == env47343) = true)

theorem identity47343 : scanCanonicalize (H12AffineFastState.compose env47343 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47343 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47344 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,114,8540,242,320,8541,0,476,8525,98,8329,8477,318,8460,80,10360,8204,8477,256,8201,0,512]

theorem envBound47344 : H12AffineFastState.Bounded env47344 := by
  intro p hp
  have h : env47344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47343_47344 : H12AffineEnvironment.transform 15 114 env47343 = env47344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47343 == env47344) = true)

theorem identity47344 : scanCanonicalize (H12AffineFastState.compose env47344 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47344 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47345 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8460,34,8460,162,272,8461,0,396,8477,50,8329,8477,318,8460,0,10280,8204,8477,256,8201,0,512]

theorem envBound47345 : H12AffineFastState.Bounded env47345 := by
  intro p hp
  have h : env47345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47344_47345 : H12AffineEnvironment.transform 5 16 env47344 = env47345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47344 == env47345) = true)

theorem identity47345 : scanCanonicalize (H12AffineFastState.compose env47345 (packedSelected [2,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound47345 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env47346 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2721,1,2989,34,2989,162,272,2988,0,396,3004,50,2600,3004,318,2989,0,649,2733,3004,256,2728,0,512]

theorem envBound47346 : H12AffineFastState.Bounded env47346 := by
  intro p hp
  have h : env47346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47345_47346 : H12AffineEnvironment.transform 12 2721 env47345 = env47346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env47345 == env47346) = true)

theorem identity47346 : scanCanonicalize (H12AffineFastState.compose env47346 (packedSelected [0,1,2,5,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound47346 : packedSelected [0,1,2,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47347 : List Nat := [2,4,8,16,32,16,128,256,512,273,697,1,24,1,276,34,276,162,272,277,0,396,261,50,145,261,318,276,0,649,20,261,256,17,0,512]

theorem envBound47347 : H12AffineFastState.Bounded env47347 := by
  intro p hp
  have h : env47347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47346_47347 : H12AffineEnvironment.transform 10 697 env47346 = env47347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env47346 == env47347) = true)

theorem identity47347 : scanCanonicalize (H12AffineFastState.compose env47347 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound47347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47348 : List Nat := [2,4,8,16,32,16,56,256,512,273,513,1,24,1,276,34,276,26,272,277,0,308,261,50,41,261,318,276,0,561,20,261,256,17,0,512]

theorem envBound47348 : H12AffineFastState.Bounded env47348 := by
  intro p hp
  have h : env47348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47347_47348 : H12AffineEnvironment.transform 6 56 env47347 = env47348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env47347 == env47348) = true)

theorem identity47348 : scanCanonicalize (H12AffineFastState.compose env47348 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47348 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env47349 : List Nat := [2,4,8,16,10,16,18,256,512,273,513,1,24,1,276,8,276,26,272,277,0,286,261,24,3,261,276,276,0,539,20,261,256,17,0,512]

theorem envBound47349 : H12AffineFastState.Bounded env47349 := by
  intro p hp
  have h : env47349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47348_47349 : H12AffineEnvironment.transform 4 10 env47348 = env47349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47348 == env47349) = true)

theorem identity47349 : scanCanonicalize (H12AffineFastState.compose env47349 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound47349 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47350 : List Nat := [2,4,8,16,10,16,18,256,270,273,271,1,24,1,276,8,276,26,272,277,0,286,261,24,3,261,276,276,0,277,20,261,256,17,0,270]

theorem envBound47350 : H12AffineFastState.Bounded env47350 := by
  intro p hp
  have h : env47350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47349_47350 : H12AffineEnvironment.transform 8 270 env47349 = env47350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env47349 == env47350) = true)

theorem identity47350 : scanCanonicalize (H12AffineFastState.compose env47350 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound47350 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47351 : List Nat := [2,4,8,16,10,16,18,20,26,5,27,1,24,1,0,8,0,26,4,1,0,10,17,24,3,17,0,0,0,1,20,17,20,17,0,26]

theorem envBound47351 : H12AffineFastState.Bounded env47351 := by
  intro p hp
  have h : env47351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47350_47351 : H12AffineEnvironment.transform 7 20 env47350 = env47351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env47350 == env47351) = true)

theorem identity47351 : scanCanonicalize (H12AffineFastState.compose env47351 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47352 : List Nat := [2,4,4,16,6,16,18,20,22,5,23,1,20,1,0,4,0,22,4,1,0,6,17,20,3,17,0,0,0,1,20,17,20,17,0,22]

theorem envBound47352 : H12AffineFastState.Bounded env47352 := by
  intro p hp
  have h : env47352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47351_47352 : H12AffineEnvironment.transform 2 4 env47351 = env47352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47351 == env47352) = true)

theorem identity47352 : scanCanonicalize (H12AffineFastState.compose env47352 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47352 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47353 : List Nat := [2,4,4,7,6,7,5,3,1,5,0,1,3,1,0,4,0,1,4,1,0,6,6,3,3,6,0,0,0,1,3,6,3,6,0,1]

theorem envBound47353 : H12AffineFastState.Bounded env47353 := by
  intro p hp
  have h : env47353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47352_47353 : H12AffineEnvironment.transform 3 7 env47352 = env47353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47352 == env47353) = true)

def env47354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4097,5276,74047,66897,13769,78895,1150,74815,1297,81226,8204,74798,256,8201,1345,5952]

theorem envBound47354 : H12AffineFastState.Bounded env47354 := by
  intro p hp
  have h : env47354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47328_47354 : H12AffineEnvironment.transform 17 65665 env47328 = env47354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47328 == env47354) = true)

theorem identity47354 : scanCanonicalize (H12AffineFastState.compose env47354 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47354 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47355 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,65536,74031,65665,4417,8541,4097,4572,74047,65553,12425,78191,318,74111,81,79882,8204,74094,256,8201,1,4608]

theorem envBound47355 : H12AffineFastState.Bounded env47355 := by
  intro p hp
  have h : env47355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47354_47355 : H12AffineEnvironment.transform 9 320 env47354 = env47355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47354 == env47355) = true)

def env47356 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,80,8540,65536,74031,65665,533,8541,853,648,74047,65553,9181,74299,318,74111,81,76638,8204,74094,256,8201,1,340]

theorem envBound47356 : H12AffineFastState.Bounded env47356 := by
  intro p hp
  have h : env47356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47355_47356 : H12AffineEnvironment.transform 11 852 env47355 = env47356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env47355 == env47356) = true)

def env47357 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,65536,74031,65665,517,8525,837,648,74031,65537,9165,74283,302,74095,65,76622,8204,74094,256,8201,1,324]

theorem envBound47357 : H12AffineFastState.Bounded env47357 := by
  intro p hp
  have h : env47357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47356_47357 : H12AffineEnvironment.transform 3 0 env47356 = env47357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47356 == env47357) = true)

theorem identity47357 : scanCanonicalize (H12AffineFastState.compose env47357 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 482) := by decide +kernel

theorem selectedBound47357 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47358 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,482,64,174,65536,65741,65665,517,175,837,648,65741,65537,559,66505,302,65677,65,68268,494,65676,256,491,1,324]

theorem envBound47358 : H12AffineFastState.Bounded env47358 := by
  intro p hp
  have h : env47358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47357_47358 : H12AffineEnvironment.transform 12 482 env47357 = env47358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 482 env47357 == env47358) = true)

def env47359 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,482,64,174,2828,3009,2957,517,175,837,648,3009,2829,559,2245,302,2945,65,416,494,2944,256,491,1,324]

theorem envBound47359 : H12AffineFastState.Bounded env47359 := by
  intro p hp
  have h : env47359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47358_47359 : H12AffineEnvironment.transform 15 2828 env47358 = env47359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2828 env47358 == env47359) = true)

theorem identity47359 : scanCanonicalize (H12AffineFastState.compose env47359 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound47359 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env47360 : List Nat := [2,4,8,0,32,64,105,256,512,320,2048,836,267,64,71,2828,2856,2916,517,70,837,609,2856,2829,559,2092,302,2920,65,329,263,2921,256,258,1,324]

theorem envBound47360 : H12AffineFastState.Bounded env47360 := by
  intro p hp
  have h : env47360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47359_47360 : H12AffineEnvironment.transform 6 105 env47359 = env47360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env47359 == env47360) = true)

theorem identity47360 : scanCanonicalize (H12AffineFastState.compose env47360 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 619) := by decide +kernel

theorem selectedBound47360 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env47361 : List Nat := [2,4,8,0,32,64,105,256,512,320,619,836,267,64,71,359,323,271,517,70,837,609,323,358,559,583,302,259,65,329,263,258,256,258,1,324]

theorem envBound47361 : H12AffineFastState.Bounded env47361 := by
  intro p hp
  have h : env47361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47360_47361 : H12AffineEnvironment.transform 10 619 env47360 = env47361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 619 env47360 == env47361) = true)

theorem identity47361 : scanCanonicalize (H12AffineFastState.compose env47361 (packedSelected [0,3,4,7,8,9,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound47361 : packedSelected [0,3,4,7,8,9,13,15,17] rootPS < 2^1333 := by decide +kernel

def env47362 : List Nat := [2,4,8,0,32,64,105,256,292,320,335,96,267,64,71,359,323,271,289,70,97,325,323,358,267,355,302,259,65,329,263,258,256,258,1,324]

theorem envBound47362 : H12AffineFastState.Bounded env47362 := by
  intro p hp
  have h : env47362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47361_47362 : H12AffineEnvironment.transform 8 292 env47361 = env47362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env47361 == env47362) = true)

theorem identity47362 : scanCanonicalize (H12AffineFastState.compose env47362 (packedSelected [2,4,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound47362 : packedSelected [2,4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47363 : List Nat := [2,4,8,0,32,64,105,34,6,98,109,96,41,64,71,69,97,45,3,70,97,103,97,68,41,65,12,33,65,107,37,32,34,32,1,102]

theorem envBound47363 : H12AffineFastState.Bounded env47363 := by
  intro p hp
  have h : env47363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47362_47363 : H12AffineEnvironment.transform 7 34 env47362 = env47363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env47362 == env47363) = true)

theorem identity47363 : scanCanonicalize (H12AffineFastState.compose env47363 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound47363 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47364 : List Nat := [2,4,8,0,32,45,4,34,6,15,0,13,41,45,42,40,12,45,3,43,12,10,12,41,41,44,12,33,44,6,37,32,34,32,1,11]

theorem envBound47364 : H12AffineFastState.Bounded env47364 := by
  intro p hp
  have h : env47364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47363_47364 : H12AffineEnvironment.transform 5 45 env47363 = env47364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env47363 == env47364) = true)

theorem identity47364 : scanCanonicalize (H12AffineFastState.compose env47364 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47364 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47365 : List Nat := [2,4,8,0,0,13,4,2,6,15,0,13,9,13,10,8,12,13,3,11,12,10,12,9,9,12,12,1,12,6,5,0,2,0,1,11]

theorem envBound47365 : H12AffineFastState.Bounded env47365 := by
  intro p hp
  have h : env47365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47364_47365 : H12AffineEnvironment.transform 4 0 env47364 = env47365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47364 == env47365) = true)

def env47366 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,482,64,174,2829,3008,2956,517,175,837,648,3008,2828,559,2244,302,2944,65,417,494,2945,256,491,1,324]

theorem envBound47366 : H12AffineFastState.Bounded env47366 := by
  intro p hp
  have h : env47366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47358_47366 : H12AffineEnvironment.transform 15 2829 env47358 = env47366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2829 env47358 == env47366) = true)

theorem identity47366 : scanCanonicalize (H12AffineFastState.compose env47366 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 879) := by decide +kernel

theorem selectedBound47366 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env47367 : List Nat := [2,4,8,0,32,64,128,256,512,320,879,836,482,64,174,98,175,227,517,175,837,648,175,99,559,939,302,239,65,417,494,238,256,491,1,324]

theorem envBound47367 : H12AffineFastState.Bounded env47367 := by
  intro p hp
  have h : env47367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47366_47367 : H12AffineEnvironment.transform 10 879 env47366 = env47367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 879 env47366 == env47367) = true)

theorem identity47367 : scanCanonicalize (H12AffineFastState.compose env47367 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound47367 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47368 : List Nat := [2,4,8,0,32,64,128,256,260,320,107,64,482,64,174,98,175,227,257,175,65,396,175,99,299,175,302,239,65,417,494,238,256,491,1,324]

theorem envBound47368 : H12AffineFastState.Bounded env47368 := by
  intro p hp
  have h : env47368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47367_47368 : H12AffineEnvironment.transform 8 260 env47367 = env47368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env47367 == env47368) = true)

theorem identity47368 : scanCanonicalize (H12AffineFastState.compose env47368 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47368 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47369 : List Nat := [2,4,8,0,32,64,128,68,64,4,107,64,166,64,174,98,175,227,69,175,65,200,175,99,111,175,106,239,65,229,170,238,68,175,1,0]

theorem envBound47369 : H12AffineFastState.Bounded env47369 := by
  intro p hp
  have h : env47369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47368_47369 : H12AffineEnvironment.transform 7 68 env47368 = env47369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47368 == env47369) = true)

theorem identity47369 : scanCanonicalize (H12AffineFastState.compose env47369 (packedSelected [0,3,4,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound47369 : packedSelected [0,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47370 : List Nat := [2,4,8,0,32,64,98,68,64,4,107,64,68,64,76,98,77,1,69,77,65,42,77,99,111,77,106,13,65,7,72,12,68,77,1,0]

theorem envBound47370 : H12AffineFastState.Bounded env47370 := by
  intro p hp
  have h : env47370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47369_47370 : H12AffineEnvironment.transform 6 98 env47369 = env47370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env47369 == env47370) = true)

theorem identity47370 : scanCanonicalize (H12AffineFastState.compose env47370 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47370 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47371 : List Nat := [2,4,2,0,32,64,98,68,64,4,97,64,68,64,70,98,71,1,69,71,65,32,71,99,101,71,96,7,65,7,66,6,68,71,1,0]

theorem envBound47371 : H12AffineFastState.Bounded env47371 := by
  intro p hp
  have h : env47371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47370_47371 : H12AffineEnvironment.transform 2 2 env47370 = env47371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47370 == env47371) = true)

theorem identity47371 : scanCanonicalize (H12AffineFastState.compose env47371 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47372 : List Nat := [2,4,2,0,1,64,67,68,64,4,64,64,68,64,70,67,71,1,69,71,65,1,71,66,68,71,65,7,65,7,66,6,68,71,1,0]

theorem envBound47372 : H12AffineFastState.Bounded env47372 := by
  intro p hp
  have h : env47372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47371_47372 : H12AffineEnvironment.transform 4 1 env47371 = env47372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47371 == env47372) = true)

theorem identity47372 : scanCanonicalize (H12AffineFastState.compose env47372 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47372 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47373 : List Nat := [2,3,2,0,1,64,67,67,64,3,64,64,67,64,65,67,64,1,66,64,65,1,64,66,67,64,65,0,65,0,66,1,67,64,1,0]

theorem envBound47373 : H12AffineFastState.Bounded env47373 := by
  intro p hp
  have h : env47373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47372_47373 : H12AffineEnvironment.transform 1 3 env47372 = env47373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47372 == env47373) = true)

theorem identity47373 : scanCanonicalize (H12AffineFastState.compose env47373 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47374 : List Nat := [2,3,2,0,1,1,2,2,1,3,1,1,2,1,0,2,1,1,3,1,0,1,1,3,2,1,0,0,0,0,3,1,2,1,1,0]

theorem envBound47374 : H12AffineFastState.Bounded env47374 := by
  intro p hp
  have h : env47374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47373_47374 : H12AffineEnvironment.transform 5 1 env47373 = env47374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47373 == env47374) = true)

theorem identity47374 : scanCanonicalize (H12AffineFastState.compose env47374 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47375 : List Nat := [1,0,1,0,1,1,1,1,1,0,1,1,1,1,0,1,1,1,0,1,0,1,1,0,1,1,0,0,0,0,0,1,1,1,1,0]

theorem envBound47375 : H12AffineFastState.Bounded env47375 := by
  intro p hp
  have h : env47375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47374_47375 : H12AffineEnvironment.transform 0 1 env47374 = env47375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47374 == env47375) = true)

def env47376 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,65536,74031,65665,516,8524,836,648,74030,65536,9164,74282,303,74094,64,76623,8204,74094,256,8201,1,325]

theorem envBound47376 : H12AffineFastState.Bounded env47376 := by
  intro p hp
  have h : env47376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47356_47376 : H12AffineEnvironment.transform 3 1 env47356 = env47376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47356 == env47376) = true)

theorem identity47376 : scanCanonicalize (H12AffineFastState.compose env47376 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound47376 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47377 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,750,8192,65,8422,65536,73860,65665,516,8423,751,648,73861,65536,8807,74282,132,73925,64,76516,8204,73925,171,8201,1,238]

theorem envBound47377 : H12AffineFastState.Bounded env47377 := by
  intro p hp
  have h : env47377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47376_47377 : H12AffineEnvironment.transform 7 171 env47376 = env47377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env47376 == env47377) = true)

def env47378 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,750,72,65,174,65536,65740,65665,516,175,751,648,65741,65536,559,66146,132,65677,64,68268,68,65677,171,65,1,238]

theorem envBound47378 : H12AffineFastState.Bounded env47378 := by
  intro p hp
  have h : env47378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47377_47378 : H12AffineEnvironment.transform 12 72 env47377 = env47378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47377 == env47378) = true)

theorem identity47378 : scanCanonicalize (H12AffineFastState.compose env47378 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 653) := by decide +kernel

theorem selectedBound47378 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47379 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,750,72,65,174,653,577,524,516,175,751,648,576,653,559,239,132,512,64,2081,68,512,171,65,1,238]

theorem envBound47379 : H12AffineFastState.Bounded env47379 := by
  intro p hp
  have h : env47379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47378_47379 : H12AffineEnvironment.transform 15 653 env47378 = env47379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 653 env47378 == env47379) = true)

theorem identity47379 : scanCanonicalize (H12AffineFastState.compose env47379 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound47379 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47380 : List Nat := [2,4,8,1,32,64,46,5,512,69,2048,576,72,65,0,547,577,524,516,1,577,550,576,547,559,65,42,512,64,2081,68,512,5,65,1,64]

theorem envBound47380 : H12AffineFastState.Bounded env47380 := by
  intro p hp
  have h : env47380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47379_47380 : H12AffineEnvironment.transform 6 46 env47379 = env47380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env47379 == env47380) = true)

theorem identity47380 : scanCanonicalize (H12AffineFastState.compose env47380 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound47380 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47381 : List Nat := [2,4,8,1,32,33,46,5,512,36,2048,545,41,32,0,547,544,524,516,1,544,550,545,547,559,32,42,512,33,2081,37,512,5,32,1,33]

theorem envBound47381 : H12AffineFastState.Bounded env47381 := by
  intro p hp
  have h : env47381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47380_47381 : H12AffineEnvironment.transform 5 33 env47380 = env47381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env47380 == env47381) = true)

theorem identity47381 : scanCanonicalize (H12AffineFastState.compose env47381 (packedSelected [5,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound47381 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env47382 : List Nat := [2,4,8,1,32,33,46,5,44,36,2048,13,41,32,0,15,12,32,40,1,12,10,13,15,3,32,42,44,33,2081,37,44,5,32,1,33]

theorem envBound47382 : H12AffineFastState.Bounded env47382 := by
  intro p hp
  have h : env47382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47381_47382 : H12AffineEnvironment.transform 8 44 env47381 = env47382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env47381 == env47382) = true)

theorem identity47382 : scanCanonicalize (H12AffineFastState.compose env47382 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47382 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47383 : List Nat := [2,3,8,1,32,33,41,2,43,35,2048,10,41,32,0,8,11,32,40,1,11,10,10,8,3,32,42,43,33,2081,34,43,2,32,1,33]

theorem envBound47383 : H12AffineFastState.Bounded env47383 := by
  intro p hp
  have h : env47383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47382_47383 : H12AffineEnvironment.transform 1 3 env47382 = env47383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47382 == env47383) = true)

theorem identity47383 : scanCanonicalize (H12AffineFastState.compose env47383 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47383 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47384 : List Nat := [2,3,8,1,10,11,3,2,1,9,2048,10,3,10,0,8,11,10,2,1,11,10,10,8,3,10,0,1,11,2059,8,1,2,10,1,11]

theorem envBound47384 : H12AffineFastState.Bounded env47384 := by
  intro p hp
  have h : env47384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47383_47384 : H12AffineEnvironment.transform 4 10 env47383 = env47384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47383 == env47384) = true)

theorem identity47384 : scanCanonicalize (H12AffineFastState.compose env47384 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound47384 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47385 : List Nat := [2,3,8,1,10,11,3,2,1,9,11,10,3,10,0,8,11,10,2,1,11,10,10,8,3,10,0,1,11,0,8,1,2,10,1,11]

theorem envBound47385 : H12AffineFastState.Bounded env47385 := by
  intro p hp
  have h : env47385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47384_47385 : H12AffineEnvironment.transform 10 11 env47384 = env47385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env47384 == env47385) = true)

theorem identity47385 : scanCanonicalize (H12AffineFastState.compose env47385 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47386 : List Nat := [2,3,2,1,0,1,3,2,1,3,1,0,3,0,0,2,1,0,2,1,1,0,0,2,3,0,0,1,1,0,2,1,2,0,1,1]

theorem envBound47386 : H12AffineFastState.Bounded env47386 := by
  intro p hp
  have h : env47386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47385_47386 : H12AffineEnvironment.transform 2 2 env47385 = env47386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47385 == env47386) = true)

def env47387 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,750,73,65,175,65536,65741,65665,516,174,751,648,65740,65536,558,66147,132,65676,64,68269,69,65676,171,64,1,238]

theorem envBound47387 : H12AffineFastState.Bounded env47387 := by
  intro p hp
  have h : env47387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47377_47387 : H12AffineEnvironment.transform 12 73 env47377 = env47387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47377 == env47387) = true)

theorem identity47387 : scanCanonicalize (H12AffineFastState.compose env47387 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound47387 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47388 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,750,73,65,175,99,174,226,516,174,751,648,175,99,558,512,132,239,64,2766,69,239,171,64,1,238]

theorem envBound47388 : H12AffineFastState.Bounded env47388 := by
  intro p hp
  have h : env47388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47387_47388 : H12AffineEnvironment.transform 15 99 env47387 = env47388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env47387 == env47388) = true)

theorem identity47388 : scanCanonicalize (H12AffineFastState.compose env47388 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound47388 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47389 : List Nat := [2,4,8,1,32,64,128,171,175,235,2048,65,73,65,175,99,174,226,171,174,64,39,175,99,129,175,132,239,64,2145,69,239,171,64,1,238]

theorem envBound47389 : H12AffineFastState.Bounded env47389 := by
  intro p hp
  have h : env47389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47388_47389 : H12AffineEnvironment.transform 8 175 env47388 = env47389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env47388 == env47389) = true)

theorem identity47389 : scanCanonicalize (H12AffineFastState.compose env47389 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound47389 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47390 : List Nat := [2,4,8,1,32,64,110,69,65,5,2048,65,73,65,65,99,64,12,69,64,64,39,65,99,111,65,106,1,64,2145,69,1,69,64,1,0]

theorem envBound47390 : H12AffineFastState.Bounded env47390 := by
  intro p hp
  have h : env47390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47389_47390 : H12AffineEnvironment.transform 6 110 env47389 = env47390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env47389 == env47390) = true)

theorem identity47390 : scanCanonicalize (H12AffineFastState.compose env47390 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound47390 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47391 : List Nat := [2,4,8,1,32,64,110,69,65,5,65,65,73,65,65,99,64,12,69,64,64,39,65,99,111,65,106,1,64,32,69,1,69,64,1,0]

theorem envBound47391 : H12AffineFastState.Bounded env47391 := by
  intro p hp
  have h : env47391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47390_47391 : H12AffineEnvironment.transform 10 65 env47390 = env47391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env47390 == env47391) = true)

theorem identity47391 : scanCanonicalize (H12AffineFastState.compose env47391 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound47391 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47392 : List Nat := [2,4,8,1,32,33,15,36,32,5,32,32,40,32,32,2,33,12,36,33,33,39,32,2,14,32,11,1,33,32,36,1,36,33,1,0]

theorem envBound47392 : H12AffineFastState.Bounded env47392 := by
  intro p hp
  have h : env47392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47391_47392 : H12AffineEnvironment.transform 5 33 env47391 = env47392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env47391 == env47392) = true)

theorem identity47392 : scanCanonicalize (H12AffineFastState.compose env47392 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47392 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47393 : List Nat := [2,4,8,1,10,11,15,14,10,5,10,10,2,10,10,2,11,12,14,11,11,13,10,2,14,10,11,1,11,10,14,1,14,11,1,0]

theorem envBound47393 : H12AffineFastState.Bounded env47393 := by
  intro p hp
  have h : env47393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47392_47393 : H12AffineEnvironment.transform 4 10 env47392 = env47393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47392 == env47393) = true)

theorem identity47393 : scanCanonicalize (H12AffineFastState.compose env47393 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47393 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47394 : List Nat := [2,2,8,1,10,11,9,8,10,3,10,10,2,10,10,2,11,10,8,11,11,11,10,2,8,10,11,1,11,10,8,1,8,11,1,0]

theorem envBound47394 : H12AffineFastState.Bounded env47394 := by
  intro p hp
  have h : env47394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47393_47394 : H12AffineEnvironment.transform 1 2 env47393 = env47394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47393 == env47394) = true)

theorem identity47394 : scanCanonicalize (H12AffineFastState.compose env47394 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47395 : List Nat := [2,2,2,1,0,1,3,2,0,3,0,0,2,0,0,2,1,0,2,1,1,1,0,2,2,0,1,1,1,0,2,1,2,1,1,0]

theorem envBound47395 : H12AffineFastState.Bounded env47395 := by
  intro p hp
  have h : env47395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47394_47395 : H12AffineEnvironment.transform 2 2 env47394 = env47395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47394 == env47395) = true)

def env47396 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,80,8540,65536,74031,65665,532,8541,852,649,74047,65553,9180,74298,318,74111,81,76639,8204,74094,256,8201,1,341]

theorem envBound47396 : H12AffineFastState.Bounded env47396 := by
  intro p hp
  have h : env47396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47355_47396 : H12AffineEnvironment.transform 11 853 env47355 = env47396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env47355 == env47396) = true)

def env47397 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,65536,74031,65665,516,8525,836,649,74031,65537,9164,74282,302,74095,65,76623,8204,74094,256,8201,1,325]

theorem envBound47397 : H12AffineFastState.Bounded env47397 := by
  intro p hp
  have h : env47397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47396_47397 : H12AffineEnvironment.transform 3 0 env47396 = env47397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47396 == env47397) = true)

theorem identity47397 : scanCanonicalize (H12AffineFastState.compose env47397 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 205) := by decide +kernel

theorem selectedBound47397 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47398 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,205,8674,76,516,8525,836,649,8674,204,9164,8935,302,8610,65,11138,8204,8611,256,8201,1,325]

theorem envBound47398 : H12AffineFastState.Bounded env47398 := by
  intro p hp
  have h : env47398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47397_47398 : H12AffineEnvironment.transform 15 205 env47397 = env47398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 205 env47397 == env47398) = true)

def env47399 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,72,64,260,205,426,76,516,261,836,649,426,204,900,687,302,490,65,3018,68,491,256,65,1,325]

theorem envBound47399 : H12AffineFastState.Bounded env47399 := by
  intro p hp
  have h : env47399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47398_47399 : H12AffineEnvironment.transform 12 72 env47398 = env47399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47398 == env47399) = true)

theorem identity47399 : scanCanonicalize (H12AffineFastState.compose env47399 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 490) := by decide +kernel

theorem selectedBound47399 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47400 : List Nat := [2,4,8,0,32,64,128,256,490,320,2048,175,72,64,260,205,426,76,494,261,174,355,426,204,110,325,302,490,65,2080,68,491,256,65,1,325]

theorem envBound47400 : H12AffineFastState.Bounded env47400 := by
  intro p hp
  have h : env47400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47399_47400 : H12AffineEnvironment.transform 8 490 env47399 = env47400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 490 env47399 == env47400) = true)

theorem identity47400 : scanCanonicalize (H12AffineFastState.compose env47400 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47400 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47401 : List Nat := [2,4,8,0,32,64,128,4,238,68,2048,175,72,64,0,205,174,76,234,1,174,103,174,204,110,65,42,238,65,2080,68,239,4,65,1,65]

theorem envBound47401 : H12AffineFastState.Bounded env47401 := by
  intro p hp
  have h : env47401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47400_47401 : H12AffineEnvironment.transform 7 4 env47400 = env47401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47400 == env47401) = true)

theorem identity47401 : scanCanonicalize (H12AffineFastState.compose env47401 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound47401 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47402 : List Nat := [2,4,8,0,32,33,128,4,143,37,2048,175,41,33,0,172,174,45,139,1,174,6,174,173,15,32,42,143,32,2080,37,142,4,32,1,32]

theorem envBound47402 : H12AffineFastState.Bounded env47402 := by
  intro p hp
  have h : env47402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47401_47402 : H12AffineEnvironment.transform 5 33 env47401 = env47402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env47401 == env47402) = true)

theorem identity47402 : scanCanonicalize (H12AffineFastState.compose env47402 (packedSelected [5,8,13] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47402 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env47403 : List Nat := [2,4,4,0,32,33,128,4,131,37,2048,163,37,33,0,160,162,33,135,1,162,6,162,161,3,32,38,131,32,2080,37,130,4,32,1,32]

theorem envBound47403 : H12AffineFastState.Bounded env47403 := by
  intro p hp
  have h : env47403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47402_47403 : H12AffineEnvironment.transform 2 4 env47402 = env47403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47402 == env47403) = true)

theorem identity47403 : scanCanonicalize (H12AffineFastState.compose env47403 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47403 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47404 : List Nat := [2,3,3,0,32,33,128,3,131,34,2048,163,34,33,0,160,162,33,128,1,162,1,162,161,3,32,33,131,32,2080,34,130,3,32,1,32]

theorem envBound47404 : H12AffineFastState.Bounded env47404 := by
  intro p hp
  have h : env47404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47403_47404 : H12AffineEnvironment.transform 1 3 env47403 = env47404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47403 == env47404) = true)

theorem identity47404 : scanCanonicalize (H12AffineFastState.compose env47404 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound47404 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47405 : List Nat := [2,3,3,0,32,33,2,3,1,34,2048,33,34,33,0,34,32,33,2,1,32,1,32,35,3,32,33,1,32,2080,34,0,3,32,1,32]

theorem envBound47405 : H12AffineFastState.Bounded env47405 := by
  intro p hp
  have h : env47405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47404_47405 : H12AffineEnvironment.transform 6 2 env47404 = env47405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env47404 == env47405) = true)

theorem identity47405 : scanCanonicalize (H12AffineFastState.compose env47405 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound47405 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47406 : List Nat := [2,3,3,0,32,33,2,3,1,34,32,33,34,33,0,34,32,33,2,1,32,1,32,35,3,32,33,1,32,0,34,0,3,32,1,32]

theorem envBound47406 : H12AffineFastState.Bounded env47406 := by
  intro p hp
  have h : env47406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47405_47406 : H12AffineEnvironment.transform 10 32 env47405 = env47406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env47405 == env47406) = true)

def env47407 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,73,64,261,205,427,76,516,260,836,649,427,204,901,686,302,491,65,3019,69,490,256,64,1,325]

theorem envBound47407 : H12AffineFastState.Bounded env47407 := by
  intro p hp
  have h : env47407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47398_47407 : H12AffineEnvironment.transform 12 73 env47398 = env47407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47398 == env47407) = true)

theorem identity47407 : scanCanonicalize (H12AffineFastState.compose env47407 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound47407 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47408 : List Nat := [2,4,8,0,32,64,47,256,512,320,2048,837,73,64,261,98,260,76,516,260,836,550,260,99,810,513,302,324,65,2916,69,325,256,64,1,325]

theorem envBound47408 : H12AffineFastState.Bounded env47408 := by
  intro p hp
  have h : env47408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47407_47408 : H12AffineEnvironment.transform 6 47 env47407 = env47408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env47407 == env47408) = true)

theorem identity47408 : scanCanonicalize (H12AffineFastState.compose env47408 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47408 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47409 : List Nat := [2,4,8,0,32,64,47,256,261,320,2048,64,73,64,261,98,260,76,257,260,65,291,260,99,47,260,302,324,65,2145,69,325,256,64,1,325]

theorem envBound47409 : H12AffineFastState.Bounded env47409 := by
  intro p hp
  have h : env47409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47408_47409 : H12AffineEnvironment.transform 8 261 env47408 = env47409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47408 == env47409) = true)

theorem identity47409 : scanCanonicalize (H12AffineFastState.compose env47409 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47409 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47410 : List Nat := [2,4,8,0,32,64,47,5,0,69,2048,64,73,64,0,98,1,76,4,1,65,38,1,99,47,1,43,65,65,2145,69,64,5,64,1,64]

theorem envBound47410 : H12AffineFastState.Bounded env47410 := by
  intro p hp
  have h : env47410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47409_47410 : H12AffineEnvironment.transform 7 5 env47409 = env47410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47409 == env47410) = true)

theorem identity47410 : scanCanonicalize (H12AffineFastState.compose env47410 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound47410 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47411 : List Nat := [2,4,8,0,32,64,47,5,0,69,33,64,73,64,0,98,1,76,4,1,65,38,1,99,47,1,43,65,65,64,69,64,5,64,1,64]

theorem envBound47411 : H12AffineFastState.Bounded env47411 := by
  intro p hp
  have h : env47411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47410_47411 : H12AffineEnvironment.transform 10 33 env47410 = env47411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env47410 == env47411) = true)

theorem identity47411 : scanCanonicalize (H12AffineFastState.compose env47411 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound47411 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47412 : List Nat := [2,4,8,0,32,33,47,5,0,36,33,33,40,33,0,3,1,45,4,1,32,38,1,2,47,1,43,32,32,33,36,33,5,33,1,33]

theorem envBound47412 : H12AffineFastState.Bounded env47412 := by
  intro p hp
  have h : env47412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47411_47412 : H12AffineEnvironment.transform 5 33 env47411 = env47412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env47411 == env47412) = true)

theorem identity47412 : scanCanonicalize (H12AffineFastState.compose env47412 (packedSelected [0,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47412 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env47413 : List Nat := [2,3,8,0,32,33,40,2,0,35,33,33,40,33,0,3,1,42,3,1,32,33,1,2,40,1,43,32,32,33,35,33,2,33,1,33]

theorem envBound47413 : H12AffineFastState.Bounded env47413 := by
  intro p hp
  have h : env47413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47412_47413 : H12AffineEnvironment.transform 1 3 env47412 = env47413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47412 == env47413) = true)

theorem identity47413 : scanCanonicalize (H12AffineFastState.compose env47413 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47414 : List Nat := [2,3,8,0,1,0,9,2,0,2,0,0,9,0,0,3,1,11,3,1,1,0,1,2,9,1,10,1,1,0,2,0,2,0,1,0]

theorem envBound47414 : H12AffineFastState.Bounded env47414 := by
  intro p hp
  have h : env47414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47413_47414 : H12AffineEnvironment.transform 4 1 env47413 = env47414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47413 == env47414) = true)

theorem identity47414 : scanCanonicalize (H12AffineFastState.compose env47414 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47415 : List Nat := [2,3,2,0,1,0,3,2,0,2,0,0,3,0,0,3,1,1,3,1,1,0,1,2,3,1,0,1,1,0,2,0,2,0,1,0]

theorem envBound47415 : H12AffineFastState.Bounded env47415 := by
  intro p hp
  have h : env47415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47414_47415 : H12AffineEnvironment.transform 2 2 env47414 = env47415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47414 == env47415) = true)

def env47416 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,65536,74031,65665,517,8524,837,649,74030,65536,9165,74283,303,74094,64,76622,8204,74094,256,8201,1,324]

theorem envBound47416 : H12AffineFastState.Bounded env47416 := by
  intro p hp
  have h : env47416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47396_47416 : H12AffineEnvironment.transform 3 1 env47396 = env47416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47396 == env47416) = true)

theorem identity47416 : scanCanonicalize (H12AffineFastState.compose env47416 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8324) := by decide +kernel

theorem selectedBound47416 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47417 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,8324,427,8197,517,8524,837,649,426,8324,9165,687,303,490,64,3018,8204,490,256,8201,1,324]

theorem envBound47417 : H12AffineFastState.Bounded env47417 := by
  intro p hp
  have h : env47417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47416_47417 : H12AffineEnvironment.transform 15 8324 env47416 = env47417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8324 env47416 == env47417) = true)

def env47418 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,72,65,261,204,427,77,517,260,837,649,426,204,901,687,303,490,64,3018,68,490,256,65,1,324]

theorem envBound47418 : H12AffineFastState.Bounded env47418 := by
  intro p hp
  have h : env47418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47417_47418 : H12AffineEnvironment.transform 12 72 env47417 = env47418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47417 == env47418) = true)

theorem identity47418 : scanCanonicalize (H12AffineFastState.compose env47418 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 491) := by decide +kernel

theorem selectedBound47418 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47419 : List Nat := [2,4,8,1,32,64,128,256,491,320,2048,175,72,65,261,204,427,77,494,260,174,354,426,204,110,324,303,490,64,2081,68,490,256,65,1,324]

theorem envBound47419 : H12AffineFastState.Bounded env47419 := by
  intro p hp
  have h : env47419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47418_47419 : H12AffineEnvironment.transform 8 491 env47418 = env47419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 491 env47418 == env47419) = true)

theorem identity47419 : scanCanonicalize (H12AffineFastState.compose env47419 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47419 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47420 : List Nat := [2,4,8,1,32,64,128,5,238,69,2048,175,72,65,0,204,174,77,235,1,174,103,175,204,110,65,42,239,64,2081,68,239,5,65,1,65]

theorem envBound47420 : H12AffineFastState.Bounded env47420 := by
  intro p hp
  have h : env47420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47419_47420 : H12AffineEnvironment.transform 7 5 env47419 = env47420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47419 == env47420) = true)

theorem identity47420 : scanCanonicalize (H12AffineFastState.compose env47420 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 79) := by decide +kernel

theorem selectedBound47420 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47421 : List Nat := [2,4,8,1,32,64,79,5,33,69,2048,96,72,65,0,3,97,77,36,1,97,103,96,3,110,65,42,32,64,2081,68,32,5,65,1,65]

theorem envBound47421 : H12AffineFastState.Bounded env47421 := by
  intro p hp
  have h : env47421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47420_47421 : H12AffineEnvironment.transform 6 79 env47420 = env47421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 79 env47420 == env47421) = true)

theorem identity47421 : scanCanonicalize (H12AffineFastState.compose env47421 (packedSelected [0,1,3,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47421 : packedSelected [0,1,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47422 : List Nat := [2,4,8,1,13,64,79,5,12,69,2048,77,72,65,0,3,76,77,9,1,76,74,77,3,67,65,7,13,64,2060,68,13,5,65,1,65]

theorem envBound47422 : H12AffineFastState.Bounded env47422 := by
  intro p hp
  have h : env47422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47421_47422 : H12AffineEnvironment.transform 4 13 env47421 = env47422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47421 == env47422) = true)

theorem identity47422 : scanCanonicalize (H12AffineFastState.compose env47422 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound47422 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env47423 : List Nat := [2,4,8,1,13,64,79,5,12,69,75,77,72,65,0,3,76,77,9,1,76,74,77,3,67,65,7,13,64,71,68,13,5,65,1,65]

theorem envBound47423 : H12AffineFastState.Bounded env47423 := by
  intro p hp
  have h : env47423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47422_47423 : H12AffineEnvironment.transform 10 75 env47422 = env47423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env47422 == env47423) = true)

theorem identity47423 : scanCanonicalize (H12AffineFastState.compose env47423 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound47423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47424 : List Nat := [2,4,8,1,13,13,2,5,12,8,6,0,5,12,0,3,1,0,9,1,1,7,0,3,14,12,7,13,13,10,9,13,5,12,1,12]

theorem envBound47424 : H12AffineFastState.Bounded env47424 := by
  intro p hp
  have h : env47424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47423_47424 : H12AffineEnvironment.transform 5 13 env47423 = env47424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env47423 == env47424) = true)

theorem identity47424 : scanCanonicalize (H12AffineFastState.compose env47424 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47424 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47425 : List Nat := [2,3,8,1,10,10,2,2,11,8,1,0,2,11,0,3,1,0,9,1,1,0,0,3,9,11,0,10,10,10,9,10,2,11,1,11]

theorem envBound47425 : H12AffineFastState.Bounded env47425 := by
  intro p hp
  have h : env47425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47424_47425 : H12AffineEnvironment.transform 1 3 env47424 = env47425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47424 == env47425) = true)

theorem identity47425 : scanCanonicalize (H12AffineFastState.compose env47425 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47425 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47426 : List Nat := [2,3,3,1,1,1,2,2,0,3,1,0,2,0,0,3,1,0,2,1,1,0,0,3,2,0,0,1,1,1,2,1,2,0,1,0]

theorem envBound47426 : H12AffineFastState.Bounded env47426 := by
  intro p hp
  have h : env47426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47425_47426 : H12AffineEnvironment.transform 2 3 env47425 = env47426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47425 == env47426) = true)

def env47427 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,73,65,260,205,427,76,517,261,837,649,426,205,900,687,303,490,64,3018,69,490,256,64,1,324]

theorem envBound47427 : H12AffineFastState.Bounded env47427 := by
  intro p hp
  have h : env47427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47417_47427 : H12AffineEnvironment.transform 12 73 env47417 = env47427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47417 == env47427) = true)

theorem identity47427 : scanCanonicalize (H12AffineFastState.compose env47427 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound47427 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47428 : List Nat := [2,4,8,1,32,64,46,256,512,320,2048,836,73,65,260,99,261,76,517,261,837,551,260,99,810,513,303,324,64,2916,69,324,256,64,1,324]

theorem envBound47428 : H12AffineFastState.Bounded env47428 := by
  intro p hp
  have h : env47428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47427_47428 : H12AffineEnvironment.transform 6 46 env47427 = env47428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env47427 == env47428) = true)

theorem identity47428 : scanCanonicalize (H12AffineFastState.compose env47428 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47428 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47429 : List Nat := [2,4,8,1,32,64,46,256,261,320,2048,65,73,65,260,99,261,76,256,261,64,290,260,99,47,260,303,324,64,2145,69,324,256,64,1,324]

theorem envBound47429 : H12AffineFastState.Bounded env47429 := by
  intro p hp
  have h : env47429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47428_47429 : H12AffineEnvironment.transform 8 261 env47428 = env47429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47428 == env47429) = true)

theorem identity47429 : scanCanonicalize (H12AffineFastState.compose env47429 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47429 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47430 : List Nat := [2,4,8,1,32,64,46,5,0,69,2048,65,73,65,1,99,0,76,5,0,64,39,1,99,47,1,42,65,64,2145,69,65,5,64,1,65]

theorem envBound47430 : H12AffineFastState.Bounded env47430 := by
  intro p hp
  have h : env47430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47429_47430 : H12AffineEnvironment.transform 7 5 env47429 = env47430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47429 == env47430) = true)

theorem identity47430 : scanCanonicalize (H12AffineFastState.compose env47430 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound47430 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47431 : List Nat := [2,4,8,1,32,33,46,5,0,36,2048,32,40,32,1,2,0,45,5,0,33,39,1,2,47,1,42,32,33,2048,36,32,5,33,1,32]

theorem envBound47431 : H12AffineFastState.Bounded env47431 := by
  intro p hp
  have h : env47431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47430_47431 : H12AffineEnvironment.transform 5 33 env47430 = env47431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env47430 == env47431) = true)

theorem identity47431 : scanCanonicalize (H12AffineFastState.compose env47431 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound47431 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env47432 : List Nat := [2,4,8,1,32,33,46,5,0,36,38,32,40,32,1,2,0,45,5,0,33,39,1,2,47,1,42,32,33,38,36,32,5,33,1,32]

theorem envBound47432 : H12AffineFastState.Bounded env47432 := by
  intro p hp
  have h : env47432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47431_47432 : H12AffineEnvironment.transform 10 38 env47431 = env47432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env47431 == env47432) = true)

theorem identity47432 : scanCanonicalize (H12AffineFastState.compose env47432 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47433 : List Nat := [2,2,8,1,32,33,40,3,0,34,32,32,40,32,1,2,0,43,3,0,33,33,1,2,41,1,42,32,33,32,34,32,3,33,1,32]

theorem envBound47433 : H12AffineFastState.Bounded env47433 := by
  intro p hp
  have h : env47433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47432_47433 : H12AffineEnvironment.transform 1 2 env47432 = env47433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47432 == env47433) = true)

def env47434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4097,5276,74046,66897,13768,78895,328959,74814,1297,81227,8205,74798,256,8200,1345,5953]

theorem envBound47434 : H12AffineFastState.Bounded env47434 := by
  intro p hp
  have h : env47434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47327_47434 : H12AffineEnvironment.transform 13 1297 env47327 = env47434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env47327 == env47434) = true)

def env47435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4097,5276,74046,66897,13768,78895,1151,74814,1297,81227,8205,74798,256,8200,1345,5953]

theorem envBound47435 : H12AffineFastState.Bounded env47435 := by
  intro p hp
  have h : env47435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47434_47435 : H12AffineEnvironment.transform 17 65664 env47434 = env47435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47434 == env47435) = true)

theorem identity47435 : scanCanonicalize (H12AffineFastState.compose env47435 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound47435 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,65536,66599,65664,4416,276,4097,5276,65910,66897,5504,70759,1151,66678,1297,72963,69,66662,256,64,1345,5953]

theorem envBound47436 : H12AffineFastState.Bounded env47436 := by
  intro p hp
  have h : env47436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47435_47436 : H12AffineEnvironment.transform 12 72 env47435 = env47436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47435 == env47436) = true)

def env47437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1297,277,65536,66599,65664,1876,276,1557,648,65910,66897,916,66163,1151,66678,1297,68375,69,66662,256,64,1345,341]

theorem envBound47437 : H12AffineFastState.Bounded env47437 := by
  intro p hp
  have h : env47437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47436_47437 : H12AffineEnvironment.transform 11 1556 env47436 = env47437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env47436 == env47437) = true)

def env47438 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,81,277,65536,65895,65664,532,276,853,648,65910,65553,916,66163,319,65846,81,68375,69,65830,256,64,1,341]

theorem envBound47438 : H12AffineFastState.Bounded env47438 := by
  intro p hp
  have h : env47438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47437_47438 : H12AffineEnvironment.transform 9 320 env47437 = env47438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47437 == env47438) = true)

theorem identity47438 : scanCanonicalize (H12AffineFastState.compose env47438 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound47438 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47439 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,81,277,115,276,243,532,276,853,648,261,98,916,512,319,325,81,2916,69,341,256,64,1,341]

theorem envBound47439 : H12AffineFastState.Bounded env47439 := by
  intro p hp
  have h : env47439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47438_47439 : H12AffineEnvironment.transform 15 115 env47438 = env47439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env47438 == env47439) = true)

theorem identity47439 : scanCanonicalize (H12AffineFastState.compose env47439 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47439 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47440 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,772,24,1,277,35,276,163,532,276,773,648,261,50,916,512,319,277,1,2868,21,261,256,16,1,261]

theorem envBound47440 : H12AffineFastState.Bounded env47440 := by
  intro p hp
  have h : env47440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47439_47440 : H12AffineEnvironment.transform 5 16 env47439 = env47440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47439 == env47440) = true)

theorem identity47440 : scanCanonicalize (H12AffineFastState.compose env47440 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 442) := by decide +kernel

theorem selectedBound47440 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env47441 : List Nat := [2,4,8,16,32,16,128,256,512,272,442,772,24,1,277,35,276,163,532,276,773,648,261,50,916,512,319,277,1,654,21,261,256,16,1,261]

theorem envBound47441 : H12AffineFastState.Bounded env47441 := by
  intro p hp
  have h : env47441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47440_47441 : H12AffineEnvironment.transform 10 442 env47440 = env47441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 442 env47440 == env47441) = true)

theorem identity47441 : scanCanonicalize (H12AffineFastState.compose env47441 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound47441 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47442 : List Nat := [2,4,8,16,32,16,128,256,146,272,442,406,24,1,277,35,276,163,134,276,407,26,261,50,262,146,319,277,1,28,21,261,256,16,1,261]

theorem envBound47442 : H12AffineFastState.Bounded env47442 := by
  intro p hp
  have h : env47442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47441_47442 : H12AffineEnvironment.transform 8 146 env47441 = env47442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env47441 == env47442) = true)

theorem identity47442 : scanCanonicalize (H12AffineFastState.compose env47442 (packedSelected [0,4,5,7,9,10,11,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound47442 : packedSelected [0,4,5,7,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env47443 : List Nat := [2,4,8,16,22,16,128,256,146,272,396,406,24,1,277,21,276,149,134,276,407,26,261,4,262,146,265,277,1,28,21,261,256,16,1,261]

theorem envBound47443 : H12AffineFastState.Bounded env47443 := by
  intro p hp
  have h : env47443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47442_47443 : H12AffineEnvironment.transform 4 22 env47442 = env47443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env47442 == env47443) = true)

theorem identity47443 : scanCanonicalize (H12AffineFastState.compose env47443 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound47443 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env47444 : List Nat := [2,4,8,16,22,16,24,256,10,272,276,270,24,1,277,21,276,13,30,276,271,26,261,4,262,10,265,277,1,28,21,261,256,16,1,261]

theorem envBound47444 : H12AffineFastState.Bounded env47444 := by
  intro p hp
  have h : env47444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47443_47444 : H12AffineEnvironment.transform 6 24 env47443 = env47444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env47443 == env47444) = true)

theorem identity47444 : scanCanonicalize (H12AffineFastState.compose env47444 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound47444 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env47445 : List Nat := [2,4,8,16,22,16,24,18,10,2,6,28,24,1,7,21,6,13,30,6,29,26,23,4,20,10,27,7,1,28,21,23,18,16,1,23]

theorem envBound47445 : H12AffineFastState.Bounded env47445 := by
  intro p hp
  have h : env47445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47444_47445 : H12AffineEnvironment.transform 7 18 env47444 = env47445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env47444 == env47445) = true)

theorem identity47445 : scanCanonicalize (H12AffineFastState.compose env47445 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47445 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47446 : List Nat := [2,4,8,7,1,7,15,5,10,2,6,11,15,1,7,2,6,13,9,6,10,13,0,4,3,10,12,7,1,11,2,0,5,7,1,0]

theorem envBound47446 : H12AffineFastState.Bounded env47446 := by
  intro p hp
  have h : env47446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47445_47446 : H12AffineEnvironment.transform 3 7 env47445 = env47446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47445 == env47446) = true)

theorem identity47446 : scanCanonicalize (H12AffineFastState.compose env47446 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47447 : List Nat := [2,3,8,0,1,0,8,2,10,2,1,11,8,1,0,2,1,10,9,1,10,10,0,3,3,10,11,0,1,11,2,0,2,0,1,0]

theorem envBound47447 : H12AffineFastState.Bounded env47447 := by
  intro p hp
  have h : env47447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47446_47447 : H12AffineEnvironment.transform 1 3 env47446 = env47447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47446 == env47447) = true)

theorem identity47447 : scanCanonicalize (H12AffineFastState.compose env47447 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47448 : List Nat := [2,3,3,0,1,0,3,2,1,2,1,0,3,1,0,2,1,1,2,1,1,1,0,3,3,1,0,0,1,0,2,0,2,0,1,0]

theorem envBound47448 : H12AffineFastState.Bounded env47448 := by
  intro p hp
  have h : env47448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47447_47448 : H12AffineEnvironment.transform 2 3 env47447 = env47448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47447 == env47448) = true)

theorem identity47448 : scanCanonicalize (H12AffineFastState.compose env47448 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47449 : List Nat := [0,1,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,1,0,1,1,1,0,1,1,1,0,0,1,0,0,0,0,0,1,0]

theorem envBound47449 : H12AffineFastState.Bounded env47449 := by
  intro p hp
  have h : env47449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47448_47449 : H12AffineEnvironment.transform 0 0 env47448 = env47449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47448 == env47449) = true)

def env47450 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,80,277,65536,65894,65664,533,276,852,648,65910,65552,916,66163,318,65847,80,68375,69,65831,256,64,0,341]

theorem envBound47450 : H12AffineFastState.Bounded env47450 := by
  intro p hp
  have h : env47450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47437_47450 : H12AffineEnvironment.transform 9 321 env47437 = env47450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47437 == env47450) = true)

theorem identity47450 : scanCanonicalize (H12AffineFastState.compose env47450 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound47450 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47451 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,80,277,806,576,934,533,276,852,648,592,822,916,341,318,529,80,2097,69,513,256,64,0,341]

theorem envBound47451 : H12AffineFastState.Bounded env47451 := by
  intro p hp
  have h : env47451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47450_47451 : H12AffineEnvironment.transform 15 806 env47450 = env47451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env47450 == env47451) = true)

theorem identity47451 : scanCanonicalize (H12AffineFastState.compose env47451 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47451 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env47452 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,576,72,80,0,563,576,691,533,1,577,648,592,547,641,64,43,529,80,2097,69,513,21,64,0,64]

theorem envBound47452 : H12AffineFastState.Bounded env47452 := by
  intro p hp
  have h : env47452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47451_47452 : H12AffineEnvironment.transform 7 21 env47451 = env47452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47451 == env47452) = true)

theorem identity47452 : scanCanonicalize (H12AffineFastState.compose env47452 (packedSelected [2,3,4,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound47452 : packedSelected [2,3,4,9,10,16] rootPS < 2^1333 := by decide +kernel

def env47453 : List Nat := [2,4,8,16,32,64,128,21,512,84,23,576,72,80,0,563,576,691,533,1,577,648,592,547,641,64,43,529,80,38,69,513,21,64,0,64]

theorem envBound47453 : H12AffineFastState.Bounded env47453 := by
  intro p hp
  have h : env47453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47452_47453 : H12AffineEnvironment.transform 10 23 env47452 = env47453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env47452 == env47453) = true)

theorem identity47453 : scanCanonicalize (H12AffineFastState.compose env47453 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound47453 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env47454 : List Nat := [2,4,8,16,32,64,128,21,49,84,23,113,72,80,0,2,113,130,36,1,112,185,97,18,176,64,43,32,80,38,69,48,21,64,0,64]

theorem envBound47454 : H12AffineFastState.Bounded env47454 := by
  intro p hp
  have h : env47454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47453_47454 : H12AffineEnvironment.transform 8 49 env47453 = env47454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47453 == env47454) = true)

theorem identity47454 : scanCanonicalize (H12AffineFastState.compose env47454 (packedSelected [0,1,2,5,7,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound47454 : packedSelected [0,1,2,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env47455 : List Nat := [2,4,8,16,32,64,127,21,49,84,23,113,72,80,0,2,113,125,36,1,112,70,97,18,79,64,43,32,80,38,69,48,21,64,0,64]

theorem envBound47455 : H12AffineFastState.Bounded env47455 := by
  intro p hp
  have h : env47455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47454_47455 : H12AffineEnvironment.transform 6 127 env47454 = env47455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env47454 == env47455) = true)

theorem identity47455 : scanCanonicalize (H12AffineFastState.compose env47455 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47455 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47456 : List Nat := [2,4,8,16,32,17,46,21,49,5,23,32,25,1,0,2,32,44,36,1,33,23,48,18,30,17,43,32,1,38,20,48,21,17,0,17]

theorem envBound47456 : H12AffineFastState.Bounded env47456 := by
  intro p hp
  have h : env47456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47455_47456 : H12AffineEnvironment.transform 5 17 env47455 = env47456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47455 == env47456) = true)

theorem identity47456 : scanCanonicalize (H12AffineFastState.compose env47456 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47456 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47457 : List Nat := [2,4,8,16,16,17,30,21,1,5,23,16,25,1,0,2,16,28,20,1,17,23,0,18,30,17,27,16,1,22,20,0,21,17,0,17]

theorem envBound47457 : H12AffineFastState.Bounded env47457 := by
  intro p hp
  have h : env47457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47456_47457 : H12AffineEnvironment.transform 4 16 env47456 = env47457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47456 == env47457) = true)

theorem identity47457 : scanCanonicalize (H12AffineFastState.compose env47457 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47457 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47458 : List Nat := [2,2,8,16,16,17,24,19,1,3,17,16,25,1,0,2,16,26,18,1,17,17,0,18,24,17,27,16,1,16,18,0,19,17,0,17]

theorem envBound47458 : H12AffineFastState.Bounded env47458 := by
  intro p hp
  have h : env47458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47457_47458 : H12AffineEnvironment.transform 1 2 env47457 = env47458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47457 == env47458) = true)

def env47459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1297,277,65536,66599,65664,1877,276,1556,649,65910,66897,917,66162,1151,66678,1297,68374,69,66662,256,64,1345,340]

theorem envBound47459 : H12AffineFastState.Bounded env47459 := by
  intro p hp
  have h : env47459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47436_47459 : H12AffineEnvironment.transform 11 1557 env47436 = env47459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env47436 == env47459) = true)

def env47460 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,81,277,65536,65895,65664,533,276,852,649,65910,65553,917,66162,319,65846,81,68374,69,65830,256,64,1,340]

theorem envBound47460 : H12AffineFastState.Bounded env47460 := by
  intro p hp
  have h : env47460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47459_47460 : H12AffineEnvironment.transform 9 320 env47459 = env47460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47459 == env47460) = true)

theorem identity47460 : scanCanonicalize (H12AffineFastState.compose env47460 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound47460 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47461 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,81,277,115,276,243,533,276,852,649,261,98,917,513,319,325,81,2917,69,341,256,64,1,340]

theorem envBound47461 : H12AffineFastState.Bounded env47461 := by
  intro p hp
  have h : env47461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47460_47461 : H12AffineEnvironment.transform 15 115 env47460 = env47461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env47460 == env47461) = true)

end H12CloudChart2