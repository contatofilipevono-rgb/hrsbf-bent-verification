import H12CloudChart2Data056

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity13937 : scanCanonicalize (H12AffineFastState.compose env13937 (packedSelected [0,1,2,4,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound13937 : packedSelected [0,1,2,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7196,16384,22901,7611,16384,22609,4369,22900,4097,5141,17665,17867,7316,20544,22609,1345,1296,2048,16452,4294967296,17472,4294988148,16385,512]

theorem envBound13938 : H12AffineFastState.Bounded env13938 := by
  intro p hp
  have h : env13938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13937_13938 : H12AffineEnvironment.transform 12 7196 env13937 = env13938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env13937 == env13938) = true)

theorem identity13938 : scanCanonicalize (H12AffineFastState.compose env13938 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound13938 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7196,4177,2340,7611,4177,2048,4369,2341,4097,5141,5456,5530,7316,17,2048,1345,1296,2048,4117,4294967296,5137,4294967589,4176,512]

theorem envBound13939 : H12AffineFastState.Bounded env13939 := by
  intro p hp
  have h : env13939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13938_13939 : H12AffineEnvironment.transform 13 4177 env13938 = env13939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env13938 == env13939) = true)

def env13940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2316,1345,2340,2219,1345,2048,1025,2341,1297,261,64,138,2436,17,2048,1345,1296,2048,1285,4294967296,257,4294967589,1344,512]

theorem envBound13940 : H12AffineFastState.Bounded env13940 := by
  intro p hp
  have h : env13940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13939_13940 : H12AffineEnvironment.transform 11 1296 env13939 = env13940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13939 == env13940) = true)

theorem identity13940 : scanCanonicalize (H12AffineFastState.compose env13940 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 853) := by decide +kernel

theorem selectedBound13940 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2316,1345,2340,2219,1345,2048,1025,2341,1297,261,64,138,2436,17,2048,1345,1296,2048,1285,853,257,624,1344,512]

theorem envBound13941 : H12AffineFastState.Bounded env13941 := by
  intro p hp
  have h : env13941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13940_13941 : H12AffineEnvironment.transform 31 853 env13940 = env13941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 853 env13940 == env13941) = true)

theorem identity13941 : scanCanonicalize (H12AffineFastState.compose env13941 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13941 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env13942 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2316,1345,2340,2219,1345,2048,1025,2341,1297,261,64,138,2436,17,2048,1345,1296,2048,1285,476,257,249,1344,137]

theorem envBound13942 : H12AffineFastState.Bounded env13942 := by
  intro p hp
  have h : env13942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13941_13942 : H12AffineEnvironment.transform 8 137 env13941 = env13942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13941 == env13942) = true)

def env13943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2317,1344,2340,2218,1344,2048,1024,2341,1296,260,65,139,2437,17,2048,1345,1296,2048,1284,4294967296,256,4294967589,1345,512]

theorem envBound13943 : H12AffineFastState.Bounded env13943 := by
  intro p hp
  have h : env13943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13939_13943 : H12AffineEnvironment.transform 11 1297 env13939 = env13943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env13939 == env13943) = true)

def env13944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,2317,1344,2340,2082,1344,2048,1024,2341,1296,260,65,3,2317,17,2048,1345,1296,2048,1284,4294967296,256,4294967589,1345,512]

theorem envBound13944 : H12AffineFastState.Bounded env13944 := by
  intro p hp
  have h : env13944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13943_13944 : H12AffineEnvironment.transform 6 8 env13943 = env13944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13943 == env13944) = true)

theorem identity13944 : scanCanonicalize (H12AffineFastState.compose env13944 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 372) := by decide +kernel

theorem selectedBound13944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,2317,1344,2340,2082,1344,2048,1024,2341,1296,260,65,3,2317,17,2048,1345,1296,2048,1284,372,256,81,1345,512]

theorem envBound13945 : H12AffineFastState.Bounded env13945 := by
  intro p hp
  have h : env13945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13944_13945 : H12AffineEnvironment.transform 31 372 env13944 = env13945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 372 env13944 == env13945) = true)

def env13946 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1297,2317,1296,2340,2082,1296,2048,1024,2341,1296,260,17,3,2317,17,2048,1297,1296,2048,1284,292,256,1,1297,512]

theorem envBound13946 : H12AffineFastState.Bounded env13946 := by
  intro p hp
  have h : env13946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13945_13946 : H12AffineEnvironment.transform 5 16 env13945 = env13946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13945 == env13946) = true)

theorem identity13946 : scanCanonicalize (H12AffineFastState.compose env13946 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound13946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13947 : List Nat := [2,4,8,16,32,16,8,256,292,1024,2048,1297,2317,1296,2340,2082,1296,2048,1024,2341,1296,260,17,3,2317,17,2048,1297,1296,2048,1284,292,256,1,1297,292]

theorem envBound13947 : H12AffineFastState.Bounded env13947 := by
  intro p hp
  have h : env13947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13946_13947 : H12AffineEnvironment.transform 8 292 env13946 = env13947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env13946 == env13947) = true)

theorem identity13947 : scanCanonicalize (H12AffineFastState.compose env13947 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13947 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13948 : List Nat := [2,4,8,16,32,16,8,36,0,1024,2048,1077,2089,1076,2048,2082,1076,2048,1024,2049,1076,32,17,3,2089,17,2048,1077,1076,2048,1056,0,36,1,1077,0]

theorem envBound13948 : H12AffineFastState.Bounded env13948 := by
  intro p hp
  have h : env13948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13947_13948 : H12AffineEnvironment.transform 7 36 env13947 = env13948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13947 == env13948) = true)

theorem identity13948 : scanCanonicalize (H12AffineFastState.compose env13948 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13949 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1045,2057,1044,2048,2050,1044,2048,1024,2049,1044,0,17,3,2057,17,2048,1045,1044,2048,1024,0,4,1,1045,0]

theorem envBound13949 : H12AffineFastState.Bounded env13949 := by
  intro p hp
  have h : env13949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13948_13949 : H12AffineEnvironment.transform 4 0 env13948 = env13949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13948 == env13949) = true)

def leafEnv13949 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1045,2057,1044,2048,2050,1044,2048,1024,2049,1044,0,17,3,1024,2057,1,17,2048,1045,1044,2048,1024,0,4,1,4,2051,1045,0,0,1045,1]

def active13949 : List Nat := [0,1,2,3,9,10]

def tree13949 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13949 : H12WitnessSearch.Good tree13949 := H12GlobalWitnessIndex.good

theorem leafIdentity13949 : H12AffineFastState.composeSystem env13949 rootObs = leafEnv13949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13949 rootObs == leafEnv13949) = true)

theorem terminalChecked13949 : H12PackedTerminal.terminalCheckFast leafEnv13949 active13949 tree13949 = true := by decide +kernel

def env13950 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1297,2317,1297,2340,2082,1297,2048,1024,2341,1296,260,16,3,2317,17,2048,1296,1296,2048,1284,293,256,0,1296,512]

theorem envBound13950 : H12AffineFastState.Bounded env13950 := by
  intro p hp
  have h : env13950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13945_13950 : H12AffineEnvironment.transform 5 17 env13945 = env13950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13945 == env13950) = true)

def env13951 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,1297,2317,1297,2308,2050,1297,2048,1024,2309,1296,260,16,3,2317,17,2048,1296,1296,2048,1284,261,256,0,1296,512]

theorem envBound13951 : H12AffineFastState.Bounded env13951 := by
  intro p hp
  have h : env13951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13950_13951 : H12AffineEnvironment.transform 4 0 env13950 = env13951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13950 == env13951) = true)

theorem identity13951 : scanCanonicalize (H12AffineFastState.compose env13951 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13951 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13952 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,2317,1297,2308,2050,1297,2048,1024,2309,1296,260,16,3,2317,17,2048,1296,1296,2048,1284,261,256,0,1296,0]

theorem envBound13952 : H12AffineFastState.Bounded env13952 := by
  intro p hp
  have h : env13952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13951_13952 : H12AffineEnvironment.transform 8 0 env13951 = env13952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13951 == env13952) = true)

def leafEnv13952 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,2317,1297,2308,2050,1297,2048,1024,2309,1296,260,16,3,1284,2317,1,17,2048,1296,1296,2048,1284,261,256,0,4,2051,1296,0,0,1297,1]

def active13952 : List Nat := [0,1,2,3,7,9,10]

def tree13952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13952 : H12WitnessSearch.Good tree13952 := H12GlobalWitnessIndex.good

theorem leafIdentity13952 : H12AffineFastState.composeSystem env13952 rootObs = leafEnv13952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13952 rootObs == leafEnv13952) = true)

theorem terminalChecked13952 : H12PackedTerminal.terminalCheckFast leafEnv13952 active13952 tree13952 = true := by decide +kernel

def env13953 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1297,2317,1297,2309,2051,1297,2048,1024,2308,1296,260,16,3,2317,17,2048,1296,1296,2048,1284,260,256,0,1296,512]

theorem envBound13953 : H12AffineFastState.Bounded env13953 := by
  intro p hp
  have h : env13953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13950_13953 : H12AffineEnvironment.transform 4 1 env13950 = env13953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13950 == env13953) = true)

theorem identity13953 : scanCanonicalize (H12AffineFastState.compose env13953 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13954 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1297,2317,1297,2309,2051,1297,2048,1024,2308,1296,260,16,3,2317,17,2048,1296,1296,2048,1284,260,256,0,1296,260]

theorem envBound13954 : H12AffineFastState.Bounded env13954 := by
  intro p hp
  have h : env13954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13953_13954 : H12AffineEnvironment.transform 8 260 env13953 = env13954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13953 == env13954) = true)

def leafEnv13954 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1297,2317,1297,2309,2051,1297,2048,1024,2308,1296,260,16,3,1284,2317,1,17,2048,1296,1296,2048,1284,260,256,0,4,2050,1296,260,0,1297,1]

def active13954 : List Nat := [0,1,2,3,7,9,10]

def tree13954 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13954 : H12WitnessSearch.Good tree13954 := H12GlobalWitnessIndex.good

theorem leafIdentity13954 : H12AffineFastState.composeSystem env13954 rootObs = leafEnv13954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13954 rootObs == leafEnv13954) = true)

theorem terminalChecked13954 : H12PackedTerminal.terminalCheckFast leafEnv13954 active13954 tree13954 = true := by decide +kernel

def env13955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1297,2317,1344,2340,2083,1344,2048,1024,2341,1296,260,65,2,2316,17,2048,1345,1296,2048,1284,4294967296,256,4294967589,1345,512]

theorem envBound13955 : H12AffineFastState.Bounded env13955 := by
  intro p hp
  have h : env13955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13943_13955 : H12AffineEnvironment.transform 6 9 env13943 = env13955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13943 == env13955) = true)

theorem identity13955 : scanCanonicalize (H12AffineFastState.compose env13955 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 592) := by decide +kernel

theorem selectedBound13955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1297,2317,1344,2340,2083,1344,2048,1024,2341,1296,260,65,2,2316,17,2048,1345,1296,2048,1284,592,256,885,1345,512]

theorem envBound13956 : H12AffineFastState.Bounded env13956 := by
  intro p hp
  have h : env13956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13955_13956 : H12AffineEnvironment.transform 31 592 env13955 = env13956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 592 env13955 == env13956) = true)

theorem identity13956 : scanCanonicalize (H12AffineFastState.compose env13956 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13956 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13957 : List Nat := [2,4,8,16,32,64,9,256,1,1024,2048,1297,2317,1344,2340,2083,1344,2048,1024,2341,1296,260,65,2,2316,17,2048,1345,1296,2048,1284,81,256,372,1345,1]

theorem envBound13957 : H12AffineFastState.Bounded env13957 := by
  intro p hp
  have h : env13957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13956_13957 : H12AffineEnvironment.transform 8 1 env13956 = env13957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13956 == env13957) = true)

def env13958 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1297,2317,1296,2340,2083,1296,2048,1024,2341,1296,260,17,2,2316,17,2048,1297,1296,2048,1284,1,256,292,1297,1]

theorem envBound13958 : H12AffineFastState.Bounded env13958 := by
  intro p hp
  have h : env13958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13958 : H12AffineEnvironment.transform 5 16 env13957 = env13958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13957 == env13958) = true)

theorem identity13958 : scanCanonicalize (H12AffineFastState.compose env13958 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13959 : List Nat := [2,4,8,16,32,16,9,37,1,1024,2048,1076,2088,1077,2049,2083,1077,2048,1024,2048,1077,33,17,2,2089,17,2048,1076,1077,2048,1057,1,37,1,1076,1]

theorem envBound13959 : H12AffineFastState.Bounded env13959 := by
  intro p hp
  have h : env13959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13958_13959 : H12AffineEnvironment.transform 7 37 env13958 = env13959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13958 == env13959) = true)

def leafEnv13959 : List Nat := [2,4,8,16,32,16,9,37,1,1024,2048,1076,2088,1077,2049,2083,1077,2048,1024,2048,1077,33,17,2,1057,2089,1,17,2048,1076,1077,2048,1057,1,37,1,4,2083,1076,1,0,1076,1]

def active13959 : List Nat := [0,1,2,3,4,9,10]

def tree13959 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13959 : H12WitnessSearch.Good tree13959 := H12GlobalWitnessIndex.good

theorem leafIdentity13959 : H12AffineFastState.composeSystem env13959 rootObs = leafEnv13959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13959 rootObs == leafEnv13959) = true)

theorem terminalChecked13959 : H12PackedTerminal.terminalCheckFast leafEnv13959 active13959 tree13959 = true := by decide +kernel

def env13960 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1297,2317,1297,2340,2083,1297,2048,1024,2341,1296,260,16,2,2316,17,2048,1296,1296,2048,1284,0,256,293,1296,1]

theorem envBound13960 : H12AffineFastState.Bounded env13960 := by
  intro p hp
  have h : env13960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13960 : H12AffineEnvironment.transform 5 17 env13957 = env13960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13957 == env13960) = true)

def env13961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,1344,529408,1073741824,16453,4294967296,17473,4299260335,16384,512]

theorem envBound13961 : H12AffineFastState.Bounded env13961 := by
  intro p hp
  have h : env13961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13919_13961 : H12AffineEnvironment.transform 16 16385 env13919 = env13961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env13919 == env13961) = true)

def env13962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,10248,17665,98565,8328,541009,797964,1344,529408,1073741824,16453,4294967296,17473,4295076263,16384,512]

theorem envBound13962 : H12AffineFastState.Bounded env13962 := by
  intro p hp
  have h : env13962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13961_13962 : H12AffineEnvironment.transform 21 10248 env13961 = env13962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env13961 == env13962) = true)

def env13963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,8200,17665,98565,8328,541009,795916,1344,529408,1073741824,16453,4294967296,17473,4295074215,16384,512]

theorem envBound13963 : H12AffineFastState.Bounded env13963 := by
  intro p hp
  have h : env13963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13962_13963 : H12AffineEnvironment.transform 10 0 env13962 = env13963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13962 == env13963) = true)

def env13964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1344,529408,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound13964 : H12AffineFastState.Bounded env13964 := by
  intro p hp
  have h : env13964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13963_13964 : H12AffineEnvironment.transform 13 1344 env13963 = env13964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env13963 == env13964) = true)

theorem identity13964 : scanCanonicalize (H12AffineFastState.compose env13964 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 300084) := by decide +kernel

theorem selectedBound13964 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1344,529408,300084,1285,4294967296,257,4295074215,1344,512]

theorem envBound13965 : H12AffineFastState.Bounded env13965 := by
  intro p hp
  have h : env13965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13964_13965 : H12AffineEnvironment.transform 29 300084 env13964 = env13965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 300084 env13964 == env13965) = true)

theorem identity13965 : scanCanonicalize (H12AffineFastState.compose env13965 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound13965 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env13966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,8200,65,98565,8328,16,270605,1344,4097,300084,1285,4294967296,257,4295074215,1344,512]

theorem envBound13966 : H12AffineFastState.Bounded env13966 := by
  intro p hp
  have h : env13966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13965_13966 : H12AffineEnvironment.transform 18 1025 env13965 = env13966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13965 == env13966) = true)

theorem identity13966 : scanCanonicalize (H12AffineFastState.compose env13966 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 13341) := by decide +kernel

theorem selectedBound13966 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,13341,1025,32769,4097,8200,65,98565,8328,16,5392,1344,4097,41001,1285,4294967296,257,4295074215,1344,512]

theorem envBound13967 : H12AffineFastState.Bounded env13967 := by
  intro p hp
  have h : env13967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13966_13967 : H12AffineEnvironment.transform 17 13341 env13966 = env13967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13341 env13966 == env13967) = true)

theorem identity13967 : scanCanonicalize (H12AffineFastState.compose env13967 (packedSelected [0,1,3,4,7,9,10,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 5820) := by decide +kernel

theorem selectedBound13967 : packedSelected [0,1,3,4,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,5820,65536,1345,13341,1025,5821,4097,8200,65,71609,8328,16,5392,1344,4097,13973,1285,4294967296,257,4295046939,1344,512]

theorem envBound13968 : H12AffineFastState.Bounded env13968 := by
  intro p hp
  have h : env13968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13967_13968 : H12AffineEnvironment.transform 14 5820 env13967 = env13968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5820 env13967 == env13968) = true)

def env13969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,940,65536,1345,8461,1025,941,1297,8200,65,66217,8328,16,0,1344,1297,9093,1285,4294967296,257,4295041547,1344,512]

theorem envBound13969 : H12AffineFastState.Bounded env13969 := by
  intro p hp
  have h : env13969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13968_13969 : H12AffineEnvironment.transform 11 1296 env13968 = env13969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13968 == env13969) = true)

theorem identity13969 : scanCanonicalize (H12AffineFastState.compose env13969 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13969 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,269,1344,940,65536,1345,0,1025,941,1297,261,65,66217,389,16,0,1344,1297,648,1285,4294967296,257,4295033606,1344,512]

theorem envBound13970 : H12AffineFastState.Bounded env13970 := by
  intro p hp
  have h : env13970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13969_13970 : H12AffineEnvironment.transform 12 269 env13969 = env13970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13969 == env13970) = true)

theorem identity13970 : scanCanonicalize (H12AffineFastState.compose env13970 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13970 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13971 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,1077,40,1125,649,65536,1124,0,1025,648,1076,32,65,66217,160,16,0,1125,1076,648,1056,4294967296,36,4295033379,1125,512]

theorem envBound13971 : H12AffineFastState.Bounded env13971 := by
  intro p hp
  have h : env13971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13970_13971 : H12AffineEnvironment.transform 7 37 env13970 = env13971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13970 == env13971) = true)

theorem identity13971 : scanCanonicalize (H12AffineFastState.compose env13971 (packedSelected [2,4,6] rootPS)) = affineNative (2^(31+1) ^^^ 1604) := by decide +kernel

theorem selectedBound13971 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env13972 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,1077,40,1125,649,65536,1124,0,1025,648,1076,32,65,66217,160,16,0,1125,1076,648,1056,1604,36,66663,1125,512]

theorem envBound13972 : H12AffineFastState.Bounded env13972 := by
  intro p hp
  have h : env13972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13971_13972 : H12AffineEnvironment.transform 31 1604 env13971 = env13972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1604 env13971 == env13972) = true)

theorem identity13972 : scanCanonicalize (H12AffineFastState.compose env13972 (packedSelected [3,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 1606) := by decide +kernel

theorem selectedBound13972 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env13973 : List Nat := [2,4,8,16,32,64,128,37,512,1024,0,1077,40,1125,649,1606,1124,0,1025,648,1076,32,65,1263,160,16,0,1125,1076,648,1056,1604,36,545,1125,512]

theorem envBound13973 : H12AffineFastState.Bounded env13973 := by
  intro p hp
  have h : env13973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13972_13973 : H12AffineEnvironment.transform 15 1606 env13972 = env13973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1606 env13972 == env13973) = true)

theorem identity13973 : scanCanonicalize (H12AffineFastState.compose env13973 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13973 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13974 : List Nat := [2,4,8,16,32,64,128,37,512,53,0,0,40,80,649,627,81,0,52,648,1,32,65,218,160,16,0,80,1,648,21,625,36,545,80,512]

theorem envBound13974 : H12AffineFastState.Bounded env13974 := by
  intro p hp
  have h : env13974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13973_13974 : H12AffineEnvironment.transform 9 53 env13973 = env13974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13973 == env13974) = true)

theorem identity13974 : scanCanonicalize (H12AffineFastState.compose env13974 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 210) := by decide +kernel

theorem selectedBound13974 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13975 : List Nat := [2,4,8,16,32,64,128,37,210,53,0,0,40,80,91,161,81,0,52,90,1,32,65,218,160,16,0,80,1,90,21,163,36,243,80,210]

theorem envBound13975 : H12AffineFastState.Bounded env13975 := by
  intro p hp
  have h : env13975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13974_13975 : H12AffineEnvironment.transform 8 210 env13974 = env13975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 210 env13974 == env13975) = true)

theorem identity13975 : scanCanonicalize (H12AffineFastState.compose env13975 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13975 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env13976 : List Nat := [2,4,2,16,32,64,128,37,210,53,0,0,34,80,81,161,81,0,52,80,1,32,65,208,160,16,0,80,1,80,21,163,36,243,80,210]

theorem envBound13976 : H12AffineFastState.Bounded env13976 := by
  intro p hp
  have h : env13976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13975_13976 : H12AffineEnvironment.transform 2 2 env13975 = env13976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13975 == env13976) = true)

theorem identity13976 : scanCanonicalize (H12AffineFastState.compose env13976 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13977 : List Nat := [2,4,2,16,32,17,128,37,131,53,0,0,34,1,0,161,0,0,52,1,1,32,16,129,160,16,0,1,1,1,21,163,36,162,1,131]

theorem envBound13977 : H12AffineFastState.Bounded env13977 := by
  intro p hp
  have h : env13977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13976_13977 : H12AffineEnvironment.transform 5 17 env13976 = env13977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13976 == env13977) = true)

theorem identity13977 : scanCanonicalize (H12AffineFastState.compose env13977 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13978 : List Nat := [2,4,2,0,32,1,128,37,131,37,0,0,34,1,0,161,0,0,36,1,1,32,0,129,160,0,0,1,1,1,5,163,36,162,1,131]

theorem envBound13978 : H12AffineFastState.Bounded env13978 := by
  intro p hp
  have h : env13978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13977_13978 : H12AffineEnvironment.transform 3 0 env13977 = env13978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13977 == env13978) = true)

def env13979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1344,941,65536,1345,8460,1025,940,1296,8200,65,66216,8328,16,1,1344,1296,9092,1285,4294967296,257,4295041546,1344,512]

theorem envBound13979 : H12AffineFastState.Bounded env13979 := by
  intro p hp
  have h : env13979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13968_13979 : H12AffineEnvironment.transform 11 1297 env13968 = env13979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env13968 == env13979) = true)

theorem identity13979 : scanCanonicalize (H12AffineFastState.compose env13979 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13979 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13980 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8192,1344,292,65536,1345,8460,1025,293,1296,8200,65,65569,8328,16,1,1344,1296,8461,1285,4294967296,257,4295041155,1344,137]

theorem envBound13980 : H12AffineFastState.Bounded env13980 := by
  intro p hp
  have h : env13980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13979_13980 : H12AffineEnvironment.transform 8 137 env13979 = env13980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13979 == env13980) = true)

theorem identity13980 : scanCanonicalize (H12AffineFastState.compose env13980 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound13980 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13981 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,9,1344,292,65536,1345,261,1025,293,1296,1,65,65569,129,16,1,1344,1296,260,1285,4294967296,257,4295032970,1344,137]

theorem envBound13981 : H12AffineFastState.Bounded env13981 := by
  intro p hp
  have h : env13981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13980_13981 : H12AffineEnvironment.transform 12 9 env13980 = env13981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13980 == env13981) = true)

def env13982 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1297,9,1296,292,65536,1297,261,1025,293,1296,1,17,65569,129,16,1,1296,1296,260,1285,4294967296,257,4295032970,1296,137]

theorem envBound13982 : H12AffineFastState.Bounded env13982 := by
  intro p hp
  have h : env13982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13981_13982 : H12AffineEnvironment.transform 5 16 env13981 = env13982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13981 == env13982) = true)

theorem identity13982 : scanCanonicalize (H12AffineFastState.compose env13982 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound13982 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13983 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1297,9,1296,292,65536,1297,261,1025,293,1296,1,17,65569,129,16,1,1296,1296,260,1285,137,257,65539,1296,137]

theorem envBound13983 : H12AffineFastState.Bounded env13983 := by
  intro p hp
  have h : env13983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13982_13983 : H12AffineEnvironment.transform 31 137 env13982 = env13983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env13982 == env13983) = true)

def env13984 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,1,9,0,292,65536,1,261,273,293,0,1,17,65569,129,16,1,0,0,260,21,137,257,65539,0,137]

theorem envBound13984 : H12AffineFastState.Bounded env13984 := by
  intro p hp
  have h : env13984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13983_13984 : H12AffineEnvironment.transform 9 272 env13983 = env13984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13983 == env13984) = true)

theorem identity13984 : scanCanonicalize (H12AffineFastState.compose env13984 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound13984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13985 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,1,9,0,292,430,1,261,273,293,0,1,17,399,129,16,1,0,0,260,21,137,257,429,0,137]

theorem envBound13985 : H12AffineFastState.Bounded env13985 := by
  intro p hp
  have h : env13985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13984_13985 : H12AffineEnvironment.transform 15 430 env13984 = env13985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env13984 == env13985) = true)

theorem identity13985 : scanCanonicalize (H12AffineFastState.compose env13985 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13985 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13986 : List Nat := [2,4,8,16,32,16,128,4,137,20,0,1,9,0,32,170,1,1,21,33,0,1,17,139,129,16,1,0,0,0,21,137,5,169,0,137]

theorem envBound13986 : H12AffineFastState.Bounded env13986 := by
  intro p hp
  have h : env13986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13985_13986 : H12AffineEnvironment.transform 7 4 env13985 = env13986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13985 == env13986) = true)

theorem identity13986 : scanCanonicalize (H12AffineFastState.compose env13986 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13986 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13987 : List Nat := [2,4,8,16,1,16,128,4,137,20,0,1,9,0,1,139,1,1,21,0,0,1,17,139,129,16,1,0,0,0,21,137,5,136,0,137]

theorem envBound13987 : H12AffineFastState.Bounded env13987 := by
  intro p hp
  have h : env13987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13986_13987 : H12AffineEnvironment.transform 4 1 env13986 = env13987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13986 == env13987) = true)

theorem identity13987 : scanCanonicalize (H12AffineFastState.compose env13987 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound13987 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13988 : List Nat := [2,4,8,16,1,16,25,4,16,20,0,1,9,0,1,18,1,1,21,0,0,1,17,18,24,16,1,0,0,0,21,16,5,17,0,16]

theorem envBound13988 : H12AffineFastState.Bounded env13988 := by
  intro p hp
  have h : env13988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13987_13988 : H12AffineEnvironment.transform 6 25 env13987 = env13988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env13987 == env13988) = true)

def leafEnv13988 : List Nat := [2,4,8,16,1,16,25,4,16,20,0,1,9,0,1,18,1,1,21,0,0,1,17,18,21,24,1,16,1,0,0,0,21,16,5,17,4,2,0,16,0,0,1]

def active13988 : List Nat := [0,1,2,3]

def tree13988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13988 : H12WitnessSearch.Good tree13988 := H12GlobalWitnessIndex.good

theorem leafIdentity13988 : H12AffineFastState.composeSystem env13988 rootObs = leafEnv13988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13988 rootObs == leafEnv13988) = true)

theorem terminalChecked13988 : H12PackedTerminal.terminalCheckFast leafEnv13988 active13988 tree13988 = true := by decide +kernel

def env13989 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,0,9,1,292,65536,0,261,272,293,1,1,17,65569,129,16,1,1,1,260,20,137,257,65539,1,137]

theorem envBound13989 : H12AffineFastState.Bounded env13989 := by
  intro p hp
  have h : env13989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13983_13989 : H12AffineEnvironment.transform 9 273 env13983 = env13989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13983 == env13989) = true)

theorem identity13989 : scanCanonicalize (H12AffineFastState.compose env13989 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13990 : List Nat := [2,4,8,16,32,16,128,4,137,21,0,0,9,1,32,65536,0,1,20,33,1,1,17,65569,129,16,1,1,1,0,20,137,5,65539,1,137]

theorem envBound13990 : H12AffineFastState.Bounded env13990 := by
  intro p hp
  have h : env13990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13989_13990 : H12AffineEnvironment.transform 7 4 env13989 = env13990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13989 == env13990) = true)

def env13991 : List Nat := [2,4,8,16,0,16,128,4,137,21,0,0,9,1,0,65536,0,1,20,1,1,1,17,65537,129,16,1,1,1,0,20,137,5,65539,1,137]

theorem envBound13991 : H12AffineFastState.Bounded env13991 := by
  intro p hp
  have h : env13991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13990_13991 : H12AffineEnvironment.transform 4 0 env13990 = env13991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13990 == env13991) = true)

theorem identity13991 : scanCanonicalize (H12AffineFastState.compose env13991 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13992 : List Nat := [2,4,8,1,0,1,128,4,137,4,0,0,9,1,0,65536,0,1,5,1,1,1,0,65537,129,1,1,1,1,0,5,137,5,65539,1,137]

theorem envBound13992 : H12AffineFastState.Bounded env13992 := by
  intro p hp
  have h : env13992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13991_13992 : H12AffineEnvironment.transform 3 1 env13991 = env13992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13991 == env13992) = true)

theorem identity13992 : scanCanonicalize (H12AffineFastState.compose env13992 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound13992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13993 : List Nat := [2,4,8,1,0,1,128,4,137,4,0,0,9,1,0,138,0,1,5,1,1,1,0,139,129,1,1,1,1,0,5,137,5,137,1,137]

theorem envBound13993 : H12AffineFastState.Bounded env13993 := by
  intro p hp
  have h : env13993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13992_13993 : H12AffineEnvironment.transform 15 138 env13992 = env13993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env13992 == env13993) = true)

def leafEnv13993 : List Nat := [2,4,8,1,0,1,128,4,137,4,0,0,9,1,0,138,0,1,5,1,1,1,0,139,5,129,1,1,1,1,1,0,5,137,5,137,4,3,1,137,0,1,1]

def active13993 : List Nat := [0,1,2,6]

def tree13993 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13993 : H12WitnessSearch.Good tree13993 := H12GlobalWitnessIndex.good

theorem leafIdentity13993 : H12AffineFastState.composeSystem env13993 rootObs = leafEnv13993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13993 rootObs == leafEnv13993) = true)

theorem terminalChecked13993 : H12PackedTerminal.terminalCheckFast leafEnv13993 active13993 tree13993 = true := by decide +kernel

def env13994 : List Nat := [2,4,8,16,1,16,128,4,137,21,0,0,9,1,1,65536,0,1,20,0,1,1,17,65536,129,16,1,1,1,0,20,137,5,65539,1,137]

theorem envBound13994 : H12AffineFastState.Bounded env13994 := by
  intro p hp
  have h : env13994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13990_13994 : H12AffineEnvironment.transform 4 1 env13990 = env13994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13990 == env13994) = true)

theorem identity13994 : scanCanonicalize (H12AffineFastState.compose env13994 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound13994 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13995 : List Nat := [2,4,8,16,1,16,128,4,137,21,0,0,9,1,1,19,0,1,20,0,1,1,17,19,129,16,1,1,1,0,20,137,5,16,1,137]

theorem envBound13995 : H12AffineFastState.Bounded env13995 := by
  intro p hp
  have h : env13995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13994_13995 : H12AffineEnvironment.transform 15 19 env13994 = env13995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env13994 == env13995) = true)

def env13996 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,9,1297,292,65536,1296,261,1025,293,1296,1,16,65569,129,16,1,1297,1296,260,1285,4294967296,257,4295032970,1297,137]

theorem envBound13996 : H12AffineFastState.Bounded env13996 := by
  intro p hp
  have h : env13996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13981_13996 : H12AffineEnvironment.transform 5 17 env13981 = env13996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13981 == env13996) = true)

theorem identity13996 : scanCanonicalize (H12AffineFastState.compose env13996 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound13996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13997 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,9,1297,292,65536,1296,261,1025,293,1296,1,16,65569,129,16,1,1297,1296,260,1285,65571,257,169,1297,137]

theorem envBound13997 : H12AffineFastState.Bounded env13997 := by
  intro p hp
  have h : env13997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13996_13997 : H12AffineEnvironment.transform 31 65571 env13996 = env13997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env13996 == env13997) = true)

theorem identity13997 : scanCanonicalize (H12AffineFastState.compose env13997 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound13997 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13998 : List Nat := [2,4,8,16,32,17,128,256,137,305,0,32,9,32,292,65536,33,261,304,293,33,1,16,65569,129,16,1,32,33,260,52,65571,257,169,32,137]

theorem envBound13998 : H12AffineFastState.Bounded env13998 := by
  intro p hp
  have h : env13998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13997_13998 : H12AffineEnvironment.transform 9 305 env13997 = env13998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env13997 == env13998) = true)

def env13999 : List Nat := [2,4,8,16,0,17,128,256,137,273,0,0,9,0,260,65536,1,261,272,261,1,1,16,65537,129,16,1,0,1,260,20,65539,257,137,0,137]

theorem envBound13999 : H12AffineFastState.Bounded env13999 := by
  intro p hp
  have h : env13999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13998_13999 : H12AffineEnvironment.transform 4 0 env13998 = env13999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13998 == env13999) = true)

theorem identity13999 : scanCanonicalize (H12AffineFastState.compose env13999 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound13999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14000 : List Nat := [2,4,8,16,0,17,128,256,137,273,0,0,9,0,260,398,1,261,272,261,1,1,16,399,129,16,1,0,1,260,20,397,257,137,0,137]

theorem envBound14000 : H12AffineFastState.Bounded env14000 := by
  intro p hp
  have h : env14000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13999_14000 : H12AffineEnvironment.transform 15 398 env13999 = env14000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env13999 == env14000) = true)

theorem identity14000 : scanCanonicalize (H12AffineFastState.compose env14000 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14000 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14001 : List Nat := [2,4,8,16,0,17,128,21,137,4,0,0,9,0,17,155,1,16,5,16,1,1,16,154,129,16,1,0,1,17,20,152,20,137,0,137]

theorem envBound14001 : H12AffineFastState.Bounded env14001 := by
  intro p hp
  have h : env14001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14000_14001 : H12AffineEnvironment.transform 7 21 env14000 = env14001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14000 == env14001) = true)

theorem identity14001 : scanCanonicalize (H12AffineFastState.compose env14001 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14001 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14002 : List Nat := [2,4,8,1,0,0,128,4,137,4,0,0,9,0,0,138,1,1,5,1,1,1,1,139,129,1,1,0,1,0,5,137,5,137,0,137]

theorem envBound14002 : H12AffineFastState.Bounded env14002 := by
  intro p hp
  have h : env14002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14001_14002 : H12AffineEnvironment.transform 3 1 env14001 = env14002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14001 == env14002) = true)

def leafEnv14002 : List Nat := [2,4,8,1,0,0,128,4,137,4,0,0,9,0,0,138,1,1,5,1,1,1,1,139,5,129,1,1,1,0,1,0,5,137,5,137,4,3,0,137,0,1,1]

def active14002 : List Nat := [0,1,2,6]

def tree14002 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14002 : H12WitnessSearch.Good tree14002 := H12GlobalWitnessIndex.good

theorem leafIdentity14002 : H12AffineFastState.composeSystem env14002 rootObs = leafEnv14002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14002 rootObs == leafEnv14002) = true)

theorem terminalChecked14002 : H12PackedTerminal.terminalCheckFast leafEnv14002 active14002 tree14002 = true := by decide +kernel

def env14003 : List Nat := [2,4,8,16,1,17,128,256,137,272,0,1,9,1,261,65536,0,261,273,260,0,1,16,65536,129,16,1,1,0,260,21,65538,257,136,1,137]

theorem envBound14003 : H12AffineFastState.Bounded env14003 := by
  intro p hp
  have h : env14003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13998_14003 : H12AffineEnvironment.transform 4 1 env13998 = env14003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13998 == env14003) = true)

theorem identity14003 : scanCanonicalize (H12AffineFastState.compose env14003 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14003 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14004 : List Nat := [2,4,8,16,1,17,128,5,137,21,0,1,9,1,0,65536,0,0,20,1,0,1,16,65536,129,16,1,1,0,1,21,65538,4,136,1,137]

theorem envBound14004 : H12AffineFastState.Bounded env14004 := by
  intro p hp
  have h : env14004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14003_14004 : H12AffineEnvironment.transform 7 5 env14003 = env14004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14003 == env14004) = true)

theorem identity14004 : scanCanonicalize (H12AffineFastState.compose env14004 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound14004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14005 : List Nat := [2,4,8,16,1,17,128,5,137,21,0,1,9,1,0,18,0,0,20,1,0,1,16,18,129,16,1,1,0,1,21,16,4,136,1,137]

theorem envBound14005 : H12AffineFastState.Bounded env14005 := by
  intro p hp
  have h : env14005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14004_14005 : H12AffineEnvironment.transform 15 18 env14004 = env14005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env14004 == env14005) = true)

theorem identity14005 : scanCanonicalize (H12AffineFastState.compose env14005 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14005 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14006 : List Nat := [2,4,8,16,1,17,25,5,16,21,0,1,9,1,0,18,0,0,20,1,0,1,16,18,24,16,1,1,0,1,21,16,4,17,1,16]

theorem envBound14006 : H12AffineFastState.Bounded env14006 := by
  intro p hp
  have h : env14006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14005_14006 : H12AffineEnvironment.transform 6 25 env14005 = env14006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14005 == env14006) = true)

def leafEnv14006 : List Nat := [2,4,8,16,1,17,25,5,16,21,0,1,9,1,0,18,0,0,20,1,0,1,16,18,21,24,1,16,1,1,0,1,21,16,4,17,4,2,1,16,0,0,1]

def active14006 : List Nat := [0,1,2,3]

def tree14006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14006 : H12WitnessSearch.Good tree14006 := H12GlobalWitnessIndex.good

theorem leafIdentity14006 : H12AffineFastState.composeSystem env14006 rootObs = leafEnv14006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14006 rootObs == leafEnv14006) = true)

theorem terminalChecked14006 : H12PackedTerminal.terminalCheckFast leafEnv14006 active14006 tree14006 = true := by decide +kernel

def env14007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1344,529408,1073741824,1284,4294967296,256,4295074215,1345,512]

theorem envBound14007 : H12AffineFastState.Bounded env14007 := by
  intro p hp
  have h : env14007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13963_14007 : H12AffineEnvironment.transform 13 1345 env13963 = env14007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env13963 == env14007) = true)

theorem identity14007 : scanCanonicalize (H12AffineFastState.compose env14007 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 820517) := by decide +kernel

theorem selectedBound14007 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1344,529408,820517,1284,4294967296,256,4295074215,1345,512]

theorem envBound14008 : H12AffineFastState.Bounded env14008 := by
  intro p hp
  have h : env14008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14007_14008 : H12AffineEnvironment.transform 29 820517 env14007 = env14008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 820517 env14007 == env14008) = true)

theorem identity14008 : scanCanonicalize (H12AffineFastState.compose env14008 (packedSelected [17,21] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound14008 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,1024,32769,4097,8200,64,98565,8328,16,270604,1344,4096,295205,1284,4294967296,256,4295074215,1345,512]

theorem envBound14009 : H12AffineFastState.Bounded env14009 := by
  intro p hp
  have h : env14009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14008_14009 : H12AffineEnvironment.transform 18 1024 env14008 = env14009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14008 == env14009) = true)

theorem identity14009 : scanCanonicalize (H12AffineFastState.compose env14009 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound14009 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,41001,1024,32769,4097,8200,64,98565,8328,16,33061,1344,4096,8460,1284,4294967296,256,4295074215,1345,512]

theorem envBound14010 : H12AffineFastState.Bounded env14010 := by
  intro p hp
  have h : env14010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14009_14010 : H12AffineEnvironment.transform 17 41001 env14009 = env14010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env14009 == env14010) = true)

theorem identity14010 : scanCanonicalize (H12AffineFastState.compose env14010 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound14010 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,292,65536,1344,8461,1024,293,4097,8200,64,65569,8328,16,1,1344,4096,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14011 : H12AffineFastState.Bounded env14011 := by
  intro p hp
  have h : env14011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14010_14011 : H12AffineEnvironment.transform 14 292 env14010 = env14011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env14010 == env14011) = true)

def env14012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1345,292,65536,1344,8461,1024,293,1345,8200,64,65569,8328,16,1,1344,1344,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14012 : H12AffineFastState.Bounded env14012 := by
  intro p hp
  have h : env14012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14011_14012 : H12AffineEnvironment.transform 11 1344 env14011 = env14012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14011 == env14012) = true)

theorem identity14012 : scanCanonicalize (H12AffineFastState.compose env14012 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14012 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1297,292,65536,1296,8461,1024,293,1297,8200,16,65569,8328,16,1,1296,1296,8460,1284,4294967296,256,4295041155,1297,512]

theorem envBound14013 : H12AffineFastState.Bounded env14013 := by
  intro p hp
  have h : env14013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14012_14013 : H12AffineEnvironment.transform 5 16 env14012 = env14013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14012 == env14013) = true)

theorem identity14013 : scanCanonicalize (H12AffineFastState.compose env14013 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14013 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14014 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,268,1297,292,65536,1296,1,1024,293,1297,260,16,65569,388,16,1,1296,1296,0,1284,4294967296,256,4295033231,1297,512]

theorem envBound14014 : H12AffineFastState.Bounded env14014 := by
  intro p hp
  have h : env14014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14013_14014 : H12AffineEnvironment.transform 12 268 env14013 = env14014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14013 == env14014) = true)

def env14015 : List Nat := [2,4,8,16,32,16,128,256,512,272,0,0,268,1,292,65536,0,1,272,293,1,260,16,65569,388,16,1,0,0,0,20,4294967296,256,4295033231,1,512]

theorem envBound14015 : H12AffineFastState.Bounded env14015 := by
  intro p hp
  have h : env14015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14014_14015 : H12AffineEnvironment.transform 9 272 env14014 = env14015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14014 == env14015) = true)

def env14016 : List Nat := [2,4,8,16,32,16,128,36,512,52,0,0,40,1,0,65536,0,1,52,1,1,32,16,65569,160,16,1,0,0,0,20,4294967296,36,4295033003,1,512]

theorem envBound14016 : H12AffineFastState.Bounded env14016 := by
  intro p hp
  have h : env14016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14015_14016 : H12AffineEnvironment.transform 7 36 env14015 = env14016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14015 == env14016) = true)

def env14017 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,40,1,0,65536,0,1,52,1,1,32,16,65569,160,16,1,0,0,0,20,4294967296,36,4295033003,1,0]

theorem envBound14017 : H12AffineFastState.Bounded env14017 := by
  intro p hp
  have h : env14017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14016_14017 : H12AffineEnvironment.transform 8 0 env14016 = env14017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14016 == env14017) = true)

theorem identity14017 : scanCanonicalize (H12AffineFastState.compose env14017 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14018 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,40,1,0,65536,0,1,52,1,1,32,16,65569,160,16,1,0,0,0,20,137,36,65570,1,0]

theorem envBound14018 : H12AffineFastState.Bounded env14018 := by
  intro p hp
  have h : env14018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14017_14018 : H12AffineEnvironment.transform 31 137 env14017 = env14018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14017 == env14018) = true)

theorem identity14018 : scanCanonicalize (H12AffineFastState.compose env14018 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound14018 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14019 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,40,1,0,138,0,1,52,1,1,32,16,171,160,16,1,0,0,0,20,137,36,168,1,0]

theorem envBound14019 : H12AffineFastState.Bounded env14019 := by
  intro p hp
  have h : env14019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14018_14019 : H12AffineEnvironment.transform 15 138 env14018 = env14019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env14018 == env14019) = true)

theorem identity14019 : scanCanonicalize (H12AffineFastState.compose env14019 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound14019 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14020 : List Nat := [2,4,8,16,32,16,40,36,0,52,0,0,40,1,0,34,0,1,52,1,1,32,16,3,8,16,1,0,0,0,20,33,36,0,1,0]

theorem envBound14020 : H12AffineFastState.Bounded env14020 := by
  intro p hp
  have h : env14020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14019_14020 : H12AffineEnvironment.transform 6 40 env14019 = env14020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env14019 == env14020) = true)

theorem identity14020 : scanCanonicalize (H12AffineFastState.compose env14020 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14020 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14021 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,0,8,1,0,2,0,1,20,1,1,0,16,3,8,16,1,0,0,0,20,1,4,0,1,0]

theorem envBound14021 : H12AffineFastState.Bounded env14021 := by
  intro p hp
  have h : env14021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14020_14021 : H12AffineEnvironment.transform 4 0 env14020 = env14021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14020 == env14021) = true)

def leafEnv14021 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,0,8,1,0,2,0,1,20,1,1,0,16,3,20,8,1,16,1,0,0,0,20,1,4,0,4,3,1,0,0,1,1]

def active14021 : List Nat := [0,1,2,3]

def tree14021 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14021 : H12WitnessSearch.Good tree14021 := H12GlobalWitnessIndex.good

theorem leafIdentity14021 : H12AffineFastState.composeSystem env14021 rootObs = leafEnv14021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14021 rootObs == leafEnv14021) = true)

theorem terminalChecked14021 : H12PackedTerminal.terminalCheckFast leafEnv14021 active14021 tree14021 = true := by decide +kernel

def env14022 : List Nat := [2,4,8,16,32,16,128,36,1,52,0,0,40,1,0,65536,0,1,52,1,1,32,16,65569,160,16,1,0,0,0,20,4294967296,36,4295033003,1,1]

theorem envBound14022 : H12AffineFastState.Bounded env14022 := by
  intro p hp
  have h : env14022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14016_14022 : H12AffineEnvironment.transform 8 1 env14016 = env14022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14016 == env14022) = true)

theorem identity14022 : scanCanonicalize (H12AffineFastState.compose env14022 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound14022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14023 : List Nat := [2,4,8,16,32,16,128,36,1,52,0,0,40,1,0,65536,0,1,52,1,1,32,16,65569,160,16,1,0,0,0,20,1,36,65706,1,1]

theorem envBound14023 : H12AffineFastState.Bounded env14023 := by
  intro p hp
  have h : env14023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14022_14023 : H12AffineEnvironment.transform 31 1 env14022 = env14023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env14022 == env14023) = true)

theorem identity14023 : scanCanonicalize (H12AffineFastState.compose env14023 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14023 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14024 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,9,1,0,65536,0,1,21,1,1,1,16,65536,129,16,1,0,0,0,20,1,5,65675,1,1]

theorem envBound14024 : H12AffineFastState.Bounded env14024 := by
  intro p hp
  have h : env14024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14023_14024 : H12AffineEnvironment.transform 4 1 env14023 = env14024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14023 == env14024) = true)

theorem identity14024 : scanCanonicalize (H12AffineFastState.compose env14024 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14024 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14025 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,9,1,0,139,0,1,21,1,1,1,16,139,129,16,1,0,0,0,20,1,5,0,1,1]

theorem envBound14025 : H12AffineFastState.Bounded env14025 := by
  intro p hp
  have h : env14025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14024_14025 : H12AffineEnvironment.transform 15 139 env14024 = env14025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14024 == env14025) = true)

def leafEnv14025 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,9,1,0,139,0,1,21,1,1,1,16,139,20,129,1,16,1,0,0,0,20,1,5,0,4,2,1,1,0,1,1]

def active14025 : List Nat := [0,1,2,3,6]

def tree14025 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14025 : H12WitnessSearch.Good tree14025 := H12GlobalWitnessIndex.good

theorem leafIdentity14025 : H12AffineFastState.composeSystem env14025 rootObs = leafEnv14025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14025 rootObs == leafEnv14025) = true)

theorem terminalChecked14025 : H12PackedTerminal.terminalCheckFast leafEnv14025 active14025 tree14025 = true := by decide +kernel

def env14026 : List Nat := [2,4,8,16,32,16,128,37,512,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,161,16,1,0,0,0,20,4294967296,37,4295033002,1,512]

theorem envBound14026 : H12AffineFastState.Bounded env14026 := by
  intro p hp
  have h : env14026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14015_14026 : H12AffineEnvironment.transform 7 37 env14015 = env14026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14015 == env14026) = true)

def env14027 : List Nat := [2,4,8,16,32,16,128,37,0,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,161,16,1,0,0,0,20,4294967296,37,4295033002,1,0]

theorem envBound14027 : H12AffineFastState.Bounded env14027 := by
  intro p hp
  have h : env14027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14026_14027 : H12AffineEnvironment.transform 8 0 env14026 = env14027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14026 == env14027) = true)

theorem identity14027 : scanCanonicalize (H12AffineFastState.compose env14027 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound14027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14028 : List Nat := [2,4,8,16,32,16,128,37,0,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,161,16,1,0,0,0,20,65706,37,0,1,0]

theorem envBound14028 : H12AffineFastState.Bounded env14028 := by
  intro p hp
  have h : env14028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14027_14028 : H12AffineEnvironment.transform 31 65706 env14027 = env14028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env14027 == env14028) = true)

def env14029 : List Nat := [2,4,8,16,32,16,8,37,0,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,41,16,1,0,0,0,20,65570,37,0,1,0]

theorem envBound14029 : H12AffineFastState.Bounded env14029 := by
  intro p hp
  have h : env14029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14028_14029 : H12AffineEnvironment.transform 6 8 env14028 = env14029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14028 == env14029) = true)

def env14030 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,9,1,1,65536,0,1,21,0,1,1,16,65537,9,16,1,0,0,0,20,65538,5,0,1,0]

theorem envBound14030 : H12AffineFastState.Bounded env14030 := by
  intro p hp
  have h : env14030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14029_14030 : H12AffineEnvironment.transform 4 0 env14029 = env14030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14029 == env14030) = true)

theorem identity14030 : scanCanonicalize (H12AffineFastState.compose env14030 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14030 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14031 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,9,1,1,2,0,1,21,0,1,1,16,3,9,16,1,0,0,0,20,0,5,0,1,0]

theorem envBound14031 : H12AffineFastState.Bounded env14031 := by
  intro p hp
  have h : env14031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14030_14031 : H12AffineEnvironment.transform 15 2 env14030 = env14031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14030 == env14031) = true)

def leafEnv14031 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,9,1,1,2,0,1,21,0,1,1,16,3,20,9,1,16,1,0,0,0,20,0,5,0,4,3,1,0,0,1,1]

def active14031 : List Nat := [0,1,2,3]

def tree14031 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14031 : H12WitnessSearch.Good tree14031 := H12GlobalWitnessIndex.good

theorem leafIdentity14031 : H12AffineFastState.composeSystem env14031 rootObs = leafEnv14031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14031 rootObs == leafEnv14031) = true)

theorem terminalChecked14031 : H12PackedTerminal.terminalCheckFast leafEnv14031 active14031 tree14031 = true := by decide +kernel

def env14032 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,1,1,65536,0,1,20,0,1,0,16,65536,8,16,1,0,0,0,20,65539,4,0,1,0]

theorem envBound14032 : H12AffineFastState.Bounded env14032 := by
  intro p hp
  have h : env14032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14029_14032 : H12AffineEnvironment.transform 4 1 env14029 = env14032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14029 == env14032) = true)

def leafEnv14032 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,1,1,65536,0,1,20,0,1,0,16,65536,20,8,1,16,1,0,0,0,20,65539,4,0,4,2,1,0,0,1,1]

def active14032 : List Nat := [0,1,2,3,15]

def tree14032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14032 : H12WitnessSearch.Good tree14032 := H12GlobalWitnessIndex.good

theorem leafIdentity14032 : H12AffineFastState.composeSystem env14032 rootObs = leafEnv14032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14032 rootObs == leafEnv14032) = true)

theorem terminalChecked14032 : H12PackedTerminal.terminalCheckFast leafEnv14032 active14032 tree14032 = true := by decide +kernel

def env14033 : List Nat := [2,4,8,16,32,16,9,37,0,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,40,16,1,0,0,0,20,65571,37,0,1,0]

theorem envBound14033 : H12AffineFastState.Bounded env14033 := by
  intro p hp
  have h : env14033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14028_14033 : H12AffineEnvironment.transform 6 9 env14028 = env14033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14028 == env14033) = true)

theorem identity14033 : scanCanonicalize (H12AffineFastState.compose env14033 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound14033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14034 : List Nat := [2,4,8,16,32,16,9,37,0,53,0,0,41,1,1,35,0,1,53,0,1,33,16,2,40,16,1,0,0,0,20,0,37,0,1,0]

theorem envBound14034 : H12AffineFastState.Bounded env14034 := by
  intro p hp
  have h : env14034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14033_14034 : H12AffineEnvironment.transform 15 35 env14033 = env14034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env14033 == env14034) = true)

def env14035 : List Nat := [2,4,8,16,32,16,128,37,1,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,161,16,1,0,0,0,20,4294967296,37,4295033002,1,1]

theorem envBound14035 : H12AffineFastState.Bounded env14035 := by
  intro p hp
  have h : env14035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14026_14035 : H12AffineEnvironment.transform 8 1 env14026 = env14035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14026 == env14035) = true)

theorem identity14035 : scanCanonicalize (H12AffineFastState.compose env14035 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound14035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14036 : List Nat := [2,4,8,16,32,16,128,37,1,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,161,16,1,0,0,0,20,65570,37,136,1,1]

theorem envBound14036 : H12AffineFastState.Bounded env14036 := by
  intro p hp
  have h : env14036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14035_14036 : H12AffineEnvironment.transform 31 65570 env14035 = env14036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env14035 == env14036) = true)

theorem identity14036 : scanCanonicalize (H12AffineFastState.compose env14036 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14037 : List Nat := [2,4,8,16,32,16,9,37,1,53,0,0,41,1,1,65536,0,1,53,0,1,33,16,65569,40,16,1,0,0,0,20,65570,37,1,1,1]

theorem envBound14037 : H12AffineFastState.Bounded env14037 := by
  intro p hp
  have h : env14037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14036_14037 : H12AffineEnvironment.transform 6 9 env14036 = env14037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14036 == env14037) = true)

def env14038 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,9,1,1,65536,0,1,21,0,1,1,16,65537,8,16,1,0,0,0,20,65538,5,1,1,1]

theorem envBound14038 : H12AffineFastState.Bounded env14038 := by
  intro p hp
  have h : env14038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14038 : H12AffineEnvironment.transform 4 0 env14037 = env14038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14037 == env14038) = true)

theorem identity14038 : scanCanonicalize (H12AffineFastState.compose env14038 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14038 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14039 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,9,1,1,3,0,1,21,0,1,1,16,2,8,16,1,0,0,0,20,1,5,1,1,1]

theorem envBound14039 : H12AffineFastState.Bounded env14039 := by
  intro p hp
  have h : env14039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14038_14039 : H12AffineEnvironment.transform 15 3 env14038 = env14039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14038 == env14039) = true)

def leafEnv14039 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,9,1,1,3,0,1,21,0,1,1,16,2,20,8,1,16,1,0,0,0,20,1,5,1,4,3,1,1,0,1,1]

def active14039 : List Nat := [0,1,2,3]

def tree14039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14039 : H12WitnessSearch.Good tree14039 := H12GlobalWitnessIndex.good

theorem leafIdentity14039 : H12AffineFastState.composeSystem env14039 rootObs = leafEnv14039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14039 rootObs == leafEnv14039) = true)

theorem terminalChecked14039 : H12PackedTerminal.terminalCheckFast leafEnv14039 active14039 tree14039 = true := by decide +kernel

def env14040 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,8,1,1,65536,0,1,20,0,1,0,16,65536,9,16,1,0,0,0,20,65539,4,1,1,1]

theorem envBound14040 : H12AffineFastState.Bounded env14040 := by
  intro p hp
  have h : env14040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14040 : H12AffineEnvironment.transform 4 1 env14037 = env14040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14037 == env14040) = true)

def leafEnv14040 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,8,1,1,65536,0,1,20,0,1,0,16,65536,20,9,1,16,1,0,0,0,20,65539,4,1,4,2,1,1,0,1,1]

def active14040 : List Nat := [0,1,2,3,15]

def tree14040 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14040 : H12WitnessSearch.Good tree14040 := H12GlobalWitnessIndex.good

theorem leafIdentity14040 : H12AffineFastState.composeSystem env14040 rootObs = leafEnv14040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14040 rootObs == leafEnv14040) = true)

theorem terminalChecked14040 : H12PackedTerminal.terminalCheckFast leafEnv14040 active14040 tree14040 = true := by decide +kernel

def env14041 : List Nat := [2,4,8,16,32,16,128,256,512,273,0,1,268,0,292,65536,1,1,273,293,0,260,16,65569,388,16,1,1,1,0,21,4294967296,256,4295033231,0,512]

theorem envBound14041 : H12AffineFastState.Bounded env14041 := by
  intro p hp
  have h : env14041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14014_14041 : H12AffineEnvironment.transform 9 273 env14014 = env14041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14014 == env14041) = true)

theorem identity14041 : scanCanonicalize (H12AffineFastState.compose env14041 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14042 : List Nat := [2,4,8,16,32,16,128,256,512,273,0,1,268,0,292,170,1,1,273,293,0,260,16,139,388,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14042 : H12AffineFastState.Bounded env14042 := by
  intro p hp
  have h : env14042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14041_14042 : H12AffineEnvironment.transform 15 170 env14041 = env14042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14041 == env14042) = true)

def env14043 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,1,268,0,292,34,1,1,273,293,0,260,16,3,268,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14043 : H12AffineFastState.Bounded env14043 := by
  intro p hp
  have h : env14043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14042_14043 : H12AffineEnvironment.transform 6 8 env14042 = env14043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14042 == env14043) = true)

theorem identity14043 : scanCanonicalize (H12AffineFastState.compose env14043 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound14043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14044 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,1,268,0,292,34,1,1,273,293,0,260,16,3,268,16,1,1,1,0,21,293,256,0,0,512]

theorem envBound14044 : H12AffineFastState.Bounded env14044 := by
  intro p hp
  have h : env14044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14043_14044 : H12AffineEnvironment.transform 31 293 env14043 = env14044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env14043 == env14044) = true)

def env14045 : List Nat := [2,4,8,16,0,16,8,256,512,273,0,1,268,0,260,2,1,1,273,261,0,260,16,3,268,16,1,1,1,0,21,261,256,0,0,512]

theorem envBound14045 : H12AffineFastState.Bounded env14045 := by
  intro p hp
  have h : env14045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14044_14045 : H12AffineEnvironment.transform 4 0 env14044 = env14045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14044 == env14045) = true)

theorem identity14045 : scanCanonicalize (H12AffineFastState.compose env14045 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14045 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14046 : List Nat := [2,4,8,16,0,16,8,256,0,273,0,1,268,0,260,2,1,1,273,261,0,260,16,3,268,16,1,1,1,0,21,261,256,0,0,0]

theorem envBound14046 : H12AffineFastState.Bounded env14046 := by
  intro p hp
  have h : env14046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14045_14046 : H12AffineEnvironment.transform 8 0 env14045 = env14046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14045 == env14046) = true)

def leafEnv14046 : List Nat := [2,4,8,16,0,16,8,256,0,273,0,1,268,0,260,2,1,1,273,261,0,260,16,3,21,268,1,16,1,1,1,0,21,261,256,0,4,3,0,0,0,0,1]

def active14046 : List Nat := [0,1,2,3,7]

def tree14046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14046 : H12WitnessSearch.Good tree14046 := H12GlobalWitnessIndex.good

theorem leafIdentity14046 : H12AffineFastState.composeSystem env14046 rootObs = leafEnv14046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14046 rootObs == leafEnv14046) = true)

theorem terminalChecked14046 : H12PackedTerminal.terminalCheckFast leafEnv14046 active14046 tree14046 = true := by decide +kernel

def env14047 : List Nat := [2,4,8,16,1,16,8,256,512,273,0,1,268,0,261,3,1,1,273,260,0,260,16,3,268,16,1,1,1,0,21,260,256,0,0,512]

theorem envBound14047 : H12AffineFastState.Bounded env14047 := by
  intro p hp
  have h : env14047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14044_14047 : H12AffineEnvironment.transform 4 1 env14044 = env14047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14044 == env14047) = true)

theorem identity14047 : scanCanonicalize (H12AffineFastState.compose env14047 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound14047 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14048 : List Nat := [2,4,8,16,1,16,8,256,260,273,0,1,268,0,261,3,1,1,273,260,0,260,16,3,268,16,1,1,1,0,21,260,256,0,0,260]

theorem envBound14048 : H12AffineFastState.Bounded env14048 := by
  intro p hp
  have h : env14048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14047_14048 : H12AffineEnvironment.transform 8 260 env14047 = env14048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env14047 == env14048) = true)

def leafEnv14048 : List Nat := [2,4,8,16,1,16,8,256,260,273,0,1,268,0,261,3,1,1,273,260,0,260,16,3,21,268,1,16,1,1,1,0,21,260,256,0,4,2,0,260,0,0,1]

def active14048 : List Nat := [0,1,2,3,7]

def tree14048 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14048 : H12WitnessSearch.Good tree14048 := H12GlobalWitnessIndex.good

theorem leafIdentity14048 : H12AffineFastState.composeSystem env14048 rootObs = leafEnv14048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14048 rootObs == leafEnv14048) = true)

theorem terminalChecked14048 : H12PackedTerminal.terminalCheckFast leafEnv14048 active14048 tree14048 = true := by decide +kernel

def env14049 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,1,268,0,292,35,1,1,273,293,0,260,16,2,269,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14049 : H12AffineFastState.Bounded env14049 := by
  intro p hp
  have h : env14049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14042_14049 : H12AffineEnvironment.transform 6 9 env14042 = env14049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14042 == env14049) = true)

theorem identity14049 : scanCanonicalize (H12AffineFastState.compose env14049 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound14049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14050 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,1,268,0,292,35,1,1,273,293,0,260,16,2,269,16,1,1,1,0,21,512,256,805,0,512]

theorem envBound14050 : H12AffineFastState.Bounded env14050 := by
  intro p hp
  have h : env14050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14049_14050 : H12AffineEnvironment.transform 31 512 env14049 = env14050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env14049 == env14050) = true)

theorem identity14050 : scanCanonicalize (H12AffineFastState.compose env14050 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14050 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14051 : List Nat := [2,4,8,16,32,16,9,256,1,273,0,1,268,0,292,35,1,1,273,293,0,260,16,2,269,16,1,1,1,0,21,1,256,292,0,1]

theorem envBound14051 : H12AffineFastState.Bounded env14051 := by
  intro p hp
  have h : env14051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14050_14051 : H12AffineEnvironment.transform 8 1 env14050 = env14051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14050 == env14051) = true)

def env14052 : List Nat := [2,4,8,16,0,16,9,256,1,273,0,1,268,0,260,3,1,1,273,261,0,260,16,2,269,16,1,1,1,0,21,1,256,260,0,1]

theorem envBound14052 : H12AffineFastState.Bounded env14052 := by
  intro p hp
  have h : env14052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14051_14052 : H12AffineEnvironment.transform 4 0 env14051 = env14052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14051 == env14052) = true)

theorem identity14052 : scanCanonicalize (H12AffineFastState.compose env14052 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14053 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,9,0,1,3,1,1,20,0,0,1,16,2,8,16,1,1,1,0,21,1,5,1,0,1]

theorem envBound14053 : H12AffineFastState.Bounded env14053 := by
  intro p hp
  have h : env14053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14052_14053 : H12AffineEnvironment.transform 7 5 env14052 = env14053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14052 == env14053) = true)

def leafEnv14053 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,9,0,1,3,1,1,20,0,0,1,16,2,21,8,1,16,1,1,1,0,21,1,5,1,4,3,0,1,0,0,1]

def active14053 : List Nat := [0,1,2,3]

def tree14053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14053 : H12WitnessSearch.Good tree14053 := H12GlobalWitnessIndex.good

theorem leafIdentity14053 : H12AffineFastState.composeSystem env14053 rootObs = leafEnv14053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14053 rootObs == leafEnv14053) = true)

theorem terminalChecked14053 : H12PackedTerminal.terminalCheckFast leafEnv14053 active14053 tree14053 = true := by decide +kernel

def env14054 : List Nat := [2,4,8,16,1,16,9,256,1,273,0,1,268,0,261,2,1,1,273,260,0,260,16,2,269,16,1,1,1,0,21,1,256,261,0,1]

theorem envBound14054 : H12AffineFastState.Bounded env14054 := by
  intro p hp
  have h : env14054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14051_14054 : H12AffineEnvironment.transform 4 1 env14051 = env14054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14051 == env14054) = true)

def leafEnv14054 : List Nat := [2,4,8,16,1,16,9,256,1,273,0,1,268,0,261,2,1,1,273,260,0,260,16,2,21,269,1,16,1,1,1,0,21,1,256,261,4,2,0,1,0,0,1]

def active14054 : List Nat := [0,1,2,3,7]

def tree14054 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14054 : H12WitnessSearch.Good tree14054 := H12GlobalWitnessIndex.good

theorem leafIdentity14054 : H12AffineFastState.composeSystem env14054 rootObs = leafEnv14054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14054 rootObs == leafEnv14054) = true)

theorem terminalChecked14054 : H12PackedTerminal.terminalCheckFast leafEnv14054 active14054 tree14054 = true := by decide +kernel

def env14055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,8192,1345,292,65536,1344,8461,1024,293,1344,8200,64,65569,8328,16,1,1344,1345,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14055 : H12AffineFastState.Bounded env14055 := by
  intro p hp
  have h : env14055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14011_14055 : H12AffineEnvironment.transform 11 1345 env14011 = env14055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14011 == env14055) = true)

theorem identity14055 : scanCanonicalize (H12AffineFastState.compose env14055 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound14055 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,8192,1345,292,251,1344,8461,1024,293,1344,8200,64,218,8328,16,1,1344,1345,8460,1284,4294967296,256,4294975608,1345,512]

theorem envBound14056 : H12AffineFastState.Bounded env14056 := by
  intro p hp
  have h : env14056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14055_14056 : H12AffineEnvironment.transform 15 251 env14055 = env14056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env14055 == env14056) = true)

theorem identity14056 : scanCanonicalize (H12AffineFastState.compose env14056 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14056 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,8192,1296,292,170,1297,8461,1024,293,1297,8200,17,139,8328,16,1,1297,1296,8460,1284,4294967296,256,4294975529,1296,512]

theorem envBound14057 : H12AffineFastState.Bounded env14057 := by
  intro p hp
  have h : env14057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14056_14057 : H12AffineEnvironment.transform 5 17 env14056 = env14057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14056 == env14057) = true)

theorem identity14057 : scanCanonicalize (H12AffineFastState.compose env14057 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound14057 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14058 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,8192,1296,292,170,1297,8461,1024,293,1297,8200,17,139,8328,16,1,1297,1296,8460,1284,4294967296,256,4294975529,1296,429]

theorem envBound14058 : H12AffineFastState.Bounded env14058 := by
  intro p hp
  have h : env14058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14057_14058 : H12AffineEnvironment.transform 8 429 env14057 = env14058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env14057 == env14058) = true)

theorem identity14058 : scanCanonicalize (H12AffineFastState.compose env14058 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14058 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14059 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,41,1296,292,170,1297,292,1024,293,1297,33,17,139,161,16,1,1297,1296,293,1284,4294967296,256,4294967296,1296,429]

theorem envBound14059 : H12AffineFastState.Bounded env14059 := by
  intro p hp
  have h : env14059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14058_14059 : H12AffineEnvironment.transform 12 41 env14058 = env14059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14058 == env14059) = true)

theorem identity14059 : scanCanonicalize (H12AffineFastState.compose env14059 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14059 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14060 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,41,1296,292,170,1297,292,1024,293,1297,33,17,139,161,16,1,1297,1296,293,1284,137,256,137,1296,429]

theorem envBound14060 : H12AffineFastState.Bounded env14060 := by
  intro p hp
  have h : env14060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14059_14060 : H12AffineEnvironment.transform 31 137 env14059 = env14060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14059 == env14060) = true)

theorem identity14060 : scanCanonicalize (H12AffineFastState.compose env14060 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14060 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14061 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,41,1077,1,170,1076,1,1024,0,1076,33,17,139,161,16,1,1076,1077,0,1057,137,37,137,1077,136]

theorem envBound14061 : H12AffineFastState.Bounded env14061 := by
  intro p hp
  have h : env14061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14060_14061 : H12AffineEnvironment.transform 7 37 env14060 = env14061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14060 == env14061) = true)

def leafEnv14061 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,41,1077,1,170,1076,1,1024,0,1076,33,17,139,1057,161,1,16,1,1076,1077,0,1057,137,37,137,4,35,1077,136,0,1076,1]

def active14061 : List Nat := [0,1,2,3,4,6,9]

def tree14061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14061 : H12WitnessSearch.Good tree14061 := H12GlobalWitnessIndex.good

theorem leafIdentity14061 : H12AffineFastState.composeSystem env14061 rootObs = leafEnv14061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14061 rootObs == leafEnv14061) = true)

theorem terminalChecked14061 : H12PackedTerminal.terminalCheckFast leafEnv14061 active14061 tree14061 = true := by decide +kernel

def env14062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,8201,17665,98565,8328,541009,795917,1344,529408,1073741824,16453,4294967296,17473,4295074214,16384,512]

theorem envBound14062 : H12AffineFastState.Bounded env14062 := by
  intro p hp
  have h : env14062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13962_14062 : H12AffineEnvironment.transform 10 1 env13962 = env14062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13962 == env14062) = true)

def env14063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1344,529408,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound14063 : H12AffineFastState.Bounded env14063 := by
  intro p hp
  have h : env14063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14062_14063 : H12AffineEnvironment.transform 13 1344 env14062 = env14063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14062 == env14063) = true)

theorem identity14063 : scanCanonicalize (H12AffineFastState.compose env14063 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 536605) := by decide +kernel

theorem selectedBound14063 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1344,529408,536605,1285,4294967296,257,4295074214,1344,512]

theorem envBound14064 : H12AffineFastState.Bounded env14064 := by
  intro p hp
  have h : env14064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14063_14064 : H12AffineEnvironment.transform 29 536605 env14063 = env14064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 536605 env14063 == env14064) = true)

theorem identity14064 : scanCanonicalize (H12AffineFastState.compose env14064 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14064 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,8201,65,98565,8328,16,270604,1344,4097,13340,1285,4294967296,257,4295074214,1344,512]

theorem envBound14065 : H12AffineFastState.Bounded env14065 := by
  intro p hp
  have h : env14065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14064_14065 : H12AffineEnvironment.transform 18 1025 env14064 = env14065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14064 == env14065) = true)

theorem identity14065 : scanCanonicalize (H12AffineFastState.compose env14065 (packedSelected [0,1,4,5,7,9,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 5821) := by decide +kernel

theorem selectedBound14065 : packedSelected [0,1,4,5,7,9,15,17] rootPS < 2^1333 := by decide +kernel

def env14066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,5821,65536,1345,262144,1025,5820,4097,8201,65,71608,8328,16,270604,1344,4097,13340,1285,4294967296,257,4295046939,1344,512]

theorem envBound14066 : H12AffineFastState.Bounded env14066 := by
  intro p hp
  have h : env14066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14065_14066 : H12AffineEnvironment.transform 14 5821 env14065 = env14066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5821 env14065 == env14066) = true)

theorem identity14066 : scanCanonicalize (H12AffineFastState.compose env14066 (packedSelected [0,1,4,5,7,9,15,21] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14066 : packedSelected [0,1,4,5,7,9,15,21] rootPS < 2^1333 := by decide +kernel

def env14067 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1344,5172,65536,1345,262144,1025,5173,4097,8201,65,70961,8328,16,270604,1344,4097,13340,1285,4294967296,257,4295046546,1344,137]

theorem envBound14067 : H12AffineFastState.Bounded env14067 := by
  intro p hp
  have h : env14067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14066_14067 : H12AffineEnvironment.transform 8 137 env14066 = env14067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14066 == env14067) = true)

theorem identity14067 : scanCanonicalize (H12AffineFastState.compose env14067 (packedSelected [0,2,4,6,18] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound14067 : packedSelected [0,2,4,6,18] rootPS < 2^1333 := by decide +kernel

def env14068 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,8192,1344,293,65536,1345,262144,1025,292,1296,8201,65,65568,8328,16,270604,1344,1296,8461,1285,4294967296,257,4295041155,1344,137]

theorem envBound14068 : H12AffineFastState.Bounded env14068 := by
  intro p hp
  have h : env14068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14067_14068 : H12AffineEnvironment.transform 11 1297 env14067 = env14068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env14067 == env14068) = true)

theorem identity14068 : scanCanonicalize (H12AffineFastState.compose env14068 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14068 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14069 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,8,1344,293,65536,1345,262144,1025,292,1296,1,65,65568,128,16,262404,1344,1296,261,1285,4294967296,257,4295032971,1344,137]

theorem envBound14069 : H12AffineFastState.Bounded env14069 := by
  intro p hp
  have h : env14069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14068_14069 : H12AffineEnvironment.transform 12 8 env14068 = env14069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14068 == env14069) = true)

theorem identity14069 : scanCanonicalize (H12AffineFastState.compose env14069 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 260) := by decide +kernel

theorem selectedBound14069 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14070 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,8,1344,293,65536,1345,260,1025,292,1296,1,65,65568,128,16,0,1344,1296,261,1285,4294967296,257,4295032971,1344,137]

theorem envBound14070 : H12AffineFastState.Bounded env14070 := by
  intro p hp
  have h : env14070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14069_14070 : H12AffineEnvironment.transform 17 260 env14069 = env14070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 260 env14069 == env14070) = true)

def env14071 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1297,8,1296,293,65536,1297,260,1025,292,1296,1,17,65568,128,16,0,1296,1296,261,1285,4294967296,257,4295032971,1296,137]

theorem envBound14071 : H12AffineFastState.Bounded env14071 := by
  intro p hp
  have h : env14071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14070_14071 : H12AffineEnvironment.transform 5 16 env14070 = env14071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14070 == env14071) = true)

theorem identity14071 : scanCanonicalize (H12AffineFastState.compose env14071 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14071 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14072 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1297,8,1296,293,65536,1297,260,1025,292,1296,1,17,65568,128,16,0,1296,1296,261,1285,137,257,65538,1296,137]

theorem envBound14072 : H12AffineFastState.Bounded env14072 := by
  intro p hp
  have h : env14072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14071_14072 : H12AffineEnvironment.transform 31 137 env14071 = env14072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14071 == env14072) = true)

def env14073 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,1,8,0,293,65536,1,260,273,292,0,1,17,65568,128,16,0,0,0,261,21,137,257,65538,0,137]

theorem envBound14073 : H12AffineFastState.Bounded env14073 := by
  intro p hp
  have h : env14073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14072_14073 : H12AffineEnvironment.transform 9 272 env14072 = env14073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14072 == env14073) = true)

theorem identity14073 : scanCanonicalize (H12AffineFastState.compose env14073 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound14073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14074 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,1,8,0,293,430,1,260,273,292,0,1,17,398,128,16,0,0,0,261,21,137,257,428,0,137]

theorem envBound14074 : H12AffineFastState.Bounded env14074 := by
  intro p hp
  have h : env14074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14073_14074 : H12AffineEnvironment.transform 15 430 env14073 = env14074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env14073 == env14074) = true)

def env14075 : List Nat := [2,4,8,16,0,16,128,256,137,272,1,1,8,0,261,398,1,260,273,260,0,1,17,398,128,16,0,0,0,261,21,137,257,396,0,137]

theorem envBound14075 : H12AffineFastState.Bounded env14075 := by
  intro p hp
  have h : env14075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14074_14075 : H12AffineEnvironment.transform 4 0 env14074 = env14075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14074 == env14075) = true)

theorem identity14075 : scanCanonicalize (H12AffineFastState.compose env14075 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14076 : List Nat := [2,4,8,1,0,1,128,256,137,257,1,1,8,0,261,398,1,260,256,260,0,1,0,398,128,1,0,0,0,261,4,137,257,396,0,137]

theorem envBound14076 : H12AffineFastState.Bounded env14076 := by
  intro p hp
  have h : env14076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14075_14076 : H12AffineEnvironment.transform 3 1 env14075 = env14076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14075 == env14076) = true)

def env14077 : List Nat := [2,4,8,16,1,16,128,256,137,272,1,1,8,0,260,399,1,260,273,261,0,1,17,398,128,16,0,0,0,261,21,137,257,397,0,137]

theorem envBound14077 : H12AffineFastState.Bounded env14077 := by
  intro p hp
  have h : env14077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14074_14077 : H12AffineEnvironment.transform 4 1 env14074 = env14077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14074 == env14077) = true)

theorem identity14077 : scanCanonicalize (H12AffineFastState.compose env14077 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14077 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14078 : List Nat := [2,4,8,16,1,16,25,256,16,272,1,1,8,0,260,278,1,260,273,261,0,1,17,279,25,16,0,0,0,261,21,16,257,276,0,16]

theorem envBound14078 : H12AffineFastState.Bounded env14078 := by
  intro p hp
  have h : env14078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14077_14078 : H12AffineEnvironment.transform 6 25 env14077 = env14078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14077 == env14078) = true)

theorem identity14078 : scanCanonicalize (H12AffineFastState.compose env14078 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14079 : List Nat := [2,4,8,16,1,16,25,5,16,21,1,1,8,0,1,19,1,1,20,0,0,1,17,18,25,16,0,0,0,0,21,16,4,17,0,16]

theorem envBound14079 : H12AffineFastState.Bounded env14079 := by
  intro p hp
  have h : env14079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14078_14079 : H12AffineEnvironment.transform 7 5 env14078 = env14079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14078 == env14079) = true)

def leafEnv14079 : List Nat := [2,4,8,16,1,16,25,5,16,21,1,1,8,0,1,19,1,1,20,0,0,1,17,18,21,25,1,16,0,0,0,0,21,16,4,17,4,3,0,16,0,0,1]

def active14079 : List Nat := [0,1,2,3]

def tree14079 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14079 : H12WitnessSearch.Good tree14079 := H12GlobalWitnessIndex.good

theorem leafIdentity14079 : H12AffineFastState.composeSystem env14079 rootObs = leafEnv14079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14079 rootObs == leafEnv14079) = true)

theorem terminalChecked14079 : H12PackedTerminal.terminalCheckFast leafEnv14079 active14079 tree14079 = true := by decide +kernel

def env14080 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,0,8,1,293,65536,0,260,272,292,1,1,17,65568,128,16,0,1,1,261,20,137,257,65538,1,137]

theorem envBound14080 : H12AffineFastState.Bounded env14080 := by
  intro p hp
  have h : env14080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14072_14080 : H12AffineEnvironment.transform 9 273 env14072 = env14080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14072 == env14080) = true)

theorem identity14080 : scanCanonicalize (H12AffineFastState.compose env14080 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14080 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14081 : List Nat := [2,4,8,16,32,16,128,5,137,20,1,0,8,1,32,65536,0,1,21,33,1,1,17,65568,128,16,0,1,1,0,20,137,4,65538,1,137]

theorem envBound14081 : H12AffineFastState.Bounded env14081 := by
  intro p hp
  have h : env14081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14080_14081 : H12AffineEnvironment.transform 7 5 env14080 = env14081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14080 == env14081) = true)

theorem identity14081 : scanCanonicalize (H12AffineFastState.compose env14081 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14081 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14082 : List Nat := [2,4,8,16,32,16,128,5,137,20,1,0,8,1,32,171,0,1,21,33,1,1,17,139,128,16,0,1,1,0,20,137,4,169,1,137]

theorem envBound14082 : H12AffineFastState.Bounded env14082 := by
  intro p hp
  have h : env14082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14081_14082 : H12AffineEnvironment.transform 15 171 env14081 = env14082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14081 == env14082) = true)

theorem identity14082 : scanCanonicalize (H12AffineFastState.compose env14082 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14082 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14083 : List Nat := [2,4,8,16,0,16,128,5,137,20,1,0,8,1,0,139,0,1,21,1,1,1,17,139,128,16,0,1,1,0,20,137,4,137,1,137]

theorem envBound14083 : H12AffineFastState.Bounded env14083 := by
  intro p hp
  have h : env14083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14082_14083 : H12AffineEnvironment.transform 4 0 env14082 = env14083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14082 == env14083) = true)

theorem identity14083 : scanCanonicalize (H12AffineFastState.compose env14083 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14084 : List Nat := [2,4,8,0,0,0,128,5,137,4,1,0,8,1,0,139,0,1,5,1,1,1,1,139,128,0,0,1,1,0,4,137,4,137,1,137]

theorem envBound14084 : H12AffineFastState.Bounded env14084 := by
  intro p hp
  have h : env14084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14083_14084 : H12AffineEnvironment.transform 3 0 env14083 = env14084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14083 == env14084) = true)

def leafEnv14084 : List Nat := [2,4,8,0,0,0,128,5,137,4,1,0,8,1,0,139,0,1,5,1,1,1,1,139,4,128,1,0,0,1,1,0,4,137,4,137,4,2,1,137,0,1,1]

def active14084 : List Nat := [0,1,2,6]

def tree14084 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14084 : H12WitnessSearch.Good tree14084 := H12GlobalWitnessIndex.good

theorem leafIdentity14084 : H12AffineFastState.composeSystem env14084 rootObs = leafEnv14084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14084 rootObs == leafEnv14084) = true)

theorem terminalChecked14084 : H12PackedTerminal.terminalCheckFast leafEnv14084 active14084 tree14084 = true := by decide +kernel

def env14085 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,8,1297,293,65536,1296,260,1025,292,1296,1,16,65568,128,16,0,1297,1296,261,1285,4294967296,257,4295032971,1297,137]

theorem envBound14085 : H12AffineFastState.Bounded env14085 := by
  intro p hp
  have h : env14085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14070_14085 : H12AffineEnvironment.transform 5 17 env14070 = env14085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14070 == env14085) = true)

theorem identity14085 : scanCanonicalize (H12AffineFastState.compose env14085 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound14085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14086 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,8,1297,293,65536,1296,260,1025,292,1296,1,16,65568,128,16,0,1297,1296,261,1285,65570,257,169,1297,137]

theorem envBound14086 : H12AffineFastState.Bounded env14086 := by
  intro p hp
  have h : env14086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14085_14086 : H12AffineEnvironment.transform 31 65570 env14085 = env14086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env14085 == env14086) = true)

theorem identity14086 : scanCanonicalize (H12AffineFastState.compose env14086 (packedSelected [0,2] rootPS)) = affineNative (2^(15+1) ^^^ 1434) := by decide +kernel

theorem selectedBound14086 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14087 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,8,1297,293,1434,1296,260,1025,292,1296,1,16,1466,128,16,0,1297,1296,261,1285,1464,257,169,1297,137]

theorem envBound14087 : H12AffineFastState.Bounded env14087 := by
  intro p hp
  have h : env14087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14086_14087 : H12AffineEnvironment.transform 15 1434 env14086 = env14087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1434 env14086 == env14087) = true)

def env14088 : List Nat := [2,4,8,16,0,17,128,256,137,1024,1,1297,8,1297,261,1434,1296,260,1025,260,1296,1,16,1434,128,16,0,1297,1296,261,1285,1432,257,137,1297,137]

theorem envBound14088 : H12AffineFastState.Bounded env14088 := by
  intro p hp
  have h : env14088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14087_14088 : H12AffineEnvironment.transform 4 0 env14087 = env14088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14087 == env14088) = true)

theorem identity14088 : scanCanonicalize (H12AffineFastState.compose env14088 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14089 : List Nat := [2,4,8,16,0,17,128,5,137,1024,1,1044,8,1044,0,1183,1045,1,1025,1,1045,1,16,1183,128,16,0,1044,1045,0,1024,1181,4,137,1044,137]

theorem envBound14089 : H12AffineFastState.Bounded env14089 := by
  intro p hp
  have h : env14089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14088_14089 : H12AffineEnvironment.transform 7 5 env14088 = env14089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14088 == env14089) = true)

theorem identity14089 : scanCanonicalize (H12AffineFastState.compose env14089 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14089 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14090 : List Nat := [2,4,8,0,0,1,128,5,137,1024,1,1028,8,1028,0,1167,1029,1,1025,1,1029,1,0,1167,128,0,0,1028,1029,0,1024,1165,4,137,1028,137]

theorem envBound14090 : H12AffineFastState.Bounded env14090 := by
  intro p hp
  have h : env14090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14089_14090 : H12AffineEnvironment.transform 3 0 env14089 = env14090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14089 == env14090) = true)

theorem identity14090 : scanCanonicalize (H12AffineFastState.compose env14090 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound14090 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14091 : List Nat := [2,4,8,0,0,1,128,5,137,4,1,0,8,0,0,139,1,1,5,1,1,1,0,139,128,0,0,0,1,0,4,137,4,137,0,137]

theorem envBound14091 : H12AffineFastState.Bounded env14091 := by
  intro p hp
  have h : env14091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14090_14091 : H12AffineEnvironment.transform 9 4 env14090 = env14091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env14090 == env14091) = true)

def leafEnv14091 : List Nat := [2,4,8,0,0,1,128,5,137,4,1,0,8,0,0,139,1,1,5,1,1,1,0,139,4,128,1,0,0,0,1,0,4,137,4,137,4,2,0,137,0,1,1]

def active14091 : List Nat := [0,1,2,6]

def tree14091 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14091 : H12WitnessSearch.Good tree14091 := H12GlobalWitnessIndex.good

theorem leafIdentity14091 : H12AffineFastState.composeSystem env14091 rootObs = leafEnv14091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14091 rootObs == leafEnv14091) = true)

theorem terminalChecked14091 : H12PackedTerminal.terminalCheckFast leafEnv14091 active14091 tree14091 = true := by decide +kernel

def env14092 : List Nat := [2,4,8,16,1,17,128,256,137,1024,1,1297,8,1297,260,1434,1296,260,1025,261,1296,1,16,1435,128,16,0,1297,1296,261,1285,1433,257,136,1297,137]

theorem envBound14092 : H12AffineFastState.Bounded env14092 := by
  intro p hp
  have h : env14092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14087_14092 : H12AffineEnvironment.transform 4 1 env14087 = env14092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14087 == env14092) = true)

theorem identity14092 : scanCanonicalize (H12AffineFastState.compose env14092 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14092 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14093 : List Nat := [2,4,8,16,1,17,128,256,137,20,1,261,8,261,260,398,260,260,21,261,260,1,16,399,128,16,0,261,260,261,273,397,257,136,261,137]

theorem envBound14093 : H12AffineFastState.Bounded env14093 := by
  intro p hp
  have h : env14093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14092_14093 : H12AffineEnvironment.transform 9 20 env14092 = env14093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14092 == env14093) = true)

theorem identity14093 : scanCanonicalize (H12AffineFastState.compose env14093 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound14093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14094 : List Nat := [2,4,8,16,1,17,128,157,137,20,1,152,8,152,153,19,153,153,21,152,153,1,16,18,128,16,0,152,153,152,140,16,156,136,152,137]

theorem envBound14094 : H12AffineFastState.Bounded env14094 := by
  intro p hp
  have h : env14094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14093_14094 : H12AffineEnvironment.transform 7 157 env14093 = env14094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env14093 == env14094) = true)

theorem identity14094 : scanCanonicalize (H12AffineFastState.compose env14094 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14094 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14095 : List Nat := [2,4,8,16,1,17,25,4,16,20,1,1,8,1,0,19,0,0,21,1,0,1,16,18,25,16,0,1,0,1,21,16,5,17,1,16]

theorem envBound14095 : H12AffineFastState.Bounded env14095 := by
  intro p hp
  have h : env14095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14094_14095 : H12AffineEnvironment.transform 6 25 env14094 = env14095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14094 == env14095) = true)

def leafEnv14095 : List Nat := [2,4,8,16,1,17,25,4,16,20,1,1,8,1,0,19,0,0,21,1,0,1,16,18,21,25,1,16,0,1,0,1,21,16,5,17,4,3,1,16,0,0,1]

def active14095 : List Nat := [0,1,2,3]

def tree14095 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14095 : H12WitnessSearch.Good tree14095 := H12GlobalWitnessIndex.good

theorem leafIdentity14095 : H12AffineFastState.composeSystem env14095 rootObs = leafEnv14095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14095 rootObs == leafEnv14095) = true)

theorem terminalChecked14095 : H12PackedTerminal.terminalCheckFast leafEnv14095 active14095 tree14095 = true := by decide +kernel

def env14096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1344,529408,1073741824,1284,4294967296,256,4295074214,1345,512]

theorem envBound14096 : H12AffineFastState.Bounded env14096 := by
  intro p hp
  have h : env14096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14062_14096 : H12AffineEnvironment.transform 13 1345 env14062 = env14096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14062 == env14096) = true)

theorem identity14096 : scanCanonicalize (H12AffineFastState.compose env14096 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8460) := by decide +kernel

theorem selectedBound14096 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1344,529408,8460,1284,4294967296,256,4295074214,1345,512]

theorem envBound14097 : H12AffineFastState.Bounded env14097 := by
  intro p hp
  have h : env14097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14096_14097 : H12AffineEnvironment.transform 29 8460 env14096 = env14097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8460 env14096 == env14097) = true)

theorem identity14097 : scanCanonicalize (H12AffineFastState.compose env14097 (packedSelected [3,10,17,19,21,24] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound14097 : packedSelected [3,10,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env14098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,262144,1024,32769,4097,8201,64,98565,8328,16,270605,1344,4096,8460,1284,4294967296,256,4295074214,1345,512]

theorem envBound14098 : H12AffineFastState.Bounded env14098 := by
  intro p hp
  have h : env14098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14097_14098 : H12AffineEnvironment.transform 18 1024 env14097 = env14098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14097 == env14098) = true)

theorem identity14098 : scanCanonicalize (H12AffineFastState.compose env14098 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 41000) := by decide +kernel

theorem selectedBound14098 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,41000,1024,32769,4097,8201,64,98565,8328,16,33061,1344,4096,8460,1284,4294967296,256,4295074214,1345,512]

theorem envBound14099 : H12AffineFastState.Bounded env14099 := by
  intro p hp
  have h : env14099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14098_14099 : H12AffineEnvironment.transform 17 41000 env14098 = env14099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env14098 == env14099) = true)

theorem identity14099 : scanCanonicalize (H12AffineFastState.compose env14099 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound14099 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,293,65536,1344,8461,1024,292,4097,8201,64,65568,8328,16,0,1344,4096,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14100 : H12AffineFastState.Bounded env14100 := by
  intro p hp
  have h : env14100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14099_14100 : H12AffineEnvironment.transform 14 293 env14099 = env14100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env14099 == env14100) = true)

def env14101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1345,293,65536,1344,8461,1024,292,1345,8201,64,65568,8328,16,0,1344,1344,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14101 : H12AffineFastState.Bounded env14101 := by
  intro p hp
  have h : env14101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14100_14101 : H12AffineEnvironment.transform 11 1344 env14100 = env14101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14100 == env14101) = true)

theorem identity14101 : scanCanonicalize (H12AffineFastState.compose env14101 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14101 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14102 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1297,293,65536,1296,8461,1024,292,1297,8201,16,65568,8328,16,0,1296,1296,8460,1284,4294967296,256,4295041155,1297,512]

theorem envBound14102 : H12AffineFastState.Bounded env14102 := by
  intro p hp
  have h : env14102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14101_14102 : H12AffineEnvironment.transform 5 16 env14101 = env14102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14101 == env14102) = true)

theorem identity14102 : scanCanonicalize (H12AffineFastState.compose env14102 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14102 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14103 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,269,1297,293,65536,1296,0,1024,292,1297,260,16,65568,389,16,0,1296,1296,1,1284,4294967296,256,4295033230,1297,512]

theorem envBound14103 : H12AffineFastState.Bounded env14103 := by
  intro p hp
  have h : env14103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14102_14103 : H12AffineEnvironment.transform 12 269 env14102 = env14103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14102 == env14103) = true)

def env14104 : List Nat := [2,4,8,16,32,16,128,256,512,272,1,0,269,1,293,65536,0,0,272,292,1,260,16,65568,389,16,0,0,0,1,20,4294967296,256,4295033230,1,512]

theorem envBound14104 : H12AffineFastState.Bounded env14104 := by
  intro p hp
  have h : env14104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14103_14104 : H12AffineEnvironment.transform 9 272 env14103 = env14104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14103 == env14104) = true)

def env14105 : List Nat := [2,4,8,16,32,16,128,36,512,52,1,0,41,1,1,65536,0,0,52,0,1,32,16,65568,161,16,0,0,0,1,20,4294967296,36,4295033002,1,512]

theorem envBound14105 : H12AffineFastState.Bounded env14105 := by
  intro p hp
  have h : env14105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14104_14105 : H12AffineEnvironment.transform 7 36 env14104 = env14105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14104 == env14105) = true)

def env14106 : List Nat := [2,4,8,16,32,16,128,36,0,52,1,0,41,1,1,65536,0,0,52,0,1,32,16,65568,161,16,0,0,0,1,20,4294967296,36,4295033002,1,0]

theorem envBound14106 : H12AffineFastState.Bounded env14106 := by
  intro p hp
  have h : env14106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14105_14106 : H12AffineEnvironment.transform 8 0 env14105 = env14106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14105 == env14106) = true)

theorem identity14106 : scanCanonicalize (H12AffineFastState.compose env14106 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound14106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14107 : List Nat := [2,4,8,16,32,16,128,36,0,52,1,0,41,1,1,65536,0,0,52,0,1,32,16,65568,161,16,0,0,0,1,20,65570,36,136,1,0]

theorem envBound14107 : H12AffineFastState.Bounded env14107 := by
  intro p hp
  have h : env14107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14106_14107 : H12AffineEnvironment.transform 31 65570 env14106 = env14107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env14106 == env14107) = true)

theorem identity14107 : scanCanonicalize (H12AffineFastState.compose env14107 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14108 : List Nat := [2,4,8,16,0,16,128,4,0,20,1,0,9,1,1,65536,0,0,20,0,1,0,16,65536,129,16,0,0,0,1,20,65538,4,136,1,0]

theorem envBound14108 : H12AffineFastState.Bounded env14108 := by
  intro p hp
  have h : env14108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14107_14108 : H12AffineEnvironment.transform 4 0 env14107 = env14108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14107 == env14108) = true)

theorem identity14108 : scanCanonicalize (H12AffineFastState.compose env14108 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14108 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14109 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,1,1,65536,0,0,20,0,1,0,16,65536,9,16,0,0,0,1,20,65538,4,0,1,0]

theorem envBound14109 : H12AffineFastState.Bounded env14109 := by
  intro p hp
  have h : env14109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14108_14109 : H12AffineEnvironment.transform 6 8 env14108 = env14109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14108 == env14109) = true)

def leafEnv14109 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,1,1,65536,0,0,20,0,1,0,16,65536,20,9,1,16,0,0,0,1,20,65538,4,0,4,2,1,0,0,1,1]

def active14109 : List Nat := [0,1,2,3,15]

def tree14109 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14109 : H12WitnessSearch.Good tree14109 := H12GlobalWitnessIndex.good

theorem leafIdentity14109 : H12AffineFastState.composeSystem env14109 rootObs = leafEnv14109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14109 rootObs == leafEnv14109) = true)

theorem terminalChecked14109 : H12PackedTerminal.terminalCheckFast leafEnv14109 active14109 tree14109 = true := by decide +kernel

def env14110 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,41,1,1,65536,0,0,52,0,1,32,16,65568,161,16,0,0,0,1,20,4294967296,36,4295033002,1,1]

theorem envBound14110 : H12AffineFastState.Bounded env14110 := by
  intro p hp
  have h : env14110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14105_14110 : H12AffineEnvironment.transform 8 1 env14105 = env14110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14105 == env14110) = true)

theorem identity14110 : scanCanonicalize (H12AffineFastState.compose env14110 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound14110 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14111 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,41,1,1,65536,0,0,52,0,1,32,16,65568,161,16,0,0,0,1,20,65706,36,0,1,1]

theorem envBound14111 : H12AffineFastState.Bounded env14111 := by
  intro p hp
  have h : env14111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14110_14111 : H12AffineEnvironment.transform 31 65706 env14110 = env14111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env14110 == env14111) = true)

theorem identity14111 : scanCanonicalize (H12AffineFastState.compose env14111 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound14111 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14112 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,41,1,1,138,0,0,52,0,1,32,16,170,161,16,0,0,0,1,20,32,36,0,1,1]

theorem envBound14112 : H12AffineFastState.Bounded env14112 := by
  intro p hp
  have h : env14112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14111_14112 : H12AffineEnvironment.transform 15 138 env14111 = env14112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env14111 == env14112) = true)

def env14113 : List Nat := [2,4,8,16,0,16,128,4,1,20,1,0,9,1,1,138,0,0,20,0,1,0,16,138,129,16,0,0,0,1,20,0,4,0,1,1]

theorem envBound14113 : H12AffineFastState.Bounded env14113 := by
  intro p hp
  have h : env14113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14112_14113 : H12AffineEnvironment.transform 4 0 env14112 = env14113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14112 == env14113) = true)

theorem identity14113 : scanCanonicalize (H12AffineFastState.compose env14113 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14114 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,9,1,1,3,0,0,20,0,1,0,16,3,8,16,0,0,0,1,20,0,4,0,1,1]

theorem envBound14114 : H12AffineFastState.Bounded env14114 := by
  intro p hp
  have h : env14114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14113_14114 : H12AffineEnvironment.transform 6 9 env14113 = env14114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14113 == env14114) = true)

def leafEnv14114 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,9,1,1,3,0,0,20,0,1,0,16,3,20,8,1,16,0,0,0,1,20,0,4,0,4,2,1,1,0,1,1]

def active14114 : List Nat := [0,1,2,3]

def tree14114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14114 : H12WitnessSearch.Good tree14114 := H12GlobalWitnessIndex.good

theorem leafIdentity14114 : H12AffineFastState.composeSystem env14114 rootObs = leafEnv14114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14114 rootObs == leafEnv14114) = true)

theorem terminalChecked14114 : H12PackedTerminal.terminalCheckFast leafEnv14114 active14114 tree14114 = true := by decide +kernel

def env14115 : List Nat := [2,4,8,16,1,16,128,5,1,21,1,0,8,1,1,138,0,0,21,0,1,1,16,139,128,16,0,0,0,1,20,1,5,0,1,1]

theorem envBound14115 : H12AffineFastState.Bounded env14115 := by
  intro p hp
  have h : env14115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14112_14115 : H12AffineEnvironment.transform 4 1 env14112 = env14115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14112 == env14115) = true)

def leafEnv14115 : List Nat := [2,4,8,16,1,16,128,5,1,21,1,0,8,1,1,138,0,0,21,0,1,1,16,139,20,128,1,16,0,0,0,1,20,1,5,0,4,3,1,1,0,1,1]

def active14115 : List Nat := [0,1,2,3,6]

def tree14115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14115 : H12WitnessSearch.Good tree14115 := H12GlobalWitnessIndex.good

theorem leafIdentity14115 : H12AffineFastState.composeSystem env14115 rootObs = leafEnv14115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14115 rootObs == leafEnv14115) = true)

theorem terminalChecked14115 : H12PackedTerminal.terminalCheckFast leafEnv14115 active14115 tree14115 = true := by decide +kernel

def env14116 : List Nat := [2,4,8,16,32,16,128,37,512,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,160,16,0,0,0,1,20,4294967296,37,4295033003,1,512]

theorem envBound14116 : H12AffineFastState.Bounded env14116 := by
  intro p hp
  have h : env14116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14104_14116 : H12AffineEnvironment.transform 7 37 env14104 = env14116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14104 == env14116) = true)

def env14117 : List Nat := [2,4,8,16,32,16,128,37,0,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,160,16,0,0,0,1,20,4294967296,37,4295033003,1,0]

theorem envBound14117 : H12AffineFastState.Bounded env14117 := by
  intro p hp
  have h : env14117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14116_14117 : H12AffineEnvironment.transform 8 0 env14116 = env14117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14116 == env14117) = true)

theorem identity14117 : scanCanonicalize (H12AffineFastState.compose env14117 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound14117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14118 : List Nat := [2,4,8,16,32,16,128,37,0,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,160,16,0,0,0,1,20,0,37,65707,1,0]

theorem envBound14118 : H12AffineFastState.Bounded env14118 := by
  intro p hp
  have h : env14118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14117_14118 : H12AffineEnvironment.transform 31 0 env14117 = env14118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env14117 == env14118) = true)

def env14119 : List Nat := [2,4,8,16,32,16,8,37,0,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,40,16,0,0,0,1,20,0,37,65571,1,0]

theorem envBound14119 : H12AffineFastState.Bounded env14119 := by
  intro p hp
  have h : env14119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14118_14119 : H12AffineEnvironment.transform 6 8 env14118 = env14119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14118 == env14119) = true)

def env14120 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,1,0,65536,0,0,21,1,1,1,16,65536,8,16,0,0,0,1,20,0,5,65539,1,0]

theorem envBound14120 : H12AffineFastState.Bounded env14120 := by
  intro p hp
  have h : env14120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14119_14120 : H12AffineEnvironment.transform 4 0 env14119 = env14120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14119 == env14120) = true)

theorem identity14120 : scanCanonicalize (H12AffineFastState.compose env14120 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14120 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14121 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,1,0,3,0,0,21,1,1,1,16,3,8,16,0,0,0,1,20,0,5,0,1,0]

theorem envBound14121 : H12AffineFastState.Bounded env14121 := by
  intro p hp
  have h : env14121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14120_14121 : H12AffineEnvironment.transform 15 3 env14120 = env14121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14120 == env14121) = true)

def leafEnv14121 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,1,0,3,0,0,21,1,1,1,16,3,20,8,1,16,0,0,0,1,20,0,5,0,4,2,1,0,0,1,1]

def active14121 : List Nat := [0,1,2,3]

def tree14121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14121 : H12WitnessSearch.Good tree14121 := H12GlobalWitnessIndex.good

theorem leafIdentity14121 : H12AffineFastState.composeSystem env14121 rootObs = leafEnv14121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14121 rootObs == leafEnv14121) = true)

theorem terminalChecked14121 : H12PackedTerminal.terminalCheckFast leafEnv14121 active14121 tree14121 = true := by decide +kernel

def env14122 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,1,0,65536,0,0,20,1,1,0,16,65537,9,16,0,0,0,1,20,0,4,65538,1,0]

theorem envBound14122 : H12AffineFastState.Bounded env14122 := by
  intro p hp
  have h : env14122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14119_14122 : H12AffineEnvironment.transform 4 1 env14119 = env14122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14119 == env14122) = true)

def leafEnv14122 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,1,0,65536,0,0,20,1,1,0,16,65537,20,9,1,16,0,0,0,1,20,0,4,65538,4,3,1,0,0,1,1]

def active14122 : List Nat := [0,1,2,3,15]

def tree14122 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14122 : H12WitnessSearch.Good tree14122 := H12GlobalWitnessIndex.good

theorem leafIdentity14122 : H12AffineFastState.composeSystem env14122 rootObs = leafEnv14122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14122 rootObs == leafEnv14122) = true)

theorem terminalChecked14122 : H12PackedTerminal.terminalCheckFast leafEnv14122 active14122 tree14122 = true := by decide +kernel

def env14123 : List Nat := [2,4,8,16,32,16,9,37,0,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,41,16,0,0,0,1,20,0,37,65570,1,0]

theorem envBound14123 : H12AffineFastState.Bounded env14123 := by
  intro p hp
  have h : env14123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14118_14123 : H12AffineEnvironment.transform 6 9 env14118 = env14123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14118 == env14123) = true)

theorem identity14123 : scanCanonicalize (H12AffineFastState.compose env14123 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound14123 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14124 : List Nat := [2,4,8,16,32,16,9,37,0,53,1,0,40,1,0,34,0,0,53,1,1,33,16,2,41,16,0,0,0,1,20,0,37,0,1,0]

theorem envBound14124 : H12AffineFastState.Bounded env14124 := by
  intro p hp
  have h : env14124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14123_14124 : H12AffineEnvironment.transform 15 34 env14123 = env14124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env14123 == env14124) = true)

def env14125 : List Nat := [2,4,8,16,32,16,128,37,1,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,160,16,0,0,0,1,20,4294967296,37,4295033003,1,1]

theorem envBound14125 : H12AffineFastState.Bounded env14125 := by
  intro p hp
  have h : env14125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14116_14125 : H12AffineEnvironment.transform 8 1 env14116 = env14125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14116 == env14125) = true)

theorem identity14125 : scanCanonicalize (H12AffineFastState.compose env14125 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound14125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14126 : List Nat := [2,4,8,16,32,16,128,37,1,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,160,16,0,0,0,1,20,136,37,65571,1,1]

theorem envBound14126 : H12AffineFastState.Bounded env14126 := by
  intro p hp
  have h : env14126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14125_14126 : H12AffineEnvironment.transform 31 136 env14125 = env14126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env14125 == env14126) = true)

theorem identity14126 : scanCanonicalize (H12AffineFastState.compose env14126 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14127 : List Nat := [2,4,8,16,32,16,9,37,1,53,1,0,40,1,0,65536,0,0,53,1,1,33,16,65568,41,16,0,0,0,1,20,1,37,65571,1,1]

theorem envBound14127 : H12AffineFastState.Bounded env14127 := by
  intro p hp
  have h : env14127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14126_14127 : H12AffineEnvironment.transform 6 9 env14126 = env14127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14126 == env14127) = true)

def env14128 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,0,65536,0,0,21,1,1,1,16,65536,9,16,0,0,0,1,20,1,5,65539,1,1]

theorem envBound14128 : H12AffineFastState.Bounded env14128 := by
  intro p hp
  have h : env14128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14127_14128 : H12AffineEnvironment.transform 4 0 env14127 = env14128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14127 == env14128) = true)

theorem identity14128 : scanCanonicalize (H12AffineFastState.compose env14128 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14128 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14129 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,0,2,0,0,21,1,1,1,16,2,9,16,0,0,0,1,20,1,5,1,1,1]

theorem envBound14129 : H12AffineFastState.Bounded env14129 := by
  intro p hp
  have h : env14129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14128_14129 : H12AffineEnvironment.transform 15 2 env14128 = env14129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14128 == env14129) = true)

def leafEnv14129 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,0,2,0,0,21,1,1,1,16,2,20,9,1,16,0,0,0,1,20,1,5,1,4,2,1,1,0,1,1]

def active14129 : List Nat := [0,1,2,3]

def tree14129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14129 : H12WitnessSearch.Good tree14129 := H12GlobalWitnessIndex.good

theorem leafIdentity14129 : H12AffineFastState.composeSystem env14129 rootObs = leafEnv14129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14129 rootObs == leafEnv14129) = true)

theorem terminalChecked14129 : H12PackedTerminal.terminalCheckFast leafEnv14129 active14129 tree14129 = true := by decide +kernel

def env14130 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,0,9,1,0,65536,0,0,20,1,1,0,16,65537,8,16,0,0,0,1,20,1,4,65538,1,1]

theorem envBound14130 : H12AffineFastState.Bounded env14130 := by
  intro p hp
  have h : env14130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14127_14130 : H12AffineEnvironment.transform 4 1 env14127 = env14130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14127 == env14130) = true)

def leafEnv14130 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,0,9,1,0,65536,0,0,20,1,1,0,16,65537,20,8,1,16,0,0,0,1,20,1,4,65538,4,3,1,1,0,1,1]

def active14130 : List Nat := [0,1,2,3,15]

def tree14130 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14130 : H12WitnessSearch.Good tree14130 := H12GlobalWitnessIndex.good

theorem leafIdentity14130 : H12AffineFastState.composeSystem env14130 rootObs = leafEnv14130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14130 rootObs == leafEnv14130) = true)

theorem terminalChecked14130 : H12PackedTerminal.terminalCheckFast leafEnv14130 active14130 tree14130 = true := by decide +kernel

def env14131 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,1,269,0,293,65536,1,0,273,292,0,260,16,65568,389,16,0,1,1,1,21,4294967296,256,4295033230,0,512]

theorem envBound14131 : H12AffineFastState.Bounded env14131 := by
  intro p hp
  have h : env14131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14103_14131 : H12AffineEnvironment.transform 9 273 env14103 = env14131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14103 == env14131) = true)

theorem identity14131 : scanCanonicalize (H12AffineFastState.compose env14131 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14132 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,1,269,0,293,171,1,0,273,292,0,260,16,139,389,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14132 : H12AffineFastState.Bounded env14132 := by
  intro p hp
  have h : env14132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14131_14132 : H12AffineEnvironment.transform 15 171 env14131 = env14132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14131 == env14132) = true)

def env14133 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,1,269,0,293,35,1,0,273,292,0,260,16,3,269,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14133 : H12AffineFastState.Bounded env14133 := by
  intro p hp
  have h : env14133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14132_14133 : H12AffineEnvironment.transform 6 8 env14132 = env14133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14132 == env14133) = true)

theorem identity14133 : scanCanonicalize (H12AffineFastState.compose env14133 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound14133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14134 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,1,269,0,293,35,1,0,273,292,0,260,16,3,269,16,0,1,1,1,21,293,256,0,0,512]

theorem envBound14134 : H12AffineFastState.Bounded env14134 := by
  intro p hp
  have h : env14134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14133_14134 : H12AffineEnvironment.transform 31 293 env14133 = env14134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env14133 == env14134) = true)

def env14135 : List Nat := [2,4,8,16,0,16,8,256,512,273,1,1,269,0,261,3,1,0,273,260,0,260,16,3,269,16,0,1,1,1,21,261,256,0,0,512]

theorem envBound14135 : H12AffineFastState.Bounded env14135 := by
  intro p hp
  have h : env14135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14134_14135 : H12AffineEnvironment.transform 4 0 env14134 = env14135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14134 == env14135) = true)

theorem identity14135 : scanCanonicalize (H12AffineFastState.compose env14135 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14136 : List Nat := [2,4,8,16,0,16,8,256,0,273,1,1,269,0,261,3,1,0,273,260,0,260,16,3,269,16,0,1,1,1,21,261,256,0,0,0]

theorem envBound14136 : H12AffineFastState.Bounded env14136 := by
  intro p hp
  have h : env14136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14135_14136 : H12AffineEnvironment.transform 8 0 env14135 = env14136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14135 == env14136) = true)

def leafEnv14136 : List Nat := [2,4,8,16,0,16,8,256,0,273,1,1,269,0,261,3,1,0,273,260,0,260,16,3,21,269,1,16,0,1,1,1,21,261,256,0,4,2,0,0,0,0,1]

def active14136 : List Nat := [0,1,2,3,7]

def tree14136 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14136 : H12WitnessSearch.Good tree14136 := H12GlobalWitnessIndex.good

theorem leafIdentity14136 : H12AffineFastState.composeSystem env14136 rootObs = leafEnv14136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14136 rootObs == leafEnv14136) = true)

theorem terminalChecked14136 : H12PackedTerminal.terminalCheckFast leafEnv14136 active14136 tree14136 = true := by decide +kernel

def env14137 : List Nat := [2,4,8,16,1,16,8,256,512,273,1,1,269,0,260,2,1,0,273,261,0,260,16,3,269,16,0,1,1,1,21,260,256,0,0,512]

theorem envBound14137 : H12AffineFastState.Bounded env14137 := by
  intro p hp
  have h : env14137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14134_14137 : H12AffineEnvironment.transform 4 1 env14134 = env14137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14134 == env14137) = true)

theorem identity14137 : scanCanonicalize (H12AffineFastState.compose env14137 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound14137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14138 : List Nat := [2,4,8,16,1,16,8,256,260,273,1,1,269,0,260,2,1,0,273,261,0,260,16,3,269,16,0,1,1,1,21,260,256,0,0,260]

theorem envBound14138 : H12AffineFastState.Bounded env14138 := by
  intro p hp
  have h : env14138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14137_14138 : H12AffineEnvironment.transform 8 260 env14137 = env14138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env14137 == env14138) = true)

def leafEnv14138 : List Nat := [2,4,8,16,1,16,8,256,260,273,1,1,269,0,260,2,1,0,273,261,0,260,16,3,21,269,1,16,0,1,1,1,21,260,256,0,4,3,0,260,0,0,1]

def active14138 : List Nat := [0,1,2,3,7]

def tree14138 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14138 : H12WitnessSearch.Good tree14138 := H12GlobalWitnessIndex.good

theorem leafIdentity14138 : H12AffineFastState.composeSystem env14138 rootObs = leafEnv14138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14138 rootObs == leafEnv14138) = true)

theorem terminalChecked14138 : H12PackedTerminal.terminalCheckFast leafEnv14138 active14138 tree14138 = true := by decide +kernel

def env14139 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,1,269,0,293,34,1,0,273,292,0,260,16,2,268,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14139 : H12AffineFastState.Bounded env14139 := by
  intro p hp
  have h : env14139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14132_14139 : H12AffineEnvironment.transform 6 9 env14132 = env14139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14132 == env14139) = true)

theorem identity14139 : scanCanonicalize (H12AffineFastState.compose env14139 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound14139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14140 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,1,269,0,293,34,1,0,273,292,0,260,16,2,268,16,0,1,1,1,21,512,256,805,0,512]

theorem envBound14140 : H12AffineFastState.Bounded env14140 := by
  intro p hp
  have h : env14140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14139_14140 : H12AffineEnvironment.transform 31 512 env14139 = env14140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env14139 == env14140) = true)

theorem identity14140 : scanCanonicalize (H12AffineFastState.compose env14140 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14140 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14141 : List Nat := [2,4,8,16,32,16,9,256,1,273,1,1,269,0,293,34,1,0,273,292,0,260,16,2,268,16,0,1,1,1,21,1,256,292,0,1]

theorem envBound14141 : H12AffineFastState.Bounded env14141 := by
  intro p hp
  have h : env14141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14140_14141 : H12AffineEnvironment.transform 8 1 env14140 = env14141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14140 == env14141) = true)

def env14142 : List Nat := [2,4,8,16,0,16,9,256,1,273,1,1,269,0,261,2,1,0,273,260,0,260,16,2,268,16,0,1,1,1,21,1,256,260,0,1]

theorem envBound14142 : H12AffineFastState.Bounded env14142 := by
  intro p hp
  have h : env14142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14141_14142 : H12AffineEnvironment.transform 4 0 env14141 = env14142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14141 == env14142) = true)

theorem identity14142 : scanCanonicalize (H12AffineFastState.compose env14142 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14142 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14143 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,8,0,0,2,1,0,20,1,0,1,16,2,9,16,0,1,1,1,21,1,5,1,0,1]

theorem envBound14143 : H12AffineFastState.Bounded env14143 := by
  intro p hp
  have h : env14143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14142_14143 : H12AffineEnvironment.transform 7 5 env14142 = env14143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14142 == env14143) = true)

def leafEnv14143 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,8,0,0,2,1,0,20,1,0,1,16,2,21,9,1,16,0,1,1,1,21,1,5,1,4,2,0,1,0,0,1]

def active14143 : List Nat := [0,1,2,3]

def tree14143 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14143 : H12WitnessSearch.Good tree14143 := H12GlobalWitnessIndex.good

theorem leafIdentity14143 : H12AffineFastState.composeSystem env14143 rootObs = leafEnv14143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14143 rootObs == leafEnv14143) = true)

theorem terminalChecked14143 : H12PackedTerminal.terminalCheckFast leafEnv14143 active14143 tree14143 = true := by decide +kernel

def env14144 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,269,0,260,3,1,0,273,261,0,260,16,2,268,16,0,1,1,1,21,1,256,261,0,1]

theorem envBound14144 : H12AffineFastState.Bounded env14144 := by
  intro p hp
  have h : env14144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14141_14144 : H12AffineEnvironment.transform 4 1 env14141 = env14144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14141 == env14144) = true)

def leafEnv14144 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,269,0,260,3,1,0,273,261,0,260,16,2,21,268,1,16,0,1,1,1,21,1,256,261,4,3,0,1,0,0,1]

def active14144 : List Nat := [0,1,2,3,7]

def tree14144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14144 : H12WitnessSearch.Good tree14144 := H12GlobalWitnessIndex.good

theorem leafIdentity14144 : H12AffineFastState.composeSystem env14144 rootObs = leafEnv14144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14144 rootObs == leafEnv14144) = true)

theorem terminalChecked14144 : H12PackedTerminal.terminalCheckFast leafEnv14144 active14144 tree14144 = true := by decide +kernel

def env14145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,8192,1345,293,65536,1344,8461,1024,292,1344,8201,64,65568,8328,16,0,1344,1345,8460,1284,4294967296,256,4295041155,1345,512]

theorem envBound14145 : H12AffineFastState.Bounded env14145 := by
  intro p hp
  have h : env14145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14100_14145 : H12AffineEnvironment.transform 11 1345 env14100 = env14145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14100 == env14145) = true)

theorem identity14145 : scanCanonicalize (H12AffineFastState.compose env14145 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound14145 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,8192,1345,293,250,1344,8461,1024,292,1344,8201,64,218,8328,16,0,1344,1345,8460,1284,4294967296,256,4294975609,1345,512]

theorem envBound14146 : H12AffineFastState.Bounded env14146 := by
  intro p hp
  have h : env14146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14145_14146 : H12AffineEnvironment.transform 15 250 env14145 = env14146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env14145 == env14146) = true)

theorem identity14146 : scanCanonicalize (H12AffineFastState.compose env14146 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14146 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14147 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,8192,1296,293,171,1297,8461,1024,292,1297,8201,17,139,8328,16,0,1297,1296,8460,1284,4294967296,256,4294975528,1296,512]

theorem envBound14147 : H12AffineFastState.Bounded env14147 := by
  intro p hp
  have h : env14147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14146_14147 : H12AffineEnvironment.transform 5 17 env14146 = env14147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14146 == env14147) = true)

theorem identity14147 : scanCanonicalize (H12AffineFastState.compose env14147 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound14147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14148 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,8192,1296,293,171,1297,8461,1024,292,1297,8201,17,139,8328,16,0,1297,1296,8460,1284,4294967296,256,4294975528,1296,429]

theorem envBound14148 : H12AffineFastState.Bounded env14148 := by
  intro p hp
  have h : env14148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14147_14148 : H12AffineEnvironment.transform 8 429 env14147 = env14148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env14147 == env14148) = true)

theorem identity14148 : scanCanonicalize (H12AffineFastState.compose env14148 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14148 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14149 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,40,1296,293,171,1297,293,1024,292,1297,33,17,139,160,16,0,1297,1296,292,1284,4294967296,256,4294967296,1296,429]

theorem envBound14149 : H12AffineFastState.Bounded env14149 := by
  intro p hp
  have h : env14149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14148_14149 : H12AffineEnvironment.transform 12 40 env14148 = env14149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14148 == env14149) = true)

theorem identity14149 : scanCanonicalize (H12AffineFastState.compose env14149 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14150 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,40,1296,293,171,1297,293,1024,292,1297,33,17,139,160,16,0,1297,1296,292,1284,137,256,137,1296,429]

theorem envBound14150 : H12AffineFastState.Bounded env14150 := by
  intro p hp
  have h : env14150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14149_14150 : H12AffineEnvironment.transform 31 137 env14149 = env14150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14149 == env14150) = true)

theorem identity14150 : scanCanonicalize (H12AffineFastState.compose env14150 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14150 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14151 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,40,1077,0,171,1076,0,1024,1,1076,33,17,139,160,16,0,1076,1077,1,1057,137,37,137,1077,136]

theorem envBound14151 : H12AffineFastState.Bounded env14151 := by
  intro p hp
  have h : env14151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14150_14151 : H12AffineEnvironment.transform 7 37 env14150 = env14151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14150 == env14151) = true)

def leafEnv14151 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,40,1077,0,171,1076,0,1024,1,1076,33,17,139,1057,160,1,16,0,1076,1077,1,1057,137,37,137,4,34,1077,136,0,1076,1]

def active14151 : List Nat := [0,1,2,3,4,6,9]

def tree14151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14151 : H12WitnessSearch.Good tree14151 := H12GlobalWitnessIndex.good

theorem leafIdentity14151 : H12AffineFastState.composeSystem env14151 rootObs = leafEnv14151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14151 rootObs == leafEnv14151) = true)

theorem terminalChecked14151 : H12PackedTerminal.terminalCheckFast leafEnv14151 active14151 tree14151 = true := by decide +kernel

def env14152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,10249,17665,98565,8328,541009,797965,1344,529408,1073741824,16453,4294967296,17473,4295076262,16384,512]

theorem envBound14152 : H12AffineFastState.Bounded env14152 := by
  intro p hp
  have h : env14152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13961_14152 : H12AffineEnvironment.transform 21 10249 env13961 = env14152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env13961 == env14152) = true)

def env14153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,8201,17665,98565,8328,541009,795917,1344,529408,1073741824,16453,4294967296,17473,4295074214,16384,512]

theorem envBound14153 : H12AffineFastState.Bounded env14153 := by
  intro p hp
  have h : env14153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14152_14153 : H12AffineEnvironment.transform 10 0 env14152 = env14153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14152 == env14153) = true)

def env14154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1344,529408,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound14154 : H12AffineFastState.Bounded env14154 := by
  intro p hp
  have h : env14154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14153_14154 : H12AffineEnvironment.transform 13 1344 env14153 = env14154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14153 == env14154) = true)

theorem identity14154 : scanCanonicalize (H12AffineFastState.compose env14154 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 569657) := by decide +kernel

theorem selectedBound14154 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1344,529408,569657,1285,4294967296,257,4295074214,1344,512]

theorem envBound14155 : H12AffineFastState.Bounded env14155 := by
  intro p hp
  have h : env14155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14154_14155 : H12AffineEnvironment.transform 29 569657 env14154 = env14155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 569657 env14154 == env14155) = true)

theorem identity14155 : scanCanonicalize (H12AffineFastState.compose env14155 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14155 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,8201,65,98565,8328,16,270604,1344,4097,46392,1285,4294967296,257,4295074214,1344,512]

theorem envBound14156 : H12AffineFastState.Bounded env14156 := by
  intro p hp
  have h : env14156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14155_14156 : H12AffineEnvironment.transform 18 1025 env14155 = env14156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14155 == env14156) = true)

theorem identity14156 : scanCanonicalize (H12AffineFastState.compose env14156 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound14156 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env14157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1344,32768,65536,1345,262144,1025,32769,1296,8201,65,98565,8328,16,270604,1344,1296,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound14157 : H12AffineFastState.Bounded env14157 := by
  intro p hp
  have h : env14157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14156_14157 : H12AffineEnvironment.transform 11 1297 env14156 = env14157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env14156 == env14157) = true)

theorem identity14157 : scanCanonicalize (H12AffineFastState.compose env14157 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14157 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14158 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8192,1344,32768,65536,1345,262144,1025,32769,1296,8201,65,98565,8328,16,270604,1344,1296,41001,1285,4294967296,257,4295074214,1344,137]

theorem envBound14158 : H12AffineFastState.Bounded env14158 := by
  intro p hp
  have h : env14158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14157_14158 : H12AffineEnvironment.transform 8 137 env14157 = env14158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14157 == env14158) = true)

theorem identity14158 : scanCanonicalize (H12AffineFastState.compose env14158 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14158 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14159 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8,1344,32768,65536,1345,262144,1025,32769,1296,1,65,98565,128,16,262404,1344,1296,32801,1285,4294967296,257,4295066030,1344,137]

theorem envBound14159 : H12AffineFastState.Bounded env14159 := by
  intro p hp
  have h : env14159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14158_14159 : H12AffineEnvironment.transform 12 8 env14158 = env14159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14158 == env14159) = true)

theorem identity14159 : scanCanonicalize (H12AffineFastState.compose env14159 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 32800) := by decide +kernel

theorem selectedBound14159 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14160 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8,1344,32768,65536,1345,32800,1025,32769,1296,1,65,98565,128,16,33060,1344,1296,32801,1285,4294967296,257,4295066030,1344,137]

theorem envBound14160 : H12AffineFastState.Bounded env14160 := by
  intro p hp
  have h : env14160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14159_14160 : H12AffineEnvironment.transform 17 32800 env14159 = env14160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32800 env14159 == env14160) = true)

theorem identity14160 : scanCanonicalize (H12AffineFastState.compose env14160 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound14160 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env14161 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8,1344,293,65536,1345,261,1025,292,1296,1,65,65568,128,16,1,1344,1296,260,1285,4294967296,257,4295032971,1344,137]

theorem envBound14161 : H12AffineFastState.Bounded env14161 := by
  intro p hp
  have h : env14161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14160_14161 : H12AffineEnvironment.transform 14 293 env14160 = env14161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env14160 == env14161) = true)

def env14162 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1297,8,1296,293,65536,1297,261,1025,292,1296,1,17,65568,128,16,1,1296,1296,260,1285,4294967296,257,4295032971,1296,137]

theorem envBound14162 : H12AffineFastState.Bounded env14162 := by
  intro p hp
  have h : env14162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14161_14162 : H12AffineEnvironment.transform 5 16 env14161 = env14162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14161 == env14162) = true)

theorem identity14162 : scanCanonicalize (H12AffineFastState.compose env14162 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14162 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14163 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1297,8,1296,293,65536,1297,261,1025,292,1296,1,17,65568,128,16,1,1296,1296,260,1285,137,257,65538,1296,137]

theorem envBound14163 : H12AffineFastState.Bounded env14163 := by
  intro p hp
  have h : env14163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14162_14163 : H12AffineEnvironment.transform 31 137 env14162 = env14163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14162 == env14163) = true)

def env14164 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,1,8,0,293,65536,1,261,273,292,0,1,17,65568,128,16,1,0,0,260,21,137,257,65538,0,137]

theorem envBound14164 : H12AffineFastState.Bounded env14164 := by
  intro p hp
  have h : env14164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14163_14164 : H12AffineEnvironment.transform 9 272 env14163 = env14164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14163 == env14164) = true)

theorem identity14164 : scanCanonicalize (H12AffineFastState.compose env14164 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound14164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14165 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,1,8,0,293,430,1,261,273,292,0,1,17,398,128,16,1,0,0,260,21,137,257,428,0,137]

theorem envBound14165 : H12AffineFastState.Bounded env14165 := by
  intro p hp
  have h : env14165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14164_14165 : H12AffineEnvironment.transform 15 430 env14164 = env14165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env14164 == env14165) = true)

theorem identity14165 : scanCanonicalize (H12AffineFastState.compose env14165 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14165 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14166 : List Nat := [2,4,8,16,32,16,128,5,137,21,0,1,8,0,32,171,1,0,20,33,0,1,17,139,128,16,1,0,0,1,21,137,4,169,0,137]

theorem envBound14166 : H12AffineFastState.Bounded env14166 := by
  intro p hp
  have h : env14166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14165_14166 : H12AffineEnvironment.transform 7 5 env14165 = env14166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14165 == env14166) = true)

theorem identity14166 : scanCanonicalize (H12AffineFastState.compose env14166 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14166 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14167 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,1,8,0,1,138,1,0,20,0,0,1,17,139,128,16,1,0,0,1,21,137,4,136,0,137]

theorem envBound14167 : H12AffineFastState.Bounded env14167 := by
  intro p hp
  have h : env14167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14166_14167 : H12AffineEnvironment.transform 4 1 env14166 = env14167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14166 == env14167) = true)

theorem identity14167 : scanCanonicalize (H12AffineFastState.compose env14167 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14168 : List Nat := [2,4,8,16,1,16,25,5,16,21,0,1,8,0,1,19,1,0,20,0,0,1,17,18,25,16,1,0,0,1,21,16,4,17,0,16]

theorem envBound14168 : H12AffineFastState.Bounded env14168 := by
  intro p hp
  have h : env14168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14167_14168 : H12AffineEnvironment.transform 6 25 env14167 = env14168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14167 == env14168) = true)

def leafEnv14168 : List Nat := [2,4,8,16,1,16,25,5,16,21,0,1,8,0,1,19,1,0,20,0,0,1,17,18,21,25,1,16,1,0,0,1,21,16,4,17,4,3,0,16,0,0,1]

def active14168 : List Nat := [0,1,2,3]

def tree14168 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14168 : H12WitnessSearch.Good tree14168 := H12GlobalWitnessIndex.good

theorem leafIdentity14168 : H12AffineFastState.composeSystem env14168 rootObs = leafEnv14168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14168 rootObs == leafEnv14168) = true)

theorem terminalChecked14168 : H12PackedTerminal.terminalCheckFast leafEnv14168 active14168 tree14168 = true := by decide +kernel

def env14169 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,0,8,1,293,65536,0,261,272,292,1,1,17,65568,128,16,1,1,1,260,20,137,257,65538,1,137]

theorem envBound14169 : H12AffineFastState.Bounded env14169 := by
  intro p hp
  have h : env14169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14163_14169 : H12AffineEnvironment.transform 9 273 env14163 = env14169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14163 == env14169) = true)

end H12CloudChart2