import H12CloudChart2Data039

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity9747 : scanCanonicalize (H12AffineFastState.compose env9747 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9747 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9748 : List Nat := [2,4,8,16,32,11,51,36,59,1024,33,1076,8,1070,32,57,1071,32,1024,32,1076,32,11,56,50,17,32,1071,1077,32,1057,42,37,42,1070,58]

theorem envBound9748 : H12AffineFastState.Bounded env9748 := by
  intro p hp
  have h : env9748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9747_9748 : H12AffineEnvironment.transform 5 11 env9747 = env9748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9747 == env9748) = true)

def leafEnv9748 : List Nat := [2,4,8,16,32,11,51,36,59,1024,33,1076,8,1070,32,57,1071,32,1024,32,1076,32,11,56,1057,50,1,17,32,1071,1077,32,1057,42,37,42,5,2,1070,58,0,1077,1]

def active9748 : List Nat := [0,1,2,3,4,9]

def tree9748 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9748 : H12WitnessSearch.Good tree9748 := H12GlobalWitnessIndex.good

theorem leafIdentity9748 : H12AffineFastState.composeSystem env9748 rootObs = leafEnv9748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9748 rootObs == leafEnv9748) = true)

theorem terminalChecked9748 : H12PackedTerminal.terminalCheckFast leafEnv9748 active9748 tree9748 = true := by decide +kernel

def env9749 : List Nat := [2,4,8,16,32,64,121,256,113,1024,261,1296,8,1345,32,65536,1344,260,66903,32,1296,260,64,65829,120,17,260,1344,1297,260,1285,4294967296,257,4294967588,1345,112]

theorem envBound9749 : H12AffineFastState.Bounded env9749 := by
  intro p hp
  have h : env9749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9743_9749 : H12AffineEnvironment.transform 6 121 env9743 = env9749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9743 == env9749) = true)

theorem identity9749 : scanCanonicalize (H12AffineFastState.compose env9749 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9749 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9750 : List Nat := [2,4,8,16,32,64,121,36,113,1024,33,1076,8,1125,32,65536,1124,32,66675,32,1076,32,64,65537,120,17,32,1124,1077,32,1057,4294967296,37,4294967296,1125,112]

theorem envBound9750 : H12AffineFastState.Bounded env9750 := by
  intro p hp
  have h : env9750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9749_9750 : H12AffineEnvironment.transform 7 36 env9749 = env9750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9749 == env9750) = true)

theorem identity9750 : scanCanonicalize (H12AffineFastState.compose env9750 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 97) := by decide +kernel

theorem selectedBound9750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9751 : List Nat := [2,4,8,16,32,64,121,36,113,1024,33,1076,8,1125,32,65536,1124,32,66675,32,1076,32,64,65537,120,17,32,1124,1077,32,1057,97,37,97,1125,112]

theorem envBound9751 : H12AffineFastState.Bounded env9751 := by
  intro p hp
  have h : env9751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9750_9751 : H12AffineEnvironment.transform 31 97 env9750 = env9751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 97 env9750 == env9751) = true)

theorem identity9751 : scanCanonicalize (H12AffineFastState.compose env9751 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9751 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9752 : List Nat := [2,4,8,16,32,11,50,36,58,1024,33,1076,8,1070,32,65536,1071,32,66616,32,1076,32,11,65537,51,17,32,1071,1077,32,1057,42,37,42,1070,59]

theorem envBound9752 : H12AffineFastState.Bounded env9752 := by
  intro p hp
  have h : env9752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9751_9752 : H12AffineEnvironment.transform 5 11 env9751 = env9752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9751 == env9752) = true)

theorem identity9752 : scanCanonicalize (H12AffineFastState.compose env9752 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound9752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9753 : List Nat := [2,4,8,16,32,11,50,36,58,1024,33,1076,8,1070,32,56,1071,32,1024,32,1076,32,11,57,51,17,32,1071,1077,32,1057,42,37,42,1070,59]

theorem envBound9753 : H12AffineFastState.Bounded env9753 := by
  intro p hp
  have h : env9753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9752_9753 : H12AffineEnvironment.transform 15 56 env9752 = env9753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env9752 == env9753) = true)

def leafEnv9753 : List Nat := [2,4,8,16,32,11,50,36,58,1024,33,1076,8,1070,32,56,1071,32,1024,32,1076,32,11,57,1057,51,1,17,32,1071,1077,32,1057,42,37,42,5,2,1070,59,0,1077,1]

def active9753 : List Nat := [0,1,2,3,4,9]

def tree9753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9753 : H12WitnessSearch.Good tree9753 := H12GlobalWitnessIndex.good

theorem leafIdentity9753 : H12AffineFastState.composeSystem env9753 rootObs = leafEnv9753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9753 rootObs == leafEnv9753) = true)

theorem terminalChecked9753 : H12PackedTerminal.terminalCheckFast leafEnv9753 active9753 tree9753 = true := by decide +kernel

def env9754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,8,1344,681,65536,1344,2048,524288,681,1945,2049,65,66476,129,664,909,1345,1297,908,1285,4294967296,257,4295560590,1345,513]

theorem envBound9754 : H12AffineFastState.Bounded env9754 := by
  intro p hp
  have h : env9754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9739_9754 : H12AffineEnvironment.transform 11 1945 env9739 = env9754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env9739 == env9754) = true)

theorem identity9754 : scanCanonicalize (H12AffineFastState.compose env9754 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9754 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9755 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8,1344,32,65536,1344,2048,524288,32,1296,2049,65,65829,129,17,260,1345,1297,261,1285,4294967296,257,4295560590,1345,136]

theorem envBound9755 : H12AffineFastState.Bounded env9755 := by
  intro p hp
  have h : env9755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9754_9755 : H12AffineEnvironment.transform 8 137 env9754 = env9755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9754 == env9755) = true)

theorem identity9755 : scanCanonicalize (H12AffineFastState.compose env9755 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound9755 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9756 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8,1344,32,430,1344,2048,524288,32,1296,2049,65,139,129,17,260,1345,1297,261,1285,4294967296,257,4295494688,1345,136]

theorem envBound9756 : H12AffineFastState.Bounded env9756 := by
  intro p hp
  have h : env9756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9755_9756 : H12AffineEnvironment.transform 15 430 env9755 = env9756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env9755 == env9756) = true)

theorem identity9756 : scanCanonicalize (H12AffineFastState.compose env9756 (packedSelected [5,8] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9756 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9757 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8,1344,32,430,1344,2048,1025,32,1296,2049,65,139,129,17,260,1345,1297,261,1285,4294967296,257,4294969377,1345,136]

theorem envBound9757 : H12AffineFastState.Bounded env9757 := by
  intro p hp
  have h : env9757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9756_9757 : H12AffineEnvironment.transform 18 1025 env9756 = env9757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9756 == env9757) = true)

def env9758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13009,32768,65536,1344,262144,524288,32768,4097,4194304,14288,98565,33554432,5376,4465541,13009,1297,1073741824,1285,4294967296,257,4333340582,1345,33563272]

theorem envBound9758 : H12AffineFastState.Bounded env9758 := by
  intro p hp
  have h : env9758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9686_9758 : H12AffineEnvironment.transform 20 4097 env9686 = env9758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9686 == env9758) = true)

theorem identity9758 : scanCanonicalize (H12AffineFastState.compose env9758 (packedSelected [6,9,22,25] rootPS)) = affineNative (2^(24+1) ^^^ 534096) := by decide +kernel

theorem selectedBound9758 : packedSelected [6,9,22,25] rootPS < 2^1333 := by decide +kernel

def env9759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13009,32768,65536,1344,262144,524288,32768,4097,4194304,14288,98565,534096,5376,4465541,13009,1297,1073741824,1285,4294967296,257,4299268598,1345,525528]

theorem envBound9759 : H12AffineFastState.Bounded env9759 := by
  intro p hp
  have h : env9759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9758_9759 : H12AffineEnvironment.transform 24 534096 env9758 = env9759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 534096 env9758 == env9759) = true)

theorem identity9759 : scanCanonicalize (H12AffineFastState.compose env9759 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound9759 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,32768,65536,1344,262144,524288,32768,4097,4194304,6025,98565,525833,5376,4457436,4744,1297,1073741824,1285,4294967296,257,4299260335,1345,525528]

theorem envBound9760 : H12AffineFastState.Bounded env9760 := by
  intro p hp
  have h : env9760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9759_9760 : H12AffineEnvironment.transform 12 89 env9759 = env9760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9759 == env9760) = true)

theorem identity9760 : scanCanonicalize (H12AffineFastState.compose env9760 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 35496) := by decide +kernel

theorem selectedBound9760 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,32768,65536,1344,35496,524288,32768,4097,4194304,6025,98565,525833,5376,4229492,4744,1297,1073741824,1285,4294967296,257,4299260335,1345,525528]

theorem envBound9761 : H12AffineFastState.Bounded env9761 := by
  intro p hp
  have h : env9761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9760_9761 : H12AffineEnvironment.transform 17 35496 env9760 = env9761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35496 env9760 == env9761) = true)

theorem identity9761 : scanCanonicalize (H12AffineFastState.compose env9761 (packedSelected [9,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(29+1) ^^^ 4721924) := by decide +kernel

theorem selectedBound9761 : packedSelected [9,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env9762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,32768,65536,1344,35496,524288,32768,4097,4194304,6025,98565,525833,5376,4229492,4744,1297,4721924,1285,4294967296,257,4299260335,1345,525528]

theorem envBound9762 : H12AffineFastState.Bounded env9762 := by
  intro p hp
  have h : env9762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9761_9762 : H12AffineEnvironment.transform 29 4721924 env9761 = env9762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4721924 env9761 == env9762) = true)

theorem identity9762 : scanCanonicalize (H12AffineFastState.compose env9762 (packedSelected [0,4,7,9,10,11,12,13,15,16,17,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 33622) := by decide +kernel

theorem selectedBound9762 : packedSelected [0,4,7,9,10,11,12,13,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env9763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,32768,33622,1344,35496,524288,32768,4097,4194304,6025,595,525833,5376,4229492,4744,1297,4721924,1285,4294967296,257,4299162361,1345,525528]

theorem envBound9763 : H12AffineFastState.Bounded env9763 := by
  intro p hp
  have h : env9763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9762_9763 : H12AffineEnvironment.transform 15 33622 env9762 = env9763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33622 env9762 == env9763) = true)

theorem identity9763 : scanCanonicalize (H12AffineFastState.compose env9763 (packedSelected [11,16,18] rootPS)) = affineNative (2^(18+1) ^^^ 1752) := by decide +kernel

theorem selectedBound9763 : packedSelected [11,16,18] rootPS < 2^1333 := by decide +kernel

def env9764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,32768,33622,1344,35496,1752,32768,4097,4194304,6025,595,209,5376,4229492,4744,1297,4197340,1285,4294967296,257,4299162361,1345,512]

theorem envBound9764 : H12AffineFastState.Bounded env9764 := by
  intro p hp
  have h : env9764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9763_9764 : H12AffineEnvironment.transform 18 1752 env9763 = env9764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1752 env9763 == env9764) = true)

theorem identity9764 : scanCanonicalize (H12AffineFastState.compose env9764 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 909) := by decide +kernel

theorem selectedBound9764 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,909,219,1344,2341,1752,909,4097,4194304,6025,595,209,5376,4197113,4744,1297,4197340,1285,4294967296,257,4299162361,1345,512]

theorem envBound9765 : H12AffineFastState.Bounded env9765 := by
  intro p hp
  have h : env9765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9764_9765 : H12AffineEnvironment.transform 14 909 env9764 = env9765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 909 env9764 == env9765) = true)

theorem identity9765 : scanCanonicalize (H12AffineFastState.compose env9765 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(21+1) ^^^ 7603) := by decide +kernel

theorem selectedBound9765 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env9766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4744,909,219,1344,2341,1752,909,4097,7603,6025,595,209,5376,5962,4744,1297,5743,1285,4294967296,257,4294975306,1345,512]

theorem envBound9766 : H12AffineFastState.Bounded env9766 := by
  intro p hp
  have h : env9766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9765_9766 : H12AffineEnvironment.transform 21 7603 env9765 = env9766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7603 env9765 == env9766) = true)

theorem identity9766 : scanCanonicalize (H12AffineFastState.compose env9766 (packedSelected [10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound9766 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env9767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,89,4744,909,219,1344,642,1752,909,4097,5652,6025,595,209,5376,5962,4744,1297,5743,1285,4294967296,257,4294972653,1345,512]

theorem envBound9767 : H12AffineFastState.Bounded env9767 := by
  intro p hp
  have h : env9767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9766_9767 : H12AffineEnvironment.transform 10 935 env9766 = env9767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env9766 == env9767) = true)

theorem identity9767 : scanCanonicalize (H12AffineFastState.compose env9767 (packedSelected [5,6,8] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound9767 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env9768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,89,4744,909,219,1344,642,1752,909,4097,5652,6025,595,209,5376,5962,4744,1297,5743,1285,429,257,5440,1345,512]

theorem envBound9768 : H12AffineFastState.Bounded env9768 := by
  intro p hp
  have h : env9768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9767_9768 : H12AffineEnvironment.transform 31 429 env9767 = env9768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env9767 == env9768) = true)

theorem identity9768 : scanCanonicalize (H12AffineFastState.compose env9768 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound9768 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,1945,89,1297,909,219,1344,642,1752,909,1944,397,16,595,209,665,211,1297,1297,502,1285,429,257,729,1345,512]

theorem envBound9769 : H12AffineFastState.Bounded env9769 := by
  intro p hp
  have h : env9769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9768_9769 : H12AffineEnvironment.transform 11 1945 env9768 = env9769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env9768 == env9769) = true)

theorem identity9769 : scanCanonicalize (H12AffineFastState.compose env9769 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 470) := by decide +kernel

theorem selectedBound9769 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env9770 : List Nat := [2,4,8,16,32,64,128,256,470,1024,113,1103,89,1297,91,219,1344,340,1294,91,1102,397,16,389,209,335,211,1297,1297,502,1285,429,257,271,1345,470]

theorem envBound9770 : H12AffineFastState.Bounded env9770 := by
  intro p hp
  have h : env9770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9769_9770 : H12AffineEnvironment.transform 8 470 env9769 = env9770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 470 env9769 == env9770) = true)

theorem identity9770 : scanCanonicalize (H12AffineFastState.compose env9770 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound9770 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9771 : List Nat := [2,4,8,16,32,64,128,256,470,267,113,324,89,26,91,219,75,340,5,91,325,397,16,389,209,335,211,26,26,502,14,429,257,271,74,470]

theorem envBound9771 : H12AffineFastState.Bounded env9771 := by
  intro p hp
  have h : env9771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9770_9771 : H12AffineEnvironment.transform 9 267 env9770 = env9771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env9770 == env9771) = true)

theorem identity9771 : scanCanonicalize (H12AffineFastState.compose env9771 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound9771 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env9772 : List Nat := [2,4,8,16,32,64,128,15,217,4,113,75,89,26,91,219,75,91,5,91,74,130,16,138,209,64,211,26,26,249,14,162,14,0,74,217]

theorem envBound9772 : H12AffineFastState.Bounded env9772 := by
  intro p hp
  have h : env9772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9771_9772 : H12AffineEnvironment.transform 7 15 env9771 = env9772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env9771 == env9772) = true)

theorem identity9772 : scanCanonicalize (H12AffineFastState.compose env9772 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound9772 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9773 : List Nat := [1,4,8,16,32,64,128,12,217,4,113,72,89,25,88,216,72,88,5,88,73,129,16,137,209,64,208,25,25,249,13,161,13,0,73,217]

theorem envBound9773 : H12AffineFastState.Bounded env9773 := by
  intro p hp
  have h : env9773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9772_9773 : H12AffineEnvironment.transform 0 1 env9772 = env9773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env9772 == env9773) = true)

def env9774 : List Nat := [1,4,8,16,32,64,32,12,121,4,113,72,89,25,88,120,72,88,5,88,73,33,16,41,113,64,112,25,25,89,13,1,13,0,73,121]

theorem envBound9774 : H12AffineFastState.Bounded env9774 := by
  intro p hp
  have h : env9774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9773_9774 : H12AffineEnvironment.transform 6 32 env9773 = env9774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 32 env9773 == env9774) = true)

theorem identity9774 : scanCanonicalize (H12AffineFastState.compose env9774 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9775 : List Nat := [1,4,8,16,32,16,32,12,41,4,33,24,9,25,8,40,24,8,5,8,25,33,16,41,33,16,32,25,25,9,13,1,13,0,25,41]

theorem envBound9775 : H12AffineFastState.Bounded env9775 := by
  intro p hp
  have h : env9775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9774_9775 : H12AffineEnvironment.transform 5 16 env9774 = env9775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9774 == env9775) = true)

def env9776 : List Nat := [1,4,8,16,32,64,33,12,120,4,113,72,89,25,88,121,72,88,5,88,73,32,16,40,112,64,113,25,25,88,13,0,13,0,73,120]

theorem envBound9776 : H12AffineFastState.Bounded env9776 := by
  intro p hp
  have h : env9776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9773_9776 : H12AffineEnvironment.transform 6 33 env9773 = env9776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 33 env9773 == env9776) = true)

theorem identity9776 : scanCanonicalize (H12AffineFastState.compose env9776 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 57) := by decide +kernel

theorem selectedBound9776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9777 : List Nat := [1,4,8,16,32,57,33,12,1,4,8,49,32,25,33,0,49,33,5,33,48,32,16,40,9,57,8,25,25,33,13,0,13,0,48,1]

theorem envBound9777 : H12AffineFastState.Bounded env9777 := by
  intro p hp
  have h : env9777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9776_9777 : H12AffineEnvironment.transform 5 57 env9776 = env9777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 57 env9776 == env9777) = true)

theorem identity9777 : scanCanonicalize (H12AffineFastState.compose env9777 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9778 : List Nat := [1,4,8,16,1,24,0,12,1,4,8,16,1,25,0,0,16,0,5,0,17,1,16,9,9,24,8,25,25,0,13,0,13,0,17,1]

theorem envBound9778 : H12AffineFastState.Bounded env9778 := by
  intro p hp
  have h : env9778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9777_9778 : H12AffineEnvironment.transform 4 1 env9777 = env9778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9777 == env9778) = true)

theorem identity9778 : scanCanonicalize (H12AffineFastState.compose env9778 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound9778 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9779 : List Nat := [1,4,0,16,1,16,0,4,1,4,0,16,1,17,0,0,16,0,5,0,17,1,16,1,1,16,0,17,17,0,5,0,5,0,17,1]

theorem envBound9779 : H12AffineFastState.Bounded env9779 := by
  intro p hp
  have h : env9779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9778_9779 : H12AffineEnvironment.transform 2 0 env9778 = env9779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env9778 == env9779) = true)

def leafEnv9779 : List Nat := [1,4,0,16,1,16,0,4,1,4,0,16,1,17,0,0,16,0,5,0,17,1,16,1,4,1,1,16,0,17,17,0,5,0,5,0,5,0,17,1,0,17,1]

def active9779 : List Nat := [1,3]

def tree9779 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9779 : H12WitnessSearch.Good tree9779 := H12GlobalWitnessIndex.good

theorem leafIdentity9779 : H12AffineFastState.composeSystem env9779 rootObs = leafEnv9779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9779 rootObs == leafEnv9779) = true)

theorem terminalChecked9779 : H12PackedTerminal.terminalCheckFast leafEnv9779 active9779 tree9779 = true := by decide +kernel

def env9780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,23445585,2117633,1296,1073741824,16876545,4294967296,256,4352140403,1345,33563272]

theorem envBound9780 : H12AffineFastState.Bounded env9780 := by
  intro p hp
  have h : env9780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9605_9780 : H12AffineEnvironment.transform 26 23445585 env9605 = env9780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env9605 == env9780) = true)

def env9781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098432,134217728,2117632,157664576,1073741824,140788816,4294967296,157663569,4352140402,1344,33563272]

theorem envBound9781 : H12AffineFastState.Bounded env9781 := by
  intro p hp
  have h : env9781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9604_9781 : H12AffineEnvironment.transform 16 1345 env9604 = env9781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env9604 == env9781) = true)

theorem identity9781 : scanCanonicalize (H12AffineFastState.compose env9781 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9781 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env9782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,8329,2098432,134217728,2117632,157664576,1073741824,140788816,4294967296,157663569,4318577915,1344,513]

theorem envBound9782 : H12AffineFastState.Bounded env9782 := by
  intro p hp
  have h : env9782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9781_9782 : H12AffineEnvironment.transform 24 8329 env9781 = env9782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9781 == env9782) = true)

def env9783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,8329,2098432,23445584,2117632,1296,1073741824,16876544,4294967296,257,4318577915,1344,513]

theorem envBound9783 : H12AffineFastState.Bounded env9783 := by
  intro p hp
  have h : env9783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9782_9783 : H12AffineEnvironment.transform 26 23445584 env9782 = env9783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env9782 == env9783) = true)

theorem identity9783 : scanCanonicalize (H12AffineFastState.compose env9783 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 2199813) := by decide +kernel

theorem selectedBound9783 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env9784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,2199813,8329,2098432,4477269,2117632,1296,1073741824,2102533,4294967296,257,4299806206,1344,513]

theorem envBound9784 : H12AffineFastState.Bounded env9784 := by
  intro p hp
  have h : env9784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9783_9784 : H12AffineEnvironment.transform 23 2199813 env9783 = env9784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199813 env9783 == env9784) = true)

theorem identity9784 : scanCanonicalize (H12AffineFastState.compose env9784 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(20+1) ^^^ 541776) := by decide +kernel

theorem selectedBound9784 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env9785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,541776,4194304,17665,644437,8329,541008,4477269,529488,1296,1073741824,545109,4294967296,257,4299806206,1344,513]

theorem envBound9785 : H12AffineFastState.Bounded env9785 := by
  intro p hp
  have h : env9785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9784_9785 : H12AffineEnvironment.transform 20 541776 env9784 = env9785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 541776 env9784 == env9785) = true)

theorem identity9785 : scanCanonicalize (H12AffineFastState.compose env9785 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4820106) := by decide +kernel

theorem selectedBound9785 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,541776,4194304,17665,644437,8329,541008,4477269,529488,1296,4820106,545109,4294967296,257,4299806206,1344,513]

theorem envBound9786 : H12AffineFastState.Bounded env9786 := by
  intro p hp
  have h : env9786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9785_9786 : H12AffineEnvironment.transform 29 4820106 env9785 = env9786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4820106 env9785 == env9786) = true)

theorem identity9786 : scanCanonicalize (H12AffineFastState.compose env9786 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9786 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env9787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,16465,4194304,17665,119124,8329,17745,4477269,4177,1296,4294795,21844,4294967296,257,4299280895,1344,513]

theorem envBound9787 : H12AffineFastState.Bounded env9787 := by
  intro p hp
  have h : env9787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9786_9787 : H12AffineEnvironment.transform 18 1025 env9786 = env9787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9786 == env9787) = true)

theorem identity9787 : scanCanonicalize (H12AffineFastState.compose env9787 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4212169) := by decide +kernel

theorem selectedBound9787 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,16465,4194304,17665,119124,8329,17745,4477269,4177,1296,4294795,21844,4212169,257,103478,1344,513]

theorem envBound9788 : H12AffineFastState.Bounded env9788 := by
  intro p hp
  have h : env9788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9787_9788 : H12AffineEnvironment.transform 31 4212169 env9787 = env9788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4212169 env9787 == env9788) = true)

def env9789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,8329,2098432,23445585,2117632,1297,1073741824,16876545,4294967296,256,4318577915,1344,513]

theorem envBound9789 : H12AffineFastState.Bounded env9789 := by
  intro p hp
  have h : env9789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9782_9789 : H12AffineEnvironment.transform 26 23445585 env9782 = env9789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env9782 == env9789) = true)

theorem identity9789 : scanCanonicalize (H12AffineFastState.compose env9789 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound9789 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env9790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,16777216,8329,5376,21352529,16384,1297,1073741824,16876545,4294967296,256,4316484859,1344,513]

theorem envBound9790 : H12AffineFastState.Bounded env9790 := by
  intro p hp
  have h : env9790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9789_9790 : H12AffineEnvironment.transform 20 4096 env9789 = env9790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9789 == env9790) = true)

theorem identity9790 : scanCanonicalize (H12AffineFastState.compose env9790 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9790 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,8329,5376,4477268,16384,1297,1073741824,1284,4294967296,256,4299806206,1344,513]

theorem envBound9791 : H12AffineFastState.Bounded env9791 := by
  intro p hp
  have h : env9791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9790_9791 : H12AffineEnvironment.transform 23 98565 env9790 = env9791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9790 == env9791) = true)

theorem identity9791 : scanCanonicalize (H12AffineFastState.compose env9791 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4824) := by decide +kernel

theorem selectedBound9791 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,262144,524288,32768,4096,4194304,6105,98565,8329,5376,4457356,4824,1297,1073741824,1284,4294967296,256,4299786022,1344,513]

theorem envBound9792 : H12AffineFastState.Bounded env9792 := by
  intro p hp
  have h : env9792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9791_9792 : H12AffineEnvironment.transform 13 4824 env9791 = env9792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4824 env9791 == env9792) = true)

theorem identity9792 : scanCanonicalize (H12AffineFastState.compose env9792 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound9792 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,262144,524288,32768,4096,4194304,6105,98565,8329,5376,4457356,4824,1297,4497708,1284,4294967296,256,4299786022,1344,513]

theorem envBound9793 : H12AffineFastState.Bounded env9793 := by
  intro p hp
  have h : env9793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9792_9793 : H12AffineEnvironment.transform 29 4497708 env9792 = env9793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env9792 == env9793) = true)

theorem identity9793 : scanCanonicalize (H12AffineFastState.compose env9793 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound9793 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env9794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,4194304,6105,98565,8329,5376,4237613,4824,1297,4197261,1284,4294967296,256,4299786022,1344,513]

theorem envBound9794 : H12AffineFastState.Bounded env9794 := by
  intro p hp
  have h : env9794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9793_9794 : H12AffineEnvironment.transform 17 43681 env9793 = env9794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env9793 == env9794) = true)

def env9795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,10248,6105,98565,8329,5376,33061,4824,1297,9093,1284,4294967296,256,4295601966,1344,513]

theorem envBound9795 : H12AffineFastState.Bounded env9795 := by
  intro p hp
  have h : env9795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9794_9795 : H12AffineEnvironment.transform 21 10248 env9794 = env9795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env9794 == env9795) = true)

theorem identity9795 : scanCanonicalize (H12AffineFastState.compose env9795 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound9795 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7197,4824,32768,65536,1345,38588,524288,32768,4096,5141,6105,98565,7316,5376,33061,4824,1297,8088,1284,4294967296,256,4295594803,1344,513]

theorem envBound9796 : H12AffineFastState.Bounded env9796 := by
  intro p hp
  have h : env9796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9795_9796 : H12AffineEnvironment.transform 12 7197 env9795 = env9796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env9795 == env9796) = true)

def env9797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,2949,1344,32768,65536,1345,33060,524288,32768,1944,909,65,98565,2828,664,33061,1344,1297,2048,1284,4294967296,256,4295591083,1344,513]

theorem envBound9797 : H12AffineFastState.Bounded env9797 := by
  intro p hp
  have h : env9797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9796_9797 : H12AffineEnvironment.transform 11 1944 env9796 = env9797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env9796 == env9797) = true)

theorem identity9797 : scanCanonicalize (H12AffineFastState.compose env9797 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 2988) := by decide +kernel

theorem selectedBound9797 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,2949,1344,2988,65536,1345,2696,524288,2988,1944,909,65,68265,2828,664,2697,1344,1297,2048,1284,4294967296,256,4295560967,1344,513]

theorem envBound9798 : H12AffineFastState.Bounded env9798 := by
  intro p hp
  have h : env9798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9797_9798 : H12AffineEnvironment.transform 14 2988 env9797 = env9798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2988 env9797 == env9798) = true)

theorem identity9798 : scanCanonicalize (H12AffineFastState.compose env9798 (packedSelected [0,2,3,4,6,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 69155) := by decide +kernel

theorem selectedBound9798 : packedSelected [0,2,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,2949,1344,2988,65536,1345,2696,69155,2988,1944,909,65,68265,2828,664,2697,1344,1297,2048,1284,4294967296,256,4294967588,1344,513]

theorem envBound9799 : H12AffineFastState.Bounded env9799 := by
  intro p hp
  have h : env9799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9798_9799 : H12AffineEnvironment.transform 18 69155 env9798 = env9799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 69155 env9798 == env9799) = true)

theorem identity9799 : scanCanonicalize (H12AffineFastState.compose env9799 (packedSelected [1,5,13] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound9799 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env9800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,2949,1344,2988,2218,1345,2696,1673,2988,1944,909,65,515,2828,664,2697,1344,1297,2048,1284,4294967296,256,4294967588,1344,513]

theorem envBound9800 : H12AffineFastState.Bounded env9800 := by
  intro p hp
  have h : env9800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9799_9800 : H12AffineEnvironment.transform 15 2218 env9799 = env9800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env9799 == env9800) = true)

theorem identity9800 : scanCanonicalize (H12AffineFastState.compose env9800 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9800 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9801 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,1725,2720,1125,2697,2218,1124,2696,1673,2697,1725,680,65,515,2601,664,2697,1125,1076,2048,1057,4294967296,37,4294967297,1125,513]

theorem envBound9801 : H12AffineFastState.Bounded env9801 := by
  intro p hp
  have h : env9801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9800_9801 : H12AffineEnvironment.transform 7 37 env9800 = env9801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9800 == env9801) = true)

theorem identity9801 : scanCanonicalize (H12AffineFastState.compose env9801 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9801 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9802 : List Nat := [2,4,8,16,32,64,128,37,137,1024,2048,1076,2089,1125,2048,2218,1124,2049,1024,2048,1076,33,65,138,2208,17,2048,1125,1076,2048,1057,4294967296,37,4294967297,1125,136]

theorem envBound9802 : H12AffineFastState.Bounded env9802 := by
  intro p hp
  have h : env9802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9801_9802 : H12AffineEnvironment.transform 8 137 env9801 = env9802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9801 == env9802) = true)

theorem identity9802 : scanCanonicalize (H12AffineFastState.compose env9802 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3167) := by decide +kernel

theorem selectedBound9802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9803 : List Nat := [2,4,8,16,32,64,128,37,137,1024,2048,1076,2089,1125,2048,2218,1124,2049,1024,2048,1076,33,65,138,2208,17,2048,1125,1076,2048,1057,3167,37,3166,1125,136]

theorem envBound9803 : H12AffineFastState.Bounded env9803 := by
  intro p hp
  have h : env9803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9802_9803 : H12AffineEnvironment.transform 31 3167 env9802 = env9803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3167 env9802 == env9803) = true)

def env9804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,2948,1345,32768,65536,1345,33061,524288,32768,1945,908,64,98565,2829,665,33061,1345,1297,2049,1284,4294967296,256,4295591082,1344,513]

theorem envBound9804 : H12AffineFastState.Bounded env9804 := by
  intro p hp
  have h : env9804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9796_9804 : H12AffineEnvironment.transform 11 1945 env9796 = env9804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env9796 == env9804) = true)

theorem identity9804 : scanCanonicalize (H12AffineFastState.compose env9804 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9804 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9805 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2317,1345,32768,65536,1345,33061,524288,32768,1296,261,64,98565,2436,16,33061,1345,1297,2049,1284,4294967296,256,4295591082,1344,136]

theorem envBound9805 : H12AffineFastState.Bounded env9805 := by
  intro p hp
  have h : env9805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9804_9805 : H12AffineEnvironment.transform 8 137 env9804 = env9805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9804 == env9805) = true)

theorem identity9805 : scanCanonicalize (H12AffineFastState.compose env9805 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound9805 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9806 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2317,1345,32768,33167,1345,33061,524288,32768,1296,261,64,138,2436,16,33061,1345,1297,2049,1284,4294967296,256,4295492901,1344,136]

theorem envBound9806 : H12AffineFastState.Bounded env9806 := by
  intro p hp
  have h : env9806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9805_9806 : H12AffineEnvironment.transform 15 33167 env9805 = env9806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env9805 == env9806) = true)

theorem identity9806 : scanCanonicalize (H12AffineFastState.compose env9806 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9806 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9807 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,2056,1092,32768,32906,1092,32800,524288,32768,1045,0,64,138,2177,16,32800,1092,1044,2049,1025,4294967296,5,4295492640,1093,136]

theorem envBound9807 : H12AffineFastState.Bounded env9807 := by
  intro p hp
  have h : env9807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9806_9807 : H12AffineEnvironment.transform 7 5 env9806 = env9807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9806 == env9807) = true)

theorem identity9807 : scanCanonicalize (H12AffineFastState.compose env9807 (packedSelected [3,10] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound9807 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env9808 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,2056,1092,2080,2218,1092,2048,524288,2080,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,4294967296,5,4295492640,1093,136]

theorem envBound9808 : H12AffineFastState.Bounded env9808 := by
  intro p hp
  have h : env9808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9807_9808 : H12AffineEnvironment.transform 14 2080 env9807 = env9808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env9807 == env9808) = true)

def env9809 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1092,2048,2186,1092,2048,524288,2048,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,4294967296,5,4295492608,1093,136]

theorem envBound9809 : H12AffineFastState.Bounded env9809 := by
  intro p hp
  have h : env9809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9808_9809 : H12AffineEnvironment.transform 4 0 env9808 = env9809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9808 == env9809) = true)

theorem identity9809 : scanCanonicalize (H12AffineFastState.compose env9809 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3286) := by decide +kernel

theorem selectedBound9809 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9810 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1092,2048,2186,1092,2048,524288,2048,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,3286,5,526550,1093,136]

theorem envBound9810 : H12AffineFastState.Bounded env9810 := by
  intro p hp
  have h : env9810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9809_9810 : H12AffineEnvironment.transform 31 3286 env9809 = env9810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3286 env9809 == env9810) = true)

theorem identity9810 : scanCanonicalize (H12AffineFastState.compose env9810 (packedSelected [1,2,5] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9810 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env9811 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1092,2048,2186,1092,2048,1025,2048,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,3286,5,3287,1093,136]

theorem envBound9811 : H12AffineFastState.Bounded env9811 := by
  intro p hp
  have h : env9811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9810_9811 : H12AffineEnvironment.transform 18 1025 env9810 = env9811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9810 == env9811) = true)

theorem identity9811 : scanCanonicalize (H12AffineFastState.compose env9811 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1239) := by decide +kernel

theorem selectedBound9811 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9812 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1239,1045,1247,1092,1239,1117,1092,1239,1025,1239,1045,0,64,138,1110,16,1239,1092,1044,1238,1025,1,5,0,1093,136]

theorem envBound9812 : H12AffineFastState.Bounded env9812 := by
  intro p hp
  have h : env9812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9811_9812 : H12AffineEnvironment.transform 10 1239 env9811 = env9812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1239 env9811 == env9812) = true)

theorem identity9812 : scanCanonicalize (H12AffineFastState.compose env9812 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9812 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9813 : List Nat := [2,4,8,16,0,64,88,5,81,1024,1039,1045,1031,1092,1039,1117,1092,1039,1025,1039,1045,0,64,82,1110,16,1039,1092,1044,1038,1025,1,5,0,1093,80]

theorem envBound9813 : H12AffineFastState.Bounded env9813 := by
  intro p hp
  have h : env9813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9812_9813 : H12AffineEnvironment.transform 6 88 env9812 = env9813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9812 == env9813) = true)

def leafEnv9813 : List Nat := [2,4,8,16,0,64,88,5,81,1024,1039,1045,1031,1092,1039,1117,1092,1039,1025,1039,1045,0,64,82,1025,1110,1,16,1039,1092,1044,1038,1025,1,5,0,5,1036,1093,80,0,1045,1]

def active9813 : List Nat := [0,1,2,3,5,9]

def tree9813 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9813 : H12WitnessSearch.Good tree9813 := H12GlobalWitnessIndex.good

theorem leafIdentity9813 : H12AffineFastState.composeSystem env9813 rootObs = leafEnv9813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9813 rootObs == leafEnv9813) = true)

theorem terminalChecked9813 : H12PackedTerminal.terminalCheckFast leafEnv9813 active9813 tree9813 = true := by decide +kernel

def env9814 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1092,2049,2187,1092,2048,524288,2049,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,4294967296,5,4295492609,1093,136]

theorem envBound9814 : H12AffineFastState.Bounded env9814 := by
  intro p hp
  have h : env9814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9808_9814 : H12AffineEnvironment.transform 4 1 env9808 = env9814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9808 == env9814) = true)

theorem identity9814 : scanCanonicalize (H12AffineFastState.compose env9814 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3167) := by decide +kernel

theorem selectedBound9814 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9815 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1092,2049,2187,1092,2048,524288,2049,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,3167,5,526430,1093,136]

theorem envBound9815 : H12AffineFastState.Bounded env9815 := by
  intro p hp
  have h : env9815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9814_9815 : H12AffineEnvironment.transform 31 3167 env9814 = env9815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3167 env9814 == env9815) = true)

def env9816 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1092,2049,2187,1092,2048,1024,2049,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,3167,5,3166,1093,136]

theorem envBound9816 : H12AffineFastState.Bounded env9816 := by
  intro p hp
  have h : env9816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9815_9816 : H12AffineEnvironment.transform 18 1024 env9815 = env9816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9815 == env9816) = true)

theorem identity9816 : scanCanonicalize (H12AffineFastState.compose env9816 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9817 : List Nat := [2,4,8,16,1,64,8,5,1,1024,2048,1045,2056,1092,2049,2051,1092,2048,1024,2049,1045,0,64,2,2057,16,2048,1092,1044,2049,1025,3167,5,3166,1093,0]

theorem envBound9817 : H12AffineFastState.Bounded env9817 := by
  intro p hp
  have h : env9817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9816_9817 : H12AffineEnvironment.transform 6 8 env9816 = env9817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9816 == env9817) = true)

theorem identity9817 : scanCanonicalize (H12AffineFastState.compose env9817 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound9817 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9818 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1039,1045,1031,1092,1038,1036,1092,1039,1024,1038,1045,0,64,2,1030,16,1039,1092,1044,1038,1025,80,5,81,1093,0]

theorem envBound9818 : H12AffineFastState.Bounded env9818 := by
  intro p hp
  have h : env9818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9817_9818 : H12AffineEnvironment.transform 10 1039 env9817 = env9818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env9817 == env9818) = true)

def leafEnv9818 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1039,1045,1031,1092,1038,1036,1092,1039,1024,1038,1045,0,64,2,1024,1030,1,16,1039,1092,1044,1038,1025,80,5,81,5,1037,1093,0,0,1045,1]

def active9818 : List Nat := [0,1,2,3,5,9]

def tree9818 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9818 : H12WitnessSearch.Good tree9818 := H12GlobalWitnessIndex.good

theorem leafIdentity9818 : H12AffineFastState.composeSystem env9818 rootObs = leafEnv9818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9818 rootObs == leafEnv9818) = true)

theorem terminalChecked9818 : H12PackedTerminal.terminalCheckFast leafEnv9818 active9818 tree9818 = true := by decide +kernel

def env9819 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1092,2049,2187,1092,2048,1025,2049,1045,0,64,138,2177,16,2048,1092,1044,2049,1025,3167,5,3167,1093,136]

theorem envBound9819 : H12AffineFastState.Bounded env9819 := by
  intro p hp
  have h : env9819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9815_9819 : H12AffineEnvironment.transform 18 1025 env9815 = env9819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9815 == env9819) = true)

theorem identity9819 : scanCanonicalize (H12AffineFastState.compose env9819 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1159) := by decide +kernel

theorem selectedBound9819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9820 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1159,1045,1167,1092,1158,1036,1092,1159,1025,1158,1045,0,64,138,1030,16,1159,1092,1044,1158,1025,216,5,216,1093,136]

theorem envBound9820 : H12AffineFastState.Bounded env9820 := by
  intro p hp
  have h : env9820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9819_9820 : H12AffineEnvironment.transform 10 1159 env9819 = env9820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1159 env9819 == env9820) = true)

def leafEnv9820 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1159,1045,1167,1092,1158,1036,1092,1159,1025,1158,1045,0,64,138,1025,1030,1,16,1159,1092,1044,1158,1025,216,5,216,5,1157,1093,136,0,1045,1]

def active9820 : List Nat := [0,1,2,3,5,6,9]

def tree9820 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9820 : H12WitnessSearch.Good tree9820 := H12GlobalWitnessIndex.good

theorem leafIdentity9820 : H12AffineFastState.composeSystem env9820 rootObs = leafEnv9820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9820 rootObs == leafEnv9820) = true)

theorem terminalChecked9820 : H12PackedTerminal.terminalCheckFast leafEnv9820 active9820 tree9820 = true := by decide +kernel

def env9821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,10249,6105,98565,8329,5376,33060,4824,1297,9092,1284,4294967296,256,4295601967,1344,513]

theorem envBound9821 : H12AffineFastState.Bounded env9821 := by
  intro p hp
  have h : env9821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9794_9821 : H12AffineEnvironment.transform 21 10249 env9794 = env9821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env9794 == env9821) = true)

theorem identity9821 : scanCanonicalize (H12AffineFastState.compose env9821 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 13624) := by decide +kernel

theorem selectedBound9821 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,13624,65536,1345,8089,524288,13624,4096,10249,6105,78909,8329,5376,13340,4824,1297,9092,1284,4294967296,256,4295563799,1344,513]

theorem envBound9822 : H12AffineFastState.Bounded env9822 := by
  intro p hp
  have h : env9822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9821_9822 : H12AffineEnvironment.transform 14 13624 env9821 = env9822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13624 env9821 == env9822) = true)

def env9823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1344,8864,65536,1345,2049,524288,8864,1944,10249,65,74661,8329,664,9092,1344,1297,9092,1284,4294967296,256,4295560591,1344,513]

theorem envBound9823 : H12AffineFastState.Bounded env9823 := by
  intro p hp
  have h : env9823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9822_9823 : H12AffineEnvironment.transform 11 1944 env9822 = env9823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env9822 == env9823) = true)

theorem identity9823 : scanCanonicalize (H12AffineFastState.compose env9823 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound9823 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,2316,1344,2988,65536,1345,2049,524288,2988,1944,261,65,68265,2437,664,2696,1344,1297,2696,1284,4294967296,256,4295560591,1344,513]

theorem envBound9824 : H12AffineFastState.Bounded env9824 := by
  intro p hp
  have h : env9824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9823_9824 : H12AffineEnvironment.transform 12 2316 env9823 = env9824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env9823 == env9824) = true)

theorem identity9824 : scanCanonicalize (H12AffineFastState.compose env9824 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9824 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9825 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2316,1344,2341,65536,1345,2049,524288,2341,1297,261,65,67616,2437,17,2049,1344,1297,2049,1284,4294967296,256,4295560591,1344,136]

theorem envBound9825 : H12AffineFastState.Bounded env9825 := by
  intro p hp
  have h : env9825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9824_9825 : H12AffineEnvironment.transform 8 137 env9824 = env9825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9824 == env9825) = true)

theorem identity9825 : scanCanonicalize (H12AffineFastState.compose env9825 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound9825 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9826 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2316,1344,2341,2218,1345,2049,524288,2341,1297,261,65,138,2437,17,2049,1344,1297,2049,1284,4294967296,256,4295492901,1344,136]

theorem envBound9826 : H12AffineFastState.Bounded env9826 := by
  intro p hp
  have h : env9826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9825_9826 : H12AffineEnvironment.transform 15 2218 env9825 = env9826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env9825 == env9826) = true)

theorem identity9826 : scanCanonicalize (H12AffineFastState.compose env9826 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9826 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9827 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1044,2057,1093,2080,2218,1092,2049,524288,2080,1044,0,65,138,2176,17,2049,1093,1044,2049,1025,4294967296,5,4295492640,1093,136]

theorem envBound9827 : H12AffineFastState.Bounded env9827 := by
  intro p hp
  have h : env9827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9826_9827 : H12AffineEnvironment.transform 7 5 env9826 = env9827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9826 == env9827) = true)

def env9828 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1093,2048,2186,1092,2049,524288,2048,1044,0,65,138,2176,17,2049,1093,1044,2049,1025,4294967296,5,4295492608,1093,136]

theorem envBound9828 : H12AffineFastState.Bounded env9828 := by
  intro p hp
  have h : env9828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9827_9828 : H12AffineEnvironment.transform 4 0 env9827 = env9828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9827 == env9828) = true)

theorem identity9828 : scanCanonicalize (H12AffineFastState.compose env9828 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3166) := by decide +kernel

theorem selectedBound9828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9829 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1093,2048,2186,1092,2049,524288,2048,1044,0,65,138,2176,17,2049,1093,1044,2049,1025,3166,5,526430,1093,136]

theorem envBound9829 : H12AffineFastState.Bounded env9829 := by
  intro p hp
  have h : env9829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9828_9829 : H12AffineEnvironment.transform 31 3166 env9828 = env9829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3166 env9828 == env9829) = true)

theorem identity9829 : scanCanonicalize (H12AffineFastState.compose env9829 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1158) := by decide +kernel

theorem selectedBound9829 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9830 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1158,1044,1167,1093,1158,1036,1092,1159,524288,1158,1044,0,65,138,1030,17,1159,1093,1044,1159,1025,216,5,525528,1093,136]

theorem envBound9830 : H12AffineFastState.Bounded env9830 := by
  intro p hp
  have h : env9830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9829_9830 : H12AffineEnvironment.transform 10 1158 env9829 = env9830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1158 env9829 == env9830) = true)

theorem identity9830 : scanCanonicalize (H12AffineFastState.compose env9830 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9830 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9831 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1038,1044,1031,1093,1038,1036,1092,1039,524288,1038,1044,0,65,2,1030,17,1039,1093,1044,1039,1025,80,5,525392,1093,0]

theorem envBound9831 : H12AffineFastState.Bounded env9831 := by
  intro p hp
  have h : env9831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9830_9831 : H12AffineEnvironment.transform 6 8 env9830 = env9831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9830 == env9831) = true)

def leafEnv9831 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1038,1044,1031,1093,1038,1036,1092,1039,524288,1038,1044,0,65,2,524288,1030,1,17,1039,1093,1044,1039,1025,80,5,525392,5,1037,1093,0,0,1045,1]

def active9831 : List Nat := [0,1,2,3,5,9,18]

def tree9831 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9831 : H12WitnessSearch.Good tree9831 := H12GlobalWitnessIndex.good

theorem leafIdentity9831 : H12AffineFastState.composeSystem env9831 rootObs = leafEnv9831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9831 rootObs == leafEnv9831) = true)

theorem terminalChecked9831 : H12PackedTerminal.terminalCheckFast leafEnv9831 active9831 tree9831 = true := by decide +kernel

def env9832 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2057,1093,2049,2187,1092,2049,524288,2049,1044,0,65,138,2176,17,2049,1093,1044,2049,1025,4294967296,5,4295492609,1093,136]

theorem envBound9832 : H12AffineFastState.Bounded env9832 := by
  intro p hp
  have h : env9832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9827_9832 : H12AffineEnvironment.transform 4 1 env9827 = env9832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9827 == env9832) = true)

theorem identity9832 : scanCanonicalize (H12AffineFastState.compose env9832 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3287) := by decide +kernel

theorem selectedBound9832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9833 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2057,1093,2049,2187,1092,2049,524288,2049,1044,0,65,138,2176,17,2049,1093,1044,2049,1025,3287,5,526550,1093,136]

theorem envBound9833 : H12AffineFastState.Bounded env9833 := by
  intro p hp
  have h : env9833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9832_9833 : H12AffineEnvironment.transform 31 3287 env9832 = env9833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3287 env9832 == env9833) = true)

theorem identity9833 : scanCanonicalize (H12AffineFastState.compose env9833 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound9833 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9834 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1038,1044,1031,1093,1039,1157,1092,1039,524288,1039,1044,0,65,138,1166,17,1039,1093,1044,1039,1025,217,5,525528,1093,136]

theorem envBound9834 : H12AffineFastState.Bounded env9834 := by
  intro p hp
  have h : env9834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9833_9834 : H12AffineEnvironment.transform 10 1038 env9833 = env9834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env9833 == env9834) = true)

theorem identity9834 : scanCanonicalize (H12AffineFastState.compose env9834 (packedSelected [1] rootPS)) = affineNative (2^(18+1) ^^^ 1104) := by decide +kernel

theorem selectedBound9834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9835 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1038,1044,1031,1093,1039,1157,1092,1039,1104,1039,1044,0,65,138,1166,17,1039,1093,1044,1039,1025,217,5,136,1093,136]

theorem envBound9835 : H12AffineFastState.Bounded env9835 := by
  intro p hp
  have h : env9835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9834_9835 : H12AffineEnvironment.transform 18 1104 env9834 = env9835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env9834 == env9835) = true)

theorem identity9835 : scanCanonicalize (H12AffineFastState.compose env9835 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9835 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env9836 : List Nat := [2,4,8,16,1,17,128,5,137,1024,1038,1044,1031,1044,1039,1157,1045,1039,1025,1039,1044,0,16,138,1166,17,1039,1044,1044,1039,1025,136,5,136,1044,136]

theorem envBound9836 : H12AffineFastState.Bounded env9836 := by
  intro p hp
  have h : env9836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9835_9836 : H12AffineEnvironment.transform 5 17 env9835 = env9836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9835 == env9836) = true)

def leafEnv9836 : List Nat := [2,4,8,16,1,17,128,5,137,1024,1038,1044,1031,1044,1039,1157,1045,1039,1025,1039,1044,0,16,138,1025,1166,1,17,1039,1044,1044,1039,1025,136,5,136,5,1036,1044,136,0,1045,1]

def active9836 : List Nat := [0,1,2,3,6,9]

def tree9836 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9836 : H12WitnessSearch.Good tree9836 := H12GlobalWitnessIndex.good

theorem leafIdentity9836 : H12AffineFastState.composeSystem env9836 rootObs = leafEnv9836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9836 rootObs == leafEnv9836) = true)

theorem terminalChecked9836 : H12PackedTerminal.terminalCheckFast leafEnv9836 active9836 tree9836 = true := by decide +kernel

def env9837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,8192,1345,8865,65536,1345,2048,524288,8865,1945,10249,64,74660,8329,665,9093,1345,1297,9092,1284,4294967296,256,4295560590,1344,513]

theorem envBound9837 : H12AffineFastState.Bounded env9837 := by
  intro p hp
  have h : env9837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9822_9837 : H12AffineEnvironment.transform 11 1945 env9822 = env9837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env9822 == env9837) = true)

theorem identity9837 : scanCanonicalize (H12AffineFastState.compose env9837 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9837 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9838 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1345,8233,65536,1345,2048,524288,8233,1297,10249,64,74028,8329,17,8461,1345,1297,8460,1284,4294967296,256,4295560590,1344,137]

theorem envBound9838 : H12AffineFastState.Bounded env9838 := by
  intro p hp
  have h : env9838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9837_9838 : H12AffineEnvironment.transform 8 136 env9837 = env9838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9837 == env9838) = true)

theorem identity9838 : scanCanonicalize (H12AffineFastState.compose env9838 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 75175) := by decide +kernel

theorem selectedBound9838 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9839 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1345,8233,65536,1345,2048,75175,8233,1297,10249,64,74028,8329,17,8461,1345,1297,8460,1284,4294967296,256,4294977577,1344,137]

theorem envBound9839 : H12AffineFastState.Bounded env9839 := by
  intro p hp
  have h : env9839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9838_9839 : H12AffineEnvironment.transform 18 75175 env9838 = env9839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75175 env9838 == env9839) = true)

def env9840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,536870912,1073741824,553878609,4294967296,537002320,4417151346,694534145,33563272]

theorem envBound9840 : H12AffineFastState.Bounded env9840 := by
  intro p hp
  have h : env9840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9448_9840 : H12AffineEnvironment.transform 34 694534145 env9448 = env9840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534145 env9448 == env9840) = true)

def env9841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,157794304,1073741824,140788817,4294967296,157663568,4417151346,131073,33563272]

theorem envBound9841 : H12AffineFastState.Bounded env9841 := by
  intro p hp
  have h : env9841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9840_9841 : H12AffineEnvironment.transform 28 157794304 env9840 = env9841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env9840 == env9841) = true)

theorem identity9841 : scanCanonicalize (H12AffineFastState.compose env9841 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 136513) := by decide +kernel

theorem selectedBound9841 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,67108864,134217728,67130624,155571521,1073741824,138826000,4294967296,155702289,4417151346,131073,33563272]

theorem envBound9842 : H12AffineFastState.Bounded env9842 := by
  intro p hp
  have h : env9842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9841_9842 : H12AffineEnvironment.transform 20 136513 env9841 = env9842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env9841 == env9842) = true)

def env9843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,67108864,21484816,67130624,131153,1073741824,16876544,4294967296,257,4417151346,131073,33563272]

theorem envBound9843 : H12AffineFastState.Bounded env9843 := by
  intro p hp
  have h : env9843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9842_9843 : H12AffineEnvironment.transform 26 21484816 env9842 = env9843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21484816 env9842 == env9843) = true)

def env9844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,5376,21484816,16384,131153,1073741824,16876544,4294967296,257,4350047346,131073,33563272]

theorem envBound9844 : H12AffineFastState.Bounded env9844 := by
  intro p hp
  have h : env9844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9843_9844 : H12AffineEnvironment.transform 25 5376 env9843 = env9844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9843 == env9844) = true)

theorem identity9844 : scanCanonicalize (H12AffineFastState.compose env9844 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound9844 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,98564,33554432,5376,4609044,16384,131153,1073741824,1284,4294967296,257,4333368694,131073,33563272]

theorem envBound9845 : H12AffineFastState.Bounded env9845 := by
  intro p hp
  have h : env9845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9844_9845 : H12AffineEnvironment.transform 23 98564 env9844 = env9845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env9844 == env9845) = true)

def env9846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151824,32768,136513,4194304,17665,98564,33554432,5376,4609044,16384,131153,1073741824,1284,4294967296,257,4332954726,131073,33563272]

theorem envBound9846 : H12AffineFastState.Bounded env9846 := by
  intro p hp
  have h : env9846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9845_9846 : H12AffineEnvironment.transform 18 151824 env9845 = env9846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 151824 env9845 == env9846) = true)

theorem identity9846 : scanCanonicalize (H12AffineFastState.compose env9846 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 4427211) := by decide +kernel

theorem selectedBound9846 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151824,32768,136513,4194304,17665,98564,33554432,5376,4609044,16384,131153,4427211,1284,4294967296,257,4332954726,131073,33563272]

theorem envBound9847 : H12AffineFastState.Bounded env9847 := by
  intro p hp
  have h : env9847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9846_9847 : H12AffineEnvironment.transform 29 4427211 env9846 = env9847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4427211 env9846 == env9847) = true)

theorem identity9847 : scanCanonicalize (H12AffineFastState.compose env9847 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(16+1) ^^^ 21776) := by decide +kernel

theorem selectedBound9847 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env9848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1024,32768,16465,4194304,17665,98564,33554432,5376,4456708,16384,21825,4315355,1284,4294967296,257,4332843382,21777,33563272]

theorem envBound9848 : H12AffineFastState.Bounded env9848 := by
  intro p hp
  have h : env9848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9847_9848 : H12AffineEnvironment.transform 16 21776 env9847 = env9848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21776 env9847 == env9848) = true)

theorem identity9848 : scanCanonicalize (H12AffineFastState.compose env9848 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9848 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1024,32768,16465,4194304,17665,98564,8328,5376,4456708,16384,21825,4315355,1284,4294967296,257,4299280894,21777,512]

theorem envBound9849 : H12AffineFastState.Bounded env9849 := by
  intro p hp
  have h : env9849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9848_9849 : H12AffineEnvironment.transform 24 8328 env9848 = env9849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9848 == env9849) = true)

theorem identity9849 : scanCanonicalize (H12AffineFastState.compose env9849 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 20956) := by decide +kernel

theorem selectedBound9849 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1024,32768,16465,20956,17665,98564,8328,5376,282840,16384,21825,100615,1284,4294967296,257,4295065634,21777,512]

theorem envBound9850 : H12AffineFastState.Bounded env9850 := by
  intro p hp
  have h : env9850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9849_9850 : H12AffineEnvironment.transform 21 20956 env9849 = env9850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20956 env9849 == env9850) = true)

theorem identity9850 : scanCanonicalize (H12AffineFastState.compose env9850 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29020) := by decide +kernel

theorem selectedBound9850 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env9851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29020,65536,21776,262144,1024,29020,16465,20956,17665,94296,8328,5376,282840,16384,21825,96347,1284,4294967296,257,4295061886,21777,512]

theorem envBound9851 : H12AffineFastState.Bounded env9851 := by
  intro p hp
  have h : env9851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9850_9851 : H12AffineEnvironment.transform 14 29020 env9850 = env9851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29020 env9850 == env9851) = true)

theorem identity9851 : scanCanonicalize (H12AffineFastState.compose env9851 (packedSelected [6,25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9851 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1345,262144,1024,8461,4096,397,5456,73737,8328,5376,262281,4177,1296,75786,1284,4294967296,257,4295041327,1344,512]

theorem envBound9852 : H12AffineFastState.Bounded env9852 := by
  intro p hp
  have h : env9852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9851_9852 : H12AffineEnvironment.transform 13 4177 env9851 = env9852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9851 == env9852) = true)

theorem identity9852 : scanCanonicalize (H12AffineFastState.compose env9852 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 65831) := by decide +kernel

theorem selectedBound9852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1345,262144,1024,8461,4096,397,5456,73737,8328,5376,262281,4177,1296,75786,1284,65831,257,8200,1344,512]

theorem envBound9853 : H12AffineFastState.Bounded env9853 := by
  intro p hp
  have h : env9853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9852_9853 : H12AffineEnvironment.transform 31 65831 env9852 = env9853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65831 env9852 == env9853) = true)

theorem identity9853 : scanCanonicalize (H12AffineFastState.compose env9853 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 4842) := by decide +kernel

theorem selectedBound9853 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,4842,1345,262144,1024,8461,4096,397,5456,13027,8328,5376,262281,4177,1296,15072,1284,5069,257,8200,1344,512]

theorem envBound9854 : H12AffineFastState.Bounded env9854 := by
  intro p hp
  have h : env9854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9853_9854 : H12AffineEnvironment.transform 15 4842 env9853 = env9854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4842 env9853 == env9854) = true)

theorem identity9854 : scanCanonicalize (H12AffineFastState.compose env9854 (packedSelected [1,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 3671) := by decide +kernel

theorem selectedBound9854 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env9855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3671,4177,3930,4842,1345,262144,1024,3930,4096,397,5456,7348,3807,5376,262281,4177,1296,5303,1284,5069,257,3679,1344,512]

theorem envBound9855 : H12AffineFastState.Bounded env9855 := by
  intro p hp
  have h : env9855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9854_9855 : H12AffineEnvironment.transform 12 3671 env9854 = env9855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3671 env9854 == env9855) = true)

theorem identity9855 : scanCanonicalize (H12AffineFastState.compose env9855 (packedSelected [3,5,15] rootPS)) = affineNative (2^(17+1) ^^^ 5403) := by decide +kernel

theorem selectedBound9855 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env9856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3671,4177,3930,4842,1345,5403,1024,3930,4096,397,5456,7348,3807,5376,5522,4177,1296,5303,1284,5069,257,3679,1344,512]

theorem envBound9856 : H12AffineFastState.Bounded env9856 := by
  intro p hp
  have h : env9856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9855_9856 : H12AffineEnvironment.transform 17 5403 env9855 = env9856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5403 env9855 == env9856) = true)

theorem identity9856 : scanCanonicalize (H12AffineFastState.compose env9856 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 1014) := by decide +kernel

theorem selectedBound9856 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env9857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1014,4096,1441,4177,1196,4842,1345,5403,1024,1196,4096,397,5456,5954,1321,5376,5522,4177,1296,5303,1284,5069,257,1449,1344,512]

theorem envBound9857 : H12AffineFastState.Bounded env9857 := by
  intro p hp
  have h : env9857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9856_9857 : H12AffineEnvironment.transform 10 1014 env9856 = env9857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1014 env9856 == env9857) = true)

theorem identity9857 : scanCanonicalize (H12AffineFastState.compose env9857 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound9857 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1014,233,1441,184,1196,515,1345,1522,1024,1196,233,397,1465,1963,1321,1513,1403,184,1296,1118,1284,804,257,1449,1344,512]

theorem envBound9858 : H12AffineFastState.Bounded env9858 := by
  intro p hp
  have h : env9858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9857_9858 : H12AffineEnvironment.transform 11 233 env9857 = env9858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env9857 == env9858) = true)

theorem identity9858 : scanCanonicalize (H12AffineFastState.compose env9858 (packedSelected [18,23] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound9858 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env9859 : List Nat := [2,4,8,16,32,64,128,256,512,801,1014,233,640,184,909,515,608,723,801,909,233,397,664,138,520,712,602,184,561,895,549,804,257,648,609,512]

theorem envBound9859 : H12AffineFastState.Bounded env9859 := by
  intro p hp
  have h : env9859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9858_9859 : H12AffineEnvironment.transform 9 801 env9858 = env9859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env9858 == env9859) = true)

theorem identity9859 : scanCanonicalize (H12AffineFastState.compose env9859 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound9859 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9860 : List Nat := [2,4,8,16,32,64,128,256,91,378,429,233,219,184,470,88,59,136,378,470,233,397,195,138,83,147,1,184,106,292,126,383,257,211,58,91]

theorem envBound9860 : H12AffineFastState.Bounded env9860 := by
  intro p hp
  have h : env9860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9859_9860 : H12AffineEnvironment.transform 8 91 env9859 = env9860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env9859 == env9860) = true)

def env9861 : List Nat := [2,4,8,16,32,64,8,256,91,378,293,97,83,48,350,88,59,0,378,350,97,261,75,2,83,27,1,48,106,292,126,383,257,91,58,91]

theorem envBound9861 : H12AffineFastState.Bounded env9861 := by
  intro p hp
  have h : env9861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9860_9861 : H12AffineEnvironment.transform 6 8 env9860 = env9861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9860 == env9861) = true)

theorem identity9861 : scanCanonicalize (H12AffineFastState.compose env9861 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 40) := by decide +kernel

theorem selectedBound9861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9862 : List Nat := [2,4,8,16,32,40,8,256,51,274,293,9,59,48,310,48,59,0,274,310,9,261,35,2,59,27,1,48,2,292,22,279,257,51,58,51]

theorem envBound9862 : H12AffineFastState.Bounded env9862 := by
  intro p hp
  have h : env9862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9861_9862 : H12AffineEnvironment.transform 5 40 env9861 = env9862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 40 env9861 == env9862) = true)

theorem identity9862 : scanCanonicalize (H12AffineFastState.compose env9862 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound9862 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9863 : List Nat := [2,4,8,16,32,40,8,46,51,60,11,9,59,48,24,48,59,0,60,24,9,43,35,2,59,27,1,48,2,10,22,57,47,51,58,51]

theorem envBound9863 : H12AffineFastState.Bounded env9863 := by
  intro p hp
  have h : env9863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9862_9863 : H12AffineEnvironment.transform 7 46 env9862 = env9863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env9862 == env9863) = true)

def env9864 : List Nat := [2,4,8,16,32,64,9,256,91,378,292,96,82,49,351,88,59,1,378,351,96,260,74,3,83,26,1,49,106,292,126,383,257,90,58,91]

theorem envBound9864 : H12AffineFastState.Bounded env9864 := by
  intro p hp
  have h : env9864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9860_9864 : H12AffineEnvironment.transform 6 9 env9860 = env9864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9860 == env9864) = true)

theorem identity9864 : scanCanonicalize (H12AffineFastState.compose env9864 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound9864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9865 : List Nat := [2,4,8,3,32,64,9,256,72,361,292,96,65,34,332,75,40,1,361,332,96,260,74,3,64,9,1,34,106,292,109,364,257,73,41,72]

theorem envBound9865 : H12AffineFastState.Bounded env9865 := by
  intro p hp
  have h : env9865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9864_9865 : H12AffineEnvironment.transform 3 3 env9864 = env9865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env9864 == env9865) = true)

theorem identity9865 : scanCanonicalize (H12AffineFastState.compose env9865 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9865 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9866 : List Nat := [2,4,8,3,32,64,9,36,72,77,0,96,65,34,104,75,40,1,77,104,96,32,74,3,64,9,1,34,106,0,109,72,37,73,41,72]

theorem envBound9866 : H12AffineFastState.Bounded env9866 := by
  intro p hp
  have h : env9866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9865_9866 : H12AffineEnvironment.transform 7 36 env9865 = env9866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9865 == env9866) = true)

theorem identity9866 : scanCanonicalize (H12AffineFastState.compose env9866 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9866 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9867 : List Nat := [2,4,3,3,32,64,2,36,67,70,0,96,65,34,99,64,35,1,70,99,96,32,65,3,64,2,1,34,97,0,102,67,37,66,34,67]

theorem envBound9867 : H12AffineFastState.Bounded env9867 := by
  intro p hp
  have h : env9867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9866_9867 : H12AffineEnvironment.transform 2 3 env9866 = env9867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9866 == env9867) = true)

theorem identity9867 : scanCanonicalize (H12AffineFastState.compose env9867 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound9867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9868 : List Nat := [2,4,3,3,32,35,2,36,32,37,0,3,34,34,0,35,35,1,37,0,3,32,34,3,35,2,1,34,2,0,5,32,37,33,34,32]

theorem envBound9868 : H12AffineFastState.Bounded env9868 := by
  intro p hp
  have h : env9868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9867_9868 : H12AffineEnvironment.transform 5 35 env9867 = env9868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env9867 == env9868) = true)

theorem identity9868 : scanCanonicalize (H12AffineFastState.compose env9868 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9869 : List Nat := [2,4,3,3,0,3,2,4,0,5,0,3,2,2,0,3,3,1,5,0,3,0,2,3,3,2,1,2,2,0,5,0,5,1,2,0]

theorem envBound9869 : H12AffineFastState.Bounded env9869 := by
  intro p hp
  have h : env9869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9868_9869 : H12AffineEnvironment.transform 4 0 env9868 = env9869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9868 == env9869) = true)

def leafEnv9869 : List Nat := [2,4,3,3,0,3,2,4,0,5,0,3,2,2,0,3,3,1,5,0,3,0,2,3,5,3,1,2,1,2,2,0,5,0,5,1,5,2,2,0,0,3,1]

def active9869 : List Nat := [0,1]

def tree9869 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9869 : H12WitnessSearch.Good tree9869 := H12GlobalWitnessIndex.good

theorem leafIdentity9869 : H12AffineFastState.composeSystem env9869 rootObs = leafEnv9869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9869 rootObs == leafEnv9869) = true)

theorem terminalChecked9869 : H12PackedTerminal.terminalCheckFast leafEnv9869 active9869 tree9869 = true := by decide +kernel

def env9870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32768,136513,4194304,17665,98564,33554432,5376,4609044,16384,131153,1073741824,1284,4294967296,257,4332954727,131073,33563272]

theorem envBound9870 : H12AffineFastState.Bounded env9870 := by
  intro p hp
  have h : env9870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9845_9870 : H12AffineEnvironment.transform 18 151825 env9845 = env9870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 151825 env9845 == env9870) = true)

theorem identity9870 : scanCanonicalize (H12AffineFastState.compose env9870 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 4315355) := by decide +kernel

theorem selectedBound9870 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32768,136513,4194304,17665,98564,33554432,5376,4609044,16384,131153,4315355,1284,4294967296,257,4332954727,131073,33563272]

theorem envBound9871 : H12AffineFastState.Bounded env9871 := by
  intro p hp
  have h : env9871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9870_9871 : H12AffineEnvironment.transform 29 4315355 env9870 = env9871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4315355 env9870 == env9871) = true)

theorem identity9871 : scanCanonicalize (H12AffineFastState.compose env9871 (packedSelected [3,6,10,24,25,26] rootPS)) = affineNative (2^(24+1) ^^^ 140745) := by decide +kernel

theorem selectedBound9871 : packedSelected [3,6,10,24,25,26] rootPS < 2^1333 := by decide +kernel

def env9872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32768,136513,4194304,17665,98564,140745,5376,4609044,16384,131153,4315355,1284,4294967296,257,4299260334,131073,132929]

theorem envBound9872 : H12AffineFastState.Bounded env9872 := by
  intro p hp
  have h : env9872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9871_9872 : H12AffineEnvironment.transform 24 140745 env9871 = env9872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 140745 env9871 == env9872) = true)

theorem identity9872 : scanCanonicalize (H12AffineFastState.compose env9872 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 21777) := by decide +kernel

theorem selectedBound9872 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1024,32768,16464,4194304,17665,98564,28888,5376,4456709,16384,21824,4315355,1284,4294967296,257,4299260334,21776,21072]

theorem envBound9873 : H12AffineFastState.Bounded env9873 := by
  intro p hp
  have h : env9873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9872_9873 : H12AffineEnvironment.transform 16 21777 env9872 = env9873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21777 env9872 == env9873) = true)

theorem identity9873 : scanCanonicalize (H12AffineFastState.compose env9873 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound9873 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env9874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1024,32768,4096,4194304,5457,98564,8328,5376,4456709,4176,1296,4294795,1284,4294967296,257,4299260334,1344,512]

theorem envBound9874 : H12AffineFastState.Bounded env9874 := by
  intro p hp
  have h : env9874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9873_9874 : H12AffineEnvironment.transform 13 4176 env9873 = env9874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9873 == env9874) = true)

theorem identity9874 : scanCanonicalize (H12AffineFastState.compose env9874 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 4240205) := by decide +kernel

theorem selectedBound9874 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1024,32768,4096,4194304,5457,98564,8328,5376,4456709,4176,1296,4294795,1284,4240205,257,78563,1344,512]

theorem envBound9875 : H12AffineFastState.Bounded env9875 := by
  intro p hp
  have h : env9875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9874_9875 : H12AffineEnvironment.transform 31 4240205 env9874 = env9875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4240205 env9874 == env9875) = true)

theorem identity9875 : scanCanonicalize (H12AffineFastState.compose env9875 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound9875 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,100523,1024,32768,4096,4194304,5457,98564,8328,5376,4295086,4176,1296,4294795,1284,4240205,257,78563,1344,512]

theorem envBound9876 : H12AffineFastState.Bounded env9876 := by
  intro p hp
  have h : env9876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9875_9876 : H12AffineEnvironment.transform 17 100523 env9875 = env9876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env9875 == env9876) = true)

theorem identity9876 : scanCanonicalize (H12AffineFastState.compose env9876 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound9876 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,100523,1024,32768,4096,396,5457,98564,8328,5376,100386,4176,1296,100615,1284,45761,257,78563,1344,512]

theorem envBound9877 : H12AffineFastState.Bounded env9877 := by
  intro p hp
  have h : env9877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9876_9877 : H12AffineEnvironment.transform 21 396 env9876 = env9877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env9876 == env9877) = true)

theorem identity9877 : scanCanonicalize (H12AffineFastState.compose env9877 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 1962) := by decide +kernel

theorem selectedBound9877 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,1962,1345,36609,1024,32768,4096,396,5457,34478,8328,5376,36744,4176,1296,36525,1284,45761,257,13641,1344,512]

theorem envBound9878 : H12AffineFastState.Bounded env9878 := by
  intro p hp
  have h : env9878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9877_9878 : H12AffineEnvironment.transform 15 1962 env9877 = env9878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1962 env9877 == env9878) = true)

theorem identity9878 : scanCanonicalize (H12AffineFastState.compose env9878 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9878 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env9879 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,1315,1345,36232,1024,32768,4096,396,5457,33831,8328,5376,36097,4176,1296,35876,1284,45128,257,13641,1344,137]

theorem envBound9879 : H12AffineFastState.Bounded env9879 := by
  intro p hp
  have h : env9879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9878_9879 : H12AffineEnvironment.transform 8 137 env9878 = env9879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9878 == env9879) = true)

theorem identity9879 : scanCanonicalize (H12AffineFastState.compose env9879 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 15588) := by decide +kernel

theorem selectedBound9879 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9880 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,15588,1315,1345,12652,1024,15588,4096,396,5457,14531,8328,5376,12773,4176,1296,12480,1284,3244,257,13641,1344,137]

theorem envBound9880 : H12AffineFastState.Bounded env9880 := by
  intro p hp
  have h : env9880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9879_9880 : H12AffineEnvironment.transform 14 15588 env9879 = env9880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15588 env9879 == env9880) = true)

theorem identity9880 : scanCanonicalize (H12AffineFastState.compose env9880 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound9880 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9881 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,2209,4176,5189,1315,1345,6605,1024,5189,4096,396,5457,4194,2089,5376,6468,4176,1296,6241,1284,3244,257,7656,1344,137]

theorem envBound9881 : H12AffineFastState.Bounded env9881 := by
  intro p hp
  have h : env9881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9880_9881 : H12AffineEnvironment.transform 12 2209 env9880 = env9881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env9880 == env9881) = true)

theorem identity9881 : scanCanonicalize (H12AffineFastState.compose env9881 (packedSelected [1,12,21] rootPS)) = affineNative (2^(11+1) ^^^ 3560) := by decide +kernel

theorem selectedBound9881 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env9882 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,3560,2209,3512,2477,1315,1345,1061,1024,2477,3560,396,2233,3466,2089,2280,1196,3512,1296,1417,1284,3244,257,0,1344,137]

theorem envBound9882 : H12AffineFastState.Bounded env9882 := by
  intro p hp
  have h : env9882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9881_9882 : H12AffineEnvironment.transform 11 3560 env9881 = env9882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3560 env9881 == env9882) = true)

theorem identity9882 : scanCanonicalize (H12AffineFastState.compose env9882 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound9882 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env9883 : List Nat := [2,4,8,16,32,64,128,256,137,1024,169,1345,8,1297,260,1315,1345,1061,1024,260,1345,396,16,1315,128,65,1196,1297,1296,1417,1284,1029,257,0,1344,137]

theorem envBound9883 : H12AffineFastState.Bounded env9883 := by
  intro p hp
  have h : env9883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9882_9883 : H12AffineEnvironment.transform 10 169 env9882 = env9883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env9882 == env9883) = true)

theorem identity9883 : scanCanonicalize (H12AffineFastState.compose env9883 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 246) := by decide +kernel

theorem selectedBound9883 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9884 : List Nat := [2,4,8,16,32,64,128,246,137,1024,169,1207,8,1255,242,1237,1207,1061,1024,242,1207,122,16,1237,128,65,1196,1255,1254,1151,1266,1029,247,0,1206,137]

theorem envBound9884 : H12AffineFastState.Bounded env9884 := by
  intro p hp
  have h : env9884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9883_9884 : H12AffineEnvironment.transform 7 246 env9883 = env9884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 246 env9883 == env9884) = true)

theorem identity9884 : scanCanonicalize (H12AffineFastState.compose env9884 (packedSelected [0,2,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 206) := by decide +kernel

theorem selectedBound9884 : packedSelected [0,2,7,9] rootPS < 2^1333 := by decide +kernel

def env9885 : List Nat := [2,4,8,16,32,64,128,246,137,206,169,121,8,41,242,27,121,235,206,242,121,122,16,27,128,65,98,41,40,177,60,203,247,0,120,137]

theorem envBound9885 : H12AffineFastState.Bounded env9885 := by
  intro p hp
  have h : env9885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9884_9885 : H12AffineEnvironment.transform 9 206 env9884 = env9885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 206 env9884 == env9885) = true)

theorem identity9885 : scanCanonicalize (H12AffineFastState.compose env9885 (packedSelected [0,2,4,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound9885 : packedSelected [0,2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env9886 : List Nat := [2,4,8,16,32,64,16,102,25,94,57,121,8,41,98,27,121,123,94,98,121,122,16,27,16,65,98,41,40,33,60,91,103,0,120,25]

theorem envBound9886 : H12AffineFastState.Bounded env9886 := by
  intro p hp
  have h : env9886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9885_9886 : H12AffineEnvironment.transform 6 16 env9885 = env9886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env9885 == env9886) = true)

theorem identity9886 : scanCanonicalize (H12AffineFastState.compose env9886 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9886 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9887 : List Nat := [2,4,8,16,32,16,16,54,25,14,57,41,8,41,50,27,41,43,14,50,41,42,16,27,16,17,50,41,40,33,60,11,55,0,40,25]

theorem envBound9887 : H12AffineFastState.Bounded env9887 := by
  intro p hp
  have h : env9887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9886_9887 : H12AffineEnvironment.transform 5 16 env9886 = env9887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9886 == env9887) = true)

theorem identity9887 : scanCanonicalize (H12AffineFastState.compose env9887 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound9887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9888 : List Nat := [2,4,8,16,2,16,16,20,25,14,27,11,8,11,16,27,11,9,14,16,11,8,16,27,16,17,16,11,10,3,30,11,21,0,10,25]

theorem envBound9888 : H12AffineFastState.Bounded env9888 := by
  intro p hp
  have h : env9888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9887_9888 : H12AffineEnvironment.transform 4 2 env9887 = env9888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env9887 == env9888) = true)

theorem identity9888 : scanCanonicalize (H12AffineFastState.compose env9888 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9888 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9889 : List Nat := [2,4,3,16,2,16,16,20,18,5,16,0,3,0,16,16,0,2,5,16,0,3,16,16,16,17,16,0,1,3,21,0,21,0,1,18]

theorem envBound9889 : H12AffineFastState.Bounded env9889 := by
  intro p hp
  have h : env9889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9888_9889 : H12AffineEnvironment.transform 2 3 env9888 = env9889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9888 == env9889) = true)

theorem identity9889 : scanCanonicalize (H12AffineFastState.compose env9889 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound9889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9890 : List Nat := [2,4,3,2,2,2,2,6,0,5,2,0,3,0,2,2,0,2,5,2,0,3,2,2,2,3,2,0,1,3,7,0,7,0,1,0]

theorem envBound9890 : H12AffineFastState.Bounded env9890 := by
  intro p hp
  have h : env9890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9889_9890 : H12AffineEnvironment.transform 3 2 env9889 = env9890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env9889 == env9890) = true)

theorem identity9890 : scanCanonicalize (H12AffineFastState.compose env9890 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound9890 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9891 : List Nat := [0,4,1,0,0,0,0,4,0,5,0,0,1,0,0,0,0,0,5,0,0,1,0,0,0,1,0,0,1,1,5,0,5,0,1,0]

theorem envBound9891 : H12AffineFastState.Bounded env9891 := by
  intro p hp
  have h : env9891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9890_9891 : H12AffineEnvironment.transform 0 0 env9890 = env9891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env9890 == env9891) = true)

def env9892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,5377,21484816,16385,131153,1073741824,16876544,4294967296,257,4350047347,131073,33563272]

theorem envBound9892 : H12AffineFastState.Bounded env9892 := by
  intro p hp
  have h : env9892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9843_9892 : H12AffineEnvironment.transform 25 5377 env9843 = env9892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9843 == env9892) = true)

theorem identity9892 : scanCanonicalize (H12AffineFastState.compose env9892 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound9892 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,230469,33554432,5377,4477269,16385,131153,1073741824,131141,4294967296,257,4333498422,131073,33563272]

theorem envBound9893 : H12AffineFastState.Bounded env9893 := by
  intro p hp
  have h : env9893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9892_9893 : H12AffineEnvironment.transform 23 230469 env9892 = env9893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env9892 == env9893) = true)

def env9894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131392,32768,136513,4194304,17665,230469,33554432,5377,4477269,16385,131153,1073741824,131141,4294967296,257,4332843382,131073,33563272]

theorem envBound9894 : H12AffineFastState.Bounded env9894 := by
  intro p hp
  have h : env9894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9893_9894 : H12AffineEnvironment.transform 18 131392 env9893 = env9894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131392 env9893 == env9894) = true)

theorem identity9894 : scanCanonicalize (H12AffineFastState.compose env9894 (packedSelected [3,4,6,7,9,10,16,20,24,25,26,27] rootPS)) = affineNative (2^(29+1) ^^^ 37877843) := by decide +kernel

theorem selectedBound9894 : packedSelected [3,4,6,7,9,10,16,20,24,25,26,27] rootPS < 2^1333 := by decide +kernel

def env9895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131392,32768,136513,4194304,17665,230469,33554432,5377,4477269,16385,131153,37877843,131141,4294967296,257,4332843382,131073,33563272]

theorem envBound9895 : H12AffineFastState.Bounded env9895 := by
  intro p hp
  have h : env9895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9894_9895 : H12AffineEnvironment.transform 29 37877843 env9894 = env9895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 37877843 env9894 == env9895) = true)

theorem identity9895 : scanCanonicalize (H12AffineFastState.compose env9895 (packedSelected [1,6,19,25,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9895 : packedSelected [1,6,19,25,28,31] rootPS < 2^1333 := by decide +kernel

def env9896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131392,32768,136513,4194304,17665,230469,8329,5377,4477269,16385,131153,4315354,131141,4294967296,257,4299280895,131073,513]

theorem envBound9896 : H12AffineFastState.Bounded env9896 := by
  intro p hp
  have h : env9896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9895_9896 : H12AffineEnvironment.transform 24 8329 env9895 = env9896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9895 == env9896) = true)

theorem identity9896 : scanCanonicalize (H12AffineFastState.compose env9896 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9896 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17665,98565,8329,5377,4477269,16385,1297,4315354,1285,4294967296,257,4299280895,1345,513]

theorem envBound9897 : H12AffineFastState.Bounded env9897 := by
  intro p hp
  have h : env9897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9896_9897 : H12AffineEnvironment.transform 16 1344 env9896 = env9897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9896 == env9897) = true)

theorem identity9897 : scanCanonicalize (H12AffineFastState.compose env9897 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9897 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,4194304,5456,98565,8329,5377,4456708,4176,1297,4294795,1285,4294967296,257,4299260334,1345,513]

theorem envBound9898 : H12AffineFastState.Bounded env9898 := by
  intro p hp
  have h : env9898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9897_9898 : H12AffineEnvironment.transform 13 4177 env9897 = env9898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9897 == env9898) = true)

theorem identity9898 : scanCanonicalize (H12AffineFastState.compose env9898 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound9898 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13973,65536,1344,262144,1024,13973,4097,4194304,5456,79760,8329,5377,4456708,4176,1297,4275742,1285,4294967296,257,4299241275,1345,513]

theorem envBound9899 : H12AffineFastState.Bounded env9899 := by
  intro p hp
  have h : env9899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9898_9899 : H12AffineEnvironment.transform 14 13973 env9898 = env9899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env9898 == env9899) = true)

theorem identity9899 : scanCanonicalize (H12AffineFastState.compose env9899 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 13714) := by decide +kernel

theorem selectedBound9899 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13973,13714,1344,262144,1024,13973,4097,4194304,5456,514,8329,5377,4456708,4176,1297,4197260,1285,4294967296,257,4299162281,1345,513]

theorem envBound9900 : H12AffineFastState.Bounded env9900 := by
  intro p hp
  have h : env9900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9899_9900 : H12AffineEnvironment.transform 15 13714 env9899 = env9900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13714 env9899 == env9900) = true)

theorem identity9900 : scanCanonicalize (H12AffineFastState.compose env9900 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9900 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9901 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,13340,13714,1344,262144,1024,13340,4097,4194304,5456,139,8329,5377,4456708,4176,1297,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound9901 : H12AffineFastState.Bounded env9901 := by
  intro p hp
  have h : env9901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9900_9901 : H12AffineEnvironment.transform 8 137 env9900 = env9901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9900 == env9901) = true)

theorem identity9901 : scanCanonicalize (H12AffineFastState.compose env9901 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 7221) := by decide +kernel

theorem selectedBound9901 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9902 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,13340,13714,1344,7221,1024,13340,4097,4194304,5456,139,8329,5377,4201777,4176,1297,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound9902 : H12AffineFastState.Bounded env9902 := by
  intro p hp
  have h : env9902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9901_9902 : H12AffineEnvironment.transform 17 7221 env9901 = env9902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7221 env9901 == env9902) = true)

theorem identity9902 : scanCanonicalize (H12AffineFastState.compose env9902 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound9902 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9903 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,4096,8192,4177,13340,13643,1344,7221,1024,13340,4097,4194304,5456,82,8272,5377,4201777,4176,1297,4196613,1285,4294967296,257,4299161632,1345,81]

theorem envBound9903 : H12AffineFastState.Bounded env9903 := by
  intro p hp
  have h : env9903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9902_9903 : H12AffineEnvironment.transform 6 89 env9902 = env9903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env9902 == env9903) = true)

theorem identity9903 : scanCanonicalize (H12AffineFastState.compose env9903 (packedSelected [1,12] rootPS)) = affineNative (2^(21+1) ^^^ 5499) := by decide +kernel

theorem selectedBound9903 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env9904 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,4096,8192,4177,13340,13643,1344,7221,1024,13340,4097,5499,5456,82,8272,5377,2122,4176,1297,7294,1285,4294967296,257,4294972763,1345,81]

theorem envBound9904 : H12AffineFastState.Bounded env9904 := by
  intro p hp
  have h : env9904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9903_9904 : H12AffineEnvironment.transform 21 5499 env9903 = env9904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5499 env9903 == env9904) = true)

def env9905 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1296,8192,1345,8460,8283,1344,2341,1024,8460,1297,107,64,82,8272,17,2122,1344,1297,2414,1285,4294967296,257,4294967371,1345,81]

theorem envBound9905 : H12AffineFastState.Bounded env9905 := by
  intro p hp
  have h : env9905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9904_9905 : H12AffineEnvironment.transform 11 1296 env9904 = env9905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9904 == env9905) = true)

theorem identity9905 : scanCanonicalize (H12AffineFastState.compose env9905 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9906 : List Nat := [2,4,8,16,32,64,89,37,80,1024,2048,1077,8192,1124,8233,8283,1125,2048,1024,8233,1076,107,64,82,8272,17,2122,1125,1076,2123,1056,4294967296,36,4294967371,1124,81]

theorem envBound9906 : H12AffineFastState.Bounded env9906 := by
  intro p hp
  have h : env9906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9905_9906 : H12AffineEnvironment.transform 7 37 env9905 = env9906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9905 == env9906) = true)

theorem identity9906 : scanCanonicalize (H12AffineFastState.compose env9906 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound9906 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9907 : List Nat := [2,4,8,16,32,64,89,37,80,1024,2048,1077,2089,1124,2048,2162,1125,2048,1024,2048,1076,107,64,82,2169,17,2122,1125,1076,2123,1056,4294967296,36,4294967371,1124,81]

theorem envBound9907 : H12AffineFastState.Bounded env9907 := by
  intro p hp
  have h : env9907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9906_9907 : H12AffineEnvironment.transform 12 2089 env9906 = env9907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env9906 == env9907) = true)

theorem identity9907 : scanCanonicalize (H12AffineFastState.compose env9907 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 96) := by decide +kernel

theorem selectedBound9907 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9908 : List Nat := [2,4,8,16,32,64,89,37,80,1024,2048,1077,2089,1124,2048,2162,1125,2048,1024,2048,1076,107,64,82,2169,17,2122,1125,1076,2123,1056,96,36,43,1124,81]

theorem envBound9908 : H12AffineFastState.Bounded env9908 := by
  intro p hp
  have h : env9908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9907_9908 : H12AffineEnvironment.transform 31 96 env9907 = env9908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 96 env9907 == env9908) = true)

theorem identity9908 : scanCanonicalize (H12AffineFastState.compose env9908 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9908 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9909 : List Nat := [2,4,8,16,32,11,18,37,27,1024,2048,1077,2089,1071,2048,2105,1070,2048,1024,2048,1076,32,11,25,2098,17,2049,1070,1076,2048,1056,43,36,43,1071,26]

theorem envBound9909 : H12AffineFastState.Bounded env9909 := by
  intro p hp
  have h : env9909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9908_9909 : H12AffineEnvironment.transform 5 11 env9908 = env9909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9908 == env9909) = true)

def leafEnv9909 : List Nat := [2,4,8,16,32,11,18,37,27,1024,2048,1077,2089,1071,2048,2105,1070,2048,1024,2048,1076,32,11,25,1056,2098,1,17,2049,1070,1076,2048,1056,43,36,43,5,2083,1071,26,0,1077,1]

def active9909 : List Nat := [0,1,2,3,4,9,10]

def tree9909 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9909 : H12WitnessSearch.Good tree9909 := H12GlobalWitnessIndex.good

theorem leafIdentity9909 : H12AffineFastState.composeSystem env9909 rootObs = leafEnv9909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9909 rootObs == leafEnv9909) = true)

theorem terminalChecked9909 : H12PackedTerminal.terminalCheckFast leafEnv9909 active9909 tree9909 = true := by decide +kernel

def env9910 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1297,8192,1344,8461,8282,1344,2340,1024,8461,1296,106,65,82,8272,16,2122,1345,1297,2415,1285,4294967296,257,4294967370,1345,81]

theorem envBound9910 : H12AffineFastState.Bounded env9910 := by
  intro p hp
  have h : env9910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9904_9910 : H12AffineEnvironment.transform 11 1297 env9904 = env9910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9904 == env9910) = true)

theorem identity9910 : scanCanonicalize (H12AffineFastState.compose env9910 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2146) := by decide +kernel

theorem selectedBound9910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9911 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1297,2146,1344,2415,2104,1344,2340,1024,2415,1296,106,65,82,2098,16,2122,1345,1297,2415,1285,4294967296,257,4294967370,1345,81]

theorem envBound9911 : H12AffineFastState.Bounded env9911 := by
  intro p hp
  have h : env9911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9910_9911 : H12AffineEnvironment.transform 12 2146 env9910 = env9911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2146 env9910 == env9911) = true)

theorem identity9911 : scanCanonicalize (H12AffineFastState.compose env9911 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 48) := by decide +kernel

theorem selectedBound9911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9912 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1297,2146,1344,2415,2104,1344,2340,1024,2415,1296,106,65,82,2098,16,2122,1345,1297,2415,1285,48,257,122,1345,81]

theorem envBound9912 : H12AffineFastState.Bounded env9912 := by
  intro p hp
  have h : env9912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9911_9912 : H12AffineEnvironment.transform 31 48 env9911 = env9912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 48 env9911 == env9912) = true)

theorem identity9912 : scanCanonicalize (H12AffineFastState.compose env9912 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9912 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9913 : List Nat := [2,4,8,16,32,64,89,37,80,1024,2048,1076,2146,1125,2122,2104,1125,2049,1024,2122,1077,106,65,82,2098,16,2122,1124,1076,2122,1056,48,36,122,1124,81]

theorem envBound9913 : H12AffineFastState.Bounded env9913 := by
  intro p hp
  have h : env9913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9912_9913 : H12AffineEnvironment.transform 7 37 env9912 = env9913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9912 == env9913) = true)

theorem identity9913 : scanCanonicalize (H12AffineFastState.compose env9913 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9913 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9914 : List Nat := [2,4,8,16,32,10,19,37,26,1024,2048,1076,2088,1071,2048,2104,1071,2049,1024,2048,1077,32,11,24,2098,16,2048,1070,1076,2048,1056,48,36,48,1070,27]

theorem envBound9914 : H12AffineFastState.Bounded env9914 := by
  intro p hp
  have h : env9914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9913_9914 : H12AffineEnvironment.transform 5 10 env9913 = env9914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9913 == env9914) = true)

def leafEnv9914 : List Nat := [2,4,8,16,32,10,19,37,26,1024,2048,1076,2088,1071,2048,2104,1071,2049,1024,2048,1077,32,11,24,1056,2098,1,16,2048,1070,1076,2048,1056,48,36,48,5,2083,1070,27,0,1077,1]

def active9914 : List Nat := [0,1,2,3,4,9,10]

def tree9914 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9914 : H12WitnessSearch.Good tree9914 := H12GlobalWitnessIndex.good

theorem leafIdentity9914 : H12AffineFastState.composeSystem env9914 rootObs = leafEnv9914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9914 rootObs == leafEnv9914) = true)

theorem terminalChecked9914 : H12PackedTerminal.terminalCheckFast leafEnv9914 active9914 tree9914 = true := by decide +kernel

def env9915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131393,32768,136513,4194304,17665,230469,33554432,5377,4477269,16385,131153,1073741824,131141,4294967296,257,4332843383,131073,33563272]

theorem envBound9915 : H12AffineFastState.Bounded env9915 := by
  intro p hp
  have h : env9915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9893_9915 : H12AffineEnvironment.transform 18 131393 env9893 = env9915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131393 env9893 == env9915) = true)

theorem identity9915 : scanCanonicalize (H12AffineFastState.compose env9915 (packedSelected [3,4,6,7,9,10,16,20,24,25,26,27] rootPS)) = affineNative (2^(29+1) ^^^ 37857283) := by decide +kernel

theorem selectedBound9915 : packedSelected [3,4,6,7,9,10,16,20,24,25,26,27] rootPS < 2^1333 := by decide +kernel

def env9916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131393,32768,136513,4194304,17665,230469,33554432,5377,4477269,16385,131153,37857283,131141,4294967296,257,4332843383,131073,33563272]

theorem envBound9916 : H12AffineFastState.Bounded env9916 := by
  intro p hp
  have h : env9916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9915_9916 : H12AffineEnvironment.transform 29 37857283 env9915 = env9916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 37857283 env9915 == env9916) = true)

theorem identity9916 : scanCanonicalize (H12AffineFastState.compose env9916 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9916 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env9917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17665,98565,33554432,5377,4477269,16385,1297,37857283,1285,4294967296,257,4332843383,1345,33563272]

theorem envBound9917 : H12AffineFastState.Bounded env9917 := by
  intro p hp
  have h : env9917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9916_9917 : H12AffineEnvironment.transform 16 1344 env9916 = env9917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9916 == env9917) = true)

theorem identity9917 : scanCanonicalize (H12AffineFastState.compose env9917 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9917 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env9918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17665,98565,8329,5377,4477269,16385,1297,4294794,1285,4294967296,257,4299280894,1345,513]

theorem envBound9918 : H12AffineFastState.Bounded env9918 := by
  intro p hp
  have h : env9918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9917_9918 : H12AffineEnvironment.transform 24 8329 env9917 = env9918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9917 == env9918) = true)

theorem identity9918 : scanCanonicalize (H12AffineFastState.compose env9918 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9918 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9919 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17665,98565,8329,5377,4477269,16385,1297,4294794,1285,4294967296,257,4299280894,1345,136]

theorem envBound9919 : H12AffineFastState.Bounded env9919 := by
  intro p hp
  have h : env9919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9918_9919 : H12AffineEnvironment.transform 8 137 env9918 = env9919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9918 == env9919) = true)

theorem identity9919 : scanCanonicalize (H12AffineFastState.compose env9919 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound9919 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9920 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,33167,1344,262144,1025,32768,4097,4194304,17665,138,8329,5377,4477269,16385,1297,4196613,1285,4294967296,257,4299182193,1345,136]

theorem envBound9920 : H12AffineFastState.Bounded env9920 := by
  intro p hp
  have h : env9920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9919_9920 : H12AffineEnvironment.transform 15 33167 env9919 = env9920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env9919 == env9920) = true)

theorem identity9920 : scanCanonicalize (H12AffineFastState.compose env9920 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9920 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9921 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,33167,1344,262144,1025,32768,4097,4194304,5456,138,8329,5377,4456708,4176,1297,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound9921 : H12AffineFastState.Bounded env9921 := by
  intro p hp
  have h : env9921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9920_9921 : H12AffineEnvironment.transform 13 4177 env9920 = env9921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9920 == env9921) = true)

theorem identity9921 : scanCanonicalize (H12AffineFastState.compose env9921 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound9921 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9922 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,33167,1344,43049,1025,32768,4097,4194304,5456,138,8329,5377,4237613,4176,1297,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound9922 : H12AffineFastState.Bounded env9922 := by
  intro p hp
  have h : env9922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9921_9922 : H12AffineEnvironment.transform 17 43049 env9921 = env9922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env9921 == env9922) = true)

theorem identity9922 : scanCanonicalize (H12AffineFastState.compose env9922 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound9922 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9923 : List Nat := [2,4,8,16,32,64,128,220,137,1024,2048,4096,8192,4177,32768,32851,1180,43049,1025,32768,4097,4194304,5260,138,8329,5341,4237553,4176,1229,4196569,1241,4294967296,221,4299161632,1181,136]

theorem envBound9923 : H12AffineFastState.Bounded env9923 := by
  intro p hp
  have h : env9923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9922_9923 : H12AffineEnvironment.transform 7 220 env9922 = env9923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env9922 == env9923) = true)

theorem identity9923 : scanCanonicalize (H12AffineFastState.compose env9923 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 1) := by decide +kernel

theorem selectedBound9923 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9924 : List Nat := [2,4,8,16,32,64,128,220,137,1024,2048,4096,8192,4177,32768,32851,1180,43049,1025,32768,4097,1,5260,138,8329,5341,43248,4176,1229,2264,1241,4294967296,221,4294967329,1181,136]

theorem envBound9924 : H12AffineFastState.Bounded env9924 := by
  intro p hp
  have h : env9924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9923_9924 : H12AffineEnvironment.transform 21 1 env9923 = env9924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env9923 == env9924) = true)

theorem identity9924 : scanCanonicalize (H12AffineFastState.compose env9924 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound9924 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9925 : List Nat := [2,4,8,16,32,64,128,220,137,1024,2048,4096,8192,4177,13340,13391,1180,7221,1025,13340,4097,1,5260,138,8329,5341,7404,4176,1229,2264,1241,4294967296,221,4294967329,1181,136]

theorem envBound9925 : H12AffineFastState.Bounded env9925 := by
  intro p hp
  have h : env9925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9924_9925 : H12AffineEnvironment.transform 14 13340 env9924 = env9925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env9924 == env9925) = true)

theorem identity9925 : scanCanonicalize (H12AffineFastState.compose env9925 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound9925 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env9926 : List Nat := [2,4,8,16,32,64,128,220,137,1024,2048,4096,5180,4177,32,115,1180,7221,1025,32,4097,1,5260,138,5301,5341,7404,4176,1229,2264,1241,4294967296,221,4294967329,1181,136]

theorem envBound9926 : H12AffineFastState.Bounded env9926 := by
  intro p hp
  have h : env9926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9925_9926 : H12AffineEnvironment.transform 12 5180 env9925 = env9926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env9925 == env9926) = true)

def env9927 : List Nat := [2,4,8,16,32,64,128,220,137,1024,216,4096,5180,4177,32,115,1180,5357,1025,32,4097,1,5260,138,5301,5341,5172,4176,1229,0,1241,4294967296,221,4294967329,1181,136]

theorem envBound9927 : H12AffineFastState.Bounded env9927 := by
  intro p hp
  have h : env9927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9926_9927 : H12AffineEnvironment.transform 10 216 env9926 = env9927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env9926 == env9927) = true)

theorem identity9927 : scanCanonicalize (H12AffineFastState.compose env9927 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound9927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9928 : List Nat := [2,4,8,16,32,64,128,220,137,1024,216,1077,9,1124,32,115,1180,216,1025,32,1076,1,185,138,128,232,1,1125,1229,0,1241,4294967296,221,4294967329,1181,136]

theorem envBound9928 : H12AffineFastState.Bounded env9928 := by
  intro p hp
  have h : env9928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9927_9928 : H12AffineEnvironment.transform 11 1077 env9927 = env9928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env9927 == env9928) = true)

theorem identity9928 : scanCanonicalize (H12AffineFastState.compose env9928 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9928 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9929 : List Nat := [2,4,8,16,32,64,120,36,113,1024,32,1077,9,1124,32,115,1124,32,1025,32,1076,1,65,114,120,16,1,1125,1077,0,1057,4294967296,37,4294967329,1125,112]

theorem envBound9929 : H12AffineFastState.Bounded env9929 := by
  intro p hp
  have h : env9929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9928_9929 : H12AffineEnvironment.transform 6 120 env9928 = env9929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9928 == env9929) = true)

theorem identity9929 : scanCanonicalize (H12AffineFastState.compose env9929 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 122) := by decide +kernel

theorem selectedBound9929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9930 : List Nat := [2,4,8,16,32,64,120,36,113,1024,32,1077,9,1124,32,115,1124,32,1025,32,1076,1,65,114,120,16,1,1125,1077,0,1057,122,37,91,1125,112]

theorem envBound9930 : H12AffineFastState.Bounded env9930 := by
  intro p hp
  have h : env9930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9929_9930 : H12AffineEnvironment.transform 31 122 env9929 = env9930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 122 env9929 == env9930) = true)

def env9931 : List Nat := [2,4,8,16,32,64,128,220,137,1024,217,4096,5180,4177,32,115,1180,5356,1025,32,4097,1,5260,138,5301,5341,5173,4176,1229,1,1241,4294967296,221,4294967329,1181,136]

theorem envBound9931 : H12AffineFastState.Bounded env9931 := by
  intro p hp
  have h : env9931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9926_9931 : H12AffineEnvironment.transform 10 217 env9926 = env9931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env9926 == env9931) = true)

theorem identity9931 : scanCanonicalize (H12AffineFastState.compose env9931 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9932 : List Nat := [2,4,8,16,32,64,121,37,112,1024,32,4096,5180,4177,32,115,1125,5141,1025,32,4097,1,5237,115,5196,5156,5173,4176,1076,1,1056,4294967296,36,4294967329,1124,113]

theorem envBound9932 : H12AffineFastState.Bounded env9932 := by
  intro p hp
  have h : env9932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9931_9932 : H12AffineEnvironment.transform 6 121 env9931 = env9932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9931 == env9932) = true)

theorem identity9932 : scanCanonicalize (H12AffineFastState.compose env9932 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9932 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env9933 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1,4096,5149,4177,1,82,1092,5141,1025,1,4097,1,5204,82,5196,5125,5140,4176,1045,1,1025,4294967296,5,4294967296,1093,80]

theorem envBound9933 : H12AffineFastState.Bounded env9933 := by
  intro p hp
  have h : env9933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9932_9933 : H12AffineEnvironment.transform 4 1 env9932 = env9933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9932 == env9933) = true)

theorem identity9933 : scanCanonicalize (H12AffineFastState.compose env9933 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9933 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9934 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,4096,5149,4122,1,25,1039,5141,1025,1,4097,1,5151,25,5127,5125,5140,4123,1045,1,1025,4294967296,5,4294967296,1038,27]

theorem envBound9934 : H12AffineFastState.Bounded env9934 := by
  intro p hp
  have h : env9934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9933_9934 : H12AffineEnvironment.transform 5 11 env9933 = env9934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9933 == env9934) = true)

def env9935 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1044,9,1038,1,25,1039,1,1025,1,1045,1,11,25,19,17,0,1039,1045,1,1025,4294967296,5,4294967296,1038,27]

theorem envBound9935 : H12AffineFastState.Bounded env9935 := by
  intro p hp
  have h : env9935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9934_9935 : H12AffineEnvironment.transform 11 1044 env9934 = env9935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env9934 == env9935) = true)

theorem identity9935 : scanCanonicalize (H12AffineFastState.compose env9935 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound9935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9936 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1044,9,1038,1,25,1039,1,1025,1,1045,1,11,25,19,17,0,1039,1045,1,1025,11,5,11,1038,27]

theorem envBound9936 : H12AffineFastState.Bounded env9936 := by
  intro p hp
  have h : env9936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9935_9936 : H12AffineEnvironment.transform 31 11 env9935 = env9936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env9935 == env9936) = true)

def leafEnv9936 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1044,9,1038,1,25,1039,1,1025,1,1045,1,11,25,1024,19,1,17,0,1039,1045,1,1025,11,5,11,5,3,1038,27,0,1044,1]

def active9936 : List Nat := [0,1,2,3,9]

def tree9936 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9936 : H12WitnessSearch.Good tree9936 := H12GlobalWitnessIndex.good

theorem leafIdentity9936 : H12AffineFastState.composeSystem env9936 rootObs = leafEnv9936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9936 rootObs == leafEnv9936) = true)

theorem terminalChecked9936 : H12PackedTerminal.terminalCheckFast leafEnv9936 active9936 tree9936 = true := by decide +kernel

def env9937 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1045,8,1039,1,25,1039,0,1025,1,1044,1,10,25,18,16,1,1038,1045,1,1025,4294967296,5,4294967296,1038,27]

theorem envBound9937 : H12AffineFastState.Bounded env9937 := by
  intro p hp
  have h : env9937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9934_9937 : H12AffineEnvironment.transform 11 1045 env9934 = env9937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env9934 == env9937) = true)

theorem identity9937 : scanCanonicalize (H12AffineFastState.compose env9937 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 16) := by decide +kernel

theorem selectedBound9937 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9938 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1045,8,1039,1,25,1039,0,1025,1,1044,1,10,25,18,16,1,1038,1045,1,1025,16,5,16,1038,27]

theorem envBound9938 : H12AffineFastState.Bounded env9938 := by
  intro p hp
  have h : env9938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9937_9938 : H12AffineEnvironment.transform 31 16 env9937 = env9938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 16 env9937 == env9938) = true)

def leafEnv9938 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1045,8,1039,1,25,1039,0,1025,1,1044,1,10,25,1024,18,1,16,1,1038,1045,1,1025,16,5,16,5,3,1038,27,0,1044,1]

def active9938 : List Nat := [0,1,2,3,9]

def tree9938 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9938 : H12WitnessSearch.Good tree9938 := H12GlobalWitnessIndex.good

theorem leafIdentity9938 : H12AffineFastState.composeSystem env9938 rootObs = leafEnv9938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9938 rootObs == leafEnv9938) = true)

theorem terminalChecked9938 : H12PackedTerminal.terminalCheckFast leafEnv9938 active9938 tree9938 = true := by decide +kernel

def env9939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,67108864,21484817,67130624,131152,1073741824,16876545,4294967296,256,4417151346,131073,33563272]

theorem envBound9939 : H12AffineFastState.Bounded env9939 := by
  intro p hp
  have h : env9939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9842_9939 : H12AffineEnvironment.transform 26 21484817 env9842 = env9939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21484817 env9842 == env9939) = true)

def env9940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,5376,21484817,16384,131152,1073741824,16876545,4294967296,256,4350047346,131073,33563272]

theorem envBound9940 : H12AffineFastState.Bounded env9940 := by
  intro p hp
  have h : env9940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9939_9940 : H12AffineEnvironment.transform 25 5376 env9939 = env9940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9939 == env9940) = true)

theorem identity9940 : scanCanonicalize (H12AffineFastState.compose env9940 (packedSelected [35] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9940 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17665,16777216,33554432,5376,21352529,16384,1296,1073741824,16876545,4294967296,256,4350047346,1345,33563272]

theorem envBound9941 : H12AffineFastState.Bounded env9941 := by
  intro p hp
  have h : env9941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9940_9941 : H12AffineEnvironment.transform 16 1344 env9940 = env9941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9940 == env9941) = true)

theorem identity9941 : scanCanonicalize (H12AffineFastState.compose env9941 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9941 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env9942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17665,16777216,8329,5376,21352529,16384,1296,1073741824,16876545,4294967296,256,4316484859,1345,513]

theorem envBound9942 : H12AffineFastState.Bounded env9942 := by
  intro p hp
  have h : env9942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9941_9942 : H12AffineEnvironment.transform 24 8329 env9941 = env9942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9941 == env9942) = true)

theorem identity9942 : scanCanonicalize (H12AffineFastState.compose env9942 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound9942 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17665,644436,8329,5376,4982021,16384,1296,1073741824,545109,4294967296,256,4299260335,1345,513]

theorem envBound9943 : H12AffineFastState.Bounded env9943 := by
  intro p hp
  have h : env9943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9942_9943 : H12AffineEnvironment.transform 23 644436 env9942 = env9943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env9942 == env9943) = true)

theorem identity9943 : scanCanonicalize (H12AffineFastState.compose env9943 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4840667) := by decide +kernel

theorem selectedBound9943 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17665,644436,8329,5376,4982021,16384,1296,4840667,545109,4294967296,256,4299260335,1345,513]

theorem envBound9944 : H12AffineFastState.Bounded env9944 := by
  intro p hp
  have h : env9944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9943_9944 : H12AffineEnvironment.transform 29 4840667 env9943 = env9944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4840667 env9943 == env9944) = true)

theorem identity9944 : scanCanonicalize (H12AffineFastState.compose env9944 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9944 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env9945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,524288,32768,4097,4194304,5456,623877,8329,5376,4982021,4177,1296,4820106,524548,4294967296,256,4299260335,1345,513]

theorem envBound9945 : H12AffineFastState.Bounded env9945 := by
  intro p hp
  have h : env9945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9944_9945 : H12AffineEnvironment.transform 13 4177 env9944 = env9945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9944 == env9945) = true)

theorem identity9945 : scanCanonicalize (H12AffineFastState.compose env9945 (packedSelected [6,25] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9945 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,4194304,5456,98564,8329,5376,4456708,4177,1296,4294795,1285,4294967296,256,4299260335,1345,513]

theorem envBound9946 : H12AffineFastState.Bounded env9946 := by
  intro p hp
  have h : env9946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9945_9946 : H12AffineEnvironment.transform 18 1025 env9945 = env9946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9945 == env9946) = true)

theorem identity9946 : scanCanonicalize (H12AffineFastState.compose env9946 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 99327) := by decide +kernel

theorem selectedBound9946 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,4194304,5456,98564,8329,5376,4456708,4177,1296,4294795,1285,99327,256,4194896,1345,513]

theorem envBound9947 : H12AffineFastState.Bounded env9947 := by
  intro p hp
  have h : env9947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9946_9947 : H12AffineEnvironment.transform 31 99327 env9946 = env9947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 99327 env9946 == env9947) = true)

theorem identity9947 : scanCanonicalize (H12AffineFastState.compose env9947 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 49073) := by decide +kernel

theorem selectedBound9947 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,49073,1025,32768,4097,4194304,5456,98564,8329,5376,4243125,4177,1296,4294795,1285,99327,256,4194896,1345,513]

theorem envBound9948 : H12AffineFastState.Bounded env9948 := by
  intro p hp
  have h : env9948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9947_9948 : H12AffineEnvironment.transform 17 49073 env9947 = env9948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49073 env9947 == env9948) = true)

theorem identity9948 : scanCanonicalize (H12AffineFastState.compose env9948 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound9948 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env9949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13972,65536,1344,2341,1025,13972,4097,4194304,5456,79760,8329,5376,4196385,4177,1296,4275743,1285,79211,256,4194896,1345,513]

theorem envBound9949 : H12AffineFastState.Bounded env9949 := by
  intro p hp
  have h : env9949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9948_9949 : H12AffineEnvironment.transform 14 13972 env9948 = env9949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env9948 == env9949) = true)

theorem identity9949 : scanCanonicalize (H12AffineFastState.compose env9949 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound9949 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1993,8460,65536,1344,2341,1025,8460,1945,4194304,712,73736,8329,664,4196385,1993,1296,4270471,1285,74483,256,4194896,1345,513]

theorem envBound9950 : H12AffineFastState.Bounded env9950 := by
  intro p hp
  have h : env9950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9949_9950 : H12AffineEnvironment.transform 11 1944 env9949 = env9950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env9949 == env9950) = true)

theorem identity9950 : scanCanonicalize (H12AffineFastState.compose env9950 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12065) := by decide +kernel

theorem selectedBound9950 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1993,8460,12065,1344,2341,1025,8460,1945,4194304,712,3881,8329,664,4196385,1993,1296,4196006,1285,3538,256,4194896,1345,513]

theorem envBound9951 : H12AffineFastState.Bounded env9951 := by
  intro p hp
  have h : env9951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9950_9951 : H12AffineEnvironment.transform 15 12065 env9950 = env9951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12065 env9950 == env9951) = true)

theorem identity9951 : scanCanonicalize (H12AffineFastState.compose env9951 (packedSelected [3,5,12,21] rootPS)) = affineNative (2^(21+1) ^^^ 3338) := by decide +kernel

theorem selectedBound9951 : packedSelected [3,5,12,21] rootPS < 2^1333 := by decide +kernel

def env9952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1993,8460,12065,1344,2341,1025,8460,1945,3338,712,3881,8329,664,1323,1993,1296,2988,1285,3538,256,3930,1345,513]

theorem envBound9952 : H12AffineFastState.Bounded env9952 := by
  intro p hp
  have h : env9952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9951_9952 : H12AffineEnvironment.transform 21 3338 env9951 = env9952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3338 env9951 == env9952) = true)

def env9953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,136513,4194304,17665,16777216,33554432,5377,21484817,16385,131152,1073741824,16876545,4294967296,256,4350047347,131073,33563272]

theorem envBound9953 : H12AffineFastState.Bounded env9953 := by
  intro p hp
  have h : env9953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9939_9953 : H12AffineEnvironment.transform 25 5377 env9939 = env9953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9939 == env9953) = true)

def env9954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,157794305,1073741824,140788816,4294967296,157663569,4417151346,131072,33563272]

theorem envBound9954 : H12AffineFastState.Bounded env9954 := by
  intro p hp
  have h : env9954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9840_9954 : H12AffineEnvironment.transform 28 157794305 env9840 = env9954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env9840 == env9954) = true)

theorem identity9954 : scanCanonicalize (H12AffineFastState.compose env9954 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound9954 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,157664576,1073741824,140788816,4294967296,157663569,4417151346,1345,33563272]

theorem envBound9955 : H12AffineFastState.Bounded env9955 := by
  intro p hp
  have h : env9955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9954_9955 : H12AffineEnvironment.transform 16 1345 env9954 = env9955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env9954 == env9955) = true)

def env9956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,23445584,67130624,1296,1073741824,16876544,4294967296,257,4417151346,1345,33563272]

theorem envBound9956 : H12AffineFastState.Bounded env9956 := by
  intro p hp
  have h : env9956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9955_9956 : H12AffineEnvironment.transform 26 23445584 env9955 = env9956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env9955 == env9956) = true)

def env9957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352528,67130624,1296,1073741824,16876544,4294967296,257,4417151346,1345,33563272]

theorem envBound9957 : H12AffineFastState.Bounded env9957 := by
  intro p hp
  have h : env9957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9956_9957 : H12AffineEnvironment.transform 20 4096 env9956 = env9957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9956 == env9957) = true)

theorem identity9957 : scanCanonicalize (H12AffineFastState.compose env9957 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9957 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,33554432,67108864,4477269,67130624,1296,1073741824,1285,4294967296,257,4400472183,1345,33563272]

theorem envBound9958 : H12AffineFastState.Bounded env9958 := by
  intro p hp
  have h : env9958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9957_9958 : H12AffineEnvironment.transform 23 98565 env9957 = env9958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9957 == env9958) = true)

def env9959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,33554432,5376,4477269,16384,1296,1073741824,1285,4294967296,257,4333368695,1345,33563272]

theorem envBound9959 : H12AffineFastState.Bounded env9959 := by
  intro p hp
  have h : env9959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9958_9959 : H12AffineEnvironment.transform 25 5376 env9958 = env9959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9958 == env9959) = true)

theorem identity9959 : scanCanonicalize (H12AffineFastState.compose env9959 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9959 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,8328,5376,4477269,16384,1296,1073741824,1285,4294967296,257,4299806207,1345,512]

theorem envBound9960 : H12AffineFastState.Bounded env9960 := by
  intro p hp
  have h : env9960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9959_9960 : H12AffineEnvironment.transform 24 8328 env9959 = env9960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9959 == env9960) = true)

theorem identity9960 : scanCanonicalize (H12AffineFastState.compose env9960 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(29+1) ^^^ 4279454) := by decide +kernel

theorem selectedBound9960 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,8328,5376,4477269,16384,1296,4279454,1285,4294967296,257,4299806207,1345,512]

theorem envBound9961 : H12AffineFastState.Bounded env9961 := by
  intro p hp
  have h : env9961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9960_9961 : H12AffineEnvironment.transform 29 4279454 env9960 = env9961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4279454 env9960 == env9961) = true)

theorem identity9961 : scanCanonicalize (H12AffineFastState.compose env9961 (packedSelected [4,16,22] rootPS)) = affineNative (2^(21+1) ^^^ 13509) := by decide +kernel

theorem selectedBound9961 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env9962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,13509,17665,98565,8328,5376,288144,16384,1296,96347,1285,4294967296,257,4295614778,1345,512]

theorem envBound9962 : H12AffineFastState.Bounded env9962 := by
  intro p hp
  have h : env9962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9961_9962 : H12AffineEnvironment.transform 21 13509 env9961 = env9962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 13509 env9961 == env9962) = true)

theorem identity9962 : scanCanonicalize (H12AffineFastState.compose env9962 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(31+1) ^^^ 788905) := by decide +kernel

theorem selectedBound9962 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env9963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,13509,17665,98565,8328,5376,288144,16384,1296,96347,1285,788905,257,387219,1345,512]

theorem envBound9963 : H12AffineFastState.Bounded env9963 := by
  intro p hp
  have h : env9963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9962_9963 : H12AffineEnvironment.transform 31 788905 env9962 = env9963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 788905 env9962 == env9963) = true)

theorem identity9963 : scanCanonicalize (H12AffineFastState.compose env9963 (packedSelected [4,6,9,16,25] rootPS)) = affineNative (2^(18+1) ^^^ 24857) := by decide +kernel

theorem selectedBound9963 : packedSelected [4,6,9,16,25] rootPS < 2^1333 := by decide +kernel

def env9964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,24857,32768,4096,13509,17665,98565,8328,5376,288144,16384,1296,96347,1285,288944,257,387219,1345,512]

theorem envBound9964 : H12AffineFastState.Bounded env9964 := by
  intro p hp
  have h : env9964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9963_9964 : H12AffineEnvironment.transform 18 24857 env9963 = env9964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 24857 env9963 == env9964) = true)

theorem identity9964 : scanCanonicalize (H12AffineFastState.compose env9964 (packedSelected [0,27] rootPS)) = affineNative (2^(14+1) ^^^ 5188) := by decide +kernel

theorem selectedBound9964 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env9965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5188,65536,1345,262144,24857,5188,4096,13509,17665,70977,8328,5376,288144,16384,1296,96347,1285,288944,257,359639,1345,512]

theorem envBound9965 : H12AffineFastState.Bounded env9965 := by
  intro p hp
  have h : env9965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9964_9965 : H12AffineEnvironment.transform 14 5188 env9964 = env9965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5188 env9964 == env9965) = true)

theorem identity9965 : scanCanonicalize (H12AffineFastState.compose env9965 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 66987) := by decide +kernel

theorem selectedBound9965 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5188,65536,1345,66987,24857,5188,4096,13509,17665,70977,8328,5376,90171,16384,1296,96347,1285,93467,257,31100,1345,512]

theorem envBound9966 : H12AffineFastState.Bounded env9966 := by
  intro p hp
  have h : env9966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9965_9966 : H12AffineEnvironment.transform 17 66987 env9965 = env9966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66987 env9965 == env9966) = true)

theorem identity9966 : scanCanonicalize (H12AffineFastState.compose env9966 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound9966 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,5188,65536,1345,66987,12617,5188,4096,13509,5457,70977,8328,5376,77931,4176,1296,75787,1285,81227,257,10540,1345,512]

theorem envBound9967 : H12AffineFastState.Bounded env9967 := by
  intro p hp
  have h : env9967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9966_9967 : H12AffineEnvironment.transform 13 4176 env9966 = env9967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9966 == env9967) = true)

theorem identity9967 : scanCanonicalize (H12AffineFastState.compose env9967 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 6508) := by decide +kernel

theorem selectedBound9967 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6508,4176,5188,65536,1345,66987,2085,5188,4096,3497,5457,70977,6628,5376,67847,4176,1296,69991,1285,66599,257,4160,1345,512]

theorem envBound9968 : H12AffineFastState.Bounded env9968 := by
  intro p hp
  have h : env9968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9967_9968 : H12AffineEnvironment.transform 12 6508 env9967 = env9968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6508 env9967 == env9968) = true)

def env9969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,33554432,5377,4477269,16385,1296,1073741824,1285,4294967296,257,4333368694,1345,33563272]

theorem envBound9969 : H12AffineFastState.Bounded env9969 := by
  intro p hp
  have h : env9969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9958_9969 : H12AffineEnvironment.transform 25 5377 env9958 = env9969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9958 == env9969) = true)

theorem identity9969 : scanCanonicalize (H12AffineFastState.compose env9969 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 554201) := by decide +kernel

theorem selectedBound9969 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,554201,5377,4477269,16385,1296,1073741824,1285,4294967296,257,4299260335,1345,546385]

theorem envBound9970 : H12AffineFastState.Bounded env9970 := by
  intro p hp
  have h : env9970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9969_9970 : H12AffineEnvironment.transform 24 554201 env9969 = env9970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 554201 env9969 == env9970) = true)

theorem identity9970 : scanCanonicalize (H12AffineFastState.compose env9970 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 63608) := by decide +kernel

theorem selectedBound9970 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,63608,524288,32768,4096,4194304,17665,98565,554201,5377,4237613,16385,1296,1073741824,1285,4294967296,257,4299260335,1345,546385]

theorem envBound9971 : H12AffineFastState.Bounded env9971 := by
  intro p hp
  have h : env9971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9970_9971 : H12AffineEnvironment.transform 17 63608 env9970 = env9971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63608 env9970 == env9971) = true)

theorem identity9971 : scanCanonicalize (H12AffineFastState.compose env9971 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(29+1) ^^^ 4721924) := by decide +kernel

theorem selectedBound9971 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env9972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,63608,524288,32768,4096,4194304,17665,98565,554201,5377,4237613,16385,1296,4721924,1285,4294967296,257,4299260335,1345,546385]

theorem envBound9972 : H12AffineFastState.Bounded env9972 := by
  intro p hp
  have h : env9972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9971_9972 : H12AffineEnvironment.transform 29 4721924 env9971 = env9972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4721924 env9971 == env9972) = true)

theorem identity9972 : scanCanonicalize (H12AffineFastState.compose env9972 (packedSelected [0,4,7,10,12,13,15,17,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 53727) := by decide +kernel

theorem selectedBound9972 : packedSelected [0,4,7,10,12,13,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env9973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53727,1345,63608,524288,32768,4096,4194304,17665,20698,554201,5377,4237613,16385,1296,4721924,1285,4294967296,257,4299182192,1345,546385]

theorem envBound9973 : H12AffineFastState.Bounded env9973 := by
  intro p hp
  have h : env9973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9972_9973 : H12AffineEnvironment.transform 15 53727 env9972 = env9973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53727 env9972 == env9973) = true)

theorem identity9973 : scanCanonicalize (H12AffineFastState.compose env9973 (packedSelected [11,16,18] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound9973 : packedSelected [11,16,18] rootPS < 2^1333 := by decide +kernel

def env9974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53727,1345,63608,21585,32768,4096,4194304,17665,20698,8328,5377,4237613,16385,1296,4217173,1285,4294967296,257,4299182192,1345,512]

theorem envBound9974 : H12AffineFastState.Bounded env9974 := by
  intro p hp
  have h : env9974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9973_9974 : H12AffineEnvironment.transform 18 21585 env9973 = env9974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env9973 == env9974) = true)

theorem identity9974 : scanCanonicalize (H12AffineFastState.compose env9974 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound9974 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,340,20619,1345,31020,21585,340,4096,4194304,17665,20698,8328,5377,4204665,16385,1296,4217173,1285,4294967296,257,4299182192,1345,512]

theorem envBound9975 : H12AffineFastState.Bounded env9975 := by
  intro p hp
  have h : env9975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9974_9975 : H12AffineEnvironment.transform 14 340 env9974 = env9975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env9974 == env9975) = true)

theorem identity9975 : scanCanonicalize (H12AffineFastState.compose env9975 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(21+1) ^^^ 8043) := by decide +kernel

theorem selectedBound9975 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env9976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,340,20619,1345,31020,21585,340,4096,8043,17665,20698,8328,5377,14098,16385,1296,17982,1285,4294967296,257,4294987547,1345,512]

theorem envBound9976 : H12AffineFastState.Bounded env9976 := by
  intro p hp
  have h : env9976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9975_9976 : H12AffineEnvironment.transform 21 8043 env9975 = env9976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8043 env9975 == env9976) = true)

theorem identity9976 : scanCanonicalize (H12AffineFastState.compose env9976 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 9544) := by decide +kernel

theorem selectedBound9976 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env9977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9544,340,13763,1345,7268,12569,340,4096,8043,8265,13714,8328,5377,14098,9545,1296,9078,1285,4294967296,257,4294978131,1345,512]

theorem envBound9977 : H12AffineFastState.Bounded env9977 := by
  intro p hp
  have h : env9977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9976_9977 : H12AffineEnvironment.transform 13 9544 env9976 = env9977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9544 env9976 == env9977) = true)

theorem identity9977 : scanCanonicalize (H12AffineFastState.compose env9977 (packedSelected [3,8,10] rootPS)) = affineNative (2^(31+1) ^^^ 11863) := by decide +kernel

theorem selectedBound9977 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env9978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9544,340,13763,1345,7268,12569,340,4096,8043,8265,13714,8328,5377,14098,9545,1296,9078,1285,11863,257,1028,1345,512]

theorem envBound9978 : H12AffineFastState.Bounded env9978 := by
  intro p hp
  have h : env9978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9977_9978 : H12AffineEnvironment.transform 31 11863 env9977 = env9978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11863 env9977 == env9978) = true)

theorem identity9978 : scanCanonicalize (H12AffineFastState.compose env9978 (packedSelected [0,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 3814) := by decide +kernel

theorem selectedBound9978 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env9979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,8192,9544,340,11045,1345,642,12287,340,3814,397,8265,11124,8328,3047,10740,9545,1296,9078,1285,11863,257,1028,1345,512]

theorem envBound9979 : H12AffineFastState.Bounded env9979 := by
  intro p hp
  have h : env9979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9978_9979 : H12AffineEnvironment.transform 11 3814 env9978 = env9979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3814 env9978 == env9979) = true)

theorem identity9979 : scanCanonicalize (H12AffineFastState.compose env9979 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 3070) := by decide +kernel

theorem selectedBound9979 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env9980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,3070,3766,340,219,1345,642,1025,340,3814,397,2999,138,2934,3047,522,3767,1296,2184,1285,1449,257,1028,1345,512]

theorem envBound9980 : H12AffineFastState.Bounded env9980 := by
  intro p hp
  have h : env9980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9979_9980 : H12AffineEnvironment.transform 12 3070 env9979 = env9980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3070 env9979 == env9980) = true)

theorem identity9980 : scanCanonicalize (H12AffineFastState.compose env9980 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1955) := by decide +kernel

theorem selectedBound9980 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1955,325,1117,277,340,219,1345,642,1025,340,325,397,1044,138,1237,1092,522,276,1296,1835,1285,1449,257,1028,1345,512]

theorem envBound9981 : H12AffineFastState.Bounded env9981 := by
  intro p hp
  have h : env9981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9980_9981 : H12AffineEnvironment.transform 10 1955 env9980 = env9981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1955 env9980 == env9981) = true)

theorem identity9981 : scanCanonicalize (H12AffineFastState.compose env9981 (packedSelected [1,5,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9981 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env9982 : List Nat := [2,4,8,16,32,64,128,256,512,4,935,325,89,277,340,219,325,642,5,340,325,397,16,138,209,64,522,276,276,815,257,429,257,0,325,512]

theorem envBound9982 : H12AffineFastState.Bounded env9982 := by
  intro p hp
  have h : env9982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9981_9982 : H12AffineEnvironment.transform 9 4 env9981 = env9982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9981 == env9982) = true)

theorem identity9982 : scanCanonicalize (H12AffineFastState.compose env9982 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 470) := by decide +kernel

theorem selectedBound9982 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9983 : List Nat := [2,4,8,16,32,64,128,256,470,4,113,325,89,277,340,219,325,340,5,340,325,397,16,138,209,64,476,276,276,249,257,429,257,0,325,470]

theorem envBound9983 : H12AffineFastState.Bounded env9983 := by
  intro p hp
  have h : env9983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9982_9983 : H12AffineEnvironment.transform 8 470 env9982 = env9983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 470 env9982 == env9983) = true)

theorem identity9983 : scanCanonicalize (H12AffineFastState.compose env9983 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound9983 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9984 : List Nat := [2,4,8,16,32,18,128,256,388,4,35,279,11,277,262,137,279,262,5,262,279,397,16,138,131,18,398,276,276,171,257,429,257,0,279,388]

theorem envBound9984 : H12AffineFastState.Bounded env9984 := by
  intro p hp
  have h : env9984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9983_9984 : H12AffineEnvironment.transform 5 18 env9983 = env9984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env9983 == env9984) = true)

def env9985 : List Nat := [2,4,8,16,32,18,8,256,268,4,35,279,11,277,262,1,279,262,5,262,279,261,16,2,11,18,262,276,276,35,257,293,257,0,279,268]

theorem envBound9985 : H12AffineFastState.Bounded env9985 := by
  intro p hp
  have h : env9985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9984_9985 : H12AffineEnvironment.transform 6 8 env9984 = env9985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9984 == env9985) = true)

theorem identity9985 : scanCanonicalize (H12AffineFastState.compose env9985 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound9985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9986 : List Nat := [0,4,8,16,32,16,8,256,268,4,33,277,9,277,260,1,277,260,5,260,277,261,16,0,9,16,260,276,276,33,257,293,257,0,277,268]

theorem envBound9986 : H12AffineFastState.Bounded env9986 := by
  intro p hp
  have h : env9986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9985_9986 : H12AffineEnvironment.transform 0 0 env9985 = env9986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env9985 == env9986) = true)

theorem identity9986 : scanCanonicalize (H12AffineFastState.compose env9986 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9986 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9987 : List Nat := [0,4,8,16,32,16,8,37,41,4,33,48,9,48,33,1,48,33,5,33,48,32,16,0,9,16,33,49,49,33,36,0,36,0,48,41]

theorem envBound9987 : H12AffineFastState.Bounded env9987 := by
  intro p hp
  have h : env9987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9986_9987 : H12AffineEnvironment.transform 7 37 env9986 = env9987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9986 == env9987) = true)

theorem identity9987 : scanCanonicalize (H12AffineFastState.compose env9987 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound9987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9988 : List Nat := [0,4,1,16,32,16,1,37,32,4,33,48,0,48,33,1,48,33,5,33,48,32,16,0,0,16,33,49,49,33,36,0,36,0,48,32]

theorem envBound9988 : H12AffineFastState.Bounded env9988 := by
  intro p hp
  have h : env9988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9987_9988 : H12AffineEnvironment.transform 2 1 env9987 = env9988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env9987 == env9988) = true)

def leafEnv9988 : List Nat := [0,4,1,16,32,16,1,37,32,4,33,48,0,48,33,1,48,33,5,33,48,32,16,0,37,0,1,16,33,49,49,33,36,0,36,0,5,1,48,32,0,48,1]

def active9988 : List Nat := [1,3,4]

def tree9988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9988 : H12WitnessSearch.Good tree9988 := H12GlobalWitnessIndex.good

theorem leafIdentity9988 : H12AffineFastState.composeSystem env9988 rootObs = leafEnv9988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9988 rootObs == leafEnv9988) = true)

theorem terminalChecked9988 : H12PackedTerminal.terminalCheckFast leafEnv9988 active9988 tree9988 = true := by decide +kernel

def env9989 : List Nat := [2,4,8,16,32,18,9,256,269,4,35,279,11,277,262,0,279,262,5,262,279,260,16,3,10,18,263,276,276,34,257,292,257,0,279,269]

theorem envBound9989 : H12AffineFastState.Bounded env9989 := by
  intro p hp
  have h : env9989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9984_9989 : H12AffineEnvironment.transform 6 9 env9984 = env9989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9984 == env9989) = true)

theorem identity9989 : scanCanonicalize (H12AffineFastState.compose env9989 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 39) := by decide +kernel

theorem selectedBound9989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2