import H12CloudChart2Data052

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound12961 : H12AffineFastState.Bounded env12961 := by
  intro p hp
  have h : env12961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12960_12961 : H12AffineEnvironment.transform 7 134 env12960 = env12961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env12960 == env12961) = true)

theorem identity12961 : scanCanonicalize (H12AffineFastState.compose env12961 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12961 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env12962 : List Nat := [2,4,8,0,11,64,128,134,65,135,1,65,3,0,201,9,64,1,134,200,64,10,1,66,139,64,137,1,0,136,5,131,135,74,64,65]

theorem envBound12962 : H12AffineFastState.Bounded env12962 := by
  intro p hp
  have h : env12962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12961_12962 : H12AffineEnvironment.transform 3 0 env12961 = env12962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12961 == env12962) = true)

theorem identity12962 : scanCanonicalize (H12AffineFastState.compose env12962 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound12962 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12963 : List Nat := [2,4,8,0,11,0,128,134,1,135,1,1,3,0,137,9,0,1,134,136,0,10,1,2,139,0,137,1,0,136,5,131,135,10,0,1]

theorem envBound12963 : H12AffineFastState.Bounded env12963 := by
  intro p hp
  have h : env12963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12962_12963 : H12AffineEnvironment.transform 5 0 env12962 = env12963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env12962 == env12963) = true)

theorem identity12963 : scanCanonicalize (H12AffineFastState.compose env12963 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12963 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12964 : List Nat := [2,4,8,0,11,0,9,15,1,14,1,1,3,0,0,9,0,1,15,1,0,10,1,2,2,0,0,1,0,1,5,10,14,10,0,1]

theorem envBound12964 : H12AffineFastState.Bounded env12964 := by
  intro p hp
  have h : env12964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12963_12964 : H12AffineEnvironment.transform 6 9 env12963 = env12964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12963 == env12964) = true)

def env12965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10249,17664,230469,8328,541008,927821,148800,676864,1073741824,1284,4294967296,132160,4295208166,131072,512]

theorem envBound12965 : H12AffineFastState.Bounded env12965 := by
  intro p hp
  have h : env12965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12842_12965 : H12AffineEnvironment.transform 21 10249 env12842 = env12965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env12842 == env12965) = true)

def env12966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,17664,230469,8328,541008,925773,148800,676864,1073741824,1284,4294967296,132160,4295206118,131072,512]

theorem envBound12966 : H12AffineFastState.Bounded env12966 := by
  intro p hp
  have h : env12966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12965_12966 : H12AffineEnvironment.transform 10 0 env12965 = env12966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12965 == env12966) = true)

def env12967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16384,545088,1073741824,1284,4294967296,256,4295074214,1344,512]

theorem envBound12967 : H12AffineFastState.Bounded env12967 := by
  intro p hp
  have h : env12967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12966_12967 : H12AffineEnvironment.transform 16 1344 env12966 = env12967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12966 == env12967) = true)

theorem identity12967 : scanCanonicalize (H12AffineFastState.compose env12967 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 566312) := by decide +kernel

theorem selectedBound12967 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16384,545088,566312,1284,4294967296,256,4295074214,1344,512]

theorem envBound12968 : H12AffineFastState.Bounded env12968 := by
  intro p hp
  have h : env12968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12967_12968 : H12AffineEnvironment.transform 29 566312 env12967 = env12968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 566312 env12967 == env12968) = true)

def env12969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8201,17664,98565,8328,320888,33061,16384,324968,262144,1284,4294967296,256,4295074214,1344,512]

theorem envBound12969 : H12AffineFastState.Bounded env12969 := by
  intro p hp
  have h : env12969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12968_12969 : H12AffineEnvironment.transform 18 304168 env12968 = env12969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12968 == env12969) = true)

theorem identity12969 : scanCanonicalize (H12AffineFastState.compose env12969 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound12969 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,33061,9485,32769,4097,8201,17664,98565,8328,25693,33061,16384,29773,33061,1284,4294967296,256,4295074214,1344,512]

theorem envBound12970 : H12AffineFastState.Bounded env12970 := by
  intro p hp
  have h : env12970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12969_12970 : H12AffineEnvironment.transform 17 33061 env12969 = env12970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env12969 == env12970) = true)

def env12971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8201,17664,98565,8328,320889,33060,16384,324969,262145,1284,4294967296,256,4295074214,1344,512]

theorem envBound12971 : H12AffineFastState.Bounded env12971 := by
  intro p hp
  have h : env12971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12968_12971 : H12AffineEnvironment.transform 18 304169 env12968 = env12971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12968 == env12971) = true)

theorem identity12971 : scanCanonicalize (H12AffineFastState.compose env12971 (packedSelected [4,9,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound12971 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,293,65536,1344,262144,271628,292,4097,8201,17664,65568,8328,287836,1,16384,291916,262145,1284,4294967296,256,4295041155,1344,512]

theorem envBound12972 : H12AffineFastState.Bounded env12972 := by
  intro p hp
  have h : env12972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12971_12972 : H12AffineEnvironment.transform 14 293 env12971 = env12972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env12971 == env12972) = true)

theorem identity12972 : scanCanonicalize (H12AffineFastState.compose env12972 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound12972 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,293,171,1344,262144,271628,292,4097,8201,17664,139,8328,287836,1,16384,291916,262145,1284,4294967296,256,4294975528,1344,512]

theorem envBound12973 : H12AffineFastState.Bounded env12973 := by
  intro p hp
  have h : env12973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12972_12973 : H12AffineEnvironment.transform 15 171 env12972 = env12973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env12972 == env12973) = true)

def env12974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,293,171,1344,8864,1964,292,4097,8201,17664,139,8328,18172,1,16384,22252,8865,1284,4294967296,256,4294975528,1344,512]

theorem envBound12974 : H12AffineFastState.Bounded env12974 := by
  intro p hp
  have h : env12974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12973_12974 : H12AffineEnvironment.transform 17 8864 env12973 = env12974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8864 env12973 == env12974) = true)

theorem identity12974 : scanCanonicalize (H12AffineFastState.compose env12974 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5116) := by decide +kernel

theorem selectedBound12974 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,5116,293,171,1344,8864,1964,292,4097,8201,5884,139,8328,5376,1,5116,1296,8865,1284,4294967296,256,4294975528,1344,512]

theorem envBound12975 : H12AffineFastState.Bounded env12975 := by
  intro p hp
  have h : env12975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12974_12975 : H12AffineEnvironment.transform 13 5116 env12974 = env12975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5116 env12974 == env12975) = true)

theorem identity12975 : scanCanonicalize (H12AffineFastState.compose env12975 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound12975 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1772,293,171,1344,8864,1964,292,1297,8201,1004,139,8328,16,1,1772,1296,8865,1284,4294967296,256,4294975528,1344,512]

theorem envBound12976 : H12AffineFastState.Bounded env12976 := by
  intro p hp
  have h : env12976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12975_12976 : H12AffineEnvironment.transform 11 1296 env12975 = env12976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env12975 == env12976) = true)

theorem identity12976 : scanCanonicalize (H12AffineFastState.compose env12976 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound12976 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12977 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1296,8192,1344,293,171,1344,8460,1024,292,1297,8201,64,139,8328,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,428]

theorem envBound12977 : H12AffineFastState.Bounded env12977 := by
  intro p hp
  have h : env12977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12976_12977 : H12AffineEnvironment.transform 8 428 env12976 = env12977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12976 == env12977) = true)

def env12978 : List Nat := [2,4,8,16,32,64,8,256,292,1024,0,1296,8192,1344,293,35,1344,8460,1024,292,1297,8201,64,3,8192,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,292]

theorem envBound12978 : H12AffineFastState.Bounded env12978 := by
  intro p hp
  have h : env12978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12977_12978 : H12AffineEnvironment.transform 6 8 env12977 = env12978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12977 == env12978) = true)

theorem identity12978 : scanCanonicalize (H12AffineFastState.compose env12978 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8232) := by decide +kernel

theorem selectedBound12978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12979 : List Nat := [2,4,8,16,32,64,8,256,292,1024,0,1296,8192,1344,293,35,1344,8460,1024,292,1297,8201,64,3,8192,16,1,1344,1296,8461,1284,8232,256,0,1344,292]

theorem envBound12979 : H12AffineFastState.Bounded env12979 := by
  intro p hp
  have h : env12979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12978_12979 : H12AffineEnvironment.transform 31 8232 env12978 = env12979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8232 env12978 == env12979) = true)

def env12980 : List Nat := [2,4,8,16,32,16,8,256,292,1024,0,1296,8192,1296,293,35,1296,8460,1024,292,1297,8201,16,3,8192,16,1,1296,1296,8461,1284,8232,256,0,1296,292]

theorem envBound12980 : H12AffineFastState.Bounded env12980 := by
  intro p hp
  have h : env12980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12979_12980 : H12AffineEnvironment.transform 5 16 env12979 = env12980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12979 == env12980) = true)

def env12981 : List Nat := [2,4,8,16,32,17,8,256,292,1024,0,1296,8192,1297,293,35,1297,8460,1024,292,1297,8201,17,3,8192,16,1,1297,1296,8461,1284,8232,256,0,1297,292]

theorem envBound12981 : H12AffineFastState.Bounded env12981 := by
  intro p hp
  have h : env12981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12979_12981 : H12AffineEnvironment.transform 5 17 env12979 = env12981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12979 == env12981) = true)

theorem identity12981 : scanCanonicalize (H12AffineFastState.compose env12981 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12981 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12982 : List Nat := [2,4,8,16,32,17,8,256,292,1024,0,1296,268,1297,293,35,1297,0,1024,292,1297,261,17,3,268,16,1,1297,1296,1,1284,292,256,0,1297,292]

theorem envBound12982 : H12AffineFastState.Bounded env12982 := by
  intro p hp
  have h : env12982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12981_12982 : H12AffineEnvironment.transform 12 268 env12981 = env12982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12981 == env12982) = true)

theorem identity12982 : scanCanonicalize (H12AffineFastState.compose env12982 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12982 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12983 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1076,40,1077,1,35,1077,0,1024,0,1077,33,17,3,40,16,1,1077,1076,1,1056,0,36,0,1077,0]

theorem envBound12983 : H12AffineFastState.Bounded env12983 := by
  intro p hp
  have h : env12983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12982_12983 : H12AffineEnvironment.transform 7 36 env12982 = env12983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12982 == env12983) = true)

def env12984 : List Nat := [2,4,8,16,32,64,9,256,293,1024,0,1296,8192,1344,293,34,1344,8460,1024,292,1297,8201,64,2,8193,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,293]

theorem envBound12984 : H12AffineFastState.Bounded env12984 := by
  intro p hp
  have h : env12984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12977_12984 : H12AffineEnvironment.transform 6 9 env12977 = env12984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12977 == env12984) = true)

theorem identity12984 : scanCanonicalize (H12AffineFastState.compose env12984 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound12984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12985 : List Nat := [2,4,8,16,32,64,9,256,293,1024,0,1296,8192,1344,293,34,1344,8460,1024,292,1297,8201,64,2,8193,16,1,1344,1296,8461,1284,293,256,8461,1344,293]

theorem envBound12985 : H12AffineFastState.Bounded env12985 := by
  intro p hp
  have h : env12985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12984_12985 : H12AffineEnvironment.transform 31 293 env12984 = env12985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env12984 == env12985) = true)

def env12986 : List Nat := [2,4,8,16,32,16,9,256,293,1024,0,1296,8192,1296,293,34,1296,8460,1024,292,1297,8201,16,2,8193,16,1,1296,1296,8461,1284,293,256,8461,1296,293]

theorem envBound12986 : H12AffineFastState.Bounded env12986 := by
  intro p hp
  have h : env12986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12985_12986 : H12AffineEnvironment.transform 5 16 env12985 = env12986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12985 == env12986) = true)

def env12987 : List Nat := [2,4,8,16,32,17,9,256,293,1024,0,1296,8192,1297,293,34,1297,8460,1024,292,1297,8201,17,2,8193,16,1,1297,1296,8461,1284,293,256,8461,1297,293]

theorem envBound12987 : H12AffineFastState.Bounded env12987 := by
  intro p hp
  have h : env12987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12985_12987 : H12AffineEnvironment.transform 5 17 env12985 = env12987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12985 == env12987) = true)

theorem identity12987 : scanCanonicalize (H12AffineFastState.compose env12987 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12987 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12988 : List Nat := [2,4,8,16,32,17,9,256,293,1024,0,1296,269,1297,293,34,1297,1,1024,292,1297,260,17,2,268,16,1,1297,1296,0,1284,293,256,0,1297,293]

theorem envBound12988 : H12AffineFastState.Bounded env12988 := by
  intro p hp
  have h : env12988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12987_12988 : H12AffineEnvironment.transform 12 269 env12987 = env12988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12987 == env12988) = true)

theorem identity12988 : scanCanonicalize (H12AffineFastState.compose env12988 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12988 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12989 : List Nat := [2,4,8,16,32,17,9,37,0,1024,0,1077,40,1076,0,34,1076,1,1024,1,1076,33,17,2,41,16,1,1076,1077,0,1057,0,37,0,1076,0]

theorem envBound12989 : H12AffineFastState.Bounded env12989 := by
  intro p hp
  have h : env12989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12988_12989 : H12AffineEnvironment.transform 7 37 env12988 = env12989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12988 == env12989) = true)

def env12990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,293,171,1344,8865,1965,292,4097,8201,17664,139,8328,18173,1,16384,22253,8864,1284,4294967296,256,4294975528,1344,512]

theorem envBound12990 : H12AffineFastState.Bounded env12990 := by
  intro p hp
  have h : env12990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12973_12990 : H12AffineEnvironment.transform 17 8865 env12973 = env12990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8865 env12973 == env12990) = true)

theorem identity12990 : scanCanonicalize (H12AffineFastState.compose env12990 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound12990 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,293,171,1344,8865,1965,292,4097,8201,5456,139,8328,5805,1,4176,1725,8864,1284,4294967296,256,4294975528,1344,512]

theorem envBound12991 : H12AffineFastState.Bounded env12991 := by
  intro p hp
  have h : env12991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12990_12991 : H12AffineEnvironment.transform 13 4176 env12990 = env12991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env12990 == env12991) = true)

theorem identity12991 : scanCanonicalize (H12AffineFastState.compose env12991 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound12991 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,293,171,1344,8865,1965,292,1297,8201,64,139,8328,957,1,1344,1725,8864,1284,4294967296,256,4294975528,1344,512]

theorem envBound12992 : H12AffineFastState.Bounded env12992 := by
  intro p hp
  have h : env12992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12991_12992 : H12AffineEnvironment.transform 11 1296 env12991 = env12992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env12991 == env12992) = true)

theorem identity12992 : scanCanonicalize (H12AffineFastState.compose env12992 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound12992 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12993 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1296,8192,1344,293,171,1344,8460,1024,292,1297,8201,64,139,8328,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,429]

theorem envBound12993 : H12AffineFastState.Bounded env12993 := by
  intro p hp
  have h : env12993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12992_12993 : H12AffineEnvironment.transform 8 429 env12992 = env12993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12992 == env12993) = true)

def env12994 : List Nat := [2,4,8,16,32,64,8,256,293,1024,0,1296,8192,1344,293,35,1344,8460,1024,292,1297,8201,64,3,8192,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,293]

theorem envBound12994 : H12AffineFastState.Bounded env12994 := by
  intro p hp
  have h : env12994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12993_12994 : H12AffineEnvironment.transform 6 8 env12993 = env12994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12993 == env12994) = true)

theorem identity12994 : scanCanonicalize (H12AffineFastState.compose env12994 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound12994 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12995 : List Nat := [2,4,8,16,32,64,8,256,293,1024,0,1296,8192,1344,293,35,1344,8460,1024,292,1297,8201,64,3,8192,16,1,1344,1296,8461,1284,293,256,8461,1344,293]

theorem envBound12995 : H12AffineFastState.Bounded env12995 := by
  intro p hp
  have h : env12995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12994_12995 : H12AffineEnvironment.transform 31 293 env12994 = env12995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env12994 == env12995) = true)

def env12996 : List Nat := [2,4,8,16,32,16,8,256,293,1024,0,1296,8192,1296,293,35,1296,8460,1024,292,1297,8201,16,3,8192,16,1,1296,1296,8461,1284,293,256,8461,1296,293]

theorem envBound12996 : H12AffineFastState.Bounded env12996 := by
  intro p hp
  have h : env12996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12995_12996 : H12AffineEnvironment.transform 5 16 env12995 = env12996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12995 == env12996) = true)

def env12997 : List Nat := [2,4,8,16,32,17,8,256,293,1024,0,1296,8192,1297,293,35,1297,8460,1024,292,1297,8201,17,3,8192,16,1,1297,1296,8461,1284,293,256,8461,1297,293]

theorem envBound12997 : H12AffineFastState.Bounded env12997 := by
  intro p hp
  have h : env12997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12995_12997 : H12AffineEnvironment.transform 5 17 env12995 = env12997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12995 == env12997) = true)

theorem identity12997 : scanCanonicalize (H12AffineFastState.compose env12997 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12998 : List Nat := [2,4,8,16,32,17,8,256,293,1024,0,1296,268,1297,293,35,1297,0,1024,292,1297,261,17,3,268,16,1,1297,1296,1,1284,293,256,1,1297,293]

theorem envBound12998 : H12AffineFastState.Bounded env12998 := by
  intro p hp
  have h : env12998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12997_12998 : H12AffineEnvironment.transform 12 268 env12997 = env12998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12997 == env12998) = true)

theorem identity12998 : scanCanonicalize (H12AffineFastState.compose env12998 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12998 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12999 : List Nat := [2,4,8,16,32,17,8,37,0,1024,0,1077,41,1076,0,35,1076,0,1024,1,1076,32,17,3,41,16,1,1076,1077,1,1057,0,37,1,1076,0]

theorem envBound12999 : H12AffineFastState.Bounded env12999 := by
  intro p hp
  have h : env12999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12998_12999 : H12AffineEnvironment.transform 7 37 env12998 = env12999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12998 == env12999) = true)

theorem identity12999 : scanCanonicalize (H12AffineFastState.compose env12999 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12999 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13000 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1044,8,1045,0,2,1045,0,1024,1,1045,1,17,3,8,16,1,1045,1044,1,1024,0,4,1,1045,0]

theorem envBound13000 : H12AffineFastState.Bounded env13000 := by
  intro p hp
  have h : env13000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12999_13000 : H12AffineEnvironment.transform 4 1 env12999 = env13000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12999 == env13000) = true)

def leafEnv13000 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1044,8,1045,0,2,1045,0,1024,1,1045,1,17,3,1024,8,1,16,1,1045,1044,1,1024,0,4,1,4,3,1045,0,0,1045,1]

def active13000 : List Nat := [0,1,2,3,9]

def tree13000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13000 : H12WitnessSearch.Good tree13000 := H12GlobalWitnessIndex.good

theorem leafIdentity13000 : H12AffineFastState.composeSystem env13000 rootObs = leafEnv13000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13000 rootObs == leafEnv13000) = true)

theorem terminalChecked13000 : H12PackedTerminal.terminalCheckFast leafEnv13000 active13000 tree13000 = true := by decide +kernel

def env13001 : List Nat := [2,4,8,16,32,64,9,256,292,1024,0,1296,8192,1344,293,34,1344,8460,1024,292,1297,8201,64,2,8193,16,1,1344,1296,8461,1284,4294967296,256,4294975528,1344,292]

theorem envBound13001 : H12AffineFastState.Bounded env13001 := by
  intro p hp
  have h : env13001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12993_13001 : H12AffineEnvironment.transform 6 9 env12993 = env13001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12993 == env13001) = true)

theorem identity13001 : scanCanonicalize (H12AffineFastState.compose env13001 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8233) := by decide +kernel

theorem selectedBound13001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13002 : List Nat := [2,4,8,16,32,64,9,256,292,1024,0,1296,8192,1344,293,34,1344,8460,1024,292,1297,8201,64,2,8193,16,1,1344,1296,8461,1284,8233,256,1,1344,292]

theorem envBound13002 : H12AffineFastState.Bounded env13002 := by
  intro p hp
  have h : env13002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13001_13002 : H12AffineEnvironment.transform 31 8233 env13001 = env13002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8233 env13001 == env13002) = true)

def env13003 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1296,8192,1296,293,34,1296,8460,1024,292,1297,8201,16,2,8193,16,1,1296,1296,8461,1284,8233,256,1,1296,292]

theorem envBound13003 : H12AffineFastState.Bounded env13003 := by
  intro p hp
  have h : env13003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13002_13003 : H12AffineEnvironment.transform 5 16 env13002 = env13003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13002 == env13003) = true)

def env13004 : List Nat := [2,4,8,16,32,17,9,256,292,1024,0,1296,8192,1297,293,34,1297,8460,1024,292,1297,8201,17,2,8193,16,1,1297,1296,8461,1284,8233,256,1,1297,292]

theorem envBound13004 : H12AffineFastState.Bounded env13004 := by
  intro p hp
  have h : env13004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13002_13004 : H12AffineEnvironment.transform 5 17 env13002 = env13004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13002 == env13004) = true)

theorem identity13004 : scanCanonicalize (H12AffineFastState.compose env13004 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13004 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13005 : List Nat := [2,4,8,16,32,17,9,256,292,1024,0,1296,269,1297,293,34,1297,1,1024,292,1297,260,17,2,268,16,1,1297,1296,0,1284,292,256,1,1297,292]

theorem envBound13005 : H12AffineFastState.Bounded env13005 := by
  intro p hp
  have h : env13005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13004_13005 : H12AffineEnvironment.transform 12 269 env13004 = env13005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13004 == env13005) = true)

theorem identity13005 : scanCanonicalize (H12AffineFastState.compose env13005 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13005 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13006 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1076,41,1077,1,34,1077,1,1024,0,1077,32,17,2,40,16,1,1077,1076,0,1056,0,36,1,1077,0]

theorem envBound13006 : H12AffineFastState.Bounded env13006 := by
  intro p hp
  have h : env13006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13005_13006 : H12AffineEnvironment.transform 7 36 env13005 = env13006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13005 == env13006) = true)

theorem identity13006 : scanCanonicalize (H12AffineFastState.compose env13006 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13006 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13007 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1045,8,1044,1,3,1044,1,1024,0,1044,1,17,2,9,16,1,1044,1045,0,1025,0,5,1,1044,0]

theorem envBound13007 : H12AffineFastState.Bounded env13007 := by
  intro p hp
  have h : env13007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13006_13007 : H12AffineEnvironment.transform 4 1 env13006 = env13007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13006 == env13007) = true)

def leafEnv13007 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1045,8,1044,1,3,1044,1,1024,0,1044,1,17,2,1025,9,1,16,1,1044,1045,0,1025,0,5,1,4,3,1044,0,0,1044,1]

def active13007 : List Nat := [0,1,2,3,9]

def tree13007 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13007 : H12WitnessSearch.Good tree13007 := H12GlobalWitnessIndex.good

theorem leafIdentity13007 : H12AffineFastState.composeSystem env13007 rootObs = leafEnv13007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13007 rootObs == leafEnv13007) = true)

theorem terminalChecked13007 : H12PackedTerminal.terminalCheckFast leafEnv13007 active13007 tree13007 = true := by decide +kernel

def env13008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16385,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound13008 : H12AffineFastState.Bounded env13008 := by
  intro p hp
  have h : env13008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12966_13008 : H12AffineEnvironment.transform 16 1345 env12966 = env13008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12966 == env13008) = true)

theorem identity13008 : scanCanonicalize (H12AffineFastState.compose env13008 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 45177) := by decide +kernel

theorem selectedBound13008 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16385,545089,45177,1284,4294967296,257,4295074215,1345,512]

theorem envBound13009 : H12AffineFastState.Bounded env13009 := by
  intro p hp
  have h : env13009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13008_13009 : H12AffineEnvironment.transform 29 45177 env13008 = env13009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 45177 env13008 == env13009) = true)

theorem identity13009 : scanCanonicalize (H12AffineFastState.compose env13009 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound13009 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env13010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8201,17664,98564,8328,17745,270605,16385,21824,45177,1284,4294967296,257,4295074215,1345,512]

theorem envBound13010 : H12AffineFastState.Bounded env13010 := by
  intro p hp
  have h : env13010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13009_13010 : H12AffineEnvironment.transform 18 1025 env13009 = env13010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13009 == env13010) = true)

theorem identity13010 : scanCanonicalize (H12AffineFastState.compose env13010 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74151) := by decide +kernel

theorem selectedBound13010 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env13011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,74151,1025,32769,4097,8201,17664,98564,8328,17745,65706,16385,21824,45177,1284,4294967296,257,4295074215,1345,512]

theorem envBound13011 : H12AffineFastState.Bounded env13011 := by
  intro p hp
  have h : env13011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13010_13011 : H12AffineEnvironment.transform 17 74151 env13010 = env13011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74151 env13010 == env13011) = true)

theorem identity13011 : scanCanonicalize (H12AffineFastState.compose env13011 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 4469) := by decide +kernel

theorem selectedBound13011 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env13012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,4469,65536,1345,74151,1025,4468,4097,8201,17664,69745,8328,17745,65706,16385,21824,8460,1284,4294967296,257,4295045330,1345,512]

theorem envBound13012 : H12AffineFastState.Bounded env13012 := by
  intro p hp
  have h : env13012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13011_13012 : H12AffineEnvironment.transform 14 4469 env13011 = env13012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4469 env13011 == env13012) = true)

theorem identity13012 : scanCanonicalize (H12AffineFastState.compose env13012 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 29879) := by decide +kernel

theorem selectedBound13012 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env13013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,4469,29879,1345,21776,1025,4468,4097,8201,17664,25798,8328,17745,29725,16385,21824,8460,1284,4294967296,257,4294984805,1345,512]

theorem envBound13013 : H12AffineFastState.Bounded env13013 := by
  intro p hp
  have h : env13013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13012_13013 : H12AffineEnvironment.transform 15 29879 env13012 = env13013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29879 env13012 == env13013) = true)

theorem identity13013 : scanCanonicalize (H12AffineFastState.compose env13013 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound13013 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,0,4469,13495,1345,5392,1025,4468,4097,8201,1280,9414,8328,1361,13341,1,5440,8460,1284,4294967296,257,4294968421,1345,512]

theorem envBound13014 : H12AffineFastState.Bounded env13014 := by
  intro p hp
  have h : env13014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13013_13014 : H12AffineEnvironment.transform 13 0 env13013 = env13014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env13013 == env13014) = true)

theorem identity13014 : scanCanonicalize (H12AffineFastState.compose env13014 (packedSelected [0,7,12] rootPS)) = affineNative (2^(31+1) ^^^ 5324) := by decide +kernel

theorem selectedBound13014 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env13015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,0,4469,13495,1345,5392,1025,4468,4097,8201,1280,9414,8328,1361,13341,1,5440,8460,1284,5324,257,4265,1345,512]

theorem envBound13015 : H12AffineFastState.Bounded env13015 := by
  intro p hp
  have h : env13015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13014_13015 : H12AffineEnvironment.transform 31 5324 env13014 = env13015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5324 env13014 == env13015) = true)

theorem identity13015 : scanCanonicalize (H12AffineFastState.compose env13015 (packedSelected [0,1,4,5,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound13015 : packedSelected [0,1,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env13016 : List Nat := [2,4,8,16,32,64,128,256,512,701,0,4096,8192,0,4469,12810,1020,5037,700,4468,4097,8201,957,8827,8328,1004,12960,1,5117,8460,953,4721,257,4265,1020,512]

theorem envBound13016 : H12AffineFastState.Bounded env13016 := by
  intro p hp
  have h : env13016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13015_13016 : H12AffineEnvironment.transform 9 701 env13015 = env13016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env13015 == env13016) = true)

theorem identity13016 : scanCanonicalize (H12AffineFastState.compose env13016 (packedSelected [1,3,4,5,8,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 4848) := by decide +kernel

theorem selectedBound13016 : packedSelected [1,3,4,5,8,9,18] rootPS < 2^1333 := by decide +kernel

def env13017 : List Nat := [2,4,8,16,32,64,128,256,512,701,0,4096,4848,0,4469,250,1020,5037,700,4468,4097,4857,957,4235,4728,1004,80,1,5117,5116,953,4721,257,4265,1020,512]

theorem envBound13017 : H12AffineFastState.Bounded env13017 := by
  intro p hp
  have h : env13017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13016_13017 : H12AffineEnvironment.transform 12 4848 env13016 = env13017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4848 env13016 == env13017) = true)

theorem identity13017 : scanCanonicalize (H12AffineFastState.compose env13017 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13017 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env13018 : List Nat := [2,4,8,16,32,16,128,256,512,701,0,4096,4768,0,4389,170,940,5037,700,4388,4097,4777,957,4235,4648,956,0,1,5037,5036,953,4641,257,4265,940,512]

theorem envBound13018 : H12AffineFastState.Bounded env13018 := by
  intro p hp
  have h : env13018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13017_13018 : H12AffineEnvironment.transform 5 16 env13017 = env13018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13017 == env13018) = true)

theorem identity13018 : scanCanonicalize (H12AffineFastState.compose env13018 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound13018 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env13019 : List Nat := [2,4,8,16,32,16,128,256,512,701,0,512,160,0,805,170,940,429,700,804,513,169,957,651,40,956,0,1,429,428,953,33,257,681,940,512]

theorem envBound13019 : H12AffineFastState.Bounded env13019 := by
  intro p hp
  have h : env13019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13018_13019 : H12AffineEnvironment.transform 11 512 env13018 = env13019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env13018 == env13019) = true)

theorem identity13019 : scanCanonicalize (H12AffineFastState.compose env13019 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13019 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13020 : List Nat := [2,4,8,16,32,16,8,256,512,565,0,512,40,0,805,34,804,293,564,804,513,33,821,515,40,820,0,1,293,292,817,33,257,545,804,512]

theorem envBound13020 : H12AffineFastState.Bounded env13020 := by
  intro p hp
  have h : env13020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13019_13020 : H12AffineEnvironment.transform 6 8 env13019 = env13020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13019 == env13020) = true)

theorem identity13020 : scanCanonicalize (H12AffineFastState.compose env13020 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13020 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13021 : List Nat := [2,4,8,16,32,16,8,256,1,52,0,1,40,0,292,34,293,293,53,293,0,33,308,2,40,309,0,1,293,292,304,33,257,32,293,1]

theorem envBound13021 : H12AffineFastState.Bounded env13021 := by
  intro p hp
  have h : env13021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13020_13021 : H12AffineEnvironment.transform 8 1 env13020 = env13021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13020 == env13021) = true)

theorem identity13021 : scanCanonicalize (H12AffineFastState.compose env13021 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound13021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13022 : List Nat := [2,4,8,16,32,16,8,52,1,52,0,1,40,0,16,34,17,17,53,17,0,33,0,2,40,1,0,1,17,16,4,33,53,32,17,1]

theorem envBound13022 : H12AffineFastState.Bounded env13022 := by
  intro p hp
  have h : env13022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13021_13022 : H12AffineEnvironment.transform 7 52 env13021 = env13022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env13021 == env13022) = true)

theorem identity13022 : scanCanonicalize (H12AffineFastState.compose env13022 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound13022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13023 : List Nat := [2,4,8,16,27,16,8,15,1,15,0,1,19,0,16,25,17,17,14,17,0,26,0,2,19,1,0,1,17,16,4,26,14,27,17,1]

theorem envBound13023 : H12AffineFastState.Bounded env13023 := by
  intro p hp
  have h : env13023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13022_13023 : H12AffineEnvironment.transform 4 27 env13022 = env13023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env13022 == env13023) = true)

theorem identity13023 : scanCanonicalize (H12AffineFastState.compose env13023 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13024 : List Nat := [2,4,8,10,1,10,8,15,1,15,0,1,9,0,10,3,11,11,14,11,0,0,0,2,9,1,0,1,11,10,4,0,14,1,11,1]

theorem envBound13024 : H12AffineFastState.Bounded env13024 := by
  intro p hp
  have h : env13024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13023_13024 : H12AffineEnvironment.transform 3 10 env13023 = env13024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13023 == env13024) = true)

theorem identity13024 : scanCanonicalize (H12AffineFastState.compose env13024 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13024 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13025 : List Nat := [2,4,3,1,1,1,3,4,1,4,0,1,2,0,1,3,0,0,5,0,0,0,0,2,2,1,0,1,0,1,4,0,5,1,0,1]

theorem envBound13025 : H12AffineFastState.Bounded env13025 := by
  intro p hp
  have h : env13025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13024_13025 : H12AffineEnvironment.transform 2 3 env13024 = env13025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13024 == env13025) = true)

def env13026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,17664,230469,8328,541008,925772,148800,676864,1073741824,1284,4294967296,132160,4295206119,131072,512]

theorem envBound13026 : H12AffineFastState.Bounded env13026 := by
  intro p hp
  have h : env13026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12965_13026 : H12AffineEnvironment.transform 10 1 env12965 = env13026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12965 == env13026) = true)

def env13027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16384,545088,1073741824,1284,4294967296,256,4295074215,1344,512]

theorem envBound13027 : H12AffineFastState.Bounded env13027 := by
  intro p hp
  have h : env13027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13026_13027 : H12AffineEnvironment.transform 16 1344 env13026 = env13027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env13026 == env13027) = true)

theorem identity13027 : scanCanonicalize (H12AffineFastState.compose env13027 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound13027 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16384,545088,262145,1284,4294967296,256,4295074215,1344,512]

theorem envBound13028 : H12AffineFastState.Bounded env13028 := by
  intro p hp
  have h : env13028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13027_13028 : H12AffineEnvironment.transform 29 262145 env13027 = env13028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env13027 == env13028) = true)

theorem identity13028 : scanCanonicalize (H12AffineFastState.compose env13028 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound13028 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env13029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,292,65536,1344,262144,524288,293,4097,8200,17664,65569,8328,541008,795916,16384,545088,262145,1284,4294967296,256,4295041155,1344,512]

theorem envBound13029 : H12AffineFastState.Bounded env13029 := by
  intro p hp
  have h : env13029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13028_13029 : H12AffineEnvironment.transform 14 292 env13028 = env13029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env13028 == env13029) = true)

theorem identity13029 : scanCanonicalize (H12AffineFastState.compose env13029 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 271628) := by decide +kernel

theorem selectedBound13029 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,292,65536,1344,262144,271628,293,4097,8200,17664,65569,8328,287836,0,16384,291916,262145,1284,4294967296,256,4295041155,1344,512]

theorem envBound13030 : H12AffineFastState.Bounded env13030 := by
  intro p hp
  have h : env13030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13029_13030 : H12AffineEnvironment.transform 18 271628 env13029 = env13030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 271628 env13029 == env13030) = true)

theorem identity13030 : scanCanonicalize (H12AffineFastState.compose env13030 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound13030 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env13031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,292,170,1344,262144,271628,293,4097,8200,17664,139,8328,287836,0,16384,291916,262145,1284,4294967296,256,4294975529,1344,512]

theorem envBound13031 : H12AffineFastState.Bounded env13031 := by
  intro p hp
  have h : env13031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13030_13031 : H12AffineEnvironment.transform 15 170 env13030 = env13031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env13030 == env13031) = true)

def env13032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,292,170,1344,8864,1964,293,4097,8200,17664,139,8328,18172,0,16384,22252,8865,1284,4294967296,256,4294975529,1344,512]

theorem envBound13032 : H12AffineFastState.Bounded env13032 := by
  intro p hp
  have h : env13032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13031_13032 : H12AffineEnvironment.transform 17 8864 env13031 = env13032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8864 env13031 == env13032) = true)

theorem identity13032 : scanCanonicalize (H12AffineFastState.compose env13032 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5116) := by decide +kernel

theorem selectedBound13032 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env13033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,5116,292,170,1344,8864,1964,293,4097,8200,5884,139,8328,5376,0,5116,1296,8865,1284,4294967296,256,4294975529,1344,512]

theorem envBound13033 : H12AffineFastState.Bounded env13033 := by
  intro p hp
  have h : env13033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13032_13033 : H12AffineEnvironment.transform 13 5116 env13032 = env13033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5116 env13032 == env13033) = true)

theorem identity13033 : scanCanonicalize (H12AffineFastState.compose env13033 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13033 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1772,292,170,1344,8864,1964,293,1297,8200,1004,139,8328,16,0,1772,1296,8865,1284,4294967296,256,4294975529,1344,512]

theorem envBound13034 : H12AffineFastState.Bounded env13034 := by
  intro p hp
  have h : env13034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13033_13034 : H12AffineEnvironment.transform 11 1296 env13033 = env13034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13033 == env13034) = true)

theorem identity13034 : scanCanonicalize (H12AffineFastState.compose env13034 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound13034 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13035 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1296,8192,1344,292,170,1344,8460,1024,293,1297,8200,64,139,8328,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,428]

theorem envBound13035 : H12AffineFastState.Bounded env13035 := by
  intro p hp
  have h : env13035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13034_13035 : H12AffineEnvironment.transform 8 428 env13034 = env13035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env13034 == env13035) = true)

def env13036 : List Nat := [2,4,8,16,32,64,8,256,292,1024,1,1296,8192,1344,292,34,1344,8460,1024,293,1297,8200,64,3,8192,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,292]

theorem envBound13036 : H12AffineFastState.Bounded env13036 := by
  intro p hp
  have h : env13036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13035_13036 : H12AffineEnvironment.transform 6 8 env13035 = env13036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13035 == env13036) = true)

theorem identity13036 : scanCanonicalize (H12AffineFastState.compose env13036 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8233) := by decide +kernel

theorem selectedBound13036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13037 : List Nat := [2,4,8,16,32,64,8,256,292,1024,1,1296,8192,1344,292,34,1344,8460,1024,293,1297,8200,64,3,8192,16,0,1344,1296,8461,1284,8233,256,0,1344,292]

theorem envBound13037 : H12AffineFastState.Bounded env13037 := by
  intro p hp
  have h : env13037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13036_13037 : H12AffineEnvironment.transform 31 8233 env13036 = env13037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8233 env13036 == env13037) = true)

def env13038 : List Nat := [2,4,8,16,32,16,8,256,292,1024,1,1296,8192,1296,292,34,1296,8460,1024,293,1297,8200,16,3,8192,16,0,1296,1296,8461,1284,8233,256,0,1296,292]

theorem envBound13038 : H12AffineFastState.Bounded env13038 := by
  intro p hp
  have h : env13038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13037_13038 : H12AffineEnvironment.transform 5 16 env13037 = env13038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13037 == env13038) = true)

def env13039 : List Nat := [2,4,8,16,32,17,8,256,292,1024,1,1296,8192,1297,292,34,1297,8460,1024,293,1297,8200,17,3,8192,16,0,1297,1296,8461,1284,8233,256,0,1297,292]

theorem envBound13039 : H12AffineFastState.Bounded env13039 := by
  intro p hp
  have h : env13039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13037_13039 : H12AffineEnvironment.transform 5 17 env13037 = env13039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13037 == env13039) = true)

theorem identity13039 : scanCanonicalize (H12AffineFastState.compose env13039 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13040 : List Nat := [2,4,8,16,32,17,8,256,292,1024,1,1296,269,1297,292,34,1297,1,1024,293,1297,261,17,3,269,16,0,1297,1296,0,1284,292,256,0,1297,292]

theorem envBound13040 : H12AffineFastState.Bounded env13040 := by
  intro p hp
  have h : env13040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13039_13040 : H12AffineEnvironment.transform 12 269 env13039 = env13040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13039 == env13040) = true)

theorem identity13040 : scanCanonicalize (H12AffineFastState.compose env13040 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13040 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13041 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1076,41,1077,0,34,1077,1,1024,1,1077,33,17,3,41,16,0,1077,1076,0,1056,0,36,0,1077,0]

theorem envBound13041 : H12AffineFastState.Bounded env13041 := by
  intro p hp
  have h : env13041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13040_13041 : H12AffineEnvironment.transform 7 36 env13040 = env13041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13040 == env13041) = true)

def env13042 : List Nat := [2,4,8,16,32,64,9,256,293,1024,1,1296,8192,1344,292,35,1344,8460,1024,293,1297,8200,64,2,8193,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,293]

theorem envBound13042 : H12AffineFastState.Bounded env13042 := by
  intro p hp
  have h : env13042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13035_13042 : H12AffineEnvironment.transform 6 9 env13035 = env13042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13035 == env13042) = true)

theorem identity13042 : scanCanonicalize (H12AffineFastState.compose env13042 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound13042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13043 : List Nat := [2,4,8,16,32,64,9,256,293,1024,1,1296,8192,1344,292,35,1344,8460,1024,293,1297,8200,64,2,8193,16,0,1344,1296,8461,1284,293,256,8460,1344,293]

theorem envBound13043 : H12AffineFastState.Bounded env13043 := by
  intro p hp
  have h : env13043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13042_13043 : H12AffineEnvironment.transform 31 293 env13042 = env13043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env13042 == env13043) = true)

def env13044 : List Nat := [2,4,8,16,32,16,9,256,293,1024,1,1296,8192,1296,292,35,1296,8460,1024,293,1297,8200,16,2,8193,16,0,1296,1296,8461,1284,293,256,8460,1296,293]

theorem envBound13044 : H12AffineFastState.Bounded env13044 := by
  intro p hp
  have h : env13044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13043_13044 : H12AffineEnvironment.transform 5 16 env13043 = env13044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13043 == env13044) = true)

def env13045 : List Nat := [2,4,8,16,32,17,9,256,293,1024,1,1296,8192,1297,292,35,1297,8460,1024,293,1297,8200,17,2,8193,16,0,1297,1296,8461,1284,293,256,8460,1297,293]

theorem envBound13045 : H12AffineFastState.Bounded env13045 := by
  intro p hp
  have h : env13045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13043_13045 : H12AffineEnvironment.transform 5 17 env13043 = env13045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13043 == env13045) = true)

theorem identity13045 : scanCanonicalize (H12AffineFastState.compose env13045 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13046 : List Nat := [2,4,8,16,32,17,9,256,293,1024,1,1296,268,1297,292,35,1297,0,1024,293,1297,260,17,2,269,16,0,1297,1296,1,1284,293,256,0,1297,293]

theorem envBound13046 : H12AffineFastState.Bounded env13046 := by
  intro p hp
  have h : env13046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13045_13046 : H12AffineEnvironment.transform 12 268 env13045 = env13046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13045 == env13046) = true)

theorem identity13046 : scanCanonicalize (H12AffineFastState.compose env13046 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13046 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13047 : List Nat := [2,4,8,16,32,17,9,37,0,1024,1,1077,41,1076,1,35,1076,0,1024,0,1076,33,17,2,40,16,0,1076,1077,1,1057,0,37,0,1076,0]

theorem envBound13047 : H12AffineFastState.Bounded env13047 := by
  intro p hp
  have h : env13047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13046_13047 : H12AffineEnvironment.transform 7 37 env13046 = env13047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13046 == env13047) = true)

def env13048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,292,170,1344,8865,1965,293,4097,8200,17664,139,8328,18173,0,16384,22253,8864,1284,4294967296,256,4294975529,1344,512]

theorem envBound13048 : H12AffineFastState.Bounded env13048 := by
  intro p hp
  have h : env13048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13031_13048 : H12AffineEnvironment.transform 17 8865 env13031 = env13048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8865 env13031 == env13048) = true)

theorem identity13048 : scanCanonicalize (H12AffineFastState.compose env13048 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound13048 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env13049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,292,170,1344,8865,1965,293,4097,8200,5456,139,8328,5805,0,4176,1725,8864,1284,4294967296,256,4294975529,1344,512]

theorem envBound13049 : H12AffineFastState.Bounded env13049 := by
  intro p hp
  have h : env13049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13048_13049 : H12AffineEnvironment.transform 13 4176 env13048 = env13049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env13048 == env13049) = true)

theorem identity13049 : scanCanonicalize (H12AffineFastState.compose env13049 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13049 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1344,292,170,1344,8865,1965,293,1297,8200,64,139,8328,957,0,1344,1725,8864,1284,4294967296,256,4294975529,1344,512]

theorem envBound13050 : H12AffineFastState.Bounded env13050 := by
  intro p hp
  have h : env13050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13049_13050 : H12AffineEnvironment.transform 11 1296 env13049 = env13050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13049 == env13050) = true)

theorem identity13050 : scanCanonicalize (H12AffineFastState.compose env13050 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound13050 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13051 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1296,8192,1344,292,170,1344,8460,1024,293,1297,8200,64,139,8328,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,429]

theorem envBound13051 : H12AffineFastState.Bounded env13051 := by
  intro p hp
  have h : env13051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13050_13051 : H12AffineEnvironment.transform 8 429 env13050 = env13051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env13050 == env13051) = true)

def env13052 : List Nat := [2,4,8,16,32,64,8,256,293,1024,1,1296,8192,1344,292,34,1344,8460,1024,293,1297,8200,64,3,8192,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,293]

theorem envBound13052 : H12AffineFastState.Bounded env13052 := by
  intro p hp
  have h : env13052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13051_13052 : H12AffineEnvironment.transform 6 8 env13051 = env13052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13051 == env13052) = true)

theorem identity13052 : scanCanonicalize (H12AffineFastState.compose env13052 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound13052 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13053 : List Nat := [2,4,8,16,32,64,8,256,293,1024,1,1296,8192,1344,292,34,1344,8460,1024,293,1297,8200,64,3,8192,16,0,1344,1296,8461,1284,293,256,8460,1344,293]

theorem envBound13053 : H12AffineFastState.Bounded env13053 := by
  intro p hp
  have h : env13053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13052_13053 : H12AffineEnvironment.transform 31 293 env13052 = env13053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env13052 == env13053) = true)

def env13054 : List Nat := [2,4,8,16,32,16,8,256,293,1024,1,1296,8192,1296,292,34,1296,8460,1024,293,1297,8200,16,3,8192,16,0,1296,1296,8461,1284,293,256,8460,1296,293]

theorem envBound13054 : H12AffineFastState.Bounded env13054 := by
  intro p hp
  have h : env13054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13053_13054 : H12AffineEnvironment.transform 5 16 env13053 = env13054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13053 == env13054) = true)

def env13055 : List Nat := [2,4,8,16,32,17,8,256,293,1024,1,1296,8192,1297,292,34,1297,8460,1024,293,1297,8200,17,3,8192,16,0,1297,1296,8461,1284,293,256,8460,1297,293]

theorem envBound13055 : H12AffineFastState.Bounded env13055 := by
  intro p hp
  have h : env13055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13053_13055 : H12AffineEnvironment.transform 5 17 env13053 = env13055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13053 == env13055) = true)

theorem identity13055 : scanCanonicalize (H12AffineFastState.compose env13055 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13056 : List Nat := [2,4,8,16,32,17,8,256,293,1024,1,1296,269,1297,292,34,1297,1,1024,293,1297,261,17,3,269,16,0,1297,1296,0,1284,293,256,1,1297,293]

theorem envBound13056 : H12AffineFastState.Bounded env13056 := by
  intro p hp
  have h : env13056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13055_13056 : H12AffineEnvironment.transform 12 269 env13055 = env13056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13055 == env13056) = true)

theorem identity13056 : scanCanonicalize (H12AffineFastState.compose env13056 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13056 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13057 : List Nat := [2,4,8,16,32,17,8,37,0,1024,1,1077,40,1076,1,34,1076,1,1024,0,1076,32,17,3,40,16,0,1076,1077,0,1057,0,37,1,1076,0]

theorem envBound13057 : H12AffineFastState.Bounded env13057 := by
  intro p hp
  have h : env13057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13056_13057 : H12AffineEnvironment.transform 7 37 env13056 = env13057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13056 == env13057) = true)

theorem identity13057 : scanCanonicalize (H12AffineFastState.compose env13057 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13057 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13058 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1044,9,1045,1,3,1045,1,1024,0,1045,1,17,3,9,16,0,1045,1044,0,1024,0,4,1,1045,0]

theorem envBound13058 : H12AffineFastState.Bounded env13058 := by
  intro p hp
  have h : env13058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13057_13058 : H12AffineEnvironment.transform 4 1 env13057 = env13058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13057 == env13058) = true)

def leafEnv13058 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1044,9,1045,1,3,1045,1,1024,0,1045,1,17,3,1024,9,1,16,0,1045,1044,0,1024,0,4,1,4,2,1045,0,0,1045,1]

def active13058 : List Nat := [0,1,2,3,9]

def tree13058 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13058 : H12WitnessSearch.Good tree13058 := H12GlobalWitnessIndex.good

theorem leafIdentity13058 : H12AffineFastState.composeSystem env13058 rootObs = leafEnv13058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13058 rootObs == leafEnv13058) = true)

theorem terminalChecked13058 : H12PackedTerminal.terminalCheckFast leafEnv13058 active13058 tree13058 = true := by decide +kernel

def env13059 : List Nat := [2,4,8,16,32,64,9,256,292,1024,1,1296,8192,1344,292,35,1344,8460,1024,293,1297,8200,64,2,8193,16,0,1344,1296,8461,1284,4294967296,256,4294975529,1344,292]

theorem envBound13059 : H12AffineFastState.Bounded env13059 := by
  intro p hp
  have h : env13059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13051_13059 : H12AffineEnvironment.transform 6 9 env13051 = env13059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13051 == env13059) = true)

theorem identity13059 : scanCanonicalize (H12AffineFastState.compose env13059 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8232) := by decide +kernel

theorem selectedBound13059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13060 : List Nat := [2,4,8,16,32,64,9,256,292,1024,1,1296,8192,1344,292,35,1344,8460,1024,293,1297,8200,64,2,8193,16,0,1344,1296,8461,1284,8232,256,1,1344,292]

theorem envBound13060 : H12AffineFastState.Bounded env13060 := by
  intro p hp
  have h : env13060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13059_13060 : H12AffineEnvironment.transform 31 8232 env13059 = env13060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8232 env13059 == env13060) = true)

def env13061 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1296,8192,1296,292,35,1296,8460,1024,293,1297,8200,16,2,8193,16,0,1296,1296,8461,1284,8232,256,1,1296,292]

theorem envBound13061 : H12AffineFastState.Bounded env13061 := by
  intro p hp
  have h : env13061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13060_13061 : H12AffineEnvironment.transform 5 16 env13060 = env13061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13060 == env13061) = true)

def env13062 : List Nat := [2,4,8,16,32,17,9,256,292,1024,1,1296,8192,1297,292,35,1297,8460,1024,293,1297,8200,17,2,8193,16,0,1297,1296,8461,1284,8232,256,1,1297,292]

theorem envBound13062 : H12AffineFastState.Bounded env13062 := by
  intro p hp
  have h : env13062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13060_13062 : H12AffineEnvironment.transform 5 17 env13060 = env13062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13060 == env13062) = true)

theorem identity13062 : scanCanonicalize (H12AffineFastState.compose env13062 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13062 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13063 : List Nat := [2,4,8,16,32,17,9,256,292,1024,1,1296,268,1297,292,35,1297,0,1024,293,1297,260,17,2,269,16,0,1297,1296,1,1284,292,256,1,1297,292]

theorem envBound13063 : H12AffineFastState.Bounded env13063 := by
  intro p hp
  have h : env13063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13062_13063 : H12AffineEnvironment.transform 12 268 env13062 = env13063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13062 == env13063) = true)

theorem identity13063 : scanCanonicalize (H12AffineFastState.compose env13063 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13063 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13064 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1076,40,1077,0,35,1077,0,1024,1,1077,32,17,2,41,16,0,1077,1076,1,1056,0,36,1,1077,0]

theorem envBound13064 : H12AffineFastState.Bounded env13064 := by
  intro p hp
  have h : env13064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13063_13064 : H12AffineEnvironment.transform 7 36 env13063 = env13064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13063 == env13064) = true)

theorem identity13064 : scanCanonicalize (H12AffineFastState.compose env13064 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13065 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,9,1044,0,2,1044,0,1024,1,1044,1,17,2,8,16,0,1044,1045,1,1025,0,5,1,1044,0]

theorem envBound13065 : H12AffineFastState.Bounded env13065 := by
  intro p hp
  have h : env13065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13064_13065 : H12AffineEnvironment.transform 4 1 env13064 = env13065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13064 == env13065) = true)

def leafEnv13065 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,9,1044,0,2,1044,0,1024,1,1044,1,17,2,1025,8,1,16,0,1044,1045,1,1025,0,5,1,4,2,1044,0,0,1044,1]

def active13065 : List Nat := [0,1,2,3,9]

def tree13065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13065 : H12WitnessSearch.Good tree13065 := H12GlobalWitnessIndex.good

theorem leafIdentity13065 : H12AffineFastState.composeSystem env13065 rootObs = leafEnv13065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13065 rootObs == leafEnv13065) = true)

theorem terminalChecked13065 : H12PackedTerminal.terminalCheckFast leafEnv13065 active13065 tree13065 = true := by decide +kernel

def env13066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16385,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound13066 : H12AffineFastState.Bounded env13066 := by
  intro p hp
  have h : env13066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13026_13066 : H12AffineEnvironment.transform 16 1345 env13026 = env13066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env13026 == env13066) = true)

theorem identity13066 : scanCanonicalize (H12AffineFastState.compose env13066 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 791632) := by decide +kernel

theorem selectedBound13066 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16385,545089,791632,1284,4294967296,257,4295074214,1345,512]

theorem envBound13067 : H12AffineFastState.Bounded env13067 := by
  intro p hp
  have h : env13067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13066_13067 : H12AffineEnvironment.transform 29 791632 env13066 = env13067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 791632 env13066 == env13067) = true)

theorem identity13067 : scanCanonicalize (H12AffineFastState.compose env13067 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound13067 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env13068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8200,17664,98564,8328,17745,270604,16385,21824,266321,1284,4294967296,257,4295074214,1345,512]

theorem envBound13068 : H12AffineFastState.Bounded env13068 := by
  intro p hp
  have h : env13068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13067_13068 : H12AffineEnvironment.transform 18 1025 env13067 = env13068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13067 == env13068) = true)

theorem identity13068 : scanCanonicalize (H12AffineFastState.compose env13068 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74150) := by decide +kernel

theorem selectedBound13068 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env13069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,74150,1025,32769,4097,8200,17664,98564,8328,17745,65706,16385,21824,78327,1284,4294967296,257,4295074214,1345,512]

theorem envBound13069 : H12AffineFastState.Bounded env13069 := by
  intro p hp
  have h : env13069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13068_13069 : H12AffineEnvironment.transform 17 74150 env13068 = env13069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74150 env13068 == env13069) = true)

theorem identity13069 : scanCanonicalize (H12AffineFastState.compose env13069 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 4347) := by decide +kernel

theorem selectedBound13069 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env13070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,4347,1345,12637,1025,32769,4097,8200,17664,37375,8328,17745,4177,16385,21824,8460,1284,4294967296,257,4295012701,1345,512]

theorem envBound13070 : H12AffineFastState.Bounded env13070 := by
  intro p hp
  have h : env13070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13069_13070 : H12AffineEnvironment.transform 15 4347 env13069 = env13070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4347 env13069 == env13070) = true)

theorem identity13070 : scanCanonicalize (H12AffineFastState.compose env13070 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 30008) := by decide +kernel

theorem selectedBound13070 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env13071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,30008,4347,1345,12637,1025,30009,4097,8200,17664,25799,8328,17745,4177,16385,21824,8460,1284,4294967296,257,4294984805,1345,512]

theorem envBound13071 : H12AffineFastState.Bounded env13071 := by
  intro p hp
  have h : env13071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13070_13071 : H12AffineEnvironment.transform 14 30008 env13070 = env13071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30008 env13070 == env13071) = true)

theorem identity13071 : scanCanonicalize (H12AffineFastState.compose env13071 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound13071 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,0,13624,4347,1345,12637,1025,13625,4097,8200,1280,9415,8328,1361,4177,1,5440,8460,1284,4294967296,257,4294968421,1345,512]

theorem envBound13072 : H12AffineFastState.Bounded env13072 := by
  intro p hp
  have h : env13072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13071_13072 : H12AffineEnvironment.transform 13 0 env13071 = env13072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env13071 == env13072) = true)

theorem identity13072 : scanCanonicalize (H12AffineFastState.compose env13072 (packedSelected [0,4,7,9,12] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound13072 : packedSelected [0,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env13073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,0,13624,4347,1345,12637,1025,13625,4097,8200,1280,9415,8328,1361,4177,1,5440,8460,1284,396,257,1513,1345,512]

theorem envBound13073 : H12AffineFastState.Bounded env13073 := by
  intro p hp
  have h : env13073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13072_13073 : H12AffineEnvironment.transform 31 396 env13072 = env13073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env13072 == env13073) = true)

theorem identity13073 : scanCanonicalize (H12AffineFastState.compose env13073 (packedSelected [0,3,4,7,8,9,13] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound13073 : packedSelected [0,3,4,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env13074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,8192,0,9093,1606,1345,10208,1025,9092,1724,8200,1280,9415,8328,1361,1772,1,1021,8460,1284,396,257,1513,1345,512]

theorem envBound13074 : H12AffineFastState.Bounded env13074 := by
  intro p hp
  have h : env13074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13073_13074 : H12AffineEnvironment.transform 11 1725 env13073 = env13074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env13073 == env13074) = true)

theorem identity13074 : scanCanonicalize (H12AffineFastState.compose env13074 (packedSelected [1,3,5,8,18] rootPS)) = affineNative (2^(12+1) ^^^ 753) := by decide +kernel

theorem selectedBound13074 : packedSelected [1,3,5,8,18] rootPS < 2^1333 := by decide +kernel

def env13075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,753,0,372,1606,1345,1297,1025,373,1724,761,1280,1590,633,1361,1772,1,1021,1021,1284,396,257,1513,1345,512]

theorem envBound13075 : H12AffineFastState.Bounded env13075 := by
  intro p hp
  have h : env13075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13074_13075 : H12AffineEnvironment.transform 12 753 env13074 = env13075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 753 env13074 == env13075) = true)

theorem identity13075 : scanCanonicalize (H12AffineFastState.compose env13075 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13075 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13076 : List Nat := [2,4,8,16,32,64,128,256,512,272,1,941,753,0,372,854,81,1,273,373,940,761,16,806,633,65,1020,1,1021,1021,20,396,257,249,81,512]

theorem envBound13076 : H12AffineFastState.Bounded env13076 := by
  intro p hp
  have h : env13076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13075_13076 : H12AffineEnvironment.transform 9 272 env13075 = env13076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13075 == env13076) = true)

theorem identity13076 : scanCanonicalize (H12AffineFastState.compose env13076 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13076 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13077 : List Nat := [2,4,8,16,32,64,128,256,1,272,1,428,240,0,372,343,81,1,273,373,429,248,16,295,120,65,509,1,508,508,20,396,257,249,81,1]

theorem envBound13077 : H12AffineFastState.Bounded env13077 := by
  intro p hp
  have h : env13077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13076_13077 : H12AffineEnvironment.transform 8 1 env13076 = env13077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13076 == env13077) = true)

theorem identity13077 : scanCanonicalize (H12AffineFastState.compose env13077 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound13077 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13078 : List Nat := [2,4,8,16,32,64,128,253,1,237,1,81,240,0,137,170,81,1,236,136,80,248,16,218,120,65,0,1,1,1,20,113,252,249,81,1]

theorem envBound13078 : H12AffineFastState.Bounded env13078 := by
  intro p hp
  have h : env13078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13077_13078 : H12AffineEnvironment.transform 7 253 env13077 = env13078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env13077 == env13078) = true)

theorem identity13078 : scanCanonicalize (H12AffineFastState.compose env13078 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound13078 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13079 : List Nat := [2,4,8,16,26,64,128,199,1,215,1,81,202,0,137,144,81,1,214,136,80,194,16,218,66,65,0,1,1,1,20,75,198,195,81,1]

theorem envBound13079 : H12AffineFastState.Bounded env13079 := by
  intro p hp
  have h : env13079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13078_13079 : H12AffineEnvironment.transform 4 26 env13078 = env13079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env13078 == env13079) = true)

theorem identity13079 : scanCanonicalize (H12AffineFastState.compose env13079 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13079 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env13080 : List Nat := [2,4,8,16,26,17,128,150,1,134,1,0,155,0,137,144,0,1,135,136,1,147,16,139,19,16,0,1,1,1,20,26,151,146,0,1]

theorem envBound13080 : H12AffineFastState.Bounded env13080 := by
  intro p hp
  have h : env13080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13079_13080 : H12AffineEnvironment.transform 5 17 env13079 = env13080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13079 == env13080) = true)

theorem identity13080 : scanCanonicalize (H12AffineFastState.compose env13080 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13081 : List Nat := [2,4,8,0,10,1,128,134,1,134,1,0,139,0,137,128,0,1,135,136,1,131,0,139,3,0,0,1,1,1,4,10,135,130,0,1]

theorem envBound13081 : H12AffineFastState.Bounded env13081 := by
  intro p hp
  have h : env13081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13080_13081 : H12AffineEnvironment.transform 3 0 env13080 = env13081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13080 == env13081) = true)

theorem identity13081 : scanCanonicalize (H12AffineFastState.compose env13081 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13082 : List Nat := [2,4,8,0,10,1,9,15,1,15,1,0,2,0,0,9,0,1,14,1,1,10,0,2,3,0,0,1,1,1,4,10,14,11,0,1]

theorem envBound13082 : H12AffineFastState.Bounded env13082 := by
  intro p hp
  have h : env13082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13081_13082 : H12AffineEnvironment.transform 6 9 env13081 = env13082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13081 == env13082) = true)

def env13083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,5111876,148801,676864,1073741824,17006912,4294967296,132161,4315938986,16876612,512]

theorem envBound13083 : H12AffineFastState.Bounded env13083 := by
  intro p hp
  have h : env13083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12840_13083 : H12AffineEnvironment.transform 22 17665 env12840 = env13083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env12840 == env13083) = true)

theorem identity13083 : scanCanonicalize (H12AffineFastState.compose env13083 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound13083 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env13084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4982021,16384,545089,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound13084 : H12AffineFastState.Bounded env13084 := by
  intro p hp
  have h : env13084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13083_13084 : H12AffineEnvironment.transform 16 1345 env13083 = env13084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env13083 == env13084) = true)

theorem identity13084 : scanCanonicalize (H12AffineFastState.compose env13084 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound13084 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env13085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4097,4194304,17665,16777216,8328,17745,4456709,16384,21825,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound13085 : H12AffineFastState.Bounded env13085 := by
  intro p hp
  have h : env13085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13084_13085 : H12AffineEnvironment.transform 18 1024 env13084 = env13085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13084 == env13085) = true)

def env13086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,1024,32769,4097,4194304,65,16777216,8328,17,4456709,1344,4097,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound13086 : H12AffineFastState.Bounded env13086 := by
  intro p hp
  have h : env13086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13085_13086 : H12AffineEnvironment.transform 13 1344 env13085 = env13086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env13085 == env13086) = true)

theorem identity13086 : scanCanonicalize (H12AffineFastState.compose env13086 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13086 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,1296,262144,1024,32769,4097,4194304,16,16777216,8328,17,4456709,1297,4097,1073741824,16876545,4294967296,256,4315938986,16876565,512]

theorem envBound13087 : H12AffineFastState.Bounded env13087 := by
  intro p hp
  have h : env13087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13086_13087 : H12AffineEnvironment.transform 5 17 env13086 = env13087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13086 == env13087) = true)

def env13088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1024,32769,4097,4194304,64,16777216,8328,16,4456709,1345,4096,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound13088 : H12AffineFastState.Bounded env13088 := by
  intro p hp
  have h : env13088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13085_13088 : H12AffineEnvironment.transform 13 1345 env13085 = env13088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env13085 == env13088) = true)

theorem identity13088 : scanCanonicalize (H12AffineFastState.compose env13088 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound13088 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,16777216,8328,16,4456709,1345,1345,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound13089 : H12AffineFastState.Bounded env13089 := by
  intro p hp
  have h : env13089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13088_13089 : H12AffineEnvironment.transform 11 1345 env13088 = env13089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env13088 == env13089) = true)

theorem identity13089 : scanCanonicalize (H12AffineFastState.compose env13089 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound13089 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,138,8328,16,4456709,1345,1345,1073741824,99467,4294967296,256,4299161632,99534,512]

theorem envBound13090 : H12AffineFastState.Bounded env13090 := by
  intro p hp
  have h : env13090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13089_13090 : H12AffineEnvironment.transform 23 138 env13089 = env13090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env13089 == env13090) = true)

theorem identity13090 : scanCanonicalize (H12AffineFastState.compose env13090 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound13090 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env13091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,76199,1024,32769,1344,4194304,64,138,8328,16,4270242,1345,1345,1073741824,99467,4294967296,256,4299161632,99534,512]

theorem envBound13091 : H12AffineFastState.Bounded env13091 := by
  intro p hp
  have h : env13091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13090_13091 : H12AffineEnvironment.transform 17 76199 env13090 = env13091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env13090 == env13091) = true)

theorem identity13091 : scanCanonicalize (H12AffineFastState.compose env13091 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4294795) := by decide +kernel

theorem selectedBound13091 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env13092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,76199,1024,32769,1344,4194304,64,138,8328,16,4270242,1345,1345,4294795,99467,4294967296,256,4299161632,99534,512]

theorem envBound13092 : H12AffineFastState.Bounded env13092 := by
  intro p hp
  have h : env13092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13091_13092 : H12AffineEnvironment.transform 29 4294795 env13091 = env13092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294795 env13091 == env13092) = true)

theorem identity13092 : scanCanonicalize (H12AffineFastState.compose env13092 (packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound13092 : packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env13093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,9093,65536,1345,76199,1024,9092,1344,4194304,64,138,8328,16,4270242,1345,1345,4270862,75534,4294967296,256,4299161632,75595,512]

theorem envBound13093 : H12AffineFastState.Bounded env13093 := by
  intro p hp
  have h : env13093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13092_13093 : H12AffineEnvironment.transform 14 9093 env13092 = env13093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env13092 == env13093) = true)

theorem identity13093 : scanCanonicalize (H12AffineFastState.compose env13093 (packedSelected [0,2,5,6,8,9,10,12,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8794) := by decide +kernel

theorem selectedBound13093 : packedSelected [0,2,5,6,8,9,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env13094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,9093,8794,1345,3069,1024,9092,1344,4194304,64,138,8328,16,4197112,1345,1345,4196692,1364,4294967296,256,4299161632,1297,512]

theorem envBound13094 : H12AffineFastState.Bounded env13094 := by
  intro p hp
  have h : env13094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13093_13094 : H12AffineEnvironment.transform 15 8794 env13093 = env13094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8794 env13093 == env13094) = true)

theorem identity13094 : scanCanonicalize (H12AffineFastState.compose env13094 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(31+1) ^^^ 10449) := by decide +kernel

theorem selectedBound13094 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env13095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,9093,8794,1345,3069,1024,9092,1344,4194304,64,138,8328,16,4197112,1345,1345,4196692,1364,10449,256,4204785,1297,512]

theorem envBound13095 : H12AffineFastState.Bounded env13095 := by
  intro p hp
  have h : env13095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13094_13095 : H12AffineEnvironment.transform 31 10449 env13094 = env13095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10449 env13094 == env13095) = true)

theorem identity13095 : scanCanonicalize (H12AffineFastState.compose env13095 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(21+1) ^^^ 11132) := by decide +kernel

theorem selectedBound13095 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,9093,8794,1345,3069,1024,9092,1344,11132,64,138,8328,16,8580,1345,1345,8744,1364,10449,256,909,1297,512]

theorem envBound13096 : H12AffineFastState.Bounded env13096 := by
  intro p hp
  have h : env13096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13095_13096 : H12AffineEnvironment.transform 21 11132 env13095 = env13096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 11132 env13095 == env13096) = true)

theorem identity13096 : scanCanonicalize (H12AffineFastState.compose env13096 (packedSelected [0,1,2,4,5,6,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound13096 : packedSelected [0,1,2,4,5,6,11,17] rootPS < 2^1333 := by decide +kernel

def env13097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2720,1345,2341,2298,1345,3069,1024,2340,1344,476,64,138,2600,16,2852,1345,1345,2184,1364,625,256,909,1297,512]

theorem envBound13097 : H12AffineFastState.Bounded env13097 := by
  intro p hp
  have h : env13097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13096_13097 : H12AffineEnvironment.transform 12 2720 env13096 = env13097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env13096 == env13097) = true)

theorem identity13097 : scanCanonicalize (H12AffineFastState.compose env13097 (packedSelected [5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound13097 : packedSelected [5,8,11] rootPS < 2^1333 := by decide +kernel

def env13098 : List Nat := [2,4,8,16,32,64,128,256,372,1024,2048,1345,2516,1345,2341,2298,1345,2185,1024,2340,1344,476,64,138,2396,16,2128,1345,1345,2184,1364,261,256,249,1297,372]

theorem envBound13098 : H12AffineFastState.Bounded env13098 := by
  intro p hp
  have h : env13098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13097_13098 : H12AffineEnvironment.transform 8 372 env13097 = env13098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env13097 == env13098) = true)

theorem identity13098 : scanCanonicalize (H12AffineFastState.compose env13098 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound13098 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13099 : List Nat := [2,4,8,16,32,64,128,256,372,1024,292,1345,240,1345,1,478,1345,429,1024,0,1344,476,64,138,120,16,372,1345,1345,428,1364,261,256,249,1297,372]

theorem envBound13099 : H12AffineFastState.Bounded env13099 := by
  intro p hp
  have h : env13099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13098_13099 : H12AffineEnvironment.transform 10 292 env13098 = env13099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env13098 == env13099) = true)

theorem identity13099 : scanCanonicalize (H12AffineFastState.compose env13099 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound13099 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env13100 : List Nat := [2,4,8,16,32,64,88,256,372,1024,292,1345,40,1345,1,262,1345,373,1024,0,1344,260,64,82,120,16,372,1345,1345,372,1364,261,256,33,1297,372]

theorem envBound13100 : H12AffineFastState.Bounded env13100 := by
  intro p hp
  have h : env13100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13099_13100 : H12AffineEnvironment.transform 6 88 env13099 = env13100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env13099 == env13100) = true)

theorem identity13100 : scanCanonicalize (H12AffineFastState.compose env13100 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound13100 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13101 : List Nat := [2,4,8,16,32,64,88,256,372,273,292,80,40,80,1,262,80,373,273,0,81,260,64,82,120,16,372,80,80,372,69,261,256,33,0,372]

theorem envBound13101 : H12AffineFastState.Bounded env13101 := by
  intro p hp
  have h : env13101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13100_13101 : H12AffineEnvironment.transform 9 273 env13100 = env13101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13100 == env13101) = true)

theorem identity13101 : scanCanonicalize (H12AffineFastState.compose env13101 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13101 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13102 : List Nat := [2,4,8,16,32,64,88,36,80,53,0,80,40,80,1,34,80,81,53,0,81,32,64,82,120,16,80,80,80,80,69,33,36,33,0,80]

theorem envBound13102 : H12AffineFastState.Bounded env13102 := by
  intro p hp
  have h : env13102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13101_13102 : H12AffineEnvironment.transform 7 36 env13101 = env13102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13101 == env13102) = true)

theorem identity13102 : scanCanonicalize (H12AffineFastState.compose env13102 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13102 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13103 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,0,40,0,1,34,0,1,53,0,1,32,16,2,40,16,0,0,0,0,21,33,36,33,0,0]

theorem envBound13103 : H12AffineFastState.Bounded env13103 := by
  intro p hp
  have h : env13103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13102_13103 : H12AffineEnvironment.transform 5 16 env13102 = env13103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13102 == env13103) = true)

theorem identity13103 : scanCanonicalize (H12AffineFastState.compose env13103 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13104 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,0,8,0,1,2,0,1,21,0,1,0,16,2,8,16,0,0,0,0,21,1,4,1,0,0]

theorem envBound13104 : H12AffineFastState.Bounded env13104 := by
  intro p hp
  have h : env13104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13103_13104 : H12AffineEnvironment.transform 4 0 env13103 = env13104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13103 == env13104) = true)

theorem identity13104 : scanCanonicalize (H12AffineFastState.compose env13104 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13105 : List Nat := [2,4,8,0,0,0,8,4,0,5,0,0,8,0,1,2,0,1,5,0,1,0,0,2,8,0,0,0,0,0,5,1,4,1,0,0]

theorem envBound13105 : H12AffineFastState.Bounded env13105 := by
  intro p hp
  have h : env13105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13104_13105 : H12AffineEnvironment.transform 3 0 env13104 = env13105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13104 == env13105) = true)

def env13106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,536870912,1073741824,562663489,4294967296,545789248,4315938986,702907649,512]

theorem envBound13106 : H12AffineFastState.Bounded env13106 := by
  intro p hp
  have h : env13106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12206_13106 : H12AffineEnvironment.transform 34 702907649 env12206 = env13106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907649 env12206 == env13106) = true)

def env13107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,2769920,1073741824,27513921,4294967296,10637632,4315938986,164610305,512]

theorem envBound13107 : H12AffineFastState.Bounded env13107 := by
  intro p hp
  have h : env13107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13106_13107 : H12AffineEnvironment.transform 28 2769920 env13106 = env13107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env13106 == env13107) = true)

def env13108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,164610305,512]

theorem envBound13108 : H12AffineFastState.Bounded env13108 := by
  intro p hp
  have h : env13108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13107_13108 : H12AffineEnvironment.transform 20 4096 env13107 = env13108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env13107 == env13108) = true)

theorem identity13108 : scanCanonicalize (H12AffineFastState.compose env13108 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound13108 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env13109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,98565,8328,8914000,134217728,8519744,676864,1073741824,8537412,4294967296,8536384,4299260335,147734532,512]

theorem envBound13109 : H12AffineFastState.Bounded env13109 := by
  intro p hp
  have h : env13109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13108_13109 : H12AffineEnvironment.transform 23 98565 env13108 = env13109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env13108 == env13109) = true)

def env13110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,98565,8328,8914000,134217728,8389888,545088,1073741824,8404996,4294967296,8406016,4299260335,147604804,512]

theorem envBound13110 : H12AffineFastState.Bounded env13110 := by
  intro p hp
  have h : env13110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13109_13110 : H12AffineEnvironment.transform 16 1344 env13109 = env13110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env13109 == env13110) = true)

theorem identity13110 : scanCanonicalize (H12AffineFastState.compose env13110 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 17664) := by decide +kernel

theorem selectedBound13110 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env13111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17664,98565,8328,541008,134217728,16384,545088,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13111 : H12AffineFastState.Bounded env13111 := by
  intro p hp
  have h : env13111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13110_13111 : H12AffineEnvironment.transform 22 17664 env13110 = env13111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env13110 == env13111) = true)

def env13112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,524288,32769,1344,4194304,17664,98565,8328,541008,134217728,16384,541696,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13112 : H12AffineFastState.Bounded env13112 := by
  intro p hp
  have h : env13112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13111_13112 : H12AffineEnvironment.transform 11 1344 env13111 = env13112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env13111 == env13112) = true)

def env13113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13113 : H12AffineFastState.Bounded env13113 := by
  intro p hp
  have h : env13113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13112_13113 : H12AffineEnvironment.transform 13 1344 env13112 = env13113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env13112 == env13113) = true)

def env13114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,138936900,512]

theorem envBound13114 : H12AffineFastState.Bounded env13114 := by
  intro p hp
  have h : env13114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13113_13114 : H12AffineEnvironment.transform 17 512 env13113 = env13114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env13113 == env13114) = true)

def env13115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1104,32769,1344,4194304,64,98565,8328,64,134217728,1344,1296,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13115 : H12AffineFastState.Bounded env13115 := by
  intro p hp
  have h : env13115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13114_13115 : H12AffineEnvironment.transform 18 1104 env13114 = env13115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env13114 == env13115) = true)

def env13116 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1024,32769,1296,4194304,16,98565,8328,16,134217728,1296,1296,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13116 : H12AffineFastState.Bounded env13116 := by
  intro p hp
  have h : env13116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13115_13116 : H12AffineEnvironment.transform 5 16 env13115 = env13116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13115 == env13116) = true)

theorem identity13116 : scanCanonicalize (H12AffineFastState.compose env13116 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4195076) := by decide +kernel

theorem selectedBound13116 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env13117 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1024,32769,1296,4194304,16,98565,8328,16,4195076,1296,1296,1073741824,1284,4294967296,256,4299260335,1296,512]

theorem envBound13117 : H12AffineFastState.Bounded env13117 := by
  intro p hp
  have h : env13117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13116_13117 : H12AffineEnvironment.transform 26 4195076 env13116 = env13117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195076 env13116 == env13117) = true)

def env13118 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,32768,65536,0,512,272,32769,0,4194304,16,98565,8328,16,4195076,0,0,1073741824,20,4294967296,256,4299260335,0,512]

theorem envBound13118 : H12AffineFastState.Bounded env13118 := by
  intro p hp
  have h : env13118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13117_13118 : H12AffineEnvironment.transform 9 272 env13117 = env13118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13117 == env13118) = true)

def env13119 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,260,65536,0,512,272,261,0,4194304,16,65537,8328,16,4195076,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13119 : H12AffineFastState.Bounded env13119 := by
  intro p hp
  have h : env13119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13118_13119 : H12AffineEnvironment.transform 14 260 env13118 = env13119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env13118 == env13119) = true)

def env13120 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,260,65536,0,512,272,261,0,4194304,16,65537,128,16,4195076,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13120 : H12AffineFastState.Bounded env13120 := by
  intro p hp
  have h : env13120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13119_13120 : H12AffineEnvironment.transform 12 8 env13119 = env13120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13119 == env13120) = true)

theorem identity13120 : scanCanonicalize (H12AffineFastState.compose env13120 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1073744165) := by decide +kernel

theorem selectedBound13120 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13121 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,260,65536,0,512,272,261,0,4194304,16,65537,128,16,4195076,0,0,1073741824,20,1073744165,256,1078004110,0,512]

theorem envBound13121 : H12AffineFastState.Bounded env13121 := by
  intro p hp
  have h : env13121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13120_13121 : H12AffineEnvironment.transform 31 1073744165 env13120 = env13121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073744165 env13120 == env13121) = true)

def env13122 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,4194304,16,65537,128,16,4194816,0,0,1073741824,20,1073743905,4,1078003850,0,512]

theorem envBound13122 : H12AffineFastState.Bounded env13122 := by
  intro p hp
  have h : env13122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13121_13122 : H12AffineEnvironment.transform 7 4 env13121 = env13122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13121 == env13122) = true)

def env13123 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,512,16,65537,128,16,0,0,0,1073741824,20,1073743905,4,1073810058,0,512]

theorem envBound13123 : H12AffineFastState.Bounded env13123 := by
  intro p hp
  have h : env13123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13122_13123 : H12AffineEnvironment.transform 21 512 env13122 = env13123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13122 == env13123) = true)

theorem identity13123 : scanCanonicalize (H12AffineFastState.compose env13123 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13123 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13124 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,512,16,65537,8,16,0,0,0,1073741824,20,1073743905,4,1073809922,0,512]

theorem envBound13124 : H12AffineFastState.Bounded env13124 := by
  intro p hp
  have h : env13124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13123_13124 : H12AffineEnvironment.transform 6 8 env13123 = env13124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13123 == env13124) = true)

def env13125 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,512,16,65537,8,16,0,0,0,0,20,2081,4,68098,0,512]

theorem envBound13125 : H12AffineFastState.Bounded env13125 := by
  intro p hp
  have h : env13125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13124_13125 : H12AffineEnvironment.transform 29 0 env13124 = env13125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env13124 == env13125) = true)

theorem identity13125 : scanCanonicalize (H12AffineFastState.compose env13125 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound13125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13126 : List Nat := [2,4,8,16,32,16,8,4,512,20,545,0,8,0,0,65536,0,512,20,1,0,512,16,65537,8,16,0,0,0,0,20,512,4,65571,0,512]

theorem envBound13126 : H12AffineFastState.Bounded env13126 := by
  intro p hp
  have h : env13126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13125_13126 : H12AffineEnvironment.transform 10 545 env13125 = env13126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env13125 == env13126) = true)

theorem identity13126 : scanCanonicalize (H12AffineFastState.compose env13126 (packedSelected [4,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13126 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13127 : List Nat := [2,4,8,16,1,16,8,4,512,20,512,0,8,0,0,65536,0,512,20,1,0,512,16,65537,8,16,0,0,0,0,20,512,4,65538,0,512]

theorem envBound13127 : H12AffineFastState.Bounded env13127 := by
  intro p hp
  have h : env13127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13126_13127 : H12AffineEnvironment.transform 4 1 env13126 = env13127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13126 == env13127) = true)

def env13128 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,0,0,65536,0,0,20,1,0,0,16,65537,8,16,0,0,0,0,20,0,4,65538,0,0]

theorem envBound13128 : H12AffineFastState.Bounded env13128 := by
  intro p hp
  have h : env13128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13127_13128 : H12AffineEnvironment.transform 8 0 env13127 = env13128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13127 == env13128) = true)

def leafEnv13128 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,0,0,65536,0,0,20,1,0,0,16,65537,20,8,1,16,0,0,0,0,20,0,4,65538,4,3,0,0,0,0,1]

def active13128 : List Nat := [0,1,2,3,15]

def tree13128 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13128 : H12WitnessSearch.Good tree13128 := H12GlobalWitnessIndex.good

theorem leafIdentity13128 : H12AffineFastState.composeSystem env13128 rootObs = leafEnv13128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13128 rootObs == leafEnv13128) = true)

theorem terminalChecked13128 : H12PackedTerminal.terminalCheckFast leafEnv13128 active13128 tree13128 = true := by decide +kernel

def env13129 : List Nat := [2,4,8,16,1,16,8,4,1,20,1,0,8,0,0,65536,0,1,20,1,0,1,16,65537,8,16,0,0,0,0,20,1,4,65538,0,1]

theorem envBound13129 : H12AffineFastState.Bounded env13129 := by
  intro p hp
  have h : env13129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13127_13129 : H12AffineEnvironment.transform 8 1 env13127 = env13129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13127 == env13129) = true)

theorem identity13129 : scanCanonicalize (H12AffineFastState.compose env13129 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13129 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13130 : List Nat := [2,4,8,16,1,16,8,4,1,20,1,0,8,0,0,2,0,1,20,1,0,1,16,3,8,16,0,0,0,0,20,1,4,0,0,1]

theorem envBound13130 : H12AffineFastState.Bounded env13130 := by
  intro p hp
  have h : env13130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13129_13130 : H12AffineEnvironment.transform 15 2 env13129 = env13130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13129 == env13130) = true)

def leafEnv13130 : List Nat := [2,4,8,16,1,16,8,4,1,20,1,0,8,0,0,2,0,1,20,1,0,1,16,3,20,8,1,16,0,0,0,0,20,1,4,0,4,3,0,1,0,0,1]

def active13130 : List Nat := [0,1,2,3]

def tree13130 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13130 : H12WitnessSearch.Good tree13130 := H12GlobalWitnessIndex.good

theorem leafIdentity13130 : H12AffineFastState.composeSystem env13130 rootObs = leafEnv13130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13130 rootObs == leafEnv13130) = true)

theorem terminalChecked13130 : H12PackedTerminal.terminalCheckFast leafEnv13130 active13130 tree13130 = true := by decide +kernel

def env13131 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,512,16,65537,8,16,0,0,0,1,20,2080,4,68099,0,512]

theorem envBound13131 : H12AffineFastState.Bounded env13131 := by
  intro p hp
  have h : env13131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13124_13131 : H12AffineEnvironment.transform 29 1 env13124 = env13131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env13124 == env13131) = true)

theorem identity13131 : scanCanonicalize (H12AffineFastState.compose env13131 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13132 : List Nat := [2,4,8,16,32,16,8,4,32,20,2048,0,8,0,0,65536,0,32,20,1,0,32,16,65537,8,16,0,0,0,1,20,2080,4,67619,0,32]

theorem envBound13132 : H12AffineFastState.Bounded env13132 := by
  intro p hp
  have h : env13132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13131_13132 : H12AffineEnvironment.transform 8 32 env13131 = env13132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13131 == env13132) = true)

theorem identity13132 : scanCanonicalize (H12AffineFastState.compose env13132 (packedSelected [4,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13132 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13133 : List Nat := [2,4,8,16,0,16,8,4,0,20,2048,0,8,0,0,65536,0,0,20,1,0,0,16,65537,8,16,0,0,0,1,20,2048,4,67587,0,0]

theorem envBound13133 : H12AffineFastState.Bounded env13133 := by
  intro p hp
  have h : env13133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13132_13133 : H12AffineEnvironment.transform 4 0 env13132 = env13133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13132 == env13133) = true)

theorem identity13133 : scanCanonicalize (H12AffineFastState.compose env13133 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13133 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13134 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,8,0,0,65536,0,0,20,1,0,0,16,65537,8,16,0,0,0,1,20,1,4,65538,0,0]

theorem envBound13134 : H12AffineFastState.Bounded env13134 := by
  intro p hp
  have h : env13134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13133_13134 : H12AffineEnvironment.transform 10 1 env13133 = env13134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13133 == env13134) = true)

theorem identity13134 : scanCanonicalize (H12AffineFastState.compose env13134 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13135 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,8,0,0,2,0,0,20,1,0,0,16,3,8,16,0,0,0,1,20,1,4,0,0,0]

theorem envBound13135 : H12AffineFastState.Bounded env13135 := by
  intro p hp
  have h : env13135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13134_13135 : H12AffineEnvironment.transform 15 2 env13134 = env13135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13134 == env13135) = true)

def leafEnv13135 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,8,0,0,2,0,0,20,1,0,0,16,3,20,8,1,16,0,0,0,1,20,1,4,0,4,3,0,0,0,0,1]

def active13135 : List Nat := [0,1,2,3]

def tree13135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13135 : H12WitnessSearch.Good tree13135 := H12GlobalWitnessIndex.good

theorem leafIdentity13135 : H12AffineFastState.composeSystem env13135 rootObs = leafEnv13135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13135 rootObs == leafEnv13135) = true)

theorem terminalChecked13135 : H12PackedTerminal.terminalCheckFast leafEnv13135 active13135 tree13135 = true := by decide +kernel

def env13136 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,512,20,1,0,513,16,65537,128,16,1,0,0,1073741824,20,1073743905,4,1073810059,0,512]

theorem envBound13136 : H12AffineFastState.Bounded env13136 := by
  intro p hp
  have h : env13136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13122_13136 : H12AffineEnvironment.transform 21 513 env13122 = env13136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13122 == env13136) = true)

def env13137 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,512,21,0,0,4194304,16,65537,128,16,4194817,0,0,1073741824,20,1073743904,5,1078003851,0,512]

theorem envBound13137 : H12AffineFastState.Bounded env13137 := by
  intro p hp
  have h : env13137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13121_13137 : H12AffineEnvironment.transform 7 5 env13121 = env13137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13121 == env13137) = true)

def env13138 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,512,21,0,0,512,16,65537,128,16,1,0,0,1073741824,20,1073743904,5,1073810059,0,512]

theorem envBound13138 : H12AffineFastState.Bounded env13138 := by
  intro p hp
  have h : env13138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13137_13138 : H12AffineEnvironment.transform 21 512 env13137 = env13138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13137 == env13138) = true)

theorem identity13138 : scanCanonicalize (H12AffineFastState.compose env13138 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 67722) := by decide +kernel

theorem selectedBound13138 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13139 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,512,21,0,0,512,16,65537,128,16,1,0,0,67722,20,65706,5,513,0,512]

theorem envBound13139 : H12AffineFastState.Bounded env13139 := by
  intro p hp
  have h : env13139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13138_13139 : H12AffineEnvironment.transform 29 67722 env13138 = env13139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67722 env13138 == env13139) = true)

theorem identity13139 : scanCanonicalize (H12AffineFastState.compose env13139 (packedSelected [4,9,32] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound13139 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13140 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,2219,0,512,21,0,0,512,16,2218,128,16,1,0,0,33,20,2049,5,513,0,512]

theorem envBound13140 : H12AffineFastState.Bounded env13140 := by
  intro p hp
  have h : env13140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13139_13140 : H12AffineEnvironment.transform 15 2219 env13139 = env13140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env13139 == env13140) = true)

theorem identity13140 : scanCanonicalize (H12AffineFastState.compose env13140 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound13140 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13141 : List Nat := [2,4,8,16,32,16,128,5,512,21,544,0,8,0,1,651,0,512,21,0,0,512,16,650,128,16,1,0,0,33,20,545,5,513,0,512]

theorem envBound13141 : H12AffineFastState.Bounded env13141 := by
  intro p hp
  have h : env13141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13140_13141 : H12AffineEnvironment.transform 10 544 env13140 = env13141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env13140 == env13141) = true)

theorem identity13141 : scanCanonicalize (H12AffineFastState.compose env13141 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13141 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13142 : List Nat := [2,4,8,16,32,16,128,5,32,21,0,0,8,0,1,171,0,32,21,0,0,32,16,170,128,16,1,0,0,33,20,1,5,33,0,32]

theorem envBound13142 : H12AffineFastState.Bounded env13142 := by
  intro p hp
  have h : env13142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13141_13142 : H12AffineEnvironment.transform 8 32 env13141 = env13142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13141 == env13142) = true)

def env13143 : List Nat := [2,4,8,16,0,16,128,5,0,21,0,0,8,0,1,139,0,0,21,0,0,0,16,138,128,16,1,0,0,1,20,1,5,1,0,0]

theorem envBound13143 : H12AffineFastState.Bounded env13143 := by
  intro p hp
  have h : env13143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13142_13143 : H12AffineEnvironment.transform 4 0 env13142 = env13143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13142 == env13143) = true)

theorem identity13143 : scanCanonicalize (H12AffineFastState.compose env13143 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13144 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,8,0,1,3,0,0,21,0,0,0,16,2,8,16,1,0,0,1,20,1,5,1,0,0]

theorem envBound13144 : H12AffineFastState.Bounded env13144 := by
  intro p hp
  have h : env13144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13143_13144 : H12AffineEnvironment.transform 6 8 env13143 = env13144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13143 == env13144) = true)

def leafEnv13144 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,8,0,1,3,0,0,21,0,0,0,16,2,20,8,1,16,1,0,0,1,20,1,5,1,4,3,0,0,0,0,1]

def active13144 : List Nat := [0,1,2,3]

def tree13144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13144 : H12WitnessSearch.Good tree13144 := H12GlobalWitnessIndex.good

theorem leafIdentity13144 : H12AffineFastState.composeSystem env13144 rootObs = leafEnv13144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13144 rootObs == leafEnv13144) = true)

theorem terminalChecked13144 : H12PackedTerminal.terminalCheckFast leafEnv13144 active13144 tree13144 = true := by decide +kernel

def env13145 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,8,0,1,138,0,1,21,0,0,1,16,139,128,16,1,0,0,0,20,1,5,0,0,1]

theorem envBound13145 : H12AffineFastState.Bounded env13145 := by
  intro p hp
  have h : env13145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13142_13145 : H12AffineEnvironment.transform 4 1 env13142 = env13145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13142 == env13145) = true)

def leafEnv13145 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,8,0,1,138,0,1,21,0,0,1,16,139,20,128,1,16,1,0,0,0,20,1,5,0,4,3,0,1,0,0,1]

def active13145 : List Nat := [0,1,2,3,6]

def tree13145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13145 : H12WitnessSearch.Good tree13145 := H12GlobalWitnessIndex.good

theorem leafIdentity13145 : H12AffineFastState.composeSystem env13145 rootObs = leafEnv13145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13145 rootObs == leafEnv13145) = true)

theorem terminalChecked13145 : H12PackedTerminal.terminalCheckFast leafEnv13145 active13145 tree13145 = true := by decide +kernel

def env13146 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,512,21,0,0,513,16,65537,128,16,0,0,0,1073741824,20,1073743904,5,1073810058,0,512]

theorem envBound13146 : H12AffineFastState.Bounded env13146 := by
  intro p hp
  have h : env13146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13137_13146 : H12AffineEnvironment.transform 21 513 env13137 = env13146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13137 == env13146) = true)

theorem identity13146 : scanCanonicalize (H12AffineFastState.compose env13146 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 67587) := by decide +kernel

theorem selectedBound13146 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13147 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,512,21,0,0,513,16,65537,128,16,0,0,0,67587,20,65571,5,649,0,512]

theorem envBound13147 : H12AffineFastState.Bounded env13147 := by
  intro p hp
  have h : env13147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13146_13147 : H12AffineEnvironment.transform 29 67587 env13146 = env13147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67587 env13146 == env13147) = true)

theorem identity13147 : scanCanonicalize (H12AffineFastState.compose env13147 (packedSelected [4,9,32] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13147 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13148 : List Nat := [2,4,8,16,32,16,128,5,512,21,1,0,8,0,1,65536,0,512,21,0,0,513,16,65537,128,16,0,0,0,65538,20,65571,5,649,0,512]

theorem envBound13148 : H12AffineFastState.Bounded env13148 := by
  intro p hp
  have h : env13148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13147_13148 : H12AffineEnvironment.transform 10 1 env13147 = env13148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13147 == env13148) = true)

theorem identity13148 : scanCanonicalize (H12AffineFastState.compose env13148 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound13148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13149 : List Nat := [2,4,8,16,32,16,128,5,33,21,1,0,8,0,1,65536,0,33,21,0,0,32,16,65537,128,16,0,0,0,65538,20,65571,5,168,0,33]

theorem envBound13149 : H12AffineFastState.Bounded env13149 := by
  intro p hp
  have h : env13149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13148_13149 : H12AffineEnvironment.transform 8 33 env13148 = env13149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env13148 == env13149) = true)

theorem identity13149 : scanCanonicalize (H12AffineFastState.compose env13149 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound13149 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13150 : List Nat := [2,4,8,16,32,16,128,5,33,21,1,0,8,0,1,34,0,33,21,0,0,32,16,35,128,16,0,0,0,32,20,1,5,168,0,33]

theorem envBound13150 : H12AffineFastState.Bounded env13150 := by
  intro p hp
  have h : env13150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13149_13150 : H12AffineEnvironment.transform 15 34 env13149 = env13150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env13149 == env13150) = true)

theorem identity13150 : scanCanonicalize (H12AffineFastState.compose env13150 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13151 : List Nat := [2,4,8,16,32,16,41,5,33,21,1,0,8,0,1,34,0,33,21,0,0,32,16,35,41,16,0,0,0,32,20,1,5,1,0,33]

theorem envBound13151 : H12AffineFastState.Bounded env13151 := by
  intro p hp
  have h : env13151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13150_13151 : H12AffineEnvironment.transform 6 41 env13150 = env13151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13150 == env13151) = true)

def leafEnv13151 : List Nat := [2,4,8,16,32,16,41,5,33,21,1,0,8,0,1,34,0,33,21,0,0,32,16,35,20,41,1,16,0,0,0,32,20,1,5,1,4,3,0,33,0,0,1]

def active13151 : List Nat := [0,1,2,3,4]

def tree13151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13151 : H12WitnessSearch.Good tree13151 := H12GlobalWitnessIndex.good

theorem leafIdentity13151 : H12AffineFastState.composeSystem env13151 rootObs = leafEnv13151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13151 rootObs == leafEnv13151) = true)

theorem terminalChecked13151 : H12PackedTerminal.terminalCheckFast leafEnv13151 active13151 tree13151 = true := by decide +kernel

def env13152 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,512,272,261,0,4194304,16,65537,129,16,4195076,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13152 : H12AffineFastState.Bounded env13152 := by
  intro p hp
  have h : env13152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13119_13152 : H12AffineEnvironment.transform 12 9 env13119 = env13152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13119 == env13152) = true)

theorem identity13152 : scanCanonicalize (H12AffineFastState.compose env13152 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1077938345) := by decide +kernel

theorem selectedBound13152 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13153 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,512,272,261,0,4194304,16,65537,129,16,4195076,0,0,1073741824,20,1077938345,256,1073809410,0,512]

theorem envBound13153 : H12AffineFastState.Bounded env13153 := by
  intro p hp
  have h : env13153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13152_13153 : H12AffineEnvironment.transform 31 1077938345 env13152 = env13153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077938345 env13152 == env13153) = true)

def env13154 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,512,272,261,0,4194304,16,65537,129,16,4195076,0,0,2340,20,4194701,256,65830,0,512]

theorem envBound13154 : H12AffineFastState.Bounded env13154 := by
  intro p hp
  have h : env13154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13153_13154 : H12AffineEnvironment.transform 29 2340 env13153 = env13154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2340 env13153 == env13154) = true)

theorem identity13154 : scanCanonicalize (H12AffineFastState.compose env13154 (packedSelected [2,11,18] rootPS)) = affineNative (2^(21+1) ^^^ 66186) := by decide +kernel

theorem selectedBound13154 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13155 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,512,272,261,0,66186,16,65537,129,16,65934,0,0,2340,20,66311,256,65830,0,512]

theorem envBound13155 : H12AffineFastState.Bounded env13155 := by
  intro p hp
  have h : env13155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13154_13155 : H12AffineEnvironment.transform 21 66186 env13154 = env13155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66186 env13154 == env13155) = true)

theorem identity13155 : scanCanonicalize (H12AffineFastState.compose env13155 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound13155 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env13156 : List Nat := [2,4,8,16,32,16,128,256,512,272,804,0,9,0,260,65536,0,512,272,261,0,66186,16,65537,129,16,65934,0,0,512,20,66311,256,65830,0,512]

theorem envBound13156 : H12AffineFastState.Bounded env13156 := by
  intro p hp
  have h : env13156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13155_13156 : H12AffineEnvironment.transform 10 804 env13155 = env13156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env13155 == env13156) = true)

theorem identity13156 : scanCanonicalize (H12AffineFastState.compose env13156 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13156 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env13157 : List Nat := [2,4,8,16,32,16,128,256,261,272,33,0,9,0,260,65536,0,261,272,261,0,65935,16,65537,129,16,65934,0,0,261,20,65538,256,65830,0,261]

theorem envBound13157 : H12AffineFastState.Bounded env13157 := by
  intro p hp
  have h : env13157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13156_13157 : H12AffineEnvironment.transform 8 261 env13156 = env13157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13156 == env13157) = true)

theorem identity13157 : scanCanonicalize (H12AffineFastState.compose env13157 (packedSelected [0,2,7] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound13157 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env13158 : List Nat := [2,4,8,16,32,16,128,256,261,272,33,0,9,0,260,431,0,261,272,261,0,32,16,430,129,16,33,0,0,261,20,429,256,137,0,261]

theorem envBound13158 : H12AffineFastState.Bounded env13158 := by
  intro p hp
  have h : env13158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13157_13158 : H12AffineEnvironment.transform 15 431 env13157 = env13158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env13157 == env13158) = true)

theorem identity13158 : scanCanonicalize (H12AffineFastState.compose env13158 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13159 : List Nat := [2,4,8,16,32,16,128,36,33,52,33,0,9,0,32,139,0,33,52,33,0,32,16,138,129,16,33,0,0,33,20,137,36,137,0,33]

theorem envBound13159 : H12AffineFastState.Bounded env13159 := by
  intro p hp
  have h : env13159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13158_13159 : H12AffineEnvironment.transform 7 36 env13158 = env13159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13158 == env13159) = true)

theorem identity13159 : scanCanonicalize (H12AffineFastState.compose env13159 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13159 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13160 : List Nat := [2,4,8,16,32,16,41,36,33,52,33,0,9,0,32,34,0,33,52,33,0,32,16,35,40,16,33,0,0,33,20,32,36,32,0,33]

theorem envBound13160 : H12AffineFastState.Bounded env13160 := by
  intro p hp
  have h : env13160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13159_13160 : H12AffineEnvironment.transform 6 41 env13159 = env13160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13159 == env13160) = true)

theorem identity13160 : scanCanonicalize (H12AffineFastState.compose env13160 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13161 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,9,0,0,2,0,1,20,1,0,0,16,3,8,16,1,0,0,1,20,0,4,0,0,1]

theorem envBound13161 : H12AffineFastState.Bounded env13161 := by
  intro p hp
  have h : env13161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13160_13161 : H12AffineEnvironment.transform 4 0 env13160 = env13161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13160 == env13161) = true)

def leafEnv13161 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,9,0,0,2,0,1,20,1,0,0,16,3,20,8,1,16,1,0,0,1,20,0,4,0,4,3,0,1,0,0,1]

def active13161 : List Nat := [0,1,2,3]

def tree13161 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13161 : H12WitnessSearch.Good tree13161 := H12GlobalWitnessIndex.good

theorem leafIdentity13161 : H12AffineFastState.composeSystem env13161 rootObs = leafEnv13161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13161 rootObs == leafEnv13161) = true)

theorem terminalChecked13161 : H12PackedTerminal.terminalCheckFast leafEnv13161 active13161 tree13161 = true := by decide +kernel

def env13162 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,512,272,261,0,4194304,16,65537,129,16,4195076,0,0,2341,20,4194700,256,65831,0,512]

theorem envBound13162 : H12AffineFastState.Bounded env13162 := by
  intro p hp
  have h : env13162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13153_13162 : H12AffineEnvironment.transform 29 2341 env13153 = env13162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2341 env13153 == env13162) = true)

theorem identity13162 : scanCanonicalize (H12AffineFastState.compose env13162 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound13162 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13163 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,136,272,261,0,4194304,16,65537,129,16,4194700,0,0,2341,20,4194700,256,65831,0,136]

theorem envBound13163 : H12AffineFastState.Bounded env13163 := by
  intro p hp
  have h : env13163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13162_13163 : H12AffineEnvironment.transform 8 136 env13162 = env13163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13162 == env13163) = true)

def env13164 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,136,272,261,0,32,16,65537,129,16,428,0,0,2341,20,428,256,65831,0,136]

theorem envBound13164 : H12AffineFastState.Bounded env13164 := by
  intro p hp
  have h : env13164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13163_13164 : H12AffineEnvironment.transform 21 32 env13163 = env13164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13163 == env13164) = true)

theorem identity13164 : scanCanonicalize (H12AffineFastState.compose env13164 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13164 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13165 : List Nat := [2,4,8,16,32,16,128,5,136,21,2048,0,9,0,1,65536,0,136,21,0,0,32,16,65537,129,16,169,0,0,2080,20,169,5,65570,0,136]

theorem envBound13165 : H12AffineFastState.Bounded env13165 := by
  intro p hp
  have h : env13165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13164_13165 : H12AffineEnvironment.transform 7 5 env13164 = env13165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13164 == env13165) = true)

def env13166 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,136,272,261,0,33,16,65537,129,16,429,0,0,2341,20,429,256,65831,0,136]

theorem envBound13166 : H12AffineFastState.Bounded env13166 := by
  intro p hp
  have h : env13166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13163_13166 : H12AffineEnvironment.transform 21 33 env13163 = env13166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13163 == env13166) = true)

theorem identity13166 : scanCanonicalize (H12AffineFastState.compose env13166 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound13166 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13167 : List Nat := [2,4,8,16,32,16,128,256,136,272,428,0,9,0,260,65536,0,136,272,261,0,33,16,65537,129,16,429,0,0,137,20,429,256,65831,0,136]

theorem envBound13167 : H12AffineFastState.Bounded env13167 := by
  intro p hp
  have h : env13167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13166_13167 : H12AffineEnvironment.transform 10 428 env13166 = env13167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env13166 == env13167) = true)

def env13168 : List Nat := [2,4,8,16,32,16,128,4,136,20,168,0,9,0,0,65536,0,136,20,1,0,33,16,65537,129,16,169,0,0,137,20,169,4,65571,0,136]

theorem envBound13168 : H12AffineFastState.Bounded env13168 := by
  intro p hp
  have h : env13168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13167_13168 : H12AffineEnvironment.transform 7 4 env13167 = env13168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13167 == env13168) = true)

def env13169 : List Nat := [2,4,8,16,0,16,128,4,136,20,136,0,9,0,0,65536,0,136,20,1,0,1,16,65537,129,16,137,0,0,137,20,137,4,65539,0,136]

theorem envBound13169 : H12AffineFastState.Bounded env13169 := by
  intro p hp
  have h : env13169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13168_13169 : H12AffineEnvironment.transform 4 0 env13168 = env13169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13168 == env13169) = true)

def env13170 : List Nat := [2,4,8,16,1,16,128,4,136,20,137,0,9,0,0,65536,0,136,20,1,0,0,16,65537,129,16,136,0,0,137,20,136,4,65538,0,136]

theorem envBound13170 : H12AffineFastState.Bounded env13170 := by
  intro p hp
  have h : env13170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13168_13170 : H12AffineEnvironment.transform 4 1 env13168 = env13170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13168 == env13170) = true)

theorem identity13170 : scanCanonicalize (H12AffineFastState.compose env13170 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13171 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,9,0,0,65536,0,1,20,1,0,0,16,65537,8,16,1,0,0,0,20,1,4,65538,0,1]

theorem envBound13171 : H12AffineFastState.Bounded env13171 := by
  intro p hp
  have h : env13171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13170_13171 : H12AffineEnvironment.transform 6 9 env13170 = env13171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13170 == env13171) = true)

def leafEnv13171 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,9,0,0,65536,0,1,20,1,0,0,16,65537,20,8,1,16,1,0,0,0,20,1,4,65538,4,3,0,1,0,0,1]

def active13171 : List Nat := [0,1,2,3,15]

def tree13171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13171 : H12WitnessSearch.Good tree13171 := H12GlobalWitnessIndex.good

theorem leafIdentity13171 : H12AffineFastState.composeSystem env13171 rootObs = leafEnv13171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13171 rootObs == leafEnv13171) = true)

theorem terminalChecked13171 : H12PackedTerminal.terminalCheckFast leafEnv13171 active13171 tree13171 = true := by decide +kernel

def env13172 : List Nat := [2,4,8,16,32,16,128,5,136,21,169,0,9,0,1,65536,0,136,21,0,0,33,16,65537,129,16,168,0,0,137,20,168,5,65570,0,136]

theorem envBound13172 : H12AffineFastState.Bounded env13172 := by
  intro p hp
  have h : env13172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13167_13172 : H12AffineEnvironment.transform 7 5 env13167 = env13172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13167 == env13172) = true)

def env13173 : List Nat := [2,4,8,16,0,16,128,5,136,21,137,0,9,0,1,65536,0,136,21,0,0,1,16,65537,129,16,136,0,0,137,20,136,5,65538,0,136]

theorem envBound13173 : H12AffineFastState.Bounded env13173 := by
  intro p hp
  have h : env13173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13172_13173 : H12AffineEnvironment.transform 4 0 env13172 = env13173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13172 == env13173) = true)

theorem identity13173 : scanCanonicalize (H12AffineFastState.compose env13173 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13174 : List Nat := [2,4,8,16,0,16,128,5,136,21,137,0,9,0,1,2,0,136,21,0,0,1,16,3,129,16,136,0,0,137,20,136,5,0,0,136]

theorem envBound13174 : H12AffineFastState.Bounded env13174 := by
  intro p hp
  have h : env13174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13173_13174 : H12AffineEnvironment.transform 15 2 env13173 = env13174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13173 == env13174) = true)

def leafEnv13174 : List Nat := [2,4,8,16,0,16,128,5,136,21,137,0,9,0,1,2,0,136,21,0,0,1,16,3,20,129,1,16,136,0,0,137,20,136,5,0,4,3,0,136,0,0,1]

def active13174 : List Nat := [0,1,2,3,6]

def tree13174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13174 : H12WitnessSearch.Good tree13174 := H12GlobalWitnessIndex.good

theorem leafIdentity13174 : H12AffineFastState.composeSystem env13174 rootObs = leafEnv13174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13174 rootObs == leafEnv13174) = true)

theorem terminalChecked13174 : H12PackedTerminal.terminalCheckFast leafEnv13174 active13174 tree13174 = true := by decide +kernel

def env13175 : List Nat := [2,4,8,16,1,16,128,5,136,21,136,0,9,0,1,65536,0,136,21,0,0,0,16,65537,129,16,137,0,0,137,20,137,5,65539,0,136]

theorem envBound13175 : H12AffineFastState.Bounded env13175 := by
  intro p hp
  have h : env13175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13172_13175 : H12AffineEnvironment.transform 4 1 env13172 = env13175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13172 == env13175) = true)

theorem identity13175 : scanCanonicalize (H12AffineFastState.compose env13175 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound13175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13176 : List Nat := [2,4,8,16,1,16,128,5,136,21,136,0,9,0,1,139,0,136,21,0,0,0,16,138,129,16,137,0,0,137,20,137,5,136,0,136]

theorem envBound13176 : H12AffineFastState.Bounded env13176 := by
  intro p hp
  have h : env13176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13175_13176 : H12AffineEnvironment.transform 15 139 env13175 = env13176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env13175 == env13176) = true)

def leafEnv13176 : List Nat := [2,4,8,16,1,16,128,5,136,21,136,0,9,0,1,139,0,136,21,0,0,0,16,138,20,129,1,16,137,0,0,137,20,137,5,136,4,3,0,136,0,0,1]

def active13176 : List Nat := [0,1,2,3,6]

def tree13176 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13176 : H12WitnessSearch.Good tree13176 := H12GlobalWitnessIndex.good

theorem leafIdentity13176 : H12AffineFastState.composeSystem env13176 rootObs = leafEnv13176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13176 rootObs == leafEnv13176) = true)

theorem terminalChecked13176 : H12PackedTerminal.terminalCheckFast leafEnv13176 active13176 tree13176 = true := by decide +kernel

def env13177 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,261,65536,0,512,272,260,0,4194304,16,65536,8328,16,4195076,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13177 : H12AffineFastState.Bounded env13177 := by
  intro p hp
  have h : env13177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13118_13177 : H12AffineEnvironment.transform 14 261 env13118 = env13177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env13118 == env13177) = true)

def env13178 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,128,16,4195076,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13178 : H12AffineFastState.Bounded env13178 := by
  intro p hp
  have h : env13178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13177_13178 : H12AffineEnvironment.transform 12 8 env13177 = env13178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13177 == env13178) = true)

theorem identity13178 : scanCanonicalize (H12AffineFastState.compose env13178 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 65830) := by decide +kernel

theorem selectedBound13178 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13179 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,128,16,4195076,0,0,1073741824,20,65830,256,4194700,0,512]

theorem envBound13179 : H12AffineFastState.Bounded env13179 := by
  intro p hp
  have h : env13179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13178_13179 : H12AffineEnvironment.transform 31 65830 env13178 = env13179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65830 env13178 == env13179) = true)

def env13180 : List Nat := [2,4,8,16,32,16,40,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,40,16,4195076,0,0,1073741824,20,65830,256,4194596,0,512]

theorem envBound13180 : H12AffineFastState.Bounded env13180 := by
  intro p hp
  have h : env13180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13179_13180 : H12AffineEnvironment.transform 6 40 env13179 = env13180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13179 == env13180) = true)

theorem identity13180 : scanCanonicalize (H12AffineFastState.compose env13180 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13180 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13181 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,32,272,260,0,4194304,16,65536,40,16,4194596,0,0,1073741824,20,65830,256,4194596,0,32]

theorem envBound13181 : H12AffineFastState.Bounded env13181 := by
  intro p hp
  have h : env13181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13180_13181 : H12AffineEnvironment.transform 8 32 env13180 = env13181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13180 == env13181) = true)

def env13182 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,32,272,260,0,4194304,16,65536,40,16,4194596,0,0,4194304,20,65830,256,4194596,0,32]

theorem envBound13182 : H12AffineFastState.Bounded env13182 := by
  intro p hp
  have h : env13182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13181_13182 : H12AffineEnvironment.transform 29 4194304 env13181 = env13182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4194304 env13181 == env13182) = true)

theorem identity13182 : scanCanonicalize (H12AffineFastState.compose env13182 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound13182 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13183 : List Nat := [2,4,8,16,32,16,40,256,32,272,260,0,8,0,261,65536,0,32,272,260,0,4194304,16,65536,40,16,4194596,0,0,4194304,20,65830,256,4194596,0,32]

theorem envBound13183 : H12AffineFastState.Bounded env13183 := by
  intro p hp
  have h : env13183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13182_13183 : H12AffineEnvironment.transform 10 260 env13182 = env13183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env13182 == env13183) = true)

def env13184 : List Nat := [2,4,8,16,32,16,40,4,32,20,0,0,8,0,1,65536,0,32,20,0,0,4194304,16,65536,40,16,4194336,0,0,4194304,20,65570,4,4194336,0,32]

theorem envBound13184 : H12AffineFastState.Bounded env13184 := by
  intro p hp
  have h : env13184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13183_13184 : H12AffineEnvironment.transform 7 4 env13183 = env13184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13183 == env13184) = true)

theorem identity13184 : scanCanonicalize (H12AffineFastState.compose env13184 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound13184 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13185 : List Nat := [2,4,8,16,32,16,40,4,32,20,0,0,8,0,1,65536,0,32,20,0,0,32,16,65536,40,16,0,0,0,32,20,65570,4,0,0,32]

theorem envBound13185 : H12AffineFastState.Bounded env13185 := by
  intro p hp
  have h : env13185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13184_13185 : H12AffineEnvironment.transform 21 32 env13184 = env13185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13184 == env13185) = true)

theorem identity13185 : scanCanonicalize (H12AffineFastState.compose env13185 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13186 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,0,8,0,1,65536,0,0,20,0,0,0,16,65536,8,16,0,0,0,0,20,65538,4,0,0,0]

theorem envBound13186 : H12AffineFastState.Bounded env13186 := by
  intro p hp
  have h : env13186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13185_13186 : H12AffineEnvironment.transform 4 0 env13185 = env13186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13185 == env13186) = true)

def leafEnv13186 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,0,8,0,1,65536,0,0,20,0,0,0,16,65536,20,8,1,16,0,0,0,0,20,65538,4,0,4,2,0,0,0,0,1]

def active13186 : List Nat := [0,1,2,3,15]

def tree13186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13186 : H12WitnessSearch.Good tree13186 := H12GlobalWitnessIndex.good

theorem leafIdentity13186 : H12AffineFastState.composeSystem env13186 rootObs = leafEnv13186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13186 rootObs == leafEnv13186) = true)

theorem terminalChecked13186 : H12PackedTerminal.terminalCheckFast leafEnv13186 active13186 tree13186 = true := by decide +kernel

def env13187 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,0,65536,0,32,21,1,0,4194304,16,65536,40,16,4194337,0,0,4194304,20,65571,5,4194337,0,32]

theorem envBound13187 : H12AffineFastState.Bounded env13187 := by
  intro p hp
  have h : env13187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13183_13187 : H12AffineEnvironment.transform 7 5 env13183 = env13187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13183 == env13187) = true)

theorem identity13187 : scanCanonicalize (H12AffineFastState.compose env13187 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 65539) := by decide +kernel

theorem selectedBound13187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13188 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,0,65536,0,32,21,1,0,65539,16,65536,40,16,65570,0,0,65539,20,65571,5,65570,0,32]

theorem envBound13188 : H12AffineFastState.Bounded env13188 := by
  intro p hp
  have h : env13188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13187_13188 : H12AffineEnvironment.transform 21 65539 env13187 = env13188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65539 env13187 == env13188) = true)

def env13189 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,0,0,65536,0,0,21,1,0,65539,16,65536,8,16,65538,0,0,65539,20,65539,5,65538,0,0]

theorem envBound13189 : H12AffineFastState.Bounded env13189 := by
  intro p hp
  have h : env13189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13188_13189 : H12AffineEnvironment.transform 4 0 env13188 = env13189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13188 == env13189) = true)

theorem identity13189 : scanCanonicalize (H12AffineFastState.compose env13189 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13190 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,0,0,2,0,0,21,1,0,1,16,2,8,16,0,0,0,1,20,1,5,0,0,0]

theorem envBound13190 : H12AffineFastState.Bounded env13190 := by
  intro p hp
  have h : env13190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13189_13190 : H12AffineEnvironment.transform 15 2 env13189 = env13190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13189 == env13190) = true)

def leafEnv13190 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,0,0,2,0,0,21,1,0,1,16,2,20,8,1,16,0,0,0,1,20,1,5,0,4,2,0,0,0,0,1]

def active13190 : List Nat := [0,1,2,3]

def tree13190 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13190 : H12WitnessSearch.Good tree13190 := H12GlobalWitnessIndex.good

theorem leafIdentity13190 : H12AffineFastState.composeSystem env13190 rootObs = leafEnv13190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13190 rootObs == leafEnv13190) = true)

theorem terminalChecked13190 : H12PackedTerminal.terminalCheckFast leafEnv13190 active13190 tree13190 = true := by decide +kernel

def env13191 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,0,8,0,0,65536,0,1,21,1,0,65539,16,65536,9,16,65539,0,0,65539,20,65538,5,65539,0,1]

theorem envBound13191 : H12AffineFastState.Bounded env13191 := by
  intro p hp
  have h : env13191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13188_13191 : H12AffineEnvironment.transform 4 1 env13188 = env13191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13188 == env13191) = true)

def leafEnv13191 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,0,8,0,0,65536,0,1,21,1,0,65539,16,65536,20,9,1,16,65539,0,0,65539,20,65538,5,65539,4,2,0,1,0,0,1]

def active13191 : List Nat := [0,1,2,3,15]

def tree13191 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13191 : H12WitnessSearch.Good tree13191 := H12GlobalWitnessIndex.good

theorem leafIdentity13191 : H12AffineFastState.composeSystem env13191 rootObs = leafEnv13191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13191 rootObs == leafEnv13191) = true)

theorem terminalChecked13191 : H12PackedTerminal.terminalCheckFast leafEnv13191 active13191 tree13191 = true := by decide +kernel

def env13192 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,32,272,260,0,4194304,16,65536,40,16,4194596,0,0,4194305,20,65830,256,4194596,0,32]

theorem envBound13192 : H12AffineFastState.Bounded env13192 := by
  intro p hp
  have h : env13192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13181_13192 : H12AffineEnvironment.transform 29 4194305 env13181 = env13192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4194305 env13181 == env13192) = true)

theorem identity13192 : scanCanonicalize (H12AffineFastState.compose env13192 (packedSelected [2,4,9] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound13192 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13193 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,32,272,260,0,260,16,65536,40,16,32,0,0,261,20,65830,256,32,0,32]

theorem envBound13193 : H12AffineFastState.Bounded env13193 := by
  intro p hp
  have h : env13193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13192_13193 : H12AffineEnvironment.transform 21 260 env13192 = env13193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env13192 == env13193) = true)

theorem identity13193 : scanCanonicalize (H12AffineFastState.compose env13193 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13193 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13194 : List Nat := [2,4,8,16,1,16,9,256,1,272,2048,0,8,0,261,65536,0,1,272,260,0,260,16,65536,9,16,1,0,0,261,20,65799,256,1,0,1]

theorem envBound13194 : H12AffineFastState.Bounded env13194 := by
  intro p hp
  have h : env13194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13193_13194 : H12AffineEnvironment.transform 4 1 env13193 = env13194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13193 == env13194) = true)

theorem identity13194 : scanCanonicalize (H12AffineFastState.compose env13194 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound13194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13195 : List Nat := [2,4,8,16,1,16,9,256,1,272,261,0,8,0,261,65536,0,1,272,260,0,260,16,65536,9,16,1,0,0,261,20,65799,256,1,0,1]

theorem envBound13195 : H12AffineFastState.Bounded env13195 := by
  intro p hp
  have h : env13195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13194_13195 : H12AffineEnvironment.transform 10 261 env13194 = env13195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env13194 == env13195) = true)

def env13196 : List Nat := [2,4,8,16,32,16,41,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,41,16,4195076,0,0,1073741824,20,65830,256,4194597,0,512]

theorem envBound13196 : H12AffineFastState.Bounded env13196 := by
  intro p hp
  have h : env13196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13179_13196 : H12AffineEnvironment.transform 6 41 env13179 = env13196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13179 == env13196) = true)

theorem identity13196 : scanCanonicalize (H12AffineFastState.compose env13196 (packedSelected [2,11,18] rootPS)) = affineNative (2^(29+1) ^^^ 2820) := by decide +kernel

theorem selectedBound13196 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13197 : List Nat := [2,4,8,16,32,16,41,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,41,16,4195076,0,0,2820,20,65830,256,4194597,0,512]

theorem envBound13197 : H12AffineFastState.Bounded env13197 := by
  intro p hp
  have h : env13197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13196_13197 : H12AffineEnvironment.transform 29 2820 env13196 = env13197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2820 env13196 == env13197) = true)

def env13198 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,9,16,4195076,0,0,2820,20,65798,256,4194565,0,512]

theorem envBound13198 : H12AffineFastState.Bounded env13198 := by
  intro p hp
  have h : env13198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13197_13198 : H12AffineEnvironment.transform 4 0 env13197 = env13198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13197 == env13198) = true)

def env13199 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,0,16,65536,9,16,772,0,0,2820,20,65798,256,261,0,512]

theorem envBound13199 : H12AffineFastState.Bounded env13199 := by
  intro p hp
  have h : env13199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13198_13199 : H12AffineEnvironment.transform 21 0 env13198 = env13199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env13198 == env13199) = true)

theorem identity13199 : scanCanonicalize (H12AffineFastState.compose env13199 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13200 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,0,8,0,1,65536,0,512,20,0,0,0,16,65536,9,16,512,0,0,2560,20,65538,4,1,0,512]

theorem envBound13200 : H12AffineFastState.Bounded env13200 := by
  intro p hp
  have h : env13200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13199_13200 : H12AffineEnvironment.transform 7 4 env13199 = env13200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13199 == env13200) = true)

def env13201 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,1,16,65536,9,16,773,0,0,2820,20,65798,256,260,0,512]

theorem envBound13201 : H12AffineFastState.Bounded env13201 := by
  intro p hp
  have h : env13201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13198_13201 : H12AffineEnvironment.transform 21 1 env13198 = env13201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env13198 == env13201) = true)

theorem identity13201 : scanCanonicalize (H12AffineFastState.compose env13201 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13201 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13202 : List Nat := [2,4,8,16,0,16,9,256,1,272,2048,0,8,0,261,65536,0,1,272,260,0,1,16,65536,9,16,260,0,0,2309,20,65798,256,260,0,1]

theorem envBound13202 : H12AffineFastState.Bounded env13202 := by
  intro p hp
  have h : env13202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13201_13202 : H12AffineEnvironment.transform 8 1 env13201 = env13202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13201 == env13202) = true)

theorem identity13202 : scanCanonicalize (H12AffineFastState.compose env13202 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound13202 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env13203 : List Nat := [2,4,8,16,0,16,9,256,1,272,261,0,8,0,261,65536,0,1,272,260,0,1,16,65536,9,16,260,0,0,0,20,65798,256,260,0,1]

theorem envBound13203 : H12AffineFastState.Bounded env13203 := by
  intro p hp
  have h : env13203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13202_13203 : H12AffineEnvironment.transform 10 261 env13202 = env13203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env13202 == env13203) = true)

def env13204 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,8,0,1,65536,0,1,20,0,0,1,16,65536,9,16,0,0,0,0,20,65538,4,0,0,1]

theorem envBound13204 : H12AffineFastState.Bounded env13204 := by
  intro p hp
  have h : env13204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13203_13204 : H12AffineEnvironment.transform 7 4 env13203 = env13204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13203 == env13204) = true)

def env13205 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,0,0,65536,0,1,21,1,0,1,16,65536,9,16,1,0,0,0,20,65539,5,1,0,1]

theorem envBound13205 : H12AffineFastState.Bounded env13205 := by
  intro p hp
  have h : env13205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13203_13205 : H12AffineEnvironment.transform 7 5 env13203 = env13205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13203 == env13205) = true)

theorem identity13205 : scanCanonicalize (H12AffineFastState.compose env13205 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13206 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,0,0,2,0,1,21,1,0,1,16,2,9,16,1,0,0,0,20,1,5,1,0,1]

theorem envBound13206 : H12AffineFastState.Bounded env13206 := by
  intro p hp
  have h : env13206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13205_13206 : H12AffineEnvironment.transform 15 2 env13205 = env13206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13205 == env13206) = true)

def leafEnv13206 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,0,0,2,0,1,21,1,0,1,16,2,20,9,1,16,1,0,0,0,20,1,5,1,4,2,0,1,0,0,1]

def active13206 : List Nat := [0,1,2,3]

def tree13206 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13206 : H12WitnessSearch.Good tree13206 := H12GlobalWitnessIndex.good

theorem leafIdentity13206 : H12AffineFastState.composeSystem env13206 rootObs = leafEnv13206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13206 rootObs == leafEnv13206) = true)

theorem terminalChecked13206 : H12PackedTerminal.terminalCheckFast leafEnv13206 active13206 tree13206 = true := by decide +kernel

def env13207 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,4194304,16,65536,8,16,4195076,0,0,2820,20,65799,256,4194564,0,512]

theorem envBound13207 : H12AffineFastState.Bounded env13207 := by
  intro p hp
  have h : env13207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13197_13207 : H12AffineEnvironment.transform 4 1 env13197 = env13207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13197 == env13207) = true)

theorem identity13207 : scanCanonicalize (H12AffineFastState.compose env13207 (packedSelected [11,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2309) := by decide +kernel

theorem selectedBound13207 : packedSelected [11,23,32] rootPS < 2^1333 := by decide +kernel

def env13208 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,0,8,0,261,65536,0,512,272,260,0,2309,16,65536,8,16,2561,0,0,2820,20,65799,256,2049,0,512]

theorem envBound13208 : H12AffineFastState.Bounded env13208 := by
  intro p hp
  have h : env13208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13207_13208 : H12AffineEnvironment.transform 21 2309 env13207 = env13208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2309 env13207 == env13208) = true)

theorem identity13208 : scanCanonicalize (H12AffineFastState.compose env13208 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound13208 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13209 : List Nat := [2,4,8,16,1,16,8,256,512,272,773,0,8,0,261,65536,0,512,272,260,0,512,16,65536,8,16,260,0,0,1,20,65799,256,772,0,512]

theorem envBound13209 : H12AffineFastState.Bounded env13209 := by
  intro p hp
  have h : env13209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13208_13209 : H12AffineEnvironment.transform 10 773 env13208 = env13209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env13208 == env13209) = true)

def env13210 : List Nat := [2,4,8,16,1,16,8,4,512,20,513,0,8,0,1,65536,0,512,20,0,0,512,16,65536,8,16,0,0,0,1,20,65539,4,512,0,512]

theorem envBound13210 : H12AffineFastState.Bounded env13210 := by
  intro p hp
  have h : env13210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13209_13210 : H12AffineEnvironment.transform 7 4 env13209 = env13210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13209 == env13210) = true)

theorem identity13210 : scanCanonicalize (H12AffineFastState.compose env13210 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13211 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,8,0,1,65536,0,0,20,0,0,0,16,65536,8,16,0,0,0,1,20,65539,4,0,0,0]

theorem envBound13211 : H12AffineFastState.Bounded env13211 := by
  intro p hp
  have h : env13211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13210_13211 : H12AffineEnvironment.transform 8 0 env13210 = env13211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13210 == env13211) = true)

def leafEnv13211 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,8,0,1,65536,0,0,20,0,0,0,16,65536,20,8,1,16,0,0,0,1,20,65539,4,0,4,2,0,0,0,0,1]

def active13211 : List Nat := [0,1,2,3,15]

def tree13211 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13211 : H12WitnessSearch.Good tree13211 := H12GlobalWitnessIndex.good

theorem leafIdentity13211 : H12AffineFastState.composeSystem env13211 rootObs = leafEnv13211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13211 rootObs == leafEnv13211) = true)

theorem terminalChecked13211 : H12PackedTerminal.terminalCheckFast leafEnv13211 active13211 tree13211 = true := by decide +kernel

def env13212 : List Nat := [2,4,8,16,1,16,8,5,512,21,512,0,8,0,0,65536,0,512,21,1,0,512,16,65536,8,16,1,0,0,1,20,65538,5,513,0,512]

theorem envBound13212 : H12AffineFastState.Bounded env13212 := by
  intro p hp
  have h : env13212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13209_13212 : H12AffineEnvironment.transform 7 5 env13209 = env13212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13209 == env13212) = true)

theorem identity13212 : scanCanonicalize (H12AffineFastState.compose env13212 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound13212 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13213 : List Nat := [2,4,8,16,1,16,8,5,512,21,512,0,8,0,0,514,0,512,21,1,0,512,16,514,8,16,1,0,0,1,20,512,5,513,0,512]

theorem envBound13213 : H12AffineFastState.Bounded env13213 := by
  intro p hp
  have h : env13213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13212_13213 : H12AffineEnvironment.transform 15 514 env13212 = env13213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env13212 == env13213) = true)

def leafEnv13213 : List Nat := [2,4,8,16,1,16,8,5,512,21,512,0,8,0,0,514,0,512,21,1,0,512,16,514,20,8,1,16,1,0,0,1,20,512,5,513,4,2,0,512,0,0,1]

def active13213 : List Nat := [0,1,2,3,8]

def tree13213 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13213 : H12WitnessSearch.Good tree13213 := H12GlobalWitnessIndex.good

theorem leafIdentity13213 : H12AffineFastState.composeSystem env13213 rootObs = leafEnv13213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13213 rootObs == leafEnv13213) = true)

theorem terminalChecked13213 : H12PackedTerminal.terminalCheckFast leafEnv13213 active13213 tree13213 = true := by decide +kernel

def env13214 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,261,65536,0,512,272,260,0,4194304,16,65536,129,16,4195076,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13214 : H12AffineFastState.Bounded env13214 := by
  intro p hp
  have h : env13214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13177_13214 : H12AffineEnvironment.transform 12 9 env13177 = env13214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13177 == env13214) = true)

theorem identity13214 : scanCanonicalize (H12AffineFastState.compose env13214 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 4260010) := by decide +kernel

end H12CloudChart2