import H12CloudChart2Data130

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound32465 : H12AffineFastState.Bounded env32465 := by
  intro p hp
  have h : env32465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32464_32465 : H12AffineEnvironment.transform 14 24601 env32464 = env32465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env32464 == env32465) = true)

theorem identity32465 : scanCanonicalize (H12AffineFastState.compose env32465 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound32465 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env32466 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,13374,131072,137352,136192,9381,4097,4248,132269,1167,143496,5292,3076,131073,131073,2184,4117,131088,172,1196,1213,135681]

theorem envBound32466 : H12AffineFastState.Bounded env32466 := by
  intro p hp
  have h : env32466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32465_32466 : H12AffineEnvironment.transform 13 1213 env32465 = env32466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env32465 == env32466) = true)

theorem identity32466 : scanCanonicalize (H12AffineFastState.compose env32466 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound32466 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env32467 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,8192,1213,9380,8323,131072,134197,131261,9381,1212,1061,132269,1167,140341,17,3076,131073,131073,2184,1192,131088,172,1196,1213,132796]

theorem envBound32467 : H12AffineFastState.Bounded env32467 := by
  intro p hp
  have h : env32467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32466_32467 : H12AffineEnvironment.transform 11 1213 env32466 = env32467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env32466 == env32467) = true)

theorem identity32467 : scanCanonicalize (H12AffineFastState.compose env32467 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound32467 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env32468 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,3639,1213,2707,3764,131072,134197,131261,2706,1212,1061,132269,1167,133634,17,3076,131073,131073,2184,1192,131088,172,1196,1213,132796]

theorem envBound32468 : H12AffineFastState.Bounded env32468 := by
  intro p hp
  have h : env32468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32467_32468 : H12AffineEnvironment.transform 12 3639 env32467 = env32468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env32467 == env32468) = true)

theorem identity32468 : scanCanonicalize (H12AffineFastState.compose env32468 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 1724) := by decide +kernel

theorem selectedBound32468 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env32469 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,3639,1213,2707,3764,1724,2697,1537,2706,1212,1061,529,1167,3262,17,3076,1725,1725,2184,1192,1708,172,1196,1213,0]

theorem envBound32469 : H12AffineFastState.Bounded env32469 := by
  intro p hp
  have h : env32469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32468_32469 : H12AffineEnvironment.transform 16 1724 env32468 = env32469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1724 env32468 == env32469) = true)

theorem identity32469 : scanCanonicalize (H12AffineFastState.compose env32469 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound32469 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32470 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1191,1213,656,1213,1588,531,1724,1582,1537,1589,1212,1061,529,1167,25,17,163,1725,1725,1071,1192,1708,172,1196,1213,0]

theorem envBound32470 : H12AffineFastState.Bounded env32470 := by
  intro p hp
  have h : env32470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32469_32470 : H12AffineEnvironment.transform 10 1191 env32469 = env32470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env32469 == env32470) = true)

theorem identity32470 : scanCanonicalize (H12AffineFastState.compose env32470 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound32470 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32471 : List Nat := [2,4,8,16,32,17,128,172,512,517,674,696,656,696,49,531,185,43,4,48,697,544,529,650,25,17,163,184,184,554,685,169,172,681,696,0]

theorem envBound32471 : H12AffineFastState.Bounded env32471 := by
  intro p hp
  have h : env32471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32470_32471 : H12AffineEnvironment.transform 9 517 env32470 = env32471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env32470 == env32471) = true)

theorem identity32471 : scanCanonicalize (H12AffineFastState.compose env32471 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound32471 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32472 : List Nat := [2,4,8,16,32,17,128,172,61,56,159,133,173,133,49,46,185,43,4,48,132,29,44,183,25,17,163,184,184,23,144,169,172,148,133,0]

theorem envBound32472 : H12AffineFastState.Bounded env32472 := by
  intro p hp
  have h : env32472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32471_32472 : H12AffineEnvironment.transform 8 61 env32471 = env32472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env32471 == env32472) = true)

theorem identity32472 : scanCanonicalize (H12AffineFastState.compose env32472 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound32472 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32473 : List Nat := [2,4,8,16,32,17,47,3,61,56,48,42,2,42,49,46,22,43,4,48,43,29,44,24,25,17,12,23,23,23,63,6,3,59,42,0]

theorem envBound32473 : H12AffineFastState.Bounded env32473 := by
  intro p hp
  have h : env32473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32472_32473 : H12AffineEnvironment.transform 6 47 env32472 = env32473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env32472 == env32473) = true)

def env32474 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,492614,148716,148716,96346,74795,131137,173,16401,1261,135681]

theorem envBound32474 : H12AffineFastState.Bounded env32474 := by
  intro p hp
  have h : env32474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32445_32474 : H12AffineEnvironment.transform 7 173 env32445 = env32474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32445 == env32474) = true)

def env32475 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143496,20497,492566,148668,148668,96266,74795,131089,173,16401,1213,135681]

theorem envBound32475 : H12AffineFastState.Bounded env32475 := by
  intro p hp
  have h : env32475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32474_32475 : H12AffineEnvironment.transform 5 16 env32474 = env32475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32474 == env32475) = true)

theorem identity32475 : scanCanonicalize (H12AffineFastState.compose env32475 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound32475 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32476 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,41003,32809,20497,341175,62493,62493,96266,74795,45232,173,16401,1213,41632]

theorem envBound32476 : H12AffineFastState.Bounded env32476 := by
  intro p hp
  have h : env32476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32475_32476 : H12AffineEnvironment.transform 16 45217 env32475 = env32476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env32475 == env32476) = true)

theorem identity32476 : scanCanonicalize (H12AffineFastState.compose env32476 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound32476 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env32477 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4097,46140,46092,41003,32809,5293,341175,45217,45217,81078,74795,45232,173,1197,1213,41632]

theorem envBound32477 : H12AffineFastState.Bounded env32477 := by
  intro p hp
  have h : env32477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32476_32477 : H12AffineEnvironment.transform 13 1212 env32476 = env32477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env32476 == env32477) = true)

theorem identity32477 : scanCanonicalize (H12AffineFastState.compose env32477 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound32477 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32478 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,37018,45217,262144,42145,32769,4097,46140,46092,41003,32809,5293,304173,45217,45217,44076,46257,45232,173,1197,1213,41632]

theorem envBound32478 : H12AffineFastState.Bounded env32478 := by
  intro p hp
  have h : env32478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32477_32478 : H12AffineEnvironment.transform 15 37018 env32477 = env32478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env32477 == env32478) = true)

theorem identity32478 : scanCanonicalize (H12AffineFastState.compose env32478 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32478 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env32479 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,32768,37018,45217,262144,41124,32769,4097,45113,45065,41003,32809,4264,303144,45217,45217,43049,45236,45232,173,168,184,41632]

theorem envBound32479 : H12AffineFastState.Bounded env32479 := by
  intro p hp
  have h : env32479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32478_32479 : H12AffineEnvironment.transform 9 5 env32478 = env32479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32478 == env32479) = true)

theorem identity32479 : scanCanonicalize (H12AffineFastState.compose env32479 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound32479 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env32480 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,8352,12346,4097,262144,4,8353,4097,4249,4265,139,8329,4264,262280,4097,4097,2185,4116,4112,173,168,184,512]

theorem envBound32480 : H12AffineFastState.Bounded env32480 := by
  intro p hp
  have h : env32480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32479_32480 : H12AffineEnvironment.transform 14 8352 env32479 = env32480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env32479 == env32480) = true)

theorem identity32480 : scanCanonicalize (H12AffineFastState.compose env32480 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound32480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32481 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2601,185,2697,6675,4097,262144,4,2696,4097,4249,4265,139,2720,4264,262280,4097,4097,2185,4116,4112,173,168,184,512]

theorem envBound32481 : H12AffineFastState.Bounded env32481 := by
  intro p hp
  have h : env32481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32480_32481 : H12AffineEnvironment.transform 12 2601 env32480 = env32481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env32480 == env32481) = true)

theorem identity32481 : scanCanonicalize (H12AffineFastState.compose env32481 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound32481 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32482 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2601,185,2697,6675,4097,2706,4,2696,4097,4249,4265,139,2720,4264,2586,4097,4097,2185,4116,4112,173,168,184,512]

theorem envBound32482 : H12AffineFastState.Bounded env32482 := by
  intro p hp
  have h : env32482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32481_32482 : H12AffineEnvironment.transform 17 2706 env32481 = env32482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env32481 == env32482) = true)

theorem identity32482 : scanCanonicalize (H12AffineFastState.compose env32482 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound32482 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32483 : List Nat := [2,4,8,16,32,16,128,173,512,5,185,4096,656,185,560,4778,4097,555,4,561,4097,4249,4265,139,537,4264,675,4097,4097,48,4116,4112,173,168,184,512]

theorem envBound32483 : H12AffineFastState.Bounded env32483 := by
  intro p hp
  have h : env32483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32482_32483 : H12AffineEnvironment.transform 10 185 env32482 = env32483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env32482 == env32483) = true)

theorem identity32483 : scanCanonicalize (H12AffineFastState.compose env32483 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32483 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32484 : List Nat := [2,4,8,16,32,16,128,173,0,5,185,4096,144,185,48,4266,4097,43,4,49,4097,4249,4265,139,25,4264,163,4097,4097,48,4116,4112,173,168,184,0]

theorem envBound32484 : H12AffineFastState.Bounded env32484 := by
  intro p hp
  have h : env32484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32483_32484 : H12AffineEnvironment.transform 8 0 env32483 = env32484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32483 == env32484) = true)

theorem identity32484 : scanCanonicalize (H12AffineFastState.compose env32484 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32484 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env32485 : List Nat := [2,4,8,10,32,10,128,173,0,5,163,4096,138,163,42,4266,4097,43,4,43,4097,4227,4265,139,3,4264,163,4097,4097,42,4110,4106,173,168,162,0]

theorem envBound32485 : H12AffineFastState.Bounded env32485 := by
  intro p hp
  have h : env32485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32484_32485 : H12AffineEnvironment.transform 3 10 env32484 = env32485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32484 == env32485) = true)

theorem identity32485 : scanCanonicalize (H12AffineFastState.compose env32485 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32485 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32486 : List Nat := [2,4,8,10,32,10,128,173,0,5,163,0,138,163,42,170,1,43,4,43,1,131,169,139,3,168,163,1,1,42,14,10,173,168,162,0]

theorem envBound32486 : H12AffineFastState.Bounded env32486 := by
  intro p hp
  have h : env32486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32485_32486 : H12AffineEnvironment.transform 11 0 env32485 = env32486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32485 == env32486) = true)

theorem identity32486 : scanCanonicalize (H12AffineFastState.compose env32486 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32486 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32487 : List Nat := [2,4,8,10,11,10,128,134,0,5,136,0,138,136,1,129,1,0,4,0,1,131,130,139,3,131,136,1,1,1,14,10,134,131,137,0]

theorem envBound32487 : H12AffineFastState.Bounded env32487 := by
  intro p hp
  have h : env32487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32486_32487 : H12AffineEnvironment.transform 4 11 env32486 = env32487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32486 == env32487) = true)

theorem identity32487 : scanCanonicalize (H12AffineFastState.compose env32487 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32488 : List Nat := [2,4,4,6,7,6,128,134,0,5,132,0,134,132,1,129,1,0,4,0,1,131,130,135,3,131,132,1,1,1,2,6,134,131,133,0]

theorem envBound32488 : H12AffineFastState.Bounded env32488 := by
  intro p hp
  have h : env32488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32487_32488 : H12AffineEnvironment.transform 2 4 env32487 = env32488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32487 == env32488) = true)

theorem identity32488 : scanCanonicalize (H12AffineFastState.compose env32488 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound32488 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32489 : List Nat := [2,4,4,6,7,6,5,3,0,5,1,0,3,1,1,4,1,0,4,0,1,6,7,2,3,6,1,1,1,1,2,6,3,6,0,0]

theorem envBound32489 : H12AffineFastState.Bounded env32489 := by
  intro p hp
  have h : env32489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32488_32489 : H12AffineEnvironment.transform 6 5 env32488 = env32489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env32488 == env32489) = true)

def env32490 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143496,20497,492567,148669,148669,96267,74795,131088,173,16401,1212,135681]

theorem envBound32490 : H12AffineFastState.Bounded env32490 := by
  intro p hp
  have h : env32490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32474_32490 : H12AffineEnvironment.transform 5 17 env32474 = env32490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32474 == env32490) = true)

theorem identity32490 : scanCanonicalize (H12AffineFastState.compose env32490 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound32490 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32491 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,41003,143496,20497,105630,148669,148669,96267,74795,131088,173,16401,1212,135681]

theorem envBound32491 : H12AffineFastState.Bounded env32491 := by
  intro p hp
  have h : env32491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32490_32491 : H12AffineEnvironment.transform 17 137353 env32490 = env32491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env32490 == env32491) = true)

theorem identity32491 : scanCanonicalize (H12AffineFastState.compose env32491 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound32491 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32492 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4097,61569,147472,41003,143496,20497,43169,148669,148669,19508,4116,131088,173,16401,1212,135681]

theorem envBound32492 : H12AffineFastState.Bounded env32492 := by
  intro p hp
  have h : env32492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32491_32492 : H12AffineEnvironment.transform 15 13375 env32491 = env32492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env32491 == env32492) = true)

theorem identity32492 : scanCanonicalize (H12AffineFastState.compose env32492 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound32492 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32493 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136192,32769,4097,46141,132268,41003,143496,5293,43169,131073,131073,2184,4116,131088,173,1197,1212,135681]

theorem envBound32493 : H12AffineFastState.Bounded env32493 := by
  intro p hp
  have h : env32493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32492_32493 : H12AffineEnvironment.transform 13 1212 env32492 = env32493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env32492 == env32493) = true)

theorem identity32493 : scanCanonicalize (H12AffineFastState.compose env32493 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound32493 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env32494 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,40985,47248,46105,32769,4097,46141,42165,41003,37009,5293,43169,40984,40984,2184,4116,40969,173,1197,1212,45592]

theorem envBound32494 : H12AffineFastState.Bounded env32494 := by
  intro p hp
  have h : env32494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32493_32494 : H12AffineEnvironment.transform 16 40985 env32493 = env32494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env32493 == env32494) = true)

theorem identity32494 : scanCanonicalize (H12AffineFastState.compose env32494 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound32494 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env32495 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,8192,1212,32768,10273,40985,42126,43015,32769,3103,43043,42165,41003,35983,2227,43169,40984,40984,2184,3082,40969,173,1197,1212,44550]

theorem envBound32495 : H12AffineFastState.Bounded env32495 := by
  intro p hp
  have h : env32495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32494_32495 : H12AffineEnvironment.transform 11 3102 env32494 = env32495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env32494 == env32495) = true)

theorem identity32495 : scanCanonicalize (H12AffineFastState.compose env32495 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 2234) := by decide +kernel

theorem selectedBound32495 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env32496 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,2234,1212,32768,155,34979,35892,32957,32769,3103,32921,35855,34961,35983,2227,32795,34978,34978,2184,3082,34995,173,1197,1212,34492]

theorem envBound32496 : H12AffineFastState.Bounded env32496 := by
  intro p hp
  have h : env32496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32495_32496 : H12AffineEnvironment.transform 12 2234 env32495 = env32496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2234 env32495 == env32496) = true)

theorem identity32496 : scanCanonicalize (H12AffineFastState.compose env32496 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 3223) := by decide +kernel

theorem selectedBound32496 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32497 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3102,2234,1212,3223,155,1076,163,3114,3222,3103,3086,152,1030,24,2227,3212,1077,1077,2184,3082,1060,173,1197,1212,2603]

theorem envBound32497 : H12AffineFastState.Bounded env32497 := by
  intro p hp
  have h : env32497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32496_32497 : H12AffineEnvironment.transform 14 3223 env32496 = env32497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3223 env32496 == env32497) = true)

theorem identity32497 : scanCanonicalize (H12AffineFastState.compose env32497 (packedSelected [0,1,3,4,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound32497 : packedSelected [0,1,3,4,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32498 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1190,184,1052,1212,49,155,1076,163,140,48,185,168,152,1030,24,1045,42,1077,1077,1070,172,1060,173,1197,1212,1677]

theorem envBound32498 : H12AffineFastState.Bounded env32498 := by
  intro p hp
  have h : env32498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32497_32498 : H12AffineEnvironment.transform 10 1190 env32497 = env32498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env32497 == env32498) = true)

theorem identity32498 : scanCanonicalize (H12AffineFastState.compose env32498 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32498 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32499 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1071,49,1052,1077,49,18,1076,42,5,48,48,33,17,1030,24,1045,42,1077,1077,1070,37,1060,36,1060,1077,1540]

theorem envBound32499 : H12AffineFastState.Bounded env32499 := by
  intro p hp
  have h : env32499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32498_32499 : H12AffineEnvironment.transform 6 9 env32498 = env32499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32498 == env32499) = true)

theorem identity32499 : scanCanonicalize (H12AffineFastState.compose env32499 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 563) := by decide +kernel

theorem selectedBound32499 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env32500 : List Nat := [2,4,8,16,32,17,9,36,512,563,540,49,559,518,49,18,519,42,5,48,48,33,17,565,24,550,42,518,518,541,37,535,36,535,518,55]

theorem envBound32500 : H12AffineFastState.Bounded env32500 := by
  intro p hp
  have h : env32500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32499_32500 : H12AffineEnvironment.transform 9 563 env32499 = env32500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 563 env32499 == env32500) = true)

theorem identity32500 : scanCanonicalize (H12AffineFastState.compose env32500 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32500 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env32501 : List Nat := [2,4,8,16,32,17,9,36,0,51,28,49,47,6,49,18,7,42,5,48,48,33,17,53,24,38,42,6,6,29,37,23,36,23,6,55]

theorem envBound32501 : H12AffineFastState.Bounded env32501 := by
  intro p hp
  have h : env32501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32500_32501 : H12AffineEnvironment.transform 8 0 env32500 = env32501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32500 == env32501) = true)

theorem identity32501 : scanCanonicalize (H12AffineFastState.compose env32501 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32501 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env32502 : List Nat := [2,4,8,10,32,11,9,36,0,41,6,43,47,6,43,8,7,42,5,42,42,33,11,47,2,38,42,6,6,7,37,13,36,13,6,45]

theorem envBound32502 : H12AffineFastState.Bounded env32502 := by
  intro p hp
  have h : env32502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32501_32502 : H12AffineEnvironment.transform 3 10 env32501 = env32502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32501 == env32502) = true)

theorem identity32502 : scanCanonicalize (H12AffineFastState.compose env32502 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32503 : List Nat := [2,4,8,10,12,11,9,8,0,5,6,7,3,6,7,8,7,6,5,6,6,13,11,3,2,10,6,6,6,7,9,13,8,13,6,1]

theorem envBound32503 : H12AffineFastState.Bounded env32503 := by
  intro p hp
  have h : env32503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32502_32503 : H12AffineEnvironment.transform 4 12 env32502 = env32503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32502 == env32503) = true)

theorem identity32503 : scanCanonicalize (H12AffineFastState.compose env32503 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32504 : List Nat := [1,4,8,9,12,8,9,8,0,5,5,4,0,5,4,8,4,5,5,5,5,13,8,0,1,9,5,5,5,4,9,13,8,13,5,1]

theorem envBound32504 : H12AffineFastState.Bounded env32504 := by
  intro p hp
  have h : env32504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32503_32504 : H12AffineEnvironment.transform 0 1 env32503 = env32504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32503 == env32504) = true)

theorem identity32504 : scanCanonicalize (H12AffineFastState.compose env32504 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32505 : List Nat := [1,4,5,4,1,5,4,5,0,5,5,4,0,5,4,5,4,5,5,5,5,0,5,0,1,4,5,5,5,4,4,0,5,0,5,1]

theorem envBound32505 : H12AffineFastState.Bounded env32505 := by
  intro p hp
  have h : env32505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32504_32505 : H12AffineEnvironment.transform 2 5 env32504 = env32505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32504 == env32505) = true)

theorem identity32505 : scanCanonicalize (H12AffineFastState.compose env32505 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32505 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32506 : List Nat := [1,0,1,0,1,1,0,1,0,1,1,0,0,1,0,1,0,1,1,1,1,0,1,0,1,0,1,1,1,0,0,0,1,0,1,1]

theorem envBound32506 : H12AffineFastState.Bounded env32506 := by
  intro p hp
  have h : env32506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32505_32506 : H12AffineEnvironment.transform 1 0 env32505 = env32506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32505 == env32506) = true)

def env32507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,493035,148801,148800,96346,74795,131137,256,16400,1344,135680]

theorem envBound32507 : H12AffineFastState.Bounded env32507 := by
  intro p hp
  have h : env32507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32444_32507 : H12AffineEnvironment.transform 18 136193 env32444 = env32507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env32444 == env32507) = true)

def env32508 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,492615,148717,148716,96346,74795,131137,172,16400,1260,135680]

theorem envBound32508 : H12AffineFastState.Bounded env32508 := by
  intro p hp
  have h : env32508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32507_32508 : H12AffineEnvironment.transform 7 172 env32507 = env32508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32507 == env32508) = true)

def env32509 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143497,20496,492567,148669,148668,96266,74795,131089,172,16400,1212,135680]

theorem envBound32509 : H12AffineFastState.Bounded env32509 := by
  intro p hp
  have h : env32509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32508_32509 : H12AffineEnvironment.transform 5 16 env32508 = env32509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32508 == env32509) = true)

theorem identity32509 : scanCanonicalize (H12AffineFastState.compose env32509 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound32509 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32510 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61568,147473,41003,143497,20496,60444,148669,148668,96266,74795,131089,172,16400,1212,135680]

theorem envBound32510 : H12AffineFastState.Bounded env32510 := by
  intro p hp
  have h : env32510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32509_32510 : H12AffineEnvironment.transform 17 223243 env32509 = env32510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env32509 == env32510) = true)

theorem identity32510 : scanCanonicalize (H12AffineFastState.compose env32510 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound32510 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32511 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4097,61568,147473,41003,143497,20496,60444,148669,148668,2184,21673,131089,172,16400,1212,135680]

theorem envBound32511 : H12AffineFastState.Bounded env32511 := by
  intro p hp
  have h : env32511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32510_32511 : H12AffineEnvironment.transform 15 28802 env32510 = env32511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env32510 == env32511) = true)

theorem identity32511 : scanCanonicalize (H12AffineFastState.compose env32511 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound32511 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32512 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,28802,131072,137353,136193,24600,4097,4249,147473,16434,143497,20496,3077,148669,148668,2184,21673,131089,172,16400,1212,135680]

theorem envBound32512 : H12AffineFastState.Bounded env32512 := by
  intro p hp
  have h : env32512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32511_32512 : H12AffineEnvironment.transform 14 24601 env32511 = env32512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env32511 == env32512) = true)

theorem identity32512 : scanCanonicalize (H12AffineFastState.compose env32512 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound32512 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env32513 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13374,131072,137353,136193,9380,4097,4249,132269,1166,143497,5292,3077,131073,131072,2184,4117,131089,172,1196,1212,135680]

theorem envBound32513 : H12AffineFastState.Bounded env32513 := by
  intro p hp
  have h : env32513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32512_32513 : H12AffineEnvironment.transform 13 1212 env32512 = env32513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env32512 == env32513) = true)

theorem identity32513 : scanCanonicalize (H12AffineFastState.compose env32513 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 185) := by decide +kernel

theorem selectedBound32513 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env32514 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13374,185,6192,5304,9380,4097,4249,1044,1166,12336,5292,3077,184,185,2184,4117,168,172,1196,1212,4793]

theorem envBound32514 : H12AffineFastState.Bounded env32514 := by
  intro p hp
  have h : env32514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32513_32514 : H12AffineEnvironment.transform 16 185 env32513 = env32514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 185 env32513 == env32514) = true)

theorem identity32514 : scanCanonicalize (H12AffineFastState.compose env32514 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound32514 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env32515 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3639,1212,2706,6665,185,6192,5304,2707,4097,4249,1044,1166,7687,5292,3077,184,185,2184,4117,168,172,1196,1212,4793]

theorem envBound32515 : H12AffineFastState.Bounded env32515 := by
  intro p hp
  have h : env32515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32514_32515 : H12AffineEnvironment.transform 12 3639 env32514 = env32515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env32514 == env32515) = true)

theorem identity32515 : scanCanonicalize (H12AffineFastState.compose env32515 (packedSelected [1,3,6,7,8,9,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 551) := by decide +kernel

theorem selectedBound32515 : packedSelected [1,3,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env32516 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,551,3639,1212,2706,2094,185,2583,1695,2707,550,702,1044,1166,3104,1675,3077,184,185,2184,562,168,172,1196,1212,158]

theorem envBound32516 : H12AffineFastState.Bounded env32516 := by
  intro p hp
  have h : env32516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32515_32516 : H12AffineEnvironment.transform 11 551 env32515 = env32516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 551 env32515 == env32516) = true)

theorem identity32516 : scanCanonicalize (H12AffineFastState.compose env32516 (packedSelected [0,1,3,5,6,9,10,12,16] rootPS)) = affineNative (2^(9+1) ^^^ 155) := by decide +kernel

theorem selectedBound32516 : packedSelected [0,1,3,5,6,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env32517 : List Nat := [2,4,8,16,32,16,128,172,512,155,2048,551,2732,39,2706,2094,185,2583,516,2707,550,702,143,21,2235,528,2206,184,185,2184,562,168,172,55,39,158]

theorem envBound32517 : H12AffineFastState.Bounded env32517 := by
  intro p hp
  have h : env32517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32516_32517 : H12AffineEnvironment.transform 9 155 env32516 = env32517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 155 env32516 == env32517) = true)

theorem identity32517 : scanCanonicalize (H12AffineFastState.compose env32517 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound32517 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32518 : List Nat := [2,4,8,16,32,16,128,172,512,155,675,551,15,39,49,653,185,180,516,48,550,702,143,21,536,528,573,184,185,555,562,168,172,55,39,158]

theorem envBound32518 : H12AffineFastState.Bounded env32518 := by
  intro p hp
  have h : env32518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32517_32518 : H12AffineEnvironment.transform 10 675 env32517 = env32518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env32517 == env32518) = true)

theorem identity32518 : scanCanonicalize (H12AffineFastState.compose env32518 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound32518 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32519 : List Nat := [2,4,8,16,32,16,128,172,12,155,175,43,15,39,49,129,185,180,8,48,42,178,143,21,20,28,49,184,185,39,62,168,172,55,39,158]

theorem envBound32519 : H12AffineFastState.Bounded env32519 := by
  intro p hp
  have h : env32519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32518_32519 : H12AffineEnvironment.transform 8 12 env32518 = env32519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env32518 == env32519) = true)

theorem identity32519 : scanCanonicalize (H12AffineFastState.compose env32519 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32519 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32520 : List Nat := [2,4,8,10,32,10,128,172,12,129,175,43,15,39,43,129,163,174,8,42,42,168,143,15,14,6,43,162,163,39,36,168,172,45,39,132]

theorem envBound32520 : H12AffineFastState.Bounded env32520 := by
  intro p hp
  have h : env32520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32519_32520 : H12AffineEnvironment.transform 3 10 env32519 = env32520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32519 == env32520) = true)

theorem identity32520 : scanCanonicalize (H12AffineFastState.compose env32520 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32520 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32521 : List Nat := [2,4,5,7,32,7,128,161,1,129,162,38,2,39,38,129,163,163,5,39,39,165,130,2,3,6,38,162,163,39,36,165,161,32,39,132]

theorem envBound32521 : H12AffineFastState.Bounded env32521 := by
  intro p hp
  have h : env32521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32520_32521 : H12AffineEnvironment.transform 2 5 env32520 = env32521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32520 == env32521) = true)

theorem identity32521 : scanCanonicalize (H12AffineFastState.compose env32521 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32521 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32522 : List Nat := [2,4,5,7,7,7,128,134,1,129,133,1,2,0,1,129,132,132,5,0,0,130,130,2,3,6,1,133,132,0,3,130,134,7,0,132]

theorem envBound32522 : H12AffineFastState.Bounded env32522 := by
  intro p hp
  have h : env32522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32521_32522 : H12AffineEnvironment.transform 4 7 env32521 = env32522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32521 == env32522) = true)

theorem identity32522 : scanCanonicalize (H12AffineFastState.compose env32522 (packedSelected [1,18] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound32522 : packedSelected [1,18] rootPS < 2^1333 := by decide +kernel

def env32523 : List Nat := [2,4,5,7,7,7,4,2,1,5,1,1,2,0,1,5,0,0,5,0,0,6,6,2,3,6,1,1,0,0,3,6,2,7,0,0]

theorem envBound32523 : H12AffineFastState.Bounded env32523 := by
  intro p hp
  have h : env32523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32522_32523 : H12AffineEnvironment.transform 6 4 env32522 = env32523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env32522 == env32523) = true)

theorem identity32523 : scanCanonicalize (H12AffineFastState.compose env32523 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32524 : List Nat := [0,4,5,5,5,5,4,0,1,5,1,1,0,0,1,5,0,0,5,0,0,4,4,0,1,4,1,1,0,0,1,4,0,5,0,0]

theorem envBound32524 : H12AffineFastState.Bounded env32524 := by
  intro p hp
  have h : env32524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32523_32524 : H12AffineEnvironment.transform 0 0 env32523 = env32524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32523 == env32524) = true)

theorem identity32524 : scanCanonicalize (H12AffineFastState.compose env32524 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32524 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32525 : List Nat := [0,1,0,0,0,0,1,0,1,0,1,1,0,0,1,0,0,0,0,0,0,1,1,0,1,1,1,1,0,0,1,1,0,0,0,0]

theorem envBound32525 : H12AffineFastState.Bounded env32525 := by
  intro p hp
  have h : env32525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32524_32525 : H12AffineEnvironment.transform 1 1 env32524 = env32525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32524 == env32525) = true)

def env32526 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143497,20496,492566,148668,148669,96267,74795,131088,172,16400,1213,135680]

theorem envBound32526 : H12AffineFastState.Bounded env32526 := by
  intro p hp
  have h : env32526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32508_32526 : H12AffineEnvironment.transform 5 17 env32508 = env32526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32508 == env32526) = true)

theorem identity32526 : scanCanonicalize (H12AffineFastState.compose env32526 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound32526 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32527 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61569,98354,41003,127147,20496,279604,99486,99487,96267,74795,114738,172,16400,1213,119330]

theorem envBound32527 : H12AffineFastState.Bounded env32527 := by
  intro p hp
  have h : env32527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32526_32527 : H12AffineEnvironment.transform 16 114722 env32526 = env32527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env32526 == env32527) = true)

theorem identity32527 : scanCanonicalize (H12AffineFastState.compose env32527 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 80050) := by decide +kernel

theorem selectedBound32527 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32528 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,80050,119843,32769,4097,61569,98354,41003,127147,20496,97414,99486,99487,96267,74795,114738,172,16400,1213,119330]

theorem envBound32528 : H12AffineFastState.Bounded env32528 := by
  intro p hp
  have h : env32528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32527_32528 : H12AffineEnvironment.transform 17 80050 env32527 = env32528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80050 env32527 == env32528) = true)

theorem identity32528 : scanCanonicalize (H12AffineFastState.compose env32528 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound32528 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32529 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,59536,1025,32769,4097,61569,20496,41003,8329,20496,44196,21692,21693,43049,62473,4112,172,16400,1213,512]

theorem envBound32529 : H12AffineFastState.Bounded env32529 := by
  intro p hp
  have h : env32529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32528_32529 : H12AffineEnvironment.transform 15 53282 env32528 = env32529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env32528 == env32529) = true)

theorem identity32529 : scanCanonicalize (H12AffineFastState.compose env32529 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32529 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32530 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,53282,4096,59536,5,32769,4097,61569,20496,41003,8329,20496,43168,20664,20665,43049,61453,4112,172,16400,185,512]

theorem envBound32530 : H12AffineFastState.Bounded env32530 := by
  intro p hp
  have h : env32530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32529_32530 : H12AffineEnvironment.transform 9 4 env32529 = env32530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32529 == env32530) = true)

theorem identity32530 : scanCanonicalize (H12AffineFastState.compose env32530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound32530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32531 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,8744,32768,45578,4096,35512,5,32769,4097,37545,12856,41003,8329,12856,43168,12944,12945,43049,37413,4112,172,8760,185,512]

theorem envBound32531 : H12AffineFastState.Bounded env32531 := by
  intro p hp
  have h : env32531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32530_32531 : H12AffineEnvironment.transform 13 8744 env32530 = env32531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env32530 == env32531) = true)

theorem identity32531 : scanCanonicalize (H12AffineFastState.compose env32531 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound32531 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env32532 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,138,674,32768,37504,4096,35512,5,32769,4097,37545,4786,32929,3,4786,34858,4634,4635,34979,37413,4112,172,690,185,512]

theorem envBound32532 : H12AffineFastState.Bounded env32532 := by
  intro p hp
  have h : env32532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32531_32532 : H12AffineEnvironment.transform 12 138 env32531 = env32532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env32531 == env32532) = true)

def env32533 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,492614,148716,148717,96346,74795,131137,173,16400,1261,135680]

theorem envBound32533 : H12AffineFastState.Bounded env32533 := by
  intro p hp
  have h : env32533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32507_32533 : H12AffineEnvironment.transform 7 173 env32507 = env32533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32507 == env32533) = true)

def env32534 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143497,20496,492566,148668,148669,96266,74795,131089,173,16400,1213,135680]

theorem envBound32534 : H12AffineFastState.Bounded env32534 := by
  intro p hp
  have h : env32534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32533_32534 : H12AffineEnvironment.transform 5 16 env32533 = env32534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32533 == env32534) = true)

theorem identity32534 : scanCanonicalize (H12AffineFastState.compose env32534 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound32534 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32535 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,41003,143497,20496,105630,148668,148669,96266,74795,131089,173,16400,1213,135680]

theorem envBound32535 : H12AffineFastState.Bounded env32535 := by
  intro p hp
  have h : env32535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32534_32535 : H12AffineEnvironment.transform 17 137352 env32534 = env32535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env32534 == env32535) = true)

theorem identity32535 : scanCanonicalize (H12AffineFastState.compose env32535 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound32535 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32536 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4097,61568,147473,41003,143497,20496,43169,148668,148669,19509,4116,131089,173,16400,1213,135680]

theorem envBound32536 : H12AffineFastState.Bounded env32536 := by
  intro p hp
  have h : env32536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32535_32536 : H12AffineEnvironment.transform 15 13375 env32535 = env32536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env32535 == env32536) = true)

theorem identity32536 : scanCanonicalize (H12AffineFastState.compose env32536 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound32536 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32537 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136193,32769,4097,46141,132268,41003,143497,5293,43169,131073,131072,2184,4116,131089,173,1197,1213,135680]

theorem envBound32537 : H12AffineFastState.Bounded env32537 := by
  intro p hp
  have h : env32537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32536_32537 : H12AffineEnvironment.transform 13 1213 env32536 = env32537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env32536 == env32537) = true)

theorem identity32537 : scanCanonicalize (H12AffineFastState.compose env32537 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound32537 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env32538 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13375,131072,137352,136193,12313,4097,1061,132268,4147,143497,5293,6329,131073,131072,2184,4116,131089,173,1197,1213,135680]

theorem envBound32538 : H12AffineFastState.Bounded env32538 := by
  intro p hp
  have h : env32538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32537_32538 : H12AffineEnvironment.transform 14 12312 env32537 = env32538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env32537 == env32538) = true)

theorem identity32538 : scanCanonicalize (H12AffineFastState.compose env32538 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 7334) := by decide +kernel

theorem selectedBound32538 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env32539 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13375,7334,1070,2215,12313,4097,1061,6154,4147,11311,5293,6329,7335,7334,2184,4116,7351,173,1197,1213,3750]

theorem envBound32539 : H12AffineFastState.Bounded env32539 := by
  intro p hp
  have h : env32539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32538_32539 : H12AffineEnvironment.transform 16 7334 env32538 = env32539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 7334 env32538 == env32539) = true)

theorem identity32539 : scanCanonicalize (H12AffineFastState.compose env32539 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound32539 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32540 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3102,8192,1213,11270,10273,184,1070,2215,11271,3103,1061,1044,3117,11311,2227,1191,185,184,2184,3082,169,173,1197,1213,3750]

theorem envBound32540 : H12AffineFastState.Bounded env32540 := by
  intro p hp
  have h : env32540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32539_32540 : H12AffineEnvironment.transform 11 3102 env32539 = env32540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env32539 == env32540) = true)

theorem identity32540 : scanCanonicalize (H12AffineFastState.compose env32540 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound32540 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env32541 : List Nat := [2,4,8,16,32,16,128,173,512,1024,561,1583,8192,1213,9783,8720,184,1070,662,9782,1582,1061,1044,1564,9758,642,1191,185,184,697,1595,169,173,1197,1213,1175]

theorem envBound32541 : H12AffineFastState.Bounded env32541 := by
  intro p hp
  have h : env32541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32540_32541 : H12AffineEnvironment.transform 10 561 env32540 = env32541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env32540 == env32541) = true)

theorem identity32541 : scanCanonicalize (H12AffineFastState.compose env32541 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound32541 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env32542 : List Nat := [2,4,8,16,32,16,128,173,512,1024,561,1583,1173,1213,674,1669,184,1070,662,675,1582,1061,1044,1564,651,642,1191,185,184,697,1595,169,173,1197,1213,1175]

theorem envBound32542 : H12AffineFastState.Bounded env32542 := by
  intro p hp
  have h : env32542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32541_32542 : H12AffineEnvironment.transform 12 1173 env32541 = env32542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env32541 == env32542) = true)

theorem identity32542 : scanCanonicalize (H12AffineFastState.compose env32542 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound32542 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32543 : List Nat := [2,4,8,16,32,16,128,173,146,1024,163,1213,1173,1213,48,1047,184,1070,4,49,1212,1061,1044,1166,25,16,1191,185,184,43,1193,169,173,1197,1213,1175]

theorem envBound32543 : H12AffineFastState.Bounded env32543 := by
  intro p hp
  have h : env32543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32542_32543 : H12AffineEnvironment.transform 8 146 env32542 = env32543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env32542 == env32543) = true)

theorem identity32543 : scanCanonicalize (H12AffineFastState.compose env32543 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32543 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32544 : List Nat := [2,4,8,16,32,16,9,36,27,1024,42,1076,1052,1076,48,1047,49,1070,4,49,1077,1061,1044,1031,25,16,1070,48,49,43,1056,32,36,1060,1076,1054]

theorem envBound32544 : H12AffineFastState.Bounded env32544 := by
  intro p hp
  have h : env32544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32543_32544 : H12AffineEnvironment.transform 6 9 env32543 = env32544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32543 == env32544) = true)

theorem identity32544 : scanCanonicalize (H12AffineFastState.compose env32544 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 24) := by decide +kernel

theorem selectedBound32544 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32545 : List Nat := [2,4,8,16,32,16,9,36,27,24,42,44,4,44,48,15,49,54,4,49,45,61,12,31,25,16,54,48,49,43,56,32,36,60,44,6]

theorem envBound32545 : H12AffineFastState.Bounded env32545 := by
  intro p hp
  have h : env32545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32544_32545 : H12AffineEnvironment.transform 9 24 env32544 = env32545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env32544 == env32545) = true)

theorem identity32545 : scanCanonicalize (H12AffineFastState.compose env32545 (packedSelected [1,3,6] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32545 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env32546 : List Nat := [2,2,8,16,32,16,9,34,27,24,42,42,2,42,48,9,49,48,2,49,43,59,10,25,25,16,48,48,49,43,56,32,34,58,42,0]

theorem envBound32546 : H12AffineFastState.Bounded env32546 := by
  intro p hp
  have h : env32546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32545_32546 : H12AffineEnvironment.transform 1 2 env32545 = env32546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32545 == env32546) = true)

def env32547 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143497,20496,492567,148669,148668,96267,74795,131088,173,16400,1212,135680]

theorem envBound32547 : H12AffineFastState.Bounded env32547 := by
  intro p hp
  have h : env32547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32533_32547 : H12AffineEnvironment.transform 5 17 env32533 = env32547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32533 == env32547) = true)

theorem identity32547 : scanCanonicalize (H12AffineFastState.compose env32547 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound32547 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32548 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,41003,32809,20496,341175,62493,62492,96267,74795,45232,173,16400,1212,41632]

theorem envBound32548 : H12AffineFastState.Bounded env32548 := by
  intro p hp
  have h : env32548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32547_32548 : H12AffineEnvironment.transform 16 45216 env32547 = env32548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env32547 == env32548) = true)

theorem identity32548 : scanCanonicalize (H12AffineFastState.compose env32548 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound32548 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env32549 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4097,46140,46093,41003,32809,5293,341175,45216,45217,81078,74795,45232,173,1197,1212,41632]

theorem envBound32549 : H12AffineFastState.Bounded env32549 := by
  intro p hp
  have h : env32549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32548_32549 : H12AffineEnvironment.transform 13 1213 env32548 = env32549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env32548 == env32549) = true)

theorem identity32549 : scanCanonicalize (H12AffineFastState.compose env32549 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound32549 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32550 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,37019,45216,262144,42145,32769,4097,46140,46093,41003,32809,5293,304172,45216,45217,44077,46256,45232,173,1197,1212,41632]

theorem envBound32550 : H12AffineFastState.Bounded env32550 := by
  intro p hp
  have h : env32550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32549_32550 : H12AffineEnvironment.transform 15 37019 env32549 = env32550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env32549 == env32550) = true)

theorem identity32550 : scanCanonicalize (H12AffineFastState.compose env32550 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32550 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env32551 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,185,32768,37019,45216,262144,41125,32769,4097,45112,45065,41003,32809,4265,303144,45216,45217,43049,45236,45232,173,169,184,41632]

theorem envBound32551 : H12AffineFastState.Bounded env32551 := by
  intro p hp
  have h : env32551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32550_32551 : H12AffineEnvironment.transform 9 4 env32550 = env32551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32550 == env32551) = true)

theorem identity32551 : scanCanonicalize (H12AffineFastState.compose env32551 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound32551 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env32552 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,185,8352,12347,4096,262144,5,8353,4097,4248,4265,139,8329,4265,262280,4096,4097,2185,4116,4112,173,169,184,512]

theorem envBound32552 : H12AffineFastState.Bounded env32552 := by
  intro p hp
  have h : env32552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32551_32552 : H12AffineEnvironment.transform 14 8352 env32551 = env32552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env32551 == env32552) = true)

theorem identity32552 : scanCanonicalize (H12AffineFastState.compose env32552 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound32552 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32553 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,2600,185,2696,6675,4096,262144,5,2697,4097,4248,4265,139,2721,4265,262280,4096,4097,2185,4116,4112,173,169,184,512]

theorem envBound32553 : H12AffineFastState.Bounded env32553 := by
  intro p hp
  have h : env32553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32552_32553 : H12AffineEnvironment.transform 12 2600 env32552 = env32553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env32552 == env32553) = true)

theorem identity32553 : scanCanonicalize (H12AffineFastState.compose env32553 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound32553 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32554 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,2600,185,2696,6675,4096,2706,5,2697,4097,4248,4265,139,2721,4265,2586,4096,4097,2185,4116,4112,173,169,184,512]

theorem envBound32554 : H12AffineFastState.Bounded env32554 := by
  intro p hp
  have h : env32554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32553_32554 : H12AffineEnvironment.transform 17 2706 env32553 = env32554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env32553 == env32554) = true)

theorem identity32554 : scanCanonicalize (H12AffineFastState.compose env32554 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound32554 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32555 : List Nat := [2,4,8,16,32,17,128,173,512,4,184,4096,656,185,560,4779,4096,554,5,561,4097,4248,4265,139,537,4265,674,4096,4097,49,4116,4112,173,169,184,512]

theorem envBound32555 : H12AffineFastState.Bounded env32555 := by
  intro p hp
  have h : env32555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32554_32555 : H12AffineEnvironment.transform 10 184 env32554 = env32555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env32554 == env32555) = true)

theorem identity32555 : scanCanonicalize (H12AffineFastState.compose env32555 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32555 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32556 : List Nat := [2,4,8,16,32,17,128,173,0,4,184,4096,144,185,48,4267,4096,42,5,49,4097,4248,4265,139,25,4265,162,4096,4097,49,4116,4112,173,169,184,0]

theorem envBound32556 : H12AffineFastState.Bounded env32556 := by
  intro p hp
  have h : env32556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32555_32556 : H12AffineEnvironment.transform 8 0 env32555 = env32556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32555 == env32556) = true)

theorem identity32556 : scanCanonicalize (H12AffineFastState.compose env32556 (packedSelected [3,4] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound32556 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env32557 : List Nat := [2,4,8,16,32,17,128,173,0,4,184,163,144,185,48,8,163,42,5,49,162,59,10,139,25,10,162,163,162,49,183,179,173,169,184,0]

theorem envBound32557 : H12AffineFastState.Bounded env32557 := by
  intro p hp
  have h : env32557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32556_32557 : H12AffineEnvironment.transform 11 163 env32556 = env32557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env32556 == env32557) = true)

theorem identity32557 : scanCanonicalize (H12AffineFastState.compose env32557 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32557 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32558 : List Nat := [2,4,8,16,32,17,8,37,0,4,48,43,24,49,48,8,43,42,5,49,42,59,10,3,25,10,42,43,42,49,63,59,37,33,48,0]

theorem envBound32558 : H12AffineFastState.Bounded env32558 := by
  intro p hp
  have h : env32558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32557_32558 : H12AffineEnvironment.transform 6 8 env32557 = env32558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32557 == env32558) = true)

theorem identity32558 : scanCanonicalize (H12AffineFastState.compose env32558 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32559 : List Nat := [2,4,5,16,32,17,5,37,0,4,48,38,21,49,48,5,38,39,5,49,39,54,7,3,20,7,39,38,39,49,50,54,37,33,48,0]

theorem envBound32559 : H12AffineFastState.Bounded env32559 := by
  intro p hp
  have h : env32559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32558_32559 : H12AffineEnvironment.transform 2 5 env32558 = env32559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32558 == env32559) = true)

def env32560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245633,148801,545089,96346,16876544,16949355,256,676880,1345,525825]

theorem envBound32560 : H12AffineFastState.Bounded env32560 := by
  intro p hp
  have h : env32560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32442_32560 : H12AffineEnvironment.transform 26 17245633 env32442 = env32560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env32442 == env32560) = true)

theorem identity32560 : scanCanonicalize (H12AffineFastState.compose env32560 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound32560 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717114,533640,672785,906491,148801,545089,96346,750906,545105,256,676880,1345,525825]

theorem envBound32561 : H12AffineFastState.Bounded env32561 := by
  intro p hp
  have h : env32561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32560_32561 : H12AffineEnvironment.transform 23 717114 env32560 = env32561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env32560 == env32561) = true)

def env32562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58682,143496,20497,508155,148801,148801,96346,90426,148817,256,16400,1345,135681]

theorem envBound32562 : H12AffineFastState.Bounded env32562 := by
  intro p hp
  have h : env32562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32561_32562 : H12AffineEnvironment.transform 18 136192 env32561 = env32562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env32561 == env32562) = true)

def env32563 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143496,20497,508155,148717,148717,96346,90262,148733,172,16400,1261,135681]

theorem envBound32563 : H12AffineFastState.Bounded env32563 := by
  intro p hp
  have h : env32563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32562_32563 : H12AffineEnvironment.transform 7 172 env32562 = env32563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32562 == env32563) = true)

def env32564 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143496,20497,508075,148669,148669,96266,90262,148653,172,16400,1213,135681]

theorem envBound32564 : H12AffineFastState.Bounded env32564 := by
  intro p hp
  have h : env32564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32563_32564 : H12AffineEnvironment.transform 5 16 env32563 = env32564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32563 == env32564) = true)

theorem identity32564 : scanCanonicalize (H12AffineFastState.compose env32564 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound32564 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32565 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61568,115854,58518,111639,20497,279604,114722,114722,96266,90262,114738,172,16400,1213,104094]

theorem envBound32565 : H12AffineFastState.Bounded env32565 := by
  intro p hp
  have h : env32565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32564_32565 : H12AffineEnvironment.transform 16 99487 env32564 = env32565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env32564 == env32565) = true)

theorem identity32565 : scanCanonicalize (H12AffineFastState.compose env32565 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound32565 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env32566 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,37019,5124,262144,4,32769,4097,61568,21525,58518,9356,20497,279604,20665,20665,59537,61453,20649,172,16400,1213,1541]

theorem envBound32566 : H12AffineFastState.Bounded env32566 := by
  intro p hp
  have h : env32566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32565_32566 : H12AffineEnvironment.transform 15 37019 env32565 = env32566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env32565 == env32566) = true)

theorem identity32566 : scanCanonicalize (H12AffineFastState.compose env32566 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32566 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32567 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,37019,4097,262144,4,32769,4097,61568,20496,57491,8329,20497,278577,20665,20665,59537,61453,20649,172,16400,184,512]

theorem envBound32567 : H12AffineFastState.Bounded env32567 := by
  intro p hp
  have h : env32567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32566_32567 : H12AffineEnvironment.transform 9 5 env32566 = env32567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32566 == env32567) = true)

theorem identity32567 : scanCanonicalize (H12AffineFastState.compose env32567 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound32567 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32568 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,32768,37019,4097,262144,4,32769,4097,45113,4265,41002,8329,4264,262280,4096,4096,43048,45236,4112,172,169,184,512]

theorem envBound32568 : H12AffineFastState.Bounded env32568 := by
  intro p hp
  have h : env32568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32567_32568 : H12AffineEnvironment.transform 13 185 env32567 = env32568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env32567 == env32568) = true)

theorem identity32568 : scanCanonicalize (H12AffineFastState.compose env32568 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4744) := by decide +kernel

theorem selectedBound32568 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32569 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,4744,531,4097,262144,4,4745,4097,8881,4265,12962,8329,4264,262280,4096,4096,15008,8764,4112,172,169,184,512]

theorem envBound32569 : H12AffineFastState.Bounded env32569 := by
  intro p hp
  have h : env32569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32568_32569 : H12AffineEnvironment.transform 14 4744 env32568 = env32569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4744 env32568 == env32569) = true)

theorem identity32569 : scanCanonicalize (H12AffineFastState.compose env32569 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound32569 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env32570 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,657,185,4744,531,4097,262144,4,4745,4097,32,4265,4147,536,4264,262280,4096,4096,6193,173,4112,172,169,184,512]

theorem envBound32570 : H12AffineFastState.Bounded env32570 := by
  intro p hp
  have h : env32570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32569_32570 : H12AffineEnvironment.transform 12 657 env32569 = env32570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env32569 == env32570) = true)

theorem identity32570 : scanCanonicalize (H12AffineFastState.compose env32570 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4754) := by decide +kernel

theorem selectedBound32570 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32571 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,657,185,4744,531,4097,4754,4,4745,4097,32,4265,4147,536,4264,4634,4096,4096,6193,173,4112,172,169,184,512]

theorem envBound32571 : H12AffineFastState.Bounded env32571 := by
  intro p hp
  have h : env32571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32570_32571 : H12AffineEnvironment.transform 17 4754 env32570 = env32571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4754 env32570 == env32571) = true)

theorem identity32571 : scanCanonicalize (H12AffineFastState.compose env32571 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound32571 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env32572 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,184,657,185,560,531,185,554,4,561,185,32,17,139,536,16,674,184,184,2185,173,168,172,169,184,512]

theorem envBound32572 : H12AffineFastState.Bounded env32572 := by
  intro p hp
  have h : env32572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32571_32572 : H12AffineEnvironment.transform 11 184 env32571 = env32572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env32571 == env32572) = true)

theorem identity32572 : scanCanonicalize (H12AffineFastState.compose env32572 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound32572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32573 : List Nat := [2,4,8,16,32,16,128,172,512,5,49,184,657,185,560,531,185,554,4,561,185,32,17,139,536,16,674,184,184,184,173,168,172,169,184,512]

theorem envBound32573 : H12AffineFastState.Bounded env32573 := by
  intro p hp
  have h : env32573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32572_32573 : H12AffineEnvironment.transform 10 49 env32572 = env32573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env32572 == env32573) = true)

theorem identity32573 : scanCanonicalize (H12AffineFastState.compose env32573 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound32573 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32574 : List Nat := [2,4,8,16,32,16,128,172,27,5,49,184,138,185,43,8,185,49,4,42,185,32,17,139,3,16,185,184,184,184,173,168,172,169,184,27]

theorem envBound32574 : H12AffineFastState.Bounded env32574 := by
  intro p hp
  have h : env32574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32573_32574 : H12AffineEnvironment.transform 8 27 env32573 = env32574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env32573 == env32574) = true)

theorem identity32574 : scanCanonicalize (H12AffineFastState.compose env32574 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound32574 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32575 : List Nat := [2,4,8,16,32,16,62,18,27,5,49,6,52,7,43,8,7,49,4,42,7,32,17,53,3,16,7,6,6,6,19,22,18,23,6,27]

theorem envBound32575 : H12AffineFastState.Bounded env32575 := by
  intro p hp
  have h : env32575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32574_32575 : H12AffineEnvironment.transform 6 62 env32574 = env32575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env32574 == env32575) = true)

theorem identity32575 : scanCanonicalize (H12AffineFastState.compose env32575 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound32575 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32576 : List Nat := [2,4,8,16,23,16,9,18,27,5,6,6,3,7,28,8,7,6,4,29,7,23,17,2,3,16,7,6,6,6,19,22,18,23,6,27]

theorem envBound32576 : H12AffineFastState.Bounded env32576 := by
  intro p hp
  have h : env32576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32575_32576 : H12AffineEnvironment.transform 4 23 env32575 = env32576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env32575 == env32576) = true)

theorem identity32576 : scanCanonicalize (H12AffineFastState.compose env32576 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32576 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32577 : List Nat := [2,4,8,11,12,11,9,9,0,5,6,6,3,7,7,8,7,6,4,6,7,12,10,2,3,11,7,6,6,6,8,13,9,12,6,0]

theorem envBound32577 : H12AffineFastState.Bounded env32577 := by
  intro p hp
  have h : env32577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32576_32577 : H12AffineEnvironment.transform 3 11 env32576 = env32577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32576 == env32577) = true)

theorem identity32577 : scanCanonicalize (H12AffineFastState.compose env32577 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32578 : List Nat := [2,3,8,11,11,11,9,9,0,2,1,1,3,0,0,8,0,1,3,1,0,11,10,2,3,11,0,1,1,1,8,10,9,11,1,0]

theorem envBound32578 : H12AffineFastState.Bounded env32578 := by
  intro p hp
  have h : env32578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32577_32578 : H12AffineEnvironment.transform 1 3 env32577 = env32578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32577 == env32578) = true)

def env32579 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143496,20497,508074,148668,148668,96267,90262,148652,172,16400,1212,135681]

theorem envBound32579 : H12AffineFastState.Bounded env32579 := by
  intro p hp
  have h : env32579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32563_32579 : H12AffineEnvironment.transform 5 17 env32563 = env32579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32563 == env32579) = true)

theorem identity32579 : scanCanonicalize (H12AffineFastState.compose env32579 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound32579 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32580 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61569,147472,58518,143496,20497,60444,148668,148668,96267,90262,148652,172,16400,1212,135681]

theorem envBound32580 : H12AffineFastState.Bounded env32580 := by
  intro p hp
  have h : env32580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32579_32580 : H12AffineEnvironment.transform 17 208054 env32579 = env32580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env32579 == env32580) = true)

theorem identity32580 : scanCanonicalize (H12AffineFastState.compose env32580 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound32580 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env32581 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4097,61569,147472,58518,143496,20497,60444,148668,148668,43048,45237,148652,172,16400,1212,135681]

theorem envBound32581 : H12AffineFastState.Bounded env32581 := by
  intro p hp
  have h : env32581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32580_32581 : H12AffineEnvironment.transform 15 53283 env32580 = env32581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env32580 == env32581) = true)

theorem identity32581 : scanCanonicalize (H12AffineFastState.compose env32581 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound32581 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32582 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4097,61569,5293,58518,25653,20497,60444,4097,4097,43048,45237,4113,172,16400,1212,18108]

theorem envBound32582 : H12AffineFastState.Bounded env32582 := by
  intro p hp
  have h : env32582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32581_32582 : H12AffineEnvironment.transform 16 21693 env32581 = env32582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env32581 == env32582) = true)

theorem identity32582 : scanCanonicalize (H12AffineFastState.compose env32582 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32582 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env32583 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,16384,32768,53283,20664,43048,16573,32769,4097,61569,4264,57491,24624,20497,59417,4097,4097,43048,45237,4113,172,16400,185,17081]

theorem envBound32583 : H12AffineFastState.Bounded env32583 := by
  intro p hp
  have h : env32583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32582_32583 : H12AffineEnvironment.transform 9 5 env32582 = env32583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32582 == env32583) = true)

theorem identity32583 : scanCanonicalize (H12AffineFastState.compose env32583 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 8729) := by decide +kernel

theorem selectedBound32583 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env32584 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,8729,32768,45626,12961,43048,8868,32769,4097,37528,4264,33418,553,12808,35328,4097,4097,43048,45237,4113,172,8713,185,8352]

theorem envBound32584 : H12AffineFastState.Bounded env32584 := by
  intro p hp
  have h : env32584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32583_32584 : H12AffineEnvironment.transform 13 8729 env32583 = env32584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8729 env32583 == env32584) = true)

theorem identity32584 : scanCanonicalize (H12AffineFastState.compose env32584 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 6795) := by decide +kernel

theorem selectedBound32584 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env32585 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,6795,6290,32768,34993,2090,37539,6191,32769,4097,37528,4264,33418,553,2179,35328,4097,4097,37539,35390,4113,172,6274,185,6699]

theorem envBound32585 : H12AffineFastState.Bounded env32585 := by
  intro p hp
  have h : env32585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32584_32585 : H12AffineEnvironment.transform 12 6795 env32584 = env32585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6795 env32584 == env32585) = true)

theorem identity32585 : scanCanonicalize (H12AffineFastState.compose env32585 (packedSelected [0,1,2,4,5,6,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 4745) := by decide +kernel

theorem selectedBound32585 : packedSelected [0,1,2,4,5,6,11,13,16] rootPS < 2^1333 := by decide +kernel

def env32586 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,6795,6290,4745,6712,2090,42,6191,4744,4097,17,4264,4099,553,2179,6281,4097,4097,42,6327,4113,172,6274,185,6699]

theorem envBound32586 : H12AffineFastState.Bounded env32586 := by
  intro p hp
  have h : env32586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32585_32586 : H12AffineEnvironment.transform 14 4745 env32585 = env32586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4745 env32585 == env32586) = true)

theorem identity32586 : scanCanonicalize (H12AffineFastState.compose env32586 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound32586 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32587 : List Nat := [2,4,8,16,32,17,128,172,512,5,137,4096,4610,4123,4745,4785,163,42,4262,4744,4097,17,4264,4099,553,10,4096,4097,4097,42,4158,4113,172,4107,185,4770]

theorem envBound32587 : H12AffineFastState.Bounded env32587 := by
  intro p hp
  have h : env32587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32586_32587 : H12AffineEnvironment.transform 10 137 env32586 = env32587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env32586 == env32587) = true)

theorem identity32587 : scanCanonicalize (H12AffineFastState.compose env32587 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32587 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32588 : List Nat := [2,4,8,16,32,17,128,172,0,5,137,4096,4098,4123,4233,4273,163,42,4262,4232,4097,17,4264,4099,41,10,4096,4097,4097,42,4158,4113,172,4107,185,4258]

theorem envBound32588 : H12AffineFastState.Bounded env32588 := by
  intro p hp
  have h : env32588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32587_32588 : H12AffineEnvironment.transform 8 0 env32587 = env32588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32587 == env32588) = true)

theorem identity32588 : scanCanonicalize (H12AffineFastState.compose env32588 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32588 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32589 : List Nat := [2,4,8,16,32,17,18,62,0,5,27,4096,4098,4123,4123,4131,49,42,4148,4122,4097,17,4154,4099,41,10,4096,4097,4097,42,4158,4113,62,4107,43,4144]

theorem envBound32589 : H12AffineFastState.Bounded env32589 := by
  intro p hp
  have h : env32589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32588_32589 : H12AffineEnvironment.transform 6 18 env32588 = env32589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32588 == env32589) = true)

theorem identity32589 : scanCanonicalize (H12AffineFastState.compose env32589 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound32589 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32590 : List Nat := [2,4,8,16,32,17,18,62,0,5,27,26,24,1,1,57,49,42,46,0,27,17,32,25,41,10,26,27,27,42,36,11,62,17,43,42]

theorem envBound32590 : H12AffineFastState.Bounded env32590 := by
  intro p hp
  have h : env32590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32589_32590 : H12AffineEnvironment.transform 11 26 env32589 = env32590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env32589 == env32590) = true)

theorem identity32590 : scanCanonicalize (H12AffineFastState.compose env32590 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound32590 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32591 : List Nat := [2,4,8,13,32,12,15,35,0,5,6,7,5,1,1,36,44,42,46,0,6,12,32,4,41,10,7,6,6,42,36,11,35,12,43,42]

theorem envBound32591 : H12AffineFastState.Bounded env32591 := by
  intro p hp
  have h : env32591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32590_32591 : H12AffineEnvironment.transform 3 13 env32590 = env32591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env32590 == env32591) = true)

def env32592 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143496,20497,508155,148716,148716,96346,90263,148732,173,16400,1260,135681]

theorem envBound32592 : H12AffineFastState.Bounded env32592 := by
  intro p hp
  have h : env32592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32562_32592 : H12AffineEnvironment.transform 7 173 env32562 = env32592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32562 == env32592) = true)

def env32593 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143496,20497,508075,148668,148668,96266,90263,148652,173,16400,1212,135681]

theorem envBound32593 : H12AffineFastState.Bounded env32593 := by
  intro p hp
  have h : env32593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32593 : H12AffineEnvironment.transform 5 16 env32592 = env32593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32592 == env32593) = true)

theorem identity32593 : scanCanonicalize (H12AffineFastState.compose env32593 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound32593 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32594 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,58519,32809,20497,356362,62493,62493,96266,90263,62477,173,16400,1212,41632]

theorem envBound32594 : H12AffineFastState.Bounded env32594 := by
  intro p hp
  have h : env32594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32593_32594 : H12AffineEnvironment.transform 16 45217 env32593 = env32594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env32593 == env32594) = true)

theorem identity32594 : scanCanonicalize (H12AffineFastState.compose env32594 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound32594 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32595 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4097,61568,61616,58519,32809,20497,96387,62493,62493,96266,90263,62477,173,16400,1212,41632]

theorem envBound32595 : H12AffineFastState.Bounded env32595 := by
  intro p hp
  have h : env32595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32594_32595 : H12AffineEnvironment.transform 17 2185 env32594 = env32595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env32594 == env32595) = true)

theorem identity32595 : scanCanonicalize (H12AffineFastState.compose env32595 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound32595 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32596 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,65536,45217,2185,42145,32769,4097,45113,45065,42030,32809,4264,79930,46244,46244,80051,73774,46260,173,169,1212,41632]

theorem envBound32596 : H12AffineFastState.Bounded env32596 := by
  intro p hp
  have h : env32596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32595_32596 : H12AffineEnvironment.transform 13 185 env32595 = env32596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env32595 == env32596) = true)

theorem identity32596 : scanCanonicalize (H12AffineFastState.compose env32596 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound32596 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env32597 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,13374,45217,2185,42145,32769,4097,45113,45065,42030,32809,4264,3076,46244,46244,3213,5136,46260,173,169,1212,41632]

theorem envBound32597 : H12AffineFastState.Bounded env32597 := by
  intro p hp
  have h : env32597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32596_32597 : H12AffineEnvironment.transform 15 13374 env32596 = env32597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env32596 == env32597) = true)

theorem identity32597 : scanCanonicalize (H12AffineFastState.compose env32597 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 9757) := by decide +kernel

theorem selectedBound32597 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env32598 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,9757,13374,5820,2185,700,9756,4097,5668,5652,563,9780,4264,3076,4793,4793,3213,5136,4777,173,169,1212,1213]

theorem envBound32598 : H12AffineFastState.Bounded env32598 := by
  intro p hp
  have h : env32598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32597_32598 : H12AffineEnvironment.transform 14 9757 env32597 = env32598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9757 env32597 == env32598) = true)

theorem identity32598 : scanCanonicalize (H12AffineFastState.compose env32598 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound32598 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env32599 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2603,8192,185,9757,11797,3223,2185,700,9756,2602,3087,3135,563,9780,2691,3076,2194,2194,3213,3643,2178,173,169,1212,1213]

theorem envBound32599 : H12AffineFastState.Bounded env32599 := by
  intro p hp
  have h : env32599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32598_32599 : H12AffineEnvironment.transform 11 2603 env32598 = env32599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env32598 == env32599) = true)

theorem identity32599 : scanCanonicalize (H12AffineFastState.compose env32599 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound32599 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env32600 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2603,2209,185,3772,1716,3223,2185,700,3773,2602,3087,3135,563,3733,2691,3076,2194,2194,3213,3643,2178,173,169,1212,1213]

theorem envBound32600 : H12AffineFastState.Bounded env32600 := by
  intro p hp
  have h : env32600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32599_32600 : H12AffineEnvironment.transform 12 2209 env32599 = env32600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env32599 == env32600) = true)

theorem identity32600 : scanCanonicalize (H12AffineFastState.compose env32600 (packedSelected [1,2,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound32600 : packedSelected [1,2,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32601 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1566,1077,1727,185,162,1716,649,1687,700,163,1076,529,545,563,139,1181,538,1676,1676,659,37,1692,173,169,1212,1213]

theorem envBound32601 : H12AffineFastState.Bounded env32601 := by
  intro p hp
  have h : env32601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32600_32601 : H12AffineEnvironment.transform 10 1566 env32600 = env32601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env32600 == env32601) = true)

theorem identity32601 : scanCanonicalize (H12AffineFastState.compose env32601 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32601 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env32602 : List Nat := [2,4,8,16,10,16,128,135,512,1024,1566,1055,1685,147,136,1694,649,1687,662,137,1054,529,523,537,139,1181,538,1676,1676,659,15,1692,135,131,1174,1175]

theorem envBound32602 : H12AffineFastState.Bounded env32602 := by
  intro p hp
  have h : env32602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32601_32602 : H12AffineEnvironment.transform 4 10 env32601 = env32602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32601 == env32602) = true)

theorem identity32602 : scanCanonicalize (H12AffineFastState.compose env32602 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32602 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env32603 : List Nat := [2,4,8,16,10,16,128,135,512,4,538,27,657,147,136,666,649,659,662,137,26,529,523,537,139,153,538,648,648,659,15,664,135,131,146,147]

theorem envBound32603 : H12AffineFastState.Bounded env32603 := by
  intro p hp
  have h : env32603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32602_32603 : H12AffineEnvironment.transform 9 4 env32602 = env32603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32602 == env32603) = true)

theorem identity32603 : scanCanonicalize (H12AffineFastState.compose env32603 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32603 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32604 : List Nat := [2,4,8,16,10,16,8,15,512,4,538,27,537,27,0,530,513,539,542,1,26,529,523,537,3,17,538,512,512,539,15,528,15,11,26,27]

theorem envBound32604 : H12AffineFastState.Bounded env32604 := by
  intro p hp
  have h : env32604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32603_32604 : H12AffineEnvironment.transform 6 8 env32603 = env32604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32603 == env32604) = true)

theorem identity32604 : scanCanonicalize (H12AffineFastState.compose env32604 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound32604 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32605 : List Nat := [2,4,8,7,10,7,8,15,512,4,525,12,526,12,0,517,513,524,521,1,13,518,523,526,3,6,525,512,512,524,15,519,15,11,13,12]

theorem envBound32605 : H12AffineFastState.Bounded env32605 := by
  intro p hp
  have h : env32605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32604_32605 : H12AffineEnvironment.transform 3 7 env32604 = env32605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env32604 == env32605) = true)

def env32606 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143496,20497,508074,148669,148669,96267,90263,148653,173,16400,1213,135681]

theorem envBound32606 : H12AffineFastState.Bounded env32606 := by
  intro p hp
  have h : env32606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32606 : H12AffineEnvironment.transform 5 17 env32592 = env32606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32592 == env32606) = true)

theorem identity32606 : scanCanonicalize (H12AffineFastState.compose env32606 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound32606 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32607 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,58519,143496,20497,120867,148669,148669,96267,90263,148653,173,16400,1213,135681]

theorem envBound32607 : H12AffineFastState.Bounded env32607 := by
  intro p hp
  have h : env32607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32606_32607 : H12AffineEnvironment.transform 17 137353 env32606 = env32607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env32606 == env32607) = true)

theorem identity32607 : scanCanonicalize (H12AffineFastState.compose env32607 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound32607 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env32608 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4097,61569,46093,58519,50325,20497,120867,45216,45216,96267,90263,45232,173,16400,1213,58908]

theorem envBound32608 : H12AffineFastState.Bounded env32608 := by
  intro p hp
  have h : env32608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32607_32608 : H12AffineEnvironment.transform 16 62493 env32607 = env32608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env32607 == env32608) = true)

theorem identity32608 : scanCanonicalize (H12AffineFastState.compose env32608 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound32608 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32609 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,54310,62493,60564,57373,32769,4097,61569,46093,58519,50325,20497,3077,45216,45216,44077,46257,45232,173,16400,1213,58908]

theorem envBound32609 : H12AffineFastState.Bounded env32609 := by
  intro p hp
  have h : env32609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32608_32609 : H12AffineEnvironment.transform 15 54310 env32608 = env32609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env32608 == env32609) = true)

theorem identity32609 : scanCanonicalize (H12AffineFastState.compose env32609 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 6704) := by decide +kernel

theorem selectedBound32609 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env32610 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,6704,19990,28205,30372,31277,6705,4097,27313,11837,32423,24229,20497,3077,10896,10896,13853,11905,10880,173,16400,1213,31788]

theorem envBound32610 : H12AffineFastState.Bounded env32610 := by
  intro p hp
  have h : env32610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32609_32610 : H12AffineEnvironment.transform 14 6704 env32609 = env32610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6704 env32609 == env32610) = true)

theorem identity32610 : scanCanonicalize (H12AffineFastState.compose env32610 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32610 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env32611 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,6704,18962,27177,29344,31277,6705,4097,27313,10809,31395,23201,20497,2049,10896,10896,12825,10885,10880,173,16400,185,30760]

theorem envBound32611 : H12AffineFastState.Bounded env32611 := by
  intro p hp
  have h : env32611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32610_32611 : H12AffineEnvironment.transform 9 4 env32610 = env32611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32610 == env32611) = true)

theorem identity32611 : scanCanonicalize (H12AffineFastState.compose env32611 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound32611 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env32612 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,6168,16384,6704,18962,21041,19128,16949,6705,4097,21161,4641,17083,23201,20497,2049,4744,4744,2561,4765,4760,173,16400,185,16432]

theorem envBound32612 : H12AffineFastState.Bounded env32612 := by
  intro p hp
  have h : env32612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32611_32612 : H12AffineEnvironment.transform 12 6168 env32611 = env32612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env32611 == env32612) = true)

theorem identity32612 : scanCanonicalize (H12AffineFastState.compose env32612 (packedSelected [1,5,6,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound32612 : packedSelected [1,5,6,10,11,13] rootPS < 2^1333 := by decide +kernel

def env32613 : List Nat := [2,4,8,16,32,17,128,173,512,4,163,4096,4283,16384,4755,17073,21041,16923,16949,4754,4097,21161,4641,17083,20994,20497,162,4744,4744,674,4765,4760,173,16400,185,16432]

theorem envBound32613 : H12AffineFastState.Bounded env32613 := by
  intro p hp
  have h : env32613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32612_32613 : H12AffineEnvironment.transform 10 163 env32612 = env32613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env32612 == env32613) = true)

theorem identity32613 : scanCanonicalize (H12AffineFastState.compose env32613 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32613 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env32614 : List Nat := [2,4,8,11,32,10,128,173,512,4,163,4096,4256,16384,4744,17066,21034,16896,16942,4745,4097,21161,4641,17056,20994,20490,162,4744,4744,674,4742,4739,173,16395,162,16427]

theorem envBound32614 : H12AffineFastState.Bounded env32614 := by
  intro p hp
  have h : env32614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32613_32614 : H12AffineEnvironment.transform 3 11 env32613 = env32614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32613 == env32614) = true)

theorem identity32614 : scanCanonicalize (H12AffineFastState.compose env32614 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4744) := by decide +kernel

theorem selectedBound32614 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32615 : List Nat := [2,4,8,11,32,10,128,173,512,4,163,4096,4256,4744,4744,4130,162,4232,4262,4745,4097,33,4641,4136,138,642,162,4744,4744,674,4742,4739,173,4739,162,4771]

theorem envBound32615 : H12AffineFastState.Bounded env32615 := by
  intro p hp
  have h : env32615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32614_32615 : H12AffineEnvironment.transform 13 4744 env32614 = env32615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4744 env32614 == env32615) = true)

theorem identity32615 : scanCanonicalize (H12AffineFastState.compose env32615 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32615 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32616 : List Nat := [2,4,8,11,32,10,128,173,1,4,163,4096,4256,4233,4233,4130,162,4232,4262,4232,4097,33,4128,4136,138,131,162,4233,4233,163,4231,4226,173,4226,162,4258]

theorem envBound32616 : H12AffineFastState.Bounded env32616 := by
  intro p hp
  have h : env32616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32615_32616 : H12AffineEnvironment.transform 8 1 env32615 = env32616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32615 == env32616) = true)

def env32617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58683,143497,20496,508154,148801,148800,96346,90427,148816,256,16401,1345,135680]

theorem envBound32617 : H12AffineFastState.Bounded env32617 := by
  intro p hp
  have h : env32617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32561_32617 : H12AffineEnvironment.transform 18 136193 env32561 = env32617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env32561 == env32617) = true)

def env32618 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143497,20496,508154,148717,148716,96346,90263,148732,172,16401,1261,135680]

theorem envBound32618 : H12AffineFastState.Bounded env32618 := by
  intro p hp
  have h : env32618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32617_32618 : H12AffineEnvironment.transform 7 172 env32617 = env32618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32617 == env32618) = true)

def env32619 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143497,20496,508074,148669,148668,96266,90263,148652,172,16401,1213,135680]

theorem envBound32619 : H12AffineFastState.Bounded env32619 := by
  intro p hp
  have h : env32619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32618_32619 : H12AffineEnvironment.transform 5 16 env32618 = env32619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32618 == env32619) = true)

theorem identity32619 : scanCanonicalize (H12AffineFastState.compose env32619 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound32619 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32620 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61568,147473,58519,143497,20496,60445,148669,148668,96266,90263,148652,172,16401,1213,135680]

theorem envBound32620 : H12AffineFastState.Bounded env32620 := by
  intro p hp
  have h : env32620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32619_32620 : H12AffineEnvironment.transform 17 208055 env32619 = env32620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env32619 == env32620) = true)

theorem identity32620 : scanCanonicalize (H12AffineFastState.compose env32620 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound32620 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env32621 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4097,61568,147473,58519,143497,20496,60445,148669,148668,43048,45237,148652,172,16401,1213,135680]

theorem envBound32621 : H12AffineFastState.Bounded env32621 := by
  intro p hp
  have h : env32621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32620_32621 : H12AffineEnvironment.transform 15 53282 env32620 = env32621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env32620 == env32621) = true)

theorem identity32621 : scanCanonicalize (H12AffineFastState.compose env32621 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound32621 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32622 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4097,61568,5292,58519,25652,20496,60445,4096,4097,43048,45237,4113,172,16401,1213,18109]

theorem envBound32622 : H12AffineFastState.Bounded env32622 := by
  intro p hp
  have h : env32622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32621_32622 : H12AffineEnvironment.transform 16 21693 env32621 = env32622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env32621 == env32622) = true)

theorem identity32622 : scanCanonicalize (H12AffineFastState.compose env32622 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32622 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env32623 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,16384,32768,53282,20665,43048,16572,32769,4097,61568,4264,57491,24624,20496,59417,4096,4097,43048,45237,4113,172,16401,185,17081]

theorem envBound32623 : H12AffineFastState.Bounded env32623 := by
  intro p hp
  have h : env32623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32622_32623 : H12AffineEnvironment.transform 9 4 env32622 = env32623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32622 == env32623) = true)

theorem identity32623 : scanCanonicalize (H12AffineFastState.compose env32623 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 17081) := by decide +kernel

theorem selectedBound32623 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env32624 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,16384,17081,4763,20665,27281,16572,17080,4097,12857,4264,8746,24624,20496,10912,4096,4097,27281,29196,4113,172,16401,185,17081]

theorem envBound32624 : H12AffineFastState.Bounded env32624 := by
  intro p hp
  have h : env32624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32623_32624 : H12AffineEnvironment.transform 14 17081 env32623 = env32624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17081 env32623 == env32624) = true)

theorem identity32624 : scanCanonicalize (H12AffineFastState.compose env32624 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 14899) := by decide +kernel

theorem selectedBound32624 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env32625 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,14899,14474,4763,10890,4258,14991,14475,4097,12857,4264,8746,6659,10787,10912,4096,4097,4258,2111,4113,172,14882,185,14474]

theorem envBound32625 : H12AffineFastState.Bounded env32625 := by
  intro p hp
  have h : env32625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32624_32625 : H12AffineEnvironment.transform 13 14899 env32624 = env32625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14899 env32624 == env32625) = true)

theorem identity32625 : scanCanonicalize (H12AffineFastState.compose env32625 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound32625 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env32626 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,2563,4144,4745,4763,137,4258,4236,4744,4097,6202,4264,2089,6659,32,163,4096,4097,4258,2111,4113,172,4129,185,4745]

theorem envBound32626 : H12AffineFastState.Bounded env32626 := by
  intro p hp
  have h : env32626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32625_32626 : H12AffineEnvironment.transform 12 2563 env32625 = env32626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env32625 == env32626) = true)

theorem identity32626 : scanCanonicalize (H12AffineFastState.compose env32626 (packedSelected [0,2,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound32626 : packedSelected [0,2,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32627 : List Nat := [2,4,8,16,32,16,128,172,512,4,137,4096,650,4144,4745,4763,137,4258,4236,4744,4097,4275,4264,160,4746,32,163,4096,4097,4258,182,4113,172,4129,185,4745]

theorem envBound32627 : H12AffineFastState.Bounded env32627 := by
  intro p hp
  have h : env32627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32626_32627 : H12AffineEnvironment.transform 10 137 env32626 = env32627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env32626 == env32627) = true)

theorem identity32627 : scanCanonicalize (H12AffineFastState.compose env32627 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32627 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env32628 : List Nat := [2,4,8,16,32,16,128,172,1,4,137,4096,139,4144,4232,4250,137,4258,4236,4233,4097,4275,4264,160,4235,32,163,4096,4097,4258,182,4113,172,4129,185,4232]

theorem envBound32628 : H12AffineFastState.Bounded env32628 := by
  intro p hp
  have h : env32628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32627_32628 : H12AffineEnvironment.transform 8 1 env32627 = env32628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32627 == env32628) = true)

theorem identity32628 : scanCanonicalize (H12AffineFastState.compose env32628 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound32628 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32629 : List Nat := [2,4,8,16,32,16,56,20,1,4,49,4096,51,4144,4144,4130,49,4122,4148,4145,4097,4107,4112,24,4147,32,27,4096,4097,4122,14,4113,20,4129,1,4144]

theorem envBound32629 : H12AffineFastState.Bounded env32629 := by
  intro p hp
  have h : env32629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32628_32629 : H12AffineEnvironment.transform 6 56 env32628 = env32629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env32628 == env32629) = true)

theorem identity32629 : scanCanonicalize (H12AffineFastState.compose env32629 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound32629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32630 : List Nat := [2,4,8,16,32,16,56,20,1,4,49,26,51,42,42,56,49,0,46,43,27,17,10,24,41,32,27,26,27,0,14,11,20,59,1,42]

theorem envBound32630 : H12AffineFastState.Bounded env32630 := by
  intro p hp
  have h : env32630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32629_32630 : H12AffineEnvironment.transform 11 26 env32629 = env32630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env32629 == env32630) = true)

theorem identity32630 : scanCanonicalize (H12AffineFastState.compose env32630 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound32630 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32631 : List Nat := [2,4,8,16,13,16,21,20,1,4,28,26,30,7,7,21,28,0,3,6,27,17,10,24,4,13,27,26,27,0,14,11,20,22,1,7]

theorem envBound32631 : H12AffineFastState.Bounded env32631 := by
  intro p hp
  have h : env32631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32630_32631 : H12AffineEnvironment.transform 4 13 env32630 = env32631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env32630 == env32631) = true)

theorem identity32631 : scanCanonicalize (H12AffineFastState.compose env32631 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32631 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32632 : List Nat := [2,4,8,10,13,10,15,14,1,4,6,0,4,7,7,15,6,0,3,6,1,11,10,2,4,13,1,0,1,0,14,11,14,12,1,7]

theorem envBound32632 : H12AffineFastState.Bounded env32632 := by
  intro p hp
  have h : env32632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32631_32632 : H12AffineEnvironment.transform 3 10 env32631 = env32632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32631 == env32632) = true)

def env32633 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143497,20496,508075,148668,148669,96267,90263,148653,172,16401,1212,135680]

theorem envBound32633 : H12AffineFastState.Bounded env32633 := by
  intro p hp
  have h : env32633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32618_32633 : H12AffineEnvironment.transform 5 17 env32618 = env32633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32618 == env32633) = true)

theorem identity32633 : scanCanonicalize (H12AffineFastState.compose env32633 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound32633 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32634 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61569,115854,58519,111639,20496,279605,114722,114723,96267,90263,114739,172,16401,1212,104094]

theorem envBound32634 : H12AffineFastState.Bounded env32634 := by
  intro p hp
  have h : env32634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32633_32634 : H12AffineEnvironment.transform 16 99486 env32633 = env32634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env32633 == env32634) = true)

theorem identity32634 : scanCanonicalize (H12AffineFastState.compose env32634 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound32634 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env32635 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,37018,5124,262144,5,32769,4097,61569,21524,58519,9357,20496,279605,20664,20665,59537,61453,20649,172,16401,1212,1540]

theorem envBound32635 : H12AffineFastState.Bounded env32635 := by
  intro p hp
  have h : env32635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32634_32635 : H12AffineEnvironment.transform 15 37018 env32634 = env32635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env32634 == env32635) = true)

theorem identity32635 : scanCanonicalize (H12AffineFastState.compose env32635 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32635 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32636 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,37018,4096,262144,5,32769,4097,61569,20496,57491,8329,20496,278577,20664,20665,59537,61453,20649,172,16401,184,512]

theorem envBound32636 : H12AffineFastState.Bounded env32636 := by
  intro p hp
  have h : env32636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32635_32636 : H12AffineEnvironment.transform 9 4 env32635 = env32636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32635 == env32636) = true)

theorem identity32636 : scanCanonicalize (H12AffineFastState.compose env32636 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound32636 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32637 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,32768,37018,4096,262144,5,32769,4097,45112,4265,41002,8329,4265,262280,4097,4096,43048,45236,4112,172,168,184,512]

theorem envBound32637 : H12AffineFastState.Bounded env32637 := by
  intro p hp
  have h : env32637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32636_32637 : H12AffineEnvironment.transform 13 185 env32636 = env32637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env32636 == env32637) = true)

theorem identity32637 : scanCanonicalize (H12AffineFastState.compose env32637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound32637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32638 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4649,185,32768,37018,4096,262144,5,32769,4097,33297,4265,37379,4768,4265,262280,4097,4096,39425,33437,4112,172,168,184,512]

theorem envBound32638 : H12AffineFastState.Bounded env32638 := by
  intro p hp
  have h : env32638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32637_32638 : H12AffineEnvironment.transform 12 4649 env32637 = env32638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env32637 == env32638) = true)

theorem identity32638 : scanCanonicalize (H12AffineFastState.compose env32638 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound32638 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env32639 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,657,185,32768,32802,184,262144,5,32769,185,33297,17,33467,536,17,262280,185,184,35513,33437,168,172,168,184,512]

theorem envBound32639 : H12AffineFastState.Bounded env32639 := by
  intro p hp
  have h : env32639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32638_32639 : H12AffineEnvironment.transform 11 184 env32638 = env32639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env32638 == env32639) = true)

theorem identity32639 : scanCanonicalize (H12AffineFastState.compose env32639 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound32639 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32640 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,657,185,32768,32802,184,554,5,32769,185,33297,17,33467,536,17,674,185,184,35513,33437,168,172,168,184,512]

theorem envBound32640 : H12AffineFastState.Bounded env32640 := by
  intro p hp
  have h : env32640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32639_32640 : H12AffineEnvironment.transform 17 554 env32639 = env32640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env32639 == env32640) = true)

theorem identity32640 : scanCanonicalize (H12AffineFastState.compose env32640 (packedSelected [1,3,17] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound32640 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env32641 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,657,185,560,530,184,554,5,561,185,33,17,139,536,17,674,185,184,2185,173,168,172,168,184,512]

theorem envBound32641 : H12AffineFastState.Bounded env32641 := by
  intro p hp
  have h : env32641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32640_32641 : H12AffineEnvironment.transform 14 560 env32640 = env32641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env32640 == env32641) = true)

theorem identity32641 : scanCanonicalize (H12AffineFastState.compose env32641 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound32641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32642 : List Nat := [2,4,8,16,32,17,128,172,512,4,49,184,657,185,560,530,184,554,5,561,185,33,17,139,536,17,674,185,184,184,173,168,172,168,184,512]

theorem envBound32642 : H12AffineFastState.Bounded env32642 := by
  intro p hp
  have h : env32642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32641_32642 : H12AffineEnvironment.transform 10 49 env32641 = env32642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env32641 == env32642) = true)

theorem identity32642 : scanCanonicalize (H12AffineFastState.compose env32642 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound32642 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32643 : List Nat := [2,4,8,16,32,17,128,172,27,4,49,184,138,185,43,9,184,49,5,42,185,33,17,139,3,17,185,185,184,184,173,168,172,168,184,27]

theorem envBound32643 : H12AffineFastState.Bounded env32643 := by
  intro p hp
  have h : env32643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32642_32643 : H12AffineEnvironment.transform 8 27 env32642 = env32643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env32642 == env32643) = true)

theorem identity32643 : scanCanonicalize (H12AffineFastState.compose env32643 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound32643 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32644 : List Nat := [2,4,8,16,32,17,15,35,27,4,49,55,5,54,43,9,55,49,5,42,54,33,17,4,3,17,54,54,55,55,34,39,35,39,55,27]

theorem envBound32644 : H12AffineFastState.Bounded env32644 := by
  intro p hp
  have h : env32644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32643_32644 : H12AffineEnvironment.transform 6 15 env32643 = env32644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env32643 == env32644) = true)

def env32645 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143497,20496,508154,148716,148717,96346,90262,148733,173,16401,1260,135680]

theorem envBound32645 : H12AffineFastState.Bounded env32645 := by
  intro p hp
  have h : env32645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32617_32645 : H12AffineEnvironment.transform 7 173 env32617 = env32645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32617 == env32645) = true)

def env32646 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143497,20496,508074,148668,148669,96266,90262,148653,173,16401,1212,135680]

theorem envBound32646 : H12AffineFastState.Bounded env32646 := by
  intro p hp
  have h : env32646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32645_32646 : H12AffineEnvironment.transform 5 16 env32645 = env32646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32645 == env32646) = true)

theorem identity32646 : scanCanonicalize (H12AffineFastState.compose env32646 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound32646 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32647 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,58518,143497,20496,120866,148668,148669,96266,90262,148653,173,16401,1212,135680]

theorem envBound32647 : H12AffineFastState.Bounded env32647 := by
  intro p hp
  have h : env32647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32646_32647 : H12AffineEnvironment.transform 17 137352 env32646 = env32647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env32646 == env32647) = true)

theorem identity32647 : scanCanonicalize (H12AffineFastState.compose env32647 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound32647 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env32648 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4097,61568,46092,58518,50324,20496,120866,45217,45216,96266,90262,45232,173,16401,1212,58909]

theorem envBound32648 : H12AffineFastState.Bounded env32648 := by
  intro p hp
  have h : env32648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32647_32648 : H12AffineEnvironment.transform 16 62493 env32647 = env32648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env32647 == env32648) = true)

theorem identity32648 : scanCanonicalize (H12AffineFastState.compose env32648 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound32648 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32649 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,54310,62493,60565,57372,32769,4097,61568,46092,58518,50324,20496,3076,45217,45216,44076,46256,45232,173,16401,1212,58909]

theorem envBound32649 : H12AffineFastState.Bounded env32649 := by
  intro p hp
  have h : env32649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32648_32649 : H12AffineEnvironment.transform 15 54310 env32648 = env32649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env32648 == env32649) = true)

theorem identity32649 : scanCanonicalize (H12AffineFastState.compose env32649 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound32649 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env32650 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7828,16384,32768,54310,51849,53761,56968,32769,4097,52756,35480,55810,50324,20496,3076,36405,36404,37560,35364,36388,173,16401,1212,55433]

theorem envBound32650 : H12AffineFastState.Bounded env32650 := by
  intro p hp
  have h : env32650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32649_32650 : H12AffineEnvironment.transform 12 7828 env32649 = env32650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env32649 == env32650) = true)

theorem identity32650 : scanCanonicalize (H12AffineFastState.compose env32650 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32650 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env32651 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6801,16384,32768,53283,51849,53761,55949,32769,4097,51729,35480,55810,49297,20496,2049,35376,35377,37560,35364,35361,173,16401,185,55433]

theorem envBound32651 : H12AffineFastState.Bounded env32651 := by
  intro p hp
  have h : env32651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32650_32651 : H12AffineEnvironment.transform 9 5 env32650 = env32651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32650 == env32651) = true)

theorem identity32651 : scanCanonicalize (H12AffineFastState.compose env32651 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 18481) := by decide +kernel

theorem selectedBound32651 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env32652 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6801,16384,18481,6162,696,6704,4796,18480,4097,544,17065,4659,2208,20496,2049,16897,16896,23177,16917,16912,173,16401,185,4280]

theorem envBound32652 : H12AffineFastState.Bounded env32652 := by
  intro p hp
  have h : env32652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32651_32652 : H12AffineEnvironment.transform 14 18481 env32651 = env32652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18481 env32651 == env32652) = true)

theorem identity32652 : scanCanonicalize (H12AffineFastState.compose env32652 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2195) := by decide +kernel

theorem selectedBound32652 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env32653 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6801,2195,162,6162,696,6704,4796,163,4097,544,2618,4659,2208,6275,2049,2706,2707,4634,2694,2691,173,2178,185,4280]

theorem envBound32653 : H12AffineFastState.Bounded env32653 := by
  intro p hp
  have h : env32653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32652_32653 : H12AffineEnvironment.transform 13 2195 env32652 = env32653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2195 env32652 == env32653) = true)

theorem identity32653 : scanCanonicalize (H12AffineFastState.compose env32653 (packedSelected [1,2,3,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound32653 : packedSelected [1,2,3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32654 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,697,2088,2195,162,2731,696,2185,5,163,696,544,2618,138,2208,2618,2049,2706,2707,163,2694,2691,173,2178,185,513]

theorem envBound32654 : H12AffineFastState.Bounded env32654 := by
  intro p hp
  have h : env32654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32653_32654 : H12AffineEnvironment.transform 11 697 env32653 = env32654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env32653 == env32654) = true)

theorem identity32654 : scanCanonicalize (H12AffineFastState.compose env32654 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound32654 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env32655 : List Nat := [2,4,8,16,32,16,128,173,11,5,2048,178,2088,2195,162,2208,179,2185,5,163,179,43,2097,138,2208,2097,2049,2201,2200,163,2189,2184,173,2178,185,10]

theorem envBound32655 : H12AffineFastState.Bounded env32655 := by
  intro p hp
  have h : env32655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32654_32655 : H12AffineEnvironment.transform 8 11 env32654 = env32655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env32654 == env32655) = true)

theorem identity32655 : scanCanonicalize (H12AffineFastState.compose env32655 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound32655 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env32656 : List Nat := [2,4,8,16,32,16,19,62,11,5,2048,33,2088,2048,49,2099,32,2074,5,48,32,43,2097,25,2099,2097,2049,2058,2059,48,2078,2075,62,2065,42,10]

theorem envBound32656 : H12AffineFastState.Bounded env32656 := by
  intro p hp
  have h : env32656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32655_32656 : H12AffineEnvironment.transform 6 19 env32655 = env32656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env32655 == env32656) = true)

theorem identity32656 : scanCanonicalize (H12AffineFastState.compose env32656 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32656 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32657 : List Nat := [2,4,8,11,32,11,8,37,11,5,2048,33,2088,2048,42,2088,32,2049,5,43,32,43,2090,2,2088,2090,2049,2058,2059,43,2053,2048,37,2058,42,10]

theorem envBound32657 : H12AffineFastState.Bounded env32657 := by
  intro p hp
  have h : env32657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32656_32657 : H12AffineEnvironment.transform 3 11 env32656 = env32657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32656 == env32657) = true)

theorem identity32657 : scanCanonicalize (H12AffineFastState.compose env32657 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound32657 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32658 : List Nat := [2,4,8,11,9,11,8,12,11,5,2048,8,2049,2048,3,2049,9,2049,5,2,9,2,2051,2,2049,2051,2049,2058,2059,2,2053,2048,12,2058,3,10]

theorem envBound32658 : H12AffineFastState.Bounded env32658 := by
  intro p hp
  have h : env32658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32657_32658 : H12AffineEnvironment.transform 4 9 env32657 = env32658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env32657 == env32658) = true)

theorem identity32658 : scanCanonicalize (H12AffineFastState.compose env32658 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32658 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32659 : List Nat := [2,4,1,2,0,2,1,5,2,5,2048,1,2049,2048,3,2049,0,2049,5,2,0,2,2051,2,2049,2051,2049,2051,2050,2,2053,2048,5,2051,3,3]

theorem envBound32659 : H12AffineFastState.Bounded env32659 := by
  intro p hp
  have h : env32659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32658_32659 : H12AffineEnvironment.transform 2 1 env32658 = env32659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32658 == env32659) = true)

theorem identity32659 : scanCanonicalize (H12AffineFastState.compose env32659 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32659 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32660 : List Nat := [2,1,1,2,0,2,1,0,2,0,2048,1,2049,2048,3,2049,0,2049,0,2,0,2,2051,2,2049,2051,2049,2051,2050,2,2048,2048,0,2051,3,3]

theorem envBound32660 : H12AffineFastState.Bounded env32660 := by
  intro p hp
  have h : env32660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32659_32660 : H12AffineEnvironment.transform 1 1 env32659 = env32660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32659 == env32660) = true)

theorem identity32660 : scanCanonicalize (H12AffineFastState.compose env32660 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32660 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env32661 : List Nat := [1,1,1,1,0,1,1,0,1,0,2048,1,2049,2048,0,2049,0,2049,0,1,0,1,2048,1,2049,2048,2049,2048,2049,1,2048,2048,0,2048,0,0]

theorem envBound32661 : H12AffineFastState.Bounded env32661 := by
  intro p hp
  have h : env32661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32660_32661 : H12AffineEnvironment.transform 0 1 env32660 = env32661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32660 == env32661) = true)

theorem identity32661 : scanCanonicalize (H12AffineFastState.compose env32661 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32661 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32662 : List Nat := [1,1,1,1,0,1,1,0,1,0,0,1,1,0,0,1,0,1,0,1,0,1,0,1,1,0,1,0,1,1,0,0,0,0,0,0]

theorem envBound32662 : H12AffineFastState.Bounded env32662 := by
  intro p hp
  have h : env32662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32661_32662 : H12AffineEnvironment.transform 10 0 env32661 = env32662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32661 == env32662) = true)

def env32663 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143497,20496,508075,148669,148668,96267,90262,148652,173,16401,1213,135680]

theorem envBound32663 : H12AffineFastState.Bounded env32663 := by
  intro p hp
  have h : env32663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32645_32663 : H12AffineEnvironment.transform 5 17 env32645 = env32663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32645 == env32663) = true)

theorem identity32663 : scanCanonicalize (H12AffineFastState.compose env32663 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound32663 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32664 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,58518,32809,20496,356363,62493,62492,96267,90262,62476,173,16401,1213,41632]

theorem envBound32664 : H12AffineFastState.Bounded env32664 := by
  intro p hp
  have h : env32664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32663_32664 : H12AffineEnvironment.transform 16 45216 env32663 = env32664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env32663 == env32664) = true)

theorem identity32664 : scanCanonicalize (H12AffineFastState.compose env32664 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound32664 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32665 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4097,61569,61616,58518,32809,20496,96386,62493,62492,96267,90262,62476,173,16401,1213,41632]

theorem envBound32665 : H12AffineFastState.Bounded env32665 := by
  intro p hp
  have h : env32665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32664_32665 : H12AffineEnvironment.transform 17 2185 env32664 = env32665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env32664 == env32665) = true)

theorem identity32665 : scanCanonicalize (H12AffineFastState.compose env32665 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound32665 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env32666 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,65536,45216,2185,42145,32769,4097,45112,45065,42031,32809,4265,79931,46244,46245,80050,73775,46261,173,168,1213,41632]

theorem envBound32666 : H12AffineFastState.Bounded env32666 := by
  intro p hp
  have h : env32666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32665_32666 : H12AffineEnvironment.transform 13 185 env32665 = env32666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env32665 == env32666) = true)

theorem identity32666 : scanCanonicalize (H12AffineFastState.compose env32666 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound32666 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env32667 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,13374,45216,2185,42145,32769,4097,45112,45065,42031,32809,4265,3077,46244,46245,3212,5137,46261,173,168,1213,41632]

theorem envBound32667 : H12AffineFastState.Bounded env32667 := by
  intro p hp
  have h : env32667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32666_32667 : H12AffineEnvironment.transform 15 13374 env32666 = env32667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env32666 == env32667) = true)

theorem identity32667 : scanCanonicalize (H12AffineFastState.compose env32667 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 9757) := by decide +kernel

theorem selectedBound32667 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env32668 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,9757,13374,5821,2185,700,9756,4097,5669,5652,562,9780,4265,3077,4793,4792,3212,5137,4776,173,168,1213,1213]

theorem envBound32668 : H12AffineFastState.Bounded env32668 := by
  intro p hp
  have h : env32668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32667_32668 : H12AffineEnvironment.transform 14 9757 env32667 = env32668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9757 env32667 == env32668) = true)

theorem identity32668 : scanCanonicalize (H12AffineFastState.compose env32668 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3631) := by decide +kernel

theorem selectedBound32668 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env32669 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3631,8192,185,9757,10769,2194,2185,700,9756,3630,2058,2107,562,9780,3718,3077,3222,3223,3212,2622,3207,173,168,1213,1213]

theorem envBound32669 : H12AffineFastState.Bounded env32669 := by
  intro p hp
  have h : env32669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32668_32669 : H12AffineEnvironment.transform 11 3631 env32668 = env32669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3631 env32668 == env32669) = true)

theorem identity32669 : scanCanonicalize (H12AffineFastState.compose env32669 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound32669 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env32670 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3631,2584,185,3077,9,2194,2185,700,3076,3630,2058,2107,562,3116,3718,3077,3222,3223,3212,2622,3207,173,168,1213,1213]

theorem envBound32670 : H12AffineFastState.Bounded env32670 := by
  intro p hp
  have h : env32670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32669_32670 : H12AffineEnvironment.transform 12 2584 env32669 = env32670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env32669 == env32670) = true)

theorem identity32670 : scanCanonicalize (H12AffineFastState.compose env32670 (packedSelected [1,2,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound32670 : packedSelected [1,2,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32671 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1566,49,1030,185,539,9,1676,1687,700,538,48,1556,1573,562,562,152,539,648,649,658,1056,665,173,168,1213,1213]

theorem envBound32671 : H12AffineFastState.Bounded env32671 := by
  intro p hp
  have h : env32671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32670_32671 : H12AffineEnvironment.transform 10 1566 env32670 = env32671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env32670 == env32671) = true)

theorem identity32671 : scanCanonicalize (H12AffineFastState.compose env32671 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound32671 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env32672 : List Nat := [2,4,8,16,32,17,128,173,512,47,561,49,41,185,539,9,675,696,700,538,48,571,522,562,562,152,539,648,649,658,15,665,173,168,146,146]

theorem envBound32672 : H12AffineFastState.Bounded env32672 := by
  intro p hp
  have h : env32672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32671_32672 : H12AffineEnvironment.transform 9 47 env32671 = env32672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env32671 == env32672) = true)

theorem identity32672 : scanCanonicalize (H12AffineFastState.compose env32672 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound32672 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env32673 : List Nat := [2,4,8,16,32,17,57,20,512,47,561,49,41,0,539,9,538,513,517,538,48,571,522,562,562,33,539,561,560,555,15,544,20,17,43,43]

theorem envBound32673 : H12AffineFastState.Bounded env32673 := by
  intro p hp
  have h : env32673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32672_32673 : H12AffineEnvironment.transform 6 57 env32672 = env32673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env32672 == env32673) = true)

theorem identity32673 : scanCanonicalize (H12AffineFastState.compose env32673 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32673 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32674 : List Nat := [2,4,8,16,32,17,57,20,48,47,1,49,41,0,43,9,42,49,53,42,48,11,58,2,2,33,43,1,0,27,15,16,20,17,43,43]

theorem envBound32674 : H12AffineFastState.Bounded env32674 := by
  intro p hp
  have h : env32674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32673_32674 : H12AffineEnvironment.transform 8 48 env32673 = env32674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32673 == env32674) = true)

theorem identity32674 : scanCanonicalize (H12AffineFastState.compose env32674 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32674 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32675 : List Nat := [2,4,8,16,16,17,9,20,0,31,1,1,25,0,27,9,26,1,5,26,0,11,10,2,2,17,27,1,0,27,15,16,20,17,27,27]

theorem envBound32675 : H12AffineFastState.Bounded env32675 := by
  intro p hp
  have h : env32675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32674_32675 : H12AffineEnvironment.transform 4 16 env32674 = env32675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32674 == env32675) = true)

theorem identity32675 : scanCanonicalize (H12AffineFastState.compose env32675 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound32675 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32676 : List Nat := [2,4,8,13,13,12,9,9,0,2,1,1,4,0,6,9,7,1,5,7,0,11,10,2,2,12,6,1,0,6,15,13,9,12,6,6]

theorem envBound32676 : H12AffineFastState.Bounded env32676 := by
  intro p hp
  have h : env32676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32675_32676 : H12AffineEnvironment.transform 3 13 env32675 = env32676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env32675 == env32676) = true)

def env32677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,134217728,148801,545088,96346,16876545,134579626,257,151876048,151462016,525824]

theorem envBound32677 : H12AffineFastState.Bounded env32677 := by
  intro p hp
  have h : env32677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32441_32677 : H12AffineEnvironment.transform 24 533641 env32441 = env32677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env32441 == env32677) = true)

def env32678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245632,148801,545088,96346,16876545,16949354,257,676880,1344,525824]

theorem envBound32678 : H12AffineFastState.Bounded env32678 := by
  intro p hp
  have h : env32678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32677_32678 : H12AffineEnvironment.transform 26 17245632 env32677 = env32678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env32677 == env32678) = true)

theorem identity32678 : scanCanonicalize (H12AffineFastState.compose env32678 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound32678 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,16777216,533641,614526,17039791,90414,545088,96346,16876545,16876549,257,618623,1344,525824]

theorem envBound32679 : H12AffineFastState.Bounded env32679 := by
  intro p hp
  have h : env32679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32678_32679 : H12AffineEnvironment.transform 16 74863 env32678 = env32679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env32678 == env32679) = true)

def env32680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123164,533641,614526,385203,90414,545088,96346,25885,25881,257,618623,1344,525824]

theorem envBound32680 : H12AffineFastState.Bounded env32680 := by
  intro p hp
  have h : env32680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32679_32680 : H12AffineEnvironment.transform 23 123164 env32679 = env32680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env32679 == env32680) = true)

def env32681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123164,28889,78894,385203,90414,1296,96346,25885,25881,257,74799,1344,21072]

theorem envBound32681 : H12AffineFastState.Bounded env32681 := by
  intro p hp
  have h : env32681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32680_32681 : H12AffineEnvironment.transform 18 21584 env32680 = env32681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env32680 == env32681) = true)

theorem identity32681 : scanCanonicalize (H12AffineFastState.compose env32681 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound32681 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4097,17612,91182,87296,28889,78894,349359,90414,1296,96346,25885,25881,257,74799,1344,21072]

theorem envBound32682 : H12AffineFastState.Bounded env32682 := by
  intro p hp
  have h : env32682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32681_32682 : H12AffineEnvironment.transform 14 13340 env32681 = env32682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env32681 == env32682) = true)

def env32683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4097,476,74046,69648,13769,78894,332223,74814,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound32683 : H12AffineFastState.Bounded env32683 := by
  intro p hp
  have h : env32683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32682_32683 : H12AffineEnvironment.transform 13 1296 env32682 = env32683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32682 == env32683) = true)

def env32684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4097,476,74046,69648,13769,78894,4415,74814,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound32684 : H12AffineFastState.Bounded env32684 := by
  intro p hp
  have h : env32684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32683_32684 : H12AffineEnvironment.transform 17 65664 env32683 = env32684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32683 == env32684) = true)

theorem identity32684 : scanCanonicalize (H12AffineFastState.compose env32684 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound32684 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9326,1,9454,4416,13341,4097,476,1360,13438,13769,4160,4415,80,1296,6436,8205,8201,257,65,1344,5952]

theorem envBound32685 : H12AffineFastState.Bounded env32685 := by
  intro p hp
  have h : env32685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32684_32685 : H12AffineEnvironment.transform 15 9326 env32684 = env32685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env32684 == env32685) = true)

def env32686 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,8494,1,8622,4416,12637,4097,476,16,12606,12425,4160,4415,80,80,6436,8205,8201,257,65,0,4608]

theorem envBound32686 : H12AffineFastState.Bounded env32686 := by
  intro p hp
  have h : env32686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32685_32686 : H12AffineEnvironment.transform 9 320 env32685 = env32686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32685 == env32686) = true)

theorem identity32686 : scanCanonicalize (H12AffineFastState.compose env32686 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound32686 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32687 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,80,324,4406,1,4534,4416,325,4097,476,16,294,145,4160,4415,80,80,6436,4117,4113,257,65,0,4608]

theorem envBound32687 : H12AffineFastState.Bounded env32687 := by
  intro p hp
  have h : env32687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32686_32687 : H12AffineEnvironment.transform 12 4120 env32686 = env32687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env32686 == env32687) = true)

theorem identity32687 : scanCanonicalize (H12AffineFastState.compose env32687 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32687 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32688 : List Nat := [2,4,8,16,32,64,128,172,512,236,2048,4096,4120,80,232,4250,1,4122,4332,233,4097,112,16,138,145,4160,4243,80,80,6280,4117,4113,173,65,0,4608]

theorem envBound32688 : H12AffineFastState.Bounded env32688 := by
  intro p hp
  have h : env32688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32687_32688 : H12AffineEnvironment.transform 7 172 env32687 = env32688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32687 == env32688) = true)

theorem identity32688 : scanCanonicalize (H12AffineFastState.compose env32688 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound32688 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env32689 : List Nat := [2,4,8,16,32,64,128,172,512,236,755,4096,4120,80,232,4250,1,4122,4332,233,4097,112,16,138,145,4160,4243,80,80,4731,4117,4113,173,65,0,4608]

theorem envBound32689 : H12AffineFastState.Bounded env32689 := by
  intro p hp
  have h : env32689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32688_32689 : H12AffineEnvironment.transform 10 755 env32688 = env32689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env32688 == env32689) = true)

theorem identity32689 : scanCanonicalize (H12AffineFastState.compose env32689 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound32689 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32690 : List Nat := [2,4,8,16,32,64,128,172,75,236,184,4096,4120,80,232,4250,1,4122,4332,233,4097,112,16,138,145,4160,4243,80,80,4144,4117,4113,173,65,0,4171]

theorem envBound32690 : H12AffineFastState.Bounded env32690 := by
  intro p hp
  have h : env32690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32689_32690 : H12AffineEnvironment.transform 8 75 env32689 = env32690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env32689 == env32690) = true)

theorem identity32690 : scanCanonicalize (H12AffineFastState.compose env32690 (packedSelected [0,1,2,3,5,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32690 : packedSelected [0,1,2,3,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env32691 : List Nat := [2,4,8,16,32,64,18,62,75,126,42,4096,4120,80,122,4104,1,4122,4222,123,4097,112,16,24,3,4160,4097,80,80,4144,4117,4113,63,65,0,4171]

theorem envBound32691 : H12AffineFastState.Bounded env32691 := by
  intro p hp
  have h : env32691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32690_32691 : H12AffineEnvironment.transform 6 18 env32690 = env32691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32690 == env32691) = true)

theorem identity32691 : scanCanonicalize (H12AffineFastState.compose env32691 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound32691 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32692 : List Nat := [2,4,8,16,32,59,18,62,48,5,42,4096,4120,43,1,4104,1,4122,4101,0,4097,11,16,24,3,4155,4097,43,43,4144,4117,4113,63,58,0,4144]

theorem envBound32692 : H12AffineFastState.Bounded env32692 := by
  intro p hp
  have h : env32692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32691_32692 : H12AffineEnvironment.transform 5 59 env32691 = env32692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env32691 == env32692) = true)

theorem identity32692 : scanCanonicalize (H12AffineFastState.compose env32692 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound32692 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32693 : List Nat := [2,4,8,16,32,59,18,62,48,5,42,26,2,43,1,18,1,0,31,0,27,11,16,24,3,33,27,43,43,42,15,11,63,58,0,42]

theorem envBound32693 : H12AffineFastState.Bounded env32693 := by
  intro p hp
  have h : env32693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32692_32693 : H12AffineEnvironment.transform 11 26 env32692 = env32693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env32692 == env32693) = true)

def env32694 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,8495,1,8623,4416,12636,4097,476,17,12607,12424,4160,4415,80,81,6436,8205,8201,257,65,1,4609]

theorem envBound32694 : H12AffineFastState.Bounded env32694 := by
  intro p hp
  have h : env32694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32685_32694 : H12AffineEnvironment.transform 9 321 env32685 = env32694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32685 == env32694) = true)

theorem identity32694 : scanCanonicalize (H12AffineFastState.compose env32694 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound32694 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32695 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,8192,81,12313,8299,1,8427,4100,12312,4097,152,17,12411,12424,4160,4219,80,81,6240,8205,8201,69,65,1,4609]

theorem envBound32695 : H12AffineFastState.Bounded env32695 := by
  intro p hp
  have h : env32695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32694_32695 : H12AffineEnvironment.transform 7 68 env32694 = env32695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env32694 == env32695) = true)

theorem identity32695 : scanCanonicalize (H12AffineFastState.compose env32695 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32695 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32696 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,81,8216,8299,1,8427,5,8217,0,152,17,8314,8329,65,122,80,81,2145,8205,8201,69,65,1,512]

theorem envBound32696 : H12AffineFastState.Bounded env32696 := by
  intro p hp
  have h : env32696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32695_32696 : H12AffineEnvironment.transform 11 1 env32695 = env32696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32695 == env32696) = true)

theorem identity32696 : scanCanonicalize (H12AffineFastState.compose env32696 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound32696 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32697 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,24,81,0,115,1,243,5,1,0,152,17,98,145,65,122,80,81,2145,21,17,69,65,1,512]

theorem envBound32697 : H12AffineFastState.Bounded env32697 := by
  intro p hp
  have h : env32697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32696_32697 : H12AffineEnvironment.transform 12 24 env32696 = env32697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env32696 == env32697) = true)

theorem identity32697 : scanCanonicalize (H12AffineFastState.compose env32697 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound32697 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32698 : List Nat := [2,4,8,16,32,64,128,68,136,5,2048,1,24,81,0,115,1,243,5,1,0,152,17,98,145,65,122,80,81,2145,21,17,69,65,1,136]

theorem envBound32698 : H12AffineFastState.Bounded env32698 := by
  intro p hp
  have h : env32698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32697_32698 : H12AffineEnvironment.transform 8 136 env32697 = env32698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env32697 == env32698) = true)

theorem identity32698 : scanCanonicalize (H12AffineFastState.compose env32698 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound32698 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env32699 : List Nat := [2,4,8,16,32,64,128,68,136,5,146,1,24,81,0,115,1,243,5,1,0,152,17,98,145,65,122,80,81,243,21,17,69,65,1,136]

theorem envBound32699 : H12AffineFastState.Bounded env32699 := by
  intro p hp
  have h : env32699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32698_32699 : H12AffineEnvironment.transform 10 146 env32698 = env32699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env32698 == env32699) = true)

theorem identity32699 : scanCanonicalize (H12AffineFastState.compose env32699 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound32699 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32700 : List Nat := [2,4,8,16,32,64,56,68,48,5,42,1,24,81,0,115,1,75,5,1,0,32,17,98,41,65,122,80,81,75,21,17,69,65,1,48]

theorem envBound32700 : H12AffineFastState.Bounded env32700 := by
  intro p hp
  have h : env32700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32699_32700 : H12AffineEnvironment.transform 6 56 env32699 = env32700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env32699 == env32700) = true)

theorem identity32700 : scanCanonicalize (H12AffineFastState.compose env32700 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32700 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32701 : List Nat := [2,4,8,16,32,16,56,20,48,5,42,1,24,1,0,35,1,27,5,1,0,32,17,50,41,17,42,0,1,27,21,17,21,17,1,48]

theorem envBound32701 : H12AffineFastState.Bounded env32701 := by
  intro p hp
  have h : env32701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32700_32701 : H12AffineEnvironment.transform 5 16 env32700 = env32701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32700 == env32701) = true)

theorem identity32701 : scanCanonicalize (H12AffineFastState.compose env32701 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32702 : List Nat := [2,4,8,16,12,16,20,20,28,5,6,1,24,1,0,15,1,27,5,1,0,12,17,30,5,17,6,0,1,27,21,17,21,17,1,28]

theorem envBound32702 : H12AffineFastState.Bounded env32702 := by
  intro p hp
  have h : env32702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32701_32702 : H12AffineEnvironment.transform 4 12 env32701 = env32702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32701 == env32702) = true)

theorem identity32702 : scanCanonicalize (H12AffineFastState.compose env32702 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32703 : List Nat := [2,2,8,16,10,16,18,18,26,3,0,1,24,1,0,9,1,27,3,1,0,10,17,24,3,17,0,0,1,27,19,17,19,17,1,26]

theorem envBound32703 : H12AffineFastState.Bounded env32703 := by
  intro p hp
  have h : env32703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32702_32703 : H12AffineEnvironment.transform 1 2 env32702 = env32703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32702 == env32703) = true)

theorem identity32703 : scanCanonicalize (H12AffineFastState.compose env32703 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32704 : List Nat := [2,2,8,11,10,11,9,9,1,3,0,1,3,1,0,9,1,0,3,1,0,10,10,3,3,10,0,0,1,0,8,10,8,10,1,1]

theorem envBound32704 : H12AffineFastState.Bounded env32704 := by
  intro p hp
  have h : env32704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32703_32704 : H12AffineEnvironment.transform 3 11 env32703 = env32704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32703 == env32704) = true)

def env32705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4097,476,74046,69648,13769,78894,4414,74814,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound32705 : H12AffineFastState.Bounded env32705 := by
  intro p hp
  have h : env32705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32683_32705 : H12AffineEnvironment.transform 17 65665 env32683 = env32705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32683 == env32705) = true)

theorem identity32705 : scanCanonicalize (H12AffineFastState.compose env32705 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound32705 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12591,5440,12718,4416,13341,4097,476,4113,8511,13769,1281,4414,5393,1296,3173,8205,8201,257,5376,1344,5952]

theorem envBound32706 : H12AffineFastState.Bounded env32706 := by
  intro p hp
  have h : env32706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32705_32706 : H12AffineEnvironment.transform 15 12591 env32705 = env32706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env32705 == env32706) = true)

def env32707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,8495,1344,8622,320,9245,1,476,17,8511,9673,1281,318,1297,1296,3173,8205,8201,257,1280,1344,1856]

theorem envBound32707 : H12AffineFastState.Bounded env32707 := by
  intro p hp
  have h : env32707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32706_32707 : H12AffineEnvironment.transform 11 0 env32706 = env32707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32706 == env32707) = true)

theorem identity32707 : scanCanonicalize (H12AffineFastState.compose env32707 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32707 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32708 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,277,8217,8495,325,8622,320,8216,1,476,17,8511,8652,260,318,276,277,2144,8205,8201,257,261,325,837]

theorem envBound32708 : H12AffineFastState.Bounded env32708 := by
  intro p hp
  have h : env32708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32707_32708 : H12AffineEnvironment.transform 9 5 env32707 = env32708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32707 == env32708) = true)

theorem identity32708 : scanCanonicalize (H12AffineFastState.compose env32708 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound32708 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env32709 : List Nat := [2,4,8,16,32,64,128,256,512,5,587,0,8192,277,8217,8495,325,8622,320,8216,1,476,17,8511,8652,260,318,276,277,555,8205,8201,257,261,325,837]

theorem envBound32709 : H12AffineFastState.Bounded env32709 := by
  intro p hp
  have h : env32709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32708_32709 : H12AffineEnvironment.transform 10 587 env32708 = env32709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env32708 == env32709) = true)

theorem identity32709 : scanCanonicalize (H12AffineFastState.compose env32709 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound32709 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env32710 : List Nat := [2,4,8,16,32,64,128,252,512,5,587,0,8192,233,8217,8403,185,8274,188,8216,1,32,17,8387,8240,248,194,232,233,555,8205,8201,253,249,185,697]

theorem envBound32710 : H12AffineFastState.Bounded env32710 := by
  intro p hp
  have h : env32710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32709_32710 : H12AffineEnvironment.transform 7 252 env32709 = env32710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env32709 == env32710) = true)

theorem identity32710 : scanCanonicalize (H12AffineFastState.compose env32710 (packedSelected [1,2,3,5,8,10,11,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound32710 : packedSelected [1,2,3,5,8,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32711 : List Nat := [2,4,8,16,32,64,128,252,512,5,587,0,25,233,0,202,185,75,188,1,1,32,17,218,41,248,194,232,233,555,20,16,253,249,185,697]

theorem envBound32711 : H12AffineFastState.Bounded env32711 := by
  intro p hp
  have h : env32711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32710_32711 : H12AffineEnvironment.transform 12 25 env32710 = env32711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32710 == env32711) = true)

theorem identity32711 : scanCanonicalize (H12AffineFastState.compose env32711 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound32711 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env32712 : List Nat := [2,4,8,16,32,64,105,21,512,5,587,0,25,0,0,35,80,75,85,1,1,32,17,51,41,17,43,1,0,555,20,16,20,16,80,592]

theorem envBound32712 : H12AffineFastState.Bounded env32712 := by
  intro p hp
  have h : env32712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32711_32712 : H12AffineEnvironment.transform 6 105 env32711 = env32712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env32711 == env32712) = true)

theorem identity32712 : scanCanonicalize (H12AffineFastState.compose env32712 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound32712 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env32713 : List Nat := [2,4,8,13,32,64,105,8,512,5,587,0,4,0,0,35,77,75,72,1,1,32,12,46,41,12,43,1,0,555,9,13,9,13,77,589]

theorem envBound32713 : H12AffineFastState.Bounded env32713 := by
  intro p hp
  have h : env32713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32712_32713 : H12AffineEnvironment.transform 3 13 env32712 = env32713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env32712 == env32713) = true)

theorem identity32713 : scanCanonicalize (H12AffineFastState.compose env32713 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32713 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32714 : List Nat := [2,4,8,13,10,64,67,8,512,5,587,0,4,0,0,9,77,75,72,1,1,10,12,4,3,12,1,1,0,513,9,13,9,13,77,589]

theorem envBound32714 : H12AffineFastState.Bounded env32714 := by
  intro p hp
  have h : env32714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32713_32714 : H12AffineEnvironment.transform 4 10 env32713 = env32714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32713 == env32714) = true)

theorem identity32714 : scanCanonicalize (H12AffineFastState.compose env32714 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound32714 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32715 : List Nat := [2,4,8,13,10,64,67,8,6,5,77,0,4,0,0,9,77,75,72,1,1,10,12,4,3,12,1,1,0,7,9,13,9,13,77,75]

theorem envBound32715 : H12AffineFastState.Bounded env32715 := by
  intro p hp
  have h : env32715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32714_32715 : H12AffineEnvironment.transform 8 6 env32714 = env32715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env32714 == env32715) = true)

def env32716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,8494,1345,8623,321,9244,0,476,16,8511,9672,1281,319,1296,1296,3173,8205,8201,257,1281,1344,1857]

theorem envBound32716 : H12AffineFastState.Bounded env32716 := by
  intro p hp
  have h : env32716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32706_32716 : H12AffineEnvironment.transform 11 1 env32706 = env32716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32706 == env32716) = true)

theorem identity32716 : scanCanonicalize (H12AffineFastState.compose env32716 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound32716 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1296,1028,311,1345,438,321,1029,0,476,16,294,1489,1281,319,1296,1296,3173,20,16,257,1281,1344,1857]

theorem envBound32717 : H12AffineFastState.Bounded env32717 := by
  intro p hp
  have h : env32717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32716_32717 : H12AffineEnvironment.transform 12 25 env32716 = env32717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32716 == env32717) = true)

theorem identity32717 : scanCanonicalize (H12AffineFastState.compose env32717 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32717 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32718 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,1,25,1212,1028,155,1261,26,237,1029,0,112,16,138,1149,1197,147,1212,1212,3173,20,16,173,1197,1260,1773]

theorem envBound32718 : H12AffineFastState.Bounded env32718 := by
  intro p hp
  have h : env32718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32717_32718 : H12AffineEnvironment.transform 7 172 env32717 = env32718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32717 == env32718) = true)

theorem identity32718 : scanCanonicalize (H12AffineFastState.compose env32718 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound32718 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env32719 : List Nat := [2,4,8,16,32,64,128,172,512,1024,754,1,25,1212,1028,155,1261,26,237,1029,0,112,16,138,1149,1197,147,1212,1212,1687,20,16,173,1197,1260,1773]

theorem envBound32719 : H12AffineFastState.Bounded env32719 := by
  intro p hp
  have h : env32719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32718_32719 : H12AffineEnvironment.transform 10 754 env32718 = env32719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env32718 == env32719) = true)

end H12CloudChart2