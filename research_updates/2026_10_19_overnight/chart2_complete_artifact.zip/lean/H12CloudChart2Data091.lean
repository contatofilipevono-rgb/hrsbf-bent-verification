import H12CloudChart2Data090

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem terminalChecked22328 : H12PackedTerminal.terminalCheckFast leafEnv22328 active22328 tree22328 = true := by decide +kernel

def env22329 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,8233,65536,0,2048,273,8232,1,10248,17,74028,8328,17,8460,0,0,8460,20,73770,257,10660,1,136]

theorem envBound22329 : H12AffineFastState.Bounded env22329 := by
  intro p hp
  have h : env22329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22314_22329 : H12AffineEnvironment.transform 14 8233 env22314 = env22329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env22314 == env22329) = true)

def env22330 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,40,1,1,65536,0,2048,273,0,1,2080,17,65796,160,17,292,0,0,292,20,65538,257,2444,1,136]

theorem envBound22330 : H12AffineFastState.Bounded env22330 := by
  intro p hp
  have h : env22330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22329_22330 : H12AffineEnvironment.transform 12 40 env22329 = env22330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22329 == env22330) = true)

def env22331 : List Nat := [2,4,8,16,32,16,128,256,136,272,136,0,40,1,1,65536,0,136,273,0,1,168,17,65796,160,17,292,0,0,292,20,65538,257,260,1,136]

theorem envBound22331 : H12AffineFastState.Bounded env22331 := by
  intro p hp
  have h : env22331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22330_22331 : H12AffineEnvironment.transform 10 136 env22330 = env22331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env22330 == env22331) = true)

theorem identity22331 : scanCanonicalize (H12AffineFastState.compose env22331 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound22331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22332 : List Nat := [2,4,8,16,32,16,41,256,33,272,33,0,40,1,1,65536,0,33,273,0,1,1,17,65796,9,17,292,0,0,292,20,65538,257,260,1,33]

theorem envBound22332 : H12AffineFastState.Bounded env22332 := by
  intro p hp
  have h : env22332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22331_22332 : H12AffineEnvironment.transform 6 41 env22331 = env22332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22331 == env22332) = true)

def env22333 : List Nat := [2,4,8,16,0,16,9,256,1,272,1,0,8,1,1,65536,0,1,273,0,1,1,17,65796,9,17,260,0,0,260,20,65538,257,260,1,1]

theorem envBound22333 : H12AffineFastState.Bounded env22333 := by
  intro p hp
  have h : env22333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22332_22333 : H12AffineEnvironment.transform 4 0 env22332 = env22333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22332 == env22333) = true)

def env22334 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,0,8,1,1,65536,0,1,21,0,1,1,17,65536,9,17,0,0,0,0,20,65538,5,0,1,1]

theorem envBound22334 : H12AffineFastState.Bounded env22334 := by
  intro p hp
  have h : env22334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22333_22334 : H12AffineEnvironment.transform 7 4 env22333 = env22334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22333 == env22334) = true)

def env22335 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,1,65536,0,1,20,0,1,1,17,65537,9,17,1,0,0,1,20,65538,4,1,1,1]

theorem envBound22335 : H12AffineFastState.Bounded env22335 := by
  intro p hp
  have h : env22335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22333_22335 : H12AffineEnvironment.transform 7 5 env22333 = env22335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22333 == env22335) = true)

theorem identity22335 : scanCanonicalize (H12AffineFastState.compose env22335 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound22335 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22336 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,1,3,0,1,20,0,1,1,17,2,9,17,1,0,0,1,20,1,4,1,1,1]

theorem envBound22336 : H12AffineFastState.Bounded env22336 := by
  intro p hp
  have h : env22336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22335_22336 : H12AffineEnvironment.transform 15 3 env22335 = env22336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env22335 == env22336) = true)

def leafEnv22336 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,1,1,3,0,1,20,0,1,1,17,2,21,9,1,17,1,0,0,1,20,1,4,1,5,3,1,1,0,1,1]

def active22336 : List Nat := [0,1,2,3]

def tree22336 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22336 : H12WitnessSearch.Good tree22336 := H12GlobalWitnessIndex.good

theorem leafIdentity22336 : H12AffineFastState.composeSystem env22336 rootObs = leafEnv22336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22336 rootObs == leafEnv22336) = true)

theorem terminalChecked22336 : H12PackedTerminal.terminalCheckFast leafEnv22336 active22336 tree22336 = true := by decide +kernel

def env22337 : List Nat := [2,4,8,16,1,16,8,256,0,272,0,0,9,1,1,65536,0,0,273,0,1,1,17,65796,9,17,261,0,0,261,20,65538,257,260,1,0]

theorem envBound22337 : H12AffineFastState.Bounded env22337 := by
  intro p hp
  have h : env22337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22332_22337 : H12AffineEnvironment.transform 4 1 env22332 = env22337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22332 == env22337) = true)

theorem identity22337 : scanCanonicalize (H12AffineFastState.compose env22337 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22338 : List Nat := [2,4,8,16,1,16,8,256,0,272,0,0,9,1,1,262,0,0,273,0,1,1,17,2,9,17,261,0,0,261,20,260,257,260,1,0]

theorem envBound22338 : H12AffineFastState.Bounded env22338 := by
  intro p hp
  have h : env22338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22337_22338 : H12AffineEnvironment.transform 15 262 env22337 = env22338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22337 == env22338) = true)

def env22339 : List Nat := [2,4,8,16,32,16,128,256,136,272,137,0,40,1,1,65536,0,137,273,0,1,169,17,65796,160,17,292,0,0,292,20,65538,257,261,1,136]

theorem envBound22339 : H12AffineFastState.Bounded env22339 := by
  intro p hp
  have h : env22339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22330_22339 : H12AffineEnvironment.transform 10 137 env22330 = env22339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env22330 == env22339) = true)

theorem identity22339 : scanCanonicalize (H12AffineFastState.compose env22339 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22340 : List Nat := [2,4,8,16,32,16,128,140,136,156,137,0,40,1,1,65536,0,137,157,0,1,169,17,65672,160,17,168,0,0,168,20,65538,141,137,1,136]

theorem envBound22340 : H12AffineFastState.Bounded env22340 := by
  intro p hp
  have h : env22340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22339_22340 : H12AffineEnvironment.transform 7 140 env22339 = env22340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22339 == env22340) = true)

def env22341 : List Nat := [2,4,8,16,0,16,128,140,136,156,137,0,8,1,1,65536,0,137,157,0,1,137,17,65672,128,17,136,0,0,136,20,65538,141,137,1,136]

theorem envBound22341 : H12AffineFastState.Bounded env22341 := by
  intro p hp
  have h : env22341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22340_22341 : H12AffineEnvironment.transform 4 0 env22340 = env22341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22340 == env22341) = true)

theorem identity22341 : scanCanonicalize (H12AffineFastState.compose env22341 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22342 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,8,1,1,65536,0,1,21,0,1,1,17,65536,8,17,0,0,0,0,20,65538,5,1,1,0]

theorem envBound22342 : H12AffineFastState.Bounded env22342 := by
  intro p hp
  have h : env22342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22341_22342 : H12AffineEnvironment.transform 6 8 env22341 = env22342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22341 == env22342) = true)

def env22343 : List Nat := [2,4,8,16,1,16,128,140,136,156,137,0,9,1,1,65536,0,137,157,0,1,136,17,65672,129,17,137,0,0,137,20,65538,141,137,1,136]

theorem envBound22343 : H12AffineFastState.Bounded env22343 := by
  intro p hp
  have h : env22343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22340_22343 : H12AffineEnvironment.transform 4 1 env22340 = env22343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22340 == env22343) = true)

theorem identity22343 : scanCanonicalize (H12AffineFastState.compose env22343 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound22343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22344 : List Nat := [2,4,8,16,1,16,128,140,136,156,137,0,9,1,1,138,0,137,157,0,1,136,17,2,129,17,137,0,0,137,20,136,141,137,1,136]

theorem envBound22344 : H12AffineFastState.Bounded env22344 := by
  intro p hp
  have h : env22344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22343_22344 : H12AffineEnvironment.transform 15 138 env22343 = env22344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env22343 == env22344) = true)

def leafEnv22344 : List Nat := [2,4,8,16,1,16,128,140,136,156,137,0,9,1,1,138,0,137,157,0,1,136,17,2,21,129,1,17,137,0,0,137,20,136,141,137,5,138,1,136,0,1,1]

def active22344 : List Nat := [0,1,2,3,6]

def tree22344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22344 : H12WitnessSearch.Good tree22344 := H12GlobalWitnessIndex.good

theorem leafIdentity22344 : H12AffineFastState.composeSystem env22344 rootObs = leafEnv22344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22344 rootObs == leafEnv22344) = true)

theorem terminalChecked22344 : H12PackedTerminal.terminalCheckFast leafEnv22344 active22344 tree22344 = true := by decide +kernel

def env22345 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,41,1,0,65536,0,2048,273,1,1,2081,17,65797,161,17,293,0,0,293,20,65539,257,2445,1,136]

theorem envBound22345 : H12AffineFastState.Bounded env22345 := by
  intro p hp
  have h : env22345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22329_22345 : H12AffineEnvironment.transform 12 41 env22329 = env22345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env22329 == env22345) = true)

def env22346 : List Nat := [2,4,8,16,32,16,128,256,136,272,136,0,41,1,0,65536,0,136,273,1,1,169,17,65797,161,17,293,0,0,293,20,65539,257,261,1,136]

theorem envBound22346 : H12AffineFastState.Bounded env22346 := by
  intro p hp
  have h : env22346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22345_22346 : H12AffineEnvironment.transform 10 136 env22345 = env22346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env22345 == env22346) = true)

theorem identity22346 : scanCanonicalize (H12AffineFastState.compose env22346 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound22346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22347 : List Nat := [2,4,8,16,32,16,128,256,136,272,136,0,41,1,0,2,0,136,273,1,1,169,17,263,161,17,293,0,0,293,20,1,257,261,1,136]

theorem envBound22347 : H12AffineFastState.Bounded env22347 := by
  intro p hp
  have h : env22347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22346_22347 : H12AffineEnvironment.transform 15 2 env22346 = env22347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env22346 == env22347) = true)

def env22348 : List Nat := [2,4,8,16,0,16,128,256,136,272,136,0,9,1,0,2,0,136,273,1,1,137,17,263,129,17,261,0,0,261,20,1,257,261,1,136]

theorem envBound22348 : H12AffineFastState.Bounded env22348 := by
  intro p hp
  have h : env22348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22347_22348 : H12AffineEnvironment.transform 4 0 env22347 = env22348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22347 == env22348) = true)

theorem identity22348 : scanCanonicalize (H12AffineFastState.compose env22348 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22349 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,0,9,1,0,2,0,0,273,1,1,1,17,263,9,17,261,0,0,261,20,1,257,261,1,0]

theorem envBound22349 : H12AffineFastState.Bounded env22349 := by
  intro p hp
  have h : env22349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22348_22349 : H12AffineEnvironment.transform 6 8 env22348 = env22349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22348 == env22349) = true)

def env22350 : List Nat := [2,4,8,16,1,16,128,256,136,272,136,0,8,1,0,2,0,136,273,1,1,136,17,263,128,17,260,0,0,260,20,1,257,261,1,136]

theorem envBound22350 : H12AffineFastState.Bounded env22350 := by
  intro p hp
  have h : env22350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22347_22350 : H12AffineEnvironment.transform 4 1 env22347 = env22350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22347 == env22350) = true)

theorem identity22350 : scanCanonicalize (H12AffineFastState.compose env22350 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22351 : List Nat := [2,4,8,16,1,16,128,5,136,21,136,0,8,1,0,2,0,136,20,1,1,136,17,2,128,17,1,0,0,1,20,1,4,0,1,136]

theorem envBound22351 : H12AffineFastState.Bounded env22351 := by
  intro p hp
  have h : env22351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22350_22351 : H12AffineEnvironment.transform 7 5 env22350 = env22351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22350 == env22351) = true)

def leafEnv22351 : List Nat := [2,4,8,16,1,16,128,5,136,21,136,0,8,1,0,2,0,136,20,1,1,136,17,2,21,128,1,17,1,0,0,1,20,1,4,0,5,2,1,136,0,1,1]

def active22351 : List Nat := [0,1,2,3,6]

def tree22351 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22351 : H12WitnessSearch.Good tree22351 := H12GlobalWitnessIndex.good

theorem leafIdentity22351 : H12AffineFastState.composeSystem env22351 rootObs = leafEnv22351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22351 rootObs == leafEnv22351) = true)

theorem terminalChecked22351 : H12PackedTerminal.terminalCheckFast leafEnv22351 active22351 tree22351 = true := by decide +kernel

def env22352 : List Nat := [2,4,8,16,32,16,128,256,136,272,137,0,41,1,0,65536,0,137,273,1,1,168,17,65797,161,17,293,0,0,293,20,65539,257,260,1,136]

theorem envBound22352 : H12AffineFastState.Bounded env22352 := by
  intro p hp
  have h : env22352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22345_22352 : H12AffineEnvironment.transform 10 137 env22345 = env22352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env22345 == env22352) = true)

theorem identity22352 : scanCanonicalize (H12AffineFastState.compose env22352 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound22352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22353 : List Nat := [2,4,8,16,32,16,128,256,136,272,137,0,41,1,0,295,0,137,273,1,1,168,17,34,161,17,293,0,0,293,20,292,257,260,1,136]

theorem envBound22353 : H12AffineFastState.Bounded env22353 := by
  intro p hp
  have h : env22353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22352_22353 : H12AffineEnvironment.transform 15 295 env22352 = env22353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env22352 == env22353) = true)

def env22354 : List Nat := [2,4,8,16,0,16,128,256,136,272,137,0,9,1,0,263,0,137,273,1,1,136,17,2,129,17,261,0,0,261,20,260,257,260,1,136]

theorem envBound22354 : H12AffineFastState.Bounded env22354 := by
  intro p hp
  have h : env22354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22353_22354 : H12AffineEnvironment.transform 4 0 env22353 = env22354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22353 == env22354) = true)

def env22355 : List Nat := [2,4,8,16,0,16,8,256,0,272,1,0,9,1,0,263,0,1,273,1,1,0,17,2,9,17,261,0,0,261,20,260,257,260,1,0]

theorem envBound22355 : H12AffineFastState.Bounded env22355 := by
  intro p hp
  have h : env22355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22354_22355 : H12AffineEnvironment.transform 6 8 env22354 = env22355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22354 == env22355) = true)

def leafEnv22355 : List Nat := [2,4,8,16,0,16,8,256,0,272,1,0,9,1,0,263,0,1,273,1,1,0,17,2,21,9,1,17,261,0,0,261,20,260,257,260,5,263,1,0,0,1,1]

def active22355 : List Nat := [0,1,2,3,7]

def tree22355 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22355 : H12WitnessSearch.Good tree22355 := H12GlobalWitnessIndex.good

theorem leafIdentity22355 : H12AffineFastState.composeSystem env22355 rootObs = leafEnv22355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22355 rootObs == leafEnv22355) = true)

theorem terminalChecked22355 : H12PackedTerminal.terminalCheckFast leafEnv22355 active22355 tree22355 = true := by decide +kernel

def env22356 : List Nat := [2,4,8,16,0,16,9,256,1,272,0,0,9,1,0,263,0,0,273,1,1,1,17,2,8,17,261,0,0,261,20,260,257,260,1,1]

theorem envBound22356 : H12AffineFastState.Bounded env22356 := by
  intro p hp
  have h : env22356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22354_22356 : H12AffineEnvironment.transform 6 9 env22354 = env22356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22354 == env22356) = true)

theorem identity22356 : scanCanonicalize (H12AffineFastState.compose env22356 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22356 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22357 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,9,1,0,2,0,0,20,1,1,1,17,2,8,17,0,0,0,0,20,1,4,1,1,1]

theorem envBound22357 : H12AffineFastState.Bounded env22357 := by
  intro p hp
  have h : env22357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22356_22357 : H12AffineEnvironment.transform 7 5 env22356 = env22357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22356 == env22357) = true)

def leafEnv22357 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,9,1,0,2,0,0,20,1,1,1,17,2,21,8,1,17,0,0,0,0,20,1,4,1,5,2,1,1,0,1,1]

def active22357 : List Nat := [0,1,2,3]

def tree22357 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22357 : H12WitnessSearch.Good tree22357 := H12GlobalWitnessIndex.good

theorem leafIdentity22357 : H12AffineFastState.composeSystem env22357 rootObs = leafEnv22357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22357 rootObs == leafEnv22357) = true)

theorem terminalChecked22357 : H12PackedTerminal.terminalCheckFast leafEnv22357 active22357 tree22357 = true := by decide +kernel

def env22358 : List Nat := [2,4,8,16,1,16,128,256,136,272,137,0,8,1,0,262,0,137,273,1,1,137,17,3,128,17,260,0,0,260,20,261,257,260,1,136]

theorem envBound22358 : H12AffineFastState.Bounded env22358 := by
  intro p hp
  have h : env22358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22353_22358 : H12AffineEnvironment.transform 4 1 env22353 = env22358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22353 == env22358) = true)

theorem identity22358 : scanCanonicalize (H12AffineFastState.compose env22358 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22359 : List Nat := [2,4,8,16,1,16,9,256,1,272,0,0,8,1,0,262,0,0,273,1,1,0,17,3,9,17,260,0,0,260,20,261,257,260,1,1]

theorem envBound22359 : H12AffineFastState.Bounded env22359 := by
  intro p hp
  have h : env22359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22358_22359 : H12AffineEnvironment.transform 6 9 env22358 = env22359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22358 == env22359) = true)

def leafEnv22359 : List Nat := [2,4,8,16,1,16,9,256,1,272,0,0,8,1,0,262,0,0,273,1,1,0,17,3,21,9,1,17,260,0,0,260,20,261,257,260,5,263,1,1,0,1,1]

def active22359 : List Nat := [0,1,2,3,7]

def tree22359 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22359 : H12WitnessSearch.Good tree22359 := H12GlobalWitnessIndex.good

theorem leafIdentity22359 : H12AffineFastState.composeSystem env22359 rootObs = leafEnv22359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22359 rootObs == leafEnv22359) = true)

theorem terminalChecked22359 : H12PackedTerminal.terminalCheckFast leafEnv22359 active22359 tree22359 = true := by decide +kernel

def env22360 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,43049,273,32769,1,10249,17,98565,8328,17,33060,0,0,8461,20,73770,257,35212,1,136]

theorem envBound22360 : H12AffineFastState.Bounded env22360 := by
  intro p hp
  have h : env22360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22313_22360 : H12AffineEnvironment.transform 21 10249 env22313 = env22360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env22313 == env22360) = true)

theorem identity22360 : scanCanonicalize (H12AffineFastState.compose env22360 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound22360 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env22361 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,2341,65536,0,8460,273,2340,1,10249,17,67616,8328,17,2049,0,0,8461,20,73770,257,169,1,136]

theorem envBound22361 : H12AffineFastState.Bounded env22361 := by
  intro p hp
  have h : env22361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22360_22361 : H12AffineEnvironment.transform 14 2341 env22360 = env22361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env22360 == env22361) = true)

def env22362 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,2088,1,2341,65536,0,2340,273,2340,1,33,17,67616,2208,17,2049,0,0,2341,20,67586,257,169,1,136]

theorem envBound22362 : H12AffineFastState.Bounded env22362 := by
  intro p hp
  have h : env22362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22361_22362 : H12AffineEnvironment.transform 12 2088 env22361 = env22362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22361 == env22362) = true)

theorem identity22362 : scanCanonicalize (H12AffineFastState.compose env22362 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22362 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22363 : List Nat := [2,4,8,16,1,16,128,256,136,272,2048,0,2057,1,2308,65536,0,2309,273,2309,1,0,17,67585,2177,17,2049,0,0,2308,20,67586,257,136,1,136]

theorem envBound22363 : H12AffineFastState.Bounded env22363 := by
  intro p hp
  have h : env22363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22362_22363 : H12AffineEnvironment.transform 4 1 env22362 = env22363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22362 == env22363) = true)

def env22364 : List Nat := [2,4,8,16,1,16,128,256,136,272,260,0,269,1,0,65536,0,1,273,1,1,0,17,65797,389,17,261,0,0,0,20,65798,257,136,1,136]

theorem envBound22364 : H12AffineFastState.Bounded env22364 := by
  intro p hp
  have h : env22364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22363_22364 : H12AffineEnvironment.transform 10 260 env22363 = env22364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env22363 == env22364) = true)

theorem identity22364 : scanCanonicalize (H12AffineFastState.compose env22364 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound22364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22365 : List Nat := [2,4,8,16,1,16,128,256,136,272,260,0,269,1,0,399,0,1,273,1,1,0,17,138,389,17,261,0,0,0,20,137,257,136,1,136]

theorem envBound22365 : H12AffineFastState.Bounded env22365 := by
  intro p hp
  have h : env22365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22364_22365 : H12AffineEnvironment.transform 15 399 env22364 = env22365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env22364 == env22365) = true)

def leafEnv22365 : List Nat := [2,4,8,16,1,16,128,256,136,272,260,0,269,1,0,399,0,1,273,1,1,0,17,138,21,389,1,17,261,0,0,0,20,137,257,136,5,263,1,136,0,1,1]

def active22365 : List Nat := [0,1,2,3,6,7]

def tree22365 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22365 : H12WitnessSearch.Good tree22365 := H12GlobalWitnessIndex.good

theorem leafIdentity22365 : H12AffineFastState.composeSystem env22365 rootObs = leafEnv22365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22365 rootObs == leafEnv22365) = true)

theorem terminalChecked22365 : H12PackedTerminal.terminalCheckFast leafEnv22365 active22365 tree22365 = true := by decide +kernel

def env22366 : List Nat := [2,4,8,16,1,16,128,256,136,272,261,0,268,1,1,65536,0,0,273,0,1,0,17,65796,388,17,260,0,0,1,20,65799,257,136,1,136]

theorem envBound22366 : H12AffineFastState.Bounded env22366 := by
  intro p hp
  have h : env22366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22363_22366 : H12AffineEnvironment.transform 10 261 env22363 = env22366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env22363 == env22366) = true)

def env22367 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,2089,1,2341,65536,0,2341,273,2340,1,32,17,67616,2209,17,2049,0,0,2340,20,67587,257,169,1,136]

theorem envBound22367 : H12AffineFastState.Bounded env22367 := by
  intro p hp
  have h : env22367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22361_22367 : H12AffineEnvironment.transform 12 2089 env22361 = env22367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env22361 == env22367) = true)

theorem identity22367 : scanCanonicalize (H12AffineFastState.compose env22367 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound22367 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22368 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,2089,1,2341,2343,0,2341,273,2340,1,32,17,263,2209,17,2049,0,0,2340,20,292,257,169,1,136]

theorem envBound22368 : H12AffineFastState.Bounded env22368 := by
  intro p hp
  have h : env22368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22367_22368 : H12AffineEnvironment.transform 15 2343 env22367 = env22368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env22367 == env22368) = true)

def env22369 : List Nat := [2,4,8,16,32,16,128,256,136,272,168,0,129,1,397,399,0,397,273,396,1,32,17,263,9,17,169,0,0,396,20,292,257,169,1,136]

theorem envBound22369 : H12AffineFastState.Bounded env22369 := by
  intro p hp
  have h : env22369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22368_22369 : H12AffineEnvironment.transform 10 168 env22368 = env22369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env22368 == env22369) = true)

def env22370 : List Nat := [2,4,8,16,32,16,8,256,0,272,32,0,9,1,261,263,0,261,273,260,1,32,17,263,9,17,33,0,0,260,20,292,257,33,1,0]

theorem envBound22370 : H12AffineFastState.Bounded env22370 := by
  intro p hp
  have h : env22370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22369_22370 : H12AffineEnvironment.transform 6 8 env22369 = env22370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22369 == env22370) = true)

theorem identity22370 : scanCanonicalize (H12AffineFastState.compose env22370 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22371 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,0,9,1,261,263,0,261,273,260,1,0,17,263,9,17,1,0,0,260,20,260,257,1,1,0]

theorem envBound22371 : H12AffineFastState.Bounded env22371 := by
  intro p hp
  have h : env22371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22370_22371 : H12AffineEnvironment.transform 4 0 env22370 = env22371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22370 == env22371) = true)

def leafEnv22371 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,0,9,1,261,263,0,261,273,260,1,0,17,263,21,9,1,17,1,0,0,260,20,260,257,1,5,2,1,0,0,1,1]

def active22371 : List Nat := [0,1,2,3,7]

def tree22371 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22371 : H12WitnessSearch.Good tree22371 := H12GlobalWitnessIndex.good

theorem leafIdentity22371 : H12AffineFastState.composeSystem env22371 rootObs = leafEnv22371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22371 rootObs == leafEnv22371) = true)

theorem terminalChecked22371 : H12PackedTerminal.terminalCheckFast leafEnv22371 active22371 tree22371 = true := by decide +kernel

def env22372 : List Nat := [2,4,8,16,32,16,9,256,1,272,33,0,8,1,260,262,0,260,273,261,1,32,17,263,9,17,32,0,0,261,20,292,257,32,1,1]

theorem envBound22372 : H12AffineFastState.Bounded env22372 := by
  intro p hp
  have h : env22372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22369_22372 : H12AffineEnvironment.transform 6 9 env22369 = env22372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22369 == env22372) = true)

theorem identity22372 : scanCanonicalize (H12AffineFastState.compose env22372 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22372 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22373 : List Nat := [2,4,8,16,32,16,9,36,1,52,33,0,8,1,32,34,0,32,53,33,1,32,17,35,9,17,32,0,0,33,20,0,37,32,1,1]

theorem envBound22373 : H12AffineFastState.Bounded env22373 := by
  intro p hp
  have h : env22373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22372_22373 : H12AffineEnvironment.transform 7 36 env22372 = env22373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22372 == env22373) = true)

def leafEnv22373 : List Nat := [2,4,8,16,32,16,9,36,1,52,33,0,8,1,32,34,0,32,53,33,1,32,17,35,21,9,1,17,32,0,0,33,20,0,37,32,5,3,1,1,0,1,1]

def active22373 : List Nat := [0,1,2,3,4]

def tree22373 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22373 : H12WitnessSearch.Good tree22373 := H12GlobalWitnessIndex.good

theorem leafIdentity22373 : H12AffineFastState.composeSystem env22373 rootObs = leafEnv22373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22373 rootObs == leafEnv22373) = true)

theorem terminalChecked22373 : H12PackedTerminal.terminalCheckFast leafEnv22373 active22373 tree22373 = true := by decide +kernel

def env22374 : List Nat := [2,4,8,16,32,16,128,256,136,272,169,0,128,1,396,398,0,396,273,397,1,32,17,263,8,17,168,0,0,397,20,292,257,169,1,136]

theorem envBound22374 : H12AffineFastState.Bounded env22374 := by
  intro p hp
  have h : env22374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22368_22374 : H12AffineEnvironment.transform 10 169 env22368 = env22374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env22368 == env22374) = true)

theorem identity22374 : scanCanonicalize (H12AffineFastState.compose env22374 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22375 : List Nat := [2,4,8,16,32,16,128,140,136,156,169,0,128,1,0,2,0,0,157,1,1,32,17,139,8,17,168,0,0,1,20,168,141,169,1,136]

theorem envBound22375 : H12AffineFastState.Bounded env22375 := by
  intro p hp
  have h : env22375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22374_22375 : H12AffineEnvironment.transform 7 140 env22374 = env22375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22374 == env22375) = true)

theorem identity22375 : scanCanonicalize (H12AffineFastState.compose env22375 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound22375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22376 : List Nat := [2,4,8,16,32,16,40,36,32,52,1,0,40,1,0,2,0,0,53,1,1,32,17,35,8,17,0,0,0,1,20,0,37,1,1,32]

theorem envBound22376 : H12AffineFastState.Bounded env22376 := by
  intro p hp
  have h : env22376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22375_22376 : H12AffineEnvironment.transform 6 40 env22375 = env22376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env22375 == env22376) = true)

def leafEnv22376 : List Nat := [2,4,8,16,32,16,40,36,32,52,1,0,40,1,0,2,0,0,53,1,1,32,17,35,21,8,1,17,0,0,0,1,20,0,37,1,5,35,1,32,0,1,1]

def active22376 : List Nat := [0,1,2,3,4]

def tree22376 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22376 : H12WitnessSearch.Good tree22376 := H12GlobalWitnessIndex.good

theorem leafIdentity22376 : H12AffineFastState.composeSystem env22376 rootObs = leafEnv22376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22376 rootObs == leafEnv22376) = true)

theorem terminalChecked22376 : H12PackedTerminal.terminalCheckFast leafEnv22376 active22376 tree22376 = true := by decide +kernel

def env22377 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,65536,1,262144,272,32769,0,4194304,17,98565,8328,17,4456708,1,1,1073741824,21,4294967296,257,4299260335,0,136]

theorem envBound22377 : H12AffineFastState.Bounded env22377 := by
  intro p hp
  have h : env22377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22309_22377 : H12AffineEnvironment.transform 9 273 env22309 = env22377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22309 == env22377) = true)

theorem identity22377 : scanCanonicalize (H12AffineFastState.compose env22377 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 1077979296) := by decide +kernel

theorem selectedBound22377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22378 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,32768,65536,1,262144,272,32769,0,4194304,17,98565,8328,17,4456708,1,1,1073741824,21,1077979296,257,1073817871,0,136]

theorem envBound22378 : H12AffineFastState.Bounded env22378 := by
  intro p hp
  have h : env22378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22377_22378 : H12AffineEnvironment.transform 31 1077979296 env22377 = env22378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979296 env22377 == env22378) = true)

def env22379 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,260,65536,1,262144,272,261,0,4194304,17,65537,8328,17,4456708,1,1,1073741824,21,1077946788,257,1073817871,0,136]

theorem envBound22379 : H12AffineFastState.Bounded env22379 := by
  intro p hp
  have h : env22379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22378_22379 : H12AffineEnvironment.transform 14 260 env22378 = env22379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env22378 == env22379) = true)

def env22380 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,260,65536,1,262144,272,261,0,4194304,17,65537,128,17,4456708,1,1,1073741824,21,1077938604,257,1073809671,0,136]

theorem envBound22380 : H12AffineFastState.Bounded env22380 := by
  intro p hp
  have h : env22380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22379_22380 : H12AffineEnvironment.transform 12 8 env22379 = env22380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22379 == env22380) = true)

theorem identity22380 : scanCanonicalize (H12AffineFastState.compose env22380 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound22380 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22381 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,260,65536,1,262144,272,261,0,136,17,65537,128,17,262540,1,1,1073741824,21,1073744164,257,1073809671,0,136]

theorem envBound22381 : H12AffineFastState.Bounded env22381 := by
  intro p hp
  have h : env22381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22380_22381 : H12AffineEnvironment.transform 21 136 env22380 = env22381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env22380 == env22381) = true)

def env22382 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,1073741824,21,1073743904,5,1073809411,0,136]

theorem envBound22382 : H12AffineFastState.Bounded env22382 := by
  intro p hp
  have h : env22382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22381_22382 : H12AffineEnvironment.transform 7 4 env22381 = env22382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22381 == env22382) = true)

def env22383 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,0,21,2080,5,67587,0,136]

theorem envBound22383 : H12AffineFastState.Bounded env22383 := by
  intro p hp
  have h : env22383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22382_22383 : H12AffineEnvironment.transform 29 0 env22382 = env22383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env22382 == env22383) = true)

theorem identity22383 : scanCanonicalize (H12AffineFastState.compose env22383 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22384 : List Nat := [2,4,8,16,32,16,128,4,136,21,33,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,0,21,1,5,65570,0,136]

theorem envBound22384 : H12AffineFastState.Bounded env22384 := by
  intro p hp
  have h : env22384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22383_22384 : H12AffineEnvironment.transform 10 33 env22383 = env22384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22383 == env22384) = true)

theorem identity22384 : scanCanonicalize (H12AffineFastState.compose env22384 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound22384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22385 : List Nat := [2,4,8,16,32,16,128,4,136,21,33,1,8,0,0,170,1,262144,20,1,0,136,17,171,128,17,262280,1,1,0,21,1,5,136,0,136]

theorem envBound22385 : H12AffineFastState.Bounded env22385 := by
  intro p hp
  have h : env22385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22384_22385 : H12AffineEnvironment.transform 15 170 env22384 = env22385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env22384 == env22385) = true)

theorem identity22385 : scanCanonicalize (H12AffineFastState.compose env22385 (packedSelected [7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22385 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env22386 : List Nat := [2,4,8,16,1,16,128,4,136,21,0,1,8,0,0,139,1,262144,20,1,0,136,17,138,128,17,262280,1,1,0,21,1,5,136,0,136]

theorem envBound22386 : H12AffineFastState.Bounded env22386 := by
  intro p hp
  have h : env22386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22385_22386 : H12AffineEnvironment.transform 4 1 env22385 = env22386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22385 == env22386) = true)

theorem identity22386 : scanCanonicalize (H12AffineFastState.compose env22386 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 136) := by decide +kernel

theorem selectedBound22386 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22387 : List Nat := [2,4,8,16,1,16,128,4,136,21,0,1,8,0,0,139,1,136,20,1,0,136,17,138,128,17,0,1,1,0,21,1,5,136,0,136]

theorem envBound22387 : H12AffineFastState.Bounded env22387 := by
  intro p hp
  have h : env22387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22386_22387 : H12AffineEnvironment.transform 17 136 env22386 = env22387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 136 env22386 == env22387) = true)

theorem identity22387 : scanCanonicalize (H12AffineFastState.compose env22387 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22387 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22388 : List Nat := [2,4,8,16,1,16,8,4,0,21,0,1,8,0,0,3,1,0,20,1,0,0,17,2,8,17,0,1,1,0,21,1,5,0,0,0]

theorem envBound22388 : H12AffineFastState.Bounded env22388 := by
  intro p hp
  have h : env22388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22387_22388 : H12AffineEnvironment.transform 6 8 env22387 = env22388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22387 == env22388) = true)

def leafEnv22388 : List Nat := [2,4,8,16,1,16,8,4,0,21,0,1,8,0,0,3,1,0,20,1,0,0,17,2,20,8,1,17,0,1,1,0,21,1,5,0,5,3,0,0,0,0,1]

def active22388 : List Nat := [0,1,2,3]

def tree22388 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22388 : H12WitnessSearch.Good tree22388 := H12GlobalWitnessIndex.good

theorem leafIdentity22388 : H12AffineFastState.composeSystem env22388 rootObs = leafEnv22388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22388 rootObs == leafEnv22388) = true)

theorem terminalChecked22388 : H12PackedTerminal.terminalCheckFast leafEnv22388 active22388 tree22388 = true := by decide +kernel

def env22389 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,1,21,2081,5,67586,0,136]

theorem envBound22389 : H12AffineFastState.Bounded env22389 := by
  intro p hp
  have h : env22389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22382_22389 : H12AffineEnvironment.transform 29 1 env22382 = env22389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env22382 == env22389) = true)

theorem identity22389 : scanCanonicalize (H12AffineFastState.compose env22389 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22390 : List Nat := [2,4,8,16,0,16,128,4,136,21,2048,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,1,21,2049,5,67586,0,136]

theorem envBound22390 : H12AffineFastState.Bounded env22390 := by
  intro p hp
  have h : env22390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22389_22390 : H12AffineEnvironment.transform 4 0 env22389 = env22390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22389 == env22390) = true)

theorem identity22390 : scanCanonicalize (H12AffineFastState.compose env22390 (packedSelected [7,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22390 : packedSelected [7,18] rootPS < 2^1333 := by decide +kernel

def env22391 : List Nat := [2,4,8,16,0,16,128,4,136,21,1,1,8,0,0,65536,1,262144,20,1,0,136,17,65537,128,17,262280,1,1,1,21,0,5,65539,0,136]

theorem envBound22391 : H12AffineFastState.Bounded env22391 := by
  intro p hp
  have h : env22391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22390_22391 : H12AffineEnvironment.transform 10 1 env22390 = env22391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22390 == env22391) = true)

def env22392 : List Nat := [2,4,8,16,0,16,128,4,136,21,1,1,8,0,0,65536,1,0,20,1,0,136,17,65537,128,17,136,1,1,1,21,0,5,65539,0,136]

theorem envBound22392 : H12AffineFastState.Bounded env22392 := by
  intro p hp
  have h : env22392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22391_22392 : H12AffineEnvironment.transform 17 0 env22391 = env22392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env22391 == env22392) = true)

theorem identity22392 : scanCanonicalize (H12AffineFastState.compose env22392 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22392 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22393 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,0,0,65536,1,0,20,1,0,0,17,65537,8,17,0,1,1,1,21,0,5,65539,0,0]

theorem envBound22393 : H12AffineFastState.Bounded env22393 := by
  intro p hp
  have h : env22393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22392_22393 : H12AffineEnvironment.transform 6 8 env22392 = env22393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22392 == env22393) = true)

def leafEnv22393 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,0,0,65536,1,0,20,1,0,0,17,65537,20,8,1,17,0,1,1,1,21,0,5,65539,5,3,0,0,0,0,1]

def active22393 : List Nat := [0,1,2,3,15]

def tree22393 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22393 : H12WitnessSearch.Good tree22393 := H12GlobalWitnessIndex.good

theorem leafIdentity22393 : H12AffineFastState.composeSystem env22393 rootObs = leafEnv22393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22393 rootObs == leafEnv22393) = true)

theorem terminalChecked22393 : H12PackedTerminal.terminalCheckFast leafEnv22393 active22393 tree22393 = true := by decide +kernel

def env22394 : List Nat := [2,4,8,16,0,16,128,4,136,21,1,1,8,0,0,65536,1,1,20,1,0,136,17,65537,128,17,137,1,1,1,21,0,5,65539,0,136]

theorem envBound22394 : H12AffineFastState.Bounded env22394 := by
  intro p hp
  have h : env22394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22391_22394 : H12AffineEnvironment.transform 17 1 env22391 = env22394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22391 == env22394) = true)

def env22395 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,65536,1,262144,21,0,0,136,17,65537,128,17,262281,1,1,1073741824,21,1073743905,4,1073809410,0,136]

theorem envBound22395 : H12AffineFastState.Bounded env22395 := by
  intro p hp
  have h : env22395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22381_22395 : H12AffineEnvironment.transform 7 5 env22381 = env22395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22381 == env22395) = true)

def env22396 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,65536,1,262144,21,0,0,136,17,65537,128,17,262281,1,1,0,21,2081,4,67586,0,136]

theorem envBound22396 : H12AffineFastState.Bounded env22396 := by
  intro p hp
  have h : env22396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22395_22396 : H12AffineEnvironment.transform 29 0 env22395 = env22396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env22395 == env22396) = true)

theorem identity22396 : scanCanonicalize (H12AffineFastState.compose env22396 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound22396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22397 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,171,1,262144,21,0,0,136,17,170,128,17,262281,1,1,0,21,2081,4,2217,0,136]

theorem envBound22397 : H12AffineFastState.Bounded env22397 := by
  intro p hp
  have h : env22397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22396_22397 : H12AffineEnvironment.transform 15 171 env22396 = env22397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env22396 == env22397) = true)

theorem identity22397 : scanCanonicalize (H12AffineFastState.compose env22397 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22398 : List Nat := [2,4,8,16,32,16,128,5,136,20,0,1,8,0,1,171,1,262144,21,0,0,136,17,170,128,17,262281,1,1,0,21,33,4,169,0,136]

theorem envBound22398 : H12AffineFastState.Bounded env22398 := by
  intro p hp
  have h : env22398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22397_22398 : H12AffineEnvironment.transform 10 0 env22397 = env22398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22397 == env22398) = true)

theorem identity22398 : scanCanonicalize (H12AffineFastState.compose env22398 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22398 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22399 : List Nat := [2,4,8,16,32,16,9,5,1,20,0,1,8,0,1,34,1,262144,21,0,0,1,17,35,9,17,262144,1,1,0,21,33,4,32,0,1]

theorem envBound22399 : H12AffineFastState.Bounded env22399 := by
  intro p hp
  have h : env22399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22398_22399 : H12AffineEnvironment.transform 6 9 env22398 = env22399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22398 == env22399) = true)

theorem identity22399 : scanCanonicalize (H12AffineFastState.compose env22399 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound22399 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22400 : List Nat := [2,4,8,16,32,16,9,5,1,20,0,1,8,0,1,34,1,1,21,0,0,1,17,35,9,17,1,1,1,0,21,33,4,32,0,1]

theorem envBound22400 : H12AffineFastState.Bounded env22400 := by
  intro p hp
  have h : env22400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22399_22400 : H12AffineEnvironment.transform 17 1 env22399 = env22400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22399 == env22400) = true)

theorem identity22400 : scanCanonicalize (H12AffineFastState.compose env22400 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22400 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22401 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,8,0,1,3,1,1,21,0,0,1,17,2,9,17,1,1,1,0,21,0,4,1,0,1]

theorem envBound22401 : H12AffineFastState.Bounded env22401 := by
  intro p hp
  have h : env22401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22400_22401 : H12AffineEnvironment.transform 4 1 env22400 = env22401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22400 == env22401) = true)

def leafEnv22401 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,8,0,1,3,1,1,21,0,0,1,17,2,20,9,1,17,1,1,1,0,21,0,4,1,5,3,0,1,0,0,1]

def active22401 : List Nat := [0,1,2,3]

def tree22401 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22401 : H12WitnessSearch.Good tree22401 := H12GlobalWitnessIndex.good

theorem leafIdentity22401 : H12AffineFastState.composeSystem env22401 rootObs = leafEnv22401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22401 rootObs == leafEnv22401) = true)

theorem terminalChecked22401 : H12PackedTerminal.terminalCheckFast leafEnv22401 active22401 tree22401 = true := by decide +kernel

def env22402 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,65536,1,262144,21,0,0,136,17,65537,128,17,262281,1,1,1,21,2080,4,67587,0,136]

theorem envBound22402 : H12AffineFastState.Bounded env22402 := by
  intro p hp
  have h : env22402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22395_22402 : H12AffineEnvironment.transform 29 1 env22395 = env22402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env22395 == env22402) = true)

theorem identity22402 : scanCanonicalize (H12AffineFastState.compose env22402 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound22402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22403 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,2219,1,262144,21,0,0,136,17,2218,128,17,262281,1,1,1,21,2080,4,168,0,136]

theorem envBound22403 : H12AffineFastState.Bounded env22403 := by
  intro p hp
  have h : env22403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22402_22403 : H12AffineEnvironment.transform 15 2219 env22402 = env22403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env22402 == env22403) = true)

theorem identity22403 : scanCanonicalize (H12AffineFastState.compose env22403 (packedSelected [2,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound22403 : packedSelected [2,7,11] rootPS < 2^1333 := by decide +kernel

def env22404 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,8,0,1,2219,1,2185,21,0,0,136,17,2218,128,17,2048,1,1,1,21,2080,4,168,0,136]

theorem envBound22404 : H12AffineFastState.Bounded env22404 := by
  intro p hp
  have h : env22404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22403_22404 : H12AffineEnvironment.transform 17 2185 env22403 = env22404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env22403 == env22404) = true)

theorem identity22404 : scanCanonicalize (H12AffineFastState.compose env22404 (packedSelected [4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22404 : packedSelected [4,7,9] rootPS < 2^1333 := by decide +kernel

def env22405 : List Nat := [2,4,8,16,32,16,128,5,136,20,33,1,8,0,1,138,1,168,21,0,0,136,17,139,128,17,33,1,1,1,21,1,4,168,0,136]

theorem envBound22405 : H12AffineFastState.Bounded env22405 := by
  intro p hp
  have h : env22405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22404_22405 : H12AffineEnvironment.transform 10 33 env22404 = env22405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22404 == env22405) = true)

theorem identity22405 : scanCanonicalize (H12AffineFastState.compose env22405 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22405 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22406 : List Nat := [2,4,8,16,0,16,128,5,136,20,1,1,8,0,1,138,1,136,21,0,0,136,17,139,128,17,1,1,1,1,21,1,4,136,0,136]

theorem envBound22406 : H12AffineFastState.Bounded env22406 := by
  intro p hp
  have h : env22406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22405_22406 : H12AffineEnvironment.transform 4 0 env22405 = env22406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22405 == env22406) = true)

theorem identity22406 : scanCanonicalize (H12AffineFastState.compose env22406 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22406 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22407 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,8,0,1,3,1,1,21,0,0,1,17,2,9,17,1,1,1,1,21,1,4,1,0,1]

theorem envBound22407 : H12AffineFastState.Bounded env22407 := by
  intro p hp
  have h : env22407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22406_22407 : H12AffineEnvironment.transform 6 9 env22406 = env22407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22406 == env22407) = true)

def leafEnv22407 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,8,0,1,3,1,1,21,0,0,1,17,2,20,9,1,17,1,1,1,1,21,1,4,1,5,3,0,1,0,0,1]

def active22407 : List Nat := [0,1,2,3]

def tree22407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22407 : H12WitnessSearch.Good tree22407 := H12GlobalWitnessIndex.good

theorem leafIdentity22407 : H12AffineFastState.composeSystem env22407 rootObs = leafEnv22407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22407 rootObs == leafEnv22407) = true)

theorem terminalChecked22407 : H12PackedTerminal.terminalCheckFast leafEnv22407 active22407 tree22407 = true := by decide +kernel

def env22408 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,9,0,260,65536,1,262144,272,261,0,4194304,17,65537,129,17,4456708,1,1,1073741824,21,1077938605,257,1073809670,0,136]

theorem envBound22408 : H12AffineFastState.Bounded env22408 := by
  intro p hp
  have h : env22408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22379_22408 : H12AffineEnvironment.transform 12 9 env22379 = env22408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22379 == env22408) = true)

theorem identity22408 : scanCanonicalize (H12AffineFastState.compose env22408 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22408 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22409 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,9,0,1,65536,1,262144,21,0,0,4194304,17,65537,129,17,4456449,1,1,1073741824,21,1077938344,4,1073809411,0,136]

theorem envBound22409 : H12AffineFastState.Bounded env22409 := by
  intro p hp
  have h : env22409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22408_22409 : H12AffineEnvironment.transform 7 5 env22408 = env22409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22408 == env22409) = true)

def env22410 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,9,0,1,65536,1,262144,21,0,0,4194304,17,65537,129,17,4456449,1,1,0,21,4196520,4,67587,0,136]

theorem envBound22410 : H12AffineFastState.Bounded env22410 := by
  intro p hp
  have h : env22410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22409_22410 : H12AffineEnvironment.transform 29 0 env22409 = env22410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env22409 == env22410) = true)

theorem identity22410 : scanCanonicalize (H12AffineFastState.compose env22410 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 65706) := by decide +kernel

theorem selectedBound22410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22411 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,9,0,1,65536,1,262144,21,0,0,65706,17,65537,129,17,327851,1,1,0,21,67586,4,67587,0,136]

theorem envBound22411 : H12AffineFastState.Bounded env22411 := by
  intro p hp
  have h : env22411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22410_22411 : H12AffineEnvironment.transform 21 65706 env22410 = env22411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65706 env22410 == env22411) = true)

def env22412 : List Nat := [2,4,8,16,32,16,128,5,136,20,32,1,9,0,1,65536,1,262144,21,0,0,65706,17,65537,129,17,327851,1,1,0,21,65570,4,65571,0,136]

theorem envBound22412 : H12AffineFastState.Bounded env22412 := by
  intro p hp
  have h : env22412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22411_22412 : H12AffineEnvironment.transform 10 32 env22411 = env22412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env22411 == env22412) = true)

def env22413 : List Nat := [2,4,8,16,0,16,128,5,136,20,0,1,9,0,1,65536,1,262144,21,0,0,65674,17,65537,129,17,327819,1,1,0,21,65538,4,65539,0,136]

theorem envBound22413 : H12AffineFastState.Bounded env22413 := by
  intro p hp
  have h : env22413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22412_22413 : H12AffineEnvironment.transform 4 0 env22412 = env22413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22412 == env22413) = true)

theorem identity22413 : scanCanonicalize (H12AffineFastState.compose env22413 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound22413 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22414 : List Nat := [2,4,8,16,0,16,128,5,136,20,0,1,9,0,1,65536,1,1,21,0,0,65674,17,65537,129,17,65674,1,1,0,21,65538,4,65539,0,136]

theorem envBound22414 : H12AffineFastState.Bounded env22414 := by
  intro p hp
  have h : env22414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22413_22414 : H12AffineEnvironment.transform 17 1 env22413 = env22414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22413 == env22414) = true)

theorem identity22414 : scanCanonicalize (H12AffineFastState.compose env22414 (packedSelected [9] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound22414 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env22415 : List Nat := [2,4,8,16,0,16,128,5,136,20,0,1,9,0,1,139,1,1,21,0,0,1,17,138,129,17,1,1,1,0,21,137,4,136,0,136]

theorem envBound22415 : H12AffineFastState.Bounded env22415 := by
  intro p hp
  have h : env22415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22414_22415 : H12AffineEnvironment.transform 15 139 env22414 = env22415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env22414 == env22415) = true)

def leafEnv22415 : List Nat := [2,4,8,16,0,16,128,5,136,20,0,1,9,0,1,139,1,1,21,0,0,1,17,138,20,129,1,17,1,1,1,0,21,137,4,136,5,3,0,136,0,0,1]

def active22415 : List Nat := [0,1,2,3,6]

def tree22415 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22415 : H12WitnessSearch.Good tree22415 := H12GlobalWitnessIndex.good

theorem leafIdentity22415 : H12AffineFastState.composeSystem env22415 rootObs = leafEnv22415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22415 rootObs == leafEnv22415) = true)

theorem terminalChecked22415 : H12PackedTerminal.terminalCheckFast leafEnv22415 active22415 tree22415 = true := by decide +kernel

def env22416 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,1,9,0,1,65536,1,262144,21,0,0,65675,17,65537,129,17,327818,1,1,0,21,65539,4,65538,0,136]

theorem envBound22416 : H12AffineFastState.Bounded env22416 := by
  intro p hp
  have h : env22416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22412_22416 : H12AffineEnvironment.transform 4 1 env22412 = env22416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22412 == env22416) = true)

theorem identity22416 : scanCanonicalize (H12AffineFastState.compose env22416 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound22416 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22417 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,1,9,0,1,139,1,262144,21,0,0,0,17,138,129,17,262145,1,1,0,21,136,4,137,0,136]

theorem envBound22417 : H12AffineFastState.Bounded env22417 := by
  intro p hp
  have h : env22417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22416_22417 : H12AffineEnvironment.transform 15 139 env22416 = env22417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env22416 == env22417) = true)

theorem identity22417 : scanCanonicalize (H12AffineFastState.compose env22417 (packedSelected [9] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound22417 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env22418 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,1,9,0,1,139,1,1,21,0,0,0,17,138,129,17,0,1,1,0,21,136,4,137,0,136]

theorem envBound22418 : H12AffineFastState.Bounded env22418 := by
  intro p hp
  have h : env22418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22417_22418 : H12AffineEnvironment.transform 17 1 env22417 = env22418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22417 == env22418) = true)

def leafEnv22418 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,1,9,0,1,139,1,1,21,0,0,0,17,138,20,129,1,17,0,1,1,0,21,136,4,137,5,3,0,136,0,0,1]

def active22418 : List Nat := [0,1,2,3,6]

def tree22418 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22418 : H12WitnessSearch.Good tree22418 := H12GlobalWitnessIndex.good

theorem leafIdentity22418 : H12AffineFastState.composeSystem env22418 rootObs = leafEnv22418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22418 rootObs == leafEnv22418) = true)

theorem terminalChecked22418 : H12PackedTerminal.terminalCheckFast leafEnv22418 active22418 tree22418 = true := by decide +kernel

def env22419 : List Nat := [2,4,8,16,32,16,128,5,136,20,33,1,9,0,1,65536,1,262144,21,0,0,65706,17,65537,129,17,327851,1,1,0,21,65571,4,65570,0,136]

theorem envBound22419 : H12AffineFastState.Bounded env22419 := by
  intro p hp
  have h : env22419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22411_22419 : H12AffineEnvironment.transform 10 33 env22411 = env22419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22411 == env22419) = true)

theorem identity22419 : scanCanonicalize (H12AffineFastState.compose env22419 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22420 : List Nat := [2,4,8,16,32,16,9,5,1,20,33,1,9,0,1,65536,1,262144,21,0,0,65571,17,65537,8,17,327714,1,1,0,21,65571,4,65570,0,1]

theorem envBound22420 : H12AffineFastState.Bounded env22420 := by
  intro p hp
  have h : env22420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22419_22420 : H12AffineEnvironment.transform 6 9 env22419 = env22420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22419 == env22420) = true)

theorem identity22420 : scanCanonicalize (H12AffineFastState.compose env22420 (packedSelected [7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22420 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env22421 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,0,1,65536,1,262144,21,0,0,65538,17,65537,8,17,327683,1,1,0,21,65538,4,65539,0,1]

theorem envBound22421 : H12AffineFastState.Bounded env22421 := by
  intro p hp
  have h : env22421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22420_22421 : H12AffineEnvironment.transform 4 1 env22420 = env22421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22420 == env22421) = true)

theorem identity22421 : scanCanonicalize (H12AffineFastState.compose env22421 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 65539) := by decide +kernel

theorem selectedBound22421 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22422 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,0,1,65536,1,65539,21,0,0,65538,17,65537,8,17,0,1,1,0,21,65538,4,65539,0,1]

theorem envBound22422 : H12AffineFastState.Bounded env22422 := by
  intro p hp
  have h : env22422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22421_22422 : H12AffineEnvironment.transform 17 65539 env22421 = env22422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65539 env22421 == env22422) = true)

theorem identity22422 : scanCanonicalize (H12AffineFastState.compose env22422 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound22422 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22423 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,0,1,3,1,0,21,0,0,1,17,2,8,17,0,1,1,0,21,1,4,0,0,1]

theorem envBound22423 : H12AffineFastState.Bounded env22423 := by
  intro p hp
  have h : env22423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22422_22423 : H12AffineEnvironment.transform 15 3 env22422 = env22423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env22422 == env22423) = true)

def leafEnv22423 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,0,1,3,1,0,21,0,0,1,17,2,20,8,1,17,0,1,1,0,21,1,4,0,5,3,0,1,0,0,1]

def active22423 : List Nat := [0,1,2,3]

def tree22423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22423 : H12WitnessSearch.Good tree22423 := H12GlobalWitnessIndex.good

theorem leafIdentity22423 : H12AffineFastState.composeSystem env22423 rootObs = leafEnv22423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22423 rootObs == leafEnv22423) = true)

theorem terminalChecked22423 : H12PackedTerminal.terminalCheckFast leafEnv22423 active22423 tree22423 = true := by decide +kernel

def env22424 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,9,0,1,65536,1,262144,21,0,0,4194304,17,65537,129,17,4456449,1,1,1,21,4196521,4,67586,0,136]

theorem envBound22424 : H12AffineFastState.Bounded env22424 := by
  intro p hp
  have h : env22424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22409_22424 : H12AffineEnvironment.transform 29 1 env22409 = env22424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env22409 == env22424) = true)

theorem identity22424 : scanCanonicalize (H12AffineFastState.compose env22424 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound22424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22425 : List Nat := [2,4,8,16,32,16,128,5,136,20,2048,1,9,0,1,65536,1,262144,21,0,0,67754,17,65537,129,17,329899,1,1,1,21,65539,4,67586,0,136]

theorem envBound22425 : H12AffineFastState.Bounded env22425 := by
  intro p hp
  have h : env22425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22424_22425 : H12AffineEnvironment.transform 21 67754 env22424 = env22425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env22424 == env22425) = true)

theorem identity22425 : scanCanonicalize (H12AffineFastState.compose env22425 (packedSelected [7,18] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22425 : packedSelected [7,18] rootPS < 2^1333 := by decide +kernel

def env22426 : List Nat := [2,4,8,16,32,16,128,5,136,20,33,1,9,0,1,65536,1,262144,21,0,0,65675,17,65537,129,17,327818,1,1,1,21,65539,4,65571,0,136]

theorem envBound22426 : H12AffineFastState.Bounded env22426 := by
  intro p hp
  have h : env22426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22425_22426 : H12AffineEnvironment.transform 10 33 env22425 = env22426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22425 == env22426) = true)

theorem identity22426 : scanCanonicalize (H12AffineFastState.compose env22426 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22427 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,1,9,0,1,65536,1,262144,21,0,0,65675,17,65537,129,17,327818,1,1,1,21,65539,4,65538,0,136]

theorem envBound22427 : H12AffineFastState.Bounded env22427 := by
  intro p hp
  have h : env22427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22426_22427 : H12AffineEnvironment.transform 4 1 env22426 = env22427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22426 == env22427) = true)

theorem identity22427 : scanCanonicalize (H12AffineFastState.compose env22427 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 65675) := by decide +kernel

theorem selectedBound22427 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22428 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,1,9,0,1,65536,1,65675,21,0,0,65675,17,65537,129,17,1,1,1,1,21,65539,4,65538,0,136]

theorem envBound22428 : H12AffineFastState.Bounded env22428 := by
  intro p hp
  have h : env22428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22427_22428 : H12AffineEnvironment.transform 17 65675 env22427 = env22428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65675 env22427 == env22428) = true)

theorem identity22428 : scanCanonicalize (H12AffineFastState.compose env22428 (packedSelected [9] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound22428 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env22429 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,1,9,0,1,139,1,0,21,0,0,0,17,138,129,17,1,1,1,1,21,136,4,137,0,136]

theorem envBound22429 : H12AffineFastState.Bounded env22429 := by
  intro p hp
  have h : env22429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22428_22429 : H12AffineEnvironment.transform 15 139 env22428 = env22429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env22428 == env22429) = true)

def leafEnv22429 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,1,9,0,1,139,1,0,21,0,0,0,17,138,20,129,1,17,1,1,1,1,21,136,4,137,5,3,0,136,0,0,1]

def active22429 : List Nat := [0,1,2,3,6]

def tree22429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22429 : H12WitnessSearch.Good tree22429 := H12GlobalWitnessIndex.good

theorem leafIdentity22429 : H12AffineFastState.composeSystem env22429 rootObs = leafEnv22429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22429 rootObs == leafEnv22429) = true)

theorem terminalChecked22429 : H12PackedTerminal.terminalCheckFast leafEnv22429 active22429 tree22429 = true := by decide +kernel

def env22430 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8192,0,261,65536,1,262144,272,260,0,4194304,17,65536,8328,17,4456708,1,1,1073741824,21,1077946789,257,1073817871,0,136]

theorem envBound22430 : H12AffineFastState.Bounded env22430 := by
  intro p hp
  have h : env22430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22378_22430 : H12AffineEnvironment.transform 14 261 env22378 = env22430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env22378 == env22430) = true)

def env22431 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,261,65536,1,262144,272,260,0,4194304,17,65536,128,17,4456708,1,1,1073741824,21,1077938605,257,1073809671,0,136]

theorem envBound22431 : H12AffineFastState.Bounded env22431 := by
  intro p hp
  have h : env22431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22430_22431 : H12AffineEnvironment.transform 12 8 env22430 = env22431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22430 == env22431) = true)

theorem identity22431 : scanCanonicalize (H12AffineFastState.compose env22431 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 4262026) := by decide +kernel

theorem selectedBound22431 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22432 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,261,65536,1,262144,272,260,0,4194304,17,65536,128,17,4456708,1,1,4262026,21,65831,257,4194701,0,136]

theorem envBound22432 : H12AffineFastState.Bounded env22432 := by
  intro p hp
  have h : env22432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22431_22432 : H12AffineEnvironment.transform 29 4262026 env22431 = env22432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4262026 env22431 == env22432) = true)

def env22433 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,261,65536,1,262144,272,260,0,262144,17,65536,128,17,260,1,1,329866,21,65831,257,262541,0,136]

theorem envBound22433 : H12AffineFastState.Bounded env22433 := by
  intro p hp
  have h : env22433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22432_22433 : H12AffineEnvironment.transform 21 262144 env22432 = env22433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262144 env22432 == env22433) = true)

theorem identity22433 : scanCanonicalize (H12AffineFastState.compose env22433 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 260) := by decide +kernel

theorem selectedBound22433 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22434 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,261,65536,1,260,272,260,0,260,17,65536,128,17,260,1,1,67982,21,65831,257,137,0,136]

theorem envBound22434 : H12AffineFastState.Bounded env22434 := by
  intro p hp
  have h : env22434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22433_22434 : H12AffineEnvironment.transform 17 260 env22433 = env22434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 260 env22433 == env22434) = true)

def env22435 : List Nat := [2,4,8,16,32,16,128,256,136,273,0,1,8,0,261,65536,1,260,272,260,0,260,17,65536,128,17,260,1,1,65934,21,65831,257,137,0,136]

theorem envBound22435 : H12AffineFastState.Bounded env22435 := by
  intro p hp
  have h : env22435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22434_22435 : H12AffineEnvironment.transform 10 0 env22434 = env22435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22434 == env22435) = true)

theorem identity22435 : scanCanonicalize (H12AffineFastState.compose env22435 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound22435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22436 : List Nat := [2,4,8,16,32,16,128,256,136,273,0,1,8,0,261,430,1,260,272,260,0,260,17,430,128,17,260,1,1,32,21,137,257,137,0,136]

theorem envBound22436 : H12AffineFastState.Bounded env22436 := by
  intro p hp
  have h : env22436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22435_22436 : H12AffineEnvironment.transform 15 430 env22435 = env22436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env22435 == env22436) = true)

theorem identity22436 : scanCanonicalize (H12AffineFastState.compose env22436 (packedSelected [18] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22436 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env22437 : List Nat := [2,4,8,16,0,16,128,256,136,273,0,1,8,0,261,398,1,260,272,260,0,260,17,398,128,17,260,1,1,0,21,137,257,137,0,136]

theorem envBound22437 : H12AffineFastState.Bounded env22437 := by
  intro p hp
  have h : env22437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22436_22437 : H12AffineEnvironment.transform 4 0 env22436 = env22437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22436 == env22437) = true)

def env22438 : List Nat := [2,4,8,16,0,16,8,256,0,273,0,1,8,0,261,262,1,260,272,260,0,260,17,262,8,17,260,1,1,0,21,1,257,1,0,0]

theorem envBound22438 : H12AffineFastState.Bounded env22438 := by
  intro p hp
  have h : env22438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22437_22438 : H12AffineEnvironment.transform 6 8 env22437 = env22438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22437 == env22438) = true)

def env22439 : List Nat := [2,4,8,16,0,16,9,256,1,273,0,1,8,0,261,263,1,260,272,260,0,260,17,263,9,17,260,1,1,0,21,0,257,0,0,1]

theorem envBound22439 : H12AffineFastState.Bounded env22439 := by
  intro p hp
  have h : env22439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22437_22439 : H12AffineEnvironment.transform 6 9 env22437 = env22439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22437 == env22439) = true)

theorem identity22439 : scanCanonicalize (H12AffineFastState.compose env22439 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22440 : List Nat := [2,4,8,16,0,16,9,4,1,21,0,1,8,0,1,3,1,0,20,0,0,0,17,3,9,17,0,1,1,0,21,0,5,0,0,1]

theorem envBound22440 : H12AffineFastState.Bounded env22440 := by
  intro p hp
  have h : env22440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22439_22440 : H12AffineEnvironment.transform 7 4 env22439 = env22440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22439 == env22440) = true)

def leafEnv22440 : List Nat := [2,4,8,16,0,16,9,4,1,21,0,1,8,0,1,3,1,0,20,0,0,0,17,3,20,9,1,17,0,1,1,0,21,0,5,0,5,2,0,1,0,0,1]

def active22440 : List Nat := [0,1,2,3]

def tree22440 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22440 : H12WitnessSearch.Good tree22440 := H12GlobalWitnessIndex.good

theorem leafIdentity22440 : H12AffineFastState.composeSystem env22440 rootObs = leafEnv22440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22440 rootObs == leafEnv22440) = true)

theorem terminalChecked22440 : H12PackedTerminal.terminalCheckFast leafEnv22440 active22440 tree22440 = true := by decide +kernel

def env22441 : List Nat := [2,4,8,16,32,16,128,256,136,273,1,1,8,0,261,65536,1,260,272,260,0,260,17,65536,128,17,260,1,1,65935,21,65831,257,137,0,136]

theorem envBound22441 : H12AffineFastState.Bounded env22441 := by
  intro p hp
  have h : env22441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22434_22441 : H12AffineEnvironment.transform 10 1 env22434 = env22441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22434 == env22441) = true)

theorem identity22441 : scanCanonicalize (H12AffineFastState.compose env22441 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22442 : List Nat := [2,4,8,16,1,16,128,256,136,273,1,1,8,0,261,65536,1,260,272,260,0,260,17,65536,128,17,260,1,1,65935,21,65798,257,137,0,136]

theorem envBound22442 : H12AffineFastState.Bounded env22442 := by
  intro p hp
  have h : env22442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22441_22442 : H12AffineEnvironment.transform 4 1 env22441 = env22442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22441 == env22442) = true)

theorem identity22442 : scanCanonicalize (H12AffineFastState.compose env22442 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound22442 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env22443 : List Nat := [2,4,8,16,1,16,128,256,136,273,1,1,8,0,261,398,1,260,272,260,0,260,17,398,128,17,260,1,1,1,21,136,257,137,0,136]

theorem envBound22443 : H12AffineFastState.Bounded env22443 := by
  intro p hp
  have h : env22443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22442_22443 : H12AffineEnvironment.transform 15 398 env22442 = env22443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env22442 == env22443) = true)

def env22444 : List Nat := [2,4,8,16,1,16,8,256,0,273,1,1,8,0,261,262,1,260,272,260,0,260,17,262,8,17,260,1,1,1,21,0,257,1,0,0]

theorem envBound22444 : H12AffineFastState.Bounded env22444 := by
  intro p hp
  have h : env22444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22443_22444 : H12AffineEnvironment.transform 6 8 env22443 = env22444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22443 == env22444) = true)

theorem identity22444 : scanCanonicalize (H12AffineFastState.compose env22444 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22444 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22445 : List Nat := [2,4,8,16,1,16,8,4,0,21,1,1,8,0,1,2,1,0,20,0,0,0,17,2,8,17,0,1,1,1,21,0,5,1,0,0]

theorem envBound22445 : H12AffineFastState.Bounded env22445 := by
  intro p hp
  have h : env22445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22444_22445 : H12AffineEnvironment.transform 7 4 env22444 = env22445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22444 == env22445) = true)

def leafEnv22445 : List Nat := [2,4,8,16,1,16,8,4,0,21,1,1,8,0,1,2,1,0,20,0,0,0,17,2,20,8,1,17,0,1,1,1,21,0,5,1,5,2,0,0,0,0,1]

def active22445 : List Nat := [0,1,2,3]

def tree22445 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22445 : H12WitnessSearch.Good tree22445 := H12GlobalWitnessIndex.good

theorem leafIdentity22445 : H12AffineFastState.composeSystem env22445 rootObs = leafEnv22445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22445 rootObs == leafEnv22445) = true)

theorem terminalChecked22445 : H12PackedTerminal.terminalCheckFast leafEnv22445 active22445 tree22445 = true := by decide +kernel

def env22446 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,8,0,261,263,1,260,272,260,0,260,17,263,9,17,260,1,1,1,21,1,257,0,0,1]

theorem envBound22446 : H12AffineFastState.Bounded env22446 := by
  intro p hp
  have h : env22446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22443_22446 : H12AffineEnvironment.transform 6 9 env22443 = env22446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22443 == env22446) = true)

def leafEnv22446 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,8,0,261,263,1,260,272,260,0,260,17,263,20,9,1,17,260,1,1,1,21,1,257,0,5,2,0,1,0,0,1]

def active22446 : List Nat := [0,1,2,3,7]

def tree22446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22446 : H12WitnessSearch.Good tree22446 := H12GlobalWitnessIndex.good

theorem leafIdentity22446 : H12AffineFastState.composeSystem env22446 rootObs = leafEnv22446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22446 rootObs == leafEnv22446) = true)

theorem terminalChecked22446 : H12PackedTerminal.terminalCheckFast leafEnv22446 active22446 tree22446 = true := by decide +kernel

def env22447 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,8,0,261,65536,1,262144,272,260,0,262145,17,65536,128,17,261,1,1,329867,21,65831,257,262540,0,136]

theorem envBound22447 : H12AffineFastState.Bounded env22447 := by
  intro p hp
  have h : env22447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22432_22447 : H12AffineEnvironment.transform 21 262145 env22432 = env22447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262145 env22432 == env22447) = true)

def env22448 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,129,17,4456708,1,1,1073741824,21,1077938604,257,1073809670,0,136]

theorem envBound22448 : H12AffineFastState.Bounded env22448 := by
  intro p hp
  have h : env22448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22430_22448 : H12AffineEnvironment.transform 12 9 env22430 = env22448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22430 == env22448) = true)

theorem identity22448 : scanCanonicalize (H12AffineFastState.compose env22448 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 67847) := by decide +kernel

theorem selectedBound22448 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22449 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,129,17,4456708,1,1,67847,21,4260011,257,1,0,136]

theorem envBound22449 : H12AffineFastState.Bounded env22449 := by
  intro p hp
  have h : env22449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22448_22449 : H12AffineEnvironment.transform 29 67847 env22448 = env22449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67847 env22448 == env22449) = true)

def env22450 : List Nat := [2,4,8,16,32,16,128,256,136,273,0,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,129,17,4456708,1,1,65799,21,4260011,257,1,0,136]

theorem envBound22450 : H12AffineFastState.Bounded env22450 := by
  intro p hp
  have h : env22450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22449_22450 : H12AffineEnvironment.transform 10 0 env22449 = env22450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22449 == env22450) = true)

def env22451 : List Nat := [2,4,8,16,32,16,8,256,0,273,0,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,9,17,4456708,1,1,65799,21,4259875,257,1,0,0]

theorem envBound22451 : H12AffineFastState.Bounded env22451 := by
  intro p hp
  have h : env22451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22450_22451 : H12AffineEnvironment.transform 6 8 env22450 = env22451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22450 == env22451) = true)

theorem identity22451 : scanCanonicalize (H12AffineFastState.compose env22451 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound22451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22452 : List Nat := [2,4,8,16,32,16,8,256,0,273,0,1,9,0,261,65536,1,262144,272,260,0,65831,17,65536,9,17,327715,1,1,65799,21,260,257,1,0,0]

theorem envBound22452 : H12AffineFastState.Bounded env22452 := by
  intro p hp
  have h : env22452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22451_22452 : H12AffineEnvironment.transform 21 65831 env22451 = env22452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env22451 == env22452) = true)

theorem identity22452 : scanCanonicalize (H12AffineFastState.compose env22452 (packedSelected [2,4,9,11,23] rootPS)) = affineNative (2^(17+1) ^^^ 65570) := by decide +kernel

theorem selectedBound22452 : packedSelected [2,4,9,11,23] rootPS < 2^1333 := by decide +kernel

def env22453 : List Nat := [2,4,8,16,32,16,8,256,0,273,0,1,9,0,261,65536,1,65570,272,260,0,65831,17,65536,9,17,1,1,1,65799,21,260,257,1,0,0]

theorem envBound22453 : H12AffineFastState.Bounded env22453 := by
  intro p hp
  have h : env22453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22452_22453 : H12AffineEnvironment.transform 17 65570 env22452 = env22453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65570 env22452 == env22453) = true)

theorem identity22453 : scanCanonicalize (H12AffineFastState.compose env22453 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound22453 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22454 : List Nat := [2,4,8,16,32,16,8,256,0,273,0,1,9,0,261,35,1,1,272,260,0,260,17,35,9,17,1,1,1,292,21,260,257,1,0,0]

theorem envBound22454 : H12AffineFastState.Bounded env22454 := by
  intro p hp
  have h : env22454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22453_22454 : H12AffineEnvironment.transform 15 35 env22453 = env22454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env22453 == env22454) = true)

theorem identity22454 : scanCanonicalize (H12AffineFastState.compose env22454 (packedSelected [2,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22454 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env22455 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,1,9,0,33,35,1,1,52,32,0,32,17,35,9,17,1,1,1,0,21,32,37,1,0,0]

theorem envBound22455 : H12AffineFastState.Bounded env22455 := by
  intro p hp
  have h : env22455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22454_22455 : H12AffineEnvironment.transform 7 36 env22454 = env22455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22454 == env22455) = true)

def leafEnv22455 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,1,9,0,33,35,1,1,52,32,0,32,17,35,20,9,1,17,1,1,1,0,21,32,37,1,5,2,0,0,0,0,1]

def active22455 : List Nat := [0,1,2,3,4]

def tree22455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22455 : H12WitnessSearch.Good tree22455 := H12GlobalWitnessIndex.good

theorem leafIdentity22455 : H12AffineFastState.composeSystem env22455 rootObs = leafEnv22455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22455 rootObs == leafEnv22455) = true)

theorem terminalChecked22455 : H12PackedTerminal.terminalCheckFast leafEnv22455 active22455 tree22455 = true := by decide +kernel

def env22456 : List Nat := [2,4,8,16,32,16,9,256,1,273,0,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,8,17,4456708,1,1,65799,21,4259874,257,1,0,1]

theorem envBound22456 : H12AffineFastState.Bounded env22456 := by
  intro p hp
  have h : env22456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22450_22456 : H12AffineEnvironment.transform 6 9 env22450 = env22456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22450 == env22456) = true)

theorem identity22456 : scanCanonicalize (H12AffineFastState.compose env22456 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 65571) := by decide +kernel

theorem selectedBound22456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22457 : List Nat := [2,4,8,16,32,16,9,256,1,273,0,1,9,0,261,65536,1,262144,272,260,0,65571,17,65536,8,17,327975,1,1,65799,21,1,257,1,0,1]

theorem envBound22457 : H12AffineFastState.Bounded env22457 := by
  intro p hp
  have h : env22457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22456_22457 : H12AffineEnvironment.transform 21 65571 env22456 = env22457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65571 env22456 == env22457) = true)

theorem identity22457 : scanCanonicalize (H12AffineFastState.compose env22457 (packedSelected [2,4,7,9,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22457 : packedSelected [2,4,7,9,23] rootPS < 2^1333 := by decide +kernel

def env22458 : List Nat := [2,4,8,16,32,16,9,5,1,20,0,1,9,0,0,65536,1,262144,21,1,0,65571,17,65536,8,17,327714,1,1,65538,21,1,4,1,0,1]

theorem envBound22458 : H12AffineFastState.Bounded env22458 := by
  intro p hp
  have h : env22458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22457_22458 : H12AffineEnvironment.transform 7 5 env22457 = env22458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22457 == env22458) = true)

theorem identity22458 : scanCanonicalize (H12AffineFastState.compose env22458 (packedSelected [4,7,18] rootPS)) = affineNative (2^(17+1) ^^^ 32) := by decide +kernel

theorem selectedBound22458 : packedSelected [4,7,18] rootPS < 2^1333 := by decide +kernel

def env22459 : List Nat := [2,4,8,16,32,16,9,5,1,20,0,1,9,0,0,65536,1,32,21,1,0,65571,17,65536,8,17,65538,1,1,65538,21,1,4,1,0,1]

theorem envBound22459 : H12AffineFastState.Bounded env22459 := by
  intro p hp
  have h : env22459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22458_22459 : H12AffineEnvironment.transform 17 32 env22458 = env22459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32 env22458 == env22459) = true)

theorem identity22459 : scanCanonicalize (H12AffineFastState.compose env22459 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22459 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22460 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,9,0,0,65536,1,0,21,1,0,65539,17,65536,8,17,65538,1,1,65538,21,1,4,1,0,1]

theorem envBound22460 : H12AffineFastState.Bounded env22460 := by
  intro p hp
  have h : env22460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22459_22460 : H12AffineEnvironment.transform 4 0 env22459 = env22460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22459 == env22460) = true)

def leafEnv22460 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,9,0,0,65536,1,0,21,1,0,65539,17,65536,20,8,1,17,65538,1,1,65538,21,1,4,1,5,2,0,1,0,0,1]

def active22460 : List Nat := [0,1,2,3,15]

def tree22460 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22460 : H12WitnessSearch.Good tree22460 := H12GlobalWitnessIndex.good

theorem leafIdentity22460 : H12AffineFastState.composeSystem env22460 rootObs = leafEnv22460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22460 rootObs == leafEnv22460) = true)

theorem terminalChecked22460 : H12PackedTerminal.terminalCheckFast leafEnv22460 active22460 tree22460 = true := by decide +kernel

def env22461 : List Nat := [2,4,8,16,32,16,128,256,136,273,1,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,129,17,4456708,1,1,65798,21,4260011,257,1,0,136]

theorem envBound22461 : H12AffineFastState.Bounded env22461 := by
  intro p hp
  have h : env22461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22449_22461 : H12AffineEnvironment.transform 10 1 env22449 = env22461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22449 == env22461) = true)

def env22462 : List Nat := [2,4,8,16,32,16,8,256,0,273,1,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,9,17,4456708,1,1,65798,21,4259875,257,1,0,0]

theorem envBound22462 : H12AffineFastState.Bounded env22462 := by
  intro p hp
  have h : env22462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22461_22462 : H12AffineEnvironment.transform 6 8 env22461 = env22462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22461 == env22462) = true)

theorem identity22462 : scanCanonicalize (H12AffineFastState.compose env22462 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound22462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22463 : List Nat := [2,4,8,16,32,16,8,256,0,273,1,1,9,0,261,65536,1,262144,272,260,0,33,17,65536,9,17,262437,1,1,65798,21,65538,257,1,0,0]

theorem envBound22463 : H12AffineFastState.Bounded env22463 := by
  intro p hp
  have h : env22463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22462_22463 : H12AffineEnvironment.transform 21 33 env22462 = env22463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22462 == env22463) = true)

theorem identity22463 : scanCanonicalize (H12AffineFastState.compose env22463 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound22463 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22464 : List Nat := [2,4,8,16,32,16,8,256,0,273,1,1,9,0,261,34,1,262144,272,260,0,33,17,34,9,17,262437,1,1,292,21,32,257,1,0,0]

theorem envBound22464 : H12AffineFastState.Bounded env22464 := by
  intro p hp
  have h : env22464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22463_22464 : H12AffineEnvironment.transform 15 34 env22463 = env22464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env22463 == env22464) = true)

theorem identity22464 : scanCanonicalize (H12AffineFastState.compose env22464 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22464 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22465 : List Nat := [2,4,8,16,1,16,8,256,0,273,1,1,9,0,261,3,1,262144,272,260,0,0,17,3,9,17,262404,1,1,261,21,1,257,1,0,0]

theorem envBound22465 : H12AffineFastState.Bounded env22465 := by
  intro p hp
  have h : env22465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22464_22465 : H12AffineEnvironment.transform 4 1 env22464 = env22465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22464 == env22465) = true)

def env22466 : List Nat := [2,4,8,16,32,16,9,256,1,273,1,1,9,0,261,65536,1,262144,272,260,0,4194304,17,65536,8,17,4456708,1,1,65798,21,4259874,257,1,0,1]

theorem envBound22466 : H12AffineFastState.Bounded env22466 := by
  intro p hp
  have h : env22466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22461_22466 : H12AffineEnvironment.transform 6 9 env22461 = env22466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22461 == env22466) = true)

theorem identity22466 : scanCanonicalize (H12AffineFastState.compose env22466 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound22466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22467 : List Nat := [2,4,8,16,32,16,9,256,1,273,1,1,9,0,261,65536,1,262144,272,260,0,293,17,65536,8,17,262177,1,1,65798,21,65799,257,1,0,1]

theorem envBound22467 : H12AffineFastState.Bounded env22467 := by
  intro p hp
  have h : env22467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22466_22467 : H12AffineEnvironment.transform 21 293 env22466 = env22467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env22466 == env22467) = true)

theorem identity22467 : scanCanonicalize (H12AffineFastState.compose env22467 (packedSelected [4,7,23] rootPS)) = affineNative (2^(17+1) ^^^ 292) := by decide +kernel

theorem selectedBound22467 : packedSelected [4,7,23] rootPS < 2^1333 := by decide +kernel

def env22468 : List Nat := [2,4,8,16,32,16,9,256,1,273,1,1,9,0,261,65536,1,292,272,260,0,293,17,65536,8,17,261,1,1,65798,21,65799,257,1,0,1]

theorem envBound22468 : H12AffineFastState.Bounded env22468 := by
  intro p hp
  have h : env22468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22467_22468 : H12AffineEnvironment.transform 17 292 env22467 = env22468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 292 env22467 == env22468) = true)

theorem identity22468 : scanCanonicalize (H12AffineFastState.compose env22468 (packedSelected [7,11] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound22468 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env22469 : List Nat := [2,4,8,16,32,16,9,256,1,273,1,1,9,0,261,294,1,292,272,260,0,293,17,294,8,17,261,1,1,32,21,33,257,1,0,1]

theorem envBound22469 : H12AffineFastState.Bounded env22469 := by
  intro p hp
  have h : env22469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22468_22469 : H12AffineEnvironment.transform 15 294 env22468 = env22469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env22468 == env22469) = true)

def env22470 : List Nat := [2,4,8,16,0,16,9,256,1,273,1,1,9,0,261,262,1,260,272,260,0,261,17,262,8,17,261,1,1,0,21,1,257,1,0,1]

theorem envBound22470 : H12AffineFastState.Bounded env22470 := by
  intro p hp
  have h : env22470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22469_22470 : H12AffineEnvironment.transform 4 0 env22469 = env22470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22469 == env22470) = true)

theorem identity22470 : scanCanonicalize (H12AffineFastState.compose env22470 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22470 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22471 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,9,0,0,3,1,1,21,1,0,0,17,3,8,17,0,1,1,0,21,1,4,1,0,1]

theorem envBound22471 : H12AffineFastState.Bounded env22471 := by
  intro p hp
  have h : env22471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22470_22471 : H12AffineEnvironment.transform 7 5 env22470 = env22471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22470 == env22471) = true)

def leafEnv22471 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,9,0,0,3,1,1,21,1,0,0,17,3,20,8,1,17,0,1,1,0,21,1,4,1,5,2,0,1,0,0,1]

def active22471 : List Nat := [0,1,2,3]

def tree22471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22471 : H12WitnessSearch.Good tree22471 := H12GlobalWitnessIndex.good

theorem leafIdentity22471 : H12AffineFastState.composeSystem env22471 rootObs = leafEnv22471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22471 rootObs == leafEnv22471) = true)

theorem terminalChecked22471 : H12PackedTerminal.terminalCheckFast leafEnv22471 active22471 tree22471 = true := by decide +kernel

def env22472 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,9,0,261,263,1,261,272,260,0,260,17,263,8,17,261,1,1,1,21,0,257,1,0,1]

theorem envBound22472 : H12AffineFastState.Bounded env22472 := by
  intro p hp
  have h : env22472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22469_22472 : H12AffineEnvironment.transform 4 1 env22469 = env22472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22469 == env22472) = true)

def leafEnv22472 : List Nat := [2,4,8,16,1,16,9,256,1,273,1,1,9,0,261,263,1,261,272,260,0,260,17,263,20,8,1,17,261,1,1,1,21,0,257,1,5,2,0,1,0,0,1]

def active22472 : List Nat := [0,1,2,3,7]

def tree22472 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22472 : H12WitnessSearch.Good tree22472 := H12GlobalWitnessIndex.good

theorem leafIdentity22472 : H12AffineFastState.composeSystem env22472 rootObs = leafEnv22472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22472 rootObs == leafEnv22472) = true)

theorem terminalChecked22472 : H12PackedTerminal.terminalCheckFast leafEnv22472 active22472 tree22472 = true := by decide +kernel

def env22473 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,98565,8328,17,4456709,1297,1296,1073741824,1284,4294967296,257,4299260335,1297,137]

theorem envBound22473 : H12AffineFastState.Bounded env22473 := by
  intro p hp
  have h : env22473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22308_22473 : H12AffineEnvironment.transform 8 137 env22308 = env22473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22308 == env22473) = true)

theorem identity22473 : scanCanonicalize (H12AffineFastState.compose env22473 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound22473 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22474 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,76198,1024,32769,1297,4194304,16,98565,8328,17,4270243,1297,1296,1073741824,1284,4294967296,257,4299260335,1297,137]

theorem envBound22474 : H12AffineFastState.Bounded env22474 := by
  intro p hp
  have h : env22474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22473_22474 : H12AffineEnvironment.transform 17 76198 env22473 = env22474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env22473 == env22474) = true)

theorem identity22474 : scanCanonicalize (H12AffineFastState.compose env22474 (packedSelected [3] rootPS)) = affineNative (2^(31+1) ^^^ 4268201) := by decide +kernel

theorem selectedBound22474 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22475 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,76198,1024,32769,1297,4194304,16,98565,8328,17,4270243,1297,1296,1073741824,1284,4268201,257,41222,1297,137]

theorem envBound22475 : H12AffineFastState.Bounded env22475 := by
  intro p hp
  have h : env22475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22474_22475 : H12AffineEnvironment.transform 31 4268201 env22474 = env22475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4268201 env22474 == env22475) = true)

theorem identity22475 : scanCanonicalize (H12AffineFastState.compose env22475 (packedSelected [1,8] rootPS)) = affineNative (2^(29+1) ^^^ 4196613) := by decide +kernel

theorem selectedBound22475 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22476 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,76198,1024,32769,1297,4194304,16,98565,8328,17,4270243,1297,1296,4196613,1284,4268201,257,41222,1297,137]

theorem envBound22476 : H12AffineFastState.Bounded env22476 := by
  intro p hp
  have h : env22476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22475_22476 : H12AffineEnvironment.transform 29 4196613 env22475 = env22476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196613 env22475 == env22476) = true)

theorem identity22476 : scanCanonicalize (H12AffineFastState.compose env22476 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 108707) := by decide +kernel

theorem selectedBound22476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22477 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,76198,1024,32769,1297,108707,16,98565,8328,17,32768,1297,1296,106918,1284,34826,257,41222,1297,137]

theorem envBound22477 : H12AffineFastState.Bounded env22477 := by
  intro p hp
  have h : env22477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22476_22477 : H12AffineEnvironment.transform 21 108707 env22476 = env22477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 108707 env22476 == env22477) = true)

theorem identity22477 : scanCanonicalize (H12AffineFastState.compose env22477 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound22477 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22478 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,33166,1296,43048,1024,32769,1297,10541,16,139,8328,17,32768,1297,1296,8232,1284,34826,257,41222,1297,137]

theorem envBound22478 : H12AffineFastState.Bounded env22478 := by
  intro p hp
  have h : env22478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22477_22478 : H12AffineEnvironment.transform 15 33166 env22477 = env22478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env22477 == env22478) = true)

theorem identity22478 : scanCanonicalize (H12AffineFastState.compose env22478 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22478 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env22479 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,8461,8323,1296,2341,1024,8460,1297,10541,16,139,8328,17,8461,1297,1296,8232,1284,10503,257,11,1297,137]

theorem envBound22479 : H12AffineFastState.Bounded env22479 := by
  intro p hp
  have h : env22479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22478_22479 : H12AffineEnvironment.transform 14 8461 env22478 = env22479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22478 == env22479) = true)

theorem identity22479 : scanCanonicalize (H12AffineFastState.compose env22479 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound22479 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22480 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2088,1296,2341,2219,1296,2341,1024,2340,1297,261,16,139,2208,17,2341,1297,1296,2048,1284,303,257,11,1297,137]

theorem envBound22480 : H12AffineFastState.Bounded env22480 := by
  intro p hp
  have h : env22480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22479_22480 : H12AffineEnvironment.transform 12 2088 env22479 = env22480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22479 == env22480) = true)

theorem identity22480 : scanCanonicalize (H12AffineFastState.compose env22480 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22481 : List Nat := [2,4,8,16,32,16,2,256,11,1024,2048,1296,2088,1296,2341,2089,1296,2341,1024,2340,1297,261,16,9,2082,17,2341,1297,1296,2048,1284,303,257,11,1297,11]

theorem envBound22481 : H12AffineFastState.Bounded env22481 := by
  intro p hp
  have h : env22481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22480_22481 : H12AffineEnvironment.transform 6 2 env22480 = env22481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22480 == env22481) = true)

def env22482 : List Nat := [2,4,8,16,32,16,2,36,11,1024,2048,1076,2088,1076,2049,2089,1076,2049,1024,2048,1077,33,16,9,2082,17,2049,1077,1076,2048,1056,11,37,11,1077,11]

theorem envBound22482 : H12AffineFastState.Bounded env22482 := by
  intro p hp
  have h : env22482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22481_22482 : H12AffineEnvironment.transform 7 36 env22481 = env22482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22481 == env22482) = true)

theorem identity22482 : scanCanonicalize (H12AffineFastState.compose env22482 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound22482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22483 : List Nat := [2,4,8,16,16,16,2,20,11,1024,2048,1028,2072,1028,2049,2073,1028,2049,1024,2048,1029,17,16,9,2066,17,2049,1029,1028,2048,1040,11,21,11,1029,11]

theorem envBound22483 : H12AffineFastState.Bounded env22483 := by
  intro p hp
  have h : env22483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22482_22483 : H12AffineEnvironment.transform 4 16 env22482 = env22483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env22482 == env22483) = true)

def leafEnv22483 : List Nat := [2,4,8,16,16,16,2,20,11,1024,2048,1028,2072,1028,2049,2073,1028,2049,1024,2048,1029,17,16,9,1040,2066,1,17,2049,1029,1028,2048,1040,11,21,11,5,2066,1029,11,0,1029,1]

def active22483 : List Nat := [0,1,2,3,9,10]

def tree22483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22483 : H12WitnessSearch.Good tree22483 := H12GlobalWitnessIndex.good

theorem leafIdentity22483 : H12AffineFastState.composeSystem env22483 rootObs = leafEnv22483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22483 rootObs == leafEnv22483) = true)

theorem terminalChecked22483 : H12PackedTerminal.terminalCheckFast leafEnv22483 active22483 tree22483 = true := by decide +kernel

def env22484 : List Nat := [2,4,8,16,32,16,2,37,11,1024,2048,1077,2088,1077,2048,2089,1077,2048,1024,2049,1076,32,16,9,2082,17,2048,1076,1077,2048,1057,10,36,11,1076,11]

theorem envBound22484 : H12AffineFastState.Bounded env22484 := by
  intro p hp
  have h : env22484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22481_22484 : H12AffineEnvironment.transform 7 37 env22481 = env22484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22481 == env22484) = true)

theorem identity22484 : scanCanonicalize (H12AffineFastState.compose env22484 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound22484 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22485 : List Nat := [2,4,8,10,32,10,2,37,11,1024,2048,1071,2088,1071,2048,2089,1071,2048,1024,2049,1070,32,10,9,2082,11,2048,1070,1071,2048,1057,10,36,11,1070,11]

theorem envBound22485 : H12AffineFastState.Bounded env22485 := by
  intro p hp
  have h : env22485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22484_22485 : H12AffineEnvironment.transform 3 10 env22484 = env22485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env22484 == env22485) = true)

def leafEnv22485 : List Nat := [2,4,8,10,32,10,2,37,11,1024,2048,1071,2088,1071,2048,2089,1071,2048,1024,2049,1070,32,10,9,1057,2082,1,11,2048,1070,1071,2048,1057,10,36,11,5,2082,1070,11,0,1070,1]

def active22485 : List Nat := [0,1,2,4,9,10]

def tree22485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22485 : H12WitnessSearch.Good tree22485 := H12GlobalWitnessIndex.good

theorem leafIdentity22485 : H12AffineFastState.composeSystem env22485 rootObs = leafEnv22485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22485 rootObs == leafEnv22485) = true)

theorem terminalChecked22485 : H12PackedTerminal.terminalCheckFast leafEnv22485 active22485 tree22485 = true := by decide +kernel

def env22486 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,4194304,17664,98565,8328,16,4473876,16385,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22486 : H12AffineFastState.Bounded env22486 := by
  intro p hp
  have h : env22486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22306_22486 : H12AffineEnvironment.transform 11 1297 env22306 = env22486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env22306 == env22486) = true)

theorem identity22486 : scanCanonicalize (H12AffineFastState.compose env22486 (packedSelected [1,3,5,13,15,19] rootPS)) = affineNative (2^(29+1) ^^^ 4312474) := by decide +kernel

theorem selectedBound22486 : packedSelected [1,3,5,13,15,19] rootPS < 2^1333 := by decide +kernel

def env22487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,4194304,17664,98565,8328,16,4473876,16385,1296,4312474,1284,4294967296,257,4299260335,1297,512]

theorem envBound22487 : H12AffineFastState.Bounded env22487 := by
  intro p hp
  have h : env22487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22486_22487 : H12AffineEnvironment.transform 29 4312474 env22486 = env22487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4312474 env22486 == env22487) = true)

def env22488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,58768,17664,98565,8328,16,303492,16385,1296,75786,1284,4294967296,257,4295058495,1297,512]

theorem envBound22488 : H12AffineFastState.Bounded env22488 := by
  intro p hp
  have h : env22488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22487_22488 : H12AffineEnvironment.transform 21 58768 env22487 = env22488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 58768 env22487 == env22488) = true)

theorem identity22488 : scanCanonicalize (H12AffineFastState.compose env22488 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98339) := by decide +kernel

theorem selectedBound22488 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,58768,17664,98565,8328,16,303492,16385,1296,75786,1284,98339,257,58396,1297,512]

theorem envBound22489 : H12AffineFastState.Bounded env22489 := by
  intro p hp
  have h : env22489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22488_22489 : H12AffineEnvironment.transform 31 98339 env22488 = env22489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98339 env22488 == env22489) = true)

def env22490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1296,41088,16,98565,8328,16,303492,1297,1296,75786,1284,98339,257,41228,1297,512]

theorem envBound22490 : H12AffineFastState.Bounded env22490 := by
  intro p hp
  have h : env22490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22489_22490 : H12AffineEnvironment.transform 13 1296 env22489 = env22490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env22489 == env22490) = true)

theorem identity22490 : scanCanonicalize (H12AffineFastState.compose env22490 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22490 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22491 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,43049,1025,32769,1296,41088,16,98565,8328,16,2477,1297,1296,75786,1284,98339,257,41228,1297,512]

theorem envBound22491 : H12AffineFastState.Bounded env22491 := by
  intro p hp
  have h : env22491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22490_22491 : H12AffineEnvironment.transform 17 43049 env22490 = env22491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22490 == env22491) = true)

theorem identity22491 : scanCanonicalize (H12AffineFastState.compose env22491 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 43171) := by decide +kernel

theorem selectedBound22491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22492 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,43171,1296,43049,1025,32769,1296,41088,16,10662,8328,16,2477,1297,1296,32937,1284,10368,257,41228,1297,512]

theorem envBound22492 : H12AffineFastState.Bounded env22492 := by
  intro p hp
  have h : env22492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22491_22492 : H12AffineEnvironment.transform 15 43171 env22491 = env22492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43171 env22491 == env22492) = true)

theorem identity22492 : scanCanonicalize (H12AffineFastState.compose env22492 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound22492 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env22493 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2349,1296,32768,33166,1296,33028,1025,32769,1296,35245,16,139,2469,16,2477,1297,1296,32937,1284,429,257,34849,1297,512]

theorem envBound22493 : H12AffineFastState.Bounded env22493 := by
  intro p hp
  have h : env22493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22492_22493 : H12AffineEnvironment.transform 12 2349 env22492 = env22493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env22492 == env22493) = true)

theorem identity22493 : scanCanonicalize (H12AffineFastState.compose env22493 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2217) := by decide +kernel

theorem selectedBound22493 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22494 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2349,1296,2217,2343,1296,2477,1025,2216,1296,260,16,139,2469,16,2477,1297,1296,2048,1284,429,257,136,1297,512]

theorem envBound22494 : H12AffineFastState.Bounded env22494 := by
  intro p hp
  have h : env22494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22493_22494 : H12AffineEnvironment.transform 14 2217 env22493 = env22494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2217 env22493 == env22494) = true)

theorem identity22494 : scanCanonicalize (H12AffineFastState.compose env22494 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22494 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22495 : List Nat := [2,4,8,16,32,16,128,140,512,1024,2048,1181,2209,1180,2217,2219,1180,2081,1025,2216,1180,136,16,139,2089,16,2081,1181,1180,2048,1160,33,141,136,1181,512]

theorem envBound22495 : H12AffineFastState.Bounded env22495 := by
  intro p hp
  have h : env22495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22494_22495 : H12AffineEnvironment.transform 7 140 env22494 = env22495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22494 == env22495) = true)

theorem identity22495 : scanCanonicalize (H12AffineFastState.compose env22495 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound22495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22496 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1181,2209,1180,2217,2219,1180,2081,1025,2216,1180,136,16,139,2089,16,2081,1181,1180,2048,1160,33,141,136,1181,136]

theorem envBound22496 : H12AffineFastState.Bounded env22496 := by
  intro p hp
  have h : env22496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22495_22496 : H12AffineEnvironment.transform 8 136 env22495 = env22496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22495 == env22496) = true)

def leafEnv22496 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1181,2209,1180,2217,2219,1180,2081,1025,2216,1180,136,16,139,1161,2089,1,16,2081,1181,1180,2048,1160,33,141,136,5,2082,1181,136,0,1181,1]

def active22496 : List Nat := [0,1,2,3,4,6,9,10]

def tree22496 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22496 : H12WitnessSearch.Good tree22496 := H12GlobalWitnessIndex.good

theorem leafIdentity22496 : H12AffineFastState.composeSystem env22496 rootObs = leafEnv22496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22496 rootObs == leafEnv22496) = true)

theorem terminalChecked22496 : H12PackedTerminal.terminalCheckFast leafEnv22496 active22496 tree22496 = true := by decide +kernel

def env22497 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1024,32769,1296,41089,17,98565,8328,16,303492,1296,1296,75786,1284,98339,257,41229,1297,512]

theorem envBound22497 : H12AffineFastState.Bounded env22497 := by
  intro p hp
  have h : env22497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22489_22497 : H12AffineEnvironment.transform 13 1297 env22489 = env22497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env22489 == env22497) = true)

theorem identity22497 : scanCanonicalize (H12AffineFastState.compose env22497 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound22497 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22498 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33543,1296,262144,1024,32769,1296,41089,17,514,8328,16,303492,1296,1296,43789,1284,804,257,41229,1297,512]

theorem envBound22498 : H12AffineFastState.Bounded env22498 := by
  intro p hp
  have h : env22498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22497_22498 : H12AffineEnvironment.transform 15 33543 env22497 = env22498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env22497 == env22498) = true)

theorem identity22498 : scanCanonicalize (H12AffineFastState.compose env22498 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22498 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22499 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33543,1296,43048,1024,32769,1296,41089,17,514,8328,16,2476,1296,1296,43789,1284,804,257,41229,1297,512]

theorem envBound22499 : H12AffineFastState.Bounded env22499 := by
  intro p hp
  have h : env22499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22498_22499 : H12AffineEnvironment.transform 17 43048 env22498 = env22499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22498 == env22499) = true)

theorem identity22499 : scanCanonicalize (H12AffineFastState.compose env22499 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound22499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22500 : List Nat := [2,4,8,16,32,16,3,256,512,1024,2048,1297,8192,1297,32768,33543,1296,43048,1024,32769,1296,40962,17,514,8203,16,2351,1296,1296,43789,1284,804,257,41229,1297,512]

theorem envBound22500 : H12AffineFastState.Bounded env22500 := by
  intro p hp
  have h : env22500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22499_22500 : H12AffineEnvironment.transform 6 3 env22499 = env22500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env22499 == env22500) = true)

theorem identity22500 : scanCanonicalize (H12AffineFastState.compose env22500 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 8967) := by decide +kernel

theorem selectedBound22500 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env22501 : List Nat := [2,4,8,16,32,16,3,256,512,1024,2048,1297,8192,1297,8967,8192,1296,2863,1024,8966,1296,773,17,514,8203,16,2351,1296,1296,2058,1284,804,257,522,1297,512]

theorem envBound22501 : H12AffineFastState.Bounded env22501 := by
  intro p hp
  have h : env22501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22500_22501 : H12AffineEnvironment.transform 14 8967 env22500 = env22501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8967 env22500 == env22501) = true)

theorem identity22501 : scanCanonicalize (H12AffineFastState.compose env22501 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound22501 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env22502 : List Nat := [2,4,8,16,32,16,3,256,512,1024,2048,1297,2600,1297,2351,2600,1296,2863,1024,2350,1296,773,17,514,2595,16,2351,1296,1296,2058,1284,804,257,522,1297,512]

theorem envBound22502 : H12AffineFastState.Bounded env22502 := by
  intro p hp
  have h : env22502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22501_22502 : H12AffineEnvironment.transform 12 2600 env22501 = env22502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env22501 == env22502) = true)

theorem identity22502 : scanCanonicalize (H12AffineFastState.compose env22502 (packedSelected [3,13] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound22502 : packedSelected [3,13] rootPS < 2^1333 := by decide +kernel

def env22503 : List Nat := [2,4,8,16,32,16,3,256,10,1024,2048,1297,2082,1297,2351,2082,1296,2341,1024,2350,1296,271,17,8,2089,16,2351,1296,1296,2058,1284,302,257,0,1297,10]

theorem envBound22503 : H12AffineFastState.Bounded env22503 := by
  intro p hp
  have h : env22503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22502_22503 : H12AffineEnvironment.transform 8 10 env22502 = env22503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env22502 == env22503) = true)

theorem identity22503 : scanCanonicalize (H12AffineFastState.compose env22503 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22503 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22504 : List Nat := [2,4,2,16,32,16,3,256,0,1024,2048,1297,2082,1297,2341,2082,1296,2341,1024,2340,1296,261,17,2,2083,16,2341,1296,1296,2048,1284,292,257,0,1297,0]

theorem envBound22504 : H12AffineFastState.Bounded env22504 := by
  intro p hp
  have h : env22504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22503_22504 : H12AffineEnvironment.transform 2 2 env22503 = env22504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22503 == env22504) = true)

def env22505 : List Nat := [2,4,2,16,0,16,3,256,0,1024,2048,1297,2050,1297,2309,2050,1296,2309,1024,2308,1296,261,17,2,2051,16,2309,1296,1296,2048,1284,260,257,0,1297,0]

theorem envBound22505 : H12AffineFastState.Bounded env22505 := by
  intro p hp
  have h : env22505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22504_22505 : H12AffineEnvironment.transform 4 0 env22504 = env22505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22504 == env22505) = true)

theorem identity22505 : scanCanonicalize (H12AffineFastState.compose env22505 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22506 : List Nat := [2,4,2,16,0,16,3,20,0,1024,2048,1029,2050,1029,2065,2050,1028,2065,1024,2064,1028,17,17,2,2051,16,2065,1028,1028,2048,1040,16,21,0,1029,0]

theorem envBound22506 : H12AffineFastState.Bounded env22506 := by
  intro p hp
  have h : env22506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22505_22506 : H12AffineEnvironment.transform 7 20 env22505 = env22506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22505 == env22506) = true)

def leafEnv22506 : List Nat := [2,4,2,16,0,16,3,20,0,1024,2048,1029,2050,1029,2065,2050,1028,2065,1024,2064,1028,17,17,2,1040,2051,1,16,2065,1028,1028,2048,1040,16,21,0,5,2050,1029,0,0,1029,1]

def active22506 : List Nat := [0,1,3,9,10]

def tree22506 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22506 : H12WitnessSearch.Good tree22506 := H12GlobalWitnessIndex.good

theorem leafIdentity22506 : H12AffineFastState.composeSystem env22506 rootObs = leafEnv22506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22506 rootObs == leafEnv22506) = true)

theorem terminalChecked22506 : H12PackedTerminal.terminalCheckFast leafEnv22506 active22506 tree22506 = true := by decide +kernel

def env22507 : List Nat := [2,4,2,16,1,16,3,256,0,1024,2048,1297,2051,1297,2308,2051,1296,2308,1024,2309,1296,261,17,2,2050,16,2308,1296,1296,2048,1284,261,257,0,1297,0]

theorem envBound22507 : H12AffineFastState.Bounded env22507 := by
  intro p hp
  have h : env22507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22504_22507 : H12AffineEnvironment.transform 4 1 env22504 = env22507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22504 == env22507) = true)

theorem identity22507 : scanCanonicalize (H12AffineFastState.compose env22507 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22508 : List Nat := [2,4,2,1,1,1,3,256,0,1024,2048,1280,2051,1280,2308,2051,1281,2308,1024,2309,1281,261,0,2,2050,1,2308,1281,1281,2048,1284,261,257,0,1280,0]

theorem envBound22508 : H12AffineFastState.Bounded env22508 := by
  intro p hp
  have h : env22508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22507_22508 : H12AffineEnvironment.transform 3 1 env22507 = env22508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22507 == env22508) = true)

def leafEnv22508 : List Nat := [2,4,2,1,1,1,3,256,0,1024,2048,1280,2051,1280,2308,2051,1281,2308,1024,2309,1281,261,0,2,1284,2050,1,1,2308,1281,1281,2048,1284,261,257,0,5,2051,1280,0,0,1280,1]

def active22508 : List Nat := [0,1,7,9,10]

def tree22508 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22508 : H12WitnessSearch.Good tree22508 := H12GlobalWitnessIndex.good

theorem leafIdentity22508 : H12AffineFastState.composeSystem env22508 rootObs = leafEnv22508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22508 rootObs == leafEnv22508) = true)

theorem terminalChecked22508 : H12PackedTerminal.terminalCheckFast leafEnv22508 active22508 tree22508 = true := by decide +kernel

def env22509 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,58769,17664,98565,8328,16,303493,16385,1296,75787,1284,4294967296,257,4295058494,1297,512]

theorem envBound22509 : H12AffineFastState.Bounded env22509 := by
  intro p hp
  have h : env22509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22487_22509 : H12AffineEnvironment.transform 21 58769 env22487 = env22509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 58769 env22487 == env22509) = true)

theorem identity22509 : scanCanonicalize (H12AffineFastState.compose env22509 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74030) := by decide +kernel

theorem selectedBound22509 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22510 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,65536,1296,262144,16657,32769,1296,58769,17664,98565,8328,16,303493,16385,1296,75787,1284,74030,257,17680,1297,512]

theorem envBound22510 : H12AffineFastState.Bounded env22510 := by
  intro p hp
  have h : env22510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22509_22510 : H12AffineEnvironment.transform 31 74030 env22509 = env22510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74030 env22509 == env22510) = true)

def env22511 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1296,41089,16,98565,8328,16,303493,1297,1296,75787,1284,74030,257,0,1297,512]

theorem envBound22511 : H12AffineFastState.Bounded env22511 := by
  intro p hp
  have h : env22511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22510_22511 : H12AffineEnvironment.transform 13 1296 env22510 = env22511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env22510 == env22511) = true)

theorem identity22511 : scanCanonicalize (H12AffineFastState.compose env22511 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22511 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22512 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,43049,1025,32769,1296,41089,16,98565,8328,16,2476,1297,1296,75787,1284,74030,257,0,1297,512]

theorem envBound22512 : H12AffineFastState.Bounded env22512 := by
  intro p hp
  have h : env22512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22511_22512 : H12AffineEnvironment.transform 17 43049 env22511 = env22512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22511 == env22512) = true)

theorem identity22512 : scanCanonicalize (H12AffineFastState.compose env22512 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2479) := by decide +kernel

theorem selectedBound22512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22513 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,2479,1296,43049,1025,32769,1296,41089,16,34986,8328,16,2476,1297,1296,8612,1284,10369,257,0,1297,512]

theorem envBound22513 : H12AffineFastState.Bounded env22513 := by
  intro p hp
  have h : env22513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22512_22513 : H12AffineEnvironment.transform 15 2479 env22512 = env22513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2479 env22512 == env22513) = true)

theorem identity22513 : scanCanonicalize (H12AffineFastState.compose env22513 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound22513 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env22514 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,2081,2479,1296,8200,1025,2080,1296,10400,16,139,8328,16,2476,1297,1296,8612,1284,10369,257,0,1297,512]

theorem envBound22514 : H12AffineFastState.Bounded env22514 := by
  intro p hp
  have h : env22514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22513_22514 : H12AffineEnvironment.transform 14 2081 env22513 = env22514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env22513 == env22514) = true)

theorem identity22514 : scanCanonicalize (H12AffineFastState.compose env22514 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2468) := by decide +kernel

theorem selectedBound22514 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22515 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2468,1296,2081,2479,1296,2476,1025,2080,1296,260,16,139,2348,16,2476,1297,1296,2048,1284,293,257,0,1297,512]

theorem envBound22515 : H12AffineFastState.Bounded env22515 := by
  intro p hp
  have h : env22515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22514_22515 : H12AffineEnvironment.transform 12 2468 env22514 = env22515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2468 env22514 == env22515) = true)

theorem identity22515 : scanCanonicalize (H12AffineFastState.compose env22515 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22515 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22516 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,2208,1044,2081,2219,1044,2216,1025,2080,1044,0,16,139,2088,16,2216,1045,1044,2048,1024,33,5,0,1045,512]

theorem envBound22516 : H12AffineFastState.Bounded env22516 := by
  intro p hp
  have h : env22516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22515_22516 : H12AffineEnvironment.transform 7 4 env22515 = env22516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22515 == env22516) = true)

theorem identity22516 : scanCanonicalize (H12AffineFastState.compose env22516 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22517 : List Nat := [2,4,8,16,32,16,128,4,0,1024,2048,1045,2208,1044,2081,2219,1044,2216,1025,2080,1044,0,16,139,2088,16,2216,1045,1044,2048,1024,33,5,0,1045,0]

theorem envBound22517 : H12AffineFastState.Bounded env22517 := by
  intro p hp
  have h : env22517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22516_22517 : H12AffineEnvironment.transform 8 0 env22516 = env22517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22516 == env22517) = true)

theorem identity22517 : scanCanonicalize (H12AffineFastState.compose env22517 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22518 : List Nat := [2,4,8,16,32,16,8,4,0,1024,2048,1045,2088,1044,2081,2083,1044,2080,1025,2080,1044,0,16,3,2088,16,2080,1045,1044,2048,1024,33,5,0,1045,0]

theorem envBound22518 : H12AffineFastState.Bounded env22518 := by
  intro p hp
  have h : env22518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22517_22518 : H12AffineEnvironment.transform 6 8 env22517 = env22518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22517 == env22518) = true)

def leafEnv22518 : List Nat := [2,4,8,16,32,16,8,4,0,1024,2048,1045,2088,1044,2081,2083,1044,2080,1025,2080,1044,0,16,3,1025,2088,1,16,2080,1045,1044,2048,1024,33,5,0,5,2082,1045,0,0,1045,1]

def active22518 : List Nat := [0,1,2,3,4,9,10]

def tree22518 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22518 : H12WitnessSearch.Good tree22518 := H12GlobalWitnessIndex.good

theorem leafIdentity22518 : H12AffineFastState.composeSystem env22518 rootObs = leafEnv22518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22518 rootObs == leafEnv22518) = true)

theorem terminalChecked22518 : H12PackedTerminal.terminalCheckFast leafEnv22518 active22518 tree22518 = true := by decide +kernel

def env22519 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1024,32769,1296,41088,17,98565,8328,16,303493,1296,1296,75787,1284,74030,257,1,1297,512]

theorem envBound22519 : H12AffineFastState.Bounded env22519 := by
  intro p hp
  have h : env22519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22510_22519 : H12AffineEnvironment.transform 13 1297 env22510 = env22519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env22510 == env22519) = true)

theorem identity22519 : scanCanonicalize (H12AffineFastState.compose env22519 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound22519 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22520 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33543,1296,262144,1024,32769,1296,41088,17,514,8328,16,303493,1296,1296,43788,1284,41513,257,1,1297,512]

theorem envBound22520 : H12AffineFastState.Bounded env22520 := by
  intro p hp
  have h : env22520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22519_22520 : H12AffineEnvironment.transform 15 33543 env22519 = env22520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env22519 == env22520) = true)

theorem identity22520 : scanCanonicalize (H12AffineFastState.compose env22520 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22520 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22521 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33543,1296,43048,1024,32769,1296,41088,17,514,8328,16,2477,1296,1296,43788,1284,41513,257,1,1297,512]

theorem envBound22521 : H12AffineFastState.Bounded env22521 := by
  intro p hp
  have h : env22521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22520_22521 : H12AffineEnvironment.transform 17 43048 env22520 = env22521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22520 == env22521) = true)

theorem identity22521 : scanCanonicalize (H12AffineFastState.compose env22521 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 8591) := by decide +kernel

theorem selectedBound22521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22522 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,8591,8840,1296,2471,1024,8590,1296,271,17,514,8328,16,2477,1296,1296,2691,1284,934,257,1,1297,512]

theorem envBound22522 : H12AffineFastState.Bounded env22522 := by
  intro p hp
  have h : env22522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22521_22522 : H12AffineEnvironment.transform 14 8591 env22521 = env22522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8591 env22521 == env22522) = true)

theorem identity22522 : scanCanonicalize (H12AffineFastState.compose env22522 (packedSelected [10] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound22522 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env22523 : List Nat := [2,4,8,16,32,16,128,256,11,1024,2048,1297,8192,1297,8591,8323,1296,2471,1024,8590,1296,271,17,9,8328,16,2477,1296,1296,2184,1284,429,257,1,1297,11]

theorem envBound22523 : H12AffineFastState.Bounded env22523 := by
  intro p hp
  have h : env22523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22522_22523 : H12AffineEnvironment.transform 8 11 env22522 = env22523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env22522 == env22523) = true)

theorem identity22523 : scanCanonicalize (H12AffineFastState.compose env22523 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound22523 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env22524 : List Nat := [2,4,8,16,32,16,128,256,11,1024,2048,1297,2082,1297,2477,2209,1296,2471,1024,2476,1296,271,17,9,2218,16,2477,1296,1296,2184,1284,429,257,1,1297,11]

theorem envBound22524 : H12AffineFastState.Bounded env22524 := by
  intro p hp
  have h : env22524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22523_22524 : H12AffineEnvironment.transform 12 2082 env22523 = env22524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env22523 == env22524) = true)

theorem identity22524 : scanCanonicalize (H12AffineFastState.compose env22524 (packedSelected [3,13] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22524 : packedSelected [3,13] rootPS < 2^1333 := by decide +kernel

def env22525 : List Nat := [2,4,8,16,32,16,2,256,11,1024,2048,1297,2082,1297,2351,2083,1296,2341,1024,2350,1296,271,17,9,2088,16,2351,1296,1296,2058,1284,303,257,1,1297,11]

theorem envBound22525 : H12AffineFastState.Bounded env22525 := by
  intro p hp
  have h : env22525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22524_22525 : H12AffineEnvironment.transform 6 2 env22524 = env22525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22524 == env22525) = true)

theorem identity22525 : scanCanonicalize (H12AffineFastState.compose env22525 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22525 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22526 : List Nat := [2,4,2,16,32,16,2,256,1,1024,2048,1297,2082,1297,2341,2083,1296,2341,1024,2340,1296,261,17,3,2082,16,2341,1296,1296,2048,1284,293,257,1,1297,1]

theorem envBound22526 : H12AffineFastState.Bounded env22526 := by
  intro p hp
  have h : env22526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22525_22526 : H12AffineEnvironment.transform 2 2 env22525 = env22526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22525 == env22526) = true)

def env22527 : List Nat := [2,4,2,16,0,16,2,256,1,1024,2048,1297,2050,1297,2309,2051,1296,2309,1024,2308,1296,261,17,3,2050,16,2309,1296,1296,2048,1284,261,257,1,1297,1]

theorem envBound22527 : H12AffineFastState.Bounded env22527 := by
  intro p hp
  have h : env22527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22526_22527 : H12AffineEnvironment.transform 4 0 env22526 = env22527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22526 == env22527) = true)

theorem identity22527 : scanCanonicalize (H12AffineFastState.compose env22527 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22528 : List Nat := [2,4,2,0,0,0,2,256,1,1024,2048,1281,2050,1281,2309,2051,1280,2309,1024,2308,1280,261,1,3,2050,0,2309,1280,1280,2048,1284,261,257,1,1281,1]

theorem envBound22528 : H12AffineFastState.Bounded env22528 := by
  intro p hp
  have h : env22528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22527_22528 : H12AffineEnvironment.transform 3 0 env22527 = env22528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22527 == env22528) = true)

def leafEnv22528 : List Nat := [2,4,2,0,0,0,2,256,1,1024,2048,1281,2050,1281,2309,2051,1280,2309,1024,2308,1280,261,1,3,1284,2050,1,0,2309,1280,1280,2048,1284,261,257,1,5,2050,1281,1,0,1281,1]

def active22528 : List Nat := [0,1,7,9,10]

def tree22528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22528 : H12WitnessSearch.Good tree22528 := H12GlobalWitnessIndex.good

theorem leafIdentity22528 : H12AffineFastState.composeSystem env22528 rootObs = leafEnv22528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22528 rootObs == leafEnv22528) = true)

theorem terminalChecked22528 : H12PackedTerminal.terminalCheckFast leafEnv22528 active22528 tree22528 = true := by decide +kernel

def env22529 : List Nat := [2,4,2,16,1,16,2,256,1,1024,2048,1297,2051,1297,2308,2050,1296,2308,1024,2309,1296,261,17,3,2051,16,2308,1296,1296,2048,1284,260,257,1,1297,1]

theorem envBound22529 : H12AffineFastState.Bounded env22529 := by
  intro p hp
  have h : env22529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22526_22529 : H12AffineEnvironment.transform 4 1 env22526 = env22529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22526 == env22529) = true)

theorem identity22529 : scanCanonicalize (H12AffineFastState.compose env22529 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22530 : List Nat := [2,4,2,16,1,16,2,20,1,1024,2048,1029,2051,1029,2064,2050,1028,2064,1024,2065,1028,17,17,3,2051,16,2064,1028,1028,2048,1040,16,21,1,1029,1]

theorem envBound22530 : H12AffineFastState.Bounded env22530 := by
  intro p hp
  have h : env22530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22529_22530 : H12AffineEnvironment.transform 7 20 env22529 = env22530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22529 == env22530) = true)

def leafEnv22530 : List Nat := [2,4,2,16,1,16,2,20,1,1024,2048,1029,2051,1029,2064,2050,1028,2064,1024,2065,1028,17,17,3,1040,2051,1,16,2064,1028,1028,2048,1040,16,21,1,5,2051,1029,1,0,1029,1]

def active22530 : List Nat := [0,1,3,9,10]

def tree22530 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22530 : H12WitnessSearch.Good tree22530 := H12GlobalWitnessIndex.good

theorem leafIdentity22530 : H12AffineFastState.composeSystem env22530 rootObs = leafEnv22530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22530 rootObs == leafEnv22530) = true)

theorem terminalChecked22530 : H12PackedTerminal.terminalCheckFast leafEnv22530 active22530 tree22530 = true := by decide +kernel

def env22531 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21504,32769,4097,4194304,17664,98565,8328,5376,4477188,16385,1297,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22531 : H12AffineFastState.Bounded env22531 := by
  intro p hp
  have h : env22531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22305_22531 : H12AffineEnvironment.transform 5 17 env22305 = env22531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22305 == env22531) = true)

theorem identity22531 : scanCanonicalize (H12AffineFastState.compose env22531 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(31+1) ^^^ 1074004877) := by decide +kernel

theorem selectedBound22531 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env22532 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21504,32769,4097,4194304,17664,98565,8328,5376,4477188,16385,1297,1073741824,1284,1074004877,257,1078297122,1297,512]

theorem envBound22532 : H12AffineFastState.Bounded env22532 := by
  intro p hp
  have h : env22532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22531_22532 : H12AffineEnvironment.transform 31 1074004877 env22531 = env22532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074004877 env22531 == env22532) = true)

theorem identity22532 : scanCanonicalize (H12AffineFastState.compose env22532 (packedSelected [9,22] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound22532 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env22533 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4096,1297,1073741824,1284,1074004877,257,1078297122,1297,512]

theorem envBound22533 : H12AffineFastState.Bounded env22533 := by
  intro p hp
  have h : env22533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22532_22533 : H12AffineEnvironment.transform 13 4097 env22532 = env22533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env22532 == env22533) = true)

theorem identity22533 : scanCanonicalize (H12AffineFastState.compose env22533 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4227617) := by decide +kernel

theorem selectedBound22533 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env22534 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4096,1297,4227617,1284,4489644,257,327683,1297,512]

theorem envBound22534 : H12AffineFastState.Bounded env22534 := by
  intro p hp
  have h : env22534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22533_22534 : H12AffineEnvironment.transform 29 4227617 env22533 = env22534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227617 env22533 == env22534) = true)

theorem identity22534 : scanCanonicalize (H12AffineFastState.compose env22534 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 305964) := by decide +kernel

theorem selectedBound22534 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env22535 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,305964,5377,98565,8328,5376,43561,4096,1297,272653,1284,10880,257,327683,1297,512]

theorem envBound22535 : H12AffineFastState.Bounded env22535 := by
  intro p hp
  have h : env22535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22534_22535 : H12AffineEnvironment.transform 21 305964 env22534 = env22535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305964 env22534 == env22535) = true)

theorem identity22535 : scanCanonicalize (H12AffineFastState.compose env22535 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 33417) := by decide +kernel

theorem selectedBound22535 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env22536 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,33417,1025,32769,4097,10661,5377,98565,8328,5376,43561,4096,1297,43908,1284,10880,257,98954,1297,512]

theorem envBound22536 : H12AffineFastState.Bounded env22536 := by
  intro p hp
  have h : env22536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22535_22536 : H12AffineEnvironment.transform 17 33417 env22535 = env22536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33417 env22535 == env22536) = true)

theorem identity22536 : scanCanonicalize (H12AffineFastState.compose env22536 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound22536 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env22537 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,8581,65536,1297,8972,1025,8580,4097,10661,5377,73856,8328,5376,2988,4096,1297,2561,1284,10880,257,74511,1297,512]

theorem envBound22537 : H12AffineFastState.Bounded env22537 := by
  intro p hp
  have h : env22537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22536_22537 : H12AffineEnvironment.transform 14 8581 env22536 = env22537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env22536 == env22537) = true)

theorem identity22537 : scanCanonicalize (H12AffineFastState.compose env22537 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound22537 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22538 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2720,4097,2853,65536,1297,2476,1025,2852,4097,773,5377,68128,2600,5376,2988,4096,1297,2561,1284,32,257,68015,1297,512]

theorem envBound22538 : H12AffineFastState.Bounded env22538 := by
  intro p hp
  have h : env22538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22537_22538 : H12AffineEnvironment.transform 12 2720 env22537 = env22538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env22537 == env22538) = true)

theorem identity22538 : scanCanonicalize (H12AffineFastState.compose env22538 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound22538 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22539 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1725,2720,1724,2853,65536,1297,2476,1025,2852,1724,773,956,68128,2600,957,2988,1725,1297,2561,1284,32,257,68015,1297,512]

theorem envBound22539 : H12AffineFastState.Bounded env22539 := by
  intro p hp
  have h : env22539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22538_22539 : H12AffineEnvironment.transform 11 1725 env22538 = env22539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env22538 == env22539) = true)

theorem identity22539 : scanCanonicalize (H12AffineFastState.compose env22539 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound22539 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env22540 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,2316,1296,2185,65536,1297,2476,1025,2184,1296,169,16,67980,2436,17,2048,1297,1297,2477,1284,32,257,68015,1297,428]

theorem envBound22540 : H12AffineFastState.Bounded env22540 := by
  intro p hp
  have h : env22540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22539_22540 : H12AffineEnvironment.transform 8 428 env22539 = env22540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env22539 == env22540) = true)

theorem identity22540 : scanCanonicalize (H12AffineFastState.compose env22540 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound22540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22541 : List Nat := [2,4,8,16,32,17,128,256,428,1024,1212,1297,1456,1296,1077,65536,1297,1296,1025,1076,1296,169,16,66864,1336,17,1212,1297,1297,1297,1284,32,257,66835,1297,428]

theorem envBound22541 : H12AffineFastState.Bounded env22541 := by
  intro p hp
  have h : env22541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22540_22541 : H12AffineEnvironment.transform 10 1212 env22540 = env22541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env22540 == env22541) = true)

theorem identity22541 : scanCanonicalize (H12AffineFastState.compose env22541 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound22541 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env22542 : List Nat := [2,4,8,16,32,17,128,256,428,31,163,270,431,271,42,65536,270,271,30,43,271,169,16,65839,295,17,163,270,270,270,283,32,257,65804,270,428]

theorem envBound22542 : H12AffineFastState.Bounded env22542 := by
  intro p hp
  have h : env22542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22541_22542 : H12AffineEnvironment.transform 9 31 env22541 = env22542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env22541 == env22542) = true)

theorem identity22542 : scanCanonicalize (H12AffineFastState.compose env22542 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 9) := by decide +kernel

theorem selectedBound22542 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22543 : List Nat := [2,4,8,16,32,17,128,256,428,31,163,270,431,271,42,9,270,271,30,43,271,169,16,294,295,17,163,270,270,270,283,32,257,261,270,428]

theorem envBound22543 : H12AffineFastState.Bounded env22543 := by
  intro p hp
  have h : env22543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22542_22543 : H12AffineEnvironment.transform 15 9 env22542 = env22543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env22542 == env22543) = true)

theorem identity22543 : scanCanonicalize (H12AffineFastState.compose env22543 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound22543 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22544 : List Nat := [2,4,8,16,32,17,128,189,17,31,163,179,18,178,42,9,179,178,30,43,178,169,16,155,154,17,163,179,179,179,166,32,188,184,179,17]

theorem envBound22544 : H12AffineFastState.Bounded env22544 := by
  intro p hp
  have h : env22544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22543_22544 : H12AffineEnvironment.transform 7 189 env22543 = env22544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env22543 == env22544) = true)

theorem identity22544 : scanCanonicalize (H12AffineFastState.compose env22544 (packedSelected [0,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22544 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env22545 : List Nat := [2,4,8,1,32,0,128,172,0,14,163,162,3,163,42,9,162,163,15,43,163,169,1,138,139,0,163,162,162,162,166,32,173,169,162,0]

theorem envBound22545 : H12AffineFastState.Bounded env22545 := by
  intro p hp
  have h : env22545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22544_22545 : H12AffineEnvironment.transform 3 1 env22544 = env22545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22544 == env22545) = true)

theorem identity22545 : scanCanonicalize (H12AffineFastState.compose env22545 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound22545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22546 : List Nat := [2,4,8,1,32,0,35,15,0,14,0,1,3,0,42,9,1,0,15,43,0,10,1,41,40,0,0,1,1,1,5,32,14,10,1,0]

theorem envBound22546 : H12AffineFastState.Bounded env22546 := by
  intro p hp
  have h : env22546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22545_22546 : H12AffineEnvironment.transform 6 35 env22545 = env22546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env22545 == env22546) = true)

theorem identity22546 : scanCanonicalize (H12AffineFastState.compose env22546 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22547 : List Nat := [2,4,3,1,32,0,35,4,0,5,0,1,3,0,33,2,1,0,4,32,0,1,1,34,35,0,0,1,1,1,5,32,5,1,1,0]

theorem envBound22547 : H12AffineFastState.Bounded env22547 := by
  intro p hp
  have h : env22547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22546_22547 : H12AffineEnvironment.transform 2 3 env22546 = env22547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22546 == env22547) = true)

def env22548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21505,32769,4097,4194304,17664,98565,8328,5456,4477269,16385,1345,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22548 : H12AffineFastState.Bounded env22548 := by
  intro p hp
  have h : env22548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22304_22548 : H12AffineEnvironment.transform 18 21505 env22304 = env22548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env22304 == env22548) = true)

theorem identity22548 : scanCanonicalize (H12AffineFastState.compose env22548 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22548 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22549 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21505,32769,4097,4194304,17664,98565,8328,5377,4477188,16385,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22549 : H12AffineFastState.Bounded env22549 := by
  intro p hp
  have h : env22549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22548_22549 : H12AffineEnvironment.transform 5 17 env22548 = env22549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22548 == env22549) = true)

def env22550 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,16384,32768,65536,1297,262144,16657,32769,1297,4194304,17664,98565,8328,17,4473876,16385,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22550 : H12AffineFastState.Bounded env22550 := by
  intro p hp
  have h : env22550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22549_22550 : H12AffineEnvironment.transform 11 1296 env22549 = env22550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22549 == env22550) = true)

def env22551 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1297,4194304,16,98565,8328,17,4456708,1297,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22551 : H12AffineFastState.Bounded env22551 := by
  intro p hp
  have h : env22551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22550_22551 : H12AffineEnvironment.transform 13 1296 env22550 = env22551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env22550 == env22551) = true)

theorem identity22551 : scanCanonicalize (H12AffineFastState.compose env22551 (packedSelected [1,10] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound22551 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env22552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1297,4194304,16,98565,8328,17,4456708,1297,1296,4294794,1284,4294967296,257,4299260335,1296,512]

theorem envBound22552 : H12AffineFastState.Bounded env22552 := by
  intro p hp
  have h : env22552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22551_22552 : H12AffineEnvironment.transform 29 4294794 env22551 = env22552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env22551 == env22552) = true)

theorem identity22552 : scanCanonicalize (H12AffineFastState.compose env22552 (packedSelected [3,12] rootPS)) = affineNative (2^(31+1) ^^^ 98599) := by decide +kernel

theorem selectedBound22552 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env22553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1297,4194304,16,98565,8328,17,4456708,1297,1296,4294794,1284,98599,257,4194440,1296,512]

theorem envBound22553 : H12AffineFastState.Bounded env22553 := by
  intro p hp
  have h : env22553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22552_22553 : H12AffineEnvironment.transform 31 98599 env22552 = env22553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98599 env22552 == env22553) = true)

def env22554 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,65536,1,262144,273,32769,1,4194304,16,98565,8328,17,4456708,1,0,4294794,20,98599,257,4194440,0,512]

theorem envBound22554 : H12AffineFastState.Bounded env22554 := by
  intro p hp
  have h : env22554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22553_22554 : H12AffineEnvironment.transform 9 272 env22553 = env22554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22553 == env22554) = true)

theorem identity22554 : scanCanonicalize (H12AffineFastState.compose env22554 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound22554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22555 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,1,262144,273,32769,1,4194304,16,139,8328,17,4456708,1,0,4196612,20,169,257,4194440,0,512]

theorem envBound22555 : H12AffineFastState.Bounded env22555 := by
  intro p hp
  have h : env22555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22554_22555 : H12AffineEnvironment.transform 15 33166 env22554 = env22555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env22554 == env22555) = true)

theorem identity22555 : scanCanonicalize (H12AffineFastState.compose env22555 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22555 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22556 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,1,43049,273,32769,1,4194304,16,139,8328,17,4237613,1,0,4196612,20,169,257,4194440,0,512]

theorem envBound22556 : H12AffineFastState.Bounded env22556 := by
  intro p hp
  have h : env22556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22555_22556 : H12AffineEnvironment.transform 17 43049 env22555 = env22556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22555 == env22556) = true)

def env22557 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,1,43049,273,32769,1,41088,16,139,8328,17,2477,1,0,43396,20,169,257,40968,0,512]

theorem envBound22557 : H12AffineFastState.Bounded env22557 := by
  intro p hp
  have h : env22557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22556_22557 : H12AffineEnvironment.transform 21 41088 env22556 = env22557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env22556 == env22557) = true)

theorem identity22557 : scanCanonicalize (H12AffineFastState.compose env22557 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22557 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22558 : List Nat := [2,4,8,16,32,17,128,4,512,20,2048,0,8192,0,32768,32906,1,43049,21,32769,1,41088,16,139,8328,17,2217,1,0,43136,20,169,5,40968,0,512]

theorem envBound22558 : H12AffineFastState.Bounded env22558 := by
  intro p hp
  have h : env22558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22557_22558 : H12AffineEnvironment.transform 7 4 env22557 = env22558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22557 == env22558) = true)

def env22559 : List Nat := [2,4,8,16,0,17,128,4,512,20,2048,0,8192,0,32768,32906,1,43017,21,32769,1,41088,16,139,8328,17,2185,1,0,43136,20,137,5,40968,0,512]

theorem envBound22559 : H12AffineFastState.Bounded env22559 := by
  intro p hp
  have h : env22559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22558_22559 : H12AffineEnvironment.transform 4 0 env22558 = env22559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22558 == env22559) = true)

theorem identity22559 : scanCanonicalize (H12AffineFastState.compose env22559 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22560 : List Nat := [2,4,8,16,0,17,128,4,0,20,2048,0,8192,0,32768,32906,1,43017,21,32769,1,41088,16,139,8328,17,2185,1,0,43136,20,137,5,40968,0,0]

theorem envBound22560 : H12AffineFastState.Bounded env22560 := by
  intro p hp
  have h : env22560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22559_22560 : H12AffineEnvironment.transform 8 0 env22559 = env22560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22559 == env22560) = true)

def env22561 : List Nat := [2,4,8,16,0,17,128,4,0,20,2048,0,8192,0,2048,2186,1,8201,21,2049,1,10368,16,139,8328,17,2185,1,0,8320,20,137,5,10248,0,0]

theorem envBound22561 : H12AffineFastState.Bounded env22561 := by
  intro p hp
  have h : env22561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22560_22561 : H12AffineEnvironment.transform 14 2048 env22560 = env22561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env22560 == env22561) = true)

theorem identity22561 : scanCanonicalize (H12AffineFastState.compose env22561 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22562 : List Nat := [2,4,8,16,0,17,9,4,0,20,2048,0,8192,0,2048,2051,1,8201,21,2049,1,10249,16,2,8193,17,2048,1,0,8201,20,0,5,10248,0,0]

theorem envBound22562 : H12AffineFastState.Bounded env22562 := by
  intro p hp
  have h : env22562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22561_22562 : H12AffineEnvironment.transform 6 9 env22561 = env22562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22561 == env22562) = true)

def env22563 : List Nat := [2,4,8,16,0,17,128,4,0,20,2048,0,8192,0,2049,2187,1,8200,21,2048,1,10369,16,139,8328,17,2185,1,0,8321,20,137,5,10249,0,0]

theorem envBound22563 : H12AffineFastState.Bounded env22563 := by
  intro p hp
  have h : env22563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22560_22563 : H12AffineEnvironment.transform 14 2049 env22560 = env22563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env22560 == env22563) = true)

theorem identity22563 : scanCanonicalize (H12AffineFastState.compose env22563 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound22563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2