import H12CloudChart2Data144

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound36080 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36081 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6282,1212,2195,3253,1213,7221,4284,2194,4096,1061,16,4147,3262,5293,6328,1212,1213,2185,4117,1197,173,1196,1212,5821]

theorem envBound36081 : H12AffineFastState.Bounded env36081 := by
  intro p hp
  have h : env36081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36080_36081 : H12AffineEnvironment.transform 16 1213 env36080 = env36081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1213 env36080 == env36081) = true)

theorem identity36081 : scanCanonicalize (H12AffineFastState.compose env36081 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 525) := by decide +kernel

theorem selectedBound36081 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env36082 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,525,2695,1212,2195,3253,1213,3640,689,2194,525,1061,16,574,3262,1696,2741,1212,1213,2185,536,1197,173,1196,1212,1200]

theorem envBound36082 : H12AffineFastState.Bounded env36082 := by
  intro p hp
  have h : env36082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36081_36082 : H12AffineEnvironment.transform 11 525 env36081 = env36082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 525 env36081 == env36082) = true)

theorem identity36082 : scanCanonicalize (H12AffineFastState.compose env36082 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound36082 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env36083 : List Nat := [2,4,8,16,32,17,52,25,512,1024,2048,525,2611,1032,2087,3073,1033,3640,517,2086,525,1061,16,574,3082,1556,2561,1032,1033,2109,536,1049,25,1048,1032,1028]

theorem envBound36083 : H12AffineFastState.Bounded env36083 := by
  intro p hp
  have h : env36083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36082_36083 : H12AffineEnvironment.transform 6 52 env36082 = env36083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env36082 == env36083) = true)

theorem identity36083 : scanCanonicalize (H12AffineFastState.compose env36083 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1555) := by decide +kernel

theorem selectedBound36083 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36084 : List Nat := [2,4,8,16,32,17,52,25,512,1024,1555,525,1056,1032,1588,530,1033,43,517,1589,525,1061,16,574,537,1556,1042,1032,1033,1582,536,1049,25,1048,1032,1028]

theorem envBound36084 : H12AffineFastState.Bounded env36084 := by
  intro p hp
  have h : env36084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36083_36084 : H12AffineEnvironment.transform 10 1555 env36083 = env36084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1555 env36083 == env36084) = true)

theorem identity36084 : scanCanonicalize (H12AffineFastState.compose env36084 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 547) := by decide +kernel

theorem selectedBound36084 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36085 : List Nat := [2,4,8,16,32,17,52,25,512,547,48,525,515,555,23,530,554,43,517,22,525,518,16,574,537,55,561,555,554,13,536,570,25,571,555,551]

theorem envBound36085 : H12AffineFastState.Bounded env36085 := by
  intro p hp
  have h : env36085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36084_36085 : H12AffineEnvironment.transform 9 547 env36084 = env36085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 547 env36084 == env36085) = true)

theorem identity36085 : scanCanonicalize (H12AffineFastState.compose env36085 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound36085 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env36086 : List Nat := [2,4,8,16,28,17,8,25,512,543,12,525,515,535,23,530,534,23,517,22,525,518,16,514,537,11,525,535,534,13,536,518,25,519,535,539]

theorem envBound36086 : H12AffineFastState.Bounded env36086 := by
  intro p hp
  have h : env36086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36085_36086 : H12AffineEnvironment.transform 4 28 env36085 = env36086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env36085 == env36086) = true)

theorem identity36086 : scanCanonicalize (H12AffineFastState.compose env36086 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36086 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env36087 : List Nat := [2,4,8,16,28,17,8,25,1,30,12,12,2,22,23,19,23,23,4,22,12,7,16,3,24,11,12,22,23,13,25,7,25,6,22,26]

theorem envBound36087 : H12AffineFastState.Bounded env36087 := by
  intro p hp
  have h : env36087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36086_36087 : H12AffineEnvironment.transform 8 1 env36086 = env36087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36086 == env36087) = true)

def env36088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245633,148801,545089,96347,16876544,17495098,256,131136,1345,525825]

theorem envBound36088 : H12AffineFastState.Bounded env36088 := by
  intro p hp
  have h : env36088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35966_36088 : H12AffineEnvironment.transform 26 17245633 env35966 = env36088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env35966 == env36088) = true)

theorem identity36088 : scanCanonicalize (H12AffineFastState.compose env36088 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound36088 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717114,533640,672784,906491,148801,545089,96347,750906,1280,256,131136,1345,525825]

theorem envBound36089 : H12AffineFastState.Bounded env36089 := by
  intro p hp
  have h : env36089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36088_36089 : H12AffineEnvironment.transform 23 717114 env36088 = env36089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env36088 == env36089) = true)

def env36090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58682,143496,20496,508155,148801,148801,96347,90426,1280,256,131136,1345,135681]

theorem envBound36090 : H12AffineFastState.Bounded env36090 := by
  intro p hp
  have h : env36090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36089_36090 : H12AffineEnvironment.transform 18 136192 env36089 = env36090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env36089 == env36090) = true)

def env36091 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143496,20496,508155,148717,148717,96347,90262,1196,172,131136,1261,135681]

theorem envBound36091 : H12AffineFastState.Bounded env36091 := by
  intro p hp
  have h : env36091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36090_36091 : H12AffineEnvironment.transform 7 172 env36090 = env36091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env36090 == env36091) = true)

def env36092 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143496,20496,508075,148669,148669,96267,90262,1196,172,131088,1213,135681]

theorem envBound36092 : H12AffineFastState.Bounded env36092 := by
  intro p hp
  have h : env36092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36091_36092 : H12AffineEnvironment.transform 5 16 env36091 = env36092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36091 == env36092) = true)

theorem identity36092 : scanCanonicalize (H12AffineFastState.compose env36092 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound36092 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36093 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,58518,143496,20496,120867,148669,148669,96267,90262,1196,172,131088,1213,135681]

theorem envBound36093 : H12AffineFastState.Bounded env36093 := by
  intro p hp
  have h : env36093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36092_36093 : H12AffineEnvironment.transform 17 137352 env36092 = env36093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env36092 == env36093) = true)

theorem identity36093 : scanCanonicalize (H12AffineFastState.compose env36093 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound36093 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36094 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4096,61569,46092,58518,50324,20496,120867,45217,45217,96267,90262,1196,172,62476,1213,58909]

theorem envBound36094 : H12AffineFastState.Bounded env36094 := by
  intro p hp
  have h : env36094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36093_36094 : H12AffineEnvironment.transform 16 62492 env36093 = env36094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env36093 == env36094) = true)

theorem identity36094 : scanCanonicalize (H12AffineFastState.compose env36094 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound36094 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36095 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,33831,62492,60564,57372,32769,4096,61569,46092,58518,50324,20496,23556,45217,45217,64556,58545,1196,172,62476,1213,58909]

theorem envBound36095 : H12AffineFastState.Bounded env36095 := by
  intro p hp
  have h : env36095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36094_36095 : H12AffineEnvironment.transform 15 33831 env36094 = env36095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env36094 == env36095) = true)

theorem identity36095 : scanCanonicalize (H12AffineFastState.compose env36095 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(14+1) ^^^ 7733) := by decide +kernel

theorem selectedBound36095 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env36096 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,7733,6674,27177,29345,32297,7732,4096,28340,10809,31395,23201,20496,23556,11924,11924,25113,31364,1196,172,27193,1213,30760]

theorem envBound36096 : H12AffineFastState.Bounded env36096 := by
  intro p hp
  have h : env36096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36095_36096 : H12AffineEnvironment.transform 14 7733 env36095 = env36096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7733 env36095 == env36096) = true)

theorem identity36096 : scanCanonicalize (H12AffineFastState.compose env36096 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound36096 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env36097 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5125,7733,6674,15916,9892,10796,7732,4096,15025,10809,11942,3748,1045,2049,11924,11924,13852,11905,1196,172,15932,1213,11309]

theorem envBound36097 : H12AffineFastState.Bounded env36097 := by
  intro p hp
  have h : env36097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36096_36097 : H12AffineEnvironment.transform 13 5125 env36096 = env36097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env36096 == env36097) = true)

theorem identity36097 : scanCanonicalize (H12AffineFastState.compose env36097 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 7709) := by decide +kernel

theorem selectedBound36097 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36098 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7709,5125,7733,6674,49,6329,5169,7732,4096,1196,5156,4283,3748,1045,2049,4233,4233,2049,4252,1196,172,33,1213,4656]

theorem envBound36098 : H12AffineFastState.Bounded env36098 := by
  intro p hp
  have h : env36098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36097_36098 : H12AffineEnvironment.transform 12 7709 env36097 = env36098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7709 env36097 == env36098) = true)

theorem identity36098 : scanCanonicalize (H12AffineFastState.compose env36098 (packedSelected [1,2,4,5,6,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound36098 : packedSelected [1,2,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env36099 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1190,2747,163,2707,3764,49,3103,151,2706,1190,1196,130,1053,3748,1045,2049,1071,1071,2049,1082,1196,172,33,1213,1686]

theorem envBound36099 : H12AffineFastState.Bounded env36099 := by
  intro p hp
  have h : env36099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36098_36099 : H12AffineEnvironment.transform 11 1190 env36098 = env36099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env36098 == env36099) = true)

theorem identity36099 : scanCanonicalize (H12AffineFastState.compose env36099 (packedSelected [0,2,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound36099 : packedSelected [0,2,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36100 : List Nat := [2,4,8,16,32,16,128,172,512,663,2048,561,2747,163,2707,2083,49,2696,151,2706,561,571,130,650,2099,642,2049,696,696,2049,685,571,172,33,554,1]

theorem envBound36100 : H12AffineFastState.Bounded env36100 := by
  intro p hp
  have h : env36100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36099_36100 : H12AffineEnvironment.transform 9 663 env36099 = env36100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env36099 == env36100) = true)

theorem identity36100 : scanCanonicalize (H12AffineFastState.compose env36100 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36100 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env36101 : List Nat := [2,4,8,16,32,16,9,37,512,542,2048,561,2610,42,2586,2083,49,2561,30,2587,561,571,11,515,2099,523,2049,561,561,2049,548,571,37,33,554,1]

theorem envBound36101 : H12AffineFastState.Bounded env36101 := by
  intro p hp
  have h : env36101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36100_36101 : H12AffineEnvironment.transform 6 9 env36100 = env36101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36100 == env36101) = true)

theorem identity36101 : scanCanonicalize (H12AffineFastState.compose env36101 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36101 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env36102 : List Nat := [2,4,8,16,32,16,9,37,1,31,2048,48,2099,42,2075,2083,49,2048,30,2074,48,58,11,2,2099,10,2049,48,48,2049,37,58,37,33,43,1]

theorem envBound36102 : H12AffineFastState.Bounded env36102 := by
  intro p hp
  have h : env36102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36101_36102 : H12AffineEnvironment.transform 8 1 env36101 = env36102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36101 == env36102) = true)

theorem identity36102 : scanCanonicalize (H12AffineFastState.compose env36102 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound36102 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36103 : List Nat := [2,4,8,16,32,16,9,37,1,31,42,48,25,42,49,9,49,42,30,48,48,58,11,2,25,10,43,48,48,43,37,58,37,33,43,1]

theorem envBound36103 : H12AffineFastState.Bounded env36103 := by
  intro p hp
  have h : env36103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36102_36103 : H12AffineEnvironment.transform 10 42 env36102 = env36103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env36102 == env36103) = true)

theorem identity36103 : scanCanonicalize (H12AffineFastState.compose env36103 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36104 : List Nat := [2,4,8,16,17,16,9,20,1,31,27,1,25,27,0,9,0,27,30,1,1,11,11,2,25,10,26,1,1,26,20,11,20,16,26,1]

theorem envBound36104 : H12AffineFastState.Bounded env36104 := by
  intro p hp
  have h : env36104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36103_36104 : H12AffineEnvironment.transform 4 17 env36103 = env36104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36103 == env36104) = true)

theorem identity36104 : scanCanonicalize (H12AffineFastState.compose env36104 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36105 : List Nat := [2,4,4,16,17,16,5,20,1,19,23,1,21,23,0,5,0,23,18,1,1,7,7,2,21,6,22,1,1,22,20,7,20,16,22,1]

theorem envBound36105 : H12AffineFastState.Bounded env36105 := by
  intro p hp
  have h : env36105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36104_36105 : H12AffineEnvironment.transform 2 4 env36104 = env36105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36104 == env36105) = true)

def env36106 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143496,20496,508074,148668,148668,96266,90262,1196,172,131089,1212,135681]

theorem envBound36106 : H12AffineFastState.Bounded env36106 := by
  intro p hp
  have h : env36106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36091_36106 : H12AffineEnvironment.transform 5 17 env36091 = env36106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36091 == env36106) = true)

theorem identity36106 : scanCanonicalize (H12AffineFastState.compose env36106 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound36106 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36107 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,58518,32808,20496,356362,62492,62492,96266,90262,1196,172,45233,1212,41633]

theorem envBound36107 : H12AffineFastState.Bounded env36107 := by
  intro p hp
  have h : env36107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36106_36107 : H12AffineEnvironment.transform 16 45216 env36106 = env36107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env36106 == env36107) = true)

theorem identity36107 : scanCanonicalize (H12AffineFastState.compose env36107 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound36107 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36108 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4096,61568,61617,58518,32808,20496,96386,62492,62492,96266,90262,1196,172,45233,1212,41633]

theorem envBound36108 : H12AffineFastState.Bounded env36108 := by
  intro p hp
  have h : env36108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36107_36108 : H12AffineEnvironment.transform 17 2184 env36107 = env36108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env36107 == env36108) = true)

theorem identity36108 : scanCanonicalize (H12AffineFastState.compose env36108 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound36108 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36109 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,65536,40985,2184,42144,32769,185,57401,57352,58518,32808,16553,92219,58533,58533,92339,90262,1196,172,40968,1212,41633]

theorem envBound36109 : H12AffineFastState.Bounded env36109 := by
  intro p hp
  have h : env36109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36108_36109 : H12AffineEnvironment.transform 11 185 env36108 = env36109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env36108 == env36109) = true)

theorem identity36109 : scanCanonicalize (H12AffineFastState.compose env36109 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound36109 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env36110 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,9350,40985,2184,42144,32769,185,57401,57352,58518,32808,16553,19645,58533,58533,19509,17424,1196,172,40968,1212,41633]

theorem envBound36110 : H12AffineFastState.Bounded env36110 := by
  intro p hp
  have h : env36110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36109_36110 : H12AffineEnvironment.transform 15 9350 env36109 = env36110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env36109 == env36110) = true)

theorem identity36110 : scanCanonicalize (H12AffineFastState.compose env36110 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(13+1) ^^^ 10265) := by decide +kernel

theorem selectedBound36110 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env36111 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,10265,32768,9350,40985,2184,42144,32769,185,34848,34833,35983,32808,10416,9380,36028,36028,9260,11273,1196,172,40968,1212,41633]

theorem envBound36111 : H12AffineFastState.Bounded env36111 := by
  intro p hp
  have h : env36111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36110_36111 : H12AffineEnvironment.transform 13 10265 env36110 = env36111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10265 env36110 == env36111) = true)

theorem identity36111 : scanCanonicalize (H12AffineFastState.compose env36111 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound36111 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env36112 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,3612,1541,32768,2714,36357,2184,35516,32769,185,34848,34833,35983,32808,1708,2744,36028,36028,2608,533,1196,172,36372,1212,36029]

theorem envBound36112 : H12AffineFastState.Bounded env36112 := by
  intro p hp
  have h : env36112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36111_36112 : H12AffineEnvironment.transform 12 3612 env36111 = env36112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env36111 == env36112) = true)

theorem identity36112 : scanCanonicalize (H12AffineFastState.compose env36112 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound36112 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env36113 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1077,185,553,1541,32768,1711,33328,1213,34441,32769,185,33813,33828,32954,32808,1708,1677,32905,32905,1541,533,1196,172,33313,1212,32904]

theorem envBound36113 : H12AffineFastState.Bounded env36113 := by
  intro p hp
  have h : env36113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36112_36113 : H12AffineEnvironment.transform 10 1077 env36112 = env36113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env36112 == env36113) = true)

theorem identity36113 : scanCanonicalize (H12AffineFastState.compose env36113 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36113 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env36114 : List Nat := [2,4,8,16,10,17,128,134,512,1024,1055,147,515,1541,32768,1669,33306,1175,34441,32769,147,33813,33806,32912,32770,1670,1677,32905,32905,1541,533,1158,134,33291,1174,32904]

theorem envBound36114 : H12AffineFastState.Bounded env36114 := by
  intro p hp
  have h : env36114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36113_36114 : H12AffineEnvironment.transform 4 10 env36113 = env36114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36113 == env36114) = true)

theorem identity36114 : scanCanonicalize (H12AffineFastState.compose env36114 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound36114 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env36115 : List Nat := [2,4,8,16,10,17,128,134,147,1024,1055,147,144,1174,32768,1046,32905,1175,33818,32769,147,33813,33806,32912,32770,1045,1054,32905,32905,1174,134,1158,134,32920,1174,32904]

theorem envBound36115 : H12AffineFastState.Bounded env36115 := by
  intro p hp
  have h : env36115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36114_36115 : H12AffineEnvironment.transform 8 147 env36114 = env36115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env36114 == env36115) = true)

theorem identity36115 : scanCanonicalize (H12AffineFastState.compose env36115 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound36115 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36116 : List Nat := [2,4,8,16,10,17,128,134,147,5,26,147,144,147,32768,19,32905,146,32799,32769,147,32784,32779,32912,32770,16,27,32905,32905,147,134,131,134,32920,147,32904]

theorem envBound36116 : H12AffineFastState.Bounded env36116 := by
  intro p hp
  have h : env36116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36115_36116 : H12AffineEnvironment.transform 9 5 env36115 = env36116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env36115 == env36116) = true)

theorem identity36116 : scanCanonicalize (H12AffineFastState.compose env36116 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36116 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36117 : List Nat := [2,4,8,16,10,17,128,134,147,5,26,147,144,147,1,19,136,146,30,0,147,17,10,145,3,16,27,136,136,147,134,131,134,153,147,137]

theorem envBound36117 : H12AffineFastState.Bounded env36117 := by
  intro p hp
  have h : env36117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36116_36117 : H12AffineEnvironment.transform 14 1 env36116 = env36117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36116 == env36117) = true)

theorem identity36117 : scanCanonicalize (H12AffineFastState.compose env36117 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound36117 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env36118 : List Nat := [2,4,8,12,10,13,128,134,143,5,6,143,140,143,1,15,136,142,2,0,143,13,10,141,3,12,7,136,136,143,134,131,134,133,143,137]

theorem envBound36118 : H12AffineFastState.Bounded env36118 := by
  intro p hp
  have h : env36118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36117_36118 : H12AffineEnvironment.transform 3 12 env36117 = env36118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env36117 == env36118) = true)

theorem identity36118 : scanCanonicalize (H12AffineFastState.compose env36118 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36118 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36119 : List Nat := [2,4,8,12,10,13,9,15,6,5,6,6,5,6,1,15,1,7,2,0,6,13,10,4,3,12,7,1,1,6,15,10,15,12,6,0]

theorem envBound36119 : H12AffineFastState.Bounded env36119 := by
  intro p hp
  have h : env36119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36118_36119 : H12AffineEnvironment.transform 6 9 env36118 = env36119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36118 == env36119) = true)

theorem identity36119 : scanCanonicalize (H12AffineFastState.compose env36119 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36120 : List Nat := [2,2,8,10,10,11,9,9,0,3,0,0,3,0,1,9,1,1,2,0,0,11,10,2,3,10,1,1,1,0,9,10,9,10,0,0]

theorem envBound36120 : H12AffineFastState.Bounded env36120 := by
  intro p hp
  have h : env36120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36119_36120 : H12AffineEnvironment.transform 1 2 env36119 = env36120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36119 == env36120) = true)

def env36121 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143496,20496,508155,148716,148716,96347,90263,1197,173,131136,1260,135681]

theorem envBound36121 : H12AffineFastState.Bounded env36121 := by
  intro p hp
  have h : env36121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36090_36121 : H12AffineEnvironment.transform 7 173 env36090 = env36121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36090 == env36121) = true)

def env36122 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143496,20496,508075,148668,148668,96267,90263,1197,173,131088,1212,135681]

theorem envBound36122 : H12AffineFastState.Bounded env36122 := by
  intro p hp
  have h : env36122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36121_36122 : H12AffineEnvironment.transform 5 16 env36121 = env36122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36121 == env36122) = true)

theorem identity36122 : scanCanonicalize (H12AffineFastState.compose env36122 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound36122 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36123 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61569,147472,58519,143496,20496,60445,148668,148668,96267,90263,1197,173,131088,1212,135681]

theorem envBound36123 : H12AffineFastState.Bounded env36123 := by
  intro p hp
  have h : env36123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36122_36123 : H12AffineEnvironment.transform 17 208054 env36122 = env36123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env36122 == env36123) = true)

theorem identity36123 : scanCanonicalize (H12AffineFastState.compose env36123 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound36123 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env36124 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4096,61569,147472,58519,143496,20496,60445,148668,148668,43048,45236,1197,173,131088,1212,135681]

theorem envBound36124 : H12AffineFastState.Bounded env36124 := by
  intro p hp
  have h : env36124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36123_36124 : H12AffineEnvironment.transform 15 53283 env36123 = env36124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env36123 == env36124) = true)

theorem identity36124 : scanCanonicalize (H12AffineFastState.compose env36124 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound36124 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36125 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4096,61569,5293,58519,25653,20496,60445,4097,4097,43048,45236,1197,173,21677,1212,18108]

theorem envBound36125 : H12AffineFastState.Bounded env36125 := by
  intro p hp
  have h : env36125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36124_36125 : H12AffineEnvironment.transform 16 21693 env36124 = env36125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env36124 == env36125) = true)

theorem identity36125 : scanCanonicalize (H12AffineFastState.compose env36125 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound36125 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env36126 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,32768,33831,185,43048,5305,32769,4096,42117,5293,45203,12337,1044,47129,4097,4097,43048,45236,1197,173,169,1212,4792]

theorem envBound36126 : H12AffineFastState.Bounded env36126 := by
  intro p hp
  have h : env36126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36125_36126 : H12AffineEnvironment.transform 13 5124 env36125 = env36126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env36125 == env36126) = true)

theorem identity36126 : scanCanonicalize (H12AffineFastState.compose env36126 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 4792) := by decide +kernel

theorem selectedBound36126 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env36127 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,4792,5791,185,14992,5305,4793,4096,13885,5293,8747,12337,1044,10913,4097,4097,14992,8716,1197,173,169,1212,4792]

theorem envBound36127 : H12AffineFastState.Bounded env36127 := by
  intro p hp
  have h : env36127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36126_36127 : H12AffineEnvironment.transform 14 4792 env36126 = env36127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4792 env36126 == env36127) = true)

theorem identity36127 : scanCanonicalize (H12AffineFastState.compose env36127 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound36127 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env36128 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1175,4096,8192,5124,4792,5791,185,13831,5305,4793,4096,13885,5293,8747,12337,1044,9782,4097,4097,13831,8716,1197,173,169,1212,4792]

theorem envBound36128 : H12AffineFastState.Bounded env36128 := by
  intro p hp
  have h : env36128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36127_36128 : H12AffineEnvironment.transform 10 1175 env36127 = env36128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env36127 == env36128) = true)

theorem identity36128 : scanCanonicalize (H12AffineFastState.compose env36128 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound36128 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env36129 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1175,4096,1684,5124,4792,5791,185,4243,5305,4793,4096,4265,5293,1215,5797,1044,162,4097,4097,4243,1176,1197,173,169,1212,4792]

theorem envBound36129 : H12AffineFastState.Bounded env36129 := by
  intro p hp
  have h : env36129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36128_36129 : H12AffineEnvironment.transform 12 1684 env36128 = env36129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env36128 == env36129) = true)

theorem identity36129 : scanCanonicalize (H12AffineFastState.compose env36129 (packedSelected [0,1,5,6,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound36129 : packedSelected [0,1,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env36130 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1175,1724,1684,696,1028,35,185,1583,517,1029,1724,1557,529,1215,25,1044,162,1725,1725,1583,1176,1197,173,169,1212,1028]

theorem envBound36130 : H12AffineFastState.Bounded env36130 := by
  intro p hp
  have h : env36130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36129_36130 : H12AffineEnvironment.transform 11 1724 env36129 = env36130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env36129 == env36130) = true)

theorem identity36130 : scanCanonicalize (H12AffineFastState.compose env36130 (packedSelected [3,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound36130 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env36131 : List Nat := [2,4,8,16,32,16,128,173,512,700,555,0,40,696,696,35,185,147,517,697,0,169,529,515,25,680,162,1,1,147,548,529,173,169,512,696]

theorem envBound36131 : H12AffineFastState.Bounded env36131 := by
  intro p hp
  have h : env36131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36130_36131 : H12AffineEnvironment.transform 9 700 env36130 = env36131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env36130 == env36131) = true)

theorem identity36131 : scanCanonicalize (H12AffineFastState.compose env36131 (packedSelected [3,5,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36131 : packedSelected [3,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36132 : List Nat := [2,4,8,16,10,16,128,135,512,662,513,0,2,658,658,9,147,147,517,659,0,131,529,515,25,642,136,1,1,147,526,529,135,131,512,658]

theorem envBound36132 : H12AffineFastState.Bounded env36132 := by
  intro p hp
  have h : env36132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36131_36132 : H12AffineEnvironment.transform 4 10 env36131 = env36132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36131 == env36132) = true)

theorem identity36132 : scanCanonicalize (H12AffineFastState.compose env36132 (packedSelected [1,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound36132 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env36133 : List Nat := [2,4,8,16,10,16,128,135,147,5,146,0,2,1,1,9,147,147,150,0,0,131,130,144,25,17,136,1,1,147,157,130,135,131,147,1]

theorem envBound36133 : H12AffineFastState.Bounded env36133 := by
  intro p hp
  have h : env36133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36132_36133 : H12AffineEnvironment.transform 8 147 env36132 = env36133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env36132 == env36133) = true)

theorem identity36133 : scanCanonicalize (H12AffineFastState.compose env36133 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36133 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36134 : List Nat := [2,4,8,16,10,16,18,21,1,5,0,0,2,1,1,9,1,1,4,0,0,17,16,2,25,17,26,1,1,1,15,16,21,17,1,1]

theorem envBound36134 : H12AffineFastState.Bounded env36134 := by
  intro p hp
  have h : env36134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36133_36134 : H12AffineEnvironment.transform 6 18 env36133 = env36134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36133 == env36134) = true)

theorem identity36134 : scanCanonicalize (H12AffineFastState.compose env36134 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36134 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36135 : List Nat := [2,4,8,11,10,11,9,14,1,5,0,0,2,1,1,9,1,1,4,0,0,10,11,2,2,10,1,1,1,1,15,11,14,10,1,1]

theorem envBound36135 : H12AffineFastState.Bounded env36135 := by
  intro p hp
  have h : env36135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36134_36135 : H12AffineEnvironment.transform 3 11 env36134 = env36135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36134 == env36135) = true)

theorem identity36135 : scanCanonicalize (H12AffineFastState.compose env36135 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36136 : List Nat := [2,2,8,11,10,11,9,8,1,3,0,0,2,1,1,9,1,1,2,0,0,10,11,2,2,10,1,1,1,1,9,11,8,10,1,1]

theorem envBound36136 : H12AffineFastState.Bounded env36136 := by
  intro p hp
  have h : env36136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36135_36136 : H12AffineEnvironment.transform 1 2 env36135 = env36136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36135 == env36136) = true)

def env36137 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143496,20496,508074,148669,148669,96266,90263,1197,173,131089,1213,135681]

theorem envBound36137 : H12AffineFastState.Bounded env36137 := by
  intro p hp
  have h : env36137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36121_36137 : H12AffineEnvironment.transform 5 17 env36121 = env36137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36121 == env36137) = true)

theorem identity36137 : scanCanonicalize (H12AffineFastState.compose env36137 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound36137 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36138 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61568,115854,58519,111639,20496,279605,114722,114722,96266,90263,1197,173,99470,1213,104094]

theorem envBound36138 : H12AffineFastState.Bounded env36138 := by
  intro p hp
  have h : env36138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36137_36138 : H12AffineEnvironment.transform 16 99487 env36137 = env36138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env36137 == env36138) = true)

theorem identity36138 : scanCanonicalize (H12AffineFastState.compose env36138 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound36138 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env36139 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,49307,17412,262144,20484,32769,4096,61568,1045,58519,29836,20496,279605,185,185,47249,40972,1197,173,17429,1213,22021]

theorem envBound36139 : H12AffineFastState.Bounded env36139 := by
  intro p hp
  have h : env36139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36138_36139 : H12AffineEnvironment.transform 15 49307 env36138 = env36139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env36138 == env36139) = true)

theorem identity36139 : scanCanonicalize (H12AffineFastState.compose env36139 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound36139 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36140 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5125,32768,38046,4097,262144,1025,32769,4096,42117,1045,45202,8329,1045,266288,185,185,47249,40972,1197,173,4112,1213,512]

theorem envBound36140 : H12AffineFastState.Bounded env36140 := by
  intro p hp
  have h : env36140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36139_36140 : H12AffineEnvironment.transform 13 5125 env36139 = env36140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env36139 == env36140) = true)

theorem identity36140 : scanCanonicalize (H12AffineFastState.compose env36140 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound36140 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36141 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,32768,33831,184,262144,1025,32769,185,42117,1045,41003,8329,1045,262281,185,185,43048,40972,1197,173,169,1213,512]

theorem envBound36141 : H12AffineFastState.Bounded env36141 := by
  intro p hp
  have h : env36141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36140_36141 : H12AffineEnvironment.transform 11 185 env36140 = env36141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env36140 == env36141) = true)

theorem identity36141 : scanCanonicalize (H12AffineFastState.compose env36141 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound36141 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36142 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,561,1558,184,262144,1025,560,185,9908,1045,8730,8329,1045,262281,185,185,10777,8765,1197,173,169,1213,512]

theorem envBound36142 : H12AffineFastState.Bounded env36142 := by
  intro p hp
  have h : env36142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36141_36142 : H12AffineEnvironment.transform 14 561 env36141 = env36142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env36141 == env36142) = true)

theorem identity36142 : scanCanonicalize (H12AffineFastState.compose env36142 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 11804) := by decide +kernel

theorem selectedBound36142 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env36143 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,561,1558,184,11804,1025,560,185,9908,1045,8730,8329,1045,11925,185,185,10777,8765,1197,173,169,1213,512]

theorem envBound36143 : H12AffineFastState.Bounded env36143 := by
  intro p hp
  have h : env36143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36142_36143 : H12AffineEnvironment.transform 17 11804 env36142 = env36143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11804 env36142 == env36143) = true)

theorem identity36143 : scanCanonicalize (H12AffineFastState.compose env36143 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound36143 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36144 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2098,1212,561,1558,184,1582,1025,560,185,3718,1045,2600,2235,1045,1703,185,185,555,2575,1197,173,169,1213,512]

theorem envBound36144 : H12AffineFastState.Bounded env36144 := by
  intro p hp
  have h : env36144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36143_36144 : H12AffineEnvironment.transform 12 2098 env36143 = env36144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env36143 == env36144) = true)

theorem identity36144 : scanCanonicalize (H12AffineFastState.compose env36144 (packedSelected [1,3,17] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound36144 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env36145 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1703,185,1685,1212,561,1558,184,1582,1025,560,185,33,1045,1167,1564,1045,1703,185,185,555,1192,1197,173,169,1213,512]

theorem envBound36145 : H12AffineFastState.Bounded env36145 := by
  intro p hp
  have h : env36145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36144_36145 : H12AffineEnvironment.transform 10 1703 env36144 = env36145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env36144 == env36145) = true)

theorem identity36145 : scanCanonicalize (H12AffineFastState.compose env36145 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound36145 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36146 : List Nat := [2,4,8,16,32,17,128,173,512,517,162,185,144,697,561,19,184,43,516,560,185,33,528,650,25,528,162,185,185,555,685,680,173,169,696,512]

theorem envBound36146 : H12AffineFastState.Bounded env36146 := by
  intro p hp
  have h : env36146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36145_36146 : H12AffineEnvironment.transform 9 517 env36145 = env36146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env36145 == env36146) = true)

theorem identity36146 : scanCanonicalize (H12AffineFastState.compose env36146 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound36146 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36147 : List Nat := [2,4,8,16,32,17,128,173,27,30,162,185,144,162,42,19,184,43,31,43,185,33,11,145,25,11,162,185,185,48,182,179,173,169,163,27]

theorem envBound36147 : H12AffineFastState.Bounded env36147 := by
  intro p hp
  have h : env36147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36146_36147 : H12AffineEnvironment.transform 8 27 env36146 = env36147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env36146 == env36147) = true)

theorem identity36147 : scanCanonicalize (H12AffineFastState.compose env36147 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36147 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env36148 : List Nat := [2,4,8,16,32,17,18,63,27,30,48,43,2,48,42,19,42,43,31,43,43,33,11,3,25,11,48,43,43,48,36,33,63,59,49,27]

theorem envBound36148 : H12AffineFastState.Bounded env36148 := by
  intro p hp
  have h : env36148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36147_36148 : H12AffineEnvironment.transform 6 18 env36147 = env36148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36147 == env36148) = true)

def env36149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58683,143497,20497,508154,148801,148800,96347,90427,1280,256,131136,1345,135680]

theorem envBound36149 : H12AffineFastState.Bounded env36149 := by
  intro p hp
  have h : env36149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36089_36149 : H12AffineEnvironment.transform 18 136193 env36089 = env36149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env36089 == env36149) = true)

def env36150 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143497,20497,508154,148717,148716,96347,90263,1196,172,131136,1261,135680]

theorem envBound36150 : H12AffineFastState.Bounded env36150 := by
  intro p hp
  have h : env36150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36149_36150 : H12AffineEnvironment.transform 7 172 env36149 = env36150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env36149 == env36150) = true)

def env36151 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143497,20497,508074,148669,148668,96267,90263,1196,172,131088,1213,135680]

theorem envBound36151 : H12AffineFastState.Bounded env36151 := by
  intro p hp
  have h : env36151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36150_36151 : H12AffineEnvironment.transform 5 16 env36150 = env36151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36150 == env36151) = true)

theorem identity36151 : scanCanonicalize (H12AffineFastState.compose env36151 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound36151 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36152 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,58519,32808,20497,356363,62492,62493,96267,90263,1196,172,45233,1213,41633]

theorem envBound36152 : H12AffineFastState.Bounded env36152 := by
  intro p hp
  have h : env36152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36151_36152 : H12AffineEnvironment.transform 16 45217 env36151 = env36152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env36151 == env36152) = true)

theorem identity36152 : scanCanonicalize (H12AffineFastState.compose env36152 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound36152 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36153 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4096,61569,61617,58519,32808,20497,96387,62492,62493,96267,90263,1196,172,45233,1213,41633]

theorem envBound36153 : H12AffineFastState.Bounded env36153 := by
  intro p hp
  have h : env36153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36152_36153 : H12AffineEnvironment.transform 17 2184 env36152 = env36153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env36152 == env36153) = true)

theorem identity36153 : scanCanonicalize (H12AffineFastState.compose env36153 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound36153 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36154 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,65536,40985,2184,42144,32769,184,57401,57353,58519,32808,16553,92219,58532,58533,92339,90263,1196,172,40969,1213,41633]

theorem envBound36154 : H12AffineFastState.Bounded env36154 := by
  intro p hp
  have h : env36154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36153_36154 : H12AffineEnvironment.transform 11 184 env36153 = env36154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env36153 == env36154) = true)

theorem identity36154 : scanCanonicalize (H12AffineFastState.compose env36154 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound36154 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env36155 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,9351,40985,2184,42144,32769,184,57401,57353,58519,32808,16553,19644,58532,58533,19508,17424,1196,172,40969,1213,41633]

theorem envBound36155 : H12AffineFastState.Bounded env36155 := by
  intro p hp
  have h : env36155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36154_36155 : H12AffineEnvironment.transform 15 9351 env36154 = env36155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env36154 == env36155) = true)

theorem identity36155 : scanCanonicalize (H12AffineFastState.compose env36155 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound36155 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env36156 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,3237,16384,32768,2082,36028,2184,34821,32769,184,52380,52396,51250,32808,16553,19644,51201,51200,19508,17424,1196,172,36012,1213,36356]

theorem envBound36156 : H12AffineFastState.Bounded env36156 := by
  intro p hp
  have h : env36156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36155_36156 : H12AffineEnvironment.transform 12 3237 env36155 = env36156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env36155 == env36156) = true)

theorem identity36156 : scanCanonicalize (H12AffineFastState.compose env36156 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 18944) := by decide +kernel

theorem selectedBound36156 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env36157 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,3237,16384,18944,2082,18108,2184,16901,18945,184,1692,1708,562,18984,16553,19644,513,512,19508,17424,1196,172,18092,1213,17412]

theorem envBound36157 : H12AffineFastState.Bounded env36157 := by
  intro p hp
  have h : env36157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36156_36157 : H12AffineEnvironment.transform 14 18944 env36156 = env36157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18944 env36156 == env36157) = true)

theorem identity36157 : scanCanonicalize (H12AffineFastState.compose env36157 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound36157 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env36158 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,3237,2185,649,2082,3637,2184,2700,648,184,1692,1708,562,673,2080,1077,513,512,1213,3225,1196,172,3621,1213,3213]

theorem envBound36158 : H12AffineFastState.Bounded env36158 := by
  intro p hp
  have h : env36158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36157_36158 : H12AffineEnvironment.transform 13 2185 env36157 = env36158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env36157 == env36158) = true)

theorem identity36158 : scanCanonicalize (H12AffineFastState.compose env36158 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound36158 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env36159 : List Nat := [2,4,8,16,32,16,128,172,512,140,2048,184,2089,2185,649,2082,2745,2184,2700,648,184,528,544,562,673,2080,185,513,512,49,2069,32,172,2729,49,2049]

theorem envBound36159 : H12AffineFastState.Bounded env36159 := by
  intro p hp
  have h : env36159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36158_36159 : H12AffineEnvironment.transform 9 140 env36158 = env36159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env36158 == env36159) = true)

theorem identity36159 : scanCanonicalize (H12AffineFastState.compose env36159 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound36159 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env36160 : List Nat := [2,4,8,16,32,16,128,172,42,140,2048,184,2089,2185,163,2082,2195,2184,2214,162,184,58,10,24,139,2080,185,43,42,49,2069,32,172,2179,49,2049]

theorem envBound36160 : H12AffineFastState.Bounded env36160 := by
  intro p hp
  have h : env36160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36159_36160 : H12AffineEnvironment.transform 8 42 env36159 = env36160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env36159 == env36160) = true)

theorem identity36160 : scanCanonicalize (H12AffineFastState.compose env36160 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36160 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env36161 : List Nat := [2,4,8,16,16,16,128,156,26,140,2048,136,2073,2185,147,2066,2195,2184,2198,146,136,10,10,24,139,2064,137,27,26,1,2069,16,156,2179,1,2049]

theorem envBound36161 : H12AffineFastState.Bounded env36161 := by
  intro p hp
  have h : env36161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36160_36161 : H12AffineEnvironment.transform 4 16 env36160 = env36161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36160 == env36161) = true)

theorem identity36161 : scanCanonicalize (H12AffineFastState.compose env36161 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36161 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36162 : List Nat := [2,4,8,16,16,16,8,20,26,4,2048,0,2073,2049,27,2066,2075,2048,2078,26,0,10,10,24,3,2064,1,27,26,1,2069,16,20,2059,1,2049]

theorem envBound36162 : H12AffineFastState.Bounded env36162 := by
  intro p hp
  have h : env36162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36161_36162 : H12AffineEnvironment.transform 6 8 env36161 = env36162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36161 == env36162) = true)

def env36163 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143497,20497,508075,148668,148669,96266,90263,1196,172,131089,1212,135680]

theorem envBound36163 : H12AffineFastState.Bounded env36163 := by
  intro p hp
  have h : env36163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36150_36163 : H12AffineEnvironment.transform 5 17 env36150 = env36163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36150 == env36163) = true)

theorem identity36163 : scanCanonicalize (H12AffineFastState.compose env36163 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound36163 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36164 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,58519,143497,20497,120866,148668,148669,96266,90263,1196,172,131089,1212,135680]

theorem envBound36164 : H12AffineFastState.Bounded env36164 := by
  intro p hp
  have h : env36164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36163_36164 : H12AffineEnvironment.transform 17 137353 env36163 = env36164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env36163 == env36164) = true)

theorem identity36164 : scanCanonicalize (H12AffineFastState.compose env36164 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound36164 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36165 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4096,61568,46093,58519,50325,20497,120866,45216,45217,96266,90263,1196,172,62477,1212,58908]

theorem envBound36165 : H12AffineFastState.Bounded env36165 := by
  intro p hp
  have h : env36165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36164_36165 : H12AffineEnvironment.transform 16 62492 env36164 = env36165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env36164 == env36165) = true)

theorem identity36165 : scanCanonicalize (H12AffineFastState.compose env36165 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound36165 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36166 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,33830,62492,60565,57373,32769,4096,61568,46093,58519,50325,20497,23556,45216,45217,64556,58545,1196,172,62477,1212,58908]

theorem envBound36166 : H12AffineFastState.Bounded env36166 := by
  intro p hp
  have h : env36166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36165_36166 : H12AffineEnvironment.transform 15 33830 env36165 = env36166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env36165 == env36166) = true)

theorem identity36166 : scanCanonicalize (H12AffineFastState.compose env36166 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 10897) := by decide +kernel

theorem selectedBound36166 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env36167 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10897,32768,33830,40589,34308,35468,32769,4096,39441,46093,36358,44548,14976,13973,45216,45217,38589,36384,1196,172,40604,1212,35981]

theorem envBound36167 : H12AffineFastState.Bounded env36167 := by
  intro p hp
  have h : env36167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36166_36167 : H12AffineEnvironment.transform 13 10897 env36166 = env36167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10897 env36166 == env36167) = true)

theorem identity36167 : scanCanonicalize (H12AffineFastState.compose env36167 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound36167 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env36168 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7828,5125,32768,33830,40589,34308,35468,32769,4096,39441,35481,36358,37008,1044,2049,36404,36405,38589,36384,1196,172,40604,1212,35981]

theorem envBound36168 : H12AffineFastState.Bounded env36168 := by
  intro p hp
  have h : env36168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36167_36168 : H12AffineEnvironment.transform 12 7828 env36167 = env36168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env36167 == env36168) = true)

theorem identity36168 : scanCanonicalize (H12AffineFastState.compose env36168 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound36168 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36169 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,49,3749,1076,32768,33830,36540,34308,35468,32769,49,35360,35481,36358,32929,1044,2049,36404,36405,34444,36384,1196,172,36525,1212,35981]

theorem envBound36169 : H12AffineFastState.Bounded env36169 := by
  intro p hp
  have h : env36169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36168_36169 : H12AffineEnvironment.transform 11 49 env36168 = env36169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36168 == env36169) = true)

theorem identity36169 : scanCanonicalize (H12AffineFastState.compose env36169 (packedSelected [0,1,3,5,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36169 : packedSelected [0,1,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36170 : List Nat := [2,4,8,16,32,17,128,172,1,1024,2048,49,3236,1076,32768,33830,36029,33797,34957,32769,49,34849,34968,35847,32929,1044,2049,35893,35892,33933,35873,1196,172,36012,1212,35981]

theorem envBound36170 : H12AffineFastState.Bounded env36170 := by
  intro p hp
  have h : env36170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36169_36170 : H12AffineEnvironment.transform 8 1 env36169 = env36170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36169 == env36170) = true)

theorem identity36170 : scanCanonicalize (H12AffineFastState.compose env36170 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound36170 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36171 : List Nat := [2,4,8,16,32,17,128,172,1,1024,2048,49,3236,1076,1070,8,2195,43,3235,1071,49,3087,3254,2089,1167,1044,2049,2075,2074,163,2063,1196,172,2178,1212,2211]

theorem envBound36171 : H12AffineFastState.Bounded env36171 := by
  intro p hp
  have h : env36171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36170_36171 : H12AffineEnvironment.transform 14 1070 env36170 = env36171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env36170 == env36171) = true)

theorem identity36171 : scanCanonicalize (H12AffineFastState.compose env36171 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36171 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env36172 : List Nat := [2,4,8,16,32,17,8,36,1,1024,2048,49,3116,1076,1070,8,2075,43,3115,1071,49,3087,3134,2089,1031,1044,2049,2075,2074,43,2063,1060,36,2058,1076,2091]

theorem envBound36172 : H12AffineFastState.Bounded env36172 := by
  intro p hp
  have h : env36172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36171_36172 : H12AffineEnvironment.transform 6 8 env36171 = env36172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36171 == env36172) = true)

theorem identity36172 : scanCanonicalize (H12AffineFastState.compose env36172 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound36172 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env36173 : List Nat := [2,4,8,16,32,17,8,36,1,31,2048,49,2099,43,49,8,2075,43,2100,48,49,2064,2081,2089,24,11,2049,2075,2074,43,2063,59,36,2058,43,2091]

theorem envBound36173 : H12AffineFastState.Bounded env36173 := by
  intro p hp
  have h : env36173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36172_36173 : H12AffineEnvironment.transform 9 31 env36172 = env36173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env36172 == env36173) = true)

theorem identity36173 : scanCanonicalize (H12AffineFastState.compose env36173 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound36173 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36174 : List Nat := [2,4,8,16,32,17,8,36,1,31,48,49,3,43,49,8,43,43,4,48,49,32,17,25,24,11,49,43,42,43,63,59,36,58,43,27]

theorem envBound36174 : H12AffineFastState.Bounded env36174 := by
  intro p hp
  have h : env36174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36173_36174 : H12AffineEnvironment.transform 10 48 env36173 = env36174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env36173 == env36174) = true)

theorem identity36174 : scanCanonicalize (H12AffineFastState.compose env36174 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36174 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36175 : List Nat := [2,2,8,16,32,17,8,34,1,25,48,49,3,43,49,8,43,43,2,48,49,32,17,25,24,11,49,43,42,43,57,59,34,58,43,27]

theorem envBound36175 : H12AffineFastState.Bounded env36175 := by
  intro p hp
  have h : env36175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36174_36175 : H12AffineEnvironment.transform 1 2 env36174 = env36175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36174 == env36175) = true)

theorem identity36175 : scanCanonicalize (H12AffineFastState.compose env36175 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36175 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36176 : List Nat := [2,2,8,11,32,10,8,34,1,2,43,42,3,43,42,8,43,43,2,43,42,32,10,2,3,11,42,43,42,43,34,32,34,33,43,0]

theorem envBound36176 : H12AffineFastState.Bounded env36176 := by
  intro p hp
  have h : env36176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36175_36176 : H12AffineEnvironment.transform 3 11 env36175 = env36176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36175 == env36176) = true)

theorem identity36176 : scanCanonicalize (H12AffineFastState.compose env36176 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36177 : List Nat := [2,2,1,2,32,3,1,34,1,2,34,35,3,34,35,1,34,34,2,34,35,32,3,2,3,2,35,34,35,34,34,32,34,33,34,0]

theorem envBound36177 : H12AffineFastState.Bounded env36177 := by
  intro p hp
  have h : env36177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36176_36177 : H12AffineEnvironment.transform 2 1 env36176 = env36177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36176 == env36177) = true)

theorem identity36177 : scanCanonicalize (H12AffineFastState.compose env36177 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound36177 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36178 : List Nat := [2,2,1,2,3,3,1,1,1,2,1,0,3,1,0,1,1,1,2,1,0,3,3,2,3,2,0,1,0,1,1,3,1,2,1,0]

theorem envBound36178 : H12AffineFastState.Bounded env36178 := by
  intro p hp
  have h : env36178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36177_36178 : H12AffineEnvironment.transform 4 3 env36177 = env36178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env36177 == env36178) = true)

theorem identity36178 : scanCanonicalize (H12AffineFastState.compose env36178 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36178 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36179 : List Nat := [0,0,1,0,1,1,1,1,1,0,1,0,1,1,0,1,1,1,0,1,0,1,1,0,1,0,0,1,0,1,1,1,1,0,1,0]

theorem envBound36179 : H12AffineFastState.Bounded env36179 := by
  intro p hp
  have h : env36179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36178_36179 : H12AffineEnvironment.transform 0 0 env36178 = env36179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36178 == env36179) = true)

def env36180 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143497,20497,508154,148716,148717,96347,90262,1197,173,131136,1260,135680]

theorem envBound36180 : H12AffineFastState.Bounded env36180 := by
  intro p hp
  have h : env36180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36149_36180 : H12AffineEnvironment.transform 7 173 env36149 = env36180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36149 == env36180) = true)

def env36181 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143497,20497,508074,148668,148669,96267,90262,1197,173,131088,1212,135680]

theorem envBound36181 : H12AffineFastState.Bounded env36181 := by
  intro p hp
  have h : env36181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36180_36181 : H12AffineEnvironment.transform 5 16 env36180 = env36181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36180 == env36181) = true)

theorem identity36181 : scanCanonicalize (H12AffineFastState.compose env36181 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound36181 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36182 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61569,115854,58518,111639,20497,279604,114722,114723,96267,90262,1197,173,99470,1212,104094]

theorem envBound36182 : H12AffineFastState.Bounded env36182 := by
  intro p hp
  have h : env36182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36181_36182 : H12AffineEnvironment.transform 16 99486 env36181 = env36182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env36181 == env36182) = true)

theorem identity36182 : scanCanonicalize (H12AffineFastState.compose env36182 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound36182 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env36183 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,49307,17413,262144,20484,32769,4096,61569,1045,58518,29836,20497,279604,185,184,47248,40973,1197,173,17429,1212,22021]

theorem envBound36183 : H12AffineFastState.Bounded env36183 := by
  intro p hp
  have h : env36183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36182_36183 : H12AffineEnvironment.transform 15 49307 env36182 = env36183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env36182 == env36183) = true)

theorem identity36183 : scanCanonicalize (H12AffineFastState.compose env36183 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound36183 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36184 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5125,32768,38046,4096,262144,1025,32769,4096,42116,1045,45203,8329,1044,266289,185,184,47248,40973,1197,173,4112,1212,512]

theorem envBound36184 : H12AffineFastState.Bounded env36184 := by
  intro p hp
  have h : env36184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36183_36184 : H12AffineEnvironment.transform 13 5125 env36183 = env36184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env36183 == env36184) = true)

theorem identity36184 : scanCanonicalize (H12AffineFastState.compose env36184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound36184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36185 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1213,32768,33830,184,262144,1025,32769,184,42116,1045,41003,8329,1044,262281,185,184,43048,40973,1197,173,168,1212,512]

theorem envBound36185 : H12AffineFastState.Bounded env36185 := by
  intro p hp
  have h : env36185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36184_36185 : H12AffineEnvironment.transform 11 184 env36184 = env36185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env36184 == env36185) = true)

theorem identity36185 : scanCanonicalize (H12AffineFastState.compose env36185 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound36185 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36186 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,656,1213,32768,33830,184,262144,1025,32769,184,34324,1045,33467,537,1044,262281,185,184,35512,33437,1197,173,168,1212,512]

theorem envBound36186 : H12AffineFastState.Bounded env36186 := by
  intro p hp
  have h : env36186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36185_36186 : H12AffineEnvironment.transform 12 656 env36185 = env36186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env36185 == env36186) = true)

theorem identity36186 : scanCanonicalize (H12AffineFastState.compose env36186 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound36186 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env36187 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,656,1213,32768,33830,184,3213,1025,32769,184,34324,1045,33467,537,1044,3076,185,184,35512,33437,1197,173,168,1212,512]

theorem envBound36187 : H12AffineFastState.Bounded env36187 := by
  intro p hp
  have h : env36187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36186_36187 : H12AffineEnvironment.transform 17 3213 env36186 = env36187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env36186 == env36187) = true)

theorem identity36187 : scanCanonicalize (H12AffineFastState.compose env36187 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound36187 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36188 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,184,656,1213,32768,33830,184,1583,1025,32769,184,34324,1045,33467,537,1044,1702,185,184,32794,33437,1197,173,168,1212,512]

theorem envBound36188 : H12AffineFastState.Bounded env36188 := by
  intro p hp
  have h : env36188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36187_36188 : H12AffineEnvironment.transform 10 674 env36187 = env36188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env36187 == env36188) = true)

theorem identity36188 : scanCanonicalize (H12AffineFastState.compose env36188 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound36188 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env36189 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,184,656,1213,560,1558,184,1583,1025,561,184,1060,1045,139,537,1044,1702,185,184,554,173,1197,173,168,1212,512]

theorem envBound36189 : H12AffineFastState.Bounded env36189 := by
  intro p hp
  have h : env36189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36188_36189 : H12AffineEnvironment.transform 14 560 env36188 = env36189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env36188 == env36189) = true)

theorem identity36189 : scanCanonicalize (H12AffineFastState.compose env36189 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound36189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36190 : List Nat := [2,4,8,16,32,16,128,173,512,663,674,184,656,554,560,129,184,184,662,561,184,691,642,139,537,643,49,185,184,554,173,570,173,168,555,512]

theorem envBound36190 : H12AffineFastState.Bounded env36190 := by
  intro p hp
  have h : env36190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36189_36190 : H12AffineEnvironment.transform 9 663 env36189 = env36190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env36189 == env36190) = true)

theorem identity36190 : scanCanonicalize (H12AffineFastState.compose env36190 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36191 : List Nat := [2,4,8,16,32,16,8,37,512,543,554,48,536,554,560,9,48,48,542,561,48,571,522,3,537,523,49,49,48,554,37,570,37,32,555,512]

theorem envBound36191 : H12AffineFastState.Bounded env36191 := by
  intro p hp
  have h : env36191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36190_36191 : H12AffineEnvironment.transform 6 8 env36190 = env36191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36190 == env36191) = true)

theorem identity36191 : scanCanonicalize (H12AffineFastState.compose env36191 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound36191 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36192 : List Nat := [2,4,8,16,32,16,8,37,6,25,44,48,30,44,54,9,48,48,24,55,48,61,12,3,31,13,49,49,48,44,37,60,37,32,45,6]

theorem envBound36192 : H12AffineFastState.Bounded env36192 := by
  intro p hp
  have h : env36192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36191_36192 : H12AffineEnvironment.transform 8 6 env36191 = env36192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env36191 == env36192) = true)

theorem identity36192 : scanCanonicalize (H12AffineFastState.compose env36192 (packedSelected [0,1,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound36192 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env36193 : List Nat := [2,4,8,13,32,13,8,37,6,4,44,45,3,44,43,9,45,45,5,42,45,32,12,3,2,13,44,44,45,44,37,33,37,32,45,6]

theorem envBound36193 : H12AffineFastState.Bounded env36193 := by
  intro p hp
  have h : env36193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36192_36193 : H12AffineEnvironment.transform 3 13 env36192 = env36193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env36192 == env36193) = true)

theorem identity36193 : scanCanonicalize (H12AffineFastState.compose env36193 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36194 : List Nat := [2,2,8,11,32,11,8,35,0,2,42,43,3,42,43,9,43,43,3,42,43,32,10,3,2,11,42,42,43,42,35,33,35,32,43,0]

theorem envBound36194 : H12AffineFastState.Bounded env36194 := by
  intro p hp
  have h : env36194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36193_36194 : H12AffineEnvironment.transform 1 2 env36193 = env36194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36193 == env36194) = true)

def env36195 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143497,20497,508075,148669,148668,96266,90262,1197,173,131089,1213,135680]

theorem envBound36195 : H12AffineFastState.Bounded env36195 := by
  intro p hp
  have h : env36195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36180_36195 : H12AffineEnvironment.transform 5 17 env36180 = env36195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36180 == env36195) = true)

theorem identity36195 : scanCanonicalize (H12AffineFastState.compose env36195 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound36195 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36196 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61568,147473,58518,143497,20497,60444,148669,148668,96266,90262,1197,173,131089,1213,135680]

theorem envBound36196 : H12AffineFastState.Bounded env36196 := by
  intro p hp
  have h : env36196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36195_36196 : H12AffineEnvironment.transform 17 208055 env36195 = env36196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env36195 == env36196) = true)

theorem identity36196 : scanCanonicalize (H12AffineFastState.compose env36196 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound36196 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env36197 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4096,61568,147473,58518,143497,20497,60444,148669,148668,43048,45236,1197,173,131089,1213,135680]

theorem envBound36197 : H12AffineFastState.Bounded env36197 := by
  intro p hp
  have h : env36197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36196_36197 : H12AffineEnvironment.transform 15 53282 env36196 = env36197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env36196 == env36197) = true)

theorem identity36197 : scanCanonicalize (H12AffineFastState.compose env36197 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound36197 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36198 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4096,61568,5292,58518,25652,20497,60444,4096,4097,43048,45236,1197,173,21676,1213,18109]

theorem envBound36198 : H12AffineFastState.Bounded env36198 := by
  intro p hp
  have h : env36198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36197_36198 : H12AffineEnvironment.transform 16 21693 env36197 = env36198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env36197 == env36198) = true)

theorem identity36198 : scanCanonicalize (H12AffineFastState.compose env36198 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound36198 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env36199 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,32768,33830,185,43048,5304,32769,4096,42116,5292,45202,12336,1045,47128,4096,4097,43048,45236,1197,173,168,1213,4793]

theorem envBound36199 : H12AffineFastState.Bounded env36199 := by
  intro p hp
  have h : env36199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36198_36199 : H12AffineEnvironment.transform 13 5124 env36198 = env36199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env36198 == env36199) = true)

theorem identity36199 : scanCanonicalize (H12AffineFastState.compose env36199 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 4632) := by decide +kernel

theorem selectedBound36199 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env36200 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4632,5124,32768,33830,185,39472,5304,32769,4096,38556,5292,33418,552,1045,35328,4096,4097,39472,33452,1197,173,168,1213,4793]

theorem envBound36200 : H12AffineFastState.Bounded env36200 := by
  intro p hp
  have h : env36200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36199_36200 : H12AffineEnvironment.transform 12 4632 env36199 = env36200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4632 env36199 == env36200) = true)

theorem identity36200 : scanCanonicalize (H12AffineFastState.compose env36200 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 3734) := by decide +kernel

theorem selectedBound36200 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env36201 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4632,5124,3734,2736,185,5286,5304,3735,4096,6154,5292,3100,552,1045,1174,4096,4097,5286,3130,1197,173,168,1213,4793]

theorem envBound36201 : H12AffineFastState.Bounded env36201 := by
  intro p hp
  have h : env36201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36200_36201 : H12AffineEnvironment.transform 14 3734 env36200 = env36201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3734 env36200 == env36201) = true)

theorem identity36201 : scanCanonicalize (H12AffineFastState.compose env36201 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36201 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env36202 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,4096,4632,4144,2722,2736,185,4242,4236,2723,4096,6154,4248,2088,552,33,162,4096,4097,4242,2062,153,173,168,137,4793]

theorem envBound36202 : H12AffineFastState.Bounded env36202 := by
  intro p hp
  have h : env36202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36201_36202 : H12AffineEnvironment.transform 9 52 env36201 = env36202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36201 == env36202) = true)

theorem identity36202 : scanCanonicalize (H12AffineFastState.compose env36202 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound36202 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36203 : List Nat := [2,4,8,16,32,17,128,173,512,52,136,4096,4632,4144,554,568,185,4242,4236,555,4096,4226,4248,160,552,33,162,4096,4097,4242,134,153,173,168,137,4793]

theorem envBound36203 : H12AffineFastState.Bounded env36203 := by
  intro p hp
  have h : env36203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36202_36203 : H12AffineEnvironment.transform 10 136 env36202 = env36203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env36202 == env36203) = true)

theorem identity36203 : scanCanonicalize (H12AffineFastState.compose env36203 (packedSelected [1,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36203 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env36204 : List Nat := [2,4,8,16,16,17,128,157,512,4,136,4096,4632,4096,538,520,137,4242,4236,539,4096,4226,4248,144,536,17,146,4096,4097,4242,134,153,157,152,137,4745]

theorem envBound36204 : H12AffineFastState.Bounded env36204 := by
  intro p hp
  have h : env36204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36203_36204 : H12AffineEnvironment.transform 4 16 env36203 = env36204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36203 == env36204) = true)

theorem identity36204 : scanCanonicalize (H12AffineFastState.compose env36204 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound36204 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env36205 : List Nat := [2,4,8,16,16,17,128,157,512,4,136,146,650,146,538,520,137,0,30,539,146,16,10,144,536,17,146,146,147,0,134,153,157,152,137,539]

theorem envBound36205 : H12AffineFastState.Bounded env36205 := by
  intro p hp
  have h : env36205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36204_36205 : H12AffineEnvironment.transform 11 146 env36204 = env36205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env36204 == env36205) = true)

theorem identity36205 : scanCanonicalize (H12AffineFastState.compose env36205 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound36205 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env36206 : List Nat := [2,4,8,16,16,17,128,157,148,4,136,146,30,146,142,156,137,0,30,143,146,16,10,144,140,17,146,146,147,0,134,153,157,152,137,143]

theorem envBound36206 : H12AffineFastState.Bounded env36206 := by
  intro p hp
  have h : env36206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36205_36206 : H12AffineEnvironment.transform 8 148 env36205 = env36206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env36205 == env36206) = true)

theorem identity36206 : scanCanonicalize (H12AffineFastState.compose env36206 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound36206 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36207 : List Nat := [2,4,8,16,16,17,14,19,26,4,6,28,30,28,0,18,7,0,30,1,28,16,10,30,2,17,28,28,29,0,8,23,19,22,7,1]

theorem envBound36207 : H12AffineFastState.Bounded env36207 := by
  intro p hp
  have h : env36207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36206_36207 : H12AffineEnvironment.transform 6 14 env36206 = env36207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env36206 == env36207) = true)

theorem identity36207 : scanCanonicalize (H12AffineFastState.compose env36207 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36208 : List Nat := [2,2,8,16,16,17,8,19,26,2,0,26,24,26,0,18,1,0,24,1,26,16,10,24,2,17,26,26,27,0,8,17,19,16,1,1]

theorem envBound36208 : H12AffineFastState.Bounded env36208 := by
  intro p hp
  have h : env36208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36207_36208 : H12AffineEnvironment.transform 1 2 env36207 = env36208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36207 == env36208) = true)

theorem identity36208 : scanCanonicalize (H12AffineFastState.compose env36208 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36208 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36209 : List Nat := [2,2,8,10,10,11,8,9,0,2,0,0,2,0,0,8,1,0,2,1,0,10,10,2,2,11,0,0,1,0,8,11,9,10,1,1]

theorem envBound36209 : H12AffineFastState.Bounded env36209 := by
  intro p hp
  have h : env36209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36208_36209 : H12AffineEnvironment.transform 3 10 env36208 = env36209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36208 == env36209) = true)

theorem identity36209 : scanCanonicalize (H12AffineFastState.compose env36209 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36210 : List Nat := [1,1,8,9,9,8,8,9,0,1,0,0,1,0,0,8,1,0,1,1,0,9,9,1,1,8,0,0,1,0,8,8,9,9,1,1]

theorem envBound36210 : H12AffineFastState.Bounded env36210 := by
  intro p hp
  have h : env36210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36209_36210 : H12AffineEnvironment.transform 0 1 env36209 = env36210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36209 == env36210) = true)

theorem identity36210 : scanCanonicalize (H12AffineFastState.compose env36210 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36211 : List Nat := [1,1,0,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,1,1,0,1,1,1,1,0,0,0,1,0,0,0,1,1,1,1]

theorem envBound36211 : H12AffineFastState.Bounded env36211 := by
  intro p hp
  have h : env36211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36210_36211 : H12AffineEnvironment.transform 2 0 env36210 = env36211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36210 == env36211) = true)

def env36212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,134217728,148801,545088,96347,16876545,17495099,257,131136,151462016,525824]

theorem envBound36212 : H12AffineFastState.Bounded env36212 := by
  intro p hp
  have h : env36212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35965_36212 : H12AffineEnvironment.transform 24 533641 env35965 = env36212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env35965 == env36212) = true)

def env36213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245632,148801,545088,96347,16876545,17495099,257,131136,1344,525824]

theorem envBound36213 : H12AffineFastState.Bounded env36213 := by
  intro p hp
  have h : env36213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36212_36213 : H12AffineEnvironment.transform 26 17245632 env36212 = env36213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env36212 == env36213) = true)

theorem identity36213 : scanCanonicalize (H12AffineFastState.compose env36213 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound36213 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,16777216,533641,614527,17039791,90414,545088,96347,16876545,17420372,257,74799,1344,525824]

theorem envBound36214 : H12AffineFastState.Bounded env36214 := by
  intro p hp
  have h : env36214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36213_36214 : H12AffineEnvironment.transform 16 74863 env36213 = env36214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env36213 == env36214) = true)

def env36215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123164,533641,614527,385203,90414,545088,96347,25885,536904,257,74799,1344,525824]

theorem envBound36215 : H12AffineFastState.Bounded env36215 := by
  intro p hp
  have h : env36215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36214_36215 : H12AffineEnvironment.transform 23 123164 env36214 = env36215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env36214 == env36215) = true)

def env36216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123164,28889,78895,385203,90414,1296,96347,25885,25880,257,74799,1344,21072]

theorem envBound36216 : H12AffineFastState.Bounded env36216 := by
  intro p hp
  have h : env36216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36215_36216 : H12AffineEnvironment.transform 18 21584 env36215 = env36216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env36215 == env36216) = true)

theorem identity36216 : scanCanonicalize (H12AffineFastState.compose env36216 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36216 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4096,17613,91183,87296,28889,78895,349359,90414,1296,96347,25885,25880,257,74799,1344,21072]

theorem envBound36217 : H12AffineFastState.Bounded env36217 := by
  intro p hp
  have h : env36217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36216_36217 : H12AffineEnvironment.transform 14 13340 env36216 = env36217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env36216 == env36217) = true)

def env36218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4096,477,74047,69648,13769,78895,332223,74814,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound36218 : H12AffineFastState.Bounded env36218 := by
  intro p hp
  have h : env36218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36217_36218 : H12AffineEnvironment.transform 13 1296 env36217 = env36218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36217 == env36218) = true)

def env36219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4096,477,74047,69648,13769,78895,4415,74814,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound36219 : H12AffineFastState.Bounded env36219 := by
  intro p hp
  have h : env36219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36218_36219 : H12AffineEnvironment.transform 17 65664 env36218 = env36219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36218 == env36219) = true)

theorem identity36219 : scanCanonicalize (H12AffineFastState.compose env36219 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound36219 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9327,0,9455,4416,13341,4096,477,1360,13439,13769,4160,4415,81,1296,6436,8205,8200,257,64,1344,5952]

theorem envBound36220 : H12AffineFastState.Bounded env36220 := by
  intro p hp
  have h : env36220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36219_36220 : H12AffineEnvironment.transform 15 9327 env36219 = env36220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env36219 == env36220) = true)

def env36221 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,8495,0,8623,4416,12637,4096,477,16,12607,12425,4160,4415,81,80,6436,8205,8200,257,64,0,4608]

theorem envBound36221 : H12AffineFastState.Bounded env36221 := by
  intro p hp
  have h : env36221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36220_36221 : H12AffineEnvironment.transform 9 320 env36220 = env36221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36220 == env36221) = true)

theorem identity36221 : scanCanonicalize (H12AffineFastState.compose env36221 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound36221 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36222 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,4421,310,0,438,4416,4420,4096,477,16,4390,4240,4160,4415,81,80,6436,20,17,257,64,0,4608]

theorem envBound36222 : H12AffineFastState.Bounded env36222 := by
  intro p hp
  have h : env36222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36221_36222 : H12AffineEnvironment.transform 12 25 env36221 = env36222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env36221 == env36222) = true)

theorem identity36222 : scanCanonicalize (H12AffineFastState.compose env36222 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound36222 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36223 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,428,25,80,233,310,0,438,236,232,428,477,16,138,316,492,147,81,80,2184,20,17,257,64,0,940]

theorem envBound36223 : H12AffineFastState.Bounded env36223 := by
  intro p hp
  have h : env36223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36222_36223 : H12AffineEnvironment.transform 11 428 env36222 = env36223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env36222 == env36223) = true)

theorem identity36223 : scanCanonicalize (H12AffineFastState.compose env36223 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound36223 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env36224 : List Nat := [2,4,8,16,32,64,128,256,97,320,2048,428,25,80,233,310,0,438,236,232,428,477,16,138,316,492,147,81,80,2184,20,17,257,64,0,461]

theorem envBound36224 : H12AffineFastState.Bounded env36224 := by
  intro p hp
  have h : env36224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36223_36224 : H12AffineEnvironment.transform 8 97 env36223 = env36224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env36223 == env36224) = true)

theorem identity36224 : scanCanonicalize (H12AffineFastState.compose env36224 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36224 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36225 : List Nat := [2,4,8,16,32,64,128,256,97,320,80,428,25,80,233,310,0,438,236,232,428,477,16,138,316,492,147,81,80,216,20,17,257,64,0,461]

theorem envBound36225 : H12AffineFastState.Bounded env36225 := by
  intro p hp
  have h : env36225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36224_36225 : H12AffineEnvironment.transform 10 80 env36224 = env36225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36224 == env36225) = true)

theorem identity36225 : scanCanonicalize (H12AffineFastState.compose env36225 (packedSelected [0,1,2,4,8,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound36225 : packedSelected [0,1,2,4,8,10,13] rootPS < 2^1333 := by decide +kernel

def env36226 : List Nat := [2,4,8,16,32,64,34,256,97,320,80,270,25,80,75,310,0,276,78,74,270,383,16,40,316,334,49,81,80,122,20,17,257,64,0,367]

theorem envBound36226 : H12AffineFastState.Bounded env36226 := by
  intro p hp
  have h : env36226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36225_36226 : H12AffineEnvironment.transform 6 34 env36225 = env36226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env36225 == env36226) = true)

theorem identity36226 : scanCanonicalize (H12AffineFastState.compose env36226 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36226 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36227 : List Nat := [2,4,8,16,17,64,19,256,80,320,80,270,25,80,75,263,0,276,78,74,270,334,16,25,269,334,0,81,80,75,20,17,257,64,0,350]

theorem envBound36227 : H12AffineFastState.Bounded env36227 := by
  intro p hp
  have h : env36227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36226_36227 : H12AffineEnvironment.transform 4 17 env36226 = env36227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36226 == env36227) = true)

theorem identity36227 : scanCanonicalize (H12AffineFastState.compose env36227 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound36227 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36228 : List Nat := [2,4,8,16,17,64,19,68,80,4,80,74,25,80,75,67,0,80,78,74,74,10,16,25,73,10,0,81,80,75,20,17,69,64,0,26]

theorem envBound36228 : H12AffineFastState.Bounded env36228 := by
  intro p hp
  have h : env36228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36227_36228 : H12AffineEnvironment.transform 7 68 env36227 = env36228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env36227 == env36228) = true)

theorem identity36228 : scanCanonicalize (H12AffineFastState.compose env36228 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36228 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36229 : List Nat := [2,4,8,10,11,64,9,68,74,4,74,74,3,74,75,67,0,74,78,74,74,10,10,3,73,10,0,75,74,75,14,11,69,64,0,0]

theorem envBound36229 : H12AffineFastState.Bounded env36229 := by
  intro p hp
  have h : env36229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36228_36229 : H12AffineEnvironment.transform 3 10 env36228 = env36229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36228 == env36229) = true)

def env36230 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,8494,0,8622,4416,12636,4096,477,17,12606,12424,4160,4415,81,81,6436,8205,8200,257,64,1,4609]

theorem envBound36230 : H12AffineFastState.Bounded env36230 := by
  intro p hp
  have h : env36230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36220_36230 : H12AffineEnvironment.transform 9 321 env36220 = env36230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36220 == env36230) = true)

theorem identity36230 : scanCanonicalize (H12AffineFastState.compose env36230 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound36230 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36231 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,324,8192,81,8217,8494,0,8622,4,8216,324,477,17,8314,8652,260,123,81,81,2144,8205,8200,257,64,1,837]

theorem envBound36231 : H12AffineFastState.Bounded env36231 := by
  intro p hp
  have h : env36231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36230_36231 : H12AffineEnvironment.transform 11 324 env36230 = env36231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env36230 == env36231) = true)

theorem identity36231 : scanCanonicalize (H12AffineFastState.compose env36231 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound36231 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env36232 : List Nat := [2,4,8,16,32,64,128,256,512,321,538,324,8192,81,8217,8494,0,8622,4,8216,324,477,17,8314,8652,260,123,81,81,634,8205,8200,257,64,1,837]

theorem envBound36232 : H12AffineFastState.Bounded env36232 := by
  intro p hp
  have h : env36232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36231_36232 : H12AffineEnvironment.transform 10 538 env36231 = env36232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env36231 == env36232) = true)

theorem identity36232 : scanCanonicalize (H12AffineFastState.compose env36232 (packedSelected [1,2,3,4,9,10,13,17,23] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound36232 : packedSelected [1,2,3,4,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env36233 : List Nat := [2,4,8,16,32,64,128,256,49,321,43,324,8192,81,8217,8494,0,8622,4,8216,324,477,17,8314,8652,260,123,81,81,75,8205,8200,257,64,1,372]

theorem envBound36233 : H12AffineFastState.Bounded env36233 := by
  intro p hp
  have h : env36233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36232_36233 : H12AffineEnvironment.transform 8 49 env36232 = env36233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env36232 == env36233) = true)

theorem identity36233 : scanCanonicalize (H12AffineFastState.compose env36233 (packedSelected [0,1,2,4,7,8,9,11,13,16] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound36233 : packedSelected [0,1,2,4,7,8,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env36234 : List Nat := [2,4,8,16,32,64,128,256,49,321,43,324,25,81,0,311,0,439,4,1,324,477,17,99,469,260,123,81,81,75,20,17,257,64,1,372]

theorem envBound36234 : H12AffineFastState.Bounded env36234 := by
  intro p hp
  have h : env36234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36233_36234 : H12AffineEnvironment.transform 12 25 env36233 = env36234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env36233 == env36234) = true)

theorem identity36234 : scanCanonicalize (H12AffineFastState.compose env36234 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36234 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36235 : List Nat := [2,4,8,16,32,64,128,21,49,84,43,81,25,81,0,34,0,162,4,1,81,200,17,99,192,17,123,81,81,75,20,17,20,64,1,97]

theorem envBound36235 : H12AffineFastState.Bounded env36235 := by
  intro p hp
  have h : env36235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36234_36235 : H12AffineEnvironment.transform 7 21 env36234 = env36235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36234 == env36235) = true)

theorem identity36235 : scanCanonicalize (H12AffineFastState.compose env36235 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36235 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36236 : List Nat := [2,4,8,16,32,64,19,21,49,84,43,81,25,81,0,34,0,49,4,1,81,91,17,99,83,17,123,81,81,75,20,17,20,64,1,97]

theorem envBound36236 : H12AffineFastState.Bounded env36236 := by
  intro p hp
  have h : env36236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36235_36236 : H12AffineEnvironment.transform 6 19 env36235 = env36236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36235 == env36236) = true)

theorem identity36236 : scanCanonicalize (H12AffineFastState.compose env36236 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36236 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env36237 : List Nat := [2,4,8,6,32,64,5,3,39,66,43,71,15,71,0,34,0,39,4,1,71,77,7,99,69,7,109,71,71,75,2,7,2,64,1,97]

theorem envBound36237 : H12AffineFastState.Bounded env36237 := by
  intro p hp
  have h : env36237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36236_36237 : H12AffineEnvironment.transform 3 6 env36236 = env36237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36236 == env36237) = true)

def env36238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4096,477,74047,69648,13769,78895,4414,74814,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound36238 : H12AffineFastState.Bounded env36238 := by
  intro p hp
  have h : env36238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36218_36238 : H12AffineEnvironment.transform 17 65665 env36218 = env36238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36218 == env36238) = true)

theorem identity36238 : scanCanonicalize (H12AffineFastState.compose env36238 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound36238 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12590,5441,12719,4416,13341,4096,477,4113,8510,13769,1281,4414,5392,1296,3173,8205,8200,257,5377,1344,5952]

theorem envBound36239 : H12AffineFastState.Bounded env36239 := by
  intro p hp
  have h : env36239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36238_36239 : H12AffineEnvironment.transform 15 12590 env36238 = env36239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env36238 == env36239) = true)

def env36240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,8494,1345,8623,320,9245,0,477,17,8510,9673,1281,318,1296,1296,3173,8205,8200,257,1281,1344,1856]

theorem envBound36240 : H12AffineFastState.Bounded env36240 := by
  intro p hp
  have h : env36240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36239_36240 : H12AffineEnvironment.transform 11 0 env36239 = env36240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36239 == env36240) = true)

theorem identity36240 : scanCanonicalize (H12AffineFastState.compose env36240 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound36240 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36241 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,0,8192,1108,9244,8298,1029,8427,4,9245,0,153,17,8314,9357,1093,122,1108,1108,3173,8205,8200,69,1093,1028,1540]

theorem envBound36241 : H12AffineFastState.Bounded env36241 := by
  intro p hp
  have h : env36241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36240_36241 : H12AffineEnvironment.transform 7 68 env36240 = env36241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env36240 == env36241) = true)

theorem identity36241 : scanCanonicalize (H12AffineFastState.compose env36241 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36241 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36242 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8192,80,8216,8298,1,8427,4,8217,0,153,17,8314,8329,65,122,80,80,2145,8205,8200,69,65,0,512]

theorem envBound36242 : H12AffineFastState.Bounded env36242 := by
  intro p hp
  have h : env36242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36241_36242 : H12AffineEnvironment.transform 9 4 env36241 = env36242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36241 == env36242) = true)

def env36243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,8495,1344,8622,321,9244,1,477,16,8510,9672,1281,319,1297,1296,3173,8205,8200,257,1280,1344,1857]

theorem envBound36243 : H12AffineFastState.Bounded env36243 := by
  intro p hp
  have h : env36243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36239_36243 : H12AffineEnvironment.transform 11 1 env36239 = env36243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env36239 == env36243) = true)

theorem identity36243 : scanCanonicalize (H12AffineFastState.compose env36243 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound36243 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1296,324,1142,1344,1271,321,325,1,477,16,1127,145,1281,319,1297,1296,3173,1364,1361,257,1280,1344,1857]

theorem envBound36244 : H12AffineFastState.Bounded env36244 := by
  intro p hp
  have h : env36244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36243_36244 : H12AffineEnvironment.transform 12 1369 env36243 = env36244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env36243 == env36244) = true)

theorem identity36244 : scanCanonicalize (H12AffineFastState.compose env36244 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound36244 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36245 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,1,436,509,324,155,429,26,321,325,1,477,16,138,145,492,319,508,509,2184,441,444,257,493,429,940]

theorem envBound36245 : H12AffineFastState.Bounded env36245 := by
  intro p hp
  have h : env36245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36244_36245 : H12AffineEnvironment.transform 9 237 env36244 = env36245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env36244 == env36245) = true)

theorem identity36245 : scanCanonicalize (H12AffineFastState.compose env36245 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound36245 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env36246 : List Nat := [2,4,8,16,32,64,128,256,460,237,2048,1,436,509,324,155,429,26,321,325,1,477,16,138,145,492,319,508,509,2184,441,444,257,493,429,96]

theorem envBound36246 : H12AffineFastState.Bounded env36246 := by
  intro p hp
  have h : env36246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36245_36246 : H12AffineEnvironment.transform 8 460 env36245 = env36246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env36245 == env36246) = true)

theorem identity36246 : scanCanonicalize (H12AffineFastState.compose env36246 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound36246 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36247 : List Nat := [2,4,8,16,32,64,128,256,460,237,508,1,436,509,324,155,429,26,321,325,1,477,16,138,145,492,319,508,509,372,441,444,257,493,429,96]

theorem envBound36247 : H12AffineFastState.Bounded env36247 := by
  intro p hp
  have h : env36247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36246_36247 : H12AffineEnvironment.transform 10 508 env36246 = env36247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env36246 == env36247) = true)

theorem identity36247 : scanCanonicalize (H12AffineFastState.compose env36247 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36247 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env36248 : List Nat := [2,4,8,16,32,64,89,256,277,52,293,1,365,292,324,66,372,26,321,325,1,260,16,83,72,309,319,293,292,372,352,357,257,308,372,96]

theorem envBound36248 : H12AffineFastState.Bounded env36248 := by
  intro p hp
  have h : env36248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36247_36248 : H12AffineEnvironment.transform 6 89 env36247 = env36248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36247 == env36248) = true)

theorem identity36248 : scanCanonicalize (H12AffineFastState.compose env36248 (packedSelected [1,3,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36248 : packedSelected [1,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env36249 : List Nat := [2,4,8,16,32,64,89,37,48,52,0,1,72,1,97,66,81,26,100,96,1,33,16,83,72,16,26,0,1,81,69,64,36,17,81,96]

theorem envBound36249 : H12AffineFastState.Bounded env36249 := by
  intro p hp
  have h : env36249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36248_36249 : H12AffineEnvironment.transform 7 37 env36248 = env36249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36248 == env36249) = true)

theorem identity36249 : scanCanonicalize (H12AffineFastState.compose env36249 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound36249 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36250 : List Nat := [2,4,8,16,32,58,35,37,48,52,0,1,50,1,27,56,43,26,30,26,1,33,16,41,50,16,26,0,1,43,63,58,36,17,43,26]

theorem envBound36250 : H12AffineFastState.Bounded env36250 := by
  intro p hp
  have h : env36250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36249_36250 : H12AffineEnvironment.transform 5 58 env36249 = env36250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env36249 == env36250) = true)

theorem identity36250 : scanCanonicalize (H12AffineFastState.compose env36250 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36250 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env36251 : List Nat := [2,4,4,16,32,54,35,37,48,52,0,1,50,1,23,52,39,22,18,22,1,33,16,37,50,16,22,0,1,39,51,54,36,17,39,22]

theorem envBound36251 : H12AffineFastState.Bounded env36251 := by
  intro p hp
  have h : env36251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36250_36251 : H12AffineEnvironment.transform 2 4 env36250 = env36251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36250 == env36251) = true)

theorem identity36251 : scanCanonicalize (H12AffineFastState.compose env36251 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36251 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36252 : List Nat := [2,4,4,6,32,32,35,37,38,34,0,1,36,1,1,34,39,0,4,0,1,33,6,37,36,6,0,0,1,39,37,32,36,7,39,0]

theorem envBound36252 : H12AffineFastState.Bounded env36252 := by
  intro p hp
  have h : env36252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36251_36252 : H12AffineEnvironment.transform 3 6 env36251 = env36252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36251 == env36252) = true)

theorem identity36252 : scanCanonicalize (H12AffineFastState.compose env36252 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36252 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env36253 : List Nat := [2,4,4,6,7,7,4,2,1,5,0,1,3,1,1,5,0,0,4,0,1,6,6,2,3,6,0,0,1,0,2,7,3,7,0,0]

theorem envBound36253 : H12AffineFastState.Bounded env36253 := by
  intro p hp
  have h : env36253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36252_36253 : H12AffineEnvironment.transform 4 7 env36252 = env36253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36252 == env36253) = true)

theorem identity36253 : scanCanonicalize (H12AffineFastState.compose env36253 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36254 : List Nat := [0,4,4,4,5,5,4,0,1,5,0,1,1,1,1,5,0,0,4,0,1,4,4,0,1,4,0,0,1,0,0,5,1,5,0,0]

theorem envBound36254 : H12AffineFastState.Bounded env36254 := by
  intro p hp
  have h : env36254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36253_36254 : H12AffineEnvironment.transform 0 0 env36253 = env36254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36253 == env36254) = true)

theorem identity36254 : scanCanonicalize (H12AffineFastState.compose env36254 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36255 : List Nat := [0,0,0,0,1,1,0,0,1,1,0,1,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,1,1,1,0,0]

theorem envBound36255 : H12AffineFastState.Bounded env36255 := by
  intro p hp
  have h : env36255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36254_36255 : H12AffineEnvironment.transform 1 0 env36254 = env36255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36254 == env36255) = true)

def env36256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4096,476,74046,69649,13768,78895,332222,74815,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound36256 : H12AffineFastState.Bounded env36256 := by
  intro p hp
  have h : env36256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36217_36256 : H12AffineEnvironment.transform 13 1297 env36217 = env36256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36217 == env36256) = true)

def env36257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4096,476,74046,69649,13768,78895,4414,74815,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound36257 : H12AffineFastState.Bounded env36257 := by
  intro p hp
  have h : env36257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36256_36257 : H12AffineEnvironment.transform 17 65664 env36256 = env36257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36256 == env36257) = true)

theorem identity36257 : scanCanonicalize (H12AffineFastState.compose env36257 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound36257 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5158,12361,5286,4417,13341,4096,476,13592,1079,13768,8201,4414,12313,1296,10604,8204,8201,257,12297,1344,5953]

theorem envBound36258 : H12AffineFastState.Bounded env36258 := by
  intro p hp
  have h : env36258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36257_36258 : H12AffineEnvironment.transform 15 5158 env36257 = env36258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env36257 == env36258) = true)

def env36259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,5158,1345,5286,4417,277,4096,476,16,1079,192,5377,4414,1297,1296,7268,5380,5377,257,1281,1344,5953]

theorem envBound36259 : H12AffineFastState.Bounded env36259 := by
  intro p hp
  have h : env36259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36258_36259 : H12AffineEnvironment.transform 12 5384 env36258 = env36259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env36258 == env36259) = true)

theorem identity36259 : scanCanonicalize (H12AffineFastState.compose env36259 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36259 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36260 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4364,277,276,4130,325,4258,4417,277,4096,476,16,51,192,4357,4414,277,276,6240,4352,4357,257,261,324,4933]

theorem envBound36260 : H12AffineFastState.Bounded env36260 := by
  intro p hp
  have h : env36260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36259_36260 : H12AffineEnvironment.transform 9 4 env36259 = env36260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36259 == env36260) = true)

theorem identity36260 : scanCanonicalize (H12AffineFastState.compose env36260 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound36260 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36261 : List Nat := [2,4,8,16,32,64,128,256,512,4,863,4096,4364,277,276,4130,325,4258,4417,277,4096,476,16,51,192,4357,4414,277,276,4927,4352,4357,257,261,324,4933]

theorem envBound36261 : H12AffineFastState.Bounded env36261 := by
  intro p hp
  have h : env36261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36260_36261 : H12AffineEnvironment.transform 10 863 env36260 = env36261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env36260 == env36261) = true)

def env36262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,5158,1344,5286,4417,276,4096,476,17,1079,193,5376,4414,1296,1296,7269,5381,5376,257,1280,1344,5953]

theorem envBound36262 : H12AffineFastState.Bounded env36262 := by
  intro p hp
  have h : env36262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36258_36262 : H12AffineEnvironment.transform 12 5385 env36258 = env36262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env36258 == env36262) = true)

theorem identity36262 : scanCanonicalize (H12AffineFastState.compose env36262 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36262 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36263 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,1,277,4406,80,4534,4417,276,4096,476,17,295,193,4112,4414,0,0,6517,4117,4112,257,16,80,4689]

theorem envBound36263 : H12AffineFastState.Bounded env36263 := by
  intro p hp
  have h : env36263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36262_36263 : H12AffineEnvironment.transform 9 272 env36262 = env36263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36262 == env36263) = true)

theorem identity36263 : scanCanonicalize (H12AffineFastState.compose env36263 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound36263 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36264 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,4096,4121,1,184,4251,80,4123,4332,185,4096,113,17,138,193,4112,4243,0,0,6360,4117,4112,172,16,80,4689]

theorem envBound36264 : H12AffineFastState.Bounded env36264 := by
  intro p hp
  have h : env36264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36263_36264 : H12AffineEnvironment.transform 7 173 env36263 = env36264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36263 == env36264) = true)

theorem identity36264 : scanCanonicalize (H12AffineFastState.compose env36264 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound36264 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env36265 : List Nat := [2,4,8,16,32,64,128,173,512,189,539,4096,4121,1,184,4251,80,4123,4332,185,4096,113,17,138,193,4112,4243,0,0,4803,4117,4112,172,16,80,4689]

theorem envBound36265 : H12AffineFastState.Bounded env36265 := by
  intro p hp
  have h : env36265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36264_36265 : H12AffineEnvironment.transform 10 539 env36264 = env36265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env36264 == env36265) = true)

theorem identity36265 : scanCanonicalize (H12AffineFastState.compose env36265 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36265 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env36266 : List Nat := [2,4,8,16,32,64,18,63,512,47,539,4096,4121,1,42,4105,80,4123,4222,43,4096,113,17,24,83,4112,4097,0,0,4689,4117,4112,62,16,80,4689]

theorem envBound36266 : H12AffineFastState.Bounded env36266 := by
  intro p hp
  have h : env36266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36265_36266 : H12AffineEnvironment.transform 6 18 env36265 = env36266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36265 == env36266) = true)

theorem identity36266 : scanCanonicalize (H12AffineFastState.compose env36266 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 75) := by decide +kernel

theorem selectedBound36266 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36267 : List Nat := [2,4,8,16,32,64,18,63,512,47,539,75,82,1,42,66,80,80,53,43,75,113,17,24,83,91,74,0,0,538,94,91,62,16,80,538]

theorem envBound36267 : H12AffineFastState.Bounded env36267 := by
  intro p hp
  have h : env36267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36266_36267 : H12AffineEnvironment.transform 11 75 env36266 = env36267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 75 env36266 == env36267) = true)

theorem identity36267 : scanCanonicalize (H12AffineFastState.compose env36267 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound36267 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36268 : List Nat := [2,4,8,16,32,64,18,63,42,47,49,75,82,1,42,66,80,80,53,43,75,113,17,24,83,91,74,0,0,48,94,91,62,16,80,48]

theorem envBound36268 : H12AffineFastState.Bounded env36268 := by
  intro p hp
  have h : env36268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36267_36268 : H12AffineEnvironment.transform 8 42 env36267 = env36268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env36267 == env36268) = true)

theorem identity36268 : scanCanonicalize (H12AffineFastState.compose env36268 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound36268 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36269 : List Nat := [2,4,8,16,32,11,18,63,42,47,49,0,25,1,42,9,27,27,53,43,0,58,17,24,24,16,1,0,0,48,21,16,62,16,27,48]

theorem envBound36269 : H12AffineFastState.Bounded env36269 := by
  intro p hp
  have h : env36269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36268_36269 : H12AffineEnvironment.transform 5 11 env36268 = env36269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env36268 == env36269) = true)

theorem identity36269 : scanCanonicalize (H12AffineFastState.compose env36269 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound36269 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36270 : List Nat := [2,4,8,16,12,11,18,19,6,3,29,0,25,1,6,9,27,27,25,7,0,22,17,24,24,16,1,0,0,28,21,16,18,16,27,28]

theorem envBound36270 : H12AffineFastState.Bounded env36270 := by
  intro p hp
  have h : env36270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36269_36270 : H12AffineEnvironment.transform 4 12 env36269 = env36270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env36269 == env36270) = true)

theorem identity36270 : scanCanonicalize (H12AffineFastState.compose env36270 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36270 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36271 : List Nat := [2,3,8,16,11,11,18,19,1,3,26,0,25,1,1,9,27,27,25,0,0,17,17,24,24,16,1,0,0,27,18,16,18,16,27,27]

theorem envBound36271 : H12AffineFastState.Bounded env36271 := by
  intro p hp
  have h : env36271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36270_36271 : H12AffineEnvironment.transform 1 3 env36270 = env36271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36270 == env36271) = true)

theorem identity36271 : scanCanonicalize (H12AffineFastState.compose env36271 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36271 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36272 : List Nat := [2,3,8,10,11,11,8,9,1,3,0,0,3,1,1,9,1,1,3,0,0,11,11,2,2,10,1,0,0,1,8,10,8,10,1,1]

theorem envBound36272 : H12AffineFastState.Bounded env36272 := by
  intro p hp
  have h : env36272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36271_36272 : H12AffineEnvironment.transform 3 10 env36271 = env36272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36271 == env36272) = true)

def env36273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4096,476,74046,69649,13768,78895,4415,74815,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound36273 : H12AffineFastState.Bounded env36273 := by
  intro p hp
  have h : env36273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36256_36273 : H12AffineEnvironment.transform 17 65665 env36256 = env36273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36256 == env36273) = true)

theorem identity36273 : scanCanonicalize (H12AffineFastState.compose env36273 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound36273 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,358,9481,487,4417,13341,4096,476,8280,4471,13768,13641,4415,9561,1296,15404,8204,8201,257,9545,1344,5953]

theorem envBound36274 : H12AffineFastState.Bounded env36274 := by
  intro p hp
  have h : env36274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36273_36274 : H12AffineEnvironment.transform 15 358 env36273 = env36274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env36273 == env36274) = true)

def env36275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,358,1345,487,4417,5205,4096,476,16,4471,5504,5377,4415,1297,1296,7268,68,65,257,1281,1344,5953]

theorem envBound36275 : H12AffineFastState.Bounded env36275 := by
  intro p hp
  have h : env36275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36274_36275 : H12AffineEnvironment.transform 12 72 env36274 = env36275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env36274 == env36275) = true)

theorem identity36275 : scanCanonicalize (H12AffineFastState.compose env36275 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36275 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36276 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,72,277,4176,358,325,487,4417,4177,4096,476,16,4471,4484,4357,4415,277,276,6240,68,65,257,261,324,4933]

theorem envBound36276 : H12AffineFastState.Bounded env36276 := by
  intro p hp
  have h : env36276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36275_36276 : H12AffineEnvironment.transform 9 4 env36275 = env36276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36275 == env36276) = true)

theorem identity36276 : scanCanonicalize (H12AffineFastState.compose env36276 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound36276 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36277 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,325,72,277,277,358,325,487,4,276,325,476,16,50,193,64,122,277,276,2341,68,65,257,261,324,512]

theorem envBound36277 : H12AffineFastState.Bounded env36277 := by
  intro p hp
  have h : env36277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36276_36277 : H12AffineEnvironment.transform 11 325 env36276 = env36277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env36276 == env36277) = true)

theorem identity36277 : scanCanonicalize (H12AffineFastState.compose env36277 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36277 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36278 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,24,277,277,310,277,439,4,276,277,396,16,50,145,16,42,277,276,2341,20,17,257,261,276,512]

theorem envBound36278 : H12AffineFastState.Bounded env36278 := by
  intro p hp
  have h : env36278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36277_36278 : H12AffineEnvironment.transform 5 16 env36277 = env36278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36277 == env36278) = true)

theorem identity36278 : scanCanonicalize (H12AffineFastState.compose env36278 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound36278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36279 : List Nat := [2,4,8,16,32,16,128,256,512,4,696,277,24,277,277,310,277,439,4,276,277,396,16,50,145,16,42,277,276,925,20,17,257,261,276,512]

theorem envBound36279 : H12AffineFastState.Bounded env36279 := by
  intro p hp
  have h : env36279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36278_36279 : H12AffineEnvironment.transform 10 696 env36278 = env36279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env36278 == env36279) = true)

theorem identity36279 : scanCanonicalize (H12AffineFastState.compose env36279 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound36279 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36280 : List Nat := [2,4,8,16,32,16,35,256,512,4,539,277,24,277,277,310,277,276,4,276,277,303,16,50,50,16,42,277,276,830,20,17,257,261,276,512]

theorem envBound36280 : H12AffineFastState.Bounded env36280 := by
  intro p hp
  have h : env36280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36279_36280 : H12AffineEnvironment.transform 6 35 env36279 = env36280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env36279 == env36280) = true)

theorem identity36280 : scanCanonicalize (H12AffineFastState.compose env36280 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound36280 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36281 : List Nat := [2,4,8,16,32,16,35,256,43,4,48,277,24,277,277,310,277,276,4,276,277,303,16,50,50,16,42,277,276,277,20,17,257,261,276,43]

theorem envBound36281 : H12AffineFastState.Bounded env36281 := by
  intro p hp
  have h : env36281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36280_36281 : H12AffineEnvironment.transform 8 43 env36280 = env36281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env36280 == env36281) = true)

theorem identity36281 : scanCanonicalize (H12AffineFastState.compose env36281 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36281 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36282 : List Nat := [2,4,8,16,11,16,8,256,0,4,27,277,24,277,277,285,277,276,4,276,277,260,16,25,25,16,1,277,276,277,20,17,257,261,276,0]

theorem envBound36282 : H12AffineFastState.Bounded env36282 := by
  intro p hp
  have h : env36282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36281_36282 : H12AffineEnvironment.transform 4 11 env36281 = env36282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36281 == env36282) = true)

theorem identity36282 : scanCanonicalize (H12AffineFastState.compose env36282 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound36282 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36283 : List Nat := [2,4,8,16,11,16,8,14,0,4,27,27,24,27,27,19,27,26,4,26,27,10,16,25,25,16,1,27,26,27,20,17,15,11,26,0]

theorem envBound36283 : H12AffineFastState.Bounded env36283 := by
  intro p hp
  have h : env36283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36282_36283 : H12AffineEnvironment.transform 7 14 env36282 = env36283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env36282 == env36283) = true)

theorem identity36283 : scanCanonicalize (H12AffineFastState.compose env36283 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36283 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36284 : List Nat := [2,4,8,11,11,11,8,14,0,4,0,0,3,0,0,8,0,1,4,1,0,10,11,2,2,11,1,0,1,0,15,10,15,11,1,0]

theorem envBound36284 : H12AffineFastState.Bounded env36284 := by
  intro p hp
  have h : env36284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36283_36284 : H12AffineEnvironment.transform 3 11 env36283 = env36284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36283 == env36284) = true)

theorem identity36284 : scanCanonicalize (H12AffineFastState.compose env36284 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36285 : List Nat := [2,4,5,6,6,6,5,3,0,4,0,0,3,0,0,5,0,1,4,1,0,7,6,2,2,6,1,0,1,0,2,7,2,6,1,0]

theorem envBound36285 : H12AffineFastState.Bounded env36285 := by
  intro p hp
  have h : env36285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36284_36285 : H12AffineEnvironment.transform 2 5 env36284 = env36285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36284 == env36285) = true)

def env36286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,358,1344,487,4417,5204,4096,476,17,4471,5505,5376,4415,1296,1296,7269,69,64,257,1280,1344,5953]

theorem envBound36286 : H12AffineFastState.Bounded env36286 := by
  intro p hp
  have h : env36286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36274_36286 : H12AffineEnvironment.transform 12 73 env36274 = env36286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env36274 == env36286) = true)

theorem identity36286 : scanCanonicalize (H12AffineFastState.compose env36286 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound36286 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1297,1029,358,1344,487,273,1028,80,476,17,295,1489,1360,367,1296,1296,3125,69,64,257,1280,1344,1809]

theorem envBound36287 : H12AffineFastState.Bounded env36287 := by
  intro p hp
  have h : env36287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36286_36287 : H12AffineEnvironment.transform 11 80 env36286 = env36287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env36286 == env36287) = true)

theorem identity36287 : scanCanonicalize (H12AffineFastState.compose env36287 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound36287 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36288 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,73,1212,1029,203,1261,74,188,1028,80,113,17,138,1148,1277,194,1213,1213,3125,69,64,172,1197,1261,1724]

theorem envBound36288 : H12AffineFastState.Bounded env36288 := by
  intro p hp
  have h : env36288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36287_36288 : H12AffineEnvironment.transform 7 173 env36287 = env36288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36287 == env36288) = true)

theorem identity36288 : scanCanonicalize (H12AffineFastState.compose env36288 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound36288 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env36289 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1703,80,73,1212,1029,203,1261,74,188,1028,80,113,17,138,1148,1277,194,1213,1213,658,69,64,172,1197,1261,1724]

theorem envBound36289 : H12AffineFastState.Bounded env36289 := by
  intro p hp
  have h : env36289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36288_36289 : H12AffineEnvironment.transform 10 1703 env36288 = env36289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env36288 == env36289) = true)

theorem identity36289 : scanCanonicalize (H12AffineFastState.compose env36289 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound36289 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env36290 : List Nat := [2,4,8,16,32,64,128,173,512,47,648,80,73,147,42,203,194,74,188,43,80,113,17,138,83,210,194,146,146,658,69,64,172,130,194,659]

theorem envBound36290 : H12AffineFastState.Bounded env36290 := by
  intro p hp
  have h : env36290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36289_36290 : H12AffineEnvironment.transform 9 47 env36289 = env36290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env36289 == env36290) = true)

theorem identity36290 : scanCanonicalize (H12AffineFastState.compose env36290 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36290 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36291 : List Nat := [2,4,8,10,32,64,128,173,512,47,648,74,73,137,42,203,194,74,166,43,74,107,11,138,73,200,194,136,136,648,69,64,172,130,194,649]

theorem envBound36291 : H12AffineFastState.Bounded env36291 := by
  intro p hp
  have h : env36291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36290_36291 : H12AffineEnvironment.transform 3 10 env36290 = env36291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36290 == env36291) = true)

theorem identity36291 : scanCanonicalize (H12AffineFastState.compose env36291 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36291 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36292 : List Nat := [2,4,8,10,32,64,128,173,1,47,137,74,73,137,42,203,194,74,166,43,74,107,11,138,73,200,194,136,136,137,69,64,172,130,194,136]

theorem envBound36292 : H12AffineFastState.Bounded env36292 := by
  intro p hp
  have h : env36292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36291_36292 : H12AffineEnvironment.transform 8 1 env36291 = env36292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36291 == env36292) = true)

theorem identity36292 : scanCanonicalize (H12AffineFastState.compose env36292 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound36292 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36293 : List Nat := [2,4,8,10,32,64,104,69,1,47,97,74,73,97,42,35,42,74,78,43,74,107,11,98,73,32,42,96,96,97,69,64,68,106,42,96]

theorem envBound36293 : H12AffineFastState.Bounded env36293 := by
  intro p hp
  have h : env36293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36292_36293 : H12AffineEnvironment.transform 6 104 env36292 = env36293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env36292 == env36293) = true)

theorem identity36293 : scanCanonicalize (H12AffineFastState.compose env36293 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound36293 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36294 : List Nat := [2,4,8,10,32,32,8,37,1,47,1,42,41,1,42,35,42,42,46,43,42,11,11,2,41,32,42,0,0,1,37,32,36,10,42,0]

theorem envBound36294 : H12AffineFastState.Bounded env36294 := by
  intro p hp
  have h : env36294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36293_36294 : H12AffineEnvironment.transform 5 32 env36293 = env36294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env36293 == env36294) = true)

theorem identity36294 : scanCanonicalize (H12AffineFastState.compose env36294 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound36294 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36295 : List Nat := [2,4,8,10,3,3,8,6,1,12,1,9,10,1,9,0,9,9,13,8,9,11,11,2,10,3,9,0,0,1,6,3,7,10,9,0]

theorem envBound36295 : H12AffineFastState.Bounded env36295 := by
  intro p hp
  have h : env36295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36294_36295 : H12AffineEnvironment.transform 4 3 env36294 = env36295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env36294 == env36295) = true)

theorem identity36295 : scanCanonicalize (H12AffineFastState.compose env36295 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36295 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36296 : List Nat := [2,4,0,2,3,3,0,6,1,4,1,1,2,1,1,0,1,1,5,0,1,3,3,2,2,3,1,0,0,1,6,3,7,2,1,0]

theorem envBound36296 : H12AffineFastState.Bounded env36296 := by
  intro p hp
  have h : env36296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36295_36296 : H12AffineEnvironment.transform 2 0 env36295 = env36296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36295 == env36296) = true)

theorem identity36296 : scanCanonicalize (H12AffineFastState.compose env36296 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36297 : List Nat := [2,0,0,2,3,3,0,2,1,0,1,1,2,1,1,0,1,1,1,0,1,3,3,2,2,3,1,0,0,1,2,3,3,2,1,0]

theorem envBound36297 : H12AffineFastState.Bounded env36297 := by
  intro p hp
  have h : env36297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36296_36297 : H12AffineEnvironment.transform 1 0 env36296 = env36297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36296 == env36297) = true)

theorem identity36297 : scanCanonicalize (H12AffineFastState.compose env36297 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36297 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36298 : List Nat := [0,0,0,0,1,1,0,0,1,0,1,1,0,1,1,0,1,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,1,0,1,0]

theorem envBound36298 : H12AffineFastState.Bounded env36298 := by
  intro p hp
  have h : env36298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36297_36298 : H12AffineEnvironment.transform 0 0 env36297 = env36298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36297 == env36298) = true)

def env36299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123164,28888,78894,385203,90414,1297,96347,25885,25881,257,74799,1344,21073]

theorem envBound36299 : H12AffineFastState.Bounded env36299 := by
  intro p hp
  have h : env36299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36215_36299 : H12AffineEnvironment.transform 18 21585 env36215 = env36299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env36215 == env36299) = true)

theorem identity36299 : scanCanonicalize (H12AffineFastState.compose env36299 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound36299 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4096,5277,91183,66896,28888,78894,328959,90414,1297,96347,25885,25881,257,74799,1344,21073]

theorem envBound36300 : H12AffineFastState.Bounded env36300 := by
  intro p hp
  have h : env36300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36299_36300 : H12AffineEnvironment.transform 14 25676 env36299 = env36300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env36299 == env36300) = true)

def env36301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4096,5277,74047,66896,13768,78894,328959,74814,1297,81227,8205,8201,257,74799,1344,5953]

theorem envBound36301 : H12AffineFastState.Bounded env36301 := by
  intro p hp
  have h : env36301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36300_36301 : H12AffineEnvironment.transform 13 1296 env36300 = env36301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36300 == env36301) = true)

def env36302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4096,5277,74047,66896,13768,78894,1151,74814,1297,81227,8205,8201,257,74799,1344,5953]

theorem envBound36302 : H12AffineFastState.Bounded env36302 := by
  intro p hp
  have h : env36302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36301_36302 : H12AffineEnvironment.transform 17 65664 env36301 = env36302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36301 == env36302) = true)

theorem identity36302 : scanCanonicalize (H12AffineFastState.compose env36302 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound36302 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9327,0,9455,4417,8541,4096,5277,1360,8511,13768,4161,1151,81,1297,6436,8205,8201,257,64,1344,5953]

theorem envBound36303 : H12AffineFastState.Bounded env36303 := by
  intro p hp
  have h : env36303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36302_36303 : H12AffineEnvironment.transform 15 9327 env36302 = env36303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env36302 == env36303) = true)

def env36304 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8495,0,8623,4417,8541,4096,4573,16,8511,12424,4161,319,81,81,6436,8205,8201,257,64,0,4609]

theorem envBound36304 : H12AffineFastState.Bounded env36304 := by
  intro p hp
  have h : env36304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36303_36304 : H12AffineEnvironment.transform 9 320 env36303 = env36304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36303 == env36304) = true)

theorem identity36304 : scanCanonicalize (H12AffineFastState.compose env36304 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound36304 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36305 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,80,8540,8495,0,8623,4,8541,325,152,16,8511,8653,260,319,81,81,2145,8205,8201,257,64,0,836]

theorem envBound36305 : H12AffineFastState.Bounded env36305 := by
  intro p hp
  have h : env36305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36304_36305 : H12AffineEnvironment.transform 11 325 env36304 = env36305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env36304 == env36305) = true)

theorem identity36305 : scanCanonicalize (H12AffineFastState.compose env36305 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound36305 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36306 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,80,8216,8299,0,8427,4,8217,1,152,16,8315,8329,64,123,81,81,2145,8205,8201,69,64,0,512]

theorem envBound36306 : H12AffineFastState.Bounded env36306 := by
  intro p hp
  have h : env36306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36305_36306 : H12AffineEnvironment.transform 7 68 env36305 = env36306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env36305 == env36306) = true)

theorem identity36306 : scanCanonicalize (H12AffineFastState.compose env36306 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound36306 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36307 : List Nat := [2,4,8,16,32,64,128,68,512,4,123,1,8192,80,8216,8299,0,8427,4,8217,1,152,16,8315,8329,64,123,81,81,26,8205,8201,69,64,0,512]

theorem envBound36307 : H12AffineFastState.Bounded env36307 := by
  intro p hp
  have h : env36307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36306_36307 : H12AffineEnvironment.transform 10 123 env36306 = env36307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env36306 == env36307) = true)

theorem identity36307 : scanCanonicalize (H12AffineFastState.compose env36307 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound36307 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36308 : List Nat := [2,4,8,16,32,64,128,68,97,4,123,1,8192,80,8216,8299,0,8427,4,8217,1,152,16,8315,8329,64,123,81,81,26,8205,8201,69,64,0,97]

theorem envBound36308 : H12AffineFastState.Bounded env36308 := by
  intro p hp
  have h : env36308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36307_36308 : H12AffineEnvironment.transform 8 97 env36307 = env36308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env36307 == env36308) = true)

theorem identity36308 : scanCanonicalize (H12AffineFastState.compose env36308 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound36308 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env36309 : List Nat := [2,4,8,16,32,64,57,68,97,4,123,1,8192,80,8216,8299,0,8274,4,8217,1,33,16,8315,8240,64,123,81,81,26,8205,8201,69,64,0,97]

theorem envBound36309 : H12AffineFastState.Bounded env36309 := by
  intro p hp
  have h : env36309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36308_36309 : H12AffineEnvironment.transform 6 57 env36308 = env36309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env36308 == env36309) = true)

theorem identity36309 : scanCanonicalize (H12AffineFastState.compose env36309 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36309 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36310 : List Nat := [2,4,8,16,32,64,57,68,97,4,123,1,41,80,49,66,0,123,4,48,1,33,16,82,25,64,123,81,81,26,36,32,69,64,0,97]

theorem envBound36310 : H12AffineFastState.Bounded env36310 := by
  intro p hp
  have h : env36310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36309_36310 : H12AffineEnvironment.transform 12 41 env36309 = env36310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36309 == env36310) = true)

theorem identity36310 : scanCanonicalize (H12AffineFastState.compose env36310 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound36310 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36311 : List Nat := [2,4,8,16,32,11,57,15,42,4,48,1,41,27,49,9,0,48,4,48,1,33,16,25,25,11,48,26,26,26,36,32,14,11,0,42]

theorem envBound36311 : H12AffineFastState.Bounded env36311 := by
  intro p hp
  have h : env36311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36310_36311 : H12AffineEnvironment.transform 5 11 env36310 = env36311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env36310 == env36311) = true)

theorem identity36311 : scanCanonicalize (H12AffineFastState.compose env36311 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36311 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36312 : List Nat := [2,4,8,16,17,11,8,15,27,4,1,1,24,27,0,9,0,1,4,1,1,16,16,25,25,11,1,26,26,26,21,17,14,11,0,27]

theorem envBound36312 : H12AffineFastState.Bounded env36312 := by
  intro p hp
  have h : env36312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36311_36312 : H12AffineEnvironment.transform 4 17 env36311 = env36312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36311 == env36312) = true)

theorem identity36312 : scanCanonicalize (H12AffineFastState.compose env36312 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36312 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36313 : List Nat := [2,4,8,11,10,11,8,15,0,4,1,1,3,0,0,9,0,1,4,1,1,11,11,2,2,11,1,1,1,1,14,10,14,11,0,0]

theorem envBound36313 : H12AffineFastState.Bounded env36313 := by
  intro p hp
  have h : env36313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36312_36313 : H12AffineEnvironment.transform 3 11 env36312 = env36313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36312 == env36313) = true)

theorem identity36313 : scanCanonicalize (H12AffineFastState.compose env36313 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36313 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36314 : List Nat := [2,2,8,11,10,11,8,9,0,2,1,1,3,0,0,9,0,1,2,1,1,11,11,2,2,11,1,1,1,1,8,10,8,11,0,0]

theorem envBound36314 : H12AffineFastState.Bounded env36314 := by
  intro p hp
  have h : env36314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36313_36314 : H12AffineEnvironment.transform 1 2 env36313 = env36314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36313 == env36314) = true)

def env36315 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8494,0,8622,4417,8541,4096,4572,17,8511,12425,4161,318,81,80,6436,8205,8201,257,64,1,4608]

theorem envBound36315 : H12AffineFastState.Bounded env36315 := by
  intro p hp
  have h : env36315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36303_36315 : H12AffineEnvironment.transform 9 321 env36303 = env36315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36303 == env36315) = true)

theorem identity36315 : scanCanonicalize (H12AffineFastState.compose env36315 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound36315 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36316 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,81,4421,4407,0,4535,4417,4420,4096,4572,17,4390,144,4161,318,81,80,6436,4116,4112,257,64,1,4608]

theorem envBound36316 : H12AffineFastState.Bounded env36316 := by
  intro p hp
  have h : env36316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36315_36316 : H12AffineEnvironment.transform 12 4121 env36315 = env36316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env36315 == env36316) = true)

theorem identity36316 : scanCanonicalize (H12AffineFastState.compose env36316 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound36316 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env36317 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,4096,4121,81,4421,4407,0,4535,4417,4420,4096,4572,17,4390,144,4161,318,81,80,6436,4116,4112,257,64,1,4232]

theorem envBound36317 : H12AffineFastState.Bounded env36317 := by
  intro p hp
  have h : env36317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36316_36317 : H12AffineEnvironment.transform 8 136 env36316 = env36317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env36316 == env36317) = true)

theorem identity36317 : scanCanonicalize (H12AffineFastState.compose env36317 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound36317 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env36318 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,276,269,81,81,35,0,163,85,80,276,200,17,50,144,341,318,81,80,2096,256,260,257,64,1,412]

theorem envBound36318 : H12AffineFastState.Bounded env36318 := by
  intro p hp
  have h : env36318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36317_36318 : H12AffineEnvironment.transform 11 276 env36317 = env36318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env36317 == env36318) = true)

theorem identity36318 : scanCanonicalize (H12AffineFastState.compose env36318 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound36318 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env36319 : List Nat := [2,4,8,16,32,64,128,256,136,321,351,276,269,81,81,35,0,163,85,80,276,200,17,50,144,341,318,81,80,367,256,260,257,64,1,412]

theorem envBound36319 : H12AffineFastState.Bounded env36319 := by
  intro p hp
  have h : env36319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36318_36319 : H12AffineEnvironment.transform 10 351 env36318 = env36319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env36318 == env36319) = true)

theorem identity36319 : scanCanonicalize (H12AffineFastState.compose env36319 (packedSelected [0,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36319 : packedSelected [0,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env36320 : List Nat := [2,4,8,16,32,64,19,256,27,321,351,276,269,81,81,35,0,48,85,80,276,91,17,50,3,341,318,81,80,367,256,260,257,64,1,271]

theorem envBound36320 : H12AffineFastState.Bounded env36320 := by
  intro p hp
  have h : env36320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36319_36320 : H12AffineEnvironment.transform 6 19 env36319 = env36320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36319 == env36320) = true)

theorem identity36320 : scanCanonicalize (H12AffineFastState.compose env36320 (packedSelected [0,2,5,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36320 : packedSelected [0,2,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36321 : List Nat := [2,4,8,16,11,64,19,256,27,321,351,276,269,81,81,8,0,27,85,80,276,91,17,25,3,341,277,81,80,324,256,260,257,64,1,271]

theorem envBound36321 : H12AffineFastState.Bounded env36321 := by
  intro p hp
  have h : env36321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36320_36321 : H12AffineEnvironment.transform 4 11 env36320 = env36321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36320 == env36321) = true)

theorem identity36321 : scanCanonicalize (H12AffineFastState.compose env36321 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound36321 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env36322 : List Nat := [2,4,8,16,11,64,19,15,27,78,80,27,2,81,81,8,0,27,85,80,27,91,17,25,3,90,26,81,80,75,15,11,14,64,1,0]

theorem envBound36322 : H12AffineFastState.Bounded env36322 := by
  intro p hp
  have h : env36322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36321_36322 : H12AffineEnvironment.transform 7 15 env36321 = env36322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env36321 == env36322) = true)

def env36323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4096,5277,74047,66896,13768,78894,1150,74814,1297,81227,8205,8201,257,74799,1344,5953]

theorem envBound36323 : H12AffineFastState.Bounded env36323 := by
  intro p hp
  have h : env36323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36301_36323 : H12AffineEnvironment.transform 17 65665 env36301 = env36323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36301 == env36323) = true)

theorem identity36323 : scanCanonicalize (H12AffineFastState.compose env36323 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound36323 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12591,5440,12718,4417,8541,4096,5277,4112,13439,13768,1281,1150,5393,1297,3172,8205,8201,257,5376,1344,5953]

theorem envBound36324 : H12AffineFastState.Bounded env36324 := by
  intro p hp
  have h : env36324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36323_36324 : H12AffineEnvironment.transform 15 12591 env36323 = env36324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env36323 == env36324) = true)

def env36325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8495,1344,8622,321,8541,0,1181,16,9343,9672,1281,1150,1297,1297,3172,8205,8201,257,1280,1344,1857]

theorem envBound36325 : H12AffineFastState.Bounded env36325 := by
  intro p hp
  have h : env36325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36324_36325 : H12AffineEnvironment.transform 11 0 env36324 = env36325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36324 == env36325) = true)

theorem identity36325 : scanCanonicalize (H12AffineFastState.compose env36325 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound36325 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36326 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1109,8217,8298,1029,8427,4,8216,0,1181,16,9343,9357,1092,1150,1108,1108,3172,8205,8201,68,1093,1029,1540]

theorem envBound36326 : H12AffineFastState.Bounded env36326 := by
  intro p hp
  have h : env36326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36325_36326 : H12AffineEnvironment.transform 7 69 env36325 = env36326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env36325 == env36326) = true)

theorem identity36326 : scanCanonicalize (H12AffineFastState.compose env36326 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36326 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36327 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8217,8298,1,8427,4,8216,0,153,16,8315,8329,64,122,80,80,2144,8205,8201,68,65,1,512]

theorem envBound36327 : H12AffineFastState.Bounded env36327 := by
  intro p hp
  have h : env36327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36326_36327 : H12AffineEnvironment.transform 9 4 env36326 = env36327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36326 == env36327) = true)

theorem identity36327 : scanCanonicalize (H12AffineFastState.compose env36327 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound36327 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36328 : List Nat := [2,4,8,16,32,64,104,69,512,4,2048,0,8192,81,8217,8298,1,8195,4,8216,0,113,16,8315,8289,64,122,80,80,2144,8205,8201,68,65,1,512]

theorem envBound36328 : H12AffineFastState.Bounded env36328 := by
  intro p hp
  have h : env36328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36327_36328 : H12AffineEnvironment.transform 6 104 env36327 = env36328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env36327 == env36328) = true)

theorem identity36328 : scanCanonicalize (H12AffineFastState.compose env36328 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 2147) := by decide +kernel

theorem selectedBound36328 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env36329 : List Nat := [2,4,8,16,32,64,104,69,512,4,2048,0,2147,81,2170,2057,1,2144,4,2171,0,113,16,2072,2050,64,122,80,80,2144,2158,2154,68,65,1,512]

theorem envBound36329 : H12AffineFastState.Bounded env36329 := by
  intro p hp
  have h : env36329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36328_36329 : H12AffineEnvironment.transform 12 2147 env36328 = env36329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2147 env36328 == env36329) = true)

theorem identity36329 : scanCanonicalize (H12AffineFastState.compose env36329 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound36329 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env36330 : List Nat := [2,4,8,16,32,64,104,69,26,4,2048,0,2147,81,2170,2057,1,2144,4,2171,0,113,16,2072,2050,64,122,80,80,2144,2158,2154,68,65,1,26]

theorem envBound36330 : H12AffineFastState.Bounded env36330 := by
  intro p hp
  have h : env36330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36329_36330 : H12AffineEnvironment.transform 8 26 env36329 = env36330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env36329 == env36330) = true)

theorem identity36330 : scanCanonicalize (H12AffineFastState.compose env36330 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36330 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36331 : List Nat := [2,4,8,16,11,64,67,69,26,4,2048,0,2120,81,2129,2057,1,2123,4,2128,0,90,16,2072,2050,64,81,80,80,2123,2117,2113,68,65,1,26]

theorem envBound36331 : H12AffineFastState.Bounded env36331 := by
  intro p hp
  have h : env36331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36330_36331 : H12AffineEnvironment.transform 4 11 env36330 = env36331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36330 == env36331) = true)

theorem identity36331 : scanCanonicalize (H12AffineFastState.compose env36331 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound36331 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env36332 : List Nat := [2,4,8,16,11,64,67,69,26,4,74,0,2,81,27,67,1,1,4,26,0,90,16,82,72,64,81,80,80,1,15,11,68,65,1,26]

theorem envBound36332 : H12AffineFastState.Bounded env36332 := by
  intro p hp
  have h : env36332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36331_36332 : H12AffineEnvironment.transform 10 74 env36331 = env36332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env36331 == env36332) = true)

theorem identity36332 : scanCanonicalize (H12AffineFastState.compose env36332 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36332 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36333 : List Nat := [2,4,8,10,11,64,67,69,0,4,74,0,2,75,1,67,1,1,4,0,0,64,10,72,72,64,75,74,74,1,15,11,68,65,1,0]

theorem envBound36333 : H12AffineFastState.Bounded env36333 := by
  intro p hp
  have h : env36333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36332_36333 : H12AffineEnvironment.transform 3 10 env36332 = env36333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36332 == env36333) = true)

theorem identity36333 : scanCanonicalize (H12AffineFastState.compose env36333 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound36333 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36334 : List Nat := [2,4,8,10,11,11,8,14,0,4,1,0,2,0,1,8,1,1,4,0,0,11,10,3,3,11,0,1,1,1,15,11,15,10,1,0]

theorem envBound36334 : H12AffineFastState.Bounded env36334 := by
  intro p hp
  have h : env36334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36333_36334 : H12AffineEnvironment.transform 5 11 env36333 = env36334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env36333 == env36334) = true)

theorem identity36334 : scanCanonicalize (H12AffineFastState.compose env36334 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36335 : List Nat := [2,2,8,10,11,11,8,8,0,2,1,0,2,0,1,8,1,1,2,0,0,11,10,3,3,11,0,1,1,1,9,11,9,10,1,0]

theorem envBound36335 : H12AffineFastState.Bounded env36335 := by
  intro p hp
  have h : env36335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36334_36335 : H12AffineEnvironment.transform 1 2 env36334 = env36335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36334 == env36335) = true)

def env36336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8494,1345,8623,320,8541,1,1180,17,9342,9673,1281,1150,1296,1297,3172,8205,8201,257,1281,1344,1856]

theorem envBound36336 : H12AffineFastState.Bounded env36336 := by
  intro p hp
  have h : env36336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36324_36336 : H12AffineEnvironment.transform 11 1 env36324 = env36336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env36324 == env36336) = true)

theorem identity36336 : scanCanonicalize (H12AffineFastState.compose env36336 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound36336 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,24,1296,324,310,1345,439,320,325,1,1180,17,1126,1489,1281,1150,1296,1297,3172,21,17,257,1281,1344,1856]

end H12CloudChart2